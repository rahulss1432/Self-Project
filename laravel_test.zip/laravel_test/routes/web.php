<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Auth::routes();
Route::group(['middleware' => 'guest'], function() {
	Route::get('/', 'Auth\LoginController@showLogin');
	Route::get('/login', 'Auth\LoginController@showLogin');
	Route::post('/login', 'Auth\LoginController@login');
	Route::get('/register', 'Auth\RegisterController@showRegister');
	Route::post('/register', 'Auth\RegisterController@register');
	Route::get('forgot-password', 'Auth\RegisterController@forgotPassword');
    Route::post('send-forgot-email', 'Auth\RegisterController@sendForgotEmail');
    Route::get('reset-password/{token}', 'Auth\RegisterController@resetPassword');
    Route::post('reset-password', 'Auth\RegisterController@reset');
});
Route::group(['middleware' => 'admin'], function() {
	Route::post('/logout', 'Auth\LoginController@logout');
	Route::get('/home', 'HomeController@index')->name('home');
	Route::post('/submit-questions', 'HomeController@submitQuestions');
	Route::get('/user-profile', 'HomeController@userProfile');
});
