<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Register</div>
                <div class="panel-body">
                    <form class="form-horizontal" id="registerForm" method="POST" action="<?php echo e(url('/register')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Name</label>
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>
                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">Profile Image</label>
                            <div class="col-md-6">
                                <input id="profile_image" type="file" class="form-control" name="profile_image">
                            </div>
                        </div>
						<div class="form-group">
                            <label for="password" class="col-md-4 control-label">Password</label>
                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>
                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="button" onclick="addUser();" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
					<?php echo JsValidator::formRequest('App\Http\Requests\RegisterRequest','#registerForm'); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function addUser() {
		var formData = new FormData($('#registerForm')[0]);
		//formData.append('_token', '<?php echo e(csrf_token()); ?>');
        if ($('#registerForm').valid()) {
            $.ajax({
                type: "POST",
                url: "<?php echo e(url('/register')); ?>",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response)
                {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
						window.location.href = "<?php echo e(url('/')); ?>";
                    } else {
                        toastrAlertMessage('error', response.message);
                    }
                }
            });
        }
    }
	
	// toaster common function
    function toastrAlertMessage(type, msg) {
        if (type == 'success') {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.success(msg, {timeOut: 2000});
        } else {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.error(msg, {timeOut: 2000});
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>