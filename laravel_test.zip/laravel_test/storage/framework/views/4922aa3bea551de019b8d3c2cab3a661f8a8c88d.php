<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    You are logged in!
                </div>
				<div class="panel-body">
				<form method="post" action="<?php echo e(url('/submit-questions')); ?>">
					<?php echo e(csrf_field()); ?>

                    <?php if($result->count()>0): ?>
						<?php 
							$i = 1;
						 ?>
						<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<input type="hidden" name="question_id[<?php echo e($key); ?>]" value="<?php echo e($data->id); ?>">
							<div style="margin-left:20px"><strong>Q.<?php echo e($i++); ?> <?php echo e($data->question); ?></strong></div>
							<ol>
							<?php if(!empty($data->answers)): ?>
							<?php $__currentLoopData = $data->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <li><input type="radio" name="answer_id[<?php echo e($key); ?>]" value="<?php echo e($val->id); ?>"> <?php echo e(!empty($val->answer) ? $val->answer : '-'); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
							</ol>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					<input style="margin-left:300px" type="submit" class="btn btn-primary" value="Submit">
				</form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>