<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Response;
use File;

class User extends Model {
	
	public static function register($post){
		try{
			$fileName = "";
            $categoryIconPath = public_path() . '/uploads/users';
            if (!is_dir($categoryIconPath)) {
                File::makeDirectory($categoryIconPath, $mode = 0777, true, true);
            }
            if ($post->hasFile('profile_image')) {
                $file = $post->file('profile_image');
                $fileName = $file->getClientOriginalName();
                $fileExtension = strtolower($file->getClientOriginalExtension());
                $imageExist = public_path() . '/uploads/users/' . $fileName;
                $post->file('profile_image')->move('public/uploads/users', $fileName);
            }
			$model = new User();
			$model->name = $post['name'];
			$model->email = $post['email'];
			$model->password = bcrypt($post['password']);
			$model->user_profile = $fileName;
			$model->save();
		    return response()->json(['success' => true, 'message' => 'User added successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
	}
	
	public static function forgotEmail($post) {
        try {
            $user = User::where('email', $post['email'])->first();
            if (!empty($user)) {
                $reset_password_token = str_random(30);
                $data = [];
                $data['request'] = 'admin_forgot_password';
                $data['link'] = url('/reset-password/' . $reset_password_token);
                $data['username'] = $user->name;
                $data['email'] = $user->email;
                $data['subject'] = 'Reset password link';
                $mail = sendMail($data);
                if (!empty($user)) {
                    $user->reset_token = $reset_password_token;
                    if ($user->save()) {
                        return Response::json(['success' => true, 'message' => 'send mail successfully']);
                    }
                } else {
                    return Response::json(['success' => false, 'message' => 'something went wrong']);
                }
                return redirect('/');
            }
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function ResetPassword($post) {
        try {
            $reset_token = $post['reset_token'];
            $password = $post['password'];
            $user = User::where('reset_token', $reset_token)->first();
            if (!empty($user)) {
                $user->reset_token = NULL;
                $user->password = bcrypt($password);
                $user->save();
                return Response::json(['success' => true, 'message' => 'Password reset successfully']);
            } else {
                return Response::json(['success' => false, 'message' => 'Reset token not found']);
            }
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
}
