<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Response;

class UserQuestion extends Model {
	
	public function questions(){
		return $this->belongsTo('\App\Models\Question','question_id', 'id');
	}
	
	public function rightQuestions(){
		return $this->belongsTo('\App\Models\RightAnswer','answer_id', 'answer_id');
	}
	
	public static function submitQuestions($post){
		try{
			$userId = \Auth::guard('admin')->user()->id;
			if (!empty($post['question_id'])) {
                foreach ($post['question_id'] as $key => $question) {
					if(!empty($post['answer_id'][$key]) && count($post['answer_id'][$key]) > 0){
						$questionModel = new UserQuestion();
						$questionModel->question_id = $question;
						$questionModel->answer_id = $post['answer_id'][$key];
						$questionModel->user_id = $userId;
						$questionModel->save();
					}
				}
			}
			return redirect('/home');
		    //return response()->json(['success' => true, 'message' => 'User question added successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
	}
	
	public static function getAllQuestions(){
		$userId = \Auth::guard('admin')->user()->id;
		try{
			return UserQuestion::where('user_id',$userId)->get();
		}catch(\Exception $e){
			return $e->getMessage();
		}
	}
}
