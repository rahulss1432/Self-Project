<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Response;

class Answer extends Model {
	
	public function rightAns(){
		return $this->hasOne('\App\Models\RightAnswer','answer_id', 'id');
	}
	
}
