<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Response;

class Question extends Model {
	
	public function answers(){
		return $this->hasMany('\App\Models\Answer','question_id', 'id');
	}

	public static function getQuestions(){
		try{
			return Question::get();
		}catch(\Exeption $e){
			return $e->getMessage();
		}
	}

}
