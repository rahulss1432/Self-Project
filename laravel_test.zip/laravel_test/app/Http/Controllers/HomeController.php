<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Question;
use App\Models\UserQuestion;

class HomeController extends Controller
{
    public function index()
    {
		$result = Question::getQuestions();
        return view('home',['result' => $result]);
    }
	
	public function submitQuestions(Request $request)
    {
		return UserQuestion::submitQuestions($request);
    }
	
	public function userProfile()
    {
		$result = UserQuestion::getAllQuestions();
        return view('user-profile',['result' => $result]);
    }
}
