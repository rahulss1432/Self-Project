<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use App\Http\Requests\RegisterRequest;

class RegisterController extends Controller
{	
	public function showRegister(){
		return view('auth.register');
	}
	
	public function register(RegisterRequest $request){
		return User::register($request);
	}
	
	public function forgotPassword() {
        try {
            return view('auth.forgot-password');
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
	
	public function sendForgotEmail(Request $request) {
        return User::forgotEmail($request->all());
    }
	
	public function resetPassword($token) {
        try {
            return view('auth.password_reset', ['token' => $token]);
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
	
	public function Reset(Request $request) {
        return User::ResetPassword($request->all());
    }	
}
