@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>
                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    You are logged in!
                </div>
				<div class="panel-body">
				<form method="post" action="{{url('/submit-questions')}}">
					{{csrf_field()}}
                    @if($result->count()>0)
						@php
							$i = 1;
						@endphp
						@foreach($result as $key => $data)
							<input type="hidden" name="question_id[{{$key}}]" value="{{$data->id}}">
							<div style="margin-left:20px"><strong>Q.{{$i++}} {{$data->question}}</strong></div>
							<ol>
							@if(!empty($data->answers))
							@foreach($data->answers as $val)
							  <li><input type="radio" name="answer_id[{{$key}}]" value="{{$val->id}}"> {{!empty($val->answer) ? $val->answer : '-'}}</li>
							@endforeach
							@endif
							</ol>
						@endforeach
					@endif
					<input style="margin-left:300px" type="submit" class="btn btn-primary" value="Submit">
				</form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
