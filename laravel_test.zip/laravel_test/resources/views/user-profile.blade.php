@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">User Profile</div>
                <div class="panel-body">
				<img src="{{url('public/uploads/users/'.Auth::guard('admin')->user()->user_profile)}}" width="100px"></br>
				Name: {{Auth::guard('admin')->user()->name}}</br>
				Email: {{Auth::guard('admin')->user()->email}}
				@php
				$totalMark = '';
				@endphp
				@if($result->count()>0)
					@foreach($result as $key => $data)
						<div style="margin-left:20px"><strong>{{$key + 1}}. {{$data->questions->question}}</strong></div>
						<ol>
						@if(!empty($data->questions->answers))
						@foreach($data->questions->answers as $val)
						<li><input type="radio" {{!empty($val->id == $data->answer_id) ? 'checked' : ''}} disabled> {{!empty($val->answer) ? $val->answer : '-'}}</li>
						@endforeach
						@php
						$rightAnswer = !empty($data->rightQuestions->answer_id) ? $data->rightQuestions->answer_id : '';
						$totalMark[] = !empty($data->rightQuestions->mark) ? $data->rightQuestions->mark : '';
						@endphp
						@if($data->answer_id == $rightAnswer)
							<div style="margin-left:30px"><strong>Your answer is right.</strong></div> 
						@else
							<div style="margin-left:30px"><strong>Your answer is wrong.</strong></div>
						@endif
						@endif
						</ol>
					@endforeach
				@endif
				@if(!empty($totalMark))
				<div style="margin-left:30px"><strong>Your Total Mark is {{array_sum($totalMark)}} and Percent is {{array_sum($totalMark)/count($result)}}%</strong></div>
				@endif
				</div>
            </div>
        </div>
    </div>
</div>
@endsection
