<?php

$params = require_once('params.php');

$account = require_once('account.php');
$event = require_once('event.php');
$paths = array_merge($account['paths'], $event['paths']);
$definitions = array_merge($account['definitions']);

echo json_encode([
    'tags' => [
        [
            'name' => 'account',
            'description' => 'guest user operations.',
        ],
        [
            'name' => 'event',
            'description' => 'user event operations.',
        ],
    ],
    "swagger" => "2.0",
    "info" => [
        "version" => "2.0.0",
        "title" => "Angular API"
    ],
    "host" => $params['host'],
    "basePath" => $params['basePath'],
    "schemes" => [
        "http",
        "https"
    ],
    'paths' => $paths,
    'definitions' => $definitions
]);
