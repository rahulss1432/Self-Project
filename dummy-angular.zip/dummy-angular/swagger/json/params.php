<?php
$baseUrl = 'http://localhost/new-angular/';
return array_merge([
    'apiVersion' => '1.0.0',
    'swaggerVersion' => '3.2.0',
    'host' => 'localhost/new-angular/',
    'basePath' => '/api',
    'baseUrl' => $baseUrl
]);