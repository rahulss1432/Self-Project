<?php
return [
    'paths' => [
        "/event-submit" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "Event Up",
                "description" => "Event Sign Up",
                "operationId" => "event",
                "consumes" => [
                    "multipart/form-data"
                ],
                "produces" => [
                   "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "user_id",
                        "in" => "formData",
                        "description" => "user_id",
                        "required" => true,
                        "type" => "string",
                    ],
                   
                    [
                        "name" => "startDate",
                        "in" => "formData",
                        "description" => "startTime",
                        "required" => true,
                        "type" => "string"
                    ],
                    [
                        "name" => "endDate",
                        "in" => "formData",
                        "description" => "endTime",
                        "required" => true,
                        "type" => "string",
                    ],
                    [
                        "name" => "message",
                        "in" => "formData",
                        "description" => "message",
                        "required" => true,
                        "type" => "string",
                    ],
                   
                ],
                "responses" => [
                    
                ]
            ]
        ],
    ],
  ];
