<?php
return [
    'paths' => [
        "/signup" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "User Sign Up",
                "description" => "User Sign Up",
                "operationId" => "signup",
                "consumes" => [
                    "multipart/form-data"
                ],
                "produces" => [
                   "application/json"
                ],
                "parameters" => [
                   
//                    [
//                        "name" => "profile_picture",
//                        "in" => "formData",
//                        "description" => "Profile Picture ",
//                        "required" => false,
//                        "type" => "file"
//                    ],
                    [
                        "name" => "name",
                        "in" => "formData",
                        "description" => "Name",
                        "required" => true,
                        "type" => "string",
                    ],
                   
                    [
                        "name" => "email",
                        "in" => "formData",
                        "description" => "Email",
                        "required" => true,
                        "type" => "string"
                    ],
                    [
                        "name" => "password",
                        "in" => "formData",
                        "description" => "Password",
                        "required" => true,
                        "type" => "string",
                    ],
                   
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/useraccount" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "User Account Sign Up",
                "description" => "User Account Sign Up",
                "operationId" => "userAccount",
                "consumes" => [
                    "multipart/form-data"
                ],
                "produces" => [
                   "application/json"
                ],
                "parameters" => [
                   [
                        "name" => "name",
                        "in" => "formData",
                        "description" => "Name",
                        "required" => false,
                        "type" => "string"
                    ],
                    [
                        "name" => "id",
                        "in" => "formData",
                        "description" => "User Id",
                        "required" => true,
                        "type" => "string",
                    ],
                    [
                        "name" => "address",
                        "in" => "formData",
                        "description" => "Address",
                        "required" => true,
                        "type" => "string",
                    ],
                   
                    [
                        "name" => "phoneNumber",
                        "in" => "formData",
                        "description" => "phoneNumber",
                        "required" => true,
                        "type" => "string"
                    ],
                    [
                        "name" => "working",
                        "in" => "formData",
                        "description" => "working",
                        "required" => true,
                        "type" => "string",
                    ],
                    [
                        "name" => "profileImage",
                        "in" => "formData",
                        "description" => "profileImage",
                        "required" => true,
                        "type" => "file",
                    ],
                    [
                        "name" => "security",
                        "in" => "formData",
                        "description" => "Security",
                        "required" => true,
                        "type" => "string",
                    ],
                   
                ],
                "responses" => [
                    
                ]
            ]
        ],
         "/login" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "Login a user",
                "description" => "Login for User",
                "operationId" => "login",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "Login for user",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/login"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        
    ],
    'definitions' => [
         'login' => [
            'type' => "object",
            'properties' => [
                'user_type' => [
                    'type' => 'string'
                ],
                'email' => [
                    'type' => 'string'
                ],
                'password' => [
                    'type' => 'string'
                ],
                
            ],
            'xml' => [
                'name' => "Login"
            ]
        ],
         'signup' => [
            'type' => "object",
            'properties' => [
                'name' => [
                    'type' => 'string'
                ],
                'email' => [
                    'type' => 'string'
                ],
                'password' => [
                    'type' => 'string'
                ],
                
            ],
            'xml' => [
                'name' => "Signup"
            ]
        ],
    ]
    ];
