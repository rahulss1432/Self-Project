<?php

namespace App\Http\Controllers\Api;

use App\User;
use App\Models\UserProfile;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class UserController extends Controller {

    public function changeAccount(request $data) {
        $result = UserProfile::changeUserProfile($data);          
        if ($result) {
            return response()->json(['success' => true, 'data' => 'Account changes successfully!']);
        } else {
            return response()->json(['error' => true, 'data' => 'Please try again']);
        }
    }
    
    public function getLoginUser($id){
            $query = User::select(['user_profile.profile_image','users.id','users.name','users.email','user_profile.phone_number','user_profile.working'])
                        ->leftJoin('user_profile', 'user_profile.user_id', '=', 'users.id')
                        ->where('users.id', '=', $id)
                       ->first();
           return response()->json(['success' => true, 'data' => $query]);
    }
    
    
    public function getUserList(){
       $query = User::all();
       return response()->json(['success' => true, 'data' => $query]);
    }
	
    public function addUser(Request $request){
        $post = $request->all(); 
        $model = new User();
        $model->name = $post['name'];
        $model->email = $post['email'];
        $model->type = $post['role'];
        $model->password =  bcrypt(str_random(10));
        if($model->save()){
             return response()->json(['success' => true, 'message' => 'Add user successfully!']);
        }else{
            return response()->json(['success' => false, 'message' => 'Please try again.']); 
        }
    }
    
    public function removeUser($id) {
       $query = User::where(['id' => $id])->first();
       if($query->delet()){
          return response()->json(['success' => true, 'message' => 'Remove user successfully!']); 
       }else{
          return response()->json(['success' => false, 'message' => 'Please try again']);
       }
    }
   
}
