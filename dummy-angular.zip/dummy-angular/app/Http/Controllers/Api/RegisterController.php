<?php

namespace App\Http\Controllers\Api;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use JWTAuthException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;


class RegisterController extends Controller {

    public function register(request $data) {
         $rules = array(
            'email' => 'email|unique:users,email',
        );
        $validator = Validator::make($data->all(), $rules);
        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => 'Email has been alrady tacken']);
        }
        $result = User::create([
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'password' => bcrypt($data['password']),
        ]);
        if ($result) {
            return response()->json(['success' => true, 'message' => $result->email . ' ' . 'Your registretion successfully!']);
        } else {
            return response()->json(['error' => true, 'message' => $result]);
        }
    }
    
    
    
	
    public function changePassword(Request $request){
        $getUser = User::where(['id' =>  $request['userId']])->first();
        if(Hash::check($request['oldPassword'], $getUser->password)){
           $getUser->password  =  bcrypt($request['newPassword']);
           if($getUser->save()){
               return response()->json(['success' => true, 'message' => 'Change Password successfully!']);
           }
        }else{
              return response()->json(['error' => true,  'message' =>'Current Password dos not match!']);
        }
    }

}
