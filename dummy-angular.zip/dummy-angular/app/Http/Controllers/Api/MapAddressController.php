<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\MapAddress;

class MapAddressController extends Controller {

    public function submitAddress(Request $request) {
        $post = $request->all();
        if (!empty($post)) {
            $result = MapAddress::submitAddress($post);
            if (!empty($result)) {
                return response()->json(['success' => true, 'message' => 'Address Submited  successfully!']);
            } else {
                return response()->json(['error' => true, 'message' => 'please try again']);
            }
        }
    }

    public function getMessageList() {
        $result = MapAddress::paginate(3);
        return response()->json(['success' => true, 'data' => $result]);
    }
    
    public function removeAddress($id){
        $result = MapAddress::where(['id' => $id])->delete();
        if(!empty($result)){
            return response()->json(['success' => true, 'message' => 'Address deleted  successfully!']);
        }
    }
    
    public function getUpdateData($id){
      $query = MapAddress::where(['id' => $id])->first();
      return response()->json(['success' => true, 'data' => $query]);
    }

}
