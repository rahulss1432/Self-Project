<?php

namespace App\Http\Controllers\Api;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\UserEvent;
use App\Models\CroppImage;
use File;

class UserEventController extends Controller {
   
    
     public function userEventSubmit(Request $request){
         if(!empty($request)){
             $result = UserEvent::eventSubmit($request->all()); 
             if(!empty($result)){
               return response()->json(['success' => true, 'message' => 'Submit event successfully!']);
             }else{
              return response()->json(['error' => true, 'message' => 'please try again']);
             }
         }
     }
     
     public function getEventList(){
         $query = UserEvent::all(); 
          return response()->json(['success' => true, 'data' => $query]);
     }
     
    public function updateEvent(Request $request){
         $post = $request->all();
         $model = UserEvent::where(['id' => $post['event_id']])->first();
         $start_date = date("Y-m-d",strtotime(date("Y-m-d", strtotime($model->start_date)) .$post['duration_start_days']." day"));
         $end_date = date("Y-m-d",strtotime(date("Y-m-d", strtotime($model->end_date)) .$post['duration_start_days']." day"));
         if(!empty($model)){
           $model->start_date = $start_date;
           $model->end_date = $end_date;
           if($model->save()){
             return response()->json(['success' => true, 'message' => 'Change events successfully!']);
           }else{
             return response()->json(['error' => true, 'message' => 'Please try again']);
           }
         }
    }
    
    
    
    
//    public function updateImages(Request $request){
//           $imagePath = base_path() . '/public/uploads/user/cropp-image';
//            if (!is_dir($imagePath)) {
//                File::makeDirectory($imagePath, $mode = 0777, true, true);
//            }
//            
//             $model = new CroppImage();
//             if ($request->hasFile('file')) {
//                    $photo = $request->file('file');
//                    $imageName = time() . '.' . $photo->getClientOriginalExtension();
//                    $destinationPath = $imagePath;
//                    $photo->move($destinationPath, $imageName);
//                    $imagePathName =  url('/public/uploads/user/cropp-image') .'/'.$imageName;
//                    $model->images = $imagePathName;
//                    $model->save();
//                    return response()->json(['success' => true, 'message' => 'Image Upload successfully!']); 
//                }else{
//                    return response()->json(['error' => true, 'message' => 'Please try again']);
//                }
//                
//    }
    
     
}
