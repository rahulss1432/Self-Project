<?php

namespace App\Http\Controllers\Api;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\Messages;

class MessagesController extends Controller {
   
     public function getMessageList($id){
          $query = Messages::where(['to_id' => $id])->get(); 
          return response()->json(['success' => true, 'data' => $query]);
     }
   
     
}
