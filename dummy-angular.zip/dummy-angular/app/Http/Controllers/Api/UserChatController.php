<?php

namespace App\Http\Controllers\Api;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\UserChat;

class UserChatController extends Controller {
    
    public function updateEvent(Request $request){
         $post = $request->all();
         $result = UserChat::submitUserChat($post);
         if(!empty($result)){
             return true;
         }else{
             return false;
         }
         
    }
    
     
}
