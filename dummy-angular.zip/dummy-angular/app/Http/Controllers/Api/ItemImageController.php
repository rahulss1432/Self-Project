<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\CroppImage;
use File;

class ItemImageController extends Controller {

    public function updateImages(Request $request) {
        $imagePath = base_path() . '/public/uploads/user/cropp-image';
        if (!is_dir($imagePath)) {
            File::makeDirectory($imagePath, $mode = 0777, true, true);
        }

        $model = new CroppImage();
        if ($request->hasFile('file')) {
            $photo = $request->file('file');
            $imageName = time() . '.' . $photo->getClientOriginalExtension();
            $destinationPath = $imagePath;
            $photo->move($destinationPath, $imageName);
            $imagePathName = url('/public/uploads/user/cropp-image') . '/' . $imageName;
            $model->images = $imagePathName;
            $model->save();
            return response()->json(['success' => true, 'message' => 'Image Upload successfully!']);
        } else {
            return response()->json(['error' => true, 'message' => 'Please try again']);
        }
    }
    
    public function getItemImageList(){
        $query = CroppImage::all();
         return response()->json(['success' => true, 'data' => $query]);
    }
    public function deleteItemImage($id){
        $query = CroppImage::where('id',$id)->delete();
        return response()->json(['success' => true, 'data' => $query]);
    }

}
