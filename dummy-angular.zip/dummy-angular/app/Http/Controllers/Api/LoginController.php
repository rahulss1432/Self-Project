<?php

namespace App\Http\Controllers\Api;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use JWTAuth;
use JWTAuthException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Login Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles authenticating users for the application and
      | redirecting them to your home screen. The controller uses a trait
      | to conveniently provide its functionality to your applications.
      |
     */

use AuthenticatesUsers;

    /**
     * Auth guard
     *
     * @var
     */
    protected $auth;

    /**
     * lockoutTime
     *
     * @var
     */
    protected $lockoutTime;

    /**
     * maxLoginAttempts
     *
     * @var
     */
    protected $maxLoginAttempts;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * LoginController constructor.
     * @param Guard $auth
     */

    /**
     * Determine if the user has too many failed login attempts.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
    protected function hasTooManyLoginAttempts(Request $request) {
        return $this->limiter()->tooManyAttempts(
                        $this->throttleKey($request), $this->maxLoginAttempts, $this->lockoutTime
        );
    }
    
    public function login(Request $request) {
        if($request->email && $request->password){
        if(Auth::attempt($request->only('email', 'password'))) {
            $request->session()->regenerate();
            $this->clearLoginAttempts($request);
             return response()->json(['success' => true, 'loginUserData' => Auth::user()]);
        } else {
            return response()->json(['success' => false, 'message' => 'Email not registered to us']);
        }
     }else{
        return response()->json(['success' => false, 'message' => 'field not required']);
      }
    }
    
	
    public function logOut() {
      Auth::logout();
      return response()->json(['success' => true]);
    }

    public function username() {
        return 'email';
    }

    /**
     * Validate the user login request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */
    protected function validateLogin(Request $request) {
        $this->validate($request, [
            $this->username() => 'required', 'password' => 'required',
        ]);
    }

}
