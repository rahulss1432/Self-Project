<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\CenterManagers;


class CroppImage extends Model {

    protected $table = 'cropp-image';

  
}
