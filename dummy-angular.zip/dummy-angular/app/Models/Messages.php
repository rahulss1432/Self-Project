<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\CenterManagers;
use App\User;
use File;

class Messages extends Model {

    protected $table = 'messages';

}
