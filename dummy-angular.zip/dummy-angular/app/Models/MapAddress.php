<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MapAddress extends Model {

    protected $table = 'map_address';

    public static function submitAddress($postData) {
        if (!empty($postData['id'])) {
            $model = MapAddress::where(['id' => $postData['id']])->first();
        } else {
            $model = new MapAddress();
        }
        $model->lat = $postData['lat'];
        $model->lng = $postData['lng'];
        $model->country = $postData['country'];
        $model->state = $postData['state'];
        $model->street = $postData['street'];
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

}
