<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\CenterManagers;
use App\User;
use File;

class UserProfile extends Model {

    protected $table = 'user_profile';

    public static function changeUserProfile($post) {
        $model = User::where(['id' => $post['id']])->first();
        if (!empty($model)) {
            $model->name = $post['name'];
            if ($model->save()) {
                $ProfileModel = UserProfile::where(['user_id' => $post['id']])->first();
                if (empty($ProfileModel)) {
                    $ProfileModel = new UserProfile();
                }
                $ProfileModel->user_id = $model->id;
                $ProfileModel->name = $post['name'];
                $ProfileModel->working = $post['working'];
                $ProfileModel->phone_number = $post['phoneNumber'];
                $ProfileModel->address = $post['address'];
                $ProfileModel->security = $post['security'];

                $imagePath = base_path() . '/public/uploads/user/profile-image';
                if (!is_dir($imagePath)) {
                    File::makeDirectory($imagePath, $mode = 0777, true, true);
                }
                if ($post->hasFile('profileImage')) {
                    $photo = $post->file('profileImage');
                    $imageName = time() . '.' . $photo->getClientOriginalExtension();
                    $destinationPath = $imagePath;
                    $photo->move($destinationPath, $imageName);
                    $ProfileModel->profile_image =  url('/public/uploads/user/profile-image') .'/'.$imageName;
                }
                if($ProfileModel->save()){
                    return true;
                }
            }
            return false;
        }
        return false;
    }

}
