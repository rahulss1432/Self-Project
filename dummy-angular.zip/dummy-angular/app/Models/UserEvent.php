<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserEvent extends Model {

   protected $table = 'user_event';
   
   public static function eventSubmit($post){
       $model = new UserEvent();
       $model->user_id = $post['user_id'];
       $model->message = $post['message'];
       $model->start_date = date('Y-m-d');
       $model->end_date =   date('Y-m-d');
       $model->created_at = date('Y-m-d h:i:s');
       $model->updated_at = date('Y-m-d h:i:s');
       if($model->save()){
           return true;
       }else{
           return false;
       }
   }
  
}
