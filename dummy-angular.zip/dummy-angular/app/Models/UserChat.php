<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserChat extends Model {

   protected $table = 'user_chat';
   
   public static function submitUserChat($post){
       $model = new UserChat();
       $model->to_id  = $post['toId'];
       $model->from_id = $post['sender_id'];
       $model->message = $post['message'];
       $model->created_at = date('Y-m-d h:i:s');
       $model->updated_at = date('Y-m-d h:i:s');
       if($model->save()){
           return true;
       }else{
           return false;
       }
   }
  
}
