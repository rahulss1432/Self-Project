export const error_msg = {
    INPUT_REQUIRED: input_name => `${input_name} field is required`,
    MIN_LENGTH: minLength => `This field should have minimum ${minLength} characters`,
    MAX_LENGTH: maxLength => `This field can't exceed ${maxLength} characters`,  
    SESSION_TIMOUT_MESSAGE: "Your session has been timed out"
};

