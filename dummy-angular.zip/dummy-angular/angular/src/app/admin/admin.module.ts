import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { adminRouting } from './admin-routing.module';
import {AdminComponent} from './admin.component';
import { HeaderComponent } from './layoute/header/header.component';
import { SidebarComponent } from './layoute/sidebar/sidebar.component';
import { FooterComponent } from './layoute/footer/footer.component';
import { DashboardComponent } from './dashboard/dashboard.component';

@NgModule({
  imports: [
    CommonModule,
    adminRouting
  ],
  declarations: [
    AdminComponent,
    HeaderComponent,
    SidebarComponent,
    FooterComponent,
    DashboardComponent,
  ]
})
export class AdminModule { }
