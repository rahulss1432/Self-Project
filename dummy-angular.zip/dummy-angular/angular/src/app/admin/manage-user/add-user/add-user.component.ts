import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, AbstractControl, ValidationErrors } from "@angular/forms";
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { error_msg } from "../../../shared/error-message/error-message";
import { ManageUserService } from '../service/manage-user.service';

export interface addUserFormFileds {
  role: string;
  name: string;
  email: string;
}

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})

export class AddUserComponent implements OnInit {

 
  addUserForm: FormGroup;
  errorMsg = error_msg;
  loading: boolean;


  initData: addUserFormFileds = {
    role: '',
    name: '',
    email: '',
  };


  constructor(
     public toster: ToastrService,
     public fb: FormBuilder,
     public router: Router,
     private route: ActivatedRoute,
     public ManageUserApi: ManageUserService,
  ) { }

  ngOnInit() {
    this.createForm();
  }

   createForm(){
    this.addUserForm = this.fb.group(
      {
        email: [
          this.initData.email,
          Validators.compose([
            Validators.required,
            Validators.maxLength(30),
            Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/),
          ])
        ],
        name: [
          this.initData.name,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20),
            Validators.pattern(/(^\w+)\s?/)
          ])
        ],
        role: [
          this.initData.role,
          Validators.compose([
            Validators.required,
          ])
        ],
      },
    );
   }


  addUser(){
    if(this.addUserForm.valid) {
      const formVal = this.addUserForm.value;
      const formData = {};
      formData['name'] = formVal.name;
      formData['email'] = formVal.email;
      formData['role'] = formVal.role;
      this.ManageUserApi.addUser(formData).subscribe({
        next: data => {
            if(data['success'] == true){
              this.loading = false;
              this.toster.success(data['message']);
              this.router.navigate(['manage-user']);
            }else{
              this.loading = false;
              this.toster.error(data['message']);
            } 
        },error: err => {
            if (err.error && err.error.error) {
              this.toster.success('error!');
            } else {
              this.toster.success('error');
            }
            this.loading = false;
        },
        complete: () => {
         }
    });

    }else{
      Object.keys(this.addUserForm.controls).forEach(key => {
        const control = this.addUserForm.get(key);
        control.markAsTouched({ onlySelf: true });
      });
    }
  }
 
  get role() {
    return this.addUserForm.get("role");
  }

  get name() {
    return this.addUserForm.get("name");
  }
  
  get email(){
    return this.addUserForm.get("email");
  }



}
