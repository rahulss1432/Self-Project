import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { error_msg } from "../../shared/error-message/error-message";
import { ManageUserService } from './service/manage-user.service';

@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styleUrls: ['./manage-user.component.css']
})

export class ManageUserComponent implements OnInit {
 
  userlist:any;

  constructor(
    public toster: ToastrService,
    public router: Router,
    private route: ActivatedRoute,
    public ManageUserApi: ManageUserService,
  ) { }

  ngOnInit() {
     this.getUserList();
  }

  getUserList(){
    this.ManageUserApi.getUserList().subscribe({
      next: res => {
        if(res['success'] == true){
          this.userlist =  res['data'];
        }else{
          this.toster.error('error!');
        }
      }
    })
  }

  removeUser(id){
    this.ManageUserApi.removeUser(id).subscribe({
      next: res => {
        if(res['success'] == true){
          this.toster.success(res['message']);
        }else{
          this.toster.error('error!');
        }
      }
    })
  }

}
