import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageUserComponent } from './manage-user.component';
import { manageUserRouting } from './manage-user-routing.module';
import { ManageUserService } from './service/manage-user.service';
import { AddUserComponent } from './add-user/add-user.component';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    manageUserRouting,
    ReactiveFormsModule
  ],
  declarations: [
    ManageUserComponent,
    AddUserComponent
  ],
  providers: [
    ManageUserService
  ]
})
export class ManageUserModule { }
