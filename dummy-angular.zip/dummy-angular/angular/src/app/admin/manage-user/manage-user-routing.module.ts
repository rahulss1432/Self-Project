import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../auth/_guards';
import { CommonModule } from '@angular/common';
import { ManageUserComponent } from './manage-user.component';
import { AddUserComponent } from './add-user/add-user.component';

const MANAGE_USER_ROUTE: Routes = [
     { path: '',  component: ManageUserComponent },
     { path: 'add-user', component: AddUserComponent},

]
  
export const manageUserRouting = RouterModule.forChild(MANAGE_USER_ROUTE);
