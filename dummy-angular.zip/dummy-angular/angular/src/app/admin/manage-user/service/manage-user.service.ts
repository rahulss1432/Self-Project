import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, Response } from "@angular/http";
import { ApiHandler } from "../../../shared/service/api-handler.service";
import "rxjs";
import { Observable, throwError, BehaviorSubject } from "rxjs";
import { tap, map } from "rxjs/operators";


@Injectable({
  providedIn: 'root'
})
export class ManageUserService {

  constructor(
    private http: Http,
    private apiHandler: ApiHandler,
  ) { }

  getUserList(){
    return this.apiHandler.apiGet('http://localhost/dummy-angular/api/get-user-list');
  }

  addUser(fromData){
     return this.apiHandler.apiPost('http://localhost/dummy-angular/api/add-new-user', fromData);
  }

  removeUser(id){
     return this.apiHandler.apiDelete('http://localhost/dummy-angular/api/remove-user', id);
  }
}
