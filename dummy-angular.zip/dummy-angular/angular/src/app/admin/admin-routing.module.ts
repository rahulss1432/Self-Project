import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../auth/_guards';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { ManageUserModule } from './manage-user/manage-user.module';

const ADMIN_ROUTE: Routes = [
     { path: '',  component: AdminComponent, children: [
     { path: '', component: DashboardComponent },
     { path: 'manage-user', loadChildren: () => ManageUserModule , canActivate: [AuthGuard] },
  ]}
]
  
export const adminRouting = RouterModule.forChild(ADMIN_ROUTE);
