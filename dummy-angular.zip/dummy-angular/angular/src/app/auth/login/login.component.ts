import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, AbstractControl, ValidationErrors } from "@angular/forms";
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { error_msg } from "../../shared/error-message/error-message";
import { AuthService } from "../service";

export interface UserLoginFormFileds {
  email: string;
  password: string;
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  userLoginForm: FormGroup;
  errorMsg = error_msg;
  loading: boolean;
 
  constructor(
    public authService: AuthService,
    public toster: ToastrService,
    public fb: FormBuilder,
    public router: Router,
    private route: ActivatedRoute,
  ) { }

  initData: UserLoginFormFileds = {
    email: '',
    password: '',
  };

  ngOnInit() {
     this.createForm(); 
  }

  createForm() {
    this.userLoginForm = this.fb.group(
      {
        email: [
          this.initData.email,
          Validators.compose([
            Validators.required,
            Validators.maxLength(30),
            Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/),
          ])
        ],
        password: [
          this.initData.password,
          Validators.compose([
            Validators.required,
          ])
        ],
      },
    );
  }

  loginUser(){
    if (this.userLoginForm.valid) {
      const formVal = this.userLoginForm.value;
      const formData = {};
      formData['email'] = formVal.email;
      formData['password'] = formVal.password;
      this.authService.loginUser(formData).subscribe({
          next: data => {
              if(data['success'] == true){
                this.loading = false;
                this.router.navigate(['dashboard']);
              } else {
                this.loading = false;
                this.toster.error(data['message']);
              } 
          },error: err => {
              if (err.error && err.error.error) {
                this.toster.error('error!');
              } else {
                this.toster.error('error');
              }
              this.loading = false;
          },
          complete: () => {
          }
      });
    }else{
      Object.keys(this.userLoginForm.controls).forEach(key => {
        const control = this.userLoginForm.get(key);
        control.markAsTouched({ onlySelf: true });
      });
    }
  }

  get email() {
    return this.userLoginForm.get("email");
  }
  get password() {
    return this.userLoginForm.get("password");
  }

}
