import { Injectable, PLATFORM_ID, Inject } from "@angular/core";
import { Headers, Http, RequestOptions, Response } from "@angular/http";
import { ApiHandler } from "../../shared/service/api-handler.service";
import "rxjs";
import { Observable, throwError, BehaviorSubject } from "rxjs";
import { tap, map } from "rxjs/operators";

@Injectable({
	providedIn: 'root'
})

export class AuthService {

	constructor(
		  private http: Http,
		  private apiHandler: ApiHandler,
		) {
    }
	
	userSignUP(formData) {
		return this.apiHandler.apiPost('http://localhost/dummy-angular/api/signup', formData);
	}
	
	loginUser(formData) {
    	return this.apiHandler.apiPost('http://localhost/dummy-angular/api/login', formData).pipe(
			tap((response: any) => {
				if(response['success'] == true){
                  localStorage.setItem('currentLoginUser', response.loginUserData);
				}else{
					return response;
				}
         	})
		);
	}

}


