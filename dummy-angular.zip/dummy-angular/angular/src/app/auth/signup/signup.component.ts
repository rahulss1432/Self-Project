import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, AbstractControl, ValidationErrors } from "@angular/forms";
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { error_msg } from "../../shared/error-message/error-message";
import { AuthService } from "../service";

export interface UserRegistrationFormFileds {
  name: string;
  email: string;
  password: string;
  confirm_password: string;
}

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  userRegistrationForm: FormGroup;
  errorMsg = error_msg;
  initData: UserRegistrationFormFileds = {
    name: '',
    email: '',
    password: '',
    confirm_password: '',
  };

  loading: boolean;

  constructor(
    public authService: AuthService,
    public toster: ToastrService,
    public fb: FormBuilder,
    public router: Router,
    private route: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.userRegistrationForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20),
            Validators.pattern(/(^\w+)\s?/)
          ])
        ],

        email: [
          this.initData.email,
          Validators.compose([
            Validators.required,
            Validators.maxLength(30),
            Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/),
          ])
        ],
        password: [
          this.initData.password,
          Validators.compose([
            Validators.required,
            Validators.minLength(4),
            Validators.maxLength(20),
            Validators.pattern(/(^\w+)\s?/)
          ])
        ],
        confirm_password: [
          this.initData.confirm_password,
          Validators.compose([
            Validators.required,
            Validators.pattern(/(^\w+)\s?/)
          ])
        ],
      },
      {
        validator: this.MatchPassword.bind(this)
      }
      
    );
  }

  MatchPassword(control: AbstractControl): ValidationErrors | null {
    const pass = control.get("password").value;
    const confirmedPass = control.get("confirm_password").value;
    if (pass !== confirmedPass) {
      return { passError: { msg: "Password don't match" } };
    } else {
      return null;
    }
  }
 
  signUp() {
    if (this.userRegistrationForm.valid) {
      this.loading = true; 
      const formVal = this.userRegistrationForm.value;
      const formData = {};
      formData['name'] = formVal.name;
      formData['password'] = formVal.password;
      formData['email'] = formVal.email;
      this.authService.userSignUP(formData).subscribe({
        next: data => {
            if(data['success'] == true){
              this.loading = false;
              this.toster.success(data['message']);
              this.router.navigate(['/login']);
            }else{
              this.loading = false;
              this.toster.error(data['message']);
            } 
        },error: err => {
            if (err.error && err.error.error) {
              this.toster.success('error!');
            } else {
              this.toster.success('error');
            }
            this.loading = false;
        },
        complete: () => {
         }
    });
   }else{
      Object.keys(this.userRegistrationForm.controls).forEach(key => {
        const control = this.userRegistrationForm.get(key);
        control.markAsTouched({ onlySelf: true });
      });
    }
  }  
 

  get name() {
    return this.userRegistrationForm.get("name");
  }
  get email() {
    return this.userRegistrationForm.get("email");
  }
  get password() {
    return this.userRegistrationForm.get("password");
  }
  get confirm_password() {
    return this.userRegistrationForm.get("confirm_password");
  }


}
