<?php

use Illuminate\Http\Request;

/*
  |--------------------------------------------------------------------------
  | API Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register API routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | is assigned the "api" middleware group. Enjoy building your API!
  |
 */

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

    Route::POST('/login', 'Api\LoginController@login');
    Route::POST('/signup', 'Api\RegisterController@register');
    Route::post('/useraccount', 'Api\UserController@changeAccount');
    Route::post('/add-new-user', 'Api\UserController@addUser');
    Route::get('/user-details/{id}', 'Api\UserController@getLoginUser');
    Route::get('/remove-user/{id}', 'Api\UserController@removeUser');
    
    Route::get('/get-user-list', 'Api\UserController@getUserList');
    Route::get('/get-event-list', 'Api\UserEventController@getEventList');
    Route::post('/event-submit', 'Api\UserEventController@userEventSubmit');
    Route::post('/update-user-event', 'Api\UserEventController@updateEvent');
    Route::post('/upload-cropp-image', 'Api\ItemImageController@updateImages');
    Route::get('/get-item-image-list', 'Api\ItemImageController@getItemImageList');
    Route::get('/delete-item-image/{id}', 'Api\ItemImageController@deleteItemImage');
    Route::post('/save-message', 'Api\ItemImageController@deleteItemImage');
    Route::post('/change-password', 'Api\RegisterController@changePassword');
    Route::get('/getUserMessage/{id}', 'Api\MessagesController@getMessageList');
    Route::post('/save-address-location', 'Api\MapAddressController@submitAddress');
    Route::get('/get-address-list', 'Api\MapAddressController@getMessageList');
    Route::get('/remove-address/{id}', 'Api\MapAddressController@removeAddress');
    Route::get('/get-update-data/{id}', 'Api\MapAddressController@getUpdateData');
    
    Route::options('{any}', function() {
        return response()->json(['status' => true, 'message' => '', 'data' => []]);
    })->where('any', '.*');
