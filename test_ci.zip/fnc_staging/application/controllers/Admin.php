<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();

        if (!$this->session->userdata('super_admin'))
            redirect('login/admin_login');

        $this->load->model('type_model', 'fnc_types');
        $this->load->helper('email_template_helper');
        $this->load->library('cart');
        #$this->load->model('feedback_model', 'feedback');
        #$this->load->model('catering_model', 'catering_model');
        #$this->load->model('businesses_authorized_model', 'businesses_authorized_model');
    }

    public function index() {
        redirect('admin/dashboard');
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('login/admin_login');
    }

    public function dashboard() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $this->load->view('admin/dashboard');
        $this->load->view('admin/footer');
    }

    public function users() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $data['table_data_source'] = base_url('admin/users_ajax_list');
        $this->load->view('admin/users', $data);
        $this->load->view('admin/footer');
    }

    public function users_ajax_list() {
        $this->load->model('updated_model');
        echo $this->updated_model->users_ajax_list();
        die;
    }

    public function edit_user($user_id) {
        $where = "user_id = '" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '', $where);


        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $this->load->view('admin/edit_user', $data);
        $this->load->view('admin/footer');
    }

    public function update_user() {
        if ($this->input->post()) {
            $userData = $this->input->post();

            $userData['pay_by_account'] = (!empty($userData['pay_by_account']) && $userData['pay_by_account'] == 1) ? 1 : 0;

            $user_id = $this->input->post('user_id');

//            $imageName = $userData['dimesion_image_11111'];
//
//            if (!empty($imageName)) {
//                $reposne = $this->copy_image_user($imageName);
//                $image_url = '';
//                if ($reposne['status']) {
//                    $image_url = base_url() . 'uploads/users/' . $userData['dimesion_image_11111'];
//                    $userData['user_image'] = $image_url;
//                }
//                $session_data = array(
//                    'user_image' => $image_url
//                );
//                $this->session->set_userdata($session_data);
//            }

            $config['upload_path'] = './uploads/users/';
            $config['allowed_types'] = 'gif|jpg|png';
            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if ($this->upload->do_upload('user_image')) {
                $data = array('upload_data' => $this->upload->data());
                $image_url = base_url() . '/uploads/users/' . $data['upload_data']['file_name'];
                $userData['user_image'] = $image_url;
            }

            $where = "user_id = '" . $user_id . "'";
            $this->basic_model->update_records('users', $userData, $where);
            $this->edit_user($user_id);
            redirect('admin/users');
        } else {
            redirect('admin/update_user');
        }
    }

    function email_existance() {
        if ($this->input->get('user_email')) {
            $email = $this->input->get('user_email');
            $user_id = $this->input->get('user_id');
            $where = "user_email = '" . $email . "' and user_id != '" . $user_id . "'";
            $result = $this->basic_model->get_record_where('users', $column = '', $where);
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
    }

    function change_password() {
        if ($this->input->post('user_id')) {
            $user_id = $this->input->post("user_id");
            $data = array(
                'user_password' => md5($this->input->post("password"))
            );
            $where = "user_id='" . $user_id . "'";
            $this->basic_model->update_records('users', $data, $where);
        }
    }

    //--------------------------FNC Types------------------------------------//
    // Listing
    public function fnc_list() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $this->load->view('admin/fnc_types_view_new');
        $this->load->view('admin/footer');
    }

    public function get_on_update_council() {
        if ($this->input->post('suburb')) {
            $subrub = $this->input->post('suburb');
            $coordinate = $this->basic_model->get_record_where('aus_councils', '', array('suburb' => $subrub));
            $item_arr = array();
            if (!empty($coordinate)) {
                $item_arr = array(
                    'status' => true,
                    'id' => $coordinate[0]->id,
                    'suburb' => $coordinate[0]->suburb,
                    'postcode' => $coordinate[0]->postcode,
                    'state' => $coordinate[0]->state,
                    'council' => $coordinate[0]->council,
                    'council_id' => $coordinate[0]->council_id
                );
            } else {
                $item_arr = array('status' => false);
            }
        }

        echo json_encode($item_arr);
    }

    // Ajax to create list
    public function ajax_list() {
        $list = $this->fnc_types->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $fnc_types) {
            $no++;
            $img = base_url("uploads/fnc_types/" . $fnc_types->image);
            $img_white = base_url("uploads/fnc_types/" . $fnc_types->white_image);
            $row = array();
            $row[] = $fnc_types->name;
            $row[] = ucwords(str_replace("_", " ", $fnc_types->type));
            $row[] = '<img width=50px; height=50px; src="' . $img . '">';
            $row[] = '<img width=50px; height=50px; src="' . $img_white . '">';
            if ($fnc_types->status == 1)
                $status = 'Active';
            else
                $status = 'Deactive';
            $row[] = $status;
            $row[] = $fnc_types->short_desc;
            $edit_fnc = site_url('admin/fnc_types_edit/' . $fnc_types->id);
            $row[] = '<a data-id="' . $fnc_types->id . '"  class="btn btn-primary pop_edit edit_but" href="javascript:;" onclick="editForm(' . $fnc_types->id . ')"><i class="fa fa-pencil"></i>Edit</a>';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->fnc_types->count_all(),
            "recordsFiltered" => $this->fnc_types->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    // Ajax function to add fnc type
    public function fnc_types_add() {
        $this->load->library("form_validation");
        if ($this->input->post()) {
            $this->form_validation->set_rules("name", "fnc name", "required|is_unique[fnc_types.name]");
            $this->form_validation->set_rules("type", "fnc types", "required");
            $this->form_validation->set_rules("status", "fnc status", "required");
            if (empty($_FILES['image']['name'])) {
                $this->form_validation->set_rules('image', 'image', 'required');
            }if ($this->form_validation->run() == FALSE) {
                
            } else {
                $config["upload_path"] = "uploads/fnc_types";
                $congig["max_size"] = 2048;
                $config["allowed_types"] = "jpg|png|jpeg";
                $config['overwrite'] = FALSE;
                $this->load->library("upload", $config);
                $this->upload->initialize($config);
                if (!$this->upload->do_upload('image')) {
                    $error = $this->upload->display_errors();
                } else {
                    $img_data = $this->upload->data();
                    $file_name = $img_data['file_name'];
                }

                if (!$this->upload->do_upload('white_image')) {
                    $error = $this->upload->display_errors();
                } else {
                    $img_data = $this->upload->data();
                    $file_name = $img_data['file_name'];
                }

                $insert_data = array('name' => $this->input->post('name'),
                    'type' => $this->input->post('type'),
                    'status' => $this->input->post('status'),
                    'short_desc' => $this->input->post('short_desc'));
                if (!empty($file_name)) {
                    $insert_data['image'] = $file_name;
                }
                $id = $this->basic_model->insert_records('fnc_types', $insert_data);
                if ($id > 0) {
                    $this->session->set_flashdata('success', 'Facility added successfully');
                } else {
                    $this->session->set_flashdata('error', 'Error in facility insertion');
                }
                redirect('admin/fnc_list');
            }
        }
    }

    // Ajax to get data from DB
    public function fnc_list_edit() {
        $id = $this->input->post('id');
        if (!empty($id)) {
            $where = array('id' => $id);
            $this->load->model("basic_model");
            $data = $this->basic_model->get_record_where('fnc_types', '', $where);
            echo json_encode($data);
        }
    }

    // Ajax function to update Fnc type
    public function fnc_list_update() {
        $data = array();
        if ($_FILES) {
            $config["upload_path"] = "uploads/fnc_types";
            $congig["max_size"] = 2048;
            $config["allowed_types"] = "jpg|png|jpeg";
            $config['overwrite'] = FALSE;
            $this->load->library("upload", $config);
            $this->upload->initialize($config);
            if ($this->upload->do_upload('image') == false) {
                $error = $this->upload->display_errors();
                $this->session->set_flashdata("msg", $error);
            } else {
                $file_name = $this->upload->data("image");
                $data['image'] = $this->upload->data('file_name');
            }
        }

        $data['type'] = $this->input->post('type');
        $data['name'] = $this->input->post('name');
        $data['status'] = $this->input->post('status');
        $data['short_desc'] = $this->input->post('short_desc');


        $where = array('id' => $this->input->post('id'));

        $this->load->model("basic_model");
        $this->basic_model->update_records('fnc_types', $data, $where);
    }

    //--------------------------------------------------------------//
    //-------------------------Feedback section-------------------------------------//
    // Feedback list
    public function feedback_list() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $data['table_data_source'] = base_url('admin/feedback_ajax_list');
        $this->load->view('admin/feedback_view', $data);
        $this->load->view('admin/footer');
    }

    // Ajax of listing of feedback
    public function feedback_ajax_list() {
        $this->load->model('updated_model');
        echo $this->updated_model->feedback_ajax_list();
        die;
    }

    // Update status with approved / deny
    public function feedback_update() {
        if ($this->input->post('f_id')) {
            $data = array('f_status' => $this->input->post('f_status'));
            $where = array('f_id' => $this->input->post('f_id'));
            $this->load->model("basic_model");
            $my_data = $this->basic_model->update_records('feedback', $data, $where);
            echo "1";
        }
    }

    // Get comment of the feedback
    public function feedback_edit() {
        if ($this->input->post('f_id')) {
            $f_id = $this->input->post('f_id');
            $where = array('f_id' => $f_id);
            $this->load->model("basic_model");
            $data = $this->basic_model->get_record_where('feedback', '', $where);
            echo json_encode($data);
        }
    }

    // Edit comments of feedback
    public function feedback_all_update() {
        if ($this->input->post('f_id')) {
            $data = array('f_text' => $this->input->post('f_text'));
            $where = array('f_id' => $this->input->post('f_id'));
            $this->load->model("basic_model");
            $my_data = $this->basic_model->update_records('feedback', $data, $where);
        }
    }

    //--------------------------------------------------------------//

    public function venue_catering() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $data['table_data_source'] = base_url('admin/catering_ajax_list');
        $this->load->view('admin/venue_catering_view', $data);
        $this->load->view('admin/footer');
    }

    public function catering_ajax_list() {
        $this->load->model('updated_model');
        echo $this->updated_model->catering_ajax_list();
        die;
    }

    public function businesses_authorized() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $data['table_data_source'] = base_url('admin/businesses_authorized_ajax_list');
        $this->load->view('admin/businesses_authorized', $data);
        $this->load->view('admin/footer');
    }

    public function businesses_authorized_ajax_list() {
        $this->load->model('updated_model');
        echo $this->updated_model->businesses_authorized_ajax_list();
        die;
    }

    public function businesses_update() {
        if ($this->input->post('bus_auth_id')) {
            $data = array('bus_auth_status' => $this->input->post('bus_auth_status'));
            $where = array('bus_auth_id' => $this->input->post('bus_auth_id'));
            $this->load->model("basic_model");
            $my_data = $this->basic_model->update_records('businesses_authorized', $data, $where);
            echo "1";
            $bus_auth_data = array('bus_auth_id' => $this->input->post('bus_auth_id'));
            $bus_auth_data = $this->basic_model->get_record_where('businesses_authorized', '', $bus_auth_data);
            if ($this->input->post('is_mail_send') == 1) {
                $user_id = $bus_auth_data[0]->user_id;
                if ($bus_auth_data[0]->bus_auth_req == 1) {
                    $type = 'Venue';
                } else if ($bus_auth_data[0]->bus_auth_req == 2) {
                    $type = 'Catering';
                }
                $user_data = $this->basic_model->get_record_where('users', 'user_firstname,user_lastname,user_email', array('user_id' => $user_id));
                $user_name = ucfirst($user_data[0]->user_firstname . ' ' . $user_data[0]->user_lastname);
                $user_email = $user_data[0]->user_email;
                $fc_new_data = array('fc_type' => $type, 'name' => $user_name, 'bus_auth_notes' => $bus_auth_data[0]->bus_auth_notes, 'email' => $user_email, 'url' => base_url('admin/businesses_update'), 'bus_auth_create_time' => $bus_auth_data[0]->bus_auth_create_time);
                $this->load->helper('email_template_helper');
                approved_bus_auth_mail($fc_new_data);
                echo "1";
            }
        }
    }

    public function businesses_edit() {
        if ($this->input->post('bus_auth_id')) {
            $bus_auth_id = $this->input->post('bus_auth_id');
            $where = array('bus_auth_id' => $bus_auth_id);
            $this->load->model("basic_model");
            $data = $this->basic_model->get_record_where('businesses_authorized', '', $where);
            echo json_encode($data);
        }
    }

    // Edit businesses 
    public function businesses_all_update() {
        $this->load->model("basic_model");
        $bus_auth_req = $this->input->post('bus_auth_req');


        $user_id = $this->input->post('name');
        $where = array('bus_auth_req' => $bus_auth_req,
            'user_id' => $user_id);
        $data = $this->basic_model->get_record_where('businesses_authorized', 'bus_auth_req', $where);

        if (!empty($data)) {
            $success = 0;
            if ($bus_auth_req == 1)
                $msg = "You have already request for venue.";

            if ($bus_auth_req == 2)
                $msg = "You have already request for catering.";
        }
        else {
            $success = 1;
            $msg = '';
            if ($this->input->post('bus_auth_id')) {
                $data = array('bus_auth_req' => $this->input->post('bus_auth_req'),
                    'bus_auth_notes' => $this->input->post('bus_auth_notes')
                );
                $where = array('bus_auth_id' => $this->input->post('bus_auth_id'));

                $my_data = $this->basic_model->update_records('businesses_authorized', $data, $where);
            }
        }
        echo json_encode(array('status' => $success, 'msg' => $msg));
// die;
    }

    //
    // <- new cahnges->

    public function catering_update() {
        if ($this->input->post('fc_id')) {
            $data = array('fc_status' => $this->input->post('fc_status'));
            $where = array('fc_id' => $this->input->post('fc_id'));
            $this->load->model("basic_model");
            $my_data = $this->basic_model->update_records('function_catering', $data, $where);
            echo "1";
            $fc_data = array('fc_id' => $this->input->post('fc_id'));
            $fc_data = $this->basic_model->get_record_where('function_catering', '', $fc_data);
            // print_r($fc_data);die;

            if ($this->input->post('is_mail_send') == 1) {
                $user_id = $fc_data[0]->fc_user;
                // print_r($user_id);die;
                $user_data = $this->basic_model->get_record_where('users', 'user_firstname,user_lastname,user_email', array('user_id' => $user_id));
                // print_r($user_data);die;
                $user_name = ucfirst($user_data[0]->user_firstname . ' ' . $user_data[0]->user_lastname);
                $user_email = $user_data[0]->user_email;
                // print_r($user_email);die;
                $fc_id = $this->input->post('fc_id');
                $fc_new_data = array('fc_id' => $fc_id, 'name' => $user_name, 'business_name' => $fc_data[0]->fc_business_name, 'email' => $user_email, 'contact_no' => $fc_data[0]->fc_phone_no, 'url' => base_url('admin/catering_update'), 'requested_date' => $fc_data[0]->fc_created_date, 'contact_name' => $fc_data[0]->fc_contact_name, 'contact_email' => $fc_data[0]->fc_email, 'type' => $fc_data[0]->fc_type);
                $this->load->helper('email_template_helper');
                approved_fc_mail($fc_new_data);
                echo "1";
            }
        }
    }

    public function edit_venue($venueID = 0) {
        $user_id = $this->session->userdata('user_id');
        if ($this->input->post()) {
            $data = $this->input->post();
            $venue_id = $this->input->post('venue');
            $update_data = array('fc_business_name' => $data['venue_business_name'], 'fc_company_name' => $data['venue_company_name'], 'fc_state' => $data['venue_state'], 'fc_suburb' => $data['venue_suburb'], 'fc_street' => $data['venue_street'], 'fc_postcode' => $data['venue_postcode'], 'fc_country' => $data['venue_country'], 'fc_lat' => $data['lat'], 'fc_lng' => $data['lng'], 'fc_abn' => $data['venue_abn'], 'fc_contact_name' => $data['venue_contact_name'], 'fc_phone_no' => $data['venue_phone_no'], 'fc_website' => $data['venue_website'], 'fc_email' => $data['venue_email'], 'fc_overview' => $data['venue_overview'], 'fc_details' => $data['venue_details'], 'fc_min_guest' => $data['venue_min_guest'], 'fc_max_guest' => $data['venue_max_guest']);
            if ($this->input->post('venue_pricing')) {
                $update_data['fc_pricing'] = implode(',', $data['venue_pricing']);
            } else {
                $update_data['fc_pricing'] = '';
            }
            $where = array('fc_id' => $venue_id);

            $listing_image = UploadFcListingPicture();
            if (!empty($listing_image)) {
                $update_data['fc_listing_picture'] = $listing_image;
            }

            $this->basic_model->update_records('function_catering', $update_data, $where);

            //update plan
            if ($data['update_pack_id'] == 1 || $data['update_pack_id'] == 2) {
                $where_fc = array('fc_id' => $venue_id);
                $catering_data = $this->basic_model->get_record_where('function_catering', 'fc_valid_upto', $where_fc);
                $old_expiry_date = $catering_data[0]->fc_valid_upto;

                if (strtotime($old_expiry_date) < strtotime(date('Y-m-d'))) {
                    $old_expiry_date = date('Y-m-d');
                }

                $where_pro = array('pro_id' => $data['update_pack_id']);
                $get_price = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_pro);
                $validity_type = $get_price[0]->pro_pay_type;
                $valid_upto = date("Y-m-d", strtotime("+1 $validity_type", strtotime($old_expiry_date)));
                $this->basic_model->update_records('function_catering', array('fc_valid_upto' => $valid_upto), $where_fc);
            }

            // Edit spaces

            if (array_key_exists("total_space", $data)) {
                $total_space = $this->input->post('total_space');
                for ($i = 0; $i <= $total_space - 1; $i++) {
                    if ($this->input->post("space_name$i")) {
                        $update_data_space = array(
                            'space_name' => $data["space_name$i"],
                            'space_min_guest' => $data["space_min_guest$i"],
                            'space_max_guest' => $data["space_max_guest$i"],
                            'space_details' => $data["space_details$i"]
                        );

                        if ($this->input->post("space_events$i")) {
                            $update_data_space['space_events'] = implode(',', $data["space_events$i"]);
                        } else {
                            $update_data_space['space_events'] = '';
                        }

                        if ($this->input->post("space_facilities$i")) {
                            $update_data_space['space_facilities'] = implode(',', $data["space_facilities$i"]);
                        } else {
                            $update_data_space['space_facilities'] = '';
                        }

                        if ($this->input->post("space_features$i")) {
                            $update_data_space['space_features'] = implode(',', $data["space_features$i"]);
                        } else {
                            $update_data_space['space_features'] = '';
                        }

                        $upload_i = $i + 6;


                        if ($this->input->post("dimesion_image_" . $upload_i)) {
                            $update_data_space['space_image'] = $image_url = $this->input->post("dimesion_image_" . $upload_i);

                            if (file_exists("uploads/venue_spaces/temp/" . $image_url)) {
                                rename("uploads/venue_spaces/temp/" . $image_url, "uploads/venue_spaces/" . $image_url);
                            }
                        } elseif ($_FILES["space_image$upload_i"]['size'] != 0) {
                            $s_config['upload_path'] = './uploads/venue_spaces/';
                            $s_config['allowed_types'] = 'jpeg|jpg|png';

                            $this->load->library('upload', $s_config);

                            $this->upload->initialize($s_config);

                            if (!$this->upload->do_upload("space_image$upload_i")) {
                                $error = $this->upload->display_errors();
                            } else {
                                $i_data = $this->upload->data();
                                $update_data_space['space_image'] = $i_data['file_name'];
                            }
                        }


                        $where_space = array('space_id' => $data["space_id$i"]);
                        $this->basic_model->update_records('venue_spaces', $update_data_space, $where_space);
                    }
                }
            }

            /* --------addional space------------- */
            $t_spaces = $data['total_another'];
            $additional_spaces = array();
            if (array_key_exists("total_space", $data)) {
                $crop_count = $data['total_space'];
                $crop_count = $crop_count + 5;
                $i = $data['total_space'] + 1;

                $t_spaces = $t_spaces + $data['total_space'];
            } else {
                $crop_count = 6;
                $i = 1;
            }

            if ($data['total_another'] > 0) {
                $additional_space = array();
                for ($i; $i <= $t_spaces; $i++) {
                    $spaces = array('space_venue' => $venue_id, 'space_name' => $data["space_name$i"], 'space_min_guest' => $data["space_min_guest$i"], 'space_max_guest' => $data["space_max_guest$i"], 'space_details' => $data["space_details$i"]);

                    $spaces['space_events'] = '';
                    if (!empty($data["space_events$i"])) {
                        $spaces['space_events'] = implode(',', $data["space_events$i"]);
                    }

                    $spaces['space_facilities'] = '';
                    if (!empty($data["space_facilities$i"])) {
                        $spaces['space_facilities'] = implode(',', $data["space_facilities$i"]);
                    }

                    $spaces['space_features'] = '';
                    if (!empty($data["space_features$i"])) {
                        $spaces['space_features'] = implode(',', $data["space_features$i"]);
                    }

                    $spaces['space_image'] = '';
                    $croped_image_name = 'dimesion_image_' . ($crop_count + 1);

                    if ($this->input->post($croped_image_name) != '0') {
                        $image_url = $this->input->post($croped_image_name);
                        if (file_exists("uploads/venue_spaces/temp/" . $image_url) && !empty($image_url)) {
                            // echo "test";die;
                            rename("uploads/venue_spaces/temp/" . $image_url, "uploads/venue_spaces/" . $image_url);
                        }
                        // die;
                        $spaces['space_image'] = $image_url;
                    } elseif ($_FILES["space_image$i"]['size'] != 0) {
                        $s_config['upload_path'] = './uploads/venue_spaces/';
                        $s_config['allowed_types'] = 'jpeg|jpg|png';

                        $this->load->library('upload', $s_config);

                        $this->upload->initialize($s_config);

                        if (!$this->upload->do_upload("space_image$i")) {
                            $error = $this->upload->display_errors();
                        } else {
                            $i_data = $this->upload->data();
                            $spaces['space_image'] = $i_data['file_name'];
                        }
                    }

                    $additional_spaces[] = $spaces;
                    $crop_count++;
                }

                $this->basic_model->insert_records('venue_spaces', $additional_spaces, $multiple = true);
            }

            $addition_area = array();

            if ($data['number_region'] > 0) {
                for ($i = 1; $i <= $data['number_region']; $i++) {
                    $region_id = 'area_' . $i;
                    $region_name = 'add_arr' . $i;
                    $area_lat = 'add_arr_lat' . $i;
                    $area_lng = 'add_arr_lng' . $i;
                    if (!empty($data[$region_id])) {
                        $data[$region_name] = !empty($data[$region_name]) ? $data[$region_name] : '';
                        $addition_area = array('area_name' => $data[$region_name], 'area_lat' => $data[$area_lat], 'area_lng' => $data[$area_lng]);

                        $where = array('area_id' => encrypt_decrypt('decrypt', $data[$region_id]));
                        $this->basic_model->update_records('additional_area', $addition_area, $where);
                    }
                }
            }


            $addition_area = array();
            if ($data['new_area_total'] > 0 && isset($data['new_add_arr'])) {
                $today = date('Y-m-d');
                foreach ($data['new_add_arr'] as $key => $value) {
                    if (!empty($value) && !empty($data['add_arr_lng'][$key]) && $data['add_arr_lat'][$key]) {
                        $addition_area[] = array('area_venue' => $venue_id, 'area_name' => $value, 'area_lat' => $data['add_arr_lat'][$key], 'area_lng' => $data['add_arr_lng'][$key], 'area_created_on' => $today);
                    }
                }

                if (!empty($addition_area)) {
                    $this->basic_model->insert_records('additional_area', $addition_area, $multiple = true);
                }
            }



            $venue_details = array();
            if ($this->input->post('venue_events')) {
                $venue_details['vd_events'] = implode(',', $data['venue_events']);
            } else {
                $venue_details['vd_events'] = '';
            }
            if ($this->input->post('venue_facilities')) {
                $venue_details['vd_facilities'] = implode(',', $data['venue_facilities']);
            } else {
                $venue_details['vd_facilities'] = '';
            }
            if ($this->input->post('venue_features')) {
                $venue_details['vd_features'] = implode(',', $data['venue_features']);
            } else {
                $venue_details['vd_features'] = '';
            }
            $where_details = array('vd_fc_id' => $venue_id);
            $this->basic_model->update_records('venue_details', $venue_details, $where_details);
            $img_count = 5;
            if ($this->input->post('img_count')) {
                $img_count = $img_count - $this->input->post('img_count');
                // Multi venue images
                $this->load->library('upload');
                $dataInfo = array();
                $files = $_FILES;
                $cpt = count($_FILES['venue_image']['name']);
                $image_data = array();
                for ($i = 0; $i < $cpt; $i++) {
                    $croped_image_name = 'dimesion_image_' . ($i);
                    if ($this->input->post($croped_image_name) != '0') {
                        $image_url = $this->input->post($croped_image_name);
                        if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                            rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                        }
                        $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $venue_id, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                    } else {
                        if ($files['venue_image']['size'][$i] != 0) {
                            $_FILES['venue_image']['name'] = $files['venue_image']['name'][$i];
                            $_FILES['venue_image']['type'] = $files['venue_image']['type'][$i];
                            $_FILES['venue_image']['tmp_name'] = $files['venue_image']['tmp_name'][$i];
                            $_FILES['venue_image']['error'] = $files['venue_image']['error'][$i];
                            $_FILES['venue_image']['size'] = $files['venue_image']['size'][$i];
                            $this->upload->initialize($this->set_upload_options());
                            if (!$this->upload->do_upload('venue_image')) {
                                $error = $this->upload->display_errors();
                            } else {
                                $dataInfo[] = $this->upload->data();
                                $i_data = $this->upload->data();
                                $image_url = $i_data['file_name'];
                                $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $venue_id, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                            }
                        }
                    }
                }
                if (!empty($image_data)) {
                    $this->basic_model->insert_records('fc_images', $image_data, TRUE);
                }
            }
            if ($img_count > 0) {
                // Multi venue images
                $this->load->library('upload');
                for ($ic = 0; $ic < $img_count; $ic++) {
                    $croped_image_name = 'dimesion_image_' . ($ic);
                    $image_url = false;
                    if ($this->input->post($croped_image_name) != '0') {
                        $image_url = $this->input->post($croped_image_name);
                        if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                            rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                        }
                    } elseif ($_FILES["venue_image$ic"]['size'] != 0) {
                        $this->upload->initialize($this->set_upload_options());
                        if (!$this->upload->do_upload("venue_image$ic")) {
                            $error = $this->upload->display_errors();
                        } else {
                            $dataInfo[] = $this->upload->data();
                            $i_data = $this->upload->data();
                            $i_data = $this->upload->data();
                            $image_url = $i_data['file_name'];
                        }
                    }
                    if (!empty($image_url)) {
                        unlink_image('slide', $data["image$ic"]);
                        $image_update = array('fc_img_name' => $image_url, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                        $where_img = array('fc_img_id' => $data["image$ic"]);
                        $this->basic_model->update_records('fc_images', $image_update, $where_img);
                    }
                }
            }

//            if (!is_dir('uploads/' . 'venue_pdf_image')) {
//                mkdir('./uploads/' . 'venue_pdf_image', 0777, TRUE);
//            }
//            $upload_dir = 'uploads/venue_pdf_image';
//            $pdfData = array();
//            $pdf = '';
//            $pdfImage = '';
//            $pdfTitleName = '';
//            $pdf_title = '';
//            if (!is_dir('uploads/' . 'venue_pdf')) {
//                mkdir('./uploads/' . 'venue_pdf', 0777, TRUE);
//            }
//            $pdf_title = $this->input->post('pdf_title');
//            if (!empty($_FILES['venue_pdf']['name'])) {
//                $filesCount = count($_FILES['venue_pdf']['name']);
//                for ($i = 0; $i < $filesCount; $i++) {
//                    $_FILES['file']['name'] = $_FILES['venue_pdf']['name'][$i];
//                    $_FILES['file']['type'] = $_FILES['venue_pdf']['type'][$i];
//                    $_FILES['file']['tmp_name'] = $_FILES['venue_pdf']['tmp_name'][$i];
//                    $_FILES['file']['error'] = $_FILES['venue_pdf']['error'][$i];
//                    $_FILES['file']['size'] = $_FILES['venue_pdf']['size'][$i];
//                    $uploadPath = 'uploads/venue_pdf/';
//                    $config['upload_path'] = $uploadPath;
//                    $config['allowed_types'] = 'pdf';
//                    $this->load->library('upload', $config);
//                    $this->upload->initialize($config);
//                    if ($this->upload->do_upload('file')) {
//                        $fileData = $this->upload->data();
//                        $uploadData[$i]['fc_pdf_name'] = $fileData['file_name'];
//                        $img = $this->input->post('fc_pdf_image');
//                        if (!empty($img)) {
//                            foreach ($img as $key1 => $pdfImage) {
//                                if (!empty($pdfImage)) {
//                                    $imgstr = $pdfImage;
//                                    $new_data = explode(";", $imgstr);
//                                    $type = $new_data[1];
//                                    $data1 = explode(",", $new_data[1]);
//                                    header("Content-type:" . $type);
//                                    $data2 = base64_decode($data1[1]);
//                                    $file = $upload_dir . '/' . date("YmdHis") . ".png";
//                                    $uploadData[$key1]['fc_pdf_image'] = date("YmdHis") . ".png";
//                                    $success = file_put_contents($file, $data2);
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//            if (!empty($pdf_title)) {
//                foreach ($pdf_title as $key => $title) {
//                    if (!empty($title)) {
//                        $uploadData[$key]['fc_pdf_title_name'] = $title;
//                        $uploadData[$key]['fc_id'] = $venue_id;
//                    }
//                }
//            }
//            $uploadData1 = array();
//            $pdf_id = $data['pdf_id'];
//            if (empty($pdf_id)) {
//                $fc_pdf_id = $this->basic_model->insert_records('fc_pdfs', $uploadData, true);
//            } else {
////                $where = array('fc_id' => $venue_id);
//                $where = $this->db->where_in('fc_pdf_id', $pdf_id);
//                $uploadData1 = array('fc_pdf_title_name' => '', 'fc_pdf_name' => '');
//                $fc_pdf_id = $this->basic_model->update_records('fc_pdfs', $uploadData1, $where);
//            }

            unset($_POST);
            redirect('admin/venue_catering');
        } else {
            if (!empty($venueID)) {
                $venue_id = $venueID;
                $where_fc = array('fc_id' => $venueID);
                $venue = $this->basic_model->get_record_where('function_catering', '', $where_fc);
                if (!empty($venue)) {
                    $data['venue'] = $venue;

                    /* ---------get council-------- */
                    $data['council'] = '';
                    $where_for_council = array('suburb' => $venue[0]->fc_suburb, 'postcode' => $venue[0]->fc_postcode);
                    $council = $this->basic_model->get_record_where('aus_councils', 'council,council_id,zoom', $where_for_council);
                    if ($council) {
                        $data['council'] = $council[0]->council;
                        $data['council_id'] = $council[0]->council_id;
                        $data['zoom'] = $council[0]->zoom;
                    } else {
                        $data['council'] = $venue[0]->fc_suburb;
                        $data['council_id'] = '';
                        $data['zoom'] = 8;
                    }
                    // Get venue spaces
                    $where_fc1 = array('space_venue' => $venue_id, 'space_status' => 0);
                    $data['venue_space'] = $this->basic_model->get_record_where('venue_spaces', '', $where_fc1);


                    //--------Basic Venue Details----------//
                    $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');
                    $where_events = array('type' => 'event_type', 'status' => 1);
                    $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);
                    $where_facilities = array('type' => 'facilities', 'status' => 1);
                    $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);
                    $where_features = array('type' => 'features', 'status' => 1);
                    $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);
                    //--------Basic Venue Details----------//
                    $where = 'pro_id IN (1,2)';
                    $data['packs'] = $this->basic_model->get_record_where('products', '', $where);
                    //--------additional area Details----------//
                    $join = array(
                        'aus_councils' => 'aus_councils.council = additional_area.area_name'
                    );
                    $where = array('area_venue' => $venue_id, 'area_status' => 0);
                    $column = 'distinct(aus_councils.council_id),additional_area.*';
                    $where = "area_venue = " . $venue_id . " and area_status IN (0,2)";
                    $data['additinal_council'] = $this->basic_model->get_record_join_tables('additional_area', $where, $column, $join, '', '', '', 'ASC', 'left', '');

                    $where_details = array('vd_fc_id' => $venue_id);
                    $data['venue_details'] = $this->basic_model->get_record_where('venue_details', '', $where_details);
                    $where_images = array('fc_id' => $venue_id);
                    $data['venue_images'] = $this->basic_model->get_record_where('fc_images', '', $where_images);
                    $where_pdfs = array('fc_id' => $venue_id);
                    $data['venue_pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '', $where_pdfs);
                    $this->load->view('admin/header');
                    $this->load->view('admin/menu');
                    $this->load->view('admin/edit_venue', $data);
                    $this->load->view('admin/footer');
                } else {
                    redirect('admin/venue_catering');
                }
            } else {
                redirect('admin/venue_catering');
            }
        }
    }

    public function check_council() {
        if ($this->input->post('addr_str')) {
            $search_term = $this->input->post('addr_str');

            $where_term = "council LIKE '$search_term%' OR suburb LIKE '$search_term%' OR postcode LIKE '$search_term%' ";
            $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);

            if (!empty($coucils)) {
                $response = array('status' => TRUE, 'council' => $coucils[0]->council, 'council_id' => $coucils[0]->council_id);
            } else {
                $response = array('status' => FALSE);
            }
            echo json_encode($response);
        }
    }

    public function set_upload_options() {
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/fc_images/';
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = '0';
        $config['overwrite'] = FALSE;
        return $config;
    }

    public function edit_catering($cateringID = 0) {
        $user_id = $this->session->userdata('user_id');
        if ($this->input->post()) {

            $data = $this->input->post();
            $catering_id = $this->input->post('catering');
            // print_r($catering_id);
            $update_data = array('fc_business_name' => $data['catering_business_name'], 'fc_company_name' => $data['catering_company_name'], 'fc_state' => $data['catering_state'], 'fc_council' => $data['catering_council'], 'fc_suburb' => $data['catering_suburb'], 'fc_street' => $data['catering_street'], 'fc_postcode' => $data['catering_postcode'], 'fc_country' => $data['catering_country'], 'fc_lat' => $data['lat'], 'fc_lng' => $data['lng'], 'fc_abn' => $data['catering_abn'], 'fc_contact_name' => $data['catering_contact_name'], 'fc_phone_no' => $data['catering_phone_no'], 'fc_website' => $data['catering_website'], 'fc_email' => $data['catering_email'], 'fc_overview' => $data['catering_overview'], 'fc_details' => $data['catering_details'], 'fc_min_guest' => $data['catering_min_guest'], 'fc_max_guest' => $data['catering_max_guest']);

            $listing_image = UploadFcListingPicture();
            if (!empty($listing_image)) {
                $update_data['fc_listing_picture'] = $listing_image;
            }

            if ($this->input->post('catering_pricing')) {
                $update_data['fc_pricing'] = implode(',', $data['catering_pricing']);
            } else {
                $update_data['fc_pricing'] = '';
            }
            $where = array('fc_id' => $cateringID);

            $this->basic_model->update_records('function_catering', $update_data, $where);

            //update plan
            if ($data['update_pack_id'] == 1 || $data['update_pack_id'] == 2) {
                $where_fc = array('fc_id' => $cateringID);
                $catering_data = $this->basic_model->get_record_where('function_catering', 'fc_valid_upto', $where_fc);

                $old_expiry_date = $catering_data[0]->fc_valid_upto;
                $where_pro = array('pro_id' => $data['update_pack_id']);
                $get_price = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_pro);


                $validity_type = $get_price[0]->pro_pay_type;

                if (strtotime($old_expiry_date) < strtotime(date('Y-m-d'))) {
                    $old_expiry_date = date('Y-m-d');
                }

                $valid_upto = date("Y-m-d", strtotime("+1 $validity_type", strtotime($old_expiry_date)));

//                $data = $this->basic_model->update_records('function_catering', array('fc_valid_upto' => $valid_upto), $where_fc);
                $this->basic_model->update_records('function_catering', array('fc_valid_upto' => $valid_upto), $where_fc);
                // echo $this->db->last_query();
            }




            if (!empty($data['catering_pricing'])) {
                $update_data['fc_pricing'] = implode(',', $data['catering_pricing']);
            } else {
                $update_data['fc_pricing'] = '';
            }
            $where = array('fc_id' => $catering_id);
            $this->basic_model->update_records('function_catering', $update_data, $where);
            $catering_details = array();

            if (!empty($data['catering_function_type'])) {
                $catering_details['cd_function_type'] = implode(',', $data['catering_function_type']);
            } else {
                $catering_details['cd_function_type'] = '';
            }
            if (!empty($data['catering_menus'])) {
                $catering_details['cd_menus'] = implode(',', $data['catering_menus']);
            } else {
                $catering_details['cd_menus'] = '';
            }
            if (!empty($data['catering_cuisine'])) {
                $catering_details['cd_cuisine'] = implode(',', $data['catering_cuisine']);
            } else {
                $catering_details['cd_cuisine'] = '';
            }



            if (!empty($data['catering_services'])) {
                $catering_details['cd_services'] = implode(',', $data['catering_services']);
            } else {
                $catering_details['cd_services'] = '';
            }

            $where_details = array('cd_fc_id' => $catering_id);
            $this->basic_model->update_records('catering_details', $catering_details, $where_details);
            // echo $this->db->last_query();die;
            $img_count = 5;
            if ($this->input->post('img_count')) {
                $img_count = $img_count - $this->input->post('img_count');
                // Multi venue images
                $this->load->library('upload');
                $dataInfo = array();
                $files = $_FILES;
                $cpt = count($_FILES['catering_image']['name']);
                $image_data = array();
                for ($i = 0; $i < $cpt; $i++) {
                    $croped_image_name = 'dimesion_image_' . ($i + 1);
                    if ($this->input->post($croped_image_name) != '0') {
                        $image_url = $this->input->post($croped_image_name);
                        if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                            rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                        }
                        $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $catering_id);
                    } elseif ($files['catering_image']['size'][$i] != 0) {
                        $_FILES['catering_image']['name'] = $files['catering_image']['name'][$i];
                        $_FILES['catering_image']['type'] = $files['catering_image']['type'][$i];
                        $_FILES['catering_image']['tmp_name'] = $files['catering_image']['tmp_name'][$i];
                        $_FILES['catering_image']['error'] = $files['catering_image']['error'][$i];
                        $_FILES['catering_image']['size'] = $files['catering_image']['size'][$i];
                        $this->upload->initialize($this->set_upload_options());
                        if (!$this->upload->do_upload('catering_image')) {
                            $error = $this->upload->display_errors();
                        } else {
                            $dataInfo[] = $this->upload->data();
                            $i_data = $this->upload->data();
                            $image_url = $i_data['file_name'];
                            $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $catering_id, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                        }
                    }
                }
                if (!empty($image_data)) {
                    $this->basic_model->insert_records('fc_images', $image_data, TRUE);
                }
            }
            if ($img_count > 0) {
                // Multi venue images
                $this->load->library('upload');
                for ($ic = 0; $ic < $img_count; $ic++) {
                    $image_url = false;
                    $croped_image_name = 'dimesion_image_' . ($ic);
                    if ($this->input->post($croped_image_name) != '0') {
                        $image_url = $this->input->post($croped_image_name);
                        if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                            rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                        }
                    } elseif ($_FILES["catering_image$ic"]['size'] != 0) {
                        $this->upload->initialize($this->set_upload_options());
                        if (!$this->upload->do_upload("catering_image$ic")) {
                            $error = $this->upload->display_errors();
                        } else {
                            $dataInfo[] = $this->upload->data();
                            $i_data = $this->upload->data();
                            $image_url = $i_data['file_name'];
                        }
                    }
                    if (!empty($image_url)) {
                        unlink_image('slide', $data["image$ic"]);
                        $image_update = array('fc_img_name' => $image_url, 'fc_img_modified_on' => date('Y-m-d H:i:s'));

                        $where_img = array('fc_img_id' => $data["image$ic"]);
                        $this->basic_model->update_records('fc_images', $image_update, $where_img);
                    }
                }
            }
            unset($_POST);
            redirect('admin/venue_catering');
        } else {
            if (!empty($cateringID)) {
                $catering_id = $cateringID;
                // $catering_id = encrypt_decrypt('decrypt', $cateringID);
                $where_fc = array('fc_id' => $cateringID);
                $catering = $this->basic_model->get_record_where('function_catering', '', $where_fc);
                if (!empty($catering)) {
                    $data['catering'] = $catering;
                    $where_user = array('user_id' => $user_id);
                    $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);
                    $data['council'] = '';
                    $where_for_council = array('suburb' => $catering[0]->fc_suburb, 'postcode' => $catering[0]->fc_postcode);
                    $council = $this->basic_model->get_record_where('aus_councils', 'council', $where_for_council);
                    // print_r($council);die;
                    if ($council) {
                        $data['council'] = $council[0]->council;
                    } else {
                        $data['council'] = $catering[0]->fc_city;
                    }
                    //--------Basic Venue Details----------//
                    $where = 'pro_id IN (1,2)';
                    $data['packs'] = $this->basic_model->get_record_where('products', '', $where);
                    $data['service_area_pack'] = $this->basic_model->get_record_where('products', '', 'pro_id IN (5,6,7)');
                    $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');
                    $where_function_type = array('type' => 'function_type', 'status' => 1);
                    $data['function_type'] = $this->basic_model->get_record_where('fnc_types', '', $where_function_type);
                    $where_cuisine = array('type' => 'cuisine', 'status' => 1);
                    $data['cuisine'] = $this->basic_model->get_record_where('fnc_types', '', $where_cuisine);
                    $where_menus = array('type' => 'menus', 'status' => 1);
                    $data['menus'] = $this->basic_model->get_record_where('fnc_types', '', $where_menus);
                    $where_services = array('type' => 'services', 'status' => 1);
                    $data['services'] = $this->basic_model->get_record_where('fnc_types', '', $where_services);
                    //--------Basic Venue Details----------//
                    $where_details = array('cd_fc_id' => $catering_id);
                    $data['catering_details'] = $this->basic_model->get_record_where('catering_details', '', $where_details);
                    $where_images = array('fc_id' => $catering_id);
                    $data['catering_images'] = $this->basic_model->get_record_where('fc_images', '', $where_images);
                    $where_csr_radius = array('csr_fc_id' => $catering_id, 'csr_status' => 0);
                    $data['catering_radius'] = $this->basic_model->get_record_where('catering_search_radius', 'csr_radius,csr_plan_id,csr_id', $where_csr_radius);
                    $this->load->view('admin/header');
                    $this->load->view('admin/menu');
                    $this->load->view('admin/edit_catering', $data);
                    $this->load->view('admin/footer');
                }
            }
        }
    }

    public function search_suburb() {
        if ($this->input->post('term')) {
            $search_term = $this->input->post('term');
            $where_term = "suburb LIKE '$search_term%'";
            $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);
            $search_result = array();

            if (!empty($coucils)) {
                $item_arr = array();

                foreach ($coucils as $key => $value) {
                    $item_arr[] = array('id' => $value->id, 'suburb' => $value->suburb, 'council' => $value->council, 'postcode' => $value->postcode, 'state' => $value->state);
                }

                $search_result['items'] = $item_arr;

                echo json_encode($search_result);
            }
        }
    }

    public function search_postcode() {
        if ($this->input->post('term')) {
            $search_term = $this->input->post('term');
            $where_term = "postcode LIKE '$search_term%'";
            $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);
            $search_result = array();
            if (!empty($coucils)) {
                $item_arr = array();
                foreach ($coucils as $key => $value) {
                    $item_arr[] = array('id' => $value->id, 'suburb' => $value->suburb, 'postcode' => $value->postcode, 'state' => $value->state);
                }
                $search_result['items'] = $item_arr;
                echo json_encode($search_result);
            }
        }
    }

    public function search_area() {
        if ($this->input->post('term')) {
            $search_term = $this->input->post('term');
            $where_term = "council LIKE '$search_term%' OR suburb LIKE '$search_term%' OR postcode LIKE '$search_term%' ";
            $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);
            $search_result = array();
            if (!empty($coucils)) {
                $item_arr = array();
                foreach ($coucils as $key => $value) {
                    $item_arr[] = array('id' => $value->id, 'council' => $value->council, 'suburb' => $value->suburb, 'postcode' => $value->postcode);
                }
                $search_result['items'] = $item_arr;
                echo json_encode($search_result);
            }
        }
    }

    /*
      public function check_council() {
      if ($this->input->post('addr_str')) {
      $search_term = $this->input->post('addr_str');
      $where_term = "council LIKE '$search_term%' OR suburb LIKE '$search_term%' OR postcode LIKE '$search_term%' ";
      $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);
      if (!empty($coucils)) {
      $response = array('status' => TRUE, 'council' => $coucils[0]->council);
      } else {
      $response = array('status' => FALSE);
      }
      echo json_encode($response);
      }
      } */

    public function change_password_admin() {
        if ($this->session->userdata()) {
            $id = $this->session->userdata("id");
            $password = $this->input->post("password");
            $old_password = md5($password);
            $where = array('id' => $id, 'password' => $old_password);
            $check = $this->basic_model->get_record_where('admin', '', $where);

            if (!empty($check)) {
                $npassword = md5($this->input->post('npassword'));
                $update_data = array('password' => $npassword);
                $this->basic_model->update_records('admin', $update_data, $where);
                $this->session->set_flashdata('success', 'User Password updated succesfully');
                redirect('admin/change_password_admin');
            } else {
                $this->load->view("admin/header");
                $this->load->view("admin/menu");
                $this->load->view("admin/admin_change_pw");
                $this->load->view("admin/footer");
            }
        }
    }

    public function load_council() {
        if ($this->input->post('first_council')) {
            $first_councile = $this->input->post('first_council');
            $where_term = array('council_id' => $first_councile);
            $relative_council = $this->basic_model->get_record_where('aus_councils', '', $where_term);
            if ($relative_council) {
                $relative_id = $relative_council[0]->rel_council;
                $where_term = "council_id IN (" . $relative_id . ") ";
                $coordinate = $this->basic_model->get_record_where('aus_councils', 'distinct(council),council_id', $where_term);
            } else {
                $coordinate = $this->basic_model->get_record_where('aus_councils', 'distinct(council)');
            }

            $options = '';
            foreach ($coordinate as $val) {
                $options .= '<option council_id="' . $val->council_id . '" value="' . $val->council . '">' . $val->council . '</option>';
            }
            echo $options;
        }
    }

    public function venue_check_business_name() {
        if ($this->input->get('venue_business_name') and ! $this->input->get('fc_id')) {
            $fc_business_name = $this->input->get('venue_business_name');
            $result = $this->basic_model->get_record_where('function_catering', '', array('fc_business_name' => $fc_business_name));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
        if ($this->input->get('venue_business_name') and $this->input->get('fc_id')) {
            $fc_business_name = $this->input->get('venue_business_name');
            $fc_id = $this->input->get('fc_id');
            $result = $this->basic_model->get_record_where('function_catering', '', array('fc_business_name' => $fc_business_name, 'fc_id !=' => $fc_id));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
    }

    public function catering_check_business_name() {
        if ($this->input->get('catering_business_name') and ! $this->input->get('fc_id')) {
            $fc_business_name = $this->input->get('catering_business_name');
            $result = $this->basic_model->get_record_where('function_catering', '', array('fc_business_name' => $fc_business_name));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
        if ($this->input->get('catering_business_name') and $this->input->get('fc_id')) {
            $fc_business_name = $this->input->get('catering_business_name');
            $fc_id = $this->input->get('fc_id');
            $result = $this->basic_model->get_record_where('function_catering', '', array('fc_business_name' => $fc_business_name, 'fc_id !=' => $fc_id));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
//echo $this->db->last_query();
    }

//new_changes
    public function premium_venues() {
        $this->load->view("admin/header");
        $this->load->view("admin/menu");
        $data['table_data_source'] = base_url('admin/premium_venues_ajax_list');
        $this->load->view("admin/premium_venues", $data);
        $this->load->view("admin/footer");
    }

    public function premium_venues_ajax_list() {
        $this->load->model('updated_model');
        echo $this->updated_model->premium_venues_ajax_list();
        die;
    }

    public function add_update_premium_venues() {
        $this->load->model('updated_model');
        $data['councils'] = $this->basic_model->get_record_where('aus_councils', 'distinct(council),council_id', $where = '');
        #echo $this->db->last_query();

        if ($this->input->post()) {
            $council_id = $this->input->post('council_id');
            $fc_business_name = $this->input->post('fc_business_name');
            $fc_business_name = array_filter($fc_business_name);
            $businessArray = implode(',', $fc_business_name);

            $check_exist = $this->basic_model->get_record_where('premium_venue', '', array('council' => $council_id));

            if (!empty($check_exist)) {
                $data = array('venue_id' =>
                    $businessArray
                );
                $this->basic_model->update_records('premium_venue', $data, array('council' => $council_id));
            } else {
                $data = array('council' => $council_id,
                    'venue_id' => $businessArray,
                    'created_date' => date('Y-m-d H:i:s'),
                );
                $this->basic_model->insert_records('premium_venue', $data);
            }
            redirect('admin/premium_venues');
        }
        $this->load->view("admin/header");
        $this->load->view("admin/menu", $data);
        $this->load->view("admin/premium_venues_add", $data);
        $this->load->view("admin/footer");
    }

//new_changes

    public function getPremimumvenues() {
        $this->load->model('updated_model');

        $postData = array('council' => $this->input->post('council'),
            'council_id' => $this->input->post('council_id')
        );
        $council = $this->input->post('council_id');

        $where = array('council' => $council);
        $data_venue = $this->basic_model->get_record_where('premium_venue', '', $where);

        $venues = array();
        if (!empty($data_venue)) {
            $data_venue[0]->venue_id;
            $venues = explode(",", $data_venue[0]->venue_id);
        }

        $opt = array();
        $data = $this->updated_model->getPremimumvenues($postData);

        $data_count = count($data);

        if ($data) {
            for ($i = 1; $i <= $data_count; $i++) {
                $status = false;
                $option = '<option value="0">select business name</option>';
                foreach ($data as $val) {

                    if (in_array($val['fc_id'], $venues) && !$status) {
                        if (($key = array_search($val['fc_id'], $venues)) !== false) {
                            unset($venues[$key]);
                        }

                        $status = true;
                        $option .= '<option selected value="' . $val['fc_id'] . '">' . $val['fc_business_name'] . '</option>';
                    } else {
                        $option .= '<option value="' . $val['fc_id'] . '">' . $val['fc_business_name'] . '</option>';
                    }
                }
                $opt[] = $option;
            }
        }
        echo json_encode(array('option' => $opt, 'count' => $data_count));
    }

    public function div2clone() {
        if ($this->input->post('clone_no') && $this->input->post('clone_word')) {
            $data['num'] = $this->input->post('clone_no');

            $data['num_word'] = inWord($this->input->post('clone_word'));

            $where_events = array('type' => 'event_type', 'status' => 1);
            $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

            $where_facilities = array('type' => 'facilities', 'status' => 1);
            $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

            $where_features = array('type' => 'features', 'status' => 1);
            $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);
            $data['img_id'] = 5 + (int) $this->input->post('clone_no');
            echo $this->load->view('venue/another_space', $data, true);
        }
    }

    public function remove_product() {
        if ($this->input->post('remove_id') && !$this->input->post('space')) {
            $remove_id = $this->input->post('remove_id');
            $remove_id = encrypt_decrypt('decrypt', $remove_id);

            $set = array('area_status' => 1);
            $this->basic_model->update_records('additional_area', $set, array('area_id' => $remove_id));

            echo json_encode(array('status' => true));
        } elseif ($this->input->post('remove_id') && $this->input->post('space')) {
            $remove_id = $this->input->post('remove_id'); // not required decrypt
            $set = array('space_status' => 1);
            $this->basic_model->update_records('venue_spaces', $set, array('space_id' => $remove_id));

            echo json_encode(array('status' => true));
        } else {
            echo json_encode(array('status' => false));
        }
    }

    public function remove_Premimum() {
        if ($this->input->post('council_id') && $this->input->post('fc_id')) {
            $council_id = $this->input->post('council_id');
            $fc_id = $this->input->post('fc_id');

            $primium_fc_ids = $this->basic_model->get_record_where('premium_venue', 'venue_id', $where = array('council' => $council_id));
            if (!empty($primium_fc_ids)) {
                $primium_fcs = explode(',', $primium_fc_ids[0]->venue_id);
                if (($key = array_search($fc_id, $primium_fcs)) !== false) {
                    unset($primium_fcs[$key]);
                }
                $new_primium_ids = implode(',', $primium_fcs);
                $this->basic_model->update_records('premium_venue', array('venue_id' => $new_primium_ids), $where = array('council' => $council_id));
                echo json_encode(array('status' => true));
            } else {
                echo json_encode(array('status' => false));
            }
        } elseif ($this->input->post('council_id') && !$this->input->post('fc_id')) {
            $council_id = $this->input->post('council_id');
            $primium_fc_ids = $this->basic_model->delete_records('premium_venue', $where = array('council' => $council_id));
            echo json_encode(array('status' => true));
        }
    }

    public function add_extra_area() {
        $status = true;
        $pro_id = $this->input->post('pack_id');
        $where_pro = array('pro_id' => $pro_id);
        $get_price = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);
        if (!empty($get_price)) {
            $name = $get_price[0]->pro_title;
            $price = $get_price[0]->pro_price;
            $pro_curr = $get_price[0]->pro_curr;
            $fc_id = $this->input->post('fc_id');
            $where = array('csr_fc_id' => $fc_id);
            $get_check = $this->basic_model->get_record_where('catering_search_radius', '', $where);
            if (!empty($get_check)) {
                if ($this->input->post('fc_id')) {
                    $where = array('csr_fc_id' => $this->input->post('fc_id'));
                    $data = $this->basic_model->update_records('catering_search_radius', array('csr_status' => 0, 'csr_radius' => $name, 'csr_plan_id' => $pro_id), $where);
                    echo json_encode($data);
                }
            } else {
                $insert_data = array('csr_radius' => $name,
                    'csr_status' => 0,
                    'csr_plan_id' => $pro_id,
                    'csr_fc_id' => $this->input->post('fc_id'),
                    'csr_created_on' => date('Y-m-d H:i:s'));
                $data = $this->basic_model->insert_records('catering_search_radius', $insert_data);
                echo json_encode($data);
            }
        }
    }

    function update_status_catering() {
        if ($this->input->post('fc_id')) {
            $where = array('csr_fc_id' => $this->input->post('fc_id'));
            $this->load->model("basic_model");
            //$data = $this->basic_model->update_records('catering_search_radius', array('csr_status' => 1 ), $where);
            $data = $this->basic_model->delete_records('catering_search_radius', $where);
            echo json_encode($data);
        }
    }

    public function voucher() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $data['table_data_source'] = base_url('admin/voucher_ajax_list');
        $this->load->view('admin/voucher', $data);
        $this->load->view('admin/footer');
        $data['body_class'] = 'classname';
    }

    public function voucher_ajax_list() {
        $this->load->model('updated_model');
        echo $this->updated_model->voucher_ajax_list();
        die;
    }

    public function voucher_add() {
        $data['page_title'] = 'Add voucher';
        $data['active_class'] = 'voucher_list';
        $data['form_action'] = base_url('admin/voucher_add/');

        if ($this->input->post()) {
            $start_date = date('Y-m-d', strtotime($_POST['start_date']));
            $end_date = date('Y-m-d', strtotime($_POST['end_date']));

            $insert_data = array(
                'voucher_code' => $this->input->post('voucher_code'),
                'description' => $this->input->post('description'),
                'value' => $this->input->post('value'),
                'start_date' => $start_date,
                'end_date' => $end_date,
                'total_value' => $this->input->post('total_value'),
                'voucher_use' => $this->input->post('voucher_use')
            );
            $data = $this->basic_model->insert_records('voucher', $insert_data);
            $this->session->set_flashdata('success', 'Added successfully');
        }
        $this->load->view('admin/header', $data);
        $this->load->view('admin/menu', $data);
        $this->load->view('admin/voucher_add', $data);
        $this->load->view('admin/footer', $data);
    }

    public function voucher_edit() {
        $data['page_title'] = 'Update voucher';
        $data['active_class'] = 'voucher_list';
        $uri = $this->uri->segment(3);
        if (!empty($uri)) {
            $data['form_action'] = base_url('admin/voucher_update/' . $uri);
            $where = array('id' => $uri);
            $data['user_record'] = $this->basic_model->get_record_where('voucher', '', $where);
            if (empty($data['user_record']))
                redirect(base_url('store_group'));

            $this->load->view('admin/header', $data);
            $this->load->view('admin/menu', $data);
            $this->load->view('admin/voucher_add', $data);
            $this->load->view('admin/footer', $data);
        }
        else {
            redirect(base_url('store_group'));
        }
    }

    public function voucher_update() {
        $uri = $this->uri->segment(3);
        $data['page_title'] = 'Update voucher';
        $data['active_class'] = 'voucher_list';

        if (!empty($uri)) {
            $where = array('id' => $uri);
            $start_date = date('Y-m-d', strtotime($_POST['start_date']));
            $end_date = date('Y-m-d', strtotime($_POST['end_date']));
            $update_data = array(
                'voucher_code' => $this->input->post('voucher_code'),
                'description' => $this->input->post('description'),
                'value' => $this->input->post('value'),
                'start_date' => $start_date,
                'end_date' => $end_date,
                'total_value' => $this->input->post('total_value'),
                'voucher_use' => $this->input->post('voucher_use')
            );
            $data = $this->basic_model->update_records('voucher', $update_data, $where);
            redirect('admin/voucher');
        }
    }

    public function update_voucher_status() {
        if ($this->input->post('id')) {
            $data = array('voucher_status' => $this->input->post('voucher_status'));
            $where = array('id' => $this->input->post('id'));
            $this->load->model("basic_model");
            $my_data = $this->basic_model->update_records('voucher', $data, $where);
            echo "1";
        }
    }

    public function delete_voucher() {
        if ($this->input->post('id')) {
            $where = array('id' => $this->input->post('id'));
            $this->load->model("basic_model");
            $my_data = $this->basic_model->delete_records('voucher', $where);
            echo "1";
        }
    }

    public function pages() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $data['table_data_source'] = base_url('admin/pages_ajax_list');
        $this->load->view('admin/pages_view', $data);
        $this->load->view('admin/footer');
    }

    public function pages_ajax_list() {
        $this->load->model('updated_model');
        echo $this->updated_model->pages_ajax_list();
        die;
    }

    public function pages_edit() {
        $data['page_title'] = 'Update pages';
        $data['active_class'] = 'pages_list';
        $uri = $this->uri->segment(3);
        if (!empty($uri)) {
            $data['form_action'] = base_url('admin/pages_update/' . $uri);
            $where = array('id' => $uri);
            $data['user_record'] = $this->basic_model->get_record_where('pages', '', $where);
            if (empty($data['user_record']))
                redirect(base_url('store_group'));

            $this->load->view('admin/header', $data);
            $this->load->view('admin/menu', $data);
            $this->load->view('admin/pages_edit', $data);
            $this->load->view('admin/footer', $data);
        }
        else {
            redirect(base_url('store_group'));
        }
    }

    public function pages_update() {
        $uri = $this->uri->segment(3);
        $data['page_title'] = 'Update pages';
        $data['active_class'] = 'pages_list';

        if (!empty($uri)) {
            $where = array('id' => $uri);
            $update_data = array(
                'content' => $this->input->post('content')
            );
            $data = $this->basic_model->update_records('pages', $update_data, $where);
            redirect('admin/pages');
        }
    }

    public function voucher_history() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $data['table_data_source'] = base_url('admin/voucher_history_ajax_list');
        $this->load->view('admin/voucher_history', $data);
        $this->load->view('admin/footer');
        $data['body_class'] = 'classname';
    }

    public function voucher_history_ajax_list() {
        $this->load->model('updated_model');
        echo $this->updated_model->voucher_history_ajax_list();
        die;
    }

    public function voucher_check_name() {
        if ($this->input->get('voucher_code') and ! $this->input->get('id')) {
            $voucher_code = $this->input->get('voucher_code');
            $result = $this->basic_model->get_record_where('voucher', '', array('voucher_code' => $voucher_code));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
        if ($this->input->get('voucher_code') and $this->input->get('id')) {
            $voucher_code = $this->input->get('voucher_code');
            $id = $this->input->get('id');
            $result = $this->basic_model->get_record_where('voucher', '', array('voucher_code' => $voucher_code, 'id !=' => $id));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
    }

    public function payment_details() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $data['table_data_source'] = base_url('admin/payment_details_ajax_list');
        $this->load->view('admin/payment_details', $data);
        $this->load->view('admin/footer');
        $data['body_class'] = 'classname';
    }

    public function payment_details_ajax_list() {
        $this->load->model('updated_model');
        echo $this->updated_model->payment_details_ajax_list();
        die;
    }

    public function PaymentDetails_edit() {
        if ($this->input->post('pay_id')) {
            $pay_id = $this->input->post('pay_id');
            $where = array('pay_id' => $pay_id);
            $this->load->model("basic_model");
            $data = $this->basic_model->get_record_where('payment_details', '', $where);
            echo json_encode($data);
        }
    }

    public function get_payment_detail() {
        if ($this->input->post('pay_id')) {
            $pay_id = $this->input->post('pay_id');
            $where = array('pay_id' => $pay_id);
            $this->load->model("basic_model");
            $data_new['user_record'] = $this->basic_model->get_record_where('payment_details', '', $where);

            $packs = $this->basic_model->get_record_where('products', 'pro_id,pro_title', '');
            foreach ($packs as $val) {
                $product[$val->pro_id] = (array) $val;
            }
            $data_new['products'] = $product;
            $this->load->view('admin/payment_view', $data_new);
        }
    }

    // Edit PaymentDetails of transaction id
    public function PaymentDetails_update() {
        if ($this->input->post('pay_id')) {
            $where = array('pay_id' => $this->input->post('pay_id'));
            $this->load->model("basic_model");
            $data['payment_deatils'] = $this->basic_model->get_record_where('payment_details', 'pay_for,payment_mode', $where);
            //print_r($data['payment_deatils']);
            $pay_for['details'] = json_decode($data['payment_deatils'][0]->pay_for);
            if (!empty($pay_for)) {
                foreach ($pay_for['details'] as $obj) {
                    if (($obj->id == 1 || $obj->id == 2) && $data['payment_deatils'][0]->payment_mode == 1) {
                        $fc_id = $this->input->post('pay_fc_id');
                        $where_fc = array('function_catering.fc_id' => $fc_id);
                        $catering_data = $this->basic_model->get_record_where('function_catering', 'fc_valid_upto', $where_fc);
                        $old_expiry_date = $catering_data[0]->fc_valid_upto;

                        if (strtotime($old_expiry_date) < strtotime(date('Y-m-d'))) {
                            $old_expiry_date = date('Y-m-d');
                        }

                        $where_pro = array('pro_id' => $obj->id);
                        // print_r($where_pro);die;
                        $get_price = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_pro);
                        $validity_type = $get_price[0]->pro_pay_type;
                        $valid_upto = date("Y-m-d", strtotime("+1 $validity_type", strtotime($old_expiry_date)));
                        $this->basic_model->update_records('function_catering', array('fc_valid_upto' => $valid_upto, 'fc_current_plan' => $obj->id, 'fc_free' => 0), $where_fc);
                    }
                    if ($obj->id == 3 || $obj->id == 4) {
                        $data['additional_item_data'] = $this->input->post('additional_item_data');
                        $additional_item_data['venue_area'] = json_decode($data['additional_item_data']);
                        // print_r($additional_item_data);die;
                        if (!empty($additional_item_data['venue_area']->spaces)) {
                            // print_r($additional_item_data['venue_area']->spaces);die;
                            foreach ($additional_item_data['venue_area']->spaces as $spaces_values) {
                                $where = array('venue_spaces.space_id' => $spaces_values, 'venue_spaces.space_status' => 2);
                                // print_r($where);die;
                                $data = array('venue_spaces.space_status' => 0);
                                $my_data = $this->basic_model->update_records('venue_spaces', $data, $where);
                            }
                        }
                        if (!empty($additional_item_data['venue_area']->area)) {
                            // print_r($additional_item_data['venue_area']->spaces);die;
                            foreach ($additional_item_data['venue_area']->area as $area_values) {
                                $where = array('additional_area.area_id' => $area_values, 'additional_area.area_status' => 2);
                                $data = array('additional_area.area_status' => 0);
                                $my_data = $this->basic_model->update_records('additional_area', $data, $where);
                            }
                        }
                    }



                    if ($obj->id == 5 || $obj->id == 6 || $obj->id == 7) {
                        $where_pro = array('pro_id' => $obj->id);
                        // print_r($where_pro);die;
                        $get_price = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);
                        if (!empty($get_price)) {
                            $name = $get_price[0]->pro_title;
                            $price = $get_price[0]->pro_price;
                            $pro_curr = $get_price[0]->pro_curr;
                            $fc_id = $this->input->post('pay_fc_id');
                            // print_r($fc_id);die;
                            $where_fc = array('catering_search_radius.csr_fc_id' => $fc_id);
                            $get_check = $this->basic_model->get_record_where('catering_search_radius', '', $where_fc);
                            if (!empty($get_check)) {
                                if ($this->input->post('pay_fc_id')) {
                                    $where = array('csr_fc_id' => $this->input->post('pay_fc_id'));
                                    $data = $this->basic_model->update_records('catering_search_radius', array('csr_status' => 0, 'csr_radius' => $name, 'csr_plan_id' => $obj->id), $where);
                                }
                            } else {
                                $insert_data = array('csr_radius' => $name,
                                    'csr_status' => 0,
                                    'csr_plan_id' => $obj->id,
                                    'csr_fc_id' => $this->input->post('pay_fc_id'),
                                    'csr_created_on' => date('Y-m-d H:i:s'));
                                $data = $this->basic_model->insert_records('catering_search_radius', $insert_data);
                            }
                        }
                    }
                }
            }
            // die;
            $where_new = array('pay_id' => $this->input->post('pay_id'));
            $data = array('pay_txn_id' => $this->input->post('pay_txn_id'), 'payment_status' => 2);
            $my_data = $this->basic_model->update_records('payment_details', $data, $where_new);
        }
    }

// function check_tx_id(){
//     if ($this->input->get('pay_txn_id')) {
//             $pay_txn_id = $this->input->get('pay_txn_id');
//             $result = $this->basic_model->get_record_where('payment_details', '', array('pay_txn_id' => $pay_txn_id));
//             // echo $this->db->last_query();die;
//             if (!empty($result)) {
//                   echo 'false';
//             } else {
//                 echo 'true';
//             }
//     }
// }

    public function check_tx_id() {
        if ($this->input->get('pay_txn_id') and ! $this->input->get('pay_id')) {
            $pay_txn_id = $this->input->get('pay_txn_id');
            $result = $this->basic_model->get_record_where('payment_details', '', array('pay_txn_id' => $pay_txn_id));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
        if ($this->input->get('pay_txn_id') and $this->input->get('pay_id')) {
            $pay_txn_id = $this->input->get('pay_txn_id');
            $pay_id = $this->input->get('pay_id');
            $result = $this->basic_model->get_record_where('payment_details', '', array('pay_txn_id' => $pay_txn_id, 'pay_id !=' => $pay_id));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
    }

    public function user_add() {

        $this->load->library('form_validation');
        $this->form_validation->set_rules("user_phone_no", "Phone number", "required");
        $this->form_validation->set_rules("user_email", "Email", "required|valid_email");
        $this->form_validation->set_rules("user_firstname", "First name", "required");
        $this->form_validation->set_rules("user_lastname", "last name", "required");
        if ($this->form_validation->run() == FALSE) {
            // $this->load->view('admin/header');
            // $this->load->view('admin/menu');
            // $this->load->view('admin/user_add');
            // $this->load->view('admin/footer');
        } else {

            if ($this->input->post()) {
                $userData = $this->input->post();
                $user_id = $this->input->post('user_id');
                $type = $this->input->post('user_type');

                $hash = md5(rand(1000, 9000000));

                $userData = array(
                    'user_firstname' => $this->input->post('user_firstname'),
                    'user_lastname' => $this->input->post('user_lastname'),
                    'user_phone_no' => $this->input->post('user_phone_no'),
                    'user_email' => $this->input->post('user_email'),
                    'user_business_name' => $this->input->post('user_business_name'),
                    'user_abn' => $this->input->post('user_abn'),
//                    'user_city' => $this->input->post('user_city'),
//                    'user_suburb' => $this->input->post('user_suburb'),
//                    'user_address' => $this->input->post('user_address'),
//                    'user_state' => $this->input->post('user_state'),
                    'user_postcode' => $this->input->post('user_postcode'),
                    'is_registration' => 1,
                    'user_hash' => $hash
                );

//                $imageName = $this->input->post('dimesion_image_11111');
//
//                if (!empty($imageName)) {
//                    $reposne = $this->copy_image_user($imageName);
//                    $image_url = '';
//                    if ($reposne['status']) {
//                        $image_url = base_url() . 'uploads/users/' . $this->input->post('dimesion_image_11111');
//                        $userData['user_image'] = $image_url;
//                    }
//                    $session_data = array(
//                        'user_image' => $image_url
//                    );
//                    $this->session->set_userdata($session_data);
//                }

                $config['upload_path'] = './uploads/users/';
                $config['allowed_types'] = 'gif|jpg|png';

                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ($this->upload->do_upload('user_image')) {
                    $data = array('upload_data' => $this->upload->data());
                    $image_url = base_url() . '/uploads/users/' . $data['upload_data']['file_name'];
                    $userData['user_image'] = $image_url;
                }

                $id = $this->basic_model->insert_records('users', $userData);
                if (!empty($type)) {
                    foreach ($type as $value) {

                        $bus_auth_data = array(
                            'bus_auth_req' => $value,
                            'user_id' => $id,
                            'bus_auth_status' => 1,
                            'bus_auth_create_time' => date('Y,m,d h:i:sa')
                        );

                        $this->basic_model->insert_records('businesses_authorized', $bus_auth_data);
                    }
                }
                $userData['user_id'] = $id;
                $username = $userData['user_firstname'] . ' ' . $userData['user_lastname'];
                $userData['user_id'] = $id;



                if ($id > 0) {
                    $data['confirm'] = customer_confirmation_mail($userData);
                    // $data['confirm'] = random_password($userData);
                    $this->session->set_flashdata('success', 'User added successfully , please verify from gmail');
                } else {
                    $this->session->set_flashdata('error', 'Error in User insertion');
                }
            }
        }

        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $this->load->view('admin/user_add');
        $this->load->view('admin/footer');
    }

    public function copy_image_user($imgName) {

        $tempPath = FCPATH . '/uploads/venue_spaces/temp/' . $imgName;
        $newPath = FCPATH . '/uploads/users/' . $imgName;

        $imageExist = $this->is_valid_type($tempPath);
        $arrResponse = array();

        if ($imageExist) {
            $copied = copy($tempPath, $newPath);
            if ((!$copied)) {
                $arrResponse = array('status' => false);
            } else {
                unlink($tempPath);
                $doc_root = $_SERVER["DOCUMENT_ROOT"] . '/uploads/users/' . $imgName;
                $arrResponse = array('status' => true, 'path' => $doc_root);
            }
        } else {
            $arrResponse = array('status' => false);
        }
        return $arrResponse;
    }

    function is_valid_type($file) {
        $size = getimagesize($file);
        if (!$size) {
            return 0;
        }

        $valid_types = array(IMAGETYPE_GIF, IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_BMP);

        if (in_array($size[2], $valid_types)) {
            return true;
        } else {
            return false;
        }
    }

// echo random_password();

    public function archive_single_user() {
        if ($this->input->post('fc_id')) {
            $data = array('fc_is_deleted' => 1);
            $where = array('fc_id' => $this->input->post('fc_id'));
            $this->load->model("basic_model");
            echo $my_data = $this->basic_model->update_records('function_catering', $data, $where);
        }
    }

    public function archive_single_review() {
        if ($this->input->post('f_id')) {
            $data = array('f_status' => 5);
            $where = array('f_id' => $this->input->post('f_id'));
            $this->load->model("basic_model");
            echo $my_data = $this->basic_model->update_records('feedback', $data, $where);
        }
    }

    public function archive_single_bus_auth() {
        if ($this->input->post('bus_auth_id')) {
            $data = array('bus_is_deleted' => 1);
            $where = array('bus_auth_id' => $this->input->post('bus_auth_id'));
            $this->load->model("basic_model");
            echo $my_data = $this->basic_model->update_records('businesses_authorized', $data, $where);
        }
    }

    public function archive_single_premium() {
        if ($this->input->post('council_id')) {
            $data = array('is_deleted' => 1);
            $where = array('council' => $this->input->post('council_id'));
            $this->load->model("basic_model");
            echo $my_data = $this->basic_model->update_records('premium_venue', $data, $where);
        }
    }

    public function archive_single_voucher() {
        if ($this->input->post('id')) {
            $data = array('is_deleted' => 1);
            $where = array('id' => $this->input->post('id'));
            $this->load->model("basic_model");
            echo $my_data = $this->basic_model->update_records('voucher', $data, $where);
        }
    }

    public function archive_single_users() {
        if ($this->input->post('user_id')) {
            $data = array('is_deleted' => 1);
            $where = array('user_id' => $this->input->post('user_id'));
            $this->load->model("basic_model");
            echo $my_data = $this->basic_model->update_records('users', $data, $where);
            // echo json_encode($my_data);
        }
    }

    public function active_single_users() {
        if ($this->input->post('user_id')) {
            $data = array('is_deleted' => 0);
            $where = array('user_id' => $this->input->post('user_id'));
            $this->load->model("basic_model");
            echo $my_data = $this->basic_model->update_records('users', $data, $where);
        }
    }

    function admin_vanue_preview($fc_id = 0) {
        $user_id = $this->session->userdata('user_id');
        require_once(APPPATH . 'libraries/mpdf/mpdf.php');
        $data = array();
        $this->load->model('web_model');
        if (!empty($fc_id)) {
            $data['venue_data'] = array();
            $data['pdf_data'] = array();
            $fc_data = array();
            $where = array('fc_id' => $fc_id);
            $functionData = $this->basic_model->get_record_where('function_catering', $column = '', array('fc_id' => $fc_id));
            if ($functionData) {
                $fc_data = $functionData[0];
                $data['extra_detils'] = $this->basic_model->get_record_where('venue_details', $column = '', array('vd_fc_id' => $fc_id));
                $fc_venue_detail = false;
                if ($data['extra_detils']) {
                    $fc_venue_details = $data['extra_detils'][0];
                }
                if ($fc_id) {
                    $where_venue = array('space_venue' => $fc_id, 'space_status' => 0);
                    $spaces = $this->basic_model->get_record_where('venue_spaces', 'space_id, space_name', $where_venue);
                    if (!empty($spaces))
                        $fc_data->spaces = $spaces;
                }
                $data['images'] = $this->basic_model->get_record_where('fc_images', 'fc_img_name', $where);
                if ($data['images']) {
                    foreach ($data['images'] as $img) {
                        $fc_data->fc_images[] = $img->fc_img_name;
                    }
                }
                $data['pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '*', $where);
                if ($data['pdfs']) {
                    foreach ($data['pdfs'] as $img) {
                        $fc_data->fc_pdfs[] = $img;
                    }
                }
                $fc_data->fc_pricing = '';
                $fc_data->events = '';
                $fc_data->facilities = '';
                $fc_data->features = '';
                $fc_data->nearest_to_me = '';
                if ($fc_data->fc_pricing) {
                    $where = 'p_id IN (' . $fc_data->fc_pricing . ')';
                    $pricing = $this->basic_model->get_record_where('price_per_head', 'p_name,p_value', $where);
                    $fc_data->fc_pricing = $pricing;
                }
                if (!empty($fc_venue_details->vd_events)) {
                    $where = 'type="event_type" and id IN (' . $fc_venue_details->vd_events . ')';
                    $events = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->events = $events;
                }
                if (!empty($fc_venue_details->vd_facilities)) {
                    $where = 'type="facilities" and id IN (' . $fc_venue_details->vd_facilities . ')';
                    $facilities = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->facilities = $facilities;
                }
                if (!empty($fc_venue_details->vd_features)) {
                    $where = 'type="features" and id IN (' . $fc_venue_details->vd_features . ')';
                    $features = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->features = $features;
                }
                if ($fc_data->fc_lat) {
                    $data['nearest_to_me'] = $this->web_model->find_nearest($fc_data->fc_lat, $fc_data->fc_lng);
                }
                $data['venue_data'] = $fc_data;
            }
            $file = $this->load->view('admin/preview_venue_listing_pdf', $data, true);
            @ob_clean();
            $mpdf = new mPDF();
            $mpdf->WriteHTML($file);
            $mpdf->Output();
        } else {
            redirect('admin/venue_catering');
        }
    }

    function admin_catering_preview($fc_id = 0) {
        $user_id = $this->session->userdata('user_id');
        require_once(APPPATH . 'libraries/mpdf/mpdf.php');
        $data = array();
        $this->load->model('web_model');
        if (!empty($fc_id)) {
            $data['venue_data'] = array();
            $data['pdf_data'] = array();
            $fc_data = array();
            $where = array('fc_id' => $fc_id);
            $functionData = $this->basic_model->get_record_where('function_catering', $column = '', array('fc_id' => $fc_id));
            if ($functionData) {
                $fc_data = $functionData[0];
                $data['extra_detils'] = $this->basic_model->get_record_where('catering_details', $column = '', array('cd_fc_id' => $fc_id));
                $fc_venue_detail = false;
                if ($data['extra_detils']) {
                    $fc_venue_details = $data['extra_detils'][0];
                }
                if ($fc_id) {
                    $cartData = $this->cart->contents();
                    if (!empty($cartData)) {
                        foreach ($cartData as $val) {
                            if ($val['id'] == 4) {
                                $fc_data->spaces[] = $val['options']['space_name'];
                            }
                        }
                    }
                }
                $data['images'] = $this->basic_model->get_record_where('fc_images', 'fc_img_name', $where);
                if ($data['images']) {
                    foreach ($data['images'] as $img) {
                        $fc_data->fc_images[] = $img->fc_img_name;
                    }
                }
                $data['pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '*', $where);
                if ($data['pdfs']) {
                    foreach ($data['pdfs'] as $img) {
                        $fc_data->fc_pdfs[] = $img;
                    }
                }

                $fc_data->fc_pricing = '';
                $fc_data->events = '';
                $fc_data->facilities = '';
                $fc_data->features = '';
                $fc_data->nearest_to_me = '';
                if ($fc_data->fc_pricing) {
                    $where = 'p_id IN (' . $fc_data->fc_pricing . ')';
                    $pricing = $this->basic_model->get_record_where('price_per_head', 'p_name,p_value', $where);
                    $fc_data->fc_pricing = $pricing;
                }
                if (!empty($fc_venue_details->cd_function_type)) {
                    $where = 'type="function_type" and id IN (' . $fc_venue_details->cd_function_type . ')';
                    $function_type = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->function_type = $function_type;
                }

                if (!empty($fc_venue_details->cd_menus)) {
                    $where = 'type="menus" and id IN (' . $fc_venue_details->cd_menus . ')';
                    $menus = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->menus = $menus;
                }

                if (!empty($fc_venue_details->cd_cuisine)) {
                    $where = 'type="cuisine" and id IN (' . $fc_venue_details->cd_cuisine . ')';
                    $cuisine = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->cuisine = $cuisine;
                }

                if (!empty($fc_venue_details->cd_services)) {
                    $where = 'type="services" and id IN (' . $fc_venue_details->cd_services . ')';
                    $services = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->services = $services;
                }
                if ($fc_data->fc_lat) {
                    $data['nearest_to_me'] = $this->web_model->find_nearest($fc_data->fc_lat, $fc_data->fc_lng);
                }
                $data['venue_data'] = $fc_data;
            }
            $file = $this->load->view('admin/preview_catering_listing_pdf', $data, true);
            @ob_clean();
            $mpdf = new mPDF();
            $mpdf->WriteHTML($file);
            $mpdf->Output();
        } else {
            redirect('admin/venue_catering');
        }
    }

}
