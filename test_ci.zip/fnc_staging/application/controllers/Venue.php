<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Venue extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->library('cart');
        if (!$this->session->userdata('user_email'))
            redirect('login/user_login');
    }

    public function index() {
        redirect('my_venues');
    }

    public function add_venue() {
        $permission = cater_permission();
        if (isset($permission->bus_auth_status) && $permission->bus_auth_status != 1)
            redirect(base_url('request'));

        $data['title'] = 'Add venue';
        $this->cart->destroy();
        $data['firstcart'] = '';
        $data['plan_id'] = false;
        $data['draft_venue_space'] = false;
        $data['draft_addional_row_id'] = false;
        $data['free'] = false;

        if ($this->uri->segment(2)) {
            $venue_id = encrypt_decrypt('decrypt', $this->uri->segment(2));

            $where_fc = array('fc_id' => $venue_id);
            $venue = $this->basic_model->get_record_where('function_catering', '', $where_fc);


            if (!empty($venue)) {
                $data['draft_venue'] = $venue;
                /* --------load cart data--------- */
                $draft_cart = '';
                if (!empty($venue[0]->fc_cart_data) && $venue[0]->fc_cart_data != 'free') {
                    $draft_cart = unserialize($venue[0]->fc_cart_data);
                }

                if ($draft_cart != 'free' && !empty($draft_cart)) {
                    $i = 1;

                    if (in_array(1, array_column($draft_cart, 'id'))) {
                        $response = $this->add2cart(1);
                        $data['plan_id'] = 1;
                        $data['firstcart'] = $response['row_id'];
                    } elseif (in_array(2, array_column($draft_cart, 'id'))) {
                        $response = $this->add2cart(2);
                        $data['plan_id'] = 2;
                        $data['firstcart'] = $response['row_id'];
                    }


                    foreach ($draft_cart as $item) {
                        if ($item['id'] == 3) {
                            for ($i = 1; $i <= $item['qty']; $i++) {
                                $this->add2cart($item['id'], $data['firstcart']);
                            }
                        } elseif ($item['id'] == 4) {
                            for ($i = 1; $i <= $item['qty']; $i++) {
                                $additonal_space = $this->add2cart($item['id'], $data['firstcart']);
                                $data['draft_addional_row_id'] = $additonal_space['row_id'];
                            }
                        }
                    }
                } else {
                    $data['free'] = $venue[0]->fc_cart_data;
                    $data['plan_id'] = 0;
                }

                /* ---------get council-------- */
                $data['draft_council'] = '';
                $where_for_council = array('suburb' => $venue[0]->fc_suburb, 'postcode' => $venue[0]->fc_postcode);
                $council = $this->basic_model->get_record_where('aus_councils', 'council,council_id,zoom', $where_for_council);
                if ($council) {
                    $data['draft_council'] = $council[0]->council;
                    $data['draft_council_id'] = $council[0]->council_id;
                    $data['zoom'] = $council[0]->zoom;
                } else {
                    $data['draft_council'] = $venue[0]->fc_suburb;
                    $data['draft_council_id'] = '';
                    $data['zoom'] = 8;
                }

                /* -----------------get space of venue----------- */
                $where_space = array('space_venue' => $venue_id);

                $data['draft_venue_space'] = $this->basic_model->get_record_where('venue_spaces', '', $where_space);

                //--------additional area Details----------//
                $join = array(
                    'aus_councils' => 'aus_councils.council = additional_area.area_name'
                );
                $column = 'distinct(aus_councils.council_id),additional_area.*';
                $draft_additinal_council = $this->basic_model->get_record_join_tables('additional_area', array('area_venue' => $venue_id), $column, $join, '', '', '', 'ASC', 'inner', '');
                $data['draft_additinal_council'] = $draft_additinal_council;

                $where_details = array('vd_fc_id' => $venue_id);
                $data['draft_venue_details'] = $this->basic_model->get_record_where('venue_details', '', $where_details);

                $where_images = array('fc_id' => $venue_id);
                $data['draft_venue_images'] = $this->basic_model->get_record_where('fc_images', '', $where_images);
            } else {
                redirect('my_venues');
            }
        }

        $user_id = $this->session->userdata('user_id');

        $where_user = array('user_id' => $user_id);
        $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

        $where = 'pro_id IN (1,2)';
        $data['packs'] = $this->basic_model->get_record_where('products', '', $where);

        $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');

        $where_events = array('type' => 'event_type', 'status' => 1);
        $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

        $where_facilities = array('type' => 'facilities', 'status' => 1);
        $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

        $where_features = array('type' => 'features', 'status' => 1);
        $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);

        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('venue/add_venue', $data);
        $this->load->view('footer');
    }

    public function get_pricing() {
        if ($this->input->post('pack_id')) {
            $pro_id = $this->input->post('pack_id');

            $where_pro = array('pro_id' => $pro_id);
            $get_price = $this->basic_model->get_record_where('products', 'pro_price', $where_pro);

            if (!empty($get_price)) {
                $price = $get_price[0]->pro_price;

                echo json_encode(array('status' => TRUE, 'price' => $price));
            } else {
                echo json_encode(array('status' => FALSE));
            }
        } else {
            echo json_encode(array('status' => FALSE));
        }
    }

    public function add2cart($pack_id = 0, $draft_FirstCart = '') {
        if ($pack_id > 0 || $this->input->post('pack_id')) {
            $row_id = false;
            if ($pack_id > 0) {
                $pro_id = $pack_id;
            } else {
                $pro_id = $this->input->post('pack_id');
            }

            $where_pro = array('pro_id' => $pro_id);
            $get_price = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);

            if (!empty($get_price)) {
                $name = $get_price[0]->pro_title;
                $price = $get_price[0]->pro_price;

                // Product currency 0-Dollar / 1-Cent
                $pro_curr = $get_price[0]->pro_curr;

                if ($pro_curr == 1) {
                    $cart_content = $this->cart->contents();

                    if (($this->input->post('firstcart') && $cart_content) || (!empty($draft_FirstCart))) {
                        if (!empty($draft_FirstCart)) {
                            $firstcart = $draft_FirstCart;
                        } else {
                            $firstcart = $this->input->post('firstcart');
                        }

                        $product_id = $cart_content[$firstcart]['id'];

                        $where_p = array('pro_id' => $product_id);
                        $get_term = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_p);

                        if (!empty($get_term)) {
                            $term = $get_term[0]->pro_pay_type;

                            if ($term == 'month') {
                                $price = $price * 30;

                                $price = $price / 100;
                            } elseif ($term == 'year') {
                                $price = $price * 365;

                                $price = $price / 100;
                            }
                        }
                    }
                }

                if ($this->input->post('firstplan')) {
                    if ($this->input->post('firstcart')) {
                        $firstcart = $this->input->post('firstcart');

                        $cart_content = $this->cart->contents();

                        $product_id = $cart_content[$firstcart]['id'];

                        if ($product_id) {
                            $row_id = $this->change_plan($pro_id, $firstcart);
                        }
                    } else {
                        $data = array(
                            'id' => $pro_id,
                            'qty' => 1,
                            'price' => $price,
                            'name' => 'Product-ID-' . $pro_id
                        );

                        $row_id = $this->cart->insert($data);
                    }
                } elseif ($this->input->post('total_another') > 0 && $pro_id == 4 && $this->input->post('row_id') != '') {

                    $data = array(
                        'rowid' => $this->input->post('row_id'),
                        'qty' => $this->input->post('total_another'),
                    );

                    $this->cart->update($data);
                    $row_id = $this->input->post('row_id');
                } else {
                    $data = array(
                        'id' => $pro_id,
                        'qty' => 1,
                        'price' => $price,
                        'name' => 'Product-ID-' . $pro_id
                    );

                    $row_id = $this->cart->insert($data);
                }

                $cart_content = $this->cart->contents();

                $cart_total = $this->cart->total();
                $result = array('status' => TRUE, 'cart_content' => $cart_content, 'row_id' => $row_id, 'cart_total' => $cart_total);

                if ($pack_id > 0) {
                    return $result;
                } else {
                    echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'row_id' => $row_id, 'cart_total' => $cart_total));
                }
            } else {
                echo json_encode(array('status' => FALSE));
            }
        } else {
            echo json_encode(array('status' => FALSE));
        }
    }

    public function remove_2_cart() {
        if ($this->input->post()) {
            $prod_id = $this->input->post('pack_id');
            $cart_content = $this->cart->contents();
            if (!empty($cart_content)) {
                foreach ($cart_content as $rowid => $val) {
                    if ($val['id'] == $prod_id) {
                        $new_qty = $val['qty'] - 1;

                        $p_data = array(
                            'rowid' => $rowid,
                            'qty' => $new_qty,
                        );

                        $this->cart->update($p_data);
                    }
                }
            }

            $cart_total = $this->cart->total();
            echo json_encode(array('status' => true, 'cart_total' => $cart_total));
        } else {
            echo json_encode(array('status' => false));
        }
    }

    public function change_plan($pro_id, $firstcart) {
        $data = array(
            'rowid' => $firstcart,
            'qty' => 0
        );

        $this->cart->update($data);

        $where_pro = array('pro_id' => $pro_id);
        $get_price = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr, pro_pay_type', $where_pro);

        if (!empty($get_price)) {
            $name = $get_price[0]->pro_title;
            $price = $get_price[0]->pro_price;

            // Product currency 0-Dollar / 1-Cent
            $pro_curr = $get_price[0]->pro_curr;

            $term = $get_price[0]->pro_pay_type;

            $data = array(
                'id' => $pro_id,
                'qty' => 1,
                'price' => $price,
                'name' => 'Product-ID-' . $pro_id
            );

            $firstcart = $this->cart->insert($data);

            $cart_content = $this->cart->contents();

            if (!empty($cart_content)) {
                foreach ($cart_content as $value) {
                    if ($value['id'] != $pro_id) {
                        $p_id = $value['id'];

                        $rowid = $value['rowid'];
                        $qty = $value['qty'];

                        $where_p = array('pro_id' => $p_id);
                        $get_p = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_p);

                        if (!empty($get_p)) {
                            $p_price = $get_p[0]->pro_price;
                            $p_curr = $get_p[0]->pro_curr;

                            if ($term == 'month') {
                                $p_price = $p_price * 30;
                            } elseif ($term == 'year') {
                                $p_price = $p_price * 365;
                            }

                            if ($p_curr == 1)
                                $p_price = $p_price / 100;

                            $p_data = array(
                                'rowid' => $rowid,
                                'qty' => $qty,
                                'price' => $p_price
                            );

                            $this->cart->update($p_data);
                        }
                    }
                }
            }
            return $firstcart;
        }
    }

    public function div2clone() {
        if ($this->input->post('clone_no') && $this->input->post('clone_word')) {
            $data['num'] = $this->input->post('clone_no');

            $data['num_word'] = inWord($this->input->post('clone_no'));

            $where_events = array('type' => 'event_type', 'status' => 1);
            $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

            $where_facilities = array('type' => 'facilities', 'status' => 1);
            $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

            $where_features = array('type' => 'features', 'status' => 1);
            $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);
            $data['img_id'] = 5 + (int) $this->input->post('clone_no');
            echo $this->load->view('venue/another_space', $data, true);
        }
    }

    public function save_profile() {
        $this->load->helper('email_template_helper');
        if ($this->input->post()) {
            $user_id = $this->session->userdata('user_id');


            $data = $this->input->post();
            if ($data['free'] == 1) {
                $cart_data = 'free';
            } else {
                $cart_data = serialize($this->cart->contents());
            }

            $total_addional_area = 0;
            $total_addional_space = 0;
            $cart_content = $this->cart->contents();
            if (!empty($cart_content)) {
                foreach ($cart_content as $crt) {
                    if ($crt['id'] == 3) {
                        $total_addional_area = $crt['qty'];
                    } elseif ($crt['id'] == 4) {
                        $total_addional_space = $crt['qty'];
                    }
                }
            }

            $today = date('Y-m-d');

            $plan = 1;
            if ($this->input->post('plan1')) {
                $plan = $data['plan1'];
            }



            $where_pro = array('pro_id' => $plan);
            $get_price = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_pro);

            $validity_type = $get_price[0]->pro_pay_type;

            $valid_upto = date("Y-m-d", strtotime("+1 $validity_type", strtotime($today)));
            $fc_data = array('fc_user' => $user_id, 'fc_business_name' => $data['venue_business_name'], 'fc_council' => $data['venue_council'], 'fc_state' => $data['venue_state'], 'fc_suburb' => $data['venue_suburb'], 'fc_street' => $data['venue_street'], 'fc_postcode' => $data['venue_postcode'], 'fc_country' => $data['venue_country'], 'fc_lat' => $data['venue_lat'], 'fc_lng' => $data['venue_lng'], 'fc_abn' => $data['venue_abn'], 'fc_contact_name' => $data['venue_contact_name'], 'fc_phone_no' => $data['venue_phone_no'], 'fc_website' => $data['venue_website'], 'fc_email' => $data['venue_email'], 'fc_overview' => $data['venue_overview'], 'fc_details' => $data['venue_details'], 'fc_min_guest' => $data['venue_min_guest'], 'fc_max_guest' => $data['venue_max_guest'], 'fc_cart_data' => $cart_data, 'fc_type' => 1, 'fc_status' => 5, 'fc_free' => $data['free'], 'fc_created_date' => date('Y-m-d H:i:s'), 'fc_modified_on' => date('Y-m-d H:i:s'));

            $listing_image = UploadFcListingPicture();
            if (!empty($listing_image)) {
                $fc_data['fc_listing_picture'] = $listing_image;
            }

            if ($this->input->post('venue_pricing')) {
                $fc_data['fc_pricing'] = implode(',', $data['venue_pricing']);
            }

            if ($data['fc_id'] != '') {
                $fc_id = encrypt_decrypt('decrypt', $data['fc_id']);
                $this->basic_model->update_records('function_catering', $fc_data, array('fc_id' => $fc_id));
            } else {
                $fc_id = $this->basic_model->insert_records('function_catering', $fc_data);
            }

            if ($fc_id > 0) {
                // Adding venue details
                $venue_details = array();

                if ($this->input->post('venue_events')) {
                    $venue_details['vd_events'] = implode(',', $data['venue_events']);
                }

                if ($this->input->post('venue_facilities')) {
                    $venue_details['vd_facilities'] = implode(',', $data['venue_facilities']);
                }

                if ($this->input->post('venue_features')) {
                    $venue_details['vd_features'] = implode(',', $data['venue_features']);
                }

                if (!empty($venue_details)) {
                    $venue_details['vd_fc_id'] = $fc_id;
                    $check_venue_details = $this->basic_model->get_record_where('venue_details', '', array('vd_fc_id' => $fc_id));
                    if (!empty($check_venue_details)) {
                        $this->basic_model->update_records('venue_details', $venue_details, array('vd_fc_id' => $fc_id));
                    } else {
                        $this->basic_model->insert_records('venue_details', $venue_details);
                    }
                }

                if ($data['free'] != 1) {
                    // Adding addtional area
                    $this->save_addional_area($data, $fc_id, $total_addional_area);

                    // Adding additional spaces
                    $this->save_addional_space($data, $fc_id, $total_addional_space);
                } else {
                    $this->basic_model->delete_records('additional_area', array('area_venue' => $fc_id));
                    $this->basic_model->delete_records('venue_spaces', array('space_venue' => $fc_id));
                }

                // Multi venue images
                $img_count = 5;
                $check_existing_img = $this->basic_model->get_record_where('fc_images', '', array('fc_id' => $fc_id));
                $ic = 1;
                if (!empty($check_existing_img)) {
                    // Multi venue images
                    $this->load->library('upload');

                    foreach ($check_existing_img as $img_key) {
                        $croped_image_name = 'dimesion_image_' . ($ic);
                        $image_url = false;
                        if ($this->input->post($croped_image_name) != '0') {
                            $image_url = $this->input->post($croped_image_name);
                            if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                                rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                            }
                        } elseif ($_FILES["fc_img_name$ic"]['size'] != 0) {
                            $this->upload->initialize($this->set_upload_options());
                            if (!$this->upload->do_upload("fc_img_name$ic")) {
                                $error = $this->upload->display_errors();
                            } else {
                                $dataInfo[] = $this->upload->data();
                                $i_data = $this->upload->data();
                                $image_url = $i_data['file_name'];
                            }
                        }

                        if (!empty($image_url)) {
                            $image_update = array('fc_img_name' => $image_url, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                            $where_img = array('fc_img_id' => $img_key->fc_img_id);
                            $this->basic_model->update_records('fc_images', $image_update, $where_img);
                        }

                        $ic++;
                        $img_count--;
                    }
                }

                if ($img_count > 0) {
                    // Multi venue images
                    $this->load->library('upload');
                    $image_data = array();
                    for ($ic; $ic <= 5; $ic++) {
                        $croped_image_name = 'dimesion_image_' . ($ic);
                        if ($this->input->post($croped_image_name) != '0') {
                            $image_url = $this->input->post($croped_image_name);
                            if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                                rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                            }
                            $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $fc_id, 'fc_img_modified_on' => date('Y-m-d h:i:s'));
                        } else if ($_FILES["fc_img_name$ic"]['size'] != 0) {
                            $this->upload->initialize($this->set_upload_options());
                            if (!$this->upload->do_upload("fc_img_name$ic")) {
                                $error = $this->upload->display_errors();
                            } else {
                                $dataInfo[] = $this->upload->data();
                                $i_data = $this->upload->data();
                                $image_url = $i_data['file_name'];
                                $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $fc_id, 'fc_img_modified_on' => date('Y-m-d h:i:s'));
                            }
                        }
                    }

                    if (!empty($image_data)) {
                        $this->basic_model->insert_records('fc_images', $image_data, true);
                    }
                }


                if ($data['need_photography'] > 0) {
                    $need_ph_data = array('img_req_fc_id' => $fc_id);
                    $this->basic_model->delete_records('image_request', '', $need_ph_data);
                    $this->basic_model->insert_records('image_request', $need_ph_data);
                } else {
                    $this->basic_model->delete_records('image_request', array('img_req_fc_id' => $fc_id));
                }

                $result = array('status' => true, 'fc_id' => encrypt_decrypt('encrypt', $fc_id));
            } else {
                $result = array('status' => false);
            }
            echo $response = json_encode($result);
        }
    }

    public function get_cart() {
        $cart_content = $this->cart->contents();

        if (!empty($cart_content)) {
            $my_cart = array();
            foreach ($cart_content as $key => $row) {
                $my_cart[$key] = $row['id'];
            }
            array_multisort($my_cart, SORT_ASC, $cart_content);

            $current_cart = array();

            foreach ($cart_content as $key => $value) {
                $pro_id = $value['id'];
                $where_pro = array('pro_id' => $pro_id);
                $get_name = $this->basic_model->get_record_where('products', 'pro_title', $where_pro);

                if ($pro_id == 'voucher_id') {
                    $p_title = 'Applied voucher <a href="javascript:void(0);" onClick="RemoveVoucher();" id="remove_voucher">Remove</a>';
                    $title = $p_title;
                    $current_cart[] = array('name' => $title, 'subtotal' => $value['subtotal'], 'class' => 'voucher_maintain');
                } else {
                    if (!empty($value['options']['days_payment'])) {
                        $fc_id = $this->session->userdata('fc_id');
                        $upto_valid = $this->basic_model->get_record_where('function_catering', 'fc_valid_upto', $where_fc = array('fc_id' => $fc_id));
                        $p_title = $get_name[0]->pro_title;
                        $p_title = $p_title . ' (' . date("d M Y") . ' - ' . date("d M Y", strtotime($upto_valid[0]->fc_valid_upto)) . ')';
                    } else {
                        $p_title = strip_tags($get_name[0]->pro_title);
                    }
                    $title = $p_title;
                    $current_cart[] = array('name' => $title, 'subtotal' => $value['subtotal'], 'class' => 'plan_maintain');
                }
            }

            $cart_total = $this->cart->total();

            echo json_encode(array('status' => TRUE, 'cart' => $current_cart, 'total' => $cart_total));
        } else {
            echo json_encode(array('status' => FALSE));
        }
    }

    public function remove_cartitem() {
        $cart_content = $this->cart->contents();

        if ($this->input->post('packid')) {
            $row_id = 0;
            $product_id = $this->input->post('packid');

            if (!empty($cart_content)) {
                foreach ($cart_content as $value) {
                    if ($value['id'] == $product_id || $value['id'] == 'S_4') {
                        $row_id = $value['rowid'];
                        $data = array(
                            'rowid' => $row_id,
                            'qty' => $value['qty'] - 1
                        );

                        $this->cart->update($data);
                    }
                }
            }
        }

        $cart_content = $this->cart->contents();

        $cart_total = $this->cart->total();

        echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'cart_total' => $cart_total));
    }

    public function save_venue() {
        require APPPATH . 'libraries/Stripe/lib/Stripe.php';
        $this->load->helper('email_template_helper');
        if ($this->input->post()) {
            $user_id = $this->session->userdata('user_id');
            $data = $this->input->post();
            if ($data['free'] == 1) {
                $cart_data = 'free';
            } else {
                $cart_data = json_encode($this->cart->contents());
            }

            // here check cart content not empty
            if (count($this->cart->contents()) > 0) {
                $voucher_log_id = '';
                $voucher_id = '';
                $payment_data = array();
                if (!empty($data['voucher_code'])) {
                    $result = checkVoucherHelper($data['voucher_code']);

                    if ($result['status']) {
                        $voucher_id = $result['voucher_id'];
                        $redeemed_ammount = abs($result['redeemed_ammount']); // value is redeem ammount
                        $voucher_value = abs($result['voucher_value']);
                        $voucher_log_id = insert_voucher_log($user_id, $data['voucher_code'], $voucher_value, $redeemed_ammount);
                    }
                }

                // here get number of area and number of spaces
                $total_addional_space = 0;
                $total_addional_area = 0;
                $total_ammount = 0;
                $cart_content = $this->cart->contents();

                if (!empty($cart_content)) {
                    foreach ($cart_content as $crt) {
                        if ($crt['id'] == 3) {
                            $total_addional_area = $crt['qty'];
                        } elseif ($crt['id'] == 4) {
                            $total_addional_space = $crt['qty'];
                        }

                        if (($crt['subtotal']) > 0) {
                            $total_ammount += $crt['subtotal'];
                        }
                    }
                }

                $cart_total = $this->cart->total();
                //if aaplied voucher greather or equal to total ammount then skip payment method
                // here payment method 1 mean strip payment method selected
                $data['payment_method'] = (!empty($data['payment_method'])) ? $data['payment_method'] : '';
                if ($cart_total > 0 && $data['payment_method'] == 1 && (!empty($data['payment_method']))) {
                    $chargeable_amount = $cart_total * 100;

                    Stripe::setApiKey(STRIPE_PRIVATE_KEY);

                    try {
                        if (!isset($_POST['stripeToken']))
                            throw new Exception("The Stripe Token was not generated correctly.");

                        $charge = Stripe_Charge::create(array("amount" => $chargeable_amount,
                                    "currency" => "aud",
                                    "card" => $this->input->post('stripeToken'),
                                    "description" => $this->input->post('venue_email')));

                        $captured = $charge['captured'];
                        $paid = $charge['paid'];
                        $data['id'] = $charge['id'];

                        if ((isset($captured) && $captured == 1) && (isset($paid) && $paid == 1)) {
                            $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => $charge['id'], 'pay_for' => json_encode($this->cart->contents()), 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 1, 'payment_status' => 2, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'pay_created_on' => date('Y-m-d H:i:s'));
                            $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                        } else {
                            throw new Exception("Error in transaction.");
                        }
                    } catch (Exception $e) {
                        $error_msg = $e->getMessage();
                        $this->session->set_flashdata('error_msg', $error_msg);
                        redirect('add_venue');
                        exit();
                    }
                } elseif (!empty($data['payment_method']) == 2 && (!empty($data['payment_method']))) {
                    // here paymetnt method 2 mean pay by account

                    $order_data = json_encode($this->cart->contents());
                    $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => '', 'pay_for' => $order_data, 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 2, 'payment_status' => 1, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'pay_created_on' => date('Y-m-d H:i:s'));
                    $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                    $this->account_details_invoice($order_data, $cart_total, $txn_id);
                } elseif ($cart_total == 0) {

                    $order_data = json_encode($this->cart->contents());
                    $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => '', 'pay_for' => $order_data, 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 3, 'payment_status' => 2, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'pay_created_on' => date('Y-m-d H:i:s'));
                    $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                } else {
                    $this->session->set_flashdata('error_msg', 'No payment method found');
                    redirect('add_venue');
                    exit();
                }
            }


            $today = date('Y-m-d');

            $plan = 1;
            if ($this->input->post('plan1')) {
                $plan = $data['plan1'];
            }

            $where_pro = array('pro_id' => $plan);
            $get_price = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_pro);

            $validity_type = $get_price[0]->pro_pay_type;

            $valid_upto = date("Y-m-d", strtotime("+1 $validity_type", strtotime($today)));
            $business_name = $data['venue_business_name'];
            $business_email = $data['venue_email'];
            $business_number = $data['venue_phone_no'];
            $service_type = $data['free'];

            $fc_data = array('fc_current_plan' => $plan, 'fc_user' => $user_id, 'fc_business_name' => $data['venue_business_name'], 'fc_council' => $data['venue_council'], 'fc_state' => $data['venue_state'], 'fc_suburb' => $data['venue_suburb'], 'fc_street' => $data['venue_street'], 'fc_postcode' => $data['venue_postcode'], 'fc_country' => $data['venue_country'], 'fc_lat' => $data['venue_lat'], 'fc_lng' => $data['venue_lng'], 'fc_abn' => $data['venue_abn'], 'fc_contact_name' => $data['venue_contact_name'], 'fc_phone_no' => $data['venue_phone_no'], 'fc_website' => $data['venue_website'], 'fc_email' => $data['venue_email'], 'fc_overview' => $data['venue_overview'], 'fc_details' => $data['venue_details'], 'fc_min_guest' => $data['venue_min_guest'], 'fc_max_guest' => $data['venue_max_guest'], 'fc_cart_data' => $cart_data, 'fc_type' => 1, 'fc_status' => 0, 'fc_free' => $data['free'], 'fc_valid_upto' => $valid_upto, 'fc_modified_on' => date('Y-m-d H:i:s'), 'fc_created_date' => date('Y-m-d H:i:s'));

            // here upload fetured images
            $listing_image = UploadFcListingPicture();
            if (!empty($listing_image)) {
                $fc_data['fc_listing_picture'] = $listing_image;
            }

            if ($this->input->post('venue_pricing')) {
                $fc_data['fc_pricing'] = implode(',', $data['venue_pricing']);
            }

            // draft saved of not if saved then update data other wise else condtion insert data
            if ($data['fc_id'] != '') {
                $fc_id = encrypt_decrypt('decrypt', $data['fc_id']);
                $this->basic_model->update_records('function_catering', $fc_data, array('fc_id' => $fc_id));
            } else {
                $fc_id = $this->basic_model->insert_records('function_catering', $fc_data);
            }

            if (!empty($voucher_log_id) && $fc_id) {
                $this->basic_model->update_records('voucher_logs', array('fc_id' => $fc_id), array('v_log_id' => $voucher_log_id));
            }
            $requeste_date = $this->basic_model->get_record_where('function_catering', array('fc_created_date'), array('fc_id' => $fc_id));

            $requested_date = $requeste_date[0]->fc_created_date;

            if ($fc_id > 0) {
                if (!empty($txn_id)) {
                    $where_tx = array('pay_id' => $txn_id);
                    $update_txn_data = array('pay_fc_id' => $fc_id);
                    $this->basic_model->update_records('payment_details', $update_txn_data, $where_tx);
                }

                if ($data['free'] != 1) {
                    // Adding addtional area
                    $this->save_addional_area($data, $fc_id, $total_addional_area);

                    // Adding additional spaces
                    $this->save_addional_space($data, $fc_id, $total_addional_space);
                } else {
                    $this->basic_model->delete_records('additional_area', array('area_venue' => $fc_id));
                    $this->basic_model->delete_records('venue_spaces', array('space_venue' => $fc_id));
                }

                $this->cart->destroy();

                $user_data = $this->basic_model->get_record_where('users', '', array('user_id' => $user_id));
                $name = $this->session->userdata('user_firstname') . ' ' . $this->session->userdata('user_lastname');


                $catering_mail_data = array('fc_id' => $fc_id, 'type' => 'venue', 'name' => $name, 'email' => $this->session->userdata('user_email'), 'business_name' => $business_name, 'url' => base_url() . 'web/single_venue/' . (encrypt_decrypt('encrypt', $fc_id)), 'telephone' => $user_data[0]->user_phone_no, 'business_email' => $business_email, 'business_number' => $business_number, 'service_type' => (($service_type == 1) ? 'free' : 'paid'), 'requested_date' => $requested_date, 'type' => 'Venue');

                // pending payment mail send
                pending_fc_mail_to_user($catering_mail_data);
                // notify to admin new venue crated
                alert_admin_mail($catering_mail_data);

                $this->session->set_flashdata('success', 'Venue Create successfully');
                redirect('my_venues');
            } else {
                $this->session->set_flashdata('error', 'Error in insertion');
                redirect('my_venues');
            }
        } else {
            redirect('add_venue');
        }
    }

    public function set_upload_options() {
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/fc_images/';
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = '0';
        $config['overwrite'] = FALSE;

        return $config;
    }

    /* public function my_venues() {
      $data = array();

      $user_id = $this->session->userdata('user_id');

      $where_user = array('user_id' => $user_id);
      $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

      $where = array('fc_user' => $user_id, 'fc_type' => 1, 'function_catering.fc_is_deleted' => 0, 'function_catering.fc_status' => 1);

      $venues = $this->basic_model->get_record_where('function_catering', array('fc_id', 'fc_business_name', 'fc_overview', 'fc_listing_picture', 'fc_valid_upto', 'fc_free'), $where);
      // echo '<pre>';
      // print_r( $venues);die;
      // echo $this->db->last_query();die;


      if (!empty($venues)) {
      foreach ($venues as $key => $value) {
      $where_venue = array('space_venue' => $value->fc_id, 'space_status' => 0);
      $spaces = $this->basic_model->get_record_where('venue_spaces', 'space_id, space_name ,space_image,space_details', $where_venue);
      // print_r($spaces);die;
      // echo $this->db->last_query();die;

      if (!empty($spaces))
      $venues[$key]->spaces = $spaces;
      }

      $data['venues'] = $venues;
      }
      $data['title'] = 'My venues';
      $data['wish_list'] = home_page_data();

      $where = array('fc_user' => $user_id,'function_catering.fc_is_deleted' => 0, 'function_catering.fc_status' => 5);

      $my_draft = $this->basic_model->get_record_where('function_catering', 'fc_id,fc_type, fc_business_name, fc_overview, fc_listing_picture',$where);
      $data['my_draft'] = $my_draft;
      $this->load->view('header', $data);
      $this->load->view('menu', $data);
      $this->load->view('venue/my_venues', $data);
      $this->load->view('footer');
      } */

    public function my_venues() {
        $data = array();

        $user_id = $this->session->userdata('user_id');

        $where_user = array('user_id' => $user_id);
        $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

        $where = array('fc_user' => $user_id, 'fc_type' => 1, 'function_catering.fc_is_deleted' => 0, 'function_catering.fc_status' => 1);
        $venues = $this->basic_model->get_record_where('function_catering', array('fc_id', 'fc_business_name', 'fc_overview', 'fc_listing_picture', 'fc_valid_upto', 'fc_free'), $where);
        if (!empty($venues)) {
            foreach ($venues as $key => $value) {
                $where_venue = array('space_venue' => $value->fc_id, 'space_status' => 0);
                $spaces = $this->basic_model->get_record_where('venue_spaces', 'space_id, space_name ,space_image,space_details', $where_venue);
                if (!empty($spaces))
                    $venues[$key]->spaces = $spaces;
            }
            $data['venues'] = $venues;
        }
        $data['title'] = 'My venues';
        $data['wish_list'] = home_page_data();
		
		/* Get Approval Pending venue list*/
		
		$where = array('fc_user' => $user_id, 'fc_type' => 1, 'function_catering.fc_is_deleted' => 0, 'function_catering.fc_status' => 0);
        $venues = $this->basic_model->get_record_where('function_catering', array('fc_id', 'fc_business_name', 'fc_overview', 'fc_listing_picture', 'fc_valid_upto', 'fc_free'), $where);
        if (!empty($venues)) {
            foreach ($venues as $key => $value) {
                $where_venue = array('space_venue' => $value->fc_id, 'space_status' => 0);
                $spaces = $this->basic_model->get_record_where('venue_spaces', 'space_id, space_name ,space_image,space_details', $where_venue);
                if (!empty($spaces))
                    $venues[$key]->spaces = $spaces;
            }
            $data['pending'] = $venues;
        }
		
		
		
		
        $where = array('fc_user' => $user_id, 'function_catering.fc_is_deleted' => 0, 'function_catering.fc_status' => 5, 'fc_type' => 1);

        $my_draft = $this->basic_model->get_record_where('function_catering', 'fc_id,fc_type, fc_business_name, fc_overview, fc_listing_picture', $where);
        //echo $this->db->last_query();
        $data['my_draft'] = $my_draft;
        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('venue/my_venues', $data);
        $this->load->view('footer');
    }

//venue delete_records

    public function remove_venue() {

        $venue_id = encrypt_decrypt('decrypt', $_POST['venue_id']);
        $user_id = $this->session->userdata('user_id');
        $where = array('fc_id' => $venue_id, 'fc_user' => $user_id);

        $data_delete = array('fc_is_deleted' => 1);
        $responce = $this->basic_model->update_records('function_catering', $data_delete, $where);
        if ($responce) {
            $output = array("status_code" => "success", "status" => "s");
            echo json_encode($output);
        } else {
            $output = array("status_code" => "Faield", "status" => "f");
            echo json_encode($output);
        }
        //echo $this->db->last_query();
    }

    function space_venue() {

        $data = array();
        $user_id = $this->session->userdata('user_id');
        $where_user = array('user_id' => $user_id);
        $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);
        $where = array('fc_user' => $user_id, 'fc_type' => 1, 'function_catering.fc_is_deleted' => 0, 'function_catering.fc_status' => 1);
        $venues = $this->basic_model->get_record_where('function_catering', array('fc_id', 'fc_business_name', 'fc_overview', 'fc_listing_picture', 'fc_valid_upto', 'fc_free'), $where);
        if (!empty($venues)) {
            foreach ($venues as $key => $value) {
                $where_venue = array('space_venue' => $value->fc_id, 'space_status' => 0);
                $spaces = $this->basic_model->get_record_where('venue_spaces', 'space_id, space_name ,space_image,space_details', $where_venue);
                if (!empty($spaces))
                    $venues[$key]->spaces = $spaces;
            }

            $data['venues'] = $venues;
        }
        $data['title'] = 'Space venues';
        $data['wish_list'] = home_page_data();

        $where = array('fc_user' => $user_id, 'function_catering.fc_is_deleted' => 0, 'function_catering.fc_status' => 5);

        $my_draft = $this->basic_model->get_record_where('function_catering', 'fc_id,fc_type, fc_business_name, fc_overview, fc_listing_picture', $where);

        $data['space_id'] = $this->uri->segment(2);

        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('venue/space_venues', $data);
        $this->load->view('footer');
    }

//venue space add
    public function spaces() {

        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);
        $data['space_id'] = $this->uri->segment(3);

        $where_events = array('type' => 'event_type', 'status' => 1);
        $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

        $where_facilities = array('type' => 'facilities', 'status' => 1);
        $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

        $where_features = array('type' => 'features', 'status' => 1);
        $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);
        $data['img_id'] = 5 + (int) $this->input->post('clone_no');
        //echo "<pre>";print_r($data);	
        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('venue/spaces', $data);
        $this->load->view('footer');
    }

//venue space add using ajax
    public function space_add_venue() {
        $data = $this->input->post();
        //print_r($data['space_events']);
        $space_events = $data['space_events'];
        $space_facilities = $data['space_facilities'];
        $space_features = $data['space_features'];
        $space_events_id = '';
        $space_facilities_id = '';
        $space_features_id = '';
        if (!empty($space_events)) {
            foreach ($space_events as $val) {
                $space_events_id .= $val . ' ,';
            }
        }
        if (!empty($space_facilities)) {
            foreach ($space_facilities as $val) {
                $space_facilities_id .= $val . ' ,';
            }
        }
        if (!empty($space_features)) {
            foreach ($space_features as $val) {
                $space_features_id .= $val . ' ,';
            }
        }
        $space_events_id = rtrim($space_events_id, ",");
        $space_facilities_id = rtrim($space_facilities_id, ",");
        $space_features_id = rtrim($space_features_id, ",");

        $all_data = array();
        $all_data['space_venue'] = $data['space_id'];
        $all_data['space_name'] = $data['space_name'];
        $all_data['space_min_guest'] = $data['space_min_guest'];
        $all_data['space_max_guest'] = $data['space_max_guest'];
        $all_data['space_details'] = $data['space_details'];
        $all_data['space_status'] = 0;
        $all_data['space_image'] = !empty($data['fc_image']) ? $data['fc_image'] : $data['dimesion_image'];
        $all_data['space_events'] = $space_events_id;
        $all_data['space_facilities'] = $space_facilities_id;
        $all_data['space_features'] = $space_features_id;

        //print_r($data);
        $result = $this->basic_model->insert_records('venue_spaces', $all_data, $multiple = FALSE);
    }

    function single_space() {
//        $this->input->post('space_id') = 1;
        if ($this->input->post('space_id')) {
            $space_id = $this->input->post('space_id');

            $where_venue = array('space_id' => $space_id);
            $space = $this->basic_model->get_record_where('venue_spaces', $colown = '', $where_venue);
            $spaces = $space[0];


            if ($spaces->space_events) {
                $where = 'type="event_type" and id IN (' . $spaces->space_events . ')';
                $events = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $spaces->space_events = $events;
            }

            if ($spaces->space_facilities) {
                $where = 'type="facilities" and id IN (' . $spaces->space_facilities . ')';
                $facilities = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $spaces->space_facilities = $facilities;
            }

            if ($spaces->space_features) {
                $where = 'type="features" and id IN (' . $spaces->space_features . ')';
                $features = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $spaces->space_features = $features;
            }

            echo json_encode($spaces);
        }
    }

    function venue_thank_you() {
        $this->load->view('header');
        $this->load->view('menu');
        $this->load->view('user/bad_exp');
        $this->load->view('footer');
    }

    function query_form_submit() {

        if ($this->input->post()) {
            $query_data = $this->input->post();
            $query_data['fq_user'] = $this->session->userdata('user_id');
            $result = $this->basic_model->insert_records('fnc_queries', $query_data, $multiple = FALSE);
            if ($result > 0) {
                redirect('venue_thank_you');
            }
        } else {
            redirect('my_venues');
        }
    }

    function save_addional_area($data, $fc_id, $total_addional_area) {
        $today = date('Y-m-d');
        $addition_area = array();
        if (array_key_exists("add_arr", $data)) { // here making array of addional area data
            $i = 1;
            foreach ($data['add_arr'] as $key => $value) {
                if (!empty($value) && $i <= $total_addional_area) {
                    $addition_area[] = array('area_venue' => $fc_id, 'area_name' => $value, 'area_lat' => $data['add_arr_lat'][$key], 'area_lng' => $data['add_arr_lng'][$key], 'area_created_on' => $today, 'area_valid_upto' => $today); // modified date
                }
                $i++;
            }
        }

        if (!empty($addition_area)) { // here get all old addional area data 
            $area_count = count($addition_area);
            $old_addition_area = $this->basic_model->get_record_where('additional_area', '', array('area_venue' => $fc_id));
            $ext_area = count($old_addition_area);

            $main_count = 0;
            if ($ext_area > 0) { // here update all old addional area data 
                foreach ($old_addition_area as $area) {
                    $where = array('area_id' => $area->area_id);
                    if ($area_count != 0) {
                        $this->basic_model->update_records('additional_area', $addition_area[$main_count], $where);
                        $area_count--;
                        $main_count++;
                    } else {
                        $this->basic_model->delete_records('additional_area', $where);
                    }
                }
            }

            if ($area_count > 0) {  // here remaning new addional area data insert
                for ($i = 0; $i <= ($area_count - 1); $i++) {
                    $this->basic_model->insert_records('additional_area', $addition_area[$main_count]);
                    $main_count++;
                }
            }
        } else {
            $this->basic_model->delete_records('additional_area', array('area_venue' => $fc_id));
        }
    }

    function save_addional_space($data, $fc_id, $total_addional_space) {
        $today = date('Y-m-d');
        if ($total_addional_space > 0) {
            $t_spaces = $data['total_another'];
            $additional_spaces = array();

            $crop_count = 5;
            for ($i = 1; $i <= $t_spaces; $i++) {
                $spaces = array('space_venue' => $fc_id, 'space_name' => $data["space_name$i"], 'space_min_guest' => $data["space_min_guest$i"], 'space_max_guest' => $data["space_max_guest$i"], 'space_details' => $data["space_details$i"]);

                if (!empty($data["space_events$i"])) {
                    $spaces['space_events'] = implode(',', $data["space_events$i"]);
                }

                if (!empty($data["space_facilities$i"])) {
                    $spaces['space_facilities'] = implode(',', $data["space_facilities$i"]);
                }

                if (!empty($data["space_features$i"])) {
                    $spaces['space_features'] = implode(',', $data["space_features$i"]);
                }

                $croped_image_name = 'dimesion_image_' . ($crop_count + $i);
                if ($this->input->post($croped_image_name) != '0') {
                    $image_url = $this->input->post($croped_image_name);
                    if (file_exists("uploads/venue_spaces/temp/" . $image_url)) {
                        rename("uploads/venue_spaces/temp/" . $image_url, "uploads/venue_spaces/" . $image_url);
                    }
                    $spaces['space_image'] = $image_url;
                } elseif ($_FILES["space_image$i"]['size'] != 0) {
                    $s_config['upload_path'] = './uploads/venue_spaces/';
                    $s_config['allowed_types'] = 'jpeg|jpg|png';

                    $this->load->library('upload', $s_config);
                    $this->upload->initialize($s_config);
                    if (!$this->upload->do_upload("space_image$i")) {
                        $error = $this->upload->display_errors();
                    } else {
                        $i_data = $this->upload->data();
                        $spaces['space_image'] = $i_data['file_name'];
                    }
                }

                $additional_spaces[] = $spaces;
            }

            if (!empty($additional_spaces)) {
                $space_count = count($additional_spaces);
                $old_venue_space = $this->basic_model->get_record_where('venue_spaces', '', array('space_venue' => $fc_id));
                $ext_space_count = count($old_venue_space);
                $main_space_count = 0;

                if ($ext_space_count > 0) {
                    foreach ($old_venue_space as $space) {
                        $where = array('space_id' => $space->space_id);
                        if ($space_count != 0) {
                            $this->basic_model->update_records('venue_spaces', $additional_spaces[$main_space_count], $where);
                            $space_count--;
                            $main_space_count++;
                        } else {
                            $this->basic_model->delete_records('venue_spaces', $where);
                        }
                    }
                }

                if ($space_count > 0) {
                    for ($i = 1; $i <= $space_count; $i++) {
                        $this->basic_model->insert_records('venue_spaces', $additional_spaces[$main_space_count]);
                        $main_space_count++;
                    }
                }
            } else {
                $this->basic_model->delete_records('venue_spaces', array('space_venue' => $fc_id));
            }
        } else {
            $this->basic_model->delete_records('venue_spaces', array('space_venue' => $fc_id));
        }
    }

    function add_to_wishlist() {
        if ($this->input->post('v_id')) {
            $data['w_venue'] = $this->input->post('v_id');
            $data['w_user'] = $this->session->userdata('user_id');
            $already_added = $this->basic_model->get_record_where('wish_list', $column = '', $data);
            if (!empty($already_added)) {
                echo 'already';
            } else {
                $result = $this->basic_model->insert_records('wish_list', $data, $multiple = FALSE);
                echo 'success';
            }
        }
    }

    function send_to_friend() {
        $this->load->helper('email_template_helper');
        if ($this->input->post()) {
            $mail_data = $this->input->post();
            $response = send_to_friend_mail($mail_data);
            if ($response > 0) {
                echo 'success';
            } else {
                echo 'false';
            }
        }
    }

    public function edit_venue($venueID = 0) {
        require APPPATH . 'libraries/Stripe/lib/Stripe.php';
        $user_id = $this->session->userdata('user_id');
        $data['title'] = 'Edit venue';
        if ($this->input->post()) {
            $fc_id = $this->session->userdata('fc_id');
            $payment_status = '';
            $data = $this->input->post();
            $venue_id = encrypt_decrypt('decrypt', $this->input->post('venue'));

            $voucher_log_id = '';
            $voucher_id = '';
            if (!empty($data['voucher_code'])) {
                $result = checkVoucherHelper($data['voucher_code']);

                if ($result['status']) {
                    $voucher_id = $result['voucher_id'];
                    $redeemed_ammount = abs($result['redeemed_ammount']); // value is redeem ammount
                    $voucher_value = abs($result['voucher_value']);
                    $voucher_log_id = insert_voucher_log($user_id, $data['voucher_code'], $voucher_value, $redeemed_ammount, $fc_id);
                }
            }

            if (count($this->cart->contents()) > 0) {

                $plan_product_id = 0;
                $total_addional_area = 0;
                $total_addional_space = 0;
                $total_ammount = 0;
                $cart_item = $this->cart->contents();

                foreach ($cart_item as $cart_val) {
                    if ($cart_val['id'] == 1 || $cart_val['id'] == 2) {
                        $plan_product_id = $cart_val['id'];
                    } elseif ($cart_val['id'] == 3) {
                        if (array_key_exists('options', $cart_val)) { // check variation in product exixst
                            if ($cart_val['options']['new_added'] == 1) {
                                $total_addional_area = $cart_val['qty'];
                            }
                        }
                    } elseif ($cart_val['id'] == 4) {
                        if (array_key_exists('options', $cart_val)) { // check variation in product exixst
                            if ($cart_val['options']['new_added'] == 1) {
                                $total_addional_space = $cart_val['qty'];
                            }
                        }
                    }

                    if ($cart_val['subtotal'] > 0) {
                        $total_ammount += $cart_val['subtotal'];
                    }
                }


                $cart_total = $this->cart->total();
                $data['payment_method'] = (!empty($data['payment_method'])) ? $data['payment_method'] : '';
                if ($cart_total > 0 && $data['payment_method'] == 1 && (!empty($data['payment_method']))) {
                    $cart_data = json_encode($this->cart->contents());
                    $chargeable_amount = $cart_total * 100;

                    Stripe::setApiKey(STRIPE_PRIVATE_KEY);

                    try {
                        if (!isset($_POST['stripeToken']))
                            throw new Exception("The Stripe Token was not generated correctly.");

                        $charge = Stripe_Charge::create(array("amount" => $chargeable_amount,
                                    "currency" => "aud",
                                    "card" => $this->input->post('stripeToken'),
                                    "description" => $this->input->post('venue_email')));

                        $captured = $charge['captured'];
                        $paid = $charge['paid'];
                        $data['id'] = $charge['id'];

                        if ((isset($captured) && $captured == 1) && (isset($paid) && $paid == 1)) {
                            $payment_status = 'pending';
                            $order_data = json_encode($this->cart->contents());

                            $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => $charge['id'], 'pay_for' => json_encode($this->cart->contents()), 'pay_fc_id' => $fc_id, 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 1, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'payment_mode' => 1, 'payment_status' => 2, 'pay_created_on' => date('Y-m-d H:i:s'));
                            $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                            $this->account_update_invoice($order_data, $cart_total, $txn_id);
                            $payment_status = 1;
                        } else {
                            throw new Exception("Error in transaction.");
                        }
                    } catch (Exception $e) {
                        $error_msg = $e->getMessage();
                        $this->session->set_flashdata('error_msg', $error_msg);
                        redirect('my_venues');
                        exit();
                    }
                } elseif ($data['payment_method'] == 2 && (!empty($data['payment_method']))) { // here paymetnt method 2 mean pay by account
                    $payment_status = 'pending';
                    $order_data = json_encode($this->cart->contents());
                    $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => '', 'pay_for' => $order_data, 'pay_fc_id' => $fc_id, 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 2, 'payment_status' => 1, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'payment_mode' => 1, 'pay_created_on' => date('Y-m-d H:i:s'));
                    $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                    $this->account_details_invoice($order_data, $cart_total, $txn_id);
                } elseif ($cart_total == 0) {
                    $payment_status = 1; // if voucher grether then cart total then no payment required
                    $order_data = json_encode($this->cart->contents());
                    $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => '', 'pay_for' => $order_data, 'pay_fc_id' => $fc_id, 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 3, 'payment_status' => 2, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'payment_mode' => 1, 'pay_created_on' => date('Y-m-d H:i:s'));
                    $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                } else {
                    $this->session->set_flashdata('error_msg', 'No payment method found');
                    redirect('my_venues');
                    exit();
                }


                if ($payment_status or $payment_status == 'pending') {

                    //plan update code start
                    // if payment is pending then update plan will be update by admin when verified payment by admin
                    if ($plan_product_id > 0 && $payment_status == 1) {
                        $where_fc = array('fc_id' => $fc_id, 'fc_user' => $user_id);
                        $catering_data = $this->basic_model->get_record_where('function_catering', 'fc_valid_upto', $where_fc);
                        $old_expiry_date = $catering_data[0]->fc_valid_upto;

                        if (strtotime($old_expiry_date) < strtotime(date('Y-m-d'))) {
                            $old_expiry_date = date('Y-m-d');
                        }

                        $where_pro = array('pro_id' => $plan_product_id);
                        $get_price = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_pro);
                        $validity_type = $get_price[0]->pro_pay_type;
                        $valid_upto = date("Y-m-d", strtotime("+1 $validity_type", strtotime($old_expiry_date)));
                        $this->basic_model->update_records('function_catering', array('fc_valid_upto' => $valid_upto, 'fc_free' => 0, 'fc_current_plan' => $plan_product_id), $where_fc);
                    }

                    /* --------addional space------------- */
                    // if payment is pending then add adional space using pending payment status
                    $t_spaces = $total_addional_space;
                    $additional_spaces = array();
                    $crop_count = 5;
                    if ($t_spaces > 0) {
                        for ($i = 1; $i <= $t_spaces; $i++) {
                            $spaces = array('space_venue' => $fc_id, 'space_name' => $data["space_name$i"], 'space_min_guest' => $data["space_min_guest$i"], 'space_max_guest' => $data["space_max_guest$i"], 'space_details' => $data["space_details$i"], 'space_events' => '', 'space_facilities' => '', 'space_features' => '', 'space_image' => '');

                            if (!empty($data["space_events$i"])) {
                                $spaces['space_events'] = implode(',', $data["space_events$i"]);
                            }

                            if (!empty($data["space_facilities$i"])) {
                                $spaces['space_facilities'] = implode(',', $data["space_facilities$i"]);
                            }

                            if (!empty($data["space_features$i"])) {
                                $spaces['space_features'] = implode(',', $data["space_features$i"]);
                            }

                            $croped_image_name = 'dimesion_image_' . ($crop_count + $i);
                            if ($this->input->post($croped_image_name) != '0') {
                                $image_url = $this->input->post($croped_image_name);
                                $spaces['space_image'] = $image_url;
                                if (file_exists("uploads/venue_spaces/temp/" . $image_url)) {
                                    rename("uploads/venue_spaces/temp/" . $image_url, "uploads/venue_spaces/" . $image_url);
                                }
                            } elseif ($_FILES["space_image$i"]['size'] != 0) {
                                $s_config['upload_path'] = './uploads/venue_spaces/';
                                $s_config['allowed_types'] = 'jpeg|jpg|png';
                                $this->load->library('upload', $s_config);

                                $this->upload->initialize($s_config);

                                if (!$this->upload->do_upload("space_image$i")) {
                                    $error = $this->upload->display_errors();
                                } else {
                                    $i_data = $this->upload->data();
                                    $spaces['space_image'] = $i_data['file_name'];
                                }
                            }

                            if ($payment_status == 'pending') {
                                $spaces['space_status'] = 2;
                            }
                            $itemes_ids['spaces'][] = $this->basic_model->insert_records('venue_spaces', $spaces, $multiple = false);
                        }

                        //$this->basic_model->insert_records('venue_spaces', $additional_spaces, $multiple = true);
                    }

                    $today = date('Y-m-d');

                    if (array_key_exists("new_add_arr", $data) && $total_addional_area > 0) {
                        $a = 1;
                        $addition_area = array();
                        foreach ($data['new_add_arr'] as $key => $value) {
                            if ($a > $total_addional_area)
                                break;

                            if (!empty($value)) {

                                $area_details = array('area_venue' => $fc_id, 'area_name' => $value, 'area_lat' => $data['add_arr_lat'][$key], 'area_lng' => $data['add_arr_lng'][$key], 'area_created_on' => $today);

                                if ($payment_status == 'pending') {
                                    $area_details['area_status'] = 2;
                                }

                                $itemes_ids['area'][] = $this->basic_model->insert_records('additional_area', $area_details, $multiple = false);
                            }
                            $a++;
                        }
                        // $this->basic_model->insert_records('additional_area', $addition_area, $multiple = true);
                    }

                    if (!empty($itemes_ids)) {
                        $this->load->helper('stripe_subscription_helper');
                        update_subscription($fc_id);
                        $this->basic_model->update_records('payment_details', array('additional_item_data' => json_encode($itemes_ids)), $where_tx = array('pay_id' => $txn_id));
                    }


                    $this->session->unset_userdata('fc_id');
                    $this->cart->destroy();
                }
            }


            $update_data = array('fc_business_name' => $data['venue_business_name'], 'fc_council' => $data['venue_council'], 'fc_state' => $data['venue_state'], 'fc_suburb' => $data['venue_suburb'], 'fc_street' => $data['venue_street'], 'fc_postcode' => $data['venue_postcode'], 'fc_country' => $data['venue_country'], 'fc_lat' => $data['lat'], 'fc_lng' => $data['lng'], 'fc_abn' => $data['venue_abn'], 'fc_contact_name' => $data['venue_contact_name'], 'fc_phone_no' => $data['venue_phone_no'], 'fc_website' => $data['venue_website'], 'fc_email' => $data['venue_email'], 'fc_overview' => $data['venue_overview'], 'fc_details' => $data['venue_details'], 'fc_min_guest' => $data['venue_min_guest'], 'fc_max_guest' => $data['venue_max_guest']);

            if ($this->input->post('venue_pricing')) {
                $update_data['fc_pricing'] = implode(',', $data['venue_pricing']);
            } else {
                $update_data['fc_pricing'] = '';
            }

            $where = array('fc_id' => $venue_id, 'fc_user' => $user_id);

            $listing_image = UploadFcListingPicture();
            if (!empty($listing_image)) {
                $update_data['fc_listing_picture'] = $listing_image;
            }
            // unlink_image("main",$venue_id);


            $this->basic_model->update_records('function_catering', $update_data, $where);

            $venue_details = array();

            if ($this->input->post('venue_events')) {
                $venue_details['vd_events'] = implode(',', $data['venue_events']);
            } else {
                $venue_details['vd_events'] = '';
            }

            if ($this->input->post('venue_facilities')) {
                $venue_details['vd_facilities'] = implode(',', $data['venue_facilities']);
            } else {
                $venue_details['vd_facilities'] = '';
            }

            if ($this->input->post('venue_features')) {
                $venue_details['vd_features'] = implode(',', $data['venue_features']);
            } else {
                $venue_details['vd_features'] = '';
            }

            $addition_area = array();

            if ($data['number_region'] > 0) {
                for ($i = 1; $i <= $data['number_region']; $i++) {

                    $region_id = 'area_' . $i;
                    $region_name = 'add_arr' . $i;
                    $area_lat = 'add_arr_lat' . $i;
                    $area_lng = 'add_arr_lng' . $i;

                    $data[$region_name] = isset($data[$region_name]) ? $data[$region_name] : '';
                    $addition_area = array('area_name' => $data[$region_name], 'area_lat' => $data[$area_lat], 'area_lng' => $data[$area_lng]);

                    $where = array('area_id' => encrypt_decrypt('decrypt', $data[$region_id]));
                    $this->basic_model->update_records('additional_area', $addition_area, $where);
                }
            }

            $where_details = array('vd_fc_id' => $venue_id);

            $this->basic_model->update_records('venue_details', $venue_details, $where_details);

            $img_count = 5;

            if ($this->input->post('img_count')) {                // Multi venue images
                $img_count = $img_count - $this->input->post('img_count');

                $this->load->library('upload');

                $dataInfo = array();
                $files = $_FILES;
                $cpt = count($_FILES['venue_image']['name']);

                $image_data = array();
                for ($i = 0; $i < $cpt; $i++) {
                    $croped_image_name = 'dimesion_image_' . ($i + 1);
                    if ($this->input->post($croped_image_name)) {
                        $image_url = $this->input->post($croped_image_name);
                        if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                            rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                        }
                        $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $venue_id, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                    } elseif ($files['venue_image']['size'][$i] != 0) {
                        $_FILES['venue_image']['name'] = $files['venue_image']['name'][$i];
                        $_FILES['venue_image']['type'] = $files['venue_image']['type'][$i];
                        $_FILES['venue_image']['tmp_name'] = $files['venue_image']['tmp_name'][$i];
                        $_FILES['venue_image']['error'] = $files['venue_image']['error'][$i];
                        $_FILES['venue_image']['size'] = $files['venue_image']['size'][$i];

                        $this->upload->initialize($this->set_upload_options());

                        if (!$this->upload->do_upload('venue_image')) {
                            $error = $this->upload->display_errors();
                        } else {
                            $dataInfo[] = $this->upload->data();

                            $i_data = $this->upload->data();
                            $image_url = $i_data['file_name'];
                            $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $venue_id, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                        }
                    }
                }

                if (!empty($image_data)) {
                    $this->basic_model->insert_records('fc_images', $image_data, TRUE);
                }
            }

            if ($img_count > 0) { // Multi venue images
                $this->load->library('upload');

                for ($ic = 0; $ic < $img_count; $ic++) {
                    $croped_image_name = 'dimesion_image_' . ($ic + 1);
                    $image_url = false;
                    if ($this->input->post($croped_image_name) != '0') {
                        $image_url = $this->input->post($croped_image_name);
                        if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                            rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                        }
                    } else {
                        if ($_FILES["venue_image$ic"]['size'] != 0) {
                            $this->upload->initialize($this->set_upload_options());
                            if (!$this->upload->do_upload("venue_image$ic")) {
                                $error = $this->upload->display_errors();
                            } else {
                                $dataInfo[] = $this->upload->data();
                                $i_data = $this->upload->data();
                                $image_url = $i_data['file_name'];
                            }
                        }
                    }

                    if (!empty($image_url)) {
                        unlink_image('slide', $data["image$ic"]);

                        $image_update = array('fc_img_name' => $image_url, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                        $where_img = array('fc_img_id' => $data["image$ic"]);
                        $this->basic_model->update_records('fc_images', $image_update, $where_img);
                    }
                }
            }


            unset($_POST);
            redirect('my_venues');
        } else {
            if (!empty($venueID)) {
                $this->cart->destroy();
                $venue_id = encrypt_decrypt('decrypt', $venueID);

                $where_fc = array('fc_id' => $venue_id, 'fc_user' => $user_id);
                $venue = $this->basic_model->get_record_where('function_catering', '', $where_fc);

                if (!empty($venue)) {
                    $data['venue'] = $venue;
                    $this->session->set_userdata(array('fc_id' => $venue[0]->fc_id));
                    /* ---------get council-------- */
                    $data['council'] = '';
                    $where_for_council = array('suburb' => $venue[0]->fc_suburb, 'postcode' => $venue[0]->fc_postcode);
                    $council = $this->basic_model->get_record_where('aus_councils', 'council,council_id,zoom', $where_for_council);
                    if ($council) {
                        $data['council'] = $council[0]->council;
                        $data['council_id'] = $council[0]->council_id;
                        $data['zoom'] = $council[0]->zoom;
                    } else {
                        $data['council'] = $venue[0]->fc_suburb;
                        $data['council_id'] = '';
                        $data['zoom'] = 8;
                    }


                    $where_user = array('user_id' => $user_id);
                    $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);
                    //-----------plan -------------------//
                    $where = 'pro_id IN (1,2)';
                    $data['packs'] = $this->basic_model->get_record_where('products', '', $where);

                    //--------Basic Venue Details----------//

                    $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');

                    $where_events = array('type' => 'event_type', 'status' => 1);
                    $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

                    $where_facilities = array('type' => 'facilities', 'status' => 1);
                    $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

                    $where_features = array('type' => 'features', 'status' => 1);
                    $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);

                    //--------additional area Details----------//
                    $join = array(
                        'aus_councils' => 'aus_councils.council = additional_area.area_name'
                    );
                    $column = 'distinct(aus_councils.council_id),additional_area.*';
                    $where = "area_venue = " . $venue_id . " and area_status IN (0,2)";
                    $data['additinal_council'] = $this->basic_model->get_record_join_tables('additional_area', $where, $column, $join, '', '', '', 'ASC', 'left', '');

                    //--------Basic Venue Details----------//

                    $where_details = array('vd_fc_id' => $venue_id);
                    $data['venue_details'] = $this->basic_model->get_record_where('venue_details', '', $where_details);

                    $where_images = array('fc_id' => $venue_id);
                    $data['venue_images'] = $this->basic_model->get_record_where('fc_images', '', $where_images);

                    $where_subscpt = array('fc_id' => $venue_id, 'subsciption_active' => 1);
                    $subscpt_result = $this->basic_model->get_record_where('stripe_subscription', 'ss_id,subsciption_active', $where_subscpt);

                    $data['subscrption'] = (!empty($subscpt_result)) ? $subscpt_result[0]->ss_id : false;

                    $this->load->view('header');
                    $this->load->view('menu', $data);
                    $this->load->view('venue/edit_venue', $data);
                    $this->load->view('footer');
                } else {
                    redirect('my_venues');
                }
            } else {
                redirect('my_venues');
            }
        }
    }

    public function search_area() {
        if ($this->input->post('term')) {
            $search_term = $this->input->post('term');

            if ($this->input->post('more_councile')) {
                $more_councile = $this->input->post('more_councile');
                $more_councile = implode("', '", $more_councile);

                $where_term = "council LIKE '$search_term%' and council NOT IN ('" . $more_councile . "') ";
                $coucils = $this->basic_model->get_record_where('aus_councils', 'distinct(council), council_id', $where_term);
            } else {
                $where_term = "council LIKE '$search_term%' OR suburb LIKE '$search_term%' OR postcode LIKE '$search_term%' ";
                $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);
            }

            $search_result = array();

            if (!empty($coucils)) {
                $item_arr = array();
                if ($this->input->post('more_councile')) {
                    foreach ($coucils as $key => $value) {
                        $item_arr[] = array('id' => $value->council_id, 'council' => $value->council);
                    }
                } else {
                    foreach ($coucils as $key => $value) {
                        $item_arr[] = array('id' => $value->id, 'suburb' => $value->suburb, 'postcode' => $value->postcode);
                    }
                }
                $search_result['items'] = $item_arr;

                echo json_encode($search_result);
            }
        }
    }

    public function check_council() {
        if ($this->input->post('addr_str')) {
            $search_term = $this->input->post('addr_str');

            $where_term = "council LIKE '$search_term%' OR suburb LIKE '$search_term' OR postcode LIKE '$search_term%' ";
            $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);

            if (!empty($coucils)) {
                $response = array('status' => TRUE, 'council' => $coucils[0]->council, 'council_id' => $coucils[0]->council_id);
            } else {
                $response = array('status' => FALSE);
            }
            echo json_encode($response);
        }
    }

    public function edit_space($space_enc = 0) {
        $data['title'] = 'Edit space';
        $user_id = $this->session->userdata('user_id');

        if ($this->input->post('submit')) {
            $data = $this->input->post();

            $space_id = encrypt_decrypt('decrypt', $data['space']);

            unset($data['submit']);
            unset($data['space']);
            unset($data['dimesion_image_6']);
            unset($data['space_events']);
            unset($data['space_facilities']);
            unset($data['space_features']);

            if ($this->input->post('space_events')) {
                $data['space_events'] = implode(',', $this->input->post('space_events'));
            } else {
                $data['space_events'] = '';
            }

            if ($this->input->post('space_facilities')) {
                $data['space_facilities'] = implode(',', $this->input->post('space_facilities'));
            } else {
                $data['space_facilities'] = '';
            }

            if ($this->input->post('space_features')) {
                $data['space_features'] = implode(',', $this->input->post('space_features'));
            } else {
                $data['space_features'] = '';
            }

            $croped_image_name = 'dimesion_image_6';
            if ($this->input->post($croped_image_name) != '0') {
                $image_url = $this->input->post($croped_image_name);
                if (file_exists("uploads/venue_spaces/temp/" . $image_url)) {
                    rename("uploads/venue_spaces/temp/" . $image_url, "uploads/venue_spaces/" . $image_url);
                }
                $data['space_image'] = $image_url;
            } elseif ($_FILES['space_image']['size'] != 0) {

                $this->load->library('upload');
                $s_config['upload_path'] = './uploads/venue_spaces/';
                $s_config['allowed_types'] = 'jpeg|jpg|png';
                $this->load->library('upload', $s_config);
                $this->upload->initialize($s_config);

                if (!$this->upload->do_upload("space_image")) {
                    $error = $this->upload->display_errors();
                } else {
                    $i_data = $this->upload->data();
                    $data['space_image'] = $i_data['file_name'];
                }
            }
            $where = array('space_id' => $space_id);
            $data_new = $this->basic_model->get_record_where('venue_spaces', '', $where);
            $old_image = $data_new[0]->space_image;
            // print_r($test);
            if (!empty($old_image)) {
                $space_old_image = $old_image;
                $path = "uploads/venue_spaces/" . $space_old_image;
                unlink($path);
            }

            $where = array('space_id' => $space_id);
            $this->basic_model->update_records('venue_spaces', $data, $where);

            redirect('my_venues');
        } else {
            if (!empty($space_enc)) {
                $space_id = encrypt_decrypt('decrypt', $space_enc);
                $where_space = array('space_id' => $space_id, 'function_catering.fc_user' => $user_id);
                $join = array(
                    'function_catering' => 'function_catering.fc_id = venue_spaces.space_venue'
                );

                $space = $this->basic_model->get_record_join_tables('venue_spaces', $where_space, 'venue_spaces.*', $join);

                if (!empty($space)) {
                    $data['space_enc'] = $space_enc;

                    $data['space'] = $space;

                    $where_user = array('user_id' => $user_id);
                    $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

                    //--------Basic Venue Details----------//

                    $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');

                    $where_events = array('type' => 'event_type', 'status' => 1);
                    $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

                    $where_facilities = array('type' => 'facilities', 'status' => 1);
                    $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

                    $where_features = array('type' => 'features', 'status' => 1);
                    $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);

                    //--------Basic Venue Details----------//

                    $this->load->view('header', $data);
                    $this->load->view('menu', $data);
                    $this->load->view('venue/edit_space', $data);
                    $this->load->view('footer');
                }
            } else {
                redirect('my_venues');
            }
        }
    }

    public function check_business_name() {
        if ($this->input->get('venue_business_name') && !$this->input->get('fc_id')) {
            $fc_business_name = $this->input->get('venue_business_name');
            $result = $this->basic_model->get_record_where('function_catering', '', array('fc_business_name' => $fc_business_name));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
        if ($this->input->get('venue_business_name') && $this->input->get('fc_id')) {
            $fc_business_name = $this->input->get('venue_business_name');
            $fc_id = encrypt_decrypt('decrypt', $this->input->get('fc_id'));
            $result = $this->basic_model->get_record_where('function_catering', '', array('fc_business_name' => $fc_business_name, 'fc_id !=' => $fc_id));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
    }

    public function load_council() {
        $first_councile = $this->input->post('first_council');
        $where_term = array('council_id' => $first_councile);
        $relative_council = $this->basic_model->get_record_where('aus_councils', '', $where_term);
        $options = '<option council_id="" value="0">None</option>';

        if ($relative_council) {
            $relative_id = $relative_council[0]->rel_council;
            $where_term = "council_id IN (" . $relative_id . ") ";
            $coordinate = $this->basic_model->get_record_where('aus_councils', 'distinct(council),council_id,zoom', $where_term);

            foreach ($coordinate as $val) {
                $options .= '<option zoom="' . $val->zoom . '" council_id="' . $val->council_id . '" value="' . $val->council . '">' . $val->council . '</option>';
            }
        } else {
            $options = '<option council_id="" value="">No near by council found</option>';
        }

        echo $options;
    }

    public function remove_product() {
        if ($this->input->post('remove_id') && !$this->input->post('space')) {
            $remove_id = $this->input->post('remove_id');
            $remove_id = encrypt_decrypt('decrypt', $remove_id);

            $set = array('area_status' => 1);
            $this->basic_model->update_records('additional_area', $set, array('area_id' => $remove_id));
            $fc_id = $this->basic_model->get_record_where('additional_area', 'area_venue', array('area_id' => $remove_id));
            $this->load->helper('stripe_subscription_helper');
            update_subscription($fc_id[0]->area_venue);

            echo json_encode(array('status' => true));
        } elseif ($this->input->post('remove_id') && $this->input->post('space')) {

            $remove_id = encrypt_decrypt('decrypt', $this->input->post('remove_id'));
            $set = array('space_status' => 1);
            $this->basic_model->update_records('venue_spaces', $set, array('space_id' => $remove_id));

            $fc_id = $this->basic_model->get_record_where('venue_spaces', 'space_venue', array('space_id' => $remove_id));
            $this->load->helper('stripe_subscription_helper');
            update_subscription($fc_id[0]->space_venue);

            echo json_encode(array('status' => true));
        } else {
            echo json_encode(array('status' => false));
        }
    }

    public function add_additonal_area() {
        if ($this->input->post('pack_id') && $this->session->userdata('fc_id')) {
            $fc_id = $this->session->userdata('fc_id');
            $pack_id = $this->input->post('pack_id');

            $where_pro = array('pro_id' => $pack_id);
            $get_price = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);

            $name = $get_price[0]->pro_title;
            $price = $get_price[0]->pro_price;
            $pro_curr = $get_price[0]->pro_curr;

            $where_fc = array('fc_id' => $fc_id,);
            $fc_date = $this->basic_model->get_record_where('function_catering', '', $where_fc);
            $valid_upto = $fc_date[0]->fc_valid_upto;

            $today = date('Y-m-d');
            $row_id = false;
            $a_row_id = false;
            if ($pack_id && (strtotime($valid_upto) > strtotime($today))) {
                $diff = date_diff(date_create($valid_upto), date_create($today));
                $days = (int) $diff->format("%a");
                $remaining_price = $price * $days;

                if ($pro_curr == 1) {
                    $remaining_price = $remaining_price / 100;
                }

                $data = array(
                    'id' => $pack_id,
                    'qty' => 1,
                    'price' => $remaining_price,
                    'name' => 'Product-ID-' . $pack_id,
                    'options' => array('days_payment' => $days, 'new_added' => true)
                );
                $row_id = $this->cart->insert($data);
            }

            if ($this->input->post('firstcart')) {
                $firstcart = $this->input->post('firstcart');
                $a_row_id = $this->input->post('a_row_id');
                $cart_content = $this->cart->contents();

                if ($a_row_id && array_key_exists($a_row_id, $cart_content)) {
                    $this->update_product_quantity($a_row_id, 1);
                } else {
                    $pro_pay_type = $this->check_current_plan($firstcart);
                    if ($pro_pay_type == 'month') {
                        $price = $price * 30;
                    } elseif ($pro_pay_type == 'year') {
                        $price = $price * 365;
                    }
                    $price = ($pro_curr == 1) ? $price / 100 : $price;

                    $a_row_data = array(
                        'id' => $pack_id,
                        'qty' => 1,
                        'price' => $price,
                        'name' => 'Product-ID-' . $pack_id,
                    );
                    $a_row_id = $this->cart->insert($a_row_data);
                }
            }

            $cart_content = $this->cart->contents();
            $cart_total = $this->cart->total();

            echo json_encode(array('status' => TRUE, 'row_id' => $row_id, 'a_row_id' => $a_row_id, 'cart_content' => $cart_content, 'cart_total' => $cart_total));
        } else {
            echo json_encode(array('status' => false));
        }
    }

    private function update_product_quantity($row_id, $qty, $remove = false) {
        $cart_content = $this->cart->contents();

        if (array_key_exists($row_id, $cart_content)) {
            $ex_qty = $cart_content[$row_id]['qty'];
            $total_qty = ($remove) ? $ex_qty - $qty : $ex_qty + $qty;
            $data = array(
                'rowid' => $row_id,
                'qty' => $total_qty
            );

            $this->cart->update($data);
        } else {
            
        }
    }

    private function check_current_plan($firstcart) {
        $cart_content = $this->cart->contents();
        $plan_id = $cart_content[$firstcart]['id'];

        $where_pro = array('pro_id' => $plan_id);
        $get_price = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr, pro_pay_type', $where_pro);

        if (!empty($get_price)) {
            $name = $get_price[0]->pro_title;
            $price = $get_price[0]->pro_price;

            // Product currency 0-Dollar / 1-Cent
            $pro_curr = $get_price[0]->pro_curr;

            $term = $get_price[0]->pro_pay_type;
            return $term;
        } else {
            return false;
        }
    }

    function removeCart() {
        if ($this->input->post('firstcart')) {
            $firstcart = $this->input->post('firstcart');
            $this->cart->remove($firstcart);
        }
        if ($this->input->post('a_row_id')) {
            $a_row_id = $this->input->post('a_row_id');
            $cart_content = $this->cart->contents();
            $qty = $cart_content[$a_row_id]['qty'];
            $this->update_product_quantity($a_row_id, $qty, true);
        }
        if ($this->input->post('s_row_id') || $this->input->post('space_row_id')) {
            if ($this->input->post('s_qty')) {
                $qty = $this->input->post('s_qty');
                $s_row_id = $this->input->post('s_row_id');
                $space_row_id = $this->input->post('space_row_id');
                $this->update_product_quantity($s_row_id, 1, true);
                $this->update_product_quantity($space_row_id, 1, true);
            } else {
                $s_row_id = $this->input->post('s_row_id');
                $cart_content = $this->cart->contents();
                $qty = $cart_content[$s_row_id]['qty'];
                $this->update_product_quantity($s_row_id, $qty, true);
            }
        }

        if ($this->input->post('row_id')) {
            $rowid = $this->input->post('row_id');
            $this->update_product_quantity($rowid, 1, true);

            if ($this->input->post('this_row_id')) {
                $row_id = $this->input->post('this_row_id');
                $this->update_product_quantity($row_id, 1, true);
            }
        }

        $cart_content = $this->cart->contents();
        $cart_total = $this->cart->total();

        echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'cart_total' => $cart_total));
    }

    function update_existing_plan() {
        $fc_id = $this->session->userdata('fc_id');
        $user_id = $this->session->userdata('user_id');

        if ($this->input->post('pack_id')) {
            $pro_id = $this->input->post('pack_id');

            $where_pro = array('pro_id' => $pro_id);
            $plan_details = $this->basic_model->get_record_where('products', '', $where_pro);

            if (!empty($plan_details)) {
                $name = $plan_details[0]->pro_title;
                $price = $plan_details[0]->pro_price;
                $pro_curr = $plan_details[0]->pro_curr;
                $prod_pay_type = $plan_details[0]->pro_pay_type;

                if ($this->input->post('firstcart')) {

                    $firstcart = $this->input->post('firstcart');
                    $cart_content = $this->cart->contents();
                    $product_id = $cart_content[$firstcart]['id'];

                    if ($product_id != $pro_id) {
                        $firstcart = $this->change_plan($pro_id, $firstcart);
                    }
                    $a_row_id = false;
                    $s_row_id = false;
                } else {

                    $data = array(
                        'id' => $pro_id,
                        'qty' => 1,
                        'price' => $price,
                        'name' => 'Product-ID-' . $pro_id
                    );
                    $firstcart = $this->cart->insert($data);

                    $where_area = array('area_venue' => $fc_id, 'area_status' => 0); // for addional area
                    $a_row_id = $this->add_addional_product($plan_details, 3, 'additional_area', $where_area); // 3 product id for addional area
                    $where_space = array('space_venue' => $fc_id, 'space_status' => 0); // for addional space
                    $s_row_id = $this->add_addional_product($plan_details, 4, 'venue_spaces', $where_space); // 4 product id for space

                    $cart_content = $this->cart->contents();

                    if ($cart_content) {
                        foreach ($cart_content as $val) {
                            if (!empty($val['options']) and ( $val['options']['new_added'] == '3' || $val['options']['new_added'] == '4')) {

                                $qty = $val['qty'];
                                $p_id = $val['id'];

                                $where_p = array('pro_id' => $p_id);
                                $get_p = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_p);

                                if (!empty($get_p)) {
                                    $p_price = $get_p[0]->pro_price;
                                    $p_curr = $get_p[0]->pro_curr;
                                    $p_name = $get_p[0]->pro_title;

                                    if ($prod_pay_type == 'month') {
                                        $p_price = $p_price * 30;
                                    } elseif ($prod_pay_type == 'year') {
                                        $p_price = $p_price * 365;
                                    }

                                    if ($p_curr == 1)
                                        $p_price = $p_price / 100;

                                    $p_data = array(
                                        'id' => $p_id,
                                        'name' => $p_name,
                                        'qty' => $qty,
                                        'price' => $p_price
                                    );

                                    $this->cart->insert($p_data);
                                }
                            }
                        }
                    }
                }

                $cart_content = $this->cart->contents();
                $cart_total = $this->cart->total();

                echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'firstcart' => $firstcart, 'a_row_id' => $a_row_id, 's_row_id' => $s_row_id, 'cart_total' => $cart_total));
            } else {
                echo json_encode(array('status' => FALSE));
            }
        } else {
            echo json_encode(array('status' => FALSE));
        }
    }

    private function add_addional_product($plan_details, $prod_id, $type, $where_addioinal) {
        $additional_areas = $this->basic_model->get_record_where($type, '', $where_addioinal);

        if (!empty($additional_areas)) {
            $count_area = count($additional_areas);

            $where_prod = array('pro_id' => $prod_id);
            $area_product = $this->basic_model->get_record_where('products', '', $where_prod);
            $area_price = $area_product[0]->pro_price;
            $term = $plan_details[0]->pro_pay_type;

            if ($term == 'month') {
                $area_price = $area_price * 30;
                $area_price = $area_price / 100;
            } elseif ($term == 'year') {
                $area_price = $area_price * 365;
                $area_price = $area_price / 100;
            }

            $area_pack = array(
                'id' => $prod_id,
                'qty' => $count_area,
                'price' => $area_price,
                'name' => 'Product-ID-' . $prod_id
            );

            $row_id = $this->cart->insert($area_pack);
            return $row_id;
        }
    }

    public function add_additonal_space() {
        if ($this->input->post('pack_id') && $this->session->userdata('fc_id')) {
            $fc_id = $this->session->userdata('fc_id');
            $pack_id = $this->input->post('pack_id');

            $where_pro = array('pro_id' => $pack_id);
            $get_price = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);

            $name = $get_price[0]->pro_title;
            $price = $get_price[0]->pro_price;
            $pro_curr = $get_price[0]->pro_curr;

            $where_fc = array('fc_id' => $fc_id,);
            $fc_date = $this->basic_model->get_record_where('function_catering', '', $where_fc);
            $valid_upto = $fc_date[0]->fc_valid_upto;

            $today = date('Y-m-d');
            $row_id = false;
            $a_row_id = false;
            if ($pack_id && (strtotime($valid_upto) > strtotime($today))) {
                $diff = date_diff(date_create($valid_upto), date_create($today));
                $days = (int) $diff->format("%a");
                $remaining_price = $price * $days;

                if ($pro_curr == 1) {
                    $remaining_price = $remaining_price / 100;
                }

                $data = array(
                    'id' => $pack_id,
                    'qty' => 1,
                    'price' => $remaining_price,
                    'name' => 'Product-ID-' . 'S_' . $pack_id,
                    'options' => array('days_payment' => $days, 'new_added' => true)// here days_payment mean (number of day calculate to pay)
                );
                $row_id = $this->cart->insert($data);
            }

            if ($this->input->post('firstcart')) {
                $firstcart = $this->input->post('firstcart');
                $a_row_id = $this->input->post('a_row_id');
                $cart_content = $this->cart->contents();

                if ($a_row_id && array_key_exists($a_row_id, $cart_content)) {
                    $this->update_product_quantity($a_row_id, 1);
                } else {
                    $pro_pay_type = $this->check_current_plan($firstcart);
                    if ($pro_pay_type == 'month') {
                        $price = $price * 30;
                    } elseif ($pro_pay_type == 'year') {
                        $price = $price * 365;
                    }
                    $price = ($pro_curr == 1) ? $price / 100 : $price;

                    $a_row_data = array(
                        'id' => $pack_id,
                        'qty' => 1,
                        'price' => $price,
                        'name' => 'Product-ID-' . $pack_id,
                            // 'options' => array('new_added' => false) // here new option mean new added area
                    );
                    $s_row_id = $this->cart->insert($a_row_data);
                }
            }

            $cart_content = $this->cart->contents();
            $cart_total = $this->cart->total();

            echo json_encode(array('status' => TRUE, 'space_row_id' => $row_id, 'cart_content' => $cart_content, 'cart_total' => $cart_total));
        } else {
            echo json_encode(array('status' => false));
        }
    }

    public function account_details_invoice($order_data, $total, $payId) {
        require_once(APPPATH . 'libraries/mpdf/mpdf.php');
        $this->load->helper('email_template_helper');

        $data = array();
        $order_data = json_decode($order_data);

        $packs = $this->basic_model->get_record_where('products', 'pro_id,pro_title', '');
        foreach ($packs as $val) {
            $product[$val->pro_id] = (array) $val;
        }

        $data['invoice_no'] = sprintf("%010d", $payId);
        $data['order_total'] = $total;
        $data['products'] = $product;
        $data['order_data'] = $order_data;

        $file = $this->load->view('invoices/account_details_invoice', $data, TRUE);
        ob_clean();
        $mpdf = new mPDF();
        ob_end_clean();

        $mpdf->WriteHTML($file);
        $date = time();
        $pdf_name = 'fnc-bank-details' . $date . '.pdf';

        $mpdf->Output('assets/pdf/' . $pdf_name, 'F');
        send_account_details_invoice($pdf_name);
    }

    function get_stripPaymentView() {
        $this->load->view('venue/strip_payment');
    }

    function cancel_subscription() {
        $this->load->helper('stripe_subscription_helper');
        if ($this->input->post()) {
            $cancel_result = array();
            $data = array('strip_private_key' => 'sk_test_oN2t24XXWa6rfxjMQO40Q9YI');

            $fc_id = encrypt_decrypt('decrypt', $this->input->post('fc_id'));
            $data['cancel_type'] = $this->input->post('cancel_type');

            $where = array('function_catering.fc_id' => $fc_id, 'subsciption_active' => 1);
            $column = array('subsciption_active', 'strp_subscription_id', 'ss_id');
            $join = array(
                'stripe_subscription' => 'stripe_subscription.fc_id = function_catering.fc_id'
            );
            $fc_data = $this->basic_model->get_record_join_tables('function_catering', $where, $column, $join, $like = '', $or_like = '', $orderby = '', 'ASC', 'inner', $groupby = '');

            if (!empty($fc_data)) {
                $data['strp_subscription_id'] = $fc_data[0]->strp_subscription_id;
                $data['ss_id'] = $fc_data[0]->ss_id;

                $response = cancel_subscription($data);
                if ($response['status']) {
                    $cancel_result = array('status' => true);
                } else {
                    $cancel_result = array('status' => false, 'error' => $response['error']);
                }
            }
        } else {
            $cancel_result = array('status' => false, 'error' => 'bad requrest');
        }

        echo json_encode($cancel_result);
    }

    function strip_subscription() {
        $this->load->helper('stripe_subscription_helper');
        if ($this->input->post('stripToken')) {
            $status = true;
            $subscription_result = array();
            $data = array('strip_private_key' => 'sk_test_oN2t24XXWa6rfxjMQO40Q9YI');

            $data['plan'] = $this->input->post('subscription_plan'); // here plan mean monthly or yearly
            $data['stripeToken'] = $this->input->post('stripToken');
            $data['fc_id'] = encrypt_decrypt('decrypt', $this->input->post('fc_id'));


            $fc_data = $this->basic_model->get_record_where('function_catering', 'fc_email,fc_valid_upto', $where = array('fc_id' => $data['fc_id']));
            if (!empty($fc_data)) {
                $data['fc_email'] = $this->session->userdata('user_email');
                $data['subscription_start_date'] = $fc_data[0]->fc_valid_upto;
            } else {
                $status = false;
                $subscription_result = json_encode(array('status' => false, 'error' => 'something wend wrong'));
            }


            // first need to create users
            if ($status) {
                $user_id = $this->session->userdata('user_id');
                $strip_user_data = $fc_data = $this->basic_model->get_record_where('stripe_users', 'stripe_customer_id,s_id', $where = array('user_id' => $user_id));

                if (!empty($strip_user_data)) {
                    $data['stripe_customer_id'] = $strip_user_data[0]->stripe_customer_id;
                    $data['s_id'] = $strip_user_data[0]->s_id;
                } else {
                    $response = create_user($data);
                    if ($response['status']) {
                        $data['s_id'] = $response['s_id'];
                        $data['stripe_customer_id'] = $response['stripe_customer_id'];
                    } else { // if status true mean user succefully create and if false mean error
                        $status = false;
                        $subscription_result = array('status' => false, 'error' => $response['error']);
                    }
                }
            }


            // then check its current active plans of function and catering
            if ($status) {

                // match the plans from fc to strip and get
                $strip_plans = strip_plan_get($data['fc_id'], $data['plan']);

                // subscribe plan
                $response = active_subscription($data, $strip_plans);
                if ($response['status']) {
                    $subscription_result = json_encode(array('status' => true));
                } else {
                    $subscription_result = json_encode(array('status' => false, 'error' => $response['error']));
                }
            }
        } else {
            $subscription_result = json_encode(array('status' => false, 'error' => 'strip token not genrated'));
        }

        echo $subscription_result;
    }

    public function venue_details() {

        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');
        $where_events = array('type' => 'event_type', 'status' => 1);
        $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

        $where_facilities = array('type' => 'facilities', 'status' => 1);
        $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

        $where_features = array('type' => 'features', 'status' => 1);
        $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);

        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('venue/venue_details', $data);
        $this->load->view('footer');
    }

}
