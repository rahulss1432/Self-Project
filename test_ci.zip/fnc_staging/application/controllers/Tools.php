<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Tools extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function new_admin_user($email, $password)
    {
        $admin = [
            'name' => 'Admin',
            'email' => "$email",
            'password' => md5($password),
        ];

        $this->db->insert('admin', $admin);
    }
}
