<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('cart');
        $this->load->model('web_model');
        $this->load->model('basic_model');
        $this->load->helper('message');
        $this->load->library('form_validation');
    }

    public function index() {
        $data['body_class'] = 'ihome_page';
        $data['title'] = APPLICATION_NAME;
        $data['subscriber_form_action'] = base_url('web/save_subscriber');
        $data['search_form_action'] = base_url('search');

        $column = array('name', 'image', 'type', 'status');
        $where = array('status' => 1, 'type' => 'event_type');
        $data['features'] = $events = $this->basic_model->get_record_where_orderby('fnc_types', $column, $where, $orderby = '', $direction = 'DESC');

        $data['function_and_catering_data'] = $this->web_model->get_function_and_catering_data();

        //$details = get_client_ip();

        if ($this->session->userdata('user_email')) {
            $user_id = $this->session->userdata('user_id');
            $where_user = array('user_id' => $user_id);
            $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);
        }
        $data['wish_list'] = home_page_data();
        $data['events'] = $events;
        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('web/home', $data);
        $this->load->view('footer');
    }

    public function about_us() {
        $data['pages_data'] = $this->basic_model->get_row('pages', array('id' => 1), array('content'));

        if (empty($data['pages_data'])) {
            redirect();
        }
        $user_id = $this->session->userdata('user_id');

        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('web/about_us', $data);
        $this->load->view('footer', $data);
    }

    public function help() {

        $data['pages_data'] = $this->basic_model->get_row('pages', array('id' => 2), array('content'));
        if (empty($data['pages_data'])) {
            redirect();
        }
        $user_id = $this->session->userdata('user_id');

        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('web/help', $data);
        $this->load->view('footer', $data);
    }

    function vanue_preview($fcId = 0) {
        require_once(APPPATH . 'libraries/mpdf/mpdf.php');
        $this->load->helper('email_template_helper');

        $data = array();

        $this->load->model('web_model');
        $fc_id = encrypt_decrypt('decrypt', $fcId);
        if (!empty($fc_id)) {
            $data['venue_data'] = array();
            $data['pdf_data'] = array();
//            $user = $this->session->userdata('user_id');
            $fc_data = array();
            $where = array('fc_id' => $fc_id);
            $functionData = $this->basic_model->get_record_where('function_catering', $column = '', array('fc_id' => $fc_id));
            if ($functionData) {
                $fc_data = $functionData[0];
                $data['extra_detils'] = $this->basic_model->get_record_where('venue_details', $column = '', array('vd_fc_id' => $fc_id));
                $fc_venue_detail = false;
                if ($data['extra_detils']) {
                    $fc_venue_details = $data['extra_detils'][0];
                }
                if ($fc_id) {
                    $where_venue = array('space_venue' => $fc_id, 'space_status' => 0);
                    $spaces = $this->basic_model->get_record_where('venue_spaces', 'space_id, space_name', $where_venue);
                    if (!empty($spaces))
                        $fc_data->spaces = $spaces;
                }
                $data['images'] = $this->basic_model->get_record_where('fc_images', 'fc_img_name', $where);
                if ($data['images']) {
                    foreach ($data['images'] as $img) {
                        $fc_data->fc_images[] = $img->fc_img_name;
                    }
                }
                $data['pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '*', $where);
                if ($data['pdfs']) {
                    foreach ($data['pdfs'] as $img) {
                        $fc_data->fc_pdfs[] = $img;
                    }
                }
                $fc_data->fc_pricing = '';
                $fc_data->events = '';
                $fc_data->facilities = '';
                $fc_data->features = '';
                $fc_data->nearest_to_me = '';
                if ($fc_data->fc_pricing) {
                    $where = 'p_id IN (' . $fc_data->fc_pricing . ')';
                    $pricing = $this->basic_model->get_record_where('price_per_head', 'p_name,p_value', $where);
                    $fc_data->fc_pricing = $pricing;
                }
                if (!empty($fc_venue_details->vd_events)) {
                    $where = 'type="event_type" and id IN (' . $fc_venue_details->vd_events . ')';
                    $events = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->events = $events;
                }
                if (!empty($fc_venue_details->vd_facilities)) {
                    $where = 'type="facilities" and id IN (' . $fc_venue_details->vd_facilities . ')';
                    $facilities = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->facilities = $facilities;
                }
                if (!empty($fc_venue_details->vd_features)) {
                    $where = 'type="features" and id IN (' . $fc_venue_details->vd_features . ')';
                    $features = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->features = $features;
                }
                if ($fc_data->fc_lat) {
                    $data['nearest_to_me'] = $this->web_model->find_nearest($fc_data->fc_lat, $fc_data->fc_lng);
                }
                $data['venue_data'] = $fc_data;
            }
            $file = $this->load->view('venue/add_venue/preview_listing_pdf', $data, true);
            @ob_clean();
            $mpdf = new mPDF();
            $mpdf->WriteHTML($file);
            $mpdf->Output();
        } else {
            redirect('/');
        }
    }

    function catering_preview($fcId = 0) {
        require_once(APPPATH . 'libraries/mpdf/mpdf.php');
        $this->load->helper('email_template_helper');

        $data = array();

        $this->load->model('web_model');
        $fc_id = encrypt_decrypt('decrypt', $fcId);
        if (!empty($fc_id)) {
            $data['venue_data'] = array();
            $data['pdf_data'] = array();
//            $user = $this->session->userdata('user_id');
            $fc_data = array();
            $where = array('fc_id' => $fc_id);
            $functionData = $this->basic_model->get_record_where('function_catering', $column = '', array('fc_id' => $fc_id));
            if ($functionData) {
                $fc_data = $functionData[0];
                $data['extra_detils'] = $this->basic_model->get_record_where('catering_details', $column = '', array('cd_fc_id' => $fc_id));
                $fc_venue_detail = false;
                if ($data['extra_detils']) {
                    $fc_venue_details = $data['extra_detils'][0];
                }
                if ($fc_id) {
                    $cartData = $this->cart->contents();
                    if (!empty($cartData)) {
                        foreach ($cartData as $val) {
                            if ($val['id'] == 4) {
                                $fc_data->spaces[] = $val['options']['space_name'];
                            }
                        }
                    }
                }
                $data['images'] = $this->basic_model->get_record_where('fc_images', 'fc_img_name', $where);
                if ($data['images']) {
                    foreach ($data['images'] as $img) {
                        $fc_data->fc_images[] = $img->fc_img_name;
                    }
                }
                $data['pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '*', $where);
                if ($data['pdfs']) {
                    foreach ($data['pdfs'] as $img) {
                        $fc_data->fc_pdfs[] = $img;
                    }
                }
                $fc_data->fc_pricing = '';
                $fc_data->function_type = '';
                $fc_data->menus = '';
                $fc_data->cuisine = '';
                $fc_data->services = '';
                if ($fc_data->fc_pricing) {
                    $where = 'p_id IN (' . $fc_data->fc_pricing . ')';
                    $pricing = $this->basic_model->get_record_where('price_per_head', 'p_name,p_value', $where);
                    $fc_data->fc_pricing = $pricing;
                }

                if (!empty($fc_venue_details->cd_function_type)) {
                    $where = 'type="function_type" and id IN (' . $fc_venue_details->cd_function_type . ')';
                    $function_type = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->function_type = $function_type;
                }

                if (!empty($fc_venue_details->cd_menus)) {
                    $where = 'type="menus" and id IN (' . $fc_venue_details->cd_menus . ')';
                    $menus = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->menus = $menus;
                }

                if (!empty($fc_venue_details->cd_cuisine)) {
                    $where = 'type="cuisine" and id IN (' . $fc_venue_details->cd_cuisine . ')';
                    $cuisine = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->cuisine = $cuisine;
                }

                if (!empty($fc_venue_details->cd_services)) {
                    $where = 'type="services" and id IN (' . $fc_venue_details->cd_services . ')';
                    $services = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->services = $services;
                }
                if ($fc_data->fc_lat) {
                    $data['nearest_to_me'] = $this->web_model->find_nearest($fc_data->fc_lat, $fc_data->fc_lng);
                }
                $data['venue_data'] = $fc_data;
            }
            $file = $this->load->view('catering/add_catering/preview_listing_pdf', $data, true);
            @ob_clean();
            $mpdf = new mPDF();
            $mpdf->WriteHTML($file);
            $mpdf->Output();
        } else {
            redirect('/');
        }
    }
	
	function request_approve_deny(){
	   
		if(!empty($_GET['fc']) && isset($_GET['st']) && isset($_GET['sm']))
		{
			$this->venue_catering_update($_GET['fc'],$_GET['st'],$_GET['sm']);
		
		    
		}else{
			redirect('/404');
		}

	}
	
    // function using for approve and deny on mail sending
    public function venue_catering_update($fcId, $status, $is_mail_send) {
     
        try {
            if ($fcId) {
                $fc_id = encrypt_decrypt('decrypt', $fcId);
                $fcData = array('fc_id' => $fc_id);
                $fcData = $this->basic_model->get_record_where('function_catering', '', $fcData);
				if(empty($fcData)){
					redirect('/404');
				}
                if (($fcData[0]->fc_status == 1) || ($fcData[0]->fc_status == 2)) {
                    redirect('/');
                }
                if (($fcData[0]->fc_status == 0)) {
                    $data = array('fc_status' => $status);
                    $where = array('fc_id' => $fc_id);
                    $this->load->model("basic_model");
                    $my_data = $this->basic_model->update_records('function_catering', $data, $where);
                    $fc_data = array('fc_id' => $fc_id);
                    $fc_data = $this->basic_model->get_record_where('function_catering', '', $fc_data);
                    if ($is_mail_send == 1) {
                        $user_id = $fc_data[0]->fc_user;
                        $user_data = $this->basic_model->get_record_where('users', 'user_firstname,user_lastname,user_email', array('user_id' => $user_id));
                        $user_name = ucfirst($user_data[0]->user_firstname . ' ' . $user_data[0]->user_lastname);
                        $user_email = $user_data[0]->user_email;
                        $fc_new_data = array('fc_id' => $fc_id, 'name' => $user_name, 'business_name' => $fc_data[0]->fc_business_name, 'email' => $user_email, 'contact_no' => $fc_data[0]->fc_phone_no, 'url' => base_url('admin/catering_update'), 'requested_date' => $fc_data[0]->fc_created_date, 'contact_name' => $fc_data[0]->fc_contact_name, 'contact_email' => $fc_data[0]->fc_email, 'type' => $fc_data[0]->fc_type);
                        $this->load->helper('email_template_helper');
                        approved_fc_mail($fc_new_data);
                    }
                    $fc_data['fc_data'] = $fc_data;
                    $this->load->view('success_msg', $fc_data);
                    
                }
            }
        } catch (Exception $e) {
            return $return = array('status' => false, 'error' => system_msgs('something_went_wrong'));
        }
    }

    public function privacy_policy() {
        $data['title'] = 'Privacy policy';
        $user_id = $this->session->userdata('user_id');

        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);
        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('web/privacy-policy');
        $this->load->view('footer');
    }

    public function term_condition() {
        $data['title'] = 'Term condition';
        $user_id = $this->session->userdata('user_id');

        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);
        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('web/terms-and-condition');
        $this->load->view('footer');
    }

//    public function contact_us() {
//        $data['title'] = 'Contact';
//        $this->load->helper('email_template_helper');
//        $data = '';
//        if ($this->input->post()) {
//            if ($this->input->post('g-recaptcha-response')) {
//
//                $post_data = http_build_query(
//                        array(
//                            'secret' => CAPTCHA_SECRET_KEY,
//                            'response' => $this->input->post('g-recaptcha-response'),
//                            'remoteip' => $_SERVER['REMOTE_ADDR']
//                        )
//                );
//
//                $opts = array('http' =>
//                    array(
//                        'method' => 'POST',
//                        'header' => 'Content-type: application/x-www-form-urlencoded',
//                        'content' => $post_data
//                    )
//                );
//
//                $context = stream_context_create($opts);
//                $response = file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
//                $result = json_decode($response, TRUE);
//
//                if ($result) {
//                    $contact_data = $this->input->post();
//                    contact_us_mail($contact_data);
//                    unset($contact_data['g-recaptcha-response']);
//                    $this->basic_model->insert_records('contact_us', $contact_data);
//                    // $data['success'] = 'Your message has been submitted successfully';
//                    $this->session->set_flashdata('success', 'Your message has been submitted successfully');
//                    redirect('contact_us');
//                }
//                // } else {
//                //     echo "error";
//                //     // $data['error'] = 'Please verify captcha!';
//                //     $this->session->set_flashdata('error','YPlease verify captcha!');
//                // }
//            } else {
//                $this->session->set_flashdata('error', 'Please verify captcha!');
//                redirect('contact_us');
//            }
//        }
//        $user_id = $this->session->userdata('user_id');
//        $where = "user_id='" . $user_id . "'";
//        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);
//
//        $this->load->view('header', $data);
//        $this->load->view('menu');
//        $this->load->view('web/contact-us', $data);
//        $this->load->view('footer');
//    }

    public function contact_us() {
        $data['title'] = 'Contact';
        $this->load->helper('email_template_helper');
//        $data = '';
        if ($this->input->post()) {
            if ($this->input->post('g-recaptcha-response')) {
                if (CAPTCHA_SHOW) {
                    $verify = $this->verify_recapacha($this->input->post('g-recaptcha-response'));
                    if (!$verify) {
                        $this->session->set_flashdata('error', 'something when wrong!!');
                        redirect('contact_us');
                    }
                }
                $contact_data = $this->input->post();
                $contact_data['reCaptcha'] = $verify['success'];
                $response_valid = $this->validate_contact_us((array) $contact_data);
                if ($response_valid['status']) {
                    contact_us_mail($contact_data);
                    unset($contact_data['g-recaptcha-response']);
                    $contact_data_arr = array();
                    $contact_data_arr['contact_name'] = $contact_data['contact_name'];
                    $contact_data_arr['contact_business_name'] = $contact_data['contact_business_name'];
                    $contact_data_arr['contact_email'] = $contact_data['contact_email'];
                    $contact_data_arr['contact_state'] = $contact_data['contact_state'];
                    $contact_data_arr['contact_city'] = $contact_data['contact_city'];
                    $contact_data_arr['contact_postal_code'] = $contact_data['contact_postal_code'];
                    $contact_data_arr['contact_message'] = $contact_data['contact_message'];

                    $this->basic_model->insert_records('contact_us', $contact_data_arr);
                    // $data['success'] = 'Your message has been submitted successfully';
                    $this->session->set_flashdata('success', 'Your message has been submitted successfully');
                    redirect('contact_us');
                } else {
                    
                }
            } else {
                $this->session->set_flashdata('error', 'Please verify captcha!');
                redirect('contact_us');
            }
        }
        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('web/contact-us', $data);
        $this->load->view('footer');
    }

    public function validate_contact_us($contact_data) {
        try {
            $validation_rules = array(
                array('field' => 'contact_name', 'label' => 'full name', 'rules' => 'required'),
                array('field' => 'contact_email', 'label' => 'email', 'rules' => 'required|valid_email'),
                array('field' => 'contact_state', 'label' => 'state', 'rules' => 'required'),
                array('field' => 'contact_city', 'label' => 'city', 'rules' => 'required'),
                array('field' => 'contact_postal_code', 'label' => 'postal code', 'rules' => 'required'),
                array('field' => 'contact_message', 'label' => 'query', 'rules' => 'required'),
                array('field' => 'reCaptcha', 'label' => 'reCaptcha', 'rules' => 'required')
            );
            $this->form_validation->set_data($contact_data);
            $this->form_validation->set_rules($validation_rules);
            if ($this->form_validation->run()) {
                $return = array('status' => true);
            } else {
                $errors = $this->form_validation->error_array();
                $return = array('status' => false, 'error' => implode(', ', $errors));
            }
        } catch (Exception $e) {
            $return = array('status' => false, 'error' => system_msgs('something_went_wrong'));
        }
        return $return;
    }

    public function verify_recapacha($captcha) {

        $post_data = http_build_query(
                array(
                    'secret' => CAPTCHA_SECRET_KEY,
                    'response' => $captcha,
                    'remoteip' => $_SERVER['REMOTE_ADDR']
                )
        );

        $opts = array('http' =>
            array(
                'method' => 'POST',
                'header' => 'Content-type: application/x-www-form-urlencoded',
                'content' => $post_data
            )
        );
        $context = stream_context_create($opts);
        $response = file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
        $result = json_decode($response, TRUE);
        return $result;
    }

    // function using for get city by states
    public function get_city_by_state() {
        try {
            $city = $this->input->post('city');
            $state = $this->input->post('state');
            if (!empty($city)) {
                $query = $this->db->select('*')->from('tbl_suburb_state')->like("city", $city)->where('state', $state)->get();
                $data = $query->result();
                $response = array();
                foreach ($data as $city) {
                    $response[] = array("id" => $city->id, "value" => $city->city, "label" => $city->city . ', ' . $city->postcode);
                }
                echo json_encode(array('status' => true, 'city' => $response));
                exit;
            }
        } catch (Exception $e) {
            $return = array('status' => false, 'error' => system_msgs('something_went_wrong'));
        }
    }

    // function using for get postcode by cities
    public function get_postcode_by_city() {
        try {
            $state = $this->input->post('state');
            $cityId = $this->input->post('cityId');
            $query = $this->db->select('postcode')->from('tbl_suburb_state')->where("id", $cityId)->where('state', $state)->get();
            $data = $query->result();
            echo json_encode(array('status' => true, 'postcode' => $data));
            exit;
        } catch (Exception $e) {
            $return = array('status' => false, 'error' => system_msgs('something_went_wrong'));
        }
    }

    public function save_subscriber() {

        $post_data = $this->input->post(NULL, TRUE);
        if (!empty($post_data)) {
            $data_ary = array('subscriber_name' => $post_data['subscriber_name'],
                'subscriber_email' => $post_data['subscriber_email'],
                'created_date' => CURRENT_DATE_TIME,
            );

            $row = $this->basic_model->get_row('subscriber', array('subscriber_email' => $post_data['subscriber_email']), array('subscriber_id'));

            if (!empty($row)) {
                $output = array("status_code" => "400", "status" => "e", "message" => system_msgs('already_subscribe'));
                echo json_encode($output);
                exit;
            } else {
                $this->basic_model->insert_records('subscriber', $data_ary);
                $this->push_data_inmailchimp($data_ary);
                $output = array("status_code" => "200", "status" => "s", "message" => system_msgs('subscriber_add_success'), 'redirect_url' => '');
                echo json_encode($output);
                exit;
            }
        }
    }

    public function push_data_inmailchimp($data_ary) {
        $fname = $data_ary['subscriber_name'];
        $email = $data_ary['subscriber_email'];

        if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            // MailChimp API credentials
            $apiKey = MAILCHIMP_APP_KEY;
            $listID = MAILCHIMP_SUBSCRIBER_LIST_ID;

            // MailChimp API URL
            $memberID = md5(strtolower($email));
            $dataCenter = substr($apiKey, strpos($apiKey, '-') + 1);
            $url = 'https://' . $dataCenter . '.api.mailchimp.com/3.0/lists/' . $listID . '/members/' . $memberID;

            // member information
            $json = json_encode([
                'email_address' => $email,
                'status' => 'subscribed',
                'merge_fields' => [
                    'FIRST_NAME' => $fname,
                //'LNAME'     => $lname
                ]
            ]);

            // send a HTTP POST request with curl
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_USERPWD, 'user:' . $apiKey);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            $result = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode == 200) {
                $msg_show = 'You have successfully subscribed ';
                $update_data = array('is_update_in_mailchimp' => 1);
                $this->basic_model->update_records('subscriber', $update_data, array('subscriber_email' => $email));
            } else {
                switch ($httpCode) {
                    case 214:
                        $msg = 'You are already subscribed.';
                        break;
                    default:
                        $msg = 'Some problem occurred, please try again.';
                        break;
                }
                $msg_show = $msg;
            }
        } else {
            $msg_show = 'Please enter valid email address';
        }
        //echo $msg_show;
    }

    private function get_primium_six($council) {
        $council_id = $council[0]->council_id; // for 6 primium functions
        $six_primium_fc_ids = $this->basic_model->get_record_where('premium_venue', 'venue_id', $where = array('council' => $council_id));
        if (!empty($six_primium_fc_ids)) {
            $six_primium = $six_primium_fc_ids[0]->venue_id;
            $six_primium = explode(',', $six_primium);
            return $six_primium;
        } else {
            return false;
        }
    }

    public function search() {
        $data['title'] = 'Search result';
        //$data['active_class'] = 'user_profile'; 
        $post_data = $this->input->get(NULL, TRUE);
        $data['last_post_data'] = $post_data;
        $data['advance_search_form_action'] = base_url('advance_search');
        $data['post_data'] = $post_data;
        $post_data['actual_location'] = $this->input->get('location');
        $column = array('name', 'image', 'type', 'status', 'id');
        $where = array('status' => 1, 'type' => 'event_type');
        $data['event_type'] = $this->basic_model->get_record_where_orderby('fnc_types', $column, $where, $orderby = '', $direction = 'DESC');
        $data['cuisine_type'] = $this->basic_model->get_record_where_orderby('fnc_types', $column, array('status' => 1, 'type' => 'cuisine'), $orderby = '', $direction = 'DESC');

        $data['menus'] = $this->basic_model->get_record_where_orderby('fnc_types', $column, array('status' => 1, 'type' => 'menus'), $orderby = '', $direction = 'DESC');

        $column = array('p_name', 'p_id');
        $data['budget_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', $column, '', $orderby = '', $direction = 'DESC');


        $free_data = array();
        $premium_data = array();

        if (!empty($post_data)) {
            $six_primium = array();
            $check_it_council = $this->basic_model->get_record_where('aus_councils', 'council,council_id', $where = array('council' => $post_data['location']));
            $check_it_suburb = $this->basic_model->get_record_where('aus_councils', 'council,council_id', $where = array('suburb' => $post_data['location']));
            $check_it_postcode = $this->basic_model->get_record_where('aus_councils', 'council,council_id', $where = array('postcode' => $post_data['location']));

            if (!empty($check_it_council)) {
                $six_primium = $this->get_primium_six($check_it_council);
            } elseif (!empty($check_it_suburb)) {
                $post_data['location'] = $check_it_suburb[0]->council;
                $six_primium = $this->get_primium_six($check_it_suburb);
            } elseif (!empty($check_it_postcode)) {
                $six_primium = $this->get_primium_six($check_it_postcode);
            }

            $post_data['addional_fc_ids'] = '';
            if ($post_data['fc_type'][0] == 1) {
                $where_addional = array('area_name' => $post_data['location'], 'area_status' => 0);
                $addianal_ids = $this->basic_model->get_record_where('additional_area', 'area_venue', $where_addional);

                if (!empty($addianal_ids)) {
                    $addional_fc_ids_array = array();
                    foreach ($addianal_ids as $val) {
                        $addional_fc_ids_array[] = $val->area_venue;
                    }
                    $post_data['addional_fc_ids'] = implode(', ', $addional_fc_ids_array);
                }
            }

            $data['search_data'] = $search_data = $this->web_model->first_search($post_data);
//            echo $this->db->last_query();
//            die;
            $actual_search_result = array();
            if (!empty($search_data)) {
                foreach ($search_data as $key => $value) {
                    if ($value->fc_free == 0) {
                        $temp_actual_search['fc_business_name'] = $value->fc_business_name;
                        $temp_actual_search['fc_overview'] = $value->fc_overview;
                        $temp_actual_search['fc_type'] = $value->fc_type;
                        $temp_actual_search['fc_img_name'] = $value->fc_img_name;
                        $temp_actual_search['fc_listing_picture'] = $value->fc_listing_picture;
                        $temp_actual_search['fc_id'] = $value->fc_id;
                        $temp_actual_search['fc_free'] = $value->fc_free;
                        $actual_search_result[$value->fc_id] = $temp_actual_search;
                    } else {
                        $temp_free_data['fc_business_name'] = $value->fc_business_name;
                        $temp_free_data['fc_overview'] = $value->fc_overview;
                        $temp_free_data['fc_type'] = $value->fc_type;
                        $temp_free_data['fc_img_name'] = $value->fc_img_name;
                        $temp_free_data['fc_listing_picture'] = $value->fc_listing_picture;
                        $temp_free_data['fc_id'] = $value->fc_id;
                        $temp_free_data['fc_free'] = $value->fc_free;
                        $free_data[$value->fc_id] = $temp_free_data;
                    }
                }
            }

            $data['primium_data_ids'] = $six_primium;
            $data['actual_search_data'] = $actual_search_result;
            $data['free_data'] = $free_data;

            $data['location'] = $this->input->get('location');
            $this->load->view('header');
            $this->load->view('menu', $data);
            $this->load->view('web/search_result', $data);
            $this->load->view('footer');
        } else {
            redirect('web');
        }
    }

    public function advance_search() {
        $data['title'] = 'Search result';
        $data['advance_search_form_action'] = base_url('advance_search');
        //$data['active_class'] = 'user_profile'; 
        $post_data = $this->input->get(NULL, TRUE);
        $data['post_data'] = $post_data;
        $post_data['actual_location'] = $this->input->get('location');
        $column = array('name', 'image', 'type', 'status', 'id');
        $where = array('status' => 1, 'type' => 'event_type');
        $data['event_type'] = $this->basic_model->get_record_where_orderby('fnc_types', $column, $where, $orderby = '', $direction = 'DESC');
        $data['cuisine_type'] = $this->basic_model->get_record_where_orderby('fnc_types', $column, array('status' => 1, 'type' => 'cuisine'), $orderby = '', $direction = 'DESC');

        $data['menus'] = $this->basic_model->get_record_where_orderby('fnc_types', $column, array('status' => 1, 'type' => 'menus'), $orderby = '', $direction = 'DESC');

        $column = array('p_name', 'p_id');
        $data['budget_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', $column, '', $orderby = '', $direction = 'DESC');


        $free_data = array();
        $premium_data = array();
        if (!empty($post_data)) {

            $six_primium = array();
            $check_it_council = $this->basic_model->get_record_where('aus_councils', 'council,council_id', $where = array('council' => $post_data['location']));
            $check_it_suburb = $this->basic_model->get_record_where('aus_councils', 'council,council_id', $where = array('suburb' => $post_data['location']));
            $check_it_postcode = $this->basic_model->get_record_where('aus_councils', 'council,council_id', $where = array('postcode' => $post_data['location']));

            if (!empty($check_it_council)) {
                $six_primium = $this->get_primium_six($check_it_council);
            } elseif (!empty($check_it_suburb)) {
                $post_data['location'] = $check_it_suburb[0]->council;
                $six_primium = $this->get_primium_six($check_it_suburb);
            } elseif (!empty($check_it_postcode)) {
                $six_primium = $this->get_primium_six($check_it_postcode);
            }

            $post_data['addional_fc_ids'] = '';
            if ($post_data['fc_type'][0] == 1) {
                $where_addional = array('area_name' => $post_data['location'], 'area_status' => 0);
                $addianal_ids = $this->basic_model->get_record_where('additional_area', 'area_venue', $where_addional);

                if (!empty($addianal_ids)) {
                    $addional_fc_ids_array = array();
                    foreach ($addianal_ids as $val) {
                        $addional_fc_ids_array[] = $val->area_venue;
                    }
                    $post_data['addional_fc_ids'] = implode(', ', $addional_fc_ids_array);
                }
            }

            $data['search_data'] = $search_data = $this->web_model->advance_search($post_data);

            $actual_search_result = array();
            if (!empty($search_data)) {
                foreach ($search_data as $key => $value) {
                    if ($value->fc_free == 0) {
                        $temp_actual_search['fc_business_name'] = $value->fc_business_name;
                        $temp_actual_search['fc_overview'] = $value->fc_overview;
                        $temp_actual_search['fc_type'] = $value->fc_type;
                        $temp_actual_search['fc_img_name'] = $value->fc_img_name;
                        $temp_actual_search['fc_listing_picture'] = $value->fc_listing_picture;
                        $temp_actual_search['fc_id'] = $value->fc_id;
                        $temp_actual_search['fc_free'] = $value->fc_free;
                        $actual_search_result[$value->fc_id] = $temp_actual_search;
                    } else {
                        $temp_free_data['fc_business_name'] = $value->fc_business_name;
                        $temp_free_data['fc_overview'] = $value->fc_overview;
                        $temp_free_data['fc_type'] = $value->fc_type;
                        $temp_free_data['fc_img_name'] = $value->fc_img_name;
                        $temp_free_data['fc_listing_picture'] = $value->fc_listing_picture;
                        $temp_free_data['fc_id'] = $value->fc_id;
                        $temp_free_data['fc_free'] = $value->fc_free;
                        $free_data[$value->fc_id] = $temp_free_data;
                    }
                }
            }

            $data['primium_data_ids'] = $six_primium;
            $data['actual_search_data'] = $actual_search_result;
            $data['free_data'] = $free_data;

            $this->load->view('header');
            $this->load->view('menu', $data);
            $this->load->view('web/search_result', $data);
            $this->load->view('footer');
        } else {
            redirect('web');
        }
    }

    public function get_location_ajax() {
        $get_data = $this->input->get(NULL, TRUE);
        if (!empty($get_data)) {
            $srch_value = $get_data['term'];

            $this->db->distinct();
            $this->db->or_like('suburb', $srch_value);
            $this->db->or_like('council', $srch_value);
            $this->db->or_like('postcode', $srch_value);
            $this->db->or_like('state', $srch_value);
            $this->db->group_by('council');

            $location_list = $this->basic_model->get_record_where('aus_councils', array('suburb', 'council', 'postcode', 'state'));


            $location_data = array();
            $a = array();
            if (!empty($location_list)) {
                foreach ($location_list as $key => $value) {
                    foreach ($value as $search) {
                        $standard = ucfirst(strtolower($search));
                        if (!in_array($standard, array_column($location_data, 'council'))) {
                            if (substr(strtolower($standard), 0, strlen($srch_value)) == strtolower($srch_value)) {
                                $a['council'] = $standard;
                                $a['id'] = $standard;
                                $location_data[] = $a;
                            }
                        }
                    }
                }
            }

            echo json_encode($location_data);
        }
    }

// Function to get the client IP address
    function get_client_ip() {
        $ipaddress = '';
        if (isset($_SERVER['HTTP_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        else if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if (isset($_SERVER['HTTP_X_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        else if (isset($_SERVER['HTTP_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        else if (isset($_SERVER['HTTP_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        else if (isset($_SERVER['REMOTE_ADDR']))
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }

    public function single_venue($fc_id) {

        $fc_id = encrypt_decrypt('decrypt', $fc_id);

        if ($this->session->userdata('user_id')) {
            $ip = $this->get_client_ip();
            $user = $this->session->userdata('user_id');

            $where_user = array('user_id' => $user);
            $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

            $where_view = array('r_view_fc' => $fc_id, 'r_view_user' => $user);
            $view = $this->basic_model->get_record_where('recently_viewed', '', $where_view);

            if (!empty($view)) {
                $update_data = array('r_view_ip' => $ip, 'r_view_created_on' => date('Y-m-d H:i:s'));
                $this->basic_model->update_records('recently_viewed', $update_data, $where_view);
            } else {
                $insert_data = array('r_view_fc' => $fc_id, 'r_view_user' => $user, 'r_view_ip' => $ip, 'r_view_created_on' => date('Y-m-d H:i:s'));
                $this->basic_model->insert_records('recently_viewed', $insert_data);
            }
        }

        $fc_data = array();
        $where = array('fc_id' => $fc_id);

        $data['venue'] = $this->basic_model->get_record_where('function_catering', $column = '', array('fc_id' => $fc_id, 'fc_is_deleted' => 0, 'fc_status' => 1));
        if ($data['venue']) {
            $fc_data = $data['venue'][0];


            $data['extra_detils'] = $this->basic_model->get_record_where('venue_details', $column = '', array('vd_fc_id' => $fc_id));
            $fc_venue_detail = false;
            if ($data['extra_detils']) {
                $fc_venue_details = $data['extra_detils'][0];
            }

            if ($fc_id) {
                $where_venue = array('space_venue' => $fc_id, 'space_status' => 0);
                $spaces = $this->basic_model->get_record_where('venue_spaces', 'space_id, space_name', $where_venue);

                if (!empty($spaces))
                    $fc_data->spaces = $spaces;
            }

            $data['images'] = $this->basic_model->get_record_where('fc_images', 'fc_img_name', $where);
            if ($data['images']) {
                foreach ($data['images'] as $img) {
                    $fc_data->fc_images[] = $img->fc_img_name;
                }
            }

            $data['pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '*', $where);
            if ($data['pdfs']) {
                foreach ($data['pdfs'] as $img) {
                    $fc_data->fc_pdfs[] = $img;
                }
            }

            $fc_data->fc_pricing = '';
            $fc_data->events = '';
            $fc_data->facilities = '';
            $fc_data->features = '';

            if ($fc_data->fc_pricing) {
                $where = 'p_id IN (' . $fc_data->fc_pricing . ')';
                $pricing = $this->basic_model->get_record_where('price_per_head', 'p_name,p_value', $where);
                $fc_data->fc_pricing = $pricing;
            }

            if (!empty($fc_venue_details->vd_events)) {
                $where = 'type="event_type" and id IN (' . $fc_venue_details->vd_events . ')';
                $events = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $fc_data->events = $events;
            }

            if (!empty($fc_venue_details->vd_facilities)) {
                $where = 'type="facilities" and id IN (' . $fc_venue_details->vd_facilities . ')';
                $facilities = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $fc_data->facilities = $facilities;
            }

            if (!empty($fc_venue_details->vd_features)) {
                $where = 'type="features" and id IN (' . $fc_venue_details->vd_features . ')';
                $features = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $fc_data->features = $features;
            }

            $lat = isset($fc_data->lat) ? $fc_data->lat : 0;
            $long = isset($fc_data->lng) ? $fc_data->lng : 0;

            $x = $this->web_model->get_all_venue_review_count($fc_id, $id = '');
            $data['all_row_count'] = $x;
            $data['title'] = $fc_data->fc_business_name;
            $data['nearest_to_me'] = $this->find_nearest($lat, $long);
            $data['venue_data'] = $fc_data;
            $data['venue_review'] = $this->web_model->venue_review($fc_id, DEFAULT_ROW_COUNT_REVIEW_PAGINATION, $id = '');
            //print_r($data['venue_review']);die(5);
            $data['wish_list'] = home_page_data();
            $this->load->view('header', $data);
            $this->load->view('menu', $data);
            $this->load->view('venue/single_venue', $data);
            $this->load->view('footer');
        } else {
            redirect('web');
        }
    }

    public function load_review() {
        $data = array();
        $post_data = $this->input->post(NULL, TRUE);
        $this->load->model('web_model');
        if (!empty($post_data)) {

            $venue_id = $post_data['venue_id'];
            $id = $this->input->post('id');
            $id = isset($id) ? $id : '';
            $x = $this->web_model->get_all_venue_review_count($venue_id, $id);
            $data['all_row_count'] = $x;
            $default_limit = DEFAULT_ROW_COUNT_REVIEW_PAGINATION;
            $id = $this->input->post('id');
            $data['reviews'] = $this->web_model->venue_review($venue_id, $default_limit, $id);
            echo $this->load->view('user/load_user_review', $data, TRUE);
        }
    }

    function single_space() {
//        $this->input->post('space_id') = 1;
        if ($this->input->post('space_id')) {
            $space_id = $this->input->post('space_id');

            $where_venue = array('space_id' => $space_id);
            $space = $this->basic_model->get_record_where('venue_spaces', $colown = '', $where_venue);
            $spaces = $space[0];


            if ($spaces->space_events) {
                $where = 'type="event_type" and id IN (' . $spaces->space_events . ')';
                $events = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $spaces->space_events = $events;
            }

            if ($spaces->space_facilities) {
                $where = 'type="facilities" and id IN (' . $spaces->space_facilities . ')';
                $facilities = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $spaces->space_facilities = $facilities;
            }

            if ($spaces->space_features) {
                $where = 'type="features" and id IN (' . $spaces->space_features . ')';
                $features = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $spaces->space_features = $features;
            }

            echo json_encode($spaces);
        }
    }

    public function single_catering($fc_id) {
        $fc_id = encrypt_decrypt('decrypt', $fc_id);

        if ($this->session->userdata('user_id')) {
            $ip = $this->get_client_ip();
            $user = $this->session->userdata('user_id');

            $where_user = array('user_id' => $user);
            $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

            $where_view = array('r_view_fc' => $fc_id, 'r_view_user' => $user);
            $view = $this->basic_model->get_record_where('recently_viewed', '', $where_view);

            if (!empty($view)) {
                $update_data = array('r_view_ip' => $ip, 'r_view_created_on' => date('Y-m-d H:i:s'));
                $this->basic_model->update_records('recently_viewed', $update_data, $where_view);
            } else {
                $insert_data = array('r_view_fc' => $fc_id, 'r_view_user' => $user, 'r_view_ip' => $ip, 'r_view_created_on' => date('Y-m-d H:i:s'));
                $this->basic_model->insert_records('recently_viewed', $insert_data);
            }
        }

        $fc_data = array();
        $where = array('fc_id' => $fc_id);

        $data['venue'] = $this->basic_model->get_record_where('function_catering', $column = '', array('fc_id' => $fc_id, 'fc_is_deleted' => 0, 'fc_status' => 1));
        if ($data['venue']) {
            $fc_data = $data['venue'][0];


            $data['extra_detils'] = $this->basic_model->get_record_where('catering_details', $column = '', array('cd_fc_id' => $fc_id));
            $fc_venue_detail = false;
            if ($data['extra_detils']) {
                $fc_venue_details = $data['extra_detils'][0];
            }

            if ($fc_id) {
                $where_venue = array('space_venue' => $fc_id, 'space_status' => 0);
                $spaces = $this->basic_model->get_record_where('venue_spaces', 'space_id, space_name', $where_venue);

                if (!empty($spaces))
                    $fc_data->spaces = $spaces;
            }

            $data['images'] = $this->basic_model->get_record_where('fc_images', 'fc_img_name', $where);
            if ($data['images']) {
                foreach ($data['images'] as $img) {
                    $fc_data->fc_images[] = $img->fc_img_name;
                }
            }
            
            $data['pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '*', $where);
            if ($data['pdfs']) {
                foreach ($data['pdfs'] as $img) {
                    $fc_data->fc_pdfs[] = $img;
                }
            }

            $fc_data->fc_pricing = '';
            $fc_data->function_type = '';
            $fc_data->menus = '';
            $fc_data->cuisine = '';
            $fc_data->services = '';
            if ($fc_data->fc_pricing) {
                $where = 'p_id IN (' . $fc_data->fc_pricing . ')';
                $pricing = $this->basic_model->get_record_where('price_per_head', 'p_name,p_value', $where);
                $fc_data->fc_pricing = $pricing;
            }

            if (!empty($fc_venue_details->cd_function_type)) {
                $where = 'type="function_type" and id IN (' . $fc_venue_details->cd_function_type . ')';
                $function_type = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $fc_data->function_type = $function_type;
            }

            if (!empty($fc_venue_details->cd_menus)) {
                $where = 'type="menus" and id IN (' . $fc_venue_details->cd_menus . ')';
                $menus = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $fc_data->menus = $menus;
            }

            if (!empty($fc_venue_details->cd_cuisine)) {
                $where = 'type="cuisine" and id IN (' . $fc_venue_details->cd_cuisine . ')';
                $cuisine = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $fc_data->cuisine = $cuisine;
            }

            if (!empty($fc_venue_details->cd_services)) {
                $where = 'type="services" and id IN (' . $fc_venue_details->cd_services . ')';
                $services = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $fc_data->services = $services;
            }

            $lat = isset($fc_data->lat) ? $fc_data->lat : 0;
            $long = isset($fc_data->lng) ? $fc_data->lng : 0;

            $x = $this->web_model->get_all_venue_review_count($fc_id, $id = '');
            $data['all_row_count'] = $x;
            $data['title'] = $fc_data->fc_business_name;
            $data['nearest_to_me'] = $this->find_nearest($lat, $long);
            $data['venue_data'] = $fc_data;
            $data['venue_review'] = $this->web_model->venue_review($fc_id, DEFAULT_ROW_COUNT_REVIEW_PAGINATION, $id = '');


            $data['wish_list'] = home_page_data();
            $this->load->view('header', $data);
            $this->load->view('menu', $data);
            $this->load->view('catering/single_catering', $data);
            $this->load->view('footer');
        } else {
            redirect('web');
        }
    }

    public function single_catering_old($fc_id) {
        /* $fc_id = encrypt_decrypt('decrypt', $fc_id);

          if ($this->session->userdata('user_id')) {
          $ip = $this->get_client_ip();
          $user = $this->session->userdata('user_id');

          $where_user = array('user_id' => $user);
          $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

          $where_view = array('r_view_fc' => $fc_id, 'r_view_user' => $user);
          $view = $this->basic_model->get_record_where('recently_viewed', '', $where_view);

          if (!empty($view)) {
          $update_data = array('r_view_ip' => $ip, 'r_view_created_on' => date('Y-m-d H:i:s'));
          $this->basic_model->update_records('recently_viewed', $update_data, $where_view);
          } else {
          $insert_data = array('r_view_fc' => $fc_id, 'r_view_user' => $user, 'r_view_ip' => $ip, 'r_view_created_on' => date('Y-m-d H:i:s'));
          $this->basic_model->insert_records('recently_viewed', $insert_data);
          }
          }

          $fc_data = array();
          $where = array('fc_id' => $fc_id);

          $data['catering'] = $this->basic_model->get_record_where('function_catering', $column = '', array('fc_id' => $fc_id, 'fc_is_deleted' => 0, 'fc_status' => 1));
          if (!empty($data['catering'])) {
          $fc_data = $data['catering'][0];

          $data['extra_detils'] = $this->basic_model->get_record_where('catering_details', $column = '', array('cd_fc_id' => $fc_id));

          if ($data['extra_detils']) {
          $fc_catering_details = $data['extra_detils'][0];
          }

          $additonal_radius_area = $this->basic_model->get_record_where('catering_search_radius', 'csr_radius', array('csr_fc_id' => $fc_id, 'csr_status' => 0));
          if (!empty($additonal_radius_area)) {
          $fc_data->additonal_radius = $additonal_radius_area[0]->csr_radius;
          }

          $data['images'] = $this->basic_model->get_record_where('fc_images', 'fc_img_name', $where);
          if ($data['images']) {
          foreach ($data['images'] as $img) {
          $fc_data->fc_images[] = $img->fc_img_name;
          }
          }
          $fc_data->fc_pricing = '';
          $fc_data->function_type = '';
          $fc_data->cd_menus = '';
          $fc_data->cd_services = '';
          $fc_data->cd_cuisine = '';

          if ($fc_data->fc_pricing) {
          $where = 'p_id IN (' . $fc_data->fc_pricing . ')';
          $pricing = $this->basic_model->get_record_where('price_per_head', 'p_name,p_value', $where);
          $fc_data->fc_pricing = $pricing;
          }

          if ($fc_catering_details->cd_function_type) {
          $where = 'type="function_type" and id IN (' . $fc_catering_details->cd_function_type . ')';
          $function_type = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
          $fc_data->function_type = $function_type;
          }

          if ($fc_catering_details->cd_menus) {
          $where = 'type="menus" and id IN (' . $fc_catering_details->cd_menus . ')';
          $menus = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
          $fc_data->cd_menus = $menus;
          }

          if ($fc_catering_details->cd_cuisine) {
          $where = 'type="cuisine" and id IN (' . $fc_catering_details->cd_cuisine . ')';
          $cuisine = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
          $fc_data->cd_cuisine = $cuisine;
          }

          if ($fc_catering_details->cd_services) {
          $where = 'type="services" and id IN (' . $fc_catering_details->cd_services . ')';
          $services = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
          $fc_data->cd_services = $services;
          }


          $x = $this->web_model->get_all_venue_review_count($fc_id, $id = '');
          $data['all_row_count'] = $x;


          $lat = $fc_data->lat;
          $long = $fc_data->lng;
          $data['nearest_to_me'] = $this->find_nearest($lat, $long);
          $data['catering_data'] = $fc_data;
          $data['venue_review'] = $this->web_model->venue_review($fc_id, DEFAULT_ROW_COUNT_REVIEW_PAGINATION, $id = '');
          $data['wish_list'] = home_page_data();
          $data['title'] = $fc_data->fc_business_name;

          $this->load->view('header', $data);
          $this->load->view('menu', $data);
          $this->load->view('catering/single_catering', $data);
          $this->load->view('footer');
          } else {
          redirect('web');
          } */

        $fc_id = encrypt_decrypt('decrypt', $fc_id);

        if ($this->session->userdata('user_id')) {
            $ip = $this->get_client_ip();
            $user = $this->session->userdata('user_id');

            $where_user = array('user_id' => $user);
            $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

            $where_view = array('r_view_fc' => $fc_id, 'r_view_user' => $user);
            $view = $this->basic_model->get_record_where('recently_viewed', '', $where_view);

            if (!empty($view)) {
                $update_data = array('r_view_ip' => $ip, 'r_view_created_on' => date('Y-m-d H:i:s'));
                $this->basic_model->update_records('recently_viewed', $update_data, $where_view);
            } else {
                $insert_data = array('r_view_fc' => $fc_id, 'r_view_user' => $user, 'r_view_ip' => $ip, 'r_view_created_on' => date('Y-m-d H:i:s'));
                $this->basic_model->insert_records('recently_viewed', $insert_data);
            }
        }

        $fc_data = array();
        $where = array('fc_id' => $fc_id);

        $data['venue'] = $this->basic_model->get_record_where('function_catering', $column = '', array('fc_id' => $fc_id, 'fc_is_deleted' => 0, 'fc_status' => 1));
        if ($data['venue']) {
            $fc_data = $data['venue'][0];


            $data['extra_detils'] = $this->basic_model->get_record_where('venue_details', $column = '', array('vd_fc_id' => $fc_id));
            $fc_venue_detail = false;
            if ($data['extra_detils']) {
                $fc_venue_details = $data['extra_detils'][0];
            }

            if ($fc_id) {
                $where_venue = array('space_venue' => $fc_id, 'space_status' => 0);
                $spaces = $this->basic_model->get_record_where('venue_spaces', 'space_id, space_name', $where_venue);

                if (!empty($spaces))
                    $fc_data->spaces = $spaces;
            }

            $data['images'] = $this->basic_model->get_record_where('fc_images', 'fc_img_name', $where);
            if ($data['images']) {
                foreach ($data['images'] as $img) {
                    $fc_data->fc_images[] = $img->fc_img_name;
                }
            }

            $fc_data->fc_pricing = '';
            $fc_data->events = '';
            $fc_data->facilities = '';
            $fc_data->features = '';

            if ($fc_data->fc_pricing) {
                $where = 'p_id IN (' . $fc_data->fc_pricing . ')';
                $pricing = $this->basic_model->get_record_where('price_per_head', 'p_name,p_value', $where);
                $fc_data->fc_pricing = $pricing;
            }

            if (!empty($fc_venue_details->vd_events)) {
                $where = 'type="event_type" and id IN (' . $fc_venue_details->vd_events . ')';
                $events = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $fc_data->events = $events;
            }

            if (!empty($fc_venue_details->vd_facilities)) {
                $where = 'type="facilities" and id IN (' . $fc_venue_details->vd_facilities . ')';
                $facilities = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $fc_data->facilities = $facilities;
            }

            if (!empty($fc_venue_details->vd_features)) {
                $where = 'type="features" and id IN (' . $fc_venue_details->vd_features . ')';
                $features = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                $fc_data->features = $features;
            }

            $lat = isset($fc_data->lat) ? $fc_data->lat : 0;
            $long = isset($fc_data->lng) ? $fc_data->lng : 0;

            $x = $this->web_model->get_all_venue_review_count($fc_id, $id = '');
            $data['all_row_count'] = $x;
            $data['title'] = $fc_data->fc_business_name;
            $data['nearest_to_me'] = $this->find_nearest($lat, $long);
            $data['venue_data'] = $fc_data;
            $data['venue_review'] = $this->web_model->venue_review($fc_id, DEFAULT_ROW_COUNT_REVIEW_PAGINATION, $id = '');
            //echo "<pre>";print_r($data);die(5);
            $data['wish_list'] = home_page_data();
            $this->load->view('header', $data);
            $this->load->view('menu', $data);
            $this->load->view('catering/single_catering', $data);
            $this->load->view('footer');
        } else {
            redirect('web');
        }
    }

    function query_form_submit() {
        $this->load->helper('email_template_helper');
        if ($this->input->post() && $this->session->userdata('user_email')) {

            $query_data = $this->input->post();
            unset($query_data['fc_url']);
            $query_data ['fq_fc_id'] = encrypt_decrypt('decrypt', $query_data ['fq_fc_id']);
            $query_data ['fq_function_date'] = date("Y-m-d", strtotime($query_data ['fq_function_date']));
            $query_data['fq_user'] = $this->session->userdata('user_id');
            $result = $this->basic_model->insert_records('fnc_queries', $query_data, $multiple = FALSE);

            $function_data = $this->basic_model->get_record_where('function_catering', array('fc_type', 'fc_user'), array('fc_id' => $query_data ['fq_fc_id']));

            $query_data['type'] = ($function_data[0]->fc_type == 2) ? 'catering' : 'venue';

            $user_data = $this->basic_model->get_record_where('users', array('user_firstname', 'user_lastname', 'user_email'), array('user_id' => $function_data[0]->fc_user));
            $query_data['email'] = $user_data[0]->user_email;
            $query_data['fc_url'] = $this->input->post('fc_url');
            $query_data['client_name'] = $user_data[0]->user_firstname . ' ' . $user_data[0]->user_lastname;

            query_form_mail($query_data);

            if ($result > 0) {
                echo 'success';
            }
        } else {
            echo 'need_login';
        }
    }

    function add_to_wishlist() {
        if ($this->input->post('v_id') && $this->session->userdata('user_email')) {
            $data['w_venue'] = encrypt_decrypt('decrypt', $this->input->post('v_id'));
            $data['w_user'] = $this->session->userdata('user_id');
            $already_added = $this->basic_model->get_record_where('wish_list', $column = '', $data);
            if (!empty($already_added)) {
                $where = array('w_id' => $already_added[0]->w_id);
                $this->basic_model->delete_records('wish_list', $where);
                echo 'already';
            } else {
                $result = $this->basic_model->insert_records('wish_list', $data, $multiple = FALSE);
                echo 'success';
            }
        } else {
            echo 'need_login';
        }
    }

    function test_mail() {
        $this->load->helper('email_template_helper');
        $send_to_friend['friend_name'] = 'Ritesh Paliwal';
        $send_to_friend['venue_url'] = 'https://www/google.com';
        $send_to_friend['massage'] = 'Hello my friend';
        $send_to_friend['email'] = 'riteshpaliwal88@gmail.com';
        $response = send_to_friend_mail($send_to_friend);
    }

    function send_to_friend() {
        $ses_data = $this->session->userdata();
        $data = $this->input->post();
        $id = $this->input->post('venue_id');
        $venue_id = encrypt_decrypt('decrypt', $id);

        if (!empty($venue_id)) {
            $where = array('fc_id' => $venue_id);
            $data_new = $this->basic_model->get_record_where('function_catering', 'fc_listing_picture', $where);
            $fc_image = !empty($data_new[0]->fc_listing_picture) ? $data_new[0]->fc_listing_picture : 'banner_img.png';

            $listing_img = $fc_image;
            // if(empty($fc_image)){
            //     $listing_img ="cloth-decor-decoration-868330.jpg";
            // }
            // print_r($listing_img);

            $where_area = array('area_venue' => $venue_id);
            $data_area = $this->basic_model->get_record_where('additional_area', 'area_name', $where_area);

            $near_area1 = !empty($data_area[0]->area_name) ? $data_area[0]->area_name : '';
            $near_area2 = !empty($data_area[1]->area_name) ? $data_area[1]->area_name : '';
            $near_area3 = !empty($data_area[2]->area_name) ? $data_area[2]->area_name : '';
        }

        $this->load->helper('email_template_helper');

        if ($this->input->post() && $this->session->userdata('user_email')) {
            $mail_data = $this->input->post();
            // $user_profile =  $ses_data['user_image'];
            $user_profile = !empty($ses_data['user_image']) ? $ses_data['user_image'] : 'FnC_user_icon.png';
            // print_r($user_profile);die;

            $response = send_to_friend_mail($mail_data, $user_profile, $listing_img, $near_area1, $near_area2, $near_area3);
            if ($response > 0) {
                echo 'success';
            } else {
                echo 'false';
            }
        } else {
            echo 'need_login';
        }
    }

    public function check_review() {
        if ($this->input->post('fnc')) {
            if ($this->session->userdata('user_id')) {
                $fc_id = encrypt_decrypt('decrypt', $this->input->post('fnc'));
                $where = array('f_user' => $this->session->userdata('user_id'), 'f_fc_id' => $fc_id);
                $check_feed = $this->basic_model->get_record_where('feedback', '', $where);

                $where_block = array('f_user' => $this->session->userdata('user_id'), 'f_fc_id' => $fc_id, 'f_status' => 2);
                $check_feed_blocked = $this->basic_model->get_record_where('feedback', '', $where_block);
                if (!empty($check_feed_blocked)) {
                    echo json_encode(array('status' => FALSE, 'msg' => 'You have already provided review for this venue but blocked by admin, if any query <a href=' . base_url("web/contact_us") . ' class="error_link"> contact us </a>'));
                } elseif (!empty($check_feed)) {
                    echo json_encode(array('status' => FALSE, 'msg' => 'You have already provided review for this venue.'));
                } else {
                    echo json_encode(array('status' => TRUE, 'msg' => '', 'href' => site_url('user/submit_feed') . '/' . $this->input->post('fnc')));
                }
            } else {
                echo json_encode(array('status' => FALSE, 'msg' => 'Please login first to write a review. <br>Please <a href="' . base_url("user_login") . '">Click here</a>'));
            }
        }
    }

    public function update_venue_catering() {
        $post_data = $this->input->post(NULL, TRUE);
        if (!empty($post_data)) {
            $this->basic_model->update_records('function_catering', array('fc_is_deleted' => 1), array('fc_id' => $post_data['id']));
            $response_ary = array('success' => 1);
        } else {
            $response_ary = array('success' => 0);
        }
        echo json_encode($response_ary);
    }

    public function find_nearest($lat, $long) {
        $near_record = $this->web_model->find_nearest($lat, $long);
        return $near_record;
    }

    public function image_croping() {
        if ($this->input->post()) {
            $img_name = 'new_image' . mt_rand(100000, 1000000000) . '.jpg';
            $downloaded_image_url = $_FILES['file']['tmp_name'];
            $this->load->library('ImageRoation/Image_autorotate', array('filepath' => $downloaded_image_url));

            if ($this->input->post('upload_type') == 'crope') {
                $data = $this->input->post('image_dimention');
                $dimesion = json_decode($data);
                $config = array();
                $this->load->library('image_lib');
                $config['image_library'] = 'gd2';
                $config['source_image'] = $downloaded_image_url;
                $config['x_axis'] = $dimesion->x1;
                $config['y_axis'] = $dimesion->y1;
                $config['maintain_ratio'] = false;
                $config['overite'] = false;
                $config['width'] = (int) $dimesion->width;
                $config['height'] = (int) $dimesion->height;
                $config['quality'] = '100%';
                $config['Orientation'] = false;

                if ($this->input->post('space')) {
                    $config['new_image'] = 'uploads/venue_spaces/temp/' . $img_name;
                } else {
                    $config['new_image'] = 'uploads/fc_images/temp/' . $img_name;
                }
                $this->image_lib->initialize($config);
                if ($this->image_lib->crop()) {
                    $file_data = array(
                        'url' => base_url($config['new_image']),
                        'img_name' => $img_name
                    );

                    echo json_encode($file_data);
                } else {
                    echo $this->image_lib->display_errors();
                }
                $this->image_lib->clear();
            } else {
                $this->load->library('upload');

                if ($this->input->post('space')) {
                    $image_type = 'venue_spaces';
                    $this->upload->initialize($this->set_upload_options('venue_spaces'));
                } else {
                    $image_type = 'fc_images';
                    $this->upload->initialize($this->set_upload_options('fc_images'));
                }
                if (!$this->upload->do_upload("file")) {
                    $error = $this->upload->display_errors();
                } else {
                    $dataInfo[] = $this->upload->data();
                    $i_data = $this->upload->data();
                    $file_data = array(
                        'url' => base_url('') . 'uploads/' . $image_type . '/temp/' . $i_data['file_name'],
                        'img_name' => $i_data['file_name']
                    );

                    echo json_encode($file_data);
                }
            }
        }
    }

    public function set_upload_options($image_for) {
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/' . $image_for . '/temp/';
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = '0';
        $config['overwrite'] = FALSE;
        return $config;
    }

    public function advertise() {
        $data['title'] = 'Advertise';
        $this->load->helper('email_template_helper');
//        $data = '';
        // print_r($this->input->post);
        if ($this->input->post()) {
            if ($this->input->post('g-recaptcha-response')) {

                $post_data = http_build_query(
                        array(
                            'secret' => '6LferDsUAAAAAN_n7XFUr9a-s6gnarMzR5VJ26qk',
                            'response' => $this->input->post('g-recaptcha-response'),
                            'remoteip' => $_SERVER['REMOTE_ADDR']
                        )
                );
                // print_r($post_data);die;

                $opts = array('http' =>
                    array(
                        'method' => 'POST',
                        'header' => 'Content-type: application/x-www-form-urlencoded',
                        'content' => $post_data
                    )
                );
                // print_r($opts);die;

                $context = stream_context_create($opts);
                $response = file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
                $result = json_decode($response, TRUE);

                if ($result) {
                    $advertise_data = $this->input->post();
                    // print_r($advertise_data);
                    advertise_mail($advertise_data);
                    unset($advertise_data['g-recaptcha-response']);
                    $this->basic_model->insert_records('advertise', $advertise_data);
                    // $data['success'] = 'Your message has been submitted successfully';
                    $this->session->set_flashdata('success', 'Your message has been submitted successfully!');
                    redirect('web/advertise');
                }
                // else {
                //     $data['error'] = 'Please verify captcha!';
                // }
            } else {

                $this->session->set_flashdata('error', 'Please verify captcha!');
                redirect('web/advertise');
            }
        }

        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('web/advertise', $data);
        $this->load->view('footer');
    }

    function checkVoucher($voucherParameter = false) {
        checkVoucherHelper();
    }

    function removVoucher() {
        $this->load->library('cart');
        if ($this->input->post('remove_voucher')) {
            $content = $this->cart->contents();
            foreach ($content as $cart) {
                if ($cart['id'] == 'voucher_id') {
                    $data = array(
                        'rowid' => $cart['rowid'],
                        'qty' => 0
                    );
                    $this->cart->update($data);
                }
            }

            $total = $this->cart->total();
            echo json_encode(array('status' => true, 'total' => $total));
        }
    }

    public function search_suburb() {
        if ($this->input->post('term')) {
            $search_term = $this->input->post('term');

            $where_term = "suburb LIKE '$search_term%'";
            $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);

            $search_result = array();

            if (!empty($coucils)) {
                $item_arr = array();

                foreach ($coucils as $key => $value) {
                    $item_arr[] = array('id' => $value->id, 'suburb' => $value->suburb, 'postcode' => $value->postcode, 'state' => $value->state, 'council' => $value->council, 'council_id' => $value->council_id, 'zoom' => $value->zoom);
                }

                $search_result['items'] = $item_arr;

                echo json_encode($search_result);
            }
        }
    }

    public function search_postcode() {
        if ($this->input->post('term')) {
            $search_term = $this->input->post('term');

            $where_term = "postcode LIKE '$search_term%'";
            $this->db->group_by('postcode');
            $coucils = $this->basic_model->get_record_where('aus_councils', array('postcode', 'suburb', 'state', 'council', 'council_id', 'zoom', 'id'), $where_term);


            $search_result = array();

            if (!empty($coucils)) {
                $item_arr = array();

                foreach ($coucils as $key => $value) {
                    $item_arr[] = array('id' => $value->id, 'suburb' => $value->suburb, 'postcode' => $value->postcode, 'state' => $value->state, 'council' => $value->council, 'council_id' => $value->council_id, 'zoom' => $value->zoom);
                }

                $search_result['items'] = $item_arr;

                echo json_encode($search_result);
            }
        }
    }

    public function get_on_update_council() {
        if ($this->input->post('suburb')) {
            $subrub = $this->input->post('suburb');
            $coordinate = $this->basic_model->get_record_where('aus_councils', '', array('suburb' => $subrub));
            $item_arr = array();
            if (!empty($coordinate)) {
                $item_arr = array(
                    'status' => true,
                    'id' => $coordinate[0]->id,
                    'suburb' => $coordinate[0]->suburb,
                    'postcode' => $coordinate[0]->postcode,
                    'state' => $coordinate[0]->state,
                    'council' => $coordinate[0]->council,
                    'council_id' => $coordinate[0]->council_id,
                    'zoom' => $coordinate[0]->zoom,
                    'lat' => $coordinate[0]->lat,
                    'lng' => $coordinate[0]->lng,
                );
            } else {
                $item_arr = array('status' => false);
            }
        }

        echo json_encode($item_arr);
    }

    function remove_change() { // function for remove image
        if ($this->input->post()) {
            $fc_image_type = $this->input->post('fc_image_type');
            $img_id = encrypt_decrypt('decrypt', $this->input->post('img_id'));
            $flush_type = $this->input->post('flush_type');

            // fc_image_type: here fc_image_type is type of image like (1- for main image, 2- for slider images,3 - for space )
            $status = false;
            $table = false;
            if ($fc_image_type == 1) {
                $table = 'function_catering';
                $data = array('fc_listing_picture' => '', 'fc_modified_on' => date('Y-m-d h:i:sa'));
                $where = array('fc_id' => $img_id);
                $status = $this->basic_model->update_records($table, $data, $where);
            } elseif ($fc_image_type == 2) {
                $table = 'fc_images';
                $data = array('fc_img_name' => '', 'fc_img_modified_on' => date('Y-m-d h:i:sa'));
                $where = array('fc_img_id' => $img_id);
                $status = $this->basic_model->delete_records($table, $where);
            } elseif ($fc_image_type == 3) {
                $table = 'venue_spaces';
                $data = array('space_image' => '', 'space_modified' => date('Y-m-d h:i:sa'));
                $where = array('space_id' => $img_id);
                $status = $this->basic_model->update_records($table, $data, $where);
            }
            echo $this->db->last_query();

            echo json_encode(array('status' => $status));
        }
    }

    function remove_pdf() { // function for remove pdf
        if ($this->input->post()) {
            $fc_pdf_type = $this->input->post('fc_pdf_type');
            $pdf_id = encrypt_decrypt('decrypt', $this->input->post('pdf_id'));
            $flush_type = $this->input->post('flush_type');
            $status = false;
            $table = false;
            $table = 'fc_pdfs';
            $where = array('fc_pdf_id' => $pdf_id);
            $getUnlinkData = $this->basic_model->get_record_where($table, array('fc_pdf_name', 'fc_pdf_image'), $where);
            $data = array('fc_pdf_name' => '', 'fc_pdf_modified_on' => date('Y-m-d h:i:sa'));
            $status = $this->basic_model->delete_records($table, $where);
            if ($status) {
                unlink("uploads/venue_pdf/" . $getUnlinkData[0]->fc_pdf_name);
                unlink("uploads/venue_pdf_image/" . $getUnlinkData[0]->fc_pdf_image);
            }
            echo $this->db->last_query();
            echo json_encode(array('status' => $status));
        }
    }

    function stripe_webhook() {
        $this->load->helper('stripe_subscription_helper');
        $file_path = APPPATH . 'logs/stripe_log.log';

        $input = @file_get_contents('php://input');
        strip_webhook($input);
        $return = file_put_contents($file_path, json_encode($event_json) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }

    public function new_space_page() {
        $data = array();
        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('venue/new_space_page');
        $this->load->view('footer', $data);
    }

    public function test_mail_new() {
        $this->load->helper('email_template_helper');
        customer_confirmation_mail_test();
    }

    // <-new changes->
    public function check_valid_address() {
        $city = $_POST['city'];
        $postcode = $_POST['postcode'];
        $state = $_POST['user_state'];
        $aus_councils_count = $this->basic_model->get_row('tbl_suburb_state', $where = array('city' => $city, 'postcode' => $postcode, 'state' => $state), array());

        if (!empty($aus_councils_count)) {
            echo json_encode(array("status" => true, "exist" => 1));
            //echo json_encode("status"->true,"exist"->1);
        } else {
            echo json_encode(array("status" => true, "exist" => 0));
        }
    }

}
