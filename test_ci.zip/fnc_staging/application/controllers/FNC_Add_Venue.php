<?php

require_once APPPATH . 'validation/formCustomValidation.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

defined('BASEPATH') OR exit('No direct script access allowed');

class FNC_Add_Venue extends CI_Controller {

    use formCustomValidation;

    public function __construct() {
        parent::__construct();


        $this->load->library('cart');
        $this->load->library('form_validation');
        $this->load->helper('venue_helper');


        if (!$this->session->userdata('user_email'))
            redirect('login/user_login');
    }

    public function add_venue($fc_id = false) {
        $permission = venue_permission();
        if (!empty($permission) && $permission->bus_auth_status == 1) {
            
        } else {
            redirect(base_url('request'));
        }


        $user_id = $this->session->userdata('user_id');
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where = array('user_id' => $user_id));

        $data['free'] = '';
        $data['plan_id'] = '';

        $this->cart->destroy();
        if ($this->input->get('f1')) {
            $venue_id = encrypt_decrypt('decrypt', $this->input->get('f1'));

            $where_fc = array('fc_id' => $venue_id, 'fc_user' => $user_id, 'fc_status' => 5);
            $venue = $this->basic_model->get_row('function_catering', $where_fc, array());



            if (!empty($venue)) {
                $data['draft_venue'] = $venue;
                /* --------load cart data--------- */
                $draft_cart = '';

                if (!empty($venue->fc_cart_data)) {
                    $draft_cart = json_decode($venue->fc_cart_data, true);
                }

                if (!empty($draft_cart)) {
                    if (in_array(1, array_column($draft_cart, 'id'))) {
                        $response = $this->addToCartPlan(1);
                        $data['plan_id'] = 1;
                        $data['free'] = 0;
                    } elseif (in_array(2, array_column($draft_cart, 'id'))) {
                        $response = $this->addToCartPlan(2);
                        $data['plan_id'] = 2;
                        $data['free'] = 0;
                    }

                    $selectedCouncilIds = array();
                    foreach ($draft_cart as $item) {
                        if ($item['id'] == 3) {
                            $selectedCouncilIds[] = $item['options']['council_id'];
                        } elseif ($item['id'] == 4) {
                            $this->add_to_cart_space(1, $item['options']);
                        }
                    }

                    //--------additional area Details----------//
                    if (!empty($selectedCouncilIds)) {
                        $where_term = "council_id IN (" . implode(', ', $selectedCouncilIds) . ") ";
                        $selected_council = $this->basic_model->get_record_where('aus_councils', 'distinct(council_id),lat,lng,council', $where_term);
                        $this->add_to_cart_addional_area($selected_council);
                        $data['draft_additinal_council'] = $selected_council;
                    }
                }

                /* -----------------get space of venue----------- */
                $where_space = array('space_venue' => $venue_id);

                $data['draft_venue_space'] = $this->basic_model->get_record_where('venue_spaces', '', $where_space);

                /* -------------------draft venue details--------------- */
                $where_details = array('vd_fc_id' => $venue_id);
                $data['draft_venue_details'] = $this->basic_model->get_row('venue_details', $where_details, '');

                /* ---------------------get fc images ---------------- */
                $where_images = array('fc_id' => $venue_id);
                $data['draft_venue_images'] = $this->basic_model->get_record_where('fc_images', '', $where_images);

                /* ---------------------get fc pdfs ---------------- */
                //$where_pdfs = array('fc_id' => $venue_id);
                //$data['draft_venue_pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '', $where_pdfs);
            } else {
                redirect('my_venues');
            }

            if ($venue->fc_free == 1) {
                $data['plan_id'] = 0;
                $data['free'] = 1;
            }
        }

        $venue_id = encrypt_decrypt('decrypt', $this->input->get('f1'));

        $where_fc = array('fc_id' => $venue_id, 'fc_user' => $user_id);
        $venue = $this->basic_model->get_row('function_catering', $where_fc, array());

        if (!empty($venue->fc_status) == 5) {
            $data['last_date'] = isset($venue->fc_modified_on) ? $venue->fc_modified_on : '';
        } else {
            $data['last_date'] = '';
        }




        $where = 'pro_id IN (1,2)';
        $data['packs'] = $this->basic_model->get_record_where('products', '', $where);

        $data['title'] = 'Add venue';

        $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');
        $where_events = array('type' => 'event_type', 'status' => 1);
        $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

        $where_features = array('type' => 'features', 'status' => 1);
        $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);

        $where_facilities = array('type' => 'facilities', 'status' => 1);
        $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

//        echo '<pre>';
//        print_r($data);
//        echo '</pre>';
        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('venue/add_venue/add_venue', $data);
        $this->load->view('footer');
    }

    public function business_details_add_update() {
        $user_id = $this->session->userdata('user_id');
        if ($this->input->post()) {

            $user_id = $this->session->userdata('user_id');


            $data = $this->input->post();
            $data = $this->security->xss_clean($data);

            $fc_data = array('fc_user' => isset($user_id) ? $user_id : '',
                'fc_business_name' => isset($data['venue_business_name']) ? $data['venue_business_name'] : '',
                'fc_company_name' => isset($data['venue_company_name']) ? $data['venue_company_name'] : '',
                'fc_state' => isset($data['venue_state']) ? $data['venue_state'] : 'Vic',
                'fc_suburb' => isset($data['venue_suburb']) ? $data['venue_suburb'] : '',
                'fc_street' => isset($data['venue_street']) ? $data['venue_street'] : '',
                'fc_postcode' => isset($data['venue_postcode']) ? $data['venue_postcode'] : '',
                'fc_country' => isset($data['venue_country']) ? $data['venue_country'] : '',
                'fc_abn' => isset($data['venue_abn']) ? $data['venue_abn'] : '',
                'fc_contact_name' => isset($data['venue_contact_name']) ? $data['venue_contact_name'] : '',
                'fc_phone_no' => isset($data['venue_phone_no']) ? $data['venue_phone_no'] : '',
                'fc_email' => isset($data['venue_email']) ? $data['venue_email'] : '',
                'fc_lat' => isset($data['fc_lat']) ? $data['fc_lat'] : '',
                'fc_lng' => isset($data['fc_lng']) ? $data['fc_lng'] : '',
                'fc_modified_on' => date('Y-m-d H:i:s'),
                'fc_created_date' => date('Y-m-d H:i:s'),
                'fc_status' => 5,
                'fc_unit' => $data['venue_unit']
            );

            $fc_id = $this->save_venue($fc_data, $data['fc_id']);

            echo json_encode(array("status" => true, "fc_id" => $fc_id));
            exit();
        }
    }

    public function map_image_insert($fc_id = null) {
        $user_id = $this->session->userdata('user_id');
        $fc_id = encrypt_decrypt('decrypt', $fc_id);
        //file upload code 
        if (!empty($fc_id)) {
            if (!is_dir('uploads/' . 'venue_map_image')) {
                mkdir('./uploads/' . 'venue_map_image', 0777, TRUE);
            }
            $config = [];
            $_FILES['fc_map_image']['name'] = 'my_map.png';
            if (!empty($_FILES['fc_map_image']['name'])) {
                $config['upload_path'] = 'uploads/venue_map_image/';
                $config['allowed_types'] = 'octet-stream|png';
                $config['file_name'] = 'pdf_map_image' . strtotime('ymdhis' . '.png');
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                if ($this->upload->do_upload('fc_map_image')) {
                    $uploadData1 = $this->upload->data();
                    $fc_data['fc_map_image'] = $uploadData1['file_name'];
                } else {
                    print_r($this->upload->display_errors());
                }
            } else {
                $fc_data['fc_map_image'] = '';
            }
            $this->basic_model->update_records('function_catering', $fc_data, array('fc_id' => $fc_id));
        }
    }

    public function save_venue($fc_data, $fc_id) {
        $fc_id = encrypt_decrypt('decrypt', $fc_id);
        $user_id = $this->session->userdata('user_id');

        $fc_data['fc_type'] = 1;
        $fc_data['fc_modified_on'] = date('Y-m-d');
        $fc_data['fc_user'] = $this->session->userdata('user_id');
        $fc_data['fc_status'] = 5;
        $fc_data['fc_user'] = $user_id;

        if (isset($fc_id) && !empty($fc_id)) {
            $this->basic_model->update_records('function_catering', $fc_data, array('fc_id' => $fc_id, 'fc_user' => $user_id));
        } else {
            $fc_id = $this->basic_model->insert_records('function_catering', $fc_data);
            $inProgressData = $this->basic_model->insert_records('fc_in_progress', array('venue_catering_id' => $fc_id));
        }

        $fc_id = encrypt_decrypt('encrypt', $fc_id);
        return $fc_id;
    }

    // function using for business detail and package progress bar percent
    public function submit_progress_business_package() {
        $businessStep1 = $this->input->post('step1');
        $businessStep2 = $this->input->post('step2');
        $packageSteps = $this->input->post('packageSteps');
        $venueId = $this->input->post('venue_id');
        $fc_id = encrypt_decrypt('decrypt', $venueId);
        $totalBusinessSteps = floatval($businessStep1) + floatval($businessStep2);
        if ($fc_id > 0) {
            if ((!empty($packageSteps))) {
                $inProgressData = array(
                    "package" => $packageSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($businessStep1)) && (!empty($businessStep2))) {
                $inProgressData = array(
                    "business_detail" => $totalBusinessSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif (!empty($businessStep1)) {
                $inProgressData = array(
                    "business_detail" => $totalBusinessSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            }
        }
    }

    // function using for venue detail and page layout and listing area progress bar percent
    public function submit_progress_venue_detail() {
        $venueDetailstep1 = $this->input->post('step1');
        $venueDetailstep2 = $this->input->post('step2');
        $venueDetailstep3 = $this->input->post('step3');
        $venueDetailstep4 = $this->input->post('step4');
        $step5pageLayout = $this->input->post('step5pageLayout');
        $step6ListingArea = $this->input->post('step6ListingArea');
        $venueId = $this->input->post('venue_id');
        $fc_id = encrypt_decrypt('decrypt', $venueId);
        $totalVenueDetailSteps = floatval($venueDetailstep1) + floatval($venueDetailstep2) + floatval($venueDetailstep3) + floatval($venueDetailstep4);
        if ($fc_id > 0) {
            if (!empty($step6ListingArea)) {
                $inProgressData = array(
                    "listing_area" => $step6ListingArea,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif (!empty($step5pageLayout)) {
                $inProgressData = array(
                    "page_layout" => $step5pageLayout,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($venueDetailstep1)) && (!empty($venueDetailstep2)) && (!empty($venueDetailstep3)) && (!empty($venueDetailstep4))) {
                $inProgressData = array(
                    "venue_catering_detail" => $totalVenueDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($venueDetailstep1)) && (!empty($venueDetailstep2)) && (!empty($venueDetailstep3))) {
                $inProgressData = array(
                    "venue_catering_detail" => $totalVenueDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($venueDetailstep1)) && (!empty($venueDetailstep2))) {
                $inProgressData = array(
                    "venue_catering_detail" => $totalVenueDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif (!empty($venueDetailstep1)) {
                $inProgressData = array(
                    "venue_catering_detail" => $totalVenueDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            }
        }
    }

    // function using for space and payment progress bar percent
    public function submit_progress_space() {
        $spaceStep1 = $this->input->post('step1');
        $spaceStep2 = $this->input->post('step2');
        $spaceStep3 = $this->input->post('step3');
        $spaceStep4 = $this->input->post('step4');
        $step5Payment = $this->input->post('step5Payment');
        $venueId = $this->input->post('venue_id');
        $fc_id = encrypt_decrypt('decrypt', $venueId);
        $totalVenueDetailSteps = floatval($spaceStep1) + floatval($spaceStep2) + floatval($spaceStep3) + floatval($spaceStep4);
        if ($fc_id > 0) {
            if (!empty($step5Payment)) {
                $inProgressData = array(
                    "payment" => $step5Payment,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($spaceStep1)) && (!empty($spaceStep2)) && (!empty($spaceStep3)) && (!empty($spaceStep4))) {
                $inProgressData = array(
                    "spaces" => $totalVenueDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($spaceStep1)) && (!empty($spaceStep2)) && (!empty($spaceStep3))) {
                $inProgressData = array(
                    "spaces" => $totalVenueDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($spaceStep1)) && (!empty($spaceStep2))) {
                $inProgressData = array(
                    "spaces" => $totalVenueDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif (!empty($spaceStep1)) {
                $inProgressData = array(
                    "spaces" => $totalVenueDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            }
        }
    }

    public function getProductDetails($pro_id) {
        $where_pro = array('pro_id' => $pro_id);
        $result = $this->basic_model->get_row('products', $where_pro, $colown = array('pro_id', 'pro_title, pro_price, pro_curr, pro_pay_type'));

        return $result;
    }

    function choose_plan() {
        $data = $this->input->post();

        if ($this->input->post('pack_id')) {
            $pro_id = $this->input->post('pack_id');

            // check cart content
            $cart_content = $this->cart->contents();

            if (!empty($cart_content)) {
                // change plan
                $this->change_plan($pro_id);
            } else {
                $row_id = $this->addToCartPlan($pro_id);
            }

            $cart_content = $this->cart->contents();

            $cart_total = $this->cart->total();

            $fc_data = array('fc_cart_data' => json_encode($cart_content), 'fc_free' => 0);
            $fc_id = $this->save_venue($fc_data, $data['fc_id']);

            echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'cart_total' => $cart_total, 'fc_id' => $fc_id, 'isfree' => 2));
        }
    }

    function choose_free_plan() {
        $data = $this->input->post();
        $data['cart_content'] = 0;
        $data['sub_total'] = 0;
        $data['gst'] = 0;
        $data['total'] = 0;
        //$data['freeplane'] = 'freeplane';
        if (!empty($data)) {
            $fc_data = array('fc_free' => 1);
            $fc_id = $this->save_venue($fc_data, $data['fc_id']);

            $cart_content = $this->cart->contents();
            if (!empty($cart_content)) {

                foreach ($cart_content as $val) {
                    if ($val['id'] == 4) {
                        $where = $val['options']['space_id'];
                        $this->basic_model->delete_records('venue_spaces', $where);
                    }
                }
            }

            $this->cart->destroy();
            $cart = $this->load->view('venue/add_venue/cart_data', $data, true);
            $cart_count = 1;
            echo json_encode(array('status' => TRUE, 'fc_id' => $fc_id, 'cart_count' => $cart_count, 'cart' => $cart));
        }
    }

    function addToCartPlan($pro_id) {
        $productData = $this->getProductDetails($pro_id);

        if (!empty($productData) && ($pro_id == 1 or $pro_id == 2)) {
            $price = $productData->pro_price;

            $data = array(
                'id' => $pro_id,
                'qty' => 1,
                'price' => $price,
                'name' => 'Product-ID-' . $productData->pro_id
            );

            return $row_id = $this->cart->insert($data);
        }
    }

    function removePlan() {
        $cart_content = $this->cart->contents();

        if (!empty($cart_content)) {
            foreach ($cart_content as $key => $val) {
                $val = (object) $val;
                if ($val->id == 1 || $val->id == 2) {
                    $data = array(
                        'rowid' => $key,
                        'qty' => 0
                    );

                    $this->cart->update($data);
                }
            }
        }
    }

    function getCurrentChoosePlan() {
        $cart_content = $this->cart->contents();

        if (!empty($cart_content)) {
            foreach ($cart_content as $key => $val) {
                $val = (object) $val;
                if ($val->id == 1 || $val->id == 2) {
                    $productData = $this->getProductDetails($val->id);

                    return $productData->pro_pay_type;
                }
            }
        } else {
            return false;
        }
    }

    public function change_plan($pro_id) {
        // first remove plan
        $this->removePlan();

        // add new plan
        $this->addToCartPlan($pro_id);


        $cart_content = $this->cart->contents();

        // change all product priceing according to new plan
        if (!empty($cart_content)) {

            foreach ($cart_content as $val) {
                if ($val['id'] != $pro_id) {
                    $p_id = $val['id'];

                    $rowid = $val['rowid'];
                    $qty = $val['qty'];

                    $productData = $this->getProductDetails($p_id);

                    if (!empty($productData)) {
                        $p_price = $productData->pro_price;
                        $p_curr = $productData->pro_curr;

                        $term = $this->getCurrentChoosePlan();

                        if ($term == 'month') {
                            $p_price = $p_price * 30;
                        } elseif ($term == 'year') {
                            $p_price = $p_price * 365;
                        }

                        if ($p_curr == 1)
                            $p_price = $p_price / 100;

                        $p_data = array(
                            'rowid' => $rowid,
                            'qty' => $qty,
                            'price' => $p_price
                        );

                        $this->cart->update($p_data);
                    }
                }
            }
        }
    }

    public function venue_pdf_details($fcId = null) {
        $fc_id = encrypt_decrypt('decrypt', $fcId);
        $where_pdfs = array('fc_id' => $fc_id);
        $data['draft_venue_pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '', $where_pdfs);
        $this->load->view('venue/add_venue/venue_pdf_details', $data);
    }

    public function venue_details() {

        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');
        $where_events = array('type' => 'event_type', 'status' => 1);
        $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

        $where_facilities = array('type' => 'facilities', 'status' => 1);
        $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

        $where_features = array('type' => 'features', 'status' => 1);
        $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);

        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('venue/venue_details', $data);
        $this->load->view('footer');
    }

    public function venue_details_add_update() {
        $data = $this->input->post();
        $data = $this->security->xss_clean($data);

//        print_r($_FILES);

        if ($this->input->post()) {
            $fc_data = array('fc_pricing' => '');

            $fc_data['fc_overview'] = ($data['venue_overview']);
            if ($data['fc_details_select'] == 'true') {
                $fc_data['fc_details_select'] = 1;
                $fc_data['fc_details'] = ($data['fc_details']);
            } else {
                $fc_data['fc_details_select'] = 0;
                $fc_data['fc_details'] = '';
            }

            $fc_data['fc_min_guest'] = $data['venue_min_guest'];
            $fc_data['fc_max_guest'] = $data['venue_max_guest'];


            if (!empty($data['venue_pricing'])) {
                $fc_data['fc_pricing'] = implode(',', $data['venue_pricing']);
            }

            $venue_details = array('vd_events' => '', 'vd_facilities' => '', 'vd_features' => '');

            if (!empty($data['venue_events'])) {
                $venue_details['vd_events'] = implode(',', $data['venue_events']);
            }
            if (!empty($data['venue_facilities'])) {
                $venue_details['vd_facilities'] = implode(',', $data['venue_facilities']);
            }
            if (!empty($data['venue_features'])) {
                $venue_details['vd_features'] = implode(',', $data['venue_features']);
            }

            if (!empty($venue_details)) {
                $fc_id = encrypt_decrypt('decrypt', $data['fc_id']);

                $venue_details['vd_fc_id'] = $fc_id;

                $check_venue_details = $this->basic_model->get_record_where('venue_details', array('vd_fc_id'), array('vd_fc_id' => $fc_id));

                if (!empty($check_venue_details)) {
                    $this->basic_model->update_records('venue_details', $venue_details, array('vd_fc_id' => $fc_id));
                } else {
                    $this->basic_model->insert_records('venue_details', $venue_details);
                }

                if (!is_dir('uploads/' . 'venue_pdf_image')) {
                    mkdir('./uploads/' . 'venue_pdf_image', 0777, TRUE);
                }
                $upload_dir = 'uploads/venue_pdf_image';
                //file upload code 
                $pdfData = array();
                $pdf = '';
                $pdfImage = '';
                $pdfTitleName = '';
                $pdf_id = encrypt_decrypt('decrypt', $data['pdf_id']);
                $pdf_title = '';
                if ($data['fc_details_select'] == 'true') {
                    if (!is_dir('uploads/' . 'venue_pdf')) {
                        mkdir('./uploads/' . 'venue_pdf', 0777, TRUE);
                    }
                    for ($i = 1; $i <= 4; $i++) {
                        if (!empty($data['pdf_title_' . $i])) {
                            $pdf_title = $data['pdf_title_' . $i];
                        }
                        if (!empty($data['venue_pdf_' . $i])) {
                            $pdf = $data['venue_pdf_' . $i];
                        }
                        if (!empty($data['fc_pdf_image_' . $i])) {
                            $pdfImage = $data['fc_pdf_image_' . $i];
                        }
                        if (!empty($_FILES['venue_pdf_' . $i]['name'])) {
                            $config['upload_path'] = 'uploads/venue_pdf/';
                            $config['allowed_types'] = 'pdf';
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            if ($this->upload->do_upload('venue_pdf_' . $i)) {
                                $uploadData = $this->upload->data();
                                $pdf = $uploadData['file_name'];
                                $config = [];
                                $_FILES['fc_pdf_image_' . $i]['name'] = 'my_blob.png';
                                if (!empty($_FILES['fc_pdf_image_' . $i]['name'])) {
                                    $config['upload_path'] = 'uploads/venue_pdf_image/';
                                    $config['allowed_types'] = 'octet-stream|png';
                                    $config['file_name'] = 'pdf_image_header' . strtotime('ymdhis' . '.png');
                                    $this->load->library('upload', $config);
                                    $this->upload->initialize($config);
                                    if ($this->upload->do_upload('fc_pdf_image_' . $i)) {
                                        $uploadData1 = $this->upload->data();
                                        $pdfImage = $uploadData1['file_name'];
                                    } else {
                                        print_r($this->upload->display_errors());
                                    }
                                } else {
                                    $pdfImage = '';
                                }
                            } else {
                                $pdf = '';
                            }
                        }
                    }
                    $pdfData = array('fc_id' => $fc_id, 'fc_pdf_title_name' => $pdf_title, 'fc_pdf_name' => $pdf, 'fc_pdf_image' => $pdfImage);
                    if (isset($pdf_id) && !empty($pdf_id)) {
                        $where = array('fc_pdf_id' => $pdf_id);
                        $fc_pdf_id = $this->basic_model->update_records('fc_pdfs', $pdfData, $where);
                        $pdf_url = base_url('uploads/venue_pdf_image') . '/';
                        echo json_encode(array('status' => true, "fc_id" => $fc_id, "fc_pdf_id" => encrypt_decrypt('encrypt', $pdf_id), "pdf_image_name" => $pdf, "pdf_image_path" => $pdf_url . $pdfImage, "fc_pdf_title_name" => $pdf_title, "fc_pdf_image_name" => $pdfImage));
                        exit();
                    } else {
                        if ((!empty($pdf_title)) || (!empty($pdf))) {
                            $fc_pdf_id = $this->basic_model->insert_records('fc_pdfs', $pdfData);
                            $pdf_url = base_url('uploads/venue_pdf_image') . '/';
                            echo json_encode(array('status' => true, "fc_id" => $fc_id, "fc_pdf_id" => encrypt_decrypt('encrypt', $fc_pdf_id), "pdf_image_name" => $pdf, "pdf_image_path" => $pdf_url . $pdfImage, "fc_pdf_title_name" => $pdf_title, "fc_pdf_image_name" => $pdfImage));
                            exit();
                        }
                    }
                } else {
                    $where = array('fc_id' => $fc_id);
                    $status = $this->basic_model->delete_records('fc_pdfs', $where);
                }
            }

            $fc_id = $this->save_venue($fc_data, $data['fc_id']);

            echo json_encode(array('status' => true, "fc_id" => $fc_id));
            exit();
        }
    }

    function get_cart_content() {
        $data = array('cart_content' => '', 'sub_total' => 0, 'gst' => 0, 'total' => 0);
        $all_product = array();
        $free = $this->input->post('free');

        $result = $this->basic_model->get_record_where('products', array('pro_id', 'pro_title'), '');

        if (!empty($result)) {
            foreach ($result as $key => $val) {
                $all_product[$val->pro_id] = $val->pro_title;
            }
        }
        $res = array();
        $data['products'] = $all_product;
        $data['free'] = $free;
        if ($free < 1) {
            $data['cart_content'] = $this->cart->contents();

            $data['sub_total'] = $this->cart->total();
            $data['gst'] = ($this->cart->total() / $this->config->item('gst'));

            $data['total'] = ($this->cart->total() + $data['gst']);
        }

        if (!empty($data['cart_content'])) {
            $res['isfree'] = 2;
        } else if (!empty($free) == 1) {
            $res['isfree'] = 1;
        } else {
            $res['isfree'] = 0;
        }

        $res['cart'] = $this->load->view('venue/add_venue/cart_data', $data, true);

        $res['cart_count'] = count($this->cart->contents());
        echo json_encode($res);


        //$this->load->view('venue/add_venue/cart_data', $data);
    }

    public function image_croping() {
        $data = $this->input->post();

        if ($this->input->post()) {
            $img_name = 'new_image' . mt_rand(100000, 1000000000) . '.jpg';
            $downloaded_image_url = $_FILES['file']['tmp_name'];
            $this->load->library('ImageRoation/Image_autorotate', array('filepath' => $downloaded_image_url));

            if ($this->input->post('upload_type') == 'crope') {
                $dataDimes = $this->input->post('image_dimention');

                $dimesion = json_decode($dataDimes);


                $config = array();
                $this->load->library('image_lib');
                $config['image_library'] = 'gd2';
                $config['source_image'] = $downloaded_image_url;
                $config['x_axis'] = $dimesion->x1;
                $config['y_axis'] = $dimesion->y1;
                $config['maintain_ratio'] = false;
                $config['overite'] = false;
                $config['width'] = (int) $dimesion->width;
                $config['height'] = (int) $dimesion->height;
                $config['quality'] = '100%';
                $config['Orientation'] = false;
                $config['max_size'] = 2048;

                if ($this->input->post('space')) {
                    $config['new_image'] = 'uploads/venue_spaces/' . $img_name;
                } else {
                    $config['new_image'] = 'uploads/fc_images/' . $img_name;
                }
                $this->image_lib->initialize($config);
                if ($this->image_lib->crop()) {

                    $file_data = array(
                        'url' => base_url($config['new_image']),
                        'img_name' => $img_name
                    );

                    if ($data['image_id'] == 55555) {
                        $fc_data = array('fc_listing_picture' => $img_name);
                        $fc_id = $this->save_venue($fc_data, $data['fc_id']);

                        $file_data['fc_id'] = $fc_id;
                    } elseif ($data['image_id'] <= 5) {
                        $result = $this->save_venue_images($data, $img_name);
                        $file_data['fc_id'] = $result['fc_id'];
                        $file_data['fc_img_id'] = $result['fc_img_id'];
                    }

                    echo json_encode($file_data);
                } else {
                    echo $this->image_lib->display_errors();
                }
                $this->image_lib->clear();
            } else {
                $this->load->library('upload');

                if ($this->input->post('space')) {
                    $image_type = 'venue_spaces';
                    $this->upload->initialize($this->set_upload_options('venue_spaces'));
                } else {
                    $image_type = 'fc_images';
                    $this->upload->initialize($this->set_upload_options('fc_images'));
                }
                if (!$this->upload->do_upload("file")) {
                    $error = $this->upload->display_errors();
                } else {
                    $dataInfo[] = $this->upload->data();
                    $i_data = $this->upload->data();
                    $file_data = array(
                        'url' => base_url('') . 'uploads/' . $image_type . '/' . $i_data['file_name'],
                        'img_name' => $i_data['file_name']
                    );

                    if ($data['image_id'] == 55555) {
                        $fc_data = array('fc_listing_picture' => $i_data['file_name']);
                        $fc_id = $this->save_venue($fc_data, $data['fc_id']);

                        $file_data['fc_id'] = $fc_id;
                    } elseif ($data['image_id'] <= 5) {
                        $result = $this->save_venue_images($data, $i_data['file_name']);
                        $file_data['fc_id'] = $result['fc_id'];
                        $file_data['fc_img_id'] = $result['fc_img_id'];
                    }

                    echo json_encode($file_data);
                }
            }
        }
    }

    public function set_upload_options($image_for) {
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/' . $image_for . '/';
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = 2048;
        $config['overwrite'] = FALSE;
        return $config;
    }

    function save_venue_images($fc_data, $img_name) {
        if (!empty($fc_data['id'])) {
            $fc_id = encrypt_decrypt('decrypt', $fc_data['fc_id']);
        } else {
            $fc_id = $this->save_venue(array(), $fc_data['fc_id']);
        }

        $fc_id = encrypt_decrypt('decrypt', $fc_id);

        $fc_image_data = array('fc_img_name' => $img_name, 'fc_id' => $fc_id, 'fc_img_modified_on' => date('Y-m-d h:i'));


        if (!empty($fc_data['fc_img_id']) && ($fc_data['fc_img_id'] != 'undefined')) {
            $fc_img_id = encrypt_decrypt('decrypt', $fc_data['fc_img_id']);

            $this->basic_model->update_records('fc_images', $fc_image_data, array('fc_img_id' => $fc_img_id));
        } else {
            $fc_img_id = $this->basic_model->insert_records('fc_images', $fc_image_data);
        }
        //echo $this->db->last_query();

        $fc_img_id = encrypt_decrypt('encrypt', $fc_img_id);
        $fc_id = encrypt_decrypt('encrypt', $fc_id);

        return array('fc_id' => $fc_id, 'fc_img_id' => $fc_img_id);
    }

    function venue_payment_process() {
        require APPPATH . 'libraries/Stripe/lib/Stripe.php';
        $this->load->helper('email_template_helper');

        if ($this->input->post()) {
            $user_id = $this->session->userdata('user_id');

            $data = $this->input->post();
            $data = $this->security->xss_clean($data);

            $fc_id = encrypt_decrypt('decrypt', $data['fc_id']);
            $cart_data = json_encode($this->cart->contents());

            $data['free'] = !empty($data['free']) ? $data['free'] : 0;

            // here check cart content not empty
            if (count($this->cart->contents()) > 0 && $data['free'] == 0) {
                $voucher_log_id = '';
                $voucher_id = '';

                if (!empty($data['voucher_code'])) {
                    $result = checkVoucherHelper($data['voucher_code']);

                    if ($result['status']) {
                        $voucher_id = $result['voucher_id'];
                        $redeemed_ammount = abs($result['redeemed_ammount']); // value is redeem ammount
                        $voucher_value = abs($result['voucher_value']);
                        $voucher_log_id = insert_voucher_log($user_id, $data['voucher_code'], $voucher_value, $redeemed_ammount);
                    }
                }


                // this total user only form entry purpose
                $total_ammount = 0;
                $cart_content = $this->cart->contents();

                if (!empty($cart_content)) {
                    foreach ($cart_content as $crt) {
                        if (($crt['subtotal']) > 0) {
                            $total_ammount += $crt['subtotal'];
                        }
                    }
                }

                $cart_total = $this->cart->total();
                $gst = $cart_total / 10;
                $grand_total = $cart_total + $gst;

                $payment_data = array('pay_fc_id' => $fc_id, 'pay_user' => $user_id, 'pay_for' => json_encode($this->cart->contents()), 'pay_total_amount' => $grand_total, 'gst' => $gst, 'total_amount' => $total_ammount, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'pay_created_on' => date('Y-m-d H:i:s'));

                //if aaplied voucher greather or equal to total ammount then skip payment method
                // here payment method 1 mean strip payment method selected
                $data['payment_method'] = (!empty($data['payment_method'])) ? $data['payment_method'] : '';
                if ($cart_total > 0 && (!empty($data['payment_method'])) && $data['payment_method'] == 1) {
                    $chargeable_amount = $grand_total * 100;

                    Stripe::setApiKey(STRIPE_PRIVATE_KEY);

                    try {
                        if (!isset($_POST['stripeToken']) && !empty($data['stripeToken']))
                            throw new Exception("The Stripe Token was not generated correctly.");

                        $charge = Stripe_Charge::create(array("amount" => $chargeable_amount,
                                    "currency" => "aud",
                                    "card" => $this->input->post('stripeToken'),
                                    "description" => $this->input->post('venue_email')));

                        $captured = $charge['captured'];
                        $paid = $charge['paid'];
                        $data['id'] = $charge['id'];

                        if ((isset($captured) && $captured == 1) && (isset($paid) && $paid == 1)) {

                            $payment_data['pay_txn_id'] = $charge['id'];
                            $payment_data['payment_method'] = 1;
                            $payment_data['payment_status'] = 2;
                        } else {
                            throw new Exception("Error in transaction.");
                        }
                    } catch (Exception $e) {
                        $error_msg = $e->getMessage();
                        echo json_encode(array('status' => false, 'msg' => $error_msg));
                        exit();
                    }
                } elseif ((!empty($data['payment_method'])) && !empty($data['payment_method']) == 2) {
                    // here paymetnt method 2 mean pay by account
                    $payment_data['pay_txn_id'] = '';
                    $payment_data['payment_method'] = 2;
                    $payment_data['payment_status'] = 1;
                } elseif ($cart_total == 0) {
                    $payment_data['pay_txn_id'] = '';
                    $payment_data['payment_method'] = 3;
                    $payment_data['payment_status'] = 2;
                } else {
                    echo json_encode(array('status' => false, 'msg' => 'No payment method found'));
                    exit();
                }

                if (!empty($payment_data)) {
                    $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);

                    // we send invoice for pay by account
                    if ((isset($data['payment_method'])) && ($data['payment_method'] == 2)) {
                        // here paymetnt method 2 mean pay by account
                        $user_data = $this->basic_model->get_record_where('users', 'user_firstname,user_lastname,user_email', array('user_id' => $user_id));
                        $user_name = ucfirst($user_data[0]->user_firstname . ' ' . $user_data[0]->user_lastname);
                        $user_email = $user_data[0]->user_email;
                        $fc_data = $this->basic_model->get_record_where('function_catering', '', array('fc_id' => $fc_id));
                        $fc_new_data = array('fc_id' => $fc_id, 'name' => $user_name, 'business_name' => $fc_data[0]->fc_business_name, 'business_number' => $fc_data[0]->fc_phone_no, 'email' => $user_email, 'contact_no' => $fc_data[0]->fc_phone_no, 'url' => base_url('admin/catering_update'), 'requested_date' => $fc_data[0]->fc_created_date, 'contact_name' => $fc_data[0]->fc_contact_name, 'contact_email' => $fc_data[0]->fc_email, 'type' => $fc_data[0]->fc_type);
                        $this->load->helper('email_template_helper');
                        $order_data = json_encode($this->cart->contents());
                        account_details_invoice($order_data, $cart_total, $txn_id);
                        pending_fc_mail_to_user($fc_new_data);
                    } else {
                        $user_data = $this->basic_model->get_record_where('users', 'user_firstname,user_lastname,user_email', array('user_id' => $user_id));
                        $user_name = ucfirst($user_data[0]->user_firstname . ' ' . $user_data[0]->user_lastname);
                        $user_email = $user_data[0]->user_email;
                        $fc_data = $this->basic_model->get_record_where('function_catering', '', array('fc_id' => $fc_id));
                        $fc_new_data = array('fc_id' => $fc_id, 'name' => $user_name, 'business_name' => $fc_data[0]->fc_business_name, 'business_number' => $fc_data[0]->fc_phone_no, 'email' => $user_email, 'contact_no' => $fc_data[0]->fc_phone_no, 'url' => base_url('admin/catering_update'), 'requested_date' => $fc_data[0]->fc_created_date, 'contact_name' => $fc_data[0]->fc_contact_name, 'contact_email' => $fc_data[0]->fc_email, 'type' => $fc_data[0]->fc_type);
                        $this->load->helper('email_template_helper');
                        create_venue_catering_mail($fc_new_data, ADMIN_EMAIL);
                        // pending payment mail send
                        pending_fc_mail_to_user($fc_new_data);
//                        echo "1";
                    }
                }

                $this->save_addional_search_spaces($fc_id);
            } else {
                $user_data = $this->basic_model->get_record_where('users', 'user_firstname,user_lastname,user_email', array('user_id' => $user_id));
                $user_name = ucfirst($user_data[0]->user_firstname . ' ' . $user_data[0]->user_lastname);
                $user_email = $user_data[0]->user_email;
                $fc_data = $this->basic_model->get_record_where('function_catering', '', array('fc_id' => $fc_id));
                $fc_new_data = array('fc_id' => $fc_id, 'name' => $user_name, 'business_name' => $fc_data[0]->fc_business_name, 'email' => $user_email, 'contact_no' => $fc_data[0]->fc_phone_no, 'url' => base_url('admin/catering_update'), 'requested_date' => $fc_data[0]->fc_created_date, 'contact_name' => $fc_data[0]->fc_contact_name, 'contact_email' => $fc_data[0]->fc_email, 'type' => $fc_data[0]->fc_type);
                $this->load->helper('email_template_helper');
                create_venue_catering_mail($fc_new_data, ADMIN_EMAIL);
            }



            $today = date('Y-m-d');

            $validity_type = $this->getCurrentChoosePlan();
            $valid_upto = date("Y-m-d", strtotime("+1 $validity_type", strtotime($today)));


            $fc_data = array('fc_cart_data' => $cart_data, 'fc_type' => 1, 'fc_status' => 0, 'fc_free' => $data['free'], 'fc_valid_upto' => $valid_upto, 'fc_modified_on' => date('Y-m-d H:i:s'), 'fc_created_date' => date('Y-m-d H:i:s'));


            // draft saved of not if saved then update data other wise else condtion insert data
            $this->basic_model->update_records('function_catering', $fc_data, array('fc_id' => $fc_id));


            if ($fc_id > 0) {
                $this->cart->destroy();

                echo json_encode(array('status' => true, 'msg' => 'Venue Create successfully'));
//                exit();
            } else {
                echo json_encode(array('status' => false, 'msg' => 'Error in insertion, Please Contact To Admin.'));
                exit();
            }
        } else {
            echo json_encode(array('status' => false, 'msg' => 'Invalid request'));
            exit();
        }
    }

    function get_preview_listing() {
        $this->load->model('web_model');

        if ($this->input->post()) {
            $postData = $this->input->post();
            $data['venue_data'] = array();
            $data['pdf_data'] = array();


            $fc_id = encrypt_decrypt('decrypt', $postData['fc_id']);
//            $fc_id = 1;

            $user = $this->session->userdata('user_id');

            $fc_data = array();
            $where = array('fc_id' => $fc_id);

//            $functionData = $this->basic_model->get_record_where('function_catering', $column = '', array('fc_id' => $fc_id, 'fc_user' => $user));
            $functionData = $this->basic_model->get_record_where('function_catering', $column = '', array('fc_id' => $fc_id));

            if ($functionData) {
                $fc_data = $functionData[0];

                $data['extra_detils'] = $this->basic_model->get_record_where('venue_details', $column = '', array('vd_fc_id' => $fc_id));
                $fc_venue_detail = false;
                if ($data['extra_detils']) {
                    $fc_venue_details = $data['extra_detils'][0];
                }

                if ($fc_id) {
                    $cartData = $this->cart->contents();

                    if (!empty($cartData)) {
                        foreach ($cartData as $val) {
                            if ($val['id'] == 4) {
                                $fc_data->spaces[] = $val['options']['space_name'];
                            }
                        }
                    }
                }

                $data['images'] = $this->basic_model->get_record_where('fc_images', 'fc_img_name', $where);

                if ($data['images']) {
                    foreach ($data['images'] as $img) {
                        $fc_data->fc_images[] = $img->fc_img_name;
                    }
                }

                $data['pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '*', $where);
                if ($data['pdfs']) {
                    foreach ($data['pdfs'] as $img) {
                        $fc_data->fc_pdfs[] = $img;
                    }
                }

                $fc_data->fc_pricing = '';
                $fc_data->events = '';
                $fc_data->facilities = '';
                $fc_data->features = '';
                $fc_data->nearest_to_me = '';

                if ($fc_data->fc_pricing) {
                    $where = 'p_id IN (' . $fc_data->fc_pricing . ')';
                    $pricing = $this->basic_model->get_record_where('price_per_head', 'p_name,p_value', $where);
                    $fc_data->fc_pricing = $pricing;
                }

                if (!empty($fc_venue_details->vd_events)) {
                    $where = 'type="event_type" and id IN (' . $fc_venue_details->vd_events . ')';
                    $events = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->events = $events;
                }

                if (!empty($fc_venue_details->vd_facilities)) {
                    $where = 'type="facilities" and id IN (' . $fc_venue_details->vd_facilities . ')';
                    $facilities = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->facilities = $facilities;
                }

                if (!empty($fc_venue_details->vd_features)) {
                    $where = 'type="features" and id IN (' . $fc_venue_details->vd_features . ')';
                    $features = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->features = $features;
                }

                if ($fc_data->fc_lat) {
                    $data['nearest_to_me'] = $this->web_model->find_nearest($fc_data->fc_lat, $fc_data->fc_lng);
                }
                $data['venue_data'] = $fc_data;
            }

            echo $this->load->view('venue/add_venue/preview_listing', $data, true);
        }
    }

    function load_nearest_council() {
        $data['nearestCouncil'] = array();

        $first_councile = $this->input->post('first_council');
        $data['selected_council'] = array();
        $cart_data = $this->cart->contents();
        $data['plan'] = $this->getCurrentChoosePlan();

        if ($cart_data) {
            foreach ($cart_data as $val) {
                if ($val['id'] == 3) {
                    $data['selected_council'][] = $val['options']['council_id'];
                }
            }
        }


        if ($first_councile) {
            $where_term = array('council_id' => $first_councile);
            $relative_councils = $this->basic_model->get_record_where('aus_councils', 'rel_council', $where_term);

            $nearestCouncil = array();
            if ($relative_councils) {
                $relative_id = $relative_councils[0]->rel_council;
                $where_term = "council_id IN (" . $relative_id . ") ";
                $data['nearestCouncil'] = $this->basic_model->get_record_where('aus_councils', 'distinct(council_id),council', $where_term);
            }

            echo $this->load->view('venue/add_venue/NearestCouncilListing', $data, true);
        }
    }

    function addional_area_add_update() {
        $addionalArea = (array) $this->input->post('addional_area');
        $fc_id = $this->input->post('fc_id');
        $data = array();

        if (!empty($addionalArea) && $fc_id) {
            // first remove addional area
            $this->remove_all_addional_area();

            $where_term = "council_id IN (" . implode(', ', $addionalArea) . ") ";
            $selected_council = $this->basic_model->get_record_where('aus_councils', 'distinct(council_id),lat,lng,council', $where_term);

            //add cart in product
            $data = $this->add_to_cart_addional_area($selected_council);
            $data['select_council'] = $selected_council;

            $fc_data = array('fc_cart_data' => json_encode($this->cart->contents()));
            $this->save_venue($fc_data, $fc_id);

            echo json_encode($data);
        } else {
            echo json_encode(array('status' => true));
        }
    }

    function add_to_cart_addional_area($addional_area) {
        $productData = $this->getProductDetails(3);
        $term = $this->getCurrentChoosePlan();

        if (!empty($term)) {
            if ($term == 'month') {
                $productData->pro_price = $productData->pro_price * 30;

                $productData->pro_price = $productData->pro_price / 100;
            } elseif ($term == 'year') {
                $productData->pro_price = $productData->pro_price * 365;

                $productData->pro_price = $productData->pro_price / 100;
            }

            if (!empty($addional_area)) {
                foreach ($addional_area as $val) {
                    $data = array(
                        'id' => 3,
                        'qty' => 1,
                        'price' => $productData->pro_price,
                        'name' => $val->council,
                        'options' => array('council_id' => $val->council_id, 'council' => $val->council)
                    );

                    $this->cart->insert($data);
                }
            }

            return array('status' => true);
        } else {
            return array('status' => false, 'error' => 'No current plan chooses');
        }
    }

    function remove_all_addional_area() {
        $cart_content = $this->cart->contents();

        if (!empty($cart_content)) {
            foreach ($cart_content as $key => $val) {
                $val = (object) $val;
                if ($val->id == 3) {
                    $this->removeCartItem($key, 0);
                }
            }
        }
    }

    function removeCartItem($rowid, $qty) {
        $data = array(
            'rowid' => $rowid,
            'qty' => $qty
        );

        return $this->cart->update($data);
    }

    function remove_fc_cart_data() {
        $postData = (object) $this->input->post();
        //echo $postData->productId;
        if (!empty($postData)) {
            if ($postData->productId == 1 || $postData->productId == 2) {
                $this->cart->destroy();
                $free = 0;
            } else if ($postData->productId == 8) {
                $this->cart->destroy();
                $free = 0;
            } else {
                $cart_content = $this->cart->contents();
                $free = 0;
                if (!empty($cart_content)) {
                    foreach ($cart_content as $key => $val) {
                        $val = (object) $val;
                        if ($key == $postData->rowId) {

                            $this->removeCartItem($key, ($val->qty - 1));

                            // if product id is space id then remove also from database
                            if ($val->id == 4) {
                                $space_id = $val->options['space_id'];
                                $this->basic_model->delete_records('venue_spaces', $where = array('space_id' => $space_id));
                            }
                        }
                    }
                }
            }


            $free = 0;
            $fc_data = array('fc_free' => $free, 'fc_cart_data' => json_encode($this->cart->contents()));
            $this->save_venue($fc_data, $postData->fc_id);

            echo json_encode(array('status' => true, 'removeId' => $postData->productId, 'cart_count' => count($this->cart->contents())));
        }
    }

    public function div2clone() {
        if ($this->input->post('clone_no') && $this->input->post('clone_word')) {
            $data['num'] = $this->input->post('clone_no');

            $data['num_word'] = inWord($this->input->post('clone_no'));

            $where_events = array('type' => 'event_type', 'status' => 1);
            $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

            $where_facilities = array('type' => 'facilities', 'status' => 1);
            $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

            $where_features = array('type' => 'features', 'status' => 1);
            $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);
            $data['img_id'] = 5 + (int) $this->input->post('clone_no');
            echo $this->load->view('venue/add_venue/single_space', $data, true);
        }
    }

    public function save_new_space_with_cart() {
        $postData = $this->input->post();

        if (!empty($postData)) {
            $fc_id = $this->save_venue(array(), $postData['fc_id']);
            $fc_id = encrypt_decrypt('decrypt', $fc_id);

            $response = $this->getCurrentChoosePlan();
            if (!empty($response)) {
                $spaces = array('space_venue' => $fc_id, 'space_name' => $postData["space_name"], 'space_min_guest' => $postData["space_min_guest"], 'space_max_guest' => $postData["space_max_guest"], 'space_details' => $postData["space_details"], 'space_events' => '', 'space_facilities' => '', 'space_features' => '');

                if (!empty($postData["space_events"])) {
                    $spaces['space_events'] = implode(',', $postData["space_events"]);
                }

                if (!empty($postData["space_facilities"])) {
                    $spaces['space_facilities'] = implode(',', $postData["space_facilities"]);
                }

                if (!empty($postData["space_features"])) {
                    $spaces['space_features'] = implode(',', $postData["space_features"]);
                }


                if ($postData['dimesion_image']) {
                    if (file_exists("uploads/venue_spaces/temp/" . $postData['dimesion_image'])) {
                        rename("uploads/venue_spaces/temp/" . $postData['dimesion_image'], "uploads/venue_spaces/" . $postData['dimesion_image']);
                    }
                    $spaces['space_image'] = $postData['dimesion_image'];
                } elseif (!empty($_FILES["space_image"]) && $_FILES["space_image"]['size'] != 0) {
                    $s_config['upload_path'] = './uploads/venue_spaces/';
                    $s_config['allowed_types'] = 'jpeg|jpg|png';

                    $this->load->library('upload', $s_config);
                    $this->upload->initialize($s_config);

                    if (!$this->upload->do_upload("space_image")) {
                        $error = $this->upload->display_errors();
                    } else {
                        $i_data = $this->upload->data();
                        $spaces['space_image'] = $i_data['file_name'];
                    }
                }

                $spaceId = $this->basic_model->insert_records('venue_spaces', $spaces);
                $response = $this->add_to_cart_space(1, array('space_name' => $postData["space_name"], 'space_id' => $spaceId));

                // update cart content in database
                $this->save_venue(array('fc_cart_data' => json_encode($this->cart->contents())), $postData['fc_id']);

                $fc_id = encrypt_decrypt('encrypt', $fc_id);


                $return = array('status' => true, 'fc_id' => $fc_id);
            } else {
                $return = array('status' => false, 'error' => 'No current plan chooses');
            }

            echo json_encode($return);
        }
    }

    function add_to_cart_space($qty, $options) {
        $productData = $this->getProductDetails(4);
        $term = $this->getCurrentChoosePlan();

        if ($term == 'month') {
            $productData->pro_price = $productData->pro_price * 30;

            $productData->pro_price = $productData->pro_price / 100;
        } elseif ($term == 'year') {
            $productData->pro_price = $productData->pro_price * 365;

            $productData->pro_price = $productData->pro_price / 100;
        }

        $data = array(
            'id' => 4,
            'qty' => $qty,
            'price' => $productData->pro_price,
            'name' => 'Product-ID-' . 4,
            'options' => $options
        );

        $row_id = $this->cart->insert($data);

        return array('status' => true, 'rowId' => $row_id);
    }

    public function get_cart() {
        $cart_content = $this->cart->contents();

        $free = $this->input->post('free');

        if (!empty($cart_content) && $free == 0) {
            $my_cart = array();
            foreach ($cart_content as $key => $row) {
                $my_cart[$key] = $row['id'];
            }
//            array_multisort($my_cart, SORT_ASC, $cart_content);

            $current_cart = array();

            foreach ($cart_content as $key => $value) {
                $pro_id = $value['id'];
                $where_pro = array('pro_id' => $pro_id);
                $get_name = $this->basic_model->get_record_where('products', 'pro_title', $where_pro);

                if ($pro_id == 'voucher_id') {
                    $p_title = 'Applied voucher <a href="javascript:void(0);" onClick="RemoveVoucher();" id="remove_voucher">Remove</a>';
                    $title = $p_title;
                    $cart_total = $this->cart->total();
                    $current_cart[] = array('name' => $title, 'subtotal' => number_format($value['subtotal'], '2'), 'class' => 'voucher_maintain');
                    $current_cart[] = array('name' => 'SubTotal', 'subtotal' => number_format($cart_total, '2'), 'class' => 'voucher_maintain');
                } else {
                    if (!empty($value['options']['days_payment'])) {
                        $fc_id = $this->session->userdata('fc_id');
                        $upto_valid = $this->basic_model->get_record_where('function_catering', 'fc_valid_upto', $where_fc = array('fc_id' => $fc_id));
                        $p_title = $get_name[0]->pro_title;
                        $p_title = $p_title . ' (' . date("d M Y") . ' - ' . date("d M Y", strtotime($upto_valid[0]->fc_valid_upto)) . ')';
                    } elseif (!empty($value['options'])) {
                        if ($value['id'] == 3) {
                            $p_title = strip_tags($get_name[0]->pro_title) . ' (' . $value['options']['council'] . ')';
                        } elseif ($value['id'] == 4) {
                            $p_title = strip_tags($get_name[0]->pro_title) . ' (' . $value['options']['space_name'] . ')';
                        }
                    } else {
                        $p_title = strip_tags($get_name[0]->pro_title);
                    }
                    $title = $p_title;
                    $current_cart[] = array('name' => $title, 'subtotal' => number_format($value['subtotal'], '2'), 'class' => 'plan_maintain');
                }
            }

            $cart_total = $this->cart->total();
            $gst = $cart_total / 10;
            $grand_total = $cart_total + $gst;

            $current_cart[] = array('name' => "GST", 'subtotal' => number_format($gst, '2'), 'class' => 'plan_maintain');


            $res2 = array('cart' => $current_cart, 'total' => number_format($grand_total, '2'));
        } else {
            $res2 = array('cart' => [], 'total' => 0);
        }

        $res = $this->validate_fc_data($this->input->post('fc_id'));
        $return = array_merge($res2, $res);

        echo json_encode($return);
    }

    function save_addional_search_spaces($fc_id) {
        $cart_content = $this->cart->contents();

        $addionalSearchArea = array();
        if (!empty($cart_content)) {
            foreach ($cart_content as $val) {
                if ($val['id'] == 3) {
                    $addionalSearchArea[] = $val['options']['council_id'];
                }
            }
            if (!empty($addionalSearchArea)) {
                $where_term = "council_id IN (" . implode(', ', $addionalSearchArea) . ") ";
                $councilData = $this->basic_model->get_record_where('aus_councils', 'distinct(council_id),council,lat,lng', $where_term);

                $addional_search_area = array();
                if (!empty($councilData)) {

                    foreach ($councilData as $val) {
                        $addional_search_area[] = array('area_venue' => $fc_id, 'area_name' => $val->council, 'area_lat' => $val->lat, 'area_lng' => $val->lng, 'area_status' => 0, 'area_created_on' => date('Y-m-d'));
                    }

                    $this->basic_model->insert_records('additional_area', $addional_search_area, true);
                }
            }
        }
    }

    private function validate_fc_data($fc_id) {

        if (!empty($fc_id)) {
            $fc_id = encrypt_decrypt('decrypt', $fc_id);

            $where_fc = array('fc_id' => $fc_id);
            $venueData = (array) $this->basic_model->get_row('function_catering', $where_fc, array());
            $venue_details = (array) $this->basic_model->get_row('venue_details', $where = array('vd_fc_id' => $fc_id), array());
            $venue_images = (array) $this->basic_model->get_record_where('fc_images', array(), $where = array('fc_id' => $fc_id));

            $venueData = array_merge($venueData, $venue_details);

            $validation_rules = venueValidationRule($fc_id, $venueData, $venue_images);

            $this->form_validation->set_data($venueData);
            $this->form_validation->set_rules($validation_rules);

            if ($this->form_validation->run()) {
                $return = array('status' => true);
            } else {
                $errors = $this->form_validation->error_array();
                $return = array('status' => false, 'error' => $errors, 'validation_error' => true);
            }
        } else {
            $error[] = 'Please fill company name first';
            $return = array('status' => false, 'error' => $error, 'validation_error' => true);
        }

        return $return;
    }

    function check_postcode_city() {
        $city = $_POST['city'];
        $postcode = $_POST['postcode'];
//        $aus_councils_count = $this->basic_model->get_row('aus_councils', $where = array('suburb' => $city, 'postcode' => $postcode), array());
        $aus_councils_count = $this->basic_model->get_row('tbl_suburb_state', $where = array('suburb' => $city, 'postcode' => $postcode), array());
        if (!empty($aus_councils_count)) {
            echo json_encode(array("status" => true, "exist" => 1));
            //echo json_encode("status"->true,"exist"->1);
        } else {
            echo json_encode(array("status" => true, "exist" => 0));
        }
    }

}
