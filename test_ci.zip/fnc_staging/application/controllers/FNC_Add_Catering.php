<?php

require_once APPPATH . 'validation/formCustomValidation.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

defined('BASEPATH') OR exit('No direct script access allowed');

class FNC_Add_Catering extends CI_Controller {

    use formCustomValidation;

    public function __construct() {
        parent::__construct();

        $this->load->library('cart');
        $this->load->library('form_validation');
        $this->load->helper('catering_helper');


        if (!$this->session->userdata('user_email'))
            redirect('login/user_login');
    }

    public function add_catering($fc_id = false) {
        $permission = cater_permission();
        if (!empty($permission) && $permission->bus_auth_status == 1) {
            
        } else {
            redirect(base_url('request'));
        }

        $user_id = $this->session->userdata('user_id');
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where = array('user_id' => $user_id));

        $data['free'] = '';
        $data['plan_id'] = '';

        $this->cart->destroy();
        if ($this->input->get('f1')) {
            $venue_id = encrypt_decrypt('decrypt', $this->input->get('f1'));

            // check its draft
            $where_fc = array('fc_id' => $venue_id, 'fc_user' => $user_id, 'fc_status' => 5);
            $venue = $this->basic_model->get_row('function_catering', $where_fc, array());



            if (!empty($venue)) {
                $data['draft_catering'] = $venue;
                /* --------load cart data--------- */
                $draft_cart = '';

                if (!empty($venue->fc_cart_data)) {
                    $draft_cart = json_decode($venue->fc_cart_data, true);
                }

                if (!empty($draft_cart)) {
                    if (in_array(1, array_column($draft_cart, 'id'))) {
                        $response = $this->addToCartPlan(1);
                        $data['plan_id'] = 1;
                        $data['free'] = 0;
                    } elseif (in_array(2, array_column($draft_cart, 'id'))) {
                        $response = $this->addToCartPlan(2);
                        $data['plan_id'] = 2;
                        $data['free'] = 0;
                    }

                    foreach ($draft_cart as $val) {
                        if ($val['id'] == 5 || $val['id'] == 6 || $val['id'] == 7) {
                            $response = $this->addional_area_addtocart($val['id']);
                            $data['plan_id'] = 1;
                            $data['free'] = 0;
                        }
                    }
                }

                /* -----------------get space of venue----------- */
                $where_space = array('space_venue' => $venue_id);

                $data['draft_venue_space'] = $this->basic_model->get_record_where('venue_spaces', '', $where_space);

                /* -------------------draft venue details--------------- */
                $where_details = array('cd_fc_id' => $venue_id);
                $data['draft_catering_details'] = $this->basic_model->get_row('catering_details', $where_details, '');

                /* ---------------------get fc images ---------------- */
                $where_images = array('fc_id' => $venue_id);
                $data['draft_venue_images'] = $this->basic_model->get_record_where('fc_images', '', $where_images);

                /* ---------------------get fc pdfs ---------------- */
//                $where_pdfs = array('fc_id' => $venue_id);
//                $data['draft_venue_pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '', $where_pdfs);
            } else {
                redirect('my_catering');
            }

            if ($venue->fc_free == 1) {
                $data['plan_id'] = 0;
                $data['free'] = 1;
            }
        }

        $venue_id = encrypt_decrypt('decrypt', $this->input->get('f1'));

        $where_fc = array('fc_id' => $venue_id, 'fc_user' => $user_id);
        $venue = $this->basic_model->get_row('function_catering', $where_fc, array());

        if (!empty($venue->fc_status) == 5) {
            $data['last_date'] = isset($venue->fc_modified_on) ? $venue->fc_modified_on : '';
        } else {
            $data['last_date'] = '';
        }


        $where = 'pro_id IN (1,2)';
        $data['packs'] = $this->basic_model->get_record_where('products', '', $where);

        $data['title'] = 'Add catering';

        $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');


        $where_events = array('type' => 'function_type', 'status' => 1);
        $data['function_type'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

        $where_features = array('type' => 'menus', 'status' => 1);
        $data['menus'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);

        $where_facilities = array('type' => 'cuisine', 'status' => 1);
        $data['cuisine'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

        $where_facilities = array('type' => 'services', 'status' => 1);
        $data['services'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);


        $where = 'pro_id IN (5,6,7)';
        $data['service_area_pack'] = $this->basic_model->get_record_where('products', '', $where);


        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('catering/add_catering/add_catering', $data);
        $this->load->view('footer');
    }

    public function business_details_add_update() {
        $user_id = $this->session->userdata('user_id');
        if ($this->input->post()) {

            $user_id = $this->session->userdata('user_id');
            $data = $this->input->post();
            $data = $this->security->xss_clean($data);

            $fc_data = array('fc_user' => isset($user_id) ? $user_id : '',
                'fc_business_name' => isset($data['venue_business_name']) ? $data['venue_business_name'] : '',
                'fc_company_name' => isset($data['venue_company_name']) ? $data['venue_company_name'] : '',
                'fc_state' => isset($data['venue_state']) ? $data['venue_state'] : 'Vic',
                'fc_suburb' => isset($data['venue_suburb']) ? $data['venue_suburb'] : '',
                'fc_street' => isset($data['venue_street']) ? $data['venue_street'] : '',
                'fc_postcode' => isset($data['venue_postcode']) ? $data['venue_postcode'] : '',
                'fc_country' => isset($data['venue_country']) ? $data['venue_country'] : '',
                'fc_abn' => isset($data['venue_abn']) ? $data['venue_abn'] : '',
                'fc_contact_name' => isset($data['venue_contact_name']) ? $data['venue_contact_name'] : '',
                'fc_phone_no' => isset($data['venue_phone_no']) ? $data['venue_phone_no'] : '',
                'fc_email' => isset($data['venue_email']) ? $data['venue_email'] : '',
                'fc_lat' => isset($data['fc_lat']) ? $data['fc_lat'] : '',
                'fc_lng' => isset($data['fc_lng']) ? $data['fc_lng'] : '',
                'fc_modified_on' => date('Y-m-d H:i:s'),
                'fc_created_date' => date('Y-m-d H:i:s'),
                'fc_status' => 5,
                'fc_type' => 2,
                'fc_unit' => $data['venue_unit']
            );

            $fc_id = $this->save_venue($fc_data, $data['fc_id']);

            echo json_encode(array("status" => true, "fc_id" => $fc_id));
            exit();
        }
    }

    public function map_image_insert($fc_id = null) {
        $user_id = $this->session->userdata('user_id');
        $fc_id = encrypt_decrypt('decrypt', $fc_id);
        //file upload code 
        if (!empty($fc_id)) {
            if (!is_dir('uploads/' . 'venue_map_image')) {
                mkdir('./uploads/' . 'venue_map_image', 0777, TRUE);
            }
            $config = [];
            $_FILES['fc_map_image']['name'] = 'my_map.png';
            if (!empty($_FILES['fc_map_image']['name'])) {
                $config['upload_path'] = 'uploads/venue_map_image/';
                $config['allowed_types'] = 'octet-stream|png';
                $config['file_name'] = 'pdf_map_image' . strtotime('ymdhis' . '.png');
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                if ($this->upload->do_upload('fc_map_image')) {
                    $uploadData1 = $this->upload->data();
                    $fc_data['fc_map_image'] = $uploadData1['file_name'];
                } else {
                    print_r($this->upload->display_errors());
                }
            } else {
                $fc_data['fc_map_image'] = '';
            }
            $this->basic_model->update_records('function_catering', $fc_data, array('fc_id' => $fc_id));
        }
    }

    public function save_venue($fc_data, $fc_id) {
        $fc_id = encrypt_decrypt('decrypt', $fc_id);
        $user_id = $this->session->userdata('user_id');

        $fc_data['fc_type'] = 2;
        $fc_data['fc_modified_on'] = date('Y-m-d');
        $fc_data['fc_user'] = $this->session->userdata('user_id');
        $fc_data['fc_status'] = 5;
        $fc_data['fc_user'] = $user_id;

        if (isset($fc_id) && !empty($fc_id)) {
            $this->basic_model->update_records('function_catering', $fc_data, array('fc_id' => $fc_id, 'fc_user' => $user_id, 'fc_type' => 2));
            //echo $this->db->last_query();
        } else {
            $fc_id = $this->basic_model->insert_records('function_catering', $fc_data);
            $inProgressData = $this->basic_model->insert_records('fc_in_progress', array('venue_catering_id' => $fc_id));
            //echo $this->db->last_query();
        }

        $fc_id = encrypt_decrypt('encrypt', $fc_id);
        return $fc_id;
    }

    // function using for business detail and package progress bar percent
    public function submit_progress_business_package() {
        $businessStep1 = $this->input->post('step1');
        $businessStep2 = $this->input->post('step2');
        $packageSteps = $this->input->post('packageSteps');
        $venueId = $this->input->post('venue_id');
        $fc_id = encrypt_decrypt('decrypt', $venueId);
        $totalBusinessSteps = floatval($businessStep1) + floatval($businessStep2);
        if ($fc_id > 0) {
            if ((!empty($packageSteps))) {
                $inProgressData = array(
                    "package" => $packageSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($businessStep1)) && (!empty($businessStep2))) {
                $inProgressData = array(
                    "business_detail" => $totalBusinessSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif (!empty($businessStep1)) {
                $inProgressData = array(
                    "business_detail" => $totalBusinessSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            }
        }
    }

    // function using for catering detail and page layout progress bar percent
    public function submit_progress_catering_detail() {
        $cateringDetailstep1 = $this->input->post('step1');
        $cateringDetailstep2 = $this->input->post('step2');
        $cateringDetailstep3 = $this->input->post('step3');
        $cateringDetailstep4 = $this->input->post('step4');
        $cateringDetailstep5 = $this->input->post('step5');
        $step6pageLayout = $this->input->post('step6pageLayout');
        $venueId = $this->input->post('venue_id');
        $fc_id = encrypt_decrypt('decrypt', $venueId);
        $totalCateringDetailSteps = floatval($cateringDetailstep1) + floatval($cateringDetailstep2) + floatval($cateringDetailstep3) + floatval($cateringDetailstep4) + floatval($cateringDetailstep5);
        if ($fc_id > 0) {
            if (!empty($step6pageLayout)) {
                $inProgressData = array(
                    "page_layout" => $step6pageLayout,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($cateringDetailstep1)) && (!empty($cateringDetailstep2)) && (!empty($cateringDetailstep3)) && (!empty($cateringDetailstep4)) && (!empty($cateringDetailstep5))) {
                $inProgressData = array(
                    "venue_catering_detail" => $totalCateringDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($cateringDetailstep1)) && (!empty($cateringDetailstep2)) && (!empty($cateringDetailstep3)) && (!empty($cateringDetailstep4))) {
                $inProgressData = array(
                    "venue_catering_detail" => $totalCateringDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($cateringDetailstep1)) && (!empty($cateringDetailstep2)) && (!empty($cateringDetailstep3))) {
                $inProgressData = array(
                    "venue_catering_detail" => $totalCateringDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($cateringDetailstep1)) && (!empty($cateringDetailstep2))) {
                $inProgressData = array(
                    "venue_catering_detail" => $totalCateringDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif (!empty($cateringDetailstep1)) {
                $inProgressData = array(
                    "venue_catering_detail" => $totalCateringDetailSteps,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            }
        }
    }

    // function using for listing area and payment progress bar percent
    public function submit_progress_list_payment() {
        $step1ListingArea = $this->input->post('step1ListingArea');
        $step2Payment = $this->input->post('step2Payment');
        $venueId = $this->input->post('venue_id');
        $fc_id = encrypt_decrypt('decrypt', $venueId);
        if ($fc_id > 0) {
            if (!empty($step2Payment)) {
                $inProgressData = array(
                    "payment" => $step2Payment,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            } elseif ((!empty($step1ListingArea))) {
                $inProgressData = array(
                    "listing_area" => $step1ListingArea,
                );
                $inProgressData = $this->basic_model->update_records('fc_in_progress', $inProgressData, array('venue_catering_id' => $fc_id));
            }
        }
    }

    public function getProductDetails($pro_id) {
        $where_pro = array('pro_id' => $pro_id);
        $result = $this->basic_model->get_row('products', $where_pro, $colown = array('pro_id', 'pro_title, pro_price, pro_curr, pro_pay_type'));

        return $result;
    }

    function choose_plan() {
        $data = $this->input->post();
        $data = $this->security->xss_clean($data);

        if ($this->input->post('pack_id')) {
            $pro_id = $this->input->post('pack_id');

            // check cart content
            $cart_content = $this->cart->contents();

            if (!empty($cart_content)) {
                // change plan
                $this->change_plan($pro_id);
            } else {
                $row_id = $this->addToCartPlan($pro_id);
            }

            $cart_content = $this->cart->contents();

            $cart_total = $this->cart->total();

            $fc_data = array('fc_cart_data' => json_encode($cart_content), 'fc_free' => 0);
            $fc_id = $this->save_venue($fc_data, $data['fc_id']);

            echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'cart_total' => $cart_total, 'fc_id' => $fc_id, 'isfree' => 2));
        }
    }

    function choose_free_plan() {
        $data = $this->input->post();
        $data['cart_content'] = 0;
        $data['sub_total'] = 0;
        $data['gst'] = 0;
        $data['total'] = 0;
        //$data['freeplane'] = 'freeplane';
        if (!empty($data)) {
            $fc_data = array('fc_free' => 1);
            $fc_id = $this->save_venue($fc_data, $data['fc_id']);

            $cart_content = $this->cart->contents();
            if (!empty($cart_content)) {

                foreach ($cart_content as $val) {
                    if ($val['id'] == 4) {
                        $where = $val['options']['space_id'];
                        $this->basic_model->delete_records('venue_spaces', $where);
                    }
                }
            }

            $this->cart->destroy();
            $cart = $this->load->view('catering/add_catering/cart_data', $data, true);
            $cart_count = 1;
            echo json_encode(array('status' => TRUE, 'fc_id' => $fc_id, 'cart_count' => $cart_count, 'cart' => $cart));
        }
    }

    function addToCartPlan($pro_id) {
        $productData = $this->getProductDetails($pro_id);

        if (!empty($productData) && ($pro_id == 1 or $pro_id == 2)) {
            $price = $productData->pro_price;

            $data = array(
                'id' => $pro_id,
                'qty' => 1,
                'price' => $price,
                'name' => 'Product-ID-' . $productData->pro_id
            );

            return $row_id = $this->cart->insert($data);
        }
    }

    function removePlan() {
        $cart_content = $this->cart->contents();

        if (!empty($cart_content)) {
            foreach ($cart_content as $key => $val) {
                $val = (object) $val;
                if ($val->id == 1 || $val->id == 2) {
                    $data = array(
                        'rowid' => $key,
                        'qty' => 0
                    );

                    $this->cart->update($data);
                }
            }
        }
    }

    function getCurrentChoosePlan() {
        $cart_content = $this->cart->contents();

        if (!empty($cart_content)) {
            foreach ($cart_content as $key => $val) {
                $val = (object) $val;
                if ($val->id == 1 || $val->id == 2) {
                    $productData = $this->getProductDetails($val->id);

                    return $productData->pro_pay_type;
                }
            }
        } else {
            return false;
        }
    }

    public function change_plan($pro_id) {
        // first remove plan
        $this->removePlan();

        // add new plan
        $this->addToCartPlan($pro_id);


        $cart_content = $this->cart->contents();

        // change all product priceing according to new plan
        if (!empty($cart_content)) {

            foreach ($cart_content as $val) {
                if ($val['id'] != $pro_id) {
                    $p_id = $val['id'];

                    $rowid = $val['rowid'];
                    $qty = $val['qty'];

                    $productData = $this->getProductDetails($p_id);

                    if (!empty($productData)) {
                        $p_price = $productData->pro_price;
                        $p_curr = $productData->pro_curr;

                        $term = $this->getCurrentChoosePlan();

                        if ($term == 'month') {
                            $p_price = $p_price * 30;
                        } elseif ($term == 'year') {
                            $p_price = $p_price * 365;
                        }

                        if ($p_curr == 1)
                            $p_price = $p_price / 100;

                        $p_data = array(
                            'rowid' => $rowid,
                            'qty' => $qty,
                            'price' => $p_price
                        );

                        $this->cart->update($p_data);
                    }
                }
            }
        }
    }

    public function catering_details() {

        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');
        $where_events = array('type' => 'event_type', 'status' => 1);
        $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

        $where_facilities = array('type' => 'facilities', 'status' => 1);
        $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

        $where_features = array('type' => 'features', 'status' => 1);
        $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);
        print_r($data['draft_catering']); //die;
        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('catering/catering_details', $data);
        $this->load->view('footer');
    }

    public function catering_pdf_details($fcId = null) {
        $fc_id = encrypt_decrypt('decrypt', $fcId);
        $where_pdfs = array('fc_id' => $fc_id);
        $data['draft_catering_pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '', $where_pdfs);
        $this->load->view('catering/add_catering/catering_pdf_details', $data);
    }

    public function venue_details_add_update() {
        $data = $this->input->post();
        $data = $this->security->xss_clean($data);

        if ($this->input->post()) {
            $fc_data = array('fc_pricing' => '');

            $fc_data['fc_overview'] = ($data['venue_overview']);

            if ($data['fc_details_select'] == 'true') {
                $fc_data['fc_details_select'] = 1;
                $fc_data['fc_details'] = ($data['fc_details']);
            } else {
                $fc_data['fc_details_select'] = 0;
                $fc_data['fc_details'] = '';
            }
            $fc_data['fc_min_guest'] = $data['venue_min_guest'];
            $fc_data['fc_max_guest'] = $data['venue_max_guest'];
            $fc_data['fc_type'] = 2;


            if (!empty($data['venue_pricing'])) {
                $fc_data['fc_pricing'] = implode(',', $data['venue_pricing']);
            }

            $catering_details = array('cd_function_type' => '', 'cd_menus' => '', 'cd_cuisine' => '', 'cd_services' => '');

            if (!empty($data['function_types'])) {
                $catering_details['cd_function_type'] = implode(',', $data['function_types']);
            }
            if (!empty($data['catering_menus'])) {
                $catering_details['cd_menus'] = implode(',', $data['catering_menus']);
            }
            if (!empty($data['catering_cuisine'])) {
                $catering_details['cd_cuisine'] = implode(',', $data['catering_cuisine']);
            }

            if (!empty($data['catering_services'])) {
                $catering_details['cd_services'] = implode(',', $data['catering_services']);
            }
            if (!empty($catering_details)) {
                $fc_id = encrypt_decrypt('decrypt', $data['fc_id']);

                $catering_details['cd_fc_id'] = $fc_id;

                $check_venue_details = $this->basic_model->get_record_where('catering_details', array('cd_fc_id'), array('cd_fc_id' => $fc_id));

                if (!empty($check_venue_details)) {
                    $this->basic_model->update_records('catering_details', $catering_details, array('cd_fc_id' => $fc_id));
                } else {
                    $this->basic_model->insert_records('catering_details', $catering_details);
                }

                if (!is_dir('uploads/' . 'venue_pdf_image')) {
                    mkdir('./uploads/' . 'venue_pdf_image', 0777, TRUE);
                }
                $upload_dir = 'uploads/venue_pdf_image';
                //file upload code 
                $pdfData = array();
                $pdf = '';
                $pdfImage = '';
                $pdfTitleName = '';
                $pdf_id = encrypt_decrypt('decrypt', $data['pdf_id']);
                $pdf_title = '';
                if ($data['fc_details_select'] == 'true') {
                    if (!is_dir('uploads/' . 'venue_pdf')) {
                        mkdir('./uploads/' . 'venue_pdf', 0777, TRUE);
                    }
                    for ($i = 1; $i <= 4; $i++) {
                        if (!empty($data['pdf_title_' . $i])) {
                            $pdf_title = $data['pdf_title_' . $i];
                        }
                        if (!empty($data['venue_pdf_' . $i])) {
                            $pdf = $data['venue_pdf_' . $i];
                        }
                        if (!empty($data['fc_pdf_image_' . $i])) {
                            $pdfImage = $data['fc_pdf_image_' . $i];
                        }
                        if (!empty($_FILES['venue_pdf_' . $i]['name'])) {
                            $config['upload_path'] = 'uploads/venue_pdf/';
                            $config['allowed_types'] = 'pdf';
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            if ($this->upload->do_upload('venue_pdf_' . $i)) {
                                $uploadData = $this->upload->data();
                                $pdf = $uploadData['file_name'];
                                $config = [];
                                $_FILES['fc_pdf_image_' . $i]['name'] = 'my_blob.png';
                                if (!empty($_FILES['fc_pdf_image_' . $i]['name'])) {
                                    $config['upload_path'] = 'uploads/venue_pdf_image/';
                                    $config['allowed_types'] = 'octet-stream|png';
                                    $config['file_name'] = 'pdf_image_header' . strtotime('ymdhis' . '.png');
                                    $this->load->library('upload', $config);
                                    $this->upload->initialize($config);
                                    if ($this->upload->do_upload('fc_pdf_image_' . $i)) {
                                        $uploadData1 = $this->upload->data();
                                        $pdfImage = $uploadData1['file_name'];
                                    } else {
                                        print_r($this->upload->display_errors());
                                    }
                                } else {
                                    $pdfImage = '';
                                }
                            } else {
                                $pdf = '';
                            }
                        }
                    }
                    $pdfData = array('fc_id' => $fc_id, 'fc_pdf_title_name' => $pdf_title, 'fc_pdf_name' => $pdf, 'fc_pdf_image' => $pdfImage);
                    if (isset($pdf_id) && !empty($pdf_id)) {
                        $where = array('fc_pdf_id' => $pdf_id);
                        $fc_pdf_id = $this->basic_model->update_records('fc_pdfs', $pdfData, $where);
                        $pdf_url = base_url('uploads/venue_pdf_image') . '/';
                        echo json_encode(array('status' => true, "fc_id" => $fc_id, "fc_pdf_id" => encrypt_decrypt('encrypt', $pdf_id), "pdf_image_name" => $pdf, "pdf_image_path" => $pdf_url . $pdfImage, "fc_pdf_title_name" => $pdf_title, "fc_pdf_image_name" => $pdfImage));
                        exit();
                    } else {
                        if ((!empty($pdf_title)) || (!empty($pdf))) {
                            $fc_pdf_id = $this->basic_model->insert_records('fc_pdfs', $pdfData);
                            $pdf_url = base_url('uploads/venue_pdf_image') . '/';
                            echo json_encode(array('status' => true, "fc_id" => $fc_id, "fc_pdf_id" => encrypt_decrypt('encrypt', $fc_pdf_id), "pdf_image_name" => $pdf, "pdf_image_path" => $pdf_url . $pdfImage, "fc_pdf_title_name" => $pdf_title, "fc_pdf_image_name" => $pdfImage));
                            exit();
                        }
                    }
                } else {
                    $where = array('fc_id' => $fc_id);
                    $status = $this->basic_model->delete_records('fc_pdfs', $where);
                }
            }
            //print_r($data);
            $fc_id = $this->save_venue($fc_data, $data['fc_id']);

            echo json_encode(array('status' => true, "fc_id" => $fc_id));
            exit();
        } else if ($data['fc_details']) {
            $fc_id = $this->save_venue($fc_data, $data['fc_id']);

            echo json_encode(array('status' => true, "fc_id" => $fc_id));
            exit();
        }
    }

    public function venue_details_add_update_old() {
        $data = $this->input->post();
        $data = $this->security->xss_clean($data);

        if ($this->input->post()) {
            $fc_data = array('fc_pricing' => '');

            $fc_data['fc_overview'] = $data['venue_overview'];
            $fc_data['fc_details'] = !empty($data['fc_details']) ? $data['fc_details'] : ' '; //$data['fc_details'];
            $fc_data['fc_min_guest'] = $data['venue_min_guest'];
            $fc_data['fc_max_guest'] = $data['venue_max_guest'];
            $fc_data['fc_type'] = 2;


            if (!empty($data['venue_pricing'])) {
                $fc_data['fc_pricing'] = implode(',', $data['venue_pricing']);
            }

            $venue_details = array('vd_events' => '', 'vd_facilities' => '', 'vd_features' => '');

            if (!empty($data['venue_events'])) {
                $venue_details['vd_events'] = implode(',', $data['venue_events']);
            }
            if (!empty($data['venue_facilities'])) {
                $venue_details['vd_facilities'] = implode(',', $data['venue_facilities']);
            }
            if (!empty($data['venue_features'])) {
                $venue_details['vd_features'] = implode(',', $data['venue_features']);
            }

            if (!empty($venue_details)) {
                $fc_id = encrypt_decrypt('decrypt', $data['fc_id']);

                $venue_details['cd_fc_id'] = $fc_id;

                $check_venue_details = $this->basic_model->get_record_where('catering_details', array('cd_fc_id'), array('cd_fc_id' => $fc_id));

                if (!empty($check_venue_details)) {
                    $this->basic_model->update_records('catering_details', $venue_details, array('cd_fc_id' => $fc_id));
                } else {
                    $this->basic_model->insert_records('catering_details', $venue_details);
                }
            }
            //print_r($data);
            $fc_id = $this->save_venue($fc_data, $data['fc_id']);

            echo json_encode(array('status' => true, "fc_id" => $fc_id));
            exit();
        } else if ($data['fc_details']) {
            $fc_id = $this->save_venue($fc_data, $data['fc_id']);

            echo json_encode(array('status' => true, "fc_id" => $fc_id));
            exit();
        }
    }

    function get_cart_content() {
        $data = array('cart_content' => '', 'sub_total' => 0, 'gst' => 0, 'total' => 0);
        $all_product = array();
        $free = $this->input->post('free');

        $result = $this->basic_model->get_record_where('products', array('pro_id', 'pro_title'), '');

        if (!empty($result)) {
            foreach ($result as $key => $val) {
                $all_product[$val->pro_id] = $val->pro_title;
            }
        }

        $data['products'] = $all_product;
        $data['free'] = $free;

        $res = array();
        if ($free < 1) {
            $data['cart_content'] = $this->cart->contents();

            $data['sub_total'] = $this->cart->total();
            $data['gst'] = ($this->cart->total() / $this->config->item('gst'));

            $data['total'] = ($this->cart->total() + $data['gst']);
            $res['cart_count'] = count($this->cart->contents());
        }

        if ($free == 1) {
            $res['cart_count'] = 0;
        }

        if (!empty($data['cart_content'])) {
            $res['isfree'] = 2;
        } else if (!empty($free) == 1) {
            $res['isfree'] = 1;
        } else {
            $res['isfree'] = 0;
        }

        $res['cart'] = $this->load->view('catering/add_catering/cart_data', $data, true);
        echo json_encode($res);


        //echo "tes";
    }

    public function image_croping() {
        $data = $this->input->post();

        if ($this->input->post()) {
            $img_name = 'new_image' . mt_rand(100000, 1000000000) . '.jpg';
            $downloaded_image_url = $_FILES['file']['tmp_name'];
            $this->load->library('ImageRoation/Image_autorotate', array('filepath' => $downloaded_image_url));

            if ($this->input->post('upload_type') == 'crope') {
                $dataDimes = $this->input->post('image_dimention');

                $dimesion = json_decode($dataDimes);


                $config = array();
                $this->load->library('image_lib');
                $config['image_library'] = 'gd2';
                $config['source_image'] = $downloaded_image_url;
                $config['x_axis'] = $dimesion->x1;
                $config['y_axis'] = $dimesion->y1;
                $config['maintain_ratio'] = false;
                $config['overite'] = false;
                $config['width'] = (int) $dimesion->width;
                $config['height'] = (int) $dimesion->height;
                $config['quality'] = '100%';
                $config['Orientation'] = false;

                if ($this->input->post('space')) {
                    $config['new_image'] = 'uploads/venue_spaces/' . $img_name;
                } else {
                    $config['new_image'] = 'uploads/fc_images/' . $img_name;
                }
                $this->image_lib->initialize($config);
                if ($this->image_lib->crop()) {

                    $file_data = array(
                        'url' => base_url($config['new_image']),
                        'img_name' => $img_name
                    );

                    if ($data['image_id'] == 55555) {
                        $fc_data = array('fc_listing_picture' => $img_name);
                        $fc_id = $this->save_venue($fc_data, $data['fc_id']);

                        $file_data['fc_id'] = $fc_id;
                    } elseif ($data['image_id'] <= 5) {
                        $result = $this->save_venue_images($data, $img_name);
                        $file_data['fc_id'] = $result['fc_id'];
                        $file_data['fc_img_id'] = $result['fc_img_id'];
                    }

                    echo json_encode($file_data);
                } else {
                    echo $this->image_lib->display_errors();
                }
                $this->image_lib->clear();
            } else {
                $this->load->library('upload');

                if ($this->input->post('space')) {
                    $image_type = 'venue_spaces';
                    $this->upload->initialize($this->set_upload_options('venue_spaces'));
                } else {
                    $image_type = 'fc_images';
                    $this->upload->initialize($this->set_upload_options('fc_images'));
                }
                if (!$this->upload->do_upload("file")) {
                    $error = $this->upload->display_errors();
                } else {
                    $dataInfo[] = $this->upload->data();
                    $i_data = $this->upload->data();
                    $file_data = array(
                        'url' => base_url('') . 'uploads/' . $image_type . '/' . $i_data['file_name'],
                        'img_name' => $i_data['file_name']
                    );

                    if ($data['image_id'] == 55555) {
                        $fc_data = array('fc_listing_picture' => $i_data['file_name']);
                        $fc_id = $this->save_venue($fc_data, $data['fc_id']);

                        $file_data['fc_id'] = $fc_id;
                    } elseif ($data['image_id'] <= 5) {
                        $result = $this->save_venue_images($data, $i_data['file_name']);
                        $file_data['fc_id'] = $result['fc_id'];
                        $file_data['fc_img_id'] = $result['fc_img_id'];
                    }

                    echo json_encode($file_data);
                }
            }
        }
    }

    public function set_upload_options($image_for) {
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/' . $image_for . '/';
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = 2048;
        $config['overwrite'] = FALSE;
        return $config;
    }

    function save_venue_images($fc_data, $img_name) {
        if (!empty($fc_data['id'])) {
            $fc_id = encrypt_decrypt('decrypt', $fc_data['fc_id']);
        } else {
            $fc_id = $this->save_venue(array(), $fc_data['fc_id']);
        }

        $fc_id = encrypt_decrypt('decrypt', $fc_id);

        $fc_image_data = array('fc_img_name' => $img_name, 'fc_id' => $fc_id, 'fc_img_modified_on' => date('Y-m-d h:i'));


        if (!empty($fc_data['fc_img_id']) && ($fc_data['fc_img_id'] != 'undefined')) {
            $fc_img_id = encrypt_decrypt('decrypt', $fc_data['fc_img_id']);

            $this->basic_model->update_records('fc_images', $fc_image_data, array('fc_img_id' => $fc_img_id));
        } else {
            $fc_img_id = $this->basic_model->insert_records('fc_images', $fc_image_data);
        }
        //echo $this->db->last_query();

        $fc_img_id = encrypt_decrypt('encrypt', $fc_img_id);
        $fc_id = encrypt_decrypt('encrypt', $fc_id);

        return array('fc_id' => $fc_id, 'fc_img_id' => $fc_img_id);
    }

    function venue_payment_process() {
        require APPPATH . 'libraries/Stripe/lib/Stripe.php';
        $this->load->helper('email_template_helper');

        if ($this->input->post()) {
            $user_id = $this->session->userdata('user_id');

            $data = $this->input->post();
            $data = $this->security->xss_clean($data);

            $fc_id = encrypt_decrypt('decrypt', $data['fc_id']);

            $cart_data = json_encode($this->cart->contents());

            $data['free'] = !empty($data['free']) ? $data['free'] : 0;

            // here check cart content not empty
            if (count($this->cart->contents()) > 0 && $data['free'] == 0) {
                $voucher_log_id = '';
                $voucher_id = '';

                if (!empty($data['voucher_code'])) {
                    $result = checkVoucherHelper($data['voucher_code']);

                    if ($result['status']) {
                        $voucher_id = $result['voucher_id'];
                        $redeemed_ammount = abs($result['redeemed_ammount']); // value is redeem ammount
                        $voucher_value = abs($result['voucher_value']);
                        $voucher_log_id = insert_voucher_log($user_id, $data['voucher_code'], $voucher_value, $redeemed_ammount);
                    }
                }


                // this total user only form entry purpose
                $total_ammount = 0;
                $cart_content = $this->cart->contents();

                if (!empty($cart_content)) {
                    foreach ($cart_content as $crt) {
                        if (($crt['subtotal']) > 0) {
                            $total_ammount += $crt['subtotal'];
                        }
                    }
                }

                $cart_total = $this->cart->total();
                $gst = $cart_total / 10;
                $grand_total = $cart_total + $gst;

                $payment_data = array('pay_fc_id' => $fc_id, 'pay_user' => $user_id, 'pay_for' => json_encode($this->cart->contents()), 'pay_total_amount' => $grand_total, 'gst' => $gst, 'total_amount' => $total_ammount, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'pay_created_on' => date('Y-m-d H:i:s'));

                //if aaplied voucher greather or equal to total ammount then skip payment method
                // here payment method 1 mean strip payment method selected
                $data['payment_method'] = (!empty($data['payment_method'])) ? $data['payment_method'] : '';
                if ($cart_total > 0 && (!empty($data['payment_method'])) && $data['payment_method'] == 1) {
                    $chargeable_amount = $grand_total * 100;

                    Stripe::setApiKey(STRIPE_PRIVATE_KEY);

                    try {
                        if (!isset($_POST['stripeToken']) && !empty($data['stripeToken']))
                            throw new Exception("The Stripe Token was not generated correctly.");

                        $charge = Stripe_Charge::create(array("amount" => $chargeable_amount,
                                    "currency" => "aud",
                                    "card" => $this->input->post('stripeToken'),
                                    "description" => $this->input->post('venue_email')));

                        $captured = $charge['captured'];
                        $paid = $charge['paid'];
                        $data['id'] = $charge['id'];

                        if ((isset($captured) && $captured == 1) && (isset($paid) && $paid == 1)) {

                            $payment_data['pay_txn_id'] = $charge['id'];
                            $payment_data['payment_method'] = 1;
                            $payment_data['payment_status'] = 2;
                        } else {
                            throw new Exception("Error in transaction.");
                        }
                    } catch (Exception $e) {
                        $error_msg = $e->getMessage();
                        echo json_encode(array('status' => false, 'msg' => $error_msg));
                        exit();
                    }
                } elseif ((!empty($data['payment_method'])) && !empty($data['payment_method']) == 2) {
                    // here paymetnt method 2 mean pay by account
                    $payment_data['pay_txn_id'] = '';
                    $payment_data['payment_method'] = 2;
                    $payment_data['payment_status'] = 1;

//                    $order_data = json_encode($this->cart->contents());
//                    account_details_invoice($order_data, $cart_total, $txn_id);
                } elseif ($cart_total == 0) {
                    $payment_data['pay_txn_id'] = '';
                    $payment_data['payment_method'] = 3;
                    $payment_data['payment_status'] = 2;
                } else {
                    $this->session->set_flashdata('error_msg', 'No payment method found');
                    echo json_encode(array('status' => false, 'msg' => 'No payment method found'));

                    exit();
                }

                if (!empty($payment_data)) {
                    $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                    if ((isset($data['payment_method'])) && ($data['payment_method'] == 2)) {
                        // here paymetnt method 2 mean pay by account
                        $user_data = $this->basic_model->get_record_where('users', 'user_firstname,user_lastname,user_email', array('user_id' => $user_id));
                        $user_name = ucfirst($user_data[0]->user_firstname . ' ' . $user_data[0]->user_lastname);
                        $user_email = $user_data[0]->user_email;
                        $fc_data = $this->basic_model->get_record_where('function_catering', '', array('fc_id' => $fc_id));
                        $fc_new_data = array('fc_id' => $fc_id, 'name' => $user_name, 'business_name' => $fc_data[0]->fc_business_name, 'business_number' => $fc_data[0]->fc_phone_no, 'email' => $user_email, 'contact_no' => $fc_data[0]->fc_phone_no, 'url' => base_url('admin/catering_update'), 'requested_date' => $fc_data[0]->fc_created_date, 'contact_name' => $fc_data[0]->fc_contact_name, 'contact_email' => $fc_data[0]->fc_email, 'type' => $fc_data[0]->fc_type);
                        $this->load->helper('email_template_helper');
                        $order_data = json_encode($this->cart->contents());
                        account_details_invoice($order_data, $cart_total, $txn_id);
                        pending_fc_mail_to_user($fc_new_data);
                    } else {
                        $user_data = $this->basic_model->get_record_where('users', 'user_firstname,user_lastname,user_email', array('user_id' => $user_id));
                        $user_name = ucfirst($user_data[0]->user_firstname . ' ' . $user_data[0]->user_lastname);
                        $user_email = $user_data[0]->user_email;
                        $fc_data = $this->basic_model->get_record_where('function_catering', '', array('fc_id' => $fc_id));
                        $fc_new_data = array('fc_id' => $fc_id, 'name' => $user_name, 'business_name' => $fc_data[0]->fc_business_name, 'business_number' => $fc_data[0]->fc_phone_no, 'email' => $user_email, 'contact_no' => $fc_data[0]->fc_phone_no, 'url' => base_url('admin/catering_update'), 'requested_date' => $fc_data[0]->fc_created_date, 'contact_name' => $fc_data[0]->fc_contact_name, 'contact_email' => $fc_data[0]->fc_email, 'type' => $fc_data[0]->fc_type);
                        $this->load->helper('email_template_helper');
                        create_venue_catering_mail($fc_new_data, ADMIN_EMAIL);
                        pending_fc_mail_to_user($fc_new_data);
//                        echo "1";
                    }
                }

                //$this->save_addional_search_spaces($fc_id);
            } else {
                $user_data = $this->basic_model->get_record_where('users', 'user_firstname,user_lastname,user_email', array('user_id' => $user_id));
                $user_name = ucfirst($user_data[0]->user_firstname . ' ' . $user_data[0]->user_lastname);
                $user_email = $user_data[0]->user_email;
                $fc_data = $this->basic_model->get_record_where('function_catering', '', array('fc_id' => $fc_id));
                $fc_new_data = array('fc_id' => $fc_id, 'name' => $user_name, 'business_name' => $fc_data[0]->fc_business_name, 'email' => $user_email, 'contact_no' => $fc_data[0]->fc_phone_no, 'url' => base_url('admin/catering_update'), 'requested_date' => $fc_data[0]->fc_created_date, 'contact_name' => $fc_data[0]->fc_contact_name, 'contact_email' => $fc_data[0]->fc_email, 'type' => $fc_data[0]->fc_type);
                $this->load->helper('email_template_helper');
                create_venue_catering_mail($fc_new_data, ADMIN_EMAIL);
            }



            $today = date('Y-m-d');

            $validity_type = $this->getCurrentChoosePlan();
            $valid_upto = date("Y-m-d", strtotime("+1 $validity_type", strtotime($today)));

            //file_put_contents('detail_reponse.txt',json_encode($validity_type) . PHP_EOL, FILE_APPEND | LOCK_EX);

            $fc_data = array('fc_cart_data' => $cart_data, 'fc_type' => 2, 'fc_status' => 0, 'fc_free' => $data['free'], 'fc_valid_upto' => $valid_upto, 'fc_modified_on' => date('Y-m-d H:i:s'), 'fc_created_date' => date('Y-m-d H:i:s'));


            // draft saved of not if saved then update data other wise else condtion insert data
            $this->basic_model->update_records('function_catering', $fc_data, array('fc_id' => $fc_id));


            if ($fc_id > 0) {
                $this->cart->destroy();

                echo json_encode(array('status' => true, 'msg' => 'Catering Create successfully'));
            } else {

                echo json_encode(array('status' => false, 'msg' => 'Error in insertion, Please Contact To Admin.'));
                exit();
            }
        } else {
            exit();
            redirect('add_catering');
        }
    }

    function get_preview_listing() {
        $this->load->model('web_model');

        if ($this->input->post()) {
            $postData = $this->input->post();
            $data['venue_data'] = array();


            $fc_id = encrypt_decrypt('decrypt', $postData['fc_id']);
//            $fc_id = 1;

            $user = $this->session->userdata('user_id');

            $fc_data = array();
            $where = array('fc_id' => $fc_id);
            $functionData = $this->basic_model->get_record_where('function_catering', $column = '', array('fc_id' => $fc_id));

            if ($functionData) {
                $fc_data = $functionData[0];

                //$data['extra_detils'] = $this->basic_model->get_record_where('venue_details', $column = '', array('vd_fc_id' => $fc_id));

                $data['extra_detils'] = $this->basic_model->get_record_where('catering_details', $column = '', array('cd_fc_id' => $fc_id));
                $fc_venue_detail = false;
                if ($data['extra_detils']) {
                    $fc_venue_details = $data['extra_detils'][0];
                }

                if ($fc_id) {
                    $cartData = $this->cart->contents();

                    if (!empty($cartData)) {
                        foreach ($cartData as $val) {
                            if ($val['id'] == 4) {
                                $fc_data->spaces[] = $val['options']['space_name'];
                            }
                        }
                    }
                }

                $data['images'] = $this->basic_model->get_record_where('fc_images', 'fc_img_name', $where);

                if ($data['images']) {
                    foreach ($data['images'] as $img) {
                        $fc_data->fc_images[] = $img->fc_img_name;
                    }
                }

                $data['pdfs'] = $this->basic_model->get_record_where('fc_pdfs', '*', $where);
                if ($data['pdfs']) {
                    foreach ($data['pdfs'] as $img) {
                        $fc_data->fc_pdfs[] = $img;
                    }
                }

                $fc_data->fc_pricing = '';
                $fc_data->function_type = '';
                $fc_data->menus = '';
                $fc_data->cuisine = '';
                $fc_data->services = '';
                $fc_data->nearest_to_me = '';

                if ($fc_data->fc_pricing) {
                    $where = 'p_id IN (' . $fc_data->fc_pricing . ')';
                    $pricing = $this->basic_model->get_record_where('price_per_head', 'p_name,p_value', $where);
                    $fc_data->fc_pricing = $pricing;
                }

                if (!empty($fc_venue_details->cd_function_type)) {
                    $where = 'type="function_type" and id IN (' . $fc_venue_details->cd_function_type . ')';
                    $function_type = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->function_type = $function_type;
                }

                if (!empty($fc_venue_details->cd_menus)) {
                    $where = 'type="menus" and id IN (' . $fc_venue_details->cd_menus . ')';
                    $menus = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->menus = $menus;
                }

                if (!empty($fc_venue_details->cd_cuisine)) {
                    $where = 'type="cuisine" and id IN (' . $fc_venue_details->cd_cuisine . ')';
                    $cuisine = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->cuisine = $cuisine;
                }

                if (!empty($fc_venue_details->cd_services)) {
                    $where = 'type="services" and id IN (' . $fc_venue_details->cd_services . ')';
                    $services = $this->basic_model->get_record_where('fnc_types', ' name,image', $where);
                    $fc_data->services = $services;
                }

                if ($fc_data->fc_lat) {
                    $data['nearest_to_me'] = $this->web_model->find_nearest($fc_data->fc_lat, $fc_data->fc_lng);
                }
                $data['venue_data'] = $fc_data;
            }

            echo $this->load->view('catering/add_catering/preview_listing', $data, true);
        }
    }

    function load_nearest_council() {
        $data['nearestCouncil'] = array();

        $first_councile = $this->input->post('first_council');
        $data['selected_council'] = array();
        $cart_data = $this->cart->contents();

        if ($cart_data) {
            foreach ($cart_data as $val) {
                if ($val['id'] == 3) {
                    $data['selected_council'][] = $val['options']['council_id'];
                }
            }
        }


        if ($first_councile) {
            $where_term = array('council_id' => $first_councile);
            $relative_councils = $this->basic_model->get_record_where('aus_councils', 'rel_council', $where_term);

            $nearestCouncil = array();
            if ($relative_councils) {
                $relative_id = $relative_councils[0]->rel_council;
                $where_term = "council_id IN (" . $relative_id . ") ";
                $data['nearestCouncil'] = $this->basic_model->get_record_where('aus_councils', 'distinct(council_id),council', $where_term);
            }

            echo $this->load->view('catering/add_catering/NearestCouncilListing', $data, true);
        }
    }

    function addional_area_add_update() {
        $addionalArea = $this->input->post('pack_id');
        $fc_id = $this->input->post('fc_id');
        $data = array();


        if (!empty($addionalArea) && $fc_id) {
            // first remove addional area
            $this->remove_all_addional_area();


            //add cart in product
            $data = $this->add_to_cart_addional_area($addionalArea);


            $fc_data = array('fc_cart_data' => json_encode($this->cart->contents()));
            $this->save_venue($fc_data, $fc_id);

            echo json_encode($data);
        } else {
            echo json_encode(array('status' => false));
        }
    }

    function addional_area_addtocart($pro_id) {
        $postData = (object) $this->input->post();
        $productData = $this->getProductDetails($pro_id);
        $term = $this->getCurrentChoosePlan();
        if (!empty($productData) && ($pro_id == 5 or $pro_id == 6 or $pro_id == 7)) {
            $cart_content = $this->cart->contents();
            if (!empty($cart_content)) {
                foreach ($cart_content as $key => $val) {
                    if ($val['id'] == 5 || $val['id'] == 6 || $val['id'] == 7) {
                        $val = (object) $val;
                        $this->removeCartItem($key, ($val->qty - 1));
                    }
                }
            }

            if ($term == 'month') {
                if ($productData->pro_price == 1) {
                    $productData->pro_price = $productData->pro_price * 30;

                    //$productData->pro_price = $productData->pro_price / 100;
                } else {
                    $productData->pro_price = $productData->pro_price * 30;

                    $productData->pro_price = $productData->pro_price / 100;
                }
            } elseif ($term == 'year') {
                if ($productData->pro_price == 1) {
                    $productData->pro_price = $productData->pro_price * 365;

                    //$productData->pro_price = $productData->pro_price / 100;
                } else {
                    $productData->pro_price = $productData->pro_price * 365;

                    $productData->pro_price = $productData->pro_price / 100;
                }
            }

            $price = $productData->pro_price;
            $data = array(
                'id' => $pro_id,
                'qty' => 1,
                'price' => $price,
                'name' => 'Product-ID-' . $productData->pro_id
            );
            return $row_id = $this->cart->insert($data);
        }
    }

    function add_to_cart_addional_area($addional_area) {
        $productData = $this->getProductDetails($addional_area);
        $term = $this->getCurrentChoosePlan();

        if (!empty($term)) {
            if ($term == 'month') {
                $productData->pro_price = $productData->pro_price * 30;
                if ($productData->pro_curr != 0) {
                    $productData->pro_price = $productData->pro_price / 100;
                }
            } elseif ($term == 'year') {
                $productData->pro_price = $productData->pro_price * 365;
                if ($productData->pro_curr != 0) {
                    $productData->pro_price = $productData->pro_price / 100;
                }
            }

            //if (!empty($addional_area)) {
            //  foreach ($addional_area as $val) {
            $data = array(
                'id' => $addional_area,
                'qty' => 1,
                'price' => $productData->pro_price,
                'name' => 'Addional area' . $addional_area,
                    // 'options' => array('council_id' => $val->council_id, 'council' => $val->council)
            );

            $this->cart->insert($data);
            //  }
            //    }

            return array('status' => true);
        } else {
            return array('status' => false, 'error' => 'No current plan chooses');
        }
    }

    function remove_all_addional_area() {
        $cart_content = $this->cart->contents();

        if (!empty($cart_content)) {
            //  echo "test";
            //  print_r($cart_content);
            foreach ($cart_content as $key => $val) {
                $val = (object) $val;

                if (($val->id == '5') || ($val->id == '6') || ($val->id == '7')) {

                    $this->removeCartItem($key, 0);
                }
            }
        }
        //$cart_content = $this->cart->contents();
        //print_r($cart_content);
    }

    function removeCartItem($rowid, $qty) {
        $data = array(
            'rowid' => $rowid,
            'qty' => $qty
        );

        return $this->cart->update($data);
    }

    function remove_fc_cart_data() {
        $postData = (object) $this->input->post();

        if (!empty($postData)) {
            if ($postData->productId == 1 || $postData->productId == 2) {
                $this->cart->destroy();
                $free = 0;
            } else if ($postData->productId == 8) {
                $this->cart->destroy();
                $free = 0;
            } else if ($postData->productId == 5 || $postData->productId == 6 || $postData->productId == 7) {
                $cart_content = $this->cart->contents();
                if (!empty($cart_content)) {
                    foreach ($cart_content as $key => $val) {
                        $val = (object) $val;

                        if ($key == $postData->rowId) {
                            $this->removeCartItem($key, ($val->qty - 1));
                        }
                    }
                }

                // $this->cart->destroy();
            } else {
                if (!empty($cart_content)) {
                    foreach ($cart_content as $key => $val) {
                        $val = (object) $val;
                        if ($key == $postData->rowId) {

                            $this->removeCartItem($key, ($val->qty - 1));

                            // if product id is space id then remove also from database
                            if ($val->id == 4) {
                                $space_id = $val->options['space_id'];
                                $this->basic_model->delete_records('venue_spaces', $where = array('space_id' => $space_id));
                            }
                        }
                    }
                }
            }

            $free = 0;
            $fc_data = array('fc_free' => $free, 'fc_cart_data' => json_encode($this->cart->contents()));
            $this->save_venue($fc_data, $postData->fc_id);

            echo json_encode(array('status' => true, 'removeId' => $postData->productId));
        }
    }

    public function get_cart() {
        $cart_content = $this->cart->contents();

        $free = $this->input->post('free');

        if (!empty($cart_content) && $free == 0) {
            $my_cart = array();
            foreach ($cart_content as $key => $row) {
                $my_cart[$key] = $row['id'];
            }
//            array_multisort($my_cart, SORT_ASC, $cart_content);

            $current_cart = array();

            foreach ($cart_content as $key => $value) {
                $pro_id = $value['id'];
                $where_pro = array('pro_id' => $pro_id);
                $get_name = $this->basic_model->get_record_where('products', 'pro_title', $where_pro);

                if ($pro_id == 'voucher_id') {
                    $p_title = 'Applied voucher <a href="javascript:void(0);" onClick="RemoveVoucher();" id="remove_voucher">Remove</a>';
                    $title = $p_title;
                    $cart_total = $this->cart->total();
                    $current_cart[] = array('name' => $title, 'subtotal' => number_format($value['subtotal'], '2'), 'class' => 'voucher_maintain');
                    $current_cart[] = array('name' => 'SubTotal', 'subtotal' => number_format($cart_total, '2'), 'class' => 'voucher_maintain');
                } else {
                    if (!empty($value['options']['days_payment'])) {
                        $fc_id = $this->session->userdata('fc_id');
                        $upto_valid = $this->basic_model->get_record_where('function_catering', 'fc_valid_upto', $where_fc = array('fc_id' => $fc_id));
                        $p_title = $get_name[0]->pro_title;
                        $p_title = $p_title . ' (' . date("d M Y") . ' - ' . date("d M Y", strtotime($upto_valid[0]->fc_valid_upto)) . ')';
                    } elseif (!empty($value['options'])) {
                        if ($value['id'] == 3) {
                            $p_title = strip_tags($get_name[0]->pro_title) . ' (' . $value['options']['council'] . ')';
                        } elseif ($value['id'] == 4) {
                            $p_title = strip_tags($get_name[0]->pro_title) . ' (' . $value['options']['space_name'] . ')';
                        }
                    } else {
                        $p_title = strip_tags($get_name[0]->pro_title);
                    }
                    $title = $p_title;
                    $current_cart[] = array('name' => $title, 'subtotal' => number_format($value['subtotal'], '2'), 'class' => 'plan_maintain');
                }
            }

            $cart_total = $this->cart->total();
            $gst = $cart_total / 10;
            $grand_total = $cart_total + $gst;

            $current_cart[] = array('name' => "GST", 'subtotal' => number_format($gst, '2'), 'class' => 'plan_maintain');


            $res2 = array('cart' => $current_cart, 'total' => number_format($grand_total, '2'));
        } else {
            $res2 = array('cart' => [], 'total' => 0);
        }

        $res = $this->validate_fc_data($this->input->post('fc_id'));
        $return = array_merge($res2, $res);

        echo json_encode($return);
    }

    private function validate_fc_data($fc_id) {

        if (!empty($fc_id)) {
            $fc_id = encrypt_decrypt('decrypt', $fc_id);

            $where_fc = array('fc_id' => $fc_id);
            $venueData = (array) $this->basic_model->get_row('function_catering', $where_fc, array());
            $venue_details = (array) $this->basic_model->get_row('catering_details', $where = array('cd_fc_id' => $fc_id), array());
            $venue_images = (array) $this->basic_model->get_record_where('fc_images', array(), $where = array('fc_id' => $fc_id));

            $venueData = array_merge($venueData, $venue_details);

            $validation_rules = venueValidationRule($fc_id, $venueData, $venue_images);

            $this->form_validation->set_data($venueData);
            $this->form_validation->set_rules($validation_rules);

            if ($this->form_validation->run()) {
                $return = array('status' => true);
            } else {
                $errors = $this->form_validation->error_array();
                $return = array('status' => false, 'error' => $errors, 'validation_error' => true);
            }
        } else {
            $error[] = 'Please fill company name first';
            $return = array('status' => false, 'error' => $error, 'validation_error' => true);
        }

        return $return;
    }

    function additional_area_catering() {

        $arryChecked = [];
        $cart_content = $this->cart->contents();
        //echo json_encode($cart_content);
//        $plan = $this->getCurrentChoosePlan();

        $checkDisable = false;

        if (!empty($cart_content)) {
            foreach ($cart_content as $key => $val) {
                $val = (object) $val;
                $arryChecked[] = $val->id;
                if ($val->id == 1 || $val->id == 2) {
                    $checkDisable = true;
                }
            }
        }

        $disableClass = '';
        if (!$checkDisable) {
            $disableClass = 'disable';
        }

        $additional_li = '';
        $where = 'pro_id IN (5,6,7)';
        $service_area_pack = $this->basic_model->get_record_where('products', '', $where);
        if (!empty($service_area_pack)) {
            foreach ($service_area_pack as $key => $value) {

                //if(!empty($arryChecked)){
                if (in_array($value->pro_id, $arryChecked)) {
                    $active_class = 'my_active';
                } else {
                    $active_class = '';
                }

                $additional_li .= '<li><span data-area_add="' . $value->pro_desc . '" data-active="0" id="' . $value->pro_id . '" class="increase_radius_map plus new_plus_sine caterer_space ' . $active_class . ' ' . $disableClass . ' ">' . $value->pro_title . '</span></li>';
            }
        }

        echo $additional_li;
//        if (($plan)) {
//            echo '';
//        } else {
//            echo '<div class="col-sm-12 mlCh_cols planCheck"><span class="span_disable_error">Update your package to gain access to more areas</span></div>';
//        }
    }

    function get_council_current_fc() {
        $fc_id = $this->input->post('fc_id');

        if (!empty($fc_id)) {
            $fc_id = encrypt_decrypt('decrypt', $fc_id);

            $where_fc = array('fc_id' => $fc_id);
            $venueData = (object) $this->basic_model->get_row('function_catering', $where_fc, array('fc_suburb', 'fc_postcode', 'fc_business_name'));
            $businessName = '_ _ _';
            if (!empty($venueData)) {
                $businessName = (!empty($venueData->fc_business_name)) ? $venueData->fc_business_name : '_ _ _';
                $where_for_council = array('suburb' => $venueData->fc_suburb, 'postcode' => $venueData->fc_postcode);
                $council = (object) $this->basic_model->get_row('aus_councils', $where_for_council, ['council,council_id,zoom']);



                if (!empty($council)) {
                    echo json_encode(['status' => true, 'council' => $council->council, 'business_name' => $businessName]);
                } else {
                    echo json_encode(['status' => true, 'council' => '', 'business_name' => $businessName]);
                }
            } else {
                echo json_encode(['status' => true, 'council' => '', 'business_name' => $businessName]);
            }
        }
    }

}
