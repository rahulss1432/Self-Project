<?php

require_once APPPATH . 'validation/formCustomValidation.php';

defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    use formCustomValidation;

    public function __construct() {
        parent::__construct();
        $this->load->library('upload');

        if (!$this->session->userdata('user_email'))
            redirect('user_login');
    }

    public function index() {
        
    }

    public function user_dashboard() {
        $data['title'] = 'User dashboard';
        $data['body_class'] = 'user_dashboard';
        $user_id = $this->session->userdata('user_id');

        if ($this->input->post('save_profile')) {
            $userData = array(
                'user_business_name' => $this->input->post('user_business_name'),
                'user_firstname' => $this->input->post('user_firstname'),
                'user_lastname' => $this->input->post('user_lastname'),
                'user_country' => $this->input->post('user_country'),
                'user_city' => $this->input->post('user_city'),
                'user_postcode' => $this->input->post('user_postcode'),
                'user_phone_no' => $this->input->post('user_phone_no'),
                'user_abn' => $this->input->post('user_abn'),
                'user_suburb' => $this->input->post('user_suburb'),
                'user_address' => $this->input->post('user_address'),
                'user_state' => $this->input->post('user_state'),
            );

            //echo $this->input->post('dimesion_image_11111');
            //die;
            //is_valid_type
            // $config['upload_path'] = './uploads/users/';
            // $config['allowed_types'] = 'gif|jpg|png';
            //  $this->load->library('upload', $config);
            //  $this->upload->initialize($config);

            /* if ($this->upload->do_upload('userfile')) {
              $data = array('upload_data' => $this->upload->data());
              $image_url = base_url() . '/uploads/users/' . $data['upload_data']['file_name'];
              $userData['user_image'] = $image_url;
              $session_data = array(
              'user_image' => $image_url
              );

              $this->session->set_userdata($session_data);
              }else{ */

            $imageName = $this->input->post('dimesion_image_11111');

            if (!empty($imageName)) {
                $reposne = $this->copy_image_user($imageName);
                $image_url = '';
                if ($reposne['status']) {
                    $image_url = base_url() . 'uploads/users/' . $this->input->post('dimesion_image_11111');
                    $userData['user_image'] = $image_url;
                }
                $session_data = array(
                    'user_image' => $image_url
                );
                $this->session->set_userdata($session_data);
            }
            //}

            $where = "user_id = '" . $user_id . "'";
            $this->basic_model->update_records('users', $userData, $where);
            redirect('dashboard');
        } else {

            $where = "user_id='" . $user_id . "'";
            $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

            $this->load->view('header', $data);
            $this->load->view('menu', $data);
            $this->load->view('user/user_dashboard', $data);
            $this->load->view('footer');
        }
    }

    //user image crop 
    public function image_croping() {
        if ($this->input->post()) {
            $img_name = 'new_image' . mt_rand(100000, 1000000000) . '.jpg';
            $downloaded_image_url = $_FILES['file']['tmp_name'];
            $this->load->library('ImageRoation/Image_autorotate', array('filepath' => $downloaded_image_url));

            if ($this->input->post('upload_type') == 'crope') {
                $data = $this->input->post('image_dimention');
                $dimesion = json_decode($data);
                $config = array();
                $this->load->library('image_lib');
                $config['image_library'] = 'gd2';
                $config['source_image'] = $downloaded_image_url;
                $config['x_axis'] = $dimesion->x1;
                $config['y_axis'] = $dimesion->y1;
                $config['maintain_ratio'] = false;
                $config['overite'] = false;
                $config['width'] = (int) $dimesion->width;
                $config['height'] = (int) $dimesion->height;
                $config['quality'] = '100%';
                $config['Orientation'] = false;

                if ($this->input->post('space')) {
                    $config['new_image'] = 'uploads/users/' . $img_name;
                } else {
                    $config['new_image'] = 'uploads/users//' . $img_name;
                }
                $this->image_lib->initialize($config);
                if ($this->image_lib->crop()) {
                    $file_data = array(
                        'url' => base_url($config['new_image']),
                        'img_name' => $img_name
                    );

                    echo json_encode($file_data);
                } else {
                    echo $this->image_lib->display_errors();
                }
                $this->image_lib->clear();
            } else {
                $this->load->library('upload');

                if ($this->input->post('space')) {
                    $image_type = 'users';
                    $this->upload->initialize($this->set_upload_options('users'));
                } else {
                    $image_type = 'users';
                    $this->upload->initialize($this->set_upload_options('users'));
                }
                if (!$this->upload->do_upload("file")) {
                    $error = $this->upload->display_errors();
                } else {
                    $dataInfo[] = $this->upload->data();
                    $i_data = $this->upload->data();
                    $file_data = array(
                        'url' => base_url('') . 'uploads/' . $image_type . '/' . $i_data['file_name'],
                        'img_name' => $i_data['file_name']
                    );

                    echo json_encode($file_data);
                }
            }
        }
    }

    public function set_upload_options($image_for) {
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/' . $image_for . '/';
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = '0';
        $config['overwrite'] = FALSE;
        return $config;
    }

    public function copy_image_user($imgName) {

        $tempPath = FCPATH . '/uploads/venue_spaces/temp/' . $imgName;
        $newPath = FCPATH . '/uploads/users/' . $imgName;

        $imageExist = $this->is_valid_type($tempPath);
        $arrResponse = array();

        if ($imageExist) {
            $copied = copy($tempPath, $newPath);
            if ((!$copied)) {
                $arrResponse = array('status' => false);
            } else {
                unlink($tempPath);
                $doc_root = $_SERVER["DOCUMENT_ROOT"] . '/uploads/users/' . $imgName;
                $arrResponse = array('status' => true, 'path' => $doc_root);
            }
        } else {
            $arrResponse = array('status' => false);
        }
        return $arrResponse;
    }

    function is_valid_type($file) {
        $size = getimagesize($file);
        if (!$size) {
            return 0;
        }

        $valid_types = array(IMAGETYPE_GIF, IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_BMP);

        if (in_array($size[2], $valid_types)) {
            return true;
        } else {
            return false;
        }
    }

    public function user_logout() {
        $this->session->sess_destroy();
        redirect('user_login');
    }

    public function my_draft() {

        $data = array();

        $user_id = $this->session->userdata('user_id');

        $where_user = array('user_id' => $user_id);
        $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

        $where = array('fc_user' => $user_id, 'function_catering.fc_is_deleted' => 0, 'function_catering.fc_status' => 5);

        $my_draft = $this->basic_model->get_record_where('function_catering', 'fc_id,fc_type, fc_business_name, fc_overview, fc_listing_picture', $where);

        $data['my_draft'] = $my_draft;
        $data['title'] = 'My draft';

        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('user/my_draft', $data);
        $this->load->view('footer');
    }

    public function Favourite() {
        $data['title'] = 'Favourite';
        $data = array();
        $fc_id = 0;

        $user_id = $this->session->userdata('user_id');

        $where_user = array('w_user' => $user_id);
        $wish_list = $this->basic_model->get_record_where('wish_list', 'w_venue', $where_user);
        if (!empty($wish_list)) {
            foreach ($wish_list as $key => $list) {
                $wish_list_id[$key] = $list->w_venue;
            }

            $fc_id = implode(',', $wish_list_id);
        }

        $data['wish_list'] = home_page_data();
        $where = 'function_catering.fc_id IN (' . $fc_id . ') and function_catering.fc_status = 1';
        $join = array(
            'fc_images' => 'fc_images.fc_id = function_catering.fc_id'
        );
        $wish_list = $this->basic_model->get_record_join_tables_groupby('function_catering', $where, 'function_catering.fc_listing_picture,function_catering.fc_id, fc_business_name, fc_overview, fc_type, fc_img_name', $join, 'fc_images.fc_id');
        $data['wish_list_data'] = $wish_list;

        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('user/wish-list', $data);
        $this->load->view('footer');
    }

    function change_password() {

        $data = array();
        if ($this->input->post('change_password')) {

            $old_password = md5($this->input->post('user_old_password'));
            $email = $this->session->userdata('user_email');
            $where = array('user_email' => $email, 'user_password' => $old_password);
            $result = $this->basic_model->get_record_where('users', $column = '', $where);

            if (!empty($result)) {
                $where = array('user_email' => $email);
                $new_password = md5($this->input->post('user_new_password'));
                $this->basic_model->update_records('users', array('user_password' => $new_password), $where);
                $data['success'] = 'your password has successfully changed.';
            } else {
                $data['error'] = 'You enter wrong password';
            }
        }

        $data['title'] = 'Change password';

        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('user/change-password', $data);
        $this->load->view('footer');
    }

    /* ----------Feedback--------------- */

    public function feedback($fc_id = '') {
        if (!empty($fc_id)) {
            $venue_id = encrypt_decrypt('decrypt', $fc_id);

            $where = array('function_catering.fc_id' => $venue_id);
            $join = array(
                'fc_images' => 'fc_images.fc_id = function_catering.fc_id'
            );
            $fc_details = $this->basic_model->get_record_join_tables('function_catering', $where, 'function_catering.fc_id, function_catering.fc_type, fc_business_name, fc_overview, fc_img_name', $join, '', '', '', '', $join_type = 'left', 'function_catering.fc_id');

            if (!empty($fc_details)) {
                $data['fc_id'] = $fc_id;

                $data['fc_details'] = $fc_details;

                $user_id = $this->session->userdata('user_id');
                $where = array('user_id' => $user_id);
                $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

                $this->load->view('header');
                $this->load->view('menu', $data);
                $this->load->view('user/feedback', $data);
                $this->load->view('footer');
            } else {
                redirect('dashboard');
            }
        } else {
            redirect('dashboard');
        }
    }

    public function submit_feed($fc_id = '') {
        $user_id = $this->session->userdata('user_id');

        if ($this->input->post()) {

            $post_data = $this->input->post();

            $fc = encrypt_decrypt('decrypt', $post_data['feedbakc_of']);

            $where_check = array('f_user' => $this->session->userdata('user_id'), 'f_fc_id' => $fc);
            $check_review = $this->basic_model->get_record_where('feedback', array('f_text'), $where_check);

            if (!empty($check_review)) {
                redirect('dashboard');
            }

            $datestring = "%m/%d/%Y";
            $date = $this->input->post('f_attended_date');

            $feedback_data = array('f_text' => $post_data['notes'], 'f_rating_overall' => $post_data['overall'], 'f_rating_cleanliness' => $post_data['cleanliness'], 'f_rating_accuracy' => $post_data['description'], 'f_rating_comm' => $post_data['communication'], 'f_user' => $user_id, 'f_fc_id' => $fc, 'f_status' => 0, 'f_created_on' => date('Y-m-d H:i:s'), 'f_location' => $post_data['f_location'], 'f_attended_date' => date('Y-m-d', strtotime($date)));

            $f_id = $this->basic_model->insert_records('feedback', $feedback_data);

            if ($f_id > 0) {
                $data['fc'] = $fc;

                $where = array('function_catering.fc_id' => $fc);
                $join = array(
                    'fc_images' => 'fc_images.fc_id = function_catering.fc_id'
                );
                $data['fc_details'] = $this->basic_model->get_record_join_tables('function_catering', $where, 'function_catering.*, fc_img_name', $join, '', '', '', '', $join_type = 'left', 'function_catering.fc_id');

                $where = array('user_id' => $user_id);
                $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

                $given_stars = $post_data['overall'] + $post_data['cleanliness'] + $post_data['description'] + $post_data['communication'];

                $this->load->view('header');
                $this->load->view('menu', $data);

                /* if($given_stars > 8){
                  $this->load->view('user/good_exp', $data);
                  } else {
                  $this->load->view('user/bad_exp', $data);
                  } */
                unset($_POST);
                $this->load->view('user/bad_exp', $data);
                $this->load->view('footer');
            } else {
                $this->session->flashdata('error_msg', 'Error in insertion');
                $path = 'user/feedback/' . $fc;
                redirect($path);
            }
        } else {
            if (!empty($fc_id)) {
                $venue_id = encrypt_decrypt('decrypt', $fc_id);

                $where = array('function_catering.fc_id' => $venue_id);
                $join = array(
                    'fc_images' => 'fc_images.fc_id = function_catering.fc_id'
                );
                $fc_details = $this->basic_model->get_record_join_tables('function_catering', $where, 'function_catering.fc_id, fc_business_name, fc_overview, fc_img_name', $join, '', '', '', '', $join_type = 'left', 'function_catering.fc_id');

                if (!empty($fc_details)) {
                    $data['fc_id'] = $fc_id;

                    $data['fc_details'] = $fc_details;

                    $where = array('user_id' => $user_id);
                    $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

                    unset($_POST);
                    $this->load->view('header');
                    $this->load->view('menu', $data);
                    $this->load->view('user/submit_feed', $data);
                    $this->load->view('footer');
                } else {
                    redirect('dashboard');
                }
            } else {
                redirect('dashboard');
            }
        }
    }

    /* ----------Feedback--------------- */

    public function my_reviews() {

        $data = array();
        $this->load->model('web_model');
        $user_id = $this->session->userdata('user_id');
        if (!empty($user_id)) {
            $id = $this->input->post('id');
            $id = isset($id) ? $id : '';

            $x = $this->web_model->get_all_user_review_count($user_id, $id);
            $data['all_row_count'] = $x;

            $default_limit = DEFAULT_ROW_COUNT_REVIEW_PAGINATION;
            $data['fc_type'] = 0; //for load default load my remview
            if ($this->input->post('is_load')) {
                $id = $this->input->post('id');

                $x = $this->web_model->get_all_user_review_count($user_id, $id);
                $data['all_row_count'] = $x;

                $id = $this->input->post('id');
                $data['reviews'] = $this->web_model->user_review($user_id, $default_limit, $id);

                echo $this->load->view('user/load_user_review', $data, TRUE);
            } else {
                $data['title'] = 'My reviews';
                $this->load->view('header', $data);
                $data['reviews'] = $this->web_model->user_review($user_id, $default_limit, $where = '');

                $user_id = $this->session->userdata('user_id');
                $where = "user_id='" . $user_id . "'";
                $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

                $this->load->view('menu', $data);
                $this->load->view('user/user_review', $data);
                $this->load->view('footer');
            }
        } else {
            redirect('user_login');
        }
    }

    public function my_venue_reviews() {
        $data = array();
        $user_id = $this->session->userdata('user_id');

        $this->db->where(array('f_status' => 1));
        $num = $this->db->count_all_results('feedback');
        $fc_type = 1;
        $data['fc_type'] = $fc_type;
        $data['all_row_count'] = $num;
        $default_limit = DEFAULT_ROW_COUNT_REVIEW_PAGINATION;
        $this->load->model('web_model');
        if ($this->input->post('is_load')) {
            $start = $this->input->post('id');
            $data['reviews'] = $this->web_model->catering_venue_reviews($user_id, $default_limit, $fc_type, $start);

            echo $this->load->view('user/load_user_review', $data, TRUE);
        } else {
            $data['reviews'] = $this->web_model->catering_venue_reviews($user_id, $default_limit, $fc_type);
            $data['title'] = 'My venue review';

            $user_id = $this->session->userdata('user_id');
            $where = "user_id='" . $user_id . "'";
            $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

            $this->load->view('header', $data);
            $this->load->view('menu', $data);
            $this->load->view('user/user_review', $data);
            $this->load->view('footer');
        }
    }

    public function my_catering_reviews() {
        $data = array();
        $user_id = $this->session->userdata('user_id');
        $fc_type = 2;
        $this->db->where(array('f_status' => 1));
        $num = $this->db->count_all_results('feedback');

        $data['all_row_count'] = $num;
        $default_limit = DEFAULT_ROW_COUNT_REVIEW_PAGINATION;
        $data['fc_type'] = $fc_type;
        $this->load->model('web_model');
        if ($this->input->post('is_load')) {
            $start = $this->input->post('id');
            $data['reviews'] = $this->web_model->catering_venue_reviews($user_id, $default_limit, $fc_type, $start);

            echo $this->load->view('user/load_user_review', $data, TRUE);
        } else {
            $data['reviews'] = $this->web_model->catering_venue_reviews($user_id, $default_limit, $fc_type);

            $data['title'] = 'My catering reviews';

            $user_id = $this->session->userdata('user_id');
            $where = "user_id='" . $user_id . "'";
            $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

            $this->load->view('header', $data);
            $this->load->view('menu', $data);
            $this->load->view('user/user_review', $data);
            $this->load->view('footer');
        }
    }

    public function recently_viewed() {
        $user = $this->session->userdata('user_id');

        $where_user = array('user_id' => $user);
        // $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

        $where = array('r_view_user' => $user, 'function_catering.fc_status' => 1, 'function_catering.fc_is_deleted' => 0);
        $join = array(
            'function_catering' => 'function_catering.fc_id = recently_viewed.r_view_fc'
        );
        $colown = array('function_catering.fc_id', 'function_catering.fc_type', 'function_catering.fc_business_name', 'function_catering.fc_listing_picture', 'function_catering.fc_overview');
        $viewed = $this->basic_model->get_record_join_tables('recently_viewed', $where, $colown, $join, '', '', 'r_view_created_on', 'DESC');


        $data['viewed'] = $viewed;

        $data['title'] = 'Recently viewed';
        $data['wish_list'] = home_page_data();

        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('user/recently_viewed', $data);
        $this->load->view('footer');
    }

// <-new changes->
// <-new changes->
    function venue_catering() {

        $this->load->view('header');
        $this->load->view('menu');
        $this->load->view('user/venue_catering');
        $this->load->view('footer');
    }

// request for venue and catering
    public function venue_catering_request() {
        $this->load->library("form_validation");
        $this->form_validation->set_rules("bus_auth_req", "Type", "required");
        //$this->form_validation->set_rules("bus_auth_notes","Notes","required");

        if ($this->form_validation->run() == false) {
            echo json_encode(array('responce' => false, 'status' => 'Error'));
        } else {

            $user_id = $this->session->userdata('user_id');

            $data = array(
                'bus_auth_status' => '1',
                'bus_auth_req' => $this->input->post('bus_auth_req'),
                'bus_auth_notes' => $this->input->post('bus_auth_notes'),
                'bus_auth_create_time' => date('Y-m-d H:i:s'),
                'user_id' => $user_id,
            );

            $bus_auth_id = $this->basic_model->insert_records('businesses_authorized', $data);
            $data['success'] = 'Waiting for approval.';

            $bus_auth_data = array('bus_auth_id' => $bus_auth_id);
            $bus_auth_data = $this->basic_model->get_record_where('businesses_authorized', '', $bus_auth_data);
            $user_id = $bus_auth_data[0]->user_id;
            if ($bus_auth_data[0]->bus_auth_req == 1) {
                $type = 'Venue';
            } else if ($bus_auth_data[0]->bus_auth_req == 2) {
                $type = 'Catering';
            }
            $user_data = $this->basic_model->get_record_where('users', 'user_firstname,user_lastname,user_email', array('user_id' => $user_id));
            $user_name = ucfirst($user_data[0]->user_firstname . ' ' . $user_data[0]->user_lastname);
            $user_email = $user_data[0]->user_email;
            $fc_new_data = array('fc_type' => $type, 'name' => $user_name, 'bus_auth_notes' => $bus_auth_data[0]->bus_auth_notes, 'email' => $user_email, 'url' => base_url('admin/businesses_update'), 'bus_auth_create_time' => $bus_auth_data[0]->bus_auth_create_time);
            $this->load->helper('email_template_helper');
            approved_bus_auth_mail($fc_new_data);
            echo json_encode(array('responce' => TRUE, 'status' => 'Success'));
        }
    }

    public function submit_query_thank_you() {
        $user_id = $this->session->userdata('user_id');
        $where = array('user_id' => $user_id);
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);
        $fc_id = encrypt_decrypt('decrypt', $this->uri->segment(3));
        $where = array('function_catering.fc_id' => $fc_id);
        $join = array(
            'fc_images' => 'fc_images.fc_id = function_catering.fc_id'
        );
        // $data['fc_details'] = $this->basic_model->get_record_where('function_catering','',$where );
        $data['fc_details'] = $this->basic_model->get_record_join_tables('function_catering', $where, 'function_catering.*, fc_img_name', $join, '', '', '', '', $join_type = 'left', 'function_catering.fc_id');
        // print_r($data);die;

        $this->load->view('header');
        $this->load->view('menu', $data);
        $this->load->view('user/query_thank_you', $data);
        $this->load->view('footer');
    }

// <-new changes->
    function check_valid_address() {
        $city = $_POST['city'];
        $postcode = $_POST['postcode'];
        $state = $_POST['user_state'];
        $aus_councils_count = $this->basic_model->get_row('tbl_suburb_state', $where = array('suburb' => $city, 'postcode' => $postcode, 'state' => $state), array());

        //print_r(	$aus_councils_count);
        if (!empty($aus_councils_count)) {
            echo json_encode(array("status" => true, "exist" => 1));
            //echo json_encode("status"->true,"exist"->1);
        } else {
            echo json_encode(array("status" => true, "exist" => 0));
        }
    }

}
