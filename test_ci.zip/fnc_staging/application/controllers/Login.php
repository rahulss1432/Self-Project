<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //-----------load mail helper----------//
        $this->load->helper('email_template_helper');
        // ------------- Admin --------------------//
        if ($this->session->userdata('super_admin'))
            redirect('admin/dashboard');
        /* --------load social libery------- */
        $this->load->library('google/Google');
        $this->load->library('facebook/facebook');
        $this->load->helper('cookie');
        $this->load->library('form_validation');
        $this->load->helper('form');
    }

    public function index() {
        redirect('user_login');
    }

    public function user_login() {
        if ($this->session->userdata('user_email'))
            redirect('dashboard');

        $this->load->library('user_agent');
        $this->load->helper('cookie');
        $data['email'] = get_cookie('email');
        $data['password'] = get_cookie('password');

        $data['facebbok_url'] = $this->facebook->login_url();
        $data['gmail_url'] = $this->google->loginURL();


        $this->load->view('header');
        $this->load->view('menu');
        $this->load->view('login/user_login', $data);
        $this->load->view('footer');
    }

    public function check_login() {
        if ($this->session->userdata('user_email'))
            redirect('dashboard');

        $this->load->library('user_agent');

        if ($this->input->post()) {
            if ($this->input->post('g-recaptcha-response')) {
                if ($this->input->post('remember') == 1) {
                    set_cookie('email', $this->input->post('email'), '3600000');
                    set_cookie('password', $this->input->post('password'), '3600000');
                } else {
                    delete_cookie('email'); /* Delete email cookie */
                    delete_cookie('password'); /* Delete password cookie */
                }
                if (CAPTCHA_SHOW) {
                    $verify = $this->verify_recapacha($this->input->post('g-recaptcha-response'));
                    if (!$verify) {
                        $this->session->set_flashdata('error', 'something when wrong!!');
                        redirect('user_login');
                    }
                }
                $email = trim($this->input->post('email'));
                $password = md5($this->input->post('password'));
                $status = 1;

                $where = array('user_email' => $email, 'user_password' => $password, 'user_status' => $status, 'is_deleted' => 0);
                $result = $this->basic_model->get_record_where('users', $column = '*', $where);


                if ($result) {
                    $session_data = array(
                        'user_id' => $result[0]->user_id,
                        'user_email' => $result[0]->user_email,
                        'user_firstname' => $result[0]->user_firstname,
                        'user_lastname' => $result[0]->user_lastname,
                        'user_image' => $result[0]->user_image,
                    );

                    $this->session->set_userdata($session_data);

                    // if (!empty($this->input->post('referrer')))
                    //    redirect($this->input->post('referrer'));
                    redirect('dashboard');
                }

                if (empty($result)) {

                    $where = "user_email='" . $email . "' and user_password='" . $password . "'";
                    $result = $this->basic_model->get_record_where('users', $column = '*', $where);

                    if ($result) {
                        $user_id = $result[0]->user_id;
                        $userData = array(
                            'user_id' => $user_id,
                            'user_firstname' => $result[0]->user_firstname,
                            'user_lastname' => $result[0]->user_lastname,
                            'user_email' => $result[0]->user_email,
                            'user_hash' => $result = md5(rand(1000, 9000000))
                        );

                        $where = 'user_id = "' . $user_id . '"';
                        $this->basic_model->update_records('users', $userData, $where);

                        $data['confirm'] = customer_confirmation_mail($userData);

                        $this->session->set_flashdata('error', 'Your account is not verified. Please visit your inbox to verify your account.!!');
                        redirect('user_login');
                    } else {
                        $this->session->set_flashdata('error', 'Invalid email or password.!!');
                        $data['email'] = get_cookie('email');
                        $data['password'] = get_cookie('password');
                        $data['facebbok_url'] = $this->facebook->login_url();
                        $data['gmail_url'] = $this->google->loginURL();
                        $this->load->view('header');
                        $this->load->view('menu');
                        $this->load->view('login/user_login', $data);
                        $this->load->view('footer');
                    }
                }
            } else {
                $this->session->set_flashdata('error', 'Please verify captcha!');
                redirect('user_login');
                $data['email'] = get_cookie('email');
                $data['password'] = get_cookie('password');
                $data['facebbok_url'] = $this->facebook->login_url();
                $data['gmail_url'] = $this->google->loginURL();
                $this->load->view('header');
                $this->load->view('menu');
                $this->load->view('login/user_login', $data);
                $this->load->view('footer');
            }
        } else {
            redirect('user_login');
        }
    }

    function verify_recapacha($response) {
        $post_data = http_build_query(
                array(
                    'secret' => CAPTCHA_SECRET_KEY,
                    'response' => $response,
                    'remoteip' => $_SERVER['REMOTE_ADDR']
                )
        );

        $opts = array('http' =>
            array(
                'method' => 'POST',
                'header' => 'Content-type: application/x-www-form-urlencoded',
                'content' => $post_data
            )
        );

        $context = stream_context_create($opts);
        $response = file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
        $result = json_decode($response, TRUE);
        return $result;
    }

    /* ------------30-11-17 g---------- */

    public function user_registration() {
        if ($this->session->userdata('user_email'))
            redirect('dashboard');

        $data['facebbok_url'] = $this->facebook->login_url();
        $data['gmail_url'] = $this->google->loginURL();

        if ($this->input->post('submit')) {
            if ($_POST['g-recaptcha-response']) {
                $post_data = http_build_query(
                        array(
                            'secret' => CAPTCHA_SECRET_KEY,
                            'response' => $this->input->post('g-recaptcha-response'),
                            'remoteip' => $_SERVER['REMOTE_ADDR']
                        )
                );

                $opts = array('http' =>
                    array(
                        'method' => 'POST',
                        'header' => 'Content-type: application/x-www-form-urlencoded',
                        'content' => $post_data
                    )
                );

                $context = stream_context_create($opts);
                $response = file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
                $result = json_decode($response, TRUE);

                if ($result['success']) {
                    $hash = md5(rand(1000, 9000000));
                    $where = "user_email = '" . $this->input->post('email') . "'";

                    $data = array(
                        'user_firstname' => $this->input->post('first_name'),
                        'user_lastname' => $this->input->post('last_name'),
                        'user_email' => $this->input->post('email'),
                        'user_password' => md5($this->input->post('password')),
                        'user_phone_no' => $this->input->post('phone'),
                        'user_postcode' => $this->input->post('postcode'),
                        'user_hash' => $hash
                    );
                    $user_id = $this->basic_model->insert_records('users', $data);
                    $data['user_id'] = $user_id;
                    $username = $data['user_firstname'] . ' ' . $data['user_lastname'];

                    $data['user_id'] = $user_id;
                    if ($user_id > 0) {
                        $data['confirm'] = customer_confirmation_mail($data);
                        $this->load->view('login/massage_box', $data);
                    }
                }
            } else {
                $this->session->set_flashdata('error', 'Please verify captcha!');
                $this->load->view('header');
                $this->load->view('menu');
                $this->load->view('login/user_registration', $data);
                $this->load->view('footer');
            }
        } else {
            $this->load->view('header');
            $this->load->view('menu');
            $this->load->view('login/user_registration', $data);
            $this->load->view('footer');
        }
    }

    function test_mail() {
        $this->load->helper('email_template_helper');
        $send_to_friend['user_firstname'] = 'Ritesh ';
        $send_to_friend['user_lastname'] = 'Paliwal';
        $send_to_friend['user_id'] = '5';
        $send_to_friend['user_hash'] = '85';
        $send_to_friend['user_email'] = 'atifkhan2456@gmail.com';
        $response = customer_confirmation_mail($send_to_friend);
    }

    function verifyaccount($id, $hashFunction) {
        $where = "user_id = " . $id;
        $result = $this->basic_model->get_record_where('users', 'user_hash,user_email,is_registration', $where);
        $user_email = $result[0]->user_email;
        // print_r($user_email);die;

        if (!empty($result)) {
            if ($result[0]->user_hash == $hashFunction) {
                $data = array('user_status' => 1);
                $data['success'] = $this->basic_model->update_records('users', $data, $where);

                if ($result[0]->is_registration == 1) {
                    random_password($user_email);
                }


                $this->load->view('login/massage_box', $data);
                $hash_delete = array('user_hash' => '');
                $this->basic_model->update_records('users', $hash_delete, $where);
            } else {
                $data['error'] = '1';
                $this->load->view('login/massage_box', $data);
            }
        } else {
            $data['error'] = '1';
            $this->load->view('login/massage_box', $data);
        }
    }

    function email_existance() {
        if ($this->input->post('email')) {
            $email = $this->input->post('email');
            $where = "user_email = '" . $email . "'";
            $result = $this->basic_model->get_record_where('users', $column = '', $where);
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
        if ($this->input->get('email')) {
            $email = $this->input->get('email');
            $where = "user_email = '" . $email . "'";
            $result = $this->basic_model->get_record_where('users', $column = '', $where);
            if (!empty($result)) {
                echo 'true';
            } else {
                echo 'false';
            }
        }
    }

    function login_google() {
        if ($this->session->userdata('user_email'))
            redirect('dashboard');

        if (isset($_GET['code'])) {
            $this->google->getAuthenticate();
            $gpInfo = $this->google->getUserInfo();

            $userData['user_social_id'] = $gpInfo['id'];
            $userData['user_register_type'] = 'gmail';
            $userData['user_firstname'] = $gpInfo['given_name'];
            $userData['user_lastname'] = $gpInfo['family_name'];
            $userData['user_email'] = $gpInfo['email'];
            $userData['user_image'] = !empty($gpInfo['picture']) ? $gpInfo['picture'] : '';
            $userData['user_status'] = 1;
            //insert or update user data to the database
            $where = "user_email='" . $gpInfo['email'] . "'";
            $result = $this->basic_model->get_record_where('users', $column = '*', $where);

            if (empty($result)) {
                $result = $this->basic_model->insert_records('users', $userData, $multiple = FALSE);
                $result = $this->basic_model->get_record_where('users', $column = '*', $where);
            }

            $session_data = array(
                'user_id' => $result[0]->user_id,
                'user_email' => $result[0]->user_email,
                'user_firstname' => $result[0]->user_firstname,
                'user_lastname' => $result[0]->user_lastname,
                'user_image' => $result[0]->user_image,
            );
            $this->session->set_userdata($session_data);

            redirect('dashboard');
        } else {
            redirect('user_login');
        }
    }

    function login_social() {
        if ($this->session->userdata('user_email'))
            redirect('dashboard');

        if ($this->facebook->is_authenticated()) {
            $userProfile = $this->facebook->request('get', '/me?fields=id,first_name,last_name,email,gender,locale,picture');
			if (empty($userProfile['id'])){
				redirect('user_login');
			}
			if (empty($userProfile['email'])) {
                $userProfile['email'] = $userProfile['id'];
            }
            $userData['user_social_id'] = $userProfile['id'];
            $userData['user_register_type'] = 'facebook';
            $userData['user_firstname'] = $userProfile['first_name'];
            $userData['user_lastname'] = $userProfile['last_name'];
            $userData['user_email'] = $userProfile['email'];
            $userData['user_image'] = $userProfile['picture']['data']['url'];
            $userData['user_status'] = 1;
            $where = "user_email='" . $userProfile['email'] . "'";
            $result = $this->basic_model->get_record_where('users', $column = '*', $where);
            if (empty($result)) {
                $this->basic_model->insert_records('users', $userData, $multiple = FALSE);
                $result = $this->basic_model->get_record_where('users', $column = '*', $where);
            }
            $session_data = array(
                'user_id' => $result[0]->user_id,
                'user_email' => $result[0]->user_email,
                'user_firstname' => $result[0]->user_firstname,
                'user_lastname' => $result[0]->user_lastname,
                'user_image' => $result[0]->user_image,
            );
            $this->session->set_userdata($session_data);
            redirect('dashboard');
        } else {
            redirect('user_login');
        }
    }

    public function user_logout() {
        $this->session->sess_destroy();
        redirect('user_login');
    }

    /* ------------30-11-17 g---------- */

    //---------------- P (30-11-2017) ------------------------//

    public function admin_login() {
        if ($this->session->userdata('super_admin'))
            redirect('dashboard');
        $this->load->helper('cookie');
        $data['email'] = get_cookie('email');
        $data['password'] = get_cookie('password');
        $this->load->view('login/admin_login', $data);
    }

    public function perform_adlogin() {
        if ($this->session->userdata('super_admin'))
            redirect('dashboard');
        //if ($this->input->post('email') && $this->input->post('password')) {
        if ($this->input->post('email') && $this->input->post('password') && $this->input->post('g-recaptcha-response')) {
            if ($this->input->post('remember') == 1) {
                set_cookie('email', $this->input->post('email'), '36000');
                set_cookie('password', $this->input->post('password'), '36000');
            } else {
                delete_cookie('email'); /* Delete email cookie */
                delete_cookie('password'); /* Delete password cookie */
            }
            $post_data = http_build_query(
                    array(
                        'secret' => CAPTCHA_SECRET_KEY,
                        'response' => $this->input->post('g-recaptcha-response'),
                        'remoteip' => $_SERVER['REMOTE_ADDR']
                    )
            );
            $opts = array('http' =>
                array(
                    'method' => 'POST',
                    'header' => 'Content-type: application/x-www-form-urlencoded',
                    'content' => $post_data
                )
            );
            // $context = stream_context_create($opts);
            // $response = file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
            //  $result = json_decode($response, TRUE);
            // print_r($result);die;
            $result['success'] = true;
            if ($result['success']) {
                $where = array(
                    'email' => trim($this->input->post('email')),
                    'password' => md5($this->input->post('password'))
                );
                $admin = $this->basic_model->get_record_where('admin', '', $where);
                if (!empty($admin)) {
                    $newdata = array(
                        'id' => $admin[0]->id,
                        'email' => $admin[0]->email,
                        'name' => $admin[0]->name,
                        'super_admin' => TRUE
                    );
                    $this->session->set_userdata($newdata);
                    redirect('admin');
                } else {
                    $this->session->set_flashdata('error', 'Invalid email or password!!');
                    redirect('login/admin_login');
                }
            } else {
                // $this->session->set_flashdata('error', 'Sorry Google Recaptcha Unsuccessful!!');
                redirect('login/admin_login');
            }
        } else {
            $this->session->set_flashdata('error', 'Please verify captcha!');
            redirect('login/admin_login');
        }
    }

    public function forgot_password() {
        if ($this->input->post()) {
            $response = $this->verify_recapacha($this->input->post('g-recaptcha-response'));
            if ($response['success']) {
                $hash = md5(rand(1000, 9000000));
                $email = $this->input->post('email');
                $where = array('user_email' => $email);
                $result = $this->basic_model->get_record_where('users', $column = array('user_id', 'user_firstname', 'user_lastname'), $where);
                if (!empty($result)) {
                    $userData = array(
                        'user_hash' => $hash
                    );
                    $this->basic_model->update_records('users', $userData, $where);
                    $userData['user_id'] = encrypt_decrypt('encrypt', $result[0]->user_id);
                    $userData['user_firstname'] = $result[0]->user_firstname;
                    $userData['user_lastname'] = $result[0]->user_lastname;
                    $userData['user_email'] = $email;
                    forgot_password_mail($userData);
                    $this->session->unset_userdata('error');
                    $this->session->set_flashdata('message', 'Please visit your mail inbox to reset your password.!!');
                    redirect('Login/user_login');
                }
            } else {
                $this->session->unset_userdata('message');
                $this->session->set_flashdata('error', 'Please verify captcha!');
                // redirect('Login/forgot_password');
                $this->load->view('header');
                $this->load->view('menu');
                $this->load->view('login/forgot_password');
                $this->load->view('footer');
            }
        }
        $this->load->view('header');
        $this->load->view('menu');
        $this->load->view('login/forgot_password');
        $this->load->view('footer');
    }

    function reset_password($id = false, $hashFunction = false) {
        if (!empty($id) && !empty($hashFunction)) {
            $data = array('user_id' => $id);
            $user_id = encrypt_decrypt('decrypt', $id);
            $where = array('user_id' => $user_id, 'user_hash' => $hashFunction);
            $result = $this->basic_model->get_record_where('users', array('user_firstname', 'user_lastname', 'user_email'), $where);
            if (!empty($result)) {
                $this->load->view('header');
                $this->load->view('menu');
                $this->load->view('login/reset_password', $data);
                $this->load->view('footer');
            } else {
                redirect(site_url());
            }
        } elseif ($this->input->post()) {
            $user_id = encrypt_decrypt('decrypt', $this->input->post('user_id'));
            $password = md5($this->input->post('password'));
            $userData = array('user_password' => $password, 'user_hash' => '');
            $this->basic_model->update_records('users', $userData, $where = array('user_id' => $user_id));
            $this->session->set_flashdata('message', 'your password reset succefully..!!');
            redirect(site_url('user_login'));
        } else {
            redirect(site_url());
        }
    }

}
