<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Catering extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('user_email'))
            redirect('login/user_login');
        $this->load->model("custom_model");
    }

    public function index() {
        
    }

    public function add_catering() {
        $permission = venue_permission();
        if (isset($permission->bus_auth_status) && $permission->bus_auth_status != 1)
            redirect(base_url('request'));

        $data['title'] = 'Add catering';
        $this->load->library('cart');
        $this->cart->destroy();
        $data['plan_id'] = 0;
        $data['draft_catering_images'] = false;
        $data['first_cart'] = false;
        $data['free'] = false;
        if ($this->uri->segment(2)) {
            $catering_id = encrypt_decrypt('decrypt', $this->uri->segment(2));
            $where_fc = array('fc_id' => $catering_id);
            $catering = $this->basic_model->get_record_where('function_catering', '', $where_fc);

            if (!empty($catering)) {
                $data['draf_catering'] = $catering;

                $draft['council'] = '';
                $where_for_council = array('suburb' => $catering[0]->fc_suburb, 'postcode' => $catering[0]->fc_postcode);
                $council = $this->basic_model->get_record_where('aus_councils', 'council', $where_for_council);
                if ($council) {
                    $data['council'] = $council[0]->council;
                } else {
                    $data['council'] = $catering[0]->fc_suburb;
                }

                //--------plan Details----------//
                $where_details = array('csr_fc_id' => $catering_id);
                $data['catering_product_detials'] = $this->basic_model->get_record_where('catering_search_radius', '', $where_details);
                $cart_details = '';

                if (!empty($catering[0]->fc_cart_data) && $catering[0]->fc_cart_data != 'free') {
                    $cart_details = $catering[0]->fc_cart_data;
                    $cart_details = unserialize($cart_details);
                }

                if (!empty($cart_details) && $catering[0]->fc_cart_data != 'free') {
                    $i = 0;


                    if (in_array(1, array_column($cart_details, 'id'))) {
                        $response = $this->add2cart(1);
                        $data['plan_id'] = 1;
                        $data['first_cart'] = $response['row_id'];
                    } elseif (in_array(2, array_column($cart_details, 'id'))) {
                        $response = $this->add2cart(2);
                        $data['plan_id'] = 2;
                        $data['first_cart'] = $response['row_id'];
                    }

                    foreach ($cart_details as $val) {
                        if ($val['id'] == 5 or $val['id'] == 6 or $val['id'] == 7) {
                            $extra_service = $this->add2cart($val['id'], $data['first_cart']);
                            if ($extra_service) {
                                $j = 0;
                                foreach ($extra_service['cart_content'] as $ser) {
                                    if ($j == 1) {
                                        $data['draft_service_pack'] = $ser;
                                    }
                                    $j++;
                                }
                            }
                        }
                        $i++;
                    }
                } else {
                    $data['free'] = 'free';
                }



                //--------Basic catering Details----------//

                $where_details = array('cd_fc_id' => $catering_id);
                $data['draft_catering_details'] = $this->basic_model->get_record_where('catering_details', '', $where_details);

                $where_images = array('fc_id' => $catering_id);
                $data['draft_catering_images'] = $this->basic_model->get_record_where('fc_images', '', $where_images);

                $where_csr_radius = array('csr_fc_id' => $catering_id);
                $data['catering_radius'] = $this->basic_model->get_record_where('catering_search_radius', 'csr_radius', $where_csr_radius);
            }
        }

        $where = 'pro_id IN (1,2)';
        $data['packs'] = $this->basic_model->get_record_where('products', '', $where);
        $data['service_area_pack'] = $this->basic_model->get_record_where('products', '', 'pro_id IN (5,6,7)');

        $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');

        $data['function_types'] = $this->basic_model->get_record_where('fnc_types', $column = '', $where = array('type' => 'function_type'));

        $data['menus'] = $this->basic_model->get_record_where('fnc_types', $column = '', $where = array('type' => 'menus'));

        $data['cuisine'] = $this->basic_model->get_record_where('fnc_types', $column = '', $where = array('type' => 'cuisine'));

        $data['catering_services'] = $this->basic_model->get_record_where('fnc_types', $column = '', $where = array('type' => 'services'));

        $user_id = $this->session->userdata('user_id');
        $where = "user_id='" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '*', $where);

        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('catering/add_catering', $data);
        $this->load->view('footer');
    }

    public function get_pricing() {
        if ($this->input->post('pack_id')) {
            $pro_id = $this->input->post('pack_id');

            $where_pro = array('pro_id' => $pro_id);
            $get_price = $this->basic_model->get_record_where('products', 'pro_price', $where_pro);

            if (!empty($get_price)) {
                $price = $get_price[0]->pro_price;

                echo json_encode(array('status' => TRUE, 'price' => $price));
            } else {
                echo json_encode(array('status' => FALSE));
            }
        } else {
            echo json_encode(array('status' => FALSE));
        }
    }

    public function cart_details() {
        $this->load->library('cart');
        $cart_content = $this->cart->contents();

        echo '<pre>';
        print_r($cart_content);
    }

    public function add2cart($pack_id = 0, $draft_FirstCart = '') {
        $this->load->library('cart');

        if ($pack_id > 0 || $this->input->post('pack_id')) {
            if ($pack_id > 0) {
                $pro_id = $pack_id;
            } else {
                $pro_id = $this->input->post('pack_id');
            }

            $where_pro = array('pro_id' => $pro_id);
            $get_price = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);

            if (!empty($get_price)) {
                $name = $get_price[0]->pro_title;
                $price = $get_price[0]->pro_price;

                // Product currency 0-Dollar / 1-Cent
                $pro_curr = $get_price[0]->pro_curr;

                if ($this->input->post('firstcart') || $draft_FirstCart) {
                    $cart_content = $this->cart->contents();
                    if (!empty($draft_FirstCart)) {
                        $firstcart = $draft_FirstCart;
                    } else {
                        $firstcart = $this->input->post('firstcart');
                    }
                    $product_id = $cart_content[$firstcart]['id'];

                    $where_p = array('pro_id' => $product_id);
                    $get_term = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_p);

                    if (!empty($get_term)) {
                        $term = $get_term[0]->pro_pay_type;

                        if ($term == 'month') {
                            $price = $price * 30;
                        } elseif ($term == 'year') {
                            $price = $price * 365;
                        }
                    }
                }

                if ($pro_curr == 1) {
                    $price = $price / 100;
                }


                $data = array(
                    'id' => $pro_id,
                    'qty' => 1,
                    'price' => $price,
                    'name' => 'Product-ID-' . $pro_id
//                    'pro_desc' =>    
                    );

                $row_id = $this->cart->insert($data);

                $cart_content = $this->cart->contents();

                $cart_total = $this->cart->total();
                if ($pack_id > 0) {
                    $result = array('status' => TRUE, 'cart_content' => $cart_content, 'cart_total' => $cart_total, 'row_id' => $row_id);
                    return $result;
                } else {
                    echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'cart_total' => $cart_total));
                }
            } else {
                echo json_encode(array('status' => FALSE));
            }
        } else {
            echo json_encode(array('status' => FALSE));
        }
    }

    function removeCart() {
        $this->load->library('cart');
        if ($this->input->post('row_id')) {
            $rowid = $this->input->post('row_id');

            $this->cart->remove($rowid);

            $cart_content = $this->cart->contents();
            $cart_total = $this->cart->total();

            echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'cart_total' => $cart_total));
        }
    }

    function update_pricing_show() {
        $this->load->library('cart');
        if ($this->input->post('pack_id')) {
            $pro_id = $this->input->post('pack_id');
            $rowid = $this->input->post('firstcart');
            $this->cart->remove($rowid);

            $where_pro = array('pro_id' => $pro_id);
            $get_price = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);

            if (!empty($get_price)) {
                $price = $get_price[0]->pro_price;

                $data = array(
                    'id' => $pro_id,
                    'qty' => 1,
                    'price' => $price,
                    'name' => 'Product-ID-' . $pro_id
                    );

                $new_plan_id = $this->cart->insert($data);

                if ($this->input->post('service_product_id') && $this->input->post('extra_service_area_id')) {
                    $where_pro = array('pro_id' => $this->input->post('extra_service_area_id'));
                    $get_price_extra_service = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);
                    if (!empty($get_price_extra_service)) {
                        $name = $get_price_extra_service[0]->pro_title;
                        $price = $get_price_extra_service[0]->pro_price;

                        // Product currency 0-Dollar / 1-Cent
                        $pro_curr = $get_price_extra_service[0]->pro_curr;

                        if ($this->input->post('firstcart')) {
                            $cart_content = $this->cart->contents();

                            $firstcart = $this->input->post('firstcart');
                            $product_id = $cart_content[$new_plan_id]['id'];

                            $where_p = array('pro_id' => $product_id);
                            $get_term = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_p);

                            if (!empty($get_term)) {
                                $term = $get_term[0]->pro_pay_type;

                                if ($term == 'month') {
                                    $price = $price * 30;
                                } elseif ($term == 'year') {
                                    $price = $price * 365;
                                }
                            }
                        }

                        if ($pro_curr == 1) {
                            $price = $price / 100;
                        }


                        $data = array(
                            'rowid' => $this->input->post('service_product_id'),
                            'id' => $pro_id,
                            'qty' => 1,
                            'price' => $price,
                            'name' => 'Product-ID-' . $pro_id
                            );

                        $this->cart->update($data);
                    }
                }
            }
            $cart_content = $this->cart->contents();
            $cart_total = $this->cart->total();

            echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'cart_total' => $cart_total, 'new_plan_id' => $new_plan_id));
        } else {
            echo json_encode(array('status' => FALSE));
        }
    }

    public function save_profile() {
        require APPPATH . 'libraries/Stripe/lib/Stripe.php';
        $this->load->library('cart');
        $this->load->helper('email_template_helper');
        $user_id = $this->session->userdata('user_id');

        if ($this->input->post()) {
            $data = $this->input->post();

            if ($data['free'] == 1) {
                $cart_data = 'free';
            } else {
                $cart_data = serialize($this->cart->contents());
            }
            $today = date('Y-m-d');

            $plan = 1;
            if ($this->input->post('plan1')) {
                $plan = $data['plan1'];
            }



            $where_pro = array('pro_id' => $plan);
            $get_price = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_pro);

            $validity_type = $get_price[0]->pro_pay_type;

            $valid_upto = date("Y-m-d", strtotime("+1 $validity_type", strtotime($today)));

            $catering_data = array('fc_user' => $user_id, 'fc_business_name' => $data['fc_business_name'], 'fc_council' => $data['fc_council'], 'fc_state' => $data['fc_state'], 'fc_suburb' => $data['fc_suburb'], 'fc_street' => $data['fc_street'], 'fc_postcode' => $data['fc_postcode'], 'fc_country' => $data['fc_country'], 'fc_lat' => $data['fc_lat'], 'fc_lng' => $data['fc_lng'], 'fc_abn' => $data['fc_abn'], 'fc_contact_name' => $data['fc_contact_name'], 'fc_phone_no' => $data['fc_phone_no'], 'fc_website' => $data['fc_website'], 'fc_email' => $data['fc_email'], 'fc_overview' => $data['fc_overview'], 'fc_details' => $data['fc_details'], 'fc_min_guest' => $data['fc_min_guest'], 'fc_max_guest' => $data['fc_max_guest'], 'fc_cart_data' => $cart_data, 'fc_free' => $data['free'], 'fc_type' => 2, 'fc_status' => 5, 'fc_created_date' => date('Y-m-d H:i:s'), 'fc_modified_on' => date('Y-m-d H:i:s'));

            $listing_image = UploadFcListingPicture();
            if (!empty($listing_image)) {
                $catering_data['fc_listing_picture'] = $listing_image;
            }

            if ($this->input->post('fc_pricing')) {
                $catering_data['fc_pricing'] = implode(',', $data['fc_pricing']);
            }

            $catering_details = array();
            if ($this->input->post('cd_function_type')) {
                $catering_details['cd_function_type'] = implode(',', $data['cd_function_type']);
            }

            if ($this->input->post('cd_menus')) {
                $catering_details['cd_menus'] = implode(',', $data['cd_menus']);
            }

            if ($this->input->post('cd_cuisine')) {
                $catering_details['cd_cuisine'] = implode(',', $data['cd_cuisine']);
            }
            if ($this->input->post('cd_services')) {
                $catering_details['cd_services'] = implode(',', $data['cd_services']);
            }

            //echo $data['fc_id'];

            if ($data['fc_id'] != '') {
                $fc_id = encrypt_decrypt('decrypt', $data['fc_id']);
                $this->basic_model->update_records('function_catering', $catering_data, array('fc_id' => $fc_id)); // update data in main table
            } else {
                $fc_id = $this->basic_model->insert_records('function_catering', $catering_data); // insert data in main table
            }


            if ($this->input->post('csr_radius_id') && $cart_data != 'free') {
                $date = date('Y-m-d');
                $csr_radius = $this->basic_model->get_record_where('products', 'pro_desc', $where = array('pro_id' => $data['csr_radius_id']));
                $check_csr_radius = $this->basic_model->get_record_where('catering_search_radius', '', array('csr_fc_id' => $fc_id));
                $external_area = array('csr_fc_id' => $fc_id, 'csr_plan_id' => $data['csr_radius_id'], 'csr_radius' => $csr_radius[0]->pro_desc, 'csr_created_on' => $date, 'csr_valid_upto' => $valid_upto);
                if (!empty($check_csr_radius)) {
                    $this->basic_model->update_records('catering_search_radius', $external_area, array('csr_fc_id' => $check_csr_radius[0]->csr_fc_id)); // insert data in main table
                } else {
                    $this->basic_model->insert_records('catering_search_radius', $external_area); // insert data in main table
                }
            } else {
                $this->basic_model->delete_records('catering_search_radius', array('csr_fc_id' => $fc_id));
            }
            //echo $this->db->last_query();

            if ($fc_id > 0) {
                if ($catering_details) {
                    $catering_details['cd_fc_id'] = $fc_id;
                    $check_catering_details = $this->basic_model->get_record_where('catering_details', '', array('cd_fc_id' => $fc_id));

                    if (empty($check_catering_details)) {
                        $this->basic_model->insert_records('catering_details', $catering_details); // insert data in main table
                    } else {
                        $this->basic_model->update_records('catering_details', $catering_details, array('cd_fc_id' => $fc_id));
                    }
                }
            }


            if ($fc_id > 0) {
                $img_count = 5;
                $check_existing_img = $this->basic_model->get_record_where('fc_images', '', array('fc_id' => $fc_id));
                $ic = 1;
                if (!empty($check_existing_img)) {
                    // Multi venue images
                    $this->load->library('upload');
                    $ic = 1;
                    foreach ($check_existing_img as $img_key) {
                        $croped_image_name = 'dimesion_image_' . ($ic);
                        $image_url = false;
                        if ($this->input->post($croped_image_name) != '0') {
                            $image_url = $this->input->post($croped_image_name);
                            if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                                rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                            }
                        } elseif ($_FILES["fc_img_name$ic"]['size'] != 0) {
                            $this->upload->initialize($this->set_upload_options());
                            if (!$this->upload->do_upload("fc_img_name$ic")) {
                                $error = $this->upload->display_errors();
                            } else {
                                $dataInfo[] = $this->upload->data();
                                $i_data = $this->upload->data();
                                $image_url = $i_data['file_name'];
                            }
                        }
                        if (!empty($image_url)) {
                            $image_update = array('fc_img_name' => $image_url, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                            $where_img = array('fc_img_id' => $img_key->fc_img_id);
                            $this->basic_model->update_records('fc_images', $image_update, $where_img);
                        }

                        $ic++;
                        $img_count--;
                    }
                }

                if ($img_count > 0) {
                    // Multi venue images
                    $this->load->library('upload');

                    for ($ic; $ic <= 5; $ic++) {
                        $image_url = '';
                        $croped_image_name = 'dimesion_image_' . ($ic);
                        if ($this->input->post($croped_image_name) != '0') {
                            $image_url = $this->input->post($croped_image_name);
                            if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                                rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                            }
                        } else if ($_FILES["fc_img_name$ic"]['size'] != 0) {
                            $this->upload->initialize($this->set_upload_options());
                            if (!$this->upload->do_upload("fc_img_name$ic")) {
                                $error = $this->upload->display_errors();
                            } else {
                                $dataInfo[] = $this->upload->data();
                                $i_data = $this->upload->data();
                                $image_url = $i_data['file_name'];
                            }
                        }
                        if (!empty($image_url)) {
                            $image_data = array('fc_img_name' => $image_url, 'fc_id' => $fc_id, 'fc_img_modified_on' => date('Y-m-d h:i:s'));
                            $this->basic_model->insert_records('fc_images', $image_data);
                        }
                    }
                }
            }


            $result = array('status' => true, 'fc_id' => encrypt_decrypt('encrypt', $fc_id));
        } else {
            $result = array('status' => false);
        }

        echo $response = json_encode($result);
    }

    public function save_catering() {
        require APPPATH . 'libraries/Stripe/lib/Stripe.php';
        $this->load->library('cart');
        $this->load->helper('email_template_helper');
        $user_id = $this->session->userdata('user_id');
        $data = $this->input->post();

        if ($this->input->post()) {
            if (count($this->cart->contents()) > 0) {
                $cart_item = $this->cart->contents();
                $total_ammount = 0;
                foreach ($cart_item as $val) {
                    if ($val['subtotal'] > 0)
                        $total_ammount += $val['subtotal'];
                }

                $voucher_log_id = '';
                $voucher_id = '';
                if (!empty($data['voucher_code'])) {
                    $result = checkVoucherHelper($data['voucher_code']);

                    if ($result['status']) {
                        $voucher_id = $result['voucher_id'];
                        $redeemed_ammount = abs($result['redeemed_ammount']); // value is redeem ammount
                        $voucher_value = abs($result['voucher_value']);
                        $voucher_log_id = insert_voucher_log($user_id, $data['voucher_code'], $voucher_value, $redeemed_ammount);
                    }
                }

                $cart_total = $this->cart->total();
                //if aaplied voucher greather or equal to total ammount then skip payment method
                $data['payment_method'] = (!empty($data['payment_method']))? $data['payment_method']: '';

                if ($cart_total > 0 && $data['payment_method'] == 1 && (!empty($data['payment_method']))) {

                    $cart_data = json_encode($this->cart->contents());
                    $chargeable_amount = $cart_total * 100;

                    Stripe::setApiKey(STRIPE_PRIVATE_KEY);

                    try {
                        if (!isset($_POST['stripeToken']))
                            throw new Exception("The Stripe Token was not generated correctly.");

                        $charge = Stripe_Charge::create(array("amount" => $chargeable_amount,
                            "currency" => "aud",
                            "card" => $this->input->post('stripeToken'),
                            "description" => $this->input->post('venue_email')));

                        $captured = $charge['captured'];
                        $paid = $charge['paid'];
                        $data['id'] = $charge['id'];

                        if ((isset($captured) && $captured == 1) && (isset($paid) && $paid == 1)) {
                            $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => $charge['id'], 'pay_for' => json_encode($this->cart->contents()), 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 1, 'payment_status' => 2, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'pay_created_on' => date('Y-m-d H:i:s'));
                            $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                        } else {
                            throw new Exception("Error in transaction.");
                        }
                    } catch (Exception $e) {
                        $error_msg = $e->getMessage();
                        $this->session->set_flashdata('error_msg', $error_msg);
                        redirect('catering/add_catering');
                        exit();
                    }
                } elseif (!empty($data['payment_method']) == 2 && (!empty($data['payment_method']))) {
                    $order_data = json_encode($this->cart->contents());
                    $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => '', 'pay_for' => $order_data, 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 2, 'payment_status' => 1, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'pay_created_on' => date('Y-m-d H:i:s'));
                    $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                    $this->account_details_invoice($order_data, $cart_total, $txn_id);
                } elseif($cart_total == 0) {
                    $order_data = json_encode($this->cart->contents());
                    $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => '', 'pay_for' => $order_data, 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 3, 'payment_status' => 2, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'pay_created_on' => date('Y-m-d H:i:s'));
                    $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                }else{
                   $this->session->set_flashdata('error_msg', 'No payment method found');
                   redirect('add_venue');
                   exit();
               }
           }

           if ($data['free'] == 1) {
            $cart_data = 'free';
        } else {
            $cart_data = json_encode($this->cart->contents());
        }

        $today = date('Y-m-d');

        $plan = 1;
        if ($this->input->post('plan1')) {
            $plan = $data['plan1'];
        }


        $where_pro = array('pro_id' => $plan);
        $get_price = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_pro);

        $validity_type = $get_price[0]->pro_pay_type;

        $valid_upto = date("Y-m-d", strtotime("+1 $validity_type", strtotime($today)));

        $business_name = $data['fc_business_name'];
        $business_mail = $data['fc_email'];
        $business_number = $data['fc_phone_no'];
        $service_type = $data['free'];
        $catering_data = array('fc_current_plan' => $plan, 'fc_user' => $user_id, 'fc_business_name' => $data['fc_business_name'], 'fc_council' => $data['fc_council'], 'fc_state' => $data['fc_state'], 'fc_suburb' => $data['fc_suburb'], 'fc_street' => $data['fc_street'], 'fc_postcode' => $data['fc_postcode'], 'fc_country' => $data['fc_country'], 'fc_lat' => $data['fc_lat'], 'fc_lng' => $data['fc_lng'], 'fc_abn' => $data['fc_abn'], 'fc_contact_name' => $data['fc_contact_name'], 'fc_phone_no' => $data['fc_phone_no'], 'fc_website' => $data['fc_website'], 'fc_email' => $data['fc_email'], 'fc_overview' => $data['fc_overview'], 'fc_details' => $data['fc_details'], 'fc_min_guest' => $data['fc_min_guest'], 'fc_max_guest' => $data['fc_max_guest'], 'fc_cart_data' => $cart_data, 'fc_free' => $data['free'], 'fc_type' => 2, 'fc_status' => 0, 'fc_valid_upto' => $valid_upto,'fc_created_date' => date('Y-m-d H:i:s'));



        if ($this->input->post('fc_pricing')) {
            $catering_data['fc_pricing'] = implode(',', $data['fc_pricing']);
        }

        $catering_details = array();
        if ($this->input->post('cd_function_type')) {
            $catering_details['cd_function_type'] = implode(',', $data['cd_function_type']);
        }

        if ($this->input->post('cd_menus')) {
            $catering_details['cd_menus'] = implode(',', $data['cd_menus']);
        }

        if ($this->input->post('cd_cuisine')) {
            $catering_details['cd_cuisine'] = implode(',', $data['cd_cuisine']);
        }
        if ($this->input->post('cd_services')) {
            $catering_details['cd_services'] = implode(',', $data['cd_services']);
        }

        if ($data['fc_id'] != '') {
            $fc_id = encrypt_decrypt('decrypt', $data['fc_id']);
                $this->basic_model->update_records('function_catering', $catering_data, array('fc_id' => $fc_id)); // update data in main table
            } else {
                $fc_id = $this->basic_model->insert_records('function_catering', $catering_data); // insert data in main table
            }

            if (!empty($txn_id)) {
                $where_tx = array('pay_id' => $txn_id);
                $update_txn_data = array('pay_fc_id' => $fc_id);
                $this->basic_model->update_records('payment_details', $update_txn_data, $where_tx);
            }

            if (!empty($voucher_log_id) && $fc_id) {
                $this->basic_model->update_records('voucher_logs', array('fc_id' => $fc_id), array('v_log_id' => $voucher_log_id));
            }

            if ($this->input->post('csr_radius_id')) {
                $date = date('Y-m-d');
                $csr_radius = $this->basic_model->get_record_where('products', 'pro_desc', $where = array('pro_id' => $data['csr_radius_id']));
                $check_csr_radius = $this->basic_model->get_record_where('catering_search_radius', '', array('csr_fc_id' => $fc_id));
                $external_area = array('csr_fc_id' => $fc_id, 'csr_plan_id' => $data['csr_radius_id'], 'csr_radius' => $csr_radius[0]->pro_desc, 'csr_created_on' => $date, 'csr_valid_upto' => $valid_upto);
                if (!empty($check_csr_radius)) {
                    $this->basic_model->update_records('catering_search_radius', $external_area, array('csr_fc_id' => $check_csr_radius[0]->csr_fc_id)); // insert data in main table
                } else {
                    $this->basic_model->insert_records('catering_search_radius', $external_area); // insert data in main table
                }
            }


            if ($fc_id > 0) {
                $catering_details['cd_fc_id'] = $fc_id;
                $check_catering_details = $this->basic_model->get_record_where('catering_details', '', array('cd_fc_id' => $fc_id));

                if (empty($check_catering_details)) {
                    $this->basic_model->insert_records('catering_details', $catering_details); // insert data in main table
                } else {
                    $this->basic_model->update_records('catering_details', $catering_details, array('cd_fc_id' => $fc_id));
                }
            }

            $requeste_date = $this->basic_model->get_record_where('function_catering',array('fc_created_date'), array('fc_id' => $fc_id));
            $requested_date = $requeste_date[0]->fc_created_date;

            if ($fc_id > 0) {
                $this->cart->destroy();

                $user_data = $this->basic_model->get_record_where('users', '', array('user_id' => $user_id));
                $name = $this->session->userdata('user_firstname') . ' ' . $this->session->userdata('user_lastname');
                $fc_id_encypt = encrypt_decrypt('encrypt', $fc_id);
                $service_type = ($service_type == 1) ? 'free' : 'paid';
                $catering_mail_data = array('fc_id' => $fc_id, 'type' => 'catering', 'name' => $name, 'email' => $this->session->userdata('user_email'), 'business_name' => $business_name, 'url' => base_url() . 'web/single_catering/' . $fc_id_encypt, 'telephone' => $user_data[0]->user_phone_no, 'business_email' => $business_mail, 'business_number' => $business_number, 'service_type' => $service_type,'requested_date' => $requested_date);
                pending_fc_mail_to_user($catering_mail_data);
                alert_admin_mail($catering_mail_data);


                $this->session->set_flashdata('success', 'catering inserted successfully');
                redirect('my_catering');
            } else {
                $this->session->set_flashdata('error', 'Error in insertion');
                redirect('catering/add_catering');
            }
        } else {
            redirect('catering/add_catering');
        }
    }

    public function set_upload_options() {
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/fc_images/';
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = '0';
        $config['overwrite'] = FALSE;

        return $config;
    }

    public function my_catering() {
        $data = array();

        $user_id = $this->session->userdata('user_id');

        $where_user = array('user_id' => $user_id);
        $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

        $where = array('fc_user' => $user_id, 'fc_type' => 2, 'function_catering.fc_is_deleted' => 0, 'function_catering.fc_status' => 1);

        $catering = $this->basic_model->get_record_where('function_catering', array('fc_id', 'fc_business_name', 'fc_overview', 'fc_listing_picture', 'fc_valid_upto', 'fc_free'), $where);
        $data['catering'] = $catering;

        $data['title'] = 'My catering';
        $data['wish_list'] = home_page_data();
        $this->load->view('header', $data);
        $this->load->view('menu', $data);
        $this->load->view('catering/my_catering', $data);
        $this->load->view('footer');
    }

    public function edit_catering($cateringID = 0) {
        require APPPATH . 'libraries/Stripe/lib/Stripe.php';
        $this->load->library('cart');
        $data['title'] = 'Edit catering';
        $user_id = $this->session->userdata('user_id');
        
        if ($this->input->post()) {
            $data = $this->input->post();
            $fc_id = $this->session->userdata('fc_id');
            $total_ammount = 0;
            if (count($this->cart->contents()) > 0) {
                $cart_item = $this->cart->contents();
                foreach ($cart_item as $val) {
                    if ($val['subtotal'] > 0)
                        $total_ammount += $val['subtotal'];
                }


                $payment_status = '';

                $voucher_log_id = '';
                $voucher_id = '';
                if (!empty($data['voucher_code'])) {
                    $result = checkVoucherHelper($data['voucher_code']);

                    if ($result['status']) {
                        $voucher_id = $result['voucher_id'];
                        $redeemed_ammount = abs($result['redeemed_ammount']); // value is redeem ammount
                        $voucher_value = abs($result['voucher_value']);
                        $voucher_log_id = insert_voucher_log($user_id, $data['voucher_code'], $voucher_value, $redeemed_ammount, $fc_id);
                    }
                }

                $cart_total = $this->cart->total();
                $data['payment_method'] = (!empty($data['payment_method']))? $data['payment_method']: '';
                
                if ($cart_total > 0 && $data['payment_method'] == 1 && (!empty($data['payment_method']))) {
                    $cart_data = json_encode($this->cart->contents());
                    $chargeable_amount = $cart_total * 100;

                    Stripe::setApiKey(STRIPE_PRIVATE_KEY);

                    try {
                        if (!isset($_POST['stripeToken']))
                            throw new Exception("The Stripe Token was not generated correctly.");

                        $charge = Stripe_Charge::create(array("amount" => $chargeable_amount,
                            "currency" => "aud",
                            "card" => $this->input->post('stripeToken'),
                            "description" => $this->input->post('venue_email')));

                        $captured = $charge['captured'];
                        $paid = $charge['paid'];
                        $data['id'] = $charge['id'];

                        if ((isset($captured) && $captured == 1) && (isset($paid) && $paid == 1)) {
                            $payment_status = 1;

                            $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => $charge['id'], 'pay_for' => json_encode($this->cart->contents()), 'pay_fc_id' => $fc_id, 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 1, 'payment_status' => 2, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'payment_mode' => 1, 'pay_created_on' => date('Y-m-d H:i:s'));
                            $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                        } else {
                            throw new Exception("Error in transaction.");
                        }
                    } catch (Exception $e) {
                        $error_msg = $e->getMessage();
                        $this->session->set_flashdata('error_msg', $error_msg);
                        redirect('my_catering');
                        exit();
                    }
                } elseif ($data['payment_method'] == 2 && (!empty($data['payment_method']))) { // here paymetnt method 2 mean pay by account
                    $payment_status = 'panding'; // here payment status false mean payment is pending
                    $order_data = json_encode($this->cart->contents());
                    $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => '', 'pay_for' => $order_data, 'pay_fc_id' => $fc_id, 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 2, 'payment_status' => 1, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'payment_mode' => 1, 'pay_created_on' => date('Y-m-d H:i:s'));
                    $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                    $this->account_details_invoice($order_data, $cart_total, $txn_id);
                } elseif( $cart_total == 0) {
                    $order_data = json_encode($this->cart->contents());
                    $payment_data = array('pay_user' => $user_id, 'pay_txn_id' => '', 'pay_for' => $order_data, 'pay_fc_id' => $fc_id, 'pay_total_amount' => $cart_total, 'total_amount' => $total_ammount, 'payment_method' => 3, 'payment_status' => 2, 'voucher_log_id' => $voucher_log_id, 'voucher_id' => $voucher_id, 'payment_mode' => 1, 'pay_created_on' => date('Y-m-d H:i:s'));
                    $txn_id = $this->basic_model->insert_records('payment_details', $payment_data);
                    $payment_status = 1; // if voucher grether then cart total then no payment required
                }else{
                   $this->session->set_flashdata('error_msg', 'No payment method found');
                   redirect('add_venue');
                   exit();
               }

                if ($payment_status && $payment_status != 'panding') { // if payment status pending mean this data update at admin end when payment is verifed
                    $cart_item = $this->cart->contents();

                    foreach ($cart_item as $cart_val) {
                        if ($cart_val['id'] == 1 || $cart_val['id'] == 2) {
                            $where_fc = array('fc_id' => $fc_id, 'fc_user' => $user_id);
                            $catering_data = $this->basic_model->get_record_where('function_catering', 'fc_valid_upto', $where_fc);
                            $old_expiry_date = $catering_data[0]->fc_valid_upto;

                            if (strtotime($old_expiry_date) < strtotime(date('Y-m-d'))) {
                                $old_expiry_date = date('Y-m-d');
                            }

                            $where_pro = array('pro_id' => $cart_val['id']);
                            $get_price = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_pro);
                            $validity_type = $get_price[0]->pro_pay_type;
                            $valid_upto = date("Y-m-d", strtotime("+1 $validity_type", strtotime($old_expiry_date)));

                            $this->basic_model->update_records('function_catering', array('fc_valid_upto' => $valid_upto, 'fc_free' => 0, 'fc_current_plan' => $cart_val['id']), $where_fc);
                        } elseif ($cart_val['id'] == 5 || $cart_val['id'] == 6 || $cart_val['id'] == 7) {
                            $where_pro = array('pro_id' => $cart_val['id']);
                            $get_price = $this->basic_model->get_record_where('products', '', $where_pro);
                            $radius_range = $get_price[0]->pro_desc;

                            $crs_data = array('csr_plan_id' => $cart_val['id'], 'csr_radius' => $radius_range, 'csr_status' => 0);
                            $check_exist = $this->basic_model->get_record_where('catering_search_radius', '', array('csr_fc_id' => $fc_id));

                            if (empty($check_exist)) {
                                $crs_data['csr_fc_id'] = $fc_id;
                                $this->basic_model->insert_records('catering_search_radius', $crs_data);
                            } else {
                                $this->basic_model->update_records('catering_search_radius', $crs_data, array('csr_fc_id' => $fc_id));
                            }
                        }
                    }
                }
            }


            $catering_id = encrypt_decrypt('decrypt', $this->input->post('catering'));

            $update_data = array('fc_business_name' => $data['catering_business_name'], 'fc_council' => $data['catering_council'], 'fc_state' => $data['catering_state'], 'fc_suburb' => $data['catering_suburb'], 'fc_street' => $data['catering_street'], 'fc_postcode' => $data['catering_postcode'], 'fc_country' => $data['catering_country'], 'fc_lat' => $data['lat'], 'fc_lng' => $data['lng'], 'fc_abn' => $data['catering_abn'], 'fc_contact_name' => $data['catering_contact_name'], 'fc_phone_no' => $data['catering_phone_no'], 'fc_website' => $data['catering_website'], 'fc_email' => $data['catering_email'], 'fc_overview' => $data['catering_overview'], 'fc_details' => $data['catering_details'], 'fc_min_guest' => $data['catering_min_guest'], 'fc_max_guest' => $data['catering_max_guest']);

            $listing_image = UploadFcListingPicture();
            if (!empty($listing_image)) {
                $update_data['fc_listing_picture'] = $listing_image;
            }

            if ($this->input->post('catering_pricing')) {
                $update_data['fc_pricing'] = implode(',', $data['catering_pricing']);
            } else {
                $update_data['fc_pricing'] = '';
            }
            // unlink_image("main",$catering_id);

            $where = array('fc_id' => $catering_id, 'fc_user' => $user_id);


            $this->basic_model->update_records('function_catering', $update_data, $where);

            $catering_details = array();

            if ($this->input->post('catering_function_type')) {
                $catering_details['cd_function_type'] = implode(',', $data['catering_function_type']);
            } else {
                $catering_details['cd_function_type'] = '';
            }

            if ($this->input->post('catering_menus')) {
                $catering_details['cd_menus'] = implode(',', $data['catering_menus']);
            } else {
                $catering_details['cd_menus'] = '';
            }

            if ($this->input->post('catering_cuisine')) {
                $catering_details['cd_cuisine'] = implode(',', $data['catering_cuisine']);
            } else {
                $catering_details['cd_cuisine'] = '';
            }

            if ($this->input->post('catering_services')) {
                $catering_details['cd_services'] = implode(',', $data['catering_services']);
            } else {
                $catering_details['cd_services'] = '';
            }

            $where_details = array('cd_fc_id' => $catering_id);

            $this->basic_model->update_records('catering_details', $catering_details, $where_details);

            $img_count = 5;

            if ($this->input->post('img_count')) {
                $img_count = $img_count - $this->input->post('img_count');

                // Multi venue images
                $this->load->library('upload');

                $dataInfo = array();
                $files = $_FILES;
                $cpt = count($_FILES['catering_image']['name']);

                $image_data = array();

                for ($i = 0; $i < $cpt; $i++) {
                    $croped_image_name = 'dimesion_image_' . ($i);

                    if ($this->input->post($croped_image_name) != '0') {
                        $image_url = $this->input->post($croped_image_name);
                        if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                            rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                        }
                        $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $catering_id, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                    } elseif ($files['catering_image']['size'][$i] != 0) {
                        $_FILES['catering_image']['name'] = $files['catering_image']['name'][$i];
                        $_FILES['catering_image']['type'] = $files['catering_image']['type'][$i];
                        $_FILES['catering_image']['tmp_name'] = $files['catering_image']['tmp_name'][$i];
                        $_FILES['catering_image']['error'] = $files['catering_image']['error'][$i];
                        $_FILES['catering_image']['size'] = $files['catering_image']['size'][$i];

                        $this->upload->initialize($this->set_upload_options());

                        if (!$this->upload->do_upload('catering_image')) {
                            $error = $this->upload->display_errors();
                        } else {
                            $dataInfo[] = $this->upload->data();
                            $i_data = $this->upload->data();
                            $image_url = $i_data['file_name'];
                            $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $catering_id, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                        }
                    }
                }

                if (!empty($image_data)) {
                    $this->basic_model->insert_records('fc_images', $image_data, TRUE);
                }
            }

            if ($img_count > 0) {
                // Multi venue images
                $this->load->library('upload');

                for ($ic = 0; $ic < $img_count; $ic++) {
                    $croped_image_name = 'dimesion_image_' . ($ic);
                    $image_url = false;
                    if ($this->input->post($croped_image_name) != '0') {
                        $image_url = $this->input->post($croped_image_name);
                        if (file_exists("uploads/fc_images/temp/" . $image_url)) {
                            rename("uploads/fc_images/temp/" . $image_url, "uploads/fc_images/" . $image_url);
                        }
                    } else if ($_FILES["catering_image$ic"]['size'] != 0) {
                        $this->upload->initialize($this->set_upload_options());
                        if (!$this->upload->do_upload("catering_image$ic")) {
                            $error = $this->upload->display_errors();
                        } else {
                            $dataInfo[] = $this->upload->data();

                            $i_data = $this->upload->data();
                            $image_url = $i_data['file_name'];
                        }
                    }
                    if (!empty($image_url)) {

                        unlink_image('slide', $data["image$ic"]);

                        $image_update = array('fc_img_name' => $image_url, 'fc_img_modified_on' => date('Y-m-d H:i:s'));

                        $where_img = array('fc_img_id' => $data["image$ic"]);
                        $this->basic_model->update_records('fc_images', $image_update, $where_img);
                    }
                }
            }

            redirect('my_catering');
        } else {
            if ($user_id) {
                $this->cart->destroy();
                $catering_id = encrypt_decrypt('decrypt', $cateringID);
                $where_fc = array('fc_id' => $catering_id, 'fc_user' => $user_id);
                $catering = $this->basic_model->get_record_where('function_catering', '', $where_fc);

                if (!empty($catering)) {
                    $data['catering'] = $catering;
                    $this->session->set_userdata(array('fc_id' => $catering[0]->fc_id));
                    $where_user = array('user_id' => $user_id);
                    $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

                    $data['council'] = '';
                    $where_for_council = array('suburb' => $catering[0]->fc_suburb, 'postcode' => $catering[0]->fc_postcode);
                    $council = $this->basic_model->get_record_where('aus_councils', 'council', $where_for_council);
                    if ($council) {
                        $data['council'] = $council[0]->council;
                    } else {
                        $data['council'] = $catering[0]->fc_suburb;
                    }

                    //--------Basic catering Details----------//

                    $where = 'pro_id IN (1,2)';
                    $data['packs'] = $this->basic_model->get_record_where('products', '', $where);
                    $data['service_area_pack'] = $this->basic_model->get_record_where('products', '', 'pro_id IN (5,6,7)');

                    $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');

                    $where_function_type = array('type' => 'function_type', 'status' => 1);
                    $data['function_type'] = $this->basic_model->get_record_where('fnc_types', '', $where_function_type);

                    $where_cuisine = array('type' => 'cuisine', 'status' => 1);
                    $data['cuisine'] = $this->basic_model->get_record_where('fnc_types', '', $where_cuisine);

                    $where_menus = array('type' => 'menus', 'status' => 1);
                    $data['menus'] = $this->basic_model->get_record_where('fnc_types', '', $where_menus);

                    $where_services = array('type' => 'services', 'status' => 1);
                    $data['services'] = $this->basic_model->get_record_where('fnc_types', '', $where_services);

                    //--------Basic catering Details----------//

                    $where_details = array('cd_fc_id' => $catering_id);
                    $data['catering_details'] = $this->basic_model->get_record_where('catering_details', '', $where_details);

                    $where_images = array('fc_id' => $catering_id);
                    $data['catering_images'] = $this->basic_model->get_record_where('fc_images', '', $where_images);

                    $where_csr_radius = array('csr_fc_id' => $catering_id, 'csr_status' => 0);
                    $data['catering_radius'] = $this->basic_model->get_record_where('catering_search_radius', '', $where_csr_radius);

                    $where_subscpt = array('fc_id' => $catering_id, 'subsciption_active' => 1);
                    $subscpt_result = $this->basic_model->get_record_where('stripe_subscription', 'ss_id,subsciption_active', $where_subscpt);

                    $data['subscrption'] = (!empty($subscpt_result)) ? $subscpt_result[0]->ss_id : false;

                    $this->load->view('header', $data);
                    $this->load->view('menu', $data);
                    $this->load->view('catering/edit_catering', $data);
                    $this->load->view('footer');
                }
            }
        }
    }

    public function extra_service_update_cart() {
        $status = true;
        $this->load->library('cart');
        $pro_id = $this->input->post('pack_id');

        $where_pro = array('pro_id' => $pro_id);
        $get_price = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);

        if (!empty($get_price)) {
            $name = $get_price[0]->pro_title;
            $price = $get_price[0]->pro_price;
            $pro_curr = $get_price[0]->pro_curr;

            $remaining_price = 0;
            if ($this->session->userdata('fc_id')) {
                $fc_id = $this->session->userdata('fc_id');
                $user_id = $this->session->userdata('user_id');
                $where_fc = array('fc_id' => $fc_id, 'fc_user' => $user_id);
                $catering = $this->basic_model->get_record_where('function_catering', '', $where_fc);
                $today_date = date('Y-m-d');
                $valid_upto = $catering[0]->fc_valid_upto;

                $diff = date_diff(date_create($valid_upto), date_create($today_date));
                $days = (int) $diff->format("%a");
                $remaining_price = $price * $days;

                if ($pro_curr == 1) {
                    $remaining_price = $remaining_price / 100;
                }

                $data = array(
                    'id' => $pro_id,
                    'qty' => 1,
                    'price' => $remaining_price,
                    'name' => 'Product-ID-' . $pro_id,
                    'options' => array('days_payment' => $days)
                    );

                $this->cart->insert($data);
            }

            $added_prize = 0;
            if ($this->input->post('firstcart')) {
                $cart_content = $this->cart->contents();
                $firstcart = $this->input->post('firstcart');

                $product_id = $cart_content[$firstcart]['id'];

                $where_p = array('pro_id' => $product_id);
                $get_term = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_p);

                if (!empty($get_term)) {
                    $term = $get_term[0]->pro_pay_type;
                    if ($term == 'month') {
                        $added_prize = $price * 30;
                    } elseif ($term == 'year') {
                        $added_prize = $price * 365;
                    }

                    if ($pro_curr == 1) {
                        $added_prize = $added_prize / 100;
                    }
                    $data = array(
                        'id' => $pro_id,
                        'qty' => 1,
                        'price' => $added_prize,
                        'name' => 'Product-ID-' . $pro_id
                        );
                    $this->cart->insert($data);
                }
            }

            $cart_content = $this->cart->contents();
            $cart_total = $this->cart->total();

            echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'cart_total' => $cart_total));
        } else {
            echo json_encode(array('status' => FALSE));
        }
    }

    public function update_plan_catering() {
        $this->load->library('cart');
        $pro_id = $this->input->post('pack_id');
        $fc_id = $this->session->userdata('fc_id');

        $where_pro = array('pro_id' => $pro_id);
        $get_price = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);
        $cart_content = $this->cart->contents();
        if (!empty($get_price)) {
            $name = $get_price[0]->pro_title;
            $price = $get_price[0]->pro_price;
            $pro_curr = $get_price[0]->pro_curr;

            $data = array(
                'id' => $pro_id,
                'qty' => 1,
                'price' => $price,
                'name' => 'Product-ID-' . $pro_id
                );


            if ($this->input->post('firstcart')) {
                $row_id = $this->input->post('firstcart');
                $this->cart->remove($row_id);
            }

            $firstcart = $this->cart->insert($data); //row_id of plan
            $extra_service_row_id = '';
            $extra_service_id = 0;
            $status = true;

            $cart_content = $this->cart->contents();

            if (!empty($cart_content)) {
                foreach ($cart_content as $key => $val) {
                    if (($val['id'] == 5 || $val['id'] == 6 || $val['id'] == 7)) {
                        if (!array_key_exists('options', $val)) {
                            $this->cart->remove($key);
                        }
                        $extra_service_id = $val['id'];
                    }
                }
            } else {
                $where_csr_radius = array('csr_fc_id' => $fc_id, 'csr_status' => 0);
                $old_csr_radius = $this->basic_model->get_record_where('catering_search_radius', '', $where_csr_radius);

                if (!empty($old_csr_radius)) {
                    $extra_service_id = $old_csr_radius[0]->csr_plan_id;

                    $where_pro = array('pro_id' => $extra_service_id);
                    $extra_service = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);
                    $extra_service_prize = $extra_service[0]->pro_price;
                    $extra_service_curr = $extra_service[0]->pro_curr;
                }
            }

            if (!empty($extra_service_id)) {
                $where_pro = array('pro_id' => $extra_service_id);
                $extra_service = $this->basic_model->get_record_where('products', 'pro_title, pro_price, pro_curr', $where_pro);
                $extra_service_prize = $extra_service[0]->pro_price;
                $extra_service_curr = $extra_service[0]->pro_curr;
            }
        }

        if ($firstcart && $extra_service_id != 0) {
            $cart_content = $this->cart->contents();
            $product_id = $cart_content[$firstcart]['id'];

            $where_p = array('pro_id' => $product_id);
            $get_term = $this->basic_model->get_record_where('products', 'pro_pay_type', $where_p);

            if (!empty($get_term)) {
                $term = $get_term[0]->pro_pay_type;
                if ($term == 'month') {
                    $extra_service_prize = $extra_service_prize * 30;
                } elseif ($term == 'year') {
                    $extra_service_prize = $extra_service_prize * 365;
                }
            }

            if ($extra_service_curr == 1) {
                $extra_service_prize = $extra_service_prize / 100;
            }

            $service_pack = array(
                'id' => $extra_service_id,
                'qty' => 1,
                'price' => $extra_service_prize,
                'name' => 'Product-ID-' . $extra_service_id
                );

            $extra_service_row_id = $this->cart->insert($service_pack);
        }

        $cart_content = $this->cart->contents();
        $cart_total = $this->cart->total();
        echo json_encode(array('status' => TRUE, 'firstcart' => $firstcart, 'extra_service_row_id' => $extra_service_row_id, 'cart_content' => $cart_content, 'cart_total' => $cart_total));
    }

    public function removePlan() {
        $this->load->library('cart');
        $fc_id = $this->session->userdata('fc_id');
        $user_id = $this->session->userdata('user_id');

        $cart_content = $this->cart->contents();
        if (!empty($cart_content)) {
            foreach ($cart_content as $key => $val) {
                if (!array_key_exists('options', $val)) {
                    $this->cart->remove($key);
                }
            }
        }

        $cart_content = $this->cart->contents();
        $cart_total = $this->cart->total();
        echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'cart_total' => $cart_total));
    }

    public function edit_remove_cart() {
        $this->load->library('cart');
        $cart_content = $this->cart->contents();

        if (!empty($cart_content)) {
            foreach ($cart_content as $key => $val) {
                if ($val['id'] == 5 || $val['id'] == 6 || $val['id'] == 7) {
                    $this->cart->remove($key);
                }
            }
        }

        if ($this->session->userdata('fc_id')) {
            $fc_id = $this->session->userdata('fc_id');
            $user_id = $this->session->userdata('user_id');
            $this->basic_model->update_records('catering_search_radius', array('csr_status' => 1), array('csr_fc_id' => $fc_id));
        }

        $cart_content = $this->cart->contents();
        $cart_total = $this->cart->total();
        echo json_encode(array('status' => TRUE, 'cart_content' => $cart_content, 'cart_total' => $cart_total));
    }

    public function check_business_name() {
        if ($this->input->get('fc_business_name') && !$this->input->get('fc_id')) {
            $fc_business_name = $this->input->get('fc_business_name');
            $result = $this->basic_model->get_record_where('function_catering', '', array('fc_business_name' => $fc_business_name));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
        if ($this->input->get('catering_business_name')) {
            $fc_business_name = $this->input->get('catering_business_name');
            $fc_id = $this->input->get('fc_id');
            $fc_id = encrypt_decrypt('decrypt', $fc_id);
            $result = $this->basic_model->get_record_where('function_catering', '', array('fc_business_name' => $fc_business_name, 'fc_id !=' => $fc_id));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
        if ($this->input->get('fc_id') && $this->input->get('fc_business_name')) {
            $fc_business_name = $this->input->get('catering_business_name');
            $fc_id = $this->input->get('fc_id');
            $result = $this->basic_model->get_record_where('function_catering', '', array('fc_business_name' => $fc_business_name, 'fc_id !=' => $fc_id));
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
    }

    public function get_cart() {
        $cart_content = $this->cart->contents();

        if (!empty($cart_content)) {
            $my_cart = array();
            foreach ($cart_content as $key => $row) {
                $my_cart[$key] = $row['id'];
            }
            array_multisort($my_cart, SORT_ASC, $cart_content);

            $current_cart = array();

            foreach ($cart_content as $key => $value) {
                $pro_id = $value['id'];
                $where_pro = array('pro_id' => $pro_id);
                $get_name = $this->basic_model->get_record_where('products', 'pro_title', $where_pro);

                $title = strip_tags($get_name[0]->pro_title);
                $current_cart[] = array('name' => $title, 'subtotal' => $value['subtotal']);
            }

            $cart_total = $this->cart->total();

            echo json_encode(array('status' => TRUE, 'cart' => $current_cart, 'total' => $cart_total));
        } else {
            echo json_encode(array('status' => FALSE));
        }
    }

    public function account_details_invoice($order_data, $total, $payId) {
        require_once(APPPATH . 'libraries/mpdf/mpdf.php');
        $this->load->helper('email_template_helper');
        $data = array();
        $order_data = json_decode($order_data);

        $packs = $this->basic_model->get_record_where('products', 'pro_id,pro_title', '');
        foreach ($packs as $val) {
            $product[$val->pro_id] = (array) $val;
        }

        $data['invoice_no'] = sprintf("%010d", $payId);
        $data['order_total'] = $total;
        $data['products'] = $product;
        $data['order_data'] = $order_data;

        $file = $this->load->view('invoices/account_details_invoice', $data, TRUE);
        ob_clean();
        $mpdf = new mPDF();
        ob_end_clean();

        $mpdf->WriteHTML($file);
        $date = time();
        $pdf_name = 'fnc-bank-details' . $date . '.pdf';

        $mpdf->Output('assets/pdf/' . $pdf_name, 'F');
        send_account_details_invoice($pdf_name);
    }

}
