<?php
//print_r($this->session->userdata());
if ($this->session->userdata('user_image')) {
    $user_image = $this->session->userdata('user_image');
    //$user_image  = $user_data[0]->user_image;
} else {
    $user_image = base_url() . 'uploads/users/FnC_user_icon.png';
}


$venue_permission_ary = venue_permission();
$cater_permission_ary = cater_permission();

$venu_status = isset($venue_permission_ary->bus_auth_status) ? $venue_permission_ary->bus_auth_status : '';
$cater_status = isset($cater_permission_ary->bus_auth_status) ? $cater_permission_ary->bus_auth_status : '';

$venue_bus_auth_req = isset($venue_permission_ary->bus_auth_req) ? $venue_permission_ary->bus_auth_req : '';
$cater_bus_auth_req = isset($cater_permission_ary->bus_auth_req) ? $cater_permission_ary->bus_auth_req : '';
?>
<section class="section-1 space_change bg_white" id="header_dy">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 header">
                <div class="navbar-header head_logo" >
                    <!--<button type="button" class="navbar-toggle nv_align" data-toggle="collapse" data-target="#myNavbar" onclick="openNavMenu()">-->
                    <div class="col-xs-3 hidden-md hidden-sm hidden-lg"  style="padding: 0px;">
                        <a class="navbar-brand-search hidden-lg hidden-sm hidden-md" onclick="openNav()"><img class="main_logo" src="<?php echo base_url('assets/images/search_icon.svg'); ?>" /></a>
                        <a class="navbar-brand hidden-xs" href="<?php echo site_url(); ?>"><img class="main_logo" src="<?php echo base_url('assets/images/fnc_logo.svg'); ?>" /></a>
                    </div>
                    <div class="col-xs-6 col-sm-12 col-lg-8 aling_set" >
                        <a href="<?php echo base_url(''); ?>"><img class="main_logo fnc_mobile_logo" src="<?php echo base_url('assets/images/fnc_logo.svg'); ?>"></a>
                    </div>
                    <div class="col-xs-3">
                        <button type="button" class="navbar-toggle nv_align" onclick="openNavMenu()">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"> </span>
                            <span class="icon-bar"></span>                        
                        </button>
                    </div>
                </div>
                <div id="myNav" class="overlay">
                    <div class="col-xs-3"><a class="navbar-brand-search hidden-lg hidden-sm hidden-md" onclick="openNav()"><img class="main_logo" src="<?php echo base_url('assets/images/search_icon.svg'); ?>" /></a></div>
                    <div class="col-xs-6 col-sm-12"><a class="" href="<?php echo site_url(); ?>"><img class="main_logo fnc_mobile_logo" src="<?php echo base_url('assets/images/fnc_mobile_logo.svg'); ?>" /></a></div>
                    <div class="col-xs-3" style="padding: 0px;">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><img class="main_logo" src="<?php echo base_url('assets/images/close_icon.svg'); ?>" /></a>
                    </div>
                    <div class="overlay-content col-lg-12 col-md-4 col-sm-4 col-sx-4">
                       <!--<p>Search is currently locked while we onboard more venues…</p> -->
                        <div class="home-section">
                            <div class="home-section-1">
                                <form action='<?php echo site_url('search') ?>' method="get"  id="searchingform" role="form">
                                    <p>I'm looking for</p>
                                    <select name="fc_type[]">
                                        <option value="1">Function</option>
                                        <option value="2">Catering</option>
                                    </select>
                                    <p>In this area:</p>
                                    <input type="text" name="location" class="location_auto_complete" placeholder="Region, Council, Suburb or Post-Code" onfocus="this.placeholder = ''"
                                           onblur="this.placeholder = 'Region, Council, Suburb or Post-Code'" data-rule-required="true">
                                    <p>On this day:</p>
                                    <input type="text" class="date" name="search_date" id="" placeholder="DD-MM-YYYY" onfocus="this.placeholder = ''"
                                           onblur="this.placeholder = 'DD-MM-YYYY'" >
                                    <p>With this many people:</p>
                                    <input type="text" name="guest_count" autocomplete="off" placeholder="EG. 50" onfocus="this.placeholder = ''"
                                           onblur="this.placeholder = 'EG. 50'" data-rule-number="true" data-msg-number="Please enter numeric value">
                                    <button type="submit">Search</button> 
                                    <div class="overlay-content-footer text-align">
                                        <p style="text-align: center !important;"><a href="<?php echo site_url('privacy_policy'); ?>">Privacy Policy</a></p>
                                        <p style="text-align: center !important;"><a href="<?php echo site_url('term_condition'); ?>">Terms & Conditions</a></p>
                                        <p style="text-align: center !important;"><a>&copy; <?php echo date("Y"); ?> – Functions and Catering Australia Pty. Ltd.</a></p>
                                    </div>
                                </form>
                            </div>
                            <!--<div class="home-section-2">
                               <p>Search is currently locked while we onboard more venues….</p>
                               <img src="">
                               <p>Please check back here <br> 0/0/0</p>
                               </div> --> 
                        </div>
                        <div class="overlay-content-bottom">
                            <p>Developed with <img class="love-color" src="<?php echo base_url('assets/images/love.svg'); ?>"> & <img class="coffee-color" src="<?php echo base_url('assets/images/coffee.svg'); ?>"> by: <a href="http://yourdevelopmentteam.com.au/" target="blank">Your Development Team</a></p>
                        </div>
                    </div>
                </div>
                <div id="myNav1" class="overlay">
                    <div class="col-xs-3"><a class="navbar-brand-search hidden-lg hidden-sm hidden-md" onclick="openNav()"><img class="main_logo" src="<?php echo base_url('assets/images/search_icon.svg'); ?>" /></a></div>
                    <div class="col-xs-6 col-sm-12" style="text-align: center;"><a class="" href="<?php echo site_url(); ?>"><img class="main_logo fnc_mobile_logo" src="<?php echo base_url('assets/images/fnc_mobile_logo.svg'); ?>" /></a></div>
                    <div class="col-xs-3" style="padding: 0px;">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><img class="main_logo" src="<?php echo base_url('assets/images/close_icon.svg'); ?>" /></a>
                    </div>
                    <div class="overlay-content col-lg-12 col-md-4 col-sm-4 col-sx-4">
                       <!--<p>Search is currently locked while we onboard more venues…</p> -->
                        <div class="home-section">
                            <div class="home-section-1">
                                <div class="home-section-2">
                                    <p>Search is currently locked while <br> we onboard more venues….</p>
                                    <div class="pos_lock_new">
                                        <img src="<?php echo base_url('assets/images/lock.svg'); ?>" id="newdemo1"  class = "CloseLock close_lck" style="display: none;}">
                                        <img src="<?php echo base_url('assets/images/unlock.svg'); ?>" style="z-index: 9;" class= "OpenLock"> 
                                    </div>
                                    <p class="last">Please check back here <br> on : 01/07/2019</p>
                                </div>
                            </div>
                        </div>
                        <div class="overlay-content-bottom">
                            <p>Developed with <img class="love-color" src="<?php echo base_url('assets/images/love.svg'); ?>"> & <img class="coffee-color" src="<?php echo base_url('assets/images/coffee.svg'); ?>"> by: <a href="http://yourdevelopmentteam.com.au/" target="blank">Your Development Team</a></p>
                        </div>
                    </div>
                </div>
                <div id="myNavMenu" class="overlay">
                    <div class="col-xs-3"><a class="navbar-brand-search hidden-lg hidden-sm hidden-md" onclick="openNav()"><img class="main_logo" src="<?php echo base_url('assets/images/search_icon.svg'); ?>" /></a></div>
                    <div class="col-xs-6 col-sm-12" style="text-align: center;"><a class="" href="<?php echo site_url(); ?>"><img class="main_logo fnc_mobile_logo" src="<?php echo base_url('assets/images/fnc_mobile_logo.svg'); ?>" /></a></div>
                    <div class="col-xs-3" style="padding: 0px;">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNavMenu()"><img class="main_logo" src="<?php echo base_url('assets/images/close_icon.svg'); ?>" /></a>
                    </div>
                    <div class="overlay-content col-lg-12 col-md-4 col-sm-4 col-sx-4">
                       <!--<p>Search is currently locked while we onboard more venues…</p> -->
                        <div class="home-section">
                            <div class="home-section-1">
                                <?php if ($this->session->userdata("user_id")) { ?>  
                                    
                                    <p class="footer-menu"><a href="<?php echo site_url('dashboard'); ?>">Profile</a></p>
                                    <p class="footer-menu"><a href="<?php echo site_url('user/user_logout'); ?>">Log Out</a></p>
                                    <p  class="footer-menu"><a href="<?php echo site_url('change_password'); ?>">Change password</a></p>

                                <?php } else { ?>
                                    <p class="footer-menu"><a href="<?php echo site_url('user_login'); ?>">Log In</a></p>
                                    <p class="footer-menu"><a href="<?php echo creat_your_listing(); ?>">Create Profile/Listing</a></p>
                                <?php } ?>
                                <p class="footer-menu"><a href="<?php echo site_url('about_us'); ?>">About Us</a></p>
                                
                                <p class="footer-menu"><a href="<?php echo site_url('web/advertise'); ?>">Advertise</a></p>
                                <p class="footer-menu"><a href="<?php echo site_url('contact_us'); ?>">Contact Us</a></p>
                                <p class="footer-menu"><a href="<?php echo site_url('help'); ?>">Help</a></p>
                                <a class="call-us-now" href="tel:03 9088 9000">Call Us Now</a> 
                                </form>
                                <div class="overlay-content-footer">
                                    <p><a href="<?php echo site_url('privacy_policy'); ?>">Privacy Policy</a></p>
                                    <p><a href="<?php echo site_url('term_condition'); ?>">Terms & Conditions</a></p>
                                    <p><a>&copy; <?php echo date("Y"); ?> – Functions and Catering Australia Pty. Ltd.</a></p>
                                </div>
                            </div>
                            <!--<div class="home-section-2">
                               <p>Search is currently locked while we onboard more venues….</p>
                               <img src="">rivacy Policy
                               <p>Please check back here <br> 0/0/0</p>
                               </div> --> 
                        </div>
                        <div class="overlay-content-bottom">
                            <p>Developed with <img class="love-color" src="<?php echo base_url('assets/images/love.svg'); ?>"> & <img class="coffee-color" src="<?php echo base_url('assets/images/coffee.svg'); ?>"> by: <a href="http://yourdevelopmentteam.com.au/" target="blank">Your Development Team</a></p>
                        </div>
                    </div>
                </div>
                <nav class="navbar head_nav 1">
                    <div class="collapse navbar-collapse menubar" id="myNavbar">
                        <?php
                        $login_user_data = $this->session->all_userdata();
                        $login_user_id = isset($login_user_data['user_id']) ? $login_user_data['user_id'] : '';
                        ?>
                        <ul class="nav navbar-nav navbar-right nvbar_right_add" >
                            <li>
                                <span class="call_ing"><a class="call-us" href="tel:03 9088 9000"><span>Call us on</span> 03 9088 9000</a> </span>
                                <span class="call_ing_two">
                                    <div class="float_1">
                                        <?php if (!$this->session->userdata('user_email')) { ?>
                                            <a href="<?php echo site_url('user_login'); ?>" target="_blank">Log in</a>
                                            <a href="<?php echo site_url('help'); ?>"> Help</a>
                                            <a href="<?php echo creat_your_listing(); ?>">Create Profile/Listing</a>
                                        <?php } else { ?>
                                            <ul class="float_right">
                                                <!--<li><a href="<?php echo creat_your_listing(); ?>">Create Profile/Listing</a></li>-->
                                                <li><a href="<?php echo site_url('favorites'); ?>"><i class="fa fa-heart-o"></i></a></li>
                                                <li><a href="<?php echo site_url('help'); ?>"> Help</a></li>
                                                <li class="hidden-lg hidden-sm hidden-md"><a href="<?php echo site_url('dashboard'); ?>"> Profile</a></li>
                                                <li class="hidden-lg hidden-sm hidden-md"><a href="<?php echo site_url('user/user_logout'); ?>">Log out</a></li>
                                                <li class="hidden-xs">
                                                    <div class="dropdown" id='dropdwn1'>
                                                        <span class="drop_span1_" data-toggle="dropdown">
                                                            <img class=" img_center_header img-circle dropdown-toggle"  src="<?php echo $user_image ?>">
                                                        </span>
                                                        <ul class="dropdown-menu">
                                                            <div class='dropUpPart'></div>
                                                            <li class="atfo"><a href="<?php echo site_url('dashboard'); ?>"> Profile</a></li>
                                                            <li class="atfo"><a href="<?php echo site_url('change_password'); ?>">Change password</a></li>
                                                            <li class="atfo"><a href="<?php echo site_url('user/user_logout'); ?>">Sign out</a></li>
                                                        </ul>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    <?php } ?>
                                </span>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <!-- col-sm-12 -->
        </div>
        <!-- row -->
    </div>
    <!-- container-fluid -->
</section>

<script>
    $(document).ready(function () {
        $("#searchingform").validate();
    });

    $('#dropdwn1').mouseenter(function () {
        $(this).addClass('show');
    })
    $('#dropdwn1').mouseleave(function () {
        $(this).removeClass('show');
    })

</script>