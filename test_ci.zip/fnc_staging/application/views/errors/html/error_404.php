<!DOCTYPE html>
<html>
<head>
	<title>404 Page not found</title>
</head>
<style type="text/css">
.error-page span {
	text-shadow: 2px 2px 2px rgba(0, 0, 0, .3)
}
.error-page {
	padding-top: 30px;
	height: 100%;
	width: 100%
}
.error-page.page-404 {
	background: url('assets/images/searchbackground1.jpg') no-repeat;
	background-size: cover;
	position: fixed;
}
.error-page h1 {
	font-size:  5.9vw;
	line-height: 0;
}
.error-page span.text-white {
	font-size: 3vw;
}
.error-page span {
	color: #fff
}
body:not(.loaded) .mn-content {
	opacity: 0
}
.loaded .loader-bg {
	opacity: 0;
	position: relative
}
#materialPreloader,
.dd-dragel {
	z-index: 9999
}
.loader-bg {
	position: fixed;
	background: #fff;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	-webkit-transition: opacity .3s;
	-moz-transition: opacity .3s;
	-o-transition: opacity .3s;
	transition: opacity .3s;
	opacity: 1
}
.loaded .loader-bg {
	opacity: 0;
	position: relative
}
.loader {
	position: fixed;
	top: 50%;
	left: 50%;
	margin-left: -32px;
	margin-top: -35px
}
.mn-content,
body,
html {
	font-size: 14px;
	height: 100%;
	width: 100%
}
.mn-content {
	opacity: 1;
	-webkit-transition: opacity .3s;
	-moz-transition: opacity .3s;
	-o-transition: opacity .3s;
	transition: opacity .3s
}
.mn-inner {
	padding: 25px 25px 9.5px;
	min-height: calc(100% - 181px)
}

.mn-inner.hidden-fixed-sidebar {
	padding-left: 25px!important
}

.mn-inner.inner-active-sidebar {
	padding-top: 0;
	padding-right: 0;
	padding-bottom: 0;
	overflow: hidden
}

.signin-page .mn-inner,
.signup-page .mn-inner {
	min-height: 0!important
}
.error-page h1 {
	font-size: 7vw;
}
.header-title span {
	margin: 1px 0;
	display: block
}

.error-page span {
	color: #fff
}
.mailbox .mn-inner.hidden-fixed-sidebar {
	padding-left: 0!important
}
.mn-content, body, html {
	font-size: 2vw;
	height: 100%;
	width: 100%;
	padding: 0px;
	margin: 0px;
}
@media (min-width:993px) {
	.mn-content.fixed-sidebar .mn-inner {
		padding-left: 245px;
		width: 100%
	}
	.mn-content.fixed-sidebar .page-footer {
		padding-left: 245px;
		padding-right: 25px;
		width: 100%
	}
	.mn-content.fixed-sidebar-on-hidden .page-footer {
		padding-left: 25px!important;
		padding-right: 25px!important;
		width: 100%
	}
}
.pattern-lock-screen .mn-content {
	background: rgba(0, 0, 0, .54)
}
@media (min-width:993px) {
	body.mailbox .mn-content.fixed-sidebar .mn-inner {
		padding-left: 221px;
		width: 100%
	}
}

.error-page span.text-white {
	font-size: 3vw;
	background: #010402bd;
	font-family: sans-serif;
	padding: 15px 30px;
	display: -webkit-inline-box;
	/*text-shadow: 2px 2px 20px #20c4f5;*/
}
a.buttond {
	display: block;
	background: #f1f3eeab;
	width: 150px;
	margin: 7px auto;
	font-size: 40px;
	color: #fff;
	text-decoration:none;
}
h1 span{
	text-shadow:6px 3px 11px #000;
}
</style>
<body class="error-page page-404 loaded">
	<div class="mn-content">
		<main class="mn-inner">
			<div class="center" style="text-align:center;">
				<h1>
					<span>404</span>
				</h1>
				<span class="text-white">The page you requested was not found.</span><br>
				<a class="buttond" href="">
					<i class="large material-icons">Back</i>
				</a>
			</div>
		</main>
	</div> 
	<div class="hiddendiv common"></div>
</body>
</html>