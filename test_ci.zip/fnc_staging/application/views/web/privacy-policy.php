<section> 

  <div class="container-fluid home_tc_head">   

    <div class="row">

      <img src="<?php echo base_url(); ?>assets/images/PRIVACY-POLICY.png" class="img-responsive bann_img" />     

    </div>

  </div>

</section>





<section>

</section>

  <div class="container">

   <div class="row">



    <div class="col-sm-12">

      <div id="terms_and_condition">

        <div class="tc_head">Privacy Policy</div>

       <div class="sub_heading_tag">
        <h3 class="h_tag">General Terms and Conditions</h3>
        <p class="p_tag_ne">The Website, sub-domains, and any associated web-based and mobile applications you are using is
          provided by Functions and Catering Australia Pty. Ltd. (ACN <!--[INSERT]-->) trading as ‘Functions & Catering’
          (“Functions & Catering”, “we”, “our”, or “us’). Functions & Catering recognises the importance of
        maintaining the privacy of your personal information</p>
      </div>

      <div class="sub_heading_tag">
        <h3 class="h_tag">Scope</h3>
        <p class="p_tag_ne">This Privacy Policy applies to the collection, holding, use and disclosure of personal information
          provided by individuals to Functions & Catering through the use of the website,
          http://functionsandcatering.com (“Website”), sub-domains, and any associated web-based mobile
        applications and any services offered or provided by Functions & Catering (“services”).</p>
        <p class="p_tag_ne">In this Privacy Policy, “personal information” has the same meaning as defined by section 6 of the
          Privacy Act 1988 (Cth) as amended:
          <div class="padd_left_30">
            information or an opinion about an identified individual, or an individual who is reasonably
            identifiable:
            <div class="padd_left_30">
              <div>a) whether the information or opinion is true or not; and</div>
              <div>b) whether the information or opinion is recorded in material form or not</div>
            </div>
          </div>
        </p>
        <p class="p_tag_ne">Personal information may include your name, address, telephone number, email address, payment
          details (including credit card or bank account details) and/or other information that is necessary for
        the delivery of our services to you.</p>
      </div>


      <div class="sub_heading_tag">
        <h3 class="h_tag">Acknowledgement</h3>
        <p class="p_tag_ne">
          By continuing to use the Website, sub-domains, and any associated web-based mobile applications
and/or our services you acknowledge that you have had the opportunity to read this Privacy Policy
and acknowledge and consent to Functions & Catering collecting, holding, and disclosing personal
information supplied by you through your use of the Website, sub-domains, and any associated webbased
mobile applications, and retaining and/or using personal information provided by you subject
to the terms of this Privacy Policy, the Website, sub-domains, any associated web-based mobile
applications, Terms and Conditions and any other applicable contracts.
        </p>
      </div>

      <div class="sub_heading_tag">
        <h3 class="h_tag">Purpose</h3>
        <p class="p_tag_ne">
         The purpose of this Policy is to:
         <ul class="doted">
           <li>clearly communicate the personal information handling practices of Functions & Catering;</li>
           <li> enhance the transparency of Function & Catering’s information collection processes; and</li>
           <li> give individuals a better and more complete understanding of the sort of personal</li>
           <li>information that Function & Catering holds, and the way Function & Catering handles that
            information.
          </li>
        </ul>
        </p>
      </div>

       <div class="sub_heading_tag">
        <h3 class="h_tag">Collection</h3>
        <p class="p_tag_ne">
        In the course of regular business activity, Functions & Catering will from time to time collect and
otherwise handle your personal information.
        </p>
        <p class="p_tag_ne">If you do not want any of your data collected, you can stop using our Website, sub-domains, any
associated web-based mobile applications and/or our services and products at any time (subject to
applicable contracts).</p>
        <p class="p_tag_ne">Functions & Catering generally collects personal information from you directly, for example including
when you:
        <ul class="doted">
           <li>clearly communicate the personal information handling practices of Functions & Catering;</li>
           <li> enhance the transparency of Function & Catering’s information collection processes; and</li>
           <li> give individuals a better and more complete understanding of the sort of personal</li>
           <li>information that Function & Catering holds, and the way Function & Catering handles that
            information.
          </li>
        </ul>
        </p>
        <p class="p_tag_ne"> We do not generally take steps to:
         <ul class="doted">
           <li>clearly communicate the personal information handling practices of Functions & Catering;</li>
           <li> enhance the transparency of Function & Catering’s information collection processes; and</li>
           <li> give individuals a better and more complete understanding of the sort of personal</li>
           <li>information that Function & Catering holds, and the way Function & Catering handles that
            information.
          </li>
        </ul>
        </p>
        <p class="p_tag_ne">
          except in circumstances where it is reasonably necessary for us to do so or as may be required by
law, including (but not limited to) confirming the identity of an individual seeking access to personal
information.
        </p>
        <p class="p_tag_ne">
         When collecting information from you – whether it be via the Website, sub-domains associated webbased
mobile applications, email, hardcopy or any other services – we will take reasonable steps to
inform you of why we are collecting the information, the purposes for which we intend to use that
information and to whom it may be disclosed.
        </p>
      </div>

       <div class="sub_heading_tag">
        <h3 class="h_tag">Computer Information Collected</h3>
        <p class="p_tag_ne">
          To ensure we are meeting the needs and requirements of the services users and customers, and to
continue to develop our online services, we automatically collect certain computer information by the
interaction of your mobile phone or web browser with our Website. 
        </p>

<div class="italic_set">Cookies</div>

  <p class="p_tag_ne">We collect aggregated information through the use of cookies. We use cookies to collect data and
analytics about your visit and to allow you to navigate from page to page without having to reload 
each time. You can refuse cookies by using the appropriate setting on your browser, however, if you
do so you may not be able to access portions of our services.</p>

<div class="italic_set">Geographical Information</div>

  <p class="p_tag_ne">When you use the mobile application, we may use GPS technology (or other similar technology) when
you use the mobile application to determine your current location in order to determine the city you
are located within and display information with relevant data or advertisements. We will not share
your current location with other users or partners. If you do not want us to use your location for the
purposes set forth above, you should turn off the location services for the mobile application located
in your account settings or in your mobile phone settings and/or within the mobile application.</p>


<div class="italic_set">Automatic Information</div>

  <p class="p_tag_ne">We automatically receive information from your web browser or mobile device. This information
includes the name of the website from which you entered our Website, if any, as well as the name of
the website to which you’re headed when you leave our website. This information also includes the
IP address of your computer/proxy server that you use to access the Internet, your Internet Website
provider name, web browser type, type of mobile device, and computer operating system. We use all
of this information to analyse trends among our Users to help improve our Website.</p>


<div class="italic_set">Log Data</div>

  <p class="p_tag_ne">Like many site operators, we collect information that your browser sends whenever you visit our
Website (“Log Data”). This Log Data may include information such as your computer’s Internet
Protocol (“IP”) address, browser type, browser version, the pages of our Site that you visit, the time
and date of your visit, the time spent on those pages and other statistics.</p>

  <p class="p_tag_ne">Under the Child’s Online Privacy Security Act, no website operator can require, as a condition to
involvement in an activity, that a child younger than 13 years of age divulge more details than is
reasonably required. <!--Onesheep Ventures Pty Ltd -->abides by this demand. <!--Onesheep Ventures Pty Ltd-->
just collects information willingly offered; no information is gathered passively. Children under 13 can
submit only their email address when sending us an email in our “Contact Us” area. <!--One Sheep
Ventures Pty Ltd--> makes use of the e-mail address to respond to a one-time demand from a child under
13 and afterwards deletes the e-mail address. In case <!-- One Sheep Ventures Pty Ltd--> collects and
maintains personal information relating to a child under 13, the parent may send out an email to us
to review, alter and/or erase such info as well as to decline to enable any additional collection or use
of the child’s information.</p>
      </div>

       <div class="sub_heading_tag">
        <h3 class="h_tag">Use</h3>
        <p class="p_tag_ne">
          Any personal information collected by Functions & Catering will be used for the purpose for which it
was given to us, for purposes which are directly related to those purposes, for purposes which you
have otherwise consented to, or otherwise in accordance with the Privacy Act. 
        </p>
         <p class="p_tag_ne">Functions & Catering may use your personal information for the following purposes:
          <ul class="doted">
            <li> to verify you as a user of our services;</li>
            <li> to supply our services to you;</li>
            <li> to run future marketing campaigns including email marketing;</li>
            <li> to send promotional or other information about our products and services through e-mail,
              postal mail or some other means unless you otherwise instruct us to cease or refrain from
            sending you such information;</li>
            <li> to send registration information when developing your account;</li>
            <li> to send you communications in connection with our products and/or services unless you
            otherwise instruct us to cease or refrain from sending you such information;</li>
            <li> to monitor and improve our products and/or services;</li>
            <li> to process any inquiries you have about Functions & Catering;</li>
            <li> to provide and improve the material and functionality of the Website;</li>
            <li> to ensure compliance with our statutory obligations;</li>
            <li> to offer access to services on the Website;</li>
            <li> to monitor your use of our services;</li>
            <li> to comprehend our users, and to improve our services;</li>
            <li> to investigate violations of or otherwise enforce applicable contracts;</li>
            <li> to ensure compliance with our statutory obligations.</li>
        </ul>
         </p>
         <p class="p_tag_ne">
           We may offer you the chance to “opt-out” of having your personal information used for particular
purposes, for example when registering for the Website using our registration form you may be able
to opt-out of receiving any additional material or notifications from us
         </p>
      </div>



      <div class="sub_heading_tag">
        <h3 class="h_tag">Disclosure</h3>
        <p class="p_tag_ne">We may disclose information we hold to:
          <ul class="doted">
            <li> to verify you as a user of our services;</li>
            <li> to supply our services to you;</li>
            <li> our directors, officers, employees and agents; or</li>
            <li> service providers and contractors who help us provide the services; or</li>
            <li> third parties for the purpose of marketing; or</li>
            <li> a law enforcement agency if we are requested to do so by that agency in relation to
            suspected unlawful activity; or</li>
            <li> any such party, including government agencies and bodies, as required by law</li>
          </ul>
        </p>
        <p class="p_tag_ne">
          Functions & Catering does not otherwise provide personal information to any other organisations,
government agencies or third parties except in accordance with the Privacy Act.
        </p>
      </div>

       <div class="sub_heading_tag">
        <h3 class="h_tag">Direct marketing communications</h3>
        <p class="p_tag_ne">We may contact you using the contact details which you provide to us in order to provide you with
          direct marketing communications about our products, services and business, in accordance with the
        law.</p> 
        <p class="p_tag_ne">You may opt out of receiving direct marketing communications from us at any time by contacting us
        using the details set out below.</p>
        <p class="p_tag_ne">
          Where applicable, we may handle personal information relying on exemptions under the Privacy Act
          and at law, including but not limited to, the related bodies corporate exemption and the employee
          exemption.
        </p>
      </div>

      <div class="sub_heading_tag">
        <h3 class="h_tag">Access</h3>
        <p class="p_tag_ne">You may request access to our records of your personal information by contacting us using the
details set out below under “Contact” (subject to some exceptions).</p> 
        <p class="p_tag_ne">We will respond to a request for access to personal information within a reasonable period after the
request is made.</p>
      </div>

       <div class="sub_heading_tag">
        <h3 class="h_tag">Correction</h3>
        <p class="p_tag_ne">In the event Function & Catering holds personal information about you and
            <ol class="doted">
              <li>Function & Catering is satisfied that the information is inaccurate, out of date, incomplete,
              irrelevant or misleading; or</li>
              <li>You request the information be corrected;</li>
            </ol>
        </p> 
        <p class="p_tag_ne">Function & Catering will take reasonable steps to correct the information to ensure that it is
        accurate, up to date, relevant and not misleading.</p>
        <p class="p_tag_ne">If your personal details need to be corrected please make a written request to <!--[PLEASE CONFIRM]-->
        for correction (refer to “Contact” below) or update your account profile.</p>
        <p class="p_tag_ne">Function & Catering will respond to a request for correction of personal information within a
        reasonable period after the request is made.</p>
      </div>

      <div class="sub_heading_tag"> 
        <h3 class="h_tag">External Websites</h3>
        <p class="p_tag_ne">Our Website, sub-domains, and any associated web-based mobile applications may contain links to
          other websites. Functions & Catering is not affiliated with these sites and accordingly has no control
        over – and is not responsible for – their content, privacy practice or other policies.</p>
         <p class="p_tag_ne"> Your access to such linked websites is at your own risk.</p>
      </div>

      <div class="sub_heading_tag"> 
       <h3 class="h_tag"> Storage and Security</h3>
       <p class="p_tag_ne">Functions & Catering store personal information collected physically and/or electronically and has
      processes in place to endeavour to ensure the security of your personal information, such as secured
      database and may be sent out by means of an encrypted SSL method when supported by your web
      browser.</p>
       <p class="p_tag_ne">We will take all reasonable steps to protect personal information from misuse, interference and loss
      and from unauthorised access, modification or disclosure.</p>
       <p class="p_tag_ne">If your personal information is no longer needed, Functions & Catering will endeavour to take all
      reasonable steps to destroy and permanently de-identify the personal information.</p>
    </div>

<div class="sub_heading_tag"> 
 <h3 class="h_tag">General</h3>
      <p class="p_tag_ne">
      Please note that we reserve the right to amend, remove or vary this Privacy Policy without notice. You
should check this page regularly to take notice of any changes we may have made to this Privacy Policy.
Functions & Catering may notify you of changes to this Privacy Policy via the Website, by a blog post,
by email, or by any method we reasonably determine. 
    </p>
</div>

<div class="sub_heading_tag"> 
 <h3 class="h_tag"> Contact</h3>
      <p class="p_tag_ne">
        Your privacy is important to us and we are committed to conducting our business in accordance with
these principles to ensure that the confidentiality of your personal information is protected and
maintained. For that reason, if you have any questions or concerns about how Functions & Catering
safeguards your privacy, or if you wish to access or amend personal information we hold about you,
please make a request in writing. 
      </p>
    </div>

   <div class="sub_heading_tag"> 
 <h3 class="h_tag"> Complaints</h3>
<p class="p_tag_ne">If you have any enquiries about this Privacy Policy or wish to make a complaint about a matter
relating to privacy please contact us using the details set out above (refer to “Contact”).</p>
 <p class="p_tag_ne">Functions & Catering takes complaints seriously, and upon receipt of any complaint will examine the</p>
 <p class="p_tag_ne">complaint, and provide a response to the complainant within a reasonable period.</p>
</div>





    </div>
  </div>

  

   </div> 

  </div>




<style type="text/css">
.p_tag_ne{
  font-size: 16px;
  color: #777;
}
.padd_left_30 {
  padding-left: 30px;
  font-style: italic;
  font-size: 16px;
  color: #777;
}
.h_tag {
  font-size: 20px;
  font-weight: 600;
  color: #777;
}
ul.doted li {
  font-size: 16px;
  color: #777;
  line-height: 30px;
}

ol.doted li {
  font-size: 16px;
  color: #777;
  line-height: 30px;
}

.italic_set {
  font-style: italic;
  font-size: 16px;
  color: #777;
  margin-bottom: 10px;
}
.teram_table td{
  vertical-align: top;
  font-size: 20px;
  font-weight: 600;
  color: #777;
  padding-bottom: 10px;
}
.teram_table td table td{
  font-size: 16px !important;
  font-weight: normal;
  color: #777;
}
.padd_left_15px{
  padding-right: 30px;
}
.width_set-a{
  width: 10px;
}
</style>
