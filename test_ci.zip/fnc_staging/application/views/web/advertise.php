<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<section> 

    <div class="container">
        <?php if ($this->session->flashdata('error')) { ?>
            <div class="alert alert-danger col-md-6 col-md-offset-3">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <?Php echo $this->session->flashdata('error'); ?>
            </div>

        <?php }
        ?>

        <?php if ($this->session->flashdata('success')) { ?>
            <div class="alert alert-success col-md-6 col-md-offset-3">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <?Php echo $this->session->flashdata('success') ?>
            </div>

        <?php }
        ?>

        <div class="clearfix"></div>
        <div class="font-contact home_tc_head">
            Advertise
        </div>
        <div class="sub_heading_tag">
            <p class="p_tag_ne">Damn straight you want to be part of the F & C Community! We're pretty happy with what we have created and within our online platform, we promote only the best function venues and caterers under one roof. We believe F & C provides an advertising medium which talks to an already engaged audience.<br/>
           Please submit your advertising query below and let us know a little your business. An F & C team member will be in touch shortly after</p>
        </div>
    </div>

</section>
<section>
    <div class="container">
        <div id="contact_us">
            <div class="col-sm-12 profile_row c_us_content_in">

                <div class="row">
                    <form method="post" id="advertise_form" action="<?php echo site_url('web/advertise'); ?>" >

                        <div class="col-md-6 col-sm-6">
                            <div class="col-md-12 margin_set_input">           
                                <label class="lbl_class">Full Name</label>
                                <input type="text" class="form-control alphaText" data-msg-required="Please enter your full name" data-rule-required="true" name="full_name" maxlength="40">
                            </div>

                            <div class="col-md-12 margin_set_input">           
                                <label class="lbl_class">Business Name</label>
                                <input type="text" class="form-control alphaText" data-msg-required="Please enter your business name" data-rule-required="true" name="business_name" maxlength="100">
                            </div>

                            <div class="col-md-12 margin_set_input">           
                                <label class="lbl_class">Address:</label>
                                <input type="text" class="form-control" data-msg-required="Please enter your full address" data-rule-required="true" name="address" maxlength="256">
                            </div>

                            <div class="col-md-12 margin_set_input">           
                                <label class="lbl_class">E-mail Address:</label>
                                <input type="email" class="form-control" data-msg-required="Please enter your email address" data-rule-required="true" name="email_address" maxlength="100">
                            </div>
                            <div class="col-md-12 margin_set_input">           
                                <label class="lbl_class">Phone Number:</label>
                                <input type="text" class="form-control phone_no" maxlength="10" data-rule-minlength="8" data-rule-maxlength="10" data-msg-required="Please enter your phone number" data-rule-required="true" name="phone_number">
                            </div>
                            <div class="col-md-12 margin_set_input">           
                                <label class="lbl_class">Message:</label>
                                <textarea class="form-control" data-msg-required="Please enter your query" data-rule-required="true" name="message" maxlength="500" pattern="[^\\/:<>*]+" rows="9"></textarea>
                                <!--<input type="text" class="form-control" data-msg-required="Please enter your query" data-rule-required="true" name="message" maxlength="1024">-->
                            </div>
                            <div class="col-md-12 margin_set_input margin-capcha">
                                <div class="lbl_class g-recaptcha" data-sitekey="<?php echo CAPTCHA_SITE_KEY ?>" ></div>
                            </div>
                            <div class="col-md-12">
                                <input type="submit" value="Submit"  class="button_login_submit">
                            </div>
                        </div><!-- col-md-6 -->
                    </form>

                    <div class="col-md-6 col-sm-6 margin_top_advertise_106">
                        <!--<a href="" class="webAdvertisment slide_image hidden-md hidden-lg hidden-sm">-->
                        <span href="" class="webAdvertisment slide_image hidden-md hidden-lg hidden-sm"> 
                            <img src="<?php echo base_url(); ?>assets/images/New-image.jpg" class="img-responsive advertise_img">
                        </span>
                        <!--</a>-->
                        <!--<a href="" class="webAdvertisment slide_image hidden-xs" target="_blank">-->
                        <span href="" class="webAdvertisment slide_image hidden-xs">
                            <img src="<?php echo base_url(); ?>assets/images/New-image.jpg" class="">
                            <!--</a>-->
                        </span>

                        <!--<a href="" class="webAdvertisment slide_image hidden-xs" target="_blank">-->
                        <span href="" class="webAdvertisment slide_image hidden-xs">
                            <img src="<?php echo base_url(); ?>assets/images/glenmorangle_add_700X87_new.jpg" class="slide_img">
                        </span>
                        <!--</a>-->
                        <!--<a href="#" class="webAdvertisment slide_image hidden-lg hidden-md hidden-sm" target="_blank">-->
                        <span href="#" class="webAdvertisment slide_image hidden-lg hidden-md hidden-sm">
                            <img src="<?php echo base_url('assets'); ?>/images/img_advet_singalvenus_new.jpg">
                            <!--</a>-->  
                        </span>

                    </div>

                </div>
            </div>
        </div><!-- contact_us -->

    </div>
</section>
<script  type="text/javascript">
    $("#advertise_form").validate();
</script>

<!-- <script type="text/javascript">
 $(document).ready( function() {
    if ( $(window).width() < 768) {
     $('.margin_top_advertise_106 .advertise_img').attr('src','<?php //echo base_url('assets/images/advertise-mobile.png');     ?>');
    }
    else {}
 });

 $(window).resize(function() {
    if ($(window).width() < 768) {
     $('.margin_top_advertise_106 .advertise_img').attr('src','<?php //echo base_url('assets/images/advertise-mobile.png');     ?>');
    }
    else {$('.margin_top_advertise_106 .advertise_img').attr('src','<?php //echo base_url('assets/images/advertise-1-dsktop.png');     ?>');}
 });

</script> -->

<script>
    $(".phone_no").keyup(function (e) {
        length = $(this).val().length;
        limit = 18;
        if (length > limit) {
            var strtemp = $(this).val().substr(0, limit);
            $(this).val(strtemp);
            e.preventDefault();
        }
    });
    $(".phone_no").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .   
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 107, 109, 32, 110, 57, 48]) !== -1 ||
                // Allow: Ctrl+A, Command+A
                        (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                        // Allow: home, end, left, right, down, up
                                (e.keyCode >= 35 && e.keyCode <= 40) || (e.keyCode === 107 || e.keyCode === 109 || e.keyCode === 32 || e.keyCode === 57 || e.keyCode === 48)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            });
</script>



