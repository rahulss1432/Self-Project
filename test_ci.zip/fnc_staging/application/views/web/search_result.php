<script>
    var cuisine_type = "<?php echo ($this->input->get('cuisine_type')) ? $this->input->get('cuisine_type')[0] : '' ?>";
    var menus = "<?php echo ($this->input->get('menus')) ? $this->input->get('menus')[0] : '' ?>";
    var budget_per_head = "<?php echo ($this->input->get('budget_per_head')) ? $this->input->get('budget_per_head')[0] : '' ?>";
    var event_type = "<?php echo ($this->input->get('event_type')) ? $this->input->get('event_type')[0] : '' ?>";
    var near_by = "<?php echo ($this->input->get('near_by')) ? $this->input->get('near_by')[0] : '' ?>";
</script>
<script type="text/javascript" src="<?php echo base_url('assets/js/custom/search_result.js'); ?>"></script>
<section class="section-2 background_color_g home_tc_head">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="vanue-name-head">
                    <span id="venue-name" class="venu_names_105"><?php echo isset($location) ? ucfirst($location) : '' ?></span>
                </div>
                <?php
                if (!empty($search_data)) {
                    $count = count($search_data);
                } else {
                    $count = 0;
                }
                ?>
                <div class="home_some_text">
                    <span class="some_text"><?php echo $count ?> Function options for you.
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
</section><!-- section-4 -->

<section class="section-300 background_color_g">
    <div class="container">
        <div class="row margin_row_105">
            <div class="col-sm-12">
                <div class="search">
                    <div class="row search_event_box">
                        <div class="form-section">
                            <form role="form" action="<?php echo $advance_search_form_action ?>" method="get">
                                <?php
                                $location = $post_data['location'];
                                if (isset($location)) {
                                    ?>
                                    <input type="hidden" name="location" value="<?php echo $location ?>">
                                    <?php
                                }

                                $guest_count = isset($post_data['guest_count']) ? $post_data['guest_count'] : '';
                                if (isset($guest_count) && !empty($guest_count)) {
                                    ?>
                                    <input type="hidden" name="guest_count" value="<?php echo $guest_count ?>">
                                    <?php
                                }


                                $post_fc_type = isset($post_data['fc_type']) ? $post_data['fc_type'] : '';
                                if (isset($post_fc_type) && !empty($post_fc_type)) {
                                    $post_fc_type = array_unique($post_fc_type);
                                    $fc_type = $post_fc_type[0]
                                    ?>
                                    <input type="hidden" name="fc_type[]" value="<?php echo $post_fc_type[0] ?>">
                                    <?php
                                }
                                ?>
                                <div class="col-xs-12 border_box_event_vent">
                                    <?php $fc_type = (!empty($fc_type))? $fc_type : $fc_type=false  ?>
                                    <?php if ($fc_type == 2) { ?>
                                    <div class="col-md-3 partision  partision_103 filter_search padding-right_0">
                                        <div id="event_drop" class="dropdown new-drp">
                                            <div class="btn btn_drop_1 btn_drop_1_103 ser_border" type="button" data-toggle="dropdown">
                                                <img id="event_img" src="<?php echo base_url('assets/images/iconfilter.png') ?>">
                                                    <span id="choosed_cuisine" class="f_size">Select Cuisine Type</span>
                                                    <img style="display:none" class="cross_search_op" id="cross_cuisine" src="<?php echo base_url('assets/images/close_arrow.png'); ?>">
                                                <span class="glyphicon glyphicon-menu-down gly_arrow"></span>
                                            </div>
                                            <ul class="dropdown-menu dropdown-menu_103 srcoll">
                                                <?php
                                                if (!empty($cuisine_type)) {
                                                    foreach ($cuisine_type as $key => $val) {
                                                        ?>
                                                        <li>
                                                            <a class="feat-select">
                                                                <label>
                                                                    <img class="fnc_event_icon size_root_101" src="<?php echo base_url('uploads/fnc_types/' . $val->image) ?>">
                                                                        <span id="cuisine_<?php echo $val->id ?>" class="fnc_event_font"><?php echo $val->name ?></span>
                                                                        <div class="regular-checkbox">
                                                                            <input class="cuisine" type="checkbox" name="cuisine_type[]" value="<?php echo $val->id ?>" <?php if (isset($post_data['cuisine_type']) && in_array($val->id, $post_data['cuisine_type'])) echo 'checked' ?> class="category event_check event_check_103  regular-checkbox">
                                                                        <small></small>
                                                                    </div>

                                                                    <!--<input type="checkbox" name="event_type[]" value="<?php //echo $val->id             ?>" <?php //if(isset($post_data['event_type']) && in_array($val->id, $post_data['event_type'])) echo 'checked'             ?> class="category event_check event_check_103  regular-checkbox">-->

                                                                </label>
                                                            </a>
                                                        </li>  
                                                        <?php
                                                    }
                                                }
                                                ?>                                             
                                            </ul>
                                        </div>
                                    </div>

                                    <?php }else { ?>
                                    <div class="col-md-3 partision  partision_103 filter_search padding-right_0">
                                        <div id="event_drop" class="dropdown new-drp">
                                            <div class="btn btn_drop_1 btn_drop_1_103 ser_border" type="button" data-toggle="dropdown">
                                                <img id="event_img" src="<?php echo base_url('assets/images/iconfilter.png') ?>">
                                                <span id="choosed_event" class="f_size">Select Event Type</span>
<img style="display:none" class="cross_search_op" id="cross_event" src="<?php echo base_url('assets/images/close_arrow.png'); ?>">
                                                <span class="glyphicon glyphicon-menu-down gly_arrow"></span>
                                            </div>
                                            <ul class="dropdown-menu dropdown-menu_103 srcoll">
                                                <?php
                                                if (!empty($event_type)) {
                                                    foreach ($event_type as $key => $val) {
                                                        ?>
                                                        <li>
                                                            <a class="feat-select">
                                                                <label>
                                                                    <img class="fnc_event_icon size_root_101" src="<?php echo base_url('uploads/fnc_types/' . $val->image) ?>">
                                                                        <span id="event_<?php echo $val->id ?>" class="fnc_event_font"><?php echo $val->name ?></span>
                                                                        <div class="regular-checkbox">
                                                                            <input  type="checkbox" class="select_event" name="event_type[]" value="<?php echo $val->id ?>" <?php if (isset($post_data['event_type']) && in_array($val->id, $post_data['event_type'])) echo 'checked' ?> class="category event_check event_check_103  regular-checkbox">
                                                                        <small></small>
                                                                    </div>                                                                           
                                                                </label>
                                                            </a>
                                                        </li>  
                                                        <?php
                                                    }
                                                }
                                                ?>                                             
                                            </ul>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    <div class="col-md-7 add_new_view">
                                        <div class="row"> 
                                            <?php if($fc_type == 2){?>
                                             <div class="col-md-6 partision  partision_103 filter_search padding-right_0">
                                        <div id="event_drop" class="dropdown new-drp">
                                            <div class="btn btn_drop_1 btn_drop_1_103 ser_border" type="button" data-toggle="dropdown">
                                                <img id="event_img" src="<?php echo base_url('assets/images/iconfilter.png') ?>">
                                                            <span id="choosed_menus" class="f_size">Menus</span>
                                                            <img style="display:none" class="cross_search_op" id="cross_menus" src="<?php echo base_url('assets/images/close_arrow.png'); ?>">
                                                <span class="glyphicon glyphicon-menu-down gly_arrow"></span>
                                            </div>
                                            <ul class="dropdown-menu dropdown-menu_103 srcoll">
                                                <?php
                                                if (!empty($menus)) {
                                                    foreach ($menus as $key => $val) {
                                                        ?>
                                                        <li>
                                                            <a class="feat-select">
                                                                <label>
                                                                    <img class="fnc_event_icon size_root_101" src="<?php echo base_url('uploads/fnc_types/' . $val->image) ?>">
                                                                                <span id="menus_<?php echo $val->id ?>" class="fnc_event_font"><?php echo $val->name ?></span>
                                                                                <div class="regular-checkbox">
                                                                                    <input class="menus" type="checkbox" name="menus[]" value="<?php echo $val->id ?>" <?php if (isset($post_data['menus']) && in_array($val->id, $post_data['menus'])) echo 'checked' ?> class="category event_check event_check_103  regular-checkbox">
                                                                        <small></small>
                                                                    </div>                                                                           
                                                                </label>
                                                            </a>
                                                        </li>  
                                                        <?php
                                                    }
                                                }
                                                ?>                                             
                                            </ul>
                                        </div>
                                    </div>
                                    <?php } ?>
                                            <div class="col-md-6  padding-right_0">
                                                <div id="distance_drop" class="dropdown new-drp">
                                                    <div class="btn btn_drop_1 btn_drop_1_103 ser_border" type="button" data-toggle="dropdown" aria-expanded="false">
                                                        <span id="choosed_budget" class="f_size">Budget per Head </span>
                                                        <img style="display:none" class="cross_search_op" id="cross_budget" src="<?php echo base_url('assets/images/close_arrow.png'); ?>">
                                                        <span class="glyphicon glyphicon-menu-down gly_arrow g_105" ></span>
                                                    </div>
                                                    <ul class="dropdown-menu dropdown-menu_103 srcoll">
                                                        <?php
                                                        if (!empty($budget_per_head)) {
                                                            $z = 1;
                                                            foreach ($budget_per_head as $key => $per) {
                                                                ?>
                                                                <li>
                                                                    <a href="javascript:;">
                                                                        <label>
                                                                            <span id="budget_<?php echo $per->p_id ?>" class="fnc_search_price"> <?php echo $per->p_name ?></span>
                                                                            <div class="regular-checkbox">
                                                                                <input class="budget_per_head"  name="budget_per_head[]" type="checkbox" value="<?php echo $per->p_id ?>" <?php if (isset($post_data['budget_per_head']) && in_array($per->p_id, $post_data['budget_per_head'])) echo 'checked' ?>>
                                                                                <small></small>
                                                                            </div>
                                                                            <!-- <input class="category event_check event_check_103 regular-checkbox" name="budget_per_head[]" type="checkbox" value="<?php //echo $per->p_id            ?>" <?php //if(isset($post_data['budget_per_head']) && in_array($per->p_id, $post_data['budget_per_head'])) echo 'checked'            ?>> -->
                                                                        </label>
                                                                    </a>
                                                                </li>
                                                                <?php
                                                                $z++;
                                                            }
                                                        }
                                                        ?>
                                                    </ul>
                                                </div>
                                            </div>

                                            <?php if ($fc_type != 2) { ?>
                                            <div class="col-md-6  padding-right_0">
                                                <div id="distance_drop" class="dropdown new-drp">
                                                    <div class="btn btn_drop_1 btn_drop_1_103 ser_border" type="button" data-toggle="dropdown" aria-expanded="false">
                                                            <span id="choosed_near_by" class="f_size">Nearby options</span>
                                                            <img style="display:none" class="cross_search_op" id="cross_near_by" src="<?php echo base_url('assets/images/close_arrow.png'); ?>">
                                                            <span class="glyphicon glyphicon-menu-down gly_arrow g_105" ></span>
                                                    </div>
                                                    <ul class="dropdown-menu dropdown-menu_103 srcoll">
                                                        <li>
                                                            <a href="javascript:;">
                                                                <label>
                                                                        <span id="near_by_1" class="fnc_search_price">1 KM</span>
                                                                        <div class="regular-checkbox">
                                                                            <input class="near_by"  type="checkbox" name="near_by[]" value="1" <?php if (isset($post_data['near_by']) && in_array(1, $post_data['near_by'])) echo 'checked' ?>>
                                                                        <small></small>
                                                                    </div>
                                                                    <!--<input class="category event_check event_check_103 regular-checkbox" type="checkbox" name="near_by[]" value="1" <?php //if(isset($post_data['near_by']) && in_array(1, $post_data['near_by'])) echo 'checked'             ?>>-->
                                                                </label>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <label>
                                                                        <span id="near_by_3" class="fnc_search_distance">3 KM</span>
                                                                        <div class="regular-checkbox">
                                                                            <input class="near_by"  type="checkbox" name="near_by[]" value="3" <?php if (isset($post_data['near_by']) && in_array(3, $post_data['near_by'])) echo 'checked' ?>>
                                                                        <small></small>
                                                                    </div>
                                                                    <!-- <input class="category event_check event_check_103 regular-checkbox" type="checkbox" name="near_by[]" value="3" <?php //if(isset($post_data['near_by']) && in_array(3, $post_data['near_by'])) echo 'checked'             ?>>-->
                                                                </label>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <label>
                                                                        <span id="near_by_5" class="fnc_search_distance">5 KM</span>
                                                                        <div class="regular-checkbox">
                                                                            <input class="near_by"  type="checkbox" name="near_by[]" value="5" <?php if (isset($post_data['near_by']) && in_array(5, $post_data['near_by'])) echo 'checked' ?>>
                                                                        <small></small>
                                                                    </div>
                                                                    <!--<input class="category event_check event_check_103 regular-checkbox" type="checkbox" name="near_by[]" value="5" <?php //if(isset($post_data['near_by']) && in_array(5, $post_data['near_by'])) echo 'checked'             ?>>-->
                                                                </label>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <label>
                                                                        <span id="near_by_10" class="fnc_search_distance">10 KM</span>
                                                                        <div class="regular-checkbox">
                                                                            <input class="near_by"  type="checkbox"  name="near_by[]" value="10" <?php if (isset($post_data['near_by']) && in_array(10, $post_data['near_by'])) echo 'checked' ?>>
                                                                        <small></small>
                                                                    </div>
                                                                    <!-- <input class="category event_check event_check_103 regular-checkbox" type="checkbox"  name="near_by[]" value="10" <?php //if(isset($post_data['near_by']) && in_array(10, $post_data['near_by'])) echo 'checked'             ?>>-->
                                                                </label>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <label>
                                                                        <span id="near_by_25" class="fnc_search_distance">25 KM</span>
                                                                        <div class="regular-checkbox">
                                                                            <input class="near_by"  type="checkbox"  name="near_by[]" value="25" <?php if (isset($post_data['near_by']) && in_array(25, $post_data['near_by'])) echo 'checked' ?>>
                                                                        <small></small>
                                                                    </div>
                                                                    <!--<input class="category event_check event_check_103 regular-checkbox" type="checkbox"  name="near_by[]" value="25" <?php //if(isset($post_data['near_by']) && in_array(25, $post_data['near_by'])) echo 'checked'             ?>>-->
                                                                </label>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div><!--col-md-6-->
                                            <?php } ?>
                                        </div>
                                    </div><!--col-md-6-->

                                    <div class="col-md-2 padding-right_0 padding_left_0">
                                        <div class="form-group ">
                                            <button type="submit" class="btn btn-lg btn_filter btn-search btn-search_103 " value="button_click"><i class="fa fa-search search_set"></i><span>Search</span></button>
                                        </div>
                                    </div>
                                </div>
                            </form>


                        </div><!-- form-section -->
                    </div><!-- row search_event_box -->
                </div><!-- search -->
            </div><!-- col-sm-12 -->
        </div><!-- row margin_row_105 -->
    </div><!-- container -->
</section>

<?php
$counter = 0;

if (!empty($primium_data_ids)) {
    foreach ($primium_data_ids as $key => $primuim_fc_id) {
        if (in_array($primuim_fc_id, array_column($actual_search_data, 'fc_id'))) {
            $counter++;
        }
    }
}

if ($counter > 0) {
    if ($counter == 1) {
        ?>
        <style type="text/css">
            .carousel-inner>.next, .carousel-inner>.prev{
                position: relative !important;
            }
        </style>
        <?php
    }
    ?>
    <!--  slider start  -->
    <section class="section-5 background_color_g_slider">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="row slider_text">

                        <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                            <div class="carousel-inner">
                                <?php
                                $ii = 1;

                                if ($primium_data_ids) {

                                    foreach ($primium_data_ids as $key => $primuim_fc_id) {

                                        if (in_array($primuim_fc_id, array_column($actual_search_data, 'fc_id'))) {

                                            if (file_exists('uploads/fc_images/' . $actual_search_data[$primuim_fc_id]['fc_img_name']) && !empty($actual_search_data[$primuim_fc_id]['fc_img_name'])) {
                                                $img_path = base_url('uploads/fc_images/' . $actual_search_data[$primuim_fc_id]['fc_img_name']);
                                            } else {
                                                $img_path = base_url('assets/images/place_holder.jpg');
                                            }

                                            $type = $actual_search_data[$primuim_fc_id]['fc_type'];
                                            if ($type == 1) {
                                                $url = base_url('view_venue/' . encrypt_decrypt('encrypt', $actual_search_data[$primuim_fc_id]['fc_id']));
                                            } else {
                                                $url = base_url('view_catering/' . encrypt_decrypt('encrypt', $actual_search_data[$primuim_fc_id]['fc_id']));
                                            }

                                if ($ii == 1) {
                                    $class = 'next left';
                                    $class = 'active';
                                } elseif ($ii == $counter) {
                                    $class = 'active left';
                                    $class = '';
                                } else {
                                    $class = '';
                                }
                                ?>

                                            <div class="item <?php echo $class ?>">
                                                <a href="<?php echo $url ?>">
                                                    <blockquote>
                                                        <div class="row slider_rating">
                                                            <div class="col-sm-8 text-center">
                                                                <img src="<?php echo $img_path; ?>" class="slider-img" alt="<?php echo ucfirst($actual_search_data[$primuim_fc_id]['fc_business_name']) ?>">
                                                            </div>
                                                            <div class="col-sm-4">
                                                                <h3 class="hidden-xs"><?php echo ucfirst($actual_search_data[$primuim_fc_id]['fc_business_name']) ?></h3>
                                                                 <h4><?php echo ucfirst($actual_search_data[$primuim_fc_id]['fc_business_name']) ?></h4>
                                                                <span><?php
                                                                    if ($actual_search_data[$primuim_fc_id]['fc_type'] == 1)
                                                                        echo 'Function';
                                                                    else
                                                                        echo 'Catering';
                                                                    ?></span>
                                                                    <div class="reviews_div_107 reviews_768 hidden-lg hidden-sm hidden-md mb-0">
                                                                       <?php echo review_count($actual_search_data[$primuim_fc_id]['fc_id']); ?>                                
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                <p>
                                                                    <?php
                                                                    $string = $actual_search_data[$primuim_fc_id]['fc_overview'];
                                                                    if (strlen($actual_search_data[$primuim_fc_id]['fc_overview']) > 150) {
                                                                        $stringCut = substr($actual_search_data[$primuim_fc_id]['fc_overview'], 0, 150);
                                                                        $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                                                    }
                                                                    echo $string;
                                                                    ?>
                                                                </p>
                                                                <div class="star-rating rating-xs rating-disabled">
                                                                    <div class="clear-rating " title="Clear"><i class="glyphicon glyphicon-minus-sign"></i></div>
                                                                    <div class="star_create"></div>
                                                                    <div class="caption"><span class="label label-default">Not Rated</span></div>
                                                                </div>
                                                                <div class="reviews_div_107 hidden-xs">
                                                                    <?php echo review_count($actual_search_data[$primuim_fc_id]['fc_id']); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </blockquote>
                                                </a>
                                            </div>
                                            <?php
                                            $ii++;
                                        }
                                    }
                                }
                                ?>
                            </div>
                            <!-- carousel-inner -->
                            <?php
                            if ($counter > 1) {
                                ?>
                                <a data-slide="prev" href="#quote-carousel" class="left carousel-control hidden-xs">
                                    <img class="glyphicon-menu-left" src="<?php echo base_url('assets/images/arrow_left.png') ?>">
                                </a>
                                <a data-slide="next" href="#quote-carousel" class="right carousel-control hidden-xs">
                                    <img class="glyphicon-menu-right" src="<?php echo base_url('assets/images/arrow_right.png') ?>">
                                </a>
                               
                                <?php
                            }
                            ?>

                            <ol class="carousel-indicators hidden-lg hidden-sm hidden-md pb-4">
                                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                <li data-target="#myCarousel" data-slide-to="1"></li>
                                <li data-target="#myCarousel" data-slide-to="2"></li>
                            </ol>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  slider end  -->
    <?php
} elseif (empty($actual_search_data)) {
    ?>

    <section  class="not_reponse_sec">
        <div class="container">
            <div class="no response"><?php echo system_msgs('No_record_in_search'); ?></div>
        </div>
    </section>
    <?php
}
?>


<!--  primuim six functions data start  -->
<section class="section-6 section-5_105">
    <div class="container">
        <div class="row padding_responsive">
            <div class="main">
                <?php
                if ($primium_data_ids) {
                $cnt=0;
                    foreach ($primium_data_ids as $key => $primuim_fc_id) {
                $cnt++;
                        if (in_array($primuim_fc_id, array_column($actual_search_data, 'fc_id'))) {

                            if (file_exists('uploads/fc_images/' . $actual_search_data[$primuim_fc_id]['fc_listing_picture']) && !empty($actual_search_data[$primuim_fc_id]['fc_listing_picture'])) {
                                $img_path = base_url('uploads/fc_images/' . $actual_search_data[$primuim_fc_id]['fc_listing_picture']);
                            } else {
                                $img_path = base_url('assets/images/place_holder.jpg');
                            }

                            $type = $actual_search_data[$primuim_fc_id]['fc_type'];
                            if ($type == 1) {
                                $url = base_url('view_venue/' . encrypt_decrypt('encrypt', $actual_search_data[$primuim_fc_id]['fc_id']));
                            } else {
                                $url = base_url('view_catering/' . encrypt_decrypt('encrypt', $actual_search_data[$primuim_fc_id]['fc_id']));
                            }
                            ?>
                           
                                <div class="atribute parent" id="<?php echo "parent_".$cnt; ?>">
                                <!-- <div class="atribute parent" id="<?php //echo "parent_".$key;?>"> -->
                                    <!--please-add-loop-this-div-->
                                    <div class="imageContainer_1xligvk child-1 <?php echo "child_1_".$cnt; ?>">
                                       <div class="container_18q6tiq container_18q6tiq_105">
                                                <div class="children_1szwzht children_1szwzht_105">
                                                    <div class="container_e296pg container_e296pg_105">
                                                         <a href="<?php echo $url ?>">
                                                        <div class="set_img_b set_img_b_105" style="background-image: url(<?php echo $img_path ?>);"></div>
                                                         </a>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>

                                   <div class="product-details-sea_1 child-2 <?php echo "child_2_".$cnt;?>">
                                        <div id="content_2" class="main_text"><?php echo ucfirst($actual_search_data[$primuim_fc_id]['fc_business_name']) ?></div>
                                        <br>
                                        <span class="function_text"><?php
                                            if ($actual_search_data[$primuim_fc_id]['fc_type'] == 1)
                                                echo 'Venue';
                                            else
                                                echo 'Catering';
                                            ?></span>
                                            <div class="reviews_div_107 reviews_768 hidden-lg hidden-sm hidden-md">
                                                <?php echo review_count($actual_search_data[$primuim_fc_id]['fc_id']); ?>                                
                                            </div>
                                        <p>
                                            <?php
                                            $string = $actual_search_data[$primuim_fc_id]['fc_overview'];
                                            if (strlen($actual_search_data[$primuim_fc_id]['fc_overview']) > 150) {
                                                $stringCut = substr($actual_search_data[$primuim_fc_id]['fc_overview'], 0, 150);
                                                $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                            }
                                            echo $string;
                                            ?>
                                        </p>
                                    
                                     <div class="reviews_div_107 reviews_768 hidden-xs">
                                        <?php echo review_count($actual_search_data[$primuim_fc_id]['fc_id']); ?>
                                    </div>
                                    </div>

                                </div>
                           
                            <?php
                             unset($actual_search_data[$primuim_fc_id]);
                        }
                    }
                }
                ?>
            </div>
        </div>
    </div>
</section>
<!--  primuim six functions data end  -->

<section class="section-7 background_color_g ">
    <div class="container">
        <div class="row add_back respon_m">
            <div class="col-sm-12 respon_p">
                <div class="row">
                    <div class="col-sm-12">
                        <a href="#" class="webAdvertisment slide_img" target="_blank">
                            <img src="<?php echo base_url('assets/images/glenmorangle_add_700X87.jpg') ?>">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- section-7 -->

<!--  actual search result start  -->
<section class="section-100 background_color_g">
    <div class="container">

         <?php if(!empty($actual_search_data)){ ?>
        <div class="row ">
            <div class="col-sm-12">
                <span class="also-like also-like_103">You might also like.</span>
            </div>
        </div>
       <?php } ?>

        <div class="row respon_m">
            <div class="main device_size">
                <?php
                $i = 1;
                (!empty($primium_data_ids)) ?: $primium_data_ids = array();
                if ($actual_search_data) {

                    foreach ($actual_search_data as $key => $search_data) {

                        if (!in_array($search_data['fc_id'], $primium_data_ids)) {

                            if (file_exists('uploads/fc_images/' . $search_data['fc_listing_picture']) && !empty($search_data['fc_listing_picture'])) {
                                $img_path = base_url('uploads/fc_images/' . $search_data['fc_listing_picture']);
                            } else {
                                $img_path = base_url('assets/images/featured_image.jpg');
                            }

                            $type = $search_data['fc_type'];
                            if ($type == 1) {
                                $url = base_url('view_venue/' . encrypt_decrypt('encrypt', $search_data['fc_id']));
                            } else {
                                $url = base_url('view_catering/' . encrypt_decrypt('encrypt', $search_data['fc_id']));
                            }
                            ?>
                            <?php
                            $display = '';
                            if ($i > 6) {
                                $display = 'style="display:none"';
                            }
                            ?>


                            <div class="atribute" <?php echo $display; ?> id="functions_<?php echo $i; ?>">
                                <div class="col-sm-7 col-sm-push-5 set_color_p">
                                    <span id="content_1" class="main_text"><a href="<?php echo $url; ?>"><?php echo $search_data['fc_business_name']; ?></a></span>
                                    <span class="function_text"><?php
                                        if ($search_data['fc_type'] == 1)
                                            echo 'Venue';
                                        else
                                            echo 'Catering';
                                        ?></span>
                                        <div class="reviews_div_107 reviews_768 hidden-lg hidden-sm hidden-md">
                                        <?php echo review_count($search_data['fc_id']); ?>
                                    </div>
                                    <div class="clearfix"></div>
                                    <p><?php
                                        $string = $search_data['fc_overview'];
                                        if (strlen($search_data['fc_overview']) > 90) {
                                            $stringCut = substr($search_data['fc_overview'], 0, 90);
                                            $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                        }
                                        echo $string;
                                        ?></p>
                                    <div class="reviews_div_107 reviews_768 hidden-xs">
                                        <?php echo review_count($search_data['fc_id']); ?>
                                    </div>
                                </div>
                                <a href="<?php echo $url; ?>">
                                    <div class="col-sm-5 col-sm-pull-7 right_pad">
                                        <img src="<?php echo $img_path; ?>" class="img-responsive">
                                    </div>
                                </a>
                                
                            </div>

                            <?php
                            $i++;
                        }
                    }
                }
                ?>

                <input type="hidden" id="fc_listing_counter" value="6">
            </div>
        </div>
        <!--main-->
    </div><!---container-->
</section>
<!--  actual search result end  -->

<?php if ($i > 6) { ?>
    <section class="row_105_1">
        <div class="container">
            <div class="row text-center">
                <button class="btn btn-default see_more_listing">See more listings</button>
            </div>
        </div>
    </section>
<?php } ?>

<!--  free listing result start  -->
<section class="section-9 background_color_g">
    <div class="container">
        <div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="row search_div2">
                        <?php
                        if (!empty($free_data)) {
                            foreach ($free_data as $key => $value) {
                                $type = $value['fc_type'];
                                if ($type == 1) {
                                    $url = base_url('view_venue/' . encrypt_decrypt('encrypt', $value['fc_id']));
                                } else {
                                    $url = base_url('view_catering/' . encrypt_decrypt('encrypt', $value['fc_id']));
                                }
                                ?>
                                <!-- <a href="<?php echo $url ?>"> -->
                                    <div class="col-sm-4 col-md-4 col-xs-12">
                                        <span class="main_text"><?php echo ucfirst($value['fc_business_name']) ?></span>
                                        <br>
                                        <span class="function_text"><?php
                                        if ($value['fc_type'] == 1)
                                            echo 'Venue';
                                        else
                                            echo 'Catering';
                                        ?></span>
                                        <p>A venue nda sitaquamet dolorei liem poreiur, eosins sust ior untis ea oreiur, eos sustiorum poreiur, eosins sust ior untis ea oreiur, eos sustioruntis ea nis</p>
                                    </div>
                                    <!-- </a> -->
                                    <?php
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<script>
    jQuery.fn.extend({
        live: function (event, callback) {
            if (this.selector) {
                jQuery(document).on(event, this.selector, callback);
            }
        }
    });



    $(document).ready(function () {
        $(".see_more_listing").click(function () {
            var counter = parseInt($('#fc_listing_counter').val());
            var lst = counter + 6;
            var i = 0;
            counter = (counter + 1);
            for (counter; counter <= lst; counter++) {
                if ($("#functions_" + counter).length !== 0) {
                    $('#functions_' + counter).show();
                    i++;
                }
            }

            if (i != 6) {
                $(".see_more_listing").hide();
            }
            $('#fc_listing_counter').val(counter);
        });


        $('.slider1').bxSlider({
            slideWidth: '130',
            minSlides: 3,
            maxSlides: 5,
            slideMargin: 15
        });
       
        $(window).resize(function () {
           var divw = $(this).width();            
           var addwidth=0;
           if(divw>767){
            addwidth=50;                
        }
        SwipeHomeContents(divw);
        });
    });

    var divw = $(this).width();    
    var addwidth=0;
    if(divw>767){
        addwidth=50;
    }
    SwipeHomeContents(divw);
     function SwipeHomeContents(nwidth){
            if(nwidth>767){
                $('div.parent').each(function () {          
                    var v=$(this).attr('id');
                    div_no=v.split("_");            
                    var clChlid1='.child_1_'+div_no['1'];
                    var clChlid2='.child_2_'+div_no['1'];
                    var child_1 = $(clChlid1).detach();
                    var child_2 = $(clChlid2).detach();
                    $(child_1).appendTo('#'+v);
                    $(child_2).appendTo('#'+v);
                });
            }else{
                $('div.parent').each(function () {          
                    var v=$(this).attr('id');
                    div_no=v.split("_");            
                    var clChlid1='.child_1_'+div_no['1'];
                    var clChlid2='.child_2_'+div_no['1'];
                    var child_1 = $(clChlid1).detach();
                    var child_2 = $(clChlid2).detach();             
                    $(child_2).appendTo('#'+v);
                    $(child_1).appendTo('#'+v);
                });
            }
        }
</script>

    </html>