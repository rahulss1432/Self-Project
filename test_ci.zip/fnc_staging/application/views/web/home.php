<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/owl.carousel.min.css" />
<script src="<?php echo base_url(); ?>assets/js/owl-slider.js" ></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/plugins/parsley/parsley.css') ?>">
<link href="<?php echo base_url('assets/plugins/autocomplete/jquery-ui.css'); ?>" rel="stylesheet">
<section class="section-2">
    <div class="container-fluid">
        <div class="row">
            <div class="home-header">
                <!--<div class="col-md-12 home_page_banner" style="background: url(<?php //echo base_url('assets/images/banner_oct.jpg');   ?>) no-repeat 100% 100%; background-size: cover !important; ">-->
                <div class="col-md-12 home_page_banner" style="background: url(<?php echo base_url('assets/images/header.jpg'); ?>) no-repeat 100% 100%; background-size: cover !important; ">
                    <div class="container home_top_content inspiration_container">
                        <div class="row">

                            <div class="col-sm-12 banner_text">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="banner_div text-center">
                                            <span class="text-center">
                                                Create your perfect event with Functions & Catering
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12 banner_search">
                                <div class="row">
                                    <div class="search">
                                        <div class="col-lg-12 col-sm-6 col-sm-offset-3 col-lg-offset-0 col-md-12 col-md-offset-0">
                                            <div class="form-section">

                                                <form id="searchingformDesctop" role="form" action="<?php echo "#"; /* $search_form_action */ ?>" method="get" class="searchingform">
                                                    <div class="col-md-12 search_partision set_responsive_search overlay" id="overlay">
                                                        <div class="col-md-4 partision">
                                                            <div class="dropdown">
                                                                <span class="search-home-text">Location
                                                                </span>
                                                                <div class="inner-addon left-addon left_add">
                                                                    <img src="<?php echo base_url('assets/images/iconseach.png'); ?>" class="glyphicon search-icons">
                                                                    <input type="text" name="location" class="form-control btn_drop location-height location_auto_complete" placeholder="City, council, state or postcode" data-rule-required="true" readonly/>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-2 partision">
                                                            <div class="dropdown">
                                                                <span class="search-home-text">Date
                                                                </span>
                                                                <div class="left_add">
                                                                    <input type="text" name="search_date" id="" class="form-control btn_drop location-height date" placeholder="dd/mm/yyyy" disabled>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-2 partision">
                                                            <div class="dropdown">
                                                                <span class="search-home-text">Guests
                                                                </span>
                                                                <div class="left_add">
                                                                    <input type="text" name="guest_count" class="form-control btn_drop location-height" autocomplete="off" data-rule-number="true" data-msg-number="Please enter numeric value" placeholder="Number of guests" readonly/>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-2 partision paddd paddd_104">
                                                            <div class="checkbox_div">
                                                                <span class="search-home-text">Select
                                                                </span>
                                                            </div>
                                                            <div class="searchbar_div">
                                                                <div class="search_fnc1">
                                                                    <label for="function">Function
                                                                    </label>
                                                                    <!-- <input type="checkbox" name="fc_type[]" class="regular-checkbox"  value="1"> -->
                                                                    <label class="regular-checkbox_101">
                                                                        <input class="select_function" checked type="checkbox" name="fc_type[]"  value="1" disabled>
                                                                        <small></small>
                                                                    </label>
                                                                </div>
                                                                <div class="search_fnc2">
                                                                    <label for="catering">Catering
                                                                    </label>
                                                                    <!-- <input  type="checkbox" name="fc_type[]" class="regular-checkbox"  value="2"> -->
                                                                    <label class="regular-checkbox_101">
                                                                        <input class="select_function" type="checkbox" name="fc_type[]" value="2" disabled>
                                                                        <small></small>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-2 search_btn text-center">
                                                            <a href="#">
                                                                <button type="submit" class="btn_search btn-default btn-primary" >Search</button>
                                                            </a>
                                                        </div>
                                                    </div>

                                                    <div class="pos_lock">
                                                        <img src="<?php echo base_url('assets/images/lock.svg'); ?>"  id="newdemo" style="display: none;" class = "CloseLock close_lck" >

                                                        <img src="<?php echo base_url('assets/images/unlock.svg'); ?>" style="z-index: 9;" class= "OpenLock">
                                                    </div>

                                                    <h1 class="hidden-sm hidden-xs we_currently" >
                                                        We are currently onboarding - please scroll down to see what we have to offer :)</h1>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<section class="Feature_Sec section-3">
    
    <div class="row">
        
        <div class="col-md-6 col-md-offset-1 col-sm-7 pd_tb_50My">
            
             <p class="mn_hdng1">Do you have a function space or offer a catering service, but need more people to know about you? Do you feel like you’re missing out on all the Birthdays, Christenings, Engagement party bookings happening every weekend around you? Welcome to F &amp; C.<br /><br />
                                Open your business to the world.<br />
                                Let’s get you started.</span></p>

            <div>
                
                <?php
                            if (!empty($features)) {
                                ?>
                                <ul id="bxslider_1" style="display:none;">
                                    <?php
                                    foreach ($features as $key => $value) {
                                        //
                                        if (file_exists('uploads/fnc_types/' . $value->image) && !empty($value->image)) {
                                            $img_path = base_url('uploads/fnc_types/' . $value->image);
                                        } else {
                                            $img_path = base_url('assets/images/place_holder.jpg');
                                        }
                                        ?>
                                        <li> <img class="img-size img-size_104"  src="<?php echo $img_path; ?>"/>
                                            <span class="items items_104"><?php echo ucfirst($value->name) ?></span>
                                        </li>
                                        <?php
                                    }
                                    ?>
                                </ul>
                                <?php
                            }
                            ?>
            </div>

           

            <img src="<?php echo base_url('assets'); ?>/images/services-hero-1-deshktop.png" class="mob_imgFeat">

        </div>

        <div class="col-md-5 col-sm-5 no-pad-right hidden-xs">
            <div class="rgt_imgDiv">
             <img src="<?php echo base_url('assets'); ?>/images/services-hero-1-deshktop.png" class=" hg_500">
            </div>
        </div>

    </div>

</section>







<section class="section-4 Backgrond_color_padding_set">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="home_some_text">
                    <span class="some_text">Inspirational Venues:</span>
                </div>
            </div>
        </div>
    </div>
</section><!-- section-4 -->

<section class="section-5 Backgrond_color_set">
    <div class="container">
        <div class="row padding_responsive">
            <div class="main myparent">
                <?php
                if (!empty($function_and_catering_data)) {
                    $cnt = 0;
                    foreach ($function_and_catering_data as $key => $value) {
                        $cnt++;
                        if (file_exists('uploads/fc_images/' . $value->fc_listing_picture) && !empty($value->fc_listing_picture)) {
                            $img_path = base_url('uploads/fc_images/' . $value->fc_listing_picture);
                        } else {
                            $img_path = base_url('assets/images/Small_place_holder.jpg');
                        }

                        $type = $value->fc_type;
                        if ($type == 1) {
                            $url = base_url('view_venue/' . encrypt_decrypt('encrypt', $value->fc_id));
                        } else {
                            $url = base_url('view_catering/' . encrypt_decrypt('encrypt', $value->fc_id));
                        }
                        ?>

                        <div class="atribute atribute_margin_set parent" id="<?php echo "parent_" . $cnt; ?>">

                            <div class="imageContainer_1xligvk child-1 <?php echo "child_1_" . $cnt; ?>">
                                <div class="container_18q6tiq container_18q6tiq_104">
                                    <div class="children_1szwzht">
                                        <div class="container_e296pg container_e296pg_104">
                                            <a href="<?php echo $url ?>">
                                                <div class="set_img_b set_img_b_104" style="background-image: url(<?php echo $img_path; ?>);">

                                                    <?php $user_wishlist = show_wishlist_icon($wish_list, $value->fc_id, $key); ?>
                                                    <span><?php echo $user_wishlist ?></span>
                                                    <map name="planetmap_<?php echo $key ?>">
                                                        <area onclick="add_to_wishlist('<?php echo encrypt_decrypt('encrypt', $value->fc_id, 'blank') ?>', '<?php echo $key ?>');" shape="rect" coords="0,0,82,126" alt="Sun" href="javascript:void(0);">
                                                    </map>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="product-details-sea_1 child-2 <?php echo "child_2_" . $cnt; ?>">
                                <div id="content_1" class="main_text"><?php echo $value->fc_business_name ?></div>
                                <br>
                                <span class="function_text"><?php
                                    if ($value->fc_type == 1)
                                        echo 'Function';
                                    else
                                        echo 'Catering';
                                    ?></span>

                                <div class="reviews_div_107 reviews_768 hidden-lg hidden-sm hidden-md">
                                    <?php echo review_count($value->fc_id); ?>
                                </div>

                                <p>
                                    <?php
                                    $string = $value->fc_overview;
                                    if (strlen($value->fc_overview) > 130) {
                                        $stringCut = substr($value->fc_overview, 0, 130);
                                        $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                    }
                                    echo $string;
                                    ?>
                                </p>

                                <div class="reviews_div_107 reviews_768 hidden-xs">
                                    <?php echo review_count($value->fc_id); ?>
                                </div>
                            </div>



                        </div>



                        <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
</section><!-- section-5 -->






<section class="section-6 second_home_back">
    <div class="container inspiration_container">
        <div class="row d-flex">

            <div class="col-sm-7 col-sm-push-5 col-lg-7 col-lg-push-5 registered align-self-center col-xs-12">
                <div class="row register_text">
                    <?php
                    $login_user_data = $this->session->all_userdata();
                    $login_user_id = isset($login_user_data['user_id']) ? $login_user_data['user_id'] : '';
                    ?>

                    <?php
                    if ($login_user_id == '') {
                        ?>
            <!--                        <p class="before-login px-4">
                                        Whether you provide opulent grand ballrooms, a quirky boutique gallery or a picturesque beach side roof top, F&amp;C will bring your spaces to life, helping thousands of people looking for function space each week, connect to you.
                                        <br>

                                    </p>-->
                        <p class="before-login px-4">
                            Whether your space is a grand opulent ballroom, a quirky boutique gallery or a hidden garden on your family restaurant rooftop, F&amp;C can bring your spaces to life.<br /><br />If you want to open up your business to more weddings, parties or corporate functions, you need to be on F&C. We promise there’s no hidden agenda!
                            <br>
                        </p>
                        <div class="center-class">
                            <a href="<?php echo site_url('login/user_registration'); ?>" class="btn btn-info register_btn">Register now</a>
                        </div>
                    <?php } else { ?>

            <!--                        <p class="after-login px-4">
                                        Whether you provide opulent grand ballrooms, a quirky boutique gallery or a picturesque beach side roof top, F&amp;C will bring your spaces to life, helping thousands of people looking for function space each week, connect to you.
                                        <br>

                                    </p>-->
                        <p class="before-login px-4">
                            Whether your space is a grand opulent ballroom, a quirky boutique gallery or a hidden garden on your family restaurant rooftop, F&amp;C can bring your spaces to life.<br /><br />If you want to open up your business to more weddings, parties or corporate functions, you need to be on F&C. We promise there’s no hidden agenda!
                            <br>
                        </p>
                    <?php } ?>


                </div>
            </div>

            <div class="col-sm-5 col-sm-pull-7 col-lg-5 col-lg-pull-7 col-xs-12">
                <img width="437" height="500" src="<?php echo base_url('assets'); ?>/images/flower_prop.png" class="grl_img wp-post-image mbHide" alt="" >

                <img width="437" height="500" src="<?php echo base_url('assets'); ?>/images/flower_prop2.jpg" class="img-responsive wp-post-image flower_prop2 " alt="" >            
            </div>

        </div>

    </div>
</section><!-- section-6 -->



<section class="section-7 hidden-xs">
    <div class="container inspiration_container">
        <div class="row add_back">
            <div class="col-sm-12">
                <div class="row">
                    <div class="col-sm-12 hidden-xs">
                        <!--<a href="#" class="webAdvertisment" target="_blank">-->
                        <span href="#" class="webAdvertisment" target="_blank">
                            <img src="<?php echo base_url('assets'); ?>/images/glenmorangle_add_700X87_new.jpg">
                        </span>
                        <!--</a>-->
                    </div>
                    <div class="col-md-12 hidden-lg hidden-md hidden-sm">
                        <!--<a href="#" class="webAdvertisment" target="_blank">-->
                        <span href="#" class="webAdvertisment" target="_blank">
                            <img src="<?php echo base_url('assets'); ?>/images/img_advet_singalvenus_new.jpg">
                        </span>
                        <!--</a>-->
                    </div>

                </div>
            </div>
        </div>
    </div>
</section><!-- section-7 -->

<section class="section-8">
    <div class="home_back home_features">
        <div class="main-div-sub-left-padding">
            <div class="main-div-sub-fetures">
                <div class="row">
                    <div class="col-sm-6 background-content-sub-fetures">
                        <div class=" second_div_1">
                            <h3 class="receive_text">
                                <p class="sign_up_news">Sign up to the F&amp;C newsletter:
                                </p>
                                <!--<span>  Receive exclusive function and </span><span class="block_tag_use">catering deals, inside tips, and more.</span>-->
                                <span>We promise we don’t spam. We’ll only send you exclusive Functions & Catering deals, inside secrets & tips and news we know are worth writing home about!</span>
                            </h3>
                            <form class="form_submit_save" method="post" action="<?php echo isset($subscriber_form_action) ? $subscriber_form_action : '' ?>"  data-parsley-validate autocomplete="off">
                                <div class="row margin_top_subscribe">
                                    <div class="col-md-4 col-xs-12 col-sm-6 padd_dis">
                                        <input class="input_subscribe_name input_105 alphaText" name="subscriber_name" required="required" data-parsley-error-message="Name is required." type="text" placeholder="Name *" maxlength="30">
                                        <!-- <label for="name">Name</label> -->
                                    </div>
                                    <div class="col-md-5 col-xs-12 col-sm-6 padd_ing">
                                        <input class="input_subscribe_name input_105" name="subscriber_email" required="required" pattern="^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$" data-parsley-error-message="Required a valid Email id." type="email" placeholder="Email *" maxlength="100">
                                        <!--  <label for="name">Email</label>-->
                                    </div>


                                    <div class="col-md-3 col-xs-12 col-sm-6 margin_sub_but_root_1">
                                        <div class="margin_sub_but_root">
                                            <input type="submit" value="Subscribe" class="subscribe_button_at">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-6  col-lg-6 hidden-xs" style="padding: 0px ;">
                        <img src="<?php echo base_url('assets'); ?>/images/sing-up-hero-desktop.png" class="img-responsive pull-right">
                    </div>

                    <!--<div class="col-sm-6 hidden-xs">
                            <img src="<?php echo base_url('assets'); ?>/images/Sugar-Cookies-Flatlaycookies1.jpg" class="img-responsive">
                        </div>-->
                </div>
            </div>
        </div>
    </div>
</section>


<section class="section-7 hidden-md hidden-sm hidden-lg bg_white">


    <div class="container inspiration_container">

        <div class="row add_back home-row-add-back">

            <hr class="border-line">
            <div class="col-sm-12">
                <div class="row">
                    <div class="col-sm-12 hidden-xs">
                        <a href="#" class="webAdvertisment" target="_blank">
                            <img src="<?php echo base_url('assets'); ?>/images/glenmorangle_add_700X87.jpg">
                        </a>
                    </div>
                    <div class="col-md-12 hidden-lg hidden-md hidden-sm" style="display:none;">
                        <a href="#" class="webAdvertisment" target="_blank">
                            <img src="<?php echo base_url('assets'); ?>/images/img_advet_singalvenus.jpg">
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section><!-- section-7 -->

<style>
    #location-error{
        display:none !important;
    }
</style>

<script>
    jQuery.fn.extend({
        live: function (event, callback) {
            if (this.selector) {
                jQuery(document).on(event, this.selector, callback);
            }
        }
    }
    );
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $('.slider1').bxSlider({
            slideWidth: '130',
            minSlides: 3,
            maxSlides: 4,
            slideMargin: 15
        }
        );
    }
    );
</script>

<script type="text/javascript">
    $("#searchingformDesctop").validate();

    $('.date').datepicker({
        //format: 'dd-mm-yyyy',
        format: 'dd-mm-yyyy',
        todayHighlight: 'TRUE',
        autoclose: true,

    });


    $('.select_function').click(function () {
        $('.select_function').prop('checked', false);
        $(this).prop('checked', true)
    });
    function SwipeHomeContents(nwidth) {
        if (nwidth > 767) {
            $('div.parent').each(function () {
                var v = $(this).attr('id');
                div_no = v.split("_");
                var clChlid1 = '.child_1_' + div_no['1'];
                var clChlid2 = '.child_2_' + div_no['1'];
                var child_1 = $(clChlid1).detach();
                var child_2 = $(clChlid2).detach();
                $(child_1).appendTo('#' + v);
                $(child_2).appendTo('#' + v);
            });
        } else {
            $('div.parent').each(function () {
                var v = $(this).attr('id');
                div_no = v.split("_");
                var clChlid1 = '.child_1_' + div_no['1'];
                var clChlid2 = '.child_2_' + div_no['1'];
                var child_1 = $(clChlid1).detach();
                var child_2 = $(clChlid2).detach();
                $(child_2).appendTo('#' + v);
                $(child_1).appendTo('#' + v);
            });
        }
    }
    $(function () {
        $(window).resize(function () {
            var divwidth = $('.inspiration_container').width();
            var mainwidth = $('.home_page_banner').width();
            var padleft = (mainwidth - divwidth) / 2;
            var divw = $(this).width();

            var divwmain = divw - padleft;
            $('.main-div-left-padding').css("padding-left", padleft);
            $('.main-div-left-padding').css("width", divw);
            $('.main-div-sub-left-padding').css("padding-left", padleft);
            $('.main-div-sub-left-padding').css("width", divw);
            var addwidth = 0;
            if (divw > 767) {
                addwidth = 50;
            }
            var featureBannerheight = $('.features-banner-div > div >div').height();
            $('.home-main-div-fetures').css("height", featureBannerheight + addwidth);
            SwipeHomeContents(divw);

        }
        );

        var divwidth = $('.inspiration_container').width();
        var mainwidth = $('.home_page_banner').width();
        var padleft = (mainwidth - divwidth) / 2;
        var divw = $(this).width();
        var divwmain = divw - padleft;
        $('.main-div-left-padding').css("padding-left", padleft);
        $('.main-div-left-padding').css("width", divw);
        $('.main-div-sub-left-padding').css("padding-left", padleft);
        $('.main-div-sub-left-padding').css("width", divw);
        var addwidth = 0;
        if (divw > 767) {
            addwidth = 50;
        }
        SwipeHomeContents(divw);
        var featureBannerheight = $('.features-banner-div > div >div').height();
        $('.home-main-div-fetures').css("height", featureBannerheight + addwidth);
        // swipe home page contents

        /*$('div.parent').each(function () {
         //$('#div1').insertAfter('.div2');
         var v=$(this).attr('id');
         div_no=v.split("_");
         var clChlid1='.child_1_'+div_no['1'];
         var clChlid2='.child_2_'+div_no['1'];
         var child_1 = $(clChlid1).detach();
         var child_2 = $(clChlid2).detach();
         $(child_2).appendTo('#'+v);
         $(child_1).appendTo('#'+v);
         }); */
    }
    );

</script>



<script type="text/javascript">
    var slider_parameter = {
        autoPlay: true,
        navigation: true,
        items: 6,
        loop: false,
        itemsMobile: [479, 3],
        itemsTablet: [768, 3],
        itemsDesktop: [1370, 3],
        itemsDesktopSmall: [1170, 3],
        rewindNav: false,
        navClass: ["nex", "pr"],
        navigationText: [".", "."],
        captions: true
    };

    let $owl = $("#bxslider_1");
    $(document).ready(function () {
        $owl.owlCarousel(slider_parameter);
    });
</script>

<script type="text/javascript" src="<?php echo base_url('assets/plugins/parsley/parsley.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/custom/common.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/custom/function.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/plugins/autocomplete/jquery-ui.js'); ?>"></script>
<script type="text/javascript">
    setTimeout(
            function ()
            {
                $(".CloseLock").show();
                $(".OpenLock").hide();
            }, 5000);

    // $('.CloseLock').click(function() {
    // $(".CloseLock").hide();
    // });
    //   $(".CloseLock").click(function(){
    // // $("div").removeClass("overlay");
    //  $('div#overlay').removeAttr('id');

    //});

    $("#newdemo").click(function () {
        $("#newdemo").effect("shake");
    });

    $("#newdemo1").click(function () {
        $("#newdemo1").css('top', "0px !important");
        $("#newdemo1").effect("shake");
        $("#newdemo1").css('top', "0px !important");
    });
</script>

<script>
    $(function () {
        $('.bxslider').bxSlider({
            mode: 'fade',
            auto: true,
            slideWidth: 600
        });
    });
</script>
