 
 <div class="home_tc_head"><?php echo $pages_data->content;?></div>


<style type="text/css">
  .p_tag_ne{
  font-size: 16px;
  color: #777;
}
.padd_left_30 {
  padding-left: 30px;
  font-style: italic;
  font-size: 16px;
  color: #777;
}
.h_tag_contact {
  font-size: 17px;
  font-weight: 600;
  color: #777;
}
ul.doted li {
  font-size: 16px;
  color: #777;
  line-height: 30px;
}
</style>


