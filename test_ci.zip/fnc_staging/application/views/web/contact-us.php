<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<section>
    <div class="container  mt-5">
        <div class="row mt-5">
            <?php if ($this->session->flashdata('error')) { ?>
                <div class="alert alert-danger col-md-6 col-md-offset-3">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?Php echo $this->session->flashdata('error'); ?>
                </div>
            <?php }
            ?>
            <?php if ($this->session->flashdata('success')) { ?>
                <div class="alert alert-success col-md-6 col-md-offset-3">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?Php echo $this->session->flashdata('success') ?>
                </div>
            <?php }
            ?>
            <div class="col-md-12">
                <div class="font-contact home_tc_head">
                    Contact us
                </div>
            </div>
        </div>
        <div class="row margin_contact_page">
            <div id="contact_us">
                <div class="col-sm-12 profile_row c_us_content_in">
                    <div class="row">
                        <form method="post" id="contact_form" action="<?php echo site_url('web/contact_us'); ?>" >
                            <div class="col-md-6 col-sm-6">
                                <div class="col-md-12 margin_set_input">                
                                    <label class="lbl_class">Full Name</label>
                                    <input type="text" class="form-control alphaText" data-msg-required="Please enter your full name" data-rule-required="true" name="contact_name" maxlength="40" value="<?php echo set_value('contact_name'); ?>">
                                    <?php echo form_error('contact_name', '<label id="contact_name-error" class="error">', '</label>'); ?>
                                </div>
                                <div class="col-md-12 margin_set_input">                
                                    <label class="lbl_class remove_fil_1">Business Name</label>
                                    <input type="text" class="form-control alphaText"  name="contact_business_name" maxlength="100">
                                </div>
                                <div class="col-md-12 margin_set_input">                
                                    <label class="lbl_class">E-mail Address</label>
                                    <input type="email" class="form-control" data-msg-required="Please enter your email" data-rule-required="true" name="contact_email" maxlength="40" value="<?php echo set_value('contact_email'); ?>">
                                    <?php echo form_error('contact_email', '<label id="contact_email-error" class="error">', '</label>'); ?>
                                </div>
                                <div class="col-md-12 margin_set_input">                
                                    <label class="lbl_class">State </label>
                                    <select class="form-control addr-field business_form"  data-msg-required="Please enter your state" data-rule-required="true" onchange="getCityByState($(this).val())" id="contact_state" name="contact_state" value="">
                                        <option value="" selected="selected" class="">Select State</option>
                                        <option value="ACT">ACT</option>
                                        <option value="QLD">QLD</option>
                                        <option value="NSW">NSW</option>
                                        <option value="NT">NT</option>
                                        <option value="SA">SA</option>
                                        <option value="TAS">TAS</option>
                                        <option value="Vic">VIC</option>
                                        <option value="WA">WA</option>
                                    </select>
                                </div>
                                <input type="hidden" name="hidden_state" id="hiddenState">
                                <div class="col-md-12 margin_set_input">                
                                    <label class="lbl_class">City </label>
                                    <input type="text" class="form-control alphaText" id="search-box" data-msg-required="Please enter your city" data-rule-required="true" name="contact_city" maxlength="64">
                                </div>
                                <div class="col-md-12 margin_set_input">                
                                    <label class="lbl_class">Postal code</label>
                                    <input type="text" data-msg-required="Please enter your postal code" class="form-control" data-rule-required="true" name="contact_postal_code" id="contact_postal_code" maxlength="5" data-rule-postcodecheck='true' tabindex="-1">
                                    <?php //echo form_error('contact_email', '<label id="contact_postal_code-error" class="error">', '</label>'); ?>
                                </div>
                                <div class="col-md-12 margin_set_input">                
                                    <label class="lbl_class">Message </label>
                                    <textarea  name="contact_message" data-msg-required="Please enter your query" data-rule-required="true" class="text_area_set_106" maxlength="1024" pattern="[^\\/:<>*]+" rows="9"><?php echo set_value('contact_message'); ?></textarea>
                                    <?php echo form_error('contact_message', '<label id="contact_message-error" class="error">', '</label>'); ?>
                                </div>
                                <?php if (CAPTCHA_SHOW) { ?>
                                    <div class="col-md-12 margin_set_input">                
                                        <div class="lbl_class g-recaptcha" data-sitekey="<?php echo CAPTCHA_SITE_KEY ?>" ></div>
                                    </div>
                                <?php } ?>

                                <div class="col-md-12">
                                    <input type="submit" value="Send" id="button_contact_submit" class="button_login_submit">
                                </div>
                            </div><!-- col-md-6 -->
                        </form>
                        <div class="col-md-6 col-sm-6 margin_top_advertise_106" >
                            <div class="col-md-12">    
                                <div  id="map"></div>                      
                                <!--<a href="" class="webAdvertisment slide_image hidden-xs" target="_blank">-->
                                <span href="" class="webAdvertisment slide_image hidden-xs" target="_blank">
                                    <img src="<?php echo base_url(); ?>assets/images/glenmorangle_add_700X87_new.jpg" class="slide_img">
                                </span>
                                <!--</a>-->
                                <!--<a href="#" class="webAdvertisment slide_image hidden-lg hidden-md hidden-sm" target="_blank">-->
                                <span href="#" class="webAdvertisment slide_image hidden-lg hidden-md hidden-sm" target="_blank">
                                    <img src="<?php echo base_url('assets'); ?>/images/img_advet_singalvenus_new.jpg">
                                    <!--</a>-->  
                                </span>
                            </div>
                        </div>
                        <div class="col-sm-12 margin_set_input no-pad ">							
                            <label for="post_city_error" class="error CheckieError" style="">Entered values for City, State & Postcode do not match</label>
                        </div>
                    </div>
                </div>
            </div><!-- contact_us -->
        </div>
        <!--row-->
    </div>
    <!--container-->
</section>
<script  type="text/javascript">
    $("#contact_form").validate();
    function initialize() {
//        var latlng = new google.maps.LatLng(-37.8136276, 144.96305759999996);
//        var latlng = new google.maps.LatLng(-37.835812, 144.973694);
        var latlng = new google.maps.LatLng(-37.8529653, 144.9807391);
        var map = new google.maps.Map(document.getElementById('map'), {
            center: latlng,
            zoom: 13
        });
        var marker = new google.maps.Marker({
            map: map,
            position: latlng,
            draggable: false,
            anchorPoint: new google.maps.Point(0, -29),
            icon: base_url + 'assets/images/map_icon.svg'
        });
        var infowindow = new google.maps.InfoWindow();
        google.maps.event.addListener(marker, 'click', function () {
            infowindow.setContent(iwContent);
            // opening the infowindow in the current map and at the current marker location
            infowindow.open(map, marker);
        });
    }
    google.maps.event.addDomListener(window, 'load', initialize);

    // function using for get city by suburb
    function getCityByState(state) {
        $('#hiddenState').val(state);
//        $('#search-box').val(' ');
        $('#contact_postal_code').val(' ');
        $('#contact_postal_code').attr('readonly', false);
    }

    // AJAX call for autocomplete 
    $(document).ready(function () {
        $("#search-box").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: baseURL + 'Web/get_city_by_state',
                    dataType: "json",
                    method: "POST",
                    data: {city: request.term, state: $('#hiddenState').val()},
                    success: function (data) {
                        response(data.city);
                    }
                });
            },
            select: function (event, ui) {
                $('#search-box').val(ui.item.value);
                $.ajax({
                    url: baseURL + 'Web/get_postcode_by_city',
                    dataType: "json",
                    method: "POST",
                    data: {cityId: ui.item.id, state: $('#hiddenState').val()},
                    success: function (data) {
                        if (ui.item.label != '') {
                            $('#contact_postal_code').val(data.postcode[0].postcode);
                            $('#contact_postal_code').attr('readonly', true);
                        } else {
                            $('#contact_postal_code').val(' ');
                            $('#contact_postal_code').attr('readonly', false);
                        }
                    }
                });
                return false;
            }
        });

        $('#search-box').keydown(function (event) {
            if (event.which != 9) {
                $('#contact_postal_code').attr('readonly', false);
                $('#contact_postal_code').val(' ');
            }
        });

        $(document).on("click", "#button_contact_submit ", function (e) {
            $("#contact_form").validate({errorElement: 'p', errorClass: 'customErrorClass1'});
            $("label[for='post_city_error']").hide();
            if ($("#contact_form").valid()) {
                var status = false;
                var cityname = $('#search-box').val();
                var postcodename = $('#contact_postal_code').val();
                var user_state = $('#hiddenState').val();
                $.ajax({
                    url: baseURL + 'Web/check_valid_address',
                    method: "POST",
                    dataType: "json",
                    async: false,
                    data: {city: cityname, postcode: postcodename, user_state: user_state},
                    success: function (response) {
                        if (response.exist == 0) {
                            e.preventDefault();
                            $("label[for='post_city_error']").show();
                            return false;
                        } else {
                            return true;
                        }
                    }, error: function (error) {
                        console.log(error);
                    }
                });
            }
        });
    });

</script>