<section>

    <div class="container-fluid">

        <div class="row">

            <img src="<?php echo base_url(); ?>assets/images/TERMS-AND-CONDITIONS.png" class="img-responsive bann_img" />

        </div>

    </div>

</section>





<section>

</section>

<div class="container">
    <div class="row">

        <div class="col-sm-12">
            <div id="terms_and_condition">
                <div class="tc_head">Terms and Conditions</div>

                <table class="teram_table" cellspacing="0" cellspacing="0" width="100%">
                    <tr class="hdng2">
                        <td class="padd_left_15px">1. </td>
                        <td colspan="2">Terms of Use</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%" class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px">1.1</td>
                                    <td>
                                        In these Terms of Use (Terms) ‘You’ and ‘Your’ refers to the person or persons that access and
                                        navigate the Service. ‘Functions & Catering, ‘us’ and ‘we’ refers to Functions and Catering
                                        Australia Pty. Ltd. (ACN
                                        <!-- [Insert] -->) trading as
                                        <!-- [Insert] -->
                                    </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">1.2</td>
                                    <td>
                                        Please read this agreement carefully – it contains terms of use that are binding on you in
                                        respect of your use of the Service. By continuing to use the Service, you accept these Terms in
                                        their entirety and agree to be bound by them.
                                    </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">1.3</td>
                                    <td>
                                        Functions and Catering grants you the right to access and use the Service for the following
                                        permitted purposes <b>(Permitted Purposes)</b>
                                        <table width="100%">
                                            <tr>
                                                <td class="padd_left_15px width_set-a">a.</td>
                                                <td>Creating and updating your profile;</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">1.4</td>
                                    <td>
                                        Your right to access the Service is non-exclusive, non-transferable, and limited to the
                                        Permitted Purposes described in these Terms, or otherwise specified in writing by Functions &
                                        Catering.
                                    </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">1.5</td>
                                    <td>
                                        Functions & Catering may revoke or cancel your right of access at any time if you fail to
                                        comply with these Terms.
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!--1-->

                    <tr class="hdng2">
                        <td class="padd_left_15px">2. </td>
                        <td colspan="2">Modification</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%" class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px">2.1</td>
                                    <td>These Terms may be varied, replaced or removed at the discretion of Functions & Catering without
                                        further notice to you</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">2.2</td>
                                    <td> It is your obligation to ensure that you have read, understood and agree to the most recent version
                                        of the Terms available on the Service. You agree and acknowledge that your continued use of the
                                        Service will amount to renewed acceptance of these Terms as varied, replaced or removed and
                                        agree to be bound by them on each occasion that you access the Service.</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!--2-->


                    <tr class="hdng2">
                        <td class="padd_left_15px">3. </td>
                        <td colspan="2">Payments, cancellations, and cooling off</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%" class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px">3.1</td>
                                    <td><b>1 Service Options:</b> You can find a description of our Service Options on our website, and
                                        Functions & Catering will explain which Service Options are available to you when you create
                                        an account. Service options require payment before you can access them (the <b>“Paid
                                            Subscriptions”</b>). We may also offer special promotional plans, memberships, or services,
                                        including offerings of third party products and services in conjunction with or through our
                                        Service. We reserves the right to modify, terminate or otherwise amend our offered
                                        subscription plans and promotional offerings at any time in accordance with these Terms. </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">3.2</td>
                                    <td> <b>Trials:</b> From time to time, Functions & catering may offer trials of Paid Subscriptions for a
                                        specified period without payment or at a reduced rate (a “Trial”). Functions & Catering may
                                        determine your eligibility for a Trial, and withdraw or modify a Trial at any time without prior
                                        notice and with no liability, to the extent permitted under applicable law.
                                        For some Trials, we’ll require you to provide your payment details to start the Trial. By
                                        providing such details you agree that we may automatically begin charging you for the Paid
                                        Subscription on the first day following the end of the Trial on a recurring monthly basis or
                                        another interval that we disclose to you in advance. If you do not want this charge, you must
                                        cancel the applicable paid subscription before the end of the trial by</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">3.3</td>
                                    <td> <b>Billing:</b> You may purchase a Paid Subscription directly from Functions & Catering by paying a
                                        subscription fee in advance on a monthly basis or some other recurring interval disclosed to
                                        you prior to your purchase or pre-payment giving you access to Service Options for a specific
                                        time period.
                                        Functions & Catering may change the price for the Paid Subscriptions, including recurring
                                        subscription fees from time to time and will communicate any price changes to you in
                                        advance and, if applicable, how to accept those changes. Price changes will take effect at the
                                        start of the next subscription period following the date of the price change. Subject to
                                        applicable law, you accept the new price by continuing to use the Service after the price
                                        change takes effect. If you do not agree with a price change, you have the right to reject the
                                        change by unsubscribing from the Paid Subscription prior to the price change going into</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">3.4</td>
                                    <td> If you register for a Paid Subscription, you may change your mind for any or no reason and
                                        receive a full refund of all monies paid within fourteen (14) days starting from the day you
                                        sign-up for the relevant service (the <b>“Cooling-off Period”</b>) in accordance with the following:
                                        <table width="100%">
                                            <tr>
                                                <td class="padd_left_15px width_set-a">a.</td>
                                                <td>If you sign up for a Trial, you agree that the Cooling-off Period for the Paid Subscription
                                                    for which you are receiving a Trial ends fourteen (14) days after you start the Trial. If you
                                                    don’t cancel the Paid Subscription before the Trial ends, you lose your right of
                                                    withdrawal and authorise Functions & Catering to automatically charge you the agreed
                                                    price each month until you cancel the Paid Subscription.
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px width_set-a">b.</td>
                                                <td>If you purchase a Paid Subscription with no Trial, you authorise Functions & Catering to
                                                    charge you automatically each month until you cancel. You agree that the Cooling-off
                                                    Period is available for fourteen (14) days after you purchase but is lost once you use the
                                                    Service during that period.</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                            </table>
                        </td>
                    </tr>
                    <!--3-->

                    <tr class="hdng2">
                        <td class="padd_left_15px">5. </td>
                        <td colspan="2">Privacy & Security</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%" class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px"><b>4.1</b></td>
                                    <td><b>Privacy:</b> Your use of the Service is governed by the Privacy Policy. You agree to be bound by the
                                        Privacy Policy as a condition of your right of access to the Service. You should read the Privacy
                                        Policy carefully as it applies to personal information that you provide through your use of the
                                        Service, and contains binding terms in respect of your disclosure of personal information. By
                                        continuing to use the Service you accept the Privacy Policy and agree to be bound by the Privacy
                                        Policy where applicable</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px"><b>4.2</b></td>
                                    <td><b>Security:</b> You acknowledge that it is your responsibility to keep your user account and login
                                        details (including any password protected access details) secure and indemnify Functions and
                                        Catering against any claim or loss (including consequential or incidental loss or claim of breach of
                                        any privacy laws) of any kind in respect of any unauthorised access to the Service and your
                                        personal information. You must immediately notify Functions & Catering of any unauthorised
                                        use of your account or any other breach of security.
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!--4-->


                    <tr class="hdng2">
                        <td class="padd_left_15px">5. </td>
                        <td colspan="2">Confidentiality</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%" class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px">5.1</td>
                                    <td>You agree to preserve the confidentiality of any Confidential Information of any other person
                                        obtained in connection with your use of the Service. You will not, without the prior written
                                        consent of the other party, disclose or make any Confidential Information available to any third
                                        party, or use another person’s Confidential Information for your own benefit, other than as
                                        permitted by these Terms.</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">5.2</td>
                                    <td>You agree that your obligations in respect of all Confidential Information under this clause will
                                        survive termination of these Terms</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">5.3</td>
                                    <td>The provisions of clauses 4.1 and 4.2 shall not apply to any information which is:
                                        <table width="100%">
                                            <tr>
                                                <td class="padd_left_15px width_set-a">a.</td>
                                                <td>or becomes public knowledge other than by a breach of this clause;
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px width_set-a">b.</td>
                                                <td>received from a third party who lawfully acquired it and who is under no obligation
                                                    restricting its disclosure;
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px width_set-a">c.</td>
                                                <td>in relation to disclosure, Confidential Information that is in your possession prior to
                                                    the date that you are bound by these terms;
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">5.4</td>
                                    <td>Notwithstanding the parties obligations in clauses 4.1 to 4.3, you agree that to the extent
                                        permitted by law, Functions & Catering is not liable to you for any breach of confidentiality
                                        resulting from disclosure of your Confidential Information that is not within the reasonable
                                        control of Functions & Catering (including any breach to Functions & Catering’s data security
                                        arising from any unauthorised third party access, intrusion or corruption of any kind to the
                                        Service).</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">5.5</td>
                                    <td>You agree that any communications between you and Functions & Catering are Confidential
                                        Information and that you will not disclose such communications to any third party.</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!--5-->


                    <tr class="hdng2">
                        <td class="padd_left_15px">6. </td>
                        <td colspan="2">Intellectual Property</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%" class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px"><b>6.1</b></td>
                                    <td><b>General:</b> title to, and all Intellectual Property Rights in the Service, the underlying software and
                                        code of the Service and any documentation relating to the Service, including all content,
                                        trademarks, trade names and service marks, remain the property of Functions & Catering. </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px"><b>6.2</b></td>
                                    <td><b>Ownership of Data:</b> title to, and all Intellectual Property Rights in, the Data remain your
                                        property. You grant Functions & Catering a licence to use, copy, transmit, store, and back-up
                                        your information and Data for the purposes of enabling you to access and use the Service.
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!--6-->


                    <tr class="hdng2">
                        <td class="padd_left_15px">7. </td>
                        <td colspan="2">Account Registration</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%" class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px">7.1</td>
                                    <td>In order to access some or all of the features of the Service you may be required to create an
                                        account with password access.</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">7.2</td>
                                    <td>It is your responsibility to choose a suitably secure password and store your password safely.
                                        Functions & Catering is not liable for any loss resulting from any failure by you to secure your
                                        password details</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">7.3</td>
                                    <td>Where the Service integrates your profile with third party social media, you agree to Functions
                                        & Catering providing your personal information to such third parties and acknowledge that
                                        your use of the Service and any third party use of your personal information is solely at your
                                        own risk.</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!--7-->

                    <tr class="hdng2">
                        <td class="padd_left_15px">8. </td>
                        <td colspan="2">Acceptable User Conduct Policy</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%" class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px">8.1</td>
                                    <td>Use for Permitted Purposes Only - you agree to only use the Service for the Permitted
                                        Purposes. You agree that you will not:
                                        <table width="100%">
                                            <tr>
                                                <td class="padd_left_15px">a.</td>
                                                <td>use the Service except in your personal capacity; </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">b.</td>
                                                <td>use the Service for any purpose that is improper, unlawful, or to post, share or
                                                    transmit any material that:
                                                    <table width="100%">
                                                        <tr>
                                                            <td class="padd_left_15px">i.</td>
                                                            <td>is defamatory, offensive, obscene or otherwise objectionable;</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">ii.</td>
                                                            <td>is in breach of confidentiality or privacy or of any third party’s Intellectual
                                                                Property Rights:</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">iii.</td>
                                                            <td>is posted, shared or transmitted for the purpose of advertising or promoting
                                                                goods or services (either your own goods or services or the goods or services
                                                                of any third party) without the prior consent of Functions & Catering; or </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">iv.</td>
                                                            <td>is misleading or misrepresentative as to your identity or which in any way
                                                                suggests that you represent, are sponsored by, affiliated or connected with
                                                                Functions & Catering;</td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">c.</td>
                                                <td>use the Service except for legitimate private use or in any manner which may cause
                                                    damage or cause any claim to be made against Functions & Catering</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">d.</td>
                                                <td>disassemble, reverse engineer or otherwise decompile the Service or derive or
                                                    create any software, applications, updates, code, mobile applications or hardware
                                                    from the Service or information available on the Service, without the prior written
                                                    consent of Functions & Catering;</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">e.</td>
                                                <td>copy, distribute and/or communicate the Service in any way that would infringe on
                                                    Functions & Catering‘s Intellectual Property Rights;</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">f.</td>
                                                <td>attempt to access any Confidential Information of third parties or tamper with or
                                                    circumvent any security procedures embedded in the Service in any way;</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">g.</td>
                                                <td>attempt to upload any malicious software to the Service, to any other user of the
                                                    Service, or to any third party that hosts any element of the Service, or provides any
                                                    part of the Service, including Trojan Horses, time bombs, worms, denial of service
                                                    attacks, viruses, altered code, licence control utilities, software locks or other
                                                    harmful codes;</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">h.</td>
                                                <td>Undertake any of the following acts:
                                                    <table width="100%">
                                                        <tr>
                                                            <td class="padd_left_15px">i.</td>
                                                            <td>Set up a fraudulent profile or a profile which contains any false or misleading
                                                                information;</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">ii.</td>
                                                            <td>Use other person’s pictures or private information without permission;</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">iii.</td>
                                                            <td>Use the Service for illegal activities or for promoting illegal activities of any
                                                                kind; or</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">iv.</td>
                                                            <td>Use the Service in connection with any commercial endeavours whatsoever,
                                                                including advertising or soliciting any other user to buy or sell any goods
                                                                and/or services. </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">8.2</td>
                                    <td> <b>Communication Conditions:</b> As a condition of these Terms, you agree to only communicate
                                        with other users of the Service (both in person and through the Services’ communication
                                        tools) for lawful and legitimate purposes. In addition to section 8(1) above, you agree that:
                                        <table>
                                            <tr>
                                                <td class="padd_left_15px">a.</td>
                                                <td>You will not communicate, post or disseminate any material unrelated to the use of
                                                    the Service, including (but not limited to): </td>
                                            </tr>

                                            <tr>
                                                <td class="padd_left_15px"></td>
                                                <td>
                                                    <table width="100%">
                                                        <tr>
                                                            <td class="padd_left_15px">i.</td>
                                                            <td>Offers of goods or services for sale and unsolicited commercial e-mail;</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">ii.</td>
                                                            <td>Files that may damage any other person’s computing devices or software;</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">iii.</td>
                                                            <td>Content or comments that may be offensive to any other users, including but
                                                                not limited to, that which promotes racism or hatred of any kind or advocates
                                                                the harassment or intimidation of another person;
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">iv.</td>
                                                            <td>Material which involves the transmission of spam, junk mail, chain letters or
                                                                any other unsolicited mass mail; or</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">v.</td>
                                                            <td>Content, comments or material of any kind in violation of any law (including
                                                                material that is protected by copyright or trade secrets which you do not have
                                                                the right to use). </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">b.</td>
                                                <td>When you make any communication, you represent that you are permitted to make
                                                    such communication, and that the communication is not misleading or deceptive in
                                                    any way </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">c.</td>
                                                <td>Functions & Catering is under no obligation to ensure that the communications are
                                                    legitimate or that they are related only to the use of the Service. You must exercise
                                                    caution when using the communication tools available on the Service. Functions &
                                                    Catering reserves the right to remove any communication at any time in its sole
                                                    discretion and for any reason.</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">8.3</td>
                                    <td>Use subject to third party terms and conditions: some elements of the Service may interface
                                        with external third party websites and resources. You agree that the Service may access,
                                        utilise and/or exchange your personal information with external third party providers, and
                                        that you agree to act in accordance with the terms and conditions of use of those third parties
                                        servers, in addition to these Terms.<br>
                                        You acknowledge and agree that Functions & Catering is not responsible or liable for any
                                        content or information from such websites or resources. Your correspondence and business
                                        dealings with third parties located through the use of the Service, including payment and
                                        delivery of related goods or services are solely between you and such third party. You further
                                        acknowledge and agree that Functions & Catering shall not be directly or indirectly
                                        responsible or liable for any loss or damage caused in connection with the use of these third
                                        party websites or resources.</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">8.4</td>
                                    <td><b>Usage Limitations:</b> Use of the Service may be subject to limitations imposed by Functions &
                                        Catering for any reason. You agree and acknowledge that Functions & Catering may, in its
                                        absolute discretion, limit or terminate your right of access to use the Service for any reason,
                                        and at any time</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">8.5</td>
                                    <td><b>Indemnity:</b> You indemnify Functions & Catering against: all claims, costs, damage and loss
                                        arising from your use of the Service or for any breach of these Terms or any obligation you
                                        may have to Functions & Catering, including (but not limited to) any costs relating to the
                                        recovery of costs by Functions & Catering from you. </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!--8-->


                    <tr class="hdng2">
                        <td class="padd_left_15px">9. </td>
                        <td colspan="2">Warranties & Acknowledgments</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%"  class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px">9.1</td>
                                    <td>1 Authority: You warrant that you are lawfully authorised to enter into these Terms, and
                                        where you have registered to use the Service with the permission and supervision of a legal
                                        guardian, your legal guardian consents to these Terms on your behalf.</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">9.2</td>
                                    <td>Acknowledgement: You acknowledge that:
                                        <table>
                                            <tr>
                                                <td class="padd_left_15px">a.</td>
                                                <td>You are authorised to use the Service and to access the information and Data that you
                                                    input via the Service. You also acknowledge that you are authorised to access
                                                    information and Data that is made available to you through your use of the Service
                                                    (whether that information and Data is your own or that of anyone else).</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">b.</td>
                                                <td>To the extent permitted by law, Functions & Catering has no responsibility to any third
                                                    party under these Terms and nothing in these Terms confers, or purports to confer, a
                                                    benefit on any person other than you. If you use the Service on behalf of or for the
                                                    benefit of any other person (whether a body corporate or otherwise) you agree that:
                                                    <table>
                                                        <tr>
                                                            <td class="padd_left_15px">i.</td>
                                                            <td>You are responsible for ensuring that you have the right to do so;</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">ii.</td>
                                                            <td>You are responsible for authorising any person who is given access to
                                                                information or Data, and you agree that Functions & Catering has no obligation
                                                                to provide any person access to such information or Data without your
                                                                authorisation and may refer any requests from any third person to access
                                                                information or Data to you; and</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">iii.</td>
                                                            <td>To the extent permitted by law, you will indemnify Functions & Catering against
                                                                any claims or loss relating to Function & Catering’s refusal or grant of access to
                                                                any person, denying or permitting access to information or Data in accordance
                                                                with these Terms.
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">c.</td>
                                                <td>You use the Service entirely at your own risk.</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">d.</td>
                                                <td>Your interaction with other users is entirely your responsibility. You agree that:
                                                    <table>
                                                        <tr>
                                                            <td class="padd_left_15px">i.</td>
                                                            <td>You will take all necessary precautions to protect your financial information,
                                                                including credit card numbers, bank information or tax file numbers;</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="padd_left_15px">ii.</td>
                                                            <td>You will ignore any and all requests to send money and report any such request
                                                                to Functions & Catering immediately; and</td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">e.</td>
                                                <td>Functions & Catering does not take steps to verify the personal information provided
                                                    to it by you or by other users.
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">f.</td>
                                                <td>Functions & Catering does not currently conduct criminal background checks on users</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">g.</td>
                                                <td>Functions & Catering reserves the right to conduct any background check, including
                                                    any criminal background check, at any time.</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">h.</td>
                                                <td>Your right to access and use the Service is granted on an “as is” basis and at your own
                                                    risk.</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">i.</td>
                                                <td>Functions & Catering does not warrant that the use of the Service will be
                                                    uninterrupted or error free. Among other things, the operation and availability of the
                                                    systems used for accessing the Service, including public communication services,
                                                    computer networks and the Internet, can be unpredictable and may from time to time
                                                    interfere with or prevent access to the Service. Functions & Catering is not in any way
                                                    responsible for any such interference or prevention of your access or use of the
                                                    Service. </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">j.</td>
                                                <td>Functions & Catering is not liable for, and does not provide you with any advice.</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">k.</td>
                                                <td>Any guidance and/or recommendation made by Functions & Catering is provided
                                                    generally and Functions & Catering has no liability whatsoever for any such guidance
                                                    or recommendation. </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">l.</td>
                                                <td>You remain solely responsible for complying with all applicable laws. It is your
                                                    responsibility to check that storage of and access to Data via the Service will comply
                                                    with laws applicable to you (including any laws requiring you to retain records).
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">9.3</td>
                                    <td>No warranties: Functions & Catering gives no warranties about the Service. </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">9.4</td>
                                    <td>Without limiting the foregoing, Functions & Catering does not warrant that:
                                        <table>
                                            <tr>
                                                <td class="padd_left_15px">a.</td>
                                                <td>the Service will meet your requirements or that it will be suitable for any particular
                                                    purpose. To avoid doubt, all implied conditions or warranties are excluded in so far as
                                                    is permitted by law, including (without limitation) warranties of merchantability,
                                                    fitness for purpose, title and non-infringement; or</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">b.</td>
                                                <td>Functions & Catering will verify or take any steps (other than such reasonable steps
                                                    specified in the Privacy Policy) to secure or verify any information published to or on
                                                    the Service by you or any third party, including personal information.</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                            </table>
                        </td>
                    </tr>
                    <!--9-->



                    <tr class="hdng2">
                        <td class="padd_left_15px">10. </td>
                        <td colspan="2">Limitation of Liability</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%"  class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px">10.1</td>
                                    <td>To the maximum extent permitted by law, Functions & Catering excludes all liability and
                                        responsibility to you or any other person, including but not limited to any loss or damage
                                        whatsoever:

                                        <table width="100%">
                                            <tr>
                                                <td class="padd_left_15px">a.</td>
                                                <td>in contract, tort (including negligence), or otherwise, for any loss (including
                                                    consequential loss of information, Data, or pecuniary loss) or damage resulting,
                                                    directly or indirectly, from any use of, or reliance on, the Service; </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">b.</td>
                                                <td>arising in connection with the conduct of any other user of the Service, including
                                                    through communications on the Service, during games arranged using the Service or
                                                    arising at any other time whatsoever;
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">c.</td>
                                                <td>resulting from your reliance on any other user’s profile and disclosed personal
                                                    information.</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">10.2</td>
                                    <td>You agree that any claim for loss or damage suffered as a result of Function & Catering’s
                                        negligence or failure to comply with these Terms, will be limited to amounts paid by you to
                                        Function & Catering (if any) to acquire access to the Service.</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">10.3</td>
                                    <td>Function & Catering is not responsible for the conduct of any user and in no event shall
                                        Function & Catering, its affiliates or its partners be liable (directly or indirectly) for any losses
                                        or damages whatsoever, whether direct, indirect, general, special, compensatory,
                                        consequential, and/or incidental, arising out of or relating to the conduct of you or anyone
                                        else in connection with the use of the Service including, without limitation, death, bodily
                                        injury, emotional distress, and/or any other damages resulting from communications or
                                        meetings with other users or persons you meet through the Service. You agree to take all
                                        necessary precautions in all interactions with other users, particularly if you decide to
                                        communicate off the Service or when meeting in person.</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">10.4</td>
                                    <td>You agree to indemnify Function & Catering, its agents, officers and employees free from
                                        any liability or responsibility whatsoever, made by any third party, arising or allegedly arising
                                        out of your use of the Service, including but not limited to claims in relation to you providing
                                        any false or misleading personal information or your making of a false, misleading or
                                        inaccurate profile. If you are not satisfied with the Service, you agree that your sole and
                                        exclusive remedy is to terminate your use of the Service. </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">10.5</td>
                                    <td>The Website may contain links to third-part sites that are not owned or controlled by
                                        Functions & Catering. Functions & Catering has no control over, and assumes no
                                        responsibility for, the content, privacy policies, or practices of any third party terms and
                                        conditions and privacy policy of any third party site that you visit.</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!--10-->



                    <tr class="hdng2">
                        <td class="padd_left_15px">11. </td>
                        <td colspan="2">Termination and Suspension of Use</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%"  class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px">11.1</td>
                                    <td>No fault termination: Function & Catering may terminate your right of access to the Service
                                        or suspend your account immediately, without liability and without notice if Function &
                                        catering and/or its officers believe that you are in breach of these Terms, or that you do not
                                        have the full authority to use the Service. You agree that Function & Catering may terminate
                                        or suspend your account without liability to you. Function & Catering is not obliged to
                                        disclose to you the reason for termination or suspension. </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">11.2</td>
                                    <td>Accrued rights: Termination of these Terms is without prejudice to any rights and obligations
                                        of the parties accrued up to and including the date of termination. </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">11.3</td>
                                    <td>Expiry or termination: These Terms will survive termination or suspension of your account
                                        and continue in full force and effect, except for any Term which expires by its nature. </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!--11-->



                    <tr class="hdng2">
                        <td class="padd_left_15px">12. </td>
                        <td colspan="2">General</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%"  class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px">12.1</td>
                                    <td>Entire agreement: These Terms, together with the Privacy Policy and the terms of any other
                                        notices or instructions given to you under these Terms supersede and extinguish all prior
                                        agreements, representations (whether oral or written), and understandings and constitute
                                        the entire agreement between you and Functions & Catering relating to the Service and the
                                        other matters dealt with in these Terms.</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">12.2</td>
                                    <td>Waiver: If either party waives any breach of these Terms, this will not constitute a waiver of
                                        any other breach. No waiver will be effective unless made in writing.</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">12.3</td>
                                    <td>Delays: Neither party will be liable for any delay or failure in performance of its obligations
                                        under these Terms if the delay or failure is due to any cause outside its reasonable control.
                                        This clause does not apply to any obligation to pay money.</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">12.4</td>
                                    <td>No Assignment: You may not assign or transfer any rights to any other person without
                                        Functions and Catering’s prior written consent.</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">12.5</td>
                                    <td>Governing law and jurisdiction: These Terms are governed by the laws of Victoria, Australia.
                                        The parties agree to submit to the non-exclusive jurisdiction of the Courts of Victoria, and
                                        Courts entitled to hear appeals from these Courts</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">12.6</td>
                                    <td>Severability: If any part or provision of these Terms is invalid, unenforceable or in conflict
                                        with any applicable law, that part or provision is deemed to have removed or varied to the
                                        extent of the inconsistency. The remainder of these Terms will be binding on the parties.</td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">12.7</td>
                                    <td>Notices: Any notice given under these Terms by either party to the other must be in writing
                                        by email and will be deemed to have been given on transmission.
                                        <table width="100%">
                                            <tr>
                                                <td class="padd_left_15px">a.</td>
                                                <td>Notices to Functions & Catering must be sent to: [INSERT] or to any other address
                                                    notified to you by Functions & Catering.
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">b.</td>
                                                <td>Notices to you will be sent to the email address which you provided when setting up
                                                    your access to the Service. </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="padd_left_15px">12.8</td>
                                    <td>Rights of Third Parties: A person who is not a party to these Terms has no right to benefit
                                        under or to enforce any term of these Terms</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!--12-->

                    


                    <tr class="hdng2">
                        <td class="padd_left_15px">13. </td>
                        <td colspan="2">Definitions</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <table width="100%"  class="tabwd90">
                                <tr>
                                    <td class="padd_left_15px">13.1</td>
                                    <td>In these Terms, the following words have the following meanings unless stated otherwise:
                                        <table width="100%">
                                            <tr>
                                                <td class="padd_left_15px">a.</td>
                                                <td><b>“Confidential Information”</b> means any information identified as being of a
                                                    confidential nature, or that would be reasonably understood to be of a confidential
                                                    nature, and includes any personal information about any third party other than
                                                    personal information disclosed by that party voluntarily through their use of the
                                                    Service (but for the avoidance of doubt excludes any personal information of a user
                                                    voluntarily disclosed by their use of the Service).;
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">b.</td>
                                                <td><b>“Data”</b> means any data uploaded by you or with your authority into the Service,
                                                    including your personal information;
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">c.</td>
                                                <td><b>“Intellectual Property Rights”</b> means any patent, trade mark, service mark,
                                                    copyright, moral right, right in a design, know-how and any other intellectual or
                                                    industrial property rights, anywhere in the world whether or not registered or
                                                    capable of registration;</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">d.</td>
                                                <td><b>“Privacy Policy”</b> means the Functions & Catering Privacy Policy, accessible from the
                                                    Service;</td>
                                            </tr>
                                            <tr>
                                                <td class="padd_left_15px">e.</td>
                                                <td><b>“Service”</b> means the website found at https://functionsandcatering.com, whether
                                                    through a mobile device, mobile application or computer. </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!--13-->










                </table>

            </div>
        </div>


    </div>
</div>


<style type="text/css">
    .teram_table .hdng2 td {
        vertical-align: top;
        font-size: 20px;
        font-weight: 600;
        color: #777;
        padding-bottom: 10px;
        padding-top: 20px;
    }

    .teram_table td table td {
        vertical-align: top;
    }

    .padd_left_15px {
        padding-right: 30px;
    }

    .width_set-a {
        width: 10px;
    }

    .tabwd90{width: 85% !important;}

    @media (max-width:480px) and (min-width:100px) {
        .padd_left_15px {
            padding-right: 7px !important;
        }
        .teram_table .hdng2 td{font-size:15px;}
    }
</style>