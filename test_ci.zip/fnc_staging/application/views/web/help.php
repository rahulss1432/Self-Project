<section>	
    <div class="container-fluid home_tc_head">		
        <div class="row">
            <img src="<?php echo base_url('assets/images/Help.png') ?>" class="img-responsive bann_img" />			
        </div>
    </div>
</section>


<?php echo $pages_data->content;?>




<style type="text/css">
  .p_tag_ne{
  font-size: 16px;
  color: #777;
}
.padd_left_30 {
  padding-left: 30px;
  font-style: italic;
  font-size: 16px;
  color: #777;
}
.h_tag_help {
  font-size: 17px;
  font-weight: 600;
  color: #777;
}
ul.doted li {
  font-size: 16px;
  color: #777;
  line-height: 30px;
}
</style>
