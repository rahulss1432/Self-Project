<section class="function_vene_page" id="add_user_wish_list">
    <div class="container">
        <div class="row main_row">
            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>
            <!-- Loading Side Menu -->
            <?php $this->load->view('side_menu'); ?>
            <div class="col-sm-8">
                <div class="wish_head">
                    <h4>Favorites</h4>
                </div>
                <div class="main main_margin_106">
                    <div class="row">
                        <?php
                        if (!empty($wish_list_data)) {
                            foreach ($wish_list_data as $key => $value) {
                                ?>
                                <div id="function_<?php echo $key; ?>" class="atribute atribute_102">

                                    <div aria-hidden="true" class="imageContainer_1xligvk">
                                        <div class="container_18q6tiq container_18q6tiq_106">
                                            <div class="children_1szwzht">
                                                <div class="container_e296pg container_e296pg_106">
                                                    <a href="<?php echo site_url('') . (($value->fc_type == 1) ? 'view_venue/' : 'view_catering/') . encrypt_decrypt('encrypt', $value->fc_id) ?>">

                                                        <div class="set_img_b set_img_b_106" style="background-image: url('<?php echo base_url('uploads/fc_images/') . $value->fc_listing_picture?>');">
                                                            <?php $user_wishlist = show_wishlist_icon($wish_list, $value->fc_id, $key); ?>
                                                            <span><?php echo $user_wishlist ?></span>
                                                            <map name="planetmap_<?php echo $key ?>">
                                                                <area onclick="add_to_wishlist('<?php echo encrypt_decrypt('encrypt', $value->fc_id) ?>', '<?php echo $key ?>','fill');" shape="rect" coords="0,0,82,126" alt="Sun" href="javascript:void(0);">
                                                            </map>
                                                        </div>

                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="product-details-sea">
                                        <div id="content_" class="main_text"><?php echo $value->fc_business_name ?></div>
                                        <br>
                                        <span class="function_text"><?php echo ($value->fc_type == 1) ? 'Function' : 'Catering'; ?></span>
                                        <p>
                                            <?php
                                            $string = $value->fc_overview;
                                            if (strlen($string) > 140) {
                                                // truncate string
                                                $stringCut = substr($string, 0, 140);
                                                // make sure it ends in a word so assassinate doesn't become ass...
                                                $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                            }
                                            echo $string;
                                            ?>
                                        </p>
                                    </div>
                                    <div class="reviews_div_107">
                                        <?php echo review_count($value->fc_id); ?>  
                                    </div>                 
                                </div>
                                <?php
                            }
                        }else{?>
						<div class="col-sm-12">
							<div class="review_text review_rating tutorial_list">You have not selected any favorites yet.</div></div>
						<?php } ?>
                    </div><!-- row -->
                </div><!--main-->
            </div><!--col-md-8-->
        </div><!-- row -->
    </div><!-- container -->
</section><!--section-das-->


<script type="text/javascript">
   // $('#add_user_wish_list').css('background-color', '#d8d8d8 !important');
</script>