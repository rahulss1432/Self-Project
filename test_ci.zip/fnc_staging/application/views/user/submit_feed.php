<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/assets/css/nice_select.css"> 

<section class="new_first_page_bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="head_100">
                    Hi <?php
                    if (!empty($user_data[0]->user_firstname)) {
                        echo $user_data[0]->user_firstname;
                    }
                    ?>
                    <span>We value your feedback. Feedback for</span>
                    <span>our venues helps them improve or gives<span>
                        <span>them a rewarding 'keep up the good work'.<span>
                        </span></span></span></span></div>
                    </div>
                </div>
                <div class="row padding_set_re">
                    <div class="col-md-12 div_50_60">
                        <div class="user_img_50">
                            <img src="<?php echo!empty($user_data[0]->user_image) ? $user_data[0]->user_image : base_url() . 'uploads/users/FnC_user_icon.png'; ?>">
                        </div>
                        <div class="user_img_60 box_IMG">
                            <?php
                            $img_link = base_url('uploads/fc_images') . '/' . $fc_details[0]->fc_img_name;
                            if (@getimagesize($img_link)) {

                            } else {
                                $img_link = base_url('assets/images/place_holder.jpg');
                            }
                            ?>
                            <img src="<?php echo $img_link; ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <p class="you_had_set">
                            <span>You had a Function at</span> <?php echo $fc_details[0]->fc_business_name; ?>. <span><a>Tell us what you think</a></span>
                        </p>
                    </div>
                </div>
                <form method="post" id="review_form" action="" onsubmit="return checkStars();">
                    <div class="row a-b">
                        <div class="col-md-12">
                            <div class="a1">
                                <div class="reviews_div_107 big_star">
                                    <!-- Rating Stars Box -->
                                    <div class="rating-stars text-center">
                                        <input type="hidden" id="overall-input" name="overall" value="0">
                                        <ul id="overall" class="stars">
                                            <li class="star" title="Poor" data-value="1">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Fair" data-value="2">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Good" data-value="3">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Excellent" data-value="4">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="WOW!!!" data-value="5">
                                                <i class="fa fa-star"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="first_star_101">
                                    <p class="star_text_1">Overall Experience.</p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="reviews_div_107 big_star">
                                    <!-- Rating Stars Box -->
                                    <div class="rating-stars text-center">
                                        <input type="hidden" id="cleanliness-input" name="cleanliness" value="0">
                                        <ul id="cleanliness" class="stars">
                                            <li class="star" title="Poor" data-value="1">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Fair" data-value="2">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Good" data-value="3">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Excellent" data-value="4">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="WOW!!!" data-value="5">
                                                <i class="fa fa-star"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="first_star_101">
                                    <p class="star_text_1">Cleanliness</p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="reviews_div_107 big_star">
                                    <!-- Rating Stars Box -->
                                    <div class="rating-stars text-center">
                                        <input type="hidden" id="description-input" name="description" value="0">
                                        <ul id="description" class="stars">
                                            <li class="star" title="Poor" data-value="1">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Fair" data-value="2">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Good" data-value="3">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Excellent" data-value="4">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="WOW!!!" data-value="5">
                                                <i class="fa fa-star"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="first_star_101">
                                    <p class="star_text_1">Accuracy of description</p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="reviews_div_107 big_star">
                                    <!-- Rating Stars Box -->
                                    <div class="rating-stars text-center">
                                        <input type="hidden" id="communication-input" name="communication" value="0">
                                        <ul id="communication" class="stars">
                                            <li class="star" title="Poor" data-value="1">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Fair" data-value="2">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Good" data-value="3">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="Excellent" data-value="4">
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li class="star" title="WOW!!!" data-value="5">
                                                <i class="fa fa-star"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="first_star_101">
                                    <p class="star_text_1">Communication</p>
                                </div>
                            </div><!--col-md-3-->

                            <div class="b1">

                       
                             
                                    <div class="pull-left"> 
                                        <ul class="where_div">
                                            <li>Where You :</li>
                                            <li>
                                                <select name="f_location" id="f_location" placeholder="commnets" data-rule-required="true">
                                                 <option value="">Select</option>
                                                 <option  value="1">Organizer</option>
                                                 <option  value="2">Guest</option>
                                             </select>
                                         </li>
                                     </ul>
                                 </div>

                                 <div class="pull-left"> 
                                    <ul class="where_div">
                                     <li>Date Of Attendeding Event :</li>
                                     <li>
                                         <div class="form-group">
                                            <div class='input-group date set_date' id='my_datepicker'>
                                                <input type='text' class="form-control" />
                                                <span class="input-group-addon">
                                                    <span class="glyphicon glyphicon-calendar"></span>
                                                </span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        


                    <!-- <ul class="where_div">
                        <li>Where You :</li>
                        <li>
                            <select name="f_location" id="f_location" placeholder="commnets" data-rule-required="true">
                             <option value="">Select</option>
                             <option  value="1">Organizer</option>
                             <option  value="2">Guest</option>
                         </select>
                     </li>
                     <li>Date Of Attendeding Event :</li>
                     <li>
                         <div class="form-group">
                                <div class='input-group date set_date' id='my_datepicker'>
                                    <input type='text' class="form-control" />
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                     </li>
                    </ul> -->

                   <textarea type="text" rows="4" data-rule-maxlength="300" class="form-control" placeholder="Tell us what you thought of the venue and/ or catering. &#10;Max 300 words." name="notes" id="notes"></textarea>
                   <div class="save_changes_btn">
                    <input type="hidden" name="feedbakc_of" value="<?php echo $fc_id; ?>">
                    <input type="submit" value="Send" class="data" name="Send">
                </div>
            </div><!--col-md-9-->
        </div>
    </div>
</form>
</div>
</section>
<!-- Modal -->
<div id="error_model" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
          <button type="button" class="close close_error" data-dismiss="modal">&times;</button>
          <p id="error_text">Some text in the modal.</p>
      </div>
  </div>
</div>
</div>



<script src="<?php echo base_url()?>/assets/js/jquery.nice-select.min.js"></script>
<script>

    var date_input=$('#my_datepicker'); //our date input has the name "date"
    date_input.datepicker({
        todayHighlight: true,
        autoclose: true,
        format: 'dd-mm-yyyy',
    });

    $(document).ready(function() {
      $('select').niceSelect();
  });

    function checkStars() 
    {
        var status = false;
        var overall = $("#overall-input").val();
        if (overall != '0') {
            status = true;
        }
        var cleanliness = $("#cleanliness-input").val();
        if (cleanliness != '0') {
            status = true;
        }
        var description = $("#description-input").val();
        if (description != '0') {
            status = true;
        }
        var communication = $("#communication-input").val();
        if (communication != '0') {
            status = true;
        }
        var f_location = $("#f_location").val();
        if (f_location != '0') {
            status = true;
        }
        var f_attended_date = $("#f_attended_date").val();
        if (f_attended_date != '0') {
            status = true;
        }

        if (!status) {
            $('#error_text').html('Star rating is required!!');
            $('#error_model').modal('show');
        }

        var notes = $('#notes').val();

        if (notes != '') {
            var val = $('#notes').val().trim();
            var numWords = val.split(' ').length;

            if (numWords >= 300) {
                status = false;
                $('#error_text').html('Maximum 300 words!!');
                $('#error_model').modal('show');
            }
        }

        return status;

    }

    $(document).ready(function () {

        /* 1. Visualizing things on Hover - See next part for action on click */
        $('.stars li').on('mouseover', function () {
            var onStar = parseInt($(this).data('value'), 10); // The star currently mouse on
            //
            // Now highlight all the stars that's not after the current hovered star
            $(this).parent().children('li.star').each(function (e) {
                if (e < onStar) {
                    $(this).addClass('hover');
                } else {
                    $(this).removeClass('hover');
                }
            });

        }).on('mouseout', function () {
            $(this).parent().children('li.star').each(function (e) {
                $(this).removeClass('hover');
            });
        });

        /* 2. Action to perform on click */
        $('.stars li').on('click', function () {
            var onStar = parseInt($(this).data('value'), 10); // The star currently selected
            var stars = $(this).parent().children('li.star');

            for (i = 0; i < stars.length; i++) {
                $(stars[i]).removeClass('selected');
            }

            for (i = 0; i < onStar; i++) {
                $(stars[i]).addClass('selected');
            }

            var p_stars = $(this).parent().attr('id');

            var ratingValue = parseInt($('#' + p_stars + ' li.selected').last().data('value'), 10);

            $("#" + p_stars + "-input").val(ratingValue);
        });

    });
</script>




