<section class="review_page_third_bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
             <div class="head_100">
                   Thank You ,<?php
                   $fc = $fc_details[0]->fc_id;
                    if (!empty($user_data[0]->user_firstname)) {
                       echo $user_data[0]->user_firstname;
                   }
                   $type = get_fc_type($fc_details[0]->fc_id);
                   if ($type == 1) {
                        $site_url = base_url('view_venue/' . encrypt_decrypt('encrypt', $fc_details[0]->fc_id));
                    } else {
                        $site_url = base_url('view_catering/' . encrypt_decrypt('encrypt', $fc_details[0]->fc_id));
                    }
                    ?>  
                   <span>your Enquiry For <?php echo $fc_details[0]->fc_business_name; ?>.</span> <span>Our representative will get back to you shortly."</span>
                 </div>  
                   <?php
                   $type = get_fc_type($fc_details[0]->fc_id);
                   if ($type == 1) {
                        $site_url = base_url('view_venue/' . encrypt_decrypt('encrypt', $fc_details[0]->fc_id));
                    } else {
                        $site_url = base_url('view_catering/' . encrypt_decrypt('encrypt', $fc_details[0]->fc_id));
                    }
                   ?>
                       <div class="row">
                           <div class="col-md-12"><div class="name_venu_100"><?php echo $fc_details[0]->fc_business_name; ?>. <span><?php echo $fc_details[0]->fc_street . ' ' . $fc_details[0]->fc_suburb . ', ' . $fc_details[0]->fc_state; ?></span> 
                              <span class="pull-right button_back_home">
                                 <a href="<?php echo $site_url ?>" class="simple_btn">Back</a>
                                 <a href="<?php echo site_url('web'); ?>" class="simple_btn">Home</a>
                              </span>
                           </div></div>
                       </div>
                       <div class="row">
                           <div class="col-md-12">
                               <div class="set_background_img_100">
                                   <?php
                                   $img_link = base_url('uploads/fc_images') . '/' . $fc_details[0]->fc_img_name;
                                   if (@getimagesize($img_link)) {
                                   } else {
                                       $img_link = base_url('assets/images/place_holder.jpg');
                                   }
                                   ?>
                                   <img src="<?php echo $img_link; ?>">
                               </div>
                           </div>
                       </div>
                   </div>
                   </section>

<script type="text/javascript">
  $('#header_dy').addClass('add-bg_color');
</script>