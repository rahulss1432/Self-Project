<section class="function_vene_page">
    <div class="container">
        <div class="row main_row">

            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>

            <!-- Loading Side Menu -->
            <?php $this->load->view('side_menu'); ?>

            <div class="col-lg-7 col-md-6 col-sm-8">
                <form method="Post" onclick="change_password_validate();" id="change_password" action="<?php echo site_url('user/change_password'); ?>">
                    <div class="col-sm-12 profile_row das-2">
                        <div class="row top_background">
                            <h4>Change Password</h4>
                        </div>
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger alert-dismissable alert_dismiss">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Error!</strong> <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                        <?php if (isset($success)): ?>
                            <div class="alert alert-success alert-dismissable alert_dismiss">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Success!</strong> <?php echo $success; ?>
                            </div>
                        <?php endif; ?>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="col-md-12 margin_set_input">
                                    <label for="last_name">Current password</label>
                                    <input type="password" name="user_old_password" class="form-control user_profile_control" data-msg="Please enter your current password">
                                </div>
                                <div class="col-md-12 margin_set_input">
                                    <label cla>New password</label>
                                    <input type="password" name="user_new_password" id="old_password" class="form-control user_profile_control" maxLength='25'>
                                </div>
                                <div class="col-md-12 margin_set_input">
                                    <label>Confirm password</label>
                                    <input type="password" name="user_confirm_password"  class="form-control user_profile_control" maxLength='25'>
                                </div>

                                <div class="col-md-12 margin_set_input">
                                    <label class='notRequired'>Password Strength</label>
                                    <div class="progress">
                                        <div class="progress-bar " id='progress3' role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="max-width:100%">
                                            <!-- 70% Complete (danger) --><span id='strengthLabel'></span>
                                        </div>
                                    </div>

                                </div>


                            </div><!-- col-sm-12 -->
                        </div><!-- row -->
                    </div><!-- col-sm-12 -->

                    <div class="row">
                        <div class="col-sm-12 save_changes_btn">  
                            <input type="submit" value="Change Password" class="data" name="change_password">
                        </div>
                    </div>
                </form>

            </div><!--col-md-8-->
        </div><!-- row -->
    </div><!-- container -->
</section><!--section-das-->
<script>
    setTimeout(function () {
        $(".alert-dismissable").css("display", "none");
    }, 3000);
</script>

<script>
    $(document).ready(function () {
//        jQuery.validator.addMethod("strongPassword", function (value, element) {
//            if (value != '') {
//                return  !(/^[a-z0-9\\-]+$/i.test(value));
//            } else {
//                return true;
//            }
//        }, "Password must be contain alphanumeric, number and spacial character");

        $('#old_password').strengthMeter('progressBar', {
            container: $('#progress-bar2')
        });


        // $("#old_password").keyup(function(){
        //     var attri = $('#progress-bar2').children('.progress').children('.progress-bar').attr('area-valuenow');
        //     console.log(attri)
        //     $(".stregthLab").text(attri);
        // });


        $('#old_password').keyup(function () {
            var val = $(this).val();
            var len = val.length;

            if (len == 0) {
                $('#progress3').attr('aria-valuenow', 0);
                $('#progress3').css("width", 0 + '%');
            }

            if (len > 0) {
                $('#progress3').removeClass(' progress-bar-warning');
                $('#progress3').removeClass(' progress-bar-success');
                $('#progress3').addClass(' progress-bar-danger');
                $('#strengthLabel').text('Weak');
                $('#progress3').attr('aria-valuenow', 33);
                $('#progress3').css("width", 33 + '%');
            }

            if (!val.match(/^[0-9a-zA-Z]+$/) && len > 6) {

                $('#progress3').removeClass(' progress-bar-danger');
                $('#progress3').removeClass(' progress-bar-success');
                $('#progress3').addClass(' progress-bar-warning');
                $('#strengthLabel').text('Average');
                $('#progress3').attr('aria-valuenow', 66);
                $('#progress3').css("width", 66 + '%');
            }

            if (val.match(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/) && len > 6) {
                $('#progress3').removeClass(' progress-bar-danger');
                $('#progress3').removeClass(' progress-bar-warning');
                $('#progress3').addClass(' progress-bar-success');
                $('#strengthLabel').text('Strong');
                $('#progress3').attr('aria-valuenow', 100);
                $('#progress3').css("width", 100 + '%');
            }

        })
    });
</script>
