<section class="my_vene_page_106">
    <div class="container">
        <div class="row main_row">

            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>
            <!-- Loading Side Menu -->
            <?php $this->load->view('side_menu'); ?>

            <div class="col-sm-8">
                <div class="wish_head">
                    <h4>My Draft</h4>
                </div>
                <div class="main main_margin_106">
                    <div class="row">
                        <?php
                        if (!empty($my_draft)) {

                            foreach ($my_draft as $key => $value) {
                                if ($value->fc_type == 1) {
                                    $edit_url = site_url('add_venue/') . encrypt_decrypt('encrypt', $value->fc_id);
                                    $type = 'Venue';
                                } else {
                                    $edit_url = site_url('add_catering/') . encrypt_decrypt('encrypt', $value->fc_id);
                                    $type = 'Catering';
                                };
                                ?>
                                <div class="atribute atribute_102" id="<?php echo $value->fc_id ?>">
                                    <div  class="imageContainer_1xligvk">
                                        <div class="container_18q6tiq container_18q6tiq_106">
                                            <div class="children_1szwzht">
                                                <div class="container_e296pg container_e296pg_106">
                                                    <?php
                                                    $img_link = base_url('uploads/fc_images') . '/' . $value->fc_listing_picture;
                                                    if (@getimagesize($img_link)) {
                                                        
                                                    } else {
                                                        $img_link = base_url('assets/images/Small_place_holder.jpg');
                                                    }
                                                    ?>
                                                    <a href="javascript:void(0);">
                                                        <div class="set_img_b set_img_b_106" style="background-image: url('<?php echo $img_link; ?>');">
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="product-details-sea">
                                        <div class="main_text">
                                            <a href="javascript:;"><?php echo $value->fc_business_name; ?><br><br></a>
                                        </div>
                                        <span class="function_text"><?php echo $type; ?></span>
                                        <p>
                                            <?php
                                            $string = $value->fc_overview;

                                            if (strlen($string) > 140) {
                                                // truncate string
                                                $stringCut = substr($string, 0, 140);
                                                // make sure it ends in a word so assassinate doesn't become ass...
                                                $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                            }
                                            echo $string;
                                            ?>
                                        </p>
                                    </div>

                                    <div class="clearfix claer_f"></div>
                                    <span  class="my_venu_E_S_D e_S_d_106">
                                        <ul>
                                            <li><a href="<?php echo $edit_url; ?>">Edit & pay</a></li>
                                            <li class="space_li"><a onclick="delete_venue_catering('<?php echo $value->fc_id ?>', 'Are you sure you want to delete this Catering?')" href="javascript:void(0)">Delete <?php echo $type; ?></a></li>
                                        </ul>
                                    </span>
                                </div>
                                <?php
                            }
                        }
                        ?>
                    </div>
                </div>
            </div><!--col-md-8-->
        </div><!-- row -->
    </div><!-- container -->
</section><!--section-das-->
<script type="text/javascript" src="<?php echo base_url('assets/js/custom/function.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/plugins/bootbox/bootbox.js'); ?>"></script>
