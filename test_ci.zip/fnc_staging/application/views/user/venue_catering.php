<?php
$venue_permission_ary = venue_permission();
$cater_permission_ary = cater_permission();
//print_r($cater_permission_ary);
$venu_status = isset($venue_permission_ary->bus_auth_status) ? $venue_permission_ary->bus_auth_status : null;
$cater_status = isset($cater_permission_ary->bus_auth_status) ? $cater_permission_ary->bus_auth_status : null;
$cater_archived = isset($cater_permission_ary->bus_is_deleted) ? $cater_permission_ary->bus_is_deleted : null;
$venu_archived = isset($venue_permission_ary->bus_is_deleted) ? $venue_permission_ary->bus_is_deleted : null;
$venue_type = isset($venue_permission_ary->bus_auth_req) ? $venue_permission_ary->bus_auth_req : null;
$cater_type = isset($cater_permission_ary->bus_auth_req) ? $cater_permission_ary->bus_auth_req : null;

$venue_str = '';
$cater_str = '';
$radioArray[1] = "Venue";
$radioArray[2] = "Catering";
?>
<section class="function_vene_page">
    <div class="container">
        <div class="row main_row">
            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>
            <!-- Loading Side Menu -->
            <?php $this->load->view('side_menu'); ?>
            <div class="col-md-8 col-sm-8">
                <form role="form" method="post" id="myform" role="form" id="frm-login" novalidate="novalidate" name='registration'>
                    <div class="">
                        <div class="col-sm-12 profile_row das-2">
                            <div class="row top_background">
                                <h4>Select below if you will be listing as a venue or caterer.</h4>
                            </div>


                            <?php
                            $erroremsg = '';
                            $erroreType = 0;
                            if ($venu_archived == 1 && $cater_archived == 1) {
                                $erroremsg .= '<li class="already_te" style="width:100%; margin-top:15px;"><span class="business_msg">Note:</span><b> *Your both venue and catering has been archived.Please contact us.<b></li>';
                                $erroreType = 2;
                            } elseif ($venu_status == 2 && $cater_status == 2) {
                                $erroremsg .= '<li class="already_te" style="width:100%; margin-top:15px;"><span class="business_msg">Note:</span><b> *Your both venue and catering request has been denied.Please contact us.<b></li>';
                                $erroreType = 2;
                            } elseif ($venu_status == 1 && $cater_status == 1) {
                                $erroremsg .= '<li class="already_te" style="width:100%; margin-top:15px;"><span class="business_msg">Note:</span><b> *Your both venue and catering request has been approved.<b></li>';
                                $erroreType = 2;
                                redirect(site_url("add_venue"), 'location');
                            } elseif ($venu_status == '0' && $cater_status == '0') {
                                $erroremsg .= '<li class="already_te" style="width:100%; margin-top:15px;"><span class="business_msg">Note:</span><b> *You have already applied to list your venue, catering and should receive admin approval shortly. Please check your inbox.<b></li>';
                                $erroreType = 2;
                            } else {
                                if ($cater_status == '0' && $cater_status != null) {
                                    $erroremsg .= '<li class="already_te" style="width:100%; margin-top:15px;"><span class="business_msg">Note:</span><b> *You have already applied to list your catering and should receive admin approval shortly. Please check your inbox.<b></li>';
                                }if ($cater_status == 2 && $cater_status != null) {
                                    $erroremsg .= '<li class="already_te" style="width:100%; margin-top:15px;"><span class="business_msg">Note:</span><b> *Your Catering request has been denied. Please contact us.<b></li>';
                                }
                                if ($venu_status == '0' && $venu_status != null) {
                                    $erroremsg .= '<li class="already_te" style="width:100%; margin-top:15px;"><span class="business_msg">Note:</span><b> *You have already applied to list your venue and should receive admin approval shortly. Please check your inbox</b>.</li>';
                                }if ($venu_status == 2 && $venu_status != null) {
                                    $erroremsg .= '<li class="already_te" style="width:100%; margin-top:15px;"><span class="business_msg">Note:</span><b> *Your Venue request has been denied. Please contact us</b>.</li>';
                                }
                            }
                            ?>


                            <?php
                            if ($erroreType == 2) {
                                echo $erroremsg;
                            } elseif ($venu_status != null && $cater_status != null) {

                                echo '<ul class="padding_0"><li class="already_te"><span class="business_msg">Note: </span><b> * You have already request for Catering.Please wait for admin approval.</b></li></ul>';
                            } else {
                                ?>


                                <div class="type_tow">

                                    <ul>
                                        <?php echo $erroremsg; ?>
                                        <div class="clearfix"></div>
                                    </ul>
                                    <br/>

                                    <ul>


                                        <li><label for="last_name" class="type_height">Type</label></li>										
                                        <?php foreach ($radioArray as $key => $value) { ?>
                                            <?php if ($cater_type == 2 && $key == 2) { ?>

                                            <?php } elseif ($venue_type == 1 && $key == 1) { ?>

                                            <?php } else { ?>
                                                <li class="back_to_new"> 
                                                    <?php echo $value; ?>
                                                    <label class="regular-checkbox pull-right">
                                                        <input type="radio" name="bus_auth_req" data-msg-required='Select Type' class="radio1 error_down" value="<?php echo $key; ?>"> 
                                                        <small></small>
                                                    </label>                                           
                                                </li>											
                                            <?php } ?>
                                        <?php } ?>
                                        <div class="clearfix"></div>
                                    </ul>

                                    <div class="col-sm-12">
                                        <label for="bus_auth_req" class="error CheckieError" style=""></label>
                                    </div>
                                </div>
                                <div class="textarea_set">
                                    <label style="width: 100%" class="notRequired">Message</label>
                                    <textarea name="bus_auth_notes" cols="20" rows="5" id="bus_auth_notes" placeholder="To help our admin authorise your listing, please include any additional information about you and your business." class="form-control"></textarea>
                                </div>
                                <div class="save_changes_btn">
                                    <input type="submit" value="Send request" class="data">
                                </div>

                            <?php } ?>
                        </div>
                    </div>
                </form>
            </div>
        </div> <!-- row -->
    </div>  <!-- container -->
</section>
<!--section-das-->
<div class="MyModal23" id="thankyouModal">
    <div class="MyModal23_dialog">

        <span class="mdl_close">X</span>
        <h3>Thanks for your request! Please check your email.</h3>
<!--        <p>Thank you for showing interest in joining the Functions & Catering platform. You will receive a confirmation email shortly. Once received you will be able to get started setting up your <span class="select_text"></span>.</p>-->
        <p>Thank you for showing interest in joining the Functions & Catering platform. Your request to activate <span class="select_text"></span> for your user profile is approved. You can get started by clicking "<span class="select_text1"></span>" in the side menu.</p>
        <button class="btn cmn_btn1 gt_it_btn">OK, got it!</button>
    </div>
</div>
<script type="text/javascript">
    $(".radio1").click(function () {
        $(this).attr("checked");
    });

    $(function () {
        $("form[name='registration']").validate({
            rules: {
                bus_auth_req: {
                    required: true,
                },
                /*bus_auth_notes: {
                 required: true,
                 },*/
            },
            messages: {
                bus_auth_req: {
                    required: "Enter your type"
                },
                /*bus_auth_notes: {
                 required: "Please Enter a message"
                 },*/
            },
            submitHandler: function (form) {

                request_submit();
                //form.submit();
            }
        });
    });
    function request_submit() {
        //alert();
        add_loader();
        var url = baseURL + 'user/venue_catering_request';
        var form_data = $('#myform').serialize();

        var selected = $('.radio1:checked').val();
        console.log(selected);
        var text = '';
        var text1 = '';
        if (selected == 1) {
            var text = 'venues';
            var text1 = 'Add venue';
        } else {
            var text = 'catering';
            var text1 = 'Add catering';
        }

        $.ajax({
            type: "POST",
            url: url,
            dataType: 'json',
            data: form_data, //get form values
            success: function (response) {
                console.log(response);
                if (response.status) {
                    $.unblockUI();
                    console.log("success=" + response);
                    $('.MyModal23').addClass('show');
                    $('.radio1').removeAttr('checked');
                    setTimeout(function () {

                        $('.select_text').text(text);
                        $('.select_text1').text(text1);
                        $('.MyModal23').addClass('show');
                    }, 3500);
                } else {
                    $.unblockUI();
                    console.log("error=" + response);
                }
            },
            error: function (XHR, status, response) {
                console.log(response);
            }
        });


    }


    $('.mdl_close').click(function () {
        $('.MyModal23').removeClass('show');
        window.location.href = baseURL + 'dashboard';
    });

    $('.gt_it_btn').click(function () {
        window.location.href = baseURL + 'dashboard';
    });
</script>
<style type="text/css">
    .padding_0{
        padding: 0px !important;
        margin: 0px !important;
    }
    .navbar-default.sidebar {
        height: 47vw !important;
    }
    body {
        background: #fff !important;
    }
    @media(max-width: 767px) {
        .navbar-default.sidebar {
            height: 100% !important;
        }
    }
    .textarea_set textarea {
        border: 1px solid #b2e3fb !important;
        padding: 10px !important;
    }
    .type_tow ul li{
        float:left;
        list-style: none;
        margin-right: 15px !important;
    }
    .type_tow ul li .error {
        position: absolute !important;
        left: 0 !important;
        margin-top: 20px;
        margin-left: 13px;
    }
    .type_tow ul{
        padding-left: 0px !important;
    }
    .type_tow .regular-checkbox {
        width: 20px !important;
        height: 20px !important;
        border-radius: 24px !important;
        margin: 0px 5px;
    }
    .type_tow .regular-checkbox input:checked~small:after {
        color: #46b8da;
        font-size: 18px;
        margin-top: 1px;
        margin-left: 2px;
        content: "";
        text-align: center;
        width: 14px !important;
    }
    .type_01{
        float: left;
        padding-right: 15px;
    }
    .type_height{
        line-height: 0px !important;
    }
    .type_tow{
        width: 100%;
        display: table;
        margin-bottom: 30px;
    }
    .already_te{
        color: #07adee;
        width:100%; margin-top:15px; list-style:none;
    }
    .business_msg{
        color:#000;font-weight: 600; font-size: 16px; color:#6e6e71;
    }
</style>