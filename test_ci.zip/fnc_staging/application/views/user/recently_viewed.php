<section class="function_vene_page" id="add_recently_viewed">
    <div class="container">
        <div class="row main_row">
            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>
            <!-- Loading Side Menu -->
            <?php $this->load->view('side_menu'); ?>
            <div class="col-sm-8">
                <div class="wish_head">
                    <h4>Recently viewed</h4>
                </div>
                <div class="main main_margin_106">
                    <div class="row">
                        <?php
                        if (!empty($viewed)) {
                            foreach ($viewed as $key => $view) {
                                ?>
                                <div class="atribute atribute_102">
                                    <div aria-hidden="true" class="imageContainer_1xligvk">
                                        <div class="container_18q6tiq container_18q6tiq_106">
                                            <div class="children_1szwzht">
                                                <div class="container_e296pg container_e296pg_106">
                                                    <a href="<?php echo site_url() . (($view->fc_type == 1) ? 'view_venue/' : 'view_catering/') . encrypt_decrypt('encrypt', $view->fc_id) ?>">
                                                        <?php
                                                        $img_link = base_url('uploads/fc_images') . '/' . $view->fc_listing_picture;
                                                        if (@getimagesize($img_link)) {
                                                            
                                                        } else {
                                                            $img_link = base_url('assets/images/place_holder.jpg');
                                                        }
                                                        ?>
                                                        <div class="set_img_b set_img_b_106" style="background-image: url('<?php echo $img_link ?>');">
                                                            <?php $user_wishlist = show_wishlist_icon($wish_list, $view->fc_id, $key); ?>
                                                            <span><?php echo $user_wishlist ?></span>
                                                            <map name="planetmap_<?php echo $key ?>">
                                                                <area onclick="add_to_wishlist('<?php echo encrypt_decrypt('encrypt', $view->fc_id) ?>', '<?php echo $key ?>', 'blank');" shape="rect" coords="0,0,82,126" alt="Sun" href="javascript:void(0);">
                                                            </map>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="product-details-sea">
                                        <div id="content_" class="main_text"><?php echo $view->fc_business_name ?></div>
                                        <br>
                                        <span class="function_text"><?php echo ($view->fc_type == 1) ? 'Function' : 'Catering'; ?></span>
                                        <p>
                                            <?php
                                            $string = $view->fc_overview;
                                            if (strlen($string) > 140) {
                                                // truncate string
                                                $stringCut = substr($string, 0, 140);
                                                // make sure it ends in a word so assassinate doesn't become ass...
                                                $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                            }
                                            echo $string;
                                            ?>
                                        </p>
                                    </div>
                                    <div class="reviews_div_107">
                                        <?php echo review_count($view->fc_id); ?>
                                    </div>
                                </div>
                                <?php
                            }
                        }
                        ?>
                    </div><!-- row -->
                </div><!--main-->
            </div><!--col-md-8-->
        </div><!-- row -->
    </div><!-- container -->

</section><!--section-das-->
<script type="text/javascript">
    //$('#add_recently_viewed').css('background-color', '#d8d8d8 !important');
</script>