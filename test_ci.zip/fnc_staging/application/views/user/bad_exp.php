<section class="review_page_third_bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="head_100">
                    Hi <?php
                    if (!empty($user_data[0]->user_firstname)) {
                       echo $user_data[0]->user_firstname;
                   }
                   $type = get_fc_type($fc_details[0]->fc_id);
                   
                  
                    if ($type == 1) {
                        $site_url = base_url('view_venue/' . encrypt_decrypt('encrypt', $fc_details[0]->fc_id));
                    } else {
                        $site_url = base_url('view_catering/' . encrypt_decrypt('encrypt', $fc_details[0]->fc_id));
                    }
                   ?>
                   <span>Thanks for submitting you review for <a href="<?php echo site_url('web/single_venue') . '/' . $fc; ?>"><?php echo $fc_details[0]->fc_business_name; ?></a></span>
                   <span>We're so sorry that you experience was not a great one.<span></span></span>
               </div>

               <p class="bottom_text_100">Your review has now been sent straight to the venue. <?php echo $fc_details[0]->fc_business_name; ?> will have a chance to respond to you to find out why things were not up to scratch. We encourage open communication between parties and hope there can be a resolution before a review is posted.</p>
               <p class="bottom_text_100">
                We will be in touch as soon as we hear from <?php echo $fc_details[0]->fc_business_name; ?> <br>The F&C team.
            </p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12"><div class="name_venu_100"><?php echo $fc_details[0]->fc_business_name; ?>. <span><?php echo $fc_details[0]->fc_street . ' ' . $fc_details[0]->fc_suburb . ', ' . $fc_details[0]->fc_state; ?></span> 
           <span class="pull-right button_back_home">
              <a href="<?php echo $site_url ?>" class="simple_btn">Back to Venue</a>
            <a href="<?php echo site_url('web'); ?>" class="simple_btn">Home</a>
           </span>
        </div></div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="set_background_img_100">
                <?php
                $img_link = base_url('uploads/fc_images') . '/' . $fc_details[0]->fc_img_name;
                if (@getimagesize($img_link)) {
                } else {
                    $img_link = base_url('assets/images/place_holder.jpg');
                }
                ?>
                <img src="<?php echo $img_link; ?>">
            </div>
        </div>
    </div>
</div>
</section>

<script type="text/javascript">
  $('#header_dy').addClass('add-bg_color');
</script>