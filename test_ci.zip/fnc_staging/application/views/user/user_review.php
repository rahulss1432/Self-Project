<?php
if ($fc_type == 2) {
    $type = 'catering';
    $request_url = base_url('user/my_catering_reviews');
} elseif ($fc_type == 1) {
    $type = 'venue';
    $request_url = base_url('user/my_venue_reviews');
} else {
    $type = '';
    $request_url = base_url('user/my_reviews');
}
?>

<section class="function_vene_page" id="my_review">
    <div class="container">
        <div class="row main_row">
            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>
            <?php $this->load->view('side_menu'); ?>
            <div class="col-sm-8">
                <div class="wish_head">
                    <h4>My <?php echo $type; ?> reviews</h4>
                </div>
                <div class="review_text review_rating tutorial_list">
                    <?php
                    if (!empty($reviews)) {
                        $sum = 0;
                        foreach ($reviews as $review) {
                            if ($review->fc_type == 1) {
                                $fc_url = base_url('view_venue/') . encrypt_decrypt('encrypt', $review->fc_id);
                            } else {
                                $fc_url = base_url('view_catering/') . encrypt_decrypt('encrypt', $review->fc_id);
                            }

                            $postID = $review->f_id;
                            $user_image = $review->user_image;
                            if (!empty($user_image))
                                $img_url = $user_image;
                            else
                                $img_url = base_url() . 'uploads/users/FnC_user_icon.png';

                            $sum = (int) $review->f_rating_overall + (int) $review->f_rating_cleanliness + (int) $review->f_rating_accuracy + (int) $review->f_rating_comm;
                            $avg = $sum / 4;
                            ?>
                            <div class="col-lg-12 col-sm-12 col-xs-12 user-rating-detail u_r_d-104">
                                <div class="col-sm-3 col-md-2 col-xs-3">
                                    <img class="img_rewiew_nee" src="<?php echo $img_url ?>">
                                </div>
                                <div class="col-sm-9 col-md-10 col-xs-9">
                                    <div class="comm_user-desc">
                                        <span class="comm_author_name"><?php echo ucfirst($review->user_firstname . ' ' . $review->user_lastname) ?>.</span>
                                        <span class="comm_author_name"><a href="<?php echo $fc_url; ?>" ><?php echo ucfirst($review->fc_business_name); ?></a></span>
                                        <div class="reviews_div_107">
                                            <?php echo generate_review_html($avg); ?>
                                            <span class="no-reviews"><?php echo date('F Y', strtotime($review->f_created_on)) ?></span>  
                                        </div>
                                        <?php echo $review->f_text ?>
                                    </div>

                                </div>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="show_more_main" id="show_more_main<?php echo $postID; ?>">
                            <span id="<?php echo $postID; ?>" class="show_more design_class" title="Load more reviews">Show more</span>
                            <span class="loding" style="display: none;"><span class="loding_txt">Loading....</span></span>
                        </div>
                        <?php
                    } else{?>
						<div class="col-sm-12">
							<div class="review_text review_rating tutorial_list">You currently have no reviews.</div></div>
						<?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    //$('#my_review').css('background-color', '#d8d8d8 !important');

    $(document).ready(function () {
        $(document).on('click', '.show_more', function () {
            var ID = $(this).attr('id');
            $('.show_more').hide();
            $('.loding').show();
            $.ajax({
                type: 'POST',
                url: '<?php echo $request_url; ?>',
                data: {id: ID, is_load: 1},
                success: function (html) {
                    $('#show_more_main' + ID).remove();
                    $('.tutorial_list').append(html);
                }
            });
        });
    });
</script>




