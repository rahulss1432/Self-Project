<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<section class="new_first_page_bg white-bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="head_100">
                    Hi <?php if(!empty($user_data[0]->user_firstname)){ echo $user_data[0]->user_firstname; } ?>
                    <span>We value your feedback. Feedback for</span>
                    <span>our venues helps them improve or gives<span>
                            <span>them a rewarding 'pat on the back'.<span>
                                </span></span></span></span></div>
            </div>
        </div>
        <div class="row padding_set_re">
            <div class="col-md-12 div_50_60">
                <div class="user_img_50">
                    <img src="<?php echo !empty($user_data[0]->user_image) ? $user_data[0]->user_image : base_url() . 'uploads/users/FnC_user_icon.png'; ?>">
                </div>
                <div class="user_img_60">
                    <?php
                    $img_link = base_url('uploads/fc_images') . '/' . $fc_details[0]->fc_img_name;
                    if (@getimagesize($img_link)) {

                    } else {
                        $img_link = base_url('assets/images/place_holder.jpg');
                    }
                    ?>
                    <img src="<?php echo $img_link; ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <p class="you_had_set">
                    <span>You had a Function at</span> <?php echo $fc_details[0]->fc_business_name; ?>. <span><a href="javascript:;">Tell us what you think</a></span>
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <p class="write_a_review_text">
                    Write a review to go into the draw to win a
                    <span>wine and food hamper to the value of $400.</span>
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <ul class="button_100">
                    <li><a href="<?php echo site_url('user/submit_feed').'/'.$fc_id; ?>">Leave a review</a></li> 
                    <li><a id="send_to_friend" href="javascript:;">Send to a friend</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- Modal -->
<?php 
if($fc_details[0]->fc_type == 1){
       $current_url = base_url('view_venue/').$fc_id;
}else{
      $current_url = base_url('view_catering/').$fc_id;
} 

?>

<!-- Modal -->
<div id="send_to_model" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Send to a friend</h4>
            </div>
            <div class="modal-body">
                <form id="send_frnd">
                    <input type="hidden" name="venue_url" id="venue_url" value="<?php echo $current_url; ?>">
                    <input type="hidden" name="venue_id" id="venue_id_friend" value="">
                    <div class="form-group">
                        <label for="email">Friend Name:</label>
                        <input type="text" data-rule-required="true" name="friend_name"  class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email"  name="email" data-rule-required="true" class="form-control" id="email">
                    </div>
                    <div class="form-group">
                        <label for="pwd">Message:</label>
                        <textarea name="massage"  id="massage" name="massage" data-rule-required="true" value="" class="form-control" id="pwd"></textarea>
                    </div>
                    <label class="lbl_class g-recaptcha" id="recaptcha" data-sitekey="6LferDsUAAAAAI1frwpcod-3sG6S5Tv3bFdkFbYE" ></label>
                    <span id="captcha_error"></span>
                    <button type="submit" id="submit_friend" class="btn btn-default">Send to a friend</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
   $("#send_to_friend").click(function (e) {
        e.preventDefault();
        var venue_id = $('#venue_id').val();
        $("#send_frnd")[0].reset();
        $('#send_to_model').modal('show');
        $('#venue_id').val('');
        $('#venue_id_friend').val(venue_id);
        var massage = 'Hello, I think this page is interesting';
        $('#massage').val(massage);
    });

     $("#submit_friend").click(function (e) {
                                    $("#captcha_error").html('');
                                    e.preventDefault();
                                    if ($("#send_frnd").valid()) {
                                        var form_Element = document.getElementById("send_frnd");
                                        var query_Data = new FormData(form_Element);

                                        var $captcha = $('#recaptcha'),
                                                response = grecaptcha.getResponse();
                                        var is_submit = 0;

                                        if (response.length === 0)
                                        {
                                            is_submit = 0;
                                            $("#captcha_error").html('Please check Captcha')
                                        } else
                                        {
                                            is_submit = 1;
                                        }

                                        if (is_submit == 1)
                                        {
                                            $.ajax({
                                                type: "POST",
                                                url: base_url + 'web/send_to_friend',
                                                data: query_Data,
                                                contentType: false,
                                                cache: false,
                                                processData: false,
                                                success: function (response)
                                                {
                                                    if (response == 'need_login') {
                                                        $.notify("You need to login first", {type: "info"});
                                                    }
                                                    
                                                    if (response == 'success') {
                                                          $("#send_to_model .close").click();
                                                        $("#enq_form")[0].reset();
                                                        $.notify("Send successfully", {type: "success"});
                                                    } else {
                                                        $("#send_to_model .close").click();
                                                    }
                                                },
                                                async: false
                                            });
                                        }
                                    }
                                    ;
                                });

</script>