<section class="review_page_third_bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="head_100">
                    Hi <?php
                    if (!empty($user_data[0]->user_firstname)) {
                        echo $user_data[0]->user_firstname;
                    }
                    ?>
                    <span>Thanks for submitting you review for <a href="<?php echo site_url('view_venue') . '/' . $fc; ?>"><?php echo $fc_details[0]->fc_business_name; ?></a></span>
                </div>
                <p class="bottom_text_100">We're wrapped you had a great experience and<span> can't wait to help you plan your next event! </span></p>
                <p class="bottom_text_100">
                    The F&C team 
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="name_venu_100"><?php echo $fc_details[0]->fc_business_name; ?>. <span><?php echo $fc_details[0]->fc_street . ' ' . $fc_details[0]->fc_suburb . ', ' . $fc_details[0]->fc_city . ', ' . $fc_details[0]->fc_state; ?></span> <a href="<?php echo site_url('web'); ?>" class="venue_right_100">Venue.</a></div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="set_background_img_100">
                    <?php
                    $img_link = base_url('uploads/fc_images') . '/' . $fc_details[0]->fc_img_name;
                    if (@getimagesize($img_link)) {
                        
                    } else {
                        $img_link = base_url('assets/images/place_holder.jpg');
                    }
                    ?>
                    <img src="<?php echo $img_link; ?>">
                </div>
            </div>
        </div>
    </div>
</section>