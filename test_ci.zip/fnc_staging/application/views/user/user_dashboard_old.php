<?php
$venue_permission_ary = venue_permission();
$cater_permission_ary = cater_permission();

$venu_status = isset($venue_permission_ary->bus_auth_status) ? $venue_permission_ary->bus_auth_status : '';
$cater_status = isset($cater_permission_ary->bus_auth_status) ? $cater_permission_ary->bus_auth_status : '';

$venue_bus_auth_req = isset($venue_permission_ary->bus_auth_req) ? $venue_permission_ary->bus_auth_req : '';
$cater_bus_auth_req = isset($cater_permission_ary->bus_auth_req) ? $cater_permission_ary->bus_auth_req : '';
?>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script src="<?php echo base_url('assets/js/custom/user_profile.js?' . rand()); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.ezdz.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/crope_images.js'); ?>"></script>
<section class="function_vene_page" id="user_dashboard_new">
    <div class="container">
        <div class="row main_row">
            <?php
            if ($user_data) {
                $user_data = (array) $user_data[0];

                $uri = $this->uri->segment(1);
                ?>
                <div class="col-sm-12">
                    <div class="col-sm-12 dashboard_row">
                        <h4>Hi <span><?php echo ucfirst($user_data['user_firstname']); ?></span>, Welcome to your Dashboard</h4>
                    </div>
                </div>
                <!-- load side menu -->
                <?php $this->load->view('side_menu', $user_data); ?>
                <div class="col-md-9 col-sm-8">
                    <div class="tabs_sec1">
                        <ul class="bs_tabs">
                            <li  class="<?php
                            if (!empty($uri)) {
                                if ($uri == 'dashboard') {
                                    echo 'active';
                                }
                            }
                            ?>" ><a href="<?php echo site_url('dashboard'); ?>">My Profile</a></li>
                                 <?php if (!empty($venu_status) && $venue_bus_auth_req == 1) { ?>
                                <li  class=" <?php
                                if (!empty($uri)) {
                                    if ($uri == 'my_venues') {
                                        echo 'active';
                                    }
                                }
                                ?>" ><a href="<?php echo site_url('my_venues'); ?>">My Venues</a></li>        
                                     <?php
                                 }
                                 if (!empty($cater_status) && $cater_bus_auth_req == 2) {
                                     ?>
                                <li class="<?php
                                if (!empty($uri)) {
                                    if ($uri == 'my_catering') {
                                        echo 'active';
                                    }
                                }
                                ?>"><a href="<?php echo site_url('my_catering'); ?>" >My Catering</a></li>
                                <?php } ?>         
                        </ul>
                    </div>
                    <!-- <div class="clearfix"></div> -->
                    <div class="fr_bor">
                        <form method="Post" id="save_profile" enctype="multipart/form-data" action="<?php echo site_url('User/user_dashboard'); ?>">
                            <div class="col-sm-12 profile_row das-1 hdng_1">
                                <div class="row top_background">
                                    <h4>Profile Image</h4>
                                </div>
                                <div class="row">

                                    <?php
                                    if (!empty($this->session->userdata('user_image'))) {
                                        $img_url = $this->session->userdata('user_image');
                                        $removeImg = ""; //"removeImage(1, '" . encrypt_decrypt('encrypt', $draft_venue->fc_id) . "', 1, 55555)";
                                        $add_class = 'picture_added';
                                        $remove_hide = '';
                                        $upload_hide = 'display:none';
                                    } else {
                                        $img_url = base_url() . 'uploads/users/FnC_user_icon.png';
                                        $removeImg = "removeImage(1, '0', 2, 55555 )";
                                        $add_class = '';
                                        $remove_hide = 'display:none';
                                        $upload_hide = '';
                                    }
                                    //$img_url=($this->session->userdata('user_image')) ? $user_data['user_image']: base_url().'uploads/users/FnC_user_icon.png';
                                    ?>
                                    <div class="user-image-holder_root">
                                        <div class="ulpading_img_size_3 listing_picture_thumb userImgCirc <?php echo $add_class; ?> ">
                                            <img id="show_image_11111" class="dropzone" img-id="11111" src="<?php echo $img_url; ?>" style="<?php echo ($img_url == '') ? 'display: none;' : 'display:block;' ?> opacity: 1;">
                                            <input onclick="this.value = null;" type="file" name="userfile" data-id="11111" class="file-selector fc_listing_picture image_selector" id="image_selector_11111" accept="image/*">
                                            <input type="hidden" class="fc_listing_picture" name="dimesion_image_11111" id="dimesion_image_11111" value="">
                                            <input type="hidden" name="fc_image_11111" id="fc_image_11111" value="">
                                        </div>

                                        <div class="clearfix"></div>
                                    </div><!-- col-sm-6 ends -->
                                    <!--<div id="user-image-holder" class="user-image-holder_root">
                                        <div class="userImgCirc">
                                        <img id="user_img" class="img-responsive" src="<?php echo ($this->session->userdata('user_image')) ? $user_data['user_image'] : base_url() . 'uploads/users/FnC_user_icon.png'; ?>">
                                        </div>
                                    </div>
                                    <p>Upload your profile image or company logo (not mandatory).</p>
                                    <h6>Kindly upload image of the same ratio for better result (e.g. 125 X 125)</h6>
                                    <!--<div class="fileUpload btn dashboard_upload text-center">
                                        <span>Upload image</span>
                                        <input type="file" id="fileUpload1" name="userfile" class="upload" style="visibility:hidden;" img-id="11111">
                                    </div> -->
                                    <p>Upload your profile image or company logo (not mandatory).</p>
                                    <h6>Please ensure profile image is in the same ratio (eg. 125x125 px).</h6>
                                    <div class="fileUpload btn dashboard_upload text-center" id="fileUpload1" img-id="11111">
                                        <span>Upload image</span>
                                    </div>

                                </div>
                            </div>
                            <div class="col-sm-12 profile_row das-2">
                                <div class="row top_background">
                                    <h4>Profile Details</h4>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6 left_padding_remove_107">
                                        <div class="col-md-12 margin_set_input" style="display:none;">
                                            <label>Business name</label>
                                            <input type="text" data-rule-required="true" data-msg-required="This field is Required" class="form-control user_profile_control" name="user_business_name" value="<?php echo $user_data['user_business_name']; ?>" >
                                        </div>
                                        <div class="col-md-12 margin_set_input" style="display:none;">
                                            <label for="last_name">ABN</label>
                                            <input type="text" class="form-control user_profile_control" data-rule-required="true" data-msg-required="This field is Required" data-rule-abn_number="true" data-msg-abn_number="ABN must be 11 digit" name="user_abn" value="<?php echo $user_data['user_abn']; ?>" >
                                        </div>
                                        <div class="col-md-12 margin_set_input">
                                            <label>First name</label>
                                            <input type="text" class="form-control user_profile_control character_allow_only" data-rule-required="true" data-msg-required="Please enter your first name" name="user_firstname" value="<?php echo $user_data['user_firstname']; ?>" 

                                                   >
                                        </div>
                                        <div class="col-md-12 margin_set_input">
                                            <label>Last name</label>
                                            <input type="text" data-rule-required="true" data-msg-required="Please enter your last name" class="form-control user_profile_control character_allow_only" name="user_lastname" value="<?php echo $user_data['user_lastname']; ?>"  >
                                        </div>
                                        <div class="col-md-12 margin_set_input">
                                            <label>Phone number </label>
                                            <input type="text" data-rule-required="true" data-rule-number="true" data-rule-phone_number="true" data-msg-required="Please enter your phone number" class="form-control user_profile_control phone_no" name="user_phone_no" value="<?php echo $user_data['user_phone_no']; ?>"  maxLength='8' >
                                        </div>
                                        <div class="col-md-12 margin_set_input">
                                            <label>Email</label>
                                            <input type="email" class="form-control user_profile_control" name="user_email" value="<?php echo $user_data['user_email']; ?>" readonly="readonly">
                                        </div>
                                    </div> <!-- col-sm-12 -->
                                    <div class="col-sm-6 right_padding_remove_107">
                                        <div class="col-md-12 margin_set_input">
                                            <label for="City" class="notRequired">Address</label>
                                            <input type="text" class="form-control user_profile_control" name="user_address" id="user_address" value="<?php echo $user_data['user_address']; ?>" >
                                        </div>
                                        <div class="col-md-12 margin_set_input" >
                                            <label for="City" class="notRequired">Suburb</label>
                                            <input type="text" class="form-control user_profile_control" name="user_suburb" id="user_suburb" value="<?php echo $user_data['user_suburb']; ?>" >
                                        </div>
                                        <div class="col-md-12 margin_set_input">
                                            <label for="Country" class="notRequired">City</label>
                                            <input type="text" class="form-control user_profile_control" name="user_city" id="user_city" value="<?php echo $user_data['user_city']; ?>" >
                                        </div>


                                        <div class="col-md-12 margin_set_input">
                                            <label for="postal_code" class="notRequired">State</label>
                                            <input type="text" class="form-control user_profile_control" name="user_state" id="user_state" value="<?php echo $user_data['user_state']; ?>" >
                                        </div>
                                        <div class="col-md-12 margin_set_input">
                                            <label for="phone_no">Postcode</label>
                                            <input maxLength='6' required  type="text" data-rule-required="true" data-msg-required="Please enter your postcode" data-rule-number="true" class="form-control user_profile_control" data-rule-postcodecheck='true' id="user_postcode" name="user_postcode" value="<?php if (!empty($user_data['user_postcode'])) echo $user_data['user_postcode']; ?>" required="">
                                        </div>

                                        <div class="col-sm-12 margin_set_input no-pad ">							
                                            <label for="post_city_error" class="error CheckieError" style="">Entered values for City, State & Postcode do not match</label>
                                        </div>

                                    </div><!-- col-sm-12 -->

                                </div><!-- row -->
                            </div><!-- col-sm-12 -->
                        <?php } ?>
                        <div class="row">
                            <div class="col-sm-12 save_changes_btn">
                                <input type="submit" value="Update Profile" class="data" name="save_profile" id="btn_save_profile">
                            </div>
                        </div>
                    </form>
                </div> <!--col-md-8-->
            </div><!-- row -->
        </div> <!-- container -->
</section><!--section-das-->
<?php $this->load->view('models/image_cropping'); ?>    
<style>
    .userImgCirc {
        width: 125px !important;
        height: 125px !important;
        border-radius: 50%;
        overflow: hidden !important;
        border: solid 1px #cecbcb !important;
    }
    .cropper-crop-box, .cropper-view-box {
        /*border-radius: 50%;*/
    }
    .cropper-view-box,
    .cropper-face {
        border-radius: 50%;
    }
</style>