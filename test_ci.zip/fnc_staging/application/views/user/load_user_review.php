<?php
$current_uri = $this->uri->segment(2);
$class = '';
if ($current_uri != 'my_reviews' && $current_uri != 'my_catering_reviews' && $current_uri != 'my_venue_reviews') {
    $class = 'design_single';
}

if (!empty($reviews)) {
    $sum = 0;
    foreach ($reviews as $review) {
        if ($review->fc_type == 1) {
            $fc_url = base_url('view_venue/') . encrypt_decrypt('encrypt', $review->fc_id);
        } else {
            $fc_url = base_url('view_catering/') . encrypt_decrypt('encrypt', $review->fc_id);
        }

        $postID = $review->f_id;
        $user_image = $review->user_image;
        if (!empty($user_image))
            $img_url = $user_image;
        else
            $img_url = base_url() . 'uploads/users/FnC_user_icon.png';

        $sum = (int) $review->f_rating_overall + (int) $review->f_rating_cleanliness + (int) $review->f_rating_accuracy + (int) $review->f_rating_comm;
        $avg = $sum / 4;
        ?>
        <div class="col-lg-12 col-sm-12 col-xs-12 user-rating-detail u_r_d-104">
            <div class="col-sm-3 col-md-2 col-xs-3">
                <img class="img_rewiew_nee" src="<?php echo $img_url ?>">
            </div>
            <div class="col-sm-9 col-md-10 col-xs-9">
                <div class="comm_user-desc">
                    <span class="comm_author_name"><?php echo ucfirst($review->user_firstname . ' ' . $review->user_lastname) ?>.</span>
                    <span class="comm_author_name"><a href="<?php echo $fc_url; ?>" ><?php echo ucfirst($review->fc_business_name); ?></a></span>
                                        
                </div>
                <div class="reviews_div_107">
                    <ul>
                        <?php
                        if ($avg == 0) {
                            echo "<li></li><li></li><li></li><li></li><li></li>";
                        } else if (($avg >= 0.1) && ($avg <= 0.5)) {
                            echo "<li class='half_star'></li><li></li><li></li><li></li>";
                        } else if (($avg > 0.5) && ($avg <= 1)) {
                            echo "<li class='full_star'></li><li></li><li></li><li></li>";
                        } else if (($avg > 1) && ($avg <= 1.5)) {
                            echo "<li class='full_star'></li><li class='half_star'></li><li></li><li></li><li></li>";
                        } else if (($avg > 1.5) && ($avg <= 2)) {
                            echo "<li class='full_star'></li><li class='full_star'></li><li></li><li></li><li></li>";
                        } else if (($avg > 2) && ($avg <= 2.5)) {
                            echo "<li class='full_star'></li><li class='full_star'></li><li class='half_star'></li><li></li><li></li>";
                        } else if (($avg > 2.5) && ($avg <= 3)) {
                            echo "<li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li></li><li></li>";
                        } else if (($avg > 3) && ($avg <= 3.5)) {
                            echo "<li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='half_star'></li><li></li>";
                        } else if (($avg > 3.5) && ($avg <= 4)) {
                            echo "<li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li></li>";
                        } else if (($avg > 4) && ($avg <= 4.5)) {
                            echo "<li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='half_star'></li>";
                        } else if (($avg > 4.5) && ($avg <= 5)) {
                            echo "<li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li>";
                        }
                        ?>
                    </ul>
                    <span class="no-reviews"><?php echo date('F Y', strtotime($review->f_created_on)) ?></span>  

                </div> 
                <?php echo $review->f_text ?>
            </div>
        </div>
        <?php
    }


    if ($all_row_count > DEFAULT_ROW_COUNT_REVIEW_PAGINATION) {
        ?>
        <div class="show_more_main" id="show_more_main<?php echo $postID; ?>">
            <span id="<?php echo $postID; ?>" class="show_more design_class <?php echo $class ?>" title="Load more posts">Show more</span>
            <span class="loding" style="display: none;"><span class="loding_txt">Loading….</span></span>
        </div>
        <?php
    }
}
