<!-- Modal -->
<div class="modal fade" id="crop_modal" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalLabel">Position your image </h5>
                <input type="hidden" id="x" name="x" />
                <input type="hidden" id="y" name="y" />
                <input type="hidden" id="w" name="w" />
                <input type="hidden" id="h" name="h" />

                <input type="hidden" id="image_number" value=""> 
            </div>
            <div class="modal-body crop_model_body">
                <p><img id="filePreview_image" style="display:none !important;"/></p>
                    <!--<div style="display:none" class="progress_img_crop">-->
                    <div style="display:none" class="progress progress_img_crop">
                        <div class="progress-bar progress-bar-success myprogress" role="progressbar" style="width:0%">0%</div>
                    </div>
                    <div class="msg"></div>
                <div class="modal-footer">
                    <button id="crope_image" class="btn btn-primary but_crope" type="button">Crop & Upload</button>
                    <button type="button" id="cancel_crop" class="btn btn-default but_crope">Upload full image</button>
                    <button type="button" id="dont_upload" class="btn btn-default but_crope" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
</div>