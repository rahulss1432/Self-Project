<div id="error_model" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close close_error" data-dismiss="modal">&times;</button>
                <p id="error_text">Some text in the modal.</p>
            </div>
        </div>
    </div>
</div>