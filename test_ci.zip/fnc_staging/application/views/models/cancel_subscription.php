<div class="modal fade" id="cancel_subcription_model" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="cancel_subcription_form">
                <div class="modal-header">
                    <h5 class="modal-title">Cancel subscription</h5>
                </div>
                <div class="modal-body crop_model_body">

                    <p class="content_are">Cancel</p>
                    <input type="radio" data-rule-required="true" class="cancel" name="cancel_type" value="1"> immediately
                    <input type="radio" data-rule-required="true" id="remove_cnt" name="cancel_type" value="2"> end of month
                </div>
                <div class="modal-footer_1">
                    <button id="" class="btn btn-primary but_crope Confirm_button" onClick="cancelSubscription()" type="button">Confirm</button>
                    <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>