<title>Functions & Catering</title>
<style>
    .success-page{
        max-width:300px;
        display:block;
        margin: 0 auto;
        text-align: center;
        position: relative;
        top:30%;
        transform: perspective(1px) translateY(50%)
    }
    .success-page img{
        max-width:62px;
        display: block;
        margin: 0 auto;
    }

    .btn-view-orders{
        display: block;
        border:1px solid #47c7c5;
        width:100px;
        margin: 0 auto;
        margin-top: 45px;
        padding: 10px;
        color:#fff;
        background-color:#47c7c5;
        text-decoration: none;
        margin-bottom: 20px;
    }
    h2{
        color:#00adee;
        margin-top: 25px;

    }
    a{
        text-decoration: none;
    }
</style>
<div class="success-page">
    <?php if ($fc_data[0]->fc_status == 1) { ?>
        <h2>Approved Successful !</h2>
    <?php } elseif ($fc_data[0]->fc_status == 2) { ?>
        <h2>Denied Successful !</h2>
    <?php } ?>
    <a href="<?php echo base_url('/') ?>">Back to home</a>
</div>