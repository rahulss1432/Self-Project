<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<script src="<?php echo base_url('admin-assets/js/cropper.js'); ?>"></script>
<script src="<?php echo base_url('admin-assets/js/jquery.ezdz.js'); ?>"></script>
<script src="<?php echo base_url('admin-assets/js/jquery.blockUI.js'); ?>"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>admin-assets/dist/css/cropper.css">

<script>
    var search_suburb = '<?php echo site_url('web/search_suburb'); ?>';
    var search_postcode = '<?php echo site_url('web/search_postcode'); ?>';
    var get_cart = '<?php echo site_url('venue/get_cart'); ?>';
    var add_extra_area = '<?php echo site_url('admin/add_extra_area'); ?>';
    var update_status_catering = "<?php echo site_url('admin/update_status_catering') ?>";
    var getPricing = '<?php echo site_url('admin/get_pricing'); ?>';
    var lat = parseFloat('<?php echo $catering[0]->fc_lat; ?>');
    var lng = parseFloat('<?php echo $catering[0]->fc_lng; ?>');
    var radius_area = parseFloat('<?php echo !empty($catering_radius) ? $catering_radius[0]->csr_radius : 0; ?>');
</script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="<?php echo base_url('admin-assets/js/edit-catering.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/crope_images.js'); ?>"></script>
<div id="page-wrapper">

    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
            <h1 class="page-header">Catering</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="col-md-1"></div>
            <div class="col-md-10">

                <form id="msform" method="post" action="" enctype="multipart/form-data" novalidate="novalidate">

                    <div id="catering_details">
                        <div class="col-sm-12 profile_row das-2">
                            <div class="row top_background">
                                <h4 class="pull-left">Update Package</h4>
                            </div>
                            <span class="pull-right your_plan_expire_tex">Your current plan expire on <?php echo expireFormted($catering[0]->fc_valid_upto); ?></span>
                            <div class="row">
                            <div class="col-lg-8 col-md-12 col-sm-12 col-lg-offset-2">
                                <div class="display_flex_set_d">
                                    <?php
                                    if (!empty($packs)) {
                                        foreach ($packs as $key => $value) {
                                            // echo $value ; die; 
                                            ?>

                                            <div class="col-md-6 border_price_box" id="pack<?php echo $key; ?>">
                                                <span>
                                                    <div class="price_title" id="pack-title<?php echo $key; ?>">
                                                        <div class="price_content <?php echo ($value->pro_id == $catering[0]->fc_current_plan) ? 'fc_active_plan' : ''; ?>" id="pack-content<?php echo $key; ?>">
                                                            <?php echo $value->pro_title;
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <?php if ($value->pro_save != 0) { ?>
                                                        <div class="offet_side_bar"><a>Save $<?php echo $value->pro_save; ?></a></div>
                                                    <?php } ?>

                                                    <div class="offer_box_padding" id="pack-padding<?php echo $key; ?>">
                                                        <?php echo $value->pro_desc; ?>
                                                        <div class="choose_this_button">
                                                            <a data-pack="<?php echo $key; ?>" data-packtype="<?php echo $value->pro_id; ?>" class="choose_plan" href="javascript:;">Choose this plan</a>
                                                        </div>
                                                    </div>
                                                </span>
                                            </div>
                                            <!--col-md-6-->
                                        <?php
                                    }
                                }
                                ?>
                                </div>
                            </div>
                            </div>
                        </div>
                        <input type="hidden" id="update_pack_id" name="update_pack_id" value="0">

                        <input type="hidden" id="fc_id" name="catering" value="<?php echo $catering[0]->fc_id; ?>">
                        <div class="col-sm-12 profile_row das-2">
                            <div class="row top_background">
                                <h4>Function address </h4>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 margin_top_row_106">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_street">Street</label>
                                        <input type="text" class="form-control" id="fc_street-error" name="catering_street" value="<?php echo $catering[0]->fc_street; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_state">State</label>
                                        <input type="text" class="form-control" id="catering_state" name="catering_state" value="<?php echo $catering[0]->fc_state; ?>" data-rule-required="true">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_suburb">Suburb*</label>
                                        <input type="text" class="form-control" id="fc_suburb" name="catering_suburb" value="<?php echo $catering[0]->fc_suburb; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_country">Country*</label>
                                        <input type="text" class="form-control" id="catering_country" name="catering_country" value="<?php echo $catering[0]->fc_country; ?>" data-rule-required="true">
                                    </div>

                                </div>
                                <div class="col-lg-12">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_postcode">Postcode*</label>
                                        <input type="number" class="form-control" id="catering_postcode" name="catering_postcode" value="<?php echo $catering[0]->fc_postcode; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <input type="hidden" class="form-control" id="catering_council" name="catering_council" value="<?php echo $catering[0]->fc_council; ?>">
                                    </div>

                                </div>
                            </div>
                        </div>
                        <br>

                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <input type="button" class="create_map update_btn" id="create_map_catering" value="Update your listing area">
                                <input type="hidden" id="council_arr" value="[]">
                                <input type="hidden" name="lat" id="lat" value="<?php echo $catering[0]->fc_lat; ?>">
                                <input type="hidden" name="lng" id="lng" value="<?php echo $catering[0]->fc_lng; ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 margin_106">
                                <h3 class="opening_your_venue_content your_venue_1 font_your_venue">Your catering will appear in '<span id="city-nm"><?php echo $council; ?></span>' search.</h3>
                                <div id="map" style="width: 100%; height: 300px;"></div>
                                <h3 style="display: none;" id="second_map_heading" class="opening_your_venue_content your_venue_1 font_your_venue">You can increase your service area 50 km for 50c per day, or increase your service area 100km for 1$ per day.
                                </h3>
                                <div id="map1"></div>
                            </div>
                        </div>


                        <?php
                        $current_active_plan = false;
                        if (!empty($catering_radius)) {
                            // print_r($catering_radius);die;
                            $current_active_plan = $catering_radius[0]->csr_plan_id;
                        }
                        ?>
                        <div class="row" id="radius_increas">
                            <div class="col-md-12">
                                <ul class="plus-listing">
                                    <?php
                                    if (!empty($service_area_pack)) {
                                        // echo "yes" ;die;
                                        foreach ($service_area_pack as $key => $value) {
                                            // print_r($value) ;die;
                                            ?>

                                            <li>
                                                <span data-area_add="<?php echo $value->pro_desc ?>" data-active="0" id="<?php echo $value->pro_id; ?>" class="increase_radius_map plus new_plus_sine <?php echo ($value->pro_id == $current_active_plan) ? 'my_active' : '' ?> ">
                                                    <?php echo ($value->pro_id == $current_active_plan) ? '-' : '+' ?></span><span class="plus-section plus_sec_510"><?php echo $value->pro_title; ?>
                                                </span>
                                            </li>
                                        <?php
                                    }
                                }
                                ?>
                                    <input type="hidden" id="cheak_status" value="">
                                    <input type="hidden" id="service_product_id" value="">
                                    <input type="hidden" name="csr_radius_id" id="extra_service_area_id" value="">
                                    <input type="hidden" id="csr_id" value="<?php echo (!empty($catering_radius[0]->csr_id)) ? $catering_radius[0]->csr_id : ''; ?>" name="csr_id">
                                </ul>
                            </div>
                        </div>






                        <div class="col-sm-12 profile_row border_progress_page fountion_1">
                            <div class="row top_background">
                                <h4>Catering</h4>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 margin_top_row_106">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_business_name">Trading name*</label>
                                        <input type="text" class="form-control" data-msg-remote="this trading name already exist" data-rule-remote="<?php echo site_url('admin/catering_check_business_name/') . "?fc_id=" . $catering[0]->fc_id; ?>" name="catering_business_name" value="<?php echo $catering[0]->fc_business_name; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_business_name">Company name*</label>
                                        <input type="text" class="form-control" name="catering_company_name" value="<?php echo $catering[0]->fc_company_name; ?>" data-rule-required="true">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_abn">ABN*</label>
                                        <input type="text" class="form-control" name="catering_abn" value="<?php echo $catering[0]->fc_abn; ?>" data-rule-required="true" data-rule-abn_number="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_contact_name">Contact name*</label>
                                        <input type="text" class="form-control" name="catering_contact_name" value="<?php echo $catering[0]->fc_contact_name; ?>" data-rule-required="true">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_phone_no">Phone number*</label>
                                        <input type="text" data-rule-phone_number="true" maxLength='10' data-rule-minlength="8" data-rule-maxlength="10" class="form-control" name="catering_phone_no" value="<?php echo $catering[0]->fc_phone_no; ?>" data-rule-required="true" data-rule-digits="true">
                                    </div>
<!--                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_website">Website*</label>
                                        <input type="text" class="form-control" name="catering_website" value="<?php // echo $catering[0]->fc_website; ?>" data-rule-required="true">
                                    </div>-->
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_email">Email*</label>
                                        <input type="text" class="form-control" name="catering_email" value="<?php echo $catering[0]->fc_email; ?>" data-rule-required="true" data-rule-email="true">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php
                        if (!empty($catering[0]->fc_listing_picture)) {
                            $img_url = base_url('uploads/fc_images') . '/' . $catering[0]->fc_listing_picture;
                        } else {
                            $img_url = '';
                        }
                        ?>
                        <div class="col-sm-12 profile_row border_progress_page fountion_1">
                            <div class="row top_background">
                                <h4>Listing Picture </h4>
                            </div>
                            <div class="row margin_top_row_second_106 up-image-row">
                                <div class="col-md-12 text-left">
                                    <div class="col-lg-6 col-sm-12 col-xs-12">
                                        <div class="ulpading_img_size_3 main_img_55555">
                                            <img id="show_image_55555" class="dropzone" img-id="55555" src="<?php echo $img_url; ?>" style="display:<?php echo ($img_url == '') ? 'none;' : 'block;' ?>">
                                            <input type="file" onclick="this.value=null;" name="fc_listing_picture" data-id="55555" class="file-selector image_selector" id="image_selector_55555" accept="image/*">
                                            <input type="hidden" name="dimesion_image_55555" id="dimesion_image_55555" value="0">
                                            <img class="remove_image" onclick="removeImage(1, '<?php echo encrypt_decrypt('encrypt', $catering[0]->fc_id); ?>', 1, 55555)" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                        </div>
                                    </div>
                                    <div  class="col-lg-6 col-sm-12 col-xs-12">
                                        <div class="ulpading_img_size_3_1">
                                            <div>
                                                To have your catering looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 300 x 530 pixels.
                                            </div>
                                            <div class="row">
                                                <label ant-id="55555" class="upload-button_new after_102" id="another_select_55555">
                                                    <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="col-sm-12 profile_row fountion_2">
                            <div class="row top_background text-left">
                                <h4>Catering images</h4>
                            </div>
                            <?php
                            $last_key = '';
                            $img_status = TRUE;
                            $img_count = 5;
                            if (!empty($catering_images)) {
                                foreach ($catering_images as $key => $value) {
                                    $img_url = (!empty($value->fc_img_name)) ? base_url('uploads/fc_images') . '/' . $value->fc_img_name : '';
                                    ?>
                                    <div class="row margin_top_row_second_106 up-image-row">
                                        <div class="col-md-12 text-left">
                                            <div class="col-lg-6 col-sm-12 col-xs-12">
                                                <div class="ulpading_img_size_3">
                                                    <img style="display:<?php echo ($img_url) ? 'block' : 'none' ?>" img-id="<?php echo $key; ?>" class="dropzone" id="show_image_<?php echo $key; ?>" src="<?php echo $img_url; ?>">
                                                    <input type="file" onclick="this.value=null;" name="catering_image<?php echo $key; ?>" data-id="<?php echo $key; ?>" class="file-selector image_selector" id="image_selector_<?php echo $key; ?>" accept="image/*">
                                                    <input type="hidden" name="dimesion_image_<?php echo $key; ?>" id="dimesion_image_<?php echo $key; ?>" value="0">
                                                    <img onclick="removeImage(2, '<?php echo encrypt_decrypt('encrypt', $value->fc_img_id); ?>', 1, <?php echo $key; ?>)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                                </div>
                                            </div>
                                            <div  class="col-lg-6 col-sm-12 col-xs-12">
                                                <div class="ulpading_img_size_3_1">
                                                    <?php
                                                    if ($key == 0) {
                                                        $img_status = FALSE;
                                                        ?>
                                                        <div>
                                                            To have your catering looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                        </div>
                                                    <?php } ?>
                                                    <div class="row">
                                                        <label ant-id="<?php echo $key; ?>" class="upload-button_new after_102" id="another_select_<?php echo $key; ?>">

                                                            <input type="hidden" name="image<?php echo $key; ?>" value="<?php echo $value->fc_img_id; ?>">
                                                            <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $last_key = $key;
                                    $img_count = $img_count - 1;
                                }
                            }

                            if ($img_count > 0) {
                                $crp = $last_key + 1;;
                                ?>
                                <input type="hidden" name="img_count" value="<?php echo $img_count; ?>">
                                <?php
                                for ($i = 1; $i <= $img_count; $i++) {
                                    ?>
                                    <div class="row margin_top_row_second_106 up-image-row">
                                        <div class="col-md-12 text-left">
                                            <div  class="col-lg-6 col-sm-12 col-xs-12">
                                                <div class="ulpading_img_size_3 ">
                                                    <img id="show_image_<?php echo $crp; ?>" class="dropzone" img-id="<?php echo $crp; ?>" src="" style="display:none">
                                                    <input type="file" onclick="this.value=null;" name="catering_image[]" data-id="<?php echo $crp; ?>" class="file-selector image_selector" id="image_selector_<?php echo $crp; ?>" accept="image/*">
                                                    <input type="hidden" name="dimesion_image_<?php echo $crp; ?>" id="dimesion_image_<?php echo $crp; ?>" value="0">
                                                    <img onclick="removeImage(2, 0, 2, <?php echo $crp; ?>)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                                </div>
                                            </div>
                                            <div  class="col-lg-6 col-sm-12 col-xs-12">
                                                <div class="ulpading_img_size_3_1">
                                                    <?php
                                                    if ($img_status) {
                                                        $img_status = FALSE;
                                                        ?>
                                                        <div>
                                                            To have your catering looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                        </div>
                                                    <?php } ?>
                                                    <div class="row">
                                                        <label ant-id="<?php echo $crp; ?>" class="upload-button_new after_102" id="another_select_<?php echo $crp; ?>">
                                                            <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $crp++;
                                }
                            }
                            ?>
                        </div>

                        <div class="col-sm-12 profile_row fountion_3 price_sp">
                            <div class="row top_background text-left">
                                <h4>Price per head </h4>
                            </div>
                            <div class="row">
                                <div class="text-left">
                                    <div class="col-md-6">
                                        <?php
                                        $price_arr = array();

                                        if (!empty($catering[0]->fc_pricing)) {
                                            $price_arr = explode(',', $catering[0]->fc_pricing);
                                        }

                                        if (!empty($price_per_head)) {
                                            $dollar_count = 1;
                                            foreach ($price_per_head as $value) {
                                                ?>
                                                <label class="set_label_venu">
                                                    <?php
                                                    $checked_pricing = '';
                                                    if (in_array($value->p_id, $price_arr)) {
                                                        $checked_pricing = 'checked';
                                                    }
                                                    ?>
                                                    <label class="regular-checkbox pull-left r-p-n-501">
                                                        <input class="checkbox_set" name="catering_pricing[]" type="checkbox" value="<?php echo $value->p_id; ?>" <?php echo $checked_pricing; ?>>
                                                        <small></small>
                                                    </label>
                                                    <div class="dolor_icon"><?php
                                                                            for ($i = 0; $i < $dollar_count; $i++) {
                                                                                echo '$';
                                                                            }
                                                                            ?></div>
                                                    <span><?php echo $value->p_name; ?></span>

                                                </label>
                                                <?php
                                                if ($dollar_count % 2 == 0)
                                                    echo '</div><div class="col-md-6">';

                                                $dollar_count++;
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-12 profile_row fountion_4">
                            <div class="row top_background text-left">
                                <h4>Overview-Catering details</h4>
                            </div>
                            <div class="row">
                                <div class="col-md-12 text-left">
                                    <label class="">Overview*</label>
                                    <textarea class="form-control overview_textarea textare_root" placeholder="This is a short introductory overview that describes your venue. &#10;Max 1200 words." name="catering_overview" data-rule-required="true" data-rule-maxlength="1200" maxlength="1200" data-rule-required="true"><?php echo $catering[0]->fc_overview; ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 profile_row fountion_5">
                            <div class="row top_background text-left">
                                <h4>Function types</h4>
                            </div>
                            <div class="row margin_top_row_second_106">
                                <div class="form-check form-check-inline">
                                    <?php
                                    $function_type_arr = array();

                                    if (!empty($catering_details)) {
                                        if (!empty($catering_details[0]->cd_function_type)) {
                                            $function_type_arr = explode(',', $catering_details[0]->cd_function_type);
                                        }
                                    }


                                    if (!empty($function_type)) {
                                        foreach ($function_type as $f_type) {
                                            ?>
                                            <div class="col-md-6 text-left pass">

                                                <label class="set_label_venu">
                                                    <?php
                                                    $checked_event = '';
                                                    if (in_array($f_type->id, $function_type_arr)) {
                                                        $checked_event = 'checked';
                                                    }
                                                    ?>
                                                    <label class="regular-checkbox pull-left r-p-n-501">
                                                        <input class="checkbox_set" type="checkbox" name="catering_function_type[]" value="<?php echo $f_type->id; ?>" <?php echo $checked_event; ?>>
                                                        <small></small>
                                                    </label>
                                                    <div class="dolor_icon size_set_ic"><img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $f_type->image; ?>"></div>
                                                    <span><?php echo $f_type->name; ?></span>

                                                </label>
                                            </div>
                                        <?php
                                    }
                                }
                                ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 profile_row fountion_6">
                            <div class="row top_background text-left">
                                <h4>Menus</h4>
                            </div>
                            <div class="row margin_top_row_second_106">
                                <div class="form-check form-check-inline">
                                    <?php
                                    $menus_arr = array();

                                    if (!empty($catering_details)) {
                                        if (!empty($catering_details[0]->cd_menus)) {
                                            $menus_arr = explode(',', $catering_details[0]->cd_menus);
                                        }
                                    }

                                    if (!empty($menus)) {
                                        foreach ($menus as $m_val) {
                                            ?>
                                            <div class="col-md-6 text-left pass_1">
                                                <label class="set_label_venu">
                                                    <?php
                                                    $checked_facility = '';
                                                    if (in_array($m_val->id, $menus_arr)) {
                                                        $checked_facility = 'checked';
                                                    }
                                                    ?>
                                                    <label class="regular-checkbox pull-left r-p-n-501">
                                                        <input class="form-check-input regular-checkbox new_check" type="checkbox" name="catering_menus[]" value="<?php echo $m_val->id; ?>" <?php echo $checked_facility; ?>>
                                                        <small></small>
                                                    </label>
                                                    <div class="dolor_icon size_set_ic">
                                                        <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $m_val->image; ?>">
                                                    </div>
                                                    <span><?php echo $m_val->name; ?></span>

                                                </label>
                                            </div>
                                        <?php
                                    }
                                }
                                ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 profile_row fountion_6">
                            <div class="row top_background text-left">
                                <h4>Cuisine</h4>
                            </div>
                            <div class="row margin_top_row_second_106">
                                <div class="form-check form-check-inline">
                                    <?php
                                    $cuisine_arr = array();

                                    if (!empty($catering_details)) {
                                        if (!empty($catering_details[0]->cd_cuisine)) {
                                            $cuisine_arr = explode(',', $catering_details[0]->cd_cuisine);
                                        }
                                    }

                                    if (!empty($cuisine)) {
                                        foreach ($cuisine as $c_val) {
                                            ?>
                                            <div class="col-md-6 text-left pass_1">
                                                <label class="set_label_venu">
                                                    <?php
                                                    $checked_feature = '';
                                                    if (in_array($c_val->id, $cuisine_arr)) {
                                                        $checked_feature = 'checked';
                                                    }
                                                    ?>
                                                    <label class="regular-checkbox pull-left r-p-n-501">
                                                        <input class="form-check-input regular-checkbox new_check" type="checkbox" name="catering_cuisine[]" value="<?php echo $c_val->id; ?>" <?php echo $checked_feature; ?>>
                                                        <small></small>
                                                    </label>
                                                    <div class="dolor_icon size_set_ic">
                                                        <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $c_val->image; ?>">
                                                    </div>
                                                    <span><?php echo $c_val->name; ?></span>

                                                </label>
                                            </div>
                                        <?php
                                    }
                                }
                                ?>

                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 profile_row fountion_6">
                            <div class="row top_background text-left">
                                <h4>Services</h4>
                            </div>
                            <div class="row margin_top_row_second_106">
                                <div class="form-check form-check-inline">

                                    <?php
                                    $services_arr = array();

                                    if (!empty($catering_details)) {
                                        if (!empty($catering_details[0]->cd_services)) {
                                            $services_arr = explode(',', $catering_details[0]->cd_services);
                                        }
                                    }

                                    if (!empty($services)) {
                                        foreach ($services as $s_val) {
                                            ?>
                                            <div class="col-md-6 text-left pass_1">
                                                <label class="set_label_venu">
                                                    <?php
                                                    $checked_feature = '';
                                                    if (in_array($s_val->id, $services_arr)) {
                                                        $checked_feature = 'checked';
                                                    }
                                                    ?>
                                                    <label class="regular-checkbox pull-left r-p-n-501">
                                                        <input class="form-check-input regular-checkbox new_check" type="checkbox" name="catering_services[]" value="<?php echo $s_val->id; ?>" <?php echo $checked_feature; ?>>
                                                        <small></small>
                                                    </label>
                                                    <div class="dolor_icon size_set_ic">
                                                        <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $s_val->image; ?>">
                                                    </div>
                                                    <span><?php echo $s_val->name; ?></span>


                                                </label>
                                            </div>
                                        <?php
                                    }
                                }
                                ?>

                                </div>
                            </div>
                        </div>

                        <div class="col-sm-12 profile_row fountion_7">
                            <div class="row top_background text-left">
                                <h4>Catering in detail</h4>
                            </div>
                            <div class="row margin_top_row_second_106">
                                <div class="col-md-12 text-left">
                                    <label class="text-left" for="venue_description">Details</label>
                                    <textarea rows="4" class="form-control overview_textarea textare_root" placeholder="This section allows for more venue details if required. Not mandatory. &#10;Max 1200 words" data-rule-required="true" data-rule-maxlength="1200" maxlength="1200" name="catering_details"><?php echo $catering[0]->fc_details; ?></textarea>
                                </div>
                            </div>
                            <div class="row margin_top_and_bottom_user">
                                <div class="col-md-6 text-left">
                                    <label class="lbl_class" for="venue_min_guest">Minimum guest numbers</label>
                                    <input type="text" data-rule-lessThan="#max_guest" id="min_guest" class="form-control" name="catering_min_guest" value="<?php echo $catering[0]->fc_min_guest; ?>">
                                </div>
                                <div class="col-md-6 text-left">
                                    <label class="lbl_class" for="venue_max_guest">Maximum guest numbers</label>
                                    <input data-rule-greaterThan="#min_guest" id="max_guest" type="text" class="form-control" name="catering_max_guest" value="<?php echo $catering[0]->fc_max_guest; ?>">
                                </div>
                            </div>
                        </div>

                        <div class="clearfix d"></div>

                        <!-- <input type="submit" name="submit" class=" update_btn valid" value="Update Catering"> -->
                        <a class="cancel_button_venue_catering " href="javascript:void(0)" id="update_catering">Update Catering</a>
                        <a class="cancel_button_venue_catering" href="<?php echo site_url('admin/venue_catering') ?>">Cancel</a>
                </form>
            </div>

        </div>
    </div>
</div>
<?php $this->load->view('models/image_cropping'); ?>