<div id="page-wrapper">
  <div class="row">
    <div class="col-md-12 ">
     <h1 class="page-header">Premium Venues <a class="btn btn-success new pull-right" href="<?php echo site_url('admin/add_update_premium_venues'); ?>">Add premium venue</a></h1>
     <!-- <a class="btn btn-success new pull-right" href="<?php echo site_url('admin/edit_premium_venues'); ?>">Edit</a> -->
   </div>

 </div>
 <div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
     <div class="panel-heading ">Premium venues list</div>
     <ul  class="Type_select absolute_slct_dt1">
        <li>
         <label>Action</label>
         <select id= "new_one" >
          <option>Please Select</option>
          <option  value="Archive_srch">Archived</option>
        </select>
      </li>
    </ul>
  <div class="panel-body">
    <table width="100%" class="table table-striped table-bordered table-hover" id="table">
      <thead>
        <tr>

            <th>Council Name </th>
            <th>Venues </th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>

      </tbody>
    </table>
  </div>
</div>
</div>
</div>

<div class="modal fade remove_confirmation" id="remove_confirmation" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel">Confirm Remove</h5>
      </div>
      <div class="modal-body crop_model_body">
        <p class="content_are">Are you want to sure Archive this?</p>
        <input type="hidden" id="remove_id" >
        <input type="hidden" id="remove_cnt">
      </div>
      <div class="modal-footer_1">
        <button id="remove_confirmed" class="btn btn-primary but_crope Confirm_button" type="button">Confirm</button>
        <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        $(document).on("click", ".remove_class", function () {
            var council_id = $(this).attr('council_id');
            var fc_id = $(this).attr('fc_id');
            var dlt = $(this).attr('dlt');

            $.ajax({
                url: base_url + 'admin/remove_Premimum',
                method: 'POST',
                data: {fc_id: fc_id, council_id: council_id},
                dataType: 'json',
                success: function (result) {
                    if (result.status) {
                        $('#primium_axes_' + dlt).hide();
                         table.ajax.reload();
                    }
                },
                error: function (xhr, status, error) {
                    console.log(error);
                }
            });
        });

        $(document).on("click", ".row_delete", function () {
            var council_id = $(this).attr('council_id');
            var row_delete = $(this);

            $.ajax({
                url: base_url + 'admin/remove_Premimum',
                method: 'POST',
                data: {council_id: council_id},
                dataType: 'json',
                success: function (result) {
                    if (result.status) {
                        table.ajax.reload();
                    }
                },
                error: function (xhr, status, error) {
                    console.log(error);
                }
            });
        });

        var table = $('#table').DataTable({
            //dom : 'l<"#add">frtip',
            "bPaginate": true,
            "bLengthChange": true,
            "bFilter": true,
            "bSort": true,
            "bInfo": true,
            "bSearchable": true,
            "bAutoWidth": false,
            "bProcessing": true,
            "bServerSide": true,
            "sAjaxSource": '<?php echo $table_data_source ?>',
            "aoColumnDefs": [{"bSortable": false, "aTargets": [1, 2]}]
          });
  });

  $(document).on("change", "#new_one", function () {  
     // alert();
     var is_deleted = $( this ).val();
     var srch_str = '?is_deleted='+is_deleted;
     var  cntrl_url = base_url+'admin/premium_venues_ajax_list'+srch_str;
     $('#table').data('dt_params', { name: 'test' });
     $('#table').DataTable().ajax.url(cntrl_url);
     $('#table').DataTable().draw();


   });


  jQuery(document).on("click", ".new_pop", function (e) {
      // alert();
      $("#remove_confirmation").modal();
    });

  function ArchiveFnc(council_id){
    $("#remove_confirmed").click(function () {
      $('#remove_confirmation').modal('hide');
      $.ajax({
        url:"<?php echo base_url(); ?>admin/archive_single_premium",  
        method: 'POST',
        // dataType: 'json',
        data: {council_id: council_id},
        success: function (data) {
         $('#table').DataTable().ajax.reload();

       }
     });
    });
  }


</script>


