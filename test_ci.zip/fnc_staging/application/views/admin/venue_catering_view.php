<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Venue & Catering</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Venue & catering list</div>
                <ul  class="Type_select">
                    <li>
                <label>Type</label>
                    <select id= "new">
                        <option id="new1" >Please Select</option>
                        <option id="new2" value="all_srch">All</option>

                        <option id="new2" value="Venue_srch">Venue</option>
                        <option  id="new3" value="Catering_srch">Catering</option>
                        <option  id="new4" value="Venue_free"> Free venue</option>
                        <option  id="new3" value="Catering_free">Free catering</option>
              <option  id="new3" value="archive_srch">Archive</option>
                    </select>
                </li> 
                </ul>        
                <div class="panel-body">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                        <thead>
                            <tr>
                                <th>Trading Name</th>
                                <th>User</th>
                                <th>Contact Name</th>
                                <th>Phone No</th>
                                <th>Type</th>
                                <th style="width: 20%;">Action</th>
                                <th></th>
                            </tr>
                        </thead> 
                        <tbody>
                        </tbody>
                    </table>
                </div>
      </div>
    </div>
  </div>
</div>
<div class="modal fade remove_confirmation" id="remove_confirmation" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel">Confirm Remove</h5>
      </div>
      <div class="modal-body crop_model_body">
        <p class="content_are">Are you want to sure Archive this?</p>
        <input type="hidden" id="remove_id" >
        <input type="hidden" id="remove_cnt">
      </div>
      <div class="modal-footer_1">
        <button id="remove_confirmed" class="btn btn-primary but_crope Confirm_button" type="button">Confirm</button>
        <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">


    var table;
    $(document).ready(function () {

        var table = $('#table').DataTable({
          dom : 'l<"#add">frtip',
          "order": [[ 6, "DESC" ]],
          "bPaginate": true,
          "bLengthChange": true,
          "bFilter": true,
          "bSort": true,
          "bInfo": true,
          "bSearchable": true,
          "bAutoWidth": false,
          "bProcessing": true,
          "bServerSide": true,
          "sAjaxSource": "<?php echo $table_data_source ?>",
          "aoColumnDefs": [
            { "bSortable": false, "aTargets": [ 5 ] },
            { "bVisible": false, "aTargets": [ 6 ] }
          ] 
      });


   
    });

    function UpdateCatering(fc_id, fc_status,is_mail_send) {
        var url = "<?php echo site_url('admin/catering_update') ?>";
        $.ajax({
            url: url,
            type: "POST",
            data: {fc_id: fc_id, fc_status: fc_status,is_mail_send:is_mail_send},
            dataType: "JSON",
            success: function (data)
            {
                $('#table').DataTable().ajax.reload();

            }
        });
    }
function ArchiveFnc(fc_id){
  $("#remove_confirmed").click(function () {
    $('#remove_confirmation').modal('hide');
    $.ajax({
      url:"<?php echo base_url(); ?>admin/archive_single_user",  
      method: 'POST',
      // dataType: 'json',
      data: {fc_id: fc_id},
      success: function (data) {
       $('#table').DataTable().ajax.reload();

     }
   });
  });
}
</script>

<style type="text/css">
.new_class {
    width: 950px !important;
}
</style>

<script type="text/javascript">

    $(document).on("change", "#new", function () {  

        var fc_type = $( this ).val();

        var srch_str = '?fc_type='+fc_type;
        var  cntrl_url = base_url+'admin/catering_ajax_list'+srch_str;
        $('#table').data('dt_params', { name: 'test' });
        $('#table').DataTable().ajax.url(cntrl_url);
        $('#table').DataTable().draw();


    });
 
    
  jQuery(document).on("click", ".open_pop", function (e) {
    $("#remove_confirmation").modal();

  });
</script>