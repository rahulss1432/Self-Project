<?php
$edit_id = $this->uri->segment(3);
if (isset($edit_id)) {
    $str = 'Edit premium venues';
    $btn_str = 'Update';
} else {
    $str = 'Add premium venues';
    $btn_str = 'Add premium venue';
}
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"><?php echo $str ?></h1>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo $str ?></div>
                <div class="panel-body">
                    <div class="row">
                        <form id="edit_user"  action="" method="post" id="myform" role="form" id="frm-login" novalidate ="novalidate"  name='registration' >
                            <input type="hidden"   value="" name="id">
                            <div class="col-lg-4"></div>
                            <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group col-md-12">
                                    <div class="panel-body">
                                        <div class="form-group">
                                            <label for="f_state">Council<span class="red">*</span></label>
                                            <?php
                                            if (isset($edit_id) && !empty($edit_id)) {
                                                ?>
                                                <input type="hidden" name="council_id" value="<?php echo $edit_id ?>">
                                                <?php
                                            }
                                            ?>
                                            <select  name="council_id" id="council_id" class="form-control new" style="width:350px" <?php echo isset($edit_id) ? 'disabled' : '' ?>>
                                                <option value="" >--- Select Council ---</option>
                                                <?php
                                                foreach ($councils as $council) {
                                                    $council_id = $council->council_id;
                                                    ?>
                                                    <option value='<?php echo $council_id ?>' <?php if ($council_id == $edit_id) echo 'selected'; ?>><?php echo $council->council ?></option>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <?php
                                        for ($j = 1; $j <= 6; $j++) {
                                            ?>
                                            <div class="form-group" id="<?php echo 'p_venue_' . $j ?>">
                                                <label for="title"></label>
                                                <select name="fc_business_name[]" class="form-control pre_venues" style="width:350px" data-id="<?php echo $j ?>" id="fc_business_name<?php echo $j ?>">
                                                    <option value="">--- Premium venues ---</option>
                                                </select>
                                                <label style="display:none" class="error" id="error-show-<?php echo $j ?>"></label>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                        
                                            <button type="submit" value="add_premimum_venues"  id="new" class="create_map update_btn valid"  ><?php echo $btn_str ?></button>
                                            <div id="progress" class="error">You dont have any venue.</div>

                                            <a class="cancel_button_venue_catering" href="<?php echo base_url('admin/premium_venues') ?>" >Cancel</a>
                                          
                                              
                                        <div class="clearfix"></div>
                                        
                                        

                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type='text/javascript'>
    var baseURL = "<?php echo base_url(); ?>";
    $(document).ready(function () {
        $('.new').change(function () {
            var council_id = $('#council_id').val();
            var council = $("#council_id option:selected").text();
            show_council(council, council_id);
        });
    });

    function show_council(council, council_id) {
        var msg = "You dont have any venue";
        $('.venue_operation').hide();
        $('.pre_venues').attr('disabled', 'disabled');
        $.ajax({
            url: '<?php echo base_url('admin/getPremimumvenues') ?>',
            method: 'post',
            data: {council_id: council_id, council: council},
            dataType: 'json',
            success: function (response) {
                $('.error').hide();
                var i = 1;
                if (response.count > 0) {
                    $.each(response.option, function (index, data) {
                        console.log(data);

                        $('#fc_business_name' + i).html(data);
                        $('#p_venue_' + i).show();
                        $('#fc_business_name' + i).attr('disabled', false);
                        $('#progress').hide();
                        $('#new').show();
    
                        i++;
                    });
                }else{
                    
                    $('#new').hide();
                    $('#progress').show();
                    
             
                }
                console.log(i);
                for (i; i < 7; i++) {
                    $('#p_venue_' + i).hide();
                    $('#fc_business_name' + i).attr('disabled', 'disabled');
                }

            }

        });
    }

    var council_id = '<?php echo (($this->uri->segment(3))) ? $this->uri->segment(3) : ''; ?>';
    if (council_id != '') {
        var council = $("#council_id option:selected").text();
        show_council(council, council_id);
    }

</script>

<script type="text/javascript">
    $(function () {
        var main_array = [];
        var status = true;
        $(document).on('change', '.pre_venues', function () {
            var attr = $(this).attr('data-id');
            $('#error-show-' + attr).hide();
        });

        if (status) {
            $("form[name='registration']").validate({
                rules: {
                    council_id: {
                        required: true,
                    },
                },

                messages: {
                    council_id: {
                        required: "Enter your council"
                    },
                },

                submitHandler: function (form) {
                    var status = true;
                    var main_array = [];

                    $('.error').hide();
                    for (var i = 1; i <= 6; i++) {
                        var fc_id = $('#fc_business_name' + i).val();
                        if (fc_id > 0) {
                            var result = jQuery.inArray(fc_id, main_array);
                            if (jQuery.inArray(fc_id, main_array) != '-1') {
                                $('#error-show-' + i).html('You already selected this');
                                $('#error-show-' + i).show();
                                status = false;
                            } else {
                                main_array[i] = fc_id;
                            }
                        }
                    }

                    if (status) {
                        form.submit();
                    }
                }
            });
        }
    });
</script>
<style type="text/css">
    .navbar-default.sidebar{
        height:47vw !important;
    }
    body{
        background: #fff !important;
    }
    @media(max-width: 767px){
        .navbar-default.sidebar{  height:100% !important;
        }}
</style>

