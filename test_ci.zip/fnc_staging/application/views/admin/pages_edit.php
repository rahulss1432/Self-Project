<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=ounc8at0yo3ybjq14ii569ot4wmpo461nrlefsbx0pma5k4r"></script>
<?php
 $pages_id = $this->uri->segment(3);

if(!empty($pages_id))
  {
    $str = 'Edit content';
    
  }
  else
  {
    $str = 'Add pages';
    
  }

?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"><span><?php echo $str;?></span>
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
      <div class="col-lg-12">
        <div class="panel panel-default">
          <div class="panel-heading">
           <span><?php echo $str;?></span>
         </div>
         <?php 
         if(empty($user_record))
          $user_record = array();
        ?>
        <div class="panel-body">
          <div class="row">
            <form id="myform"  action="<?php echo isset($form_action) ? $form_action :''?>" method="post" name='registration' onsubmit="return check_val()">
             <input type="hidden" name="id" value="<?php echo $pages_id ?>">
             <div class="col-lg-12">
              <div class="form-group col-md-12">
                <label>Content</label>
                <textarea name = "content" id ="content" class="form-control" data-rule-required="true" class="validate[required]" ><?php echo isset($user_record[0]->content) ? $user_record[0]->content : ''?></textarea>
                <span><p id="new" style="color: #33B5FF;"></p></span>
              </div>
            </div>
            <div class="col-lg-12">
             <div class="col-md-12"><button type="submit" value="add_voucher" class="btn btn-default update_btn">Submit</button>
              <a href="<?php echo site_url('admin/pages'); ?>" class="btn btn-default cancel_btn">Cancel</a>
            </div>
          </div>
        </form>
      </div>
      <!-- /.row (nested) -->
    </div>
    <!-- /.panel-body -->
  </div>
  <!-- /.panel -->
</div>
<!-- /.col-lg-12 -->
</div>
    <!-- /.row -->
</div>


<script type="text/javascript">


  
  tinymce.init({
  selector: 'textarea',
   height: 200,
    width :500,

  menubar: false,
  plugins: [
    'advlist autolink lists link image charmap print preview anchor textcolor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table contextmenu paste code help wordcount'
  ],
  toolbar: 'insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
  content_css: [
    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
    '//www.tinymce.com/css/codepen.min.css']
});

function check_val()
{
       var editorContent = tinyMCE.get('content').getContent();
      
       if (editorContent == '')
       {
         $('#new').text("Please enter text 1st! ").slideDown();
         return false;
       }else{
        
        $('#new').text("Added successfully! ").slideDown();
        return true;
    }
}
</script>

