<link rel="stylesheet" href="<?php echo base_url('assets/css/jquery-ui.min.css'); ?>">
<script src="<?php echo base_url('admin-assets/js/jquery.blockUI.js'); ?>"></script>
<script src="<?php echo base_url('admin-assets/js/cropper.js'); ?>"></script>
<script src="<?php echo base_url('admin-assets/js/jquery.ezdz.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/coordinate.js'); ?>"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>admin-assets/dist/css/cropper.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> 
<script>
    var div2clone = '<?php echo site_url('admin/div2clone'); ?>';
    var remove_product = '<?php echo site_url('admin/remove_product'); ?>';
    var council_record = '<?php echo json_encode($additinal_council) ?>';
    var lat = parseFloat('<?php echo $venue[0]->fc_lat; ?>');
    var load_council = '<?php echo site_url('admin/load_council'); ?>';
    var lng = parseFloat('<?php echo $venue[0]->fc_lng; ?>');
    var councilURL = '<?php echo site_url('admin/check_council'); ?>';
    var total_additional_region = <?php echo count($additinal_council); ?>
</script>
<script src="<?php echo base_url('admin-assets/js/edit-venue.js'); ?>"></script>
<script src="<?php echo base_url('admin-assets/js/custom/crope_images.js'); ?>"></script>
<link rel="stylesheet" href="<?php echo base_url('assets/css/chosen.min.css'); ?>">
<script src="<?php echo base_url('assets/js/chosen.jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery-ui.min.js'); ?>"></script>
<?php
$date = date('m/d/Y');
$val = $venue[0]->fc_valid_upto;
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1" >
            <h1 class="page-header">Venue</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <form id="msform" method="post" action="" enctype="multipart/form-data" novalidate="novalidate">
                    <input type="hidden" name="venue" value="<?php echo $venue[0]->fc_id; ?>">
                    <div class="col-sm-12 profile_row das-2">
                        <div class="row top_background"><h4>Update Package </h4></div>
                        <?php if (strtotime($val) < strtotime($date)) { ?>
                            <span class="pull-right your_plan_expire_tex" style="background-color: red" >Current plan expire on <?php echo expireFormted($venue[0]->fc_valid_upto); ?></span>
                        <?php } else { ?>
                            <span class="pull-right your_plan_expire_tex "  >Current plan expire on <?php echo expireFormted($venue[0]->fc_valid_upto); ?></span>
                        <?php } ?>
                        <div class="row">


                            <div class="col-lg-8 col-md-12 col-sm-12 col-lg-offset-2">
                                <div class="display_flex_set_d">
                                    <?php
                                    if (!empty($packs)) {
                                        foreach ($packs as $key => $value) {
                                            ?>
                                            <div class="col-md-6 border_price_box" id="pack<?php echo $key; ?>">
                                                <span>
                                                    <div class="price_title " id="pack-title<?php echo $key; ?>">
                                                        <div class="price_content <?php echo ($value->pro_id == $venue[0]->fc_current_plan) ? 'fc_active_plan' : ''; ?>" id="pack-content<?php echo $key; ?>">
                                                            <?php echo $value->pro_title; ?>
                                                        </div>
                                                    </div>
                                                    <?php if ($value->pro_save != 0) { ?>
                                                        <div class="offet_side_bar"><a>Save $<?php echo $value->pro_save; ?></a></div>
                                                    <?php } ?>

                                                    <div class="offer_box_padding" id="pack-padding<?php echo $key; ?>">
                                                        <?php echo $value->pro_desc; ?>
                                                        <div class="choose_this_button">
                                                            <a data-pack="<?php echo $key; ?>" data-packtype="<?php echo $value->pro_id; ?>" class="choose_plan " href="javascript:;">Choose this plan</a>
                                                        </div>
                                                    </div>
                                                </span>
                                            </div><!--col-md-6-->
                                            <?php
                                        }
                                    }
                                    ?>

                                </div>

                            </div>
                        </div>
                    </div>
                    <input type="hidden"  id="update_pack_id" name="update_pack_id" value="0">
                    <div class="col-sm-12 profile_row das-2">
                        <div class="row top_background"><h4>Function address </h4></div>
                        <div class="row">
                            <div class="col-lg-12 margin_top_row_106">
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_street">Street*</label>
                                    <input type="text" class="form-control" id="venue_street" name="venue_street" value="<?php echo $venue[0]->fc_street; ?>" data-rule-required="true">
                                </div>
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_state">State*</label>
                                    <input type="text" class="form-control" id="venue_state" name="venue_state" value="<?php echo $venue[0]->fc_state; ?>" data-rule-required="true">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_suburb">Suburb*</label>
                                    <input type="text" class="form-control ui-autocomplete-input valid ui-autocomplete-loading" id="venue_suburb" value="<?php echo $venue[0]->fc_suburb; ?>" name="venue_suburb" data-rule-required="true" autocomplete="off">
                                </div>
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_country">Country*</label>
                                    <input type="text" class="form-control" id="venue_country" name="venue_country" value="<?php echo $venue[0]->fc_country; ?>" data-rule-required="true">
                                </div>
                            </div>
                            <input type="hidden" name="number_region" value="<?php echo count($additinal_council); ?>">
                            <div class="col-lg-12">
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_postcode">Postcode*</label>
                                    <input type="number" class="form-control ui-autocomplete-input" id="venue_postcode" name="venue_postcode" value="<?php echo $venue[0]->fc_postcode; ?>" data-rule-required="true" autocomplete="off">
                                </div>
                                <div class="col-md-6 margin_set_input">
                                    <input type="hidden" class="form-control" id="venue_council" name="venue_council" value="<?php echo $venue[0]->fc_council; ?>" >
                                    <input type="hidden" class="form-control" id="council_id"  value="<?php echo $council_id; ?>" >
                                    <input type="hidden" class="form-control" id="venue_city" name="venue_city" value="<?php echo $venue[0]->fc_city; ?>" >
                                    <input type="hidden" id="zoom" value="<?php echo $zoom ?>" >
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <input type="button" class="create_map" id="create_map" value="Update your listing area">
                            <input type="hidden" id="council_arr" value="[]">
                            <input type="hidden" name="lat" id="lat" value="<?php echo $venue[0]->fc_lat; ?>" >
                            <input type="hidden" name="lng" id="lng" value="<?php echo $venue[0]->fc_lng; ?>">
                            <input type="hidden" id="lat-temp" value="">
                            <input type="hidden" id="lng-temp" value="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 margin_106">
                            <h3 class="opening_your_venue_content your_venue_1 font_your_venue">Your venue will appear in '<span id="city-nm"><?php echo $council; ?></span>' search.</h3>
                            <div id="map-canvas" style="width:100%;height:300px"></div>
                        </div>

                    </div>
                    <div class="row margin_top_row_second_106">
                        <div class="col-md-12 margin_106">
                            <h3 class="opening_your_venue_content your_venue_1 font_your_venue">Additional area:</h3>
                            <div id="map-canvas2" style="width:100%;height:300px"></div>
                        </div>
                    </div>
                    <div id="additional-area-row" class="row edit_reagon_user">
                        <div class="col-md-12">
                            <div class="plus-listing_new">
                                <?php
                                $cnt = 1;
                                if ($additinal_council) {
                                    foreach ($additinal_council as $key => $val) {
                                        ?>
                                        <div id="region-area<?php echo $cnt ?>" class="new_block">

                                            <div class="col-md-6 col-xs-12">
                                                <div class="col-md-2 col-xs-2 margin_top_dc display_first">
                                                    <a href="javascript:;" id="add-area<?php echo $cnt ?>" class="remove_region" data-cnt="<?php echo $cnt ?>"><span class="plus old_sign<?php echo $cnt ?>">-</span></a>
                                                </div>
                                                <div class="col-md-10 col-xs-10 display_second">
                                                    <span id="minima1" class="plus-section_new edit_area_user">
                                                        <select id="addition-area<?php echo $cnt ?>" data-active="1" data-cnt="<?php echo $cnt ?>" class="input-large form-control addition-ar initialize_choosen"  name="add_arr<?php echo $cnt ?>" >
                                                            <option disabled selected value>-- select council --</option>
                                                        </select>

                                                        <input type="hidden" id="area_<?php echo $cnt ?>" name="area_<?php echo $cnt ?>" value="<?php echo encrypt_decrypt('encrypt', $val->area_id) ?>">
                                                        <input type="hidden" id="region_name<?php echo $cnt ?>" value="<?php echo $val->area_name ?>">
                                                        <input type="hidden" id="region<?php echo $cnt ?>" value="<?php echo $val->council_id ?>">
                                                        <input type="hidden" name="add_arr_lat<?php echo $cnt ?>" id="addition-lat<?php echo $cnt ?>" value="<?php echo $val->area_lat ?>">
                                                        <input type="hidden" name="add_arr_lng<?php echo $cnt ?>" id="addition-lng<?php echo $cnt ?>" value="<?php echo $val->area_lng ?>">
                                                    </span>
                                                </div>
                                            </div>

                                        </div>
                                        <?php
                                        $cnt++;
                                    }
                                }
                                if ($cnt <= 4) {
                                    for ($cnt; $cnt <= 4; $cnt++) {
                                        ?>
                                        <div id="region-area<?php echo $cnt ?>" class="new_block">
                                            <div class="col-md-6 col-xs-12">
                                                <div class="col-md-2 col-xs-2 margin_top_dc display_first">
                                                    <a href="javascript:;" id="add-area<?php echo $cnt ?>" class="add-area" data-cnt="<?php echo $cnt ?>"><span class="plus old_sign<?php echo $cnt ?>">+</span></a>
                                                </div>
                                                <div class="col-md-10 col-xs-10 display_second">   
                                                    <span id="minima1" class="plus-section_new edit_area_user">
                                                        <select id="addition-area<?php echo $cnt ?>" data-active="0" data-cnt="<?php echo $cnt ?>" class="input-large form-control initialize_choosen"  name="new_add_arr[]" >
                                                            <option disabled selected value>-- select council --</option>
                                                        </select>

                                                        <input type="hidden" id="region_name<?php echo $cnt ?>" value="">
                                                        <input type="hidden" id="region<?php echo $cnt ?>" value="">
                                                        <input type="hidden" name="add_arr_lat[]" id="addition-lat<?php echo $cnt ?>" value="">
                                                        <input type="hidden" name="add_arr_lng[]" id="addition-lng<?php echo $cnt ?>" value="">
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                                <input type="hidden" name="new_area_total" id="new_area_total" value="0">
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 profile_row border_progress_page fountion_1">
                        <div class="row top_background">
                            <h4>Venue </h4></div>
                        <div class="row">
                            <div class="col-lg-12 margin_top_row_106">
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_business_name">Trading name*</label>
                                    <input type="text" class="form-control" data-msg-remote="this trading name already exist" data-rule-remote="<?php echo site_url('admin/venue_check_business_name/') . "?fc_id=" . $venue[0]->fc_id; ?>"  
                                           name="venue_business_name" value="<?php echo $venue[0]->fc_business_name; ?>" data-rule-required="true" maxlength="50">
                                </div>
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_business_name">Company name*</label>
                                    <input type="text" class="form-control" name="venue_company_name" value="<?php echo $venue[0]->fc_company_name; ?>" data-rule-required="true" maxlength="50">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_abn">ABN*</label>
                                    <input type="text" class="form-control" name="venue_abn" data-rule-abn_number="true" value="<?php echo $venue[0]->fc_abn; ?>" data-rule-required="true">
                                </div>
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_contact_name">Contact name*</label>
                                    <input type="text" class="form-control" name="venue_contact_name" value="<?php echo $venue[0]->fc_contact_name; ?>" data-rule-required="true" maxlength="30">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_phone_no">Phone number*</label>
                                    <input type="text" class="form-control" maxLength='10' data-rule-minlength="8" data-rule-maxlength="10" name="venue_phone_no" value="<?php echo $venue[0]->fc_phone_no; ?>" data-rule-required="true" data-rule-digits="true">
                                </div>
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_website">Website*</label>
                                    <input type="text"  class="form-control" name="venue_website" value="<?php echo $venue[0]->fc_website; ?>" data-rule-required="true">
                                </div>
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="venue_email">Email*</label>
                                    <input type="text" class="form-control" name="venue_email" value="<?php echo $venue[0]->fc_email; ?>" data-rule-required="true" data-rule-email="true" maxlength="100">
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    if (!empty($venue[0]->fc_listing_picture)) {
                        $img_url = base_url('uploads/fc_images') . '/' . $venue[0]->fc_listing_picture;
                    } else {
                        $img_url = '';
                    }
                    ?>
                    <div class="col-sm-12 profile_row border_progress_page fountion_1">
                        <div class="row top_background">
                            <h4>Main Image </h4>
                        </div>
                        <div class="row margin_top_row_second_106 up-image-row">
                            <div class="col-md-12 text-left main_img_55555">
                                <div class="col-lg-6 col-sm-12 col-xs-12">
                                    <div  class="ulpading_img_size_3 listing_picture_thumb">
                                        <img  id="show_image_55555" class="dropzone" img-id="55555" src="<?php echo $img_url; ?>" style="<?php echo ($img_url) ? 'display:block' : 'display:none' ?>">
                                        <input type="file" onclick="this.value = null;" name="fc_listing_picture" data-id="55555" class="file-selector image_selector" id="image_selector_55555" accept="image/*">
                                        <input type="hidden" name="dimesion_image_55555" id="dimesion_image_55555" value="0">
                                        <img class="remove_image" onclick="removeImage(1, '<?php echo encrypt_decrypt('encrypt', $venue[0]->fc_id); ?>', 1, 55555)" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                    </div>

                                </div>

                                <div  class="col-lg-6 col-sm-12 col-xs-12">
                                    <div class="ulpading_img_size_3_1 listing_picture_thumb">
                                        <div>
                                            To have your venue looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 300 x 530 pixels.
                                        </div>
                                        <div class="row" >
                                            <label ant-id="55555" class="upload-button_new after_102" id="another_select_55555">
                                                <i  class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                            </label>
                                        </div>
                                    </div>

                                </div>


                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 profile_row fountion_2">
                        <div class="row top_background text-left">
                            <h4>Venue images</h4>
                        </div>
                        <?php
                        $last_key = '';
                        $img_status = TRUE;
                        $img_count = 5;
                        $pre_img_count = count($venue_images);
                        if (!empty($venue_images)) {
                            foreach ($venue_images as $key => $value) {
                                $img_url = (!empty($value->fc_img_name)) ? base_url('uploads/fc_images') . '/' . $value->fc_img_name : '';
                                ?>
                                <div class="row margin_top_row_second_106 up-image-row">
                                    <div class="col-md-12 text-left">

                                        <div class="col-lg-6 col-sm-12 col-xs-12">
                                            <div class="ulpading_img_size_3">
                                                <img img-id="<?php echo $key; ?>" style="display:<?php echo ($img_url) ? 'block' : 'none' ?>" class="dropzone" id="show_image_<?php echo $key; ?>" src="<?php echo base_url('uploads/fc_images') . '/' . $value->fc_img_name; ?>">
                                                <input type="file" onclick="this.value = null;" data-id="<?php echo $key; ?>" name="venue_image<?php echo $key; ?>" id="image_selector_<?php echo $key; ?>" class="file-selector image_selector" accept="image/*">
                                                <input type="hidden" name="dimesion_image_<?php echo $key; ?>" id="dimesion_image_<?php echo $key; ?>" value="0">
                                                <img onclick="removeImage(2, '<?php echo encrypt_decrypt('encrypt', $value->fc_img_id); ?>', 1, <?php echo $key; ?>)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                            </div>
                                        </div>

                                        <div  class="col-lg-6 col-sm-12 col-xs-12">
                                            <div class="ulpading_img_size_3_1">
                                                <?php
                                                if ($key == 0) {
                                                    $img_status = FALSE;
                                                    ?>
                                                    <div>To have your venue looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                    </div>
                                                <?php } ?>
                                                <div class="row">
                                                    <label ant-id="<?php echo $key; ?>" class="upload-button_new after_102">
                                                        <input type="hidden" name="image<?php echo $key; ?>" value="<?php echo $value->fc_img_id; ?>">
                                                        <i class="fa_icon icon-upload-alt margin-correction"></i> Upload image
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $img_count = $img_count - 1;
                            }
                        }
                        if ($img_count > 0) {
                            $crp = $pre_img_count;
                            ?>
                            <input type="hidden" name="img_count" value="<?php echo $img_count; ?>">
                            <?php
                            for ($i = 1; $i <= $img_count; $i++) {
                                ?>
                                <div class="row margin_top_row_second_106 up-image-row">
                                    <div class="col-md-12 text-left">
                                        <div class="col-lg-6 col-sm-12 col-xs-12">
                                            <div class="ulpading_img_size_3">
                                                <img img-id="<?php echo $crp; ?>" class="dropzone" id="show_image_<?php echo $crp; ?>" src="" style="display:none">
                                                <input type="file" onclick="this.value = null;" name="venue_image[]" data-id="<?php echo $crp; ?>" class="file-selector image_selector" id="image_selector_<?php echo $crp; ?>" accept="image/*">
                                                <input type="hidden" name="dimesion_image_<?php echo $crp; ?>" id="dimesion_image_<?php echo $crp; ?>" value="0">
                                                <img onclick="removeImage(2, '0', 2, <?php echo $key; ?>)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-sm-12 col-xs-12">
                                            <div class="ulpading_img_size_3_1">
                                                <?php
                                                if ($img_status) {
                                                    $img_status = FALSE;
                                                    ?>
                                                    <div>
                                                        To have your venue looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                    </div>
                                                <?php } ?>
                                                <div class="row">

                                                    <label ant-id="<?php echo $crp; ?>" class="upload-button_new after_102">
                                                        <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $crp++;
                            }
                        }
                        ?>
                    </div>
                    <div class="col-sm-12 profile_row fountion_3 price_sp">
                        <div class="row top_background text-left">
                            <h4>Price per head </h4>
                        </div>
                        <div class="row">
                            <div class="text-left">
                                <div class="col-md-6">
                                    <?php
                                    $price_arr = array();
                                    if (!empty($venue[0]->fc_pricing)) {
                                        $price_arr = explode(',', $venue[0]->fc_pricing);
                                    }
                                    if (!empty($price_per_head)) {
                                        $dollar_count = 1;
                                        foreach ($price_per_head as $value) {
                                            ?>
                                            <label class="set_label_venu">
                                                <?php
                                                $checked_pricing = '';
                                                if (in_array($value->p_id, $price_arr)) {
                                                    $checked_pricing = 'checked';
                                                }
                                                ?>
                                                <label class="regular-checkbox pull-left r-p-n-501">
                                                    <input name="venue_pricing[]" type="checkbox" value="<?php echo $value->p_id; ?>" <?php echo $checked_pricing; ?>>
                                                    <small></small>
                                                </label>
                                                <div class="dolor_icon"><?php
                                                    for ($i = 0; $i < $dollar_count; $i++) {
                                                        echo '$';
                                                    }
                                                    ?></div>
                                                <span><?php echo $value->p_name; ?></span>

                                            </label>
                                            <?php
                                            if ($dollar_count % 2 == 0)
                                                echo '</div><div class="col-md-6">';
                                            $dollar_count++;
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div> 

                    <div class="col-sm-12 profile_row fountion_4">
                        <div class="row top_background text-left">
                            <h4>Overview-Venue details</h4>
                        </div>
                        <div class="row">
                            <div class="col-md-12 text-left">
                                <label class="">Overview*</label>
                                <textarea class="form-control overview_textarea textare_root" placeholder="This is a short introductory overview that describes your venue. &#10;Max 1200 words." name="venue_overview" data-rule-required="true" data-rule-required="true" data-rule-maxlength="1200" maxlength="1200"><?php echo $venue[0]->fc_overview; ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 profile_row fountion_5">
                        <div class="row top_background text-left">
                            <h4>Event types</h4>
                        </div>
                        <div class="row margin_top_row_second_106">
                            <div class="form-check form-check-inline">
                                <?php
                                $event_arr = array();
                                if (!empty($venue_details)) {
                                    if (!empty($venue_details[0]->vd_events)) {
                                        $event_arr = explode(',', $venue_details[0]->vd_events);
                                    }
                                }
                                if (!empty($event_types)) {
                                    foreach ($event_types as $e_type) {
                                        ?>
                                        <div class="col-md-6 text-left pass">
                                            <label class="set_label_venu">
                                                <?php
                                                $checked_event = '';
                                                if (in_array($e_type->id, $event_arr)) {
                                                    $checked_event = 'checked';
                                                }
                                                ?>
                                                <label class="regular-checkbox pull-left r-p-n-501">
                                                    <input type="checkbox" name="venue_events[]" value="<?php echo $e_type->id; ?>" <?php echo $checked_event; ?>>
                                                    <small></small>
                                                </label>
                                                <div class="dolor_icon size_set_ic"><img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->image; ?>"></div>
                                                <span><?php echo $e_type->name; ?></span>

                                            </label>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 profile_row fountion_6">
                        <div class="row top_background text-left">
                            <h4>Facilities</h4>
                        </div>
                        <div class="row margin_top_row_second_106">
                            <div class="form-check form-check-inline">
                                <?php
                                $facility_arr = array();
                                if (!empty($venue_details)) {
                                    if (!empty($venue_details[0]->vd_facilities)) {
                                        $facility_arr = explode(',', $venue_details[0]->vd_facilities);
                                    }
                                }
                                if (!empty($facilities)) {
                                    foreach ($facilities as $f_val) {
                                        ?>
                                        <div class="col-md-6 text-left pass_1">
                                            <label class="set_label_venu">
                                                <?php
                                                $checked_facility = '';
                                                if (in_array($f_val->id, $facility_arr)) {
                                                    $checked_facility = 'checked';
                                                }
                                                ?>
                                                <label class="regular-checkbox pull-left r-p-n-501">
                                                    <input  type="checkbox" name="venue_facilities[]" value="<?php echo $f_val->id; ?>" <?php echo $checked_facility; ?>>
                                                    <small></small>
                                                </label>
                                                <div class="dolor_icon size_set_ic">
                                                    <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->image; ?>">
                                                </div>
                                                <span><?php echo $f_val->name; ?></span>

                                            </label>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 profile_row fountion_6">
                        <div class="row top_background text-left">
                            <h4>Features</h4>
                        </div>
                        <div class="row margin_top_row_second_106">
                            <div class="form-check form-check-inline">
                                <?php
                                $feature_arr = array();
                                if (!empty($venue_details)) {
                                    if (!empty($venue_details[0]->vd_features)) {
                                        $feature_arr = explode(',', $venue_details[0]->vd_features);
                                    }
                                }
                                if (!empty($features)) {
                                    foreach ($features as $feat_val) {
                                        ?>
                                        <div class="col-md-6 text-left pass_1">
                                            <label class="set_label_venu">
                                                <?php
                                                $checked_feature = '';
                                                if (in_array($feat_val->id, $feature_arr)) {
                                                    $checked_feature = 'checked';
                                                }
                                                ?>
                                                <label class="regular-checkbox pull-left r-p-n-501">
                                                    <input  type="checkbox" name="venue_features[]" value="<?php echo $feat_val->id; ?>" <?php echo $checked_feature; ?>>
                                                    <small></small>
                                                </label>
                                                <div class="dolor_icon size_set_ic">
                                                    <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->image; ?>">
                                                </div>
                                                <span><?php echo $feat_val->name; ?></span>

                                            </label>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 profile_row fountion_7">
                        <div class="row top_background text-left">
                            <h4>Venue in detail</h4>
                        </div>
                        <div class="row margin_top_row_second_106">
                            <div class="col-md-12 text-left">
                                <label class="text-left" for="venue_description">Details*</label>
                                <textarea rows="4" class="form-control overview_textarea textare_root" placeholder="This section allows for more venue details if required. Not mandatory. &#10;Max 1200 words" data-rule-required="true" data-rule-maxlength="1200" maxlength="1200" name="venue_details"><?php echo $venue[0]->fc_details; ?></textarea>
                            </div>
                        </div>
                        <div class="row margin_top_and_bottom_user">
                            <div class="col-md-6 text-left">
                                <label class="lbl_class" for="venue_min_guest">Minimum guest numbers</label>
                                <input type="text" id="venue_min_guest" maxlength="5" class="form-control number_allow_only" data-rule-lessThan="#venue_max_guest" name="venue_min_guest" value="<?php echo $venue[0]->fc_min_guest; ?>">
                            </div>
                            <div class="col-md-6 text-left">
                                <label class="lbl_class" for="venue_max_guest">Maximum guest numbers</label>
                                <input type="text" data-rule-greaterThan="#venue_min_guest" maxlength="5" class="form-control number_allow_only" id="venue_max_guest" name="venue_max_guest" value="<?php echo $venue[0]->fc_max_guest; ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 profile_row fountion_2">
                        <div class="row top_background text-left">
                            <h4>Venue pdfs</h4>
                        </div>
                        <?php
                        $old_img_count = (!empty($venue_pdfs)) ? count($venue_pdfs) : 0;
                        for ($i = 1; $i <= 4; $i++) {
                            $pdf_url = '';
                            if ($old_img_count > 0) {
                                $pdf_url = base_url('uploads/venue_pdf_image') . '/' . $venue_pdfs[$i - 1]->fc_pdf_image;
                                $pdfTitleName = $venue_pdfs[$i - 1]->fc_pdf_title_name;
                                $pdfName = $venue_pdfs[$i - 1]->fc_pdf_name;
                                $pdfImageName = $venue_pdfs[$i - 1]->fc_pdf_image;
                                $pdfId = $venue_pdfs[$i - 1]->fc_pdf_id;
                                if (empty($venue_pdfs[$i - 1]->fc_pdf_name)) {
                                    $pdf_url = '';
                                    $remove_hide = '';
                                }
                                $remove_hide = '';
                                $b_upload_hide = 'display:none';
                                $old_img_count--;
                                $removeImg = "removePdf(2, '" . encrypt_decrypt('encrypt', $venue_pdfs[$i - 1]->fc_pdf_id) . "', 1, $i )";
                                if ((!empty($pdfTitleName)) && (empty($venue_pdfs[$i - 1]->fc_pdf_name))) {
                                    $b_upload_hide = '';
                                    $remove_hide = 'display:none';
                                    $removeImg = "removePdf(2, '0', 2, $i );";
                                }
                            } else {
                                $removeImg = "removePdf(2, '0', 2, $i );";
                                $remove_hide = 'display:none';
                                $b_upload_hide = '';
                                $pdfTitleName = '';
                                $pdfId = '';
                                $pdfName = '';
                                $pdfImageName = '';
                            }
                            ?>
                            <div class="row margin_top_row_second_106 up-image-row">
                                <div>
                                    <div class="col-sm-6">
                                        <h5 class="clr_cmn"><strong>Attachment Name</strong></h5>
                                        <div class=" margin_set_input no-pad">
                                            <input type="hidden" name="pdf_id" id="pdf_id_<?php echo $i; ?>" value="<?php echo $pdfId; ?>">
                                            <input type="hidden" name="pdf_title_name" id="pdf_title_name_<?php echo $i; ?>" value="<?php echo $pdfTitleName; ?>">
                                            <input type="hidden" name="pdf_name" id="pdf_name_<?php echo $i; ?>" value="<?php echo $pdfName; ?>">
                                            <input type="hidden" name="pdf_image_name" id="pdf_image_name_<?php echo $i; ?>" value="<?php echo $pdfImageName; ?>">
                                            <input type="text" class="form-control pdf_title_name" name="pdf_title[]" id="pdf_title_<?php echo $i; ?>" data-id="<?php echo $i; ?>" minlength="5" maxlength="20" placeholder="Enter File Name" value="<?php echo $pdfTitleName; ?>">
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="col-md-12 text-left">
                                    <div class="col-lg-6 col-sm-12 col-xs-12">
                                        <div class="ulpading_img_size_3">
                                            <img id="pdfimage_<?php echo $i; ?>" src="<?php echo ($pdf_url != '') ? $pdf_url : ''; ?>" class="dropzone" img-id="<?php echo $i; ?>" style="<?php echo ($pdf_url != '') ? 'display: block;' : 'display:none;' ?> ">
                                            <input type="hidden" name="fc_pdf_image[]" id="fc_pdf_image_<?php echo $i; ?>">
                                            <input onclick="this.value = null;" type="file" name="venue_pdf[]" data-fc_img_id="" data-id="<?php echo $i ?>" class="pdf-selector pdf_selector check_pdf_validation pdf_remove_select<?php echo $i ?>" id="pdf_selector_<?php echo $i ?>">
                                            <input type="hidden" class="check_pdf_validation" name="dimesion_pdf_<?php echo $i ?>" id="dimesion_pdf_<?php echo $i ?>" value="<?php echo $pdf_url ? $pdf_url : 0; ?>">
                                            <img onclick="<?php echo $removeImg ?>" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                        </div>
                                    </div>
                                    <canvas width="500" height="200" style="display:none;" id="pdfViewer_<?php echo $i; ?>">
                                    </canvas>
                                    <div  class="col-lg-6 col-sm-12 col-xs-12">
                                        <div class="ulpading_img_size_3_1">
                                            <div class="row">
                                                <label ant-id="<?php echo $i ?>" class="upload-button_new1 after_102 btn cmn_btn1 f_s2 pdf_remove_select<?php echo $i ?>" onclick="<?php echo $removeImg; ?>" id="another_select_1" style="<?php echo $b_upload_hide; ?>">
                                                    <i class="fa_icon icon-upload-alt margin-correction"></i> <i class="fa fa-spinner fa-spin" id="loader_<?php echo $i; ?>" style="display:none;"></i> Upload pdf
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>

                    <!-- <-new changes for space-> -->

                    <?php if (!empty($venue_space)) { ?>
                        <input type="hidden" id="total_space" name="total_space" value="<?php echo count($venue_space); ?>">
                        <?php
                        foreach ($venue_space as $key => $value) {
                            $space = $value;
                            $cnt = $key + 1;
                            ?>
                            <div id="space_div_<?php echo $cnt; ?>">

                                <input type="hidden" name="space_id<?php echo $key; ?>" value="<?php echo $space->space_id; ?>">

                                <div class="col-sm-12 profile_row das-2">
                                    <div class="row top_background"><h4>Space <?php echo inWord($cnt); ?></h4>
                                        <span space_id="<?php echo $space->space_id; ?>" data-cnt="<?php echo $cnt; ?>" class="remove_space" >Remove Space</span>
                                    </div>
                                    <div class="row">

                                        <div class="col-md-12 margin_set_input">
                                            <label class="lbl_class" for="space_name<?php echo $key; ?>">Name</label>
                                            <input type="text" class="form-control" id="space_name<?php echo $key; ?>" name="space_name<?php echo $key; ?>" value="<?php echo $space->space_name; ?>" data-rule-required="true">
                                        </div>

                                        <div class="col-md-6 margin_set_input">
                                            <label class="lbl_class" for="space_min_guest<?php echo $key; ?>">Minimum guest numbers</label>
                                            <input type="text" class="form-control number_allow_only" id="space_min_guest<?php echo $key; ?>" name="space_min_guest<?php echo $key; ?>" value="<?php echo $space->space_min_guest; ?>" data-rule-lessThan="#space_max_guest<?php echo $key; ?>" data-rule-number="true" data-rule-required="true">
                                        </div>
                                        <div class="col-md-6 margin_set_input">
                                            <label class="lbl_class" for="space_max_guest<?php echo $key; ?>">Maximum guest numbers</label>
                                            <input type="text" class="form-control number_allow_only" id="space_max_guest<?php echo $key; ?>" name="space_max_guest<?php echo $key; ?>" value="<?php echo $space->space_max_guest; ?>" data-rule-greaterThan="#space_min_guest<?php echo $key; ?>" data-rule-number="true" data-rule-required="true">
                                        </div>

                                        <div class="col-md-12 text-left margin_set_input">
                                            <label class="text-left" for="space_details<?php echo $key; ?>">Details</label>
                                            <textarea data-rule-maxlength="1200" maxlength="1200" rows="4" class="form-control overview_textarea textare_root fm-field" id="space_details<?php echo $key; ?>" name="space_details<?php echo $key; ?>" data-rule-required="true" placeholder="This is a short introductory overview that describes your venue. &#10;Max 1200 words."><?php echo $space->space_details; ?></textarea>
                                        </div>
                                        <?php
                                        $upload_key = $key + 6;
                                        $url = '';
                                        if (!empty($space->space_image)) {
                                            $url = base_url('uploads/venue_spaces') . '/' . $space->space_image;
                                        }
                                        ?>
                                        <div class="col-md-12 margin_top_row_second_106">
                                            <div class="ulpading_img_size_3">
                                                <img style="display:<?Php echo ($url) ? 'block' : 'none'; ?>" id="show_image_<?php echo $upload_key; ?>" img-id="<?php echo $upload_key; ?>" class="dropzone" src="<?php echo $url ?>">
                                                <input type="file" onclick="this.value = null;" data-id="<?php echo $upload_key; ?>" id="image_selector_<?php echo $upload_key; ?>" class="file-selector fm-field image_selector" name="space_image<?php echo $upload_key; ?>">
                                                <input type="hidden" name="dimesion_image_<?php echo $upload_key; ?>" id="dimesion_image_<?php echo $upload_key; ?>" value="0">
                                                <img class="remove_image" onclick="removeImage(3, '<?php echo (isset($space->space_id)) ? encrypt_decrypt('encrypt', $space->space_id) : 0; ?>', <?php echo (isset($space->space_id)) ? 1 : 2; ?>, <?php echo $upload_key; ?>)" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                            </div>

                                            <div class="ulpading_img_size_3_1">
                                                <div class="row">
                                                    <span id="fileselector">
                                                        <label ant-id="<?php echo $upload_key; ?>" class="upload-button_new after_102">
                                                            <input type="hidden" name="image<?php echo $upload_key; ?>" value="">
                                                            <i class="fa_icon icon-upload-alt margin-correction"></i> Upload image
                                                        </label>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-sm-12 profile_row fountion_5">
                                    <div class="row top_background text-left">
                                        <h4>Space <?php echo inWord($cnt); ?> - Event types</h4>
                                    </div>
                                    <div class="row margin_top_row_second_106">
                                        <div class="form-check form-check-inline">

                                            <?php
                                            $event_arr = array();

                                            if (!empty($space)) {
                                                if (!empty($space->space_events)) {
                                                    $event_arr = explode(',', $space->space_events);
                                                }
                                            }

                                            if (!empty($event_types)) {
                                                foreach ($event_types as $e_type) {
                                                    ?>
                                                    <div class="col-md-6 text-left pass">

                                                        <label class="set_label_venu">
                                                            <?php
                                                            $checked_event = '';
                                                            if (in_array($e_type->id, $event_arr)) {
                                                                $checked_event = 'checked';
                                                            }
                                                            ?>
                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                <input type="checkbox" type="checkbox" name="space_events<?php echo $key; ?>[]" value="<?php echo $e_type->id; ?>" <?php echo $checked_event; ?>>
                                                                <small></small>
                                                            </label>



                                                            <div class="dolor_icon size_set_ic">
                                                                <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->image; ?>"></div>
                                                            <span><?php echo $e_type->name; ?></span>


                                                        </label>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_6">
                                    <div class="row top_background text-left">
                                        <h4>Space <?php echo inWord($cnt); ?> - Facilities</h4>
                                    </div>
                                    <div class="row margin_top_row_second_106">
                                        <div class="form-check form-check-inline">

                                            <?php
                                            $facility_arr = array();

                                            if (!empty($space)) {
                                                if (!empty($space->space_facilities)) {
                                                    $facility_arr = explode(',', $space->space_facilities);
                                                }
                                            }

                                            if (!empty($facilities)) {
                                                foreach ($facilities as $f_val) {
                                                    ?>
                                                    <div class="col-md-6 text-left pass_1">
                                                        <label class="set_label_venu">
                                                            <?php
                                                            $checked_facility = '';
                                                            if (in_array($f_val->id, $facility_arr)) {
                                                                $checked_facility = 'checked';
                                                            }
                                                            ?>
                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                <input type="checkbox" name="space_facilities<?php echo $key; ?>[]" value="<?php echo $f_val->id; ?>" <?php echo $checked_facility; ?>>
                                                                <small></small>
                                                            </label>
                                                            <div class="dolor_icon size_set_ic">
                                                                <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->image; ?>">
                                                            </div>
                                                            <span><?php echo $f_val->name; ?></span>

                                                        </label>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_6">
                                    <div class="row top_background text-left">
                                        <h4>Space <?php echo inWord($cnt); ?> - Features</h4>
                                    </div>
                                    <div class="row margin_top_row_second_106">
                                        <div class="form-check form-check-inline">

                                            <?php
                                            $feature_arr = array();

                                            if (!empty($space)) {
                                                if (!empty($space->space_features)) {
                                                    $feature_arr = explode(',', $space->space_features);
                                                }
                                            }

                                            if (!empty($features)) {
                                                foreach ($features as $feat_val) {
                                                    ?>
                                                    <div class="col-md-6 text-left pass_1">
                                                        <label class="set_label_venu">
                                                            <?php
                                                            $checked_feature = '';
                                                            if (in_array($feat_val->id, $feature_arr)) {
                                                                $checked_feature = 'checked';
                                                            }
                                                            ?>
                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                <input type="checkbox" name="space_features<?php echo $key; ?>[]" value="<?php echo $feat_val->id; ?>" <?php echo $checked_feature; ?>>
                                                                <small></small>
                                                            </label>
                                                            <div class="dolor_icon size_set_ic">
                                                                <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->image; ?>">
                                                            </div>
                                                            <span><?php echo $feat_val->name; ?></span>
                                                        </label>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }
                    ?>
                    <div id="append2divspace">
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-md-12 margin_top_but_102">
                        <div class="row">
                            <span class="Plus_102">+</span><span class="add_another_102" id="add-an-1_space">Add another space</span> 
                        </div>
                    </div>
                    <input type="hidden" id="total_another" name="total_another" value="0">
                    <a class="cancel_button_venue_catering create_map" id="update_venue_only" href="javascript:void(0)">Update venue</a>
                    <a class="cancel_button_venue_catering" href="<?php echo site_url('admin/venue_catering') ?>">Cancel</a>
                </form>
            </div>
            <div class="modal fade remove_confirmation" id="remove_confirmation" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title pull-left" id="modalLabel">Confirm Remove</h4>
                        </div>
                        <div class="modal-body crop_model_body">
                            <p class="content_are">Are you want to remove this</p>
                            <input type="hidden" id="remove_id">
                            <input type="hidden" id="remove_cnt">
                            <input type="hidden" id="space_active">
                        </div>
                        <div class="modal-footer border_remove_top">
                            <button id="remove_confirmed" class="btn btn-primary but_crope Confirm_button" type="button">Confirm</button>
                            <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php $this->load->view('models/image_cropping'); ?>
            <script src="https://mozilla.github.io/pdf.js/build/pdf.js"></script>
            <script>
                                            $('.upload-button_new1').unbind().on('click', function (e) {
                                                e.preventDefault();
                                                var id = $(this).attr('ant-id');
                                                $('#pdf_selector_' + id).trigger('click');
                                            });

                                            // Loaded via <script> tag, create shortcut to access PDF.js exports.
                                            var pdfjsLib = window['pdfjs-dist/build/pdf'];
                                            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://mozilla.github.io/pdf.js/build/pdf.worker.js';
                                            $('.pdf_selector').on("change", function (e) {
                                                var file = e.target.files[0];
                                                var cnt = $(this).data('id');
                                                var fileName = $(this).val();
                                                var pdf_id = $(this).data('id');
                                                var a = (this.files[0].size);
                                                if (a > 2000000) {
                                                    $('.pdf_msg_' + pdf_id).text('Maximum size exceeded. Please upload a pdf less than 2MB.').css('color', 'red');
                                                    return false;
                                                } else {
                                                    $('.pdf_msg_' + pdf_id).text('');
                                                }
                                                $('.pdf_remove_select' + cnt).show();
                                                var pdfTitle = $('#pdf_title_' + cnt).val();
                                                if (pdfTitle == '') {
                                                    var fileName = e.target.files[0].name;
                                                    var fileWithExt = fileName.substr(0, fileName.lastIndexOf('.'));
                                                    var pdfTitle = $('#pdf_title_' + cnt).val(fileWithExt);
                                                    var titleName = $('#pdf_title_name_' + cnt).val(fileWithExt);
                                                }
                                                if (file.type == "application/pdf") {
                                                    var fileReader = new FileReader();
                                                    fileReader.onload = function () {
                                                        var pdfData = new Uint8Array(this.result);
                                                        var loadingTask = pdfjsLib.getDocument({
                                                            data: pdfData
                                                        });
                                                        loadingTask.promise.then(function (pdf) {
                                                            var pageNumber = 1;
                                                            pdf.getPage(pageNumber).then(function (page) {
                                                                var scale = 1.5;
                                                                var viewport = page.getViewport({
                                                                    scale: scale
                                                                });
                                                                var canvas = $("#pdfViewer_" + cnt)[0];
                                                                var context = canvas.getContext('2d');
                                                                canvas.height = viewport.height;
                                                                canvas.width = viewport.width;
                                                                var renderContext = {
                                                                    canvasContext: context,
                                                                    viewport: viewport
                                                                };
                                                                var renderTask = page.render(renderContext);
                                                                renderTask.promise.then(function () {
//                                                                    var image = canvas.toDataURL("image/png").replace(/^data:image\/(png|jpg);base64,/, '');
                                                                    var image = canvas.toDataURL("image/png");
                                                                    $('#fc_pdf_image_' + cnt).val(image);
                                                                    $('#pdfimage_' + cnt).attr('src', image);
                                                                    $('#pdfimage_' + cnt).css('display', 'block');
//                                                                    var block = image.split(";");
//                                                                    var contentType = block[0].split(":")[1];
//                                                                    var realData = block[1].split(",")[1];
//                                                                    var hiddenInput = $('#pdf_id_' + cnt).val();
//                                                                    var titleName = $('#pdf_title_name_' + cnt).val();
//                                                                    var blob = b64toBlob(realData, contentType);
//                                                                    var form = $('#msform')[0];
//                                                                    var formData = new FormData(form);
//                                                                    formData.append('fc_pdf_image_' + cnt, blob);
//                                                                    formData.append('pdf_title_' + cnt, titleName);
//                                                                    formData.append('pdf_id', hiddenInput);
//                                        saveToDB('FNC_Add_Venue/venue_details_add_update', 'venue_details_form', formData, cnt);
                                                                    var remove_attr = $('#pdf_remove_select' + pdf_id).trigger('click');
                                                                });
                                                            });
                                                        }, function (reason) {
                                                            console.error(reason);
                                                        });
                                                    };
                                                    fileReader.readAsArrayBuffer(file);
                                                }
                                            });

                                            function b64toBlob(b64Data, contentType, sliceSize) {
                                                contentType = contentType || '';
                                                sliceSize = sliceSize || 512;

                                                var byteCharacters = atob(b64Data);
                                                var byteArrays = [];

                                                for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                                                    var slice = byteCharacters.slice(offset, offset + sliceSize);

                                                    var byteNumbers = new Array(slice.length);
                                                    for (var i = 0; i < slice.length; i++) {
                                                        byteNumbers[i] = slice.charCodeAt(i);
                                                    }

                                                    var byteArray = new Uint8Array(byteNumbers);

                                                    byteArrays.push(byteArray);
                                                }

                                                var blob = new Blob(byteArrays, {
                                                    type: contentType
                                                });
                                                return blob;
                                            }

                                            function removePdf(fc_pdf_type, pdf_id, flush_type, cnt) {
                                                if (flush_type == 1) {
                                                    $.ajax({
                                                        type: "POST",
                                                        url: base_url + 'web/remove_pdf',
                                                        data: {
                                                            'fc_pdf_type': fc_pdf_type,
                                                            'pdf_id': pdf_id,
                                                            'flush_type': flush_type
                                                        },
                                                        dataType: 'JSON',
                                                        success: function (data) {
                                                            if (data.status) {

                                                            }
                                                        },
                                                    });
                                                    $('#pdf_id_' + cnt).val('');
                                                    $('#pdf_title_' + cnt).val('');
                                                    $('#pdf_title_name_' + cnt).val('');
                                                    $('.pdf_remove_select' + cnt).attr("onclick", "removePdf(2, '" + 0 + "', 2, " + cnt + ")");
                                                }
                                                $('.pdf_remove_select' + cnt).css('pointer-events', 'unset');
                                                $('#pdf_selector_' + cnt).val(null);
                                                $('#dimesion_pdf_' + cnt).val('');
                                                $('#pdf_name_' + cnt).val('');
                                                $('#pdf_image_name_' + cnt).val('');
                                                $('#pdf_remove_select' + cnt).hide();
                                                $('.pdf_remove_select' + cnt).show();
                                                $('#pdfimage_' + cnt).hide();
                                                $("#onlImg2_" + cnt).hide();
                                            }
            </script>