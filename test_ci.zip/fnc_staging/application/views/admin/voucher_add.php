<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap-datepicker3.css') ?>"/>
<?php
$voucher_id = $this->uri->segment(3);
// print_r($voucher_id);die;
if (!empty($voucher_id)) {
    $str = 'Edit Voucher';
    $start_date = date('d-m-Y', strtotime($user_record[0]->start_date));
    $end_date = date('d-m-Y', strtotime($user_record[0]->end_date));
    $check_url = site_url('admin/voucher_check_name/') . "?id=" . $user_record[0]->id;
} else {
    $str = 'Add Voucher';
    $check_url = site_url('admin/voucher_check_name');
}
?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header-1"><span><?php echo $str; ?></span>
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <span><?php echo $str; ?></span>
                </div>
                <?php
                if (empty($user_record))
                    $user_record = array();
                ?>
                <div class="panel-body">
                    <div class="row">
                        <form id="voucher_add"  action="<?php echo isset($form_action) ? $form_action : '' ?>" method="post" name='registration' >
                            <input type="hidden" name="id" value="<?php echo $voucher_id ?>">
                            <div class="col-lg-4 col-sm-6 col-xs-12  col-lg-offset-4 col-sm-offset-3">
                                <?php if ($this->session->flashdata('success')): ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>Voucher!</strong> <?php echo $this->session->flashdata('success'); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="form-group col-md-12">
                                    <label>Voucher Code</label>
                                    <input class="form-control" type="text" maxlength='25' id='voucherCode2' name="voucher_code" placeholder="Voucher code"  data-msg-required="Please enter your Voucher Code" data-rule-required="true"  value = "<?php echo isset($user_record[0]->voucher_code) ? $user_record[0]->voucher_code : '' ?>" data-msg-alphanumeric='No special characters allowed' data-msg-remote="This voucher is already exist" data-rule-remote= "<?php echo $check_url ?>" > 
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Description</label>
                                    <textarea name = "description" class="form-control" placeholder="Description" data-rule-required="true" ><?php echo isset($user_record[0]->description) ? $user_record[0]->description : '' ?></textarea>
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Value</label>

                                    <div class="input-group">
                                        <span class="input-group-addon">$</span>
                                        <input class="form-control" type="number" name="value" placeholder="Value" 
                                               data-rule-required="true" value="<?php echo isset($user_record[0]->value) ? $user_record[0]->value : '' ?>" data-rule-validvalue="true">
                                    </div>
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Start date</label>
                                    <input class="form-control" type="text" name="start_date" placeholder="Start date" class="date set_date form-control" id="start_date" data-rule-required="true" value="<?php echo isset($start_date) ? $start_date : '' ?>" >
                                </div>
                                <div class="form-group col-md-12">
                                    <label>End date</label>
                                    <input class="form-control" type="text" name="end_date"  placeholder="End date" id='end_date' class="date set_date form-control"  data-rule-required="true" value="<?php echo isset($end_date) ? $end_date : '' ?>" data-msg-greaterThan = "End date must be greater than Start date">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Total value</label>

                                    <div class="input-group">
                                        <span class="input-group-addon">$</span>
                                        <input class="form-control" type="number" name="total_value" id="totalValue"  placeholder="Total value"  data-rule-required="true" value="<?php echo isset($user_record[0]->total_value) ? $user_record[0]->total_value : '' ?>" data-rule-validvalue="true" >
                                    </div>
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Number of times a user can use a voucher</label>
                                    <input class="form-control" type="number" id="voucher_use" name="voucher_use" placeholder="Voucher use" data-rule-required="true" value="<?php echo isset($user_record[0]->voucher_use) ? $user_record[0]->voucher_use : '' ?>" data-rule-noDecimal='true'/>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6 col-xs-12  col-lg-offset-4 col-sm-offset-3">
                                <div class="col-md-12"><button type="submit" value="add_voucher" class="btn btn-default update_btn">Submit</button>
                                    <a href="<?php echo site_url('admin/voucher'); ?>" class="btn btn-default cancel_btn">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->
<script type="text/javascript" src="<?php echo base_url('admin-assets/js/bootstrap-datepicker.min.js') ?>">

</script>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.validate.min.js') ?>">
</script>
<script type="text/javascript">

    $("#voucher_use").on("keypress keyup blur", function (event) {
        $(this).val($(this).val().replace(/[^\d].+/, ""));
        if ((event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
    });

    $(document).ready(function () {
        $("#start_date").datepicker({
            format: "dd-mm-yyyy",
            todayHighlight: 'TRUE',
            autoclose: true,
            startDate: 'today',
            numberOfMonths: 2,
            maxDate: '+1M'
        }).on('changeDate', function (selected) {
            var minDate = new Date(selected.date.valueOf());
            $('#end_date').datepicker('setStartDate', minDate);
        });

        $("#end_date").datepicker({
            format: 'dd-mm-yyyy',
            autoclose: true,
        }).on('changeDate', function (selected) {
            var maxDate = new Date(selected.date.valueOf());
            $('#start_date').datepicker('setEndDate', maxDate);
        });

        $.validator.addMethod('le', function (value, element, param) {
            return this.optional(element) || parseFloat(value) <= parseFloat($(param).val());
        }, 'Invalid value');


        $("form[name='registration']").validate({
            rules: {
                voucher_code: {
                    required: true,
                    minlength: 6,
                    alphanumeric: true
                },
                description: {
                    required: true,
                    maxlength: 50,
                },
                value: {
                    required: true,
                    le: '#totalValue'
                },
                start_date: {
                    required: true,

                },
                end_date: {
                    required: true,
                },

                total_value: {
                    required: true,
                },
                voucher_use: {
                    required: true,

                }
            },

            messages: {
                voucher_code: {
                    required: "Enter your voucher code",
                    minlength: "Your voucher code must be at least 6 characters long"
                },
                description: {
                    required: "Please Enter a description",
                    maxlength: "description should be maxium 50 characters"
                },
                value: {
                    required: "Please Enter a value",
                    le: 'Value must be less than or equal to Total Value'
                },
                start_date: {
                    required: "Please Enter  start date",
                },
                end_date: {
                    required: "Please Enter end date",
                },
                total_value: {
                    required: "Please Enter a total value",
                },
                voucher_use: {
                    required: "Please Enter some value ",

                }
            },

            submitHandler: function (form) {
                form.submit();
            }
        });
    });
</script>


<style type="text/css">
    .navbar-default.sidebar{
        height:47vw !important;
    }
    body{
        background: #fff !important;
    }
    @media(max-width: 767px){
        .navbar-default.sidebar{  height:100% !important;
        }}
</style>
