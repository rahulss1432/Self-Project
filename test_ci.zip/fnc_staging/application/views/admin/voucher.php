<div id="page-wrapper">
    <div class="row">
        <div class="col-md-12 ">
            <h1 class="page-header">Voucher
                <a class="btn btn-success new pull-right" href="<?php echo base_url('admin/voucher_history') ?>">Voucher history</a>
                <a class="btn btn-success new pull-right" style="margin-right:5px;" href="<?php echo base_url('admin/voucher_add') ?>">Add Voucher</a>
            </h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Vouchers list</div>
                <ul class="Type_select">
                    <li>
                        <label>Action</label>
                        <select id= "new_one" >
                            <option>Please Select</option>
                            <option  value="all_srch">All</option>
                            <option  value="Archive_srch">Archived</option>
                        </select>
                    </li>
                </ul>
                <div class="panel-body">
                    <table width="100%" class="table table-striped table-bordered table-hover voucher_td_pad" id="table">
                        <thead>
                            <tr>
                                <th class="desktop">Voucher Code</th>
                                <th class="none">Description</th>
                                <th class="desktop">Value</th>
                                <th  class="desktop">Start Date</th>
                                <th  class="desktop">End Date</th>
                                <th  class="desktop">Total Value</th>
                                <th  class="desktop">Status</th>
                                <th class="none">Number of times a user can use a voucher</th>
                                <th class="none">First redeemed</th>
                                <th class="none">Last redeemed</th>
                                <th class="none"> Total redeemed count  </th>
                                <th class="none">Total redeemed value</th>
                                <th  class="desktop">Action</th>
                            </tr>
                        </thead> 
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
            <!--  </div>
         </div>
       </div> -->
       <!-- <script type="text/javascript" src="<?php echo base_url('admin-assets/js/bootstrap-datepicker.min.js') ?>"></script> -->
            <div class="modal fade remove_confirmation" id="remove_confirmation" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalLabel">Confirm Remove</h5>
                        </div>
                        <div class="modal-body crop_model_body">
                            <p class="content_are">Are you want to sure Archive this?</p>
                            <input type="hidden" id="remove_id" >
                            <input type="hidden" id="remove_cnt">
                        </div>
                        <div class="modal-footer_1">
                            <button id="remove_confirmed" class="btn btn-primary but_crope Confirm_button" type="button">Confirm</button>
                            <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
            <script type="text/javascript">
                var table;
                $(document).ready(function () {
                    var table = $('#table').DataTable({
                        dom: 'l<"#add">frtip',
                        "bPaginate": true,
                        "bLengthChange": true,
                        "bFilter": true,
                        "bSort": true,
                        "bInfo": false,
                        "bSearchable": true,
                        "bAutoWidth": false,
                        "bProcessing": true,
                        "bServerSide": true,
                        "responsive": true,
                        "sAjaxSource": "<?php echo $table_data_source ?>",
                        "aoColumnDefs": [{"bSortable": false, "aTargets": [12]}]
                    });
                });
                function UpdateVoucher(id, voucher_status) {
                    var url = "<?php echo site_url('admin/update_voucher_status') ?>";
                    $.ajax({
                        url: url,
                        type: "POST",
                        data: {id: id, voucher_status: voucher_status},
                        dataType: "JSON",
                        success: function (data)
                        {
                            $('#table').DataTable().ajax.reload();

                        }
                    });
                }
                function DeleteVoucher(id) {
                    var url = "<?php echo site_url('admin/delete_voucher') ?>";
                    $.ajax({
                        url: url,
                        type: "POST",
                        data: {id: id},
                        dataType: "JSON",
                        success: function (data)
                        {
                            $('#table').DataTable().ajax.reload();

                        }
                    });
                }

                //   function ArchiveFnc(id){
                //    if(confirm("Are you sure want to move Archive this?"))  
                //    {  
                //     $.ajax({  
                //       url:"<?php echo base_url(); ?>admin/archive_single_voucher",  
                //       method:"POST",  
                //       data:{id:id},  
                //       success:function(data)  
                //       {  
                //         $('#table').DataTable().ajax.reload();
                //       }  
                //     });  
                //   }  
                //   else  
                //   {  
                //     return false;       
                //   }  
                // }
                $(document).on("change", "#new_one", function () {
                    // alert();
                    var is_deleted = $(this).val();
                    var srch_str = '?is_deleted=' + is_deleted;
                    var cntrl_url = base_url + 'admin/voucher_ajax_list' + srch_str;
                    $('#table').data('dt_params', {name: 'test'});
                    $('#table').DataTable().ajax.url(cntrl_url);
                    $('#table').DataTable().draw();


                });

                jQuery(document).on("click", ".new_pop", function (e) {
                    $("#remove_confirmation").modal();
                });

                function ArchiveFnc(id) {
                    $("#remove_confirmed").click(function () {
                        $('#remove_confirmation').modal('hide');
                        $.ajax({
                            url: "<?php echo base_url(); ?>admin/archive_single_voucher",
                            method: 'POST',
                            dataType: 'json',
                            data: {id: id},
                            success: function (data) {
                                $('#table').DataTable().ajax.reload();

                            }
                        });
                    });
                }

            </script>
            <style type="text/css">
                .new_class {
                    width: 950px !important;
                }
                .type_tow ul li{
                    float:left;
                    list-style: none;
                    margin-right: 15px !important;
                }
                .type_tow ul li .error {
                    position: absolute !important;
                    left: 0 !important;
                    margin-top: 20px;
                    margin-left: 13px;
                }
                .type_tow ul{
                    padding-left: 0px !important;
                }
                .type_tow .regular-checkbox {
                    width: 20px !important;
                    height: 20px !important;
                    border-radius: 24px !important;
                    margin: 0px 5px;
                }

                .type_tow .regular-checkbox input:checked~small:after{
                    background: url(http://onesheepventures.com/staging/functions/assets/images/check-symbol_new.png) no-repeat;
                    color: #46b8da;
                    font-size: 18px;
                    margin-top: 3px;
                    margin-left: 2px;
                    content: "";
                    text-align: center;
                    opacity: 0.6;
                    background-size: 80%;
                }
                .type_tow{
                    width: 100%;
                    display: table;
                    margin-bottom: 30px;
                }
                label#bus_auth_notes-error {
                    margin-bottom: 15px;
                }
            </style>