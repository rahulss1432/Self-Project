<div id="page-wrapper">
  <div class="row">
    <div class="col-md-12 ">
      <h1 class="page-header">F&C  <a class="btn btn-success new pull-right" href="javascript:;">Add</a></h1>
    </div>

  </div>
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
       <div class="panel-heading ">Fnc list</div>
       <div class="panel-body">
        <table width="100%" class="table table-striped table-bordered table-hover" id="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Type</th>
              <th>Image</th>
              <th>White Image</th>
              <th>Status</th>
              <th>Description</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>
<div class="modal fade " tabindex="-1" role="dialog" aria-labelledby="myModalLabel" id="newsss_model">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">F&C</h4>
      </div>
      <div class="modal-body">
        <form role="form" action="" method="post" enctype="multipart/form-data" id="myform" >
          <input type="hidden"  id='fnc_id' value="0">
          <p>

            <div class="div_12">
            <label>Types :</label>
            <select name="type"  data-rule-required="true" class="form-control" id="type">
              <option value="">---Select---</option>
              <option value="facilities" >Facilities</option>
              <option value="features">Features</option>
              <option value="event_type">Event type</option>
              <option value="function_type">Function type</option>
              <option value="menus">Menus</option>
              <option value="cuisine">Cuisine</option>
              <option value="services">Services</option>
            </select>
            <span id="error_pass"></span>
            </div>
           
            <div class="div_12">
            <label>Names :</label>
            <input type="text" name="name" data-rule-required="true" placeholder="F&c name" class="form-control" id="name" autocomplete="off">
            <span id="error_pass"></span>
            <div id="image_changes">
             <img id="image_n" src="#" name="img_name"/>
           </div>
           <input type="hidden" id="img_name" name="img_name" value="">
           </div>
          
            <div class="div_12">
           <label>Image :</label>
           <input type="file" name="image" data-rule-required="true"  id="image">
           <span id="error_pass"></span>
           </div>

         
           <div class="div_12">
             <label>Status :</label>
             <span class="set_radio_but"> Active<input type="radio" class="my_status" name="status" data-rule-required="true" value="1" id="active" checked="checked" ></span>
             <span class="set_radio_but">Deactive<input type="radio" class="my_status" name="status" value="0" id="deactive"></span>
             </div>
          
           <div class="div_12">
           <label>Short Description :</label>
           <textarea name="short_desc" cols="20" rows="2" class="form-control" id="short_desc" placeholder="Short Description" ></textarea>
           </div>

           <button type="button" class="btn btn-default sub_but" onclick="submitForm()">Submit Button</button>

         </p>
       </div>
     </div>
   </div>
 </div>
 <script>
  function submitForm(){
   var fnc_id = $('#fnc_id').val();
   if(fnc_id>0) {
     var url = "<?php echo site_url('admin/fnc_list_update')?>";
     $('#image').rules('add', {
    required: false   // overwrite an existing rule
  });
   }else{
    var url = "<?php echo site_url('admin/fnc_types_add')?>";
  }
  if ($("#myform").valid()) {   
    var form_data = new FormData(document.getElementById("myform"));
    $.ajax({
      url: url,
      type: "POST",
      data: form_data,
      processData: false,  
      contentType: false   
    }).done(function( data ) {
      var table = $('#table').DataTable();
      table.ajax.reload();
      console.log(data);
      $('#myform')[0].reset();
      $("#newsss_model").click();
      $('#fnc_id').val('');

      

    });
    return false;     
  }
}
function editForm(id){
  save_method = 'update';
  $('#myform')[0].reset(); 
  var img_url = '<?php echo site_url('uploads/fnc_types'); ?>';
  $.ajax({
    url : "<?php echo site_url('admin/fnc_list_edit')?>/" ,
    type: "POST",
    data: {id: id},
    dataType: "JSON",
    success: function(data){
      console.log(data[0]);
      $('#myform')[0].reset();
      $("#fnc_id").attr("name","id");
      $("#fnc_id").val(data[0].id);
      $('select[name="type"]:first').val(data[0].type);
      $('#name').val(data[0].name);
      var res = data[0];
      var img_src = img_url + '/' + res.image;
      $("#image_n").attr("src", img_src);
      $("#img_name").val(res.image);
      if(data[0].status == 1){
        $('#active').prop('checked', true);
      }else{
       $('#deactive').prop('checked', true); 
     }
     $('#short_desc').val(data[0].short_desc);
     $('#newsss_model').modal('show'); 
   },
   error: function (jqXHR, textStatus, errorThrown){
    alert('Error get data from ajax');
  }
});
}
</script>
<script type="text/javascript">
  var table;
  $(document).ready(function() { 
    table = $('#table').DataTable({ 
      "processing": true,
      "serverSide": true, 
      "responsive": true,
      "order": [],
      "ajax": {
        "url": "<?php echo site_url('admin/ajax_list')?>",
        "type": "POST"
      },

      "columnDefs": [
      { 
        "targets": [5], 
        "orderable": false,
      },
      ],
    });
  });
</script>

<script>
  $(document).ready(function(){
    $(".new").click(function(){
      $("#newsss_model").modal();
      var validator = $("#myform").validate();
      validator.resetForm();
      $('#fnc_id').removeAttr('name');
      $('#fnc_id').val();
      $('#image_changes').css('display','none');
      clear_form_inputs('myform');

    });
    jQuery(document).on("click", ".pop_edit", function (e) {  
     $("#newsss_model").modal();
     var id =  $(this).attr('data-id');
     $('#image_changes').css('display','block');
   });

  });
  function clear_form_inputs(form_id){ 
    $(':input','#'+form_id).closest('form').find("input[type=text], textarea , select,file").val("");
    var $el = $('#image');
    $el.wrap('<form>').closest('form').get(0).reset();
    $el.unwrap();
  }
</script>










