<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        
        if(!$this->session->userdata('super_admin'))
            redirect('login/admin_login');
        
        $this->load->model('type_model', 'fnc_types');
        $this->load->model('feedback_model', 'feedback');
        $this->load->model('catering_model', 'catering_model');
    }
    
    public function index() {
        redirect('admin/dashboard');
    }
    
    public function logout() {
        $this->session->sess_destroy();
        redirect('login/admin_login');
    }
    
    public function dashboard() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $this->load->view('admin/dashboard');
        $this->load->view('admin/footer');
    }
    
    public function users() {
        $data['user_list'] = $this->basic_model->get_record_where('users');
        
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $this->load->view('admin/users', $data);
        $this->load->view('admin/footer');
    }
    
    public function edit_user($user_id) {
        $where = "user_id = '" . $user_id . "'";
        $data['user_data'] = $this->basic_model->get_record_where('users', $column = '', $where);


        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $this->load->view('admin/edit_user', $data);
        $this->load->view('admin/footer');
    }

    public function update_user() {
        if ($this->input->post()) {
            $userData = $this->input->post();
            $user_id = $this->input->post('user_id');
            $config['upload_path'] = './uploads/users/';
            $config['allowed_types'] = 'gif|jpg|png';

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if ($this->upload->do_upload('user_image')) {
                $data = array('upload_data' => $this->upload->data());
                $image_url = base_url() . '/uploads/users/' . $data['upload_data']['file_name'];
                $userData['user_image'] = $image_url;
            }

            $where = "user_id = '" . $user_id . "'";
            $this->basic_model->update_records('users', $userData, $where);
            $this->edit_user($user_id);
        }else{
            redirect('admin/update_user');
        }
    }
    
    function email_existance() {
        if ($this->input->get('user_email')) {
            $email = $this->input->get('user_email');
            $user_id = $this->input->get('user_id');
            $where = "user_email = '" . $email . "' and user_id != '".$user_id."'";
            $result = $this->basic_model->get_record_where('users', $column = '', $where);
            if (!empty($result)) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
    }

    function change_password() {
        if ($this->input->post('user_id')) {
            $user_id = $this->input->post("user_id");
            $data = array(
                'user_password' => md5($this->input->post("password"))
                );
            $where = "user_id='" . $user_id . "'";
            $this->basic_model->update_records('users', $data, $where); 
        }
    }
    
    //--------------------------FNC Types------------------------------------//
    
    // Listing
    public function fnc_list() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $this->load->view('admin/fnc_types_view_new');
        $this->load->view('admin/footer');
    }
    
    // Ajax to create list
    public function ajax_list() {
        $list = $this->fnc_types->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $fnc_types) {
            $no++;
            $img = base_url("uploads/fnc_types/" . $fnc_types->image);
            $row = array();
            $row[] = $fnc_types->name;
            $row[] = ucwords(str_replace("_", " ", $fnc_types->type));
            $row[] = '<img width=50px; height=50px; src="' . $img . '">';
            if($fnc_types->status == 1) $status='Active'; else $status= 'Deactive';
            $row[] = $status;
            $row[] = $fnc_types->short_desc;
            $edit_fnc = site_url('admin/fnc_types_edit/' . $fnc_types->id);
            $row[] = '<a data-id="' . $fnc_types->id . '"  class="btn btn-primary pop_edit" href="javascript:;" onclick="editForm(' . $fnc_types->id . ')">Edit</a>';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->fnc_types->count_all(),
            "recordsFiltered" => $this->fnc_types->count_filtered(),
            "data" => $data,
            );
        echo json_encode($output);
    }
    
    // Ajax function to add fnc type
    public function fnc_types_add() {
        $this->load->library("form_validation");
        if ($this->input->post()) {
            $this->form_validation->set_rules("name", "fnc name", "required|is_unique[fnc_types.name]");
            $this->form_validation->set_rules("type", "fnc types", "required");
            $this->form_validation->set_rules("status", "fnc status", "required");
            if (empty($_FILES['image']['name'])) {
                $this->form_validation->set_rules('image', 'image', 'required');
            }if ($this->form_validation->run() == FALSE) {

            } else {
                $config["upload_path"] = "uploads/fnc_types";
                $congig["max_size"] = 2048;
                $config["allowed_types"] = "jpg|png|jpeg";
                $config['overwrite'] = FALSE;
                $this->load->library("upload", $config);
                $this->upload->initialize($config);
                if (!$this->upload->do_upload('image')) {
                    $error = $this->upload->display_errors();
                } else {
                    $img_data = $this->upload->data();
                    $file_name = $img_data['file_name'];
                }
                $insert_data = array('name' => $this->input->post('name'),
                    'type' => $this->input->post('type'),
                    'status' => $this->input->post('status'),
                    'short_desc' => $this->input->post('short_desc'));
                if (!empty($file_name)) {
                    $insert_data['image'] = $file_name;
                }
                $id = $this->basic_model->insert_records('fnc_types', $insert_data);
                if ($id > 0) {
                    $this->session->set_flashdata('success', 'Facility added successfully');
                } else {
                    $this->session->set_flashdata('error', 'Error in facility insertion');
                }
                redirect('admin/fnc_list');
            }
        }
    }
    
    // Ajax to get data from DB
    public function fnc_list_edit() {
        $id = $this->input->post('id');
        if (!empty($id)) {
            $where = array('id' => $id);
            $this->load->model("basic_model");
            $data = $this->basic_model->get_record_where('fnc_types', '', $where);
            echo json_encode($data);
        }
    }
    
    // Ajax function to update Fnc type
    public function fnc_list_update() {
        $data = array();
        if ($_FILES) {
            $config["upload_path"] = "uploads/fnc_types";
            $congig["max_size"] = 2048;
            $config["allowed_types"] = "jpg|png|jpeg";
            $config['overwrite'] = FALSE;
            $this->load->library("upload", $config);
            $this->upload->initialize($config);
            if ($this->upload->do_upload('image') == false) {
                $error = $this->upload->display_errors();
                $this->session->set_flashdata("msg", $error);
            } else {
                $file_name = $this->upload->data("image");
                $data['image'] = $this->upload->data('file_name');
            }
        }

        $data['type'] = $this->input->post('type');
        $data['name'] = $this->input->post('name');
        $data['status'] = $this->input->post('status');
        $data['short_desc'] = $this->input->post('short_desc');


        $where = array('id' => $this->input->post('id'));

        $this->load->model("basic_model");
        $this->basic_model->update_records('fnc_types', $data, $where);
    }
    
    //--------------------------------------------------------------//
    
    //-------------------------Feedback section-------------------------------------//
    
    // Feedback list
    public function feedback_list() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $this->load->view('admin/feedback_view');
        $this->load->view('admin/footer');
    }
    
    // Ajax of listing of feedback
    public function feedback_ajax_list() {
        $list = $this->feedback->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $feedback) {
            $no++;
            $row = array();
            $row[] = $feedback->user_firstname . ' ' . $feedback->user_lastname;
            $row[] = $feedback->fc_business_name;
            $row[] = $feedback->f_rating_cleanliness;
            $row[] = $feedback->f_rating_accuracy;
            $row[] = $feedback->f_rating_comm;
            $row[] = $feedback->f_text;
            if ($feedback->f_status == 0) {
                $new = 1; $dis =3;
                $row[] = '<a  class="btn btn-success" href="javascript:;" onclick="UpdateFeedback(' . $feedback->f_id . ',' . $new . ')">Approve</a> <a  class="btn btn-success" href="javascript:;" onclick="UpdateFeedback(' . $feedback->f_id . ',' . $dis . ')">Dispute</a>    <a data-id="' . $feedback->f_id . '"  class="btn btn-primary pop_edit" href="javascript:;" onclick="editFeedback(' . $feedback->f_id . ')">Edit</a>';
            }
            if ($feedback->f_status == 1) {
                $deny = 2; 
                $row[] = '<a href="javascript:;" class="btn btn-danger"  onclick="UpdateFeedback(' . $feedback->f_id . ',' . $deny . ')" >Deny</a>    <a data-id="' . $feedback->f_id . '"  class="btn btn-primary pop_edit" href="javascript:;" onclick="editFeedback(' . $feedback->f_id . ')">Edit</a>';
            }
            if ($feedback->f_status == 2) {
                $new = 1;
                $row[] = '<a href="javascript:;" class="btn btn-danger"  onclick="UpdateFeedback(' . $feedback->f_id . ',' . $new . ')" >Approve</a>    <a data-id="' . $feedback->f_id . '"  class="btn btn-primary pop_edit" href="javascript:;" onclick="editFeedback(' . $feedback->f_id . ')">Edit</a>';
            }
            if ($feedback->f_status == 3) {
                $res= 1;
                $row[] = '<a href="javascript:;" class="btn btn-danger"  onclick="UpdateFeedback(' . $feedback->f_id . ',' . $res . ')" >Resolve</a>    <a data-id="' . $feedback->f_id . '"  class="btn btn-primary pop_edit" href="javascript:;" onclick="editFeedback(' . $feedback->f_id . ')">Edit</a>';
            }
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->feedback->count_all(),
            "recordsFiltered" => $this->feedback->count_filtered(),
            "data" => $data,
            );
        echo json_encode($output);
    }
    
    // Update status with approved / deny
    public function feedback_update() {
        if($this->input->post('f_id')){
            $data = array('f_status' => $this->input->post('f_status'));
            $where = array('f_id' => $this->input->post('f_id'));
            $this->load->model("basic_model");
            $my_data = $this->basic_model->update_records('feedback', $data, $where);
            echo "1";
        }
    }
    
    // Get comment of the feedback
    public function feedback_edit() {
        if ($this->input->post('f_id')) {
            $f_id = $this->input->post('f_id');
            $where = array('f_id' => $f_id);
            $this->load->model("basic_model");
            $data = $this->basic_model->get_record_where('feedback', '', $where);
            echo json_encode($data);
        }
    }
    
    // Edit comments of feedback
    public function feedback_all_update() {
        if($this->input->post('f_id')){
            $data = array('f_text' => $this->input->post('f_text'));
            $where = array('f_id' => $this->input->post('f_id'));
            $this->load->model("basic_model");
            $my_data = $this->basic_model->update_records('feedback', $data, $where);
        }
    }
    
    //--------------------------------------------------------------//
    
    public function venue_catering() {
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $this->load->view('admin/venue_catering_view');
        $this->load->view('admin/footer');
    }
    
    public function catering_ajax_list() {
        $list = $this->catering_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $function_catering) {
            $no++;
            $row = array();
            $row[] = $function_catering->fc_business_name;
            $row[] = $function_catering->user_firstname . ' ' . $function_catering->user_lastname;
            $row[] = $function_catering->fc_city;
            $row[] = $function_catering->fc_state;
            $row[] = $function_catering->fc_country;
            $row[] = $function_catering->fc_contact_name;
            $row[] = $function_catering->fc_phone_no;
            $row[] = $function_catering->fc_email;
            if($function_catering->fc_type == 1) {
                $type='Venue'; 
                $url=site_url("admin/edit_venue_catering/");
            }
            else {
                $type= 'Catering'; 
                $url=site_url("admin/edit_catering/");
            }
            $row[] = $type;
            
            if ($function_catering->fc_status == 0) {
                $app = 1;
                $deny = 2;
                $row[] = '<a class="btn btn-success" href="javascript:;"  onclick="UpdateCatering(' . $function_catering->fc_id . ',' . $app . ')">Approve</a> 
                <a class="btn btn-danger" href="javascript:;"  onclick="UpdateCatering(' . $function_catering->fc_id . ',' . $deny . ')">Deny</a> <a data-id="' . $function_catering->fc_id . '"  class="btn btn-primary pop_edit" href=" '. $url.$function_catering->fc_id.'" >Edit</a>' ;
            } elseif ($function_catering->fc_status == 1) {
                $block = 3;
                $row[] = '<a  class="btn btn-warning" href="javascript:;"  onclick="UpdateCatering(' . $function_catering->fc_id . ',' . $block . ')" >Block</a> <a data-id="' . $function_catering->fc_id . '" class="btn btn-primary pop_edit" href=" '. $url.$function_catering->fc_id.'" >Edit</a>';
            } elseif ($function_catering->fc_status == 3) {
                $unblock = 1;
                $row[] = '<a  class="btn btn-info" href="javascript:;"  onclick="UpdateCatering(' . $function_catering->fc_id . ',' . $unblock . ')" >Unblock</a> <a data-id="' . $function_catering->fc_id . '" class="btn btn-primary pop_edit" href=" '. $url.$function_catering->fc_id.'"  >Edit</a>';
            } else {
                $row[] = "";
            }
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->catering_model->count_all(),
            "recordsFiltered" => $this->catering_model->count_filtered(),
            "data" => $data,
            );
        echo json_encode($output);
    }
    
    public function catering_update() {
        if($this->input->post('fc_id')){
            $data = array('fc_status' => $this->input->post('fc_status'));
            $where = array('fc_id' => $this->input->post('fc_id'));
            $this->load->model("basic_model");
            $my_data = $this->basic_model->update_records('function_catering', $data, $where);
            echo "1";
        }
    }

    public function edit_venue_catering($venueID=0) {
        $user_id = $this->session->userdata('user_id');
        if($this->input->post('submit')){
            $data = $this->input->post();
            $venue_id =  $this->input->post('venue');
            $update_data = array('fc_business_name' => $data['venue_business_name'], 'fc_city' => $data['venue_city'], 'fc_state' => $data['venue_state'], 'fc_suburb' => $data['venue_suburb'], 'fc_street' => $data['venue_street'], 'fc_postcode' => $data['venue_postcode'], 'fc_country' => $data['venue_country'], 'fc_lat' => $data['lat'], 'fc_lng' => $data['lng'], 'fc_abn' => $data['venue_abn'], 'fc_contact_name' => $data['venue_contact_name'], 'fc_phone_no' => $data['venue_phone_no'], 'fc_website' => $data['venue_website'], 'fc_email' => $data['venue_email'], 'fc_overview' => $data['venue_overview'], 'fc_details' => $data['venue_details'], 'fc_min_guest' => $data['venue_min_guest'], 'fc_max_guest' => $data['venue_max_guest']);
            
            if($this->input->post('venue_pricing')){
                $update_data['fc_pricing'] = implode(',', $data['venue_pricing']);
            } else {
                $update_data['fc_pricing'] = '';
            }
            
            $where = array('fc_id' => $venue_id);
            
            $this->basic_model->update_records('function_catering', $update_data, $where);

            $venue_details = array();
            
            if($this->input->post('venue_events')){
                $venue_details['vd_events'] = implode(',', $data['venue_events']);
            } else {
                $venue_details['vd_events'] = '';
            }

            if($this->input->post('venue_facilities')){
                $venue_details['vd_facilities'] = implode(',', $data['venue_facilities']);
            } else {
                $venue_details['vd_facilities'] = '';
            }

            if($this->input->post('venue_features')){
                $venue_details['vd_features'] = implode(',', $data['venue_features']);
            } else {
                $venue_details['vd_features'] = '';
            }
            
            $where_details = array('vd_fc_id' => $venue_id);
            
            $this->basic_model->update_records('venue_details', $venue_details, $where_details);
            // echo $this->db->last_query();die;
            
            $img_count = 5;
            
            if($this->input->post('img_count')){
                $img_count = $img_count - $this->input->post('img_count');
                
                // Multi venue images
                $this->load->library('upload');
                
                $dataInfo = array();
                $files = $_FILES;
                $cpt = count($_FILES['venue_image']['name']);
                
                $image_data = array();
                
                for($i = 0; $i < $cpt; $i++){
                    if ($files['venue_image']['size'][$i] != 0){
                        $_FILES['venue_image']['name']= $files['venue_image']['name'][$i];
                        $_FILES['venue_image']['type']= $files['venue_image']['type'][$i];
                        $_FILES['venue_image']['tmp_name']= $files['venue_image']['tmp_name'][$i];
                        $_FILES['venue_image']['error']= $files['venue_image']['error'][$i];
                        $_FILES['venue_image']['size']= $files['venue_image']['size'][$i];
                        
                        $this->upload->initialize($this->set_upload_options());
                        
                        if ( ! $this->upload->do_upload('venue_image')){
                            $error = $this->upload->display_errors();
                        } else {
                            $dataInfo[] = $this->upload->data();
                            
                            $i_data = $this->upload->data();
                            $image_url = $i_data['file_name'];
                            
                            $croped_image_name = 'dimesion_image_' . ($i);

                            if ($this->input->post($croped_image_name) != '0') {

                                $temp_img = $this->input->post($croped_image_name);
                                $image_data[] = array('fc_img_name' => $temp_img, 'fc_id' => $venue_id, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                            } else {
                                $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $venue_id, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                            }
                        }
                    }  
                }
                
                if(!empty($image_data)){
                    $this->basic_model->insert_records('fc_images', $image_data, TRUE);
                }
            }
            
            if($img_count > 0){
                // Multi venue images
                $this->load->library('upload');
                
                for($ic = 0; $ic < $img_count; $ic++){
                    if($_FILES["venue_image$ic"]['size'] != 0){
                        $this->upload->initialize($this->set_upload_options());
                        if ( ! $this->upload->do_upload("venue_image$ic")){
                            $error = $this->upload->display_errors();
                        } else {
                            $dataInfo[] = $this->upload->data();
                            
                            $i_data = $this->upload->data();
                            $i_data = $this->upload->data();
                            $croped_image_name = 'dimesion_image_' . ($ic);

                            if ($this->input->post($croped_image_name) != '0') {

                                $temp_img = $this->input->post($croped_image_name);
                                $image_url = $temp_img;
                            } else {
                                $image_url = $i_data['file_name'];
                            }
                            
                            $image_update = array('fc_img_name' => $image_url, 'fc_img_modified_on' => date('Y-m-d H:i:s'));
                            
                            $where_img = array('fc_img_id' => $data["image$ic"]);
                            
                            $this->basic_model->update_records('fc_images', $image_update, $where_img);
                        }
                    }
                }
            }
            
            redirect('venue/my_venues');
        } else {
            if(!empty($venueID)){
               $venue_id = $venueID;

               $where_fc = array('fc_id' => $venueID);
               $venue = $this->basic_model->get_record_where('function_catering', '', $where_fc);

               if(!empty($venue)){
                $data['venue'] = $venue;

                $where_user = array('user_id' => $user_id);
                $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

                    //--------Basic Venue Details----------//

                $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');

                $where_events = array('type' => 'event_type', 'status' => 1);
                $data['event_types'] = $this->basic_model->get_record_where('fnc_types', '', $where_events);

                $where_facilities = array('type' => 'facilities', 'status' => 1);
                $data['facilities'] = $this->basic_model->get_record_where('fnc_types', '', $where_facilities);

                $where_features = array('type' => 'features', 'status' => 1);
                $data['features'] = $this->basic_model->get_record_where('fnc_types', '', $where_features);

                    //--------Basic Venue Details----------//

                $where_details = array('vd_fc_id' => $venue_id);
                $data['venue_details'] = $this->basic_model->get_record_where('venue_details', '', $where_details);

                $where_images = array('fc_id' => $venue_id);
                $data['venue_images'] = $this->basic_model->get_record_where('fc_images', '', $where_images);

                $this->load->view('admin/header');

                $this->load->view('admin/menu');
                $this->load->view('admin/edit_venue_catering',$data);
                $this->load->view('admin/footer');
            } else {
                redirect('venue/my_venues');
            }
        } else {
            redirect('venue/my_venues');
        }
    }
}
private function set_upload_options() {   
    //upload an image options
    $config = array();
    $config['upload_path'] = './uploads/fc_images/';
    $config['allowed_types'] = 'jpeg|jpg|png';
    $config['max_size']      = '0';
    $config['overwrite']     = FALSE;

    return $config;
}


public function edit_catering($cateringID = 0) {

    $user_id = $this->session->userdata('user_id');
    // print_r($user_id);die;
    if ($this->input->post('submit')) {

        $data = $this->input->post();

        $catering_id =  $this->input->post('catering');
        // print_r($catering_id);

        $update_data = array('fc_business_name' => $data['catering_business_name'], 'fc_city' => $data['catering_city'], 'fc_state' => $data['catering_state'], 'fc_suburb' => $data['catering_suburb'], 'fc_street' => $data['catering_street'], 'fc_postcode' => $data['catering_postcode'], 'fc_country' => $data['catering_country'], 'fc_lat' => $data['lat'], 'fc_lng' => $data['lng'], 'fc_abn' => $data['catering_abn'], 'fc_contact_name' => $data['catering_contact_name'], 'fc_phone_no' => $data['catering_phone_no'], 'fc_website' => $data['catering_website'], 'fc_email' => $data['catering_email'], 'fc_overview' => $data['catering_overview'], 'fc_details' => $data['catering_details'], 'fc_min_guest' => $data['catering_min_guest'], 'fc_max_guest' => $data['catering_max_guest']);
        // echo $this->db->last_query();

        if ($this->input->post('catering_pricing')) {
            $update_data['fc_pricing'] = implode(',', $data['catering_pricing']);
        } else {
            $update_data['fc_pricing'] = '';
        }

        $where = array('fc_id' => $catering_id);

        $this->basic_model->update_records('function_catering', $update_data, $where);

        $catering_details = array();

        if ($this->input->post('catering_function_type')) {
            $catering_details['cd_function_type'] = implode(',', $data['catering_function_type']);
        } else {
            $catering_details['cd_function_type'] = '';
        }

        if ($this->input->post('catering_menus')) {
            $catering_details['cd_menus'] = implode(',', $data['catering_menus']);
        } else {
            $catering_details['cd_menus'] = '';
        }

        if ($this->input->post('catering_cuisine')) {
            $catering_details['cd_cuisine'] = implode(',', $data['catering_cuisine']);
        } else {
            $catering_details['cd_cuisine'] = '';
        }

        if ($this->input->post('catering_services')) {
            $catering_details['cd_services'] = implode(',', $data['catering_services']);
        } else {
            $catering_details['cd_services'] = '';
        }

        $where_details = array('cd_fc_id' => $catering_id);

        $this->basic_model->update_records('catering_details', $catering_details, $where_details);
        // echo $this->db->last_query();die;

        $img_count = 5;

        if ($this->input->post('img_count')) {
            $img_count = $img_count - $this->input->post('img_count');

                // Multi venue images
            $this->load->library('upload');

            $dataInfo = array();
            $files = $_FILES;
            $cpt = count($_FILES['catering_image']['name']);

            $image_data = array();

            for ($i = 0; $i < $cpt; $i++) {
                if ($files['catering_image']['size'][$i] != 0) {
                    $_FILES['catering_image']['name'] = $files['catering_image']['name'][$i];
                    $_FILES['catering_image']['type'] = $files['catering_image']['type'][$i];
                    $_FILES['catering_image']['tmp_name'] = $files['catering_image']['tmp_name'][$i];
                    $_FILES['catering_image']['error'] = $files['catering_image']['error'][$i];
                    $_FILES['catering_image']['size'] = $files['catering_image']['size'][$i];

                    $this->upload->initialize($this->set_upload_options());

                    if (!$this->upload->do_upload('catering_image')) {
                        $error = $this->upload->display_errors();
                    } else {
                        $dataInfo[] = $this->upload->data();

                        $i_data = $this->upload->data();
                        $image_url = $i_data['file_name'];

                        $croped_image_name = 'dimesion_image_' . ($i);

                        if ($this->input->post($croped_image_name) != '0') {

                            $temp_img = $this->input->post($croped_image_name);
                            $image_data[] = array('fc_img_name' => $temp_img, 'fc_id' => $catering_id);
                        } else {
                            $image_data[] = array('fc_img_name' => $image_url, 'fc_id' => $catering_id ,'fc_img_modified_on' => date('Y-m-d H:i:s'));
                        }

                    }
                }
            }

            if (!empty($image_data)) {
                $this->basic_model->insert_records('fc_images', $image_data, TRUE);
            }
        }

        if ($img_count > 0) {
                // Multi venue images
            $this->load->library('upload');

            for ($ic = 0; $ic < $img_count; $ic++) {
                if ($_FILES["catering_image$ic"]['size'] != 0) {
                    $this->upload->initialize($this->set_upload_options());
                    if (!$this->upload->do_upload("catering_image$ic")) {
                        $error = $this->upload->display_errors();
                    } else {
                        $dataInfo[] = $this->upload->data();

                        $i_data = $this->upload->data();

                        $croped_image_name = 'dimesion_image_' . ($ic);

                        if ($this->input->post($croped_image_name) != '0') {

                            $temp_img = $this->input->post($croped_image_name);
                            $image_url =  $temp_img;
                        } else {

                            $image_url = $i_data['file_name'];
                        }


                        $image_update = array('fc_img_name' => $image_url, 'fc_img_modified_on' => date('Y-m-d H:i:s'));

                        $where_img = array('fc_img_id' => $data["image$ic"]);

                        $this->basic_model->update_records('fc_images', $image_update, $where_img);
                    }
                }
            }
        }

        redirect('admin/venue_catering');
    } else {
        if (!empty($cateringID)) {
            $catering_id=$cateringID;
            
            // $catering_id = encrypt_decrypt('decrypt', $cateringID);
            $where_fc = array('fc_id' => $cateringID);
            $catering = $this->basic_model->get_record_where('function_catering', '', $where_fc);

            if (!empty($catering)) {
                $data['catering'] = $catering;

                $where_user = array('user_id' => $user_id);
                $data['user_data'] = $this->basic_model->get_record_where('users', '', $where_user);

                    //--------Basic Venue Details----------//

                $data['price_per_head'] = $this->basic_model->get_record_where_orderby('price_per_head', '', '', 'p_value');

                $where_function_type = array('type' => 'function_type', 'status' => 1);
                $data['function_type'] = $this->basic_model->get_record_where('fnc_types', '', $where_function_type);

                $where_cuisine = array('type' => 'cuisine', 'status' => 1);
                $data['cuisine'] = $this->basic_model->get_record_where('fnc_types', '', $where_cuisine);

                $where_menus = array('type' => 'menus', 'status' => 1);
                $data['menus'] = $this->basic_model->get_record_where('fnc_types', '', $where_menus);

                $where_services = array('type' => 'services', 'status' => 1);
                $data['services'] = $this->basic_model->get_record_where('fnc_types', '', $where_services);

                    //--------Basic Venue Details----------//

                $where_details = array('cd_fc_id' => $catering_id);
                $data['catering_details'] = $this->basic_model->get_record_where('catering_details', '', $where_details);

                $where_images = array('fc_id' => $catering_id);
                $data['catering_images'] = $this->basic_model->get_record_where('fc_images', '', $where_images);

                $where_csr_radius = array('csr_fc_id' => $catering_id);
                $data['catering_radius'] = $this->basic_model->get_record_where('catering_search_radius', 'csr_radius', $where_csr_radius);

                $this->load->view('admin/header');

                $this->load->view('admin/menu');
                $this->load->view('admin/edit_catering',$data);
                $this->load->view('admin/footer');
            }
        }
    }
}


public function search_suburb() {
    if($this->input->post('term')){
        $search_term = $this->input->post('term');

        $where_term = "suburb LIKE '$search_term%'";
        $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);

        $search_result = array();

        if(!empty($coucils)){
            $item_arr = array();

            foreach ($coucils as $key => $value) {
                $item_arr[] = array('id' => $value->id, 'suburb' => $value->suburb, 'postcode' => $value->postcode);
            }

            $search_result['items'] = $item_arr;

            echo json_encode($search_result);
        }
    }
}
public function search_postcode() {
    if($this->input->post('term')){
        $search_term = $this->input->post('term');

        $where_term = "postcode LIKE '$search_term%'";
        $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);

        $search_result = array();

        if(!empty($coucils)){
            $item_arr = array();

            foreach ($coucils as $key => $value) {
                $item_arr[] = array('id' => $value->id, 'suburb' => $value->suburb, 'postcode' => $value->postcode);
            }

            $search_result['items'] = $item_arr;

            echo json_encode($search_result);
        }
    }
}

public function search_area() {
    if($this->input->post('term')){
        $search_term = $this->input->post('term');
        
        $where_term = "council LIKE '$search_term%' OR suburb LIKE '$search_term%' OR postcode LIKE '$search_term%' ";
        $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);
        
        $search_result = array();
        
        if(!empty($coucils)){
            $item_arr = array();
            
            foreach ($coucils as $key => $value) {
                $item_arr[] = array('id' => $value->id, 'suburb' => $value->suburb, 'postcode' => $value->postcode);
            }
            
            $search_result['items'] = $item_arr;
            
            echo json_encode($search_result);
        }
    }
}

public function check_council() {
    if($this->input->post('addr_str')){
        $search_term = $this->input->post('addr_str');
        
        $where_term = "council LIKE '$search_term%' OR suburb LIKE '$search_term%' OR postcode LIKE '$search_term%' ";
        $coucils = $this->basic_model->get_record_where('aus_councils', '', $where_term);
        
        if(!empty($coucils)){
            $response = array('status' => TRUE, 'council' => $coucils[0]->council);
        } else {
            $response = array('status' => FALSE);
        }
        echo json_encode($response);
    }
}

function change_password_admin(){
    if ($this->session->userdata()) {
     $this->load->library('form_validation');
     $this->form_validation->set_rules('password','Password','required');
     $this->form_validation->set_rules('npassword','New Password','required|trim|min_length[6]');
     $this->form_validation->set_rules('cpassword','Confirm Password','required|trim|min_length[6]|matches[npassword]');
     if($this->form_validation->run()==false){
        $this->load->view('admin/header');
        $this->load->view('admin/menu');
        $this->load->view("admin/admin_change_pw");
        $this->load->view('admin/footer');
    }else{
        $id= $this->session->userdata("id");
        $password =$this->input->post("password");
        $old_password=md5($password);
        $where = array('id' => $id, 'password' => $old_password);
        $check=$this->basic_model->get_record_where('admin', '', $where);
        if(!empty($check)){
            $npassword = md5($this->input->post('npassword'));
            $update_data = array('password' => $npassword);
            $this->basic_model->update_records('admin', $update_data, $where);
            $this->session->set_flashdata('success', 'User Password updated succesfully');
            redirect('admin/change_password_admin');

        }else{
            $this->load->view("admin/user_change_password");

        }
    }
}
}
//     // Controller ends HERE


}
