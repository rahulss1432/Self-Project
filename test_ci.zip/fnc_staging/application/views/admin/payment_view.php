<?php
if (!empty($user_record)) {
//echo '<pre>';
//print_r($user_record);
    ?>
    <input type="hidden"  id='pay_id' value="" name="name">
    <input type="hidden" name="additional_item_data" class="form-control" id="additional_item_data" >
    <p>


    <table class=" Method_head">
        <tr>
            <td> 
                <label for="payment_method" class="form-control-label size-small" id="payment_method">Payment Method :</label>

                <label for="payment_method" class="form-control-label size-small dafault_d" id="payment_method">
                    <?php
                    if ($user_record[0]->payment_method == 1) {
                        echo "Stripe";
                    }if ($user_record[0]->payment_method == 2) {
                        echo "Pay by account";
                    } else {
                        echo "Pay by voucher";
                    }
                    ?> </label>

            </td>
        </tr>

        <tr>
            <td> 

                <label for="payment_status" class="form-control-label size-small" id="payment_status"> Payment Status :</label>

                <label for="payment_status" class="form-control-label size-small dafault_d" id="payment_status">
                    <?php
                    if ($user_record[0]->payment_status == 1) {
                        echo "Pending";
                    }if ($user_record[0]->payment_status == 2) {
                        echo "Paid";
                    }
                    ?> </label>

            </td>
        </tr>

        <tr>
            <td>
                <label for="payment_method" class="form-control-label size-small" id="payment_method">Transaction id :</label>

                <label for="payment_status" class="form-control-label size-small dafault_d" id="payment_status"><?php echo (!empty($user_record[0]->pay_txn_id)) ? $user_record[0]->pay_txn_id : 'N/A'; ?> </label>

            </td>
        </tr>
    </table>



    <table class="me" style="border:1px solid #d8d8d8" width="100%" cellspacing="0" cellpadding="0">
        <tbody><tr bgcolor="#d8d8d8">
                <th align="left">Item Description</th>
                <th width="100px" align="left">Price</th>
                <th width="80px" align="left">Qty.</th>
                <th style="padding:10px 15px; color: #fff;" width="100px" align="left">Total</th>
            </tr>
            <?php
            $pay_new = json_decode($user_record[0]->pay_for, true);
            foreach ($pay_new as $key => $value) {
                if ($value['id'] == 'voucher_id') {
                    $voucher_reduction = str_replace('-', '-$', $value['price']);
                    continue;
                }
                $addional = (!empty($value['options']['days_payment'])) ? ' (for ' . $value['options']['days_payment'] . ' days)' : '';
                ?>
                <tr>
                    <td>
                        <?php
                        echo $products[$value['id']]['pro_title'] . $addional;
                        ?> 

                    </td>
                    <td width="100px"><?php echo $value['price']; ?></td>
                    <td width="80px"><?php echo $value['qty']; ?></td>
                    <td width="100px" align="left"><?php echo $value['subtotal']; ?>
                    </td>
                </tr>
                <?php
            }
            ?>
        </tbody>
    </table>

    <div class="row">
        <div class="col-md-6"></div>
        <div class="col-md-6" style="margin-top: 10px; margin-bottom: 30px;">
            <table class="tab_d" style="border: 1px solid #dde5f1;" width="100%" cellspacing="0" cellpadding="0" bgcolor="#fff">
                <caption><h3>Total</h3></caption>
                <tbody>
                    <?php
                    //print_r($user_record[0]);
                    if (!empty($voucher_reduction)) { ?>
                        <tr>
                            <td  width="50%">Voucher Applied</td>
                            <td  width="50%" align="right"><?php echo $voucher_reduction ?></td>
                        </tr>
                    <?php } ?>
                    <tr>
                        <td width="50%">Sub Total</td>
                        <td width="50%" align="right">$<?php echo $user_record[0]->total_amount; ?></td>
                    </tr>
                    <tr>
                        <td width="50%">Gst </td>
                        <td width="50%" align="right">$<?php echo $user_record[0]->gst; ?></td>
                    </tr>
                </tbody>
                <tfoot bgcolor="#eee">
                    <tr><td width="50%">Total</td>
                        <td width="50%" align="right">$<?php echo $user_record[0]->pay_total_amount; ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
    <?php
}
?>
