<link href="<?php echo base_url('admin-assets/vendor/bootstrap/css/login_style.css'); ?>" rel="stylesheet">
<div id="page-wrapper" class="bg_root_change">

<div class="login-page_107">

         <div class="text_ch_pas">Change Password</div>
         
         
         <div class="form_107">
         	<form class="login-form_107" role="form" id="frm-login" action="" method="post" novalidate="novalidate" id="myform" name='registration'>
         
         		<input class="form-control" placeholder="Old Password" name="password" type="password" value="">
         		
         		<input class="form-control" placeholder=" New Password" name="npassword" type="password" value="" id="npassword" >
         		
         		<input class="form-control" placeholder="Confirm Password" name="cpassword" type="password" value="" id="cpassword" >
         		
         		<button type="submit" name="submit" value="Login">Submit</button>
              
         	</form>
            <div class="success_mes">
         	<?php
         	echo $this->session->flashdata('success')?>
            </div>

         </div>
         </div>
</div>
<script type="text/javascript">
   $(function() {
      $("form[name='registration']").validate({
         rules: {
         password: {
        required: true,
        minlength: 6,
      },
      npassword: {
        required: true,
        minlength: 6,
      },
      cpassword: {
        required: true,
        minlength: 6,
        equalTo: "#npassword"
      }
    },

    messages: {
      password: {
        required: "Enter your old password",
        minlength: "Your password must be at least 5 characters long"
      },
       npassword: {
        required: "Please Enter a new password",
        minlength: "Password should be 6 characters"
      },
       cpassword: {
        required: "Please confirm a password",
        minlength: "Your password must be at least 5 characters long",
        equalTo:"These passwords don't match. Try again?"

      },
    },

    submitHandler: function(form) {
      form.submit();
    }
  });
});
</script>

<!-- 
<style type="text/css">
   .navbar-default.sidebar{
      height:47vw !important;
   }
   body{
      background: #fff !important;
   }
   @media(max-width: 767px){
    .navbar-default.sidebar{  height:100% !important;
      }}
</style>
 -->



