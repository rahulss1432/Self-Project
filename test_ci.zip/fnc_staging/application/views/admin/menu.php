<!-- Navigation -->
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="<?php echo site_url('admin/dashboard'); ?>"><img src="<?php echo base_url('admin-assets/image/admin_logo.svg'); ?>"></a>
    </div>
    <!-- /.navbar-header -->

    <ul class="nav navbar-top-links navbar-right">
        
        <!-- /.dropdown -->
        <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
            </a>
            <ul class="dropdown-menu dropdown-user">
                <!--<li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a></li>-->
              <!--   <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                </li> -->
                <!-- <li class="divider"></li> -->
                <li><a href="<?php echo site_url('admin/change_password_admin'); ?>"><i class="fa fa-key fa-fw" aria-hidden="true"></i>Change Password</a>
                </li>
                <li class="divider"></li>
                <li><a href="<?php echo site_url('admin/logout'); ?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                </li>
            </ul>
            <!-- /.dropdown-user -->
        </li>
        <!-- /.dropdown -->
    </ul>
    <!-- /.navbar-top-links -->

    <?php
    $uri = $this->uri->segment(2);
    ?>

    <div class="navbar-default sidebar" role="navigation">
        <div class="sidebar-nav navbar-collapse">
            <ul class="nav" id="side-menu">
               
                <li>
                    <a href="<?php echo site_url('admin/dashboard'); ?>"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                </li>
                <li>
                    <a href="<?php echo site_url('admin/users'); ?>" class="<?php echo isset($uri) && $uri =='edit_user'?'active':''?>"><i class="fa fa-users fa-fw"></i> Users</a>
                </li>
                <li>
                   <a href="<?php echo site_url('admin/feedback_list'); ?>"><i class="fa fa-comments-o fa-fw"></i> Reviews</a>
                </li>
                <li>
                    <a href="<?php echo site_url('admin/venue_catering'); ?>" class="<?php echo isset($uri) && $uri =='edit_venue'?'active':''?>"><i class="fa fa-cutlery fa-fw"></i> Venue & Catering</a>
                </li>
                 <li>
                    <a href="<?php echo site_url('admin/businesses_authorized'); ?>" ><i class="fa fa-briefcase"></i> Businesses Authorised</a>
                </li>
<li>
                    <a href="<?php echo site_url('admin/premium_venues'); ?>" class="<?php echo isset($uri) && $uri =='add_update_premium_venues'?'active':''?>"><i class="fa fa-bookmark-o"></i> Premium Venues</a>
                </li>
                <li>  
                   <a href="<?php echo site_url('admin/voucher'); ?>" ><i class="fa fa-tags"></i> Voucher</a>
                </li>
                <li>  
                    <a href="<?php echo site_url('admin/pages'); ?>" ><i class="fa fa-columns"></i> Pages</a>
                 </li>
                 <li>  
                    <a href="<?php echo site_url('admin/payment_details'); ?>" ><i class="fa fa-credit-card"></i> Payment</a>
                 </li>
            </ul>
        </div>
        <!-- /.sidebar-collapse -->
    </div>
    <!-- /.navbar-static-side -->
</nav>