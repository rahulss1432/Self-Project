<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Users <a class="btn btn-success new pull-right" style="margin-right:5px;" href="<?php echo base_url('admin/user_add') ?>">Add User</a></h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Users list</div>
                <ul  class="Type_select absolute_slct_dt1">
                    <li>
                        <label>Type</label>
                        <select id= "new">
                            <option>Please Select</option>
                            <option value="all_srch">All</option>
                            <option value="web_srch">Web</option>
                            <option value="admin_srch">Admin</option>
                        </select>
                    </li> 
                </ul>        
                <div class="panel-body">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                        <thead>
                            <tr>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Phone No.</th>
                                <th>Status</th>
                                <th style="width: 20%;">Action</th>
                            </tr>
                        </thead> 
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="pass_model" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Change Password</h4>
            </div>
            <div class="modal-body">

                <div class="form-group">
                    <label for="email">Password:</label>
                    <input type="hidden" name="text" class="form-control" id="user_id">
                    <input type="password" id="user_password" name="user_password" class="form-control" placeholder="Password">
                    <span id="error_pass"></span>
                </div>
                <div class="clearfix"></div>
                <div class="form-group">
                    <label for="pwd">Confirm Password:</label>
                    <input type="password" id="c_password" name="c_password" class="form-control" placeholder="Confirm Passsword">
                    <span id="error_c_pass"></span>
                </div>
                <div class="clearfix"></div>
                <button type="submit" id="submit_password" class="btn btn-default sub_but">Submit</button>

            </div>
            <!--   <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div> -->
        </div>

    </div>
</div>
<div class="modal fade remove_confirmation" id="remove_confirmation" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalLabel">Confirm Remove</h5>
            </div>
            <div class="modal-body crop_model_body">
                <p class="content_are">Are you want to sure Archive this?</p>
                <input type="hidden" id="remove_id" >
                <input type="hidden" id="remove_cnt">
            </div>
            <div class="modal-footer_1">
                <button id="remove_confirmed" class="btn btn-primary but_crope Confirm_button" type="button">Confirm</button>
                <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade active_confirmation" id="active_confirmation" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalLabel">Confirm Re-active</h5>
            </div>
            <div class="modal-body crop_model_body">
                <p class="content_are">Are you want to sure Re-active this?</p>
                <input type="hidden" id="active_id" >
                <input type="hidden" id="active_cnt">
            </div>
            <div class="modal-footer_1">
                <button id="active_confirmed" class="btn btn-primary but_crope Confirm_button" type="button">Confirm</button>
                <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">


    var table;
    $(document).ready(function () {

        var table = $('#table').DataTable({
            "bPaginate": true,
            "bLengthChange": true,
            "bFilter": true,
            "bSort": true,
            "bInfo": true,
            "bSearchable": true,
            "bAutoWidth": false,
            "bProcessing": true,
            "bServerSide": true,
            "sAjaxSource": "<?php echo $table_data_source ?>",
            "aoColumnDefs": [{"bSortable": false}],
        });
    });
</script>

<script type="text/javascript">
    $(document).on("change", "#new", function () {
        var is_registration = $(this).val();
        var srch_str = '?is_registration=' + is_registration;
        var cntrl_url = base_url + 'admin/users_ajax_list' + srch_str;
        $('#table').data('dt_params', {name: 'test'});
        $('#table').DataTable().ajax.url(cntrl_url);
        $('#table').DataTable().draw();
    });
    jQuery(document).on("click", ".new_pop", function (e) {
        $("#remove_confirmation").modal();
    });
    jQuery(document).on("click", ".active_pop", function (e) {
        $("#active_confirmation").modal();
    });
    $(document).on("click", ".change_password", function () {
        var user_id = $(this).attr("data-id");
        $('#user_id').val(user_id);
        $('#user_password').val('');
        $('#c_password').val('');
        $('#pass_model').modal({
            show: 'false'
        });
    });

    $('#submit_password').click(function () {
        var user_id = $('#user_id').val();
        var user_password = $('#user_password').val();
        var c_password = $('#c_password').val();
        var valid = true;

        $('#error_pass').html();
        $('#error_c_pass').html();

        if (user_password == '') {
            $('#error_pass').html('This field is required');
            valid = false;
        }
        if (c_password == '') {
            $('#error_c_pass').html('This field is required');
            valid = false;
        }
        if (c_password !== user_password) {
            $('#error_c_pass').html('Password not match');
            valid = false;
        }

        if (valid) {
            $.ajax({
                url: base_url + 'admin/change_password',
                type: "POST",
                data: {password: user_password, user_id: user_id},
                success: function (resp) {
                    $('#pass_model').modal('toggle');
                },
                error: function (req, status, err) {
                    //console.log('something went wrong', status, err);

                }
            });
        }
    });
    function ArchiveFnc(user_id) {
        $("#remove_confirmed").click(function () {
            $('#remove_confirmation').modal('hide');
            $.ajax({
                url: "<?php echo base_url(); ?>admin/archive_single_users",
                method: 'POST',
                data: {user_id: user_id},
                success: function (response) {

                    $('#table').DataTable().ajax.reload();

                }
            });
        });
    }
    function ActiveFnc(user_id) {
        $("#active_confirmed").click(function () {
            $('#active_confirmation').modal('hide');
            $.ajax({
                url: "<?php echo base_url(); ?>admin/active_single_users",
                method: 'POST',
                data: {user_id: user_id},
                success: function (response) {

                    $('#table').DataTable().ajax.reload();

                }
            });
        });
    }

</script>


<style type="text/css">
    .new_class {
        width: 950px !important;
    }
</style>