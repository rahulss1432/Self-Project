<script src="<?php echo base_url('assets/js/custom/user_profile.js?' . rand()); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.ezdz.js'); ?>"></script>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Add User
            </h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Add User
                </div>
                <div class="panel-body">
                    <div class="row">
                        <form id="add_user" enctype="multipart/form-data" onclick="add_user_validate();" action=" " method="post">
                            <div class="col-lg-2">
                                <?php if ($this->session->flashdata('success')): ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>User!</strong> <?php echo $this->session->flashdata('success'); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-4 col-sm-6 col-xs-12">
                                <div class="form-group col-md-12">
                                    <label>First name</label>
                                    <input type="hidden" name="user_id">
                                    <input class="form-control" type="text" name="user_firstname" value="" placeholder="First name"  >
                                    <?php echo form_error('user_firstname'); ?>
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Last name</label>
                                    <input class="form-control" type="text" name="user_lastname" value="" placeholder="Last name">
                                    <?php echo form_error('user_lastname'); ?>
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Phone number</label>
                                    <input class="form-control phone_no" maxLength='10' data-rule-minlength="8" data-rule-maxlength="10" data-rule-phone-number="true" type="text" name="user_phone_no" value="" placeholder="Phone number">
                                    <?php echo form_error('user_phone_no'); ?>
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Email</label>
                                    <input class="form-control" type="text" name="user_email" value="" placeholder="Email">
                                    <?php echo form_error('user_email'); ?>
                                </div>
                                <!-- <div class="form-group col-md-12">
                                    <label>Password</label>
                                    <input class="form-control" type="password" name="user_password"  id ="user_password" value="" placeholder="password" data-rule-required="true">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Confirm Password</label>
                                    <input class="form-control" type="password" name="c_password" value="" placeholder="Confirm password" data-rule-required="true" >
                                </div> -->
                                <div class="form-group col-md-12" style="display:none;">
                                    <label>Business name</label>
                                    <input class="form-control" type="hidden" id="user_id" name="user_id" value="" placeholder="Business name">
                                    <input class="form-control" type="text" name="user_business_name" value="" placeholder="Business name">
                                </div>
                                <div class="form-group col-md-12" style="display:none;">
                                    <label>ABN</label>
                                    <input class="form-control" type="text" name="user_abn" value="" placeholder="ABN">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Type</label>
                                    <div class="clearfix"></div>
                                    <div class="pull-left" style="padding-right: 15px;">
                                        <label class="set_label_venu">
                                            <label class="regular-checkbox pull-left r-p-n-501 " style="margin-right: 7px !important;">
                                                <input class="checkbox_set" name="user_type[]" type="checkbox" value="1" >
                                                <small></small>
                                            </label>
                                            <span>Venue </span>
                                        </label>
                                    </div>
                                    <div class="pull-left">
                                        <label class="set_label_venu">
                                            <label class="regular-checkbox pull-left r-p-n-501" style="margin-right: 7px !important;">
                                                <input class="checkbox_set" name="user_type[]" type="checkbox" value="2" >
                                                <small></small>
                                            </label>
                                            <span>Catering</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6 col-xs-12">

<!--                                <div class="form-group col-md-12">
                                    <label>Address</label>
                                    <input class="form-control" type="text" name="user_address" value="" placeholder="Address">
                                </div>

                                <div class="form-group col-md-12">
                                    <label>City</label>
                                    <input class="form-control" type="text" name="user_city" value="" placeholder="City">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>State</label>
                                    <input class="form-control" type="text" name="user_state" value="" placeholder="State">
                                </div>
                                <div class="form-group col-md-12" style="display:none;">
                                    <label>Suburb</label>
                                    <input class="form-control" type="text" name="user_suburb" value="" placeholder="Suburb">
                                </div>-->

                                <div class="form-group col-md-12">
                                    <label>Postcode</label>
                                    <input class="form-control" type="text" maxlength="4" name="user_postcode" value="" placeholder="Postcode">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Profile Image</label>
                                    <input class="form-control" type="file" name="user_image">
                                </div>
                            </div>
                            <div class="col-lg-2"></div>
                            <div class="col-md-8 col-md-offset-2">
                                <div class="col-md-12"><button type="submit" value="update_user" class="btn btn-default update_btn">Add User</button>
                                    <a href="<?php echo site_url('admin/users'); ?>" class="btn btn-default cancel_btn">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php //$this->load->view('models/image_cropping'); ?>
<style>
    /*    .userImgCirc {
            width: 125px !important;
            height: 125px !important;
            border-radius: 50%;
            overflow: hidden !important;
            border: solid 1px #cecbcb !important;
        }
        .cropper-crop-box, .cropper-view-box {
            border-radius: 50%;
        }
        .cropper-view-box,
        .cropper-face {
            border-radius: 50%;
        }*/
</style>
<script>
    $(".phone_no").keyup(function (e) {
        length = $(this).val().length;
        limit = 18;
        if (length > limit) {
            var strtemp = $(this).val().substr(0, limit);
            $(this).val(strtemp);
            e.preventDefault();
        }
    });
    $(".phone_no").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .   
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 107, 109, 32, 110, 57, 48]) !== -1 ||
                // Allow: Ctrl+A, Command+A
                        (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                        // Allow: home, end, left, right, down, up
                                (e.keyCode >= 35 && e.keyCode <= 40) || (e.keyCode === 107 || e.keyCode === 109 || e.keyCode === 32 || e.keyCode === 57 || e.keyCode === 48)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            });
</script>
