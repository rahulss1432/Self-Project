<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap-datepicker3.css') ?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/buttons.dataTables.min.css') ?>">
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Payment Details</h1>
        </div>
    </div> 

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">

                <div class="panel-heading">Payment details list</div>


                <div class="row">

                    <div class="col-md-6 col-sm-12">
                        <ul  class="Type_select type_multi1">
                            <li>
                                <label>Method</label>
                                <select id= "new_one" >
                                    <option>Please Select</option>
                                    <option  value="all_srch">All</option>
                                    <option  value="Stripe_srch">Stripe</option>
                                    <option  value="Account_srch">Pay by account</option>
                                </select>
                            </li>
                            <li>
                                <label>Status</label>
                                <select id= "new_second" >
                                    <option>Please Select</option>
                                    <option  value="all_srch">All</option>
                                    <option  value="Pending_srch">Pending </option>
                                    <option  value="Paid_srch">Paid</option>
                                </select>
                            </li>
                        </ul>


                    </div>

                    <div class="col-md-6 col-sm-12 t_right" >

                        <div class="dataTables_wrapper src_search ">
                            <form id="search_form">
                                <div class="search_item s_101 ">
                                    <ul class="no_pad_l">
                                        <li class="cal"><input type="text" name="pay_created_on" readonly id="from_date" placeholder="From"></li>
                                        <li class="cal"><input type="text" name="pay_created_on" readonly id="to_date" placeholder="To"></li>
                                        <li><button id="customerSearchButton" type="button" class="add-school_add src_bt1">Search</button></li>
                                    </ul>
                                </div>
                            </form>
                        </div>

                    </div>


                </div>


                <div class="tab-content">
                    <div class="tab-pane active" id="demo">

                        <div class="panel-body">

                            <div class="clearfix"></div>


                            <table width="100%" class="table table-striped table-bordered table-hover voucher_td_pad" id="table">
                                <thead>
                                    <tr>
                                        <th>User</th>

                                        <th>Venue/Catering</th>
                                        <th>Payable Amount</th>
                                        <th>Total Amount</th>
                                        <th>Voucher Code</th>
                                        <th>Payment Method</th>
                                        <th>Payment Status</th>
                                        <th>Created On</th>
                                        <th>Action</th>

                                    </tr>
                                </thead> 
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <script type="text/javascript" src="<?php echo base_url('admin-assets/js/bootstrap-datepicker.min.js') ?>"></script>
        <div class="modal fade " tabindex="-1" role="dialog" aria-labelledby="myModalLabel" id="newsss_model">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Payment Details</h4>
                    </div>
                    <div class="modal-body">

                        <!-- <div id="error" class="alert alert-danger" role="alert"></div> -->
                        <?php $check_url = site_url('admin/check_tx_id'); ?>
                        <form role="form" action="" method="post"  id="myform" onclick="UpdateForm()" >
                            <input type="hidden"  id='pay_id' value="" name="name">
                            <p>
                                <label>Transaction id  :</label>
                                <br>
                                <input type="text" name="pay_txn_id" class="form-control" id="pay_txn_id" placeholder="Transaction id" data-rule-required="true" data-msg-remote="This Transaction id is already exist" data-rule-remote= "<?php echo $check_url ?>" >
                                <input type="hidden" name="payment_status" class="form-control" id="payment_status" >
                                <input type="hidden" name="pay_fc_id" class="form-control" id="pay_fc_id" >
                                <input type="hidden" name="additional_item_data" class="form-control" id="additional_item_data" >


                                <br>
                                <button type="button" class="btn btn-default sub_but">Submit</button>
                            </p>
                    </div>

                </div>
            </div>
        </div>

        <div class="modal fade " tabindex="-1" role="dialog" aria-labelledby="myModalLabel" id="view_model">

            <div class="modal-dialog new_size" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Payment Details View</h4>
                    </div>
                    <div class="modal-body" id="itemData">



                    </div>

                </div>
            </div>




        </div>

        <script type="text/javascript">

            var table;
            $(document).ready(function () {

                var table = $('#table').DataTable({
                    // dom : 'l<"#add">frtip',
                    "bPaginate": true,
                    "bLengthChange": true,
                    "bFilter": true,
                    "bSort": true,
                    "bInfo": true,
                    "bSearchable": true,
                    "bAutoWidth": false,
                    "bProcessing": true,
                    "bServerSide": true,
                    "responsive": true,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    "sAjaxSource": "<?php echo $table_data_source ?>",
                    // "aoColumnDefs": [{ "bSortable": false, "aTargets": [8] }] 
                    "aoColumnDefs": [{"bSortable": false}],
                    dom: 'lBfrtip',
                    buttons: [
                        {
                            extend: 'excelHtml5',
                            exportOptions: {
                                columns: [1, 2, 3, 4, 5, 6, 7],
                                modifer: {
                                    page: 'all',

                                    selected: null
                                }
                            }
                        }
                        ,
                        {
                            extend: 'csvHtml5',
                            exportOptions: {
                                columns: [1, 2, 3, 4, 5, 6, 7],
                                modifer: {
                                    page: 'all',

                                    selected: null
                                }

                            }

                        }
                    ]
                });
            });
            jQuery(document).on("click", ".pop_view", function (e) {
                $("#view_model").modal();

            });

            jQuery(document).on("click", ".pop_edit", function (e) {
                $("#newsss_model").modal();
                var validator = $("#myform").validate();
                validator.resetForm();
            });
            function UpdateForm() {
                var url = "<?php echo site_url('admin/PaymentDetails_update') ?>"
                var pay_id = $('#pay_id').val();
                if ($("#myform").valid()) {
                    var form_data = new FormData(document.getElementById("myform"));
                    $.ajax({
                        url: url,
                        type: "POST",
                        data: form_data,
                        processData: false,
                        contentType: false
                    }).done(function (data) {
                        $('#table').DataTable().ajax.reload();
                        $('#myform')[0].reset();
                        $("#newsss_model").click();

                    });
                    return false;
                }
            }

            function editPaymentDetails(pay_id) {
                save_method = 'update';
                $.ajax({
                    url: "<?php echo site_url('admin/PaymentDetails_edit') ?>/",
                    type: "POST",
                    data: {pay_id: pay_id},
                    dataType: "JSON",
                    success: function (data) {
                        $("#pay_id").attr("name", "pay_id");
                        $("#pay_id").val(data[0].pay_id);
                        $('#pay_txn_id').val(data[0].pay_txn_id);
                        $('#payment_status').val(data[0].payment_status);
                        $('#pay_fc_id').val(data[0].pay_fc_id);
                        $('#additional_item_data').val(data[0].additional_item_data);
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        alert('Error get data from ajax');
                    }
                });
            }

            function get_payment_detail(pay_id) {
                if (pay_id != '') {

                    $.ajax({
                        url: "<?php echo site_url('admin/get_payment_detail') ?>/",
                        type: "POST",
                        data: {pay_id: pay_id},

                        success: function (response) {
                            $("#itemData").empty();
                            $("#itemData").append(response);
                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                            alert('Error get data from ajax');
                        }
                    });
                }
            }


            $(document).on("change", "#new_one", function () {

                var payment_method = $(this).val();
                var payment_status = $('#new_second').val();

                var srch_str = '?payment_method=' + payment_method + '&payment_status=' + payment_status;
                var cntrl_url = base_url + 'admin/payment_details_ajax_list' + srch_str;
                $('#table').data('dt_params', {name: 'test'});
                $('#table').DataTable().ajax.url(cntrl_url);
                $('#table').DataTable().draw();


            });

            $(document).on("change", "#new_second", function () {
                // alert();
                var payment_status = $(this).val();
                var payment_method = $('#new_one').val();

                var srch_str = '?payment_status=' + payment_status + '&payment_method=' + payment_method;
                var cntrl_url = base_url + 'admin/payment_details_ajax_list' + srch_str;
                $('#table').data('dt_params', {name: 'test'});
                $('#table').DataTable().ajax.url(cntrl_url);
                $('#table').DataTable().draw();


            });
            // <-new chnages->
            $("#customerSearchButton").on("click", function (event) {
                var from_date = $("#from_date").val();
                var to_date = $("#to_date").val();
                var payment_status = $("#payment_status").val();





                // alert(bus_auth_req);
                if (from_date == '' && to_date == '' && payment_status == '')
                {
                    show_notification("Please select atleast one filter.", "w");
                    return;
                } else
                {
                    var srch_str = '?from_date=' + from_date + '&to_date=' + to_date + '&payment_status=' + payment_status;

                    // alert(srch_str);

                    var cntrl_url = base_url + 'admin/payment_details_ajax_list' + srch_str;
                    // alert(cntrl_url);
                    $('#table').data('dt_params', {name: 'test'});
                    $('#table').DataTable().ajax.url(cntrl_url);
                    $('#table').DataTable().draw();
                }
            });

            $(document).ready(function () {
                var date_input = $('input[name="pay_created_on"]'); //our date input has the name "date"
                var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
                date_input.datepicker({
                    format: 'dd-mm-yyyy',

                    container: container,
                    todayHighlight: true,
                    autoclose: true,
                })
            })
        </script>

        <!-- 
               <style type="text/css">
                 #table_length {
                  float: left;
                  margin-right: 15px !important;
                  width: 65%;
                  display: table;
                  margin-top: -14px;
                }
              </style>
        
        
        -->
