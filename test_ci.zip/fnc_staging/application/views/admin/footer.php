
</div>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url('admin-assets/vendor/bootstrap/js/bootstrap.min.js'); ?>"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url('admin-assets/vendor/metisMenu/metisMenu.min.js'); ?>"></script>

<!-- Morris Charts JavaScript -->
<script src="<?php echo base_url('admin-assets/vendor/raphael/raphael.min.js'); ?>"></script>
<script src="<?php echo base_url('admin-assets/vendor/morrisjs/morris.min.js'); ?>"></script>

<!-- DataTables JavaScript -->
<script src="<?php echo base_url('admin-assets/vendor/datatables/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('admin-assets/vendor/datatables-plugins/dataTables.bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('admin-assets/vendor/datatables-responsive/dataTables.responsive.js'); ?>"></script>
<!-- for excel and csv export -->
<script type="text/javascript" src="<?php echo base_url('admin-assets/js/dataTables.buttons.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('admin-assets/js/buttons.html5.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('admin-assets/js/buttons.print.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('admin-assets/js/jszip.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('admin-assets/js/pdfmake.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('admin-assets/js/vfs_fonts.js') ?>"></script>



<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url('admin-assets/dist/js/sb-admin-2.js'); ?>"></script>
<script src="<?php echo base_url('admin-assets/js/custom/custom_admin_js.js'); ?>"></script>
<script src="<?php echo base_url('admin-assets/js/jquery.validate.min.js'); ?>"></script>
<script src="<?php echo base_url('admin-assets/js/additional-methods.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/bootstrap-notify-master/bootstrap-notify.min.js') ?>"></script>
<script>
    function add_loader() {
        var image = base_url + 'assets/images/FnC_Loader.gif';
        //var image = base_url+'assets/images/3.gif';
        $.blockUI({message: "<img class='modal_loader' src=" + image + " />"});
    }

//remove loader
    function remove_loader() {
        $.unblockUI();
    }



    $.validator.addMethod("greaterThan",
            function (value, element, param) {
                var $min = $(param);
                if (this.settings.onfocusout) {
                    $min.off(".validate-greaterThan").on("blur.validate-greaterThan", function () {
                        $(element).valid();
                    });
                }
                return parseInt(value) > parseInt($min.val());
            }, "max guest must be greater than min guest");

    $.validator.addMethod("lessThan",
            function (value, element, param) {
                var $min = $(param);
                if (this.settings.onfocusout) {
                    $min.off(".validate-greaterThan").on("blur.validate-greaterThan", function () {
                        $(element).valid();
                    });
                }
                return parseInt(value) < parseInt($min.val());
            }, "min guest must be less than max guest");

    $.validator.addMethod("abn_number", function (abn_number, element) {
        abn_number = abn_number.replace(/\s+/g, "");
        return this.optional(element) || abn_number.length >= 11 &&
                abn_number.length <= 11;
    }, "Abn must be 11 digit");

    $.validator.addMethod("phone_number", function (phone_number, element) {
        phone_number = phone_number.replace(/\s+/g, "");
        return this.optional(element) || phone_number.length >= 10 && phone_number.length <= 10;
    }, "Phone number must be 10 digit");

    $.validator.addMethod("email", function (value, element) {
        if (value != '') {
            return /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(value);
        } else {
            return true;
        }
    }, "Please enter valid email address");

    $(function () {
        $('body').on('keydown', 'input:text,textarea', function (e) {
            if (e.which === 32 && e.target.selectionStart === 0) {
                return false;
            }
        });
    });
</script>





</section>

<div class="powered_by"><b> Developed with <img src="<?php echo base_url('assets/images/love.svg'); ?>"> & <img src="<?php echo base_url('assets/images/coffee.svg'); ?>"> by:</b> <a href="http://yourdevelopmentteam.com.au/" target="blank">Your Development Team</a></div><!-- /#wrapper -->

</body>

<!-- <style type="text/css">
    .section_height{
    position: relative;
    height: 100vh;
    min-height: 100vh;
}
</style> -->






</html>