<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap-datepicker3.css') ?>"/>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Reviews</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Review list</div>

                <ul  class="Type_select ">
                    <li>
                     <label>Action</label>
                     <select id= "new">
                            <option id="new1" >Please Select</option>
                            <option value="all_srch">All</option>
                            <option value="approve_srch">Approved</option>
                            <option  value="deny_srch">Denied</option>
                            <option  value="dispute_srch">Disputed</option>
                            <option  value="resolve_srch">Resolve</option>
                            <option  value="pending_srch">Pending</option>
                            <option   value="archive_srch">Archive</option>
                        </select>
                  </li>
                </ul>
               
                <div class="tab-content">
                    <div class="tab-pane active" id="demo">
                        <div class="panel-body">
                            <div class="dataTables_wrapper src_search">
                                <form id="search_form">
                                    <div class="search_item s_101 pull-right">
                                        <ul>
                                            <li class="cal"><input type="text" name="f_created_on" readonly id="from_date" placeholder="From"></li>
                                            <li class="cal"><input type="text" name="f_created_on" readonly id="to_date" placeholder="To"></li>
                                            <li><button id="customerSearchButton" type="button" class="add-school_add">Search</button></li>
                                        </ul>
                                    </div>
                                </form>
                            </div>
                            <div class="clearfix"></div>
                            <div class="panel-body">
                                <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Venue</th>
                                                           <!--  <th>Cleanliness</th>
                                                            <th>Accuracy of description</th>
                                                            <th>Communication</th> -->
                                            <th>Feedback Comment</th>
                                            <th>Status</th>
                                            <th>Date Applied</th>
                                            <th style="width: 20%;">Action</th>
                                        </tr>
                                    </thead> 
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script type="text/javascript" src="<?php echo base_url('admin-assets/js/bootstrap-datepicker.min.js') ?>"></script>
            <div class="modal fade " tabindex="-1" role="dialog" aria-labelledby="myModalLabel" id="newsss_model">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="myModalLabel">Feedback</h4>
                        </div>
                        <div class="modal-body">
                            <form role="form" action="" method="post"  id="myform" >
                                <input type="hidden"  id='f_id' value="" name="name">
                                <p>
                                    <label>Comment :</label>
                                    <br>
                                    <textarea name="f_text" cols="20" rows="5" class="form-control" id="f_text" placeholder="commnets" data-rule-required="true" ></textarea>
                                    <br>
                                    <button type="button" class="btn btn-default sub_but" onclick="submitForm()">Submit</button>
                                </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade remove_confirmation" id="remove_confirmation" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalLabel">Confirm Remove</h5>
                        </div>
                        <div class="modal-body crop_model_body">
                            <p class="content_are">Are you want to sure Archive this?</p>
                            <input type="hidden" id="remove_id" >
                            <input type="hidden" id="remove_cnt">
                        </div>
                        <div class="modal-footer_1">
                            <button id="remove_confirmed" class="btn btn-primary but_crope Confirm_button" type="button">Confirm</button>
                            <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
            <script type="text/javascript">
                var table;
                $(document).ready(function () {
                    /* table = $('#table').DataTable({
                     "processing": true,
                     "serverSide": true,
                     "responsive": true,
                     "order": [],
                     "ajax": {
                     "url": "<?php //echo site_url('admin/feedback_ajax_list')          ?>",
                     "type": "POST"
                     },
                     "columnDefs": [
                     {
                     "targets": [6],
                     "orderable": false,
                     },
                     ],
                     });
                     $.fn.dataTable.ext.errMode = 'none';*/
                    table = $('#table').DataTable({
                        "bPaginate": true,
                        "bLengthChange": true,
                        "bFilter": true,
                        "bSort": true,
                        "bInfo": true,
                        "bSearchable": true,
                        "bAutoWidth": false,
                        "bProcessing": true,
                        "bServerSide": true,
                        "sAjaxSource": '<?php echo $table_data_source ?>',
                        "aoColumnDefs": [{"bSortable": false, "aTargets": [5]}]
                    });
                });
            </script>
            <script type="text/javascript">
                function UpdateFeedback(f_id, f_status) {
                    var url = "<?php echo site_url('admin/feedback_update') ?>";
                    $.ajax({
                        url: url,
                        type: "POST",
                        data: {f_id: f_id, f_status: f_status},
                        dataType: "JSON",
                        success: function (data) {
                            $('#table').DataTable().ajax.reload();
                        }
                    });
                }

                function submitForm() {
                    var url = "<?php echo site_url('admin/feedback_all_update') ?>"
                    var f_id = $('#f_id').val();
                    if ($("#myform").valid()) {
                        var form_data = new FormData(document.getElementById("myform"));
                        $.ajax({
                            url: url,
                            type: "POST",
                            data: form_data,
                            processData: false,
                            contentType: false
                        }).done(function (data) {
                            $('#table').DataTable().ajax.reload();
                            console.log(data);
                            $('#myform')[0].reset();
                            $("#newsss_model").click();
                        });
                        return false;
                    }
                }

                function editFeedback(f_id) {
                    save_method = 'update';
                    $.ajax({
                        url: "<?php echo site_url('admin/feedback_edit') ?>/",
                        type: "POST",
                        data: {f_id: f_id},
                        dataType: "JSON",
                        success: function (data) {
                            $("#f_id").attr("name", "f_id");
                            $("#f_id").val(data[0].f_id);
                            $('#f_text').val(data[0].f_text);
                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                            alert('Error get data from ajax');
                        }
                    });
                }

                jQuery(document).on("click", ".pop_edit", function (e) {
                    $("#newsss_model").modal();
                    var validator = $("#myform").validate();
                    validator.resetForm();
                });

                // <-new chnages->
                $("#customerSearchButton").on("click", function (event) {
                    var from_date = $("#from_date").val();
                    var to_date = $("#to_date").val();
                    if (from_date == '' && to_date == '')
                    {
                        show_notification("Please select atleast one filter.", "w");
                        return;
                    } else {
                        var srch_str = '?from_date=' + from_date + '&to_date=' + to_date;
                        var cntrl_url = base_url + 'admin/feedback_ajax_list' + srch_str;
                        $('#table').data('dt_params', {name: 'test'});
                        $('#table').DataTable().ajax.url(cntrl_url);
                        $('#table').DataTable().draw();
                    }
                });

                $(document).ready(function () {
                    var date_input = $('input[name="f_created_on"]'); //our date input has the name "date"
                    var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
                    date_input.datepicker({
                        format: 'dd-mm-yyyy',
                        container: container,
                        todayHighlight: true,
                        autoclose: true,
                    })
                })

                $(document).on("change", "#new", function () {
                    var f_status = $(this).val();
                    var srch_str = '?f_status=' + f_status;
                    var cntrl_url = base_url + 'admin/feedback_ajax_list' + srch_str;
                    $('#table').data('dt_params', {name: 'test'});
                    $('#table').DataTable().ajax.url(cntrl_url);
                    $('#table').DataTable().draw();
                });

                $(document).on("change", "#new1", function () {
                    var f_deleted = $(this).val();
                    var srch_str = '?f_deleted=' + f_deleted;
                    var cntrl_url = base_url + 'admin/feedback_ajax_list' + srch_str;
                    $('#table').data('dt_params', {name: 'test'});
                    $('#table').DataTable().ajax.url(cntrl_url);
                    $('#table').DataTable().draw();
                });

                jQuery(document).on("click", ".open_popup", function (e) {
                    $("#remove_confirmation").modal();
                });

                function ArchiveFnc(f_id) {
                    $("#remove_confirmed").click(function () {
                        $('#remove_confirmation').modal('hide');
                        $.ajax({
                            url: "<?php echo base_url(); ?>admin/archive_single_review",
                            method: 'POST',
                            data: {f_id: f_id},
                            success: function (data) {
                                $('#table').DataTable().ajax.reload();
                            }
                        });
                    });
                }
            </script>
        </div>