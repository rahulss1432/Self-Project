<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap-datepicker3.css')?>"/>

<div id="page-wrapper">
    <div class="row">
    <div class="col-md-12 ">
  
      
    </div>

        <div class="col-lg-12">
            <h1 class="page-header">Voucher history   <a href="<?php echo site_url('admin/voucher'); ?>" class="btn btn-primary edit_but pull-right">Back</a></h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Vouchers history list</div>
                <br>
                <br>
                <div class="dataTables_wrapper src_search pull-right">
                  <form id="search_form">
                    <div class="search_item s_101">
                      <ul class="col-md-12">
                        <li class="cal"><input type="text" name="create_date" readonly id="from_date" placeholder="From"></li>
                        <li class="cal"><input type="text" name="create_date" readonly id="to_date" placeholder="To"></li>
                        <li><button id="customerSearchButton" type="button" class="add-school_add">Search</button></li>
                      </ul>
                    </div>
                  </form>
                </div>
                  <div class="clearfix"></div>
                <div class="panel-body">
                    <table width="100%" class="table table-striped table-bordered table-hover voucher_td_pad" id="table">
                        <thead>
                            <tr>
                                <th>Voucher id</th>
                                <th>User Name</th>
                                <th>Value/catering</th>
                                <th>Voucher Value</th>
                                <th>Redeemed Amount</th>
                                <th>Voucher Used</th>
                                 
                            </tr>
                        </thead> 
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript" src="<?php echo base_url('admin-assets/js/bootstrap-datepicker.min.js')?>"></script>
<script type="text/javascript">

            var table;
            $(document).ready(function () {

                var table = $('#table').DataTable({
                   dom : 'l<"#add">frtip',
                  "bPaginate": true,
                  "bLengthChange": true,
                  "bFilter": true,
                  "bSort": true,
                  "bInfo": false,
                  "bSearchable": true,
                  "bAutoWidth": false,
                  "bProcessing": true,
                  "bServerSide": true,
                  "responsive": true,
                  "sAjaxSource": "<?php echo $table_data_source ?>",
                  "aoColumnDefs": [{ "bSortable": false, "aTargets": [5] }] 
              });
 });
     

     $("#customerSearchButton").on("click", function (event) { 

        var from_date = $("#from_date").val();
         var to_date = $("#to_date").val();
        if(from_date == '' && to_date=='')
            {
              show_notification("Please select atleast one filter.","w");
              return;
          }else{
            var srch_str = '?from_date='+from_date+'&to_date='+to_date;
            var  cntrl_url = base_url+'admin/voucher_history_ajax_list'+srch_str;
             $('#table').data('dt_params', { name: 'test' });
             $('#table').DataTable().ajax.url(cntrl_url);
            $('#table').DataTable().draw();
          }
      });

         $(document).ready(function(){
              var date_input=$('input[name="create_date"]'); //our date input has the name "date"
              var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
              date_input.datepicker({
                  format: 'dd-mm-yyyy',
                  container: container,
                  todayHighlight: true,
                  autoclose: true,
              })
          }) 
 </script>



    

        