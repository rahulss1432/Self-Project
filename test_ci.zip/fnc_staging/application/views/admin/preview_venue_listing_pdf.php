<html>
    <head>
        <title>Functions & Catering</title>
    </head>
    <style type="text/css">
        h1, h2, h3, h4{margin-top: 0; margin-bottom: 7px; font-weight: normal;}
        .clr_cmn1{color:#00adee;}
        .btn{background:#00adee; color: #fff; border: none; padding: 10px; border-radius: 5px;}
    </style>
    <body style="font-family: sans-serif; color:#424242;">
        <div style="width: 900px; max-width: 100%; height: auto; border: solid 1px #e6e6e6; padding: 15px; margin: 0 auto; ">
            <div>
                <div>
                    <img src="<?php echo base_url('assets/images/fnc_logo.svg'); ?>" width="150px;">
                </div>
                <div>
                    <div style="text-align: right;">
                        <a href="" style="text-decoration: none; color: #00adee;"><h5 style="margin-bottom: 0; color: #00adee;">Call us on 03 9088 9000</h5></a>
                        <div style="text-decoration: none; color: #00adee; font-size: 12px; float:right; " width="100%">

                            <span  style="text-decoration: none; color:grey; padding-left:7px; display:inline-block; width:auto; float:left;"><a  style="text-decoration: none; color:grey;" href="">Create Profile/Listing</a> &nbsp; &nbsp;</span>
                            <span  style="text-decoration: none; color:grey; padding-left:7px; display:inline-block; width:auto; float:left;"><a  style="text-decoration: none; color:grey;" href="">Help</a> &nbsp; &nbsp;</span>
                            <span  style="text-decoration: none; color:grey; padding-left:7px; display:inline-block; width:auto; float:left;"><a  style="text-decoration: none; color:grey;" href="">Login</a></span>
                            </tr>
                        </div>

                    </div>
                </div>
            </div>
            <div>
                <div  width="50%" style="float: left; ">
                    <div style="margin-top: 30px;">
                        <h2 style="color:#424242; margin-top: 0; margin-bottom: 7px;"><?php echo $venue_data->fc_business_name ?></h2>
                        <h3 style="color:#424242; margin-top: 0; margin-bottom: 7px;"><?php echo $venue_data->fc_street . ', ' . $venue_data->fc_suburb . ', ' . $venue_data->fc_country ?></h3>
                        <h4 style="color:#424242; margin-top: 0; margin-bottom: 7px;">
                            <?php
                            if (!empty($venue_data->spaces)) {
                                echo 'Spaces Available:';
                            }
                            ?></h4>
                        <table>
                            <?php
                            if (!empty($venue_data->spaces)) {
                                ?>
                                <tr>
                                    <?php
                                    foreach ($venue_data->spaces as $space) {
                                        ?> 
                                        <td style="background:#00adee; color: #fff; border: none; padding: 5px 10px; border-radius: 5px; "><?php echo $space->space_name ?></td>
                                        <?php
                                    }
                                    ?>
                                </tr>
                                <?php
                                echo '<div class="close_icons_1 close_sec hidden-xs" style="display:none"><img src="' . base_url("assets/images/close_arrow.png") . '"></div>';
                            }
                            ?>
                        </table>
                    </div>
                </div>
                <div  width="40%" style="vertical-align: top; float: right;  ">
                    <div style="color:#00adee; text-align: right; margin-top: 30px;" >Venue</div>
                </div>
            </div>
            <div>
                <div colspan="2">
                    <?php
                    $i = 1;
                    if (array_key_exists('fc_images', $venue_data)) {
                        foreach ($venue_data->fc_images as $images) {
                            if ($images) {
                                if ($i == 1) {
                                    $banner_img = base_url('uploads/fc_images/') . $images;
                                    ?>
                                    <div class="item <?php echo ($i == 1) ? 'active' : '' ?>"><img src="<?php echo $banner_img ?>" alt="Venue Images" style="width: 100%; margin-top: 15px;"></div>
                                    <?php
                                    break;
                                } else {
                                    ?>
                                    <div class="item"><img src="<?php echo base_url('assets/images/FnC_banner.jpg'); ?>" alt="Venue Images" style="width: 100%; margin-top: 15px;"></div>
                                    <?php
                                }
                            }
                        }
                    }
                    ?>
                </div>
            </div>
            <div>
                <div width="64%; " style="font-size: 13px; float:left">
                    <div width="100%;" style="margin-top: 15px;">
                        <div>
                            <div width="50%" style="padding: 0 5px; float:left; "><h4 style="color: #00adee; "><sdivong>Overview.</sdivong></h4></div>
                            <div  width="40%" style="text-align: right;padding: 0 5px; float:right;"><h4 style="color: #00adee;"><sdivong>Perfect for <?php echo $venue_data->fc_min_guest . '-' . $venue_data->fc_max_guest; ?> guests</sdivong></h4></div>
                        </div>
                    </div>
                    <div>
                        <p style="padding: 0 5px; font-size: 13px; color: #424242;">
                            <?php echo $venue_data->fc_overview; ?>
                        </p>
                    </div>
                    <?php if ($venue_data->events) { ?>
                        <h4 style="margin-top: 25px; color: #000;">Great For:</h4>
                        <div style="position: relative; color: #00adee; width: 100%;">
                            <?php
                            $cnt = 0;
                            foreach ($venue_data->events as $events) {
                                ?>
                                <?php
                                $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $events->image);
                                $imagePath = base_url('uploads/fnc_types/') . $withoutExt . '.png';
                                ?>
                                <div style="text-align: center;  display: inline-block; width: 18%; box-sizing: border-box; float: left;">
                                   <!--  <img src="https://functionsandcatering.com/staging/function/uploads/fnc_types/sit_down.svg" height="30px;" />-->
                                    <img src="<?php echo $imagePath; ?>" height="30px;" />
                                    <h5 style="margin: 0 0;"><?php echo $events->name ?></h5>
                                </div>
                                <?php
                            }
                            ?>
                            <div style="clear: both;"></div>
                        </div>
                    <?php } ?>

                    <!-- use whole div for loop after everry 5 items -->
                    <?php if ($venue_data->facilities) { ?>
                        <h4 style="margin-top: 25px; color: #000;">The Venue has:</h4>
                        <div style="position: relative; color: #00adee; width: 100%;">
                            <?php
                            foreach ($venue_data->facilities as $facilities) {
                                $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $facilities->image);
                                $imagePath = base_url('uploads/fnc_types/') . $withoutExt . '.png';
                                ?>
                                <div style="text-align: center;  display: inline-block; width: 18%; box-sizing: border-box; float: left;">
                                   <!-- <img src="https://functionsandcatering.com/staging/function/uploads/fnc_types/sit_down.svg" height="30px;" /> -->
                                    <img src="<?php echo $imagePath; ?>" height="30px;" />
                                    <h5 style="margin: 0 0;"><?php echo $facilities->name ?></h5>
                                </div>
                                <?php
                            }
                            ?>
                            <div style="clear: both;"></div>
                        </div>
                    <?php } ?>
                    <!-- use whole div for loop after everry 5 items -->
                    <?php if ($venue_data->features) { ?>
                        <h4 style="margin-top: 25px; color: #000;">The Venue feature:</h4>
                        <div style="position: relative; color: #00adee; width: 100%;">
                            <?php
                            foreach ($venue_data->features as $features) {
                                $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $features->image);
                                $imagePath = base_url('uploads/fnc_types/') . $withoutExt . '.png';
                                ?>
                                <div style="text-align: center;  display: inline-block; width: 18%; box-sizing: border-box; float: left; ">
                                    <img src="<?php echo $imagePath; ?>" height="30px;" /> 
                                    <h5 style="margin: 0 0; height:60px;"><?php echo $features->name ?></h5>
                                </div>
                                <?php
                            }
                            ?>
                            <div style="clear: both;"></div>
                        </div>
                    <?php } ?>
                    <!-- use whole div for loop after everry 5 items -->
                    <?php
                    if ($venue_data->fc_details == '') {
                        $style = 'display:none';
                    } else {
                        $style = '';
                    }
                    ?>
                    <div style="margin-top: 25px;">
                        <h4 style="color: #00adee;<?php echo $style; ?>"><sdivong>The detail:</sdivong></h4>
                        <p style="padding: 0 5px; font-size: 13px; color: #424242;<?php echo $style; ?>">
                            <?php echo $venue_data->fc_details ?>
                        </p>
                    </div>
                    <!-- use whole div for loop after everry 5 items -->
                    <?php
                    if (!empty($venue_data->fc_pdfs)) {
                        ?>
                        <h4 style="margin-top: 25px; color: #000;">Attachments:</h4>
                        <div style="position: relative; color: #00adee; width: 100%;">
                            <?php
                            foreach ($venue_data->fc_pdfs as $pdfs) {
                                $pdfImage = base_url('uploads/venue_pdf_image/' . $pdfs->fc_pdf_image);
                                ?>
                                <div style="text-align: center;  display: inline-block; width: 25%; box-sizing: border-box; float: left; ">
                                    <!--<div class="attch_dv">-->
                                    <img src="<?php echo $pdfImage; ?>" height="80px" style="max-height:100%" />
                                    <h5 class="clr_cmn" style="height:50px;"><?php echo $pdfs->fc_pdf_title_name; ?></h5>
                                    <!--</div>-->
                                </div>
                                <!--<div style="clear: both;"></div>-->
                            <?php } ?>
                        </div>
                    <?php } ?>
                    <div style="margin-top: 5px;">
                        <?php
                        if (!empty($venue_data->fc_map_image)) {
                            $map_img = base_url('uploads/venue_map_image/' . $venue_data->fc_map_image);
                            ?>
                            <h4 style="color: #00adee;"><sdivong>Location:</sdivong></h4>
                            <img src="<?php echo $map_img; ?>" width="100%;" style="margin-top: 15px;">
                        <?php } ?>
                    </div>
                    <!--                    <div style="margin-top: 25px;">
                                            <h4 style="color: #00adee;"><sdivong>Review:</sdivong></h4>
                                        </div>-->
                </div>
                <div width="35%;" style="vertical-align: top; padding: 15px 0px;">
                    <div class="detBox" style="border:solid 1px #e6e6e6; padding: 15px;">
                        <div class="dt_grp" style="margin-bottom: 15px; border-bottom: solid 1px #00adee; padding-bottom: 7px; font-size: 13px;">
                            <label>Preferred Function Date:</label>
                            <div style="margin-top: 5px;"><sdivong>dd/mm/yy</sdivong></div>
                        </div>
                        <div class="dt_grp" style="margin-bottom: 15px; border-bottom: solid 1px #00adee; padding-bottom: 7px; font-size: 13px;">
                            <label>Proposed Number of Guests:</label>
                            <div style="margin-top: 5px;"><sdivong>Upto 30</sdivong></div>
                        </div>
                        <div class="dt_grp" style="margin-bottom: 15px; border-bottom: solid 1px #00adee; padding-bottom: 7px; font-size: 13px;">
                            <label>Event Type:</label>
                            <div style="margin-top: 5px;"><sdivong>Wedding</sdivong></div>
                        </div>
                        <div class="dt_grp" style="margin-bottom: 15px; border-bottom: solid 1px #00adee; padding-bottom: 7px; font-size: 13px;">
                            <label>Anything Else?</label>
                            <div style="margin-top: 5px;"><sdivong>Queries, special requests/requirements [etc]..</sdivong></div>
                        </div>
                        <div class="dt_grp" style="margin-bottom: 15px; padding-bottom: 7px; font-size: 13px;">
                            <table>
                                <tr>
                                    <td style="background:#00adee; color: #fff; border: none; padding: 5px 10px; border-radius: 5px; display:table-cell;">Submit</td>
                                </tr>
                            </table>
                                <!-- <input style="background:#00adee; color: #fff; border: none; padding: 5px 10px; border-radius: 5px; "  id="query_submit" type="submit" value="Submit"> -->
                        </div>
                        <div class="form-group">

                            <table width="100%" cellpadding="2" cellspacing="5">

                                <tr style="border-top: 10px solid;border-bottom: 10px solid;border-color: transparent;">
                                    <td style="border:solid 1px #efefef; padding:5px;">
                                        <div style="margin-bottom:10px;">
                                            <label>Add to Favorites</label>
                                            <img class="unchkImg" src="<?php echo base_url('assets/images/Add-to-wish-list.png'); ?>" style="width:20px;height: 20px;margin-left: 20px;">
                                        </div>
                                    </td>

                                </tr>

                                <tr>
                                    <td style="border:solid 1px #efefef; padding:5px;">
                                        <div style="margin-bottom:10px;">
                                            <label>Send to a friend</label>
                                            <img class="unchkImg" src="<?php echo base_url('assets/images/6.Send-to-friend(1).svg'); ?>" style="width:20px;height: 20px;margin-left: 20px;">
                                        </div>
                                    </td>

                                </tr>

                            </table>
                            <!-- <p class="csChk2" style="border:solid 1px #efefef;">
                                <label>Add to Favorites</label>
                                <img class="unchkImg" src="<?php echo base_url('assets/images/Add-to-wish-list.png'); ?>" style="width:20px;height: 20px;margin-left: 20px;">
                            </p>
                            <p class="csChk2" style="border:solid 1px #efefef;">
                                <label>Send to a friend</label>
                                <img class="unchkImg" src="<?php echo base_url('assets/images/6.Send-to-friend(1).svg'); ?>" style="width:20px;height: 20px;margin-left: 20px;">
                            </p> -->
                        </div>
                    </div>
                    <!--                    <div>
                                            <img src="<?php //echo base_url('assets/images/glenmorangle_add_700X87_new.jpg');            ?>" width="100%;" style="margin-top: 15px;">
                                        </div>-->
                </div>
            </div>
            <div>
                <div colspan="2">
                    <!--<img src="" width="100%" style="margin-top: 15px;">-->
                </div>
            </div>
        </div>
    </body>
</html>