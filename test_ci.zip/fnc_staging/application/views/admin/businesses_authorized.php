<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap-datepicker3.css') ?>"/>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Businesses Authorised</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Businesses authorised list</div>
                <ul  class="Type_select">
                    <li>
                        <label>Action</label>
                        <select id= "new_one" >
                            <option>Please Select</option>
                            <option  value="all_srch">All</option>
                            <option  value="Approve_srch">Approve</option>
                            <option  value="Deny_srch">Deny</option>
                            <option  value="Archive_srch">Archived</option>
                        </select>
                        <label>Type</label>
                        <select id= "new_second" >
                            <option>Please Select</option>
                            <option  value="all_srch">All</option>
                            <option  value="venue_srch">Venue</option>
                            <option  value="catering_srch">Catering</option>
                        </select>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="demo">
                        <div class="panel-body pad_rem_4">
                            <div class="dataTables_wrapper src_search">
                                <form id="search_form">
                                    <div class="search_item s_101 pull-right">
                                        <ul>
                                            <li class="cal"><input type="text" name="bus_auth_create_time" readonly id="from_date" placeholder="From"></li>
                                            <li class="cal"><input type="text" name="bus_auth_create_time" readonly id="to_date" placeholder="To"></li>
                                            <li><button id="customerSearchButton" type="button" class="add-school_add">Search</button></li>
                                        </ul>
                                    </div>
                                </form>
                            </div>
                            <div class="clearfix"></div>
                            <div class="panel-body">
                                <table width="100%" class="table table-striped table-bordered table-hover" id="table">
                                    <thead>
                                        <tr>
                                            <th style="width: 20%" >Users</th>
                                            <th style="width: 10%">Type</th>
                                            <th style="width: 40%">Notes</th>
                                            <th style="width: 15%">Date applied</th>
                                            <th style="width: 15%;">Action</th>
                                        </tr>
                                    </thead> 
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="<?php echo base_url('admin-assets/js/bootstrap-datepicker.min.js') ?>"></script>
    <div class="modal fade remove_confirmation" id="remove_confirmation" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalLabel">Confirm Remove</h5>
                </div>
                <div class="modal-body crop_model_body">
                    <p class="content_are">Are you want to sure Archive this?</p>
                    <input type="hidden" id="remove_id" >
                    <input type="hidden" id="remove_cnt">
                </div>
                <div class="modal-footer_1">
                    <button id="remove_confirmed" class="btn btn-primary but_crope Confirm_button" type="button">Confirm</button>
                    <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade " tabindex="-1" role="dialog" aria-labelledby="myModalLabel" id="newsss_model">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Business Edit</h4>
                </div>
                <div class="modal-body">
                    <form role="form" action="" method="post"  id="myform" >
                        <input type="hidden"  id='bus_auth_id' value="" name="name">
                        <input type="hidden"  id='user_id' value="" name="name">
                        <p>

                        <div class="type_tow">
                            <ul>
                                <li>
                                    <label>Type : </label>
                                </li>
                                <li>

                                    <label class="regular-checkbox pull-left">
                                        <input type="radio" name="bus_auth_req" value="1" data-rule-required="true" id="venue" >
                                        <small></small>
                                    </label>
                                    Venue

                                </li>
                                <li>

                                    <label class="regular-checkbox pull-left">
                                        <input type="radio"  name="bus_auth_req" value="2" data-rule-required="true" id="catering">
                                        <small></small>
                                    </label>
                                    Catering

                                </li>
                            </ul>
                            <br>
                            <label>Comment :</label>
                            <br>
                            <textarea name="bus_auth_notes" cols="20" rows="5" class="form-control" id="bus_auth_notes" placeholder="commnets" data-rule-required="true" ></textarea>
                            <div id="ordered_error_response"></div>
                            <br>
                            <button type="button" class="btn btn-default sub_but" onclick="BusinessesForm()">Submit</button>
                            </p>
                        </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            var table;
            $(document).ready(function () {
                var table = $('#table').DataTable({
                    dom: 'l<"#add">frtip',
                    "bPaginate": true,
                    "bLengthChange": true,
                    "bFilter": true,
                    "bSort": true,
                    "bInfo": true,
                    "bSearchable": true,
                    "bAutoWidth": false,
                    "bProcessing": true,
                    "bServerSide": true,
                    "sAjaxSource": "<?php echo $table_data_source ?>",
                    "aoColumnDefs": [{"bSortable": false, "aTargets": [4]}]
                });
            });

            function UpdateBusinesses(bus_auth_id, bus_auth_status, is_mail_send)
            {
                var url = "<?php echo site_url('admin/businesses_update') ?>";
                $.ajax({
                    url: url,
                    type: "POST",
                    data: {bus_auth_id: bus_auth_id, bus_auth_status: bus_auth_status, is_mail_send: is_mail_send},
                    dataType: "JSON",
                    success: function (data) {
                        $('#table').DataTable().ajax.reload();
                    }
                });
            }
            function BusinessesForm() {
                var url = "<?php echo site_url('admin/businesses_all_update') ?>"
                var bus_auth_id = $('#bus_auth_id').val();
                if ($("#myform").valid()) {
                    var form_data = new FormData(document.getElementById("myform"));
                    $.ajax({
                        url: url,
                        type: "POST",
                        data: form_data,
                        processData: false,
                        contentType: false,
                        dataType: "JSON",
                    }).done(function (data) {
                        //console.log(data);
                        // alert(data.status);
                        if (data.status == 0)
                        {
                            // alert(data.msg);
                            $("#ordered_error_response").html(data.msg);
                        } else
                        {
                            $('#table').DataTable().ajax.reload();
                            console.log(data);
                            $('#myform')[0].reset();
                            $("#newsss_model").click();
                        }
                    });
                    return false;
                }
            }
            function editBusinesses(bus_auth_id, user_id) {
                save_method = 'update';
                $.ajax({
                    url: "<?php echo site_url('admin/businesses_edit') ?>/",
                    type: "POST",
                    data: {bus_auth_id: bus_auth_id},
                    dataType: "JSON",
                    success: function (data) {
                        $("#bus_auth_id").attr("name", "bus_auth_id");
                        $("#user_id").val(user_id);
                        $("#bus_auth_id").val(data[0].bus_auth_id);
                        if (data[0].bus_auth_req == 1) {
                            $('#venue').prop('checked', true);
                        } else {
                            $('#catering').prop('checked', true);
                        }
                        $('#bus_auth_notes').val(data[0].bus_auth_notes);
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        alert('Error get data from ajax');
                    }
                });
            }
            jQuery(document).on("click", ".pop_edit", function (e) {
                $("#newsss_model").modal();
                var validator = $("#myform").validate();
                validator.resetForm();
            });
        </script>

        <script type="text/javascript">
            $(document).on("change", "#new", function () {
                // alert();
                var bus_auth_req = $(this).val();
                var srch_str = '?bus_auth_req=' + bus_auth_req;
                var cntrl_url = base_url + 'admin/businesses_authorized_ajax_list' + srch_str;
                $('#table').data('dt_params', {name: 'test'});
                $('#table').DataTable().ajax.url(cntrl_url);
                $('#table').DataTable().draw();
            });
            $(document).on("change", "#new_one", function () {
                // alert();
                var bus_auth_status = $(this).val();
                var srch_str = '?bus_auth_status=' + bus_auth_status;
                var cntrl_url = base_url + 'admin/businesses_authorized_ajax_list' + srch_str;
                $('#table').data('dt_params', {name: 'test'});
                $('#table').DataTable().ajax.url(cntrl_url);
                $('#table').DataTable().draw();
            });

            $(document).on("change", "#new_second", function () {
                // alert();
                var bus_auth_req = $(this).val();
                var srch_str = '?bus_auth_req=' + bus_auth_req;
                var cntrl_url = base_url + 'admin/businesses_authorized_ajax_list' + srch_str;
                $('#table').data('dt_params', {name: 'test'});
                $('#table').DataTable().ajax.url(cntrl_url);
                $('#table').DataTable().draw();
            });

            $(document).on("change", "#third_search", function () {
                // alert();
                var bus_is_deleted = $(this).val();
                // alert(bus_is_deleted);
                var srch_str = '?bus_is_deleted=' + bus_is_deleted;
                var cntrl_url = base_url + 'admin/businesses_authorized_ajax_list' + srch_str;
                $('#table').data('dt_params', {name: 'test'});
                $('#table').DataTable().ajax.url(cntrl_url);
                $('#table').DataTable().draw();


            });


            jQuery(document).on("click", ".new_pop", function (e) {
                // alert();
                $("#remove_confirmation").modal();
            });

            function ArchiveFnc(bus_auth_id) {
                $("#remove_confirmed").click(function () {
                    $('#remove_confirmation').modal('hide');
                    $.ajax({
                        url: "<?php echo base_url(); ?>admin/archive_single_bus_auth",
                        method: 'POST',
                        // dataType: 'json',
                        data: {bus_auth_id: bus_auth_id},
                        success: function (data) {
                            $('#table').DataTable().ajax.reload();
                        }
                    });
                });
            }


            // <-new chnages->
            $("#customerSearchButton").on("click", function (event) {
                var from_date = $("#from_date").val();
                var to_date = $("#to_date").val();
                var bus_auth_req = $("#bus_auth_req").val();
                // alert(bus_auth_req);
                if (from_date == '' && to_date == '')
                {
                    show_notification("Please select atleast one filter.", "w");
                    return;
                } else
                {
                    var srch_str = '?from_date=' + from_date + '&to_date=' + to_date + '&bus_auth_req=' + bus_auth_req;
                    // alert(srch_str);
                    var cntrl_url = base_url + 'admin/businesses_authorized_ajax_list' + srch_str;
                    // alert(cntrl_url);
                    $('#table').data('dt_params', {name: 'test'});
                    $('#table').DataTable().ajax.url(cntrl_url);
                    $('#table').DataTable().draw();
                }
            });

            $(document).ready(function () {
                var date_input = $('input[name="bus_auth_create_time"]'); //our date input has the name "date"
                var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
                date_input.datepicker({
                    format: 'dd-mm-yyyy',

                    container: container,
                    todayHighlight: true,
                    autoclose: true,
                })
            })
            // <-new chnages->

        </script>


        <style type="text/css">
            .new_class {
                width: 950px !important;
            }
            .type_tow ul li{
                float:left;
                list-style: none;
                margin-right: 15px !important;
            }
            .type_tow ul li .error {
                position: absolute !important;
                left: 0 !important;
                margin-top: 20px;
                margin-left: 13px;
            }
            .type_tow ul{
                padding-left: 0px !important;
            }
            .type_tow .regular-checkbox {
                width: 20px !important;
                height: 20px !important;
                border-radius: 24px !important;
                margin: 0px 5px;
            }

            .type_tow .regular-checkbox input:checked~small:after{
                background: url(http://onesheepventures.com/staging/functions/assets/images/check-symbol_new.png) no-repeat;
                color: #46b8da;
                font-size: 18px;
                margin-top: 3px;
                margin-left: 2px;
                content: "";
                text-align: center;
                opacity: 0.6;
                background-size: 80%;
            }
            .type_tow{
                width: 100%;
                display: table;
                margin-bottom: 30px;
            }
            label#bus_auth_notes-error {
                margin-bottom: 15px;
            }
        </style>