<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Edit User<!-- <a href="<?php //echo site_url('admin/users');       ?>" class="back_shift btn btn-default">Back</a> -->
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Edit User
                </div>
                <div class="panel-body">
                    <div class="row">
                        <form id="edit_user" enctype="multipart/form-data" onclick="edit_user_validate();" action="<?php echo site_url('admin/update_user'); ?>" method="post">
                            <div class="col-lg-2"></div>
                            <div class="col-lg-4 col-sm-6 col-xs-12">
                                <div class="form-group col-md-12" style="display:none">
                                    <label>Business name</label>
                                    <input class="form-control" type="hidden" id="user_id" name="user_id" value="<?php echo $user_data[0]->user_id ?>" placeholder="Business name">
                                    <input class="form-control" type="text" name="user_business_name" value="<?php echo $user_data[0]->user_business_name ?>" placeholder="Business name">
                                </div>
                                <div class="form-group col-md-12" style="display:none">
                                    <label>ABN</label>
                                    <input class="form-control" type="text" name="user_abn" value="<?php echo $user_data[0]->user_abn ?>" placeholder="ABN">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>First name</label>
                                    <input class="form-control" type="text" name="user_firstname" value="<?php echo $user_data[0]->user_firstname ?>" placeholder="First name">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Last name</label>
                                    <input class="form-control" type="text" name="user_lastname" value="<?php echo $user_data[0]->user_lastname ?>" value="<?php echo $user_data[0]->user_lastname ?>" placeholder="Last name">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Phone number</label>
                                    <input class="form-control phone_no" maxLength='10' data-rule-minlength="8" data-rule-maxlength="10" data-rule-phone-number="true" type="text" name="user_phone_no" value="<?php echo $user_data[0]->user_phone_no ?>" placeholder="Phone number">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Email</label>
                                    <input class="form-control" type="text" name="user_email" value="<?php echo $user_data[0]->user_email ?>" placeholder="Email">
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6 col-xs-12">
<!--                                <div class="form-group col-md-12">
                                    <label>Address</label>
                                    <input class="form-control" type="text" name="user_address" value="<?php echo $user_data[0]->user_address ?>" placeholder="Address">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>City</label>
                                    <input class="form-control" type="text" name="user_city" value="<?php echo $user_data[0]->user_city ?>" placeholder="City">
                                </div>
                                <div class="form-group col-md-12" style="display:none">
                                    <label>Suburb</label>
                                    <input class="form-control" type="text" name="user_suburb" value="<?php echo $user_data[0]->user_suburb ?>" placeholder="Suburb">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>State</label>
                                    <input class="form-control" type="text" name="user_state" value="<?php echo $user_data[0]->user_state ?>" placeholder="State">
                                </div>-->
                                <div class="form-group col-md-12">
                                    <label>Postcode</label>
                                    <input class="form-control" type="text" maxlength="4" name="user_postcode" value="<?php echo $user_data[0]->user_postcode ?>" placeholder="Postcode">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Profile Image</label>
                                    <input class="form-control" type="file" name="user_image">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Pay by Account</label>
                                    <input class="" type="checkbox" name="pay_by_account" <?php echo ($user_data[0]->pay_by_account == 1) ? 'checked' : '' ?> value="1">
                                </div>
                            </div>
                            <div class="col-lg-2"></div>
                            <div class="col-md-8 col-md-offset-2">
                                <div class="col-md-12"><button type="submit" value="update_user" class="btn btn-default update_btn">Update User</button>
                                    <a href="<?php echo site_url('admin/users'); ?>" class="btn btn-default cancel_btn">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->
<script>
    $(".phone_no").keyup(function (e) {
        length = $(this).val().length;
        limit = 18;
        if (length > limit) {
            var strtemp = $(this).val().substr(0, limit);
            $(this).val(strtemp);
            e.preventDefault();
        }
    });
    $(".phone_no").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .   
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 107, 109, 32, 110, 57, 48]) !== -1 ||
                // Allow: Ctrl+A, Command+A
                        (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                        // Allow: home, end, left, right, down, up
                                (e.keyCode >= 35 && e.keyCode <= 40) || (e.keyCode === 107 || e.keyCode === 109 || e.keyCode === 32 || e.keyCode === 57 || e.keyCode === 48)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            });
</script>