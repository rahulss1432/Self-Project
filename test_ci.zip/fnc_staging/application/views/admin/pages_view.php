<div id="page-wrapper">
    <div class="row">
    <div class="col-md-12 ">
    </div>
       <div class="col-lg-12">
            <h1 class="page-header">All Pages</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Pages list</div>
                <div class="panel-body">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="table_page">
                        <thead>
                            <tr>
                               <th style="width: 10%;">Title</th>
                               <th>Content</th>
                               <th style="width: 5%;">Action</th>
                            </tr>
                        </thead> 
                        <tbody>
                       </tbody>
                    </table>
                </div>
            </div>
      <!--   </div>
    </div>
</div>
 -->

<script type="text/javascript">

            var table;
            $(document).ready(function () {

                var table = $('#table_page').DataTable({
                  dom : 'l<"#add">frtip',
                  "bPaginate": true,
                  "bLengthChange": true,
                  "bFilter": true,
                  "bSort": true,
                  "bInfo": true,
                  "bSearchable": true,
                  "bAutoWidth": false,
                  "bProcessing": true,
                  "bServerSide": true,
                  "responsive": true,
                  "sAjaxSource": "<?php echo $table_data_source ?>",
                  "aoColumnDefs": [{ "bSortable": false, "aTargets": [2] }] 
              });
     });
      
 </script>

<style>
.dtr-data .container{
    width: 100% !important;
}
@media (min-width:768px){
   .dtr-data .container{
    width: 100% !important;
}
}
</style>
