<?php
$venue_permission_ary = venue_permission();
$cater_permission_ary = cater_permission();

$venu_status = isset($venue_permission_ary->bus_auth_status) ? $venue_permission_ary->bus_auth_status : '';
$cater_status = isset($cater_permission_ary->bus_auth_status) ? $cater_permission_ary->bus_auth_status : '';

$venue_bus_auth_req = isset($venue_permission_ary->bus_auth_req) ? $venue_permission_ary->bus_auth_req : '';
$cater_bus_auth_req = isset($cater_permission_ary->bus_auth_req) ? $cater_permission_ary->bus_auth_req : '';
?>

<footer class="container-fluid navigation space_change">
    <div class="row">
        <div class="col-sm-12">
            <div class="container inspiration_container padding_footer_root">
                <div class="row">
                    <div class="col-sm-3 footer_logo">
                        <span><a href="<?php echo site_url(); ?>"><img src="<?php echo base_url('assets/images/fnc_logo.svg'); ?>" class="footer_img"/></a></span>
                        <div class="footer-call-us"><a class="call-us-now hidden-lg hidden-md hidden-sm" href="tel:03 9088 9000">Call Us Now</a></div>
                    </div>

                    <div class="col-sm-9 footer-menu">
                        <div id="text-3" class="widget widget_text">
                            <div class="textwidget">
                                <nav class="navbar">
                                    <div class="container-fluid menubar">
                                        <ul class="nav navbar-nav navbar-right hidden-xs desk_foot">
                                            <li><a href="<?php echo site_url('about_us'); ?>">About Us</a></li>
                                            <li><a href="<?php echo site_url('help'); ?>">Help</a></li>


                                            <?php
                                            if ($venue_bus_auth_req == 1) {
                                                $url = creat_your_listing();
                                                $request_url = site_url('/request');
                                                $add_venue = site_url('/add_venue');
                                                if ($url == $request_url) {
                                                    ?>
                                                    <li><a href="<?php echo $add_venue; ?>">Create Profile/Listing</a></li>

                                                <?php } else { ?>
                                                    <!-- <li><a href="<?php echo creat_your_listing(); ?>">Create Profile/Listing</a></li> -->

                                                    <?php
                                                }
                                            } else {
                                                ?>
                                                <li><a href="<?php echo creat_your_listing(); ?>">Create Profile/Listing</a></li>

                                            <?php } ?>

                                            <li><a href="<?php echo site_url('web/advertise'); ?>">Advertise</a></li>
                                            <li><a href="<?php echo site_url('contact_us'); ?>">Contact Us</a></li>

                                        </ul>

                                        <ul class="nav navbar-nav navbar-right hidden-lg hidden-md hidden-sm">
                                            <li><a href="<?php echo site_url('about_us'); ?>">About Us</a></li>

                                            <?php
                                            if ($venue_bus_auth_req == 1) {
                                                $url = creat_your_listing();
                                                $request_url = site_url('/request');
                                                $add_venue = site_url('/add_venue');
                                                if ($url == $request_url) {
                                                    ?>
                                                    <li><a href="<?php echo $add_venue; ?>">Create Profile/Listing</a></li>

                                                <?php } else { ?>
                                                    <!-- <li><a href="<?php echo creat_your_listing(); ?>">Create Profile/Listing</a></li> -->

                                                    <?php
                                                }
                                            } else {
                                                ?>
                                                <li><a href="<?php echo creat_your_listing(); ?>">Create Profile/Listing</a></li>

                                            <?php } ?>

                                           

                                            <li><a href="<?php echo site_url('web/advertise'); ?>">Advertise</a></li>
                                            <li><a href="<?php echo site_url('contact_us'); ?>">Contact Us</a></li>
                                            <li><a href="<?php echo site_url('help'); ?>">Help</a></li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>
        <?php
        $login_user_data = $this->session->all_userdata();
        $login_user_id = isset($login_user_data['user_id']) ? $login_user_data['user_id'] : '';
        if ($login_user_id == '') {
            ?>
            <div class="col-sm-12 queries hidden-xs">
                <div class="container">
                    <div class="footer_s_menu">
                        <h4>For any queries call us on <a href="tel:03 9088 9000">03 9088 9000</a>
                        </h4>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>

    <div class="row">
        <div class="container" style="padding: 0px;">
            <div class="">
                <div class="footer_s_menu">
                    <div class="col-sm-4 fun_cate hidden-xs">
                        <span class="footer_text">&copy; <?php echo date("Y"); ?> Functions and Catering Australia Pty. Ltd.</span>
                    </div>

                    <div class="col-sm-4 hidden-xs">
                        <div class="powered_by"><b> Developed with <img class="love-color" src="<?php echo base_url('assets/images/love.svg'); ?>"> & <img class="coffee-color" src="<?php echo base_url('assets/images/coffee.svg'); ?>"> by <a href="https://yourdevelopmentteam.com.au/" target="blank">Your Development Team</a></b>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="container-fluid menubar">
                            <ul class="nav navbar-nav navbar-right footer_text">
                                <li><a href="<?php echo site_url('privacy_policy'); ?>">Privacy Policy</a></li>
                                <li><a href="<?php echo site_url('term_condition'); ?>">Terms and Conditions</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix"></div>

                    <div class="col-sm-4 fun_cate hidden-md hidden-lg hidden-sm ">
                        <span class="footer_text">© <?php echo date("Y"); ?>  Functions &amp; Catering Australia Pty. Ltd.</span>
                    </div>
                    <div class="col-sm-4 hidden-lg hidden-md hidden-sm hidden-xs">
                        <div class="powered_by"><b> Developed with <img src="<?php echo base_url('assets/images/love.svg'); ?>"> & <img src="<?php echo base_url('assets/images/coffee.svg'); ?>"> by:</b> <a href="http://yourdevelopmentteam.com.au/" target="blank">Your Development Team</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="hidden-lg hidden-md hidden-sm"><div class="powered_by"><b> Developed with <img src="<?php echo base_url('assets/images/love.svg'); ?>"> & <img src="<?php echo base_url('assets/images/coffee.svg'); ?>"> by:</b> <a href="http://yourdevelopmentteam.com.au/" target="blank">Your Development Team</a></div>

            </div>
        </div>   
    </div>
</footer>


</body>
</html>
<script src="<?php echo base_url('assets/plugins/bootstrap-notify-master/bootstrap-notify.min.js') ?>"></script>
<script>

    // $(".alphaText").keypress(function (event) {
    //     var regex = new RegExp("^[a-zA-Z ]+$");
    //     var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
    //     if (!regex.test(key)) {
    //         event.preventDefault();
    //         return false;
    //     }
    // });


    jQuery(document).ready(function () {

        jQuery(".dropdown-menu").click(function (event) {
            event.stopPropagation();
        });

        jQuery(window).scroll(function () {
            var scroll = $(window).scrollTop();


            if (scroll == 0) {
                jQuery("#header_dy").removeClass("change_header");
            } else {
                jQuery("#header_dy").addClass("change_header");
            }
        });
    });

    $(window).load(function () {
        /* Check width on page load*/

        if ($(window).width() > 768) {

            $('.love-color').attr('src', '<?php echo base_url('assets/images/love-blue-color.svg'); ?>');
            $('.coffee-color').attr('src', '<?php echo base_url('assets/images/coffee-blue-color.svg'); ?>');
        } else {
            //alert($(window).width());
        }
    });

    $(window).resize(function () {
        /*If browser resized, check width again */
        if ($(window).width() > 768) {
            $('.love-color').attr('src', '<?php echo base_url('assets/images/love-blue-color.svg'); ?>');
            $('.coffee-color').attr('src', '<?php echo base_url('assets/images/coffee-blue-color.svg'); ?>');
        } else {
        }
    });

    $('.home-section input').focus(function () {
        $(".overlay-content-bottom").addClass("hidde_foot");
        $(".overlay-content").addClass("scroll_foot");
        // $(this).parent().addClass('hidde_foot');
    }).blur(function () {
        $(".overlay-content-bottom").removeClass("hidde_foot");
        $(".overlay-content").removeClass("scroll_foot");
        // $(this).parent().removeClass('hidde_foot');
    });

    $(function () {
        $('body').on('keydown', 'input:text', function (e) {
            if (e.which === 32 && e.target.selectionStart === 0) {
                return false;
            }
        });
    });
</script>

<style type="text/css">
    .overlay-content-bottom.hidde_foot{
        display: none !important;
    }
    /*.scroll_foot{
       height:600px;
       overflow-x: scroll;
    }*/

    #myNav .home-section{
        display: block;
        height: 600px;
        overflow: scroll;
        float: left;
        width: 100%;
    }
    #myNav .home-section-1 {
        height: 700px;
        overflow: scroll;
        float: left;
        width: 100%;
    }

</style>
