<?php
if ($this->session->userdata('user_image')) {
    $user_image = $this->session->userdata('user_image');
    //$user_image = $user_data[0]->user_image;
} else {
    $user_image = base_url() . 'uploads/users/FnC_user_icon.png';
}
$venue_permission_ary = venue_permission();
$cater_permission_ary = cater_permission();
$venu_status = isset($venue_permission_ary->bus_auth_status) ? $venue_permission_ary->bus_auth_status : '';
$cater_status = isset($cater_permission_ary->bus_auth_status) ? $cater_permission_ary->bus_auth_status : '';
?>
<div class="col-md-3 col-sm-4">
    <div class="navbar" role="navigation">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle nv_align mb_toggle" data-toggle="collapse" data-target="#sm">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div id="sm" class="collapse navbar-collapse side_navigation">
            <ul class="nav navbar-nav left_menu_user left_side_menu">
                <div class="user_icon_welcome">

                    <div class="profile_pic12">
                        <a href="<?php echo site_url('/dashboard'); ?>">
                            <img src="<?php echo $user_image; ?>">
                        </a>
                    </div>

<!--<img class="img-ait-1 img-responsive" src="<?php echo $user_image; ?>">-->
                </div>

                <?php
                $uri = $this->uri->segment(1);
                $arrayMenu['dashboard'] = 'Dashboard';
                $arrayMenu['my_venue_reviews'] = 'My reviews';
                $arrayMenu['my_catering_reviews'] = 'My reviews';
                $arrayMenu['favorites'] = 'Favorites';
                $arrayMenu['recently_viewed'] = 'Recently viewed';
                $arrayMenu['my_reviews'] = 'My reviews';
                $arrayMenu['my_venues'] = 'My Venues';
                $arrayMenu['add_venue'] = 'Add New Venue';
                $arrayMenu['my_catering'] = 'My Catering';
                $arrayMenu['add_catering'] = 'Add New Catering';


                $page_arr_default = array("dashboard", "favorites", "recently_viewed", "my_reviews", "my_venues", "add_venue", "my_catering", "add_catering");
                $page_arr_my_venues = array("dashboard", "my_venue_reviews", "my_venues", "add_venue");
                $page_arr_my_catering = array("dashboard", "my_catering_reviews", "my_catering", "add_catering");
                $page_arr_request = array("dashboard", "favorites", "recently_viewed", "my_reviews");


                $page_menu_arr = array('dashboard' => $page_arr_default, 'favorites' => $page_arr_default, 'recently_viewed' => $page_arr_default, 'my_reviews' => $page_arr_default, 'my_venues' => $page_arr_my_venues, 'my_catering' => $page_arr_my_catering, 'request' => $page_arr_request,'space_venue'=>$page_arr_my_venues, 'change_password' => $page_arr_default,'my_catering_reviews'=>$page_arr_my_catering,'my_venue_reviews'=>$page_arr_my_venues);

                if (array_key_exists($uri, $page_menu_arr)) {
                    $page_arr = $page_menu_arr[$uri];
                    $strMenu = '';
                    foreach ($arrayMenu as $key => $val) {
                        if (in_array($key, $page_arr)) {
                            $site_url = site_url($key);
                            $active_class = ($key == $uri ? 'active' : '');
                            $strMenu .= '<li><a href="' . $site_url . '" class="Link ' . $active_class . '">' . $val . '</a></li>';
                        }
                    }
                    echo $strMenu;
                }
                //'space_venue' 
                //add space page field
                if ($this->uri->segment(2) == 'spaces') {
                    ?>
                    <li><a href="<?php echo site_url('my_venue_reviews'); ?>" class="Link <?php
                        if (!empty($uri)) {
                            if ($uri == 'my_venue_reviews') {
                                echo 'active';
                            }
                        }
                        ?>">My reviews</a></li>
                    <li><a href="<?php echo site_url('change_password'); ?>" class="Link <?php
                        if (!empty($uri)) {
                            if ($uri == 'change_password') {
                                echo 'active';
                            }
                        }
                        ?>">Change password</a></li>
                        <?php
                    }
                    if ($uri == 'add_catering') {
                        ?>
                    <li><a  onclick="forwordTo('business_details'); businessForwordTo('company_details', false);" class="Link business_details active">Business Details<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>
                    <li><a  onclick="forwordTo('package')" class="Link package">Package<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>
                    <li><a onclick="forwordTo('catering_details'); venuDetailsForwordTo('venu_description', false);" class="Link catering_details">Catering details<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>

                    <li><a onclick="forwordTo('page_layout'); listingForwordTo('upload_image', false);" class="Link page_layout ">Page layout<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>

                    <li><a onclick="forwordTo('listing_area')" class="Link  listing_area ">Listing Area<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>

                    <li><a onclick="forwordTo('payment', 'getPaymentCart')" class="Link payment">Payment<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>
                    <?php
                }

                if ($uri == 'add_venue') {
                    ?>
                    <li><a  onclick="forwordTo('business_details'); businessForwordTo('company_details', false);" class="Link business_details active ">Business Details<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>
                    <li><a  onclick="forwordTo('package')" class="Link package">Package<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>
                    <li><a onclick="forwordTo('venue_details'); venuDetailsForwordTo('venu_description', false);" class="Link venue_details ">Venue details<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>
                    <li><a onclick="forwordTo('page_layout'); listingForwordTo('upload_image', false);" class="Link page_layout">Page layout<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>
                    <li><a onclick="forwordTo('listing_area')" class="Link  listing_area ">Listing Area<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>
                    <li><a onclick="forwordTo('spaces')" class="Link spaces ">Spaces<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a></li>
                    <li><a onclick="forwordTo('payment', 'getPaymentCart')" class="Link payment ">Payment<img src="<?php echo site_url(); ?>assets/images/System_warning.svg" class="error_icon_2"/></a>
                    </li>
                    <?php
                }
                ?>
            </ul>
        </div>
    </div>
</div><!--col-md-4-->