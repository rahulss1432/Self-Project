<!DOCTYPE html>
<!--[if IE 7]><html class="ie ie7" lang="en-US">
    <![endif]--><!--[if IE 8]><html class="ie ie8" lang="en-US"><![endif]--><!--[if !(IE 7) | !(IE 8) ]><!-->
<html lang="en-US">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <title><?php echo (isset($title)) ? $title . ' |' : ''; ?> Functions & Catering</title>
        <link rel="shortcut icon" type="image/png" href="<?php echo base_url('assets/images/favicon.png'); ?>"/>


        <link rel="stylesheet" href="<?php echo base_url('assets/boostrap/css/bootstrap.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css'); ?>" type="text/css">
        <link rel="stylesheet" href="<?php echo base_url('assets/css/jquery-ui.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap-datepicker.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/css/star-rating.css'); ?>" media="all" type="text/css">
        <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/css/jquery.bxslider.css'); ?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/css/cropper.css'); ?>">

        <link rel="stylesheet" href="<?php echo base_url('assets/css/main_style.css?v=' . rand()); ?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/css/style_new.css'); ?>">

        <script src="<?php echo base_url('assets/js/jquery.js'); ?>"></script>

        <!--1/Dec/2017-->
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCAdbO5pXFwBbUCUeKcYZzufcQZ2xxXz0Y&sensor=false&libraries=places"></script>
        <!--<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDKpKW5X2adkkMh9Y0ihSM5itzZtHklMOE&libraries=places">-->

        <!--1/Dec/2017-->

        <!--5/Dec/2017-->
        <script src="<?php echo base_url('assets/js/jquery.blockUI.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/cropper.js'); ?>"></script>
        <!--5/Dec/2017-->

        <script src="<?php echo base_url('assets/js/equal_height.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/jquery-ui.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/boostrap/js/bootstrap.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/moment.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/star-rating.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo base_url('assets/js/jquery.bxslider.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/bootstrap-datepicker.min.js'); ?>"></script>

        <script src="<?php echo base_url('assets/js/jquery.validate.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/additional-methods.js'); ?>"></script> 

        <script src="<?php echo base_url('assets/js/customfunction.js?' . rand()); ?>"></script>
        <script src="<?php echo base_url('assets/js/passwordstrength/password-score.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/passwordstrength/password-score-options.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/passwordstrength/bootstrap-strength-meter.js'); ?>"></script>
        <script>
            var baseURL = base_url = '<?php echo base_url() ?>';
        </script>
        <script>
            var I_AM_NEW = true;
            var time = moment();

            localStorage.setItem("dateTime", time);

            function setLoginTIme() {
                var res = check_loginTime();
                var time = moment();
                if (res) {
                    localStorage.setItem("dateTime", time);
                    I_AM_NEW = false;
                }
            }

            function getLoginTIme() {
                return localStorage.getItem("dateTime")
            }

            function check_loginTime() {
                var DATE_TIME = getLoginTIme();
                var server = moment(DATE_TIME)

                var currentDateTime = moment()

                const diff = currentDateTime.diff(server);
                const diffDuration = moment.duration(diff);

                if (diffDuration.days() > 0) {
                    window.location.href = baseURL + '/user/user_logout';
                } else if (diffDuration.hours() > 0) {
                    window.location.href = baseURL + '/user/user_logout';
                } else if (diffDuration.minutes() > 30) {
                    window.location.href = baseURL + '/user/user_logout';
                } else {
                    return true
                }
            }

        </script>


    </head>
    <?php $logIn = ($this->session->userdata('user_id')) ? true : false; ?>
    <body class="<?php echo isset($body_class) ? $body_class : ''; ?>" <?php if ($logIn) { ?> onload="setLoginTIme()" onmousemove="setLoginTIme()" onclick="setLoginTIme()" onkeypress="setLoginTIme()" onscroll="setLoginTIme()"  <?php } ?> >