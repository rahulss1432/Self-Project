<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/owl.carousel.min.css" />
<script src="<?php echo base_url(); ?>assets/js/owl-slider.js" ></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php
if (isset($venue_data)) {
    ?>
    <section class="single_venues_section space_change">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 vanue-name-head">
                    <span id="venue-name" class="venue-name-new"><?php echo $venue_data->fc_business_name ?></span>
                    <span id="venue-add" class="venue-address"><?php echo $venue_data->fc_street . ', ' . $venue_data->fc_suburb . ', ' . $venue_data->fc_country ?></span>
                </div>
                <div class="col-sm-4 category-type">
                    <span class="function_text space_change_div">Venue</span>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <ul class="nav nav-pills set_root_nav_pills">
                        <?php
                        if (!empty($venue_data->spaces)) {
                            foreach ($venue_data->spaces as $space) {
                                ?>
                                <li><a class="venue_space" data-value="<?php echo $space->space_id ?>" href="javascript:;"><?php echo $space->space_name ?></a></li> <!-- $space->space_id -->
                                <?php
                            }
                            echo '<div class="close_icons_1 close_sec a" style="display:none"><img src="' . base_url("assets/images/close_arrow.png") . '"></div>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>


    <div class="set_dotted col-md-12 margin-top_slider">
        <div class="row">
            <ul id="bxslider_4">
                <li> <img src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg" class="img-responsive">
                <li> <img src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg" class="img-responsive">
                <li> <img src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg" class="img-responsive">
                <li> <img src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg" class="img-responsive">
                <li> <img src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg" class="img-responsive">

                </li>
            </ul>
        </div>
    </div>

    <section class="section-white space_change">
        <div class="container-fluid">
            <div class="row">
                <div class="container fnc_slider" >
                    <div id="carousel-example-generic" class="carousel slide button_set" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-example-generic" data-slide-to="0" class=""></li>
                            <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
                            <li data-target="#carousel-example-generic" data-slide-to="2" class="active"></li>
                        </ol>

                        <div class="carousel-inner">
                            <?php
                            $i = 1;
                            if (array_key_exists('fc_images', $venue_data)) {
                                foreach ($venue_data->fc_images as $images) {
                                    if ($images) {
                                        $banner_img = base_url('uploads/fc_images/') . $images;
                                        ?>
                                        <div class="item <?php echo ($i == 1) ? 'active' : '' ?>"><img src="<?php echo $banner_img ?>" alt="Venue Images"></div>
                                        <?php
                                        $i++;
                                    }
                                }
                            }
                            if ($i == 1) {
                                ?>
                                <div class="item active"><img src="<?php echo base_url('assets/images/FnC_banner.jpg'); ?>" alt="Venue Images"></div>
                                <?php
                            }
                            ?>
                        </div>
                        <a class="left carousel-control width_set_carousel-control" href="#carousel-example-generic" data-slide="prev">
                            <img class="glyphicon-chevron-left" src="<?php echo base_url(); ?>assets/images/arrow_left.png">
                        </a>
                        <a class="right carousel-control width_set_carousel-control" href="#carousel-example-generic" data-slide="next">
                            <img class="glyphicon-chevron-right" src="<?php echo base_url(); ?>assets/images/arrow_right.png">
                        </a>
                    </div>
                </div>
            </div>
            <div class="row space_slider" style="display:none">
                <div class="container">
                    <div class="modal_one_img"><img id="space_banner" src="" altf="Venue Images"></div>
                </div>
            </div>
        </div>

    </div>
    </section>


    <section class="space_change">
        <div class="container detail-single-venue">
            <div class="row">
                <div class="col-lg-8 col-sm-8">
                    <div class="space_change_modal for_venue_extra_details"> <!-- blur class  space_change -->
                        <div class="row">
                            <div class="col-lg-6 col-sm-4 col-xs-5 single-venue-overview">
                                <span>Overview.</span>
                            </div>
                            <div class="col-lg-6  col-sm-8 col-xs-7 single-venue-overview text-right">
                                <span id="perfect_for"> Perfect for <?php echo $venue_data->fc_min_guest . '-' . $venue_data->fc_max_guest; ?> guests</span>
                                <span id="perfect_for_space" style="display: none"></span>
                            </div>

                            <div class="col-lg-12 details" id="fc_overview">
                                <?php echo $venue_data->fc_overview; ?>
                            </div>
                            <div class="col-lg-12 details" id="space_overview" style="display: none;">
                            </div>
                        </div>

                        <?php if ($venue_data->events) { ?>
                            <div class="for_fc">
                                <div class="row">
                                    <div class="col-sm-12 single-venue-great-for">
                                        <span class="heading">Great For.</span>
                                    </div>
                                </div>
                                <div class="row">
                                    <ul id="bxslider_1"  class=" text-center">
                                        <?php
                                        foreach ($venue_data->events as $events) {
                                            ?>
                                            <li> <img class="size-new_1" src="<?php echo base_url('uploads/fnc_types/') . $events->image ?>"><span class="bottom_content_text"><?php echo $events->name ?></span></li>
                                            <?php
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        <?php } ?>

                        <div class="for_space" id="space_event_div" style="display:none">
                            <div class="row for_space" >
                                <div class="col-sm-12 single-venue-great-for">
                                    <span class="heading">Great For.</span>
                                </div>
                            </div>
                            <div class="row">
                                <ul id="space_event"  class=" new_slider_final text-center elastislide-list"></ul>
                            </div>
                        </div>

                        <?php if ($venue_data->facilities) { ?>
                            <div class="for_fc">
                                <div class="row ">
                                    <div class="col-sm-12 single-venue-venue-has">
                                        <span class="heading">The Venue Has.</span>
                                    </div>
                                </div>
                                <div class="row">
                                    <ul id="bxslider_2" class="  text-center">
                                        <?php
                                        foreach ($venue_data->facilities as $facilities) {
                                            ?>
                                            <li> <img class="size-new_1" src="<?php echo base_url('uploads/fnc_types/') . $facilities->image ?>"><span class="bottom_content_text"><?php echo $facilities->name ?></span></li>
                                            <?php
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        <?php } ?>

                        <div class="for_space" id="space_facilities_div" style="display:none">
                            <div class="row " >
                                <div class="col-sm-12 single-venue-venue-has">
                                    <span class="heading">The Venue Has.</span>
                                </div>
                            </div>
                            <div class="row">
                                <ul id="space_facilities"  class=" new_slider_final text-center elastislide-list"></ul>
                            </div>
                        </div>

                        <?php if ($venue_data->features) { ?>
                            <div class="for_fc">
                                <div class="row">
                                    <div class="col-sm-12 single-venue-venue-has">
                                        <span class="heading">The Venue Features.</span>
                                    </div>
                                </div>
                                <div class="row">
                                    <ul id="bxslider_3" class=" text-center">
                                        <?php
                                        foreach ($venue_data->features as $features) {
                                            ?>
                                            <li> <img class="size-new_1" src="<?php echo base_url('uploads/fnc_types/') . $features->image ?>"><span class="bottom_content_text"><?php echo $features->name ?></span></li>
                                            <?php
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        <?php } ?>

                        <div class="for_space" id="space_features_div" style="display:none">
                            <div class="row">
                                <div class="col-sm-12 single-venue-venue-has">
                                    <span class="heading">The Venue Features.</span>
                                </div>
                            </div>
                            <div class="row">
                                <ul id="space_features" class=" new_slider_final text-center elastislide-list"></ul>
                            </div>
                        </div>
                        <div class="close_icons_1" style="display:none"><img src="<?php echo base_url('assets/images/close_arrow.png'); ?>"></div>
                    </div>



                    <div class="maring_bottom_set_content details_section1">
                        <div class="review_head">The detail.</div>
                        <div class="heading_main_title">
                            <!--<spna>Space.</spna>-->
                            <p><?php echo $venue_data->fc_details ?></p>
                        </div>
                    </div>

                    <div id="reviews" class="space_change_div">
                        <div class="row">
                            <div class="col-lg-6 col-sm-4 col-xs-2 single-venue-overview text-left">
                                <span>Reviews.</span>
                            </div>
                            <div class="col-lg-6  col-sm-8 col-xs-10 pull-right">
                                <div class="reviews_div_107 single_venus_page_star">
                                    <?php
                                    $all_avg = $record_count = 0;
                                    $venue_id = encrypt_decrypt('decrypt', $this->uri->segment(2));
                                    $all_review = avg_review_count_venue($venue_id);
                                    if (!empty($all_review)) {
                                        $record_count = count($all_review);
                                        $main_count = 0;
                                        $sum = 0;
                                        foreach ($all_review as $key => $review) {
                                            $sum = (int) $review->f_rating_overall + (int) $review->f_rating_cleanliness + (int) $review->f_rating_accuracy + (int) $review->f_rating_comm;
                                            $avg = $sum / 4;
                                            $main_count = $main_count + $avg;
                                        }
                                        $all_avg = $main_count / $record_count;
                                    }

                                    echo generate_review_html($all_avg);
                                    if (empty($all_review)) {
                                        ?><span class="no-reviews">No reviews yet</span>  <?php } else { ?><span class="no-reviews"><?php echo $record_count ?>  Reviews</span>  <?php } ?>
                                </div>
                            </div>
                        </div>
                        <?php
                        if (!empty($venue_review)) {
                            ?>
                            <input type="hidden" id="r_venue_id" value="<?php echo encrypt_decrypt('decrypt', $this->uri->segment(3)) ?>">
                            <div class="all_coments">
                                <div class="row review_text review_rating tutorial_list">
                                    <?php
                                    $sum = 0;
                                    $count = count($venue_review);
                                    foreach ($venue_review as $key => $review) {
                                        $postID = $review->f_id;

                                        $user_image = $review->user_image;
                                        if (!empty($user_image))
                                            $img_url = $user_image;
                                        else
                                            $img_url = base_url() . 'uploads/users/FnC_user_icon.png';

                                        $sum = (int) $review->f_rating_overall + (int) $review->f_rating_cleanliness + (int) $review->f_rating_accuracy + (int) $review->f_rating_comm;
                                        $avg = $sum / 4;
                                        ?>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 user-rating-detail u_r_d-104" id="totalrating">
                                            <div class="col-sm-3 col-md-2 col-xs-3">
                                                <img class="img_rewiew_nee" src="<?php echo $img_url ?>">
                                            </div><!-- col-sm-3 -->
                                            <div class="col-sm-9 col-md-10 col-xs-9">
                                                <div class="comm_user-desc">
                                                    <span class="comm_author_name"><?php echo ucfirst($review->user_firstname . ' ' . $review->user_lastname) ?>.</span>
                                                    <div class="reviews_div_107">
                                                        <?php echo generate_review_html($avg); ?>
                                                        <span class="no-reviews"><?php echo date('F Y', strtotime($review->f_created_on)) ?></span>
                                                    </div>
                                                    <?php echo $review->f_text; ?>
                                                </div>

                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>                                    
                                </div>
                            </div>
                            <div class="row text-left col-sm-9 col-md-10 col-xs-9">
                                <?php
                                if ($all_row_count > DEFAULT_ROW_COUNT_REVIEW_PAGINATION) {
                                    ?>
                                    <div class="show_more_main" id="show_more_main<?php echo $postID; ?>">
                                        <span id="<?php echo $postID; ?>" class="show_more design_class design_single" title="Load more reviews">Show more</span>
                                        <span class="loding" style="display: none;"><span class="loding_txt">Loading....</span></span>  
                                    </div>
                                    <?php
                                }
                                ?>
                                <button id="review-write" data-fnc="<?php echo encrypt_decrypt('encrypt', $venue_data->fc_id); ?>" class="btn btn-default review_css">Review provided</button>
                            </div>


                            <?php
                        } else {
                            ?>
                            <div class="text-left">
                                <button id="review-write" data-fnc="<?php echo encrypt_decrypt('encrypt', $venue_data->fc_id); ?>" class="btn btn-default">Add Review <img src="<?php echo base_url('assets'); ?>/images/3.Add-for-add-review.svg"></button>
                            </div>
                            <?php
                        }
                        ?>
                    </div> <!--reviews-section-->


                    <div class="maring_bottom_set_content details_section2">
                        <div class="review_head">The detail.</div>
                        <div class="heading_main_title">
                            <!--<spna>Space.</spna>-->
                            <p><?php echo $venue_data->fc_details ?></p>
                        </div>
                    </div>




                </div><!--col-lg-8 col-sm-8-->

                <div class="col-lg-4 col-sm-4 details_section2">
                    <div class="space_change_modal"> <!-- blur class  space_change -->
                        <div class="contact-detail-venue">
                            <a href="<?php echo site_url('venue/add_to_wishlist'); ?>" id="add_wish_list">
                                <div class="contact-detail-venue-wish">
                                    <?php $user_wishlist = cheak_wishlist($wish_list, $venue_data->fc_id); ?>
                                    <span id="span-wishlist"><?php echo $user_wishlist['title'] ?></span>
                                    <?php echo $user_wishlist['img'] ?>
                                    <span></span>
                                </div>
                            </a>

                            <a href="">
                                <div id="send_to_friend" class="contact-detail-venue-wish c-d-v-w_104">
                                    <span id="span-wishlist">Send to a Friend</span>
                                    <img class="img-responsive" id="img-msg" src="<?php echo base_url(); ?>assets/images/6.Send-to-friend(1).svg">
                                </div>
                            </a>
                        </div><!-- contact-detail-venue -->
                        <div class="review_head">Venue Request:</div>
                    </div>

                </div><!--row-->



                <div class="col-lg-4 col-sm-4">
                    <div class="space_change_modal"> <!-- blur class  space_change -->
                        <div class="contact-detail-venue">
                            <div class="contact-page-form">
                                <form id="enq_form" name="edit_post">
                                    <input  type="hidden" name="fq_fc_id" id="venue_id" value="<?php echo encrypt_decrypt('encrypt', $venue_data->fc_id); ?>">
                                    <div class="contact-form-field">
                                        <span class="date">Preferred Function Date</span>
                                        <input  class="enquirydate" data-rule-required="true" name="fq_function_date" type="text" id="datepicker" placeholder="DD-MM-YYYY">
                                    </div>
                                    <div class="contact-form-field">
                                        <span>Proposed Number Of Guests</span>
                                        <input id="enq_guest" data-rule-required="true" name="fq_guest_no" class="enquiryguest" type="number" placeholder="Up to 30">
                                    </div>

                                    <div class="contact-form-field">
                                        <span>Type Of Event</span>
                                        <input class="questionhere1" data-rule-required="true" name="fq_event_type" type="text" placeholder="Wedding, birthday, corporate launch etc.">
                                    </div>
                                    <div class="contact-form-field">
                                        <span>Other Queries</span>
                                        <input class="questionhere2" data-rule-required="true" name="fq_other_queries" type="text" placeholder="Queries, special requests/requirements[etc]...">
                                    </div>
                                    <div class="contact-form-field">
                                        <input class="submit_button" id="query_submit" type="submit" value="Submit">
                                    </div>
                                </form>

                                <!-- fav btn strt-->
                            </div>

                            <a href="<?php echo site_url('venue/add_to_wishlist'); ?>" id="add_wish_list" class="details_section1">
                                <div class="contact-detail-venue-wish">
                                    <?php $user_wishlist = cheak_wishlist($wish_list, $venue_data->fc_id); ?>
                                    <span id="span-wishlist"><?php echo $user_wishlist['title'] ?></span>
                                    <?php echo $user_wishlist['img'] ?>
                                    <span></span>
                                </div>
                            </a>

                            <a href="" class="details_section1">
                                <div id="send_to_friend" class="contact-detail-venue-wish c-d-v-w_104">
                                    <span id="span-wishlist">Send to a friend</span>
                                    <img class="img-responsive" id="img-msg" src="<?php echo base_url(); ?>assets/images/6.Send-to-friend(1).svg">
                                </div>
                            </a>
                        </div><!-- contact-detail-venue -->
                    </div>


                    <section class="Location_section space_change details_section2">
                        <div class="clearfix"></div>
                        <div class="container">
                            <div class="row single-page-map">
                                <div class="col-lg-12">
                                    <span class="location-text">Location.</span>
                                    <div id="map"></div>
                                </div>
                            </div>
                        </div>
                    </section>


                    <div class="clearfix"></div>

                    <section class="section-5 Backgrond_color_set details_section2">
                        <div class="container">
                            <div class="row padding_responsive">
                                <div class="main">

                                    <div class="atribute atribute_margin_set hidden-xs" style="height: 0px;">

                                        <div class="imageContainer_1xligvk">
                                            <div class="container_18q6tiq container_18q6tiq_104">
                                                <div class="children_1szwzht">
                                                    <div class="container_e296pg container_e296pg_104">
                                                        <a href="http://localhost/fnc/view_venue/c2o4TGRaU0tGYXIxeitxNXNxdDZodz09">
                                                            <div class="set_img_b set_img_b_104" style="background-image: url(http://localhost/fnc/assets/images/Small_place_holder.jpg);">

                                                                <span></span>
                                                                <map name="planetmap_0">
                                                                    <area onclick="add_to_wishlist('c2o4TGRaU0tGYXIxeitxNXNxdDZodz09', '0');" shape="rect" coords="0,0,82,126" alt="Sun" href="javascript:void(0);">
                                                                </map>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>


                                        <div class="product-details-sea_1">
                                            <div id="content_1" class="main_text">ABBOTSFORD CONVENT</div>
                                            <br>
                                            <span class="function_text">Function</span>

                                            <div class="reviews_div_107 reviews-768">
                                                <ul><li></li><li></li><li></li><li></li><li></li></ul><span class="no-reviews">No reviews yet</span>                                  
                                            </div> 

                                            <p>
                                                Abbotsford Convent is a unique and beautiful place with a rare fusion of old and new. Its 19th century landscape is filled with...                                </p>
                                        </div>

                                        <div class="reviews_div_107 reviews_768">
                                            <ul><li></li><li></li><li></li><li></li><li></li></ul><span class="no-reviews">No reviews yet</span>                                  
                                        </div>  

                                    </div>



                                    <div class="atribute atribute_margin_set hidden-lg hidden-md hidden-sm" style="height: 382px;">



                                        <div class="product-details-sea_1">
                                            <div id="content_1" class="main_text">ABBOTSFORD CONVENT</div>
                                            <br>
                                            <span class="function_text">Function</span> 

                                            <div class="reviews_div_107">
                                                <ul><li></li><li></li><li></li><li></li><li></li></ul><span class="no-reviews">No reviews yet</span>                                  
                                            </div> 




                                            <p>
                                                Abbotsford Convent is a unique and beautiful place with a rare fusion of old and new. Its 19th century landscape is filled with...                                </p>

                                            <img src="http://localhost/fnc/assets/images/Small_place_holder.jpg" title="The long and winding road" class="img-responsive">



                                        </div>





                                        <div class="imageContainer_1xligvk hidden-xs">
                                            <div class="container_18q6tiq container_18q6tiq_104">
                                                <div class="children_1szwzht">
                                                    <div class="container_e296pg container_e296pg_104">
                                                        <a href="http://localhost/fnc/view_venue/c2o4TGRaU0tGYXIxeitxNXNxdDZodz09">
                                                            <div class="set_img_b set_img_b_104" style="background-image: url(http://localhost/fnc/assets/images/Small_place_holder.jpg);">
                                                                <span></span>
                                                                <map name="planetmap_0">
                                                                    <area onclick="add_to_wishlist('c2o4TGRaU0tGYXIxeitxNXNxdDZodz09', '0');" shape="rect" coords="0,0,82,126" alt="Sun" href="javascript:void(0);">
                                                                </map>
                                                            </div>


                                                        </a>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>





                                    </div>






                                    <div class="atribute atribute_margin_set hidden-xs" style="height: 0px;">

                                        <div class="imageContainer_1xligvk">
                                            <div class="container_18q6tiq container_18q6tiq_104">
                                                <div class="children_1szwzht">
                                                    <div class="container_e296pg container_e296pg_104">
                                                        <a href="http://localhost/fnc/view_venue/TWVWZ29PR3RNZ2hEVVVSQ1dZZEs3QT09">
                                                            <div class="set_img_b set_img_b_104" style="background-image: url(http://localhost/fnc/assets/images/Small_place_holder.jpg);">

                                                                <span></span>
                                                                <map name="planetmap_1">
                                                                    <area onclick="add_to_wishlist('TWVWZ29PR3RNZ2hEVVVSQ1dZZEs3QT09', '1');" shape="rect" coords="0,0,82,126" alt="Sun" href="javascript:void(0);">
                                                                </map>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>


                                        <div class="product-details-sea_1">
                                            <div id="content_1" class="main_text">STONES OF THE YARRA VALLEY</div>
                                            <br>
                                            <span class="function_text">Function</span>

                                            <div class="reviews_div_107 reviews-768">
                                                <ul><li></li><li></li><li></li><li></li><li></li></ul><span class="no-reviews">No reviews yet</span>                                  
                                            </div> 

                                            <p>
                                                Rising from the rustic, weather-beaten remnants of a barn left idle for generations,
                                                Stones of the Yarra Valley has emerged as...                                </p>
                                        </div>

                                        <div class="reviews_div_107 reviews_768">
                                            <ul><li></li><li></li><li></li><li></li><li></li></ul><span class="no-reviews">No reviews yet</span>                                  
                                        </div>  

                                    </div>



                                    <div class="atribute atribute_margin_set hidden-lg hidden-md hidden-sm" style="height: 382px;">



                                        <div class="product-details-sea_1">
                                            <div id="content_1" class="main_text">STONES OF THE YARRA VALLEY</div>
                                            <br>
                                            <span class="function_text">Function</span> 

                                            <div class="reviews_div_107">
                                                <ul><li></li><li></li><li></li><li></li><li></li></ul><span class="no-reviews">No reviews yet</span>                                  
                                            </div> 




                                            <p>
                                                Rising from the rustic, weather-beaten remnants of a barn left idle for generations,
                                                Stones of the Yarra Valley has emerged as...                                </p>

                                            <img src="http://localhost/fnc/assets/images/Small_place_holder.jpg" title="The long and winding road" class="img-responsive">



                                        </div>





                                        <div class="imageContainer_1xligvk hidden-xs">
                                            <div class="container_18q6tiq container_18q6tiq_104">
                                                <div class="children_1szwzht">
                                                    <div class="container_e296pg container_e296pg_104">
                                                        <a href="http://localhost/fnc/view_venue/TWVWZ29PR3RNZ2hEVVVSQ1dZZEs3QT09">
                                                            <div class="set_img_b set_img_b_104" style="background-image: url(http://localhost/fnc/assets/images/Small_place_holder.jpg);">
                                                                <span></span>
                                                                <map name="planetmap_1">
                                                                    <area onclick="add_to_wishlist('TWVWZ29PR3RNZ2hEVVVSQ1dZZEs3QT09', '1');" shape="rect" coords="0,0,82,126" alt="Sun" href="javascript:void(0);">
                                                                </map>
                                                            </div>


                                                        </a>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>





                                    </div>






                                    <div class="atribute atribute_margin_set hidden-xs" style="height: 0px;">

                                        <div class="imageContainer_1xligvk">
                                            <div class="container_18q6tiq container_18q6tiq_104">
                                                <div class="children_1szwzht">
                                                    <div class="container_e296pg container_e296pg_104">
                                                        <a href="http://localhost/fnc/view_venue/TWNDNFoxQit0M3FicG9ad3ROQzZEZz09">
                                                            <div class="set_img_b set_img_b_104" style="background-image: url(http://localhost/fnc/assets/images/Small_place_holder.jpg);">

                                                                <span></span>
                                                                <map name="planetmap_2">
                                                                    <area onclick="add_to_wishlist('TWNDNFoxQit0M3FicG9ad3ROQzZEZz09', '2');" shape="rect" coords="0,0,82,126" alt="Sun" href="javascript:void(0);">
                                                                </map>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>


                                        <div class="product-details-sea_1">
                                            <div id="content_1" class="main_text">MON BIJOU</div>
                                            <br>
                                            <span class="function_text">Function</span>

                                            <div class="reviews_div_107 reviews-768">
                                                <ul><li></li><li></li><li></li><li></li><li></li></ul><span class="no-reviews">No reviews yet</span>                                  
                                            </div> 

                                            <p>
                                                Set amongst the clouds high above Melbourne’s vibrant life this breath-taking penthouse space sets new standards in a realm of...                                </p>
                                        </div>

                                        <div class="reviews_div_107 reviews_768">
                                            <ul><li></li><li></li><li></li><li></li><li></li></ul><span class="no-reviews">No reviews yet</span>                                  
                                        </div>  

                                    </div>



                                    <div class="atribute atribute_margin_set hidden-lg hidden-md hidden-sm" style="height: 382px;">



                                        <div class="product-details-sea_1">
                                            <div id="content_1" class="main_text">MON BIJOU</div>
                                            <br>
                                            <span class="function_text">Function</span> 

                                            <div class="reviews_div_107">
                                                <ul><li></li><li></li><li></li><li></li><li></li></ul><span class="no-reviews">No reviews yet</span>                                  
                                            </div> 




                                            <p>
                                                Set amongst the clouds high above Melbourne’s vibrant life this breath-taking penthouse space sets new standards in a realm of...                                </p>

                                            <img src="http://localhost/fnc/assets/images/Small_place_holder.jpg" title="The long and winding road" class="img-responsive">



                                        </div>





                                        <div class="imageContainer_1xligvk hidden-xs">
                                            <div class="container_18q6tiq container_18q6tiq_104">
                                                <div class="children_1szwzht">
                                                    <div class="container_e296pg container_e296pg_104">
                                                        <a href="http://localhost/fnc/view_venue/TWNDNFoxQit0M3FicG9ad3ROQzZEZz09">
                                                            <div class="set_img_b set_img_b_104" style="background-image: url(http://localhost/fnc/assets/images/Small_place_holder.jpg);">
                                                                <span></span>
                                                                <map name="planetmap_2">
                                                                    <area onclick="add_to_wishlist('TWNDNFoxQit0M3FicG9ad3ROQzZEZz09', '2');" shape="rect" coords="0,0,82,126" alt="Sun" href="javascript:void(0);">
                                                                </map>
                                                            </div>


                                                        </a>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>





                                    </div>





                                </div>
                            </div>
                        </div>
                    </section>

                    <hr class="border-line">

                    <div class="adver space_change_bnner" style="display:none;">
                        <img src="<?php echo base_url(); ?>assets/images/img_advet_singalvenus.jpg" class="img-responsive adver_img">
                        <div class="positon_set_1" style="display:none">
                            <img class="img-responsive logo_adver" src="<?php echo base_url(); ?>assets/images/Functions_LogoFandC_w.png">
                            <h1>Register your <spna>business for <b>FREE</b></spna> Limited time only</h1>
                            <a class="register_now_title">Register now</a>
                        </div>

                        <div class="clearfix"></div>



                    </div><!-- col-lg-4 col-sm-4 -->
                </div><!--row-->
            </div><!--container-->
    </section>


    <section class="Location_section space_change details_section1">
        <div class="clearfix"></div>
        <div class="container">
            <div class="row single-page-map">
                <div class="col-lg-12">
                    <span class="location-text">Location.</span>
                    <div id="map"></div>
                </div>
            </div>
        </div>
    </section>

    <section class="setion_sign_v_p space_change">
        <div class="container">
            <?php
            if (!empty($nearest_to_me)) {
                ?>
                <div class="row ">
                    <div class="col-sm-12">
                        <span class="also-like also-like_103">You might also like.</span>
                    </div>
                </div>
                <div class="row respon_m">
                    <div class="main">
                        <?php
                        foreach ($nearest_to_me as $key => $value) {
                            if ($value->fc_type == 1) {
                                $url = base_url('web/single_venue/' . encrypt_decrypt('encrypt', $value->fc_id));
                            } else {
                                $url = base_url('web/single_catering/' . encrypt_decrypt('encrypt', $value->fc_id));
                            }

                            if (file_exists('uploads/fc_images/' . $value->fc_img_name) && !empty($value->fc_listing_picture)) {
                                $img_path = base_url('uploads/fc_images/' . $value->fc_listing_picture);
                            } else {
                                $img_path = base_url('assets/images/featured_image.jpg');
                            }
                            ?>
                            <a href="<?php echo $url ?>">
                                <div class="atribute">
                                    <div class="col-sm-4 col-xs-4 set_img_103" style="background: url(<?php echo $img_path; ?>) no-repeat 100% 100%;"></div>
                                    <div class="col-sm-8 col-xs-8 set_color_p">
                                        <span id="content_6" class="main_text"><?php echo $value->fc_business_name ?></span>
                                        <span class="function_text"><?php
                                            if ($value->fc_type == 1)
                                                echo 'Function';
                                            else
                                                echo 'Catering';
                                            ?></span>
                                        <p>
                                            <?php
                                            $string = $value->fc_overview;
                                            if (strlen($value->fc_overview) > 100) {
                                                $stringCut = substr($value->fc_overview, 0, 100);
                                                $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                            }
                                            echo $string;
                                            ?>
                                        </p>
                                        <div class="reviews_div_107">
                                            <?php echo review_count($value->fc_id); ?>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </section>
<?php } ?>
<!-- Modal -->
<div id="send_to_model" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Send to a friend</h4>
            </div>
            <div class="modal-body">
                <form id="send_frnd">
                    <input type="hidden" name="venue_url" id="venue_url" value="<?php echo current_url(); ?>">
                    <input type="hidden" name="venue_id" id="venue_id_friend" value="">
                    <div class="form-group">
                        <label for="email">Friend Name:</label>
                        <input type="text" data-rule-required="true" name="friend_name"  class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email"  name="email" data-rule-required="true" class="form-control" id="email">
                    </div>
                    <div class="form-group">
                        <label for="pwd">Message:</label>
                        <textarea name="massage"  id="massage" name="massage" data-rule-required="true" value="" class="form-control" id="pwd"></textarea>
                    </div>
                    <label class="lbl_class g-recaptcha" id="recaptcha" data-sitekey="6LferDsUAAAAAI1frwpcod-3sG6S5Tv3bFdkFbYE" ></label>
                    <span id="captcha_error"></span>
                    <button type="submit" id="submit_friend" class="btn btn-default">Send to a friend</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div id="error_model" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close close_error" data-dismiss="modal">&times;</button>
                <p id="error_text">Some text in the modal.</p>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    var slider_parameter = {
        autoPlay: false,
        navigation: true,
        items: 6,
        loop: false,
        itemsMobile: [479, 3],
        itemsTablet: [768, 3],
        itemsDesktop: [1199, 5],
        itemsDesktopSmall: [980, 4],
        rewindNav: false,
        navClass: ["nex", "pr"],
        lazyLoad: true,
        navigationText: ["<img src='" + base_url + "assets/images/left-arrow.png'>", "<img src='" + base_url + "assets/images/right-arrow.png'>"]
    };

    var slider_parameter1 = {
        autoPlay: false,
        navigation: true,
        items: 6,
        loop: false,
        itemsMobile: [479, 1],
        itemsTablet: [768, 1],
        itemsDesktop: [1199, 1],
        itemsDesktopSmall: [980, 4],
        rewindNav: false,
        navClass: ["nex", "pr"],
        lazyLoad: true,
        navigationText: ["<img src='" + base_url + "assets/images/left-arrow.png'>", "<img src='" + base_url + "assets/images/right-arrow.png'>"]
    };

    $("#bxslider_1").owlCarousel(slider_parameter);
    $("#bxslider_2").owlCarousel(slider_parameter);
    $("#bxslider_4").owlCarousel(slider_parameter1);
    $("#bxslider_3").owlCarousel(slider_parameter); //



    $('#header_dy').addClass('add-bg_color');

    $(function () {
        $("#datepicker").datepicker({
            format: "dd-mm-yyyy",
            todayHighlight: 'TRUE',
            autoclose: true,
            startDate: 'today',
            numberOfMonths: 2,
            maxDate: '+1M'
        });

        $("#review-write").click(function () {
            var fnc = $(this).data('fnc');
            $.ajax({
                url: '<?php echo site_url('web/check_review'); ?>',
                method: 'POST',
                data: {fnc: fnc},
                dataType: 'json',
                success: function (result) {
                    if (result.status) {
                        window.location.href = result.href;
                    } else {
                        $('#error_text').html(result.msg);
                        $('#error_model').modal('show');
                    }
                }
            });
        });
    });
    var map = '';
    function initialize() {
        var latlng = new google.maps.LatLng(<?php echo $venue_data->fc_lat ?>, <?php echo $venue_data->fc_lng ?>);
        var map = new google.maps.Map(document.getElementById('map'), {
            center: latlng,
            zoom: 12
        });

        var marker = new google.maps.Marker({
            map: map,
            position: latlng,
            draggable: false,
            anchorPoint: new google.maps.Point(0, -29),
            icon: base_url + 'assets/images/map_icon.svg'
        });

        var infowindow = new google.maps.InfoWindow();
        google.maps.event.addListener(marker, 'click', function () {
            var iwContent = '';
            // including content to the infowindow
            infowindow.setContent(iwContent);

            infowindow.open(map, marker);
        });
    }
    google.maps.event.addDomListener(window, 'load', initialize);

    $("#add_wish_list").click(function (e) {
        e.preventDefault();
        var venue_id = $('#venue_id').val();

        $.ajax({
            type: "POST",
            url: base_url + 'web/add_to_wishlist',
            data: {v_id: venue_id},
            success: function (response)
            {
                if (response == 'need_login') {
                    $('.alert').remove();
                    $.notify("You need to login first", {type: "info"});
                }

                if (response == 'success') {
                    $('.alert').remove();
                    $('#span-wishlist').html('Favorites added');
                    $('.change_0').attr('src', base_url + 'assets/images/icon_19.png');
                    $.notify("Added to Favorites", {type: "success"});
                }
                if (response == 'already') {
                    $('.alert').remove();
                    $('#span-wishlist').html('Add to Favorites');
                    $('.change_0').attr('src', base_url + 'assets/images/Add-to-wish-list.png');
                    $.notify("Removed from Favorites", {type: "info"});
                }
            },
            async: false
        });
    });

    $("#query_submit").click(function (e) {
        e.preventDefault();
        if ($("#enq_form").valid()) {
            var form_Element = document.getElementById("enq_form");
            var query_Data = new FormData(form_Element);
            var id = $('#venue_id').val();

            $.ajax({
                type: "POST",
                url: base_url + 'web/query_form_submit',
                data: query_Data,
                contentType: false,
                cache: false,
                processData: false,
                success: function (response)
                {
                    if (response == 'need_login') {
                        $.notify("You need to login first", {type: "info"});
                    }

                    if (response == 'success') {
                        $("#enq_form")[0].reset();
                        // $.notify("your query submit successfully", {type: "success"});
                        window.location.replace(base_url + "/user/submit_query_thank_you/" + id);
                    }
                },
                async: false
            });
        }
        ;
    });

    $(document).ready(function () {
        $("#send_to_friend").click(function (e) {
            e.preventDefault();
            $("#captcha_error").html('');
            var venue_id = $('#venue_id').val();
            var validator = $("#send_frnd").validate();
            validator.resetForm();
            $("#send_frnd")[0].reset()
            $('#send_to_model').modal('show');
            $('#venue_id').val('');
            $('#venue_id_friend').val(venue_id);
            var massage = 'Hello, I think this page is interesting';
            $('#massage').val(massage);
        });

        $("#submit_friend").click(function (e) {
            $("#captcha_error").html('');
            e.preventDefault();
            if ($("#send_frnd").valid()) {
                var form_Element = document.getElementById("send_frnd");
                var query_Data = new FormData(form_Element);

                var $captcha = $('#recaptcha'),
                        response = grecaptcha.getResponse();
                var is_submit = 0;

                if (response.length === 0)
                {
                    is_submit = 0;
                    $("#captcha_error").html('Please check Captcha')
                } else
                {
                    is_submit = 1;
                }

                if (is_submit == 1)
                {
                    $.ajax({
                        type: "POST",
                        url: base_url + 'web/send_to_friend',
                        data: query_Data,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (response)
                        {
                            if (response == 'need_login') {
                                $('.alert').remove();
                                $.notify("You need to login first", {type: "info"});
                            }

                            if (response == 'success') {
                                $("#send_to_model .close").click();
                                $("#enq_form")[0].reset();
                                $.notify("Send successfully", {type: "success"});
                            } else {
                                $("#send_to_model .close").click();
                            }
                        },
                        async: false
                    });
                }
            }
            ;
        });



        $(".venue_space").click(function (e) {
            e.preventDefault();
            var space_id = $(this).attr('data-value');

            add_loader();

            $.ajax({
                type: "POST",
                url: base_url + 'web/single_space',
                data: {space_id: space_id},
                success: function (response) {
                    var data = JSON.parse(response) //
                    if (data) {
                        $('#header_dy').removeClass('add-bg_color');

                        $('.space_change_div').addClass('review_div');
                        $('.space_change_bnner').addClass('adver_sml_bnner');
                        $('.space_change').addClass('back_101_1');
                        $('.space_change_modal').addClass('modal_set_105');

                        $('#fc_overview').css('display', 'none');
                        $('#space_overview').css('display', 'block');

                        $('.fnc_slider').css('display', 'none');
                        $('.space_slider').css('display', 'block');
                        if (data.space_image == '' || data.space_image == null) {
                            $('#space_banner').attr('src', base_url + 'assets/images/FnC_banner.jpg');
                        } else {
                            $('#space_banner').attr('src', base_url + 'uploads/venue_spaces/' + data.space_image);
                        }
                        $('.close_icons_1').css('display', 'block');
                        $('.space_change_modal').addClass('modal_set_105');

                        $('.banner_img').attr('src', base_url + 'uploads/fc_images/' + data.space_image);//
                        $('.for_fc').css('display', 'none');
                        $('.for_space').css('display', 'block');

                        $('#perfect_for').css('display', 'none');
                        $('#perfect_for_space').css('display', 'block');
                        $('#perfect_for_space').html('Perfect for ' + data.space_min_guest + '-' + data.space_max_guest + ' guests');
                        $('#space_overview').html(data.space_details);


                        $('#space_event').html('');
                        if (data.space_events) {
                            var event_data = '';
                            $.each(data.space_events, function (index, value) {   //
                                $('#space_event').append('<li><img class="size-new_1" src="' + base_url + 'uploads/fnc_types/' + value.image + '"><span class="bottom_content_text">' + value.name + '</span></li>');
                            });

                            $("#space_event_div").show();
                            $("#space_event").owlCarousel(slider_parameter);
                            $("#space_event").data('owlCarousel').reinit();
                        } else {
                            $("#space_event_div").hide();
                            //$("#space_event").data('owlCarousel').reinit();
                        }

                        $('#space_facilities').html('');
                        if (data.space_facilities) {
                            var facilities_data = '';
                            $.each(data.space_facilities, function (index, value) {
                                $('#space_facilities').append('<li><img class="size-new_1" src="' + base_url + 'uploads/fnc_types/' + value.image + '"><span class="bottom_content_text">' + value.name + '</span></li>');
                            });

                            $("#space_facilities_div").show();
                            $("#space_facilities").owlCarousel(slider_parameter);
                            $("#space_facilities").data('owlCarousel').reinit();
                        } else {
                            $("#space_facilities_div").hide();
                            //$("#space_facilities").data('owlCarousel').reinit();
                        }

                        $('#space_features').html('');
                        if (data.space_features) {
                            var features_data = '';
                            $.each(data.space_features, function (index, value) {
                                $('#space_features').append('<li><img class="size-new_1" src="' + base_url + 'uploads/fnc_types/' + value.image + '"><span class="bottom_content_text">' + value.name + '</span></li>');
                            });

                            $("#space_features").owlCarousel(slider_parameter);
                            $("#space_features").data('owlCarousel').reinit();
                            $("#space_features_div").show();
                        } else {
                            $("#space_features_div").hide();
                            //$("#space_features").data('owlCarousel').reinit();
                        }
                    }
                    $.unblockUI();
                }
            });
        });

        $(".close_icons_1").click(function (e) {
            e.preventDefault();
            $('#header_dy').addClass('add-bg_color');
            $('.space_change_div').removeClass('review_div');
            $('.space_change_bnner').removeClass('adver_sml_bnner');
            $('.space_change').removeClass('back_101_1');
            $('.space_change_modal').removeClass('modal_set_105');
            $('.fnc_slider').css('display', 'block');
            $('.space_slider').css('display', 'none');
            $('.close_icons_1').css('display', 'none');
            $('.for_fc').css('display', 'block');
            $('.for_space').css('display', 'none');
            $('#fc_overview').css('display', 'block');
            $('#space_overview').css('display', 'none');

            $('#perfect_for').css('display', 'block');
            $('#perfect_for_space').css('display', 'none');
            $('.space_change_modal').removeClass('modal_set_105');
        });
    });
    $(document).ready(function () {
        $(document).on('click', '.show_more', function () {
            var venue_id = $('#r_venue_id').val();
            var ID = $(this).attr('id');
            $('.show_more').hide();
            $('.loding').show();
            $.ajax({
                type: 'POST',
                url: base_url + 'web/load_review',
                data: {id: ID, is_load: 1, venue_id: venue_id},
                success: function (html) {
                    $('#show_more_main' + ID).remove();
                    $('.tutorial_list').append(html);
                }
            });
        });
    });

</script>

<script type="text/javascript">
    $(window).load(function () {
        /* Check width on page load*/

        if ($(window).width() < 768) {
            $('.space_change').removeClass('back_101_1');
        } else {
            //$('.space_change').addClass('back_101_1');
        }
    });

    $(window).ready(function () {
        /* Check width on page load*/

        if ($(window).width() < 768) {
            $('.space_change').removeClass('back_101_1');
        } else {
            //$('.space_change').addClass('back_101_1');
        }
    });

    $(window).resize(function () {
        /*If browser resized, check width again */
        if ($(window).width() < 768) {
            $('.space_change').removeClass('back_101_1');
        } else {
            $('.space_change').addClass('back_101_1');
        }
    });

</script>
<style>
    @media screen and (max-width:767px) {
        .space_change .adver space_change_bnner.adver_sml_bnner , .space_change .review_div{
            opacity: 1;
        }
        .space_change .nav.nav-pills.set_root_nav_pills li a{
            background-color: #03A9F4;
        }
        .single_venues_section.space_change .close_icons_1 close_sec a ,  .close_icons_1{
            display: none !important;
        }
        .space_change #space_event .owl-prev , .space_change #space_event .owl-next , .space_change #space_facilities_div .owl-prev , .space_change #space_facilities_div .owl-next , .space_change #space_features_div .owl-prev , .space_change #space_features_div .owl-next{
            display: none !important;
        }
        .space_change #space_event .owl-page , .space_change #space_facilities_div .owl-page , .space_change #space_features_div .owl-page
        {
            width: 12px;
            height: 12px;
            border: 1px solid #cccccc !important;
            background-color: #cccccc !important;
        }
        .space_change #space_event .owl-page.active , .space_change #space_facilities_div .owl-page.active  ,  .space_change #space_features_div .owl-page.active
        {
            background-color: #00b2ec !important;
            border: 1px solid #00b2ec !important;
        }
        #reviews{
            display: none;
        }
        .space_change .maring_bottom_set_content.details_section2 , .space_change .details_section2 , .Location_section.space_change details_section2 #map , .setion_sign_v_p space_change{
            display: none;
        }
        .adver_sml_bnner{
            opacity: 1;
            cursor: pointer;
        }
    }
</style>
