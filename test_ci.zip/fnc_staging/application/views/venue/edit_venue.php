<link rel="stylesheet" href="<?php echo base_url('assets/css/new-style.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/css/chosen.min.css'); ?>">
<!-- <style type="text/css">
   @media(max-width:1355px){
     .chosen-container .chosen-results{
        max-height: 120px;
    }
   }
</style>
 -->
<link rel="stylesheet" href="<?php echo base_url('assets/css/new-style.css'); ?>">
<script src="<?php echo base_url('assets/js/jquery.ezdz.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/chosen.jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/crope_images.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/coordinate.js'); ?>"></script>
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script>
    var get_cart = '<?php echo site_url('venue/get_cart'); ?>';
    var remove_cartitem = '<?php echo site_url('venue/remove_cartitem'); ?>';
    var div2clone = '<?php echo site_url('venue/div2clone'); ?>';
    var add_additonal_space = '<?php echo site_url('venue/add_additonal_space'); ?>';
    var remove_plan_product = '<?php echo site_url('venue/remove_plan_product'); ?>';
    var update_existing_plan = '<?php echo site_url('venue/update_existing_plan'); ?>';
    var removeCart = '<?php echo site_url('venue/removeCart'); ?>';
    var add_additonal_area = '<?php echo site_url('venue/add_additonal_area'); ?>';
    var remove_product = '<?php echo site_url('venue/remove_product'); ?>';
    var load_council = '<?php echo site_url('venue/load_council'); ?>';
    var lat = parseFloat('<?php echo $venue[0]->fc_lat; ?>');

    var lng = parseFloat('<?php echo $venue[0]->fc_lng; ?>');
    var search_suburb = '<?php echo site_url('web/search_suburb'); ?>';
    var search_postcode = '<?php echo site_url('web/search_postcode'); ?>';
    var search_area = '<?php echo site_url('venue/search_area'); ?>';
    var councilURL = '<?php echo site_url('venue/check_council'); ?>';
    var total_additional_region = <?php echo count($additinal_council); ?>;
     var STRIPE_PUBLIC_KEY = '<?php echo STRIPE_PUBLIC_KEY; ?>';
</script>

<script src="<?php echo base_url('assets/js/custom/edit-venue.js'); ?>"></script>
<?php
if (!empty($venue[0]->fc_valid_upto)) {
    $valid_date = $venue[0]->fc_valid_upto;
    if (strtotime($valid_date) > strtotime(date('Y-m-d'))) {
        $massage = 'Your current plan expire on ' . expireFormted($valid_date);
    } elseif (strtotime($valid_date) == strtotime(date('Y-m-d'))) {
        $massage = 'Today your plan expire ' . expireFormted($valid_date) . ' please update plans';
    } else {
        $massage = 'Plan expired on ' . expireFormted($valid_date) . ' please update plans';
    }
}
?>
<span class="postion_set_side_bar" style="display: none" id="total_tag" >
    <span class="pull-left"> Your Total:</span>
    <span class="pull-right total_of_update">$0</span>
</span>

<section class="function_vene_page">

    <div class="container">

        <div class="row main_row">



            <div class="col-sm-12">

                <div class="col-sm-12 dashboard_row">

                    <h4>Dashboard</h4>

                </div>

            </div>



            <!-- Loading Side Menu -->

            <?php $this->load->view('side_menu'); ?>



            <div class="col-md-8 col-sm-8">

                <form id="msform" method="post" action="" enctype="multipart/form-data">
                    <div id="main_venue_edit">
                        <div class="col-sm-12 profile_row das-2">
                            <div class="row top_background"><h4 class="pull-left">Update Package</h4></div><span class="pull-right your_plan_expire_tex"><?php echo $massage; ?></span>
                            <div class="row">
                                <div class="display_flex_set_d">
                                    <?php
                                    if (!empty($packs)) {
                                        foreach ($packs as $key => $value) {
                                            ?>
                                            <div class="col-md-6 col-sm-6 border_price_box " id="pack<?php echo $key; ?>">
                                                <span>
                                                    <div class="price_title " id="pack-title<?php echo $key; ?>">
                                                        <div class="price_content <?php echo ($value->pro_id == $venue[0]->fc_current_plan) ? 'fc_active_plan' : ''; ?>" id="pack-content<?php echo $key; ?>">
                                                            <?php echo $value->pro_title; ?>
                                                        </div>
                                                    </div>
                                                    <?php if ($value->pro_save != 0) { ?>
                                                        <div class="offet_side_bar"><a>Save $<?php echo $value->pro_save; ?></a></div>
                                                    <?php } ?>

                                                    <div class="offer_box_padding" id="pack-padding<?php echo $key; ?>">
                                                        <?php echo $value->pro_desc; ?>
                                                        <div class="choose_this_button">
                                                            <a data-pack="<?php echo $key; ?>" data-packtype="<?php echo $value->pro_id; ?>" class="choose_plan " href="javascript:;">Choose this plan</a>
                                                        </div>
                                                    </div>
                                                </span>
                                            </div><!--col-md-6-->
                                            <?php
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="firstcart" value="">

                        <div class="col-sm-12 profile_row das-2" style="display:none">
                            <?php if (!$subscrption) { ?>
                                <span>venue '<?php echo $venue[0]->fc_business_name ?>' can pay automatically</span>
                                <a href="javascript:void(0)" onClick="stripSubscriptionShow()" class="btn btn-primary subscriptbtn">Make it automatic</a>
                                <div class="col-md-12" id="strip_subscription" style="display: none">
                                    <div class="strip_form">

                                    </div>
                                    <input type="button" name="btnsub" onClick="activeSubscription()" id="active_subscription" class="action-button" value="Active subscription" />
                                  </div>
                                <?php } else { ?>
                                    <p>Your subscriptions is active </p><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#cancel_subcription_model">Cancel</button>
                                <?php } ?>

                            
                        </div>

                        <div class="col-sm-12 profile_row das-2">
                            <div class="row top_background"><h4>Function address </h4></div>
                            <div class="row">
                                <div class="col-lg-12 margin_top_row_106">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_street">Street</label>
                                        <input type="text" class="form-control" id="venue_street" name="venue_street" value="<?php echo $venue[0]->fc_street; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_state">State</label>
                                        <input type="text" class="form-control" id="venue_state" name="venue_state" value="<?php echo $venue[0]->fc_state; ?>" data-rule-required="true">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_suburb">Suburb</label>
                                        <input type="text" class="form-control ui-autocomplete-input valid ui-autocomplete-loading" id="venue_suburb" name="venue_suburb"  value="<?php echo $venue[0]->fc_suburb; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_postcode">Postcode</label>
                                        <input  type="number" class="form-control ui-autocomplete-input" id="venue_postcode" name="venue_postcode" value="<?php echo $venue[0]->fc_postcode; ?>" data-rule-required="true" >
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_country">Country</label>
                                        <input type="text" readonly="" class="form-control" id="venue_country" name="venue_country" value="<?php echo $venue[0]->fc_country; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <input type="hidden" class="form-control" id="venue_council" name="venue_council" value="<?php echo $venue[0]->fc_council; ?>" >
                                        <input type="hidden" class="form-control" id="council_id"  value="<?php echo $council_id; ?>" >
                                        <input type="hidden" class="form-control" id="zoom"  value="<?php echo ($zoom) ? $zoom : '' ?>" >

                                        <input type="hidden" name="number_region" id="number_region" value="<?php echo count($additinal_council); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <input type="button" class="create_map" id="create_map" value="Update your listing area">
                                <input type="hidden" id="council_arr" value="[]">
                                <input type="hidden" name="lat" id="lat" value="<?php echo $venue[0]->fc_lat; ?>">
                                <input type="hidden" name="lng" id="lng" value="<?php echo $venue[0]->fc_lng; ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 margin_106">
                                <h3 class="opening_your_venue_content your_venue_1 font_your_venue">Your venue will appear in '<span id="city-nm"><?php echo $council; ?></span>' search.</h3>
                                <div id="map-canvas"></div>
                                <h3 id="title-map-2" class="opening_your_venue_content your_venue_1 font_your_venue">You can list additional search regions for 20c per day per additional search area, with a maximum of 4 search areas.
                                </h3>
                                <div id="map-canvas2" class="map_edit_user"></div>

                                <div id="additional-area-row" class="row edit_reagon_user">
                                    <div class="col-md-12" id="edit_manage_area">
                                        <div class="plus-listing_new">
                                            <?php
                                            $cnt = 1;
                                            if ($additinal_council) {
                                                foreach ($additinal_council as $key => $val) {
                                                    $toottip = ($val->area_status == 2) ? 'data-toggle="tooltip" data-placement="top" title="Your payment verification pending, Pay by account "' : '';
                                                    ?>
                                                    <div id="region-area<?php echo $cnt ?>" class="new_block">
                                                        <a href="javascript:;" <?php echo $toottip ?> id="add-area<?php echo $cnt ?>" class="<?php echo ($val->area_status == 2) ? '' : 'remove_region'; ?>" data-cnt="<?php echo $cnt ?>"><span class="<?php echo ($val->area_status == 2) ? 'disable_area' : 'plus old_sign' . $cnt; ?>">-</span></a>
                                                        <span id="minima1" <?php echo $toottip ?> class="plus-section_new">
                                                            <select id="addition-area<?php echo $cnt ?>" data-active="1" data-cnt="<?php echo $cnt ?>" class="input-large form-control option_intialize addition-ar"  name="add_arr<?php echo $cnt ?>" >
                                                                <option disabled selected value>-- select council --</option>
                                                            </select>
                                                            <input type="hidden" name="area_<?php echo $cnt ?>" id="area_<?php echo $cnt ?>" value="<?php echo encrypt_decrypt('encrypt', $val->area_id) ?>">
                                                            <input type="hidden" id="region_name<?php echo $cnt ?>" value="<?php echo $val->area_name ?>">
<input type="hidden" id="its_live<?php echo $cnt ?>" value="<?php echo $val->area_status ?>">
 
                                                            <input type="hidden" id="region<?php echo $cnt ?>" value="<?php echo $val->council_id ?>">
                                                            <input type="hidden" name="add_arr_lat<?php echo $cnt ?>" id="addition-lat<?php echo $cnt ?>" value="<?php echo $val->area_lat ?>">
                                                            <input type="hidden" name="add_arr_lng<?php echo $cnt ?>" id="addition-lng<?php echo $cnt ?>" value="<?php echo $val->area_lng ?>">
                                                        </span>
                                                    </div>
                                                    <?php
                                                    $cnt++;
                                                }
                                            }

                                            if ($cnt <= 4) {
                                                for ($cnt; $cnt <= 4; $cnt++) {
                                                    ?>
                                                    <div id="region-area<?php echo $cnt ?>" class="new_block">
                                                        <a href="javascript:;" id="add-area<?php echo $cnt ?>" class="add-area" data-cnt="<?php echo $cnt ?>"><span class="plus old_sign<?php echo $cnt ?>">+</span></a>
                                                        <span id="minima1" class="plus-section_new">
                                                            <select id="addition-area<?php echo $cnt ?>" data-active="0" data-cnt="<?php echo $cnt ?>" class="input-large option_intialize form-control"  name="new_add_arr[]" >
                                                                <option disabled selected value>-- Add new council --</option>
                                                            </select>
                                                            <input type="hidden" id="region_name<?php echo $cnt ?>" value="">
                                                            <input type="hidden" id="region<?php echo $cnt ?>" value="">
                                                            <input type="hidden" name="add_arr_lat[]" id="addition-lat<?php echo $cnt ?>" value="">
                                                            <input type="hidden" name="add_arr_lng[]" id="addition-lng<?php echo $cnt ?>" value="">
                                                        </span>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="lat-temp">
                        <input type="hidden"  id="lng-temp">
                        <input type="hidden"  id="area_row_id" value="">
                        <input type="hidden" id="plan2" value="3">
                        <input type="hidden" id="a_row_id">
                        <input type="hidden" id="s_row_id">

                        <div class="col-sm-12 profile_row border_progress_page fountion_1">
                            <div class="row top_background">
                                <h4>Venue </h4></div>
                            <div class="row">
                                <div class="col-lg-12 margin_top_row_106">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_business_name">Business name</label>
                                        <input type="text" class="form-control" data-msg-remote="this name already exist" data-rule-remote="<?php echo site_url('venue/check_business_name/') . '?fc_id=' . encrypt_decrypt('encrypt', $venue[0]->fc_id); ?>" name="venue_business_name" value="<?php echo $venue[0]->fc_business_name; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_abn">ABN</label>
                                        <input type="text"  class="form-control" name="venue_abn" value="<?php echo $venue[0]->fc_abn; ?>" data-rule-required="true" data-rule-abn_number="true">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_contact_name">Contact name</label>
                                        <input type="text" class="form-control" name="venue_contact_name" value="<?php echo $venue[0]->fc_contact_name; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_phone_no">Phone number</label>
                                        <input type="text" class="form-control phone_no" name="venue_phone_no" value="<?php echo $venue[0]->fc_phone_no; ?>" data-rule-required="true">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_website">Website</label>
                                        <input type="text"  class="form-control" name="venue_website" value="<?php echo $venue[0]->fc_website; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="venue_email">Email</label>
                                        <input type="text" class="form-control" name="venue_email" value="<?php echo $venue[0]->fc_email; ?>" data-rule-required="true"  data-rule-email="true">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                        if (!empty($venue[0]->fc_listing_picture)) {
                            $img_url = base_url('uploads/fc_images') . '/' . $venue[0]->fc_listing_picture;
                        } else {
                            $img_url = '';
                        }
                        ?>
                        <div class="col-sm-12 profile_row border_progress_page fountion_1">
                            <div class="row top_background">
                                <h4>Main Image </h4>
                            </div>
                            <div class="row margin_top_row_second_106 up-image-row">
                                <div class="col-md-12 text-left">
                                    <div  class="ulpading_img_size_3 listing_picture_thumb">
                                        <img  id="show_image_55555" class="dropzone" img-id="55555" src="<?php echo $img_url; ?>" style="<?php echo ($img_url) ? 'display:block' : 'display:none' ?>">
                                        <input type="file" onclick="this.value=null;" name="fc_listing_picture" data-id="55555" class="file-selector image_selector" id="image_selector_55555" accept="image/*">
                                        <input type="hidden" name="dimesion_image_55555" id="dimesion_image_55555" value="0">   
                                        <img class="remove_image" onclick="removeImage(1, '<?php echo encrypt_decrypt('encrypt', $venue[0]->fc_id); ?>', 1, 55555)" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                    </div>
                                    <div class="ulpading_img_size_3_1 listing_picture_thumb">
                                        <div>
                                            To have your venue looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 300 x 530 pixels.
                                        </div>
                                        <div class="row" >
                                            <label ant-id="55555" class="upload-button_new after_102" id="another_select_55555">
                                                <i  class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 profile_row fountion_2">
                            <div class="row top_background text-left">
                                <h4>Venue images</h4>
                            </div>
                            <?php
                            $last_key = 1;
                            $img_status = TRUE;
                            $img_count = 5;
                            if (!empty($venue_images)) {
                                foreach ($venue_images as $key => $value) {
                                    $img_url = (!empty($value->fc_img_name)) ? base_url('uploads/fc_images') . '/' . $value->fc_img_name : '';
                                    ?>
                                    <div class="row margin_top_row_second_106 up-image-row">
                                        <div class="col-md-12 text-left">
                                            <div class="ulpading_img_size_3">
                                                <img img-id="<?php echo $key + 1; ?>" style="display:<?php echo ($img_url) ? 'block' : 'none' ?>" class="dropzone" id="show_image_<?php echo $key + 1; ?>" src="<?php echo $img_url; ?>">
                                                <input type="file" onclick="this.value=null;" data-id="<?php echo $key + 1; ?>" name="venue_image<?php echo $key; ?>" id="image_selector_<?php echo $key + 1; ?>" class="file-selector image_selector" accept="image/*">
                                                <input type="hidden" name="dimesion_image_<?php echo $key + 1; ?>" id="dimesion_image_<?php echo $key + 1; ?>" value="0">
                                                <img onclick="removeImage(2, '<?php echo encrypt_decrypt('encrypt', $value->fc_img_id); ?>', 1, <?php echo $key+1; ?>)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                                
                                            </div>
                                            <div class="ulpading_img_size_3_1">
                                                <?php
                                                if ($key == 0) {
                                                    $img_status = FALSE;
                                                    ?>
                                                    <div>
                                                        To have your venue looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                    </div>
                                                <?php } ?>
                                                <div class="row">
                                                    <label ant-id="<?php echo $key + 1; ?>" class="upload-button_new after_102">
                                                        <input type="hidden" name="image<?php echo $key; ?>" value="<?php echo $value->fc_img_id; ?>">
                                                        <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $last_key = $key + 1;
                                    $img_count = $img_count - 1;
                                }
                                $last_key = $last_key + 1;
                            }
                            if ($img_count > 0) {
                                $crp = $last_key;
                                ?>
                                <input type="hidden" name="img_count" value="<?php echo $img_count; ?>">
                                <?php
                                for ($i = 1; $i <= $img_count; $i++) {
                                    ?>
                                    <div class="row margin_top_row_second_106 up-image-row">
                                        <div class="col-md-12 text-left">
                                            <div class="ulpading_img_size_3">
                                                <img img-id="<?php echo $crp; ?>" class="dropzone" id="show_image_<?php echo $crp; ?>" src="" style="display:none">
                                                <input type="file" onclick="this.value=null;" name="venue_image[]" data-id="<?php echo $crp; ?>" class="file-selector image_selector" id="image_selector_<?php echo $crp; ?>" accept="image/*">
                                                <input type="hidden" name="dimesion_image_<?php echo $crp; ?>" id="dimesion_image_<?php echo $crp; ?>" value="0">
                                            </div>
                                            <div class="ulpading_img_size_3_1">
                                                <?php
                                                if ($img_status) {
                                                    $img_status = FALSE;
                                                    ?>
                                                    <div>
                                                        To have your venue looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                    </div>
                                                <?php } ?>
                                                <div class="row">
                                                    <label ant-id="<?php echo $crp; ?>" class="upload-button_new after_102">
                                                        <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $crp++;
                                }
                            }
                            ?>
                        </div>
                        <div class="col-sm-12 profile_row fountion_3">
                            <div class="row top_background text-left">
                                <h4>Price per head </h4>
                            </div>
                            <div class="row">
                                <div class="text-left">
                                    <div class="col-md-6">
                                        <?php
                                        $price_arr = array();
                                        if (!empty($venue[0]->fc_pricing)) {
                                            $price_arr = explode(',', $venue[0]->fc_pricing);
                                        }
                                        if (!empty($price_per_head)) {
                                            $dollar_count = 1;
                                            foreach ($price_per_head as $value) {
                                                ?>
                                                <label class="set_label_venu">
                                                    <?php
                                                    $checked_pricing = '';
                                                    if (in_array($value->p_id, $price_arr)) {
                                                        $checked_pricing = 'checked';
                                                    }
                                                    ?>
                                                    <label class="regular-checkbox pull-left r-p-n-501">
                                                        <input name="venue_pricing[]" type="checkbox" value="<?php echo $value->p_id; ?>" <?php echo $checked_pricing; ?>>
                                                        <small></small>
                                                    </label>
                                                    <div class="dolor_icon"><?php
                                                        for ($i = 0; $i < $dollar_count; $i++) {
                                                            echo '$';
                                                        }
                                                        ?></div>
                                                    <span><?php echo $value->p_name; ?></span>

                                                </label>
                                                <?php
                                                if ($dollar_count % 2 == 0)
                                                    echo '</div><div class="col-md-6">';
                                                $dollar_count++;
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 profile_row fountion_4">
                            <div class="row top_background text-left">
                                <h4>Overview-Venue Details</h4>
                            </div>
                            <div class="row">
                                <div class="col-md-12 text-left">
                                    <label class="">Overview</label>
                                    <textarea class="form-control overview_textarea textare_root" placeholder="This is a short introductory overview that describes your venue. &#10;Max 400 words." name="venue_overview" data-rule-required="true" data-rule-maxlength="400" data-rule-required="true" data-rule-maxlength="800"><?php echo $venue[0]->fc_overview; ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 profile_row fountion_5">
                            <div class="row top_background text-left">
                                <h4>Event types</h4>
                            </div>
                            <div class="row margin_top_row_second_106">
                                <div class="form-check form-check-inline">
                                    <?php
                                    $event_arr = array();
                                    if (!empty($venue_details)) {
                                        if (!empty($venue_details[0]->vd_events)) {
                                            $event_arr = explode(',', $venue_details[0]->vd_events);
                                        }
                                    }
                                    if (!empty($event_types)) {
                                        foreach ($event_types as $e_type) {
                                            ?>
                                            <div class="col-md-6 text-left pass">
                                                <label class="set_label_venu">
                                                    <?php
                                                    $checked_event = '';
                                                    if (in_array($e_type->id, $event_arr)) {
                                                        $checked_event = 'checked';
                                                    }
                                                    ?>
                                                    <label class="regular-checkbox pull-left r-p-n-501">
                                                        <input type="checkbox" name="venue_events[]" value="<?php echo $e_type->id; ?>" <?php echo $checked_event; ?>>
                                                        <small></small>
                                                    </label>
                                                    <div class="dolor_icon size_set_ic"><img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->image; ?>"></div>
                                                    <span><?php echo $e_type->name; ?></span>
                                                </label>
                                            </div>
                                            <?php
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 profile_row fountion_6">
                            <div class="row top_background text-left">
                                <h4>Facilities</h4>
                            </div>
                            <div class="row margin_top_row_second_106">
                                <div class="form-check form-check-inline">
                                    <?php
                                    $facility_arr = array();
                                    if (!empty($venue_details)) {
                                        if (!empty($venue_details[0]->vd_facilities)) {
                                            $facility_arr = explode(',', $venue_details[0]->vd_facilities);
                                        }
                                    }
                                    if (!empty($facilities)) {
                                        foreach ($facilities as $f_val) {
                                            ?>
                                            <div class="col-md-6 text-left pass_1">
                                                <label class="set_label_venu">
                                                    <?php
                                                    $checked_facility = '';
                                                    if (in_array($f_val->id, $facility_arr)) {
                                                        $checked_facility = 'checked';
                                                    }
                                                    ?>
                                                    <label class="regular-checkbox pull-left r-p-n-501">
                                                        <input  type="checkbox" name="venue_facilities[]" value="<?php echo $f_val->id; ?>" <?php echo $checked_facility; ?>>
                                                        <small></small>
                                                    </label>
                                                    <div class="dolor_icon size_set_ic">
                                                        <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->image; ?>">
                                                    </div>
                                                    <span><?php echo $f_val->name; ?></span>
                                                </label>
                                            </div>
                                            <?php
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 profile_row fountion_6">
                            <div class="row top_background text-left">
                                <h4>Features</h4>
                            </div>
                            <div class="row margin_top_row_second_106">
                                <div class="form-check form-check-inline">
                                    <?php
                                    $feature_arr = array();
                                    if (!empty($venue_details)) {
                                        if (!empty($venue_details[0]->vd_features)) {
                                            $feature_arr = explode(',', $venue_details[0]->vd_features);
                                        }
                                    }
                                    if (!empty($features)) {
                                        foreach ($features as $feat_val) {
                                            ?>
                                            <div class="col-md-6 text-left pass_1">
                                                <label class="set_label_venu">
                                                    <?php
                                                    $checked_feature = '';
                                                    if (in_array($feat_val->id, $feature_arr)) {
                                                        $checked_feature = 'checked';
                                                    }
                                                    ?>
                                                    <label class="regular-checkbox pull-left r-p-n-501">
                                                        <input  type="checkbox" name="venue_features[]" value="<?php echo $feat_val->id; ?>" <?php echo $checked_feature; ?>>
                                                        <small></small>
                                                    </label>
                                                    <div class="dolor_icon size_set_ic">
                                                        <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->image; ?>">
                                                    </div>
                                                    <span><?php echo $feat_val->name; ?></span>
                                                </label>
                                            </div>
                                            <?php
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 profile_row fountion_7">
                            <div class="row top_background text-left">
                                <h4>Venue in detail</h4>
                            </div>
                            <div class="row margin_top_row_second_106">
                                <div class="col-md-12 text-left">
                                    <label class="text-left" for="venue_description">Details</label>
                                    <textarea rows="4" class="form-control overview_textarea textare_root" placeholder="This section allows for more venue details if required. Not mandatory. &#10;Max 800 words" data-rule-required="true" data-rule-maxlength="800" name="venue_details"><?php echo $venue[0]->fc_details; ?></textarea>
                                </div>
                            </div>
                            <div class="row margin_top_and_bottom_user">
                                <div class="col-md-6 text-left">
                                    <label class="lbl_class" for="venue_max_guest">Minimum guest numbers</label>
                                    <input type="text" data-rule-lessThan="#venue_max_guest" id="venue_min_guest" class="form-control" name="venue_min_guest" value="<?php echo $venue[0]->fc_min_guest; ?>">
                                </div>
                                <div class="col-md-6 text-left">
                                    <label class="lbl_class" for="venue_min_guest">Maximum guest numbers</label>
                                    <input type="text" data-rule-greaterThan="#venue_min_guest" id="venue_max_guest" class="form-control" name="venue_max_guest" value="<?php echo $venue[0]->fc_max_guest; ?>">
                                </div>

                            </div>

                            <div id="list-an" class="row margin_top_ohNo">
                                <div class="col-md-8 col-xs-12 col-sm-12">
                                    <div class="oh_no_content">Does your venue have multiple function areas with different guest capacity? You can list another space within a venue for $30c a day</div>
                                </div>
                                <div class="col-md-4 bottom_button col-xs-12 col-sm-12">
                                    <button type="button" id="list-another-1" class="i_need_venue_button">List another space</button>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 margin_top_but_102" style="display:none">
                            <div class="row">
                                <span class="Plus_102">+</span><span class="add_another_102" id="add-an-1_space">Add another space</span> 
                                <span id="just-one-space" class="just_one_102">Just one space please</span>
                            </div>
                        </div>

                        <div style="display: none" id="another-space-div">
                            <div id="append2divspace">
                                <div class="div2clone">

                                    <div class="col-sm-12 profile_row fountion_7">
                                        <div class="row top_background text-left set_new_102">
                                            <h4 class="h4-title">Space One</h4>
                                        </div>
                                        <div class="row margin_top_and_bottom_user">
                                            <div class="col-md-12 margin_set_input text-left">
                                                <label class="lbl_class">Space name</label>
                                                <input type="text" class="form-control fm-field" name="space_name1" data-rule-required="true" value="">
                                            </div>
                                            <div class="margin_set_input text-left">
                                                <div class="col-md-6 margin_set_input">
                                                    <label class="lbl_class">Minimum guest numbers</label>
                                                    <input type="text" class="form-control fm-field" data-rule-lessThan="#space_max_guest1" id="space_min_guest1" name="space_min_guest1" data-rule-required="true" value="">
                                                </div>
                                                <div class="col-md-6 margin_set_input ">
                                                    <label class="lbl_class">Maximum guest numbers</label>
                                                    <input type="text" class="form-control fm-field" data-rule-greaterThan="#space_min_guest1" id="space_max_guest1" name="space_max_guest1" data-rule-required="true" value="">
                                                </div>

                                            </div>

                                            <div class="col-md-12 text-left margin_set_input">
                                                <label class="text-left">Details</label>
                                                <textarea rows="4" class="form-control overview_textarea textare_root fm-field" name="space_details1" data-rule-required="true" data-rule-maxlength="800"></textarea>
                                            </div>


                                            <div class="col-md-12">
                                                <div class="ulpading_img_size_3">
                                                    <img id="show_image_6" img-id="6" class="dropzone" src="" style="display:none">
                                                    <input type="file" onclick="this.value=null;" data-id="6" id="image_selector_6" class="file-selector fm-field image_selector" name="space_image1">
                                                    <input type="hidden" name="dimesion_image_6" id="dimesion_image_6" value="0">
                                                    <img class="remove_image" onclick="removeImage(3, '0', 1, 6)" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                                </div>

                                                <div class="ulpading_img_size_3_1">
                                                    <div class="row">
                                                        <span id="fileselector">
                                                            <label ant-id="6" class="upload-button_new after_102">
                                                                <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                            </label>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 profile_row fountion_5">
                                        <div class="row top_background text-left set_new_102">
                                            <h4 class="h4-events">Space One - Event types</h4>
                                        </div>
                                        <div class="row margin_top_row_second_106">
                                            <div class="form-check form-check-inline">

                                                <?php
                                                if (!empty($event_types)) {
                                                    foreach ($event_types as $e_type) {
                                                        ?>
                                                        <div class="col-md-6 text-left pass">
                                                            <label class="set_label_venu">

                                                                <label class="regular-checkbox pull-left r-p-n-501">
                                                                    <input type="checkbox" type="checkbox" name="space_events1[]" value="<?php echo $e_type->id; ?>" >
                                                                    <small></small>
                                                                </label>

                                                                <div class="dolor_icon size_set_ic">
                                                                    <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->image; ?>">
                                                                </div>
                                                                <span><?php echo $e_type->name; ?></span>

                                                            </label>
                                                        </div>
                                                        <?php
                                                    }
                                                }
                                                ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 profile_row fountion_5">
                                        <div class="row top_background text-left set_new_102">
                                            <h4 class="h4-facilities">Space One - Facilities</h4>
                                        </div>
                                        <div class="row margin_top_row_second_106">
                                            <div class="form-check form-check-inline">
                                                <?php
                                                if (!empty($facilities)) {
                                                    foreach ($facilities as $f_val) {
                                                        ?>
                                                        <div class="col-md-6 text-left pass">
                                                            <label class="set_label_venu">

                                                                <label class="regular-checkbox pull-left r-p-n-501">
                                                                    <input type="checkbox" name="space_facilities1[]" value="<?php echo $f_val->id; ?>">
                                                                    <small></small>
                                                                </label>
                                                                <div class="dolor_icon size_set_ic">
                                                                    <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->image; ?>">
                                                                </div>
                                                                <span><?php echo $f_val->name; ?></span>


                                                            </label>
                                                        </div>
                                                        <?php
                                                    }
                                                }
                                                ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 profile_row fountion_5">
                                        <div class="row top_background text-left set_new_102">
                                            <h4 class="h4-features">Space One - Features</h4>
                                        </div>
                                        <div class="row margin_top_row_second_106">
                                            <div class="form-check form-check-inline">

                                                <?php
                                                if (!empty($features)) {
                                                    foreach ($features as $feat_val) {
                                                        ?>
                                                        <div class="col-md-6 text-left pass">
                                                            <label class="set_label_venu">
                                                                <label class="regular-checkbox pull-left r-p-n-501">
                                                                    <input type="checkbox" name="space_features1[]" value="<?php echo $feat_val->id; ?>">
                                                                    <small></small>
                                                                </label>
                                                                <div class="dolor_icon size_set_ic"><img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->image; ?>"></div>
                                                                <span><?php echo $feat_val->name; ?></span>



                                                            </label>
                                                        </div>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>

                            <div class="clearfix"></div>

                            <div class="col-md-12 margin_top_but_102">
                                <div class="row">
                                    <span class="Plus_102">+</span><span class="add_another_102" id="add-an-1_space">Add another space</span> 
                                    <span id="just-one-space" class="just_one_102">Just one space please</span>
                                </div>
                            </div>

                            <input type="hidden" id="total_another" name="total_another" value="">
                            <input type="hidden" name="plan3" id="plan3" value="4">
                            <input type="hidden" id="space_row_id">
                        </div>


                        <input type="hidden" id="fc_id" name="venue" value="<?php echo encrypt_decrypt('encrypt', $venue[0]->fc_id); ?>">
                        <a href="javascript:void(0)" id="update_venue_only" class="create_map">Update venue</a>

                        <button type="button" id="update_and_pay" style="display:none" class="create_map">Update & pay</button>
                        <a class="cancel_button_venue_catering" href="<?php echo site_url('venue/my_venues') ?>">Cancel</a>
                    </div>

                    <div id="payment_div" style="display:none">
                        <fieldset class="fieldset_1">
                            <div class="list_your_venu_content Payment">Payment summary</div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div id="m-cart"></div>

                                    <div class="padding_and_border_top_bottom">
                                        <div class="Your_total">
                                            Your total
                                        </div>

                                        <div class="your_price_show" id="grand-total">
                                            $0
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--</div>-->

                            <span id="voucher_massage"></span>
                            <div id="cart-div" class="row maring_row_cart_page">
                                <div  class="voucher_div">
                                    <div class="col-md-8 col-sm-8 col-xs-12 text-left">
                                        <label class="lbl_class">Add voucher code</label>
                                        <input name="voucher_code" id="voucher" type="text" class="form-control add_voucher_code addr-field" placeholder="" >
                                        <label style="display: none;" id="voucher-error" class="custom-error"></label>
                                    </div>
                                    
                                    <div class="col-md-4 col-sm-4 col-xs-12 pull-right">
                                        <div class="choose_this_button second apply_button">
                                            <a class="apply_voucher" onclick="appaly_voucher(1, 2);" href="javascript:void(0)">Apply</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-12" id="payment_method">
                                    <h2 class="h_pay">Payment method</h1>
                                        <p class="pay_tap_div">
                                          <span class="pay_radio_button">
                                           
                                            <label class="regular-checkbox pull-left">
                                                <input type="radio" class="payment_method" onclick="choose_payment(1, 1, 2)" name="payment_method" value="1">
                                                <small></small>
                                            </label>
                                             <span class="pull-left"> Pay by Stripe</span>
                                       </span>
                                       <span class="pay_radio_button">
                                           
                                            <label class="regular-checkbox pull-left">
                                              <input type="radio" class="payment_method" onclick="choose_payment(2, 1, 2)" name="payment_method" value="2">
                                                <small></small>
                                            </label>
                                             <span class="pull-left"> Pay by account</span>
                                       </span>
                                    </p>
                                    <input type="hidden" id="selected_method" value="0">
                                     <label style="display: none;" id="payment_method-error">Please select payment method</label>
                                </div>

                                <div class="col-md-12" id="strip_payment" style="display: none">
                                     <div class="row color_set_gray">
                                        <div class="col-md-8 pull-left">

                                            <div class="form-group owner">
                                                <label class="card_number_label">Card Number</label>
                                                <input type="text" id="cardnumber" class="form-control-1 car_input_number card-number addr-field">
                                                <label style="display: none;" id="cardnumber-error" class="custom-error"></label>
                                            </div>

                                            <div class="cart_icon_set">
                                                <ul>
                                                    <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_card_visa-128.png" class="img-responsive"></li>
                                                    <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_discover_network_card-128.png" class="img-responsive"></li>
                                                    <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_master_card-128.png" class="img-responsive"></li>
                                                    <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_google_wallet-128.png" class="img-responsive"></li>
                                                </ul>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-8 padding-right_106">
                                                    <div class="form-group CVV" id="expiration-date">
                                                        <label class="card_number_label">Expires Date</label>
                                                        <select name="select2" id="cardexpiry" class="select_month card-expiry-month" data-stripe="exp-month">
                                                            <option value="01" selected="">January</option>
                                                            <option value="02">February </option>
                                                            <option value="03">March</option>
                                                            <option value="04">April</option>
                                                            <option value="05">May</option>
                                                            <option value="06">June</option>
                                                            <option value="07">July</option>
                                                            <option value="08">August</option>
                                                            <option value="09">September</option>
                                                            <option value="10">October</option>
                                                            <option value="11">November</option>
                                                            <option value="12">December</option>
                                                        </select>
                                                        <select name="select2" id="cardexpiry" class="select_month card-expiry-year" data-stripe="exp-year"></select>
                                                        <script type="text/javascript">
                                                            var select = $(".card-expiry-year"),
                                                                    year = new Date().getFullYear();

                                                            for (var i = 0; i < 12; i++) {
                                                                select.append($("<option value='" + (i + year) + "' " + (i === 0 ? "selected" : "") + ">" + (i + year) + "</option>"))
                                                            }
                                                        </script>
                                                    </div>
                                                    <label style="display: none;" id="cardexpiry-error" class="custom-error"></label>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="card_number_label">Security Code</label>
                                                    <input type="text" id="cvv" class="form-control-1 car_input_number card-cvc addr-field" placeholder="CVV">
                                                    <label style="display: none;" id="cvv-error" class="custom-error"></label>
                                                </div>

                                                <div class="form-group owner col-md-12">
                                                    <label class="card_number_label">Name</label>
                                                    <input type="text" name="cardholdername" id="cardholdername" class="form-control-1 car_input_number card-holder-name addr-field">
                                                    <label style="display: none;" id="cardholdername-error" class="custom-error"></label>
                                                </div>

                                                <div class="form-group owner col-md-6">
                                                    <label class="card_number_label">Order Amount</label>
                                                    <input type="text" readonly="" name="amt" id="amt" value="0" class="form-control-1 car_input_number">
                                                    <input type="hidden" id="amt_total" value="0">
                                                </div>

                                               <div class="col-md-12">
                                                    <div class="right_aling_card_root_101">
                                                        <label class="regular-checkbox ">
                                                            <input class="checkbox_set" type="checkbox" name="agree" value="1" data-rule-required="true">
                                                            <small></small>
                                                        </label>
                                                        <span>I agree with the <a href="<?php echo base_url() ?>/term_condition" target="_blank">Terms & Conditions.</a></span>
                                                    </div>
                                                </div>

                                            </div>
                                            <!--</form>-->

                                        </div>
                                        <div class="col-md-4"></div>
                                          <!-- <div class="col-md-12 mt-1">
                                            <table width="100%">
                                                <tr>
                                                    <td class="text-not"><b>Note: </b></td>
                                                    <td>When you select Pay by Account than after send invoice on mail with Function & Catering accounts details. If your payment approved than after Active your Venue/catering.</td>
                                                </tr>
                                            </table>
                                        </div> -->

                                    </div>
                                </div>
                                <div class="col-md-12" id="pay_by_account" style="display: none">
                                  

                                    <div class="color_set_gray deep">
                                           <div class="col-md-12 mt-1">
                                            <table width="100%">
                                                <tr>
                                                    <td class="text-not"><b>Note: </b></td>
                                                    <td>When you select Pay by Account than after send invoice on mail with Function & Catering accounts details. If your payment approved than after Active your Venue/catering.</td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div class="col-md-8">
                                            <label class="lbl_class">Email</label>
                                            <input class="form-control" type="email" value="<?php echo $this->session->userdata('user_email') ?>">
                                        </div>
                                       
                                        <div class="col-md-12"><br></div>
                                        <div class="col-md-8">
                                            <div class="right_aling_card_root_101">
                                                <label class="regular-checkbox ">
                                                    <input class="checkbox_set" type="checkbox" name="agree" value="1" data-rule-required="true">
                                                    <small></small>
                                                </label>
                                                <span>I agree with the <a href="<?php echo base_url()?>/term_condition" target="_blank">Terms & Conditions.<sup style="color: red">*</sup></a></span>
                                            </div>
                                        </div> 
                                          
                                    </div>
                                </div>
                            </div>
                            <input type="button" name="btnsub" id="btnsub" class="action-button float_use" value="Process payment" />
                        </fieldset>
                    </div>
                </form>

            </div> <!--col-md-8-->



        </div><!-- row -->

    </div> <!-- container -->

</section><!--section-das-->
<!-- Modal -->
<div class="modal fade remove_confirmation" id="remove_confirmation" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalLabel">Confirm Remove</h5>
            </div>
            <div class="modal-body crop_model_body">
                <p class="content_are">Are you want sure to remove permanently this</p>
                <input type="hidden" id="remove_id">
                <input type="hidden" id="remove_cnt">
            </div>
            <div class="modal-footer_1">
                <button id="remove_confirmed" class="btn btn-primary but_crope Confirm_button" type="button">Confirm</button>
                <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>



<!-- Modal -->
<?php $this->load->view('models/image_cropping'); ?>
<?php $this->load->view('models/error_show'); ?>
<?php $this->load->view('models/cancel_subscription'); ?>
<!-- <script type="text/javascript" src="https://harvesthq.github.io/chosen/chosen.jquery.js"></script> -->

<script >
    $(".phone_no").keyup(function (e) {
   length=$(this).val().length;
   limit=17;
   if(length>limit){
    var strtemp = $(this).val().substr(0,limit);
    $(this).val(strtemp);
    e.preventDefault();
   }
  });
  $(".phone_no").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .   
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 107,109,32,110,57,48]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40) || ( e.keyCode === 107 || e.keyCode === 109 || e.keyCode === 32 || e.keyCode === 57 || e.keyCode === 48 ))  {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }  
    });
</script>