<?php

if (!empty($nearestCouncil)) {
    foreach ($nearestCouncil as $val) {
        $checked = '';
        $active = '';

        if (in_array($val->council_id, $selected_council)) {
            $checked = 'checked';
            $active = 'active';
        }
        if(!empty($plan)){
        ?>
        <div class="col-sm-6 mlCh_cols">
            <p class="cstm_MlChkBx mapChkie25 <?php echo $active ?>">
                <input type="checkbox" name="addional_area[]" value="<?php echo $val->council_id ?>" <?php echo $checked ?> >
                <label><?php echo $val->council ?></label>
            </p>
        </div> 
        <?php }else {?>
        <div class="col-sm-6 mlCh_cols">
            <p class="area_disabled">
                <label><?php echo $val->council ?></label>
            </p>
        </div> 
        </div> <?php } } ?>
    
        <?php if(!empty($plan)){ ?>
            <div class="col-sm-6 mlCh_cols text-right">
            <a href="javascript:void(0)" onclick="applyForAddionalArea();" class="btn cmn_btn1 aol_btn">Apply</a>
            </div>
        <?php }else{ ?>
            <div class="col-sm-6 mlCh_cols text-right">
            <a href="javascript:void(0)" class="btn_disable btn cmn_btn1 aol_btn">Apply</a>
            </div>
            <div class="col-sm-12 mlCh_cols"><span class="span_disable_error">Update your package to gain access to more areas</span></div>
        <?php } ?>
    
    
    <?php
} else {
    ?>  
    <div class="col-sm-6 mlCh_cols">
        <p class="cstm_MlChkBx mapChkie25 active">
            No Near By council found
        </p>
    </div>
    <?php
}
?>


