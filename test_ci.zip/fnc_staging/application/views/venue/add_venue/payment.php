
<!--<div class="col-md-9 col-sm-8">-->

<div class="row" >
    <div class='col-sm-12'>

        <fieldset class="fieldset_1 paymentOkey" >
            <form id="venue_payment_process" method="post" >
                <!--<div id="pay-summary">-->
                <div class="list_your_venu_content Payment">Payment summary</div>
                <div class="row">
                    <div class="col-md-12">
                        <div id="m-cart"></div>

                        <div class="padding_and_border_top_bottom">
                            <div class="Your_total">
                                Your Total<span> (Payable by credit card or corporate account)</span>
                            </div>

                            <div class="your_price_show" id="grand-total">
                                $0
                            </div>
                            <input type="hidden" id="fc_total_ammount" value="0">
                            <input type="hidden" name="stripeToken" id="stripeToken" value="">
                        </div>
                    </div>
                </div>
                <!--</div>-->

                <span id="voucher_massage"></span>
                </br>
                <div id="cart-div" class="row maring_row_cart_page">
                    <div class="voucher_div">
                        <div class="col-md-8 col-sm-7 col-xs-12 text-left">
                            <label class="lbl_class">Add voucher code</label>
                            <input name="voucher_code" id="voucher_code" type="text" class="form-control add_voucher_code" maxLength='25' >
                            <label style="display: none;" id="voucher-error" class="custom-error"></label>
                        </div>

                        <div class="col-md-4  col-sm-5 col-xs-12 pull-right">
                            <div class="choose_this_button second apply_button">
                                <a class="apply_voucher" onclick="appaly_voucher(1, 1);" href="javascript:void(0);">Apply</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12" id="payment_method">
                        <br>
                        <label style="display: none;" id="payment_method-error">Please select payment method</label>
                        <p class="pay_tap_div">
                            <span class="pay_radio_button">

                                <label class="regular-checkbox pull-left">
                                    <input type="radio" class="payment_method"  onclick="choose_payment(1, 1, 1)" name="payment_method" value="1" checked>
                                    <small ></small>
                                </label>
                                <span class="pull-left"> Pay by Stripe</span>
                            </span>
                            <span class="pay_radio_button"  <?php echo ($pay_by_account_enable == 1) ? '' : 'style="display: none"' ?>>
                                  <label class="regular-checkbox pull-left">
                                    <input type="radio" class="payment_method" onclick="choose_payment(2, 1, 1)" name="payment_method" value="2">
                                    <small ></small>
                                </label>
                                <span class="pull-left"> Pay by account</span>
                            </span>
                        </p>


                        <input type="hidden" id="selected_method" value="1">

                    </div>

                    <div class="col-md-12" id="strip_payment" style="">
                        <div class="row color_set_gray">
                            <div class="col-md-8 pull-left">
                                <!--<form>-->
                                <div class="form-group owner">
                                    <label class="card_number_label">Card Number</label>
                                    <input type="text" id="cardnumber" class="form-control-1 car_input_number card-number addr-field">
                                    <label style="display: none;" id="cardnumber-error" class="custom-error"></label>
                                </div>

                                <div class="cart_icon_set">
                                    <ul>
                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_card_visa-128.png" class="img-responsive"></li>
                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_discover_network_card-128.png" class="img-responsive"></li>
                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_master_card-128.png" class="img-responsive"></li>
                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_google_wallet-128.png" class="img-responsive"></li>
                                    </ul>
                                </div>

                                <div class="row">
                                    <div class="col-md-8 padding-right_106">
                                        <div class="form-group CVV" id="expiration-date">
                                            <label class="card_number_label">Expires Date</label>
                                            <select name="select2" id="cardexpiry" class="select_month card-expiry-month" data-stripe="exp-month">
                                                <option value="01" selected="">January</option>
                                                <option value="02">February </option>
                                                <option value="03">March</option>
                                                <option value="04">April</option>
                                                <option value="05">May</option>
                                                <option value="06">June</option>
                                                <option value="07">July</option>
                                                <option value="08">August</option>
                                                <option value="09">September</option>
                                                <option value="10">October</option>
                                                <option value="11">November</option>
                                                <option value="12">December</option>
                                            </select>
                                            <select name="select2" id="cardexpiry" class="select_month card-expiry-year" data-stripe="exp-year"></select>
                                            <script type="text/javascript">
                                                var select = $(".card-expiry-year"),
                                                        year = new Date().getFullYear();

                                                for (var i = 0; i < 12; i++) {
                                                    select.append($("<option value='" + (i + year) + "' " + (i === 0 ? "selected" : "") + ">" + (i + year) + "</option>"))
                                                }
                                            </script>
                                        </div>
                                        <label style="display: none;" id="cardexpiry-error" class="custom-error"></label>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="card_number_label">Security Code</label>
                                        <input type="text" id="cvv" class="form-control-1 car_input_number card-cvc addr-field" placeholder="CVV">
                                        <label style="display: none;" id="cvv-error" class="custom-error"></label>
                                    </div>

                                    <div class="form-group owner col-md-12">
                                        <label class="card_number_label">Name</label>
                                        <input type="text" name="cardholdername" id="cardholdername" class="form-control-1 car_input_number card-holder-name addr-field">
                                        <label style="display: none;" id="cardholdername-error" class="custom-error"></label>
                                    </div>

                                    <div class="form-group owner col-md-6">
                                        <label class="card_number_label">Order Amount</label>
                                        <input type="text" readonly="" name="amt" id="amt" value="0" class="form-control-1 car_input_number">
                                        <input type="hidden" id="amt_total" value="0">
                                    </div>

                                    <div class="col-md-12">
                                        <div class="right_aling_card_root_101">
                                            <label class="regular-checkbox ">
                                                <input class="checkbox_set" type="checkbox" name="agree" value="1">
                                                <small></small>
                                            </label>
                                            <span class='agreeSpan'>I agree with the <a href="<?php echo base_url() ?>/term_condition" target="_blank">Terms & Conditions.</a></span>
											
                                            <div class="clearfix"></div>
                                        </div> 

                                        <input class="agree_set" type="hidden" name="agree" id="agree" value="">
										
										
										
                                        <label style="display: none;" id="checkbox_set-error" class="custom-error"></label>
                                    </div>

                                </div>
                                <!--</form>-->

                            </div>
                            <div class="col-md-4"></div>
                        </div>
                    </div>

                    <div class="col-md-12" id="pay_by_account" style="display: none">
                        <div class="color_set_gray deep">
                            <div class="col-md-12 mt-1">
                                <table width="100%">
                                    <tr>
                                        <td class="text-not"><b>Note: </b></td>
                                        <td>Selecting "Pay by account" will trigger an invoice to the email you enter below. The terms of your account will dictate when your listing will become active."</td>
                                    </tr>
                                </table>
                                 <br/>
                            </div>
                           
                            <div class="col-md-8">
                                <label class="lbl_class"style="margin-bottom:10px">Email</label>
                               
                                <input class="form-control" type="email" data-rule-email = "true"  data-rule-required="true" value="<?php echo $this->session->userdata('user_email') ?>" maxlength="100">
                            </div>
                            <div class="col-md-12"><br></div>
                            <div class="col-md-8">
                                <div class="right_aling_card_root_101">
                                    <label class="regular-checkbox ">
                                        <input class="checkbox_set" type="checkbox" name="agree" value="1" data-rule-required="true">
                                        <small></small>
                                    </label>
                                    <span class='agreeSpan'>I agree with the <a href="<?php echo base_url() ?>/term_condition" target="_blank">Terms & Conditions.<sup style="color: red">*</sup></a></span>
									<br/>
									
                                </div>
								<br/>
								<div>
									<label for="agree" class="error CheckieError" >Please select at least 1 price</label>
									</div>
                            </div> 
                        </div>
                    </div>
                </div>

                <input type="button" name="btnsub" id="btnsub" data-payment_percent1="16.66" class="btn btn cmn_btn1 frm_bt2 action-button float_use payment_percent1" value="Process payment" />
            </form>
        </fieldset>
        <fieldset class="payment-Error">
            <div class="payment_error">

            </div>
        </fieldset>
        <fieldset class="paymentError">
            <div class="list_your_venu_content Payment">Error fields</div>
            <div class="row">
                <div class="col-md-12">
                    <div id="server-error"></div>
                </div>
            </div>
        </fieldset>

    </div>

</div><!-- row ends -->

<!--</div> col-md-9 col-sm-8 ends -->
<div class="MyModal23" id="thankyouModal">
    <div class="MyModal23_dialog">

        <span class="mdl_close">X</span>
        <h3>Thanks for your request! Please check your email.</h3>
        <p>Thank you for adding your Venue. You will receive a confirmation email shortly. Once received you will be able to view your venue on F&C.</p>
        <button class="btn cmn_btn1 gt_it_btn">OK, got it!</button>

    </div>
</div>

<script type="text/javascript">

    $('.mdl_close').click(function () {
        $('.MyModal23').removeClass('show');
        window.location.href = baseURL + 'my_venues';
    });


    $('.gt_it_btn').click(function () {
        window.location.href = baseURL + 'my_venues';
    });

</script>

<script type="text/javascript">
    setTimeout(function () {
        $(".payment_error").hide();
    }, 1500);



    $('input[type="checkbox"]').click(function () {
        if ($(this).prop("checked") == true) {
            $('#agree').val(1);
            $('#checkbox_set-error').hide();
            //alert("Checkbox is checked.");
        } else if ($(this).prop("checked") == false) {
            $('#agree').val(' ');
            //$('#checkbox_set-error').hide();
            //alert("Checkbox is unchecked.");
        }

    });
</script>