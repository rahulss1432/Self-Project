
<div class="row">
    <div class="col-sm-12">
        <div class="sub_hdngs">
            <h3 class="clr_cmn"><span>1/1</span> Listing Area</h3>
              <span class="sv_span">last saved:<span class="clr_cmn form-status-holder"><i class="mylastdate"><?php echo !empty(date("d-m-Y", strtotime($last_date))) && date("d-m-Y", strtotime($last_date)) != '01-01-1970'?date("d-m-Y", strtotime($last_date)):'';?></i></span><button class="btn cmn_btn1 save_btn2">Save</button></span>
            <div class="clearfix"></div>
        </div>
        <div class="progress prog2">
            <div class="progress-bar" role="progressbar" aria-valuenow="70"
                 aria-valuemin="0" aria-valuemax="100" style="width:100%">
            </div>
        </div> <!-- progress prog2 ends -->
    </div>
</div><!-- row ends -->

<?php
    if(!empty($this->cart->contents())){
        $style='';
        $count = count($this->cart->contents());
    }else{
        $style='display:none';
        $count = 0;
    }
?>

<div class="row">

    <div class="col-sm-12">
        <div class="row">
            <div class="col-sm-12">
                <div class="fmHeading2">
                    <span class="billDropdown package_cart mini_cart_popup">
                        <i class="fa fa-shopping-cart openShoppingCart cart_ic addional_area_cart"></i>
                        <span class="noti_circ" style="<?php echo $style; ?>">"<?php echo $count; ?></span>
                        <div class="soFarDiv main-cart drop_bill">
                            <!--<div class="soFarHead">Your Account So Far <i class="fa fa-times pull-right"></i></div>
                                <h5 style="text-align:center;">Your Cart is empty.</h5>-->
                        </div>
                    </span>
                </div>
            </div>
        </div>


        <div class="row" >

            <div class="col-sm-12">
                <div class="fmHeading2">
                    <h3 class="clr_cmn">By default, <a href="javascript:void(0)" class="clr_cmn vn_anch venue_name"><?php echo (((!empty($draft_venue->fc_business_name) && trim($draft_venue->fc_business_name))) ? $draft_venue->fc_business_name : 'ABC') ?></a> will show up in searches for <span class="council-nm">Moreland City with a 25 KM search reduis.</span>.</h3>
                    <!-- <h3 class="clr_cmn">By Default, ABC will appear in search for Moreland City with a 25KM search radius</h3> -->
                </div>
            </div>

            <div class="col-md-6 col-sm-12">

                <div class="map23" id="map-canvas-2"></div>
                <div class="row">

                    <div class="col-sm-6">
                        <h3 class="clr_cmn">Is this Correct ?</h3>
                    </div><!-- col-sm-6 ends -->
                    <?php
                    if(!empty($draft_venue)){
                        if($draft_venue->fc_suburb){
                            $subrup = 'checked';
                            $display ='display:block';

                        }else{
                            $subrup = '';
                            $display ='display:none';
                        }
                    }else{
                        $subrup = '';
                        $display ='display:none';
                    }

                    ?>
                    <div class="col-sm-6 ">
                        <div class="row text-right pd_T15p">
                            <div class="col-sm-6 col-xs-6">
                                <input type="radio"  name="radio-group2" class="my_radio listing_council_correct" id="correct_yes" checked>
                                <label for="correct_yes" class="clr_cmn ">Yes</label>
                            </div>
                            <div class="col-sm-6 col-xs-6">
                                <input type="radio"  name="radio-group2" class="my_radio listing_council_correct" id="correct_no" <?php echo $subrup; ?> >
                                <label for="correct_no" class="clr_cmn ">No</label>
                            </div>
                        </div>
                    </div><!-- col-sm-6 ends -->


                            <div class="col-sm-12 col-xs-12 if_not_correct" style="<?php echo $display; ?>">
                                <label class="lbl_class">Please enter your suburb<span class="clr_cmn">*</span></label>
                                <input type="text" name="venue_suburb" class="venue_suburb form-control addr-field ven_txtie" value="<?php echo (!empty($draft_venue->fc_suburb) ? $draft_venue->fc_suburb : ''); ?>" placeholder="Suburb">
                                <a href="javascript:void()" onclick="listingAreaMap(); updateNewSuburb();"><span class="btn cmn_btn1">Update</span> </a>
                            </div>


                </div><!-- row ends -->


                <div class="gtVenBx">
                    <h3 class="clr_cmn">Increase your visibility</h3>

                    <p>Increase your search area to include <span class="clr_cmn">up to 4 near by councils</span></p>
                    <p>Each additional ara is charged at a rate of 20c per day</p>
                    <p>Click the areas on the map to expand venues search areas</p>
                </div>

                <div class="map23" id="map-canvas-3"></div>


                <div class="row mrTp_30">
                </div>


                <form id="addionla_area_form" method="post">
                    <div class="row nearest_council_show" >
                        <div class="col-md-12 mlCh_cols">
                            <p class="cstm_MlChkBx mapChkie25 active">
                                No Near By council found
                            </p>
                        </div>
                    </div>
                </form>


            </div><!-- col-sm-6 ends -->

            <div class="col-md-6 col-sm-12">
            </div><!-- col-sm-6 ends -->




        </div><!-- row ends -->

        <div class="row mrTp40">
            <div class="col-md-6 col-sm-3 col-xs-3" id="backbtn_listarea">
                <a href="JavaScript:void(0);" onclick="forwordTo('page_layout'); listingForwordTo('review_your_listing', false);"><span class="clr_cmn bckie2"><i class="fa fa-angle-left"></i> Back</span></a>
            </div>
            <div class="col-md-6 col-sm-9 col-xs-9 txt_rg1">
                <button class="btn cmn_btn2 frm_bt2 first_div_btn" onclick="forwordTo('spaces');">Skip for Now</button>
                <a href="JavaScript:void(0);"  onclick="forwordTo('spaces');" data-listing_area_percent1="16.66" class="btn cmn_btn1 frm_bt2 listing_area_percent1" id="nextbtn_listarea">Next</a>
            </div>
        </div>




    </div><!-- col-sm-12 ends -->

</div><!-- row ends -->
<!--</div> col-md-9 col-sm-8 ends -->


