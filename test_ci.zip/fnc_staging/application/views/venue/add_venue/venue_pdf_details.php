<div class="row">
    <div class="col-sm-12">
        <h3 class="clr_cmn fr_hdngSpc mr_b_30">
            You can upload attachments like a Menu or Advertising Packages here. (Max: 4)
        </h3>
    </div><!-- col-sm-6 ends -->
</div>
<?php
$old_img_count = (!empty($draft_venue_pdfs)) ? count($draft_venue_pdfs) : 0;
for ($i = 1; $i <= 4; $i++) {
    $pdf_url = '';
    if ($old_img_count > 0) {
        $pdf_url = base_url('uploads/venue_pdf_image') . '/' . $draft_venue_pdfs[$i - 1]->fc_pdf_image;
        $pdfTitleName = $draft_venue_pdfs[$i - 1]->fc_pdf_title_name;
        $pdfName = $draft_venue_pdfs[$i - 1]->fc_pdf_name;
        $pdfImageName = $draft_venue_pdfs[$i - 1]->fc_pdf_image;
        $pdfId = encrypt_decrypt('encrypt', $draft_venue_pdfs[$i - 1]->fc_pdf_id);
        if (empty($draft_venue_pdfs[$i - 1]->fc_pdf_name)) {
            $pdf_url = '';
            $remove_hide = '';
        }
        $remove_hide = '';
        $b_upload_hide = 'display:none';
        $old_img_count--;
        $removeImg = "removePdf(2, '" . encrypt_decrypt('encrypt', $draft_venue_pdfs[$i - 1]->fc_pdf_id) . "', 1, $i )";
        if ((!empty($pdfTitleName)) && (empty($draft_venue_pdfs[$i - 1]->fc_pdf_name))) {
            $b_upload_hide = '';
            $remove_hide = 'display:none';
            $removeImg = "removePdf(2, '0', 2, $i );";
        }
    } else {
        $removeImg = "removePdf(2, '0', 2, $i );";
        $remove_hide = 'display:none';
        $b_upload_hide = '';
        $pdfTitleName = '';
        $pdfId = '';
        $pdfName = '';
        $pdfImageName = '';
    }
    ?>
    <div class="row">
        <div>
            <div class="col-sm-6">
                <h5 class="clr_cmn"><strong>Attachment Name</strong></h5>
                <div class=" margin_set_input no-pad">
                    <input type="hidden" name="pdf_id" id="pdf_id_<?php echo $i; ?>" value="<?php echo $pdfId; ?>">
                    <input type="hidden" name="pdf_title_name" id="pdf_title_name_<?php echo $i; ?>" value="<?php echo $pdfTitleName; ?>">
                    <input type="hidden" name="pdf_name" id="pdf_name_<?php echo $i; ?>" value="<?php echo $pdfName; ?>">
                    <input type="hidden" name="pdf_image_name" id="pdf_image_name_<?php echo $i; ?>" value="<?php echo $pdfImageName; ?>">
                    <input type="text" class="form-control pdf_title_name" id="pdf_title_<?php echo $i; ?>" data-id="<?php echo $i; ?>" minlength="5" maxlength="20" placeholder="Enter File Name" value="<?php echo $pdfTitleName; ?>">
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="col-sm-6">
            <div class="fa fa-spinner fa-spin" style="display:none;"></div>
            <div class="ulpading_pdf_size_3 listing_picture_thumb fl_wid upImgs">
                <div class="onlImg2" id="onlImg2_<?php echo $i; ?>" style="<?php echo ($pdf_url != '') ? 'display: block;' : 'display:none;' ?>">
                    <img id="pdfimage_<?php echo $i; ?>" src="<?php echo ($pdf_url != '') ? $pdf_url : ''; ?>" class="dropzone" img-id="<?php echo $i; ?>" style="<?php echo ($pdf_url != '') ? 'display: block;' : 'display:none;' ?> ">
                </div>
                <div class="ezdz-dropzone">
                    <div class="for_plus_sign">Drag File Here</div><input onclick="this.value = null;" type="file" name="venue_pdf_<?php echo $i ?>" data-fc_img_id="" data-id="<?php echo $i ?>" class="pdf-selector pdf_selector check_pdf_validation pdf_remove_select<?php echo $i ?>" id="pdf_selector_<?php echo $i ?>" accept=".pdf">
                    <input type="hidden" class="check_pdf_validation" name="dimesion_pdf_<?php echo $i ?>" id="dimesion_pdf_<?php echo $i ?>" value="<?php echo $pdf_url ? $pdf_url : 0; ?>">
                </div>
                <canvas width="500" height="200" style="display:none;" id="pdfViewer_<?php echo $i; ?>">
                </canvas>
            </div>
        </div><!-- col-sm-6 ends -->
        <div class="col-sm-6">
            <div class="Img_spec clr_cmn">
                <h5>Upload Package or Menu</h5>
                <h6>Upload should be pdf files</h6>
                <h6>Maximum size is 2 Mb</h6>
                <div class="mn_imgBtGr">
                    <a href="javascript:void(0)" id="pdf_remove_select<?php echo $i ?>" class="btn cmn_btn2 f_s2 removeClass" onclick="<?php echo $removeImg ?>" style="<?php echo $remove_hide; ?>">Remove</a>
                    <label ant-id="<?php echo $i ?>" class="upload-button_new1 btn cmn_btn1 f_s2 pdf_remove_select<?php echo $i ?>" onclick="<?php echo $removeImg; ?>" id="another_select_1" style="<?php echo $b_upload_hide; ?>">
                        <i class="fa_icon icon-upload-alt margin-correction"></i> <i class="fa fa-spinner fa-spin" id="loader_<?php echo $i; ?>" style="display:none;"></i> Upload File
                    </label>
                </div>
                <span class="pdf_msg_<?php echo $i; ?>"></span>
            </div><!-- Img_spec ends -->
        </div><!-- col-sm-6 ends -->
    </div> <!-- row ends -->
<?php } ?>
<!-- new pdf upload area ends  -->
<script>

                        var timeoutId;
                        $('.pdf_title_name').unbind().on('keyup', function () {
                            var pdfTitle = $(this).val();
                            var cnt = $(this).data('id');
                            var hiddenInput = $('#pdf_id_' + cnt).val();
                            var pdfName = $('#pdf_name_' + cnt).val();
                            var pdfImageName = $('#pdf_image_name_' + cnt).val();
                            $("#venue_details_form").validate({
                                onkeyup: function (element) {
                                    $(element).valid()
                                }
                            });
                            clearTimeout(timeoutId);
                            timeoutId = setTimeout(function () {
                                var form = $('#venue_details_form')[0];
                                var formData = new FormData(form);
                                formData.append('pdf_title_' + cnt, pdfTitle);
                                formData.append('pdf_id', hiddenInput);
                                formData.append('venue_pdf_' + cnt, pdfName);
                                formData.append('fc_pdf_image_' + cnt, pdfImageName);
                                saveToDB('FNC_Add_Venue/venue_details_add_update', 'venue_details_form', formData, cnt, true);
                            }, 1000);
                        });

                        $('.upload-button_new1').unbind().on('click', function (e) {
                            e.preventDefault();
                            var id = $(this).attr('ant-id');
                            $('#pdf_selector_' + id).trigger('click');
                        });

                        // Loaded via <script> tag, create shortcut to access PDF.js exports.
                        var pdfjsLib = window['pdfjs-dist/build/pdf'];
                        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://mozilla.github.io/pdf.js/build/pdf.worker.js';
                        $('.pdf_selector').on("change", function (e) {
                            var file = e.target.files[0];
                            var cnt = $(this).data('id');
                            var fileName = $(this).val();
                            var pdf_id = $(this).data('id');
                            var a = (this.files[0].size);
                            if (a > 2000000) {
                                $('.pdf_msg_' + pdf_id).text('Maximum size exceeded. Please upload a pdf less than 2MB.').css('color', 'red');
                                return false;
                            } else {
                                $('.pdf_msg_' + pdf_id).text('');
                            }
//                            $('#pdf_remove_select' + cnt).show();
                            $('.pdf_remove_select' + cnt).show();
                            var pdfTitle = $('#pdf_title_' + cnt).val();
                            if (pdfTitle == '') {
                                var fileName = e.target.files[0].name;
                                var fileWithExt = fileName.substr(0, fileName.lastIndexOf('.'));
                                var pdfTitle = $('#pdf_title_' + cnt).val(fileWithExt);
                                var titleName = $('#pdf_title_name_' + cnt).val(fileWithExt);
                            }
                            if (file.type == "application/pdf") {
                                var fileReader = new FileReader();
                                fileReader.onload = function () {
                                    var pdfData = new Uint8Array(this.result);
                                    var loadingTask = pdfjsLib.getDocument({
                                        data: pdfData
                                    });
                                    loadingTask.promise.then(function (pdf) {
                                        var pageNumber = 1;
                                        pdf.getPage(pageNumber).then(function (page) {
                                            var scale = 1.5;
                                            var viewport = page.getViewport({
                                                scale: scale
                                            });
                                            var canvas = $("#pdfViewer_" + cnt)[0];
                                            var context = canvas.getContext('2d');
                                            canvas.height = viewport.height;
                                            canvas.width = viewport.width;
                                            var renderContext = {
                                                canvasContext: context,
                                                viewport: viewport
                                            };
                                            var renderTask = page.render(renderContext);
                                            renderTask.promise.then(function () {
                                                var image = canvas.toDataURL("image/png").replace(/^data:/, "");
                                                var block = image.split(";");
                                                var contentType = block[0].split(":")[1];
                                                var realData = block[1].split(",")[1];
                                                var hiddenInput = $('#pdf_id_' + cnt).val();
                                                var titleName = $('#pdf_title_name_' + cnt).val();
                                                var blob = b64toBlob(realData, contentType);
                                                var form = $('#venue_details_form')[0];
                                                var formData = new FormData(form);
                                                formData.append('fc_pdf_image_' + cnt, blob);
                                                formData.append('pdf_title_' + cnt, titleName);
                                                formData.append('pdf_id', hiddenInput);
                                                saveToDB('FNC_Add_Venue/venue_details_add_update', 'venue_details_form', formData, cnt);
                                                var remove_attr = $('#pdf_remove_select' + pdf_id).trigger('click');
                                                var fcId = $('#fc_id').val();
                                            });
                                        });
                                    }, function (reason) {
                                        console.error(reason);
                                    });
                                };
                                fileReader.readAsArrayBuffer(file);
                            }
                        });

                        function b64toBlob(b64Data, contentType, sliceSize) {
                            contentType = contentType || '';
                            sliceSize = sliceSize || 512;

                            var byteCharacters = atob(b64Data);
                            var byteArrays = [];

                            for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                                var slice = byteCharacters.slice(offset, offset + sliceSize);

                                var byteNumbers = new Array(slice.length);
                                for (var i = 0; i < slice.length; i++) {
                                    byteNumbers[i] = slice.charCodeAt(i);
                                }

                                var byteArray = new Uint8Array(byteNumbers);

                                byteArrays.push(byteArray);
                            }

                            var blob = new Blob(byteArrays, {
                                type: contentType
                            });
                            return blob;
                        }

                        function removePdf(fc_pdf_type, pdf_id, flush_type, cnt) {
                            if (flush_type == 1) {
                                $.ajax({
                                    type: "POST",
                                    url: base_url + 'web/remove_pdf',
                                    data: {
                                        'fc_pdf_type': fc_pdf_type,
                                        'pdf_id': pdf_id,
                                        'flush_type': flush_type
                                    },
                                    dataType: 'JSON',
                                    success: function (data) {
                                        if (data.status) {

                                        }
                                    },
                                });
                                $('#pdf_id_' + cnt).val('');
                                $('#pdf_title_' + cnt).val('');
                                $('#pdf_title_name_' + cnt).val('');
                                $('.pdf_remove_select' + cnt).attr("onclick", "removePdf(2, '" + 0 + "', 2, " + cnt + ")");
                            }
                            $('.pdf_remove_select' + cnt).css('pointer-events', 'unset');
                            $('#pdf_selector_' + cnt).val(null);
                            $('#dimesion_pdf_' + cnt).val('');
                            $('#pdf_name_' + cnt).val('');
                            $('#pdf_image_name_' + cnt).val('');
                            $('#pdf_remove_select' + cnt).hide();
                            $('.pdf_remove_select' + cnt).show();
                            $('#pdfimage_' + cnt).hide();
                            $("#onlImg2_" + cnt).hide();
                        }
</script>