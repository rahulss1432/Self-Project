<!--<div class="col-md-9 col-sm-8">-->
<div class="row" >
    <div class="col-sm-12">

        <div class="sub_hdngs">
            <h3 class="clr_cmn"><span>1/1</span> Package</h3>
            <span class="sv_span">last saved:<span class="clr_cmn form-status-holder"> <i class="mylastdate"><?php echo !empty(date("d-m-Y", strtotime($last_date))) && date("d-m-Y", strtotime($last_date)) != '01-01-1970'?date("d-m-Y", strtotime($last_date)):'';?></i></span><button class="btn cmn_btn1 save_btn2">Save</button></span>
            <div class="clearfix"></div>
        </div>
        <div class="progress prog2">
            <div class="progress-bar" role="progressbar" aria-valuenow="70"
                 aria-valuemin="0" aria-valuemax="100" style="width:100%">
            </div>
        </div> <!-- progress prog2 ends -->    
    </div>
</div><!-- row ends -->

<?php 
    if(!empty($this->cart->contents())){
        $style='';
        $count = count($this->cart->contents());
    }else{
        $style='display:none';
        $count = 0;
    }
?>
<div class="row">
   <div class="col-sm-12">
      <form class="cmn_frmCls" id="package_form" action="<?php echo site_url('venue/package'); ?>" method="post">
         <div class="row">
            <div class="col-sm-12">
               <div class="fmHeading2">
                  <span class="billDropdown mini_cart_popup">
                     <i class="fa fa-shopping-cart package_cartSpecific openShoppingCart cart_ic"></i>
                    <span class="noti_circ" style="<?php echo $style; ?>"><?php echo $count; ?></span>
                     <div class="soFarDiv main-cart drop_bill"></div>
                  </span>
               </div>
            </div>
         </div>
         <div class="row" >
            <div class="col-sm-12">
               <div class="fmHeading2">
                  <h3 class="clr_cmn">Select the right plan for your business needs</h3>
               </div>
            </div>
            <div class="col-lg-6 col-md-8 col-sm-12">

            <div class="row">
               <div class="col-sm-12">
                  <div class="introPackage">Introductory Package Rates</div>
               </div>
            </div>


               <div class="row">
                  <div class="display_flex_set_d">

                     <!-- start first box -->
                     <?php
                     // echo '<pre>';
                     // print_r($packs);
                        if (!empty($packs)) {
                            foreach ($packs as $key => $value) {
                                ?>
                     <div class="col-md-6 col-sm-6 border_price_box <?php echo ($value->pro_id == $plan_id) ? 'first_b_o_x' : ''; ?>" id="pack<?php echo $key; ?>">
                        <span>
                           <div class="price_title <?php echo ($value->pro_id == $plan_id) ? 'first_b_o_x' : ''; ?>" id="pack-title<?php echo $key; ?>">
                              <div class="price_content  <?php echo ($value->pro_id == $plan_id) ? 'first_b_o_x' : ''; ?>" id="pack-content<?php echo $key; ?>">
                                 <?php echo $value->pro_title; ?>                                                      
                              </div>
                           </div>
                           <?php if ($value->pro_save != 0) { ?>
                           <div class="offet_side_bar"><a>Save $<?php echo $value->pro_save; ?></a></div>
                           <?php } ?>
                           <div class="offer_box_padding  <?php echo ($value->pro_id == $plan_id) ? 'first_b_o_x' : ''; ?>" id="pack-padding<?php echo $key; ?>">
                              <?php echo $value->pro_desc; ?>
                             <a data-pack="<?php echo $key; ?>" data-packtype="<?php echo $value->pro_id; ?>" class="choose_plan <?php echo ($value->pro_id == $plan_id) ? 'selected' : ''; ?>" href="javascript:;"> 
                             <div class="choose_this_button">
                                    <?php echo ($value->pro_id == $plan_id) ? 'Selected Plan' : 'Choose this plan  <span style="font-size:10px;">*Excludes GST</span>'; ?>
<!--                                 Choose this plan
                                -->
                              </div></a>
                           </div>
                        </span>
                     </div>
                     <?php
                        }
                        }
                        ?>
                  </div>
               </div>
               <div class='row'>
                  <div class='col-sm-12'>
                            <div class='you_sure_box' style="display: none">
                        <h4>
                           <span class="clr_cmn ">Are you sure ?</span>
                           <span>
                                        <input type='button' class='btn cmn_btn1 faded' value="No, I'm not" onclick="hideShowFreeListing('no', 0);" />
                                        <input type='button' class='btn cmn_btn1' value="Yes, I'm sure"  onclick="hideShowFreeListing('yes', 0);" />
                           </span>
                                    <i onclick="hideShowFreeListing('no', 0);" class="fa fa-close sure_exit"></i>
                                </h4>
                                <p><span class='clr_cmn'>Text only listings only have</span> no images, and only limited features...</p>
                                <p><span class='clr_cmn'>are you sure want to continues</span></p>
                                <p><span class='clr_cmn'></span></p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!-- //box start for free venue -->
                        <div class="col-md-12 hlf_pad">
                            <div id="free-div" class="col-md-12 border_box_1 offer_box_padding <?php echo ($free == '1') ? 'first_b_o_x' : ''; ?>">
                        <div class="row">
                           <div class="col-md-7 col-sm-7 col-xs-7">
                              <div class="no_thanks_content">No thanks, free text only listing</div>
                           </div>
                           <div class="col-md-5 col-sm-5 col-xs-5">
                              <div class="choose_this_button second">
                                            <a id="free-plan" onclick="hideShowFreeListing('show', 1);" class="text-only" href="javascript:;">Choose this plan</a>
                                            <input type="hidden"  id="free" name="free" value="<?php echo ($free == '1') ? 1 : 0; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <input type="hidden" name="selected_package" id="selected_package" required="" data-msg-required="Please select the right Payment Plan for your business" value="<?php echo ($plan_id == 1 || $plan_id == 2) ? $plan_id : (($free == '1') ? 'free' : ''); ?>">
                            <label for="selected_package" class="error CheckieError package_error" style="display:none">Please select the right Payment Plan for your business</label>
                  </div>
               </div>
               <!-- box end for free venue -->
            </div>
            <!-- col-sm-6 ends -->
         </div>
         <!-- col-sm-6 ends -->
      </form>
   </div>
   <!-- row ends --> 
   
</div>

    <div class="row mrTp15 ">
      <div class="col-lg-4 col-md-6 col-sm-3 col-xs-3" >

         <a href="JavaScript:void(0);" onclick="forwordTo('business_details', false); businessForwordTo('map_location', false);"><span class="clr_cmn bckie2"><i class="fa fa-angle-left"></i> Back</span></a>
      </div>
      <div class="col-lg-8 col-md-6 col-sm-9 col-xs-9 txt_rg1">
         <a href="JavaScript:void(0);" class="btn cmn_btn2 frm_bt2 first_div_btn" onclick="forwordTo('venue_details', false);" id="pack_btn_skip">Skip for Now</a> 
         <a href="JavaScript:void(0);" onclick="forwordTo('venue_details', 'check_package');" data-package_percent1="8.33" class="btn cmn_btn1 frm_bt2 pack_next_btn package_percent1" id="pack_next_btn">Next</a>
      </div>
   </div>


<!--</div> row ends -->