<div class="row" id="mesaure_bar1" >
    <?php // echo '<pre>'; print_r($draft_venue) ?>
    <div class="col-sm-12">
        <div class="sub_hdngs">
            <h3 class="clr_cmn business_details_progess_bar_title"><span>1/3</span> Business Details</h3>
            <span class="sv_span">last saved:<span class="clr_cmn form-status-holder"><i class="mylastdate"><?php echo!empty(date("d-m-Y", strtotime($last_date))) && date("d-m-Y", strtotime($last_date)) != '01-01-1970' ? date("d-m-Y", strtotime($last_date)) : ''; ?></i></span><button class="btn cmn_btn1 save_btn2">Save</button></span>
            <div class="clearfix"></div>
        </div>
        <div class="progress prog2">
            <div class="progress-bar business_details_progess_bar_progress" role="progressbar" aria-valuenow="70"
                 aria-valuemin="0" aria-valuemax="100" style="width:33%">
            </div>
        </div>
        <!--progress prog2 ends-->
    </div>
</div>
<?php
if (!empty($this->cart->contents())) {
    $style = '';
    $count = count($this->cart->contents());
} else {
    $style = 'display:none';
    $count = 0;
}
?>
<div class="row">
    <div class="col-sm-12">
        <form  name="addablogform" class="cmn_frmCls venueAdd_form" id="business_details" method="post" enctype="multipart/form-data">

            <div class="row">
                <div class="col-sm-12">
                    <div class="fmHeading2">
                        <span class="billDropdown mini_cart_popup">

                            <i class="fa fa-shopping-cart openShoppingCart cart_ic"></i>
                            <span class="noti_circ" style="<?php echo $style; ?>"><?php echo $count; ?></span>

                            <div class="soFarDiv main-cart drop_bill">
                                <div class="soFarHead">Your Account So Far <i class="fa fa-times pull-right"></i></div>
                                <h5 style="text-align:center;">Your Cart is empty.</h5>
                            </div>
                        </span>
                    </div> 
                </div>
            </div>  


            <div class="company_details-page">
                <div class="row" >
                    <div class="col-sm-12 first_div" id="first_div" >
                        <div class="fmHeading2">
                            <h3 class="clr_cmn">Let’s  get started on your listing. Tell us a bit about your business.</h3>

                        </div>
                    </div>

                    <?php $check_url = !empty($draft_venue->fc_id) ? site_url('venue/check_business_name?fc_id=' . encrypt_decrypt('encrypt', $draft_venue->fc_id)) : site_url('venue/check_business_name') ?>
                    <div class="col-md-6 col-sm-8 first_div" id="first_div">
                        <div class="col-sm-12 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_business_name">Trading Name <span class="clr_cmn">*</span></label>
                            <input type="text"  class="form-control addr-field business_form" maxlength="50" id="venue_business_name" name="venue_business_name" placeholder="Enter Trading Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Trading Name'" id="venue_business_name" data-msg-remote="This trading name already exist"  data-rule-required="true" value="<?php echo!empty($draft_venue->fc_business_name) ? $draft_venue->fc_business_name : '' ?>"
                                   data-msg="Please enter your trading name" 
                                   >
                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd"></i>
                            </span>
                        </div>
                        <div class="col-sm-12 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_business_name">Company Name <span class="clr_cmn">*</span></label>
                            <input type="text"  class="form-control addr-field business_form" maxlength="50" id="venue_company_name" name="venue_company_name" placeholder="Enter Company Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Company Name'" id="venue_company_name" data-rule-required="true" value="<?php echo!empty($draft_venue->fc_company_name) ? $draft_venue->fc_company_name : '' ?>"
                                   data-msg="Please enter your company name" 
                                   >
                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd"></i>
                            </span>
                        </div>
                        <div class="col-sm-12 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_contact_name">Contact Name <span class="clr_cmn">*</span></label>
                            <input type="text" maxlength="30" onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) || (event.charCode == 32) || (event.charCode == 46)" class="form-control addr-field business_form" id="venue_contact_name" name="venue_contact_name"  placeholder="Enter Contact Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Contact Name'" data-rule-required="true" value="<?php echo!empty($draft_venue->fc_contact_name) ? $draft_venue->fc_contact_name : '' ?>"
                                   data-msg="Please enter your contact name"
                                   >

                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd"></i>
                            </span>
                        </div>
                        <div class="col-sm-12 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_email">Company Email <span class="clr_cmn">*</span></label>
                            <input type="email" maxlength="100" class="form-control addr-field business_form" id="venue_email" name="venue_email" placeholder="Company Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Company Email'" data-rule-email = "true"  data-rule-required="true" value="<?php echo!empty($draft_venue->fc_email) ? $draft_venue->fc_email : '' ?>"
                                   data-msg="Please enter your company email ID"
                                   >
                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd"></i>
                            </span>
                        </div>

                        <div class="col-sm-12 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_phone_no">Phone <span class="clr_cmn">*</span></label>
                            <input type="text" class="form-control addr-field business_form venue_phone_no" maxlength="10" id="venue_phone_no" name="venue_phone_no"  placeholder="Enter Contact Phone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Contact Phone'" data-rule-minlength="8" data-rule-maxlength="10" data-rule-required="true" value="<?php echo!empty($draft_venue->fc_phone_no) ? $draft_venue->fc_phone_no : '' ?>" data-msg-required="Please enter your phone number"
                                   >
                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd"></i>
                            </span>
                        </div>
                        <div class="col-sm-12 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_abn">ABN <span class="clr_cmn">*</span></label>
                            <input type="text" class="form-control addr-field business_form" id="venue_abn" name="venue_abn"  placeholder="Enter ABN" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter ABN'"   data-rule-number="true" data-rule-minlength="11" data-rule-maxlength="11" data-rule-required="true" value="<?php echo!empty($draft_venue->fc_abn) ? $draft_venue->fc_abn : '' ?>" maxlength="11" data-msg="Please enter your ABN">
                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd"></i>
                            </span>
                        </div>
                    </div>
                </div>
                <!--row ends--> 


                <div class="row mrTp15" id ="first_section_btn">
                    <div class="col-md-6 col-sm-3 col-xs-3" id="bck_btn2"  >
                        <a href=""><span class="clr_cmn bckie2" style="display: none" ><i class="fa fa-angle-left"></i> Back</span></a>
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-9 txt_rg1 pd_l_0Dsk">

                        <a class="btn cmn_btn2 frm_bt2 first_div_btn" onclick="businessForwordTo('address_location', false);" id="skip_btn1">Skip for Now</a>
                        <a class="btn cmn_btn1 frm_bt2 first_div_btn business_percent1" data-business_percent1="8.33" onclick="businessForwordTo('address_location', true);" id="next_btn1">Next</a>
                        <br/>
                        <div class="cstmTooltip skip_tooltip ">
                            <span class="skip_tltpClose">X</span>
                            <h5>Finish it Later!</h5>
                            <p>You can always complete your application later. Find them in 'My Venues'</p>
                        </div>

                    </div>
                </div>
            </div>


            <div class="address_location-page" style="display: none">
                <div class="row" >
                    <div class="col-sm-12">
                        <div class="fmHeading2">
                            <h3 class="clr_cmn">Location, location, location ! Where can we find your functions space</h3>

                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="col-sm-12 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_country">Country <span class="clr_cmn">*</span></label>
                            <input type="text" readonly="" value="Australia" class="form-control addr-field" id="venue_country" name="venue_country">
                        </div>

                        <div class="col-sm-12 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_street">Street <span class="clr_cmn">*</span></label>
                            <input type="text" class="form-control addr-field business_form" id="venue_street" name="venue_street" value="<?php echo!empty($draft_venue->fc_street) ? $draft_venue->fc_street : '' ?>" placeholder="Type Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Street Address'" data-rule-required = "true" data-msg="Please enter your street address"
                                   >
                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd"></i>
                            </span>
                        </div>

                        <div class="col-sm-6 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_state">State <span class="clr_cmn">*</span>

                                <i class="tooltip_i">
                                    <span class="tltp_span">
                                        <img src="<?php echo base_url('assets/images/sys_info.svg'); ?>" class="tltp_ic">
                                    </span>
                                    <!-- <i class="spc_i">i</i> -->
                                    <div class="cstmTooltip left spc_tltp">
                                        <span class="skip_tltpClose">X</span>
                                        <p>Currently only available in VIC.<br/> More states coming soon!</p>
                                    </div>
                                </i>
                                <!-- <span class="tltp_span">
                                    <img src="<?php echo base_url('assets/images/sys_info.svg'); ?>" class="tltp_ic" />
                                    <div class="cstm_tooltip1">
                                        <i class="close_tooltip">X</i>
                                        <p>Currently only available in VIC. More states coming soon!</p>
                                    </div>
                                
                                </span>  -->
                            </label>
                            <?php @$draft_venue->fc_state = !empty($draft_venue->fc_state) ? $draft_venue->fc_state : '' ?>
                            <select class="form-control addr-field business_form" id="venue_state" name="venue_state" value="" disabled>
                                <option value="" selected="selected" class="">Select a state</option>
                                <option value="ACT" <?php echo ($draft_venue->fc_state == 'ACT') ? 'Selected' : '' ?>>ACT</option>
                                <option value="QLD" <?php echo ($draft_venue->fc_state == 'QLD') ? 'Selected' : '' ?>>QLD</option>
                                <option value="NSW" <?php echo ($draft_venue->fc_state == 'NSW') ? 'Selected' : '' ?>>NSW</option>
                                <option value="NT" <?php echo ($draft_venue->fc_state == 'NT') ? 'Selected' : '' ?>>NT</option>
                                <option value="SA" <?php echo ($draft_venue->fc_state == 'SA') ? 'Selected' : '' ?>>SA</option>
                                <option value="TAS" <?php echo ($draft_venue->fc_state == 'TAS') ? 'Selected' : '' ?>>TAS</option>
                                <option value="Vic"  <?php echo ($draft_venue->fc_state == 'Vic') ? 'Selected' : '' ?> Selected>VIC</option>
                                <option value="WA" <?php echo ($draft_venue->fc_state == 'WA') ? 'Selected' : '' ?>>WA</option>
                            </select>

                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd"></i>
                            </span>
                        </div>
                        <div class="col-sm-6 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_postcode">Post Code <span class="clr_cmn">*</span></label>
                            <input type="text" data-rule-postcodecheck='true' class="form-control addr-field business_form" id="venue_postcode"
                                   name="venue_postcode" 
                                   value="<?php echo!empty($draft_venue->fc_postcode) ? $draft_venue->fc_postcode : '' ?>" placeholder="Type postcode" 
                                   onfocus="this.placeholder = ''" onblur="this.placeholder = 'Type a postcode'" data-rule-required = "true" 
                                   data-msg="Please enter your postcode"
                                   >
                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd"></i>
                            </span>
                        </div>
                        <div class="col-sm-12 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_suburb">City <span class="clr_cmn">*</span></label>
                            <input type="text" class="form-control addr-field business_form venue_suburb" id="venue_suburb" name="venue_suburb" value="<?php echo!empty($draft_venue->fc_suburb) ? $draft_venue->fc_suburb : '' ?>" placeholder="Type City" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Select City'" data-rule-required = "true" 
                                   data-msg=" Please enter your city"
                                   > 
                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd"></i>
                            </span>
                        </div>


                        <div class="col-sm-12 margin_set_input no-pad">
                            <label class="lbl_class" for="venue_unit">Street /Unit /Suite Number <span class="clr_cmn"></span></label>
                            <input type="text" class="form-control addr-field business_form" id="venue_unit" name="venue_unit" value="<?php echo!empty($draft_venue->fc_unit) ? $draft_venue->fc_unit : '' ?>" placeholder="Street /Unit /Suite Number" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Street /Unit /Suite Number'" data-msg=" Please enter your street " >
                            <!-- <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd"></i>
                            </span> -->

                        </div>

                        <div class="col-sm-12 margin_set_input no-pad " >							
                            <label for="post_city_error" class="error CheckieError" >city and post code not match</label>
                        </div>
                    </div>
                    <!--col-sm-6 ends--> 
                </div>

                <div class="row mrTp15" id="second_div_btn" >
                    <div class="col-md-6 col-sm-3 col-xs-3" id="bck_btn2" >
                        <a href="JavaScript:void(0);" onclick="businessForwordTo('company_details', false)" id="bus_back_btn1"><span class="clr_cmn bckie2"><i class="fa fa-angle-left" ></i>Back</span></a>

                    </div>
                    <div class="col-md-6 col-sm-9 col-xs-9 txt_rg1 pd_l_0Dsk">

                        <a class="btn cmn_btn2 frm_bt2" onclick="businessForwordTo('map_location', false);" >Skip for Now</a>
                        <a class="btn cmn_btn1 frm_bt2 business_percent2" data-business_percent2="8.33" onclick="businessForwordTo('map_location', true);" >Next</a>
                    </div>
                </div>
            </div>

            <div class="map_location-page" style="display: none">
                <div class="row"  >
                    <div class="col-sm-12">
                        <div class="fmHeading2">
                            <h3 class="clr_cmn">
                                Where is your business located?
                                <p class="fmPtg">Move the pin to your venue's exact location so you are visible on the map for clients to find you.</p>
                            </h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <a href="#" class="btn reset_map btn cmn_btn1" style='margin-bottom:10px'>Reset</a>
                        <div id="map-canvas" style="width: 100%; height: 500px;" ></div>
                        <input type="hidden" name="fc_lat" id="venue_lat" value="<?php echo!empty($draft_venue->fc_lat) ? $draft_venue->fc_lat : ''; ?>">
                        <input type="hidden" name="fc_lng" id="venue_lng" value="<?php echo!empty($draft_venue->fc_lng) ? $draft_venue->fc_lng : ''; ?>">
<!--                        <input type="hidden" name="reset_fc_lat" id="reset_venue_lat" value="<?php //echo!empty($draft_venue->fc_lat) ? $draft_venue->fc_lat : '';    ?>">
                        <input type="hidden" name="reset_fc_lng" id="reset_venue_lng" value="<?php //echo!empty($draft_venue->fc_lng) ? $draft_venue->fc_lng : '';    ?>">-->
                        <input type="hidden" name="reset_fc_lat" id="reset_venue_lat" value="">
                        <input type="hidden" name="reset_fc_lng" id="reset_venue_lng" value="">
                        <input type="hidden" name="zoom" id="zoom" value="">
                        <input type="hidden" name="venue_council" id="venue_council" value="">
                        <input type="hidden" name="council_id" id="council_id" value="">
                    </div>
                </div>

                <div class="row mrTp15" id="third_section_btn">
                    <div class="col-md-6 col-sm-3 col col-xs-3" id="bck_btn3">
                        <a href="JavaScript:void(0);" onclick="businessForwordTo('address_location', false)"><span class="clr_cmn bckie2"><i class="fa fa-angle-left"></i>Back</span></a>
                    </div>
                    <div class="col-md-6 col-sm-9 col-xs-9 txt_rg1 pd_l_0Dsk">
                        <a href="JavaScript:void(0);" onclick="forwordTo('package');" class="btn cmn_btn1 frm_bt2 lst_btn business_percent3">Next</a>
                    </div>
                </div>
            </div>
        </form>
        <!--form ends--> 

    </div>
    <!--col-sm-6 ends--> 
</div>
<!--row ends--> 
<!--</div>-->
<script>

                            $('#venue_postcode').keyup(function (e)
                            {
                                if (/\D/g.test(this.value))
                                {
                                    // Filter non-digits from input value.
                                    this.value = this.value.replace(/\D/g, '');
                                }
                            });

                            var timeoutId;
                            $('.business_form').on('input propertychange change focusout', function () {
                                $("#business_details").validate({onkeyup: function (element) {
                                        $(element).valid()
                                    },
                                });

                                clearTimeout(timeoutId);

                                timeoutId = setTimeout(function () {
                                    if ($('#venue_business_name').val()) {
                                        saveToDB('FNC_Add_Venue/business_details_add_update', 'business_details');
                                    }
                                }, 1000);
                            });


                            // $('.tltp_ic').click(function(){
                            //     $(this).siblings('.cstm_tooltip1').show();
                            // });
                            // $('.close_tooltip').click(function(){
                            //     $(this).parent('.cstm_tooltip1').hide();
                            // });

                            $('.tltp_span').click(function () {
                                $(this).siblings('.cstmTooltip').show();
                            });

                            $('.skip_tltpClose').click(function () {
                                $(this).parent('.cstmTooltip').hide();
                            });

</script>