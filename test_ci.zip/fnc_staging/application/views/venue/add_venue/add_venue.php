<link rel="stylesheet" href="<?php echo base_url('assets/css/new-style.css'); ?>">
<style>.edit_table {
        width: 80% !important;
    }</style>

<?php $payment_data['pay_by_account_enable'] = (!empty($user_data[0]->pay_by_account)) ? $user_data[0]->pay_by_account : 0 ?>

<section class="function_vene_page first_section" id="add_venue_header">
    <div class="container">
        <div class="row ">

            <?php $this->load->view('venue/add_venue/venue_header'); ?>
            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>
            <!--          Loading Side Menu -->
            <?php $this->load->view('side_menu'); ?>
            <div class="col-md-9 col-sm-8">
                <div class="business_details-page">
                    <?php $this->load->view('venue/add_venue/business_details'); ?>
                </div>
                <div class="package-page " style="display:none">
                    <?php $this->load->view('venue/add_venue/package'); ?>
                </div>
                <div class="venue_details-page" style="display:none">
                    <?php $this->load->view('venue/add_venue/venue_details'); ?>
                </div>
                <div class="page_layout-page" style="display:none">
                    <?php $this->load->view('venue/add_venue/page_layout'); ?>
                </div>
                <div class="listing_area-page" style="display:none">
                    <?php $this->load->view('venue/add_venue/listing_area'); ?>
                </div>
                <div class="spaces-page" style="display:none">
                    <?php $this->load->view('venue/add_venue/spaces'); ?>
                </div>
                <div class="payment-page" style="display:none">
                    <?php $this->load->view('venue/add_venue/payment', $payment_data); ?>
                </div>

                <input type="hidden"  id="current_date" value="<?php echo date('h:i:s'); ?>">

                <input type="hidden"  id="lat-f" value="">
                <input type="hidden"  id="lng-f" value="">
                <input type="hidden"  id='fc_id' value="<?php echo!empty($draft_venue->fc_id) ? encrypt_decrypt('encrypt', $draft_venue->fc_id) : 0 ?>" name='fc_id'>
            </div>
        </div>
    </div>
</section>


<!-- Modal -->
<?php $this->load->view('models/image_cropping'); ?>
<?php $this->load->view('models/error_show'); ?>

<script src="<?php echo base_url('assets/plugins/autocomplete/jquery-ui.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.ezdz.js'); ?>"></script>
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script src="<?php echo base_url('assets/js/chosen.jquery.min.js'); ?>"></script>
<link rel="stylesheet" href="<?php echo base_url('assets/css/chosen.min.css'); ?>">
<script type="text/javascript">
    var getPricing = '<?php echo site_url('venue/get_pricing'); ?>';
    var baseURL = '<?php echo site_url(); ?>';
    var STRIPE_PUBLIC_KEY = '<?php echo STRIPE_PUBLIC_KEY; ?>';
    var draft_additinal_council = '<?php echo!empty($draft_additinal_council) ? json_encode($draft_additinal_council) : ''; ?>';
</script>
<script src="<?php echo base_url('assets/js/custom/coordinate.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/add-venue.js?'.rand()); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/crope_images_with_save.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/character_counter.js'); ?>"></script>
<script >


    $(document).on('click', '.cstm_MlChkBx', function() {

        var CheckboxInput = $(this).find('input[type="checkbox"]');
        // var labName = $(this).find('label').attr('class');
        var labName = $(this).find('label').text().replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '').toLowerCase();;
        var inpName = CheckboxInput.attr('name');

        var labs = $(this).find('label').text();
        var labsSp = labs.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '');
        var myParent = $(this).parent().parent().parent().parent('.main_row11');

        var imgie = $(this).find('.img1Nm').attr('src');

        if(!imgie){
            imgie = '';
        }

        if ($(CheckboxInput).is(':checked')) {

            CheckboxInput.prop('checked', false);
            $(this).removeClass('active');
            $(".VenPrntUl").find('.' + labsSp).remove();

        }

        else {

            $(this).addClass('active');
            $(myParent).find(".VenPrntUl").append($("<li class='" + labsSp + "'>").html('<img src =' + imgie + '> ' + '' + '<label>' + labs + ' </label>'));

            if(labName === 'none'){
                    
                $('input[name="' + inpName + '"]').prop('checked', false);
                $('input[name="' + inpName + '"]').parent('.cstm_MlChkBx').removeClass('active');   
                CheckboxInput.parent('.cstm_MlChkBx').addClass('active');		

            }

            else {

                var noneLAbel = $('input[name="' + inpName + '"]').siblings('label:contains("None")');
                noneLAbel.siblings('input').prop('checked', false);
                noneLAbel.parent('.cstm_MlChkBx').removeClass('active');

            }

            CheckboxInput.prop('checked', true);
        }  
         $("#venue_details_form").valid();
    });


    var freecart = '<?php echo $free ?>';
    if (freecart == '1') {
        $('.mini_cart_popup').hide();
    } else {
        $('.mini_cart_popup').show();
    }


</script>

<script type="text/javascript">
    $('#cancel_crop').hide();

    $('.custom_chkie').click(function () {
        $('.custom_chkie').removeClass('active');
        $(this).children("input").prop("checked", true);
        if ($(this).children("input").is(":checked")) {
            $(this).addClass('active');
        }

    });


    $('#fc_details').characterCounter({
        max: 1200,
        textArea: true
    });
    $('#venue_overview').characterCounter({
        max: 1200,
        textArea: true
    });

    $('.space_details').characterCounter({
        max: 1318,
        textArea: true
    });
    var maxLength = 1318;
    $('.space_details').keyup(function () {
        var length = $(this).val().length;
        var length = maxLength - length;

        $('#char2').text(length + ' characters remaining');


    });
</script>


<script type="text/javascript">

  /* $(window).scroll(function () {
        var stickydrp = $('.billDropdown'),
                scroll = $(window).scrollTop();

        if (scroll >= 560)
            stickydrp.addClass('drpFixed');
        else
            stickydrp.removeClass('drpFixed');
    });
*/
    $('.vn_anch ').click(function (e) {
        e.preventDefault();
    });
</script>