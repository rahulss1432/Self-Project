<!--<div class="col-md-9 col-sm-8">-->
<div class="row second_part6" >
    <div class="col-sm-12">
        <div class="sub_hdngs">
            <h3 class="clr_cmn lising_progess_bar_title"><span>1/2</span> Upload Images</h3>
             <span class="sv_span">last saved:<span class="clr_cmn form-status-holder"></span><button class="btn cmn_btn1 save_btn2">Save</button></span>
            <div class="clearfix"></div>
        </div>
        <div class="progress prog2">
            <div class="progress-bar lising_progess_bar_progress" role="progressbar" aria-valuenow="70"
                 aria-valuemin="0" aria-valuemax="100" style="width:15%">
            </div>
        </div> <!-- progress prog2 ends -->    
    </div>
</div><!-- row ends -->


<?php 
    if(!empty($this->cart->contents())){
        $style='';
        $count = count($this->cart->contents());
    }else{
        $style='display:none';
        $count = 0;
    }
?>
<div class="row">
    <div class="col-sm-12">
        <form class="page_layout" id="page_layout" action="" method="get" role="form" >
            <div class="row">
                <div class="col-sm-12">
                    <div class="fmHeading2">
                        <span class="billDropdown package_cart mini_cart_popup">
                            <i class="fa fa-shopping-cart openShoppingCart cart_ic"></i>
                           <span class="noti_circ" style="<?php echo $style; ?>"><?php echo $count; ?></span>
                            <div class="soFarDiv main-cart drop_bill">
                               <!-- <div class="soFarHead">Your Account So Far <i class="fa fa-times pull-right"></i></div>
                                <h5 style="text-align:center;">Your Cart is empty.</h5>-->
                            </div>
                        </span>
                    </div> 
                </div>
            </div>

            <div id="section_one" class="upload_image-page"><!-- start-->
                <div class="row main_row11" >
                    <div class="col-sm-12">
                        <div class="fmHeading2">
                            <h3 class="clr_cmn">To have your venue looking its best and showcasing the offering a range of images can be uploaded.</h3>

                        </div> 
                    </div><!-- col-sm-12 ends -->
                </div><!-- row ends -->

                <div class="row " >
                    <div class="col-md-9">
                        <div class="row">

                            <div class="col-sm-12"> <h3 class="clr_cmn">Main Image (add 1)</h3></div>
                            <?php
                            if (!empty($draft_venue->fc_listing_picture)) {
                                $img_url = base_url('uploads/fc_images') . '/' . $draft_venue->fc_listing_picture;
                                $removeImg = "removeImage(1, '" . encrypt_decrypt('encrypt', $draft_venue->fc_id) . "', 1, 55555)";
                            } else {
                                $img_url = '';
                                $removeImg = "removeImage(1, '0', 2, 55555 )";
                            }
                            ?>
                            <div class="col-sm-6">

                                <div class="ulpading_img_size_3 listing_picture_thumb fl_wid">
                                    <img id="show_image_55555" class="dropzone" img-id="55555" src="<?php echo $img_url; ?>" style="<?php echo ($img_url == '') ? 'display: none;' : 'display:block;' ?> opacity: 1;">
                                    <input onclick="this.value = null;" type="file" name="fc_listing_picture" data-id="55555" class="file-selector fc_listing_picture image_selector" id="image_selector_55555" accept="image/*">
                                    <input type="hidden" class="fc_listing_picture" name="dimesion_image_55555" id="dimesion_image_55555" value="<?php echo $img_url ? $img_url : 0; ?>">
                                    <input type="hidden" name="fc_image_55555" id="fc_image_55555" value="">

                                </div>
                                <div class="clearfix"></div>
                            </div><!-- col-sm-6 ends -->

                            <div class="col-sm-6">

                                <div class="Img_spec clr_cmn">
                                    <h5>Image Specs</h5>
                                    <h6>Image should be jpeg or png files</h6>
                                    <h6>Dimensions are 300 X 500 Pixels</h6>
                                    <h6><b>Max image size 2 MB</b></h6>

                                    <div class="mn_imgBtGr">
                                        <a href="javascript:void(0)" id="remove_select55555" class="btn cmn_btn2 f_s2 " onclick="<?php echo $removeImg ?>" >Remove</a>
                                        <label ant-id="55555" class="upload-button_new btn cmn_btn1 f_s2" id="another_select_55555">
                                            <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                        </label>
                                    </div>
                                    <span class="img_msg_55555"></span>
                                </div><!-- Img_spec ends -->
                            </div><!-- col-sm-6 ends -->
                        </div><!-- row ends -->
                    </div><!-- col-sm-8 ends -->

                </div><!-- row ends -->


                <div class="row main_row11">

                    <div class="col-md-9 col-sm-12">
                        <h3 class="clr_cmn">Venue Images (add upto 5)</h3>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="venImgBx25 ">

                                    <?php
                                    $old_img_count = (!empty($draft_venue_images)) ? count($draft_venue_images) : 0;

                                    for ($i = 1; $i <= 5; $i++) {
                                        $img_url = '';
                                        if ($old_img_count > 0) {
                                            $img_url = base_url('uploads/fc_images') . '/' . $draft_venue_images[$i - 1]->fc_img_name;
                                            if (empty($draft_venue_images[$i - 1]->fc_img_name)) {
                                                $img_url = '';
                                            }

                                            $old_img_count--;
                                            $removeImg = "removeImage(2, '" . encrypt_decrypt('encrypt', $draft_venue_images[$i - 1]->fc_img_id) . "', 1, $i )";
                                        } else {
                                            $removeImg = "removeImage(2, '0', 2, $i )";
                                        }
                                        ?> 
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="ulpading_img_size_3 listing_picture_thumb fl_wid">
                                                    <img id="show_image_<?php echo $i ?>" class="dropzone" img-id="<?php echo $i ?>" src="<?php echo $img_url ?>" style="<?php echo ($img_url == '') ? 'display: none;' : 'display:block;' ?> opacity: 1;">

                                                    <input onclick="this.value = null;" type="file" name="venue_images_<?php echo $i ?>" data-fc_img_id="" data-id="<?php echo $i ?>" class="file-selector image_selector check_image_validation" id="image_selector_<?php echo $i ?>" accept="image/*" >
                                                    <input type="hidden" class="check_image_validation" name="dimesion_image_<?php echo $i ?>" id="dimesion_image_<?php echo $i ?>" value="<?php echo $img_url ? $img_url: 0; ?>">
                                                    <input type="hidden" name="fc_image_<?php echo $i ?>" id="fc_image_<?php echo $i ?>" value="">

                                                </div>
                                            </div><!-- col-sm-6 ends -->

                                            <div class="col-sm-6">
                                                <div class="Img_spec clr_cmn">
                                                    <h5>Image Specs</h5>
                                                    <h6>Image should be jpeg or png files</h6>
                                                    <div class="mn_imgBtGr">
                                                        <a href="javascript:void(0)" id="remove_select<?php echo $i ?>" class="btn cmn_btn2 f_s2"  onclick="<?php echo $removeImg ?>" >Remove</a>
                                                        <label ant-id="<?php echo $i ?>" class="upload-button_new btn cmn_btn1 f_s2" id="another_select_1">
                                                            <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                        </label>
                                                    </div>
                                                    <span class="img_msg_<?php echo $i; ?>"></span>
                                                </div><!-- Img_spec ends -->
                                            </div><!-- col-sm-6 ends -->
                                        </div><!-- row ends -->
                                    <?php } ?>


                                </div><!-- venImgBx25 ends -->
                            </div><!-- col-md-12 ends -->
                        </div><!-- row ends -->
                    </div><!-- col-sm-9 ends -->
                </div><!-- row ends -->

                <div class="row">
                    <div class="col-sm-12">
                        <div class="CheckieError error images_valid_error" style="display:none"><span>Please upload at least 2 images</span></div>
                    </div>
                </div>

                <div class="row mrTp15">
                    <div class="col-md-3 col-sm-3 col-xs-3" id="back_page_layout1">
                        <a href="javascript:void(0)" onclick="forwordTo('venue_details')"><span class="clr_cmn"><i class="fa fa-angle-left"></i> Back</span></a>
                    </div>
                    <div class="col-md-6 col-sm-9  col-xs-9 text-right">
                        <a href="javascript:void(0)" onclick="listingForwordTo('review_your_listing', true); show_preview_listing();" class="btn cmn_btn1 prw_btn">Preview Your Listing</a>
                    </div>
                </div>
            </div><!-- end section one-->


            <div id="section_second" class="review_your_listing-page" style="display:none"><!--start-->

                <div class="row "  >



                    <div class="col-sm-12">
                        <div class="fmHeading2">
                            <h3 class="clr_cmn">Below is a preview of what your listing for <a class="clr_cmn vn_anch venue_name"><?php echo (!empty($draft_venue->fc_business_name) ? $draft_venue->fc_business_name : '') ?></a> will look like once published. If you are satisfied, click ‘I love it!’.</h3>

                        </div> 
                    </div><!-- col-sm-12 ends -->

                </div><!-- row ends -->

                <div class="row"  >

                    <div class="col-sm-7">      
                        <h3 class="clr_cmn">Otherwise you can go back to make any changes required.</h3>
                    </div><!-- col-sm-6 ends -->

                    <div class="col-sm-4 col-sm-offset-1">

                        <div class="pg_lyBtns">
                            <a href="javascript:;" onclick="forwordTo('page_layout')" class="btn cmn_btn2 btn-block first-section">I want to make some changes</a>
                            <a href="javascript:;" onclick="forwordTo('listing_area'); businessForwordTo('company_details', false);" class="btn cmn_btn1 btn-block">I Love it !</a>
                        </div>
                    </div><!-- col-sm-4ends -->
                </div><!-- row ends -->



                <div class="row" >


                    <div class="col-sm-12">

                        <div class="main_frame12">

                        </div><!-- main_frame12 ends -->

                    </div><!-- col-sm-12 ends -->
                </div><!-- row ends -->

                <div class="row mrTp15">
                    <div class="col-md-6 col-sm-3 col-xs-3">
                        <a href="javascript:void(0)" onclick="listingForwordTo('upload_image', false);" ><span class="clr_cmn " ><i class="fa fa-angle-left"></i> Back</span></a>
                    </div>
                    <div class="col-md-6 col-sm-9  col-xs-9 text-right">
                    <!-- <input type="button" id="nextbtn_page_layout" class="btn cmn_btn1 prw_btn create_map" onclick="initialize();" value="Next"> -->

                        <a href="javascript:void(0)" onclick="forwordTo('listing_area');" class="btn cmn_btn1 prw_btn " >Next</a>
                    </div>

                </div>

            </div><!--section second end-->

        </form>
    </div><!-- col-sm-12 ends -->

</div><!-- row ends -->
<!--</div>-->