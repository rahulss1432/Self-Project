
<div class="div2clone">
    <form id="space_form" >
        
        <div class="space_details-section">
            <div class="col-md-8 col-sm-12 profile_row fountion_7 ">
                <!--<div class="row top_background text-left set_new_102">-->
                <!--    <h4 class="h4-title">Space</h4>-->
                <!--</div>-->
                <div class="row margin_top_and_bottom_user">
                    <div class="col-md-12 margin_set_input text-left">
                        <label class="lbl_class">Space name</label>
                        <input type="text" class="form-control fm-field" name="space_name" data-rule-required="true">
                    </div>
                    <div class="margin_set_input text-left">
                        <div class="col-md-6 margin_set_input ">
                            <label class="lbl_class">Minimum guest numbers</label>
                            <input id="min_guest_<?php echo $num; ?>" type="text" class="form-control fm-field" name="space_min_guest" data-rule-required="true" data-rule-lessThan="#max_guest_<?php echo $num; ?>" data-rule-number="true">
                        </div>
                        <div class="col-md-6 margin_set_input">
                            <label class="lbl_class">Maximum guest numbers</label>
                            <input id="max_guest_<?php echo $num; ?>" type="text" class="form-control fm-field" name="space_max_guest" data-rule-required="true" data-rule-greaterThan="#min_guest_<?php echo $num; ?>" data-rule-number="true">
                        </div>
                    </div>

                    <div class="col-md-12 text-left ">
                        <label class="text-left">Details</label>
                        <div class="txtie">
                            <textarea class="descrp_box2 form-control overview_textarea textare_root venue_details_input space_details validate_special_character"  name="space_details" data-rule-required="true"  rows="4" data-rule-maxlength="1200" maxlength="1200" minlength="100"></textarea>
                            <p class="text-right clr_cmn remaining_counter_show" id="char2">1200 characters remaining</p>
                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd" style="display: none"></i>
                            </span>
                            <label style="display: none;" class="custom-error"></label>
                        </div>

                    </div>

                    

                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="ulpading_img_size_3 listing_picture_thumb fl_wid">
                                    <img id="show_image_<?php echo $img_id; ?>" class="dropzone" img-id="<?php echo $img_id; ?>" src="" style="display: none; opacity: 1;">

                                    <div class="ezdz-dropzone"><div class="for_plus_sign">Drag Files Here</div>
                                        <input onclick="this.value = null;" type="file" name="space_image" data-fc_img_id="" data-id="<?php echo $img_id; ?>" class="file-selector image_selector" id="image_selector_<?php echo $img_id; ?>" accept="image/*">
                                    </div>
                                        
                                    <input type="hidden" name="dimesion_image" id="dimesion_image_<?php echo $img_id; ?>" value="0">
                                    <input type="hidden" name="fc_image" id="fc_image_<?php echo $img_id; ?>" value="">
                                </div>
                            </div><!-- col-sm-6 ends -->

                            <div class="col-sm-6">
                                <div class="Img_spec clr_cmn">
                                    <h5>Image Specs</h5>
                                    <h6>Image should be jpeg or png files</h6>
                                    <div class="mn_imgBtGr">
                                        <a href="javascript:void(0)" class="btn cmn_btn2 f_s2" id="remove_select<?php echo $img_id; ?>" onclick="removeImage(2, '0', 2, <?php echo $img_id; ?>)" style="display:none;">Remove</a>
                                        <label ant-id="<?php echo $img_id; ?>" class="upload-button_new btn cmn_btn1 f_s2 remove_select<?php echo $img_id ?>" id="another_select_<?php echo $img_id; ?>">
                                            <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                        </label>
                                    </div>
                                    <span class="img_msg_<?php echo $img_id; ?>"></span>
                                </div><!-- Img_spec ends -->
                            </div><!-- col-sm-6 ends -->
                        </div>
                    </div>


                </div>
            </div>
            <div class="clearfix"></div>

            <div class="row mrTp40">
                <div class="col-sm-6 col-xs-5" >
                    <a href="JavaScript:void(0);" onclick="spaceForwordTo('cancel', false)"><span class="clr_cmn"><i class="fa fa-angle-left"></i>Cancel</span></a>
                </div>
                <div class="col-sm-6 col-xs-7 txt_rg1">
                    <a href="JavaScript:void(0);" onclick="spaceForwordTo('space_event', true)" data-space_percent1="4.16" class="btn cmn_btn1 frm_bt2 space_percent1">Next</a>
                </div>
            </div>
        </div>

        <div class="space_event-section" style="display:none">
            
            <div class="row">
                <div class="col-sm-12">
                   <div class="fmHeading2">
                      <h3 class="clr_cmn">Space <?php echo $num_word; ?> - Event types</h3>
                   </div>
                </div>
            </div>

            <div class="row main_row11">

                <div class="col-md-6">
                    
                    <div class="row ChkRow">
                            <?php
                        if (!empty($event_types)) {
                            foreach ($event_types as $e_type) {
                                ?>  <div class="col-sm-6 mlCh_cols ">
                                        <p class="cstm_MlChkBx venue_details_input ">
                                            <span>
                                                <img src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->image; ?>" class="img1Nm ">
                                                <img src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->white_image; ?>" class="img2Ch">

                                            </span> 
                                            <input type="checkbox" name="space_events[]" value="<?php echo $e_type->id; ?>"  aria-required="true" required  data-msg-required="Please select at least one space">

                                            <label><?php echo $e_type->name; ?></label>
                                        </p><!-- cstm_MlchkBx ends -->
                                    </div><!-- col-sm-6 ends -->

                                     <?php
                            }
                        }
                        ?>
                    </div> <!-- row endds -->
                    
                    <div class="row">
                        <div class="col-sm-12">
                              <label for="space_events[]" class="error CheckieError" style=""></label>
                        </div>
                    </div>
                    
                </div>
                <!--col-md-6 ends-->
                
                <!-- <div class="col-md-6 col-sm-12">
                        <h3 class="clr_cmn">Summary</h3>
                        <ul class="VenPrntUl">
                        </ul>
                        <div class="clearfix"></div>
                </div> -->
                <!-- col-sm-6 ends -->
                
            </div>
            
         
           
            
           

            <div class="row mrTp40">
                <div class="col-sm-6 col-xs-5" >
                    <a href="JavaScript:void(0);" onclick="spaceForwordTo('space_details', false)"><span class="clr_cmn"><i class="fa fa-angle-left"></i> Back</span></a>
                </div>
                <div class="col-sm-6 col-xs-7 txt_rg1">
                    <a href="JavaScript:void(0);" onclick="spaceForwordTo('space_facilities', true)" data-space_percent2="4.16" class="btn cmn_btn1 frm_bt2 space_percent2">Next</a>
                </div>
            </div>
        </div>

        <div class="space_facilities-section" style="display:none">
            
            <div class="row">
                <div class="col-sm-12">
                   <div class="fmHeading2">
                      <h3 class="clr_cmn">Space <?php echo $num_word; ?> - Facilities</h3>
                   </div>
                </div>
            </div>

            <div class="row main_row11">

                <div class="col-md-6">
                    
                    <div class="row ChkRow">
                            <?php
                 if (!empty($facilities)) {
                       foreach ($facilities as $f_val) {
                           ?> <div class="col-sm-6 mlCh_cols ">
                                        <p class="cstm_MlChkBx venue_details_input ">
                                            <span>
                                                <img src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->image; ?>" class="img1Nm ">
                                                <img src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->white_image; ?>" class="img2Ch">

                                            </span> 
                                            <input type="checkbox" name="space_facilities[]" value="<?php echo $f_val->id; ?>"  aria-required="true" required  data-msg-required="Please select at least one facility">

                                            <label><?php echo $f_val->name; ?></label>
                                        </p><!-- cstm_MlchkBx ends -->
                                    </div><!-- col-sm-6 ends -->

                                     <?php
                            }
                        }
                        ?>
                    </div> <!-- row endds -->
                    
                    <div class="row">
                        <div class="col-sm-12">
                              <label for="space_facilities[]" class="error CheckieError" style=""></label>
                        </div>
                    </div>
                    
                </div>
                <!--col-md-6 ends-->
                
                <!-- <div class="col-md-6 col-sm-12">
                        <h3 class="clr_cmn">Summary</h3>
                        <ul class="VenPrntUl">
                        </ul>
                        <div class="clearfix"></div>
                </div> -->
                
                <!-- col-sm-6 ends -->
                
            </div>
            
            
            
            
          

            <div class="row mrTp40">
                <div class="col-sm-6 col-xs-5">
                    <a href="JavaScript:void(0);" onclick="spaceForwordTo('space_event', false)"><span class="clr_cmn"><i class="fa fa-angle-left"></i> Back</span></a>
                </div>
                <div class="col-sm-6 col-xs-7 txt_rg1">
                    <a href="JavaScript:void(0);" onclick="spaceForwordTo('space_features', true)" data-space_percent3="4.16" class="btn cmn_btn1 frm_bt2 space_percent3">Next</a>
                </div>
            </div>
        </div>

        <div class="space_features-section" style="display:none">
            
            
            <div class="row">
                <div class="col-sm-12">
                   <div class="fmHeading2">
                      <h3 class="clr_cmn">Space <?php echo $num_word; ?> - Features</h3>
                   </div>
                </div>
            </div>

            <div class="row main_row11">

                <div class="col-md-6">
                    
                    <div class="row ChkRow">
                            <?php
                        if (!empty($features)) {
                            foreach ($features as $feat_val) {
                                ?> <div class="col-sm-6 mlCh_cols ">
                                        <p class="cstm_MlChkBx venue_details_input ">
                                            <span>
                                                <img src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->image; ?>" class="img1Nm ">
                                                <img src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->white_image; ?>" class="img2Ch">

                                            </span> 
                                            <input type="checkbox" name="space_facilities[]" value="<?php echo $feat_val->id; ?>"  aria-required="true" required  data-msg-required="Please select at least one facility">

                                            <label><?php echo $feat_val->name; ?></label>
                                        </p><!-- cstm_MlchkBx ends -->
                                    </div><!-- col-sm-6 ends -->

                                     <?php
                            }
                        }
                        ?>
                    </div> <!-- row endds -->
                    
                    <div class="row">
                        <div class="col-sm-12">
                              <label for="space_features[]" class="error CheckieError" style=""></label>
                        </div>
                    </div>
                    
                </div>
                <!--col-md-6 ends-->
                
                <!-- <div class="col-md-6 col-sm-12">
                        <h3 class="clr_cmn">Summary</h3>
                        <ul class="VenPrntUl">
                        </ul>
                        <div class="clearfix"></div>
                </div> -->
                
                <!-- col-sm-6 ends -->
                
            </div>
            
            
            
        

            <div class="row mrTp40">
                <div class="col-sm-6 col-xs-5">
                    <a href="JavaScript:void(0);" onclick="spaceForwordTo('space_facilities', false)"><span class="clr_cmn"><i class="fa fa-angle-left"></i> Back</span></a>
                </div>
                <div class="col-sm-6 col-xs-7 txt_rg1">
                    <a href="JavaScript:void(0);" onclick="spaceForwordTo('finish', true)" data-space_percent4="4.16" class="btn cmn_btn1 frm_bt2 space_percent4">Finish</a>
                </div>
            </div>
        </div>

    </form>

</div>

<script type="text/javascript">
    
     var maxLength = 1200;
    $('.space_details').keyup(function() {
      var length = $(this).val().length;
      var length = maxLength-length;

        $('#char2').text(length+' characters remaining');
        
     
    });
</script>