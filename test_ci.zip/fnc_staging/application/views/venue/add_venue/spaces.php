<div class="row">
    <div class="col-sm-12">
        <div class="sub_hdngs">
            <h3 class="clr_cmn space_progess_bar_title"><span>1/1</span> Spaces</h3>
            <span class="sv_span">last saved:<span class="clr_cmn form-status-holder"><i class="mylastdate"><?php echo !empty(date("d-m-Y", strtotime($last_date))) && date("d-m-Y", strtotime($last_date)) != '01-01-1970'?date("d-m-Y", strtotime($last_date)):'';?></i></span><button class="btn cmn_btn1 save_btn2">Save</button></span>
            <div class="clearfix"></div>
        </div>

        <div class="progress prog2">
            <div class="progress-bar space_progess_bar_progress" role="progressbar" aria-valuenow="70"
                 aria-valuemin="0" aria-valuemax="100" style="width:100%">
            </div>
        </div>
    </div>
</div>
<?php 
    if(!empty($this->cart->contents())){
        $style='';
        $count = count($this->cart->contents());
    }else{
        $style='display:none';
        $count = 0;
    }
?>
<div class="row">

        <div class="col-sm-12">
            <div class="fmHeading2">
                <span class="billDropdown package_cart">
                    <i class="fa fa-shopping-cart openShoppingCart cart_ic"></i>
                    <span class="noti_circ" style="<?php echo $style; ?>"><?php echo $count; ?></span>
                    <div class="soFarDiv main-cart drop_bill">
                        <div class="soFarHead">Your Account So Far <i class="fa fa-times pull-right"></i></div>
                        <h5 style="text-align:center;">Your Cart is empty.</h5>
                        
                    </div>
                </span>
            </div> 
        </div>

    <div class="col-sm-12">
        <div class="space_view ">
            <div class="row">
                <div class="col-sm-12">
                    <div class="fmHeading2">
                    </div> 
                </div>

                <div class="col-md-6 col-sm-12">
                    <h3 class="clr_cmn fr_hdngSpc">Do you have any other spaces at this venue you would like to list?
                       
                       <!--  <i class="tooltip_i">
                             <span class="tltp_span">
                                <img src="http://functionsandcatering.com/staging/function/assets/images/sys_info.svg" class="tltp_ic">
                            </span>
                            <i class="spc_i">i</i>
                            <div class="cstmTooltip left spc_tltp">
                                <h5>Lorem ipsum</h5>
                                <p >Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                            </div>
                        </i> -->

                            <i class="tooltip_i">
                                 <span class="tltp_span">
                                    <img src="<?php echo base_url('assets/images/sys_info.svg'); ?>" class="tltp_ic">
                                </span>
                                <!-- <i class="spc_i">i</i> -->
                                <div class="cstmTooltip left spc_tltp">
                                    <span class="skip_tltpClose">X</span>
                                    <p>Does your venue have multiple function areas with different guest capacity? You can list another space within a venue for $30c a day</p>
                                </div>
                            </i>
                    </h3>

                    <div class="row">
                        <div class="col-sm-4 col-xs-6">
                            <input type="radio" name="radio-group" id="need_space" class="my_radio" >
                            <label for="need_space" class="clr_cmn sm_radie">Yes</label>
                        </div>
                        <div class="col-sm-4 col-xs-6">
                            <input type="radio" name="radio-group"  id="no_need_space" class="my_radio" checked>
                            <label for="no_need_space" class="clr_cmn sm_radie">No</label>
                        </div>
                    </div> 
                    <h5 class="yesNote">Each Additional area is charged at<br/> a rate of 30c per day</h5>
                </div><!-- col-sm-6 ends -->

                <div class="col-md-6 col-sm-12">
                </div><!-- col-md-6 ends -->


                <div class="col-md-6 col-sm-12">
                    <div class="Ven_spc_bx">
                        <h5><b>Venues and Spaces</b></h5>
                        <p>With F&C you have the option to set up ‘spaces’ within venues. For example if you have a property with several unique areas for hire within the same address.<br/>
                            Spaces can be found by clicking into the parent venue on the venues page.
                        </p>
                    </div><!-- Ven_spc_bx ends -->
                </div><!-- col-md-6 ends -->
            </div><!-- row ends -->

            <div class="row mrTp40 ">
                <div class="col-md-6 col-sm-3 col-xs-3" id= "back_btn_spaces">
                    <a href="JavaScript:void(0);" onclick="forwordTo('listing_area')"><span class="clr_cmn"><i class="fa fa-angle-left"></i> Back</span></a>
                </div>
                <div class="col-md-6 col-sm-9 col-xs-9 txt_rg1">
                    <button class="btn cmn_btn1 frm_bt2 btn_space" style="display:none" id="btn_spaces">Add Space</button> 
                    <a href="JavaScript:void(0);" onclick="forwordTo('payment', 'getPaymentCart')" class="btn cmn_btn1 frm_bt2 btn_checkout">Checkout</a>
                </div>
            </div>
        </div>

        <div class="single_space_form">
            <div class="row">
            <div class="col-md-12 col-sm-12 " id="append2divspace">
                

            </div>
            </div>
        </div>

    </div><!-- col-sm-12 ends -->
</div><!-- row ends -->

<script type="text/javascript">
    $('.tltp_span').click(function(){
        $(this).siblings('.cstmTooltip').show();
    });

    $('.skip_tltpClose').click(function(){
        $(this).parent('.cstmTooltip').hide();
    });
    
    
    var maxLength = 1318;
    $('.space_details').keyup(function() {
      var length = $(this).val().length;
      var length = maxLength-length;

        $('#char2').text(length+' characters remaining');
        
     
    });
</script>