<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/owl.carousel.min.css" />
<script src="<?php echo base_url(); ?>assets/js/owl-slider.js" ></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php
if (isset($venue_data)) {
    ?>
    <section class="single_venues_section space_change">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 vanue-name-head">
                    <span id="venue-name" class="venue-name-new"><?php echo $venue_data->fc_business_name ?></span>
                    <span id="space_type_title" class="venue-name-new" style="display: none">Space</span>
                    <span id="venue-add" class="venue-address"><?php echo $venue_data->fc_street . ', ' . $venue_data->fc_suburb . ', ' . $venue_data->fc_country ?></span>
                </div>
                <div class="col-sm-4 category-type">
                    <span class="function_text space_change_div">Venue</span>
                </div>
            </div>
            <div class="row">

                <div class="col-md-12">
                    <div class="space_available_text mb-3">
                        <?php
                        if (!empty($venue_data->spaces)) {
                            echo 'Spaces Available:';
                        }
                        ?>

                    </div>
                    <ul class="nav nav-pills set_root_nav_pills mt-0">
                        <?php
                        if (!empty($venue_data->spaces)) {
                            foreach ($venue_data->spaces as $space) {
                                ?>
                                <li><a class="venue_space" data-value="<?php echo $space->space_id ?>" href="javascript:;"><?php echo $space->space_name ?></a></li> <!-- $space->space_id -->
                                <?php
                            }
                            echo '<div class="close_icons_1 close_sec hidden-xs" style="display:none"><img src="' . base_url("assets/images/close_arrow.png") . '"></div>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>


    <section class="section-white space_change">
        <div class="container-fluid">
            <div class="row">
                <div class=" fnc_slider" >
                    <div id="carousel-example-generic" class="carousel slide button_set" data-ride="carousel">


                        <div class="carousel-inner">
                            <?php
                            $i = 1;
                            if (array_key_exists('fc_images', $venue_data)) {
                                foreach ($venue_data->fc_images as $images) {
                                    if ($images) {
                                        $banner_img = base_url('uploads/fc_images/') . $images;
                                        ?>
                                        <div class="item <?php echo ($i == 1) ? 'active' : '' ?>"><img src="<?php echo $banner_img ?>" alt="Venue Images"></div>
                                        <?php
                                        $i++;
                                    }
                                }
                            }
                            if ($i == 1) {
                                ?>
                                <div class="item active"><img src="<?php echo base_url('assets/images/FnC_banner.jpg'); ?>" alt="Venue Images"></div>
                                <?php
                            }
                            ?>
                        </div>
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-example-generic" data-slide-to="0" class=""></li>
                            <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
                            <li data-target="#carousel-example-generic" data-slide-to="2" class="active"></li>
                        </ol>
                        <a class="left carousel-control width_set_carousel-control" href="#carousel-example-generic" data-slide="prev">
                            <img class="Ven_arrw ar_left" src="<?php echo base_url(); ?>assets/images/arrow_left.png">
                        </a>
                        <a class="right carousel-control width_set_carousel-control" href="#carousel-example-generic" data-slide="next">
                            <img class="Ven_arrw ar_right" src="<?php echo base_url(); ?>assets/images/arrow_right.png">
                        </a>
                    </div>
                </div>
            </div>
            <div class="row space_slider" style="display:none">
                <div class="container">
                    <div class="modal_one_img"><img id="space_banner" src="" altf="Venue Images"></div>
                </div>
            </div>
        </div>

    </div>
    </section>

    <section class="keyMenu_sec">
        <div class="container">
            
            <ul class="SnVen_Menu">
                <li class="active"><a href="">Overview</a></li>
                <li><a href="">The Terrace</a></li>
                <li><a href="">Cocktail Lounge</a></li>
                <li><a href="">Main Restaurant</a></li>
                <li><a href="">LB Private</a></li>
            </ul>

        </div>
    </section>


    <section class="space_change">
        <div class="container detail-single-venue">
            <div class="row">
                <div class="col-lg-8 col-sm-8">
                    <div class="space_change_modal for_venue_extra_details"> <!-- blur class  space_change -->
                        <div class="row" style="display: none;">
                            <div class="col-lg-6 col-sm-4 single-venue-overview col-xs-3">
                                <span>Overview.</span>
                            </div>
                            <div class="col-lg-6  col-sm-8 single-venue-overview text-right col-xs-9">
                                <span id="perfect_for"> Perfect for <?php echo $venue_data->fc_min_guest . '-' . $venue_data->fc_max_guest; ?> guests</span>
                                <span id="perfect_for_space" style="display: none"></span>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 details" id="fc_overview">
                                <?php echo $venue_data->fc_overview; ?>
                            </div>
                            <div class="col-lg-12 details" id="space_overview" style="display: none;">
                            </div>
                        </div>


                        <div class="row">
                            
                            <div class="col-sm-12 name_col1_">
                                <h4 class="clr_cmn">Space</h4>
                                <h3>The Terrace</h3> 
                            </div>

                            <div class="col-sm-8 add_col1_">
                                <h5 class="clr_cmn"><?php echo $venue_data->fc_street . ', ' . $venue_data->fc_suburb . ', ' . $venue_data->fc_country ?></h5>
                            </div>
                            <div class="col-sm-4 quan_cl1_">
                                <h6 class="clr_cmn">Perfect for <?php echo $venue_data->fc_min_guest . '-' . $venue_data->fc_max_guest; ?> guests</h6>
                            </div>

                            <div class="col-sm-12 details" id="fc_overview">
                                <?php echo $venue_data->fc_overview; ?>
                            </div>

                        </div>


                        <?php if ($venue_data->events) { ?>
                            <div class="for_fc bor_bot1">
                                <div class="row">
                                  
                                    <div class="col-sm-12 ev_headCol">
                                        <span class="">Great for:</span>
                                    </div>

                                    <div class="col-sm-12">
                                        
                                        <div class="row">
                                            <?php
                                        foreach ($venue_data->events as $events) {
                                            ?> 
                                            <div class="col-md-3 col-sm-4 col-xs-4">
                                                
                                                <div class="evsBox22">
                                                    <img class="size-new_1" src="<?php echo base_url('uploads/fnc_types/') . $events->image ?>">
                                                    <span class="bottom_content_text"><?php echo $events->name ?></span>
                                                </div>

                                            </div>
                                            <?php
                                        }
                                        ?>

                                        </div> <!-- row ends -->

                                    </div><!-- col-sm-12 ends -->

                                    <div class="col-sm-12">
                                        <span class="shw_allBtn">Show All</span>
                                    </div>

                                </div>
                                <div class="row" style="display: none;">
                                    <ul id="bxslider_1"  class=" text-center">
                                        <?php
                                        foreach ($venue_data->events as $events) {
                                            ?>
                                            <li> <img class="size-new_1" src="<?php echo base_url('uploads/fnc_types/') . $events->image ?>"><span class="bottom_content_text"><?php echo $events->name ?></span></li>
                                            <?php
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        <?php } ?>

                        <div class="for_space" id="space_event_div" style="display:none">
                            <div class="row for_space" >
                                <div class="col-sm-12 single-venue-great-for">
                                    <span class="heading">Great for:</span>
                                </div>
                            </div>
                            <div class="row">
                                <ul id="space_event"  class=" new_slider_final text-center elastislide-list"></ul>
                            </div>
                        </div>

                        <?php if ($venue_data->facilities) { ?>
                            <div class="for_fc bor_bot1">
                                <div class="row ">
                                    
                                    <div class="col-sm-12 ev_headCol">
                                        <span class="">The venue has:</span>
                                    </div>


                                    <div class="col-sm-12">
                                        
                                        <div class="row">
                                            <?php
                                        foreach ($venue_data->facilities as $facilities) {
                                            ?>
                                            <div class="col-md-3 col-sm-4 col-xs-4">
                                                
                                                <div class="evsBox22">
                                                    <img class="size-new_1" src="<?php echo base_url('uploads/fnc_types/') . $facilities->image ?>">
                                                    <span class="bottom_content_text"><?php echo $facilities->name ?></span>
                                                </div>

                                            </div>
                                            <?php
                                        }
                                        ?>

                                        </div> <!-- row ends -->

                                    </div><!-- col-sm-12 ends -->
                                    <div class="col-sm-12">
                                        <span class="shw_allBtn">Show All</span>
                                    </div>


                                </div>
                                <div class="row" style="display: none;">
                                    <ul id="bxslider_2" class="  text-center">
                                        <?php
                                        foreach ($venue_data->facilities as $facilities) {
                                            ?>
                                            <li> <img class="size-new_1" src="<?php echo base_url('uploads/fnc_types/') . $facilities->image ?>"><span class="bottom_content_text"><?php echo $facilities->name ?></span></li>
                                            <?php
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        <?php } ?>

                        <div class="for_space" id="space_facilities_div" style="display:none">
                            <div class="row " >
                                <div class="col-sm-12 single-venue-venue-has">
                                    <span class="heading">The venue has:</span>
                                </div>
                            </div>
                            <div class="row">
                                <ul id="space_facilities"  class=" new_slider_final text-center elastislide-list"></ul>
                            </div>
                        </div>

                        <?php if ($venue_data->features) { ?>
                            <div class="for_fc bor_bot1">
                                <div class="row">


                                    <div class="col-sm-12 ev_headCol">
                                        <span class="">The venue features:</span>
                                    </div>

                                    <div class="col-sm-12">
                                        
                                        <div class="row">
                                            <?php
                                        foreach ($venue_data->features as $features) {
                                            ?>
                                            <div class="col-md-3 col-sm-4 col-xs-4">
                                                
                                                <div class="evsBox22">
                                                   <img class="size-new_1" src="<?php echo base_url('uploads/fnc_types/') . $features->image ?>"><span class="bottom_content_text"><?php echo $features->name ?></span>
                                                </div>

                                            </div>
                                            <?php
                                        }
                                        ?>

                                        </div> <!-- row ends -->

                                    </div><!-- col-sm-12 ends -->
                                    <div class="col-sm-12">
                                        <span class="shw_allBtn">Show All</span>
                                    </div>

                                   
                                </div>


                                <div class="row" style="display:none">
                                    <ul id="bxslider_3" class=" text-center">
                                        <?php
                                        foreach ($venue_data->features as $features) {
                                            ?>
                                            <li> <img class="size-new_1" src="<?php echo base_url('uploads/fnc_types/') . $features->image ?>"><span class="bottom_content_text"><?php echo $features->name ?></span></li>
                                            <?php
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        <?php } ?>

                        <div class="for_space" id="space_features_div" style="display:none">
                            <div class="row">
                                <div class="col-sm-12 single-venue-venue-has">
                                    <span class="heading">The venue features:</span>
                                </div>
                            </div>
                            <div class="row">
                                <ul id="space_features" class=" new_slider_final text-center elastislide-list"></ul>
                            </div>
                        </div>
                        <div class="close_icons_1 hidden-xs" style="display:none"><img src="<?php echo base_url('assets/images/close_arrow.png'); ?>"></div>
                    </div>



                    <div id="catering_details" class="maring_bottom_set_content">
                        <div class="review_head">The detail:</div>
                        <div class="heading_main_title">
                            <!--<spna>Space.</spna>-->
                            <p><?php echo $venue_data->fc_details ?></p>
                        </div>
                    </div>

                    <div id="reviews" class="space_change_div">
                        <div class="row">
                            <div class="col-lg-6 col-sm-4 col-xs-6 single-venue-overview text-left mb-30">
                                <span>Reviews:</span>
                            </div>

                        </div>
                        <?php
                        if (!empty($venue_review)) {
                            ?>
                            <input type="hidden" id="r_venue_id" value="<?php echo encrypt_decrypt('decrypt', $this->uri->segment(3)) ?>">
                            <div class="all_coments">
                                <div class="row review_text review_rating tutorial_list">
                                    <?php
                                    $sum = 0;
                                    $count = count($venue_review);
                                    foreach ($venue_review as $key => $review) {
                                        $postID = $review->f_id;

                                        $user_image = $review->user_image;
                                        if (!empty($user_image))
                                            $img_url = $user_image;
                                        else
                                            $img_url = base_url() . 'uploads/users/FnC_user_icon.png';

                                        $sum = (int) $review->f_rating_overall + (int) $review->f_rating_cleanliness + (int) $review->f_rating_accuracy + (int) $review->f_rating_comm;
                                        $avg = $sum / 4;
                                        ?>
                                        <div class="col-lg-12 col-sm-12 col-xs-12 user-rating-detail u_r_d-104" id="totalrating">
                                            <div class="col-sm-3 col-md-2 col-xs-3">
                                                <img class="img_rewiew_nee" src="<?php echo $img_url ?>">
                                            </div><!-- col-sm-3 -->
                                            <div class="col-sm-9 col-md-10 col-xs-9">
                                                <div class="comm_user-desc">
                                                    <span class="comm_author_name"><?php echo ucfirst($review->user_firstname . ' ' . $review->user_lastname) ?>.</span>
                                                    <div class="reviews_div_107">
                                                        <?php echo generate_review_html($avg); ?>
                                                        <span class="no-reviews"><?php echo date('F Y', strtotime($review->f_created_on)) ?></span>
                                                    </div>
                                                    <?php echo $review->f_text; ?>
                                                </div>

                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>                                    
                                </div>
                            </div>
                            <div class="row text-left col-sm-9 col-md-10 col-xs-9">
                                <?php
                                if ($all_row_count > DEFAULT_ROW_COUNT_REVIEW_PAGINATION) {
                                    ?>
                                    <div class="show_more_main" id="show_more_main<?php echo $postID; ?>">
                                        <span id="<?php echo $postID; ?>" class="show_more design_class design_single" title="Load more reviews">Show more</span>
                                        <span class="loding" style="display: none;"><span class="loding_txt">Loading....</span></span>  
                                    </div>
                                    <?php
                                }
                                ?>
                                <?php
                                $check_rev = check_review_provided($venue_data->fc_id);

                                if ($check_rev) {
                                    ?>
                                    <button id="review-write" data-fnc="<?php echo encrypt_decrypt('encrypt', $venue_data->fc_id); ?>" class="btn btn-default review_css">Review provided</button>              <?php } else{ ?>
                                    <button id="review-write" data-fnc="<?php echo encrypt_decrypt('encrypt', $venue_data->fc_id); ?>" class="btn btn-default">Add review <img src="<?php echo base_url('assets'); ?>/images/3.Add-for-add-review.svg"></button>
                                <?php } ?>
                            </div>


                            <?php
                        } else {
                            ?>
                            <div class="col-lg-6 col-sm-4 col-xs-6 single-venue-overview text-left" style="padding: 0px">                                
                                 <?php
                                $check_rev = check_review_provided($venue_data->fc_id);
                                
                                if ($check_rev) {
                                    ?>
                                    <button id="review-write" data-fnc="<?php echo encrypt_decrypt('encrypt', $venue_data->fc_id); ?>" class="btn btn-default">Review provided</button>              <?php } else{ ?>
                                    <button id="review-write" data-fnc="<?php echo encrypt_decrypt('encrypt', $venue_data->fc_id); ?>" class="btn btn-default">Add review <img src="<?php echo base_url('assets'); ?>/images/3.Add-for-add-review.svg"></button>
                                <?php } ?>
                            </div>
                            <div class="col-lg-6  col-sm-8 col-xs-6 pull-right px-0">
                                <div class="reviews_div_107 single_venus_page_star">
                                    <?php
                                    $all_avg = $record_count = 0;
                                    $venue_id = encrypt_decrypt('decrypt', $this->uri->segment(2));
                                    $all_review = avg_review_count_venue($venue_id);
                                    if (!empty($all_review)) {
                                        $record_count = count($all_review);
                                        $main_count = 0;
                                        $sum = 0;
                                        foreach ($all_review as $key => $review) {
                                            $sum = (int) $review->f_rating_overall + (int) $review->f_rating_cleanliness + (int) $review->f_rating_accuracy + (int) $review->f_rating_comm;
                                            $avg = $sum / 4;
                                            $main_count = $main_count + $avg;
                                        }
                                        $all_avg = $main_count / $record_count;
                                    }

                                    echo generate_review_html($all_avg);
                                    if (empty($all_review)) {
                                        ?><span class="no-reviews">No reviews yet…</span>  <?php } else { ?><span class="no-reviews"><?php echo $record_count ?>  Reviews</span>  <?php } ?>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div> <!--reviews-section-->

                </div><!--col-lg-8 col-sm-8-->



                <div  class="col-lg-4 col-sm-4">

                    <div id="friend_request_area_mobile" class="fav_user">

                    </div>

                    <div id="venue_request_area">
                        <div class="single-venue-overview mt-5 mb-4 hidden-lg hidden-md hidden-sm">
                            <span>Venue Request:</span>
                        </div>
                        <div  class="space_change_modal"> <!-- blur class  space_change -->
                            <div id="venue_request_form" class="contact-detail-venue">
                                <div class="contact-page-form">
                                    <form id="enq_form" name="edit_post">
                                        <input  type="hidden" name="fq_fc_id" id="venue_id" value="<?php echo encrypt_decrypt('encrypt', $venue_data->fc_id); ?>">

                                        <div class="row profile_row">

                                            <div class="col-md-12 col-sm-12 col-xs-12 nw_formGroup">
                                                <div class="fielDBox_22">               
                                                    <label class="fielLabel not_mandatory">Space:</label>
                                                    <select class="fielInp">
                                                        <option>Please select a venue space</option>
                                                    </select>
                                                   
                                                </div> 
                                            </div>
                                            
                                            <div class="col-md-12 col-sm-12 col-xs-12 nw_formGroup">
                                                <div class="fielDBox_22">               
                                                    <label class="fielLabel not_mandatory">Preferred Function Date:</label>
                                                    <input  class="enquirydate fielInp" data-rule-required="true" name="fq_function_date" type="text" id="datepicker" placeholder="DD-MM-YYYY"
                                                      onfocus="this.placeholder = ''"
                                                      onblur="this.placeholder = 'DD-MM-YYYY'"

                                                    >
                                                   
                                                </div> 
                                            </div>


                                            <div class="col-md-12 col-sm-12 col-xs-12 nw_formGroup">
                                                <div class="fielDBox_22">               
                                                    <label class="fielLabel not_mandatory">Proposed Number of Guests:</label>
                                                    <input  id="enq_guest" data-rule-required="true" name="fq_guest_no" class="enquiryguest fielInp" type="number" placeholder="Up to 30"
                                                      placeholder="Up to 30"
                                                      onfocus="this.placeholder = ''"
                                                      onblur="this.placeholder = 'Up to 30'"
                                                    >
                                                </div> 
                                            </div>


                                            <div class="col-md-12 col-sm-12 col-xs-12 nw_formGroup">
                                                <div class="fielDBox_22">               
                                                    <label class="fielLabel not_mandatory">Event Type:</label>

                                                    <input class="questionhere1 fielInp" data-rule-required="true" name="fq_event_type" type="text" 
                                                    placeholder="Wedding, birthday, corporate launch [etc]..."
                                                      onfocus="this.placeholder = ''"
                                                      onblur="this.placeholder = 'Wedding, birthday, corporate launch [etc]...'"
                                                    >

                                                </div> 
                                            </div>


                                            <div class="col-md-12 col-sm-12 col-xs-12 nw_formGroup">
                                                <div class="fielDBox_22">               
                                                    <label class="fielLabel not_mandatory">Anything Else?</label>

                                                    <input class="questionhere2 fielInp" data-rule-required="true" name="fq_other_queries" type="text"
                                                    placeholder="Queries, special requests/requirements [etc].."
                                                    onfocus="this.placeholder = ''"
                                                    onblur="this.placeholder = 'Queries, special requests/requirements [etc]..'"
                                                    >    
                                                    <input  name="fc_url" type="hidden" value="<?php echo current_url(); ?>">

                                                    

                                                </div> 
                                            </div>

                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                               
                                               <div class="row" >
                                                   
                                                    

                                                    <div class="col-lg-6 col-md-12 col-sm-12">
                                                        <a href="">
                                                            <div id="send_to_friend" class="ask_wishes ">
                                                                <span id="span-wishlist">Send to a friend</span>
                                                                <img class="img-responsive" id="img-msg" src="<?php echo base_url(); ?>assets/images/6.Send-to-friend(1).svg">
                                                            </div>
                                                        </a>
                                                    </div>

                                                    <div class="col-lg-6 col-md-12 col-sm-12">
                                                        <a href="<?php echo site_url('venue/add_to_wishlist'); ?>" id="add_wish_list">
                                                            <div class="ask_wishes">
                                                                <?php $user_wishlist = cheak_wishlist($wish_list, $venue_data->fc_id); ?>
                                                                <span id="span-wishlist"><?php echo $user_wishlist['title'] ?></span>
                                                                <?php echo $user_wishlist['img'] ?>
                                                                <span></span>
                                                            </div>
                                                        </a>
                                                    </div>

                                               </div> 

                                            </div>



                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <input class="submit_button btn-block" id="query_submit" type="submit" value="Submit">
                                            </div>


                                        </div><!-- row ends -->

                                     
                                       <!--  <div class="contact-form-field">
                                            <input class="submit_button" id="query_submit" type="submit" value="Submit">
                                        </div> -->
                                    </form>

                                    <!-- fav btn strt-->
                                </div>

                                <!-- <div id="friend_request_area" class="col-lg-12" >
                                    <a href="<?php //echo site_url('venue/add_to_wishlist'); ?>" id="add_wish_list">
                                        <div class="contact-detail-venue-wish">
                                            <?php $user_wishlist //= cheak_wishlist($wish_list, $venue_data->fc_id); ?>
                                            <span id="span-wishlist"><?php //echo $user_wishlist['title'] ?></span>
                                            <?php //echo $user_wishlist['img'] ?>
                                            <span></span>
                                        </div>
                                    </a>

                                    <a href="">
                                        <div id="send_to_friend" class="contact-detail-venue-wish c-d-v-w_104">
                                            <span id="span-wishlist">Send to a friend</span>
                                            <img class="img-responsive" id="img-msg" src="<?php //echo base_url(); ?>assets/images/6.Send-to-friend(1).svg">
                                        </div>
                                    </a>
                                </div> -->

                            </div><!-- contact-detail-venue -->
                        </div>
                        <div class="clearfix"></div>

                        <div class="adver space_change_bnner hidden-xs" style="display:none;">
                            <img src="<?php echo base_url(); ?>assets/images/img_advet_singalvenus.jpg" class="img-responsive adver_img">
                            <div class="positon_set_1" style="display:none">
                                <img class="img-responsive logo_adver" src="<?php echo base_url(); ?>assets/images/Functions_LogoFandC_w.png">
                                <h1>Register your <spna>business for <b>FREE</b></spna> Limited time only</h1>
                                <a class="register_now_title">Register now</a>
                            </div>

                            <div class="clearfix"></div>


                        </div>

                        <div  id="bottom_space_button" style="display: none">
                            <div class="space_available_text mb-3 text-center">
                                <?php
                                if (!empty($venue_data->spaces)) {
                                    echo 'Other Spaces Available:';
                                }
                                ?>
                            </div>
                            <ul class="nav nav-pills set_root_nav_pills mt-0 text-center">
                                <?php
                                if (!empty($venue_data->spaces)) {
                                    foreach ($venue_data->spaces as $space) {
                                        ?>
                                        <li class="t-center"><a class="venue_space t-center" data-value="<?php echo $space->space_id ?>" href="javascript:;"><?php echo $space->space_name ?></a></li> <!-- $space->space_id -->
                                        <?php
                                    }
                                    echo '
                            <br>
                              <div class="close_icons_1 close_sec btn_back_to_list" style="display:none"><span>Back to Main listing</span></div>';
                                }
                                ?>
                            </ul>
                        </div>

                    </div><!-- col-lg-4 col-sm-4 -->
                </div>
            </div><!--row-->
        </div><!--container-->
    </section>


    <section class="Location_section space_change">
        <div class="clearfix"></div>
        <div class="container">
            <div class="row single-page-map">
                <div class="col-lg-12">
                    <span class="location-text">Location:</span>
                    <div id="map"></div>
                </div>
            </div>
        </div>
    </section>


    <section class="might_like_area">
        
        <div class="container">
            
            <h3 class="clr_cmn nwHdngs12">You might also like:</h3>

            <div class="row">
                
                <div class="col-sm-4 col-md-3 ">
                    
                    <div class="mightList_box">
                        <a href="">
                        <div class="listImg_div">
                            <img src="http://functionsandcatering.com/staging/function/uploads/fc_images/Alatonero_233.jpg" />

                            <span class="add_favMy_">
                                <img src="http://functionsandcatering.com/staging/function/assets/images/heart-white.svg" />
                            </span>
                        </div>
                        </a>
                        <div class="mon_name_">
                            <h4>Mon Bijou</h4>
                            <span>5 Specs</span>
                        </div><!-- mon_name_ ends -->

                        <div class="mon_bodyMain_">
                            <h5 class="clr_cmn">Function</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut </p>
                            <div class="list_rating_">
                                <i class="fa fa-star rated"></i>
                                <i class="fa fa-star rated"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                        </div>

                    </div>

                </div>
                <!-- col-md-3 ends -->


                <div class="col-sm-4 col-md-3 ">
                    
                    <div class="mightList_box">
                        <a href="">
                        <div class="listImg_div">
                            <img src="http://functionsandcatering.com/staging/function/uploads/fc_images/Alatonero_233.jpg" />
                            <span class="add_favMy_">
                                <img src="http://functionsandcatering.com/staging/function/assets/images/heart-white.svg" />
                            </span>
                        </div>
                        </a>
                        <div class="mon_name_">
                            <h4>Mon Bijou</h4>
                            <span>5 Specs</span>
                        </div><!-- mon_name_ ends -->

                        <div class="mon_bodyMain_">
                            <h5 class="clr_cmn">Function</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut </p>
                            <div class="list_rating_">
                                <i class="fa fa-star rated"></i>
                                <i class="fa fa-star rated"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                        </div>

                    </div>

                </div>
                <!-- col-md-3 ends -->


                <div class="col-sm-4 col-md-3 ">
                    
                    <div class="mightList_box">
                        <a href="">
                        <div class="listImg_div">
                            <img src="http://functionsandcatering.com/staging/function/uploads/fc_images/Alatonero_233.jpg" />
                            <span class="add_favMy_">
                                <img src="http://functionsandcatering.com/staging/function/assets/images/heart-white.svg" />
                            </span>
                        </div>
                        </a>
                        <div class="mon_name_">
                            <h4>Mon Bijou</h4>
                            <span>5 Specs</span>
                        </div><!-- mon_name_ ends -->

                        <div class="mon_bodyMain_">
                            <h5 class="clr_cmn">Function</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut </p>
                            <div class="list_rating_">
                                <i class="fa fa-star rated"></i>
                                <i class="fa fa-star rated"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                        </div>

                    </div>

                </div>
                <!-- col-md-3 ends -->


                <div class="col-sm-4 col-md-3 ">
                    
                    <div class="mightList_box">
                        <a href="">
                        <div class="listImg_div">
                            <img src="http://functionsandcatering.com/staging/function/uploads/fc_images/Alatonero_233.jpg" />
                            <span class="add_favMy_">
                                <img src="http://functionsandcatering.com/staging/function/assets/images/heart-white.svg" />
                            </span>
                        </div>
                        </a>
                        <div class="mon_name_">
                            <h4>Mon Bijou</h4>
                            <span>5 Specs</span>
                        </div><!-- mon_name_ ends -->

                        <div class="mon_bodyMain_">
                            <h5 class="clr_cmn">Function</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut </p>
                            <div class="list_rating_">
                                <i class="fa fa-star rated"></i>
                                <i class="fa fa-star rated"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                        </div>

                    </div>

                </div>
                <!-- col-md-3 ends -->


                <div class="col-sm-4 col-md-3 ">
                    
                    <div class="mightList_box">
                        <a href="">
                        <div class="listImg_div">
                            <img src="http://functionsandcatering.com/staging/function/uploads/fc_images/Alatonero_233.jpg" />
                            <span class="add_favMy_">
                                <img src="http://functionsandcatering.com/staging/function/assets/images/heart-white.svg" />
                            </span>
                        </div>
                        </a>
                        <div class="mon_name_">
                            <h4>Mon Bijou</h4>
                            <span>5 Specs</span>
                        </div><!-- mon_name_ ends -->

                        <div class="mon_bodyMain_">
                            <h5 class="clr_cmn">Function</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut </p>
                            <div class="list_rating_">
                                <i class="fa fa-star rated"></i>
                                <i class="fa fa-star rated"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                        </div>

                    </div>

                </div>
                <!-- col-md-3 ends -->



            </div><!-- row ends -->

        </div><!-- container ends -->

    </section><!-- might_like_area ends -->

    <section class="setion_sign_v_p space_change">
        <div class="container">
            <?php
            if (!empty($nearest_to_me)) {
                ?>
                <div class="row ">
                    <div class="col-sm-12">
                        <span class="also-like also-like_103">You might also like:</span>
                    </div>
                </div>
                <div class="row respon_m">
                    <div class="main device_size">
                        <?php
                        foreach ($nearest_to_me as $key => $value) {
                            if ($value->fc_type == 1) {
                                $url = base_url('web/single_venue/' . encrypt_decrypt('encrypt', $value->fc_id));
                            } else {
                                $url = base_url('web/single_catering/' . encrypt_decrypt('encrypt', $value->fc_id));
                            }

                            if (file_exists('uploads/fc_images/' . $value->fc_img_name) && !empty($value->fc_listing_picture)) {
                                $img_path = base_url('uploads/fc_images/' . $value->fc_listing_picture);
                            } else {
                                $img_path = base_url('assets/images/featured_image.jpg');
                            }
                            ?>
                            <a href="<?php echo $url ?>">
                                <div class="atribute">
                                    <!-- <div class="col-sm-8 col-xs-8 set_color_p"> -->

                                    <div class="col-sm-7 col-sm-push-5 set_color_p">
                                        <span id="content_6" class="main_text"><?php echo $value->fc_business_name ?></span>
                                        <span class="function_text"><?php
                                            if ($value->fc_type == 1)
                                                echo 'Function';
                                            else
                                                echo 'Catering';
                                            ?></span>
                                        <div class="reviews_div_107 reviews_768 hidden-lg hidden-sm hidden-md">
                                            <?php echo review_count($value->fc_id); ?>
                                        </div>
                                        <div  class="clearfix"></div>
                                        <p>
                                            <?php
                                            $string = $value->fc_overview;
                                            if (strlen($value->fc_overview) > 100) {
                                                $stringCut = substr($value->fc_overview, 0, 100);
                                                $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                            }
                                            echo $string;
                                            ?>
                                        </p>
                                        <div class="reviews_div_107 reviews_768 hidden-xs">
                                            <?php echo review_count($value->fc_id); ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-5 col-sm-pull-7 right_pad">
                                        <img src="<?php echo $img_path; ?>" class="img-responsive">
                                    </div>


                                </div>
                            </a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
                <?php
            }
            ?>
        <?php } ?>

    </div>
</section>

<div  class="clearfix"></div>

<section class="section-7 hidden-md hidden-sm hidden-lg bg_white">


    <div class="container inspiration_container">

        <div class="row add_back home-row-add-back">

            <hr class="border-line">
            <div class="col-sm-12">
                <div class="row">
                    <div class="col-sm-12 hidden-xs">                   
                        <a href="#" class="webAdvertisment" target="_blank">
                            <img src="<?php echo base_url('assets'); ?>/images/glenmorangle_add_700X87.jpg">
                        </a>  
                    </div> 
                    <div class="col-md-12 hidden-lg hidden-md hidden-sm" style="display:none;">                   
                        <a href="#" class="webAdvertisment" target="_blank">
                            <img src="<?php echo base_url('assets'); ?>/images/img_advet_singalvenus.jpg">
                        </a>  
                    </div> 

                </div>
            </div>
        </div>
    </div>
</section>

<!-- Modal -->
<div id="send_to_model" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Send to a friend</h4>
            </div>
            <div class="modal-body">
                <form id="send_frnd">
                    <input type="hidden" name="venue_url" id="venue_url" value="<?php echo current_url(); ?>">
                    <input type="hidden" name="venue_id" id="venue_id_friend" value="">
                    <div class="form-group">
                        <label for="email">Friend Name:</label>
                        <input type="text" data-rule-required="true" name="friend_name"  class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email"  name="email" data-rule-required="true" class="form-control" id="email">
                    </div>
                    <div class="form-group">
                        <label for="pwd">Message:</label>
                        <textarea name="massage"  id="massage" name="massage" data-rule-required="true" value="" class="form-control" id="pwd"></textarea>
                    </div>
                    <label class="lbl_class g-recaptcha" id="recaptcha" data-sitekey="<?php echo CAPTCHA_SITE_KEY ?>" ></label>
                    <span id="captcha_error"></span>
                    <button type="submit" id="submit_friend" class="btn btn-default">Send to a friend</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div id="error_model" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close close_error" data-dismiss="modal">&times;</button>
                <p id="error_text">Some text in the modal.</p>
            </div>
        </div>
    </div>
</div>



<script type="text/javascript">
    var slider_parameter = {
        autoPlay: false,
        navigation: true,
        items: 6,
        loop: false,
        itemsMobile: [479, 2],
        itemsTablet: [768, 3],
        itemsDesktop: [1199, 5],
        itemsDesktopSmall: [980, 4],
        rewindNav: false,
        navClass: ["nex", "pr"],
        lazyLoad: true,
        // paginationNumbers: false,
        navigationText: ["<img src='" + base_url + "assets/images/left-arrow.png'>", "<img src='" + base_url + "assets/images/right-arrow.png'>"]
    };

    $("#bxslider_1").owlCarousel(slider_parameter);
    $("#bxslider_2").owlCarousel(slider_parameter);
    $("#bxslider_3").owlCarousel(slider_parameter); //


    $('#header_dy').addClass('add-bg_color');

    $(function () {
        $("#datepicker").datepicker({
            format: "dd-mm-yyyy",
            todayHighlight: 'TRUE',
            autoclose: true,
            startDate: 'today',
            numberOfMonths: 2,
            maxDate: '+1M'
        });

        $(window).resize(function () {
            var divw = $(this).width();
            SwipeVenueContents(divw);
        });
        var divw = $(this).width();
        SwipeVenueContents(divw);


        $("#review-write").click(function () {
            var fnc = $(this).data('fnc');
            $.ajax({
                url: '<?php echo site_url('web/check_review'); ?>',
                method: 'POST',
                data: {fnc: fnc},
                dataType: 'json',
                success: function (result) {
                    if (result.status) {
                        window.location.href = result.href;
                    } else {
                        $('#error_text').html(result.msg);
                        $('#error_model').modal('show');
                    }
                }
            });
        });

    });


    var map = '';
    function initialize() {
         var latlng = new google.maps.LatLng(<?php echo !empty($venue_data->fc_lat)? $venue_data->fc_lat: -37.8136  ?>, <?php echo !empty($venue_data->fc_lng)? $venue_data->fc_lng: 144.9631 ?>);
        var map = new google.maps.Map(document.getElementById('map'), {
            center: latlng,
            zoom: 12
        });

        var marker = new google.maps.Marker({
            map: map,
            position: latlng,
            draggable: false,
            anchorPoint: new google.maps.Point(0, -29),
            icon: base_url + 'assets/images/map_icon.svg'
        });

        var infowindow = new google.maps.InfoWindow();
        google.maps.event.addListener(marker, 'click', function () {
            var iwContent = '';
            // including content to the infowindow
            infowindow.setContent(iwContent);

            infowindow.open(map, marker);
        });
    }
    google.maps.event.addDomListener(window, 'load', initialize);

    $("#add_wish_list").click(function (e) {
        e.preventDefault();
        var venue_id = $('#venue_id').val();

        $.ajax({
            type: "POST",
            url: base_url + 'web/add_to_wishlist',
            data: {v_id: venue_id},
            success: function (response)
            {
                if (response == 'need_login') {
                    $('.alert').remove();
                    $.notify("You need to login first, Please <a class='show_hover' href='<?php echo base_url('user_login'); ?>'>Login Here</a>", {type: "danger"});
                }

                if (response == 'success') {
                    $('.alert').remove();
                    $('#span-wishlist').html('Favorites added');
                    $('.change_0').attr('src', base_url + 'assets/images/icon_19.png');
                    $.notify("Added to Favorites", {type: "success"});
                }
                if (response == 'already') {
                    $('.alert').remove();
                    $('#span-wishlist').html('Add to Favorites');
                    $('.change_0').attr('src', base_url + 'assets/images/Add-to-wish-list.png');
                    $.notify("Removed from Favorites", {type: "info"});
                }
            },
            async: false
        });
    });

    $("#query_submit").click(function (e) {
        e.preventDefault();
        if ($("#enq_form").valid()) {
            var form_Element = document.getElementById("enq_form");
            var query_Data = new FormData(form_Element);
            var id = $('#venue_id').val();

            $.ajax({
                type: "POST",
                url: base_url + 'web/query_form_submit',
                data: query_Data,
                contentType: false,
                cache: false,
                processData: false,
                success: function (response)
                {
                    if (response == 'need_login') {
                        $.notify("You need to login first, Please <a class='show_hover' href='<?php echo base_url('user_login'); ?>'>Login Here</a>", {type: "danger"});
                    }

                    if (response == 'success') {
                        $("#enq_form")[0].reset();
                        // $.notify("your query submit successfully", {type: "success"});
                        window.location.replace(base_url + "/user/submit_query_thank_you/" + id);
                    }
                },
                async: false
            });
        }
        ;
    });

    $(document).ready(function () {
        $("#send_to_friend").click(function (e) {
            e.preventDefault();
            $("#captcha_error").html('');
            var venue_id = $('#venue_id').val();
            var validator = $("#send_frnd").validate();
            validator.resetForm();
            $("#send_frnd")[0].reset()
            $('#send_to_model').modal('show');
            $('#venue_id_friend').val(venue_id);
            var massage = 'Hello, I think this page is interesting';
            $('#massage').val(massage);
        });

        $("#submit_friend").click(function (e) {
            $("#captcha_error").html('');
            e.preventDefault();
            if ($("#send_frnd").valid()) {
                add_loader();
                var form_Element = document.getElementById("send_frnd");
                var query_Data = new FormData(form_Element);

                var $captcha = $('#recaptcha'),
                        response = grecaptcha.getResponse();
                var is_submit = 0;

                if (response.length === 0)
                {
                    is_submit = 0;
                    $("#captcha_error").html('Please check Captcha')
                } else
                {
                    is_submit = 1;
                }

                if (is_submit == 1)
                {
                    $.ajax({
                        type: "POST",
                        url: base_url + 'web/send_to_friend',
                        data: query_Data,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (response)
                        {
                            if (response == 'need_login') {
                                $('.alert').remove();
                                $.notify("You need to login first, Please <a class='show_hover' href='<?php echo base_url('user_login'); ?>'>Login Here</a>", {type: "danger"});
                            }

                            if (response == 'success') {
                                $("#send_to_model .close").click();
                                $("#enq_form")[0].reset();
                                $.notify("Send successfully", {type: "success"});
                            } else {
                                $("#send_to_model .close").click();
                            }
                            remove_loader();
                        },
                        async: false
                    });
                }
            }
            ;
        });



        $(".venue_space").click(function (e) {
            e.preventDefault();
            var space_id = $(this).attr('data-value');
            title = $(this).text();
            title = title + " - Space";
            add_loader();

            $.ajax({
                type: "POST",
                url: base_url + 'web/single_space',
                data: {space_id: space_id},
                success: function (response) {
                    var data = JSON.parse(response) //
                    if (data) {
                        $('#header_dy').removeClass('add-bg_color');

                        $('.space_change_div').addClass('review_div');
                        $('.space_change_bnner').addClass('adver_sml_bnner');
                        $('.space_change').addClass('back_101_1');
                        $('.space_change_modal').addClass('modal_set_105');
                        $('#venue-add').addClass('hide_review_mobile');

                        $('.venue-name-new').css('display', 'block');
                        $('#bottom_space_button').css('display', 'block');


                        $("#friend_request_area").addClass('hide_review_mobile');

                        $('#fc_overview').css('display', 'none');
                        $('#space_overview').css('display', 'block');

                        $('.fnc_slider').css('display', 'none');
                        $('.space_slider').css('display', 'block');
                        if (data.space_image == '' || data.space_image == null) {
                            $('#space_banner').attr('src', base_url + 'assets/images/FnC_banner.jpg');
                        } else {
                            $('#space_banner').attr('src', base_url + 'uploads/venue_spaces/' + data.space_image);
                        }
                        $('.close_icons_1').css('display', 'block');
                        $('.space_change_modal').addClass('modal_set_105');

                        $('.banner_img').attr('src', base_url + 'uploads/fc_images/' + data.space_image);//
                        $('.for_fc').css('display', 'none');
                        $('.for_space').css('display', 'block');

                        $('#perfect_for').css('display', 'none');
                        $('#perfect_for_space').css('display', 'block');
                        $('#perfect_for_space').html('Perfect for ' + data.space_min_guest + '-' + data.space_max_guest + ' guests');
                        $('#space_overview').html(data.space_details);


                        $('#space_event').html('');
                        if (data.space_events) {
                            var event_data = '';
                            $.each(data.space_events, function (index, value) {   //
                                $('#space_event').append('<li><img class="size-new_1" src="' + base_url + 'uploads/fnc_types/' + value.image + '"><span class="bottom_content_text">' + value.name + '</span></li>');
                            });

                            $("#space_event_div").show();
                            $("#space_event").owlCarousel(slider_parameter);
                            $("#space_event").data('owlCarousel').reinit();
                        } else {
                            $("#space_event_div").hide();
                            //$("#space_event").data('owlCarousel').reinit();
                        }

                        $('#space_facilities').html('');
                        if (data.space_facilities) {
                            var facilities_data = '';
                            $.each(data.space_facilities, function (index, value) {
                                $('#space_facilities').append('<li><img class="size-new_1" src="' + base_url + 'uploads/fnc_types/' + value.image + '"><span class="bottom_content_text">' + value.name + '</span></li>');
                            });

                            $("#space_facilities_div").show();
                            $("#space_facilities").owlCarousel(slider_parameter);
                            $("#space_facilities").data('owlCarousel').reinit();
                        } else {
                            $("#space_facilities_div").hide();
                            //$("#space_facilities").data('owlCarousel').reinit();
                        }

                        $('#space_features').html('');
                        if (data.space_features) {
                            var features_data = '';
                            $.each(data.space_features, function (index, value) {
                                $('#space_features').append('<li><img class="size-new_1" src="' + base_url + 'uploads/fnc_types/' + value.image + '"><span class="bottom_content_text">' + value.name + '</span></li>');
                            });

                            $("#space_features").owlCarousel(slider_parameter);
                            $("#space_features").data('owlCarousel').reinit();
                            $("#space_features_div").show();
                        } else {
                            $("#space_features_div").hide();
                            //$("#space_features").data('owlCarousel').reinit();
                        }
                        $(".active_space").removeClass('active_space');
                        $("a[data-value=" + space_id + "]").addClass('active_space');
                    }
                    $.unblockUI();
                    $('#space_type_title').text(title);
                    $('#venue-add').hide();

                }
            });
        });

        $(".close_icons_1").click(function (e) {
            e.preventDefault();
            $('#header_dy').addClass('add-bg_color');
            $('.space_change_div').removeClass('review_div');
            $('.space_change_bnner').removeClass('adver_sml_bnner');
            $('.space_change').removeClass('back_101_1');
            $('.space_change_modal').removeClass('modal_set_105');
            $('.fnc_slider').css('display', 'block');
            $('.space_slider').css('display', 'none');
            $('.close_icons_1').css('display', 'none');
            $('.for_fc').css('display', 'block');
            $('.for_space').css('display', 'none');
            $('#fc_overview').css('display', 'block');
            $('#space_overview').css('display', 'none');
            $("#friend_request_area").show();
            $('#perfect_for').css('display', 'block');
            $('#perfect_for_space').css('display', 'none');
            $('.space_change_modal').removeClass('modal_set_105');
            $('#space_type_title').text("");
            $('#venue-add').show();
            $('#bottom_space_button').hide();
            $(".active_space").removeClass('active_space');
        });
    });
    $(document).ready(function () {
        $(document).on('click', '.show_more', function () {
            var venue_id = $('#r_venue_id').val();
            var ID = $(this).attr('id');
            $('.show_more').hide();
            $('.loding').show();
            $.ajax({
                type: 'POST',
                url: base_url + 'web/load_review',
                data: {id: ID, is_load: 1, venue_id: venue_id},
                success: function (html) {
                    $('#show_more_main' + ID).remove();
                    $('.tutorial_list').append(html);
                }
            });
        });
    });



    // Swipe div venue request
    function SwipeVenueContents(nwidth) {
        if (nwidth > 767) {

            var freindReq = $('#friend_request_area').detach();
            $(freindReq).appendTo('#venue_request_form');

            var reviews = $('#reviews').detach();
            $(reviews).insertAfter('#catering_details');

        } else {

            var freindReq = $('#friend_request_area').detach();
            $(freindReq).appendTo('#friend_request_area_mobile');

            var reviews = $('#reviews').detach();
            $(reviews).insertBefore('#catering_details');

        }
    }


</script>


