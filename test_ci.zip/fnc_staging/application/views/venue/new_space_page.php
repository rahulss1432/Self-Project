<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/owl.carousel.min.css" />
<script src="<?php echo base_url(); ?>assets/js/owl-slider.js" ></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>


<section class="single_venues_section space_change details_section2">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 vanue-name-head">
                    <span id="venue-name" class="venue-name-new">STONES OF THE YARRA VALLEY</span>
                    <span id="venue-add" class="venue-address">14 ST HUBERTS ROAD, COLDSTREAM, Vic, Australia</span>
                </div>
                <div class="col-sm-4 category-type">
                    <span class="function_text space_change_div">Venue</span>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <ul class="nav nav-pills set_root_nav_pills">
                                                        <li><a class="venue_space active" data-value="8" href="javascript:;">The Day Room</a></li> <!-- $space->space_id -->
                                                                <li><a class="venue_space" data-value="9" href="javascript:;">The Barn</a></li> <!-- $space->space_id -->
                                                                <li><a class="venue_space" data-value="10" href="javascript:;">The Stables</a></li> <!-- $space->space_id -->
                                <div class="close_icons_1 close_sec" style="display:none"><img src="http://localhost/fnc/assets/images/close_arrow.png"></div>                    </ul>
                </div>
            </div>
        </div>
</section>
	
	
<div class="set_dotted col-md-12 margin-top_slider details_section2">
        <div class="row">
			<ul id="bxslider_4">
				<li> <img src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg" class="img-responsive">
				<li> <img src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg" class="img-responsive">
				<li> <img src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg" class="img-responsive">
				<li> <img src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg" class="img-responsive">
				<li> <img src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg" class="img-responsive">
					
				</li>
			</ul>
		</div>
	</div>
	
	<section class="space_change details_section2">
        <div class="container detail-single-venue">
            <div class="row">
                <div class="col-lg-8 col-sm-8">
                    <div class="space_change_modal for_venue_extra_details"> <!-- blur class  space_change -->
                        <div class="row">
                            <div class="col-lg-6 col-sm-4 col-xs-5 single-venue-overview">
                                <span>Overview.</span>
                            </div>
                            <div class="col-lg-6  col-sm-8 col-xs-7 single-venue-overview text-right">
                                <span id="perfect_for"> Perfect for 10-40 guests</span>
                                <span id="perfect_for_space" style="display: none"></span>
                            </div>

                            <div class="col-lg-12 details" id="fc_overview">
                                The Oratory is perhaps th Convent's most spectaculat spae. Featuring stained-glass windows and distressed walls, the Oratory is perfect for a variety of performances, rehearsals and installations. Other features: dimmer lighting on single track around ceiling and a central raised area stage.                           </div>
                            <div class="col-lg-12 details" id="space_overview" style="display: none;">
                            </div>
                        </div>

                                                    <div class="for_fc">
                                <div class="row">
                                    <div class="col-sm-12 single-venue-great-for">
                                        <span class="heading">Great For.</span>
                                    </div>
                                </div>
                                <div class="row">
								
								    <ul id="bxslider_1" class=" text-center">
                                        
                                            <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li><li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
                                            
                                    </ul>
                                    
                                </div>
                            </div>
                        
                        <div class="for_space" id="space_event_div" style="display:none">
                            <div class="row for_space">
                                <div class="col-sm-12 single-venue-great-for">
                                    <span class="heading">Great For.</span>
                                </div>
                            </div>
                            <div class="row">
                                <ul id="space_event" class=" new_slider_final text-center elastislide-list"></ul>
                            </div>
                        </div>

                                                    <div class="for_fc">
                                <div class="row ">
                                    <div class="col-sm-12 single-venue-venue-has">
                                        <span class="heading">The Venue Has.</span>
                                    </div>
                                </div>
                                <div class="row">
								
								 <ul id="bxslider_2" class=" text-center">
                                       
                                            <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
											
											<li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
										   <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
										   <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
										   <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
                                           
                                    </ul>
								
                                  
                                </div>
                            </div>
                        
                        <div class="for_space" id="space_facilities_div" style="display:none">
                            <div class="row ">
                                <div class="col-sm-12 single-venue-venue-has">
                                    <span class="heading">The Venue Has.</span>
                                </div>
                            </div>
                            <div class="row">
                                <ul id="space_facilities" class=" new_slider_final text-center elastislide-list"></ul>
                            </div>
                        </div>

                                                    <div class="for_fc">
                                <div class="row">
                                    <div class="col-sm-12 single-venue-venue-has">
                                        <span class="heading">The Venue Features.</span>
                                    </div>
                                </div>
                                <div class="row">
                                   <ul id="bxslider_3" class=" text-center">
                                       
                                            <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
                                           <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
										   <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
										   <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
										   <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
										   <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
										   <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
										   <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
										   <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
										   <li> <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/FnC_banner.jpg"></li>
                                    </ul>
                                </div>
                            </div>
                                                
                        <div class="for_space" id="space_features_div" style="display:none">
                            <div class="row">
                                <div class="col-sm-12 single-venue-venue-has">
                                    <span class="heading">The Venue Features.</span>
                                </div>
                            </div>
                            <div class="row">
                                <ul id="space_features" class=" new_slider_final text-center elastislide-list"></ul>
                            </div>
                        </div>
                        <div class="close_icons_1" style="display:none"><img src="http://localhost/fnc/assets/images/close_arrow.png"></div>
                    </div>



                    <div class="maring_bottom_set_content details_section1">
                        <div class="review_head">The detail.</div>
                        <div class="heading_main_title">
                            <!--<spna>Space.</spna>-->
                            <p>Rising from the rustic, weather-beaten remnants of a barn left idle for generations,
Stones of the Yarra Valley has emerged as the region’s premiere food and wine destination.

With uninterrupted views across vines to the blue-tinged Great Divide, Stones of the Yarra Valley is located on one of the most picturesque and historic properties in the Yarra Valley, combining two superb restaurants – The Barn and The Stables at Stones –
with a stunning rough-rendered Chapel and Dairy nestled under century-old oak trees.</p>
                        </div>
                    </div>

                    
					
					
					
					
					

                </div><!--col-lg-8 col-sm-8-->
				
			
				
				

                <div class="col-lg-4 col-sm-4">
                    <div class="space_change_modal"> <!-- blur class  space_change -->
					<p class="heading venue_request">Venue Requet: </p>
                        <div class="contact-detail-venue">
                            <div class="contact-page-form">
                                <form id="enq_form" name="edit_post">
                                    <input name="fq_fc_id" id="venue_id" value="TWVWZ29PR3RNZ2hEVVVSQ1dZZEs3QT09" type="hidden">
                                    <div class="contact-form-field">
                                        <span class="date">Preferred Function Date</span>
                                        <input class="enquirydate" data-rule-required="true" name="fq_function_date" id="datepicker" placeholder="DD-MM-YYYY" type="text">
                                    </div>
                                    <div class="contact-form-field">
                                        <span>Proposed Number Of Guests</span>
                                        <input id="enq_guest" data-rule-required="true" name="fq_guest_no" class="enquiryguest" placeholder="Up to 30" type="number">
                                    </div>

                                    <div class="contact-form-field">
                                        <span>Type Of Event</span>
                                        <input class="questionhere1" data-rule-required="true" name="fq_event_type" placeholder="Wedding, birthday, corporate launch etc." type="text">
                                    </div>
                                    <div class="contact-form-field">
                                        <span>Other Queries</span>
                                        <input class="questionhere2" data-rule-required="true" name="fq_other_queries" placeholder="Queries, special requests/requirements[etc]..." type="text">
                                    </div>
                                    <div class="contact-form-field">
                                        <input class="submit_button" id="query_submit" value="Submit" type="submit">
                                    </div>
                                </form>

                                <!-- fav btn strt-->
                            </div>

                            <a href="http://localhost/fnc/venue/add_to_wishlist" id="add_wish_list" class="details_section1">
                                <div class="contact-detail-venue-wish">
                                                                        <span id="span-wishlist">Add to Favorites</span>
                                    <img class="like_103 change_0" usemap="#planetmap_0" src="http://localhost/fnc/assets/images/Add-to-wish-list.png">                                    <span></span>
                                </div>
                            </a>

                            <a href="" class="details_section1">
                                <div id="send_to_friend" class="contact-detail-venue-wish c-d-v-w_104">
                                    <span id="span-wishlist">Send to a friend</span>
                                    <img class="img-responsive" id="img-msg" src="http://localhost/fnc/assets/images/6.Send-to-friend(1).svg">
                                </div>
                            </a>
                        </div><!-- contact-detail-venue -->
                    </div>
					<div class="clearfix"></div>
					
					<section class="single_venues_section space_change single_venues_section_second">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 vanue-name-head">
                    <span id="venue-name" class="venue-name-new">Other Spaces Available:</span>
                </div>
                
            </div>
            <div class="row">
                <div class="col-md-12">
                    <ul class="nav nav-pills set_root_nav_pills">
                                                        <li><a class="venue_space" data-value="8" href="javascript:;">The Day Room</a></li> <!-- $space->space_id -->
                                                                <li><a class="venue_space" data-value="9" href="javascript:;">The Barn</a></li> <!-- $space->space_id -->
                                                                <li><a class="venue_space" data-value="10" href="javascript:;">The Stables</a></li> <!-- $space->space_id -->
                                <div class="close_icons_1 close_sec" style="display:none"><img src="http://localhost/fnc/assets/images/close_arrow.png"></div>                    </ul>
                </div>
            </div>
			<div class="call-us-now"><a href="">Back to Main Listing</a></div>
        </div>
</section>


					
	
	
	
                    <div class="clearfix details_section2"></div>
					

					
					<hr class="border-line details_section2">

                    <div class="adver space_change_bnner details_section2" style="display: none;">
                        <img src="http://localhost/fnc/assets/images/img_advet_singalvenus.jpg" class="img-responsive adver_img">
                        <div class="positon_set_1" style="display:none">
                            <img class="img-responsive logo_adver" src="http://localhost/fnc/assets/images/Functions_LogoFandC_w.png">
                            <h1>Register your <spna>business for <b>FREE</b></spna> Limited time only</h1>
                            <a class="register_now_title">Register now</a>
                        </div>

                        <div class="clearfix"></div>



                    </div><!-- col-lg-4 col-sm-4 -->
                </div><!--row-->
            </div><!--container-->
    </div></section>

	
<script type="text/javascript">
    var slider_parameter = {
        autoPlay: false,
        navigation: true,
        items: 6,
        loop: false,
        itemsMobile: [479, 3],
        itemsTablet: [768, 3],
        itemsDesktop: [1199, 5],
        itemsDesktopSmall: [980, 4],
        rewindNav: false,
        navClass: ["nex", "pr"],
        lazyLoad: true,
        navigationText: ["<img src='" + base_url + "assets/images/left-arrow.png'>", "<img src='" + base_url + "assets/images/right-arrow.png'>"]
    };
	
	 var slider_parameter1 = {
        autoPlay: false,
        navigation: true,
        items: 6,
        loop: false,
        itemsMobile: [479, 1],
        itemsTablet: [768, 1],
        itemsDesktop: [1199, 1],
        itemsDesktopSmall: [980, 4],
        rewindNav: false,
        navClass: ["nex", "pr"],
        lazyLoad: true,
        navigationText: ["<img src='" + base_url + "assets/images/left-arrow.png'>", "<img src='" + base_url + "assets/images/right-arrow.png'>"]
    };

    $("#bxslider_1").owlCarousel(slider_parameter);
    $("#bxslider_2").owlCarousel(slider_parameter);
	$("#bxslider_4").owlCarousel(slider_parameter1);
    $("#bxslider_3").owlCarousel(slider_parameter); //



    $('#header_dy').addClass('add-bg_color');

   
   

  
</script>
