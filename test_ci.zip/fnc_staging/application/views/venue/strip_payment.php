<div class="row">
    <div class="col-md-8 pull-left">

        <div class="form-group owner">
            <label class="card_number_label">Card Number</label>
            <input type="text" id="cardnumber" class="form-control-1 car_input_number card-number addr-field">
            <label style="display: none;" id="cardnumber-error" class="custom-error"></label>
        </div>

        <div class="cart_icon_set">
            <ul>
                <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_card_visa-128.png" class="img-responsive"></li>
                <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_discover_network_card-128.png" class="img-responsive"></li>
                <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_master_card-128.png" class="img-responsive"></li>
                <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_google_wallet-128.png" class="img-responsive"></li>
            </ul>
        </div>

        <div class="row">
            <div class="col-md-8 padding-right_106">
                <div class="form-group CVV" id="expiration-date">
                    <label class="card_number_label">Expires Date</label>
                    <select name="select2" id="cardexpiry" class="select_month card-expiry-month" data-stripe="exp-month">
                        <option value="01" selected="">January</option>
                        <option value="02">February </option>
                        <option value="03">March</option>
                        <option value="04">April</option>
                        <option value="05">May</option>
                        <option value="06">June</option>
                        <option value="07">July</option>
                        <option value="08">August</option>
                        <option value="09">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>
                    </select>
                    <select name="select2" id="cardexpiry" class="select_month card-expiry-year" data-stripe="exp-year"></select>
                    <script type="text/javascript">
                        var select = $(".card-expiry-year"),
                                year = new Date().getFullYear();

                        for (var i = 0; i < 12; i++) {
                            select.append($("<option value='" + (i + year) + "' " + (i === 0 ? "selected" : "") + ">" + (i + year) + "</option>"))
                        }
                    </script>
                </div>
                <label style="display: none;" id="cardexpiry-error" class="custom-error"></label>
            </div>
            <div class="col-md-4">
                <label class="card_number_label">Security Code</label>
                <input type="text" id="cvv" class="form-control-1 car_input_number card-cvc addr-field" placeholder="CVV">
                <label style="display: none;" id="cvv-error" class="custom-error"></label>
            </div>

            <div class="form-group owner col-md-12">
                <label class="card_number_label">Name</label>
                <input type="text" name="cardholdername" id="cardholdername" class="form-control-1 car_input_number card-holder-name addr-field">
                <label style="display: none;" id="cardholdername-error" class="custom-error"></label>
            </div>

            <div class="form-group owner col-md-6">
                <label class="card_number_label">Choose plan</label>
                <select type="text" id="subscription_plan" value="0" class="form-control-1 car_input_number">
                    <option value="month">Monthly</option>
                    <option value="year">Yearly</option>
                </select>
                <input type="hidden" id="amt_total" value="0">
            </div>

            <div class="col-md-12">
                <div class="right_aling_card_root_101">
                    <label class="regular-checkbox ">
                        <input class="checkbox_set" type="checkbox" name="agree" value="1" data-rule-required="true">
                        <small></small>
                    </label>
                    <span>I agree with the <a href="<?php echo base_url() ?>/term_condition" target="_blank">Terms & Conditions.</a></span>
                </div>
            </div>

        </div>
    </div>
    <div class="col-md-4"></div>
</div>