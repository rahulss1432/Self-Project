<link rel="stylesheet" href="<?php echo base_url('assets/plugins/autocomplete/jquery-ui.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/css/new-style.css'); ?>">

<!--<script src="<?php echo base_url('assets/js/custom/crope_images_with_save.js'); ?>"></script>-->
<script src="<?php echo base_url('assets/js/custom/character_counter.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.ezdz.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/crope_images.js'); ?>"></script>


<?php
//echo "<pre>";print_r($space_id);
$spaceid = encrypt_decrypt('decrypt', $this->uri->segment(3));
?>
<section class="function_vene_page" id="add_venue_header">
    <div class="container">
        <div class="row ">


            <?php //$this->load->view('venue/venue_header');  ?>

            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>
            <!-- Loading Side Menu -->
            <?php $this->load->view('side_menu'); ?>

            <?php $this->load->view('models/image_cropping'); ?>
            <?php $this->load->view('models/error_show'); ?>


            <div class="col-md-9 col-sm-8">

                <div class="row">

                    <div class="col-sm-12">

                        <div class="sub_hdngs">
                            <h3 class="clr_cmn"><span>1/5</span> Spaces</h3>
                            <span class="sv_span">last saved:<span class="clr_cmn">Just Now</span><button class="btn cmn_btn1 save_btn2">Save</button></span>

                            <div class="clearfix"></div>
                        </div>

                        <div class="progress prog2">
                            <div class="progress-bar" role="progressbar" aria-valuenow="70"
                                 aria-valuemin="0" aria-valuemax="100" style="width:15%">
                            </div>
                        </div> <!-- progress prog2 ends -->    


                    </div>

                </div><!-- row ends -->


                <div class="row">

                    <div class="col-sm-12">

                        <div class="space_ins">

                            <div class="row" >

                                <div class="col-sm-12">
                                    <div class="fmHeading2">

                                        <a href=""><i class="fa fa-shopping-cart cart_ic"></i></a>
                                    </div> 
                                </div>

                                <div class="col-md-6 col-sm-12">

                                    <h3 class="clr_cmn fr_hdngSpc">Do you have any other spaces at this venue you would like to list?

                                        <i class="tooltip_i">
                                            <span class="tltp_span">
                                                <img src="http://functionsandcatering.com/staging/function/assets/images/sys_info.svg" class="tltp_ic">
                                            </span>
                                            <!-- <i class="spc_i">i</i> -->
                                            <div class="cstmTooltip left spc_tltp">
                                                <span class="skip_tltpClose">X</span>
                                                <p>Does your venue have multiple function areas with different guest capacity? You can list another space within a venue for $30c a day</p>
                                            </div>
                                        </i>

                                    </h3>

                                    <div class="row">
                                        <div class="col-sm-4 col-xs-6">
                                          <!--<input type="radio" id="test1" name="radio-group" class="my_radio" checked>
                                          <label for="test1" class="clr_cmn sm_radie">Yes</label>-->
                                        </div>
                                        <div class="col-sm-4 col-xs-6">
                                          <!--<input type="radio" id="test2" name="radio-group" class="my_radio" >
                                          <label for="test2" class="clr_cmn sm_radie">No</label>-->
                                        </div>
                                    </div> 


                                    <h5 class="yesNote">Each Additional area is charged at<br/> a rate of 30c per day</h5>


                                </div><!-- col-sm-6 ends -->


                                <div class="col-md-6 col-sm-12">


                                </div><!-- col-md-6 ends -->


                                <div class="col-md-6 col-sm-12">

                                    <div class="Ven_spc_bx">

                                        <h5><b>Venues and Spaces</b></h5>
                                        <p>With F&C you have the option to set up ‘spaces’ within venues. For example if you have a property with several unique areas for hire within the same address.<br/>

                                            Spaces can be found by clicking into the parent venueon the venues page.
                                        </p>


                                    </div><!-- Ven_spc_bx ends -->

                                </div><!-- col-md-6 ends -->


                            </div><!-- row ends -->


                            <div class="row mrTp40">

                                <!--<div class="col-sm-6 col-xs-5" id= "back_btn_spaces">
                                    <a href="JavaScript:void(0);"><span class="clr_cmn bckie2"><i class="fa fa-angle-left"></i> Back</span></a>
                                </div>-->
                                <div class="col-sm-6 col-xs-7">
                                    <!-- <button class="btn cmn_btn1 frm_bt2" id="btn_spaces">Spaces</button> -->

                                    <a href="JavaScript:void(0);" class="btn cmn_btn1 frm_bt2" id="btn_spaces" >Add Space</a>

                                    <a href="JavaScript:void(0);" class="btn cmn_btn1 frm_bt2" id="btn_checkout" >Cancel</a>

                                    <!-- <button class="btn cmn_btn1 frm_bt2" id="btn_checkout">Checkout</button> -->
                                </div>

                            </div>


                        </div>

                    </div><!-- col-sm-12 ends -->

                </div><!-- row ends -->

                <div class="single_space_form">
                    <div class="col-md-12 col-sm-12" id="append2divspace">

                        <div class="div2clone">
                            <form id="space_form" >

                                <div class="space_details-section space_details" style="display: block;">
                                    <div class="col-md-8 col-sm-12 profile_row fountion_7 ">
                                        <input type="hidden" name="space_id" value="<?php echo $spaceid; ?>">
                                        <div class="row margin_top_and_bottom_user">
                                            <div class="col-md-12 margin_set_input text-left">
                                                <label class="lbl_class">Space name</label>
                                                <input type="text" class="form-control fm-field" name="space_name" data-rule-required="true">
                                            </div>
                                            <div class="margin_set_input text-left">
                                                <div class="col-md-6 margin_set_input ">
                                                    <label class="lbl_class">Minimum guest numbers</label>
                                                    <input id="min_guest_<?php echo!empty($num) ? $num : ''; ?>" type="text" class="form-control fm-field error_down" name="space_min_guest" data-rule-required="true" data-rule-lessThan="#max_guest_<?php echo!empty($num) ? $num : ''; ?>" data-rule-number="true">
                                                </div>
                                                <div class="col-md-6 margin_set_input">
                                                    <label class="lbl_class">Maximum guest numbers</label>
                                                    <input id="max_guest_<?php echo!empty($num) ? $num : ''; ?>" type="text" class="form-control fm-field error_down" name="space_max_guest" data-rule-required="true" data-rule-greaterThan="#min_guest_<?php echo!empty($num) ? $num : ''; ?>" data-rule-number="true">
                                                </div>
                                            </div>

                                            <div class="col-md-12 text-left ">
                                                <label class="text-left">Details</label>
                                                <div class="txtie">
                                                    <textarea class="descrp_box2 form-control overview_textarea textare_root venue_details_input" id="space_details" name="space_details" data-rule-required="true"  rows="4" data-rule-maxlength="1200" maxlength="1200" minlength="100"></textarea>
                                                    <p class="text-right clr_cmn remaining_counter_show" id="chars">1200 characters remaining</p>
                                                    <span class="inpicns">
                                                        <i class="fa fa-check ic-gr"></i>
                                                        <i class="fa fa-warning ic-rd" style="display: none"></i>
                                                    </span>
                                                    <label style="display: none;" class="custom-error"></label>
                                                </div>

                                            </div>



                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <div class="ulpading_img_size_3 listing_picture_thumb fl_wid">
                                                            <img id="show_image_<?php echo $img_id; ?>" class="dropzone" img-id="<?php echo $img_id; ?>" src="" style="display: none; opacity: 1;">

                                                            <div class="ezdz-dropzone"><div class="for_plus_sign">Drag Files Here</div>
                                                                <input onclick="this.value = null;" type="file" name="space_image" data-fc_img_id="" data-id="<?php echo $img_id; ?>" class="file-selector image_selector" id="image_selector_<?php echo $img_id; ?>" accept="image/*">
                                                            </div>

                                                            <input type="hidden" name="dimesion_image" id="dimesion_image_<?php echo $img_id; ?>" value="0">
                                                            <input type="hidden" name="fc_image" id="fc_image_<?php echo $img_id; ?>" value="">
                                                        </div>
                                                    </div><!-- col-sm-6 ends -->

                                                    <div class="col-sm-6">
                                                        <div class="Img_spec clr_cmn">
                                                            <h5>Image Specs</h5>
                                                            <h6>Image should be jpeg or png files</h6>
                                                            <div class="mn_imgBtGr">
                                                                <a href="javascript:void(0)" class="btn cmn_btn2 f_s2" onclick="removeImage(2, '0', 2, <?php echo $img_id; ?>)">Remove</a>
                                                                <label ant-id="<?php echo $img_id; ?>" class="upload-button_new btn cmn_btn1 f_s2" id="another_select_<?php echo $img_id; ?>">
                                                                    <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                                </label>
                                                            </div>

                                                        </div><!-- Img_spec ends -->
                                                    </div><!-- col-sm-6 ends -->
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                    <div class="clearfix"></div>

                                    <div class="row mrTp40">
                                        <div class="col-sm-6 col-xs-5">
                                            <a href="JavaScript:void(0);" class="clr_cmn bckie2 space_ins_show"><span class="clr_cmn"><i class="fa fa-angle-left"></i>Back</span></a>
                                        </div>
                                        <div class="col-sm-6 col-xs-7 txt_rg1">
                                            <a href="JavaScript:void(0);" class="btn cmn_btn1 frm_bt2 space_event_show" class="btn cmn_btn1 frm_bt2 ">Next</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="space_event-section space_event" style="display:none">

                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="fmHeading2">
                                                <h3 class="clr_cmn">Space <?php echo!empty($num_word) ? $num_word : 'One'; ?> - Event types</h3>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row main_row11">

                                        <div class="col-md-6">

                                            <div class="row ChkRow">
                                                <?php
                                                if (!empty($event_types)) {
                                                    foreach ($event_types as $e_type) {
                                                        ?>  <div class="col-sm-6 mlCh_cols ">
                                                            <p class="cstm_MlChkBx venue_details_input ">
                                                                <span>
                                                                    <img src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->image; ?>" class="img1Nm ">
                                                                    <img src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->white_image; ?>" class="img2Ch">

                                                                </span> 
                                                                <input type="checkbox" name="space_events[]" value="<?php echo $e_type->id; ?>"  aria-required="true" required  data-msg-required="Please select at least one space">

                                                                <label><?php echo $e_type->name; ?></label>
                                                            </p><!-- cstm_MlchkBx ends -->
                                                        </div><!-- col-sm-6 ends -->

                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </div> <!-- row endds -->

                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <label for="space_events[]" class="error CheckieError" style=""></label>
                                                </div>
                                            </div>

                                        </div>
                                        <!--col-md-6 ends-->

                                        <div class="col-md-6 col-sm-12">
                                            <h3 class="clr_cmn">Summary</h3>
                                            <ul class="VenPrntUl">
                                            </ul>
                                            <div class="clearfix"></div>
                                        </div><!-- col-sm-6 ends -->

                                    </div>






                                    <div class="row mrTp40">
                                        <div class="col-sm-6 col-xs-5">
                                            <a href="JavaScript:void(0);" class="clr_cmn bckie2 space_event_back"><span class="clr_cmn"><i class="fa fa-angle-left"></i> Back</span></a>
                                        </div>
                                        <div class="col-sm-6 col-xs-7">
                                            <a href="JavaScript:void(0);" class="btn cmn_btn1 frm_bt2 space_facilities_show">Next</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="space_facilities-section space_facilities" style="display:none">

                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="fmHeading2">
                                                <h3 class="clr_cmn">Space <?php echo!empty($num_word) ? $num_word : 'One'; ?> - Facilities</h3>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row main_row11">

                                        <div class="col-md-6">

                                            <div class="row ChkRow">
                                                <?php
                                                if (!empty($facilities)) {
                                                    foreach ($facilities as $f_val) {
                                                        ?> <div class="col-sm-6 mlCh_cols ">
                                                            <p class="cstm_MlChkBx venue_details_input ">
                                                                <span>
                                                                    <img src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->image; ?>" class="img1Nm ">
                                                                    <img src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->white_image; ?>" class="img2Ch">

                                                                </span> 
                                                                <input type="checkbox" name="space_facilities[]" value="<?php echo $f_val->id; ?>"  aria-required="true" required  data-msg-required="Please select at least one facility">

                                                                <label><?php echo $f_val->name; ?></label>
                                                            </p><!-- cstm_MlchkBx ends -->
                                                        </div><!-- col-sm-6 ends -->

                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </div> <!-- row endds -->

                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <label for="space_facilities[]" class="error CheckieError" style=""></label>
                                                </div>
                                            </div>

                                        </div>
                                        <!--col-md-6 ends-->

                                        <div class="col-md-6 col-sm-12">
                                            <h3 class="clr_cmn">Summary</h3>
                                            <ul class="VenPrntUl">
                                            </ul>
                                            <div class="clearfix"></div>
                                        </div><!-- col-sm-6 ends -->

                                    </div>






                                    <div class="row mrTp40">
                                        <div class="col-sm-6 col-xs-5">
                                            <a href="JavaScript:void(0);" class="clr_cmn bckie2 space_event_hide"><span class="clr_cmn"><i class="fa fa-angle-left"></i> Back</span></a>
                                        </div>
                                        <div class="col-sm-6 col-xs-7">
                                            <a href="JavaScript:void(0);" class="btn cmn_btn1 frm_bt2 space_features_show">Next</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="space_features-section space_features" style="display:none">


                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="fmHeading2">
                                                <h3 class="clr_cmn">Space <?php echo!empty($num_word) ? $num_word : 'One'; ?> - Features</h3>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row main_row11">

                                        <div class="col-md-6">

                                            <div class="row ChkRow">
                                                <?php
                                                if (!empty($features)) {
                                                    foreach ($features as $feat_val) {
                                                        ?> <div class="col-sm-6 mlCh_cols ">
                                                            <p class="cstm_MlChkBx venue_details_input ">
                                                                <span>
                                                                    <img src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->image; ?>" class="img1Nm ">
                                                                    <img src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->white_image; ?>" class="img2Ch">

                                                                </span> 
                                                                <input type="checkbox" name="space_features[]" value="<?php echo $feat_val->id; ?>"  aria-required="true" required  data-msg-required="Please select at least one facility">

                                                                <label><?php echo $feat_val->name; ?></label>
                                                            </p><!-- cstm_MlchkBx ends -->
                                                        </div><!-- col-sm-6 ends -->

                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </div> <!-- row endds -->

                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <label for="space_features[]" class="error CheckieError" style=""></label>
                                                </div>
                                            </div>

                                        </div>
                                        <!--col-md-6 ends-->

                                        <div class="col-md-6 col-sm-12">
                                            <h3 class="clr_cmn">Summary</h3>
                                            <ul class="VenPrntUl">
                                            </ul>
                                            <div class="clearfix"></div>
                                        </div><!-- col-sm-6 ends -->

                                    </div>





                                    <div class="row mrTp40">
                                        <div class="col-sm-6 col-xs-5">
                                            <a href="JavaScript:void(0);" class="clr_cmn bckie2 space_facilities_back"><span class="clr_cmn"><i class="fa fa-angle-left"></i> Back</span></a>
                                        </div>
                                        <div class="col-sm-6 col-xs-7">
                                            <a href="JavaScript:void(0);" venue_id="<?php echo $this->uri->segment(3); ?>" class="btn cmn_btn1 frm_bt2 space_finish">Finish</a>
                                        </div>
                                    </div>
                                </div>

                            </form>

                        </div>

                    </div>
                </div>

            </div><!-- col-md-9 col-sm-8 ends -->

        </div>
    </div>
</section>
<!-- Modal -->
<?php //$this->load->view('models/image_cropping');  ?>
<?php //$this->load->view('models/error_show'); ?>


<script type="text/javascript">


    $('#btn_checkout').hide();
    $('.yesNote').hide();
    $(".single_space_form").hide();
    $('.sm_radie').click(function () {

        $(this).siblings('input').prop('checked', true);
        if ($('#test2').is(':checked')) {
            $('.yesNote').show();
            $('#btn_spaces').hide();
            $('#btn_checkout').show();
        } else if ($('#test1').is(':checked')) {
            $('.yesNote').hide();
            $('#btn_spaces').show();
            $('#btn_checkout').hide();
        }

    });
    //next ascript
    $('#btn_spaces').click(function () {
        var validator = $("#space_form").validate({/* settings */});
        if ($("#space_form").valid()) {
            $(".progress-bar").css('width', '25%');
            $(".space_ins").hide();
            $(".single_space_form").show();
        }
    });

    $('.space_ins_show').click(function () {
        $(".progress-bar").css('width', '15%');
        $(".single_space_form").hide();
        $(".space_ins").show();
    });

    $('.space_event_show').click(function () {
        var validator = $("#space_form").validate({/* settings */});
        if ($("#space_form").valid()) {
            $(".progress-bar").css('width', '65%');
            $(".space_details").hide();
            $(".space_event").show();
        }
    });

    $('.space_facilities_show').click(function () {
        var validator = $("#space_form").validate({/* settings */});
        if ($("#space_form").valid()) {
            $(".progress-bar").css('width', '85%');
            $(".space_event").hide();
            $(".space_facilities").show();
        }
    });

    $('.space_features_show').click(function () {
        var validator = $("#space_form").validate({/* settings */});
        if ($("#space_form").valid()) {
            $(".progress-bar").css('width', '100%');
            $(".space_facilities").hide();
            $(".space_features").show();
        }
    });

    //back ascript

    $('.space_event_back').click(function () {
        $(".progress-bar").css('width', '45%');
        $(".space_details").show();
        $(".space_event").hide();
    });

    $('.space_event_hide').click(function () {
        $(".progress-bar").css('width', '45%');
        $(".space_facilities").hide();
        $(".space_event").show();
    });

    $('.space_facilities_back').click(function () {
        $(".progress-bar").css('width', '85%');
        $(".space_facilities").show();
        $(".space_features").hide();
    });


    $('.space_finish').click(function () {
        var validator = $("#space_form").validate({/* settings */});
        if ($("#space_form").valid()) {
            var venue_id = $(this).attr('venue_id');
            var venue_data = $("#space_form").serialize();
            var space_add_venue = '<?php echo site_url() ?>Venue/space_add_venue';
            $.ajax({
                url: space_add_venue,
                method: 'POST',
                dataType: 'json',
                data: $("#space_form").serialize(),
                success: function (data) {
                    if (data.status) {
                        //$('#remove_confirmation').modal('hide');
                        window.location.href = "<?php echo site_url('/my_venues/'); ?>";
                    }
                    setTimeout(function () {
                        window.location.href = "<?php echo site_url('/my_venues/'); ?>";
                    }, 1000);


                }
            });

            window.location.href = "<?php echo site_url('/my_venues/'); ?>";

        }
    });

    $(document).on('click', '.cstm_MlChkBx', function () {
        var CheckboxInput = $(this).find('input[type="checkbox"]');

        var imgie = $(this).find('.img1Nm').attr('src');
        if (!imgie) {
            imgie = '';
        }
        var labs = $(this).find('label').text();
        var labsSp = labs.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '');
        var myParent = $(this).parent().parent().parent().parent('.main_row11');

        if ($(CheckboxInput).is(':checked')) {
            CheckboxInput.prop('checked', false);
            $(this).removeClass('active');
            $('.' + labsSp).remove();
        } else {
            CheckboxInput.prop('checked', true);
            $(this).addClass('active');

            $(myParent).find(".VenPrntUl").append($("<li class='" + labsSp + "'>").html('<img src =' + imgie + '> ' + '' + '<label>' + labs + ' </label>'));
        }
    });


    $('.custom_chkie').click(function () {
        $('.custom_chkie').removeClass('active');
        $(this).children("input").prop("checked", true);
        if ($(this).children("input").is(":checked")) {
            $(this).addClass('active');
        }

    });


    var maxLength = 1200;
    $('#space_details').keyup(function () {
        var length = $(this).val().length;
        var length = maxLength - length;

        $('#chars').text(length + ' characters remaining');


    });

    $('#fc_details').characterCounter({
        max: 1200,
        textArea: true
    });
    // $('#space_details').characterCounter({
    //   max: 1318,
    // textArea: true
    //});
</script>

<script type="text/javascript">


    $('.tltp_span').click(function () {
        $(this).siblings('.cstmTooltip').show();
    });

    $('.skip_tltpClose').click(function () {
        $(this).parent('.cstmTooltip').hide();
    });

</script>