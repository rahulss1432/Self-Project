<link rel="stylesheet" href="<?php echo base_url('assets/css/new-style.css'); ?>">
<script src="<?php echo base_url('assets/js/jquery.ezdz.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/crope_images.js'); ?>"></script>
<section class="function_vene_page">
    <div class="container">
        <div class="row main_row">

            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>

            <!-- Loading Side Menu -->
            <?php $this->load->view('side_menu'); ?>

            <div class="col-md-9 col-sm-12">
                <form id="msform" method="post" action="" enctype="multipart/form-data">
                    <div class="col-sm-12  das-2">
                        <!-- <div class="row top_background"><h4>Space</h4></div> -->
                        <div class="sub_hdngs">
	                        <h3 class="clr_cmn">Spaces</h3>
	                        <div class="clearfix"></div>
	                    </div>

                        <div class="row">

                            <div class="col-md-12 margin_set_input">
                                <label class="lbl_class" for="space_name">Name</label>
                                <input type="text" class="form-control" id="space_name" name="space_name" value="<?php echo $space[0]->space_name; ?>" data-rule-required="true">
                            </div>

                            <div class="col-md-6 margin_set_input">
                                <label class="lbl_class" for="space_min_guest">Minimum guest numbers</label>
                                <input type="text" class="form-control" data-rule-lessThan="#space_max_guest" id="space_min_guest" name="space_min_guest" value="<?php echo $space[0]->space_min_guest; ?>" data-rule-required="true">
                            </div>
                            <div class="col-md-6 margin_set_input">
                                <label class="lbl_class" for="space_max_guest">Maximum guest numbers</label>
                                <input type="text" class="form-control" data-rule-greaterThan="#space_min_guest" id="space_max_guest" name="space_max_guest" value="<?php echo $space[0]->space_max_guest; ?>" data-rule-required="true">
                            </div>


                            <div class="col-md-12 text-left">
                                <label class="text-left" for="space_details">Details</label>
								<textarea rows="4" class="form-control overview_textarea textare_root fm-field space_details" 
								id="space_details" name="space_details" data-rule-required="true" maxlength="1200"><?php echo $space[0]->space_details; ?></textarea>
                                <p class="text-right clr_cmn remaining_counter_show" id="char3">1200 characters remaining</p>
                            </div>

                            <div class="col-md-12">
                                <div class="ulpading_img_size_3 spceImg1">
                                    <img id="show_image_6" img-id="6" style="display:<?php echo ($space[0]->space_image) ? 'block' : 'none' ?>" class="dropzone" src="<?php echo base_url('uploads/venue_spaces') . '/' . $space[0]->space_image; ?>">
                                    <input onclick="this.value = null;" type="file" data-id="6" id="image_selector_6" class="file-selector fm-field image_selector" name="space_image">
                                    <input type="hidden" name="dimesion_image_6" id="dimesion_image_6" value="0">
                                    <img onclick="removeImage(3, '<?php echo encrypt_decrypt('encrypt', $space[0]->space_id); ?>', 1, 6)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                </div>

                                <div class="ulpading_img_size_3_1 right_partES">
                                    <div class="">
                                        <span id="fileselector">
                                            <label ant-id="6" class="upload-button_new after_102 uploadsImg14">

                                                <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                            </label>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12  fountion_5">
                        <!-- <div class="row top_background text-left">
                            <h4>Event types</h4>
                        </div> -->

                        <div class="sub_hdngs">
	                        <h3 class="clr_cmn">Event types</h3>
	                        <div class="clearfix"></div>
	                    </div>
                        			
						<div class="row main_row11">

							<div class="col-md-6">
								
								<div class="row ChkRow">
										<?php
									$event_arr = array();
									
									if (!empty($space)) {
										if (!empty($space[0]->space_events)) {
											$event_arr = explode(',', $space[0]->space_events);
										}
									}
	
									if (!empty($event_types)) {
										foreach ($event_types as $e_type) {
												$act_class = '';
                                                $checked_event = '';
                                                if (in_array($e_type->id, $event_arr)) {
                                                   $checked_event = 'checked';
												   $act_class = 'active';
                                                }
                                                //print_r($checked_event);
											?>  <div class="col-sm-6 mlCh_cols ">
													<p class="cstm_MlChkBx venue_details_input <?php echo $act_class; ?>">
														<span>
															<img src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->image; ?>" class="img1Nm ">
															<img src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->white_image; ?>" class="img2Ch">

														</span> 
														<input type="checkbox" name="space_events[]" value="<?php echo $e_type->id; ?>" <?php echo $checked_event; ?>>

														<label><?php echo $e_type->name; ?></label>
													</p><!-- cstm_MlchkBx ends -->
												</div><!-- col-sm-6 ends -->

												 <?php
										}
									}
									?>
								</div> <!-- row endds -->
								
								<div class="row">
									<div class="col-sm-12">
										  <label for="space_events[]" class="error CheckieError" style=""></label>
									</div>
								</div>
								
							</div>
							<!--col-md-6 ends-->
							
							<div class="col-md-6 col-sm-12">
									<h3 class="clr_cmn">Summary</h3>
									<ul class="VenPrntUl">
									<?php
									if (!empty($event_types)) {
										foreach ($event_types as $e_type) {
												$act_class = '';
                                                $checked_event = '';
                                                if (in_array($e_type->id, $event_arr)) {
                                                   $checked_event = 'checked';
												   $act_class = 'active';
                                                }
                                                if($checked_event){ ?>  
													<li class="<?php echo preg_replace('/[^a-zA-Z0-9]/', '', $e_type->name); ?>">
														<img src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->image; ?>" class="img1Nm ">
														<label><?php echo $e_type->name; ?></label>	
													</li>		
												 <?php
												}
										}
									}
									?>
									</ul>
									<div class="clearfix"></div>
							</div><!-- col-sm-6 ends -->
							
						</div>
						
                    </div>

                    <div class="col-sm-12  fountion_6_">
                        <!-- <div class="row top_background text-left">
                            <h4>Facilities</h4>
                        </div> -->

                        <div class="sub_hdngs">
	                        <h3 class="clr_cmn">Facilities</h3>
	                        <div class="clearfix"></div>
	                    </div>
						
						<div class="row main_row11">

								<div class="col-md-6">
									
									<div class="row ChkRow">
								<?php
                                $facility_arr = array();

                                if (!empty($space)) {
                                    if (!empty($space[0]->space_facilities)) {
                                        $facility_arr = explode(',', $space[0]->space_facilities);
                                    }
                                }

								 if (!empty($facilities)) {
									   foreach ($facilities as $f_val) {
												$act_class = '';
                                                $checked_facility = '';
                                                if (in_array($f_val->id, $facility_arr)) {
                                                    $checked_facility = 'checked';
													$act_class = 'active';
                                                }
                                                ?>
												<div class="col-sm-6 mlCh_cols ">
														<p class="cstm_MlChkBx venue_details_input <?php echo $act_class ;?>">
															<span>
																<img src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->image; ?>" class="img1Nm ">
																<img src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->white_image; ?>" class="img2Ch">

															</span> 
															<input type="checkbox" name="space_facilities[]" value="<?php echo $f_val->id; ?>"  <?php echo $checked_facility; ?> aria-required="true" required  data-msg-required="Please select at least one facility">

															<label><?php echo $f_val->name; ?></label>
														</p><!-- cstm_MlchkBx ends -->
													</div><!-- col-sm-6 ends -->

													 <?php
											}
										}
										?>
									</div> <!-- row endds -->
									
									<div class="row">
										<div class="col-sm-12">
											  <label for="space_facilities[]" class="error CheckieError" style=""></label>
										</div>
									</div>
									
								</div>
								<!--col-md-6 ends-->
								
								<div class="col-md-6 col-sm-12">
										<h3 class="clr_cmn">Summary</h3>
										<ul class="VenPrntUl">
											<?php
											if (!empty($facilities)) {
									   foreach ($facilities as $f_val) {
												$act_class = '';
                                                $checked_facility = '';
                                                if (in_array($f_val->id, $facility_arr)) {
                                                    $checked_facility = 'checked';
													$act_class = 'active';
                                                }
												if($checked_facility){
                                                ?>
												<li class="<?php echo preg_replace('/[^a-zA-Z0-9]/', '', $f_val->name); ?>">
													<img src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->image; ?>" class="img1Nm ">
													<!--<img src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->image; ?>" class="img2Ch">-->
													<label><?php echo $f_val->name; ?></label>
												</li>	 
												<?php
												}
											}
										}
										?>
										</ul>
										<div class="clearfix"></div>
								</div><!-- col-sm-6 ends -->
								
						</div>
                    </div>

                    <div class="col-sm-12  fountion_6_">
                        <!-- <div class="row top_background text-left">
                            <h4>Features</h4>
                        </div> -->

                        <div class="sub_hdngs">
	                        <h3 class="clr_cmn">Features</h3>
	                        <div class="clearfix"></div>
	                    </div>
						
						 <div class="row main_row11">

							<div class="col-md-6">
								
								<div class="row ChkRow">
										<?php
									$feature_arr = array();

									if (!empty($space)) {
										if (!empty($space[0]->space_features)) {
											$feature_arr = explode(',', $space[0]->space_features);
										}
									}
	
										
									if (!empty($features)) {
										foreach ($features as $feat_val) {
											$act_class= '';
											$checked_feature = '';
											if (in_array($feat_val->id, $feature_arr)) {
												$checked_feature = 'checked';
												$act_class = 'active';
											}
											
											?> <div class="col-sm-6 mlCh_cols ">
													<p class="cstm_MlChkBx venue_details_input <?php echo $act_class;?>">
														<span>
															<img src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->image; ?>" class="img1Nm ">
															<img src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->white_image; ?>" class="img2Ch">

														</span> 
														<input type="checkbox" name="space_features[]" value="<?php echo $feat_val->id; ?>" <?php echo $checked_feature; ?>>

														<label><?php echo $feat_val->name; ?></label>
													</p><!-- cstm_MlchkBx ends -->
												</div><!-- col-sm-6 ends -->

												 <?php
										}
									}
									?>
								</div> <!-- row endds -->
								
								<div class="row">
									<div class="col-sm-12">
										  <label for="space_features[]" class="error CheckieError" style=""></label>
									</div>
								</div>
								
							</div>
							<!--col-md-6 ends-->
							
							<div class="col-md-6 col-sm-12">
									<h3 class="clr_cmn">Summary</h3>
									<ul class="VenPrntUl">
										<?php
										if (!empty($features)) {
										foreach ($features as $feat_val) {
											$act_class= '';
											$checked_feature = '';
											if (in_array($feat_val->id, $feature_arr)) {
												$checked_feature = 'checked';
												$act_class = 'active';
											}
											if($checked_feature){
												?>
											<li class="<?php echo preg_replace('/[^a-zA-Z0-9]/', '', $feat_val->name); ?>">												
												<img src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->image; ?>" class="img1Nm ">
												<!--<img src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->image; ?>" class="img2Ch">-->
												<label><?php echo $feat_val->name; ?></label>
											</li>			
											<?php
											}
										}
									}
									?>
																		
									</ul>
									<div class="clearfix"></div>
							</div><!-- col-sm-6 ends -->
							
						</div>
                    </div>

                    <input type="hidden" name="space" value="<?php echo $space_enc; ?>">
                    <input type="submit" name="submit" class="create_map" value="Update space">
                    <a class="cancel_button_venue_catering" href="<?php echo site_url('venue/my_venues') ?>">Cancel</a>

                </form>
            </div> <!--col-md-8-->

        </div><!-- row -->
    </div> <!-- container -->
</section><!--section-das-->

<!-- Modal -->
<?php $this->load->view('models/image_cropping'); ?>
<script>
    $(function () {
        $("#msform").validate();
    });
	
	
	$(document).on('click', '.cstm_MlChkBx', function () {
        var CheckboxInput = $(this).find('input[type="checkbox"]');

        var imgie = $(this).find('.img1Nm').attr('src');
        if(!imgie){
            imgie = '';
        }
        var labs = $(this).find('label').text();
        var labsSp = labs.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '');
        var myParent = $(this).parent().parent().parent().parent('.main_row11');

        if ($(CheckboxInput).is(':checked')) {
            CheckboxInput.prop('checked', false);
            $(this).removeClass('active');
            $('.' + labsSp).remove();
        } else {
            CheckboxInput.prop('checked', true);
            $(this).addClass('active');

            $(myParent).find(".VenPrntUl").append($("<li class='" + labsSp + "'>").html('<img src =' + imgie + '> ' + '' + '<label>' + labs + ' </label>'));
        }
    });


    $('.custom_chkie').click(function () {
        $('.custom_chkie').removeClass('active');
        $(this).children("input").prop("checked", true);
        if ($(this).children("input").is(":checked")) {
            $(this).addClass('active');
        }

    });
    

	 var maxLength = 1200;
	 var length = $('.space_details').val().length;
	 $('#char3').text(maxLength-length +' characters remaining');

    $('.space_details').keyup(function() {
    	length = $(this).val().length;
       length = maxLength-length;

        $('#char3').text(length+' characters remaining');
        
     
    });
</script>