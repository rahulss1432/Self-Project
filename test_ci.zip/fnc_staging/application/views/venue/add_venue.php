<link rel="stylesheet" href="<?php echo base_url('assets/plugins/autocomplete/jquery-ui.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/css/new-style.css'); ?>">
<style>.edit_table {
        width: 80% !important;
    }</style>
<script src="<?php echo base_url('assets/plugins/autocomplete/jquery-ui.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.ezdz.js'); ?>"></script>


<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script src="<?php echo base_url('assets/js/chosen.jquery.min.js'); ?>"></script>
<link rel="stylesheet" href="<?php echo base_url('assets/css/chosen.min.css'); ?>">

<script src="<?php echo base_url('assets/js/custom/crope_images.js'); ?>"></script>
<script type="text/javascript">
    var draft_venue_space = '<?php echo (count($draft_venue_space) > 0) ? true : false ?>';
    var add2cart = '<?php echo site_url('venue/add2cart'); ?>';

    var getPricing = '<?php echo site_url('venue/get_pricing'); ?>';

    var save_profile_uri = '<?php echo site_url('venue/save_profile'); ?>';

    var marker_icon = '<?php echo base_url('assets/images/map_pointer.png'); ?>';

    var get_cart = '<?php echo site_url('venue/get_cart'); ?>';
    var remove_2_cart = '<?php echo site_url('venue/remove_2_cart'); ?>';

    var remove_cartitem = '<?php echo site_url('venue/remove_cartitem'); ?>';

    var div2clone = '<?php echo site_url('venue/div2clone'); ?>';

    var search_suburb = '<?php echo site_url('web/search_suburb'); ?>';
    var search_postcode = '<?php echo site_url('web/search_postcode'); ?>';
    var search_area = '<?php echo site_url('web/search_area'); ?>';
    var councilURL = '<?php echo site_url('web/check_council'); ?>';
    var load_council = '<?php echo site_url('venue/load_council'); ?>';
    var draft_open = '<?php echo (isset($draft_venue) ? 'true' : ''); ?>';
    var baseURL = '<?php echo site_url(); ?>';
    var draft_addional_area = '<?php echo isset($draft_additinal_council) && !empty($draft_additinal_council) ? count($draft_additinal_council) : 0; ?>';
    var draft_set = '<?php echo isset($draft_additinal_council) && !empty($draft_additinal_council) ? 'prevent' : ''; ?>'; // prevent to remove item when draft is load
    var STRIPE_PUBLIC_KEY = '<?php echo STRIPE_PUBLIC_KEY; ?>';
</script>
<script src="<?php echo base_url('assets/js/custom/add-venue.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/coordinate.js'); ?>"></script>
<section class="function_vene_page" id="add_venue_header">
    <div class="container">
        <div class="row main_row">
            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>
            <!-- Loading Side Menu -->
            <?php $this->load->view('side_menu'); ?>

            <div class="col-sm-8">
                <?php if ($this->session->flashdata('error_msg')) { ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Error!</strong> <?php echo $this->session->flashdata('error_msg'); ?>
                    </div>   
                <?php } ?>
                <div class="col-md-12 set_col_md_106">
                    <div class="row">

                        <!-- progress bar -->
                        <div id="top-txt">
                            <div class="list_your_venu_content">List your venue for a little as $1 a day.</div>
                            <div class="opening_your_venue_content">Opening your venue to
                                <span class="text_wold_start_contert">the world starts here.</span>
                            </div>
                        </div>
                        <ul id="progressbar">
                            <li class="active">Packages</li>
                            <li>Venue location</li>
                            <li>Venue details</li>
                            <li>Review and pay</li>
                        </ul>

                        <form id="msform" action="<?php echo site_url('venue/save_venue'); ?>" method="post" enctype="multipart/form-data">

                            <fieldset class="fieldset_1">
                                <div class="row">
                                    <div class="display_flex_set_d">
                                        <?php
                                        if (!empty($packs)) {
                                            foreach ($packs as $key => $value) {
                                                ?>
                                                <div class="col-md-6 col-sm-6 border_price_box <?php echo ($value->pro_id == $plan_id) ? 'first_b_o_x' : ''; ?>" id="pack<?php echo $key; ?>">
                                                    <span>
                                                        <div class="price_title <?php echo ($value->pro_id == $plan_id) ? 'first_b_o_x' : ''; ?>" id="pack-title<?php echo $key; ?>">
                                                            <div class="price_content <?php echo ($value->pro_id == $plan_id) ? 'first_b_o_x' : ''; ?>" id="pack-content<?php echo $key; ?>">
                                                                <?php echo $value->pro_title; ?>
                                                            </div>
                                                        </div>
                                                        <?php if ($value->pro_save != 0) { ?>
                                                            <div class="offet_side_bar"><a>Save $<?php echo $value->pro_save; ?></a></div>
                                                        <?php } ?>

                                                        <div class="offer_box_padding" id="pack-padding<?php echo $key; ?>">
                                                            <?php echo $value->pro_desc; ?>
                                                            <div class="choose_this_button">
                                                                <a data-pack="<?php echo $key; ?>" data-packtype="<?php echo $value->pro_id; ?>" class="choose_plan <?php echo ($value->pro_id == $plan_id) ? 'selected' : ''; ?>" href="javascript:;">Choose this plan</a>
                                                            </div>
                                                        </div>
                                                    </span>
                                                </div><!--col-md-6-->
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                </div><!--row-->

                                <div class="row">
                                    <div class="col-md-12">
                                        <div id="free-div" class="col-md-12 border_box_1 offer_box_padding <?php echo ($free == 'free') ? 'first_b_o_x' : ''; ?>">
                                            <div class="col-md-7 col-sm-7">
                                                <div class="no_thanks_content">No thanks, free text only listing</div>
                                            </div>
                                            <div class="col-md-5 col-sm-5">
                                                <div class="choose_this_button second">
                                                    <a id="free-plan" class="text-only" href="javascript:;">Choose this plan</a>
                                                    <input type="hidden" id="free" name="free" value="<?php echo ($free == 'free') ? 1 : 0; ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--row-->


                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="padding_and_border_top_bottom">
                                            <div class="Your_total">
                                                Your Total<span> (Payable by credit card or corporate account)</span>
                                            </div>

                                            <div class="your_price_show" id="pack_price">
                                                $0
                                            </div>
                                            <input type="hidden" name="plan1" id="plan1" value="<?php echo ($plan_id) ? $plan_id : 0; ?>">
                                        </div>
                                    </div>
                                </div><!--row-->
                                <input <?php echo (isset($draft_venue) ? '' : 'disabled=""'); ?> type="button" name="next" id="continue2venue" class="next action-button" value="Add Venue Location"/>
                                <input type="hidden" id="rewiew_listing_handle" value="0">
                            </fieldset>
                            <!--first-section-->
                            <!--first-section-->

                            <fieldset class="fieldset_1">
                                <div class="col-sm-12 profile_row border_progress_page">
                                    <div class="row top_background"><h4>What is your function address </h4></div>
                                    <div class="row">
                                        <div class="col-lg-12 margin_top_row_106">


                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_street">Street</label>
                                                <input type="text" class="form-control addr-field" id="venue_street" name="venue_street" value="<?php echo (isset($draft_venue[0]->fc_street)) ? $draft_venue[0]->fc_street : '' ?>">
                                                <label style="display: none;" id="venue_street-error" class="custom-error"></label>
                                            </div>
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_state">State</label>
                                                <input type="text" class="form-control addr-field" id="venue_state" name="venue_state" value="<?php echo (isset($draft_venue[0]->fc_state)) ? $draft_venue[0]->fc_state : '' ?>">
                                                <label style="display: none;" id="venue_state-error" class="custom-error"></label>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_suburb">Suburb</label>
                                                <input type="text" class="form-control addr-field" id="venue_suburb" name="venue_suburb" value="<?php echo (isset($draft_venue[0]->fc_suburb)) ? $draft_venue[0]->fc_suburb : '' ?>">
                                                <label style="display: none;" id="venue_suburb-error" class="custom-error"></label>
                                            </div>
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_postcode">Postcode</label>
                                                <input type="number" class="form-control addr-field" id="venue_postcode" name="venue_postcode" value="<?php echo (isset($draft_venue[0]->fc_postcode)) ? $draft_venue[0]->fc_postcode : '' ?>">
                                                <label style="display: none;" id="venue_postcode-error" class="custom-error"></label>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_country">Country</label>
                                                <input type="text" readonly="" value="Australia" class="form-control addr-field" id="venue_country" name="venue_country">
                                                <label style="display: none;" id="venue_country-error" class="custom-error"></label>
                                                <input type="hidden" name="venue_lat" id="venue_lat" value="<?php echo (isset($draft_venue[0]->fc_lat)) ? $draft_venue[0]->fc_lat : '' ?>">
                                                <input type="hidden" name="venue_lng" id="venue_lng" value="<?php echo (isset($draft_venue[0]->fc_lng)) ? $draft_venue[0]->fc_lng : '' ?>">
                                            </div>
                                            <div class="col-md-6 margin_set_input">
                                                <input type="hidden" class="form-control addr-field" id="venue_council" name="venue_council" value="<?php echo (isset($draft_venue[0]->fc_council)) ? $draft_venue[0]->fc_council : '' ?>">
                                                <input type="hidden" class="form-control addr-field" id="council_id" value="<?php echo (isset($draft_council_id)) ? $draft_council_id : '' ?>">
                                                <input type="hidden" class="form-control addr-field" name="venue_city" id="venue_city" value="<?php echo (isset($draft_venue[0]->fc_city)) ? $draft_venue[0]->fc_city : '' ?>">
                                                <input type="hidden" class="form-control" id="zoom"  value="<?php echo!empty($zoom) ? $zoom : '' ?>" >
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">

                                    <div class="col-md-12" style="display:table">
                                        <span><h4>Proceed below to see where you will appear on a search map and choose to expand your listing area</h4></span>
                                        <input type="button" id="show-map" class="create_map" onclick="initialize();" value="View your listing area">
                                        <input type="hidden" id="council_arr" value="[]">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12 margin_106">
                                        <h3 style="display: none;" id="title-map-1" class="opening_your_venue_content your_venue_1 font_your_venue">Your venue will appear in '<span id="city-nm"></span>' search.</h3>

                                        <div id="map-canvas"></div>
                                        <input type="hidden" id="lat-f" value="">
                                        <input type="hidden" id="lng-f" value="">
                                        <input type="hidden" id="lat-temp" value="">
                                        <input type="hidden" id="lng-temp" value="">
                                        <input type="hidden" id="zoom" value="">
                                        <div class="map_area" style="display: none;">
                                            <h3  id="title-map-2" class="opening_your_venue_content your_venue_1 font_your_venue">You can list additional search regions for 20c per day per additional search area, with a maximum of 4 search areas.
                                            </h3>
                                            <div id="map-canvas-2"></div>
                                        </div>
                                    </div>
                                </div>



                                <div id="additional-area-row" class="row" style="display: none;">
                                    <div class="col-md-12">
                                        <div class="plus-listing_new">

                                            <?php
                                            $cnt = 1;
                                            $total_count = 4;
//                                          
                                            if (!empty($draft_additinal_council)) {
                                                foreach ($draft_additinal_council as $val) {
                                                    ?>
                                                    <div id="region-area<?php echo $cnt ?>" class="new_block">
                                                        <span id="minima<?php echo $cnt ?>" class="plus-section_new">
                                                            <select data-placeholder="Select near by council" id="addition-area<?php echo $cnt ?>" data-active="1" data-cnt="<?php echo $cnt ?>" class="input-large form-control addition-ar chossen_intialize"  name="add_arr[]" >
                                                                <option disabled selected value>-- select council --</option>
                                                            </select>
                                                            <input type="hidden" id="region_name<?php echo $cnt ?>" value="<?php echo $val->area_name ?>"/>
                                                            <input type="hidden" id="region<?php echo $cnt ?>" value="<?php echo $val->council_id ?>"/>
                                                            <input type="hidden" name="add_arr_lat[]" id="addition-lat<?php echo $cnt ?>" value="<?php echo $val->area_lat ?>"/>
                                                            <input type="hidden" name="add_arr_lng[]" id="addition-lng<?php echo $cnt ?>" value="<?php echo $val->area_lng ?>"/>
                                                        </span>
                                                    </div>
                                                    <?php
                                                    $total_count--;
                                                    $cnt++;
                                                }
                                            }
                                            ?>

                                            <?php
                                            if ($total_count > 0) {
                                                for ($total_count; 1 <= $total_count; $total_count--) {
                                                    ?>
                                                    <div id="region-area<?php echo $cnt ?>" class="new_block">
                                                        <span id="minima<?php echo $cnt ?>" class="plus-section_new">
                                                            <select data-placeholder="Select near by council" id="addition-area<?php echo $cnt ?>" data-active="0" data-cnt="<?php echo $cnt ?>" class="input-large form-control addition-ar chossen_intialize"  name="add_arr[]" >
                                                                <option disabled selected value>-- select council --</option>
                                                            </select>
                                                            <input type="hidden" id="region<?php echo $cnt ?>">
                                                            <input type="hidden" name="add_arr_lat[]" id="addition-lat<?php echo $cnt ?>">
                                                            <input type="hidden" name="add_arr_lng[]" id="addition-lng<?php echo $cnt ?>">
                                                        </span>
                                                    </div>
                                                    <?php
                                                    $cnt++;
                                                }
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="padding_and_border_top_bottom">
                                            <div class="Your_total">
                                                Your total<span> (Payable by credit card or corporate account)</span>
                                            </div>
                                            <div class="your_price_show">
                                                $0
                                            </div>
                                            <input type="hidden" name="plan2" id="plan2" value="3">
                                            <input type="hidden" id="firstcart" value="<?php echo ($firstcart) ? $firstcart : '' ?>">
                                        </div>
                                    </div>
                                </div><!--row-->

                                                                                                                                                        <!-- <input type="button" name="previous" class="previous action-button-previous" value="Previous"/> -->
                                <input type="button" style="display:none"  id="next2details" disabled="true" name="next" class="next action-button" value="Continue to venue details"/>
                            </fieldset>
                            <!--second-section-->
                            <!--second-section-->
                            <?php
                            if (isset($draft_venue)) {
                                $check_url = site_url('venue/check_business_name/') . '?fc_id=' . encrypt_decrypt('encrypt', $draft_venue[0]->fc_id);
                            } else {
                                $check_url = site_url('venue/check_business_name');
                            }
                            ?>
                            <fieldset class="fieldset_1">
                                <div class="col-sm-12 profile_row border_progress_page fountion_1">
                                    <div class="row top_background">
                                        <h4>Venue </h4></div>
                                    <div class="row">
                                        <div class="col-lg-12 margin_top_row_106">
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_business_name">Business name</label>
                                                <input type="text" class="form-control" data-msg-remote="this name already exist" data-rule-remote="<?php echo $check_url; ?>" id="venue_business_name" name="venue_business_name" data-rule-required="true" value="<?php echo (isset($draft_venue[0]->fc_business_name)) ? $draft_venue[0]->fc_business_name : '' ?>">
                                            </div>
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_abn">ABN</label>
                                                <input type="text" class="form-control" id="venue_abn" name="venue_abn" data-rule-abn_number="true" data-rule-required="true"  value="<?php echo (isset($draft_venue[0]->fc_abn)) ? $draft_venue[0]->fc_abn : '' ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_contact_name">Contact name</label>
                                                <input type="text" class="form-control" id="venue_contact_name" name="venue_contact_name" data-rule-required="true" value="<?php echo (isset($draft_venue[0]->fc_contact_name)) ? $draft_venue[0]->fc_contact_name : '' ?>">
                                            </div>
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_phone_no">Phone number</label>
                                                <input type="text" class="form-control phone_no" id="venue_phone_no" name="venue_phone_no" data-rule-required="true"  value="<?php echo (isset($draft_venue[0]->fc_phone_no)) ? $draft_venue[0]->fc_phone_no : '' ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_website">Website</label>
                                                <input type="text"  class="form-control" id="venue_website" name="venue_website" data-rule-required="true" value="<?php echo (isset($draft_venue[0]->fc_website)) ? $draft_venue[0]->fc_website : '' ?>">
                                            </div>
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_email">Email</label>
                                                <input type="text" class="form-control" id="venue_email" name="venue_email" data-rule-required="true"  data-rule-email="true" value="<?php echo (isset($draft_venue[0]->fc_email)) ? $draft_venue[0]->fc_email : '' ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- col-sm-12 -->

                                <?php
                                if (!empty($draft_venue[0]->fc_listing_picture)) {
                                    $img_url = base_url('uploads/fc_images') . '/' . $draft_venue[0]->fc_listing_picture;
                                } else {
                                    $img_url = '';
                                }
                                ?>
                                <div class="col-sm-12 profile_row border_progress_page fountion_1">
                                    <div class="row top_background">
                                        <h4>Main Image </h4>
                                    </div>
                                    <div class="row margin_top_row_second_106 up-image-row">
                                        <div class="col-md-12 text-left">
                                            <div  class="ulpading_img_size_3 listing_picture_thumb">
                                                <img  id="show_image_55555" class="dropzone" img-id="55555" src="<?php echo $img_url; ?>" style="<?php echo ($img_url == '') ? 'display: none;' : 'display:block;' ?>">
                                                <input onclick="this.value = null;" type="file" name="fc_listing_picture" data-id="55555" class="file-selector image_selector" id="image_selector_55555" accept="image/*">
                                                <input type="hidden" name="dimesion_image_55555" id="dimesion_image_55555" value="0">
                                                <img class="remove_image" onclick="removeImage(1, '<?php echo (isset($draft_venue[0]->fc_id)) ? encrypt_decrypt('encrypt', $draft_venue[0]->fc_id) : 0 ?>', <?php echo (isset($draft_venue[0]->fc_id)) ? 1 : 2 ?>, 55555)" src="<?php echo base_url(REMOVE_IMAGE) ?>">
                                            </div>
                                            <div class="ulpading_img_size_3_1 listing_picture_thumb">
                                                <div>
                                                    To have your venue looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 300 x 530 pixels.
                                                </div>
                                                <div class="row" >
                                                    <label ant-id="55555" class="upload-button_new after_102" id="another_select_55555">
                                                        <i  class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <div class="col-sm-12 profile_row fountion_2">
                                    <div class="row top_background text-left">
                                        <h4>Venue images</h4>
                                    </div>
                                    <?php
                                    $last_key = 1;
                                    $img_status = TRUE;
                                    $img_count = 5;
                                    if (!empty($draft_venue_images)) {
                                        foreach ($draft_venue_images as $key => $value) {
                                            $img_url = (!empty($value->fc_img_name)) ? base_url('uploads/fc_images') . '/' . $value->fc_img_name : '';
                                            ?>
                                            <div class="row margin_top_row_second_106 up-image-row">
                                                <div class="col-md-12 text-left">
                                                    <div class="ulpading_img_size_3">
                                                        <img style="display:<?php echo ($img_url) ? 'block' : 'none' ?>" img-id="<?php echo ($key + 1); ?>" class="dropzone" id="show_image_<?php echo ($key + 1); ?>" src="<?php echo $img_url; ?>">
                                                        <input onclick="this.value = null;" type="file" name="fc_img_name<?php echo ($key + 1); ?>" data-id="<?php echo ($key + 1); ?>" class="file-selector image_selector" id="image_selector_<?php echo ($key + 1); ?>" accept="image/*">
                                                        <input type="hidden" name="dimesion_image_<?php echo ($key + 1); ?>" id="dimesion_image_<?php echo ($key + 1); ?>" value="0">
                                                        <img onclick="removeImage(2, '<?php echo encrypt_decrypt('encrypt', $value->fc_img_id); ?>', 1, <?php echo $key + 1; ?>)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                                    </div>
                                                    <div class="ulpading_img_size_3_1">
                                                        <?php
                                                        if ($key == 0) {
                                                            $img_status = FALSE;
                                                            ?>
                                                            <div>
                                                                To have your venue looking its best and showcasing the offereing a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                            </div>
                                                        <?php } ?>
                                                        <div class="row">
                                                            <label ant-id="<?php echo ($key + 1); ?>" class="upload-button_new after_102" id="another_select_<?php echo ($key + 1); ?>">
                                                                <!-- <!-----> -->
                                                                <input type="hidden"  name="image<?php echo ($key + 1); ?>" value="<?php echo $value->fc_img_id; ?>">
                                                                <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            $last_key = $key + 1;
                                            $img_count = $img_count - 1;
                                        }
                                        $last_key = $last_key + 1;
                                    }

                                    if ($img_count > 0) {
                                        $crp = $last_key;
                                        ?>
                                        <input type="hidden" name="img_count" value="<?php echo $img_count; ?>">
                                        <?php
                                        for ($i = 1; $i <= ($img_count); $i++) {
                                            ?>
                                            <div class="row margin_top_row_second_106 up-image-row">
                                                <div class="col-md-12 text-left">
                                                    <div  class="ulpading_img_size_3 ">
                                                        <img  id="show_image_<?php echo $crp; ?>" class="dropzone" img-id="<?php echo $crp; ?>" src="" style="display:none">
                                                        <input onclick="this.value = null;" type="file" name="fc_img_name<?php echo $crp; ?>" data-id="<?php echo $crp; ?>" class="file-selector image_selector" id="image_selector_<?php echo $crp; ?>" accept="image/*">
                                                        <input type="hidden" name="dimesion_image_<?php echo $crp; ?>" id="dimesion_image_<?php echo $crp; ?>" value="0">
                                                        <img onclick="removeImage(2, '0', 2, <?php echo $crp; ?>)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                                    </div>
                                                    <div class="ulpading_img_size_3_1">
                                                        <?php
                                                        if ($img_status) {
                                                            $img_status = FALSE;
                                                            ?>
                                                            <div>
                                                                To have your catering looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                            </div>
                                                        <?php } ?>
                                                        <div class="row" >
                                                            <label ant-id="<?php echo $crp; ?>" class="upload-button_new after_102" id="another_select_<?php echo $crp; ?>">
                                                                <i  class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            $crp++;
                                        }
                                    }
                                    ?>

                                    <div class="clearfix"></div>
                                    <div class="row margin_top_ohNo">
                                        <div class="col-md-6 col-sm-12 col-xs-12">

                                        </div>
                                        <div class="col-md-6 bottom_button col-sm-12 col-xs-12">
                                            <button type="button" style="display: none" id="venue-photography" class="i_need_venue_button">I need venue photography</button>
                                            <input type="hidden" name="need_photography" id="need_photography" value="0">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_3">
                                    <div class="row top_background text-left">
                                        <h4>Price per head </h4>
                                    </div>
                                    <div class="row">
                                        <div class="text-left">
                                            <div class="col-md-6">
                                                <?php
                                                $price_arr = array();

                                                if (!empty($draft_venue[0]->fc_pricing)) {
                                                    $price_arr = explode(',', $draft_venue[0]->fc_pricing);
                                                }

                                                if (!empty($price_per_head)) {
                                                    $dollar_count = 1;
                                                    foreach ($price_per_head as $value) {
                                                        $checked_pricing = '';
                                                        if (in_array($value->p_id, $price_arr)) {
                                                            $checked_pricing = 'checked';
                                                            //die;
                                                        }
                                                        ?>
                                                        <label class="set_label_venu">
                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                <input name="venue_pricing[]" type="checkbox" value="<?php echo $value->p_id; ?>" <?php echo $checked_pricing; ?>>
                                                                <small></small>
                                                            </label>
                                                            <div class="dolor_icon"><?php
                                                                for ($i = 0; $i < $dollar_count; $i++) {
                                                                    echo '$';
                                                                }
                                                                ?></div>
                                                            <span><?php echo $value->p_name; ?></span>

                                                        </label>
                                                        <?php
                                                        if ($dollar_count % 2 == 0)
                                                            echo '</div><div class="col-md-6">';

                                                        $dollar_count++;
                                                    }
                                                }
                                                ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_4">
                                    <div class="row top_background text-left">
                                        <h4>Overview-Venue details</h4>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12 text-left">
                                            <label class="" for="venue_description">Overview</label>
                                            <textarea rows="4" class="form-control overview_textarea textare_root" id="venue_overview" name="venue_overview" placeholder="This is a short introductory overview that describes your venue. &#10;Max 400 words." data-rule-required="true" data-rule-maxlength="400"><?php echo (isset($draft_venue[0]->fc_overview)) ? $draft_venue[0]->fc_overview : '' ?></textarea>
                                        </div>
                                    </div>

                                    <div class="row margin_top_ohNo">
                                        <div class="col-md-8 col-xs-12 col-sm-12">
                                            <div class="oh_no_content">Struggling to come up with the right words? Do your best but then elect for our professional copy writers to review and write your venue description. We'll be in touch shortly.</div>
                                        </div>
                                        <div class="col-md-4 bottom_button col-xs-12 col-sm-12">
                                            <!-- <button type="button" id="venue-copy" class="i_need_venue_button">I need venue copy</button> -->
                                            <input type="hidden" name="need_venuecopy" id="need_venuecopy" value="0">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_5">
                                    <div class="row top_background text-left">
                                        <h4>Event types</h4>
                                    </div>
                                    <div class="row margin_top_row_second_106">
                                        <div class="form-check form-check-inline">
                                            <?php
                                            $event_arr = array();
                                            if (!empty($draft_venue_details)) {
                                                if (!empty($draft_venue_details[0]->vd_events)) {
                                                    $event_arr = explode(',', $draft_venue_details[0]->vd_events);
                                                }
                                            }
                                            if (!empty($event_types)) {
                                                foreach ($event_types as $e_type) {
                                                    ?>
                                                    <div class="col-md-6 text-left pass">
                                                        <label class="set_label_venu">
                                                            <?php
                                                            $checked_event = '';
                                                            if (in_array($e_type->id, $event_arr)) {
                                                                $checked_event = 'checked';
                                                            }
                                                            ?>
                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                <input type="checkbox" name="venue_events[]" value="<?php echo $e_type->id; ?>" <?php echo $checked_event; ?>>
                                                                <small></small>
                                                            </label>
                                                            <div class="dolor_icon size_set_ic"><img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->image; ?>"></div>
                                                            <span><?php echo $e_type->name; ?></span>
                                                        </label>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_6">
                                    <div class="row top_background text-left">
                                        <h4>Facilities</h4>
                                    </div>
                                    <div class="row margin_top_row_second_106">
                                        <div class="form-check form-check-inline">
                                            <?php
                                            $facility_arr = array();
                                            if (!empty($draft_venue_details)) {
                                                if (!empty($draft_venue_details[0]->vd_facilities)) {
                                                    $facility_arr = explode(',', $draft_venue_details[0]->vd_facilities);
                                                }
                                            }
                                            if (!empty($facilities)) {
                                                foreach ($facilities as $f_val) {
                                                    ?>
                                                    <div class="col-md-6 text-left pass_1">
                                                        <label class="set_label_venu">
                                                            <?php
                                                            $checked_facility = '';
                                                            if (in_array($f_val->id, $facility_arr)) {
                                                                $checked_facility = 'checked';
                                                            }
                                                            ?>
                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                <input  type="checkbox" name="venue_facilities[]" value="<?php echo $f_val->id; ?>" <?php echo $checked_facility; ?>>
                                                                <small></small>
                                                            </label>
                                                            <div class="dolor_icon size_set_ic">
                                                                <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->image; ?>">
                                                            </div>
                                                            <span><?php echo $f_val->name; ?></span>
                                                        </label>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_6">
                                    <div class="row top_background text-left">
                                        <h4>Features</h4>
                                    </div>
                                    <div class="row margin_top_row_second_106">
                                        <div class="form-check form-check-inline">
                                            <?php
                                            $feature_arr = array();
                                            if (!empty($draft_venue_details)) {
                                                if (!empty($draft_venue_details[0]->vd_features)) {
                                                    $feature_arr = explode(',', $draft_venue_details[0]->vd_features);
                                                }
                                            }
                                            if (!empty($features)) {
                                                foreach ($features as $feat_val) {
                                                    ?>
                                                    <div class="col-md-6 text-left pass_1">
                                                        <label class="set_label_venu">
                                                            <?php
                                                            $checked_feature = '';
                                                            if (in_array($feat_val->id, $feature_arr)) {
                                                                $checked_feature = 'checked';
                                                            }
                                                            ?>

                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                <input  type="checkbox" name="venue_features[]" value="<?php echo $feat_val->id; ?>" <?php echo $checked_feature; ?>>
                                                                <small></small>
                                                            </label>
                                                            <div class="dolor_icon size_set_ic">
                                                                <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->image; ?>">
                                                            </div>
                                                            <span><?php echo $feat_val->name; ?></span>
                                                        </label>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_7">
                                    <div class="row top_background text-left">
                                        <h4>Venue in detail</h4>
                                    </div>
                                    <div class="row margin_top_row_second_106">
                                        <div class="col-md-12 text-left">
                                            <label class="text-left" for="venue_description">Details</label>
                                            <textarea rows="4" class="form-control overview_textarea textare_root" placeholder="This section allows for more venue details if required. Not mandatory. &#10;Max 800 words" id="venue_details" name="venue_details" data-rule-required="true"  data-rule-maxlength="800"><?php echo (isset($draft_venue[0]->fc_details) ? $draft_venue[0]->fc_details : '' ); ?></textarea>
                                        </div>
                                    </div>

                                    <div class="row margin_top_and_bottom_user">
                                        <div class="col-md-6 text-left">
                                            <label class="lbl_class" for="venue_min_guest">Minimum guest numbers</label>
                                            <input type="text" data-rule-lessThan="#venue_max_guest" id="venue_min_guest" class="form-control" id="venue_min_guest" name="venue_min_guest" data-rule-required="true" data-rule-number="true" value="<?php echo (isset($draft_venue[0]->fc_min_guest)) ? $draft_venue[0]->fc_min_guest : '' ?>">
                                        </div>
                                        <div class="col-md-6 text-left">
                                            <label class="lbl_class" for="venue_max_guest">Maximum guest numbers</label>
                                            <input type="text" data-rule-greaterThan="#venue_min_guest" id="venue_max_guest" class="form-control" id="venue_max_guest" name="venue_max_guest" data-rule-required="true" data-rule-number="true" value="<?php echo (isset($draft_venue[0]->fc_max_guest)) ? $draft_venue[0]->fc_max_guest : '' ?>">
                                        </div>

                                    </div>

                                    <div id="list-an" class="row margin_top_ohNo">
                                        <div class="col-md-8 col-xs-12 col-sm-12">
                                            <div class="oh_no_content">Does your venue have multiple function areas with different guest capacity? You can list another space within a venue for $30c a day</div>
                                        </div>
                                        <div class="col-md-4 bottom_button col-xs-12 col-sm-12">
                                            <button type="button" id="list-another-1" class="i_need_venue_button">List another space</button>
                                        </div>
                                    </div>

                                </div>

                                <?php
                                if (!empty($draft_venue_space)) {
                                    $space_display = 'block';
                                } else {
                                    $space_display = 'none';
                                }
                                ?>


                                <div style="display: <?php echo $space_display; ?>" id="another-space-div">
                                    <div id="append2divspace">
                                        <?php
                                        $x = 1;
                                        $index = 0;
                                        $img_crop = 6;
                                        do {
                                            ?>
                                            <div class="div2clone">

                                                <div class="col-sm-12 profile_row fountion_7">
                                                    <div class="row top_background text-left set_new_102">
                                                        <h4 class="h4-title">Space <?php echo inWord($x); ?></h4>
                                                    </div>
                                                    <div class="row margin_top_and_bottom_user">
                                                        <div class="col-md-12 margin_set_input text-left">
                                                            <label class="lbl_class">Space name</label>
                                                            <input type="text" class="form-control fm-field" name="space_name<?php echo $x; ?>" data-rule-required="true" value="<?php echo (isset($draft_venue_space[$index]->space_name) ? $draft_venue_space[$index]->space_name : '') ?>">
                                                        </div>
                                                        <div class="margin_set_input text-left">
                                                            <div class="col-md-6 margin_set_input">
                                                                <label class="lbl_class">Minimum guest numbers</label>
                                                                <input type="text" class="form-control fm-field" id="min_guest<?php echo $index; ?>" name="space_min_guest<?php echo $x; ?>" data-rule-required="true" data-rule-lessThan="#max_guest<?php echo $index; ?>" data-rule-number="true" value="<?php echo (isset($draft_venue_space[$index]->space_min_guest)) ? $draft_venue_space[$index]->space_min_guest : '' ?>" data-rule-lessThan="#venue_max_guest" id="venue_min_guest" >
                                                            </div>
                                                            <div class="col-md-6 margin_set_input ">
                                                                <label class="lbl_class">Maximum guest numbers</label>
                                                                <input type="text" class="form-control fm-field" id="max_guest<?php echo $index; ?>" name="space_max_guest<?php echo $x; ?>" data-rule-required="true" data-rule-number="true" data-rule-greaterThan="#min_guest<?php echo $index; ?>" value="<?php echo (isset($draft_venue_space[$index]->space_max_guest)) ? $draft_venue_space[$index]->space_max_guest : '' ?>" data-rule-greaterThan="#venue_min_guest"  id="venue_max_guest" >
                                                            </div>

                                                        </div>

                                                        <div class="col-md-12 text-left margin_set_input">
                                                            <label class="text-left">Details</label>
                                                            <textarea rows="4" class="form-control overview_textarea textare_root fm-field" name="space_details<?php echo $x; ?>" data-rule-maxlength="800" data-rule-required="true"><?php echo (isset($draft_venue_space[$index]->space_details)) ? $draft_venue_space[$index]->space_details : '' ?></textarea>
                                                        </div>

                                                        <?php
                                                        if (!empty($draft_venue_space[$index]->space_image)) {
                                                            $img_url = base_url('uploads/venue_spaces') . '/' . $draft_venue_space[$index]->space_image;
                                                        } else {
                                                            $img_url = '';
                                                        }
                                                        ?>
                                                        <div class="col-md-12">
                                                            <div class="ulpading_img_size_3">
                                                                <img id="show_image_<?php echo $img_crop; ?>" img-id="<?php echo $img_crop; ?>" style="<?php echo ($img_url == '') ? 'display: none;' : 'display:block;' ?>" class="dropzone" src="<?php echo $img_url; ?>">
                                                                <input onclick="this.value = null;" type="file" data-id="<?php echo $img_crop; ?>" id="image_selector_<?php echo $img_crop; ?>" class="file-selector fm-field image_selector" name="space_image<?php echo $x; ?>">
                                                                <input type="hidden" name="dimesion_image_<?php echo $img_crop; ?>" id="dimesion_image_<?php echo $img_crop; ?>" value="0">
                                                                <img class="remove_image" onclick="removeImage(3, '<?php echo (isset($draft_venue_space[$index]->space_id)) ? encrypt_decrypt('encrypt', $draft_venue_space[$index]->space_id) : 0; ?>', <?php echo (isset($draft_venue_space[$index]->space_id)) ? 1 : 2; ?>, <?php echo $img_crop; ?>)" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                                            </div>

                                                            <div class="ulpading_img_size_3_1">
                                                                <div class="row">
                                                                    <span id="fileselector">
                                                                        <label ant-id="<?php echo $img_crop; ?>" class="upload-button_new after_102">
                                                                            <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                                        </label>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-sm-12 profile_row fountion_5">
                                                    <div class="row top_background text-left set_new_102">
                                                        <h4 class="h4-events">Space <?php echo inWord($x); ?> - Event types</h4>
                                                    </div>
                                                    <div class="row margin_top_row_second_106">
                                                        <div class="form-check form-check-inline">

                                                            <?php
                                                            $event_arr = array();

                                                            if (!empty($draft_venue_space)) {
                                                                if (!empty($draft_venue_space[$index]->space_events)) {
                                                                    $event_arr = explode(',', $draft_venue_space[$index]->space_events);
                                                                }
                                                            }
                                                            if (!empty($event_types)) {
                                                                foreach ($event_types as $e_type) {
                                                                    ?>
                                                                    <div class="col-md-6 text-left pass">
                                                                        <label class="set_label_venu">
                                                                            <?php
                                                                            $checked_event = '';
                                                                            if (in_array($e_type->id, $event_arr)) {
                                                                                $checked_event = 'checked';
                                                                            }
                                                                            ?>
                                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                                <input type="checkbox" type="checkbox" name="space_events1[]" value="<?php echo $e_type->id; ?>" <?php echo $checked_event; ?>>
                                                                                <small></small>
                                                                            </label>
                                                                            <div class="dolor_icon size_set_ic">
                                                                                <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $e_type->image; ?>">
                                                                            </div>
                                                                            <span><?php echo $e_type->name; ?></span>
                                                                        </label>
                                                                    </div>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>

                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-sm-12 profile_row fountion_5">
                                                    <div class="row top_background text-left set_new_102">
                                                        <h4 class="h4-facilities">Space <?php echo inWord($x); ?> - Facilities</h4>
                                                    </div>
                                                    <div class="row margin_top_row_second_106">
                                                        <div class="form-check form-check-inline">
                                                            <?php
                                                            $facility_arr = array();

                                                            if (!empty($draft_venue_space)) {
                                                                if (!empty($draft_venue_space[$index]->space_facilities)) {
                                                                    $facility_arr = explode(',', $draft_venue_space[$index]->space_facilities);
                                                                }
                                                            }
                                                            if (!empty($facilities)) {
                                                                foreach ($facilities as $f_val) {
                                                                    ?>
                                                                    <div class="col-md-6 text-left pass">
                                                                        <label class="set_label_venu">
                                                                            <?php
                                                                            $checked_facility = '';
                                                                            if (in_array($f_val->id, $facility_arr)) {
                                                                                $checked_facility = 'checked';
                                                                            }
                                                                            ?>
                                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                                <input type="checkbox" name="space_facilities1[]" value="<?php echo $f_val->id; ?>" <?php echo $checked_facility; ?>>
                                                                                <small></small>
                                                                            </label>
                                                                            <div class="dolor_icon size_set_ic">
                                                                                <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $f_val->image; ?>">
                                                                            </div>
                                                                            <span><?php echo $f_val->name; ?></span>
                                                                        </label>
                                                                    </div>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>

                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-sm-12 profile_row fountion_5">
                                                    <div class="row top_background text-left set_new_102">
                                                        <h4 class="h4-features">Space <?php echo inWord($x); ?> - Features</h4>
                                                    </div>
                                                    <div class="row margin_top_row_second_106">
                                                        <div class="form-check form-check-inline">

                                                            <?php
                                                            $feature_arr = array();

                                                            if (!empty($draft_venue_space)) {
                                                                if (!empty($draft_venue_space[$index]->space_features)) {
                                                                    $feature_arr = explode(',', $draft_venue_space[$index]->space_features);
                                                                }
                                                            }
                                                            if (!empty($features)) {
                                                                foreach ($features as $feat_val) {
                                                                    ?>
                                                                    <div class="col-md-6 text-left pass">
                                                                        <label class="set_label_venu">
                                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                                <input type="checkbox" name="space_features1[]" value="<?php echo $feat_val->id; ?>" <?php echo $checked_feature; ?>>
                                                                                <small></small>
                                                                            </label>
                                                                            <div class="dolor_icon size_set_ic"><img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $feat_val->image; ?>"></div>
                                                                            <span><?php echo $feat_val->name; ?></span>
                                                                            <?php
                                                                            $checked_feature = '';
                                                                            if (in_array($feat_val->id, $feature_arr)) {
                                                                                $checked_feature = 'checked';
                                                                            }
                                                                            ?>
                                                                        </label>
                                                                    </div>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <?php
                                            $x++;
                                            $index++;
                                            $img_crop++;
                                        } while ($x <= count($draft_venue_space));
                                        ?>
                                    </div>

                                    <div class="clearfix"></div>

                                    <div class="col-md-12 margin_top_but_102">
                                        <div class="row">
                                            <span class="Plus_102">+</span><span class="add_another_102" id="add-an-1_space">Add another space</span> 
                                            <span id="just-one-space" class="just_one_102">Just one space please</span>
                                        </div>
                                    </div>

                                </div>



                                <div class="col-md-12 margin_top_but_102">
                                    <div class="row save_profile">
                                        <input type="hidden" id="draft_addional_row_id" value="<?php echo $draft_addional_row_id; ?>">
                                        <input type="hidden" id="total_another" name="total_another" value="<?php echo (!empty($draft_venue_space)) ? count($draft_venue_space) : 0 ?>">
                                        <input type="hidden" name="plan3" id="plan3" value="4">

                                        <input type="hidden" name="fc_id" id="fc_id" value="<?php echo (isset($draft_venue[0]->fc_id)) ? encrypt_decrypt('encrypt', $draft_venue[0]->fc_id) : '' ?>">
                                    </div>
                                </div>

                                <div class="clearfix"></div>
                                <div class="row ">
                                    <div class="col-md-12">
                                        <div class="padding_and_border_top_bottom">
                                            <div class="Your_total">
                                                Your Total<span> (Payable by credit card or corporate account)</span>
                                            </div>
                                            <div id="details-pricing-div" class="your_price_show">
                                                $0
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <input type="button" id="continue2review" name="next" class="next action-button" value="Continue to Review and pay">
                                <button type="button" class="action-button float_use but pull-left"  id="save_profile" >  Save & review later</button>

                            </fieldset>
                            <!--three-section-->
                            <!--three-section-->

                            <fieldset class="fieldset_1">
                                <div id="review_listing" class="list_your_venu_content">Review your listing</div>
                                <div class="row">
                                    <div class="col-md-5 col-xs-6">
                                        <div class="choose_this_button second">
                                            <a class="first-section" href="javascript:;">Review listing</a>
                                        </div>
                                    </div>
                                </div>

                                <!--<div id="pay-summary">-->
                                <div class="list_your_venu_content Payment">Payment summary</div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div id="m-cart"></div>

                                        <div class="padding_and_border_top_bottom">
                                            <div class="Your_total">
                                                Your Total<span> (Payable by credit card or corporate account)</span>
                                            </div>

                                            <div class="your_price_show" id="grand-total">
                                                $0
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--</div>-->
                                <span id="voucher_massage"></span>
                                <div id="cart-div" class="row maring_row_cart_page">
                                    <div class="voucher_div">
                                        <div class="col-md-8 col-sm-7 col-xs-12 text-left">
                                            <label class="lbl_class">Add voucher code</label>
                                            <input name="voucher_code" type="text" class="form-control add_voucher_code">
                                            <label style="display: none;" id="voucher-error" class="custom-error"></label>
                                        </div>

                                        <div class="col-md-4  col-sm-5 col-xs-12 pull-right">
                                            <div class="choose_this_button second apply_button">
                                                <a class="apply_voucher" onclick="appaly_voucher(1, 1);" href="javascript:void(0);">Apply</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12" id="payment_method">
                                       <!--  <p>
                                            <span class="pay_radio_button">
                                                <span class="pull-left"> Pay by Stripe</span>
                                                <label class="regular-checkbox">
                                                    <input type="radio" class="payment_method" onclick="choose_payment(1, 1, 1)" name="payment_method" value="1">
                                                    <small></small>
                                                </label>
                                            </span>
                                            <span class="pay_radio_button">
                                                <span class="pull-left"> Pay by account</span>
                                                <label class="regular-checkbox">
                                                    <input type="radio" class="payment_method" onclick="choose_payment(2, 1, 1)" name="payment_method" value="2">
                                                    <small></small>
                                                </label>
                                            </span>
                                        </p> -->
                                        <br>

                                        <p class="pay_tap_div">
                                            <span class="pay_radio_button">

                                                <label class="regular-checkbox pull-left">
                                                    <input type="radio" class="payment_method" onclick="choose_payment(1, 1, 1)" name="payment_method" value="1">
                                                    <small></small>
                                                </label>
                                                <span class="pull-left"> Pay by Stripe</span>
                                            </span>
                                            <span class="pay_radio_button">

                                                <label class="regular-checkbox pull-left">
                                                    <input type="radio" class="payment_method" onclick="choose_payment(2, 1, 1)" name="payment_method" value="2">
                                                    <small></small>
                                                </label>
                                                <span class="pull-left"> Pay by account</span>
                                            </span>
                                        </p>


                                        <input type="hidden" id="selected_method" value="0">
                                        <label style="display: none;" id="payment_method-error">Please select payment method</label>
                                    </div>

                                    <div class="col-md-12" id="strip_payment" style="display: none">
                                        <div class="row color_set_gray">
                                            <div class="col-md-8 pull-left">
                                                <!--<form>-->
                                                <div class="form-group owner">
                                                    <label class="card_number_label">Card Number</label>
                                                    <input type="text" id="cardnumber" class="form-control-1 car_input_number card-number addr-field">
                                                    <label style="display: none;" id="cardnumber-error" class="custom-error"></label>
                                                </div>

                                                <div class="cart_icon_set">
                                                    <ul>
                                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_card_visa-128.png" class="img-responsive"></li>
                                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_discover_network_card-128.png" class="img-responsive"></li>
                                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_master_card-128.png" class="img-responsive"></li>
                                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_google_wallet-128.png" class="img-responsive"></li>
                                                    </ul>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-8 padding-right_106">
                                                        <div class="form-group CVV" id="expiration-date">
                                                            <label class="card_number_label">Expires Date</label>
                                                            <select name="select2" id="cardexpiry" class="select_month card-expiry-month" data-stripe="exp-month">
                                                                <option value="01" selected="">January</option>
                                                                <option value="02">February </option>
                                                                <option value="03">March</option>
                                                                <option value="04">April</option>
                                                                <option value="05">May</option>
                                                                <option value="06">June</option>
                                                                <option value="07">July</option>
                                                                <option value="08">August</option>
                                                                <option value="09">September</option>
                                                                <option value="10">October</option>
                                                                <option value="11">November</option>
                                                                <option value="12">December</option>
                                                            </select>
                                                            <select name="select2" id="cardexpiry" class="select_month card-expiry-year" data-stripe="exp-year"></select>
                                                            <script type="text/javascript">
                                                                var select = $(".card-expiry-year"),
                                                                        year = new Date().getFullYear();

                                                                for (var i = 0; i < 12; i++) {
                                                                    select.append($("<option value='" + (i + year) + "' " + (i === 0 ? "selected" : "") + ">" + (i + year) + "</option>"))
                                                                }
                                                            </script>
                                                        </div>
                                                        <label style="display: none;" id="cardexpiry-error" class="custom-error"></label>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="card_number_label">Security Code</label>
                                                        <input type="text" id="cvv" class="form-control-1 car_input_number card-cvc addr-field" placeholder="CVV">
                                                        <label style="display: none;" id="cvv-error" class="custom-error"></label>
                                                    </div>

                                                    <div class="form-group owner col-md-12">
                                                        <label class="card_number_label">Name</label>
                                                        <input type="text" name="cardholdername" id="cardholdername" class="form-control-1 car_input_number card-holder-name addr-field">
                                                        <label style="display: none;" id="cardholdername-error" class="custom-error"></label>
                                                    </div>

                                                    <div class="form-group owner col-md-6">
                                                        <label class="card_number_label">Order Amount</label>
                                                        <input type="text" readonly="" name="amt" id="amt" value="0" class="form-control-1 car_input_number">
                                                        <input type="hidden" id="amt_total" value="0">
                                                    </div>

                                                    <div class="col-md-12">
                                                        <div class="right_aling_card_root_101">
                                                            <label class="regular-checkbox ">
                                                                <input class="checkbox_set" type="checkbox" name="agree" value="1" data-rule-required="true">
                                                                <small></small>
                                                            </label>
                                                            <span>I agree with the <a href="<?php echo base_url() ?>/term_condition" target="_blank">Terms & Conditions.</a></span>
                                                        </div> 
                                                    </div>

                                                </div>
                                                <!--</form>-->

                                            </div>
                                            <div class="col-md-4"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-12" id="pay_by_account" style="display: none">
                                        <div class="color_set_gray deep">
                                            <div class="col-md-12 mt-1">
                                                <table width="100%">
                                                    <tr>
                                                        <td class="text-not"><b>Note: </b></td>
                                                        <td>When you select Pay by Account than after send invoice on mail with Function & Catering accounts details. If your payment approved than after Active your Venue/catering.</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-8">
                                                <label class="lbl_class">Email</label>
                                                <input class="form-control" type="email" value="<?php echo $this->session->userdata('user_email') ?>">
                                            </div>
                                            <div class="col-md-12"><br></div>
                                            <div class="col-md-8">
                                                <div class="right_aling_card_root_101">
                                                    <label class="regular-checkbox ">
                                                        <input class="checkbox_set" type="checkbox" name="agree" value="1" data-rule-required="true">
                                                        <small></small>
                                                    </label>
                                                    <span>I agree with the <a href="<?php echo base_url() ?>/term_condition" target="_blank">Terms & Conditions.<sup style="color: red">*</sup></a></span>
                                                </div>
                                            </div> 
                                        </div>


                                    </div>
                                </div>
                                <input type="button" name="btnsub" id="btnsub" class="action-button float_use" value="Process payment" />
                                <!--<input type="submit" name="submit" id="submit" class="action-button float_use" value="Process payment" />-->
                            </fieldset>
                            <!--last-section-->
                            <!--last-section-->

                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<!-- Modal -->
<?php $this->load->view('models/image_cropping'); ?>
<?php $this->load->view('models/error_show'); ?>
<script>

//jQuery time
    var current_fs, next_fs, previous_fs; //fieldsets
    var left, opacity, scale; //fieldset properties which we will animate
    var animating; //flag to prevent quick multi-click glitches
    $('#header_dy').addClass('add-bg_color');
    $(".next").click(function () {
        if (animating)
            return false;
        animating = true;

        current_fs = $(this).parent();
        next_fs = $(this).parent().next();

        if ($("fieldset").index(next_fs) == 3) {
            var result = save_data(2); // here pass 2 for continue to page screen
            if (!result) {
                animating = false;
                return false;
            }
        }

        if ($("fieldset").index(next_fs) == 1) {
            var htm = '<div class="opening_your_venue_content">Now its time to choose <span class="text_wold_start_contert">the search region.</span></div>';
        } else if ($("fieldset").index(next_fs) == 2) {
            var htm = '<div class="opening_your_venue_content">Now its time to plug in <span class="text_wold_start_contert">all your venue details.</span></div>';
            $('#add_venue_header').css('background-color', '#d8d8d8 !important');
            $('#header_dy').removeClass('add-bg_color');

        } else if ($("fieldset").index(next_fs) == 3) {
            var htm = '<div class="opening_your_venue_content">A final review <span class="text_wold_start_contert">before you go live.</span></div>';
            $('#add_venue_header').css('background-color', '#fff !important');
            $('#header_dy').addClass('add-bg_color');
        } else {
            var htm = '<div class="list_your_venu_content">List your venue for a little as $1 a day.</div><div class="opening_your_venue_content">Opening your venue to <span class="text_wold_start_contert">the world starts here.</span></div>';
        }

        $("#top-txt").html(htm);

        $("html, body").animate({scrollTop: 0}, "slow");

        //activate next step on progressbar using the index of next_fs
        $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

        //show the next fieldset
        next_fs.show();
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
            step: function (now, mx) {
                //as the opacity of current_fs reduces to 0 - stored in "now"
                //1. scale current_fs down to 80%
                //scale = 1 - (1 - now) * 0.

                ;
                //2. bring next_fs from the right(50%)
                left = (now * 50) + "%";
                //3. increase opacity of next_fs to 1 as it moves in
                opacity = 1 - now;
                current_fs.css({
                    'transform': 'scale(' + scale + ')',
                    'position': 'absolute'
                });
                next_fs.css({'left': left, 'opacity': opacity});
            },
            duration: 800,
            complete: function () {
                current_fs.hide();
                animating = false;
            },
            //this comes from the custom easing plugin
            easing: 'easeInOutBack'
        });
    });

    $(".previous").click(function () {
        if (animating)
            return false;
        animating = true;

        current_fs = $(this).parent();
        previous_fs = $(this).parent().prev();

        //de-activate current step on progressbar
        $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

        //show the previous fieldset
        previous_fs.show();
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
            step: function (now, mx) {
                //as the opacity of current_fs reduces to 0 - stored in "now"
                //1. scale previous_fs from 80% to 100%
                //scale = 0.8 + (1 - now) * 0.2;
                //2. take current_fs to the right(50%) - from 0%
                left = ((1 - now) * 50) + "%";
                //3. increase opacity of previous_fs to 1 as it moves in
                opacity = 1 - now;
                current_fs.css({'left': left});
                previous_fs.css({'transform': 'scale(' + scale + ')', 'opacity': opacity});
            },
            duration: 800,
            complete: function () {
                current_fs.hide();
                animating = false;
            },
            //this comes from the custom easing plugin
            easing: 'easeInOutBack'
        });
    });

    $(".first-section").click(function () {
        if (animating)
            return false;
        animating = true;

        current_fs = $("#review_listing").parent();
        previous_fs = $("#review_listing").parent().prev().prev().prev();

        var htm = '<div class="list_your_venu_content">List your venue for a little as $1 a day.</div><div class="opening_your_venue_content">Opening your venue to <span class="text_wold_start_contert">the world starts here.</span></div>';

        $("#top-txt").html(htm);

        //de-activate current step on progressbar
        $("#progressbar li").removeClass("active");

        $("#progressbar li").eq(0).addClass("active");

        //show the previous fieldset
        previous_fs.show();
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
            step: function (now, mx) {
                //as the opacity of current_fs reduces to 0 - stored in "now"
                //1. scale previous_fs from 80% to 100%
                //scale = 0.8 + (1 - now) * 0.2;
                //2. take current_fs to the right(50%) - from 0%
                left = ((1 - now) * 50) + "%";
                //3. increase opacity of previous_fs to 1 as it moves in
                opacity = 1 - now;
                current_fs.css({'left': left});
                previous_fs.css({'transform': 'scale(' + scale + ')', 'opacity': opacity});
            },
            duration: 800,
            complete: function () {
                current_fs.hide();
                animating = false;
            },
            //this comes from the custom easing plugin
            easing: 'easeInOutBack'
        });
        $('#rewiew_listing_handle').val(1);
        RemoveVoucher();
    });

    $(function () {
        $("#addition-area1").chosen();
        load_option('#addition-area1');
    });
</script>

<script >
    $(".phone_no").keyup(function (e) {
   length=$(this).val().length;
   limit=17;
   if(length>limit){
    var strtemp = $(this).val().substr(0,limit);
    $(this).val(strtemp);
    e.preventDefault();
   }
  });
  $(".phone_no").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .   
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 107,109,32,110,57,48]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40) || ( e.keyCode === 107 || e.keyCode === 109 || e.keyCode === 32 || e.keyCode === 57 || e.keyCode === 48 ))  {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }  
    });
</script>


