<?php if($this->session->userdata('user_image')){
    $user_image = $this->session->userdata('user_image');
} else{
     $user_image = base_url() . 'uploads/users/FnC_user_icon.png';
}


    $venue_permission_ary = venue_permission();
    $cater_permission_ary = cater_permission();
   
    $venu_status = isset($venue_permission_ary->bus_auth_status) ? $venue_permission_ary->bus_auth_status : '';
    $cater_status = isset($cater_permission_ary->bus_auth_status) ? $cater_permission_ary->bus_auth_status : '';
    
    $venue_bus_auth_req = isset($venue_permission_ary->bus_auth_req) ? $venue_permission_ary->bus_auth_req : '';
    $cater_bus_auth_req = isset($cater_permission_ary->bus_auth_req) ? $cater_permission_ary->bus_auth_req : '';




?>
<section class="section-1 space_change bg_white" id="header_dy">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 header">
                <div class="navbar-header head_logo" >
                    <!--<button type="button" class="navbar-toggle nv_align" data-toggle="collapse" data-target="#myNavbar" onclick="openNavMenu()">-->
					
					
					<div class="col-xs-4 hidden-md hidden-sm hidden-lg"  style="padding: 0px;">
						<a class="navbar-brand-search hidden-lg hidden-sm hidden-md" onclick="openNav()"><img class="main_logo" src="<?php echo base_url('assets/images/search_icon.svg'); ?>" /></a>
						<a class="navbar-brand hidden-xs" href="<?php echo site_url(); ?>"><img class="main_logo" src="<?php echo base_url('assets/images/fnc_logo.svg'); ?>" /></a>
					</div>
					<div class="col-xs-5 col-sm-12" style="text-align: center;" >
						<a href="<?php echo base_url(''); ?>"><img class="main_logo fnc_mobile_logo" src="<?php echo base_url('assets/images/fnc_mobile_logo.svg'); ?>"></a>
					</div>
					<div class="col-xs-3">
						<button type="button" class="navbar-toggle nv_align" onclick="openNavMenu()">
							<span class="icon-bar"></span>
							<span class="icon-bar"> </span>
							<span class="icon-bar"></span>                        
						</button>
					</div>
                </div>
				
				<div id="myNav" class="overlay">
				<div class="col-xs-4"><a class="navbar-brand-search hidden-lg hidden-sm hidden-md" onclick="openNav()"><img class="main_logo" src="<?php echo base_url('assets/images/search_icon.svg'); ?>" /></a></div>
				<div class="col-xs-4 col-sm-12"><a class="" href="<?php echo site_url(); ?>"><img class="main_logo fnc_mobile_logo" src="<?php echo base_url('assets/images/fnc_mobile_logo.svg'); ?>" /></a></div>
				<div class="col-xs-4" style="padding: 0px;">
				
				<a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><img class="main_logo" src="<?php echo base_url('assets/images/close_icon.svg'); ?>" /></a></div>
  
  <div class="overlay-content col-lg-12 col-md-4 col-sm-4 col-sx-4">
    <!--<p>Search is currently locked while we onboard more venues…</p> -->
	<div class="home-section">
	<div class="home-section-1">
	<form>
  <p>I'm looking for</p>
   <select name="">
  <option value="">Function Spaces</option>
  <option value="">Function Spaces</option>
  <option value="">Function Spaces</option>
  <option value="">Function Spaces</option>
</select> 
  <p>In this area:</p>
  <input type="text" name="" placeholder="Region, Council, Suburb or Post-Code" onfocus="this.placeholder = ''"
onblur="this.placeholder = 'Region, Council, Suburb or Post-Code'">
  <p>On this day:</p>
  <input type="text" name="" placeholder="DD-MM-YYYY" onfocus="this.placeholder = ''"
onblur="this.placeholder = 'DD-MM-YYYY'">
  <p>With this many people:</p>
  <input type="text" name="" placeholder="EG. 50" onfocus="this.placeholder = ''"
onblur="this.placeholder = 'EG. 50'" >
   <button type="button">Search</button> 
</form>
<div class="overlay-content-footer">
<p><a href="<?php echo site_url('privacy_policy'); ?>">Privacy Policy</a></p>
<p><a href="<?php echo site_url('term_condition'); ?>">Terms & Conditions</a></p>
<p><a>&copy; 2018 – Functions and Catering, Australis Pty. Ltd</a></p>
  </div>
  </div>
  <!--<div class="home-section-2">
  <p>Search is currently locked while we onboard more venues….</p>
  <img src="">
  <p>Please check back here <br> 0/0/0</p>
  </div> --> </div>
  <div class="overlay-content-bottom"><p>Developed with <img src="<?php echo base_url('assets/images/love.svg'); ?>"> & <img src="<?php echo base_url('assets/images/coffee.svg'); ?>"> by: <a href="http://yourdevelopmentteam.com.au/" target="blank">Your Development Team</a></p></div>
  </div>
</div>


<div id="myNav1" class="overlay">
				<div class="col-xs-3"><a class="navbar-brand-search hidden-lg hidden-sm hidden-md" onclick="openNav()"><img class="main_logo" src="<?php echo base_url('assets/images/search_icon.svg'); ?>" /></a></div>
				<div class="col-xs-6 col-sm-12" style="text-align: center;"><a class="" href="<?php echo site_url(); ?>"><img class="main_logo fnc_mobile_logo" src="<?php echo base_url('assets/images/fnc_mobile_logo.svg'); ?>" /></a></div>
				<div class="col-xs-3" style="padding: 0px;">
				
				<a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><img class="main_logo" src="<?php echo base_url('assets/images/close_icon.svg'); ?>" /></a></div>
  
  <div class="overlay-content col-lg-12 col-md-4 col-sm-4 col-sx-4">
    <!--<p>Search is currently locked while we onboard more venues…</p> -->
	<div class="home-section">
	<div class="home-section-1">
	 <div class="home-section-2">
  <p>Search is currently locked while <br> we onboard more venues….</p>
  <div class="pos_lock">
  <img src="<?php echo base_url('assets/images/lock.svg'); ?>" id="newdemo1"  class = "CloseLock close_lck" style="display: none;}">
  <img src="<?php echo base_url('assets/images/unlock.svg'); ?>" style="z-index: 9;" class= "OpenLock"> 
  </div>
  <p class="last">Please check back here <br> on : 01/07/2019</p>
  </div> 

  </div>
  </div>
  <div class="overlay-content-bottom"><p>Developed with <img src="<?php echo base_url('assets/images/love.svg'); ?>"> & <img src="<?php echo base_url('assets/images/coffee.svg'); ?>"> by: <a href="http://yourdevelopmentteam.com.au/" target="blank">Your Development Team</a></p></div>
  </div>
</div>


<div id="myNavMenu" class="overlay">
				<div class="col-xs-3"><a class="navbar-brand-search hidden-lg hidden-sm hidden-md" onclick="openNav()"><img class="main_logo" src="<?php echo base_url('assets/images/search_icon.svg'); ?>" /></a></div>
				<div class="col-xs-6 col-sm-12" style="text-align: center;"><a class="" href="<?php echo site_url(); ?>"><img class="main_logo fnc_mobile_logo" src="<?php echo base_url('assets/images/fnc_mobile_logo.svg'); ?>" /></a></div>
				<div class="col-xs-3" style="padding: 0px;">
				
				<a href="javascript:void(0)" class="closebtn" onclick="closeNavMenu()"><img class="main_logo" src="<?php echo base_url('assets/images/close_icon.svg'); ?>" /></a></div>
  
  <div class="overlay-content col-lg-12 col-md-4 col-sm-4 col-sx-4">
    <!--<p>Search is currently locked while we onboard more venues…</p> -->
	<div class="home-section">
	<div class="home-section-1">

	  <p class="footer-menu"><a href="<?php echo site_url('about_us'); ?>">About Us</a></p>
	  <p class="footer-menu"><a href="<?php echo creat_your_listing(); ?>">Create a Listing</a></p>
	  <p class="footer-menu"><a href="<?php echo site_url('web/advertise'); ?>">Advertise</a></p>
	  <p class="footer-menu"><a href="<?php echo site_url('contact_us'); ?>">Contact Us</a></p>
	 <p class="footer-menu"><a href="<?php echo site_url('help'); ?>">Help</a></p>
  
   <a class="call-us-now" href="tel:03 9088 9000">Call Us Now</a> 
</form>
<div class="overlay-content-footer">
<p><a href="<?php echo site_url('privacy_policy'); ?>">Privacy Policy</a></p>
<p><a href="<?php echo site_url('term_condition'); ?>">Terms & Conditions</a></p>
<p><a>&copy; 2018 – Functions and Catering, Australis Pty. Ltd</a></p>
  </div>
  </div>
  <!--<div class="home-section-2">
  <p>Search is currently locked while we onboard more venues….</p>
  <img src="">rivacy Policy
  <p>Please check back here <br> 0/0/0</p>
  </div> --> </div>
  <div class="overlay-content-bottom"><p>Developed with <img src="<?php echo base_url('assets/images/love.svg'); ?>"> & <img src="<?php echo base_url('assets/images/coffee.svg'); ?>"> by: <a href="http://yourdevelopmentteam.com.au/" target="blank">Your Development Team</a></p></div>
  </div>
</div>
  
				
			
     
	 
	 
                <nav class="navbar head_nav">
                    <div class="collapse navbar-collapse menubar" id="myNavbar">
                        <?php
                        $login_user_data = $this->session->all_userdata(); 
                        $login_user_id = isset($login_user_data['user_id'])?$login_user_data['user_id']:'';
                        ?>
                        
                        

                        <ul class="nav navbar-nav navbar-right nvbar_right_add" >
                            <li>
                              <span class="call_ing"><a class="call-us" href="tel:03 9088 9000"><span>Call us on</span> 03 9088 9000</a> </span>
                              <span class="call_ing_two">
                              <div class="float_1">
                                <?php if(!$this->session->userdata('user_email')){ ?>
                                 <a href="<?php echo site_url('user_login'); ?>">Log in</a>
                                <a href="<?php echo site_url('help'); ?>"> Help</a>
                               <a href="<?php echo creat_your_listing(); ?>">Create Profile/Listing</a>

                                 <?php } else { ?>
                                <ul class="float_right">
                                    <?php if($venue_bus_auth_req == 1 ){ 
                                        $url = creat_your_listing();
                                        $request_url=site_url('/request');
                                        if($url == $request_url){?>
                                        <li><a href="#">Create Profile/Listing</a></li>
                                         <?php }else{ ?>
                                          <li><a href="<?php echo creat_your_listing(); ?>">Create Profile/Listing</a></li>
                                          
                                          <?php } 
                                    }else{ ?>
                                  <li><a href="<?php echo creat_your_listing(); ?>">Create Profile/Listing</a></li>
                                  
                                  <?php } ?>
                                  <li><a href="<?php echo site_url('favourite'); ?>"><i class="fa fa-heart-o"></i></a></li>
                                  <li><a href="<?php echo site_url('help'); ?>"> Help</a></li>
                                  <li class="hidden-lg hidden-sm hidden-md"><a href="<?php echo site_url('dashboard'); ?>"> Profile</a></li>
                                  <li class="hidden-lg hidden-sm hidden-md"><a href="<?php echo site_url('user/user_logout'); ?>">Sign out</a></li>
                                  <li class="hidden-xs">
                                    <div class="dropdown">
                                     <img class="img-responsive img_center_header img-circle dropdown-toggle" data-toggle="dropdown" src="<?php echo $user_image ?>">
                                     <ul class="dropdown-menu">
                                       <li class="atfo"><a href="<?php echo site_url('dashboard'); ?>"> Profile</a></li>
                                       <li class="atfo"><a href="<?php echo site_url('user/user_logout'); ?>">Sign out</a></li>
                                     </ul>
                                   </div>
                                 </li>
                               </ul>
                              </div>
                              <?php } ?>
                               
                             
                            </span>
                            </li>

                        </ul>
                   </div>
               </nav>
           </div><!-- col-sm-12 -->
       </div><!-- row -->
   </div><!-- container-fluid -->
</section><!-- section-1 -->



                       <!--  <ul class="nav navbar-nav navbar-right" > -->
                         <!--   <?php if($login_user_id==''){?><li><a class="call-us" href="tel:0300000000"><span>Call us on</span> 03 0000 0000</a></li><?php } ?>  -->
                                <!-- <li><a href="<?php echo site_url('venue/my_venues'); ?>">Your event</a></li> -->
                           <!--     <li><a href="<?php echo site_url('web/help'); ?>">Help</a></li> -->
                              <!--   <?php if(!$this->session->userdata('user_email')){ ?> -->
                            <!--    <li><a href="<?php echo site_url('login/user_login'); ?>">Log in</a></li> -->
                              <!--   <?php } else { ?>
                                 <li class="hidden-lg hidden-sm hidden-md"><a href="<?php echo site_url('dashboard'); ?>"> Profile</a></li>
                                       <li class="hidden-lg hidden-sm hidden-md"><a href="<?php echo site_url('user/user_logout'); ?>">Sign out</a></li>
                                <li class="hidden-xs">
                                  <div class="dropdown">
                                     <img class="img-responsive img_center_header img-circle dropdown-toggle" data-toggle="dropdown" src="<?php echo $user_image ?>">
                                     <ul class="dropdown-menu">
                                       <li class="atfo"><a href="<?php echo site_url('dashboard'); ?>"> Profile</a></li>
                                       <li class="atfo"><a href="<?php echo site_url('user/user_logout'); ?>">Sign out</a></li>
                                   </ul>
                               </div>
                           </li>

                           <?php } ?> -->
                    <!--    </ul> -->
<script>
/*var class_counter = 0;
$(document).ready(function(){
	$(".tc_head").each(function() {
		if(class_counter==0){
			$(this).addClass('home_tc_head');
			return false;
		}
		class_counter++;
	});
}); */
</script>
                        