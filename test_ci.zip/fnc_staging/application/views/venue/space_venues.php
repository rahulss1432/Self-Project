<?php 
    $venue_permission_ary = venue_permission();
    $cater_permission_ary = cater_permission();
   
    $venu_status = isset($venue_permission_ary->bus_auth_status) ? $venue_permission_ary->bus_auth_status : '';
    $cater_status = isset($cater_permission_ary->bus_auth_status) ? $cater_permission_ary->bus_auth_status : '';
    
    $venue_bus_auth_req = isset($venue_permission_ary->bus_auth_req) ? $venue_permission_ary->bus_auth_req : '';
    $cater_bus_auth_req = isset($cater_permission_ary->bus_auth_req) ? $cater_permission_ary->bus_auth_req : '';

 //print_r($venue_permission_ary);echo "<br>";
?>

<link rel="stylesheet" href="<?php echo base_url('assets/css/new-style.css'); ?>">
<script>
 var remove_product = '<?php echo site_url('venue/remove_product'); ?>';
</script>
<section class="my_vene_page_106" style="background-color: #fff !important;">
 <div class="container">
  <div class="row main_row">
   <div class="col-sm-12">
    <div class="col-sm-12 dashboard_row">
     <h4>Dashboard</h4>
 </div>
</div>
<!-- Loading Side Menu -->
<?php $this->load->view('side_menu'); ?>
<div class="col-md-9 col-sm-8">

   <?php $uri = $this->uri->segment(1); ?>

   <div class="tabs_sec1">
    <ul class="bs_tabs">
        <li  class="<?php if(!empty($uri)){ if($uri == 'dashboard'){ echo 'active'; } } ?>" ><a href="<?php echo site_url('dashboard'); ?>">My Profile</a></li>
        <?php if($venue_bus_auth_req == 1){ ?>
                            <li  class=" <?php if(!empty($uri)){ if($uri == 'my_venues'){ echo 'active'; } } ?>" ><a href="<?php echo site_url('my_venues'); ?>">My Venues</a></li>
        <?php } else if($cater_bus_auth_req == 2){  ?>
                <li class="<?php if(!empty($uri)){ if($uri == 'my_catering'){ echo 'active'; } } ?>"><a href="<?php echo site_url('my_catering'); ?>" >My Catering</a></li>
        <?php } else{
        ?>
                <li  class=" <?php if(!empty($uri)){ if($uri == 'my_venues'){ echo 'active'; } } ?>" ><a href="<?php echo site_url('my_venues'); ?>">My Venues</a></li>
                <li class="<?php if(!empty($uri)){ if($uri == 'my_catering'){ echo 'active'; } } ?>"><a href="<?php echo site_url('my_catering'); ?>" >My Catering</a></li>
        <?php
        }?>
    </ul>
</div>
<div class="clearfix"></div>

<div class="fc_mainBox">

<div id="second_part" style="">

    <div class="row">
        <div class="col-sm-12 pd_lr7">
            <div class="ven_hds22">The Vines</div>
        </div>
        <?php 
        if(!empty($venues)) {
			$spaceid = encrypt_decrypt('decrypt',$this->uri->segment(2));
            foreach ($venues as $key => $value) {			
			if($value->fc_id == $spaceid){
				if(!empty($value->spaces)){
					foreach ($value->spaces as $spaces) {
						//print_r($spaces);
						$space_view_id = encrypt_decrypt('encrypt',$spaces->space_id);
						?>
						
						<div class="col-md-3 col-sm-4 pd_lr7 myCol">
							<a href="<?php echo site_url('/edit_space/').$space_view_id;?>" class="space_view">
								<div class="ven_Bx3">
									<?php
									$img_link = base_url('uploads/fc_images/temp') . '/' . $spaces->space_image;
									if (@getimagesize($img_link)) {

									} else {
										$img_link = base_url('assets/images/Small_place_holder.jpg');
									}
									?>
									<div class="venImg" style="background-image: url('<?php echo $img_link; ?>');"></div>
									<h4><?php echo $spaces->space_name; ?></h4>

									<div class="clr_cmn">Spaces</div>
									<p class="minDesc">
									<?php
									$string =  $spaces->space_details;

									if (strlen($string) > 10) {
														// truncate string
										$stringCut = substr($string, 0, 30);
														// make sure it ends in a word so assassinate doesn't become ass...
										$string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
									}
									echo $string;
									?>
									
								</div>
							</a>
						</div> <!-- col-sm-3 ends -->

						<!-- col-sm-3 ends -->
						<?php
					}
				}
			}
		}
	}
?>
<div class="col-md-3 col-sm-4 pd_lr7 myCol">
	<a href="">
		<div class="ven_Bx3">
			<a href="<?php echo site_url('venue/spaces/').$this->uri->segment(2); ?>"> 
				<div class="upld_vnBx">
					<div class="nw_venUPL">
						<i class="fa fa-plus"></i>
					</div>
					<h4>Add a new Space</h4>
				</div>
			</a>
		</div>
	</a>
</div> <!-- col-sm-3 ends -->
</div>
</div>

<!-- row ends -->


</div><!-- fc_mainBox ends -->

</div><!-- col-md-9 col-sm-8 ends -->


</div>
<!-- row -->
</div>
<!-- container -->
</section>
<!--section-das-->
<!-- Modal -->
<div class="modal fade remove_confirmation" id="remove_confirmation" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
 <div class="modal-dialog" role="document">
  <div class="modal-content">
   <div class="modal-header">
    <h5 class="modal-title" id="modalLabel">Confirm Remove</h5>
</div>
<div class="modal-body crop_model_body">
    <p class="content_are">Are you want to sure remove permanently this</p>
    <input type="hidden" id="remove_id">
    <input type="hidden" id="remove_cnt">
</div>
<div class="modal-footer_1">
    <button id="remove_confirmed" class="btn btn-primary but_crope Confirm_button" type="button">Confirm</button>
    <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">Cancel</button>
</div>
</div>
</div>
</div>
<!-- remove venue modal -->
<script type="text/javascript" src="<?php echo base_url('assets/js/custom/function.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/plugins/bootbox/bootbox.js'); ?>"></script>
