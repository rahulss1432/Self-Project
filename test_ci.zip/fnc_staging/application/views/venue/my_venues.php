<?php
$venue_permission_ary = venue_permission();
$cater_permission_ary = cater_permission();

$venu_status = isset($venue_permission_ary->bus_auth_status) ? $venue_permission_ary->bus_auth_status : '';
$cater_status = isset($cater_permission_ary->bus_auth_status) ? $cater_permission_ary->bus_auth_status : '';

$venue_bus_auth_req = isset($venue_permission_ary->bus_auth_req) ? $venue_permission_ary->bus_auth_req : '';
$cater_bus_auth_req = isset($cater_permission_ary->bus_auth_req) ? $cater_permission_ary->bus_auth_req : '';

//print_r($venue_permission_ary);echo "<br>";
?>

<link rel="stylesheet" href="<?php echo base_url('assets/css/new-style.css'); ?>">
<script>
    var remove_product = '<?php echo site_url('venue/remove_product'); ?>';
</script>
<section class="my_vene_page_106" style="background-color: #fff !important;">
    <div class="container">
        <div class="row main_row">
            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>
            <!-- Loading Side Menu -->
            <?php  $this->load->view('side_menu'); ?>
            <div class="col-md-9 col-sm-8">
                <?php $uri = $this->uri->segment(1); ?>
                <div class="tabs_sec1">
                    <ul class="bs_tabs">
                        <li  class="<?php
                        if (!empty($uri)) {
                            if ($uri == 'dashboard') {
                                echo 'active';
                            }
                        }
                        ?>" ><a href="<?php echo site_url('dashboard'); ?>">My Profile</a></li>

                        <!--<li  class=" <?php
                        if (!empty($uri)) {
                            if ($uri == 'my_venues') {
                                echo 'active';
                            }
                        }
                        ?>" ><a href="<?php echo site_url('my_venues'); ?>">My Venues</a></li>
                        <li class="<?php
                        if (!empty($uri)) {
                            if ($uri == 'my_catering') {
                                echo 'active';
                            }
                        }
                        ?>"><a href="<?php echo site_url('my_catering'); ?>" >My Catering</a></li>-->
                        <?php if ($venue_bus_auth_req == 1) { ?>
                            <li  class=" <?php
                            if (!empty($uri)) {
                                if ($uri == 'my_venues') {
                                    echo 'active';
                                }
                            }
                            ?>" ><a href="<?php echo site_url('my_venues'); ?>">My Venues</a></li>        
                                 <?php
                             }
                             if ($cater_bus_auth_req == 2) {
                                 ?>
                            <li class="<?php
                            if (!empty($uri)) {
                                if ($uri == 'my_catering') {
                                    echo 'active';
                                }
                            }
                            ?>"><a href="<?php echo site_url('my_catering'); ?>" >My Catering</a></li>
                            <?php } ?> 

                    </ul>
                </div>
                <div class="clearfix"></div>

                <div class="fc_mainBox">
                    <div id="part_one">

                        <div class="row">
                            <?php						
                            if (!empty($venues)) {
                                foreach ($venues as $key => $value) {
                                    ?> 
                                    <div class="col-md-3 col-sm-4 pd_lr7 myCol">
                                        <a href="<?php echo site_url('view_venue/') . encrypt_decrypt('encrypt', $value->fc_id); ?>">
                                            <div class="ven_Bx3">
                                                <?php
                                                $img_link = base_url('uploads/fc_images') . '/' . $value->fc_listing_picture;
                                                if (@getimagesize($img_link)) {
                                                    
                                                } else {
                                                    $img_link = base_url('assets/images/Small_place_holder.jpg');
                                                }
                                                $date = date('Y-m-d');
                                                $val = date('Y-m-d', strtotime($value->fc_valid_upto));
                                                ?>
                                                <div class="venImg" style="background-image: url(<?php echo $img_link; ?>);"></div>
                                                <h4><?php echo $value->fc_business_name; ?></h4>
                                                <div class="clr_cmn">Venue</div>
                                                <p class="minDesc"><?php
                                                    $string = $value->fc_overview;

                                                    if (strlen($string) > 10) {
                                                        // truncate string
                                                        $stringCut = substr($string, 0, 30);
                                                        // make sure it ends in a word so assassinate doesn't become ass...
                                                        $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                                    }
                                                    echo $string;
                                                    ?></p>

                                                <?php if ($val < $date) { ?>
                                                    <small>Current plan expire on <?php echo expireFormted($value->fc_valid_upto); ?></small>
                                                <?php } else { ?>
                                                    <small>Current plan expire on <?php echo expireFormted($value->fc_valid_upto); ?></small>
                                                <?php } ?>
                                                
                                                <p class="spc_a">

                                                    <?php
                                                    if (!empty($value->spaces)) {
                                                        ?>
                                                        <a href="<?php echo site_url('space_venue/') . encrypt_decrypt('encrypt', $value->fc_id); ?>" class="spaces_details" space_cnt="<?php echo count($value->spaces); ?> " space_id="<?php echo encrypt_decrypt('encrypt', $value->fc_id); ?>">Spaces <span>
                                                                <?php echo count($value->spaces); ?></span>  </a> <?php
                                                    } else {
                                                        ?>
                                                        <a href="<?php echo site_url('space_venue/') . encrypt_decrypt('encrypt', $value->fc_id); ?>" class="spaces_details" space_cnt="0" space_id="<?php echo encrypt_decrypt('encrypt', $value->fc_id); ?>">Spaces <span>
                                                                <?php echo "0"; ?></span> </a><?php }
                                                            ?> 
                                                </p>

                                            </div>
                                        </a>
                                    </div> 
                                    <?php
                                }
                            }
                            ?>
                            <div class="col-md-3 col-sm-4 pd_lr7 myCol">   
                                <a href="<?php echo site_url('add_venue/?') . 'p1=business_details&b1=company_details' ?>"> 
                                    <div class="upld_vnBx">
                                        <div class="nw_venUPL">
                                            <i class="fa fa-plus"></i>
                                        </div>
                                        <h4>Add new venue</h4>
                                    </div>
                                </a>
                            </div><!-- col-sm-3 ends -->
                        </div><!-- row ends -->
						
						<!-- Pending Approvel list venues start -->
						<div class="row">
                            <?php if (!empty($pending)) { ?>
                                <div class="col-sm-12 pd_lr7">
                                    <div class="ven_hds22">Pending Approval</div>
                                </div>
								<?php foreach ($pending as $key => $value) {  ?> 
                                    <div class="col-md-3 col-sm-4 pd_lr7 myCol">
                                        
                                            <div class="ven_Bx3">
                                                <?php
                                                $img_link = base_url('uploads/fc_images') . '/' . $value->fc_listing_picture;
                                                if (@getimagesize($img_link)) {
                                                    
                                                } else {
                                                    $img_link = base_url('assets/images/Small_place_holder.jpg');
                                                }
                                                $date = date('Y-m-d');
                                                $val = date('Y-m-d', strtotime($value->fc_valid_upto));
                                                ?>
                                                <div class="venImg" style="background-image: url(<?php echo $img_link; ?>);"></div>
                                                <h4><?php echo $value->fc_business_name; ?></h4>
                                                <div class="clr_cmn">Venue</div>
                                                <p class="minDesc"><?php
                                                    $string = $value->fc_overview;

                                                    if (strlen($string) > 10) {
                                                        // truncate string
                                                        $stringCut = substr($string, 0, 30);
                                                        // make sure it ends in a word so assassinate doesn't become ass...
                                                        $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                                    }
                                                    echo $string;
                                                    ?></p>

                                                <?php if ($val < $date) { ?>
                                                    <small>Current plan expire on <?php echo expireFormted($value->fc_valid_upto); ?></small>
                                                <?php } else { ?>
                                                    <small>Current plan expire on <?php echo expireFormted($value->fc_valid_upto); ?></small>
                                                <?php } ?>
                                                
                                                <p class="spc_a">

                                                    <?php
                                                    if (!empty($value->spaces)) {
                                                        ?>
                                                        <a href="#" class="spaces_details" space_cnt="<?php echo count($value->spaces); ?> " space_id="<?php echo encrypt_decrypt('encrypt', $value->fc_id); ?>">Spaces <span>
                                                                <?php echo count($value->spaces); ?></span>  </a> <?php
                                                    } else {
                                                        ?>
                                                        <a href="#" class="spaces_details" space_cnt="0" space_id="<?php echo encrypt_decrypt('encrypt', $value->fc_id); ?>">Spaces <span>
                                                                <?php echo "0"; ?></span> </a><?php }
                                                            ?> 
                                                </p>

                                            </div>
                                        
                                    </div> 
                                    <?php
                                }                            
                            } ?>						
						</div><!-- row ends -->
						<!-- Pending Approvel list venues end -->

                        <div class="row">
                            <?php if (!empty($my_draft)) { ?>

                                <div class="col-sm-12 pd_lr7">
                                    <div class="ven_hds22">In Progress</div>
                                </div>			 
                                <?php foreach ($my_draft as $key => $value) { ?>
                                    <div class="col-md-3 col-sm-4 pd_lr7 myCol">
                                        <a href="<?php echo base_url('add_venue/?p1=business_details&b1=company_details&f1=') . encrypt_decrypt('encrypt', $value->fc_id); ?>">
                                            <div class="ven_Bx3">
                                                <?php
                                                $img_link = base_url('uploads/fc_images') . '/' . $value->fc_listing_picture;
                                                if (@getimagesize($img_link)) {
                                                    
                                                } else {
                                                    $img_link = base_url('assets/images/Small_place_holder.jpg');
                                                }
                                                ?>

                                                <div class="venImg" style="background-image: url('<?php echo $img_link; ?>');"></div>
                                                <h4>Venue info ??</h4>

                                                <div class="clr_cmn">Venue</div>
                                                <p class="minDesc"><?php echo $value->fc_business_name; ?></p>

                                                <?php
                                                $percent = getVenuePercent($value->fc_id);
                                                ?>
                                                <div class="progress venProg">
                                                    <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percent; ?>%">  
                                                    </div>
                                                </div><!-- progress ends -->

                                                <a href="<?php echo base_url('add_venue/?p1=business_details&b1=company_details&f1=') . encrypt_decrypt('encrypt', $value->fc_id); ?>" class="btn venBtn2">Continue</a>

                                                <a space_id="<?php echo encrypt_decrypt('encrypt', $value->fc_id); ?>" class="btn venBtn2 remove_venue" id="">Remove</a>
                                            </div>
                                        </a>
                                    </div> <!-- col-sm-3 ends -->

                                    <!-- col-sm-3 ends -->
                                    <?php
                                }
                            }
                            ?>
                        </div>
                    </div>
					
					
					
					
					
                    <div id="second_part" style="display:none">

                        <div class="row">


                            <div class="col-sm-12 pd_lr7">
                                <div class="ven_hds22">The Vines</div>
                            </div>
                            <?php
                            if (!empty($venues)) {
                                foreach ($venues as $key => $value) {

                                    if (!empty($value->spaces)) {
                                        foreach ($value->spaces as $spaces) {

                                            // print_r($spaces);
                                            ?>

                                            <div class="col-md-3 col-sm-4 pd_lr7 myCol">
                                                <a href="">
                                                    <div class="ven_Bx3">
                                                        <?php
                                                        $img_link = base_url('uploads/fc_images') . '/' . $spaces->space_image;
                                                        if (@getimagesize($img_link)) {
                                                            
                                                        } else {
                                                            $img_link = base_url('assets/images/Small_place_holder.jpg');
                                                        }
                                                        ?>

                                                        <div class="venImg" style="background-image: url('<?php echo $img_link; ?>');"></div>
                                                        <h4><?php echo $spaces->space_name; ?></h4>

                                                        <div class="clr_cmn">Spaces</div>
                                                        <p class="minDesc"><?php echo $spaces->space_details; ?></p>



                                                    </div>
                                                </a>
                                            </div> <!-- col-sm-3 ends -->

                                            <!-- col-sm-3 ends -->
                                            <?php
                                        }
                                    }
                                }
                            }
                            ?>
                        </div>
                    </div>

                    <!-- row ends -->


                </div><!-- fc_mainBox ends -->

            </div><!-- col-md-9 col-sm-8 ends -->


        </div>
        <!-- row -->
    </div>
    <!-- container -->
</section>
<!--section-das-->
<!-- Modal -->
<div class="modal fade remove_confirmation" id="remove_confirmation" aria-labelledby="modalLabel" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalLabel">Confirm Remove</h5>
            </div>
            <div class="modal-body crop_model_body">
                <p class="content_are">Are you sure you want to remove your Venue? Removing your Venue is permanent.</p>
                <input type="hidden" id="remove_id">
                <input type="hidden" id="remove_cnt">
            </div>
            <div class="modal-footer_1">
                <button id="remove_confirmed" class="btn btn-primary but_crope Confirm_button" type="button">Yes</button>
                <button type="button" class="btn btn-default but_crope cancel_button" data-dismiss="modal">No</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="<?php echo base_url('assets/js/custom/function.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/plugins/bootbox/bootbox.js'); ?>"></script>
<script type="text/javascript">
    $(function () {
        $(".remove_venue").click(function () {
            var space_id = $(this).attr('space_id');
            console.log(space_id);
            $('#remove_id').val(space_id);
            $('#remove_confirmation').modal('show');
        });
        $("#remove_confirmed").click(function () {
            //$('#remove_confirmation').modal('hide');
            remove_id = $('#remove_id').val();
            var space = true;
            var remove_product = '<?php echo site_url() ?>Venue/remove_venue';
            $.ajax({
                url: remove_product,
                method: 'POST',
                dataType: 'json',
                data: {venue_id: remove_id, space: space},
                success: function (data) {
                    if (data.status) {
                        $('#remove_confirmation').modal('hide');
                        location.reload();
                    }
                }
            });
        });
    });
</script>