<div class="div2clone">

    <div class="col-sm-12 profile_row fountion_7">
        <div class="row top_background text-left set_new_102">
            <h4 class="h4-title">Space <?php echo $num_word; ?></h4>
        </div>
        <div class="row margin_top_and_bottom_user">
            <div class="col-md-12 margin_set_input text-left">
                <label class="lbl_class">Space name</label>
                <input type="text" class="form-control fm-field" name="space_name<?php echo $num; ?>" data-rule-required="true">
            </div>
             <div class="margin_set_input text-left">
                <div class="col-md-6 margin_set_input ">
                    <label class="lbl_class">Minimum guest numbers</label>
                    <input id="min_guest_<?php echo $num; ?>" type="text" maxlength="5" class="form-control fm-field number_allow_only" name="space_min_guest<?php echo $num; ?>" data-rule-lessThan="#max_guest_<?php echo $num; ?>" data-rule-number="true">
                </div>
                <div class="col-md-6 margin_set_input">
                    <label class="lbl_class">Maximum guest numbers</label>
                    <input id="max_guest_<?php echo $num; ?>" type="text" maxlength="5" class="form-control fm-field number_allow_only" name="space_max_guest<?php echo $num; ?>" data-rule-greaterThan="#min_guest_<?php echo $num; ?>" data-rule-number="true">
                </div>
            </div>

            <div class="col-md-12 text-left margin_set_input">
                <label class="text-left">Details</label>
                <textarea rows="4" data-rule-maxlength="1200" maxlength="1200" class="form-control overview_textarea textare_root fm-field" name="space_details<?php echo $num; ?>" data-rule-required="true" placeholder="This is a short introductory overview that describes your venue. &#10;Max 1200 words."></textarea>
            </div>

            <div class="col-md-12 text-left margin_set_input">
                <div class="ulpading_img_size_3">
                    <img id="show_image_<?php echo $img_id; ?>" img-id="<?php echo $img_id; ?>"  class="ven_img_106 dropzone" src="" style="display:none" />
                    <div class="ezdz-dropzone">
                        <div class="for_plus_sign">Drag Files Here</div>
                        <input onclick="this.value = null;" type="file" class="file-selector fm-field image_selector" data-id="<?php echo $img_id; ?>" id="image_selector_<?php echo $img_id; ?>" name="space_image<?php echo $num; ?>">
                    </div>
                    <input type="hidden" name="dimesion_image_<?php echo $img_id; ?>" id="dimesion_image_<?php echo $img_id; ?>" value="0"> 
                    <img class="remove_image" onclick="removeImage(3, '0', 1, <?php echo $img_id; ?>)" src="<?php echo base_url(REMOVE_IMAGE); ?>">

                </div>

                <div class="ulpading_img_size_3_1">
                    <div class="row">
                        <span id="fileselector">
                            <label ant-id="<?php echo $img_id; ?>" class="upload-button_new after_102">
                                
                                <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                            </label>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-12 profile_row fountion_5">
        <div class="row top_background text-left set_new_102">
            <h4 class="h4-events">Space <?php echo $num_word; ?> - Event types</h4>
        </div>
        <div class="row margin_top_row_second_106">
            <div class="form-check form-check-inline">

                <?php
                if (!empty($event_types)) {
                    foreach ($event_types as $e_type) {
                        ?>
                        <div class="col-md-6 text-left pass">
                            <label class="set_label_venu">
<label class="regular-checkbox pull-left r-p-n-501">
                                    <input type="checkbox" name="space_events<?php echo $num; ?>[]" value="<?php echo $e_type->id; ?>">
                                    <small></small>
                                </label>
                                <div class="dolor_icon size_set_ic">
                                    <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types').'/'.$e_type->image; ?>">
                                </div>
                                <span><?php echo $e_type->name; ?></span>
                               
                                <!--<input class="checkbox_set" type="checkbox" name="space_events<?php //echo $num; ?>[]" value="<?php //echo $e_type->id; ?>">-->
                            </label>
                        </div>
                        <?php
                    }
                }
                ?>

            </div>
        </div>
    </div>

    <div class="col-sm-12 profile_row fountion_5">
        <div class="row top_background text-left set_new_102">
            <h4 class="h4-facilities">Space <?php echo $num_word; ?> - Facilities</h4>
        </div>
        <div class="row margin_top_row_second_106">
            <div class="form-check form-check-inline">
                <?php
                if (!empty($facilities)) {
                    foreach ($facilities as $f_val) {
                        ?>
                        <div class="col-md-6 text-left pass">
                            <label class="set_label_venu">
 <label class="regular-checkbox pull-left r-p-n-501">
                                    <input type="checkbox" type="checkbox" name="space_facilities<?php echo $num; ?>[]" value="<?php echo $f_val->id; ?>">
                                    <small></small>
                                </label>
                                <div class="dolor_icon size_set_ic">
                                    <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types').'/'.$f_val->image; ?>">
                                </div>
                                <span><?php echo $f_val->name; ?></span>
                               
                                <!--<input class="checkbox_set" type="checkbox" type="checkbox" name="space_facilities<?php //echo $num; ?>[]" value="<?php //echo $f_val->id; ?>">-->
                            </label>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>

    <div class="col-sm-12 profile_row fountion_5">
        <div class="row top_background text-left set_new_102">
            <h4 class="h4-features">Space <?php echo $num_word; ?> - Features</h4>
        </div>
        <div class="row margin_top_row_second_106">
            <div class="form-check form-check-inline">

                <?php
                if (!empty($features)) {
                    foreach ($features as $feat_val) {
                        ?>
                        <div class="col-md-6 text-left pass">
                            <label class="set_label_venu">
 <label class="regular-checkbox pull-left r-p-n-501">
                                    <input type="checkbox" type="checkbox" type="checkbox" name="space_features<?php echo $num; ?>[]" value="<?php echo $feat_val->id; ?>">
                                    <small></small>
                                </label>
                                <div class="dolor_icon size_set_ic"><img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types').'/'.$feat_val->image; ?>"></div>
                                <span><?php echo $feat_val->name; ?></span>
                              
                                <!--<input class="checkbox_set" type="checkbox" type="checkbox" name="space_features<?php //echo $num; ?>[]" value="<?php //echo $feat_val->id; ?>">-->
                            </label>
                        </div>
                        <?php
                    }
                }
                ?>

            </div>
        </div>
    </div>

</div>