<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Function & Catering </title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo base_url('admin-assets/vendor/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
        <link href="<?php echo base_url('admin-assets/vendor/bootstrap/css/login_style.css'); ?>" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="<?php echo base_url('admin-assets/vendor/metisMenu/metisMenu.min.css'); ?>" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?php echo base_url('admin-assets/dist/css/sb-admin-2.css'); ?>" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="<?php echo base_url('admin-assets/vendor/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css">

        <!--Custom P-->
        <script src="<?php echo base_url('admin-assets/js/jquery-3.2.1.min.js'); ?>"></script>
        <script src="<?php echo base_url('admin-assets/js/jquery.validate.min.js'); ?>"></script>

        <script src='https://www.google.com/recaptcha/api.js'></script><!--reCaptcha API-->

        <script src="<?php echo base_url('admin-assets/js/custom/admin-login.js'); ?>"></script>

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>


    <body class="body_107">
        <div class="login-page_107">
            <img  class="logo_login" src="<?php echo base_url('assets/images/fnc_logo.svg') ?>">
            <div class="form_107">
                <?php if ($this->session->flashdata('error')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Error!</strong> <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php endif; ?>
                <form class="login-form_107" role="form" id="frm-login" action="<?php echo site_url('login/perform_adlogin'); ?>" method="post">
                    <input  placeholder="E-mail" name="email" type="email"  value="<?php
                    if (get_cookie('email')) {
                        echo get_cookie('email');
                    }
                    ?>"  autofocus />
                    <input  placeholder="Password" name="password" type="password"  value="<?php
                    if (get_cookie('password')) {
                        echo get_cookie('password');
                    }
                    ?>" />
                    <div style="clear:both;"></div>
                    <p class="aling_set_107">
                        <label class="remeber_me_107">Remember Me
                            <input type="checkbox"  name="remember" id="rememberme" value="1" <?php if (get_cookie('email')) { ?> checked <?php } ?>/>
                            <span class="checkmark"></span>
                        </label>
                    </p>
                    <p class="aling_set_107">
                        <label class="captch_content">Captcha</label>
                    <div class="g-recaptcha" data-sitekey="<?php echo CAPTCHA_SITE_KEY ?>"></div>
                    <input type="hidden" class="hiddenRecaptcha required" name="hiddenRecaptcha" id="hiddenRecaptcha">
                    <label id="hiddenRecaptcha-error" style="display: none;" class="error" for="hiddenRecaptcha"></label>
                    </p>
                    <button type="submit" name="submit" value="Login">login</button>
                    <input type="hidden" />

<!--   <p class="message_107">Not registered? <a href="#">Create an account</a></p> -->
                </form>

            </div>
        </div>
    </body>


    <!-- jQuery -->
    <!--<script src="../vendor/jquery/jquery.min.js"></script>-->

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url('admin-assets/vendor/bootstrap/js/bootstrap.min.js'); ?>"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url('admin-assets/vendor/metisMenu/metisMenu.min.js'); ?>"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url('admin-assets/dist/js/sb-admin-2.js'); ?>"></script>



</html>
