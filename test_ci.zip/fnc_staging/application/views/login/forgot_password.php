<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<section>	
    <div class="container-fluid">		
        <div class="row">
            <img src="<?php echo base_url('assets/images/login_banner.png'); ?>" class="img-responsive bann_img" alt=""/>			
        </div>
    </div>
</section>

<section class="section_login">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="log_head">
                    Forgot password
                </div>
            </div>
        </div>
        <div class="clarfix"></div>
        <div class="row">

            <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                <div class="profile_row c_us_content_in set_box_shadow_106">
                    <div class="row">
                        <div class="col-md-12">
                            <?php if ($this->session->flashdata('error')): ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Error!</strong> <?php echo $this->session->flashdata('error'); ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($this->session->flashdata('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo $this->session->flashdata('message'); ?>
                                </div>
                            <?php endif; ?>

                            <form action="<?php echo site_url('Login/forgot_password'); ?>" onclick="Forget_validate();" id="ForgetPassword" method="POST">
                                <div class="col-md-12 margin_set_input">                
                                    <label class="lbl_class">Email</label>
                                    <input name="email" type="text" data-rule-required="true" class="form-control" value="<?php echo set_value('email'); ?>" required="">
                                </div>

                                <div class="col-md-12 margin_set_input login-remember">                
                                    <label class="lbl_class g-recaptcha" data-sitekey="<?php echo CAPTCHA_SITE_KEY?>" ></label>
                                </div>

                                <div class="col-md-12">
                                    <p class="login-submit">
                                        <input type="submit" class="button_login_submit button button-primary" name="forgot_password" value="Request" />
                                    </p>
                                </div>

                            </form>
                            <div class="clearfix"></div>
                            <div class="col-md-12 text-right hover_register_106">
                                <p>Don't have an account? <a href="<?php echo site_url('user_registration'); ?>"><span class="line_set">Register</span></a><a class="mar_r_201" href="<?php echo site_url('user_login')?>">
                                    <span class="line_set">Login here</span></a></p>
                            </div>
                        </div><!-- col-md-6 -->
                    </div>
                </div>
            </div><!-- col-sm-6 col-sm-offset-3  -->
        </div><!-- row -->
    </div><!-- container -->
</section>
<script>
    function Forget_validate() {
        $("#ForgetPassword").validate({
            rules: {
                email: {
                    required: true,
                    email: true,
                    remote: {
                        url: base_url + "Login/email_existance", type: "GET"
                    }
                }
            }, messages: {
                email: {
                    required: "Please enter your email",
                    email: "Please enter valid email",
                    remote: "This Email not exist"
                }
            }
        });
    }
</script>
