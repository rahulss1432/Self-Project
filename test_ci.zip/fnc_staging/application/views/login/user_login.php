
<?php
$referral = explode('/', $this->agent->referrer());
$ref = (in_array('verifyaccount', $referral)) ? '' : $this->agent->referrer()
?>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<!-- <section class="details_section1">	
    <div class="container-fluid">		
        <div class="row">
            <img src="<?php echo base_url('assets/images/login_banner.png'); ?>" class="img-responsive bann_img" alt=""/>			
        </div>
    </div>
</section>
-->

<section class=" home_tc_head reg_col">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="log_head">
                    Log In
                </div>
            </div>
        </div>
        <div class="clarfix"></div>
        <div class="row">

            <div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                <div class="profile_row c_us_content_in set_box_shadow_106">
                    <div class="row">
                        <div class="col-md-12">
                            <?php if ($this->session->flashdata('error')): ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Error!</strong> <?php echo $this->session->flashdata('error'); ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($this->session->flashdata('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo $this->session->flashdata('message'); ?>
                                </div>
                            <?php endif; ?>

                            <form action="<?php echo site_url('Login/check_login'); ?>" onclick="login_validate();" id="loginForm" method="POST">

                                <div class="col-md-12 col-sm-12 col-xs-12 nw_formGroup">
                                    <div class="fielDBox_22">               
                                        <label class="fielLabel">Email:</label>
                                        <input name="email" type="text" class="form-control fielInp" value="<?php
                                        if (get_cookie('email')) {
                                            echo get_cookie('email');
                                        }
                                        ?>"  required="" placeholder="Enter Email Id" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email Id'">
                                    </div> 
                                </div>

                                <div class="col-md-12 col-sm-12 col-xs-12 nw_formGroup">
                                    <div class="fielDBox_22">               
                                        <label class="fielLabel">Password:</label>
                                        <input name="password" type="password" class="form-control fielInp" value="<?php
                                        if (get_cookie('password')) {
                                            echo get_cookie('password');
                                        }
                                        ?>" required="" placeholder="Enter Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Password'">
                                    </div> 
                                </div>

                                <!-- <div class="col-md-12 margin_set_input">                
                                    <label class="lbl_class">Email:</label>
                                    <input name="email" type="text" class="form-control" value="<?php echo set_value('email'); ?>"  required="" placeholder="Enter Email Id" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email Id'">

                                </div> -->
                                <!--  <div class="col-md-12 margin_set_input">                
                                     <label class="lbl_class">Password:</label>
                                     <input name="password" type="password" class="form-control" value="<?php echo set_value('password'); ?>" required="" placeholder="Enter Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Password'">
                                 </div> -->

                                <div class="col-md-6 col-sm-6 col-xs-6 login-remember">
                                    <label class="regular-checkbox pull-left" style="" >

                                        <input  type="checkbox" name="remember" id="rememberme" value="1" <?php if (get_cookie('email')) { ?> checked <?php } ?>/>
                                        <small></small>
                                    </label>

                                    <span class="pull-left  details_section2"><img src="<?php echo base_url('assets'); ?>/images/11.Radio-button-unselected (1).svg"> Remember Me</span>
                                    <!--<label class="pull-left  details_section1"><span> Remember Me</span></label>-->
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-6 text-right ">
                                    <a class="hover_set_for forgotPass" href="<?php echo site_url('Login/forgot_password'); ?>">Forgot password?</a>
                                </div>
                                <?php if (CAPTCHA_SHOW) { ?>
                                    <div class="clearfix"></div>
                                    <!-- <div class="col-md-12 margin_set_input login-remember details_section1"> --> 
                                    <div class="col-md-12 col-sm-12 col-xs-12 margin_set_input captcha_dv login-remember"> 								
                                        <label class="lbl_class g-recaptcha" data-sitekey="<?php echo CAPTCHA_SITE_KEY ?>" ></label>
                                        <input type="hidden" name="referrer" value="<?php echo $ref; ?>">
                                    </div>
                                <?php } ?>
                                <div class="clearfix"></div>
                                <div class="col-md-12 col-sm-12 col-xs-12 hide_INDesk">
                                    <p class="login-submit">
                                        <input type="submit" class="button_login_submit button button-primary btn-block" name="user_login" value="Log In" />
                                        <input type="hidden" />
                                    </p>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="social-login">
                                        <div class="social-login-connect">Login Using:</div>

                                        <div class="social-login-provider-list details_section1">
                                            <a class="social-login-provider-facebook" href="<?php echo $facebbok_url ?>"> <span class="facebook-button"><i class="fa fa-facebook"></i> <span>Facebook</span></span>
                                            </a>
                                            <!--<a href="<?php //echo $gmail_url; ?>"> <span class="facebook-button-1"><i class="fa fa-google-plus"></i> <span>Google plus</span></span>-->
                                            <a href="<?php echo $gmail_url; ?>"> <span class="facebook-button-1"><i class="fa fa-google"></i> <span>Google</span></span>
                                            </a>
                                        </div>
                                        <div class="social-login-provider-list details_section2">
                                            <a class="social-login-provider-facebook" href="<?php echo $facebbok_url ?>"> <span class="facebook-button"><img src="<?php echo base_url('assets'); ?>/images/13.Facebook-logo-new.svg"></span>
                                            </a>

                                            <a href="<?php echo $gmail_url; ?>"> <span class="facebook-button-1"><img src="<?php echo base_url('assets'); ?>/images/14.Googlelogo.svg"></span>
                                            </a>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-md-12  hover_register_106">
                                    <p>Don't have an account yet? <a href="<?php echo site_url('user_registration'); ?>"><span class="line_set">Register Now</span></a></p>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 hide_INMB">
                                    <p class="login-submit">
                                        <input type="submit" class="button_login_submit button button-primary btn-block" name="user_login" value="Log In" />
                                        <input type="hidden" />
                                    </p>
                                </div>
                            </form>
                        </div><!-- col-md-6 -->
                    </div>
                </div>
            </div><!-- col-sm-6 col-sm-offset-3  -->
        </div><!-- row -->
    </div><!-- container -->
</section>

<section class="section-7 hidden-md hidden-sm hidden-lg bg_white">
    <div class="container inspiration_container">
        <div class="row add_back home-row-add-back">
            <hr class="border-line">
            <div class="col-sm-12">
                <div class="row">
                    <div class="col-sm-12 hidden-xs">                   
                        <a href="#" class="webAdvertisment" target="_blank">
                            <img src="<?php echo base_url('assets'); ?>/images/glenmorangle_add_700X87.jpg">
                        </a>  
                    </div> 
                    <div class="col-md-12 hidden-lg hidden-md hidden-sm" style="display: none;">                   
                        <a href="#" class="webAdvertisment" target="_blank">
                            <img src="<?php echo base_url('assets'); ?>/images/img_advet_singalvenus.jpg">
                        </a>  
                    </div> 
                </div>
            </div>
        </div>
    </div>
</section>
<script>
    $(document).ready(function () {
        if ($('#rememberme').is(':checked')) {
            $(".pull-left.details_section2 img").attr('src', "<?php echo base_url('assets'); ?>/images/12.Radio-button-selected.svg");
        }
        $('#rememberme').click(function () {
            if ($('#rememberme').is(':checked')) {
                $(".pull-left.details_section2 img").attr('src', "<?php echo base_url('assets'); ?>/images/12.Radio-button-selected.svg");
            } else {
                $(".pull-left.details_section2 img").attr('src', "<?php echo base_url('assets'); ?>/images/11.Radio-button-unselected (1).svg");
            }
        });
    });
</script>