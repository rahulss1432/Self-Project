<section class="section-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 header">
                <div class="navbar-header head_logo" >
                    <button type="button" class="navbar-toggle nv_align" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"> </span>
                        <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand" href="<?php echo site_url(); ?>"><img class="main_logo" src="<?php echo base_url('assets/images/Functions_LogoFandC.png'); ?>" /></a>
                </div>
                <nav class="navbar head_nav">
                    <div class="collapse navbar-collapse menubar" id="myNavbar">
                        <ul class="nav navbar-nav navbar-right" >
                            <li><a class="call-us" href="tel:0300000000"><span>Call us on</span> 03 0000 0000</a></li>
                            <li><a href="#">Your Favorites</a></li>
                            <li><a href="#">Help</a></li>
                            <li><a href="#">Log in</a></li>
                        </ul>
                    </div>
                </nav>
            </div><!-- col-sm-12 -->
        </div><!-- row -->
    </div><!-- container-fluid -->
</section><!-- section-1 -->