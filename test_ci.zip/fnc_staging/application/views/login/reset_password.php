<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<section>	
    <div class="container-fluid">		
        <div class="row">
            <img src="<?php echo base_url('assets/images/login_banner.png'); ?>" class="img-responsive bann_img" alt=""/>			
        </div>
    </div>
</section>

<section class="section_login">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="log_head">
                    Reset your password here
                </div>
            </div>
        </div>
        <div class="clarfix"></div>
        <div class="row">

            <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                <div class="profile_row c_us_content_in set_box_shadow_106">
                    <div class="row">
                        <div class="col-md-12">


                            <form action="<?php echo site_url('Login/reset_password'); ?>" id="ResetPassword" onclick="reset_validate();" id="ForgetPassword" method="POST">
                                <div class="col-md-12 margin_set_input">                
                                    <label class="lbl_class">New Password</label>
                                    <input name="password" type="password" id="password" class="form-control" value="" required="">
                                </div>

                                <div class="col-md-12 margin_set_input">                
                                    <label class="lbl_class">Confirm Password</label>
                                    <input name="confirm_password" type="password" class="form-control" value="" required="">
                                </div>
                                <input type="hidden" name="user_id" value="<?php echo $user_id ?>">
                                <!--<div class="col-md-12 margin_set_input login-remember">                
                                    <label class="lbl_class g-recaptcha" data-sitekey="6LferDsUAAAAAI1frwpcod-3sG6S5Tv3bFdkFbYE" ></label>
                                </div>-->

                                <div class="col-md-12">
                                    <p class="login-submit">
                                        <input type="submit" class="button_login_submit button button-primary" name="forgot_password" value="Reset" />
                                    </p>
                                </div>

                            </form>
                            <div class="clearfix"></div>
                        </div><!-- col-md-6 -->
                    </div>
                </div>
            </div><!-- col-sm-6 col-sm-offset-3  -->
        </div><!-- row -->
    </div><!-- container -->
</section>
<script>
    function reset_validate() {
        $("#ResetPassword").validate({
            rules: {
                password: {
                    required: true,
                    minlength: 5,
                    letters_numbers_special: true
                },
                confirm_password: {
                    required: true,
                    minlength: 5,
                    equalTo: "#password"
                }
            }, messages: {
                password: {
                    required: "Please enter new password",
                    minlength: "Your password must be at least 5 characters long"
                },
                confirm_password: {
                    required: "Please confirm your password",
                    minlength: "Your password must be at least 5 characters long",
                    equalTo: "Please enter the same password as above"
                }
            }
        });
    }
</script>
