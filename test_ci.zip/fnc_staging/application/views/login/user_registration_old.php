<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<section>    <div class="container">        
        <div class="row">            
            <div class="col-sm-12">                
                <div id="contact_us" class="home_tc_head">                    
                    <div class="log_head">                        
                        Register Here                    
                    </div> 
                    <p class="text-center">
                        <strong>To list your business on F&C, or to post a review, we need you to create a user profile</strong>
                    </p>
                    <div class="col-md-6 col-md-offset-3">                        
                        <div class="profile_row c_us_content_in">   
                            <?php if ($this->session->flashdata('error')): ?>
                                <div class="alert alert-danger alert-dismissable" id="new">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Error!</strong> <?php echo $this->session->flashdata('error'); ?>
                                </div>
                            <?php endif; ?>                 

                            <div class="row">                                
                                <div class="col-md-12">                                    
                                    <form method="Post" onclick="register_validate();" id="signupForm"  action="<?php echo site_url('user_registration'); ?>">
                                        <div class="col-md-12 margin_set_input">                                                            
                                            <label class="lbl_class" >First Name:</label>                                            
                                            <input type="text" name="first_name" class="form-control alphaText" required="" value="<?php echo set_value('first_name') ?>" maxlength="30">
                                        </div>
                                        <div class="col-md-12 margin_set_input">
                                            <label class="lbl_class" >Last Name:</label>
                                            <input type="text" name="last_name" class="form-control alphaText" required="" value="<?php echo set_value('last_name') ?>" maxlength="30">
                                        </div>                                        
                                        <div class="col-md-12 margin_set_input">
                                            <label class="lbl_class" >Email:</label>
                                            <input type="email" id="user_email" name="email" maxLength='100'  class="form-control" required="" value="<?php echo set_value('email') ?>" maxlength="40">
                                        </div>

                                        <div class="col-md-12 margin_set_input">
                                            <label class="lbl_class">Phone:</label>
                                            <input type="text" name="phone" maxLength='8' class="form-control phone_no" required="" value="<?php echo set_value('phone') ?>" data-rule-required="true" data-msg-required="Please enter your phone number" data-rule-phone_number="true">
                                        </div>

                                        <div class="col-md-12 margin_set_input">
                                            <label class="lbl_class">Password:</label>
                                            <input type="password" id="password" name="password" class="form-control" maxLength='25' required="" value="<?php echo set_value('password') ?>">
                                        </div>

                                        <div class="col-md-12 margin_set_input">
                                            <label class="lbl_class">Confirm Password:</label>
                                            <input type="password" name="c_password" class="form-control" required="" maxLength='25' value="<?php echo set_value('c_password') ?>" >
                                        </div>
                                        <?php if (CAPTCHA_SHOW) { ?>
                                            <div class="col-md-12 margin_set_input">
                                                <div class="lbl_class g-recaptcha" data-sitekey="<?php echo CAPTCHA_SITE_KEY ?>" >
                                                </div>
                                            </div>
                                        <?php } ?>
                                        <div class="col-md-12"><p class="form-submit">
                                                <input  type="submit" name="submit" class="button_login_submit button new_btn" value="Sign Up" >
                                                <input  type="hidden"  value="register">
                                                <input  type="hidden" value="unspecified">
                                            </p>
                                        </div>
                                    </form>


                                    <div class="col-md-12">
                                        <div class="social-login">
                                            <div class="social-login-connect">Login Using:</div>

                                            <div class="social-login-provider-list details_section1">
                                                <a class="social-login-provider-facebook" href="<?php echo $facebbok_url ?>"> <span class="facebook-button"><i class="fa fa-facebook"></i> <span>Facebook</span></span>
                                                </a>
                                                <!--<a href="<?php //echo $gmail_url;        ?>"> <span class="facebook-button-1"><i class="fa fa-google-plus"></i> <span>Google plus</span></span>-->
                                                <a href="<?php echo $gmail_url; ?>"> <span class="facebook-button-1"><i class="fa fa-google"></i> <span>Google</span></span>
                                                </a>
                                            </div>
                                            <div class="social-login-provider-list details_section2">
                                                <a class="social-login-provider-facebook" href="<?php echo $facebbok_url ?>"> <span class="facebook-button"><img src="<?php echo base_url('assets'); ?>/images/13.Facebook-logo-new.svg"></span>
                                                </a>

                                                <a href="<?php echo $gmail_url; ?>"> <span class="facebook-button-1"><img src="<?php echo base_url('assets'); ?>/images/14.Google-plus-logo-new.svg"></span>
                                                </a>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12 text-right hover_register_106">
                                        <p>Already registered?<a href="<?php echo site_url('user_login') ?>">
                                                <span class="line_set">Login here</span></a></p>
                                    </div></div></div>

                        </div>


                    </div></div></div></div></div></section>

<section class="section-7 hidden-md hidden-sm hidden-lg bg_white">


    <div class="container inspiration_container">

        <div class="row add_back home-row-add-back">

            <hr class="border-line">
            <div class="col-sm-12">
                <div class="row">
                    <div class="col-sm-12 hidden-xs">                   
                        <a href="#" class="webAdvertisment" target="_blank">
                            <img src="<?php echo base_url('assets'); ?>/images/glenmorangle_add_700X87.jpg">
                        </a>  
                    </div> 
                    <div class="col-md-12 hidden-lg hidden-md hidden-sm">                   
                        <a href="#" class="webAdvertisment" target="_blank">
                            <img src="<?php echo base_url('assets'); ?>/images/img_advet_singalvenus.jpg">
                        </a>  
                    </div> 

                </div>
            </div>
        </div>
    </div>
</section>

<script>
    $(".phone_no").keyup(function (e) {
        length = $(this).val().length;
        limit = 18;
        if (length > limit) {
            var strtemp = $(this).val().substr(0, limit);
            $(this).val(strtemp);
            e.preventDefault();
        }
    });
    $(".phone_no").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .   
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 107, 109, 32, 110, 57, 48]) !== -1 ||
                // Allow: Ctrl+A, Command+A
                        (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                        // Allow: home, end, left, right, down, up
                                (e.keyCode >= 35 && e.keyCode <= 40) || (e.keyCode === 107 || e.keyCode === 109 || e.keyCode === 32 || e.keyCode === 57 || e.keyCode === 48)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            });
</script>
