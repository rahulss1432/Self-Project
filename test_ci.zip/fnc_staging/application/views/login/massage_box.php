<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
<style>

.btn {
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}

.cmn_btn1 {
    background-color: #00adee;
    color: #fff;
    border: solid 1px #00adee;
}
.cmn_btn1:hover {
    background-color: #0495cc;
    border: solid 1px #0495cc;
}
</style>
<div>
    <?php
    if (isset($confirm)) {
        echo '<p class="massage_box" style="text-align:center;">To verify your details, please check you email inbox. Please allow up to 2 minutes. <br/>
        <a href="'.base_url().'my_venues/"><button class="btn cmn_btn1"  style="margin-top:15px;">Return to create listing</button></a></p>';
	    // echo '<a href="'.base_url().'my_venues/" class="btn cmn_btn1">Return to create listing</a>';
    }
    if (isset($success)) {
        echo '<p class="massage_box" >Your account is verified successfully.</p>';
    }
    if(!empty($error)){
        echo  '<p class="massage_box" >Sorry your link is expired.</p>';
    }
    ?>
</div>
<script> 
 setTimeout(function(){ window.location.href ="<?php echo site_url('login/user_login') ?>" }, 3000);
</script>