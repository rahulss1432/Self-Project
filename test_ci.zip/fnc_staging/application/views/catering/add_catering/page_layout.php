<!--<div class="col-md-9 col-sm-8">-->
<div class="row second_part6" >
    <div class="col-sm-12">
        <div class="sub_hdngs">
            <h3 class="clr_cmn lising_progess_bar_title"><span>1/2</span> Upload Images</h3>
            <span class="sv_span">last saved:<span class="clr_cmn form-status-holder"><i class="mylastdate"><?php echo!empty(date("d-m-Y", strtotime($last_date))) && date("d-m-Y", strtotime($last_date)) != '01-01-1970' ? date("d-m-Y", strtotime($last_date)) : ''; ?></i></span><button class="btn cmn_btn1 save_btn2">Save</button></span>
            <div class="clearfix"></div>
        </div>
        <div class="progress prog2">
            <div class="progress-bar lising_progess_bar_progress" role="progressbar" aria-valuenow="70"
                 aria-valuemin="0" aria-valuemax="100" style="width:15%">
            </div>
        </div> <!-- progress prog2 ends -->    
    </div>
</div><!-- row ends -->

<?php
if (!empty($this->cart->contents())) {
    $style = '';
    $count = count($this->cart->contents());
} else {
    $style = 'display:none';
    $count = 0;
}
?>
<div class="row">
    <div class="col-sm-12">
        <form class="page_layout" id="page_layout" action="" method="get" role="form" >
            <div class="row">
                <div class="col-sm-12">
                    <div class="fmHeading2">
                        <span class="billDropdown mini_cart_popup package_cart">
                            <i class="fa fa-shopping-cart openShoppingCart cart_ic"></i>
                            <span class="noti_circ" style="<?php echo $style; ?>"><?php echo $count; ?></span>

                            <div class="soFarDiv main-cart drop_bill">
                                <!--<div class="soFarHead">Your Account So Far <i class="fa fa-times pull-right"></i></div>
                                <h5 style="text-align:center;">Your Cart is empty.</h5>-->
                            </div>
                        </span>
                    </div> 
                </div>
            </div>

            <div id="section_one" class="upload_image-page"><!-- start-->
                <div class="row main_row11" >
                    <div class="col-sm-12">
                        <div class="fmHeading2">
                            <h3 class="clr_cmn">Upload a range of images of your venue so we can showcase it at its best.</h3>

                        </div> 
                    </div><!-- col-sm-12 ends -->
                </div><!-- row ends -->

                <div class="row " >
                    <div class="col-lg-9 col-md-11">
                        <div class="row">

                            <div class="col-sm-12"> <h3 class="clr_cmn">Main Image</h3></div>
                            <?php
                            if (!empty($draft_catering->fc_listing_picture)) {
                                $img_url = base_url('uploads/fc_images') . '/' . $draft_catering->fc_listing_picture;
                                $removeImg = "removeImage(1, '" . encrypt_decrypt('encrypt', $draft_catering->fc_id) . "', 1, 55555)";
                                $add_class = 'picture_added';
                                $remove_hide = '';
                                $upload_hide = 'display:none';
                            } else {
                                $img_url = '';
                                $removeImg = "removeImage(1, '0', 2, 55555 )";
                                $add_class = '';
                                $remove_hide = 'display:none';
                                $upload_hide = '';
                            }
                            //echo "image_url=".$draft_venue->fc_listing_picture;
                            ?>
                            <div class="col-sm-6">

                                <div class="ulpading_img_size_3 listing_picture_thumb fl_wid <?php echo $add_class; ?> ">
                                    <img id="show_image_55555" class="dropzone" img-id="55555" src="<?php echo $img_url; ?>" style="<?php echo ($img_url == '') ? 'display: none;' : 'display:block;' ?> opacity: 1;">
                                    <input onclick="this.value = null;" type="file" name="fc_listing_picture" data-id="55555" class="file-selector fc_listing_picture image_selector" id="image_selector_55555" accept="image/*">
                                    <input type="hidden" class="fc_listing_picture" name="dimesion_image_55555" id="dimesion_image_55555" value="<?php echo $img_url ? $img_url : 0; ?>">
                                    <input type="hidden" name="fc_image_55555" id="fc_image_55555" value="">

                                </div>
                                <div class="clearfix"></div>
                            </div><!-- col-sm-6 ends -->

                            <div class="col-sm-6">

                                <div class="Img_spec clr_cmn">
                                    <h5>Image Specs</h5>
                                    <h6>Image should be jpeg or a png file</h6>
                                    <h6>Dimensions are 300 x 500 px</h6>
                                    <h6>Max size can be 2 MB</h6>
                                    <div class="mn_imgBtGr">
                                        <a href="javascript:void(0)" id="remove_select55555" class="btn cmn_btn2 f_s2 " onclick="<?php echo $removeImg ?>" style="<?php echo $remove_hide; ?>">Remove</a>
                                        <label ant-id="55555" class="upload-button_new btn cmn_btn1 f_s2 remove_select55555" id="another_select_55555"  style="<?php echo $upload_hide; ?>">
                                            <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                        </label>
                                    </div>
                                    <span class="img_msg_55555"></span>
                                </div><!-- Img_spec ends -->
                            </div><!-- col-sm-6 ends -->
                        </div><!-- row ends -->
                    </div><!-- col-sm-8 ends -->

                </div><!-- row ends -->


                <div class="row main_row11">

                    <div class="col-lg-9 col-md-11 col-sm-12">
                        <h3 class="clr_cmn">Catering Images</h3>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="venImgBx25 ">

                                    <?php
                                    $old_img_count = (!empty($draft_venue_images)) ? count($draft_venue_images) : 0;

                                    for ($i = 1; $i <= 5; $i++) {
                                        $img_url = '';
                                        if ($old_img_count > 0) {
                                            $img_url = base_url('uploads/fc_images') . '/' . $draft_venue_images[$i - 1]->fc_img_name;
                                            if (empty($draft_venue_images[$i - 1]->fc_img_name)) {
                                                $img_url = '';
                                                $add_class = '';
                                            }
                                            $remove_hide = '';
                                            $b_upload_hide = 'display:none';

                                            $old_img_count--;
                                            $removeImg = "removeImage(2, '" . encrypt_decrypt('encrypt', $draft_venue_images[$i - 1]->fc_img_id) . "', 1, $i )";
                                            $add_class = 'picture_added';
                                        } else {

                                            $removeImg = "removeImage(2, '0', 2, $i )";
                                            $add_class = '';
                                            $remove_hide = 'display:none';
                                            $b_upload_hide = '';
                                        }
                                        ?> 
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="ulpading_img_size_3 listing_picture_thumb fl_wid <?php echo $add_class; ?>">
                                                    <img id="show_image_<?php echo $i ?>" class="dropzone" img-id="<?php echo $i ?>" src="<?php echo $img_url ?>" style="<?php echo ($img_url == '') ? 'display: none;' : 'display:block;' ?> opacity: 1;">

                                                    <input onclick="this.value = null;" type="file" name="venue_images_<?php echo $i ?>" data-fc_img_id="" data-id="<?php echo $i ?>" class="file-selector image_selector check_image_validation remove_select<?php echo $i ?>" id="image_selector_<?php echo $i ?>" accept="image/*" >
                                                    <input type="hidden" class="check_image_validation" name="dimesion_image_<?php echo $i ?>" id="dimesion_image_<?php echo $i ?>" value="<?php echo $img_url ? $img_url : 0; ?>">
                                                    <input type="hidden" name="fc_image_<?php echo $i ?>" id="fc_image_<?php echo $i ?>" value="">

                                                </div>
                                            </div><!-- col-sm-6 ends -->

                                            <div class="col-sm-6">
                                                <div class="Img_spec clr_cmn">
                                                    <h5>Image Specs</h5>
                                                    <h6>Image should be jpeg or png files</h6>
                                                    <div class="mn_imgBtGr">
                                                        <a href="javascript:void(0)" id="remove_select<?php echo $i ?>" class="btn cmn_btn2 f_s2"  onclick="<?php echo $removeImg ?>" style="<?php echo $remove_hide; ?>">Remove</a>
                                                        <label ant-id="<?php echo $i ?>" class="upload-button_new btn cmn_btn1 f_s2 remove_select<?php echo $i ?>" id="another_select_1" style="<?php echo $b_upload_hide; ?>">
                                                            <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                        </label>
                                                    </div>
                                                    <span class="img_msg_<?php echo $i; ?>"></span>                 
                                                </div><!-- Img_spec ends -->
                                            </div><!-- col-sm-6 ends -->
                                        </div><!-- row ends -->
                                    <?php } ?>


                                </div><!-- venImgBx25 ends -->
                            </div><!-- col-md-12 ends -->
                        </div><!-- row ends -->
                    </div><!-- col-sm-9 ends -->
                </div><!-- row ends -->

                <div class="row">
                    <div class="col-sm-12">
                        <div class="CheckieError error images_valid_error" style="display:none"><span>Please upload at least 3 images, with main image.</span></div>
                    </div>
                </div>

                <div class="row mrTp15">
                    <div class="col-lg-3 col-md-5 col-sm-3 col-xs-3" id="back_page_layout1">
                        <a href="javascript:void(0)" onclick="forwordTo('catering_details', 'getPaymentCart'); venuDetailsForwordTo('venue_location', false)"><span class="clr_cmn"><i class="fa fa-angle-left"></i> Back</span></a>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-9  col-xs-9 text-right">
                        <a href="javascript:void(0)" onclick="listingForwordTo('review_your_listing', true); show_preview_listing();" data-page_layout_percent1="8.33" class="btn cmn_btn1 prw_btn page_layout_percent1">Preview Your Listing</a>
                    </div>
                </div>
            </div><!-- end section one-->


            <div id="section_second" class="review_your_listing-page" style="display:none"><!--start-->

                <div class="row "  >



                    <div class="col-sm-12">
                        <div class="fmHeading2">
                            <h3 class="clr_cmn">Almost done! You can now preview your listing as it will appear once published.</h3>

                        </div> 
                    </div><!-- col-sm-12 ends -->

                </div><!-- row ends -->

                <div class="row"  >

                    <div class="col-sm-7">      
                        <!--<h3 class="clr_cmn">Happy with it? Click ‘I love it!’ and your listing will be live on the site!</h3>-->
                        <h3 class="clr_cmn">Happy with it? Click ‘I love it!’</h3>
                    </div><!-- col-sm-6 ends -->

                    <div class="col-sm-4 col-sm-offset-1">

                        <div class="pg_lyBtns">
                            <a href="javascript:;" onclick="listingForwordTo('upload_image', false);" class="btn cmn_btn2 btn-block first-section">I want to make some changes</a>
                            <a href="javascript:;" class="btn cmn_btn1 btn-block preview_map">I love it !</a>
                        </div>
                    </div><!-- col-sm-4ends -->
                </div><!-- row ends -->



                <div class="row" >


                    <div class="col-sm-12">

                        <div class="main_frame12">

                        </div><!-- main_frame12 ends -->

                    </div><!-- col-sm-12 ends -->
                </div><!-- row ends -->

                <div class="row mrTp15">
                    <div class="col-md-6 col-sm-3 col-xs-3">
                        <a href="javascript:void(0)" onclick="listingForwordTo('upload_image', false);" ><span class="clr_cmn " ><i class="fa fa-angle-left"></i> Back</span></a>
                    </div>
                    <div class="col-md-6 col-sm-9  col-xs-9 text-right">
                    <!-- <input type="button" id="nextbtn_page_layout" class="btn cmn_btn1 prw_btn create_map" onclick="initialize();" value="Next"> -->

                        <a href="javascript:void(0)" class="btn cmn_btn1 prw_btn preview_map" >Next</a>
                    </div>

                </div>

            </div><!--section second end-->

        </form>
    </div><!-- col-sm-12 ends -->

</div><!-- row ends -->
<!--</div>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/canvas2image@1.0.5/canvas2image.min.js"></script>