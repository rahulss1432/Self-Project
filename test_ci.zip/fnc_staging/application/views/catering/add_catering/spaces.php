<div class="row">
    <div class="col-sm-12">
        <div class="sub_hdngs">
            <h3 class="clr_cmn space_progess_bar_title"><span>1/1</span> Spaces</h3>
            <span class="sv_span">last saved:<span class="clr_cmn">Just Now</span><button class="btn cmn_btn1 save_btn2">Save</button></span>
            <div class="clearfix"></div>
        </div>

        <div class="progress prog2">
            <div class="progress-bar space_progess_bar_progress" role="progressbar" aria-valuenow="70"
                 aria-valuemin="0" aria-valuemax="100" style="width:70%">
            </div>
        </div>
    </div>
</div>

<div class="row">

        <div class="col-sm-12">
            <div class="fmHeading2">
                <span class="billDropdown package_cart">
                    <i class="fa fa-shopping-cart openShoppingCart cart_ic"></i>
                    <div class="soFarDiv main-cart drop_bill"></div>
                </span>
            </div> 
        </div>

    <div class="col-sm-12">
        <div class="space_view ">
            <div class="row">
                <div class="col-sm-12">
                    <div class="fmHeading2">
                    </div> 
                </div>

                <div class="col-md-6 col-sm-12">
                    <h3 class="clr_cmn fr_hdngSpc">Do you have any other spaces at this venue you would like to list?
                        <i class="tooltip_i">
                            <i class="spc_i">i</i>
                            <div class="cstmTooltip left spc_tltp">
                                <h5>Lorem ipsum</h5>
                                <p >Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                            </div>
                        </i>
                    </h3>

                    <div class="row">
                        <div class="col-sm-4 col-xs-6">
                            <input type="radio" name="radio-group" id="need_space" class="my_radio" >
                            <label for="need_space" class="clr_cmn sm_radie">Yes</label>
                        </div>
                        <div class="col-sm-4 col-xs-6">
                            <input type="radio" name="radio-group"  id="no_need_space" class="my_radio" checked>
                            <label for="no_need_space" class="clr_cmn sm_radie">No</label>
                        </div>
                    </div> 
                    <h5 class="yesNote">Each Additional area is charged at<br/> a rate of 30c per day</h5>
                </div><!-- col-sm-6 ends -->

                <div class="col-md-6 col-sm-12">
                </div><!-- col-md-6 ends -->


                <div class="col-md-6 col-sm-12">
                    <div class="Ven_spc_bx">
                        <h5><b>Venues and Spaces</b></h5>
                        <p>With F&C you have the option to set up ‘spaces’ within venues. For example if you have a property with several unique areas for hire within the same address.<br/>
                            Spaces can be found by clicking into the parent venueon the venues page.
                        </p>
                    </div><!-- Ven_spc_bx ends -->
                </div><!-- col-md-6 ends -->
            </div><!-- row ends -->

            <div class="row mrTp40 ">
                <div class="col-md-6 col-sm-3 col-xs-3" id= "back_btn_spaces">
                    <a href="JavaScript:void(0);" onclick="forwordTo('listing_area')"><span class="clr_cmn"><i class="fa fa-angle-left"></i> Back</span></a>
                </div>
                <div class="col-md-6 col-sm-9 col-xs-9 txt_rg1">
                    <button class="btn cmn_btn1 frm_bt2 btn_space" style="display:none" id="btn_spaces">Add Space</button> 
                    <a href="JavaScript:void(0);" onclick="forwordTo('payment', 'getPaymentCart')" class="btn cmn_btn1 frm_bt2 btn_checkout">Checkout</a>
                </div>
            </div>
        </div>

        <div class="single_space_form">
            <div class="row">
            <div class="col-md-12 col-sm-12 " id="append2divspace">
                

            </div>
            </div>
        </div>

    </div><!-- col-sm-12 ends -->
</div><!-- row ends -->
