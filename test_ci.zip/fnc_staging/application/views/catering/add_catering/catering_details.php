
<?php //print_r($facilities);                    ?>

<div class="row first_part" >
    <div class="col-sm-12">
        <div class="sub_hdngs">
            <h3 class="clr_cmn venue_details_progess_bar_title"><span>1/6 </span> Catering Description</h3>
            <span class="sv_span">last saved:<span class="clr_cmn form-status-holder"></span><button class="btn cmn_btn1 save_btn2">Save</button></span>

            <div class="clearfix"></div>
        </div>

        <div class="progress prog2">
            <div class="progress-bar venue_details_progess_bar_progress" role="progressbar" aria-valuenow="70"
                 aria-valuemin="0" aria-valuemax="100" style="width:15%">
            </div>
        </div> <!-- progress prog2 ends -->    
    </div>
</div><!-- row ends -->

<?php
if (!empty($this->cart->contents())) {
    $style = '';
    $count = count($this->cart->contents());
} else {
    $style = 'display:none';
    $count = 0;
}
?>
<div class="row">

    <div class="col-sm-12">

        <form class="cmn_frmCls" id="venue_details_form" action="<?php echo site_url('catering/catering_details'); ?>" method="post" >
            <div class="row">
                <div class="col-sm-12">
                    <div class="fmHeading2">
                        <span class="billDropdown mini_cart_popup package_cart">
                            <i class="fa fa-shopping-cart openShoppingCart cart_ic"></i>
                            <span class="noti_circ" style="<?php echo $style; ?>"><?php echo $count; ?></span>
                            <div class="soFarDiv main-cart drop_bill">
                                <div class="soFarHead">Your Account So Far <i class="fa fa-times pull-right"></i></div>
                                <h5 style="text-align:center;">Your Cart is empty.</h5>
                            </div>
                        </span>
                    </div> 
                </div>
            </div>

            <div class="venu_description-page">
                <div class="row main_row11 first_part"  id="first_part">
                    <div class="col-sm-12">
                        <div class="fmHeading2">
                            <h3 class="clr_cmn ">Let’s get to know you! Write a short description about your catering service. This will be the overview of your listing.</h3> 
                        </div> 
                    </div>

                    <div class="col-lg-6 col-md-8 col-sm-12">
                        <div class="txtie">
                            <textarea class="descrp_box2 form-control overview_textarea textare_root venue_details_input validate_special_character" id="venue_overview" name="venue_overview" data-rule-required="true" data-rule-maxlength="1200" data-rule-minlength="100" minlength="100" maxlength="1200" data-msg-required='Please enter the description of your caterer'><?php echo (!empty($draft_catering->fc_overview) ? $draft_catering->fc_overview : '') ?></textarea>
                            <p class="text-right clr_cmn remaining_counter_show"></p>
                            <span class="inpicns">
                                <i class="fa fa-check ic-gr"></i>
                                <i class="fa fa-warning ic-rd" style="display: none"></i>
                            </span>
                            <label style="display: none;"  class="custom-error"></label>
                        </div>



                        <h3 class="clr_cmn">Lets talk capacity. Specify minimum & maximum number of guests for your listing</h3>

                        <div class="row">

                            <div class="col-md-4 col-sm-6 col-xs-6 margin_set_input ">
                                <label class="lbl_class" for="venue_min_guest">Minimum Guests<span class="clr_cmn">*</span></label>
                                <input type="text" class="form-control addr-field venue_details_input error_down number_allow_only"  maxlength="5" id="venue_min_guest" name="venue_min_guest" data-rule-number="true" data-rule-required="true" value="<?php echo (!empty($draft_catering->fc_min_guest) ? $draft_catering->fc_min_guest : '') ?>" data-msg="Please enter capacity">

                            </div>


                            <div class="col-md-4 col-sm-6 col-xs-6 margin_set_input ">
                                <label class="lbl_class" for="venue_max_guest">Maximum Guests<span class="clr_cmn">*</span></label>
                                <input type="text" class="form-control addr-field venue_details_input error_down number_allow_only"  maxlength="5" data-rule-greaterThan="#venue_min_guest" id="venue_max_guest" class="form-control" id="venue_max_guest" name="venue_max_guest" data-rule-number="true" data-rule-required="true" value="<?php echo (!empty($draft_catering->fc_max_guest) ? $draft_catering->fc_max_guest : '') ?>" data-msg-required="Please enter capacity">

                            </div>
                        </div>


                        <div class="row">

                            <div class="col-sm-12 mr_bt30">
                                <h3 class="clr_cmn">What is the average price per head at <span class="venue_name"> <?php echo (!empty($draft_catering->fc_business_name) ? $draft_catering->fc_business_name : '') ?>?</span></h3>
                            </div>


                            <?php
                            $price_arr = (!empty($draft_catering->fc_pricing) ? explode(',', $draft_catering->fc_pricing) : array());
                            $dollar_value = '';
                            if (!empty($price_per_head)) {
                                $dollar_count = 1;
                                foreach ($price_per_head as $value) {
                                    $checked_pricing = '';
                                    $active = '';

                                    if (in_array($value->p_id, $price_arr)) {
                                        $checked_pricing = 'checked';
                                        $active = 'active';
                                    }
                                    ?>
                                    <div class="col-sm-6 pd_r7">

                                        <p class="cstm_MlChkBx venue_details_input dollar_checks <?php echo $active; ?>">
                                            <input type="checkbox" class="venue_details_input" name="venue_pricing[]" value="<?php echo $value->p_id; ?>" <?php echo $checked_pricing; ?> aria-required="true" required minlength="1" data-msg-required="Please select at least one price range" data-msg-minlength="Please select at least one price range" >
                                            <label><span class="dollar_span"><?php
                                                    //for ($i = 0; $i < $dollar_count; $i++) {
                                                    $dollar_value .= '$';
                                                    echo $dollar_value;
                                                    //}
                                                    ?></span><?php echo $value->p_name; ?></label> 
                                        </p>
                                    </div>
                                    <?php
                                    // if ($dollar_count % 2 == 0)
                                    //   echo '';$dollar_count++;
                                }
                            }
                            ?>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <label for="venue_pricing[]" class="error CheckieError" style=""></label>
                            </div>
                        </div>
                    </div><!-- col-sm-6 ends -->


                    <div class="col-lg-6 col-md-4 col-sm-6">
                    </div><!-- col-md-6 ends -->

                </div><!-- row ends -->

                <div class="clearfix"></div>
                <div class="row mrTp15 first_part" >
                    <div class="col-md-4 col-sm-3 col-xs-3">
                        <a href="JavaScript:void(0);"  onclick="forwordTo('package')"><span class="clr_cmn bckie2"><i class="fa fa-angle-left" ></i> Back</span></a>
                    </div>
                    <div class="col-md-8 col-sm-9 col-xs-9 txt_rg1">
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('function_types', false)" class="btn cmn_btn2 frm_bt2">Skip for now</a>
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('function_types', true)" data-catering_detail_percent1="3.33" class="btn cmn_btn1 frm_bt2 catering_detail_percent1" id="next_venue_details1">Next</a>
                    </div>
                </div>
            </div><!-- first part -->


            <div class="function_types-page" style="display:none">
                <div class="row main_row11 second_part1" id="second_part1">
                    <div class="col-sm-12">
                        <div class="fmHeading2">
                            <h3 class="clr_cmn ">We also want you to enjoy hosting, let us know what type of events are the best fit for your catering.</h3> 

                        </div> 
                    </div>

                    <div class="col-md-6 col-sm-12 " >
                        <div class="row ChkRow">
                            <?php
                            $event_arr = (!empty($draft_catering_details->cd_function_type) ? explode(',', $draft_catering_details->cd_function_type) : array() );
                            //print_r($draft_catering_details);
                            if (!empty($function_type)) {
                                foreach ($function_type as $e_type) {
                                    ?>
                                    <div class="col-sm-6 mlCh_cols ">
                                        <?php
                                        $checked_event = '';
                                        $active = '';
                                        if (in_array($e_type->id, $event_arr)) {
                                            $checked_event = 'checked';
                                            $active = 'active';
                                        }
                                        ?>
                                        <p class="cstm_MlChkBx venue_details_input <?php echo $active; ?>">

                                            <span>
                                                <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $e_type->image; ?>" class="img1Nm ">
                                                <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $e_type->white_image; ?>" class="img2Ch ">


                                            </span> 
                                            <input type="checkbox" name="function_types[]" value="<?php echo $e_type->id; ?>" <?php echo $checked_event; ?> aria-required="true" required minlength="3" data-msg-required="Please select at least 3 function types" data-msg-minlength="Please select at least 3 function types">

                                            <label><?php echo $e_type->name; ?></label>
                                        </p><!-- cstm_MlchkBx ends -->
                                    </div><!-- col-sm-6 ends -->

                                    <?php
                                }
                            }
                            ?>
                        </div> <!-- row endds -->
                        <div class="row">
                            <div class="col-sm-12">
                                <label for="function_types[]" class="error CheckieError" style=""></label>
                            </div>
                        </div>


                    </div><!-- col-sm-6 ends -->

                    <div class="col-md-6 col-sm-12" style="display: none;">
                        <h3 class="clr_cmn">Summary</h3>
                        <ul class="VenPrntUl">
                            <?php
                            if (!empty($event_arr)) {
                                foreach ($function_type as $e_type) {
                                    if (in_array($e_type->id, $event_arr)) {
                                        ?>
                                        <li class="<?php echo str_replace(' ', '', ucfirst(preg_replace('/[^A-Za-z0-9\-]/', '', $e_type->name))) ?>">
                                            <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $e_type->image; ?>" class="img2Ch"> 
                                            <label><?php echo $e_type->name; ?></label>
                                        </li>
                                        <?php
                                    }
                                }
                            }
                            ?>
                        </ul>
                        <div class="clearfix"></div>
                    </div><!-- col-sm-6 ends -->
                </div>
                <div class="row mrTp15">
                    <div class="col-md-4 col-sm-3 col-xs-3" >
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('venu_description', false)"><span class="clr_cmn bckie2"><i class="fa fa-angle-left"></i> Back</span></a>
                    </div>
                    <div class="col-md-8 col-sm-9 col-xs-9 txt_rg1">   
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('menus', false)" class="btn cmn_btn2 frm_bt2" id="next_venue_details2">Skip for now</a>
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('menus', true)" data-catering_detail_percent2="3.33" class="btn cmn_btn1 frm_bt2 catering_detail_percent2" id="next_venue_details2">Next</a>
                    </div>
                </div>
            </div>

            <div class="menus-page" style="display: none" >
                <div class="row main_row11 second_part2" >
                    <div class="col-sm-12">
                        <div class="fmHeading2">
                            <h3 class="clr_cmn ">Choose the menu you can serve at events</h3> 

                        </div> 
                    </div>


                    <div class="col-md-6 col-sm-12 ">

                        <div class="row ChkRow">
                            <?php
                            $facility_arr = (!empty($draft_catering_details->cd_menus) ? explode(',', $draft_catering_details->cd_menus) : array() );
                            if (!empty($menus)) {
                                foreach ($menus as $f_val) {
                                    ?>
                                    <div class="col-sm-6 mlCh_cols">
                                        <?php
                                        $checked_facility = '';
                                        $active = '';
                                        if (in_array($f_val->id, $facility_arr)) {
                                            $checked_facility = 'checked';
                                            $active = 'active';
                                        }
                                        ?>
                                        <p class="cstm_MlChkBx venue_details_input <?php echo $active; ?>">

                                            <span>
                                                <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $f_val->image; ?>" class="img1Nm ">
                                                <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $f_val->white_image; ?>" class="img2Ch ">


                                            </span> 
                                            <input minlength="3" type="checkbox" name="catering_menus[]" value="<?php echo $f_val->id; ?>" <?php echo $checked_facility; ?> aria-required="true" required data-msg-required="Please select at least 3 menus" data-msg-minlength="Please select at least 3 menus">

                                            <label><?php echo $f_val->name; ?></label>
                                        </p><!-- cstm_MlchkBx ends -->
                                    </div><!-- col-sm-6 ends -->


                                    <?php
                                }
                            }
                            ?>

                        </div> <!-- row endds -->

                        <div class="row">
                            <div class="col-sm-12">
                                <label for="catering_menus[]" class="error CheckieError" style=""></label>
                            </div>
                        </div>

                    </div><!-- col-sm-6 ends -->

                    <div class="col-md-6 col-sm-12" style="display: none;">
                        <h3 class="clr_cmn">Summary</h3>
                        <ul class="VenPrntUl">
                            <?php
                            if (!empty($facility_arr)) {
                                foreach ($menus as $f_val) {
                                    if (in_array($f_val->id, $facility_arr)) {
                                        ?>
                                        <li class="<?php echo str_replace(' ', '', ucfirst(preg_replace('/[^A-Za-z0-9\-]/', '', $f_val->name))) ?>">
                                            <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $f_val->image; ?>" class="img2Ch">
                                            <label><?php echo $f_val->name; ?></label>
                                        </li>
                                        <?php
                                    }
                                }
                            }
                            ?>
                        </ul>
                        <div class="clearfix"></div>
                    </div><!-- col-sm-6 ends -->
                </div>
                <div class="row mrTp15 second_part2">

                    <div class="col-md-4 col-sm-3 col-xs-3" id="back_venue_details3">
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('function_types', false)"><span class="clr_cmn bckie2"><i class="fa fa-angle-left"></i> Back</span></a>
                    </div>
                    <div class="col-md-8 col-sm-9 col-xs-9 txt_rg1"> 
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('cuisine', false)" class="btn cmn_btn2 frm_bt2" id="next_venue_details3">Skip for now</a>
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('cuisine', true)" data-catering_detail_percent3="3.33" class="btn cmn_btn1 frm_bt2 catering_detail_percent3" id="next_venue_details3">Next</a>
                    </div>

                </div>
            </div>


            <div class="cuisine-page"  style="display: none">

                <div class="row main_row11 second_part3">
                    <div class="col-sm-12">
                        <div class="fmHeading2">
                            <h3 class="clr_cmn ">Select the cuisines you can offer</h3> 

                        </div> 
                    </div>


                    <div class="col-md-6 col-sm-12 ">

                        <div class="row ChkRow">
                            <?php
                            $feature_arr = (!empty($draft_catering_details->cd_cuisine) ? explode(',', $draft_catering_details->cd_cuisine) : array() );

                            if (!empty($cuisine)) {
                                foreach ($cuisine as $feat_val) {
                                    ?>
                                    <div class="col-sm-6 mlCh_cols">
                                        <?php
                                        $checked_feature = '';
                                        $active = '';
                                        if (in_array($feat_val->id, $feature_arr)) {
                                            $checked_feature = 'checked';
                                            $active = 'active';
                                        }
                                        ?>
                                        <p class="cstm_MlChkBx venue_details_input <?php echo $active; ?>">
                                            <span>
                                                <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $feat_val->image; ?>" class="img1Nm ">
                                                <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $feat_val->white_image; ?>" class="img2Ch">

                                            </span> 
                                            <input type="checkbox" name="catering_cuisine[]"  value="<?php echo $feat_val->id; ?>" <?php echo $checked_feature; ?> minlength="3" required data-msg-required="Please select at least 3 cuisines" data-msg-minlength="Please select at least 3 cuisines">

                                            <label><?php echo $feat_val->name; ?></label>
                                        </p><!-- cstm_MlchkBx ends -->
                                    </div><!-- col-sm-6 ends -->
                                    <?php
                                }
                            }
                            ?>

                        </div> <!-- row endds -->

                        <div class="row">
                            <div class="col-sm-12">
                                <label for="catering_cuisine[]" class="error CheckieError" style=""></label>
                            </div>
                        </div>



                    </div><!-- col-sm-6 ends -->


                    <div class="col-md-6 col-sm-12" style="display: none;">
                        <h3 class="clr_cmn">Summary</h3>
                        <ul class="VenPrntUl">
                            <?php
                            if (!empty($feature_arr)) {
                                foreach ($cuisine as $feat_val) {
                                    if (in_array($feat_val->id, $feature_arr)) {
                                        ?>

                                        <li class="<?php echo str_replace(' ', '', ucfirst(preg_replace('/[^A-Za-z0-9\-]/', '', $feat_val->name))) ?>">
                                            <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $feat_val->image; ?>" class="img2Ch">
                                            <label><?php echo $feat_val->name; ?></label>
                                        </li>
                                        <?php
                                    }
                                }
                            }
                            ?>
                        </ul>
                        <div class="clearfix"></div>
                    </div><!-- col-sm-6 ends -->
                </div><!-- row ends -->

                <div class="row mrTp15 second_part3">
                    <div class="col-md-4 col-sm-3 col-xs-3" id="back_venue_details4">
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('menus', false)"><span class="clr_cmn bckie2"><i class="fa fa-angle-left"></i> Back</span></a>
                    </div>
                    <div class="col-md-8 col-sm-9 col-xs-9 txt_rg1"> 
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('services', false)" class="btn cmn_btn2 frm_bt2" id="next_venue_details4">Skip for now</a>
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('services', true)" data-catering_detail_percent4="3.33" class="btn cmn_btn1 frm_bt2 catering_detail_percent4" id="next_venue_details4">Next</a>
                    </div>

                </div>
            </div><!-- row ends -->

            <div class="services-page"  style="display: none">

                <div class="row main_row11 second_part3">
                    <div class="col-sm-12">
                        <div class="fmHeading2">
                            <h3 class="clr_cmn ">To help us match you with the right customers, let us know what type of services are on offer at this location.</h3> 

                        </div> 
                    </div>


                    <div class="col-md-6 col-sm-12 ">

                        <div class="row ChkRow">
                            <?php
                            $services_arr = (!empty($draft_catering_details->cd_services) ? explode(',', $draft_catering_details->cd_services) : array() );

                            if (!empty($services)) {
                                foreach ($services as $feat_val) {
                                    ?>
                                    <div class="col-sm-6 mlCh_cols">
                                        <?php
                                        $checked_feature = '';
                                        $active = '';
                                        if (in_array($feat_val->id, $services_arr)) {
                                            $checked_feature = 'checked';
                                            $active = 'active';
                                        }
                                        ?>
                                        <p class="cstm_MlChkBx venue_details_input <?php echo $active; ?>">
                                            <span>
                                                <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $feat_val->image; ?>" class="img1Nm ">
                                                <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $feat_val->white_image; ?>" class="img2Ch">

                                            </span> 
                                            <input type="checkbox" name="catering_services[]"  value="<?php echo $feat_val->id; ?>" <?php echo $checked_feature; ?> minlength="3" required data-msg-required="Please select at least 3 services" data-msg-minlength="Please select at least 3 services">

                                            <label><?php echo $feat_val->name; ?></label>
                                        </p><!-- cstm_MlchkBx ends -->
                                    </div><!-- col-sm-6 ends -->
                                    <?php
                                }
                            }
                            ?>

                        </div> <!-- row endds -->

                        <div class="row">
                            <div class="col-sm-12">
                                <label for="catering_services[]" class="error CheckieError" style=""></label>
                            </div>
                        </div>



                    </div><!-- col-sm-6 ends -->


                    <div class="col-md-6 col-sm-12" style="display: none;">
                        <h3 class="clr_cmn">Summary</h3>
                        <ul class="VenPrntUl">
                            <?php
                            if (!empty($services_arr)) {
                                foreach ($services as $feat_val) {
                                    if (in_array($feat_val->id, $services_arr)) {
                                        ?>

                                        <li class="<?php echo str_replace(' ', '', ucfirst(preg_replace('/[^A-Za-z0-9\-]/', '', $feat_val->name))) ?>">
                                            <img src="<?php echo base_url('uploads/fnc_types/catering_icon') . '/' . $feat_val->image; ?>" class="img2Ch">
                                            <label><?php echo $feat_val->name; ?></label>
                                        </li>
                                        <?php
                                    }
                                }
                            }
                            ?>
                        </ul>
                        <div class="clearfix"></div>
                    </div><!-- col-sm-6 ends -->
                </div><!-- row ends -->

                <div class="row mrTp15 second_part3">
                    <div class="col-md-4 col-sm-3 col-xs-3" id="back_venue_details4">
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('cuisine', false)"><span class="clr_cmn bckie2"><i class="fa fa-angle-left"></i> Back</span></a>
                    </div>
                    <div class="col-md-8 col-sm-9 col-xs-9 txt_rg1"> 
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('venue_location', false)" class="btn cmn_btn2 frm_bt2" id="next_venue_details4">Skip for now</a>
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('venue_location', true)" data-catering_detail_percent5="3.33" class="btn cmn_btn1 frm_bt2 catering_detail_percent5" id="next_venue_details4">Next</a>
                    </div>

                </div>
            </div>

            <div class="venue_location-page" style="display:none">
                <div class="row main_row11 second_part4 "  >

                    <!-- <div class="col-sm-12 second_part4"  >
                        <div class="fmHeading2">                            
                        </div> 
                    </div> -->

                    <div class="col-md-8 col-sm-12">
                        <!--<h3 class="clr_cmn fr_hdngSpc mr_spce15__">Is there anything else you would like to say about <a class="clr_cmn vn_anch venue_name"><?php //echo (!empty($draft_catering->fc_business_name) ? $draft_catering->fc_business_name : '')                  ?>?</a>-->
                        <h3 class="clr_cmn fr_hdngSpc mr_spce15__">Write a short description outlining the best, most interesting and exclusive points of difference about your catering. This description will be featured on your listing page for your potential clients to read.
                        </h3>
                        <div class="row Rw_rad23">
                            <div class="col-sm-4 col-xs-6"><?php //echo $draft_catering->fc_details                                                            ?>
                                <input type="radio" id="say1" name="fc_details_select" class="my_radio"  onclick="pdfValidation('yes');"  value="true" <?php echo (!empty($draft_catering->fc_details_select) ? 'checked' : '') ?>>
                                <label for="say1" class="clr_cmn sm_rad">Yes, Please!</label>
                            </div>
                            <div class="col-sm-4 col-xs-6">
                                <input type="radio" id="say2" name="fc_details_select" class="my_radio"  onclick="pdfValidation('no');"  value="false" <?php echo (!empty($draft_catering->fc_details_select) ? "" : 'checked') ?>>
                                <label for="say2" class="clr_cmn sm_rad">No, Thanks</label>
                            </div>
                        </div> 
                        <?php //if($draft_catering->fc_details == 'blank'){ $draft_catering->fc_details = ''; } ?>
                        <div class="txtie say_smthng" style="display: <?php echo (!empty($draft_catering->fc_details_select) ? 'block' : 'none') ?>;">
                            <!--<textarea data-msg-required='Please provide description of your catering' class="descrp_box2 venue_details_input validate_special_character" id="fc_details" <?php //echo (!empty($draft_catering->fc_details_select) ? ('required="true" minlength="100" maxlength="1200"') : '')                  ?>;   name="fc_details"  ><?php //echo (!empty(($draft_catering->fc_details)) ? $draft_catering->fc_details : '')                  ?></textarea>-->
                            <?php
                            if (!empty($draft_catering->fc_details_select)) {
                                $fcDetails_desc = trim($draft_catering->fc_details);
                                ?>
                                <textarea class="descrp_box2 venue_details_input validate_special_character" id="fc_details" required="true"  minlength="100" name="fc_details" maxlength="1200" data-msg-required="Please provide description of your catering" ><?php echo $fcDetails_desc; ?></textarea>
                            <?php } else { ?>
                                <textarea class="descrp_box2 venue_details_input validate_special_character" id="fc_details"  name="fc_details"  data-msg-required="Please provide description of your catering" ></textarea>
                            <?php } ?>
                            <div id="getPdfData">
                            </div>
                        </div>
                    </div><!-- col-sm-6 ends -->
                </div><!-- row ends -->
                <div class="row">
<!--                    <div class="col-sm-12">
                        <div class="CheckieError error pdfs_valid_error" style="display:none"><span>Please upload a pdf.</span></div>
                    </div>-->
                </div>

                <div class="row mrTp15 second_part4">
                    <div class="col-md-6 col-sm-3 col-xs-3" id="back_venue_details5">
                        <a href="JavaScript:void(0);" onclick="venuDetailsForwordTo('services', false)" ><span class="clr_cmn bckie2"><i class="fa fa-angle-left"></i> Back</span></a>
                    </div>
                    <div class="col-md-6 col-sm-9 col-xs-9 txt_rg1">   
                        <a href="JavaScript:void(0);" onclick="forwordTo('page_layout', 'venue_details_form_validate')" class="btn cmn_btn1 frm_bt2 " id="next_venue_details5">Next</a>
                    </div>
                </div>
            </div>
        </form>
    </div><!-- col-sm-12 ends -->
</div><!-- row ends -->

<script src="https://mozilla.github.io/pdf.js/build/pdf.js"></script>
<script type="text/javascript">

                            $(document).ready(function () {
                                var fcId = $('#fc_id').val();
                                getPdfData(fcId);
                            });

                            function getPdfData(fcId = null) {
                                $.ajax({
                                    url: base_url + 'FNC_Add_Venue/venue_pdf_details/' + fcId,
                                    method: 'GET',
                                    asycns: false,
                                    success: function (data) {
                                        $('#getPdfData').html(data);
                                    }
                                });
                            }

                            var timeoutId;
                            $('.venue_details_input').on('input propertychange change click', function () {
                                $("#venue_details_form").validate({onkeyup: function (element) {
                                        $(element).valid()
                                    }});

                                clearTimeout(timeoutId);

                                timeoutId = setTimeout(function () {
                                    saveToDB('FNC_Add_Catering/venue_details_add_update', 'venue_details_form');
                                }, 1000);
                            });

                            $('.sm_rad').click(function () {
                                $(this).siblings('input').prop('checked', true);
                                if ($('#say1').is(':checked')) {
                                    $('#fc_details').val('');
                                    $('input[type="file"]').val('');
                                    $('.say_smthng').show();
                                    $('#fc_details').attr('required', true);
                                    $('#fc_details').attr('minlength', 100);
                                    $('#fc_details').attr('maxlength', 1200);
                                } else {
                                    $('.say_smthng').hide();
                                    $('input[type="file"]').val('');
                                    $('#fc_details').attr('required', false);
                                    $('#fc_details').removeAttr('minlength');
                                    $('#fc_details').removeAttr('maxlength');
                                    $('#fc_details').val('blank');
                                    saveToDB('FNC_Add_Catering/venue_details_add_update', 'venue_details_form');
                                }
                            });

                            $('.my_radio').on('click', function () {
                                var id = $(this).attr('id');
                                if (id == 'say1') {
                                    saveToDB('FNC_Add_Catering/venue_details_add_update', 'venue_details_form');
                                } else {
                                    $('#fc_details').val('blank');
                                    $('input[type="file"]').val('');
                                    $('.upload-button_new1').show();
                                    $('.ezdz-dropzone').show();
                                    $('.dropzone').hide();
                                    $('.removeClass').hide();
                                    $('.menu_name1').text('file name');
                                    saveToDB('FNC_Add_Catering/venue_details_add_update', 'venue_details_form');
                                }
                            });

</script>

