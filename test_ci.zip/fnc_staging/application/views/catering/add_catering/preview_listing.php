<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/owl.carousel.min.css" />
<script src="<?php echo base_url(); ?>assets/js/owl-slider.js"></script>
<div class="row">
    <div class="col-sm-6">
        <img src="<?php echo base_url('assets/images/fnc_logo.svg'); ?>" class="mnFr_logo">
    </div><!-- col-sm-6 ends -->

    <div class="col-sm-6">
        <div class="lnkBox22">
            <p class="clr_cmn">Call us on 03 9088 9000</p>
            <ul class="mnFrmeUl1">
                <li><a href="javascript:void(0)">Create Profile/Listing</a></li>
                <li><a href="javascript:void(0)">Help</a></li>
                <li><a href="javascript:void(0)">Login</a></li>
            </ul>
        </div>
    </div><!-- col-sm-6 ends -->

    <div class="col-sm-12">

        <h3><?php echo!empty($venue_data->fc_business_name) ? $venue_data->fc_business_name : 'Your Business Name' ?></h3>
        <h5><?php echo (!empty($venue_data->fc_street)) ? $venue_data->fc_street . ', ' . $venue_data->fc_suburb . ', ' . $venue_data->fc_country : '1 St Hellers Street, Abbotsford, Victoria, Australia' ?></h5>
        <a href="" class="clr_cmn">
            <h4>Catering</h4>
        </a>
        <h5><?php echo (!empty($venue_data->spaces)) ? 'Spaces Available:' : '' ?></h5>

        <div>
            <?php
            if (!empty($venue_data->spaces)) {
                foreach ($venue_data->spaces as $space) {
                    ?>
                    <a href="javascript:void(0)" class="btn cmn_btn1"><?php echo $space ?></a>
                    <?php
                }
            }
            ?>
        </div>


    </div><!-- col-sm-12 ends -->

    <div class="col-sm-12">
        <div id="myCarousel" class="carousel slide Carouse2" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <?php
                $i = 1;
                if (array_key_exists('fc_images', $venue_data)) {
                    foreach ($venue_data->fc_images as $images) {
                        if ($images) {
                            $banner_img = base_url('uploads/fc_images/') . $images;
                            ?>
                            <div class="item <?php echo ($i == 1) ? 'active' : '' ?>"><img src="<?php echo $banner_img ?>" alt="Venue Images"></div>
                            <?php
                            $i++;
                        }
                    }
                }
                if ($i == 1) {
                    ?>
                    <div class="item active"><img src="<?php echo base_url('assets/images/FnC_banner.jpg'); ?>" alt="Venue Images"></div>
                    <?php
                }
                ?>
            </div>

            <!-- Left and right controls -->
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                <i class="fa fa-angle-left"></i>

            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">
                <i class="fa fa-angle-right"></i>

            </a>
        </div>

    </div><!-- col-sm-12 ends -->

    <div class="col-sm-12">
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                    <?php if (!empty($venue_data->fc_details)) { ?>
                        <div class="col-sm-6">
                            <h5 class="clr_cmn">Overview</h5>
                        </div>
                    <?php } ?>

                    <div class="col-sm-6 ">
                        <?php if (!empty($venue_data->fc_min_guest)) { ?>
                            <h5 class="clr_cmn text-right">Perfect for <?php echo $venue_data->fc_min_guest . '-' . $venue_data->fc_max_guest; ?> Guests</h5>
                        <?php } ?>
                    </div>

                </div>

                <p class="mnFRmePara"><?php echo!empty($venue_data->fc_overview) ? $venue_data->fc_overview : ''; ?></p>

                <?php if (!empty($venue_data->function_type)) { ?>
                    <h4 class="hdng2Mf">Great for function type:</h4>
                    <div class="row venMgRow" id="owl_slider1">
                        <?php
                        foreach ($venue_data->function_type as $function_type) {
                            ?>
                            <div class=" venMgCol">
                                <div class="venMgBx">
                                    <img src="<?php echo base_url('uploads/fnc_types/catering_icon/') . $function_type->image ?>">
                                    <h5><?php echo $function_type->name ?></h5>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                <?php } ?>

                <?php if (!empty($venue_data->menus)) { ?>
                    <h4 class="hdng2Mf">The Catering has menus:</h4>

                    <div class="row venMgRow" id="owl_slider2">
                        <?php
                        foreach ($venue_data->menus as $menus) {
                            ?>
                            <div class=" venMgCol">
                                <div class="venMgBx">
                                    <img src="<?php echo base_url('uploads/fnc_types/catering_icon/') . $menus->image ?>">
                                    <h5><?php echo $menus->name ?></h5>
                                </div>
                            </div>
                        <?php } ?>
                    </div><!-- venMgRow ends -->
                <?php } ?>

                <?php if (!empty($venue_data->cuisine)) { ?>
                    <h4 class="hdng2Mf">The Catering has cuisine:</h4>
                    <div class="row venMgRow" id="owl_slider3">
                        <?php
                        foreach ($venue_data->cuisine as $cuisine) {
                            ?>
                            <div class="venMgCol">
                                <div class="venMgBx" id="">
                                    <img src="<?php echo base_url('uploads/fnc_types/catering_icon/') . $cuisine->image ?>">
                                    <h5><?php echo $cuisine->name ?></h5>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div><!-- venMgRow ends -->
                <?php } ?>

                <?php if (!empty($venue_data->services)) { ?>
                    <h4 class="hdng2Mf">The Catering has services:</h4>
                    <div class="row venMgRow" id="owl_slider4">
                        <?php
                        foreach ($venue_data->services as $services) {
                            ?>
                            <div class="venMgCol">
                                <div class="venMgBx" id="">
                                    <img src="<?php echo base_url('uploads/fnc_types/catering_icon/') . $services->image ?>">
                                    <h5><?php echo $services->name ?></h5>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div><!-- venMgRow ends -->
                <?php } ?>

                <?php
                if ($venue_data->fc_details == 'blank') {
                    $style = 'display:none';
                } else {
                    $style = '';
                }
                if (!empty($venue_data->fc_details)) {
                    ?>
                    <h4 class="clr_cmn" style="<?php echo $style; ?>">The details:</h4>
                    <p class="mnFRmePara" style="<?php echo $style; ?>"><?php echo $venue_data->fc_details ?></p>
                <?php } ?>
                <div>
                    <?php
                    if (array_key_exists('fc_pdfs', $venue_data)) {
                        if (!empty($venue_data->fc_pdfs)) {
                            ?>
                            <h4 class="clr_cmn">Attachments</h4>
                            <div class="row attchRow">
                                <?php
                                foreach ($venue_data->fc_pdfs as $pdfs) {
                                    $pdfImage = base_url('uploads/venue_pdf_image/' . $pdfs->fc_pdf_image);
                                    ?>
                                    <div class="col-sm-3 col-xs-6">
                                        <div class="attch_dv">
                                            <div><img src="<?php echo $pdfImage; ?>" /></div>
                                            <h5 class="clr_cmn"><?php echo $pdfs->fc_pdf_title_name; ?></h5>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
                <h4 class="clr_cmn">Reviews:
                    <ul class="fxRtng">
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                        <li>No reviews</li>
                    </ul>

                </h4>
                <a href="javascript:void(0)" class="btn cmn_btn3 rvw_btn">Write a Review</a>
            </div><!-- col-md-8 ends -->
            <div class="col-md-4">
                <div class="Ven_fcnFrm">
                    <div class="form-group">
                        <label class="lbl_class">Preferred function date</label>
                        <input type="date" class="form-control addr-field" placeholder="dd - mm - yyyy" onfocus="this.placeholder = ''" onblur="this.placeholder = 'dd - mm - yyyy'">
                    </div>
                    <div class="form-group">
                        <label class="lbl_class">Proposed No. of guests</label>
                        <input type="text" class="form-control addr-field" placeholder="Guest Number" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Guest Number'">

                    </div>

                    <div class="form-group">
                        <label class="lbl_class">Type of Event</label>
                        <input type="text" class="form-control addr-field" placeholder="Wedding, birthday, corporate launch etc.." onfocus="this.placeholder = ''" onblur="this.placeholder = 'Wedding, birthday, corporate launch etc..'">

                    </div>

                    <div class="form-group">
                        <label class="lbl_class">Other Queries</label>
                        <input type="text" class="form-control addr-field" placeholder="Queries, Special requirements etc.." onfocus="this.placeholder = ''" onblur="this.placeholder = 'Queries, Special requirements etc..'">

                    </div>

                    <div class="form-group">

                        <span class="btn cmn_btn1">submit</span>

                    </div>

                    <div class="form-group">
                        <p class="csChk2">
                            <input type="checkbox" name="">
                            <label>Add to Favorites</label>
                            <img class="unchkImg" src="<?php echo base_url('assets/images/Add-to-wish-list.png'); ?>">
                            <img class="chkdImg" src="<?php echo base_url('assets/images/Add-to-wish-list_white.png'); ?>">

                        </p>


                        <p class="csChk2">

                            <input type="checkbox" name="">
                            <label>Send to a friend</label>
                            <img class="unchkImg" src="<?php echo base_url('assets/images/6.Send-to-friend(1).svg'); ?>">
                            <img class="chkdImg" src="<?php echo base_url('assets/images/6.Send-to-friend(1).svg'); ?>">

                        </p>
                    </div>
                </div><!-- Ven_fcnFrm ends -->

            </div><!-- col-md-4 ends -->
        </div><!-- row ends -->


    </div><!-- col-sm-12 ends -->

    <div class="col-sm-12">
        <h4 class="clr_cmn">Location:</h4>
        <div id="mapVenue"></div>   
        <div class="ad_banner">
            <img src="<?php echo base_url('assets/images/glenmorangle_add_700X87_new.jpg'); ?>">
        </div>  
    </div>
    <!-- col-sm-12 ends -->
    <div class="col-sm-12" style="display:none;">


        <?php
        if (!empty($nearest_to_me)) {
            ?>
            <h4 class="clr_cmn">You might be like:</h4>
            <div class="row">
                <?php
                $cnt = 0;
                foreach ($nearest_to_me as $key => $value) {
                    if ($value->fc_type == 1) {
                        $url = base_url('web/single_venue/' . encrypt_decrypt('encrypt', $value->fc_id));
                    } else {
                        $url = base_url('web/single_catering/' . encrypt_decrypt('encrypt', $value->fc_id));
                    }

                    if (file_exists('uploads/fc_images/' . $value->fc_img_name) && !empty($value->fc_listing_picture)) {
                        $img_path = base_url('uploads/fc_images/' . $value->fc_listing_picture);
                    } else {
                        $img_path = base_url('assets/images/featured_image.jpg');
                    }
                    ?>
                    <div class="col-sm-6 pd_r7">
                        <div class="VEnSmBx">
                            <h4><?php echo $value->fc_business_name ?></h4>

                            <div>
                                <span class="clr_cmn">Function</span>
                                <ul class="fxRtng">
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li>No reviews</li>
                                </ul>
                            </div>

                            <p class="mnFRmePara"><?php
                                $string = $value->fc_overview;
                                if (strlen($value->fc_overview) > 100) {
                                    $stringCut = substr($value->fc_overview, 0, 100);
                                    $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
                                }
                                echo $string;
                                ?></p>
                            <div class="VEnSmBxImg">
                                <img src="<?php echo $img_path; ?>">
                            </div>
                        </div><!-- VEnSmBx ends -->
                    </div>
                    <?php
                    $cnt++;
                    if ($cnt == 2) {
                        $breack;
                    }
                }
                ?>
            </div><!-- row ends -->
        <?php } ?>

        <!-- <div class="ad_banner">
            <img src="<?php echo base_url('assets/images/glenmorangle_add_700X87_new.jpg'); ?>">
        </div> -->
    </div><!-- col-sm-12 ends -->
</div> <!-- row ends -->
<script>
    var mapReview = '';
    var slider_parameter = {
        autoPlay: false,
        navigation: true,
        items: 6,
        loop: false,
        itemsMobile: [479, 2],
        itemsTablet: [768, 3],
        itemsDesktop: [1199, 5],
        itemsDesktopSmall: [980, 4],
        rewindNav: false,
        navClass: ["nex", "pr"],
        lazyLoad: true,
        // paginationNumbers: false,
        navigationText: ["<img src='" + base_url + "assets/images/left-arrow.png'>", "<img src='" + base_url + "assets/images/right-arrow.png'>"]
    };

    $("#owl_slider1").owlCarousel(slider_parameter);
    $("#owl_slider2").owlCarousel(slider_parameter);
    $("#owl_slider3").owlCarousel(slider_parameter);
    $("#owl_slider4").owlCarousel(slider_parameter);
    /*function loadMapOfReviewListing() {
     
     var lat = <?php echo (!empty($venue_data->fc_lat)) ? $venue_data->fc_lat : -37.815340 ?>;
     var lng = <?php echo (!empty($venue_data->fc_lng)) ? $venue_data->fc_lng : 144.963230 ?>;
     
     var latlng = new google.maps.LatLng(lat, lng);
     var mapReview = new google.maps.Map(document.getElementById('mapVenue'), {
     center: latlng,
     zoom: 12
     });
     
     var marker = new google.maps.Marker({
     map: mapReview,
     position: latlng,
     anchorPoint: new google.maps.Point(0, -29),
     icon: base_url + 'assets/images/map_icon.svg'
     });
     
     var infowindow = new google.maps.InfoWindow();
     google.maps.event.addListener(marker, 'click', function () {
     var iwContent = '';
     // including content to the infowindow
     infowindow.setContent(iwContent);
     
     infowindow.open(mapReview, marker);
     });
     }
     loadMapOfReviewListing();*/

    var operation = "delete";
    var lat = parseFloat($("#venue_lat").val());
    var lng = parseFloat($("#venue_lng").val());
    var add_area = $('.increase_radius_map').attr('data-area_add');

    redraw_area_preview(add_area, lat, lng, operation);

    function redraw_area_preview(add_area, lat, lng, operation) {
        setTimeout(function () {
            var center = new google.maps.LatLng(lat, lng);
            var mapAttr = {
                center: center,
                zoom: 10,
                mapTypeId: google.maps.MapTypeId.TERRAIN
            };
            //$("#map-canvas-2").css("width", "100%");
            //$("#map-canvas-3").css("height", "320px");
            var mapRadius1 = new google.maps.Map(document.getElementById("mapVenue"), mapAttr);
            var defult_area = add_area + 10 * 1000; // here 10 km is defualt area
            var circle = new google.maps.Circle({
                center: center,
                map: mapRadius1,
                radius: defult_area, // IN METERS.
                fillColor: '#0083e7',
                fillOpacity: 0.5,
                strokeColor: "#FFF",
                strokeWeight: 0 // DON'T SHOW CIRCLE BORDER.
            });
            if (operation == "delete") {
                //add_area = 10;
            }
            var circle2 = new google.maps.Circle({
                center: center,
                map: mapRadius1,
                radius: add_area * 1000, // IN METERS.
                fillColor: '#0083e7',
                fillOpacity: 0.4,
                strokeColor: "#FFF",
                strokeWeight: 0 // DON'T SHOW CIRCLE BORDER.
            });
            // $('.increase_radius_map').html('+');
            // $('.my_active').html('-');
        }, 2);
    }

    $(".preview_map").on("click", function () {
        html2canvas($("#mapVenue"), {
            useCORS: true,
            onrendered: function (canvas) {
                var image = canvas.toDataURL("image/png").replace(/^data:/, "");
                var block = image.split(";");
                var contentType = block[0].split(":")[1];
                var realData = block[1].split(",")[1];
                var blob = b64toBlobToMap(realData, contentType);
                var form = $('#page_layout')[0];
                var formData = new FormData(form);
                formData.append('fc_map_image', blob);
                var fc_id = $('#fc_id').val();
                $.ajax({
                    url: '<?php echo base_url('FNC_Add_Catering/map_image_insert') ?>/' + fc_id,
                    type: "POST",
                    dataType: 'json',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (data) {
                        if (data.status) {

                        }
                    },
                });
            }
        });
        setTimeout(function () {
            forwordTo('listing_area');
            businessForwordTo('company_details', false);
        }, 1000);
    });

    function b64toBlobToMap(b64Data, contentType, sliceSize) {
        contentType = contentType || '';
        sliceSize = sliceSize || 512;

        var byteCharacters = atob(b64Data);
        var byteArrays = [];

        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);

            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }

            var byteArray = new Uint8Array(byteNumbers);

            byteArrays.push(byteArray);
        }

        var blob = new Blob(byteArrays, {
            type: contentType
        });
        return blob;
    }
</script>