<div class="row">
    <div class="col-sm-12">
        <div class="sub_hdngs">
            <h3 class="clr_cmn"><span>1/1</span> Listing Area</h3>
            <span class="sv_span">last saved:<span class="clr_cmn form-status-holder"><i class="mylastdate"><?php echo!empty(date("d-m-Y", strtotime($last_date))) && date("d-m-Y", strtotime($last_date)) != '01-01-1970' ? date("d-m-Y", strtotime($last_date)) : ''; ?></i></span><button class="btn cmn_btn1 save_btn2">Save</button></span>
            <div class="clearfix"></div>
        </div>
        <div class="progress prog2">
            <div class="progress-bar" role="progressbar" aria-valuenow="70"
                 aria-valuemin="0" aria-valuemax="100" style="width:100%">
            </div>
        </div> <!-- progress prog2 ends -->    
    </div>
</div><!-- row ends -->
<?php
if (!empty($this->cart->contents())) {
    $style = '';
    $count = count($this->cart->contents());
} else {
    $style = 'display:none';
    $count = 0;
}
?>
<div class="row">

    <div class="col-sm-12">
        <div class="row">
            <div class="col-sm-12">
                <div class="fmHeading2">
                    <span class="billDropdown mini_cart_popup package_cart">
                        <i class="fa fa-shopping-cart openShoppingCart cart_ic addional_area_cart"></i>
                        <span class="noti_circ" style="<?php echo $style; ?>"><?php echo $count; ?></span>

                        <div class="soFarDiv main-cart drop_bill">
                            <div class="soFarHead">Your Account So Far <i class="fa fa-times pull-right"></i></div>
                            <h5 style="text-align:center;">Your Cart is empty.</h5>
                        </div>
                    </span>
                </div> 
            </div>
        </div>


        <div class="row" >

            <div class="col-sm-12">
                <div class="fmHeading2">                    
                    <h3 class="clr_cmn">By default, <a href="javascript:void(0)" class="clr_cmn vn_anch venue_name"></a> will appear in search for <span><span class="council-nm"></span> with a 25KM search radius.</span></h3>                    
                </div> 
            </div>

            <div class="col-md-6 col-sm-12">

                <div class="map23" id="map-canvas-2"></div>
                <div class="row">

                    <!--<div class="col-sm-6">
                        <h3 class="clr_cmn">Is this Correct ?</h3>
                    </div>--><!-- col-sm-6 ends -->
                    <?php
                    /* if(!empty($draft_venue)){
                      if($draft_venue->fc_suburb){
                      $subrup = 'checked';
                      $display ='display:block';

                      }else{
                      $subrup = '';
                      $display ='display:none';
                      }
                      }else{
                      $subrup = '';
                      $display ='display:none';
                      }
                     */
                    ?>
                    <!--<div class="col-sm-6 ">
                        <div class="row text-right pd_T15p">
                            <div class="col-sm-6 col-xs-6">
                                <input type="radio"  name="radio-group2" class="my_radio listing_council_correct" id="correct_yes" checked>
                                <label for="correct_yes" class="clr_cmn ">Yes</label>
                            </div>
                            <div class="col-sm-6 col-xs-6">
                                <input type="radio"  name="radio-group2" class="my_radio listing_council_correct" id="correct_no" <?php echo $subrup; ?> >
                                <label for="correct_no" class="clr_cmn ">No</label>
                            </div>
                        </div> 
                    </div>--><!-- col-sm-6 ends -->


                    <!--<div class="col-sm-12 col-xs-12 if_not_correct" style="display: none">
                        <label class="lbl_class">Please enter your suburb<span class="clr_cmn">*</span></label>
                        <input type="text" name="venue_suburb" class="venue_suburb form-control addr-field ven_txtie" value="<?php echo (!empty($draft_venue->fc_suburb) ? $draft_venue->fc_suburb : ''); ?>" placeholder="Suburb">
                        <a href="javascript:void()" onclick="listingAreaMap(); updateNewSuburb();"><span class="btn cmn_btn1">Update</span> </a>
                    </div>-->


                </div><!-- row ends -->


                <div class="gtVenBx">
                    <h3 class="clr_cmn">Increase your visibility</h3>
				<p>You can increase the area in which you are searchable by up-to 25 square kms.</p>
				<p>Starting at an additional charge of 50 cents a day for 15kms, 75 cents a day for 20kms or 1 dollar a day for 25 kms.</p> <p>Click on the buttons below to expand your search radius.</p>					
                </div>

                <div class="map23" id="map-canvas-3"></div>


                <div class="row mrTp_30">
                </div>


                <form id="addionla_area_form" method="post">
                    <?php
                    //print_r($draft_catering);
                    $draft_service_id = false;
                    $draft_row_id = false;
                    if (isset($draft_service_pack)) {
                        $draft_service_id = $draft_service_pack['id'];
                        $draft_row_id = $draft_service_pack['rowid'];
                    }
                    ?>
                    <form id="addionla_area_form" method="post">
                        <div class="row" id="radius_increas" style="">
                            <div class="col-md-12">
                                <ul class="plus-listing additional_area_catering listingAreaCatering">
                                    <?php
                                    if (!empty($service_area_pack)) {
                                        foreach ($service_area_pack as $key => $value) {
                                            ?>
                                            <li><span data-area_add="<?php echo $value->pro_desc ?>" data-active="0" id="<?php echo $value->pro_id; ?>" class="increase_radius_map plus new_plus_sine caterer_space <?php echo ($value->pro_id == $draft_service_id) ? 'my_active' : '' ?> "><?php echo $value->pro_title; ?></span>
                                            </li>
                                            <?php
                                        }
                                    }
                                    ?>

                                </ul>
                                <input type="hidden" id="cheak_status" value="">
                                <input type="hidden" id="service_product_id" value="<?php echo ($draft_row_id) ? $draft_row_id : '' ?>">
                                <input type="hidden" name="csr_radius_id" id="extra_service_area_id" value="<?php echo ($draft_service_id) ? $draft_service_id : '' ?>">
                            </div>
                        </div>
                        <div class="row mrTp_30"></div>
                    </form>
                </form>


            </div><!-- col-sm-6 ends -->

            <div class="col-md-6 col-sm-12">
            </div><!-- col-sm-6 ends -->




        </div><!-- row ends -->

        <div class="row mrTp40">
            <div class="col-md-6 col-sm-3 col-xs-3" id="backbtn_listarea">
                <a href="JavaScript:void(0);" onclick="forwordTo('page_layout'); listingForwordTo('review_your_listing', false);"><span class="clr_cmn bckie2"><i class="fa fa-angle-left"></i> Back</span></a>
            </div>
            <div class="col-md-6 col-sm-9 col-xs-9 txt_rg1">
                <button class="btn cmn_btn2 frm_bt2 first_div_btn" onclick="forwordTo('payment');">Skip for Now</button>
                <a href="JavaScript:void(0);"  onclick="forwordTo('payment');" data-listing_area_percent1="16.66" class="btn cmn_btn1 frm_bt2 listing_area_percent1" id="nextbtn_listarea">Next</a>
            </div>
        </div>




    </div><!-- col-sm-12 ends -->

</div><!-- row ends -->
<!--</div> col-md-9 col-sm-8 ends -->


