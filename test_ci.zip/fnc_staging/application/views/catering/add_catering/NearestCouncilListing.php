<?php

if (!empty($nearestCouncil)) {
    foreach ($nearestCouncil as $val) {
        $checked = '';
        $active = '';

        if (in_array($val->council_id, $selected_council)) {
            $checked = 'checked';
            $active = 'active';
        }
        ?>
        <div class="col-sm-6 mlCh_cols">
            <p class="cstm_MlChkBx mapChkie25 <?php echo $active ?>">
                <input type="checkbox" name="addional_area[]" value="<?php echo $val->council_id ?>" <?php echo $checked ?> >
                <label><?php echo $val->council ?></label>
            </p>
        </div>
    <?php }
    ?>
    <div class="col-sm-6 mlCh_cols text-right">
        <a href="javascript:void(0)" onclick="applyForAddionalArea();" class="btn cmn_btn1 aol_btn">Apply</a>
    </div>
    <?php
} else {
    ?>  
    <div class="col-sm-6 mlCh_cols">
        <p class="cstm_MlChkBx mapChkie25 active">
            No Near By council found
        </p>
    </div>
    <?php
}
?>


