<div class="soFarHead">Your Account So Far <i onclick="closeCart();" class="fa fa-times pull-right"></i></div>
<?php
//print_r($freeplane);

if (!empty($cart_content)) { ?>

<div class="pckg_bill">
    <?php
    $cnt = 1;
    $productIds = array();
    if (!empty($cart_content)) {
        $productIds = array_column($cart_content, 'id');
    }
    if (!empty($cart_content)) {
        foreach ($cart_content as $rowId => $val) {
            $val = (object) $val;
            if ($val->id == 1 || $val->id == 2) {
                ?>
                <h4 class="clr_cmn">Package</h4>
                <table class="pckg_tble tbleBg">
                    <tr>
                        <td style="width: 75%;"><?php echo $cnt.') '; $cnt++ ?><?php echo $products[$val->id] ?></td>
                        <td style="width:25%;">$<?php echo number_format($val->price, '2') ?><i onclick="removeCartItem(<?php echo $val->id ?>, '<?php echo $rowId ?>');" class="fa fa-times pckg_dlt"></i></td>
                    </tr>
                </table>
                <?php
            }
        }
    }else{?>
        <h4 class="clr_cmn">Package</h4>
                <table class="pckg_tble tbleBg">
                    <tr>
                        <td style="width: 75%;">Free text only listing </td>
                        <td style="width:25%;">$0.00<i onclick="removeCartItem(0, 0);" class="fa fa-times pckg_dlt"></i></td>
                    </tr>
                </table>
    <?php  } ?>

    <?php
	if (!empty($cart_content)) {
        foreach ($cart_content as $rowId => $val) {
            $val = (object) $val;
            if ($val->id == 5 || $val->id == 6 || $val->id == 7) {
                ?>
                <h4 class="clr_cmn">Additional Raduis</h4>
                <table class="pckg_tble tbleBg">
                    <tr>
                        <td style="width: 75%;"><?php echo $cnt.') '; $cnt++ ?><?php echo $products[$val->id] ?></td>
                        <td style="width:25%;">$<?php echo number_format($val->price, '2') ?><i onclick="removeCartItem(<?php echo $val->id ?>, '<?php echo $rowId ?>');" class="fa fa-times pckg_dlt"></i></td>
                    </tr>
                </table>
                <?php
            }
        }
    }?>
	

    <?php if (!empty($cart_content) && in_array(4, $productIds)) { ?>
        <h4 class="clr_cmn mr_nop">Spaces</h4>
        <table class="pckg_tble tbleBg tble2"> 
            <?php
            foreach ($cart_content as $rowId => $val) {
                $val = (object) $val;
                if ($val->id == 4) {
                    ?>    
                    <tr>
                        <td style="width: 75%;"><?php echo $cnt.') '; $cnt++ ?>Additional spaces area (<?php echo $val->options['space_name'] ?>)</td>
                        <td style="width: 25%;">$<?php echo number_format($val->price, '2') ?> 
                            <i onclick="removeCartItem(<?php echo $val->id ?>, '<?php echo $rowId ?>');" class="fa fa-times pckg_dlt"></i>
                        </td>
                    </tr>
                    <?php
                }
            }
            ?>
        </table>
        <?php
    }
    ?>

    <?php if (!empty($cart_content) && in_array(3, $productIds)) { ?> 
        <h4 class="clr_cmn mr_nop">Listing Area</h4>
        <table class="pckg_tble tbleBg tble2">
            <?php
            foreach ($cart_content as $rowId => $val) {
                $val = (object) $val;
                if ($val->id == 3) {
                    ?>   
                    <tr>
                        <td style="width: 75%;"><?php echo $cnt.') '; $cnt++ ?>Additional listing area (<?php echo $val->options['council'] ?>)</td>
                        <td style="width:25%;">$<?php echo number_format($val->price, '2') ?> <i onclick="removeCartItem(<?php echo $val->id ?>, '<?php echo $rowId ?>');" class="fa fa-times pckg_dlt"></i></td>
                    </tr>
                    <?php
                }
            }
            ?>   
        </table>
    <?php }
    ?>

    <table class="pckg_tble ">
        <tr>
            <td style="width: 75%;">Subtotal</td>
            <td style="width:25%;">$<?php echo number_format($sub_total, '2') ?> </td>
        </tr>
        <tr>
            <td>GST</td>
            <td>$<?php echo number_format($gst, '2') ?> </td>
        </tr>
        <tr>
            <td colspan="2"><div class="clr_bor"></div></td>
        </tr>

        <tr>
            <td><h4 class="clr_cmn">Total</h4></td>
            <td><h4 class="clr_cmn">$<?php echo number_format($total,'2') ?></h4> </td>
        </tr>
    </table>

</div>

<?php }else if(!empty($free) == 1){
    echo '<h5 style="text-align:center;">You are choosing the free plan.<h5/>';
    ?>  
     <!--   <div class="free_msg"></div>
        <div class="pckg_bill">
         <h4 class="clr_cmn clk_free" >Package</h4>
            <table class="pckg_tble tbleBg clk_free">
                <tr>
                    <td style="width: 75%;">Free text only listing </td>
                    <td style="width:25%;">$0.00<i onclick="removeCartItem(8, 8);" class="fa fa-times pckg_dlt"></i></td>
                </tr>
            </table>
            <table class="pckg_tble ">
        <tr>
            <td style="width: 75%;">Subtotal</td>
            <td style="width:25%;">$0.00 </td>
        </tr>
        <tr>
            <td>GST</td>
            <td>$0.00</td>
        </tr>
        <tr>
            <td colspan="2"><div class="clr_bor"></div></td>
        </tr>

        <tr>
            <td><h4 class="clr_cmn">Total</h4></td>
            <td><h4 class="clr_cmn">$0.00</h4> </td>
        </tr>
    </table>
    </div> -->
    <?php
}else{
        echo '<h5 style="text-align:center;">Your Cart is empty.<h5/>';
}
?>