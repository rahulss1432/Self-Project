<div class="col-lg-10 col-lg-offset-1 col-md-12 prog_col55">
    <h3>Add New Catering</h3>
    <ul class="venueProgbar cateringProgbar">

        <li class="progess_bar business_details active">
            <a  onclick="forwordTo('business_details', 'getPaymentCart'); businessForwordTo('company_details', false);" >Business Details<img src="<?php echo site_url();?>assets/images/System_warning.svg" class="error_icon_2"/></a>
        </li> 
        <li class="progess_bar package ">
            <a  onclick="forwordTo('package', 'getPaymentCart')" >Package<img src="<?php echo site_url();?>assets/images/System_warning.svg" class="error_icon_2"/></a>
        </li> 
        <li class="progess_bar catering_details">
            <a  onclick="forwordTo('catering_details', 'getPaymentCart'); venuDetailsForwordTo('venu_description', false)" >Catering Details<img src="<?php echo site_url();?>assets/images/System_warning.svg" class="error_icon_2"/></a>
        </li> 
        <li class="progess_bar page_layout ">
            <a  onclick="forwordTo('page_layout', 'getPaymentCart'); listingForwordTo('upload_image', false);" >Page Layout<img src="<?php echo site_url();?>assets/images/System_warning.svg" class="error_icon_2"/></a>
        </li> 
        <li class="progess_bar listing_area ">
            <a  onclick="forwordTo('listing_area', 'getPaymentCart')" >Listing Area<img src="<?php echo site_url();?>assets/images/System_warning.svg" class="error_icon_2"/></a>
        </li> 
        <li class="progess_bar payment ">
            <a  onclick="forwordTo('payment', 'getPaymentCart')" >Payment</a>
        </li>
    </ul>
    <div class = "clearfix"></div>
</div>