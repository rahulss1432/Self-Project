<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<link href="<?php echo base_url('assets/css/imgareaselect.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/css/new-style.css'); ?>">
<script type="text/javascript">
    var draft_service_area = '<?php echo (!empty($plan_id)) ? $plan_id : 'false' ?>';
    var draft_open = '<?php echo (!empty($draf_catering)) ? 1 : 'false' ?>';
    var update_pricing_show = '<?php echo site_url('catering/update_pricing_show'); ?>';
    var add2cart = '<?php echo site_url('catering/add2cart'); ?>';
    var removeCart = '<?php echo site_url('catering/removeCart'); ?>';
    var getPricing = '<?php echo site_url('catering/get_pricing'); ?>';
    var save_profile_uri = '<?php echo site_url('catering/save_profile'); ?>';
    var search_suburb = '<?php echo site_url('web/search_suburb'); ?>';
    var search_postcode = '<?php echo site_url('web/search_postcode'); ?>';
    var search_area = '<?php echo site_url('venue/search_area'); ?>';
    var councilURL = '<?php echo site_url('venue/check_council'); ?>';
    var get_cart = '<?php echo site_url('venue/get_cart'); ?>';
    var free = '<?php echo ($free == 'free') ? 1 : 0 ?>';
    var baseURL = '<?php echo site_url(''); ?>';
    var STRIPE_PUBLIC_KEY = '<?php echo STRIPE_PUBLIC_KEY; ?>';
</script>
<script src="<?php echo base_url('assets/js/custom/add-catering.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.ezdz.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/crope_images.js'); ?>"></script>
<section class="function_vene_page" id="add_catering_header">
    <div class="container">
        <div class="row main_row">
            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>
            <!-- Loading Side Menu -->
            <?php $this->load->view('side_menu'); ?>

            <div class="col-sm-8">
                <div class="col-md-12 set_col_md_106">
                    <div class="row">

                        <!-- progress bar -->
                        <div id="top-txt">
                            <div class="list_your_venu_content">List your catering for a little as $1 a day.</div>
                            <div class="opening_your_venue_content">Opening your catering service to
                                <span class="text_wold_start_contert">the world starts here.</span>
                            </div>
                        </div>
                        <ul id="progressbar">
                            <li class="active">Packages</li>
                            <li>Service area</li>
                            <li>Catering details</li>
                            <li>Review and pay</li>
                        </ul>

                        <form id="msform" action="<?php echo site_url('catering/save_catering'); ?>" method="post" enctype="multipart/form-data">

                            <fieldset class="fieldset_1">
                                <div class="row">
                                    <div class="display_flex_set_d">
                                        <?php
                                        if (!empty($packs)) {
                                            foreach ($packs as $key => $value) {
                                                ?>
                                                <div class="col-md-6 col-sm-6 border_price_box <?php echo ($plan_id == $value->pro_id) ? 'first_b_o_x' : '' ?>" id="pack<?php echo $key; ?>">
                                                    <span>
                                                        <div class="price_title <?php echo ($plan_id == $value->pro_id) ? 'first_b_o_x' : '' ?>" id="pack-title<?php echo $key; ?>">
                                                            <div class="price_content <?php echo ($plan_id == $value->pro_id) ? 'first_b_o_x' : '' ?>" id="pack-content<?php echo $key; ?>">
                                                                <?php echo $value->pro_title; ?>
                                                            </div>
                                                        </div>
                                                        <?php if ($value->pro_save != 0) { ?>
                                                        <div class="offet_side_bar"><a>Save $<?php echo $value->pro_save; ?></a></div>
                                                        <?php } ?>

                                                        <div class="offer_box_padding" id="pack-padding<?php echo $key; ?>">
                                                            <?php echo $value->pro_desc; ?>
                                                            <div class="choose_this_button">
                                                                <a data-pack="<?php echo $key; ?>" data-packtype="<?php echo $value->pro_id; ?>" class="choose_plan <?php echo ($plan_id == $value->pro_id) ? 'selected' : '' ?>" href="javascript:;">Choose this plan</a>
                                                            </div>
                                                        </div>
                                                    </span>
                                                </div><!--col-md-6-->
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                </div><!--row-->

                                <div class="row">
                                    <div class="col-md-12">
                                        <div  id="free-div" class="col-md-12 border_box_1 offer_box_padding <?php echo ($free == 'free') ? 'first_b_o_x' : ''; ?>">
                                            <div class="col-md-7">
                                                <div class="no_thanks_content">No thanks, free text only listing</div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="choose_this_button second">
                                                    <a id="free-plan"  onclick="free_plan();" class="text-only" href="javascript:;">Choose this plan</a>
                                                    <input type="hidden" id="free" name="free" value="<?php echo ($free == 'free') ? 1 : 0 ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--row-->


                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="padding_and_border_top_bottom">
                                            <div class="Your_total">
                                                Your total
                                            </div>

                                            <div class="your_price_show" id="pack_price">
                                                $0
                                            </div>
                                            <input type="hidden" name="plan1" id="plan1" value="<?php echo (isset($plan_id)) ? $plan_id : 0 ?>">
                                        </div>
                                    </div>
                                </div><!--row-->
                                <input type="hidden" name="rewiew_listing" id="rewiew_listing_handle" value="<?php echo (isset($draf_catering)) ? 1 : 0 ?>">
                                <input  type="button" name="next" <?php echo (isset($draf_catering)) ? '' : '"disabled="true"' ?> id="continue2venue" class="next action-button" value="Continue to Catering location"/>
                            </fieldset>
                            <!--first-section-->
                            <!--first-section-->

                            <fieldset class="fieldset_1">
                                <div class="col-sm-12 profile_row border_progress_page">
                                    <div class="row top_background"><h4>What is your business address </h4></div>
                                    <div class="row">
                                        <div class="col-lg-12 margin_top_row_106">
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_street">Street</label>
                                                <input type="text" class="form-control addr-field" id="fc_street" name="fc_street" value="<?php echo (isset($draf_catering[0]->fc_street)) ? $draf_catering[0]->fc_street : '' ?>">
                                                <label style="display: none;" id="fc_street-error" class="custom-error"></label>
                                            </div>
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_state">State</label>
                                                <input type="text" class="form-control addr-field " id="fc_state" name="fc_state" value="<?php echo (isset($draf_catering[0]->fc_state)) ? $draf_catering[0]->fc_state : '' ?>">
                                                <label style="display: none;" id="fc_state-error" class="custom-error"></label>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_suburb">Suburb</label>
                                                <input type="text" class="form-control addr-field ui-autocomplete-input valid ui-autocomplete-loading" id="fc_suburb" name="fc_suburb" value="<?php echo (isset($draf_catering[0]->fc_suburb)) ? $draf_catering[0]->fc_suburb : '' ?>"> 
                                                <label style="display: none;" id="fc_suburb-error" class="custom-error"></label>
                                            </div>
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_postcode">Postcode</label>
                                                <input type="number" class="form-control addr-field ui-autocomplete-input" id="fc_postcode" name="fc_postcode" value="<?php echo (isset($draf_catering[0]->fc_postcode)) ? $draf_catering[0]->fc_postcode : '' ?>">
                                                <label style="display: none;" id="fc_postcode-error" class="custom-error"></label>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="col-md-6 margin_set_input">
                                                <label class="lbl_class" for="venue_country">Country</label>
                                                <input type="text" readonly="" class="form-control addr-field" id="fc_country" name="fc_country" value="Australia">
                                                <label style="display: none;" id="fc_country-error" class="custom-error"></label>
                                            </div>
                                            <div class="col-md-6 margin_set_input">
                                                <input type="hidden" class="form-control addr-field" id="fc_council" name="fc_council">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <input type="button" id="show-map-catering" onclick="initialize();" class="create_map" value="Create map">
                                        <input type="hidden" id="council_arr" value="[]">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12 margin_106">
                                        <h3 style="display: none;"  class="opening_your_venue_content your_venue_1 font_your_venue">Your venue will appear in '<span id="city-nm"></span>' with a 25km search radius.</h3>

                                        <div id="radius-map-1"></div>
                                        <input type="hidden" id="lat-f" name="fc_lat" value="<?php echo (isset($draf_catering[0]->fc_lat)) ? $draf_catering[0]->fc_lat : '' ?>">
                                        <input type="hidden" id="lng-f" name="fc_lng" value="<?php echo (isset($draf_catering[0]->fc_lng)) ? $draf_catering[0]->fc_lng : '' ?>">

                                        <h3 style="display: none;" id="second_map_heading" class="opening_your_venue_content your_venue_1 font_your_venue">You can increase your service area 15 km for 50c per day, or increase your service  area 25km for 1$ per day.
                                        </h3>
                                        <div id="radius-map-2"></div>
                                    </div>
                                </div>


                                <div id="additional-area-row" class="row" style="display: none;">
                                    <div class="col-md-12">
                                        <ul class="plus-listing">
                                            <li>
                                                <a href="javascript:;" class="add-area" data-cnt="1"><span class="plus">+</span></a>
                                                <span class="plus-section">
                                                    <input type="text" id="addition-area1" style="background-color: #efefef; border: none; padding: 0px; font-size: unset;" placeholder="Region name" name="add_arr[]" class="addition-ar">
                                                </span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <?php
                                $draft_service_id = false;
                                $draft_row_id = false;
                                if (isset($draft_service_pack)) {
                                    $draft_service_id = $draft_service_pack['id'];
                                    $draft_row_id = $draft_service_pack['rowid'];
                                }
                                ?>
                                <div class="row" id="radius_increas" style="display:none">
                                    <div class="col-md-12">
                                        <ul class="plus-listing">
                                            <?php
                                            if (!empty($service_area_pack)) {
                                                foreach ($service_area_pack as $key => $value) {
                                                    ?>
                                                    <li><span data-area_add="<?php echo $value->pro_desc ?>" data-active="0" id="<?php echo $value->pro_id; ?>" class="increase_radius_map plus new_plus_sine <?php echo ($value->pro_id == $draft_service_id) ? 'my_active' : '' ?> "><?php echo ($value->pro_id == $draft_service_id) ? '-' : '+' ?></span><span class="plus-section plus_sec_510"><?php echo $value->pro_title; ?></span></li>
                                                    <?php
                                                }
                                            }
                                            ?>
                                            <input type="hidden" id="cheak_status" value="">
                                            <input type="hidden" id="service_product_id" value="<?php echo ($draft_row_id) ? $draft_row_id : '' ?>">
                                            <input type="hidden" name="csr_radius_id" id="extra_service_area_id" value="<?php echo ($draft_service_id) ? $draft_service_id : '' ?>">
                                        </ul>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="padding_and_border_top_bottom">
                                            <div class="Your_total">
                                                Your total
                                            </div>
                                            <div class="your_price_show">
                                                $0
                                            </div>
                                            <input type="hidden" name="plan2" id="plan2" value="3">
                                            <input type="hidden" id="firstcart" value="<?php echo (!empty($first_cart)) ? $first_cart : '' ?>">
                                        </div>
                                    </div>
                                </div><!--row-->

                                <!-- <input type="button" name="previous" class="previous action-button-previous" value="Previous"/> -->
                                <input type="button" style="display:none" id="next2details" disabled="true" name="next" class="next action-button" value="Continue to catering Details"/>
                            </fieldset>
                            <!--second-section-->
                            <!--second-section-->
                            <?php
                            if (isset($draf_catering[0]->fc_id)) {
                                $check_url = site_url('catering/check_business_name/') . '?fc_id=' . $draf_catering[0]->fc_id;
                            } else {
                                $check_url = site_url('catering/check_business_name');
                            }
                            ?>
                            <fieldset class="fieldset_1">
                                <div class="col-sm-12 profile_row border_progress_page fountion_1">
                                    <div class="row top_background">
                                        <h4>Catering </h4></div>
                                        <div class="row">
                                            <div class="col-lg-12 margin_top_row_106">
                                                <div class="col-md-6 margin_set_input">
                                                    <label class="lbl_class" for="venue_business_name">Business name</label>
                                                    <input type="text" data-msg-remote="this name already exist" data-rule-remote="<?php echo $check_url ?>" class="form-control" data-rule-required="true"  id="fc_business_name" name="fc_business_name" value="<?php echo (isset($draf_catering)) ? $draf_catering[0]->fc_business_name : '' ?>">
                                                </div>
                                                <div class="col-md-6 margin_set_input">
                                                    <label class="lbl_class" for="venue_abn">ABN</label>
                                                    <input type="text"  class="form-control" data-rule-required="true" data-rule-abn_number="true"id="fc_abn" name="fc_abn" value="<?php echo (isset($draf_catering[0]->fc_abn)) ? $draf_catering[0]->fc_abn : '' ?>">
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="col-md-6 margin_set_input">
                                                    <label class="lbl_class" for="venue_contact_name">Contact name</label>
                                                    <input type="text" class="form-control" data-rule-required="true" id="fc_contact_name" name="fc_contact_name" value="<?php echo (isset($draf_catering[0]->fc_contact_name)) ? $draf_catering[0]->fc_contact_name : '' ?>">
                                                </div>
                                                <div class="col-md-6 margin_set_input">
                                                    <label class="lbl_class" for="venue_phone_no">Phone number</label>
                                                    <input type="text"  class="form-control phone_no" data-rule-required="true" id="fc_phone_no" name="fc_phone_no" value="<?php echo (isset($draf_catering[0]->fc_phone_no)) ? $draf_catering[0]->fc_phone_no : '' ?>">
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="col-md-6 margin_set_input">
                                                    <label class="lbl_class" for="venue_website">Website</label>
                                                    <input type="text"  class="form-control" data-rule-required="true" id="fc_website" name="fc_website" value="<?php echo (isset($draf_catering[0]->fc_website)) ? $draf_catering[0]->fc_website : '' ?>">
                                                </div>
                                                <div class="col-md-6 margin_set_input">
                                                    <label class="lbl_class" for="venue_email">Email</label>
                                                    <input type="email" class="form-control" data-rule-required="true" id="fc_email" name="fc_email" value="<?php echo (isset($draf_catering[0]->fc_email)) ? $draf_catering[0]->fc_email : '' ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- col-sm-12 -->

                                    <?php 
                                    if (!empty($draf_catering[0]->fc_listing_picture)) {
                                        $img_url = base_url('uploads/fc_images') . '/' . $draf_catering[0]->fc_listing_picture;
                                    }else{
                                        $img_url='';
                                    }
                                    ?>

                                    <div class="col-sm-12 profile_row border_progress_page fountion_1">
                                        <div class="row top_background">
                                            <h4>Listing Picture </h4>
                                        </div>
                                        <div class="row margin_top_row_second_106 up-image-row">
                                            <div class="col-md-12 text-left">
                                                <div  class="ulpading_img_size_3 listing_picture_thumb">
                                                    <img  id="show_image_55555" class="dropzone" img-id="55555" src="<?php echo $img_url; ?>" style="<?php echo ($img_url == '')? 'display: none;' : 'display:block;' ?>">
                                                    <input type="file" onclick="this.value=null;" name="fc_listing_picture" data-id="55555" class="file-selector image_selector" id="image_selector_55555" accept="image/*">
                                                    <input type="hidden" name="dimesion_image_55555" id="dimesion_image_55555" value="0">
                                                    <img class="remove_image" onclick="removeImage(1, '<?php echo (isset($draf_catering[0]->fc_id)) ? encrypt_decrypt('encrypt', $draf_catering[0]->fc_id) : 0 ?>', <?php echo (isset($draf_catering[0]->fc_id)) ? 1 : 2 ?>, 55555)" src="<?php echo base_url(REMOVE_IMAGE) ?>">
                                                </div>
                                                <div class="ulpading_img_size_3_1 listing_picture_thumb">
                                                    <div>
                                                        To have your venue looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 300 x 530 pixels.
                                                    </div>
                                                    <div class="row" >
                                                        <label ant-id="55555" class="upload-button_new after_102" id="another_select_55555">
                                                            <i  class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-sm-12 profile_row fountion_2">
                                        <div class="row top_background text-left">
                                            <h4>Catering images</h4>
                                        </div>
                                        <?php
                                        $last_key = 1;
                                        $img_status = TRUE;
                                        $img_count = 5;
                                        if (!empty($draft_catering_images)) {
                                            foreach ($draft_catering_images as $key => $value) {
                                                $img_url = (!empty($value->fc_img_name)) ? base_url('uploads/fc_images') . '/' . $value->fc_img_name : '';
                                                ?>
                                                <div class="row margin_top_row_second_106 up-image-row">
                                                    <div class="col-md-12 text-left">
                                                        <div class="ulpading_img_size_3">
                                                            <img style="display:<?php echo ($img_url) ? 'block' : 'none' ?>" img-id="<?php echo ($key + 1); ?>" class="dropzone" id="show_image_<?php echo ($key + 1); ?>" src="<?php echo $img_url ?>">
                                                            <input onclick="this.value = null;" type="file" name="fc_img_name<?php echo ($key + 1); ?>" data-id="<?php echo ($key + 1); ?>" class="file-selector image_selector" id="image_selector_<?php echo ($key + 1); ?>" accept="image/*">
                                                            <input type="hidden" name="dimesion_image_<?php echo ($key + 1); ?>" id="dimesion_image_<?php echo ($key + 1); ?>" value="0">
                                                            <img onclick="removeImage(2, '<?php echo encrypt_decrypt('encrypt', $value->fc_img_id); ?>', 1, <?php echo $key + 1; ?>)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                                        </div>
                                                        <div class="ulpading_img_size_3_1">
                                                            <?php
                                                            if ($key == 0) {
                                                                $img_status = FALSE;
                                                                ?>
                                                                <div>
                                                                    To have your catering looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                                </div>
                                                                <?php } ?>
                                                                <div class="row">
                                                                    <label ant-id="<?php echo ($key + 1); ?>" class="upload-button_new after_102" id="another_select_<?php echo ($key + 1); ?>">
                                                                        <input type="hidden"  name="image<?php echo ($key + 1); ?>" value="<?php echo $value->fc_img_id; ?>">
                                                                        <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php
                                                    $last_key = $key+1;
                                                    $img_count = $img_count - 1;
                                                }
                                                $last_key =  $last_key+1;
                                            }

                                            if ($img_count > 0) {
                                                $crp = $last_key;
                                                ?>
                                                <input type="hidden" name="img_count" value="<?php echo $img_count; ?>">
                                                <?php
                                                for ($i = 1; $i <= ($img_count); $i++) {
                                                    ?>
                                                    <div class="row margin_top_row_second_106 up-image-row">
                                                        <div class="col-md-12 text-left">
                                                            <div  class="ulpading_img_size_3 ">
                                                                <img  id="show_image_<?php echo $crp; ?>" class="dropzone" img-id="<?php echo $crp; ?>" src="" style="display:none">
                                                                <input type="file" name="fc_img_name<?php echo $crp; ?>" data-id="<?php echo $crp; ?>" class="file-selector image_selector" id="image_selector_<?php echo $crp; ?>" accept="image/*">
                                                                <input type="hidden" name="dimesion_image_<?php echo $crp; ?>" id="dimesion_image_<?php echo $crp; ?>" value="0">
                                                                <img onclick="removeImage(2, '0', 2, <?php echo $crp; ?>)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                                            </div>
                                                            <div class="ulpading_img_size_3_1">
                                                                <?php
                                                                if ($img_status) {
                                                                    $img_status = FALSE;
                                                                    ?>
                                                                    <div>
                                                                        To have your catering looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                                    </div>
                                                                    <?php } ?>
                                                                    <div class="row" >
                                                                        <label ant-id="<?php echo $crp; ?>" class="upload-button_new after_102" id="another_select_<?php echo $crp; ?>">
                                                                            <i  class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php
                                                        $crp++;
                                                    }
                                                }
                                                ?>
                                                <div class="clearfix"></div>
                                                <div class="row margin_top_ohNo">
                                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                                        <div style="display:none" class="oh_no_content">Not happy with your photos? Elect to have professional photos done and we'll be in touch shortly. </div>
                                                    </div>
                                                    <div class="col-md-6 bottom_button col-sm-12 col-xs-12">

                                                        <input type="hidden" data-rule-required="true" name="need_photography" id="need_photography" value="0">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 profile_row fountion_3">
                                                <div class="row top_background text-left">
                                                    <h4>Price per head </h4>
                                                </div>
                                                <div class="row">
                                                    <div class="text-left">
                                                        <div class="col-md-6">
                                                            <?php
                                                            $price_arr = array();

                                                            if (!empty($draf_catering[0]->fc_pricing)) {
                                                                $price_arr = explode(',', $draf_catering[0]->fc_pricing);
                                                            }

                                                            if (!empty($price_per_head)) {
                                                                $dollar_count = 1;
                                                                foreach ($price_per_head as $value) {
                                                                    ?>
                                                                    <label class="set_label_venu">
                                                                      <?php
                                                                      $checked_pricing = '';
                                                                      if (in_array($value->p_id, $price_arr)) {
                                                                        $checked_pricing = 'checked';
                                                                    //die;
                                                                    }
                                                                    ?>
                                                                    <label class="regular-checkbox pull-left r-p-n-501">
                                                                        <input name="fc_pricing[]" type="checkbox" value="<?php echo $value->p_id; ?>" <?php echo $checked_pricing; ?>>
                                                                        <small></small>
                                                                    </label>
                                                                    <div class="dolor_icon"><?php
                                                                        for ($i = 0; $i < $dollar_count; $i++) {
                                                                            echo '$';
                                                                        }
                                                                        ?></div>
                                                                        <span><?php echo $value->p_name; ?></span>
                                                                    </label>
                                                                    <?php
                                                                    if ($dollar_count % 2 == 0)
                                                                        echo '</div><div class="col-md-6">';

                                                                    $dollar_count++;
                                                                }
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 profile_row fountion_4">
                                                <div class="row top_background text-left">
                                                    <h4>Overview-Catering Details</h4>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12 text-left">
                                                        <label class="" for="venue_description">Overview</label>
                                                        <textarea rows="4" class="form-control overview_textarea textare_root" id="venue_description" data-rule-required="true" data-rule-maxlength="400"  name="fc_overview" placeholder="This is a short introductory overview that describes your Catering. &#10;Max 400 words."><?php echo (isset($draf_catering[0]->fc_overview)) ? $draf_catering[0]->fc_overview : '' ?></textarea>
                                                    </div>
                                                </div>

                                                <div class="row margin_top_ohNo">
                                                    <div class="col-md-8 col-xs-12 col-sm-12">
                                                        <div class="oh_no_content">Struggling to come up with the right words? Do your best but then elect for our professional copy writers to review and write your Catering description. We'll be in touch shortly.</div>
                                                    </div>
                                                    <div class="col-md-4 bottom_button col-xs-12 col-sm-12">
                                            <!--<button type="button" id="venue-copy" class="i_need_venue_button">I need Catering copy</button>
                                            <input type="hidden" name="need_cateringcopy" id="need_venuecopy" value="0">-->
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_5">
                                    <div class="row top_background text-left">
                                        <h4>Function types</h4>
                                    </div>
                                    <div class="row margin_top_row_second_106">
                                        <div class="form-check form-check-inline">

                                            <?php
                                            $function_type_arr = array();

                                            if (!empty($draft_catering_details)) {
                                                if (!empty($draft_catering_details[0]->cd_function_type)) {
                                                    $function_type_arr = explode(',', $draft_catering_details[0]->cd_function_type);
                                                }
                                            }


                                            if (!empty($function_types)) {
                                                foreach ($function_types as $f_type) {
                                                    ?>
                                                    <div class="col-md-6 text-left pass">

                                                        <label class="set_label_venu">
                                                            <?php
                                                            $checked_event = '';
                                                            if (in_array($f_type->id, $function_type_arr)) {
                                                                $checked_event = 'checked';
                                                            }
                                                            ?>
                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                <input type="checkbox" name="cd_function_type[]" value="<?php echo $f_type->id; ?>" <?php echo $checked_event; ?>>
                                                                <small></small>
                                                            </label>
                                                            <div class="dolor_icon size_set_ic"><img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $f_type->image; ?>"></div>
                                                            <span><?php echo $f_type->name; ?></span>

                                                        </label>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_6">
                                    <div class="row top_background text-left">
                                        <h4>Menus</h4>
                                    </div>
                                    <div class="row margin_top_row_second_106">
                                        <div class="form-check form-check-inline">

                                            <?php
                                            $menus_arr = array();

                                            if (!empty($draft_catering_details)) {
                                                if (!empty($draft_catering_details[0]->cd_menus)) {
                                                    $menus_arr = explode(',', $draft_catering_details[0]->cd_menus);
                                                }
                                            }

                                            if (!empty($menus)) {
                                                foreach ($menus as $m_val) {
                                                    ?>
                                                    <div class="col-md-6 text-left pass_1">
                                                        <label class="set_label_venu">
                                                            <?php
                                                            $checked_facility = '';
                                                            if (in_array($m_val->id, $menus_arr)) {
                                                                $checked_facility = 'checked';
                                                            }
                                                            ?>
                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                <input type="checkbox" name="cd_menus[]" value="<?php echo $m_val->id; ?>" <?php echo $checked_facility; ?>>
                                                                <small></small>
                                                            </label>
                                                            <div class="dolor_icon size_set_ic">
                                                                <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $m_val->image; ?>">
                                                            </div>
                                                            <span><?php echo $m_val->name; ?></span>

                                                        </label>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_6">
                                    <div class="row top_background text-left">
                                        <h4>Cuisine</h4>
                                    </div>
                                    <div class="row margin_top_row_second_106">
                                        <div class="form-check form-check-inline">

                                            <?php
                                            $cuisine_arr = array();

                                            if (!empty($draft_catering_details)) {
                                                if (!empty($draft_catering_details[0]->cd_cuisine)) {
                                                    $cuisine_arr = explode(',', $draft_catering_details[0]->cd_cuisine);
                                                }
                                            }

                                            if (!empty($cuisine)) {
                                                foreach ($cuisine as $c_val) {
                                                    ?>
                                                    <div class="col-md-6 text-left pass_1">
                                                        <label class="set_label_venu">
                                                            <?php
                                                            $checked_feature = '';
                                                            if (in_array($c_val->id, $cuisine_arr)) {
                                                                $checked_feature = 'checked';
                                                            }
                                                            ?>
                                                            <label class="regular-checkbox pull-left r-p-n-501">
                                                                <input type="checkbox" name="cd_cuisine[]" value="<?php echo $c_val->id; ?>" <?php echo $checked_feature; ?>>
                                                                <small></small>
                                                            </label>
                                                            <div class="dolor_icon size_set_ic">
                                                                <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $c_val->image; ?>">
                                                            </div>
                                                            <span><?php echo $c_val->name; ?></span>

                                                        </label>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12 profile_row fountion_6">
                                    <div class="row top_background text-left">
                                        <h4>Services</h4>
                                    </div>
                                    <div class="row margin_top_row_second_106">
                                        <div class="form-check form-check-inline">

                                            <?php
                                            $services_arr = array();

                                            if (!empty($draft_catering_details)) {
                                                if (!empty($draft_catering_details[0]->cd_services)) {
                                                    $services_arr = explode(',', $draft_catering_details[0]->cd_services);
                                                }
                                            }

                                            if (!empty($catering_services)) {
                                                foreach ($catering_services as $s_val) {
                                                    ?>
                                                    <div class="col-md-6 text-left pass_1">
                                                        <label class="set_label_venu">
                                                           <span><?php echo $s_val->name; ?></span>
                                                           <?php
                                                           $checked_feature = '';
                                                           if (in_array($s_val->id, $services_arr)) {
                                                            $checked_feature = 'checked';
                                                        }
                                                        ?>
                                                        <label class="regular-checkbox pull-left r-p-n-501">
                                                            <input  type="checkbox" name="cd_services[]" value="<?php echo $s_val->id; ?>" <?php echo $checked_feature; ?>>
                                                            <small></small>
                                                        </label>
                                                        <div class="dolor_icon size_set_ic">
                                                            <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $s_val->image; ?>">
                                                        </div>

                                                    </label>
                                                </div>
                                                <?php
                                            }
                                        }
                                        ?>

                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-12 profile_row fountion_7">
                                <div class="row top_background text-left">
                                    <h4>Catering in detail</h4>
                                </div>
                                <div class="row margin_top_row_second_106">
                                    <div class="col-md-12 text-left">
                                        <label class="text-left" for="venue_description">Details</label>
                                        <textarea rows="4" name="fc_details" class="form-control overview_textarea textare_root" placeholder="This section allows for more Catering details if required. Not mandatory. &#10;Max 800 words"   data-rule-required="true" data-rule-maxlength="800" ><?php echo (isset($draf_catering[0]->fc_details)) ? $draf_catering[0]->fc_details : '' ?></textarea>
                                    </div>
                                </div>

                                <div class="row margin_top_and_bottom_user">
                                    
                                    <div class="col-md-6 text-left">
                                        <label class="lbl_class"  for="venue_max_guest">Minimum guest numbers</label>
                                        <input type="text" data-rule-lessThan="#max_guest" id="min_guest"  data-rule-required="true" class="form-control"  name="fc_min_guest" value="<?php echo (isset($draf_catering[0]->fc_max_guest)) ? $draf_catering[0]->fc_min_guest : '' ?>">
                                    </div>
                                    <div class="col-md-6 text-left">
                                        <label class="lbl_class"  for="venue_min_guest">Maximum guest numbers</label>
                                        <input type="text" data-rule-greaterThan="#min_guest" id="max_guest" data-rule-required="true" class="form-control" name="fc_max_guest" value="<?php echo (isset($draf_catering[0]->fc_min_guest)) ? $draf_catering[0]->fc_max_guest : '' ?>">
                                    </div>
                                </div>
                            </div>


                            <div class="col-md-12 margin_top_but_102">
                                <div class="row save_profile">
                                    <input type="hidden" id="total_another" name="total_another" value="0">
                                    <input type="hidden" name="plan3" id="plan3" value="4">
                                    <input type="hidden" name="fc_id" id="fc_id" value="<?php echo (isset($draf_catering[0]->fc_id)) ? encrypt_decrypt('encrypt', $draf_catering[0]->fc_id) : '' ?>">
                                    
                                    <!-- / <span style="display: none" id="profile_saved">Saved profile successfully</span> -->
                                </div>
                            </div>

                            <div class="clearfix"></div>
                            <div class="row ">
                                <div class="col-md-12">
                                    <div class="padding_and_border_top_bottom">
                                        <div class="Your_total">
                                            Your total
                                        </div>
                                        <div id="details-pricing-div" class="your_price_show">
                                            $0
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <input type="button" id="continue2review"  name="next" class="next action-button" value="Continue to Review and pay">
                            <button type="button" class="action-button float_use but pull-left" id="save_profile"> Save & review later</button>

                        </fieldset>
                        <!--three-section-->
                        <!--three-section-->

                        <fieldset class="fieldset_1">
                            <div id="review_listing" class="list_your_venu_content">Review your listing</div>
                            <div class="row">
                                <div class="col-md-5 col-xs-6">
                                    <div class="choose_this_button second">
                                        <a class="first-section" id="" href="#">Review listing</a>
                                    </div>
                                </div>
                            </div>

                            <div class="list_your_venu_content Payment"><span id="pay_head">Payment summary</span></div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div id="m-cart"></div>

                                    <div class="padding_and_border_top_bottom">
                                        <div class="Your_total">
                                            Your total
                                        </div>

                                        <div class="your_price_show" id="grand-total">
                                            $0
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <span id="voucher_massage"></span>
                            <div id="cart-div" class="row maring_row_cart_page">
                                <div  class="voucher_div">
                                    <div class="col-md-8 col-sm-7 col-xs-12 text-left">
                                        <label class="lbl_class">Add voucher code</label>
                                        <input name="voucher_code" id="voucher" type="text" class="form-control add_voucher_code addr-field" placeholder="" >
                                        <label style="display: none;" id="voucher-error" class="custom-error"></label>
                                    </div>
                                    
                                    <div class="col-md-4 col-sm-5 col-xs-12 pull-right">
                                        <div class="choose_this_button second apply_button">
                                            <a class="apply_voucher" onclick="appaly_voucher(2,1);" href="javascript:void(0)">Apply</a>
                                            <input type="hidden" id="voucher_validate" value="0">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-12" id="payment_method">
                                    <h3>Payment method</h3>
                                    <p class="pay_tap_div">
                                      <span class="pay_radio_button">
                                        <label class="regular-checkbox pull-left">
                                         <input type="radio" class="payment_method" onclick="choose_payment(1, 2, 1)" name="payment_method" value="1">
                                         <small></small>
                                     </label>
                                     <span class="pull-left"> Pay by Stripe</span>
                                 </span>
                                 <span class="pay_radio_button">
                                    <label class="regular-checkbox pull-left">
                                      <input type="radio" class="payment_method" onclick="choose_payment(2, 2, 1)" name="payment_method" value="2">
                                      <small></small>
                                  </label>
                                  <span class="pull-left"> Pay by account</span>
                              </span>
                          </p>
                          <input type="hidden" id="selected_method" value="">
                          <label style="display: none;" id="payment_method-error">Please select payment method</label>
                      </div>

                      <div class="col-md-12" id="strip_payment" style="display: none">
                         <div class="row color_set_gray">
                            <div class="col-md-8 pull-left">
                                <!--<form>-->
                                <div class="form-group owner">
                                    <label for="cardNumber" class="card_number_label">Card Number</label>
                                    <input type="text" id="cardnumber" class="form-control-1 car_input_number card-number addr-field">
                                    <label style="display: none;" id="cardnumber-error" class="custom-error"></label>
                                </div>

                                <div class="cart_icon_set">
                                    <ul>
                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_card_visa-128.png" class="img-responsive"></li>
                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_discover_network_card-128.png" class="img-responsive"></li>
                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_master_card-128.png" class="img-responsive"></li>
                                        <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_google_wallet-128.png" class="img-responsive"></li>
                                    </ul>
                                </div>

                                <div class="row">
                                    <div class="col-md-8 padding-right_106">
                                        <div class="form-group CVV" id="expiration-date">
                                            <label class="card_number_label">Expires Date</label>
                                            <select name="select2" id="cardexpiry" class="select_month card-expiry-month" data-stripe="exp-month">
                                                <option value="01" selected="">January</option>
                                                <option value="02">February </option>
                                                <option value="03">March</option>
                                                <option value="04">April</option>
                                                <option value="05">May</option>
                                                <option value="06">June</option>
                                                <option value="07">July</option>
                                                <option value="08">August</option>
                                                <option value="09">September</option>
                                                <option value="10">October</option>
                                                <option value="11">November</option>
                                                <option value="12">December</option>
                                            </select>
                                            <select name="select2" id="cardexpiry" class="select_month card-expiry-year" data-stripe="exp-year"></select>
                                            <script type="text/javascript">
                                                var select = $(".card-expiry-year"),
                                                year = new Date().getFullYear();

                                                for (var i = 0; i < 12; i++) {
                                                    select.append($("<option value='" + (i + year) + "' " + (i === 0 ? "selected" : "") + ">" + (i + year) + "</option>"))
                                                }
                                            </script>
                                        </div>
                                        <label style="display: none;" id="cardexpiry-error" class="custom-error"></label>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="card_number_label">Security Code</label>
                                        <input type="text" id="cvv" class="form-control-1 car_input_number card-cvc addr-field" placeholder="CVV">
                                        <label style="display: none;" id="cvv-error" class="custom-error"></label>
                                    </div>

                                    <div class="form-group owner col-md-12">
                                        <label class="card_number_label">Name</label>
                                        <input type="text" name="cardholdername" id="cardholdername" class="form-control-1 car_input_number card-holder-name addr-field">
                                        <label style="display: none;" id="cardholdername-error" class="custom-error"></label>
                                    </div>

                                    <div class="form-group owner col-md-6">
                                        <label class="card_number_label">Order Amount</label>
                                        <input type="text" readonly="" name="amt" id="amt" value="0" class="form-control-1 car_input_number">
                                        <input type="hidden" id="amt_total" value="0">
                                    </div>

                                    <div class="col-md-12">
                                        <div class="right_aling_card_root_101">
                                            <label class="regular-checkbox ">
                                                <input class="checkbox_set" type="checkbox" name="agree" value="1" data-rule-required="true">
                                                <small></small>
                                            </label>
                                            <span>I agree with the <a href="<?php echo base_url()?>/term_condition" target="_blank">Terms & Conditions.</a></span>
                                        </div>
                                    </div>

                                </div>
                                <!--</form>-->

                            </div>
                            <div class="col-md-4"></div>
                            <div class="col-md-12"><br></div> 
                        </div>
                    </div>

                    <div class="col-md-12" id="pay_by_account" style="display: none">
                       <div class="color_set_gray deep">
                        <div class="col-md-12 mt-1">
                            <table width="100%" class="mt-1">
                                <tr>
                                    <td class="text-not"><b>Note: </b></td>
                                    <td>When you select Pay by Account than after send invoice on mail with Function & Catering accounts details. If your payment approved than after Active your Venue/catering.</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-8">
                            <label class="lbl_class">Email</label>
                            <input class="form-control" type="email" value="<?php echo $this->session->userdata('user_email') ?>">
                        </div>
                        <div class="col-md-12"><br></div>
                        <div class="col-md-8">
                            <div class="right_aling_card_root_101">
                                <label class="regular-checkbox ">
                                    <input class="checkbox_set" type="checkbox" name="agree" value="1" data-rule-required="true">
                                    <small></small>
                                </label>
                                <span>I agree with the <a href="<?php echo base_url()?>/term_condition" target="_blank">Terms & Conditions.<sup style="color: red">*</sup></a></span>
                            </div>
                        </div> 

                        

                    </div>
                </div>

            </div>
            <input type="button" name="btnsub" id="btnsub"  class="action-button float_use" value="Process payment">
        </fieldset>
        <!--last-section-->
        <!--last-section-->

    </form>
</div>
</div>

</div>
</div>
</div>
</section>


<!-- Modal -->
<?php $this->load->view('models/image_cropping'); ?>
<?php $this->load->view('models/error_show'); ?>
<script>

//jQuery time
    var current_fs, next_fs, previous_fs; //fieldsets
    var left, opacity, scale; //fieldset properties which we will animate
    var animating; //flag to prevent quick multi-click glitches
    $('#header_dy').addClass('add-bg_color');
    $(".next").click(function () {
        if (animating)
            return false;
        animating = true;

        current_fs = $(this).parent();
        next_fs = $(this).parent().next();

        if ($("fieldset").index(next_fs) == 3) {
            var result = save_data(2); // here pass 2 for continue to page pay screen
            if (!result) {
                animating = false;
                return false;
            }
        }
        

        if ($("fieldset").index(next_fs) == 1) {
            var htm = '<div class="opening_your_venue_content">Now its time to choose <span class="text_wold_start_contert">the search radius.</span></div>';
        } else if ($("fieldset").index(next_fs) == 2) {

            var htm = '<div class="opening_your_venue_content">Now its time to plug in <span class="text_wold_start_contert">all your catering details.</span></div>';
        } else if ($("fieldset").index(next_fs) == 3) {

            var htm = '<div class="opening_your_venue_content">A final review <span class="text_wold_start_contert">before you go live.</span></div>';
        } else {

            var htm = '<div class="list_your_venu_content">List your venue for a little as $1 a day.</div><div class="opening_your_venue_content">Opening your venue to <span class="text_wold_start_contert">the world starts here.</span></div>';
        }

        $("#top-txt").html(htm);
        $("html, body").animate({scrollTop: 0}, "slow");

        //activate next step on progressbar using the index of next_fs
        $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

        //show the next fieldset
        next_fs.show();
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
            step: function (now, mx) {
                //as the opacity of current_fs reduces to 0 - stored in "now"
                //1. scale current_fs down to 80%
                //scale = 1 - (1 - now) * 0.

                ;
                //2. bring next_fs from the right(50%)
                left = (now * 50) + "%";
                //3. increase opacity of next_fs to 1 as it moves in
                opacity = 1 - now;
                current_fs.css({
                    'transform': 'scale(' + scale + ')',
                    'position': 'absolute'
                });
                next_fs.css({'left': left, 'opacity': opacity});
            },
            duration: 800,
            complete: function () {
                current_fs.hide();
                animating = false;
            },
            //this comes from the custom easing plugin
            easing: 'easeInOutBack'
        });
    });

    current_fs = $(this).parent();
    previous_fs = $(this).parent().prev();


    $(".previous").click(function () {
        if (animating)
            return false;
        animating = true;

        //de-activate current step on progressbar
        $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

        //show the previous fieldset
        previous_fs.show();
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
            step: function (now, mx) {
                //as the opacity of current_fs reduces to 0 - stored in "now"
                //1. scale previous_fs from 80% to 100%
                //scale = 0.8 + (1 - now) * 0.2;
                //2. take current_fs to the right(50%) - from 0%
                left = ((1 - now) * 50) + "%"
                ;
                //3. increase opacity of previous_fs to 1 as it moves in
                opacity = 1 - now;
                current_fs.css({'left': left});
                previous_fs.css({'transform': 'scale(' + scale + ')', 'opacity': opacity});
            },
            duration: 800,
            complete: function () {
                current_fs.hide();
                animating = false;
            },
            //this comes from the custom easing plugin
            easing: 'easeInOutBack'
        });
    });

    $(".first-section").click(function () {
        if (animating)
            return false;
        animating = true;

        current_fs = $("#review_listing").parent();
        previous_fs = $("#review_listing").parent().prev().prev().prev();

        //de-activate current step on progressbar
        $("#progressbar li").removeClass("active");

        $("#progressbar li").eq(0).addClass("active");

        //show the previous fieldset
        previous_fs.show();
        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
            step: function (now, mx) {
                //as the opacity of current_fs reduces to 0 - stored in "now"
                //1. scale previous_fs from 80% to 100%
                //scale = 0.8 + (1 - now) * 0.2;
                //2. take current_fs to the right(50%) - from 0%
                left = ((1 - now) * 50) + "%";
                //3. increase opacity of previous_fs to 1 as it moves in
                opacity = 1 - now;
                current_fs.css({'left': left});
                previous_fs.css({'transform': 'scale(' + scale + ')', 'opacity': opacity});
            },
            duration: 800,
            complete: function () {
                current_fs.hide();
                animating = false;
            },
            //this comes from the custom easing plugin
            easing: 'easeInOutBack'

        });
        $('#rewiew_listing_handle').val(1);
        RemoveVoucher();
    });
    

</script>

<script >
    $(".phone_no").keyup(function (e) {
     length=$(this).val().length;
     limit=17;
     if(length>limit){
        var strtemp = $(this).val().substr(0,limit);
        $(this).val(strtemp);
        e.preventDefault();
    }
});
    $(".phone_no").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .   
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 107,109,32,110,57,48]) !== -1 ||
             // Allow: Ctrl+A, Command+A
             (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
             (e.keyCode >= 35 && e.keyCode <= 40) || ( e.keyCode === 107 || e.keyCode === 109 || e.keyCode === 32 || e.keyCode === 57 || e.keyCode === 48 ))  {
                 // let it happen, don't do anything
             return;
         }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }  
    });
</script>
