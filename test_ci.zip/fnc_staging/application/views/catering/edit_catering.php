<link rel="stylesheet" href="<?php echo base_url('assets/css/new-style.css'); ?>">
<style>.update_plan_fc{display:none}</style>
<script>
    var get_cart = '<?php echo site_url('venue/get_cart'); ?>';
    var update_plan_catering = '<?php echo site_url('catering/update_plan_catering'); ?>';
    var getPricing = '<?php echo site_url('catering/get_pricing'); ?>';
    var extra_service_update_cart = '<?php echo site_url('catering/extra_service_update_cart'); ?>';
    var edit_remove_cart = '<?php echo site_url('catering/edit_remove_cart'); ?>';
    var removePlan = '<?php echo site_url('catering/removePlan'); ?>';
    var lat = parseFloat('<?php echo $catering[0]->fc_lat; ?>');
    var lng = parseFloat('<?php echo $catering[0]->fc_lng; ?>');
    var radius_area = parseFloat('<?php echo!empty($catering_radius) ? $catering_radius[0]->csr_radius : 0; ?>');
    var search_suburb = '<?php echo site_url('web/search_suburb'); ?>';
    var search_postcode = '<?php echo site_url('web/search_postcode'); ?>';
     var search_area = '<?php echo site_url('venue/search_area'); ?>';
    var councilURL = '<?php echo site_url('venue/check_council'); ?>';
     var STRIPE_PUBLIC_KEY = '<?php echo STRIPE_PUBLIC_KEY; ?>';
</script>
<script src="<?php echo base_url('assets/js/custom/edit-catering.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.ezdz.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/custom/crope_images.js'); ?>"></script>
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<?php
if (!empty($catering[0]->fc_valid_upto)) {
    $valid_date = $catering[0]->fc_valid_upto;
    if (strtotime($valid_date) > strtotime(date('Y-m-d'))) {
        $massage = 'Your current plan expire on ' . expireFormted($valid_date);
    } elseif (strtotime($valid_date) == strtotime(date('Y-m-d'))) {
        $massage = 'Today your plan expire ' . expireFormted($valid_date) . ' please update plans';
    } else {
        $massage = 'Plan expired on ' . expireFormted($valid_date) . ' please update plans';
    }
}
?>

<span class="postion_set_side_bar" id="total_tag" style="display: none">
    <span class="pull-left">Your Total:</span>
    <span class="pull-right total_of_update">$0</span>
</span>
<section class="function_vene_page">
    <div class="container">
        <div class="row main_row">

            <div class="col-sm-12">
                <div class="col-sm-12 dashboard_row">
                    <h4>Dashboard</h4>
                </div>
            </div>

            <!-- Loading Side Menu -->
            <?php $this->load->view('side_menu'); ?>

            <div class="col-md-8 col-sm-8">
                <form id="msform"  method="post" action="" enctype="multipart/form-data">
                    <div id="catering_details">
                        <div class="col-sm-12 profile_row das-2">
                            <div class="row top_background"><h4 class="pull-left">Update Package</h4></div>
                            <span class="pull-right your_plan_expire_tex"><?php echo  $massage; ?></span>
                            <div class="row">
                             <div class="display_flex_set_d">
                                <?php
                                if (!empty($packs)) {
                                    foreach ($packs as $key => $value) {
                                        ?>
                                        <div class="col-md-6 col-sm-6 border_price_box" id="pack<?php echo $key; ?>">
                                            <span>
                                                <div class="price_title" id="pack-title<?php echo $key; ?>">
                                                    <div class="price_content <?php echo ($value->pro_id == $catering[0]->fc_current_plan) ? 'fc_active_plan' : ''; ?>" id="pack-content<?php echo $key; ?>">
                                                        <?php echo $value->pro_title; ?>
                                                    </div>
                                                </div>
                                                <?php if ($value->pro_save != 0) { ?>
                                                    <div class="offet_side_bar"><a>Save $<?php echo $value->pro_save; ?></a></div>
                                                <?php } ?>

                                                <div class="offer_box_padding" id="pack-padding<?php echo $key; ?>">
                                                    <?php echo $value->pro_desc; ?>
                                                    <div class="choose_this_button">
                                                        <a data-pack="<?php echo $key; ?>" data-packtype="<?php echo $value->pro_id; ?>" class="choose_plan" href="javascript:;">Choose this plan</a>
                                                    </div>
                                                </div>
                                            </span>
                                        </div><!--col-md-6-->
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                        </div>
                        <input type="hidden" id="firstcart" value="">
                        
                        <div class="col-sm-12 profile_row das-2" style="display:none">
                            <?php if (!$subscrption) { ?>
                                <span>venue '<?php echo $catering[0]->fc_business_name ?>' can pay automatically</span>
                                <a href="javascript:void(0)" onClick="stripSubscriptionShow()" class="btn btn-primary subscriptbtn">Make it automatic</a>
                                <div class="col-md-12" id="strip_subscription" style="display: none">
                                    <div class="strip_form">

                                    </div>
                                    <input type="button" name="btnsub" onClick="activeSubscription()" id="active_subscription" class="action-button" value="Active subscription" />
                                <?php } else { ?>
                                    <p>Your subscriptions is active </p><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#cancel_subcription_model">Cancel</button>
                                <?php } ?>

                            </div>
                        </div>

                        <div class="col-sm-12 profile_row das-2">
                            <div class="row top_background"><h4>Function address </h4></div>
                            <div class="row">
                                <div class="col-lg-12 margin_top_row_106">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="catering_street">Street</label>
                                        <input type="text" class="form-control" id="catering_street" name="catering_street" value="<?php echo $catering[0]->fc_street; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="catering_state">State</label>
                                        <input type="text" class="form-control" id="catering_state" name="catering_state" value="<?php echo $catering[0]->fc_state; ?>" data-rule-required="true">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="catering
_suburb">Suburb</label>
                                        <input type="text" class="form-control ui-autocomplete-input valid ui-autocomplete-loading" id="catering_suburb"  name="catering_suburb" value="<?php echo $catering[0]->fc_suburb; ?>" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="catering_postcode">Postcode</label>
                                        <input type="number" class="form-control ui-autocomplete-input"  id="catering_postcode" name="catering_postcode" value="<?php echo $catering[0]->fc_postcode; ?>" data-rule-required="true">
                                    </div>
                                </div>
                                <div class="col-lg-12">

                                    <div class="col-md-6 margin_set_input">
                                        <label class="lbl_class" for="catering_country">Country</label>
                                        <input type="text" class="form-control" id="catering_country" name="catering_country" value="<?php echo $catering[0]->fc_country; ?>" readonly="" data-rule-required="true">
                                    </div>
                                    <div class="col-md-6 margin_set_input">
                                        <input type="hidden" class="form-control" id="catering_council" name="catering_council" value="<?php echo $catering[0]->fc_council; ?>" >
                                    </div>
                                </div>
                            </div>
                        </div>

                    <div class="row">
                        <div class="col-md-12">
                            <input type="button" class="create_map" id="create_map_catering" value="Update your listing area">
                            <input type="hidden" id="council_arr" value="[]">
                            <input type="hidden" name="lat" id="lat" value="<?php echo $catering[0]->fc_lat; ?>">
                            <input type="hidden" name="lng" id="lng" value="<?php echo $catering[0]->fc_lng; ?>">
                        </div>
                    </div>

                        <div class="row">
                            <div class="col-md-12 margin_106">
                                <h3 class="opening_your_venue_content your_venue_1 font_your_venue">Your venue will appear in '<span id="city-nm"><?php echo $council; ?></span>' search.</h3>
                                <div id="map"></div>
                                <h3 style="display: none;" id="second_map_heading" class="opening_your_venue_content your_venue_1 font_your_venue">You can increase your service area 15 km for 50c per day, or increase your service  area 25km for 1$ per day.
                                </h3>
                                <div id="map1"></div>
                            </div>
                        </div>

                        <?php
                        $current_active_plan = false;
                        if (!empty($catering_radius)) {
                            $current_active_plan = $catering_radius[0]->csr_plan_id;
                        }
                        ?>
                        <div class="row" id="radius_increas">
                            <div class="col-md-12">
                                <ul class="plus-listing">
                                    <?php
                                    if (!empty($service_area_pack)) {
                                        foreach ($service_area_pack as $key => $value) {
                                            ?>
                                            <li><span data-area_add="<?php echo $value->pro_desc ?>" data-active="0" id="<?php echo $value->pro_id; ?>" class="increase_radius_map plus new_plus_sine <?php echo ($value->pro_id == $current_active_plan) ? 'my_active' : '' ?> "><?php echo ($value->pro_id == $current_active_plan) ? '-' : '+' ?></span><span class="plus-section plus_sec_510"><?php echo $value->pro_title; ?></span></li>
                                            <?php
                                        }
                                    }
                                    ?>
                                    <input type="hidden" id="cheak_status" value="">
                                    <input type="hidden" id="service_product_id" value="">
                                    <input type="hidden" name="csr_radius_id" id="extra_service_area_id" value="">
                                </ul>
                            </div>
                        </div>

                    <div class="col-sm-12 profile_row border_progress_page fountion_1">
                        <div class="row top_background">
                            <h4>Catering </h4></div>
                        <div class="row">
                            <div class="col-lg-12 margin_top_row_106">
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="catering_business_name">Business name</label>
                                    <input type="text" class="form-control" data-rule-remote="<?php echo site_url('catering/check_business_name/').'?fc_id='.encrypt_decrypt('encrypt', $catering[0]->fc_id); ?>" data-msg-remote="this name already exist" name="catering_business_name" value="<?php echo $catering[0]->fc_business_name; ?>" data-rule-required="true">
                                </div>
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="catering_abn">ABN</label>
                                    <input type="text" class="form-control"  name="catering_abn" value="<?php echo $catering[0]->fc_abn; ?>" data-rule-required="true" data-rule-abn_number="true">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="catering_contact_name">Contact name</label>
                                    <input type="text" class="form-control" name="catering_contact_name" value="<?php echo $catering[0]->fc_contact_name; ?>" data-rule-required="true">
                                </div>
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="catering_phone_no">Phone number</label>
                                    <input type="text" class="form-control phone_no" name="catering_phone_no" value="<?php echo $catering[0]->fc_phone_no; ?>" data-rule-required="true">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="catering_website">Website</label>
                                    <input type="text"  class="form-control" name="catering_website" value="<?php echo $catering[0]->fc_website; ?>" data-rule-required="true">
                                </div>
                                <div class="col-md-6 margin_set_input">
                                    <label class="lbl_class" for="catering_email">Email</label>
                                    <input type="text" class="form-control" name="catering_email" value="<?php echo $catering[0]->fc_email; ?>" data-rule-required="true"  data-rule-email="true">
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php 
                                if (!empty($catering[0]->fc_listing_picture)) {
                                    $img_url = base_url('uploads/fc_images') . '/' . $catering[0]->fc_listing_picture;
                                }else{
                                    $img_url='';
                                }
                                ?>
                                <div class="col-sm-12 profile_row border_progress_page fountion_1">
                                    <div class="row top_background">
                                        <h4>Main Image </h4>
                                    </div>
                                    <div class="row margin_top_row_second_106 up-image-row">
                                        <div class="col-md-12 text-left">
                                            <div  class="ulpading_img_size_3 listing_picture_thumb">
                                                <img  id="show_image_55555" class="dropzone" img-id="55555" src="<?php echo $img_url; ?>" style="<?php echo ($img_url == '')? 'display: none;' : 'display:block;' ?>">
                                                <input onclick="this.value=null;" type="file" name="fc_listing_picture" data-id="55555" class="file-selector image_selector" id="image_selector_55555" accept="image/*">
                                        <input type="hidden" name="dimesion_image_55555" id="dimesion_image_55555" value="0">    
                                        <img class="remove_image" onclick="removeImage(1, '<?php echo encrypt_decrypt('encrypt', $catering[0]->fc_id); ?>', 1, 55555)" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                            </div>
                                            <div class="ulpading_img_size_3_1 listing_picture_thumb">
                                                <div>
                                                    To have your catering looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 300 x 530 pixels.
                                                </div>
                                                <div class="row" >
                                                    <label ant-id="55555" class="upload-button_new after_102" id="another_select_55555">
                                                        <i  class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                    <div class="col-sm-12 profile_row fountion_2">
                        <div class="row top_background text-left">
                            <h4>Catering images</h4>
                        </div>
                        <?php
                        $last_key='';
                        $img_status = TRUE;
                        $img_count = 5;
                        $actual_img_count = count($catering_images);
                        if (!empty($catering_images)) {
                            foreach ($catering_images as $key => $value) {
                                    $img_url = (!empty($value->fc_img_name)) ? base_url('uploads/fc_images') . '/' . $value->fc_img_name : '';
                                    ?>
                                <div class="row margin_top_row_second_106 up-image-row">
                                    <div class="col-md-12 text-left">
                                        <div class="ulpading_img_size_3">
                                                <img img-id="<?php echo $key; ?>" style="display:<?php echo (empty($img_url)) ? 'none' : 'block'; ?>" class="dropzone" id="show_image_<?php echo $key; ?>" src="<?php echo $img_url; ?>">
                                                <input onclick="this.value = null;" type="file" name="catering_image<?php echo $key; ?>" data-id="<?php echo $key; ?>" class="file-selector image_selector" id="image_selector_<?php echo $key; ?>" accept="image/*">
                                                <input type="hidden" name="dimesion_image_<?php echo $key; ?>" id="dimesion_image_<?php echo $key; ?>" value="0">
                                                <img onclick="removeImage(2, '<?php echo encrypt_decrypt('encrypt', $value->fc_img_id); ?>', 1, <?php echo $key; ?>)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                        </div>
                                        <div class="ulpading_img_size_3_1">
                                            <?php
                                            if ($key == 0) {
                                                $img_status = FALSE;
                                                ?>
                                                <div>
                                                    To have your catering looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                </div>
                                            <?php } ?>
                                            <div class="row">
                                                <label ant-id="<?php echo $key; ?>" class="upload-button_new after_102" id="another_select_<?php echo $key; ?>">
                                                                                                       <input type="hidden"  name="image<?php echo $key; ?>" value="<?php echo $value->fc_img_id; ?>">
                                                    <i class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $last_key = $key;
                                $img_count = $img_count - 1;
                            }
                        }

                        if ($img_count > 0) {
                            $crp = $actual_img_count;
                            ?>
                            <input type="hidden" name="img_count" value="<?php echo $img_count; ?>">
                            <?php
                            for ($i = 1; $i <= $img_count; $i++) {
                                ?>
                                <div class="row margin_top_row_second_106 up-image-row">
                                    <div class="col-md-12 text-left">
                                        <div  class="ulpading_img_size_3 ">
                                            <img  id="show_image_<?php echo $crp; ?>" class="dropzone" img-id="<?php echo $crp; ?>" src="" style="display:none">
                                            <input onclick="this.value=null;" type="file" name="catering_image[]" data-id="<?php echo $crp; ?>" class="file-selector image_selector" id="image_selector_<?php echo $crp; ?>" accept="image/*">
                                                <input type="hidden" name="dimesion_image_<?php echo $crp; ?>" id="dimesion_image_<?php echo $crp; ?>" value="0">
                                                <img onclick="removeImage(2, 0, 2, <?php echo $crp; ?>)" class="remove_image" src="<?php echo base_url(REMOVE_IMAGE); ?>">
                                        </div>
                                        <div class="ulpading_img_size_3_1">
                                            <?php
                                            if ($img_status) {
                                                $img_status = FALSE;
                                                ?>
                                                <div>
                                                    To have your catering looking its best and showcasing the offering a range of images can be uploaded. JPEG or PNG files. Dimensions are 1100 x 420 pixels.
                                                </div>
                                            <?php } ?>
                                            <div class="row" >
                                                <label ant-id="<?php echo $crp; ?>" class="upload-button_new after_102" id="another_select_<?php echo $crp; ?>">
                                                    <i  class="fa_icon icon-upload-alt margin-correction"></i>Upload image
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $crp++;
                            }
                        }
                        ?>
                    </div>

                    <div class="col-sm-12 profile_row fountion_3">
                        <div class="row top_background text-left">
                            <h4>Price per head </h4>
                        </div>
                        <div class="row">
                            <div class="text-left">
                                <div class="col-md-6">
                                    <?php
                                    $price_arr = array();

                                    if (!empty($catering[0]->fc_pricing)) {
                                        $price_arr = explode(',', $catering[0]->fc_pricing);
                                    }

                                    if (!empty($price_per_head)) {
                                        $dollar_count = 1;
                                        foreach ($price_per_head as $value) {
                                            ?>
                                            <label class="set_label_venu">
                                                  <?php
                                                $checked_pricing = '';
                                                if (in_array($value->p_id, $price_arr)) {
                                                    $checked_pricing = 'checked';
                                                }
                                                ?>
                                                <label class="regular-checkbox pull-left r-p-n-501">
                                                <input name="catering_pricing[]" type="checkbox" value="<?php echo $value->p_id; ?>" <?php echo $checked_pricing; ?>>
                                                    <small></small>
                                                </label>
                                                <div class="dolor_icon"><?php
                                                    for ($i = 0; $i < $dollar_count; $i++) {
                                                        echo '$';
                                                    }
                                                    ?></div>
                                                <span><?php echo $value->p_name; ?></span>

                                                </label>
                                                <?php
                                                if ($dollar_count % 2 == 0)
                                                    echo '</div><div class="col-md-6">';

                                            $dollar_count++;
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12 profile_row fountion_4">
                        <div class="row top_background text-left">
                            <h4>Overview-Catering Details</h4>
                        </div>
                        <div class="row">
                            <div class="col-md-12 text-left">
                                <label class="">Overview</label>
                                <textarea class="form-control overview_textarea textare_root" placeholder="This is a short introductory overview that describes your catering. &#10;Max 400 words." name="catering_overview" data-rule-required="true" data-rule-maxlength="400" data-rule-required="true" data-rule-maxlength="800"><?php echo $catering[0]->fc_overview; ?></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12 profile_row fountion_5">
                        <div class="row top_background text-left">
                            <h4>Function types</h4>
                        </div>
                        <div class="row margin_top_row_second_106">
                            <div class="form-check form-check-inline">

                                <?php
                                $function_type_arr = array();

                                if (!empty($catering_details)) {
                                    if (!empty($catering_details[0]->cd_function_type)) {
                                        $function_type_arr = explode(',', $catering_details[0]->cd_function_type);
                                    }
                                }


                                if (!empty($function_type)) {
                                    foreach ($function_type as $f_type) {
                                        ?>
                                        <div class="col-md-6 text-left pass">

                                            <label class="set_label_venu">
                                                 <?php
                                                $checked_event = '';
                                                if (in_array($f_type->id, $function_type_arr)) {
                                                    $checked_event = 'checked';
                                                }
                                                ?>
                                                 <label class="regular-checkbox pull-left r-p-n-501">
                                                <input type="checkbox" name="catering_function_type[]" value="<?php echo $f_type->id; ?>" <?php echo $checked_event; ?>>
                                                    <small></small>
                                                </label>
                                                <div class="dolor_icon size_set_ic"><img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $f_type->image; ?>"></div>
                                                <span><?php echo $f_type->name; ?></span>

                                                </label>
                                            </div>
                                            <?php
                                        }
                                    }
                                    ?>

                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12 profile_row fountion_6">
                        <div class="row top_background text-left">
                            <h4>Menus</h4>
                        </div>
                        <div class="row margin_top_row_second_106">
                            <div class="form-check form-check-inline">

                                <?php
                                $menus_arr = array();

                                if (!empty($catering_details)) {
                                    if (!empty($catering_details[0]->cd_menus)) {
                                        $menus_arr = explode(',', $catering_details[0]->cd_menus);
                                    }
                                }

                                if (!empty($menus)) {
                                    foreach ($menus as $m_val) {
                                        ?>
                                        <div class="col-md-6 text-left pass_1">
                                            <label class="set_label_venu">
                                                 <?php
                                                $checked_facility = '';
                                                if (in_array($m_val->id, $menus_arr)) {
                                                    $checked_facility = 'checked';
                                                }
                                                ?>
                                                 <label class="regular-checkbox pull-left r-p-n-501">
                                                <input type="checkbox" name="catering_menus[]" value="<?php echo $m_val->id; ?>" <?php echo $checked_facility; ?>>
                                                    <small></small>
                                                </label>
                                                <div class="dolor_icon size_set_ic">
                                                    <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $m_val->image; ?>">
                                                </div>
                                                <span><?php echo $m_val->name; ?></span>

                                                </label>
                                            </div>
                                            <?php
                                        }
                                    }
                                    ?>

                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12 profile_row fountion_6">
                        <div class="row top_background text-left">
                            <h4>Cuisine</h4>
                        </div>
                        <div class="row margin_top_row_second_106">
                            <div class="form-check form-check-inline">

                                <?php
                                $cuisine_arr = array();

                                if (!empty($catering_details)) {
                                    if (!empty($catering_details[0]->cd_cuisine)) {
                                        $cuisine_arr = explode(',', $catering_details[0]->cd_cuisine);
                                    }
                                }

                                if (!empty($cuisine)) {
                                    foreach ($cuisine as $c_val) {
                                        ?>
                                        <div class="col-md-6 text-left pass_1">
                                            <label class="set_label_venu">
                                                <?php
                                                $checked_feature = '';
                                                if (in_array($c_val->id, $cuisine_arr)) {
                                                    $checked_feature = 'checked';
                                                }
                                                ?>
                                                 <label class="regular-checkbox pull-left r-p-n-501">
                                                <input type="checkbox" name="catering_cuisine[]" value="<?php echo $c_val->id; ?>" <?php echo $checked_feature; ?>>
                                                    <small></small>
                                                </label>
                                                <div class="dolor_icon size_set_ic">
                                                    <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $c_val->image; ?>">
                                                </div>
                                                <span><?php echo $c_val->name; ?></span>

                                                </label>
                                            </div>
                                            <?php
                                        }
                                    }
                                    ?>

                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12 profile_row fountion_6">
                        <div class="row top_background text-left">
                            <h4>Services</h4>
                        </div>
                        <div class="row margin_top_row_second_106">
                            <div class="form-check form-check-inline">

                                <?php
                                $services_arr = array();

                                if (!empty($catering_details)) {
                                    if (!empty($catering_details[0]->cd_services)) {
                                        $services_arr = explode(',', $catering_details[0]->cd_services);
                                    }
                                }

                                if (!empty($services)) {
                                    foreach ($services as $s_val) {
                                        ?>
                                        <div class="col-md-6 text-left pass_1">
                                            <label class="set_label_venu">
                                                <?php
                                                $checked_feature = '';
                                                if (in_array($s_val->id, $services_arr)) {
                                                    $checked_feature = 'checked';
                                                }
                                                ?>
                                                <label class="regular-checkbox pull-left r-p-n-501">
                                                <input  type="checkbox" name="catering_services[]" value="<?php echo $s_val->id; ?>" <?php echo $checked_feature; ?>>
                                                    <small></small>
                                                </label>
                                                <div class="dolor_icon size_set_ic">
                                                    <img class="fnc_event_icon" src="<?php echo base_url('uploads/fnc_types') . '/' . $s_val->image; ?>">
                                                </div>
                                                <span><?php echo $s_val->name; ?></span>

                                                </label>
                                            </div>
                                            <?php
                                        }
                                    }
                                    ?>

                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12 profile_row fountion_7">
                        <div class="row top_background text-left">
                            <h4>Catering in detail</h4>
                        </div>
                        <div class="row margin_top_row_second_106">
                            <div class="col-md-12 text-left">
                                <label class="text-left" for="catering_description">Details</label>
                                <textarea rows="4" class="form-control overview_textarea textare_root" placeholder="This section allows for more catering details if required. Not mandatory. &#10;Max 800 words" data-rule-required="true" data-rule-maxlength="800" name="catering_details"><?php echo $catering[0]->fc_details; ?></textarea>
                            </div>
                        </div>

                        <div class="row margin_top_and_bottom_user">
                            <div class="col-md-6 text-left">
                                <label class="lbl_class" for="catering_min_guest">Minimum guest numbers</label>
                                <input type="text" class="form-control" data-rule-lessThan="#max_guest" id="min_guest" name="catering_min_guest" value="<?php echo $catering[0]->fc_min_guest; ?>">
                            </div>
                            <div class="col-md-6 text-left">
                                <label class="lbl_class" for="catering_max_guest">Maximum guest numbers</label>
                                <input type="text" class="form-control" data-rule-greaterThan="#min_guest" id="max_guest" name="catering_max_guest" value="<?php echo $catering[0]->fc_max_guest; ?>">
                            </div>
                        </div>
                    </div>

                        <input type="button" style="display:none" id="update_and_pay" class="create_map" value="Update & pay">
                        <input type="hidden" id="fc_id" name="catering" value="<?php echo encrypt_decrypt('encrypt', $catering[0]->fc_id); ?>">
                        <a href="javascript:void(0)" id="update_catering" class="create_map">Update catering</a>

                        <a class="cancel_button_venue_catering" href="<?php echo site_url('catering/my_catering') ?>">Cancel</a>
                    </div>

                    <div id="payment_summery" style = "display: none">
                        <fieldset class="fieldset_1"  >
                            <div class="list_your_venu_content Payment"><span id="pay_head">Payment summary</span></div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div id="m-cart"></div>

                                    <div class="padding_and_border_top_bottom">
                                        <div class="Your_total">
                                            Your total
                                        </div>

                                        <div class="your_price_show" id="grand-total">
                                            $0
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <span id="voucher_massage"></span>
                            <div id="cart-div" class="row maring_row_cart_page">
                                <div  class="voucher_div">
                                    <div class="col-md-8 col-sm-7 col-xs-12 text-left">
                                        <label class="lbl_class">Add voucher code</label>
                                        <input name="voucher_code" id="voucher" type="text" class="form-control add_voucher_code addr-field" placeholder="" >
                                        <label style="display: none;" id="voucher-error" class="custom-error"></label>
                                    </div>
                                    <div class="col-md-4 col-sm-5 col-xs-12 pull-right">
                                        <div class="choose_this_button second apply_button">
                                            <a class="apply_voucher" onclick="appaly_voucher(2,2);" href="javascript:void(0)">Apply</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12" id="payment_method">
                                    <h3>Payment method</h3>
                                     <p class="pay_tap_div">
                                          <span class="pay_radio_button">
                                            <label class="regular-checkbox pull-left">
                                                <input type="radio" class="payment_method" onclick="choose_payment(1, 2, 2)" name="payment_method" value="1">
                                                <small></small>
                                            </label>
                                               <span class="pull-left"> Pay by Stripe</span>
                                       </span>
                                       <span class="pay_radio_button">
                                            <label class="regular-checkbox pull-left">
                                              <input type="radio" class="payment_method" onclick="choose_payment(2, 2, 2)" name="payment_method" value="2">
                                                <small></small>
                                            </label>
                                            <span class="pull-left"> Pay by account</span>
                                       </span>
                                    </p>
                                    <input type="hidden" id="selected_method" value="">
                                    <label style="display: none;" id="payment_method-error">Please select payment method</label>
                                </div>
                                <div class="col-md-12" id="strip_payment" style="display: none">
                                    <div class="row color_set_gray">
                                        <div class="col-md-8 pull-left">
                                            <!--<form>-->
                                            <div class="form-group owner">
                                                <label for="cardNumber" class="card_number_label">Card Number</label>
                                                <input type="text" id="cardnumber" class="form-control-1 car_input_number card-number addr-field">
                                                <label style="display: none;" id="cardnumber-error" class="custom-error"></label>
                                            </div>

                                            <div class="cart_icon_set">
                                                <ul>
                                                    <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_card_visa-128.png" class="img-responsive"></li>
                                                    <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_discover_network_card-128.png" class="img-responsive"></li>
                                                    <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_master_card-128.png" class="img-responsive"></li>
                                                    <li><img src="<?php echo base_url('assets'); ?>/images/payment_method_google_wallet-128.png" class="img-responsive"></li>
                                                </ul>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-8 padding-right_106">
                                                    <div class="form-group CVV" id="expiration-date">
                                                        <label class="card_number_label">Expires Date</label>
                                                        <select name="select2" id="cardexpiry" class="select_month card-expiry-month" data-stripe="exp-month">
                                                            <option value="01" selected="">January</option>
                                                            <option value="02">February </option>
                                                            <option value="03">March</option>
                                                            <option value="04">April</option>
                                                            <option value="05">May</option>
                                                            <option value="06">June</option>
                                                            <option value="07">July</option>
                                                            <option value="08">August</option>
                                                            <option value="09">September</option>
                                                            <option value="10">October</option>
                                                            <option value="11">November</option>
                                                            <option value="12">December</option>
                                                        </select>
                                                        <select name="select2" id="cardexpiry" class="select_month card-expiry-year" data-stripe="exp-year"></select>
                                                        <script type="text/javascript">
    var select = $(".card-expiry-year"),
            year = new Date().getFullYear();

    for (var i = 0; i < 12; i++) {
        select.append($("<option value='" + (i + year) + "' " + (i === 0 ? "selected" : "") + ">" + (i + year) + "</option>"))
    }
                                                        </script>
                                                    </div>
                                                    <label style="display: none;" id="cardexpiry-error" class="custom-error"></label>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="card_number_label">Security Code</label>
                                                    <input type="text" id="cvv" class="form-control-1 car_input_number card-cvc addr-field" placeholder="CVV">
                                                    <label style="display: none;" id="cvv-error" class="custom-error"></label>
                                                </div>

                                                <div class="form-group owner col-md-12">
                                                    <label class="card_number_label">Name</label>
                                                    <input type="text" name="cardholdername" id="cardholdername" class="form-control-1 car_input_number card-holder-name addr-field">
                                                    <label style="display: none;" id="cardholdername-error" class="custom-error"></label>
                                                </div>

                                                <div class="form-group owner col-md-6">
                                                    <label class="card_number_label">Order Amount</label>
                                                    <input type="text" readonly="" name="amt" id="amt" value="0" class="form-control-1 car_input_number">
                                                    <input type="hidden" id="amt_total" value="0">
                                                </div>

                                            </div>
                                            <!--</form>-->

                                        </div>
                                        <div class="col-md-4"></div>

                                       <!--  <div class="col-md-12 mt-1">
                                            <table width="100%">
                                                <tr>
                                                    <td class="text-not"><b>Note: </b></td>
                                                    <td>When you select Pay by Account than after send invoice on mail with Function & Catering accounts details. If your payment approved than after Active your Venue/catering.</td>
                                                </tr>
                                            </table>
                                        </div> -->
                                        <div class="col-md-12"><br></div>

                                        <div class="col-md-12">
                                            <div class="right_aling_card_root_101">
                                                <label class="regular-checkbox ">
                                                    <input class="checkbox_set" type="checkbox" name="agree" value="1" data-rule-required="true">
                                                    <small></small>
                                                </label>
                                                <span>I agree with the <a href="<?php echo base_url()?>/term_condition" target="_blank">Terms & Conditions<sup style="color: red">*</sup></a></span>
                                            </div>
                                        </div> 

                                    </div>
                                </div>
                                <div class="col-md-12" id="pay_by_account" style="display: none">
                                    <div class="color_set_gray deep">
                                        <div class="col-md-12 mt-1">
                                            <table width="100%">
                                                <tr>
                                                    <td class="text-not"><b>Note: </b></td>
                                                    <td>When you select Pay by Account than after send invoice on mail with Function & Catering accounts details. If your payment approved than after Active your Venue/catering.</td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div class="col-md-8">
                                            <label class="lbl_class">Email</label>
                                            <input class="form-control" type="email" value="<?php echo $this->session->userdata('user_email') ?>">
                                        </div>

                                        <div class="col-md-12"><br></div>
                                        <div class="col-md-8">
                                            <div class="right_aling_card_root_101">
                                                <label class="regular-checkbox ">
                                                    <input class="checkbox_set" type="checkbox" name="agree" value="1" data-rule-required="true">
                                                    <small></small>
                                                </label>
                                                <span>I agree with the <a href="<?php echo base_url()?>/term_condition" target="_blank">Terms & Conditions.<sup style="color: red">*</sup></a></span>
                                            </div>
                                        </div> 
                                         
                                    </div>
                                </div>
                            </div>
                            <input type="button" name="btnsub" id="btnsub"  class="action-button float_use" value="Process payment">
                        </fieldset>
                    </div>
                </form>
            </div> <!--col-md-8-->

        </div><!-- row -->
    </div> <!-- container -->
</section><!--section-das-->

<!-- Modal -->
<?php $this->load->view('models/image_cropping'); ?>
<?php $this->load->view('models/error_show'); ?>

<script >
    $(".phone_no").keyup(function (e) {
   length=$(this).val().length;
   limit=17;
   if(length>limit){
    var strtemp = $(this).val().substr(0,limit);
    $(this).val(strtemp);
    e.preventDefault();
   }
  });
  $(".phone_no").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .   
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 107,109,32,110,57,48]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40) || ( e.keyCode === 107 || e.keyCode === 109 || e.keyCode === 32 || e.keyCode === 57 || e.keyCode === 48 ))  {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }  
    });
</script>