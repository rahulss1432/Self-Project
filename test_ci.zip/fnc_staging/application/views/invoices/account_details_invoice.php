<!DOCTYPE html>
<html>
    <head>
        <title></title>
    </head>
    <body style="padding: 0px; margin:0px;">

        <table bgcolor="#fff" width="100%"  align="center" cellpadding="0" cellspacing="0" style="font-size: 15px; font-family: sans-serif; border: 1px solid #e9e9e9; border-collapse: collapse; color: #384855;">
            <tr>
                <td colspan="2" width="100%" height="30px" bgcolor="#0c81c3"></td>
            </tr>

            <tr>
                <td align="left" style="padding: 0px 30px;" bgcolor="#fff">
                    <img width="220px" src="<?php echo base_url('assets/images/Functions_LogoFandC.png'); ?>">
                </td>
                <td style="padding: 15px 30px 0px;">
                    <table  style="width:100%; border:1px solid #eeeeee;background-color:#fbfbfb;padding:7px 0">
                        <tbody>
                            <tr>
                                <td width="10" style="padding:7px 0">&nbsp;</td>
                                <td style="padding:7px 0">
                                    <font style="color:inherit;font-family:inherit;font-size:inherit">
                                    <p style="border-bottom:1px solid #eeeeee;margin:3px 0 7px;text-transform:uppercase;font-weight:500;font-size:18px;padding-bottom:10px">
                                        Invoice details</p>
                                    </font>
                                    <p style="margin:7px 0px;"><b>Invoice No: </b><font style="color:#777"><?php echo $invoice_no ?></font></p>
                                    <p style="margin:7px 0px;"><b>Order Date: </b><font style="color:#777"><?php echo date('d-M-Y') ?></font></p>
                                    <p style="margin:7px 0px;"><b>payment status: </b><font style="color:#777">Pending</font></p>
                                </td>
                                <td width="10" style="padding:7px 0">&nbsp;</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>

            <tr>
                <td colspan="2" style="padding: 70px 30px 0px;">
                    <table  style="width:100%; border:1px solid #eeeeee;background-color:#fbfbfb;padding:7px 0">
                        <tbody>
                            <tr>
                                <td width="10" style="padding:7px 0">&nbsp;</td>
                                <td style="padding:7px 0">
                                    <font style="color:inherit;font-family:inherit;font-size:inherit">
                                    <p style="border-bottom:1px solid #eeeeee;margin:3px 0 7px;text-transform:uppercase;font-weight:500;font-size:18px;padding-bottom:10px">
                                        Account details</p>
                                    </font>
                                    <p style="margin:15px 0px;"><font style="font-size: 16px; color:#66c0fd">Please make payment to the following account.</font></p>
                                    <p style="margin:7px 0px;"><b>Bank Name: </b><font style="color:#777">Westpac</font></p>
                                    <!-- <p style="margin:7px 0px;"><b>Branch Name: </b><font style="color:#777">Melburne</font></p> -->
                                    <p style="margin:7px 0px;"><b>Account Number: </b><font style="color:#777">846999</font></p>
                                    <p style="margin:7px 0px;"><b>BSB: </b><font style="color:#777">033 364</font></p>
                                </td>
                                <td width="10" style="padding:7px 0">&nbsp;</td>
                            </tr>
                        </tbody></table>
                </td>
            </tr>

            <tr>
                <td colspan="2" style="padding: 7px 30px;">
                    <table width="100%" cellspacing="0" cellpadding="0" style="border: 1px solid #dde5f1;">
                        <caption><h3 style="text-transform:uppercase; font-weight: 500; text-align: left; margin: 0px; border-bottom: 1px solid #eee; padding: 0px 0px; margin-bottom: 15px; margin-top: 20px;">Item Summary</h3></caption>


                        <tr bgcolor="#66c0fd">
                            <th align="left" style="padding:10px 15px; border-right: 1px solid #dde5f1; color: #fff;">Item Description</th>
                            <th align="left" style="padding:10px 15px; border-right: 1px solid #dde5f1; color: #fff;" width="100px">Price</th>
                            <th align="left" style="padding:10px 15px; border-right: 1px solid #dde5f1; color: #fff;" width="80px">Qty.</th>
                            <th align="center" style="padding:10px 15px; color: #fff;" width="100px">Total</th>
                        </tr>

                        <?php
                        if (!empty($order_data)) {
                            $subtotal = 0;
                            $voucher_reduction = 0;
                            foreach ($order_data as $item) {
                                if ($item->id == 'voucher_id') {
                                    $voucher_reduction = str_replace('-', '-$', $item->price);
                                    continue;
                                }

                                $addional = false;
                                if (!empty($item->options->days_payment)) {
                                    $days = $item->options->days_payment;
                                    $addional = ' (for ' . $days . ' days)';
                                }
                                ?>
                                <tr>
                                    <td style="padding:10px 15px; border-right: 1px solid #dde5f1; border-bottom:1px solid #dde5f1;"><?php echo $products[$item->id]['pro_title'] . $addional ?></td>
                                    <td style="padding:10px 15px; border-right: 1px solid #dde5f1; border-bottom:1px solid #dde5f1;" width="100px">$<?php echo $item->price ?></td>
                                    <td style="padding:10px 15px; border-right: 1px solid #dde5f1; border-bottom:1px solid #dde5f1;" width="80px"><?php echo $item->qty ?></td>
                                    <td align="right" style="padding:10px 15px; border-bottom:1px solid #dde5f1;" width="100px">$<?php echo $s_total = $item->price * $item->qty ?></td>
                                </tr>
                                <?php
                                $subtotal += $s_total;
                            }
                        }
                        ?>
                    </table>
                </td>
            </tr>

            <tr>
                <td colspan="2" style="padding:15px 30px">
                    <table width="100%">
                        <tr>
                            <td width="50%" colspan="2"></td>
                            <td>
                                <h3 style="text-transform:uppercase; font-weight: 500; text-align: left; margin: 0px; border-bottom: 1px solid #eee; padding: 0px 0px; margin-bottom: 15px; margin-top: 20px;">Total</h3>
                                <table  cellspacing="0" cellpadding="0" width="100%" bgcolor="#fff" style="border: 1px solid #dde5f1;">
                                    <tr>
                                        <td width="50%"  style="padding:10px 15px;  border-bottom: 1px solid #dde5f1;">Sub Total</td>
                                        <td align="right" width="50%" style=" padding: 10px 15px; border-bottom: 1px solid #dde5f1;">$<?php echo $subtotal ?></td>
                                    </tr>
                                    <tr>
                                        <td width="50%"  style="padding:10px 15px;  border-bottom: 1px solid #dde5f1;">GST</td>
                                        <td align="right" width="50%" style=" padding: 10px 15px; border-bottom: 1px solid #dde5f1;">$<?php echo ($order_total / $this->config->item('gst')) ?></td>
                                    </tr>

                                    <?php if (!empty($voucher_reduction)) { ?>
                                        <tr>
                                            <td width="50%"  style="padding:10px 15px; ">Voucher Applied</td>
                                            <td align="right" width="50%" style=" padding: 10px 15px;"><?php echo $voucher_reduction ?></td>
                                        </tr>
                                    <?php } ?>

                                    <tr bgcolor="#eee">
                                        <td width="50%"  style="padding:10px 15px 10px;  font-weight: bold;">Total</td>
                                        <td align="right" width="50%" style=" padding: 10px 15px 20px;">$<?php echo $order_total; ?></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <tr>
                <td colspan="2" style="color: #66c0fd; padding: 15px 15px 15px;" align="center">
                    © <?php echo date("Y"); ?> Functions &amp; Catering
                </td>
            </tr>
        </table>
    </body>
</html>