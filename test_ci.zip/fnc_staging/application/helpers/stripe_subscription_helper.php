<?php

require_once APPPATH . 'libraries/stripe-php/init.php';

function create_user($data) {
    $CI = & get_instance();
    \Stripe\Stripe::setApiKey(STRIPE_PRIVATE_KEY);
// create users on stripe

    try {
        $customer = \Stripe\Customer::create([
                    'email' => $data['fc_email'],
                    'source' => $data['stripeToken'],
        ]);

        if (!empty($customer->id)) {
            $strip_user_id = $customer->id;

            $user_data = array(
                'stripe_customer_id' => $customer->id,
                'stripe_customer_card_id' => $customer->default_source, // here default source is customer cart id
                'user_id' => $CI->session->userdata('user_id'),
                'create_date' => date('Y-m-d'),
            );

            $s_id = $CI->basic_model->insert_records('stripe_users', $user_data, $multiple = FALSE);
            $return = array('status' => true, 's_id' => $s_id, 'stripe_customer_id' => $customer->id);
        }
    } catch (Exception $e) {
        $error_msg = $e->getMessage();
        $return = array('status' => false, 'error' => $error_msg);
    }

    return $return;
}

function strip_plan_get($fc_id, $fc_plan, $mode = false) {
    $CI = & get_instance();
    $strip_plans_array = array();

    //start code of plan
    if ($fc_plan) {
        $plans_array = array();
        $where = ($fc_plan == 'year') ? array('product_id' => 2) : array('product_id' => 1);

        $strip_area_plan = $CI->basic_model->get_record_where('stripe_plans', 'strip_plan_id', $where);
        $plans_array['plan'] = $strip_area_plan[0]->strip_plan_id;
        $plans_array['quantity'] = 1;

        if ($mode == 'update') {
            $strip_plans_array[$strip_area_plan[0]->strip_plan_id] = $plans_array;
        } else {
            $strip_plans_array[] = $plans_array;
        }
    }

    // start code of addional area
    $spaces = $CI->basic_model->get_record_where('venue_spaces', 'space_id', $where = array('space_venue' => $fc_id, 'space_status' => 0));
    if (!empty($spaces)) {
        $plans_array = array();
        $total_space = count($spaces);
        // match according to strip plan and get
        $where = array('product_id' => 4, 'time_interval' => $fc_plan); // for area
        $strip_area_plan = $CI->basic_model->get_record_where('stripe_plans', 'strip_plan_id', $where);
        $plans_array['plan'] = $strip_area_plan[0]->strip_plan_id;
        $plans_array['quantity'] = $total_space;

        if ($mode == 'update') {
            $strip_plans_array[$strip_area_plan[0]->strip_plan_id] = $plans_array;
        } else {
            $strip_plans_array[] = $plans_array;
        }
    }

    // start code of spaces
    $addional_area = $CI->basic_model->get_record_where('additional_area', 'area_id', $where = array('area_venue' => $fc_id, 'area_status' => 0));
    if (!empty($addional_area)) {
        $plans_array = array();
        $total_area = count($addional_area);
        // match according to strip plan and get

        $where = array('product_id' => 3, 'time_interval' => $fc_plan); // for area
        $strip_space_plan = $CI->basic_model->get_record_where('stripe_plans', 'strip_plan_id', $where);
        $plans_array['plan'] = $strip_space_plan[0]->strip_plan_id;
        $plans_array['quantity'] = $total_area;
        if ($mode == 'update') {
            $strip_plans_array[$strip_space_plan[0]->strip_plan_id] = $plans_array;
        } else {
            $strip_plans_array[] = $plans_array;
        }
    }

    //start code with addional radius of catering
    $additional_radius = $CI->basic_model->get_record_where('catering_search_radius', 'csr_plan_id', $where = array('csr_fc_id' => $fc_id, 'csr_status' => 0));
    if (!empty($additional_radius)) {
        $plans_array['plan'] = $additional_radius[0]->csr_plan_id;

        $where = array('product_id' => $plans_array['plan'], 'time_interval' => $fc_plan); // for area
        $strip_radius_plan = $CI->basic_model->get_record_where('stripe_plans', 'strip_plan_id', $where);
        $plans_array['plan'] = $strip_radius_plan[0]->strip_plan_id;
        $plans_array['quantity'] = 1;
        if ($mode == 'update') {
            $strip_plans_array[$strip_radius_plan[0]->strip_plan_id] = $plans_array;
        } else {
            $strip_plans_array[] = $plans_array;
        }
    }

    return $strip_plans_array;
}

function active_subscription($data, $strip_plan) {
    \Stripe\Stripe::setApiKey(STRIPE_PRIVATE_KEY);
    $CI = & get_instance();

    try {
        $sub_data = array(
            'customer' => $data['stripe_customer_id'], // here customer used of strip customer
            'items' => $strip_plan, // acoording cart item plan id added
            'prorate' => false,
        );

        // stripe only accept strtotime
        $startDateStrToTime = strtotime($data['subscription_start_date']);
        $current_strtotime = strtotime(date('Y-m-d'));
        if ($current_strtotime >= $startDateStrToTime) {
            // if currnet data grather than start date then  no need to set start time of subscription
        } else {
            $sub_data['trial_end'] = $startDateStrToTime;
        }

        $subscription = \Stripe\Subscription::create($sub_data);

        if (!empty($subscription->id)) {
            $update_subcription_date = array(
                'user_id' => $CI->session->userdata('user_id'),
                'strp_user_id' => $data['s_id'],
                'strp_subscription_id' => $subscription->id,
                'subsciption_active' => 1,
                'fc_id' => $data['fc_id'],
                'start_subscription' => date('Y-m-d', $subscription->billing_cycle_anchor),
                'create_date' => date('Y-m-d'),
            );

            $CI->basic_model->insert_records('stripe_subscription', $update_subcription_date);
            $return = array('status' => true, 'strip_subscription_id' => $subscription->id);
        }
    } catch (Exception $e) {
        $error_msg = $e->getMessage();
        $return = array('status' => false, 'error' => $error_msg);
    }
    return $return;
}

function cancel_subscription($data) {

    \Stripe\Stripe::setApiKey(STRIPE_PRIVATE_KEY);
    $CI = & get_instance();

    try {
        $subscription = \Stripe\Subscription::retrieve($data['strp_subscription_id']);

        if ($data['cancel_type'] == 1) { // if cancel imidiatally
            $subscription->cancel();
        } else { // if cancel at last end of month
            $subscription->cancel(['at_period_end' => true]);
        }

        if (!empty($subscription)) {
            $cancel_data = array(
                'cancel_date' => date('Y-m-d', $subscription->canceled_at),
                'subsciption_active' => 2
            );

            $where = array('ss_id' => $data['ss_id']);
            $CI->basic_model->update_records('stripe_subscription', $cancel_data, $where);

            $return = array('status' => true);
        }
    } catch (Exception $e) {
        $error_msg = $e->getMessage();
        $return = array('status' => false, 'error' => $error_msg);
    }

    return $return;
}

function strip_webhook($event_json) {
    $CI = & get_instance();

    try {
        $event_array = json_decode($event_json);
        
        if ($event_array->type == 'invoice.payment_succeeded') {
            $object = $event_array->data->object;
            $product_plans = $event_array->data->object->lines->data;

            $subscription_id = $object->subscription;

            $subscriber_data = $CI->basic_model->get_record_where('stripe_subscription', array('fc_id', 'user_id'), $where = array('strp_subscription_id' => $subscription_id));


            if (!empty($subscriber_data)) {
                $fc_id = $subscriber_data[0]->fc_id;
                $user_id = $subscriber_data[0]->user_id;

                $payment_datails = array(
                    'pay_txn_id' => $object->charge,
                    'pay_fc_id' => $fc_id,
                    'pay_total_amount' => $object->amount_paid / 100,
                    'pay_user' => $user_id,
                    'payment_mode' => 1,
                    'payment_method' => 1,
                    'payment_status' => 2,
                    'payment_type' => 1,
                    'payment_status' => 2,
                    'payment_type' => 2,
                    'payment_method' => 1,
                    'payment_mode' => 1,
                    'pay_created_on' => date('Y-m-d', $event_array->created),
                );

                $CI->basic_model->insert_records('payment_details', $payment_datails, $multiple = FALSE);

                if (!empty($product_plans)) {
                    // get our existing plan from database 
                    $existing_plans_data = $CI->basic_model->get_record_where('stripe_plans', array('strip_plan_id'), $where = 'product_id IN (1,2)');
                    $existing_plans = array();
                    foreach ($existing_plans_data as $plans) {
                        $existing_plans[] = $plans->strip_plan_id;
                    }

                    $plan_inverval = '';
                    foreach ($product_plans as $val) {
                        if (in_array($val->plan->id, $existing_plans)) {
                            $plan_inverval = $val->plan->interval;
                        }
                    }
                }

                if ($plan_inverval == 'year' or $plan_inverval == 'month') {
                    $fc_data = $CI->basic_model->get_record_where('function_catering', 'fc_valid_upto', $where_fc = array('fc_id' => $fc_id));
                    $old_expiry_date = $fc_data[0]->fc_valid_upto;

                    if (strtotime($old_expiry_date) < strtotime(date('Y-m-d'))) {
                        $old_expiry_date = date('Y-m-d');
                    }

                    $valid_upto = date("Y-m-d", strtotime("+1 $plan_inverval", strtotime($old_expiry_date)));
                    $CI->basic_model->update_records('function_catering', array('fc_valid_upto' => $valid_upto, 'fc_free' => 0), $where_fc);
              
                }
            }
        }
    } catch (Exception $e) {
        $error_msg = $e->getMessage();
        $return = array('fc_id' => $fc_id, 'error' => $error_msg);
        $return = file_put_contents($file_path, json_encode($return) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}

function update_subscription($fc_id) {
    $CI = & get_instance();
    \Stripe\Stripe::setApiKey(STRIPE_PRIVATE_KEY);

    try {
        $subscriber_data = $CI->basic_model->get_record_where('stripe_subscription', array('strp_subscription_id'), $where = array('fc_id' => $fc_id, 'subsciption_active' => 1));

        if (!empty($subscriber_data)) {
            $subscriptionID = $subscriber_data[0]->strp_subscription_id;

            // get all subscription data
            $subscription = \Stripe\Subscription::retrieve($subscriptionID);

            // all product or plan on stripe
            $current_product_plans = $subscription->items->data;

            $plan_inverval = false;
            $subcription_plan_id = false;
            if (!empty($current_product_plans)) {
                // get our existing plan from database 
                $existing_plans_data = $CI->basic_model->get_record_where('stripe_plans', array('strip_plan_id'), $where = 'product_id IN (1,2)');
                $existing_plans = array();
                foreach ($existing_plans_data as $plans) {
                    $existing_plans[] = $plans->strip_plan_id;
                }

                foreach ($current_product_plans as $val) {
                    if (in_array($val->plan->id, $existing_plans)) {
                        $subcription_plan_id = $val->id;
                        $plan_inverval = $val->plan->interval;
                    }
                }
            }

            if ($plan_inverval && $subcription_plan_id) {
                $current_active_plans = strip_plan_get($fc_id, $plan_inverval, 'update');

                $i = 0;
                foreach ($current_product_plans as $val) {
                    if (!empty($current_active_plans[$val->plan->id]['quantity'])) {
                        $update_plans[$i]['id'] = $val->id;
                        $update_plans[$i]['plan'] = $val->plan->id;
                        $update_plans[$i]['quantity'] = $current_active_plans[$val->plan->id]['quantity'];
                        $current_active_plans[$val->plan->id]['status'] = true;
                    } else {
                        $si = \Stripe\SubscriptionItem::retrieve($val->id);
                        $si->delete(array('prorate' => false));
                    }
                    $i++;
                }

                if (!empty($update_plans)) {
                    $response = \Stripe\Subscription::update($subscriptionID, [
                                'cancel_at_period_end' => false,
                                'items' => $update_plans,
                                'prorate' => false,
                    ]);
                }

                foreach ($current_active_plans as $new_item) {
                    if (empty($new_item['status'])) {
                        \Stripe\SubscriptionItem::create(array(
                            "subscription" => $subscriptionID,
                            "plan" => $new_item['plan'],
                            "quantity" => $new_item['quantity'],
                            "prorate" => false,
                        ));
                    }
                }
            }
        }
    } catch (Exception $e) {
        $error_msg = $e->getMessage();
        $file_path = APPPATH . 'logs/stripe_log.log';
        $return = array('fc_id' => $fc_id, 'error' => $error_msg);
        $return = file_put_contents($file_path, json_encode($return) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}
