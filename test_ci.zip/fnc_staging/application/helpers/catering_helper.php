<?php

function account_details_invoice($order_data, $total, $payId) {
    $CI = & get_instance();
    require_once(APPPATH . 'libraries/mpdf/mpdf.php');
    $CI->load->helper('email_template_helper');

    $data = array();
    $order_data = json_decode($order_data);

    $packs = $CI->basic_model->get_record_where('products', 'pro_id,pro_title', '');
    foreach ($packs as $val) {
        $product[$val->pro_id] = (array) $val;
    }

    $data['invoice_no'] = sprintf("%010d", $payId);
    $data['order_total'] = $total;
    $data['products'] = $product;
    $data['order_data'] = $order_data;

    $file = $CI->load->view('invoices/account_details_invoice', $data, TRUE);
    @ob_clean();
    $mpdf = new mPDF();
    @ob_end_clean();

    $mpdf->WriteHTML($file);
    $date = time();
    $pdf_name = 'fnc-bank-details' . $date . '.pdf';

    $mpdf->Output('assets/pdf/' . $pdf_name, 'F');
    send_account_details_invoice($pdf_name);
}

function getErrorMessages($key) {
    $error = array();

    $error['fc_state'] = array(
        'required' => 'Business Details - Please select state',
    );

    $error['fc_suburb'] = array(
        'required' => 'Business Details - Please enter city',
    );
    $error['fc_street'] = array(
        'required' => 'Business Details - Please enter street',
    );
    $error['fc_postcode'] = array(
        'required' => 'Business Details - Please enter postcode',
    );

    $error['fc_abn'] = array(
        'required' => 'Business Details - Please enter ABN number',
        'numeric' => 'Business Details - Please enter ABN number only numeric',
        'exact_length' => 'Business Details - ABN number must be 11 digit',
    );
    $error['fc_listing_picture'] = array(
        'required' => 'Page Layout - Please upload listing picture',
    );
    $error['fc_contact_name'] = array(
        'required' => 'Business Details - Please enter contact name',
    );
    $error['fc_phone_no'] = array(
        'required' => 'Business Details - Please enter phone number',
//        'numeric' => 'Business Details - Please enter phone number only numeric',
//        'exact_length' => 'Business Details - Phone number must be 8 digit',
    );
    $error['fc_unit'] = array(
        'required' => 'Business Details - Please enter unit',
    );
    $error['fc_overview'] = array(
        'required' => 'Catering Details - Please enter overview of your Catering',
        'greater_than' => 'Catering Details - Please enter overview at least 100 character',
        'less_than' => 'Catering Details - Please enter overview less than 1318',
    );
    $error['fc_min_guest'] = array(
        'greater_than' => 'Catering Details - Please enter minimum guest greather than 0',
    );

    $error['fc_max_guest'] = array(
        'greater_than' => 'Catering Details - Please enter maximum guest greather than 0',
    );

    $error['cd_function_type'] = array(
        'check_fc_details' => 'Catering Details - Please select a minimum of 3 Function Type of your Catering',
    );
    $error['cd_menus'] = array(
        'check_fc_details' => 'Catering Details - Please select a minimum of 3 Menus of your Catering',
    );
    $error['cd_cuisine'] = array(
        'check_fc_details' => 'Catering Details - Please select a minimum of 3 Cuisine of your Catering',
    );
    $error['cd_services'] = array(
        'check_fc_details' => 'Catering Details - Please select a minimum of 3 Services of your Catering',
    );
    $error['fc_pricing'] = array(
        'required' => 'Catering Details - Please select at least 1 average price per head ',
    );
    $error['fc_email'] = array(
        'required' => 'Business Details - Please enter your company email id',
        'valid_email' => 'Business Details - Please enter valid company email id',
    );



    return $error[$key];
}

function venueValidationRule($fc_id, $venueData, $venue_images) {
    $validation_rules = array(
        array('field' => 'fc_business_name', 'label' => 'fc_business_name', 'rules' => 'callback_check_business_name[' . $fc_id . ']'),
        array('field' => 'fc_contact_name', 'label' => 'contact name', 'rules' => 'required', 'errors' => getErrorMessages('fc_contact_name')),
        array('field' => 'fc_email', 'label' => 'contact name', 'rules' => 'required|valid_email', 'errors' => getErrorMessages('fc_email')),        
//        array('field' => 'fc_phone_no', 'label' => 'phone', 'rules' => 'required|numeric|exact_length[8]', 'errors' => getErrorMessages('fc_phone_no')),
        array('field' => 'fc_phone_no', 'label' => 'phone', 'rules' => 'required', 'errors' => getErrorMessages('fc_phone_no')),
        array('field' => 'fc_abn', 'label' => 'ABN', 'rules' => 'required|numeric|exact_length[11]', 'errors' => getErrorMessages('fc_abn')),
        array('field' => 'fc_street', 'label' => 'street', 'rules' => 'required', 'errors' => getErrorMessages('fc_street')),        		
		array('field' => 'fc_suburb', 'rules' => 'callback_check_address_details_valid['.json_encode($venueData).']'),		
        array('field' => 'fc_postcode', 'rules' => 'callback_check_postcode_validate[' . $venueData['fc_postcode'] . ']'),		
        array('field' => 'fc_cart_data', 'rules' => 'callback_check_package[' . $venueData['fc_free'] . ']'),        
        array('field' => 'fc_overview', 'rules' => "callback_check_overview_validate[Catering Details]"),
        array('field' => 'fc_min_guest', 'label' => 'min guest', 'rules' => 'greater_than[0]|required', 'errors' => getErrorMessages('fc_min_guest')),
        array('field' => 'fc_max_guest', 'label' => 'max guest', 'rules' => 'required|greater_than[0]', 'errors' => getErrorMessages('fc_max_guest')),
        array('field' => 'fc_pricing', 'label' => 'pricing type', 'rules' => 'required', 'errors' => getErrorMessages('fc_pricing')),
        array('field' => 'cd_function_type', 'label' => 'function events', 'rules' => 'callback_check_fc_details[3]', 'errors' => getErrorMessages('cd_function_type')),
        array('field' => 'cd_menus', 'label' => 'catering menus', 'rules' => 'callback_check_fc_details[3]', 'errors' => getErrorMessages('cd_menus')),
        array('field' => 'cd_cuisine', 'label' => 'catering cuisine', 'rules' => 'callback_check_fc_details[3]', 'errors' => getErrorMessages('cd_cuisine')),
        array('field' => 'cd_services', 'label' => 'catering services', 'rules' => 'callback_check_fc_details[3]', 'errors' => getErrorMessages('cd_services')),
        array('field' => 'fc_listing_picture', 'label' => 'Listing picture', 'rules' => 'required', 'errors' => getErrorMessages('fc_listing_picture')),
        array('field' => 'fc_img', 'rules' => 'callback_check_fc_images[' . json_encode($venue_images) . ']'),		
    );
    
     if($venueData['fc_details_select'] == 1){
       $validation_rules[] =  array('field' => 'fc_details', 'rules' => 'callback_check_fc_details_validate[Catering Details]');
    }

    return $validation_rules;
}

?>