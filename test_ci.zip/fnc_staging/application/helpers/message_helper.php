<?php
function system_msgs($msg_key)
{
	$global_ary = array('subscriber_add_success'     =>   'Thank you for Subscribing',
		'subscriber_add_fail'             			 =>   'Error in subscription,Please try again.',		
		'No_record_in_search'             			 =>   'No record found.',
		'already_subscribe'             			 =>   'You are already Subscribed.',		
	);
return $global_ary[$msg_key];
}
?>
