<?php

function account_details_invoice($order_data, $total, $payId) {
    $CI = & get_instance();
    require_once(APPPATH . 'libraries/mpdf/mpdf.php');
    $CI->load->helper('email_template_helper');

    $data = array();
    $order_data = json_decode($order_data);

    $packs = $CI->basic_model->get_record_where('products', 'pro_id,pro_title', '');
    foreach ($packs as $val) {
        $product[$val->pro_id] = (array) $val;
    }

    $data['invoice_no'] = sprintf("%010d", $payId);
    $data['order_total'] = $total;
    $data['products'] = $product;
    $data['order_data'] = $order_data;

    $file = $CI->load->view('invoices/account_details_invoice', $data, TRUE);
    @ob_clean();
    $mpdf = new mPDF();
    @ob_end_clean();

    $mpdf->WriteHTML($file);
    $date = time();
    $pdf_name = 'fnc-bank-details' . $date . '.pdf';

    $mpdf->Output('assets/pdf/' . $pdf_name, 'F');
    send_account_details_invoice($pdf_name);
}

function getErrorMessages($key) {
    $error = array();

    $error['fc_state'] = array(
        'required' => 'Business Details - Please select state',
    );

    $error['fc_suburb'] = array(
        'required' => 'Business Details - Please enter city',
    );
    $error['fc_street'] = array(
        'required' => 'Business Details - Please enter street',
    );
    $error['fc_postcode'] = array(
        'required' => 'Business Details - Please enter postcode',
    );

    $error['fc_abn'] = array(
        'required' => 'Business Details - Please enter ABN number',
    );
    $error['fc_listing_picture'] = array(
        'required' => 'Page Layout - Please upload listing picture',
    );
    $error['fc_contact_name'] = array(
        'required' => 'Business Details - Please enter contact name',
    );
    $error['fc_email'] = array(
        'required' => 'Business Details - Please enter company email',
    );

    $error['fc_phone_no'] = array(
        'required' => 'Business Details - Please enter phone number',
    );
    $error['fc_unit'] = array(
        'required' => 'Business Details - Please enter unit',
    );
//    $error['fc_overview'] = array(
//        'required' => 'Venue Details - Please enter overview of your venue',
//        'greater_than' => 'Venue Details - Please enter overview at least 100 character',
//        'less_than' => 'Venue Details - Please enter overview less than 1200',
//    );
    $error['fc_min_guest'] = array(
        'greater_than' => 'Venue Details - Please enter minimum guest greather than 0',
    );

    $error['fc_max_guest'] = array(
        'greater_than' => 'Venue Details - Please enter maximum guest greather than 0',
    );


    $error['fc_pricing'] = array(
        'required' => 'Venue Details - Please select at least 1 price',
    );
    $error['vd_events'] = array(
        'check_fc_details' => 'Venue Details - Please select at least 3 events',
    );
    $error['vd_facilities'] = array(
        'check_fc_details' => 'Venue Details - Please select a minimum of 1 Facilities of your venue',
    );
    $error['vd_features'] = array(
        'check_fc_details' => 'Venue Details - Please select a minimum of 1 Features of your venue',
    );

    return $error[$key];
}

function venueValidationRule($fc_id, $venueData, $venue_images) {

    $validation_rules = array(
        array('field' => 'fc_contact_name', 'label' => 'contact name', 'rules' => 'required', 'errors' => getErrorMessages('fc_contact_name')),
        array('field' => 'fc_email', 'label' => 'company email', 'rules' => 'required', 'errors' => getErrorMessages('fc_email')),
        array('field' => 'fc_phone_no', 'label' => 'phone', 'rules' => 'required', 'errors' => getErrorMessages('fc_phone_no')),
        array('field' => 'fc_business_name', 'label' => 'fc_business_name', 'rules' => 'callback_check_business_name[' . $fc_id . ']'),
        array('field' => 'fc_abn', 'label' => 'ABN', 'rules' => 'required|numeric|exact_length[11]', 'errors' => getErrorMessages('fc_abn')),
        array('field' => 'fc_street', 'label' => 'street', 'rules' => 'required', 'errors' => getErrorMessages('fc_street')),
        // array('field' => 'fc_suburb', 'label' => 'suburb', 'rules' => 'required', 'errors' => getErrorMessages('fc_suburb')),
        array('field' => 'fc_suburb', 'rules' => 'callback_check_address_details_valid[' . json_encode($venueData) . ']'),
        array('field' => 'fc_postcode', 'rules' => 'callback_check_postcode_validate[' . $venueData['fc_postcode'] . ']'),
        //array('field' => 'fc_postcode', 'label' => 'postcode', 'rules' => 'required|min_length[3]|max_length[4]', 'errors' => getErrorMessages('fc_postcode')),
        //array('field' => 'fc_postcode', 'label' => 'ABN', 'rules' => 'required|numeric|exact_length[11]', 'errors' => getErrorMessages('fc_abn')),
        array('field' => 'fc_cart_data', 'rules' => 'callback_check_package[' . $venueData['fc_free'] . ']'),
        array('field' => 'fc_overview', 'rules' => 'callback_check_overview_validate[Venue Details]'),
        array('field' => 'fc_min_guest', 'label' => 'min guest', 'rules' => 'greater_than[0]|required', 'errors' => getErrorMessages('fc_min_guest')),
        array('field' => 'fc_max_guest', 'label' => 'max guest', 'rules' => 'required|greater_than[0]', 'errors' => getErrorMessages('fc_max_guest')),
        array('field' => 'fc_pricing', 'label' => 'pricing type', 'rules' => 'required', 'errors' => getErrorMessages('fc_pricing')),
        array('field' => 'vd_events', 'label' => 'venue events', 'rules' => 'callback_check_fc_details[3]', 'errors' => getErrorMessages('vd_events')),
        array('field' => 'vd_facilities', 'label' => 'venue facilities', 'rules' => 'callback_check_fc_details[1]', 'errors' => getErrorMessages('vd_facilities')),
        array('field' => 'vd_features', 'label' => 'venue features', 'rules' => 'callback_check_fc_details[1]', 'errors' => getErrorMessages('vd_features')),
        array('field' => 'fc_img', 'rules' => 'callback_check_fc_images[' . json_encode($venue_images) . ']'),
        array('field' => 'fc_state', 'label' => 'state', 'rules' => 'required', 'errors' => getErrorMessages('fc_state')),
        array('field' => 'fc_listing_picture', 'label' => 'Listing picture', 'rules' => 'required', 'errors' => getErrorMessages('fc_listing_picture')),
            //array('field' => 'fc_unit', 'label' => 'unit', 'rules' => 'required', 'errors' => getErrorMessages('fc_unit')),
            //array('field' => 'fc_overview', 'label' => 'overview', 'rules' => 'required|min_length[100]|max_length[1200]', 'errors' => getErrorMessages('fc_overview')),
    );

    if ($venueData['fc_details_select'] == 1) {
        $validation_rules[] = array('field' => 'fc_details', 'rules' => 'callback_check_fc_details_validate[Venue Details]');
    }


    return $validation_rules;
}
?>