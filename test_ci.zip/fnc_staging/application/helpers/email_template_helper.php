<?php

//send_mail_smtp
function send_mail($to_email, $subject, $body, $cc_email_address = null) {
    $obj = & get_instance();
    $msg = $body;
    $from_email = 'Info@functionsandcatering.com';
    $obj->load->library('email');
    $config['protocol'] = "smtp";
    $config['smtp_host'] = 'ssl://smtp.gmail.com';
//  $config['smtp_host'] = 'tls://smtp.gmail.com';
    $config['smtp_port'] = 465;  //25
    $config['smtp_user'] = 'developer@yourdevelopmentteam.com.au';
    $config['smtp_pass'] = 'NPRBpXEtUf';
    $config['charset'] = "utf-8";
    $config['mailtype'] = "html";
    $config['newline'] = "\r\n";
    $config['priority'] = "1";
    $obj->email->initialize($config);
    $obj->email->from($from_email, APPLICATION_NAME);
    $obj->email->to($to_email);
    $obj->email->cc($cc_email_address);
    $obj->email->subject($subject);
    $obj->email->message($msg);
    $obj->email->send();

    $output = $obj->email->print_debugger();
    return true;
}

// change smtp to send mail function 
//send_mail
function send_mail_smtp($to_email, $subject, $body, $cc_email_address = null) {
    //mail send using ci library
    $obj = & get_instance();
    $obj->load->library('email');
    $obj->email->set_mailtype('html');
    $obj->email->from('Info@functionsandcatering.com', APPLICATION_NAME);
    $obj->email->to($to_email);
    //$obj->email->to('riteshpaliwal88@gmail.com');
    $obj->email->subject($subject);
    $obj->email->message($body);
    //$obj->email->attach($pdfFilePath1);
    $obj->email->send();
    return true;
}

function pending_fc_mail_to_user($fc_data, $cc_email_address = null) {
    $obj = & get_instance();
    if ($fc_data['type'] == 1) {
        $type = 'Venue  ';
    }
    if ($fc_data['type'] == 2) {
        $type = 'Catering  ';
    }
    $subject = "Pending for approval " . $type . $fc_data['business_name'];
    $name = $fc_data['name'];
    $email = $fc_data['email'];
    $logo_url = base_url() . 'assets/images/logo_fnc.png';
    $logo_url_second = base_url() . 'assets/images/footer_logo.png';
    $url = $fc_data['url'];
//    $types = $fc_data['type'];
//    $type = ucfirst($types);
    // $req_date = $fc_data['requested_date'];

    $new_date = $fc_data['requested_date'];
    $req_date = date("d-m-Y", strtotime($new_date));
    $year = date('Y');
    $contact_link = base_url("web/contact_us");

    $msg = '<!DOCTYPE html>
  <html>
  <head>
    <title>TODO supply a title</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body style="padding: 0; margin: 0px;">

    <table align="center">
      <tr>
        <td align="center">
          <table width="700px" cellpadding="0" cellspacing="0" style="font-family: sans-serif;">
            <thead  bgcolor="#3399cc">
              <tr>
                <th width="100%"  style="padding:60px 0px"><img src="' . $logo_url . '" width="280px" /></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td bgcolor="#cccccc" style="padding: 15px;">
                  <table bgcolor="#fff" width="100%">
                    <tr><td style="font-size: 20px; color: #3399cc; text-align: center; padding: 15px;"> ' . $type . ' Awaiting Approval</td></tr>
                    <tr>
                      <td style="font-size: 14px; color: #666666; padding: 0px 15px;">
                       <p> Dear ' . ucfirst($name) . ',</p>
                       <p style="margin: 0px">Congratulations. You have completed your listing! We aim to have listings live within 24 hours,</p>
                       <p style="margin: 0px">subject to our final review.You will receive an email notification once your listing is live.</p>
                       <p style="margin: 0px"> in the event we identify an issue with your listing,we will contact you via the email address in your user profile.</p>
                     </p>
                   </td>
                 </tr>

                 <tr>
                  <td style="padding: 20px 15px">
                    <table>
                      <tr>
                        <td width="80px"></td>
                        <td style="border-left: 7px solid #3399cc; padding-left: 10px; font-size: 14px; color: #666666">
                          <p style="margin:0px 0px 10px; line-height: 15px;"><span style="color:#3399cc;">Requested By:</span>' . ucfirst($name) . '</p>
                          <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Date of Request: </span>' . $req_date . '</p>
                          <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Buisiness Name: </span>' . ucfirst($fc_data['business_name']) . '</p>
                          <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Email ID:</span>' . $email . '</p>
                          <p style="margin:10px 0px 0px; line-height: 15px;"><span style="color:#3399cc;">Contact: </span>' . $fc_data['business_number'] . '</p>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                    <p style="margin-bottom: 0px;">Thanks</p>
                    <p style="margin-top: 0px;">from the Functions & Catering Team</p>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 0px 15px;">
                    <p style="margin: 0px; height: 1px; border-top:1px solid #0099cc; width: 80%; "></p>
                  </td>
                </tr>
                <tr>
                  <td style="font-size: 14px; color: #666666; vertical-align: middle; padding: 7px 15px;">
                    <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px;"><img src="' . $logo_url_second . '"></p>
                    <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px; padding-left: 15px"> &copy; ' . $year . ' Functions and Catering Australia Pty. Ltd.</p>
                  </td>
                </tr>
              </table>
              <table>
               <tr>
                <td style="font-size: 12px; color: #666666; padding:15px 15px 0px;">
                  <p style="margin: 0px;">If you have recieved this message in error or have not registered for a Functions & Catering account, <a href="' . $contact_link . '" style="color: #3399cc">Click here</a></p>
                  <p style="margin: 0px;">or simply just ignore this email.</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>

      </tbody>

    </table>
  </td>
</tr>
</table>

</body>
</html>
';

    $output = send_mail($email, $subject, $msg);
    return $output;
}

function alert_admin_mail($fc_data, $cc_email_address = null) {
    $obj = & get_instance();
    $subject = "Pending for approval " . $fc_data['type'] . "-" . $fc_data['business_name'];
    $name = $fc_data['name'];
    $email = "Info@functionsandcatering.com";
    $logo_url = base_url() . 'assets/images/logo_fnc.png';
    $logo_url_second = base_url() . 'assets/images/footer_logo.png';
    $url = $fc_data['url'];
    //$req_date = $fc_data['requested_date'];
    $year = date('Y');
    $contact_link = base_url("web/contact_us");
    $new_date = $fc_data['requested_date'];
    $req_date = date("d-m-Y", strtotime($new_date));

    $msg = '<!DOCTYPE html>
  <html>
  <head>
    <title>TODO supply a title</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body style="padding: 0; margin: 0px;">

    <table align="center">
      <tr>
        <td align="center">
          <table width="700px" cellpadding="0" cellspacing="0" style="font-family: sans-serif;">
            <thead  bgcolor="#3399cc">
              <tr>
                <th width="100%"  style="padding:60px 0px"><img src="' . $logo_url . '" width="280px" /></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td bgcolor="#cccccc" style="padding: 15px;">
                  <table bgcolor="#fff" width="100%">
                    <tr><td style="font-size: 20px; color: #3399cc; text-align: center; padding: 15px;">Account  Awaiting Approval</td></tr>
                    <tr>
                      <td style="font-size: 14px; color: #666666; padding: 0px 15px;">
                       <p> Dear Admin,</p>
                       <p>Thank you for submitting your venue to us. </p>
                       <p style="margin: 0px">Here at F&C we want to provide the best possible community for our users.As part of that, </p>
                       <p style="margin: 0px">each new vendor submitted must be reviewed by our staff prior to going live, Once </p>
                       <p style="margin: 0px">approved you will receive an email notification.Thanks for you patience</p>
                     </p>
                   </td>
                 </tr>

                 <tr>
                  <td style="padding: 20px 15px">
                    <table>
                      <tr>
                        <td width="80px"></td>
                        <td style="border-left: 7px solid #3399cc; padding-left: 10px; font-size: 14px; color: #666666">
                          <p style="margin:0px 0px 10px; line-height: 15px;"><span style="color:#3399cc;">Requested By:</span>' . ucfirst($name) . '</p>
                          <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Date of Request: </span>' . $req_date . '</p>
                          <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Buisiness Name: </span>' . ucfirst($fc_data['business_name']) . '</p>
                          <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Email ID:</span>' . $email . '</p>
                          <p style="margin:10px 0px 0px; line-height: 15px;"><span style="color:#3399cc;">Contact: </span>' . $fc_data['business_number'] . '</p>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>


                <tr>
                  <td  style="font-size: 14px; color: #666666; padding:15px 15px">
                    <p style="margin: 0px;">Or click the following link:</p>
                    <a href=' . $url . ' style="color: #3399cc">' . $url . '</a>
                  </td>
                </tr>
                <tr>
                  <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                    <p style="margin-bottom: 0px;">Thanks</p>
                    <p style="margin-top: 0px;">from the Functions & Catering Team</p>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 0px 15px;">
                    <p style="margin: 0px; height: 1px; border-top:1px solid #0099cc; width: 80%; "></p>
                  </td>
                </tr>
                <tr>
                  <td style="font-size: 14px; color: #666666; vertical-align: middle; padding: 7px 15px;">
                    <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px;"><img src="' . $logo_url_second . '"></p>
                    <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px; padding-left: 15px"> &copy; ' . $year . ' Functions and Catering Australia Pty. Ltd.</p>
                  </td>
                </tr>
              </table>
              <table>
               <tr>
                <td style="font-size: 12px; color: #666666; padding:15px 15px 0px;">
                  <p style="margin: 0px;">If you have recieved this message in error or have not registered for a Functions & Catering account, <a href="' . $contact_link . '" style="color: #3399cc">Click here</a></p>
                  <p style="margin: 0px;">or simply just ignore this email.</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>

      </tbody>

    </table>
  </td>
</tr>
</table>

</body>
</html>';
    $output = send_mail($email, $subject, $msg);
    return $output;
}

function query_form_mail($query_data) {
    $test = $query_data ['fq_fc_id'];
    $obj = & get_instance();
    $subject = 'Query for ' . $query_data["type"] . '';
    $name = $query_data['client_name'];
    $email = $query_data['email'];
    $year = date('Y');
    $contact_link = base_url("web/contact_us");
    $logo_url = base_url() . 'assets/images/logo_fnc.png';
    $logo_url_second = base_url() . 'assets/images/footer_logo.png';
    // $logo_url = base_url() . 'assets/images/fnc_logo.svg';
    $date = $query_data["fq_function_date"];
    $no_of_guest = $query_data["fq_guest_no"];
    $msg = '<!DOCTYPE html>
 <html>
 <head>
  <title>TODO supply a title</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="padding: 0; margin: 0px;">

  <table align="center">
    <tr>
      <td align="center">
        <table width="700px" cellpadding="0" cellspacing="0" style="font-family: sans-serif;">
          <thead  bgcolor="#3399cc">
            <tr>
              <th width="100%"  style="padding:60px 0px"><img src="' . $logo_url . '" width="280px" /></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td bgcolor="#cccccc" style="padding: 15px;">
                <table bgcolor="#fff" width="100%">
                  <tr><td style="font-size: 20px; color: #3399cc; text-align: center; padding: 15px;">Sent a Query</td></tr>
                  <tr>
                    <td style="font-size: 14px; color: #666666; padding: 0px 15px;">
                     <p> Dear ' . $name . ',</p>
                     <p>Thank you for submitting your Queries with us. </p>
                     <p style="margin: 0px">Here we are provide best soltions </p>
                     <p style="margin: 0px">each new vendor submitted must be reviewed by our staff prior to going live, Once </p>
                     <p style="margin: 0px">approved you will receive an email notification. Thanks for you patience</p>
                   </p>
                 </td>
               </tr>

               <tr>
                <td style="padding: 20px 15px">
                  <table>
                    <tr>
                      <td width="80px"></td>
                      <td style="border-left: 7px solid #3399cc; padding-left: 10px; font-size: 14px; color: #666666">
                        <p style="margin:0px 0px 10px; line-height: 15px;"><span style="color:#3399cc;">Requested By:</span>' . ucfirst($name) . '</p>
                        <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Preferred function date: </span>' . $query_data["fq_function_date"] . '</p>
                        <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Proposed number of guests: </span>' . $query_data["fq_guest_no"] . '</p>
                        <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Type of event:</span>' . $query_data["fq_event_type"] . '</p>
                        <p style="margin:10px 0px 0px; line-height: 15px;"><span style="color:#3399cc;">Other queries: </span>' . $query_data["fq_other_queries"] . '</p>
                        <p style="margin:10px 0px 0px; line-height: 15px;"><span style="color:#3399cc;">Url: </span>' . $query_data['fc_url'] . '</p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>



              <tr>
                <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                  <p style="margin-bottom: 0px;">Thanks</p>
                  <p style="margin-top: 0px;">from the Functions & Catering Team</p>
                </td>
              </tr>
              <tr>
                <td style="padding: 0px 15px;">
                  <p style="margin: 0px; height: 1px; border-top:1px solid #0099cc; width: 80%; "></p>
                </td>
              </tr>
              <tr>
                <td style="font-size: 14px; color: #666666; vertical-align: middle; padding: 7px 15px;">
                  <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px;"><img src="' . $logo_url_second . '"></p>
                  <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px; padding-left: 15px"> &copy; ' . $year . ' Functions and Catering Australia Pty. Ltd.</p>
                </td>
              </tr>
            </table>
            <table>
             <tr>
              <td style="font-size: 12px; color: #666666; padding:15px 15px 0px;">
                <p style="margin: 0px;">If you have recieved this message in error or have not registered for a Functions & Catering account, <a href="' . $contact_link . '" style="color: #3399cc">Click here</a></p>
                <p style="margin: 0px;">or simply just ignore this email.</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>

    </tbody>

  </table>
</td>
</tr>
</table>

</body>
</html>';
    ;
    $output = send_mail($email, $subject, $msg);
    return $output;
}

function approved_fc_mail($fc_data, $cc_email_address = null) {

    if ($fc_data["type"] == 1) {
        $type = 'venue  ';
        $url = site_url('view_venue/') . encrypt_decrypt('encrypt', $fc_data['fc_id']);
    }
    if ($fc_data["type"] == 2) {
        $type = 'caterer  ';
        $url = site_url('view_catering/') . encrypt_decrypt('encrypt', $fc_data['fc_id']);
    }

    $obj = & get_instance();
//    $subject = 'Your ' . $fc_data["business_name"] . ' approved ';
    $subject = 'Your ' . $type . ' request for ' . $fc_data["business_name"] . ' is approved';
    $name = $fc_data['name'];
    $email = $fc_data['email'];
    $contact_no = $fc_data['contact_no'];
    $logo_url = base_url() . 'assets/images/logo_fnc.png';
    $logo_url_second = base_url() . 'assets/images/footer_logo.png';
    //$url = $fc_data['url'];
    $year = date('Y');
    $contact_link = base_url("web/contact_us");
    $new_date = $fc_data['requested_date'];
    $req_date = date("d-m-Y", strtotime($new_date));

    $msg = '<!DOCTYPE html>
  <html>
  <head>
    <title>TODO supply a title</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body style="padding: 0; margin: 0px;">

    <table align="center">
      <tr>
        <td align="center">
          <table width="700px" cellpadding="0" cellspacing="0" style="font-family: sans-serif;">
            <thead  bgcolor="#3399cc">
              <tr>
                <th width="100%"  style="padding:60px 0px"><img src="' . $logo_url . '" width="280px" /></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td bgcolor="#cccccc" style="padding: 15px;">
                  <table bgcolor="#fff" width="100%">
                    <tr><td style="font-size: 20px; color: #3399cc; text-align: center; padding: 15px;">Your ' . $type . ' Has Been Approved!</td></tr>
                    <tr>
                      <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                        <p> Dear ' . $name . ',</p>
                        <p style="margin-bottom: 0px">Thanks for your patience. Your ' . $type . ' has been approved and is ready for 
                         business!</p>
                       </td>
                     </tr>

                     <tr>
                      <td style="padding: 20px 15px">
                        <table>
                          <tr>
                            <td width="80px"></td>
                            <td style="border-left: 7px solid #3399cc; padding-left: 10px; font-size: 14px; color: #666666">
                             <p style="margin:0px 0px 10px; line-height: 15px;"><span style="color:#3399cc;">Requested By:</span>' . ucfirst($fc_data['contact_name']) . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Date of Request: </span>' . $req_date . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Buisiness Name: </span>' . ucfirst($fc_data['business_name']) . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Email ID:</span>' . $fc_data['contact_email'] . '</p>
                             <p style="margin:10px 0px 0px; line-height: 15px;"><span style="color:#3399cc;">Contact: </span>' . $contact_no . '</p>
                           </td>
                         </tr>
                       </table>
                     </td>
                   </tr>

                   <tr>
                    <td style="font-size: 14px; color: #666666; padding: 15px 15px">
                      <p style="margin: 0px;">To visit your page, please click the button or follow the link below. If you have
                        any further enquiries, you can contact us through the Functions & Catering 
                        website.</p>
                      </td>
                    </tr>


                    <tr>
                      <td style="padding:15px 15px">
                        <a href="' . $url . '" style="height: 35px; border-radius:4px; text-align: center; line-height: 35px; width: 230px; vertical-align: middle; background: #0099cc; display: inline-block; font-size: 20px; color: #fff; text-decoration: none;">Visit My Page</a>
                      </td>
                    </tr>
                    <tr>
                      <td  style="font-size: 14px; color: #666666; padding:15px 15px">
                        <p style="margin: 0px;">Or click the following link:</p>
                        <a href="' . $url . '" style="color: #3399cc">' . $url . '</a>
                      </td>
                    </tr>
                    <tr>
                      <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                        <p style="margin-bottom: 0px;">Thanks</p>
                        <p style="margin-top: 0px;">from the Functions & Catering Team</p>
                      </td>
                    </tr>
                    <tr>
                      <td style="padding: 0px 15px">
                        <p style="margin: 0px; height: 1px; border-top:1px solid #0099cc; width: 80%; "></p>
                      </td>
                    </tr>
                    <tr>
                      <td style="font-size: 14px; color: #666666; vertical-align: middle; padding: 7px 15px;">
                        <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px;"><img src="' . $logo_url_second . '"></p>
                        <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px; padding-left: 15px"> &copy; ' . $year . ' Functions and Catering Australia Pty. Ltd.</p>
                      </td>
                    </tr>
                  </table>
                  <table>
                    <tr>
                      <td style="font-size: 12px; color: #666666; padding:15px 15px 0px;">
                        <p style="margin: 0px;">If you have recieved this message in error or have not registered for a Functions & Catering account, <a href="' . $contact_link . '" style="color: #3399cc">Click here</a></p>
                        <p style="margin: 0px;">or simply just ignore this email.</p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>

            </tbody>

          </table>
        </td>
      </tr>
    </table>

  </body>
  </html>';
    $output = send_mail($email, $subject, $msg);
    return $output;
}

function contact_us_mail($contact_data) {
    $obj = & get_instance();
    $subject = APPLICATION_NAME . ' contact us';
    $email = 'Info@functionsandcatering.com';
    $logo_url = base_url() . 'assets/images/logo_fnc.png';
    $logo_url_second = base_url() . 'assets/images/footer_logo.png';
    $year = date('Y');
    $contact_link = base_url("web/contact_us");
    $url = base_url("web/contact_us");

    $business_name = '';
    if ($contact_data["contact_business_name"]) {
        $business_name = '' . $contact_data["contact_business_name"] . ' <br>';
    }

    $msg = '<!DOCTYPE html>
  <html>
  <head>
    <title>TODO supply a title</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body style="padding: 0; margin: 0px;">

    <table align="center">
      <tr>
        <td align="center">
          <table width="700px" cellpadding="0" cellspacing="0" style="font-family: sans-serif;">
            <thead  bgcolor="#3399cc">
              <tr>
                <th width="100%"  style="padding:60px 0px"><img src="' . $logo_url . '" width="280px" /></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td bgcolor="#cccccc" style="padding: 15px;">
                  <table bgcolor="#fff" width="100%">
                    <tr><td style="font-size: 20px; color: #3399cc; text-align: center; padding: 15px;">Your Contact Us Details</td></tr>
                    <tr>
                      <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                      </td>
                    </tr>

                    <tr>
                      <td style="padding: 20px 15px">
                        <table>
                          <tr>
                            <td width="80px"></td>
                            <td style="border-left: 7px solid #3399cc; padding-left: 10px; font-size: 14px; color: #666666">
                             <p style="margin:0px 0px 10px; line-height: 15px;"><span style="color:#3399cc;">Contact name:</span>' . ucfirst($contact_data["contact_name"]) . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Contact Email: </span>' . $contact_data["contact_email"] . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Contact address: </span>' . $contact_data["contact_city"] . ' ' . $contact_data["contact_state"] . ' ' . $contact_data["contact_postal_code"] . '</p>
                             <p style="margin:0px 0px 10px; line-height: 15px;"><span style="color:#3399cc;">Business name:</span>' . $contact_data["contact_name"] . '</p>
                             <p style="margin:0px 0px 10px; line-height: 15px;"><span style="color:#3399cc;">Message:</span>' . $contact_data['contact_message'] . '</p>

                           </td>
                         </tr>
                       </table>
                     </td>
                   </tr>
                   <tr>
                    <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                      <p style="margin-bottom: 0px;">Thanks</p>
                      <p style="margin-top: 0px;">from the Functions & Catering Team</p>
                    </td>
                  </tr>
                  <tr>
                    <td style="padding: 0px 15px">
                      <p style="margin: 0px; height: 1px; border-top:1px solid #0099cc; width: 80%; "></p>
                    </td>
                  </tr>
                  <tr>
                    <td style="font-size: 14px; color: #666666; vertical-align: middle; padding: 7px 15px;">
                      <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px;"><img src="' . $logo_url_second . '"></p>
                      <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px; padding-left: 15px"> &copy; ' . $year . ' Functions and Catering Australia Pty. Ltd.</p>
                    </td>
                  </tr>
                </table>
                <table>
                  <tr>
                    <td style="font-size: 12px; color: #666666; padding:15px 15px 0px;">
                      <p style="margin: 0px;">If you have recieved this message in error or have not registered for a Functions & Catering account, <a href="' . $contact_link . '" style="color: #3399cc">Click here</a></p>
                      <p style="margin: 0px;">or simply just ignore this email.</p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

          </tbody>

        </table>
      </td>
    </tr>
  </table>

</body>
</html>';
    $output = send_mail($email, $subject, $msg);
    return $output;
}

// its reve when user request for vneu and catering and approved by admin
function approved_bus_auth_mail($bus_auth_data, $cc_email_address = null) {

    $obj = & get_instance();
    $subject = 'Your request has been approved!';
    $name = $bus_auth_data['name'];
    $email = $bus_auth_data['email'];
    $logo_url = base_url() . 'assets/images/logo_fnc.png';
    $logo_url_second = base_url() . 'assets/images/footer_logo.png';
    $year = date('Y');
    $contact_link = base_url("web/contact_us");
    $new_date = $bus_auth_data['bus_auth_create_time'];
    $req_date = date("d-m-Y", strtotime($new_date));
    $url = $bus_auth_data['url'];
    if ($bus_auth_data['fc_type'] == 'Venue') {
        $request = base_url("my_venues");
    } else if ($bus_auth_data['fc_type'] == 'Catering') {
        $request = base_url("my_catering");
    }
    $msg = '<!DOCTYPE html>
 <html>
 <head>
  <title>TODO supply a title</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="padding: 0; margin: 0px;">

  <table align="center">
    <tr>
      <td align="center">
        <table width="700px" cellpadding="0" cellspacing="0" style="font-family: sans-serif;">
          <thead  bgcolor="#3399cc">
            <tr>
              <th width="100%"  style="padding:60px 0px"><img src="' . $logo_url . '" width="280px" /></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td bgcolor="#cccccc" style="padding: 15px;">
                <table bgcolor="#fff" width="100%">
                  <tr><td style="font-size: 20px; color: #3399cc; text-align: center; padding: 15px;">Your request has been approved!</td></tr>
                  <tr>
                    <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                     <p> Dear ' . $name . ',</p>
                     <p style="margin-bottom: 0px">You have been added to the F&C platform as a <strong> ' . $bus_auth_data['fc_type'] . ' Supplier</strong>. You are now authorised to set up your ' . $bus_auth_data['fc_type'] . '/s which can be done in your F&C Dashboard. Click the button below to get started!</p>
                     </td>
                   </tr>

                   <tr>
                    <td style="padding: 20px 15px">
                      <table>
                        <tr>
                          <td width="80px"></td>
                          <td style="border-left: 7px solid #3399cc; padding-left: 10px; font-size: 14px; color: #666666">
                           <p style="margin:0px 0px 10px; line-height: 15px;"><span style="color:#3399cc;">Requested By:</span> ' . $name . '</p>
                           <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Date of Request: </span>' . $req_date . '</p>
                           <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Email ID:</span> ' . $email . '</p>

                         </td>
                         <td style="width:40%; text-align:right; padding-right:50px;">
                           <a href="' . $request . '" style=" height:35px;border-radius:4px;text-align:center;line-height:35px;width:230px;vertical-align:middle;background:#0099cc;display:inline-block;font-size:20px;color:#fff;text-decoration:none">Get Started</a>
                          </td>
                       </tr>
                     </table>

                   </td>

                 </tr>



                 
                 <tr>
                   <td style="font-size: 14px; color: #666666; padding: 0px 15px">

                    <p style="margin-bottom: 0px;">Thanks</p>

                    <p style="margin-top: 0px;">from the Functions & Catering Team</p>

                  </td>

                </tr>

                <tr>

                  <td style="padding: 0px 15px">

                    <p style="margin: 0px; height: 1px; border-top:1px solid #0099cc; width: 80%; "></p>

                  </td>

                </tr>

                <tr>

                  <td style="font-size: 14px; color: #666666; vertical-align: middle; padding: 7px 15px;">

                    <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px;"><img src="' . $logo_url_second . '"></p>

                    <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px; padding-left: 15px"> &copy; ' . $year . ' Functions and Catering Australia Pty. Ltd.</p>

                  </td>

                </tr>

              </table>

              <table>

                <tr>

                  <td style="font-size: 12px; color: #666666; padding:15px 15px 0px;">

                    <p style="margin: 0px;">If you have recieved this message in error or have not registered for a Functions & Catering account, <a href="' . $contact_link . '" style="color: #3399cc">Click here</a></p>

                    <p style="margin: 0px;">or simply just ignore this email.</p>

                  </td>

                </tr>

              </table>

            </td>

          </tr>

        </tbody>

      </table>
    </td>
  </tr>
</table>

</body>
</html>';
    $output = send_mail($email, $subject, $msg);
    return $output;
}

function forgot_password_mail($userdata, $cc_email_address = null) {
    $obj = & get_instance();
    $subject = 'F&C: Reset your password';
    $username = $userdata['user_firstname'] . ' ' . $userdata['user_lastname'];
    $url = base_url("/Login/reset_password/" . $userdata['user_id'] . '/' . $userdata['user_hash']);
    $logo_url = base_url() . 'assets/images/Functions_LogoFandC.png';

    $msg = '<table style="max-width:40%; min-width:280px; margin: 0px auto; border: 1px solid #cdcdcd; border-collapse:collapse; font-family:sans-serif;" cellpadding="0" cellspaceing="0">
  
  <tr style="float: left; width: 100%;" align="center">
    <td style="line-height: 20px; text-align: center; padding:15px 30px"><img style="width: 150px;" src="' . $logo_url . '"></td>
  </tr>

  <tr><td style="padding:15px 30px 0px; font-size:20px; font-weight:600; color:#443d3d;">Password reset information</td></tr>
  <tr><td style="padding:0px 30px 15px"><hr style="margin: 5px 0px; background: #00A63F; height: 2px; border: 0px; width: 127px;"></td></tr>
  <tr><td style="font-size:15px; font-weight:normal; padding:15px 30px; color:#443d3d;">Thanks for contacting us. Follow the directions below to reset your password.</td></tr>
  <tr><td style="padding:15px 30px; color:#fff;"><font style="padding:10px 15px; background:#1882d6; border-radius:2px; color:#fff;">
    <a  href="' . $url . '" style="text-decoration:none; color:#fff;">Reset Your Password</a></font></td></tr>
    <tr><td style="font-size:15px; font-weight:normal; padding:15px 30px 10px; color:#443d3d;">After you click the button above, you\'ll be prompted to complete the following steps: </td></tr>
    <tr>
      <td>
        <table style="font-size:15px; font-weight:normal; color:#443d3d; padding:0px 30px;">
          <tr><td>1. </td><td>Enter and confirm your new password.</td></tr>
          <tr><td>2. </td><td>Click "Submit"</td></tr>
        </table>
      </td>
    </tr>
    <tr><td style="font-size:15px; font-weight:normal; padding:15px 30px 10px; color:#443d3d;">
      If you didn\'t request a password reset or you feel you\'ve received this message in error, please call our 24/7 support team right away at 03 9088 900. If you take no action, don\'t worry — nobody will be able to change your password without access to this email. 
    </td></tr>
    <tr>


      <tr>
        <td width="100%" style="margin-bottom: 30px; float: left; width: 100%;">
        </td>
      </tr>
    </table>

    <table style="width: 41%; margin: 0px auto; padding: 20px;">
      <tr style="margin-bottom: 20px; font-size: 12px; float: left;  width: 100%;">
        <td style="line-height: 20px; width: 100%; text-align: center; display: block; color: #909090;">&copy; ' . date("Y") . ' Functions and Catering Australia Pty. Ltd.</td>
      </tr>
    </table>
    <style>
      a:hover, a:active{
        color:#fff !important;
        text-decoration:none !important;
      }
    </style>
    ';

    $output = send_mail($userdata['user_email'], $subject, $msg);

    return $output;
}

function advertise_mail($advertise_data) {
    $obj = & get_instance();
    $subject = APPLICATION_NAME . ' advertise ';
    $logo_url = base_url() . 'assets/images/logo_fnc.png';
    $email = 'Info@functionsandcatering.com';
    $logo_url_second = base_url() . 'assets/images/footer_logo.png';
    $year = date('Y');
    $contact_link = base_url("web/contact_us");
    $business_name = '';
    if ($advertise_data["business_name"]) {
        $business_name = 'business name:- ' . $advertise_data["business_name"] . ' <br>';
    }

    $msg = '<!DOCTYPE html>
    <html>
    <head>
      <title>TODO supply a title</title>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="padding: 0; margin: 0px;">

      <table align="center">
        <tr>
          <td align="center">
            <table width="700px" cellpadding="0" cellspacing="0" style="font-family: sans-serif;">
              <thead  bgcolor="#3399cc">
                <tr>
                  <th width="100%"  style="padding:60px 0px"><img src="' . $logo_url . '" width="280px" /></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td bgcolor="#cccccc" style="padding: 15px;">
                    <table bgcolor="#fff" width="100%">
                      <tr><td style="font-size: 20px; color: #3399cc; text-align: center; padding: 15px;">Advertisement !</td></tr>
                      <tr>
                        <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                         <p> Dear Admin,</p>
                         <p style="margin-bottom: 0px">Thanks for your patience.</p>
                       </td>
                     </tr>

                     <tr>
                      <td style="padding: 20px 15px">
                        <table>
                          <tr>
                            <td width="80px"></td>
                            <td style="border-left: 7px solid #3399cc; padding-left: 10px; font-size: 14px; color: #666666">
                             <p style="margin:0px 0px 10px; line-height: 15px;"><span style="color:#3399cc;">Advertise name:</span>' . $advertise_data["full_name"] . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Advertise Email: </span>' . $advertise_data["email_address"] . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;"> Advertise address:</span>' . $advertise_data["address"] . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;"> Advertise phone number:</span>' . $advertise_data["phone_number"] . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;"> Massage:</span>' . $advertise_data['message'] . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;"> Business name:</span>' . $advertise_data["business_name"] . '</p>

                           </td>
                         </tr>
                       </table>
                     </td>
                   </tr>
                   <tr>
                    <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                      <p style="margin-bottom: 0px;">Thanks</p>
                      <p style="margin-top: 0px;">from the Functions & Catering Team</p>
                    </td>
                  </tr>
                  <tr>
                    <td style="padding: 0px 15px">
                      <p style="margin: 0px; height: 1px; border-top:1px solid #0099cc; width: 80%; "></p>
                    </td>
                  </tr>
                  <tr>
                    <td style="font-size: 14px; color: #666666; vertical-align: middle; padding: 7px 15px;">
                      <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px;"><img src="' . $logo_url_second . '"></p>
                      <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px; padding-left: 15px"> &copy; ' . $year . ' Functions and Catering Australia Pty.Ltd.</p>
                    </td>
                  </tr>
                </table>
                <table>
                  <tr>
                    <td style="font-size: 12px; color: #666666; padding:15px 15px 0px;">
                      <p style="margin: 0px;">If you have recieved this message in error or have not registered for a Functions & Catering account, <a href="' . $contact_link . '" style="color: #3399cc">Click here</a></p>
                      <p style="margin: 0px;">or simply just ignore this email.</p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
  </table>

</body>
</html>';
    $output = send_mail($email, $subject, $msg);
    return $output;
}

function send_to_friend_mail($send_to_friend, $cc_email_address = null) {
    $obj = & get_instance();
    $subject = APPLICATION_NAME . ' ';
    $username = $send_to_friend['friend_name'];
    $url = $send_to_friend['venue_url'];
    $logo_url = base_url() . 'assets/images/Functions_LogoFandC.png';

    $msg = '<table style="width: 41%; margin: 0px auto; padding: 20px; border: 1px solid #cdcdcd;">
  <tr style="margin-bottom: 20px; float: left; width: 100%;">
   <td style="line-height: 20px; text-align: center;"><img style="width:150px" width="120px" src="' . $logo_url . '"></td>
 </tr>
 <tr style="margin-bottom: 30px; float: left; width: 100%; border: 1px solid #cdcdcd;">
 </tr>
 <tr style="margin-bottom: 20px; float: left;  width: 100%;">
   <td style="line-height: 20px; font-size: 13px;"><span style="font-weight: 600;">Hey - </span>' . $username . ' 
   </td>
 </tr>
 <tr style="margin-bottom: 20px; float: left;  width: 100%;">
   <td style="line-height: 20px; font-size: 13px;">' . $send_to_friend['massage'] . ' <a href="' . $url . '">Click Here </a></td>
 </tr>

</table>
<table style="width: 41%; margin: 0px auto; padding: 20px;">
  <tr style="margin-bottom: 20px; font-size: 12px; float: left;  width: 100%;">
   <td style="line-height: 20px; width: 100%; text-align: center; display: block; color: #909090;">&copy; ' . date("Y") . '  Functions and Catering Australia Pty. Ltd.</td>
 </tr>
</table>';
    $output = send_mail($send_to_friend['email'], $subject, $msg);
    return $output;
}

function send_account_details_invoice($pdf_name) {
    $obj = & get_instance();
    $obj->load->library('email');

    $obj->email->attach('assets/pdf/' . $pdf_name);  /* Enables you to send an attachment */

    $subject = 'Fnc bank details';
    $to_email = $obj->session->userdata('user_email');
    $body = 'Fnc bank details';
    send_mail($to_email, $subject, $body, $cc_email_address = null);
}

function customer_confirmation_mail($userdata, $cc_email_address = null) {
    $obj = & get_instance();
    $subject = APPLICATION_NAME . ' Confirmation Mail';
    $username = $userdata['user_firstname'] . ' ' . $userdata['user_lastname'];
    $url = base_url("/Login/verifyaccount/" . $userdata['user_id'] . '/' . $userdata['user_hash']);
    $logo_url = base_url() . 'assets/images/logo_fnc.png';
    $logo_url_second = base_url() . 'assets/images/footer_logo.png';
    $click_url = base_url('login/user_login');
    $year = date('Y');
    $contact_link = base_url("web/contact_us");

    $msg = '<!DOCTYPE html>
  <html>
  <head>
    <title>TODO supply a title</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body style="padding: 0; margin: 0px;">

    <table align="center">
      <tr>
        <td align="center">
          <table width="700px" cellpadding="0" cellspacing="0" style="font-family: sans-serif;">
            <thead  bgcolor="#3399cc">
              <tr>
                <th width="100%"  style="padding:60px 0px"><img src="' . $logo_url . '" width="280px" /></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td bgcolor="#cccccc" style="padding: 15px;">
                  <table bgcolor="#fff" width="100%">
                    <tr><td style="font-size: 20px; color: #3399cc; text-align: center; padding:15px">Activate Your Account </td></tr>
                    <tr>
                      <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                       <p> Dear ' . $userdata['user_firstname'] . ',</p>
                       <p>Thanks for signing up to Functions & Catering.</p>
                       <p>To help us make sure your account is created correctly, simply click the button below to confirm your email address.</p>
                     </td>
                   </tr>
                   <tr>
                    <td style="padding:15px 15px">
                      <a href=' . $url . ' style="height: 35px; border-radius:4px; text-align: center; line-height: 35px; width: 230px; vertical-align: middle; background: #0099cc; display: inline-block; font-size: 20px; color: #fff; text-decoration: none;">Confirm Email</a>
                    </td>
                  </tr>
                  <tr>
                    <td  style="font-size: 14px; color: #666666; padding:15px 15px">
                      <p style="margin: 0px;">Or click the following link:</p>
                      <a href=' . $url . ' style="color: #3399cc">' . $url . '</a>
                    </td>
                  </tr>
                  <tr>
                    <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                      <p style="margin-bottom: 0px;">Thanks</p>
                      <p style="margin-top: 0px;">from the Functions & Catering Team</p>
                    </td>
                  </tr>
                  <tr>
                    <td style="padding: 0px 15px">
                      <p style="margin: 0px; height: 1px; border-top:1px solid #0099cc; width: 80%; "></p>
                    </td>
                  </tr>
                  <tr>
                    <td style="font-size: 14px; color: #666666; vertical-align: middle; padding: 7px 15px;">
                      <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px;"><img src="' . $logo_url_second . '"></p>
                      <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px; padding-left: 15px"> &copy; ' . $year . ' Functions and Catering Australia Pty. Ltd.</p>
                    </td>
                  </tr>
                </table>
                <table>
                 <tr>
                  <td style="font-size: 12px; color: #666666; padding:15px 15px 0px;">
                    <p style="margin: 0px;">If you have recieved this message in error or have not registered for a Functions & Catering account, <a href="' . $contact_link . '" style="color: #3399cc">Click here</a></p>
                    <p style="margin: 0px;">or simply just ignore this email.</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

        </tbody>

      </table>
    </td>
  </tr>
</table>

</body>
</html>';


    $output = send_mail($userdata['user_email'], $subject, $msg);
    return $output;
}

// function random_password($user_email,$cc_email_address = null){
//   $obj = & get_instance();
//   $subject= APPLICATION_NAME. 'Password';
//   $logo_url =  base_url(). 'assets/images/logo_fnc.png';
//   $logo_url_second = base_url(). 'assets/images/footer_logo.png';
//   $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
//   $password = array(); 
//   $alpha_length = strlen($alphabet) - 1; 
//   for ($i = 0; $i < 8; $i++) 
//   {
//     $n = rand(0, $alpha_length);
//     $password[] = $alphabet[$n];
//   }
//   $comp_pw = implode($password); 
//   if(!empty($comp_pw)){
//     $obj->load->model("basic_model");
//     $data = array('user_password' => md5($comp_pw));
//     $where = array('user_id' => $userdata['user_id']);
//     $my_data = $obj->basic_model->update_records('users', $data, $where);
//   }
//   $msg = '<!DOCTYPE html>
//   <html>
//   <head>
//     <title>TODO supply a title</title>
//     <meta charset="UTF-8">
//     <meta name="viewport" content="width=device-width, initial-scale=1.0">
//   </head>
//   <body style="padding: 0; margin: 0px;">
//     <table align="center">
//       <tr>
//         <td align="center">
//           <table width="700px" cellpadding="0" cellspacing="0" style="font-family: sans-serif;">
//             <thead  bgcolor="#3399cc">
//               <tr>
//                 <th width="100%"  style="padding:60px 0px"><img src="'.$logo_url.'" width="280px" /></th>
//               </tr>
//             </thead>
//             <tbody>
//               <tr>
//                 <td bgcolor="#cccccc" style="padding: 15px;">
//                   <table bgcolor="#fff" width="100%">
//                     <tr><td style="font-size: 20px; color: #3399cc; text-align: center; padding: 15px;">Your Password has been created!</td></tr>
//                     <tr>
//                       <td style="padding: 20px 15px">
//                         <table>
//                           <tr>
//                             <td width="80px"></td>
//                             <td style="border-left: 7px solid #3399cc; padding-left: 10px; font-size: 14px; color: #666666">
//                              <p style="margin:0px 0px 10px; line-height: 15px;"><span style="color:#3399cc;">Password :</span>'.$comp_pw.'</p>
//                             </td>
//                          </tr>
//                         </table>
//                      </td>
//                     </tr>
//                     <tr>
//                     <td style="font-size: 14px; color: #666666; padding: 15px 15px">
//                       <p style="margin: 0px;">To visit your page, please click the button or follow the link below. If you have
//                         any further enquiries, you can contact us through the Functions & Catering 
//                         website.</p>
//                       </td>
//                     </tr>
//                     <tr>
//                       <td style="padding:15px 15px">
//                         <a href="'.$url.'" style="height: 35px; border-radius:4px; text-align: center; line-height: 35px; width: 230px; vertical-align: middle; background: #0099cc; display: inline-block; font-size: 20px; color: #fff; text-decoration: none;">Visit My Page</a>
//                       </td>
//                     </tr>
//                     <tr>
//                       <td  style="font-size: 14px; color: #666666; padding:15px 15px">
//                         <p style="margin: 0px;">Or click the folowing link:</p>
//                         <a href="'.$url.'" style="color: #3399cc">'.$url.'</a>
//                       </td>
//                     </tr>
//                     <tr>
//                       <td style="font-size: 14px; color: #666666; padding: 0px 15px">
//                         <p style="margin-bottom: 0px;">Thanks</p>
//                         <p style="margin-top: 0px;">from the Functions & Catering Team</p>
//                       </td>
//                     </tr>
//                     <tr>
//                       <td style="padding: 0px 15px">
//                         <p style="margin: 0px; height: 1px; border-top:1px solid #0099cc; width: 80%; "></p>
//                       </td>
//                     </tr>
//                     <tr>
//                       <td style="font-size: 14px; color: #666666; vertical-align: middle; padding: 7px 15px;">
//                         <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px;"><img src="'.$logo_url_second.'"></p>
//                         <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px; padding-left: 15px"> &copy; '.$year.' Functions and Catering Australia Pty.Ltd.</p>
//                       </td>
//                     </tr>
//                   </table>
//                   <table>
//                     <tr>
//                       <td style="font-size: 12px; color: #666666; padding:15px 15px 0px;">
//                         <p style="margin: 0px;">If you have recieved this message in error or have not registered for a Functions & Catering account, <a href="'.$contact_link.'" style="color: #3399cc">Click here</a></p>
//                         <p style="margin: 0px;">or simply just ignore this email.</p>
//                       </td>
//                     </tr>
//                   </table>
//                 </td>
//               </tr>
//             </tbody>
//           </table>
//         </td>
//       </tr>
//     </table>
//   </body>
//   </html>';
//     // echo $comp_pw;
//   $output = send_mail($user_email,$subject,$msg);
//   return $output;
// }

function random_password($user_email, $cc_email_address = null) {
    $obj = & get_instance();
    $subject = APPLICATION_NAME . ' Password';
    $logo_url = base_url() . 'assets/images/logo_fnc.png';
    $logo_url_second = base_url() . 'assets/images/Functions_LogoFandC.png';
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $password = array();
    $alpha_length = strlen($alphabet) - 1;
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alpha_length);
        $password[] = $alphabet[$n];
    }
    $comp_pw = implode($password);
    if (!empty($comp_pw)) {
        $obj->load->model("basic_model");
        $data = array('user_password' => md5($comp_pw));
        $where = array('user_email' => $user_email);
        $my_data = $obj->basic_model->update_records('users', $data, $where);
    }

    $msg = '<html>
  <head>
    <title>Title of the document</title>
  </head>

  <body style="padding: 0px; margin: 0px; font-family: sans-serif;">
    <h2 style="background-color: #26abe3;padding: 50px;text-align: center;"><img width="250px" src="' . $logo_url . '"></h2>
    <div style="width: 90%; background-color: #e5e6e8; border-radius: 4px;margin: 0px auto; padding: 15px;">
      <p>Thanks for signing to Function & Catering.</p>
      <p>To help us make sure your account is created correctly, here you get your password <a style="height:35px;border-radius:4px;text-align:center;line-height:35px;width:auto;vertical-align:middle;background:#0099cc;display:inline-block;font-size:20px;color:#fff;text-decoration:none">' . $comp_pw . '</a> please login by this password after activation of account by earlier mail.</p>

      <p style="margin-top: 30px; margin-bottom: 10px;"><span>Thanks,</span></p>
      <p style="margin-top: 0px;"><span>From the Function & Catering Team ' . $logo_url_second . '</span></p>

      <hr style="width: 37%; color: #66aed4;margin-right: 95%;">
      <p><img width ="150px" src="' . $logo_url_second . '"></p>
    </div>
  </body>

  </html> ';



    // echo $comp_pw;
    $output = send_mail($user_email, $subject, $msg);
    return $output;
}

function create_venue_catering_mail($fc_data, $cc_email_address = null) {

    if ($fc_data["type"] == 1) {
        $type = 'Venue  ';
        $url = site_url('view_venue/') . encrypt_decrypt('encrypt', $fc_data['fc_id']);
        $preview = base_url('Web/vanue_preview/') . encrypt_decrypt('encrypt', $fc_data['fc_id']);
    }
    if ($fc_data["type"] == 2) {
        $type = 'Catering  ';
        $url = site_url('view_catering/') . encrypt_decrypt('encrypt', $fc_data['fc_id']);
        $preview = base_url('Web/catering_preview/') . encrypt_decrypt('encrypt', $fc_data['fc_id']);
    }

    $approve = base_url('Web/request_approve_deny/?fc=') . encrypt_decrypt('encrypt', $fc_data['fc_id']) . '&st=' . '1&sm=' . '1';
    $deny = base_url('Web/request_approve_deny/?fc=') . encrypt_decrypt('encrypt', $fc_data['fc_id']) . '&st=' . '2&sm=' . '0';

    $obj = & get_instance();
    $subject = 'Approval request for admin';
    $name = $fc_data['name'];
    $email = $cc_email_address;
    $email_cc = ADMIN_EMAIL_CC;
    $contact_no = $fc_data['contact_no'];
    $logo_url = base_url() . 'assets/images/logo_fnc.png';
    $logo_url_second = base_url() . 'assets/images/footer_logo.png';
    //$url = $fc_data['url'];
    $year = date('Y');
    $contact_link = base_url("web/contact_us");
    $new_date = $fc_data['requested_date'];
    $req_date = date("d-m-Y", strtotime($new_date));

    $msg = '<!DOCTYPE html>
  <html>
  <head>
    <title>TODO supply a title</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body style="padding: 0; margin: 0px;">

    <table align="center">
      <tr>
        <td align="center">
          <table width="700px" cellpadding="0" cellspacing="0" style="font-family: sans-serif;">
            <thead  bgcolor="#3399cc">
              <tr>
                <th width="100%"  style="padding:60px 0px"><img src="' . $logo_url . '" width="280px" /></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td bgcolor="#cccccc" style="padding: 15px;">
                  <table bgcolor="#fff" width="100%">
                    <tr><td style="font-size: 20px; color: #3399cc; text-align: center; padding: 15px;">' . $subject . '</td></tr>
                    <tr>
                      <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                        <p> Dear Admin,</p>
                        <p style="margin-bottom: 0px"></p>
                       </td>
                     </tr>

                     <tr>
                      <td style="padding: 20px 15px">
                        <table>
                          <tr>
                            <td width="80px"></td>
                            <td style="border-left: 7px solid #3399cc; padding-left: 10px; font-size: 14px; color: #666666">
                             <p style="margin:0px 0px 10px; line-height: 15px;"><span style="color:#3399cc;">Requested By: </span>' . ucfirst($fc_data['contact_name']) . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Date of Request: </span>' . $req_date . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Buisiness Name: </span>' . ucfirst($fc_data['business_name']) . '</p>
                             <p style="margin:10px 0px; line-height: 15px;"><span style="color:#3399cc;">Email ID: </span>' . $fc_data['contact_email'] . '</p>
                             <p style="margin:10px 0px 0px; line-height: 15px;"><span style="color:#3399cc;">Contact: </span>' . $contact_no . '</p>
                           </td>
                         </tr>
                       </table>
                     </td>
                   </tr>

                   <tr>
                    <td style="font-size: 14px; color: #666666; padding: 15px 15px">
                      <p style="margin: 0px;">Please click the button or follow the link below. If you have
                        any further enquiries, you can contact us through the Functions & Catering 
                        website.</p>
                      </td>
                    </tr>


                    <tr>
                      <td style="padding:15px 15px">
                        <a href="' . $preview . '" class="btn btn-danger Approve-put" style="height: 35px; border-radius:4px; text-align: center; line-height: 35px; width: 130px; vertical-align: middle; background: #0099cc; display: inline-block; font-size: 20px; color: #fff; text-decoration: none;"><i class="fa fa-thumbs-down" aria-hidden="true"></i>Preview</a> 
                        <a href="' . $approve . '" class="btn btn-danger Approve-put" style="height: 35px; border-radius:4px; text-align: center; line-height: 35px; width: 130px; vertical-align: middle; background: #0099cc; display: inline-block; font-size: 20px; color: #fff; text-decoration: none;"><i class="fa fa-thumbs-up" aria-hidden="true"></i>Approve</a>
                        <a href="' . $deny . '" class="btn btn-danger Approve-put" style="height: 35px; border-radius:4px; text-align: center; line-height: 35px; width: 130px; vertical-align: middle; background: #0099cc; display: inline-block; font-size: 20px; color: #fff; text-decoration: none;"><i class="fa fa-thumbs-down" aria-hidden="true"></i>Deny</a>    
                      </td>
                    </tr>
                    <tr>
                      <td style="font-size: 14px; color: #666666; padding: 0px 15px">
                        <p style="margin-bottom: 0px;">Thanks</p>
                        <p style="margin-top: 0px;">from the Functions & Catering Team</p>
                      </td>
                    </tr>
                    <tr>
                      <td style="padding: 0px 15px">
                        <p style="margin: 0px; height: 1px; border-top:1px solid #0099cc; width: 80%; "></p>
                      </td>
                    </tr>
                    <tr>
                      <td style="font-size: 14px; color: #666666; vertical-align: middle; padding: 7px 15px;">
                        <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px;"><img src="' . $logo_url_second . '"></p>
                        <p style="display: inline-block;vertical-align: middle; width: auto; margin: 0px; padding-left: 15px"> &copy; ' . $year . ' Functions and Catering Australia Pty. Ltd.</p>
                      </td>
                    </tr>
                  </table>
                  <table>
                    <tr>
                      <td style="font-size: 12px; color: #666666; padding:15px 15px 0px;">
                        <p style="margin: 0px;">If you have recieved this message in error or have not registered for a Functions & Catering account, <a href="' . $contact_link . '" style="color: #3399cc">Click here</a></p>
                        <p style="margin: 0px;">or simply just ignore this email.</p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>

            </tbody>

          </table>
        </td>
      </tr>
    </table>

  </body>
  </html>';
//    echo $msg;
//    die;
//    $pdf_name = vanue_catering_preview($fc_data['fc_id']);
//    $obj->email->attach('assets/pdf/' . $pdf_name);
    $output = send_mail($email, $subject, $msg, $email_cc);
    return $output;
}
