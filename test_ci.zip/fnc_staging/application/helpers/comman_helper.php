<?php

function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    $key = hash('sha256', $secret_key);
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ($action == 'encrypt') {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if ($action == 'decrypt') {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

function user_lat_long() {
    $ip = $_SERVER['REMOTE_ADDR'];
    $query = @unserialize(file_get_contents('http://ip-api.com/php/' . $ip));
    if ($query && $query['status'] == 'success') {
        return array('lat' => $query['lat'], 'long' => $query['lon']);
    }
}

function review_count($venue_id) {
    $ci = & get_instance();
    $column = array('f_text', 'f_rating_overall', 'f_rating_cleanliness', 'f_rating_accuracy', 'f_rating_comm');
    $where = array('f_status' => 1, 'f_fc_id' => $venue_id);
    $rows = $ci->basic_model->get_record_where_orderby('feedback', $column, $where, $orderby = '', $direction = 'DESC');

    if (!empty($rows)) {
        $sum = 0;
        $count = count($rows);
        foreach ($rows as $review) {
            $sum = (int) $review->f_rating_overall + (int) $review->f_rating_cleanliness + (int) $review->f_rating_accuracy + (int) $review->f_rating_comm;
        }
        //echo $sum;
        $avg = $sum / 4;
        if ($avg == 0) {
            echo "<ul><li></li><li></li><li></li><li></li><li></li></ul><span class='no-reviews'>$count Reviews</span>";
        } else if (($avg >= 0.1) && ($avg <= 0.5)) {
            echo "<ul><li class='half_star'></li><li></li><li></li><li></li></ul><span class='no-reviews'>$count Reviews</span>";
        } else if (($avg > 0.5) && ($avg <= 1)) {
            echo "<ul><li class='full_star'></li><li></li><li></li><li></li></ul><span class='no-reviews'>$count Reviews</span>";
        } else if (($avg > 1) && ($avg <= 1.5)) {
            echo "<ul><li class='full_star'></li><li class='half_star'></li><li></li><li></li><li></li></ul><span class='no-reviews'>$count Reviews</span>";
        } else if (($avg > 1.5) && ($avg <= 2)) {
            echo "<ul><li class='full_star'></li><li class='full_star'></li><li></li><li></li><li></li></ul><span class='no-reviews'>$count Reviews</span>";
        } else if (($avg > 2) && ($avg <= 2.5)) {
            echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='half_star'></li><li></li><li></li></ul><span class='no-reviews'>$count Reviews</span>";
        } else if (($avg > 2.5) && ($avg <= 3)) {
            echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li></li><li></li></ul><span class='no-reviews'>$count Reviews</span>";
        } else if (($avg > 3) && ($avg <= 3.5)) {
            echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='half_star'></li><li></li></ul><span class='no-reviews'>$count Reviews</span>";
        } else if (($avg > 3.5) && ($avg <= 4)) {
            echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li></li></ul><span class='no-reviews'>$count Reviews</span>";
        } else if (($avg > 4) && ($avg <= 4.5)) {
            echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='half_star'></li></ul><span class='no-reviews'>$count Reviews</span>";
        } else if (($avg > 4.5) && ($avg <= 5)) {
            echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li></ul><span class='no-reviews'>$count Reviews</span>";
        }
    } else {
        echo "<ul><li></li><li></li><li></li><li></li><li></li></ul><span class='no-reviews'>No reviews yet</span>";
    }
}

function avg_review_count_venue($venue_id) {
    $ci = & get_instance();
    if (!empty($venue_id)) {
        $ci->db->select('re.f_id,re.f_text,re.f_rating_overall,re.f_rating_cleanliness,re.f_rating_accuracy,re.f_rating_comm,re.f_user');
        $ci->db->from('feedback as re');
        $ci->db->where('re.f_fc_id', $venue_id);
        $ci->db->where('re.f_status', 1);
        $query = $ci->db->get();
        if ($query->num_rows() > 0)
            return $query->result();
        else
            return FALSE;
    }
}

function generate_review_html($avg) {
    if ($avg == 0) {
        echo "<ul><li></li><li></li><li></li><li></li><li></li></ul>";
    } else if (($avg >= 0.1) && ($avg <= 0.5)) {
        echo "<ul><li class='half_star'></li><li></li><li></li><li></li></ul>";
    } else if (($avg > 0.5) && ($avg <= 1)) {
        echo "<ul><li class='full_star'></li><li></li><li></li><li></li></ul>";
    } else if (($avg > 1) && ($avg <= 1.5)) {
        echo "<ul><li class='full_star'></li><li class='half_star'></li><li></li><li></li><li></li></ul>";
    } else if (($avg > 1.5) && ($avg <= 2)) {
        echo "<ul><li class='full_star'></li><li class='full_star'></li><li></li><li></li><li></li></ul>";
    } else if (($avg > 2) && ($avg <= 2.5)) {
        echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='half_star'></li><li></li><li></li></ul>";
    } else if (($avg > 2.5) && ($avg <= 3)) {
        echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li></li><li></li></ul>";
    } else if (($avg > 3) && ($avg <= 3.5)) {
        echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='half_star'></li><li></li></ul>";
    } else if (($avg > 3.5) && ($avg <= 4)) {
        echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li></li></ul>";
    } else if (($avg > 4) && ($avg <= 4.5)) {
        echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='half_star'></li></ul>";
    } else if (($avg > 4.5) && ($avg <= 5)) {
        echo "<ul><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li><li class='full_star'></li></ul>";
    }
}

function home_page_data() {
    $user_wishlist = array();
    $ci = & get_instance();
    if ($ci->session->userdata('user_id')) {
        $user_id = $ci->session->userdata('user_id');
        $ci->db->select('w_venue');
        $ci->db->from('wish_list');
        $ci->db->where('w_user', $user_id);
        $query = $ci->db->get();
        if ($query->num_rows() > 0) {
            $wish_list = $query->result();
            foreach ($wish_list as $key => $list) {
                $user_wishlist[$key] = $list->w_venue;
            }
            return $user_wishlist;
        } else
            return FALSE;
    }else {
        
    }
}

function cheak_wishlist($wishlist_ary, $venue_cater_id, $key = 0) {
    $wishlist = array();
    if (!empty($wishlist_ary)) {
        if (in_array($venue_cater_id, $wishlist_ary)) {
            $wishlist['img'] = "<img class='like_103 change_" . $key . "'  usemap='#planetmap_" . $key . "' src='" . base_url() . "assets/images/icon_19.png'>";
            $wishlist['title'] = 'Favorites added';
        } else {
            $wishlist['img'] = "<img class='like_103 change_" . $key . "' usemap='#planetmap_" . $key . "' src='" . base_url() . "assets/images/5.Heart-for-add-to-favourites-new.svg'>";
            $wishlist['title'] = 'Add to Favorites';
        }
    } else {
        $wishlist['img'] = "<img class='like_103 change_" . $key . "' usemap='#planetmap_" . $key . "' src='" . base_url() . "assets/images/5.Heart-for-add-to-favourites-new.svg'>";
        $wishlist['title'] = 'Add to Favorites';
    }
    return $wishlist;
}

function show_wishlist_icon($wishlist_ary, $venue_cater_id, $key = 0) {
    if (!empty($wishlist_ary)) {
        if (in_array($venue_cater_id, $wishlist_ary)) {
            echo $img = "<img class='like_103 change_" . $key . "'  usemap='#planetmap_" . $key . "' src='http://onesheepventures.com/staging/functions/assets/images/Add-to-wish-list_white.png'>";
        } else {
            echo $img = "";
        }
    } else {
        echo $img = "";
    }
}

function get_fc_type($fc_id) {
    $ci = & get_instance();
    if ($fc_id) {
        $ci->db->select('fc_type');
        $ci->db->from('function_catering');
        $ci->db->where('fc_id', $fc_id);
        $query = $ci->db->get();
        $type = $query->result();
        return $type[0]->fc_type;
    }
}

function inWord($number) {
    $no = round($number);
    $point = round($number - $no, 2) * 100;
    $hundred = null;
    $digits_1 = strlen($no);
    $i = 0;
    $str = array();
    $words = array('0' => '', '1' => 'one', '2' => 'two',
        '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
        '7' => 'seven', '8' => 'eight', '9' => 'nine',
        '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
        '13' => 'thirteen', '14' => 'fourteen',
        '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
        '18' => 'eighteen', '19' => 'nineteen', '20' => 'twenty',
        '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
        '60' => 'sixty', '70' => 'seventy',
        '80' => 'eighty', '90' => 'ninety');
    $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
    while ($i < $digits_1) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += ($divider == 10) ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number] .
                    " " . $digits[$counter] . $plural . " " . $hundred :
                    $words[floor($number / 10) * 10]
                    . " " . $words[$number % 10] . " "
                    . $digits[$counter] . $plural . " " . $hundred;
        } else
            $str[] = null;
    }
    $str = array_reverse($str);
    $result = implode('', $str);
    $points = ($point) ?
            "." . $words[$point / 10] . " " .
            $words[$point = $point % 10] : '';
    return $result;
}

function venue_permission() {
    $CI = & get_instance();
    $user_id = $CI->session->userdata('user_id');

    $CI->db->select('bus_auth_req,bus_auth_status,bus_is_deleted');
    $CI->db->from('businesses_authorized');
    $CI->db->where(array('user_id' => $user_id, 'bus_auth_req' => 1));
    $query = $CI->db->get();
    $row_count = $query->num_rows();
    if ($row_count > 0) {
        $auth_data = $query->row();
    } else {
        $auth_data = array();
    }
    return $auth_data;
}

function user_permission() {
    $CI = & get_instance();
    $user_id = $CI->session->userdata('user_id');
    $CI->db->select('user_type');
    $CI->db->from('users');
    $CI->db->where(array('user_id' => $user_id));
    $query = $CI->db->get();
    $row_count = $query->num_rows();
    if ($row_count > 0) {
        $auth_data = $query->row();
    } else {
        $auth_data = array();
    }
    // echo '<pre>';
    // print_r($auth_data);
}

function user_regis_permission() {
    $CI = & get_instance();
    $user_id = $CI->session->userdata('user_id');
    $CI->db->select('is_registration');
    $CI->db->from('users');
    $CI->db->where(array('user_id' => $user_id));
    $query = $CI->db->get();
    $row_count = $query->num_rows();
    if ($row_count > 0) {
        $auth_data = $query->row();
    } else {
        $auth_data = array();
    }
    // echo '<pre>';
    // print_r($auth_data);
}

function cater_permission() {
    $CI = & get_instance();
    $user_id = $CI->session->userdata('user_id');

    $CI->db->select('bus_auth_req,bus_auth_status,bus_is_deleted');
    $CI->db->from('businesses_authorized');
    $CI->db->where(array('user_id' => $user_id, 'bus_auth_req' => 2));
    $query = $CI->db->get();
    $row_count = $query->num_rows();
    if ($row_count > 0) {
        $auth_data = $query->row();
    } else {
        $auth_data = array();
    }
    return $auth_data;
}

function expireFormted($date) {
    $date = date('d M Y', strtotime($date));
    return $date;
}

function get_client_ip() {
    $return = false;
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if (getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if (getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if (getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if (getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if (getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';

    if ($ipaddress != 'UNKNOWN') {
        $query = @unserialize(file_get_contents('http://ip-api.com/php/' . $ipaddress));
        if ($query && $query['status'] == 'success') {

            $return = array('city' => $query['city'], 'state' => $query['region'], 'zip' => $query['zip'], 'lat' => $query['lat'], 'long' =>
                $query['lon']);
        }
    }
    return $return;
}

function expire_massage($fc_valid_upto) {
    if (!empty($fc_valid_upto)) {
        $valid_date = $fc_valid_upto;
        if (strtotime($valid_date) > strtotime(date('Y-m-d'))) {
            $massage = '';
        } elseif (strtotime($valid_date) == strtotime(date('Y-m-d'))) {
            $massage = '';
        } else {
            $massage = 'Plan expired on ' . expireFormted($valid_date) . ' please update plans';
        }
        return $massage;
    }
}

function creat_your_listing() {
    $CI = & get_instance();
    if (!$CI->session->userdata('user_id')) {
        $url = base_url('user_registration');
    } else {
        $venue_permission_ary = venue_permission();
        $cater_permission_ary = cater_permission();

        $venu_status = isset($venue_permission_ary->bus_auth_status) ? $venue_permission_ary->bus_auth_status : '';
        $cater_status = isset($cater_permission_ary->bus_auth_status) ? $cater_permission_ary->bus_auth_status : '';

        if ($venu_status == 1 && $cater_status == 1) {
            $url = base_url('add_venue');
        } else {
            $url = base_url('request');
        }
    }

    return $url;
}

function checkVoucherHelper($voucherParameter = false) {
    $CI = & get_instance();
    $CI->load->library('cart');

    $status = false;
    $error = false;
    $value = false;
//    $massage = false;
    $voucher_ammount = false;

    $user_id = $CI->session->userdata('user_id');
    if ($CI->input->post('voucher') || $voucherParameter) {
        if (!empty($voucherParameter)) {
            $voucher = $voucherParameter;
        } else {
            $voucher = $CI->input->post('voucher');
        }
        $voucher_id = 0;
        $result = $CI->basic_model->get_record_where('voucher', '', $where = array('voucher_code' => $voucher, 'voucher_status' => 1));
        if (!empty($result)) {
            $voucher_data = (array) $result[0];
            $todaySTR = strtotime(date('Y-m-d'));
            if ($voucher_data['voucher_code'] == $voucher) {
                if ((strtotime($voucher_data['start_date']) <= $todaySTR) && (strtotime($voucher_data['end_date']) >= $todaySTR)) {

                    if (((float)$voucher_data['total_redeemed_value'] + (float)$voucher_data['value']) <= ((float)$voucher_data['total_value'])) {

                        $uses_count = $CI->basic_model->get_record_where('voucher_logs', 'v_log_id', $where = array('voucher_id' => $voucher_data['id'], 'user_id' => $user_id));

                        if ($voucher_data['voucher_use'] > count($uses_count)) {
                            $status = true;
                            $voucher_ammount = $value = $voucher_data['value']; // heare value is voucher ammount
                            $total = $CI->cart->total();
                            if ($value > $total) {
                                $value = $total;

//                                $massage = 'The voucher that you are applying is of more value than your cart total. The remaining amount will be lapsed. Do you still want to continue?';
                            }
                            $voucher_id = $voucher_data['id'];
                            if (empty($voucherParameter)) {
                                $data = array(
                                    'id' => 'voucher_id',
                                    'qty' => 1,
                                    'price' => -$value,
                                    'name' => 'voucher',
                                );
                                $CI->cart->insert($data);
                            }
                        } else {
                            $error = 'You exceed limit to use this voucher';
                        }
                    } else {
                        $error = 'Invalid voucher code';
                    }
                } else {
                    $error = 'Your voucher expired';
                }
            } else {
                $error = 'Invalid voucher code';
            }
        } else {
            $error = 'Invalid voucher code';
        }
        $total = $CI->cart->total();
        if (empty($voucherParameter)) {
            echo json_encode(array('status' => $status, 'error' => $error, 'value' => $value, 'total' => $total));
        } else {

            $cart_contents = $CI->cart->contents();
            $redeemed_ammount = 0;
            if (!empty($cart_contents)) {
                foreach ($cart_contents as $val) {
                    if ($val['id'] == 'voucher_id') {
                        $redeemed_ammount = $val['price'];
                    }
                }
            }
            return array('status' => $status, 'error' => $error, 'voucher_value' => $voucher_ammount, 'redeemed_ammount' => $redeemed_ammount, 'voucher_id' => $voucher_id); // $value is redeemed ammount
        }
    } else {
        $total = $CI->cart->total();
        echo json_encode(array('status' => $status, 'error' => $error, 'total' => $total));
    }
}

function insert_voucher_log($user_id, $voucher_code, $voucher_value, $redeemed_ammount, $fc_id = false) {
    $ci = & get_instance();
    if (!empty($voucher_code)) {
        $ci->db->select('*');
        $ci->db->from('voucher');
        $ci->db->where('voucher_code', $voucher_code);
        $query = $ci->db->get();
        $result = $query->result();
        $voucher_id = $result[0]->id;

        $data = array('voucher_id' => $voucher_id, 'user_id' => $user_id, 'voucher_value' => $voucher_value, 'redeemed_ammount' => $redeemed_ammount, 'create_date' => date('Y-m-d'));
        if (!empty($fc_id)) {
            $data['fc_id'] = $fc_id;
        }
        $ci->db->insert('voucher_logs', $data);
        $voucher_log_id = $ci->db->insert_id();

        $data = array();

        if (empty($result[0]->total_redeemed_count)) {
            $data['first_redeemed'] = date('Y-m-d');
        }

        $data['total_redeemed_count'] = $result[0]->total_redeemed_count + 1;
        $data['last_redeemed'] = date('Y-m-d');
        $data['total_redeemed_value'] = $result[0]->total_redeemed_value + $redeemed_ammount;

        $where = array('id' => $voucher_id);
        $ci->db->where($where);
        $ci->db->update('voucher', $data);

        return $voucher_log_id;
    }
}

function UploadFcListingPicture() {
    $ci = & get_instance();
    $listing_image = '';
    if ($ci->input->post('dimesion_image_55555') != '0') {
        $listing_image = $ci->input->post('dimesion_image_55555');
        if (file_exists("uploads/fc_images/temp/" . $listing_image)) {
            rename("uploads/fc_images/temp/" . $listing_image, "uploads/fc_images/" . $listing_image);
        }
        return $listing_image;
    } elseif ($_FILES["fc_listing_picture"]['size'] != 0) {
        $ci->load->library('upload');
        $ci->upload->initialize($ci->set_upload_options());
        if (!$ci->upload->do_upload("fc_listing_picture")) {
            $error = $ci->upload->display_errors();
        } else {
            $dataInfo[] = $ci->upload->data();
            $i_data = $ci->upload->data();
            $listing_image = $i_data['file_name'];

            return $listing_image;
        }
    }
}

function unlink_image($type, $img_id) {
    $ci = & get_instance();
    if ($type == 'slide') {
        $where = array('fc_img_id' => $img_id);
        $old_images = $ci->basic_model->get_record_where('fc_images', 'fc_img_name', $where);
        $path = "uploads/fc_images/";

        if (!empty($old_images)) {
            $path_with_image = "uploads/fc_images/" . $old_images[0]->fc_img_name;
            if (file_exists($path_with_image) && !empty($old_images[0]->fc_img_name)) {
                unlink($path_with_image);
            }
        }
    }
//    elseif($type == 'main'){
//        $where = array('fc_id' => $img_id);
//        $old_images = $ci->basic_model->get_record_where('function_catering', 'fc_listing_picture', $where);
//        $path = "uploads/fc_images/";
//        if (!empty($old_images)) {
//         $path_with_image = "uploads/fc_images/".$old_images[0]->fc_listing_picture;
//         if(file_exists($path_with_image) && !empty($old_images[0]->fc_listing_picture) ){
//             unlink($path_with_image);
//         }
//     }
// }
    elseif ($type == 'space') {
        $where = array('space_image' => $img_id);
        $old_images = $ci->basic_model->get_record_where('venue_spaces', 'space_image', $where);
        $path = "uploads/venue_spaces/";

        if (!empty($old_images)) {
            $path_with_image = "uploads/venue_spaces/" . $old_images[0]->space_image;
            if (file_exists($path_with_image) && !empty($old_images[0]->space_image)) {
                unlink($path_with_image);
            }
        }
    } elseif ($type == 'profile') {
        $where = array('user_id' => $img_id);
        $old_images = $ci->basic_model->get_record_where('users', 'user_image', $where);
        $path = "uploads/users/";
        if (!empty($old_images)) {
            $path_with_image = "uploads/users/" . $old_images[0]->user_image;
            if (file_exists($path_with_image)) {
                unlink($path_with_image);
            }
        }
    }
}

function check_review_provided($fc_id) {
    $ci = & get_instance();

    if ($ci->session->userdata('user_id')) {
        $where = array('f_user' => $ci->session->userdata('user_id'), 'f_fc_id' => $fc_id, 'f_status' => 1);
        $check_feed = $ci->basic_model->get_record_where('feedback', array('f_status'), $where);
        if (!empty($check_feed)) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function string_clean($string) {
    $string = str_replace(' ', '-', $string);

    return preg_replace('/[^A-Za-z0-9-]/', '', $string);
}

function sanitize_from_word($content) {
    // Convert microsoft special characters
    $replace = array(
        "‘" => "'",
        "’" => "'",
        "�?" => '"',
        "“" => '"',
        "–" => "-",
        "—" => "-",
        "…" => "&#8230;"
    );

    foreach ($replace as $k => $v) {
        $content = str_replace($k, $v, $content);
    }
    // Remove any non-ascii character
    $content = preg_replace('/[^\x20-\x7E]*/', '', $content);
    return $content;
}

//function using for get venue percent for progress bar
function getVenuePercent($fc_id) {
    $result = "";
    $ci = & get_instance();
    $where = array('venue_catering_id' => $fc_id);
    $venuePercent = $ci->basic_model->get_record_where('fc_in_progress', '*', $where);
    if (!empty($venuePercent)) {
        foreach ($venuePercent as $val) {
            return $result = floatval($val->business_detail) + floatval($val->package) + floatval($val->venue_catering_detail) + floatval($val->page_layout) + floatval($val->listing_area) + floatval($val->spaces) + floatval($val->payment);
        }
    }
}
