<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'web';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['dashboard'] = 'user/user_dashboard';

$route['my_venues'] = 'venue/my_venues';

$route['space_venue/'] = 'venue/space_venue';
$route['space_venue/(:any)'] = 'venue/space_venue/$1';
$route['spaces/(:any)'] = 'venue/spaces/$1';

$route['my_venue_reviews'] = 'user/my_venue_reviews';

$route['my_catering'] = 'catering/my_catering';
$route['my_catering_reviews'] = 'user/my_catering_reviews';
$route['my_draft'] = 'user/my_draft';
$route['favorites'] = 'user/favourite';
$route['recently_viewed'] = 'user/recently_viewed';
$route['my_reviews'] = 'user/my_reviews';
$route['change_password'] = 'user/change_password';
$route['about_us'] = 'web/about_us';
$route['help'] = 'web/help';
$route['request'] = 'user/venue_catering';
$route['contact_us'] = 'web/contact_us';
$route['privacy_policy'] = 'web/privacy_policy';
$route['term_condition'] = 'web/term_condition';
$route['user_login'] = 'login/user_login';
$route['user_registration'] = 'login/user_registration';
$route['view_venue/(:any)'] = 'web/single_venue/$1';
$route['view_catering/(:any)'] = 'web/single_catering/$1';
$route['write_feedback'] = 'user/submit_feed/$1';
$route['edit_venue/(:any)'] = 'venue/edit_venue/$1';
$route['edit_catering/(:any)'] = 'catering/edit_catering/$1';
$route['edit_space/(:any)'] = 'venue/edit_space/$1';
$route['search'] = 'web/search';
$route['advance_search'] = 'web/advance_search';
$route['venue_catering_request'] = 'user/venue_catering_request';
$route['add_venue'] = 'FNC_Add_Venue/add_venue';
$route['add_catering'] = 'FNC_Add_Catering/add_catering';





