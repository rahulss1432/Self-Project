<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Web_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function first_search($post_data) {
        $where_location = '';
        $where_guest_count = '';
        $where_fc_type = '';

        $fc_type = isset($post_data['fc_type']) ? $post_data['fc_type'] : '';
        $location = addslashes($post_data['location']);
        $search_date = $post_data['search_date'];
        $guest_count = $post_data['guest_count'];
        $addional_fc_ids = $post_data['addional_fc_ids'];
        $where_addional_ids = '';
        $actual_location = $post_data['actual_location'];

        if (isset($fc_type) && !empty($fc_type)) {
            $c = implode(',', $fc_type);
            $where_fc_type = " AND fc.fc_type IN($c)";
        }

        if (isset($location) && !empty($location)) {
            //$where_location = " AND (fc.fc_city LIKE '%$location%' OR fc.fc_state LIKE '%$location%' OR fc.fc_postcode LIKE '%$location%')";
            $where_location = " AND (fc.fc_council LIKE '%$location%' OR fc.fc_state LIKE '%$location%' OR fc.fc_postcode LIKE '%$location%' OR fc.fc_suburb LIKE '%$location%')";
        }

        if (isset($guest_count) && !empty($guest_count) && $guest_count > 0) {
            $where_guest_count = " AND $guest_count BETWEEN fc_min_guest AND fc_max_guest";
        }

        if (!empty($addional_fc_ids)) {
            $where_addional_ids = "OR (fc.fc_id IN ($addional_fc_ids) $where_guest_count and fc.fc_is_deleted=0 and fc_valid_upto >= CURDATE() and fc.fc_status=1)";
        }

        $srch_query = "SELECT fc.fc_listing_picture,fc.fc_business_name,fc.fc_overview,fc.fc_type,fc_images.fc_img_name,fc.fc_listing_picture,fc.fc_id,fc.fc_free
		FROM function_catering as fc 
		LEFT JOIN fc_images ON fc_images.fc_id = fc.fc_id 
		WHERE fc_valid_upto >= CURDATE() and fc.fc_status=1 AND fc.fc_is_deleted=0 $where_location $where_guest_count $where_fc_type $where_addional_ids  GROUP BY fc.fc_id order by fc.fc_suburb='$actual_location' desc";

        $exe_sql = $this->db->query($srch_query);

        if ($exe_sql->num_rows() > 0)
            return $exe_sql->result();
        else
            return FALSE;
    }

    public function advance_search($post_data) {
        $where_cuisine_type = '';
        $where_menus = '';
        $where_event_type = '';
        $where_budget_per_head = '';
        $select_nearby = '';
        $nearby_having = '';
        $where_location = '';
        $where_guest_count = '';
        $where_fc_type = '';
        $where_additional_area = '';
        $actual_location = $post_data['actual_location'];

        $addional_fc_ids = $post_data['addional_fc_ids'];
        $where_addional_ids = '';

        $cuisine_type = isset($post_data['cuisine_type']) ? $post_data['cuisine_type'] : '';
        $menus = isset($post_data['menus']) ? $post_data['menus'] : '';
        $event_type = isset($post_data['event_type']) ? $post_data['event_type'] : '';
        $budget_per_head = isset($post_data['budget_per_head']) ? $post_data['budget_per_head'] : '';
        $near_by = isset($post_data['near_by']) ? $post_data['near_by'] : '';
        $fc_type = isset($post_data['fc_type']) ? $post_data['fc_type'] : '';
        $location = addslashes(isset($post_data['location']) ? $post_data['location'] : '');
        $guest_count = isset($post_data['guest_count']) ? $post_data['guest_count'] : '';



        if (isset($cuisine_type) && !empty($cuisine_type)) {
            $c = implode('|', $cuisine_type);
            $where_cuisine_type = ' AND  CONCAT(",", catering_details.cd_cuisine, ",") REGEXP ",(' . $c . '),"';
        }

        if (isset($menus) && !empty($menus)) {
            $m = implode('|', $menus);
            $where_menus = ' AND  CONCAT(",", catering_details.cd_menus, ",") REGEXP ",(' . $m . '),"';
        }

        if (isset($event_type) && !empty($event_type)) {
            $e = implode('|', $event_type);
            $where_event_type = ' AND  CONCAT(",", venue_details.vd_events, ",") REGEXP ",(' . $e . '),"';
        }

        if (isset($budget_per_head) && !empty($budget_per_head)) {
            $b = implode(',', $budget_per_head);
            $where_budget_per_head = " AND fc.fc_pricing IN($b)";
        }

        if (isset($near_by) && !empty($near_by)) {
            $user_location = user_lat_long();

            if (!empty($user_location)) {

                $user_lat = $user_location['lat'];
                $user_long = $user_location['long'];

                $min = min($near_by);
                $max = max($near_by);

                if ($min == $max)
                    $min = 0;

                $select_nearby = " , ( 6371 * acos( cos( radians(" . $user_lat . ") ) 
              * cos( radians( fc.fc_lat ) ) 
              * cos( radians( fc.fc_lng ) - radians(" . $user_long . ") ) 
				+ sin( radians(" . $user_lat . ") ) 
              * sin( radians( fc.fc_lat ) ) ) ) AS distance ";

                $nearby_having = "having distance  BETWEEN " . $min . " AND " . $max . " ";

                if (isset($fc_type) && !empty($fc_type) && in_array(1, $fc_type)) {
                    $select_area = "SELECT area_venue, ( 6371 * acos( cos( radians(" . $user_lat . ") ) * cos( radians( area_lat ) ) * cos( radians( area_lng ) - radians(" . $user_long . ") ) + sin( radians(" . $user_lat . ") ) 
              * sin( radians( area_lat ) ) ) ) AS distance FROM additional_area having distance  BETWEEN " . $min . " AND " . $max . "";
                    $exe_select_area = $this->db->query($select_area);
                    if ($exe_select_area->num_rows() > 0) {
                        $area_venue_id = '';
                        foreach ($exe_select_area->result() as $value) {
                            $area_venue_id .= $value->area_venue;
                        }
                        $area_venue_id = rtrim($area_venue_id, ',');
                        $where_additional_area = " AND fc.fc_id IN($area_venue_id)";
                    }
                }
            }
        }

        /* previous record */

        if (isset($fc_type) && !empty($fc_type)) {
            $c = implode(',', $fc_type);
            $where_fc_type = " AND fc.fc_type IN($c)";
        }

        if (isset($location) && !empty($location)) {
            //$where_location = " AND (fc.fc_city LIKE '%$location%' OR fc.fc_state LIKE '%$location%' OR fc.fc_postcode LIKE '%$location%')";
            $where_location = " AND (fc.fc_council LIKE '%$location%' OR fc.fc_state LIKE '%$location%' OR fc.fc_postcode LIKE '%$location%')";
        }

        if (isset($guest_count) && !empty($guest_count) && $guest_count > 0) {
            $where_guest_count = " AND $guest_count BETWEEN fc_min_guest AND fc_max_guest";
        }

        if (!empty($addional_fc_ids)) {
            $where_addional_ids = "OR (fc.fc_id IN ($addional_fc_ids) $where_guest_count and fc.fc_is_deleted=0 and fc_valid_upto >= CURDATE() and fc.fc_status=1 $where_budget_per_head $where_event_type)";
        }

        /**/

        $srch_query = "SELECT fc.fc_business_name,fc.fc_overview,fc.fc_type,fc_images.fc_img_name,fc.fc_listing_picture,venue_details.vd_events,fc.fc_id,fc.fc_free $select_nearby
		FROM function_catering as fc 
		LEFT JOIN fc_images ON fc_images.fc_id = fc.fc_id 
		LEFT JOIN venue_details ON venue_details.vd_fc_id = fc.fc_id
                LEFT JOIN catering_details ON catering_details.cd_fc_id = fc.fc_id 
		WHERE fc_valid_upto >= CURDATE() and fc.fc_status=1 AND fc.fc_is_deleted=0  $where_event_type $where_budget_per_head $where_fc_type $where_location $where_guest_count $where_additional_area $where_cuisine_type $where_menus $where_addional_ids GROUP BY fc.fc_id $nearby_having order by fc.fc_suburb='$actual_location' desc";

        //echo $srch_query;
        $exe_sql = $this->db->query($srch_query);

        if ($exe_sql->num_rows() > 0)
            return $exe_sql->result();
        else
            return FALSE;
    }

    public function get_function_and_catering_data() {
        $where = "fc_valid_upto >= CURDATE()";
        $this->db->select('fc_business_name,fc_overview,fc_type,fc_listing_picture,fc_id');
        $this->db->from('function_catering');
        $this->db->where('fc_status', 1);
        $this->db->where('fc_is_deleted', 0);
        $this->db->where($where);
        $this->db->order_by('fc_id', 'DESC');
        $this->db->limit(6);
        $query = $this->db->get();
        //echo $this->db->last_query();
        if ($query->num_rows() > 0)
            return $query->result();
        else
            return FALSE;
    }

    public function user_review($user_id, $default_limit, $id = '') {
        if (!empty($user_id)) {
            $this->db->select('re.f_id,re.f_text,re.f_rating_overall,re.f_rating_cleanliness,re.f_rating_accuracy,re.f_rating_comm,re.f_user,users.user_firstname,users.user_firstname,users.user_lastname,users.user_image,re.f_created_on,function_catering.fc_id,function_catering.fc_type,function_catering.fc_business_name');
            $this->db->from('feedback as re');
            $this->db->where('re.f_user', $user_id);
            $this->db->where('function_catering.fc_is_deleted', 0);
            if (!empty($id))
                $this->db->where('re.f_id < ', $id);

            $this->db->where('re.f_status', 1);
            $this->db->join('users', 'users.user_id = re.f_user', 'left');
            $this->db->join('function_catering', 'function_catering.fc_id = re.f_fc_id', 'left');

            $this->db->order_by('re.f_id', 'DESC');
            $this->db->limit($default_limit);
            $query = $this->db->get();
            //echo $this->db->last_query();
            if ($query->num_rows() > 0)
                return $query->result();
            else
                return FALSE;
        }
    }

    public function get_all_user_review_count($user_id, $id = '') {
        if (!empty($user_id)) {
            $this->db->select('re.f_id');
            $this->db->from('feedback as re');
            $this->db->where('re.f_user', $user_id);

            if (!empty($id))
                $this->db->where('re.f_id < ', $id);

            $this->db->where('re.f_status', 1);

            $this->db->order_by('re.f_id', 'DESC');
            $query = $this->db->get();
            return $query->num_rows();
        }
    }

    public function get_all_venue_review_count($venue_id, $id = '') {
        if (!empty($venue_id)) {
            $this->db->select('re.f_id');
            $this->db->from('feedback as re');
            $this->db->where('re.f_fc_id', $venue_id);

            if (!empty($id))
                $this->db->where('re.f_id < ', $id);

            $this->db->where('re.f_status', 1);
            $this->db->order_by('re.f_id', 'DESC');
            $query = $this->db->get();
            return $query->num_rows();
        }
    }

    public function venue_review($venue_id, $default_limit, $id = '') {
        if (!empty($venue_id)) {
            $this->db->select('re.f_id,re.f_text,re.f_rating_overall,re.f_rating_cleanliness,re.f_rating_accuracy,re.f_rating_comm,re.f_user,users.user_firstname,users.user_firstname,users.user_lastname,users.user_image,re.f_created_on');
            $this->db->from('feedback as re');
            $this->db->where('re.f_fc_id', $venue_id);
            $this->db->where('function_catering.fc_is_deleted', 0);
            if (!empty($id))
                $this->db->where('re.f_id < ', $id);

            $this->db->where('re.f_status', 1);
            $this->db->join('users', 'users.user_id = re.f_user', 'left');
            $this->db->join('function_catering', 'function_catering.fc_id = re.f_fc_id', 'left');
            $this->db->order_by('re.f_id', 'DESC');
            $this->db->limit($default_limit);
            $query = $this->db->get();
            //echo $this->db->last_query();
            if ($query->num_rows() > 0)
                return $query->result();
            else
                return FALSE;
        }
    }

    public function catering_venue_reviews($user_id, $default_limit, $type, $start = 0) {
        if ($user_id) {
            $fc_user = $user_id;
            $fc_status = 1;
            $fc_is_deleted = 0;

            $this->db->select('re.f_id,re.f_text,re.f_rating_overall,re.f_rating_cleanliness,re.f_rating_accuracy,re.f_rating_comm,re.f_user,users.user_firstname,users.user_firstname,users.user_lastname,users.user_image,re.f_created_on,function_catering.fc_business_name,function_catering.fc_id,function_catering.fc_type');
            $this->db->from('`feedback as re');

            $this->db->where(array('function_catering.fc_user' => $fc_user, 'function_catering.fc_status' => $fc_status, 'function_catering.fc_type' => $type, 'function_catering.fc_is_deleted' => $fc_is_deleted, 'f_status' => 1));
            if ($start > 0) {
                $this->db->where('re.f_id <', $start);
            }
            $this->db->order_by("re.f_id", "desc");
            $this->db->limit($default_limit);

            $this->db->join('users', 'users.user_id = re.f_user', 'left');
            $this->db->join('function_catering', ' function_catering.fc_id = re.f_fc_id', 'inner');
            $query = $this->db->get();

            if ($query->num_rows() > 0)
                return $query->result();
            else
                return FALSE;
        }
    }

    public function find_nearest($lat, $long) {
        $srch_query = "SELECT fc.fc_business_name,fc.fc_overview,fc.fc_listing_picture,fc.fc_type,fc_images.fc_img_name,venue_details.vd_events,fc.fc_id,fc.fc_free ,( 6371 * acos( cos( radians(" . $lat . ") ) 
              * cos( radians( fc.fc_lat ) ) 
              * cos( radians( fc.fc_lng ) - radians(" . $long . ") ) 
		+ sin( radians(" . $lat . ") ) 
              * sin( radians( fc.fc_lat ) ) ) ) AS distance
		FROM function_catering as fc 
		LEFT JOIN fc_images ON fc_images.fc_id = fc.fc_id 
		LEFT JOIN venue_details ON venue_details.vd_fc_id = fc.fc_id 
		WHERE fc.fc_valid_upto >= CURDATE() and fc.fc_status=1 AND fc.fc_is_deleted=0  GROUP BY fc.fc_id having distance  BETWEEN '1' AND '25' Order BY fc.fc_id DESC limit 6";
        $exe_sql = $this->db->query($srch_query);

        if ($exe_sql->num_rows() > 0)
            return $exe_sql->result();
        else
            return FALSE;
    }

}
