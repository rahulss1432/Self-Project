<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Updated_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function premium_venues_ajax_list() {
        $user_data = $this->session->all_userdata();

        $get_data = $this->input->get(NULL, TRUE);
        $dt_columns = array("aus_councils.council as council_name", "", "premium_venue.council", "premium_venue.venue_id", "aus_councils.council_id", "premium_venue.id", "premium_venue.is_deleted");

        $dt_searchs = array("aus_councils.council as council_name", "premium_venue.is_deleted");
        $dt_table = "premium_venue";

        $where = '1=1';
        #$where = ""; // set where condition if any
        //Pagination
        if (isset($get_data['iDisplayStart']) && $get_data['iDisplayLength'] != '-1') {
            $this->db->limit(intVal($get_data['iDisplayLength']), intVal($get_data['iDisplayStart']));
        }
        //Sorting
        if (isset($get_data['iSortCol_0'])) {
            for ($i = 0; $i < intval($get_data['iSortingCols']); $i++) {
                if ($get_data['bSortable_' . intval($get_data['iSortCol_' . $i])] == "true") {
                    $sort_column = $dt_searchs[intval($get_data['iSortCol_' . $i])];
                    if (strstr($sort_column, "as") !== false) {
                        $temp_sort_column = explode(" as ", $sort_column);
                        $this->db->order_by($temp_sort_column[$i], ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    } else {
                        $this->db->order_by($sort_column, ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    }
                }
            }
        }
        // search        
        $sWhere = $where;
        #$sch_str = $get_data['sSearch'];
        $sch_str = isset($get_data['is_deleted']) ? $get_data['is_deleted'] : '';

        if (isset($sch_str) && $sch_str != "" && $sch_str == 'Archive_srch') {
            $sWhere .= " AND premium_venue.is_deleted ='1'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'all_srch') {
            $sWhere .= "AND premium_venue.is_deleted IN(1,0)";
        }

        if (isset($get_data['sSearch']) && $get_data['sSearch'] != "") {
            $where = $where . " and (";
            $sWhere = " (" . $where;
            for ($i = 0; $i < count($dt_searchs); $i++) {
                if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true") {
                    $column_search = $dt_searchs[$i];
                    if (strstr($column_search, "as") !== false) {
                        $serch_column = explode(" as ", $column_search);
                        $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    } else {
                        $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    }
                }
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= '))';
        }
        // search all
        for ($i = 0; $i < count($dt_searchs); $i++) {
            if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true" && $get_data['sSearch_' . $i] != '') {
                $column_search = $dt_searchs[$i];
                if (strstr($column_search, "as") !== false) {
                    if ($sWhere == "") {
                        $sWhere = $where;
                    } else {
                        $sWhere .= " AND ";
                    }
                    $serch_column = explode(" as ", $column_search);
                    $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                } else {
                    $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                }
            }
        }

        $dt_query = $this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $dt_columns)), false);
        $dt_query = $this->db->from($dt_table);

        $dt_query = $this->db->join('aus_councils', 'premium_venue.council = aus_councils.council_id', 'left');
        #$dt_query = $this->db->join('function_catering', 'premium_venue.venue_id = function_catering.fc_id','inner');
        $this->db->group_by('premium_venue.id');
        if (!empty($sWhere))
            $this->db->where($sWhere, null, false);
        $dt_result = $this->db->get() or die('MySQL Error: ' . $this->db->_error_number());

        #echo '<pre>'. $this->db->last_query(); die;

        $dt_filtered_total = $this->db->query('SELECT FOUND_ROWS() as count;')->row()->count;
        $dt_total = $this->db->count_all($dt_table);

        $output = array(
            "draw" => intval($get_data['sEcho']),
            "recordsTotal" => $dt_total,
            "recordsFiltered" => $dt_filtered_total,
            "data" => array()
        );
        $i = 1;
        $id = 1;
        foreach ($dt_result->result() as $premium_venues) {
            $name_str = '';
            $row = array();
            if ($premium_venues->venue_id) {
                $row[] = $premium_venues->council_name;

                $where = ' fc_id IN (' . $premium_venues->venue_id . ')';
                $fc_name = $this->basic_model->get_record_where('function_catering', 'fc_business_name,fc_id', $where);

                if ($fc_name) {
                    $x = 1;
                    foreach ($fc_name as $value) {
                        if ($x == 3)
                            $br = '<br/>';
                        else
                            $br = '';

                        $name_str .= '<span class="hash_tag" id="primium_axes_' . $id . '" >' . ucfirst($value->fc_business_name) . '<span class="remove_class" dlt="' . $id . '" council_id="' . $premium_venues->council_id . '" fc_id="' . $value->fc_id . '"> x </span></span>' . $br;
                        $x++;
                        $id++;
                    }
                }
                $row[] = $name_str;
                $url = site_url("admin/add_update_premium_venues/");
                if ($premium_venues->is_deleted == 0) {

                    $row[] = '<a data-id="' . $premium_venues->council_id . '"  class="btn btn-primary pop_edit edit_but" href=" ' . $url . $premium_venues->council_id . '"  onclick="show_council(' . $premium_venues->council_id . ')" ><i class="fa fa-pencil"></i>Edit</a><a class="btn btn-primary row_delete" council_id="' . $premium_venues->council_id . '" ><i class="fa fa-trash"></i>Delete</a>  <a class="btn btn-primary change_password new_pop" href="javascript:;"  onclick="ArchiveFnc(' . $premium_venues->council_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
                }
                if ($premium_venues->is_deleted == 1) {
                    $row[] = "Archived";
                }

                $data[] = $row;

                $output['aaData'][] = $row;
                $i++;
            }
        }
        return json_encode($output);
    }

    public function businesses_authorized_ajax_list() {
        $user_data = $this->session->all_userdata();
        $get_data = $this->input->get(NULL, TRUE);
        $where_date = '';
        $not_delete_oder = '';
        // print_r($get_data);die;
        $dt_columns = array("users.user_firstname", "fc.bus_auth_req", "fc.bus_auth_notes", "users.user_lastname", "fc.bus_auth_status", "fc.bus_auth_id", "fc.user_id", "fc.bus_auth_status", "fc.bus_auth_create_time", "fc.bus_is_deleted");
        $dt_searchs = array("users.user_firstname", "fc.bus_auth_req", "fc.bus_auth_notes", "users.user_lastname", "fc.bus_auth_status", "fc.bus_auth_create_time");

        $dt_table = "businesses_authorized as fc";

        $where = '1=1';
        #$where = ""; // set where condition if any
        $categories = array('1', '2');

        if (isset($get_data['from_date']) && !empty($get_data['from_date'])) {
            $converted_date = date('Y-m-d', strtotime($get_data['from_date']));
            $where_date .= " AND DATE(fc.bus_auth_create_time) >= '" . $converted_date . "'";
        }
        if (isset($get_data['to_date']) && !empty($get_data['to_date'])) {
            $converted_date = date('Y-m-d', strtotime($get_data['to_date']));
            $where_date .= " AND DATE(fc.bus_auth_create_time) <= '" . $converted_date . "'";
        }

        $where = "1=1 $where_date";
        //Pagination
        if (isset($get_data['iDisplayStart']) && $get_data['iDisplayLength'] != '-1') {
            $this->db->limit(intVal($get_data['iDisplayLength']), intVal($get_data['iDisplayStart']));
        }
        //Sorting
        if (isset($get_data['iSortCol_0'])) {
            for ($i = 0; $i < intval($get_data['iSortingCols']); $i++) {
                if ($get_data['bSortable_' . intval($get_data['iSortCol_' . $i])] == "true") {
                    $sort_column = $dt_searchs[intval($get_data['iSortCol_' . $i])];
                    if (strstr($sort_column, "as") !== false) {
                        $temp_sort_column = explode(" as ", $sort_column);
                        $this->db->order_by($temp_sort_column[$i], ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    } else {
                        $this->db->order_by($sort_column, ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    }
                }
            }
        }
        // search        
        $sWhere = $where;


        $sch_str = isset($get_data['bus_auth_status']) ? $get_data['bus_auth_status'] : '';

        if (isset($sch_str) && $sch_str != "" && $sch_str == 'Approve_srch') {
            $sWhere .= " AND fc.bus_auth_status ='1'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'Deny_srch') {
            $sWhere .= " AND fc.bus_auth_status='2'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'Archive_srch') {
            $sWhere .= " AND fc.bus_is_deleted='1'";
        }


        $sch_str = isset($get_data['bus_auth_req']) ? $get_data['bus_auth_req'] : '';

        if (isset($sch_str) && $sch_str != "" && $sch_str == 'venue_srch') {
            $sWhere .= " AND fc.bus_auth_req ='1'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'catering_srch') {
            $sWhere .= " AND fc.bus_auth_req='2'";
        } else if (isset($get_data['sSearch']) && $get_data['sSearch'] != "") {
            $where = $where . " and (";
            $sWhere = " (" . $where;
            for ($i = 0; $i < count($dt_searchs); $i++) {
                if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true") {
                    $column_search = $dt_searchs[$i];
                    if (strstr($column_search, "as") !== false) {
                        $serch_column = explode(" as ", $column_search);
                        $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    } else {
                        $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    }
                }
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= '))';
        }
        // search all
        for ($i = 0; $i < count($dt_searchs); $i++) {
            if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true" && $get_data['sSearch_' . $i] != '') {
                $column_search = $dt_searchs[$i];
                if (strstr($column_search, "as") !== false) {
                    if ($sWhere == "") {
                        $sWhere = $where;
                    } else {
                        $sWhere .= " AND ";
                    }
                    $serch_column = explode(" as ", $column_search);
                    $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                } else {
                    $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                }
            }
        }

        $dt_query = $this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $dt_columns)), false);
        $dt_query = $this->db->from($dt_table);

        $this->db->join('users', 'fc.user_id = users.user_id', 'left');



        $this->db->where($sWhere, null, false);
        // $bus_auth_req= 1;
        // $this->db->where(array('fc.bus_auth_create_time='=> $where_date,'fc.bus_auth_req='=>$bus_auth_req);
        $dt_result = $this->db->get() or die('MySQL Error: ' . $this->db->_error_number());
        // echo '<pre>'. $this->db->last_query(); die;

        $dt_filtered_total = $this->db->query('SELECT FOUND_ROWS() as count;')->row()->count;
        $dt_total = $this->db->count_all($dt_table);

        $output = array(
            "draw" => intval($get_data['sEcho']),
            "recordsTotal" => $dt_total,
            "recordsFiltered" => $dt_filtered_total,
            "data" => array()
        );
        $i = 1;

        foreach ($dt_result->result() as $businesses) {
            $row = array();
            $row[] = $businesses->user_firstname . ' ' . $businesses->user_lastname;

            if ($businesses->bus_auth_req == 1) {
                $location = 'Venue';
            } else {
                $location = 'Catering';
            }
            $row[] = $location;
            $row[] = ucfirst($businesses->bus_auth_notes);
            $row[] = date('d-m-Y', strtotime($businesses->bus_auth_create_time));
            $is_mail_send = 0;

            if ($businesses->bus_auth_status == 0 && $businesses->bus_is_deleted == 0) {
                $app = 1;
                $deny = 2;
                $is_mail_send = 1;

                $row[] = '<a  class="btn btn-danger Approve-put" href="javascript:;" onclick="UpdateBusinesses(' . $businesses->bus_auth_id . ',' . $app . ',' . $is_mail_send . ')"><i class="fa fa-thumbs-up" aria-hidden="true"></i>Approve</a> <a href="javascript:;" class="btn btn-danger Deny"  onclick="UpdateBusinesses(' . $businesses->bus_auth_id . ',' . $deny . ',' . $is_mail_send . ')" ><i class="fa fa-thumbs-down" aria-hidden="true"></i>Deny</a>   <a data-id="' . $businesses->bus_auth_id . '"  class="btn btn-primary pop_edit edit_but" href="javascript:;" onclick="editBusinesses(' . $businesses->bus_auth_id . ',' . $businesses->user_id . ')"><i class="fa fa-pencil"></i>Edit</a> <a class="btn btn-primary change_password new_pop" href="javascript:;"  onclick="ArchiveFnc(' . $businesses->bus_auth_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            }
            if ($businesses->bus_auth_status == 1 && $businesses->bus_is_deleted == 0) {
                $row[] = 'Approved <a class="btn btn-primary change_password new_pop" href="javascript:;"  onclick="ArchiveFnc(' . $businesses->bus_auth_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            }
            if ($businesses->bus_auth_status == 2 && $businesses->bus_is_deleted == 0) {
                $row[] = 'Deny <a class="btn btn-primary change_password new_pop" href="javascript:;"  onclick="ArchiveFnc(' . $businesses->bus_auth_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            }
            if ($businesses->bus_is_deleted == 1) {
                $row[] = "Archived";
            }


            $data[] = $row;
            $output['aaData'][] = $row;
        }
        return json_encode($output);
    }

    public function getvenue_council() {
        $this->db->distinct('fc.fc_council');
        $this->db->select('fc.fc_council,aus_councils.council_id');
        $this->db->where('fc.fc_status', 1);
        $this->db->where('fc.fc_is_deleted', 0);
        $this->db->where('fc.fc_free', 0);
        $this->db->where('fc.fc_valid_upto >= CURDATE()');
        #$this->db->where('order_id',$order_id);
        $this->db->from('function_catering as fc');
        $this->db->join('aus_councils', 'fc.fc_council = aus_councils.council', 'inner');
        #$this->db->group_by('order_date,child_id');
        $dt_result = $this->db->get();
        return $dt_result->result();
    }

    // public function getPremimumvenues($postData) {
    //     $response = array();
    //     #query1
    //     $this->db->select('fc_council,fc_business_name,fc_id ');
    //     $this->db->where('fc_council', $postData['council'], 'fc_id');
    //     $this->db->where('fc_free', 0);
    //     $this->db->where('fc_is_deleted', 0);
    //     $this->db->where('fc_status', 1);
    //     $this->db->where('fc_valid_upto >= CURDATE()');
    //     $this->db->from('function_catering as fc');
    //     // echo $this->db->last_query();die;
    //     $query1 = (array)$this->db->get()->result();
    //     // echo $this->db->last_query();
    //     #query2
    //      $this->db->select('fc.fc_council as fc_council,fc.fc_business_name,fc.fc_id ');
    //      $this->db->where('ad.area_name', $postData['council'], 'fc.fc_id');
    //      $this->db->where('fc.fc_free', 0);
    //      $this->db->where('fc.fc_is_deleted', 0);
    //      $this->db->where('fc.fc_valid_upto >= CURDATE()');
    //      $this->db->from('additional_area as ad');
    //      $this->db->join('function_catering as fc', 'fc.fc_id = ad.area_id', 'inner');
    //      $query2 = $this->db->get()->result();
    //      echo $this->db->last_query();die;
    //       print_r($query2);die;
    //       // echo $this->db->last_query();
    //      // Merge both query results
    //   $query = array_merge($query1, $query2);
    //   // print_r($query);die;
    //     // $response = $q->result_array();
    // return $response;
    // }
    public function getPremimumvenues($postData) {
        $response = array();
//        $this->db->select('fc_council,fc_business_name,fc_id');
//        $this->db->where('fc_council', $postData['council'], 'fc_id');
//        $this->db->where('fc_free', 0);
//        $this->db->where('fc_is_deleted', 0);
//        $this->db->where('fc_status', 1);
//        $this->db->where('fc_valid_upto >= CURDATE()');
//        $this->db->get('function_catering as fc');
        $ql = "SELECT fc_council, fc_business_name, fc_id FROM function_catering
                WHERE fc_council = '" . $postData['council'] . "' AND fc_free =0
                AND fc_is_deleted =0 AND fc_status = 1 AND fc_valid_upto >= CURDATE()
                UNION
                select fc.fc_council as fc_council, fc.fc_business_name, fc.fc_id from additional_area as ad 
                INNER JOIN function_catering as fc on fc.fc_id = ad.area_venue 
                WHERE ad.area_name = '" . $postData['council'] . "' and ad.area_status = 0 "
                . "and `fc`.`fc_status` = 1 AND `fc`.`fc_is_deleted` =0 AND `fc`.`fc_free` =0 AND "
                . "`fc`.`fc_valid_upto` >= CURDATE()";
        $q = $this->db->query($ql);

        $response = $q->result_array();
        // echo $this->db->last_query();
        return $response;
    }

    public function feedback_ajax_list() {
        $user_data = $this->session->all_userdata();
        $where_date = '';
        $not_delete_oder = '';
        $get_data = $this->input->get(NULL, TRUE);

        $dt_columns = array("users.user_firstname", "function_catering.fc_business_name", "feedback.f_text", "feedback.f_status", "feedback.f_id", "feedback.f_user", "feedback.f_fc_id", "users.user_lastname", "feedback.f_created_on", "feedback.f_approved_by", "feedback.f_deleted");

        $dt_searchs = array("feedback.f_id", "users.user_firstname", "function_catering.fc_business_name", "feedback.f_text", "feedback.f_user", "feedback.f_fc_id", "users.user_lastname", "feedback.f_created_on");

        $dt_table = "feedback";

        $where = '';
        $where = '1=1';
        // $where = 'feedback.f_deleted !=1 ';
        #$where = ""; // set where condition if any

        if (isset($get_data['from_date']) && !empty($get_data['from_date'])) {
            $converted_date = date('Y-m-d', strtotime($get_data['from_date']));
            $where_date .= " AND DATE(feedback.f_created_on) >= '" . $converted_date . "'";
        }
        if (isset($get_data['to_date']) && !empty($get_data['to_date'])) {
            $converted_date = date('Y-m-d', strtotime($get_data['to_date']));
            $where_date .= " AND DATE(feedback.f_created_on) <= '" . $converted_date . "'";
        }
        $where = "feedback.f_approved_by = 0 $where_date";
        //Pagination
        if (isset($get_data['iDisplayStart']) && $get_data['iDisplayLength'] != '-1') {
            $this->db->limit(intVal($get_data['iDisplayLength']), intVal($get_data['iDisplayStart']));
        }
        //Sorting
        if (isset($get_data['iSortCol_0'])) {
            for ($i = 0; $i < intval($get_data['iSortingCols']); $i++) {
                if ($get_data['bSortable_' . intval($get_data['iSortCol_' . $i])] == "true") {
                    $sort_column = $dt_searchs[intval($get_data['iSortCol_' . $i])];
                    if (strstr($sort_column, "as") !== false) {
                        $temp_sort_column = explode(" as ", $sort_column);
                        $this->db->order_by($temp_sort_column[$i], ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    } else {
                        $this->db->order_by($sort_column, ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    }
                }
            }
        }
        // search        
        $sWhere = $where;

        $sch_str = isset($get_data['f_status']) ? $get_data['f_status'] : '';
        if (isset($sch_str) && $sch_str != "" && $sch_str == 'approve_srch') {
            $sWhere .= " AND feedback.f_status ='1' ";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'deny_srch') {
            $sWhere .= "AND feedback.f_status ='2'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'dispute_srch') {
            $sWhere .= "AND feedback.f_status ='3'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'all_srch') {
            $sWhere .= "AND feedback.f_status IN(1,2,3,4)";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'pending_srch') {
            $sWhere .= "AND feedback.f_status ='0'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'resolve_srch') {
            $sWhere .= " AND feedback.f_status ='4'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'archive_srch') {
            $sWhere .= " AND feedback.f_status ='5'";
        }
        // $sch_str = isset($get_data['f_deleted'])?$get_data['f_deleted']:'';
        // if (isset($sch_str) && $sch_str != "" && $sch_str == 'archive_srch' )
        // {
        //     $sWhere .= " AND feedback.f_deleted ='1' ";
        // }



        if (isset($get_data['sSearch']) && $get_data['sSearch'] != "") {
            $where = $where . " and (";
            $sWhere = " (" . $where;
            for ($i = 0; $i < count($dt_searchs); $i++) {
                if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true") {
                    $column_search = $dt_searchs[$i];
                    if (strstr($column_search, "as") !== false) {
                        $serch_column = explode(" as ", $column_search);
                        $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    } else {
                        $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    }
                }
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= '))';
        }
        // search all
        for ($i = 0; $i < count($dt_searchs); $i++) {
            if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true" && $get_data['sSearch_' . $i] != '') {
                $column_search = $dt_searchs[$i];
                if (strstr($column_search, "as") !== false) {
                    if ($sWhere == "") {
                        $sWhere = $where;
                    } else {
                        $sWhere .= " AND ";
                    }
                    $serch_column = explode(" as ", $column_search);
                    $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                } else {
                    $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                }
            }
        }

        $dt_query = $this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $dt_columns)), false);
        $dt_query = $this->db->from($dt_table);

        $this->db->join('users', 'feedback. f_user = users.user_id', 'inner');
        $this->db->join('function_catering', 'feedback.f_fc_id = function_catering.fc_id', 'inner');



        $this->db->where($sWhere, null, false);
        $dt_result = $this->db->get() or die('MySQL Error: ' . $this->db->_error_number());
        // echo '<pre>'. $this->db->last_query(); die;

        $dt_filtered_total = $this->db->query('SELECT FOUND_ROWS() as count;')->row()->count;
        $dt_total = $this->db->count_all($dt_table);

        $output = array(
            "draw" => intval($get_data['sEcho']),
            "recordsTotal" => $dt_total,
            "recordsFiltered" => $dt_filtered_total,
            "data" => array()
        );
        $i = 1;

        foreach ($dt_result->result() as $feedback) {
            $row = array();
            $row[] = $feedback->user_firstname . ' ' . $feedback->user_lastname;
            $row[] = $feedback->fc_business_name;
            /* $row[] = $feedback->f_rating_cleanliness;
              $row[] = $feedback->f_rating_accuracy;
              $row[] = $feedback->f_rating_comm; */
            $row[] = $feedback->f_text;
            if ($feedback->f_status == 1) {
                $row[] = "Approved";
            }
            if ($feedback->f_status == 2) {
                $row[] = "Denied";
            }
            if ($feedback->f_status == 3) {
                $row[] = "Disputed";
            }
            if ($feedback->f_status == 4) {
                $row[] = "Resolve";
            }
            if ($feedback->f_status == 0) {
                $row[] = "Approval pending";
            }
            if ($feedback->f_status == 5) {
                $row[] = "Archived";
            }
            // $row[] = $feedback->f_created_on;
            // $row[] =  date("d F, Y ", strtotime($feedback->f_created_on));
            $row[] = date('d-m-Y', strtotime($feedback->f_created_on));
            if ($feedback->f_status == 0) {
                $new = 1;
                $dis = 3;
                $row[] = '<a  class="btn btn-danger Approve-put" href="javascript:;" onclick="UpdateFeedback(' . $feedback->f_id . ',' . $new . ')"><i class="fa fa-thumbs-up" aria-hidden="true"></i>Approve</a> <a  class="btn btn-success" href="javascript:;" onclick="UpdateFeedback(' . $feedback->f_id . ',' . $dis . ')">Disputed</a>    <a data-id="' . $feedback->f_id . '"  class="btn btn-primary pop_edit edit_but" href="javascript:;" onclick="editFeedback(' . $feedback->f_id . ')"><i class="fa fa-pencil"></i>Edit</a> <a class="btn btn-primary change_password open_popup" href="javascript:;"  onclick="ArchiveFnc(' . $feedback->f_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            }
            if ($feedback->f_status == 1) {
                $deny = 2;
                $row[] = '<a href="javascript:;" class="btn btn-danger Deny"  onclick="UpdateFeedback(' . $feedback->f_id . ',' . $deny . ')" ><i class="fa fa-thumbs-down" aria-hidden="true"></i>Deny</a>    <a data-id="' . $feedback->f_id . '"  class="btn btn-primary pop_edit edit_but" href="javascript:;" onclick="editFeedback(' . $feedback->f_id . ')"><i class="fa fa-pencil"></i>Edit</a> <a class="btn btn-primary change_password open_popup" href="javascript:;"  onclick="ArchiveFnc(' . $feedback->f_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            }
            if ($feedback->f_status == 2) {
                $new = 1;
                $row[] = '<a href="javascript:;" class="btn btn-danger Approve-put"  onclick="UpdateFeedback(' . $feedback->f_id . ',' . $new . ')" ><i class="fa fa-thumbs-up" aria-hidden="true"></i>Approve</a>    <a data-id="' . $feedback->f_id . '"  class="btn btn-primary pop_edit edit_but" href="javascript:;" onclick="editFeedback(' . $feedback->f_id . ')"><i class="fa fa-pencil"></i>Edit</a> <a class="btn btn-primary change_password open_popup" href="javascript:;"  onclick="ArchiveFnc(' . $feedback->f_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            }
            if ($feedback->f_status == 3) {
                $res = 4;
                $row[] = '<a href="javascript:;" class="btn btn-danger"  onclick="UpdateFeedback(' . $feedback->f_id . ',' . $res . ')" >Pending</a>    <a data-id="' . $feedback->f_id . '"  class="btn btn-primary pop_edit edit_but" href="javascript:;" onclick="editFeedback(' . $feedback->f_id . ')"><i class="fa fa-pencil"></i>Edit</a> <a class="btn btn-primary change_password open_popup" href="javascript:;"  onclick="ArchiveFnc(' . $feedback->f_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            }
            if ($feedback->f_status == 4) {
                $deny = 2;
                $row[] = '<a href="javascript:;" class="btn btn-danger"  onclick="UpdateFeedback(' . $feedback->f_id . ',' . $deny . ')" >Deny</a>    <a data-id="' . $feedback->f_id . '"  class="btn btn-primary pop_edit edit_but" href="javascript:;" onclick="editFeedback(' . $feedback->f_id . ')"><i class="fa fa-pencil"></i>Edit</a> <a class="btn btn-primary change_password open_popup" href="javascript:;"  onclick="ArchiveFnc(' . $feedback->f_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            }
            if ($feedback->f_status == 5) {
                $row[] = "Archived";
            }




            $data[] = $row;
            $output['aaData'][] = $row;
        }
        return json_encode($output);
    }

    public function catering_ajax_list() {
        $user_data = $this->session->all_userdata();
        $get_data = $this->input->get(NULL, TRUE);

        $dt_columns = array("fc.fc_business_name", "users.user_firstname", "fc.fc_contact_name", "fc.fc_phone_no", "fc.fc_type", "fc.fc_user", "fc.fc_status", "users.user_lastname", "fc.fc_id", "fc.fc_free", 'payment_details.payment_mode', 'payment_details.payment_status', 'fc.fc_is_deleted');

        $dt_searchs = array("fc.fc_business_name", "users.user_firstname", "fc.fc_contact_name", "fc.fc_phone_no", "fc.fc_type", "fc.fc_user", "fc.fc_id", "fc.fc_status", "users.user_lastname", "fc.fc_free");

        $dt_table = "function_catering as fc";

        $where = 'fc.fc_status NOT IN(2,5)';


        //Pagination
        if (isset($get_data['iDisplayStart']) && $get_data['iDisplayLength'] != '-1') {
            $this->db->limit(intVal($get_data['iDisplayLength']), intVal($get_data['iDisplayStart']));
        }
        //Sorting
        if (isset($get_data['iSortCol_0'])) {
            for ($i = 0; $i < intval($get_data['iSortingCols']); $i++) {
                if ($get_data['bSortable_' . intval($get_data['iSortCol_' . $i])] == "true") {
                    $sort_column = $dt_searchs[intval($get_data['iSortCol_' . $i])];
                    if (strstr($sort_column, "as") !== false) {
                        $temp_sort_column = explode(" as ", $sort_column);
                        $this->db->order_by($temp_sort_column[$i], ($get_data['sSortDir_' . $i] === 'asc' ? 'ASC' : 'DESC'));
                    } else {
                        $this->db->order_by($sort_column, ($get_data['sSortDir_' . $i] === 'asc' ? 'ASC' : 'DESC'));
                    }
                }
            }
        }

        // search        
        $sWhere = $where;

        $sch_str = isset($get_data['fc_type']) ? $get_data['fc_type'] : '';

        if (isset($sch_str) && $sch_str != "" && $sch_str == 'Venue_srch') {
            $sWhere .= " AND fc.fc_type ='1' AND !fc.fc_free = '1'";
        }

        if (isset($sch_str) && $sch_str != "" && $sch_str == 'Venue_free') {
            $sWhere .= "AND fc.fc_free ='1' AND fc.fc_type ='1'";
        }

        if (isset($sch_str) && $sch_str != "" && $sch_str == 'all_srch') {
            $sWhere .= " AND fc.fc_type IN(1,2)";
        }

        if (isset($sch_str) && $sch_str != "" && $sch_str == 'Catering_free') {
            $sWhere .= "AND fc.fc_free ='1' AND fc.fc_type ='2'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'Catering_srch') {
            $sWhere .= " AND fc.fc_type ='2' AND !fc.fc_free = '1'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'archive_srch') {
            $sWhere .= " AND fc.fc_is_deleted ='1'";
        }
        #echo $sWhere;
        if (isset($get_data['sSearch']) && $get_data['sSearch'] != "") {
            $where = $where . " and (";
            $sWhere = " (" . $where;
            for ($i = 0; $i < count($dt_searchs); $i++) {
                if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true") {
                    $column_search = $dt_searchs[$i];
                    if (strstr($column_search, "as") !== false) {
                        $serch_column = explode(" as ", $column_search);
                        $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    } else {
                        $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    }
                }
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= '))';
        }


        // search all
        for ($i = 0; $i < count($dt_searchs); $i++) {
            if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true" && $get_data['sSearch_' . $i] != '') {
                $column_search = $dt_searchs[$i];
                if (strstr($column_search, "as") !== false) {
                    if ($sWhere == "") {
                        $sWhere = $where;
                    } else {
                        $sWhere .= " AND ";
                    }
                    $serch_column = explode(" as ", $column_search);
                    $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                } else {
                    $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                }
            }
        }

        $dt_query = $this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $dt_columns)), false);
        $dt_query = $this->db->from($dt_table);

        $this->db->group_by('fc.fc_id');

        $this->db->join('users', 'fc.fc_user = users.user_id', 'inner');
        $this->db->join('payment_details', 'fc.fc_id = payment_details.pay_fc_id', 'left');


        $this->db->where($sWhere, null, false);
        $dt_result = $this->db->get() or die('MySQL Error: ' . $this->db->_error_number());
        // echo '<pre>'. $this->db->last_query(); die;

        $dt_filtered_total = $this->db->query('SELECT FOUND_ROWS() as count;')->row()->count;
        $dt_total = $this->db->count_all($dt_table);

        $output = array(
            "draw" => intval($get_data['sEcho']),
            "recordsTotal" => $dt_total,
            "recordsFiltered" => $dt_filtered_total,
            "data" => array()
        );
        $i = 1;

        foreach ($dt_result->result() as $function_catering) {

            $temp = '';
            $tempPreview = '';
            $row = array();
            $row[] = $function_catering->fc_business_name;
            $row[] = $function_catering->user_firstname . ' ' . $function_catering->user_lastname;

            $row[] = ucfirst($function_catering->fc_contact_name);
            $row[] = $function_catering->fc_phone_no;

            if ($function_catering->fc_type == 1) {
                $type = 'Venue';
                $url = site_url("admin/edit_venue/");
                $urlPreview = site_url("admin/admin_vanue_preview/");
            } else {
                $type = 'Catering';
                $url = site_url("admin/edit_catering/");
                $urlPreview = site_url("admin/admin_catering_preview/");
            }
            if ($function_catering->fc_free == 1 && $function_catering->fc_type == 1) {
                $type = 'Free Venue';
            }
            if ($function_catering->fc_free == 1 && $function_catering->fc_type == 2) {
                $type = 'Free Catering';
            }
            $row[] = $type;
            $is_mail_send = 0;
            if ($function_catering->payment_mode == 0 && $function_catering->payment_status == 1) {
                $row[] = 'Payment pending';
            }
            if ($function_catering->fc_status == 0 && $function_catering->fc_is_deleted == 0) {
                $app = 1;
                $deny = 2;
                $is_mail_send = 1;
                $temp .= '<a class="btn btn-primary pop_edit edit_but" target="_blank" href=" ' . $urlPreview . $function_catering->fc_id . '" ><i class="fa fa-thumbs-up" aria-hidden="true"></i>Preview</a><a class="btn btn-danger Approve-put" href="javascript:;"  onclick="UpdateCatering(' . $function_catering->fc_id . ',' . $app . ',' . $is_mail_send . ')"><i class="fa fa-thumbs-up" aria-hidden="true"></i>Approve</a>  ';
                $is_mail_send = 0;
                $temp .= '<a class="btn btn-danger Deny" href="javascript:;"  onclick="UpdateCatering(' . $function_catering->fc_id . ',' . $deny . ',' . $is_mail_send . ')"><i class="fa fa-thumbs-down" aria-hidden="true"></i>Deny</a>
        <a data-id="' . $function_catering->fc_id . '" class="btn btn-primary pop_edit edit_but" href=" ' . $url . $function_catering->fc_id . '" ><i class="fa fa-pencil"></i>Edit</a>
        <a class="btn btn-primary change_password open_pop" href="javascript:;"  onclick="ArchiveFnc(' . $function_catering->fc_id . ')" ><i class="fa fa-archive"></i>Archive</a>';

                $row[] = $temp;
            } elseif ($function_catering->fc_status == 3 && $function_catering->fc_is_deleted == 0) {
                $unblock = 1;
                $row[] = '<a class="btn btn-primary pop_edit edit_but" target="_blank" href=" ' . $urlPreview . $function_catering->fc_id . '" ><i class="fa fa-thumbs-up" aria-hidden="true"></i>Preview</a><a  class="btn btn-warning block" href="javascript:;"  onclick="UpdateCatering(' . $function_catering->fc_id . ',' . $unblock . ',' . $is_mail_send . ')" ><i class="fa fa-unlock" aria-hidden="true"></i>Unblock</a> <a data-id="' . $function_catering->fc_id . '" class="btn btn-primary pop_edit edit_but" href=" ' . $url . $function_catering->fc_id . '" ><i class="fa fa-pencil"></i>Edit</a> <a class="btn btn-primary change_password open_pop" href="javascript:;"  onclick="ArchiveFnc(' . $function_catering->fc_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            } elseif ($function_catering->fc_status == 1 && $function_catering->fc_is_deleted == 0) {
                $block = 3;
                $row[] = '<a class="btn btn-primary pop_edit edit_but" target="_blank" href=" ' . $urlPreview . $function_catering->fc_id . '" ><i class="fa fa-thumbs-up" aria-hidden="true"></i>Preview</a><a class="btn btn-info unblock" href="javascript:;"  onclick="UpdateCatering(' . $function_catering->fc_id . ',' . $block . ',' . $is_mail_send . ')" ><i class="fa fa-lock" aria-hidden="true"></i>block</a> <a data-id="' . $function_catering->fc_id . '" class="btn btn-primary pop_edit edit_but" href=" ' . $url . $function_catering->fc_id . '"  ><i class="fa fa-pencil"></i>Edit</a>  <a class="btn btn-primary change_password open_pop" href="javascript:;"  onclick="ArchiveFnc(' . $function_catering->fc_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            } else if ($function_catering->fc_is_deleted == 1) {
                $row[] = "Archived";
            } else {
                $row[] = "";
            }
            $row[] = $function_catering->fc_id;
            $data[] = $row;
            $output['aaData'][] = $row;
        }
        return json_encode($output);
    }

    public function voucher_ajax_list() {
        $user_data = $this->session->all_userdata();
        // $where_date = ''; $not_delete_oder = '';
        $get_data = $this->input->get(NULL, TRUE);

        $dt_columns = array("voucher.voucher_code", "voucher.description", "voucher.value", "voucher.start_date", "voucher.end_date", "voucher.total_value", "voucher.voucher_use", "voucher.created_date", "voucher.modified_on", "voucher.id", "voucher.total_redeemed_value", "voucher.total_redeemed_count", "voucher.last_redeemed", "voucher.first_redeemed", "voucher.voucher_status", "voucher.is_deleted");

        $dt_searchs = array("voucher.id", "voucher.voucher_code", "voucher.description", "voucher.value", "voucher.start_date", "voucher.end_date", "voucher.total_value", "voucher.voucher_use");

        $dt_table = "voucher";

        $where = '';
        $where = '1=1';
        // $where ='voucher.is_deleted !=1';
        #$where = ""; // set where condition if any
        //Pagination
        if (isset($get_data['iDisplayStart']) && $get_data['iDisplayLength'] != '-1') {
            $this->db->limit(intVal($get_data['iDisplayLength']), intVal($get_data['iDisplayStart']));
        }
        //Sorting
        if (isset($get_data['iSortCol_0'])) {
            for ($i = 0; $i < intval($get_data['iSortingCols']); $i++) {
                if ($get_data['bSortable_' . intval($get_data['iSortCol_' . $i])] == "true") {
                    $sort_column = $dt_searchs[intval($get_data['iSortCol_' . $i])];
                    if (strstr($sort_column, "as") !== false) {
                        $temp_sort_column = explode(" as ", $sort_column);
                        $this->db->order_by($temp_sort_column[$i], ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    } else {
                        $this->db->order_by($sort_column, ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    }
                }
            }
        }
        // search        
        $sWhere = $where;
        if (isset($get_data['sSearch']) && $get_data['sSearch'] != "") {
            $where = $where . " and (";
            $sWhere = " (" . $where;
            for ($i = 0; $i < count($dt_searchs); $i++) {
                if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true") {
                    $column_search = $dt_searchs[$i];
                    if (strstr($column_search, "as") !== false) {
                        $serch_column = explode(" as ", $column_search);
                        $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    } else {
                        $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    }
                }
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= '))';
        }
        // search all
        for ($i = 0; $i < count($dt_searchs); $i++) {
            if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true" && $get_data['sSearch_' . $i] != '') {
                $column_search = $dt_searchs[$i];
                if (strstr($column_search, "as") !== false) {
                    if ($sWhere == "") {
                        $sWhere = $where;
                    } else {
                        $sWhere .= " AND ";
                    }
                    $serch_column = explode(" as ", $column_search);
                    $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                } else {
                    $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                }
            }
        }

        $dt_query = $this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $dt_columns)), false);
        $dt_query = $this->db->from($dt_table);
        $this->db->where($sWhere, null, false);
        $dt_result = $this->db->get() or die('MySQL Error: ' . $this->db->_error_number());
        // echo '<pre>'. $this->db->last_query(); die;

        $dt_filtered_total = $this->db->query('SELECT FOUND_ROWS() as count;')->row()->count;
        $dt_total = $this->db->count_all($dt_table);

        $output = array(
            "draw" => intval($get_data['sEcho']),
            "recordsTotal" => $dt_total,
            "recordsFiltered" => $dt_filtered_total,
            "data" => array()
        );
        $i = 1;

        foreach ($dt_result->result() as $voucher) {
            $row = array();
            $row[] = $voucher->voucher_code;
            $row[] = $voucher->description;
            $row[] = $voucher->value;
            $row[] = date('d-m-Y', strtotime($voucher->start_date));
            $row[] = date('d-m-Y', strtotime($voucher->end_date));
            $row[] = $voucher->total_value;
            if ($voucher->voucher_status == 0) {
                $row[] = "Approval pending";
            }
            if ($voucher->voucher_status == 1) {
                $row[] = "Activated";
            }
            if ($voucher->voucher_status == 2) {
                $row[] = "Deactivated";
            }

            $url = site_url("admin/voucher_edit/");
            $row[] = $voucher->voucher_use;

            if (!empty($voucher->first_redeemed) && $voucher->first_redeemed != '0000-00-00 00:00:00') {
                $row[] = date('d-m-Y', strtotime($voucher->first_redeemed));
            } else {
                $row[] = "N/A";
            }
            if (!empty($voucher->last_redeemed) && $voucher->last_redeemed != '0000-00-00 00:00:00') {
                $row[] = date('d-m-Y', strtotime($voucher->last_redeemed));
            } else {
                $row[] = "N/A";
            }
            if (!empty($voucher->total_redeemed_count)) {
                $row[] = $voucher->total_redeemed_count;
            } else {
                $row[] = "N/A";
            }
            if (!empty($voucher->total_redeemed_value)) {
                $row[] = $voucher->total_redeemed_value;
            } else {
                $row[] = "N/A";
            }
            if ($voucher->voucher_status == 0 && $voucher->is_deleted == 0) {
                $active = 1;
                $row[] = '<a data-id="' . $voucher->id . '" class="btn btn-primary pop_edit edit_but" href=" ' . $url . $voucher->id . '" ><i class="fa fa-pencil"></i>Edit</a> <a class="btn btn-danger Approve-put" href="javascript:;"  onclick="UpdateVoucher(' . $voucher->id . ',' . $active . ')"><i class="fa fa-thumbs-up" aria-hidden="true"></i>Active</a> <a class="btn btn-primary change_password new_pop" href="javascript:;"  onclick="ArchiveFnc(' . $voucher->id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            } elseif ($voucher->voucher_status == 1 && $voucher->is_deleted == 0) {
                $deactive = 2;
                $row[] = '<a data-id="' . $voucher->id . '" class="btn btn-primary pop_edit edit_but" href=" ' . $url . $voucher->id . '" ><i class="fa fa-pencil"></i>Edit</a> <a class="btn btn-danger Approve-put" href="javascript:;"  onclick="UpdateVoucher(' . $voucher->id . ',' . $deactive . ')"><i class="fa fa-thumbs-up" aria-hidden="true"></i>Deactive</a> <a class="btn btn-primary change_password new_pop" href="javascript:;"  onclick="ArchiveFnc(' . $voucher->id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            } elseif ($voucher->voucher_status == 2 && $voucher->is_deleted == 0) {
                $active = 1;
                $row[] = '<a data-id="' . $voucher->id . '" class="btn btn-primary pop_edit edit_but" href=" ' . $url . $voucher->id . '" ><i class="fa fa-pencil"></i>Edit</a> <a class="btn btn-danger Approve-put" href="javascript:;"  onclick="UpdateVoucher(' . $voucher->id . ',' . $active . ')"><i class="fa fa-thumbs-up" aria-hidden="true"></i>Active</a> <a class="btn btn-primary change_password new_pop" href="javascript:;"  onclick="ArchiveFnc(' . $voucher->id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            } else if ($voucher->is_deleted == 1) {
                $row[] = "Archived";
            } else {
                $row[] = "";
            }
            $output['aaData'][] = $row;
        }
        return json_encode($output);
    }

    public function pages_ajax_list() {
        $user_data = $this->session->all_userdata();
        // $where_date = ''; $not_delete_oder = '';
        $get_data = $this->input->get(NULL, TRUE);

        $dt_columns = array("pages.title", "pages.content", "pages.id");

        $dt_searchs = array("pages.title", "pages.content");

        $dt_table = "pages";

        $where = '';
        $where = '1=1';
        #$where = ""; // set where condition if any
        //Pagination
        if (isset($get_data['iDisplayStart']) && $get_data['iDisplayLength'] != '-1') {
            $this->db->limit(intVal($get_data['iDisplayLength']), intVal($get_data['iDisplayStart']));
        }
        //Sorting
        if (isset($get_data['iSortCol_0'])) {
            for ($i = 0; $i < intval($get_data['iSortingCols']); $i++) {
                if ($get_data['bSortable_' . intval($get_data['iSortCol_' . $i])] == "true") {
                    $sort_column = $dt_searchs[intval($get_data['iSortCol_' . $i])];
                    if (strstr($sort_column, "as") !== false) {
                        $temp_sort_column = explode(" as ", $sort_column);
                        $this->db->order_by($temp_sort_column[$i], ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    } else {
                        $this->db->order_by($sort_column, ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    }
                }
            }
        }
        // search        
        $sWhere = $where;
        if (isset($get_data['sSearch']) && $get_data['sSearch'] != "") {
            $where = $where . " and (";
            $sWhere = " (" . $where;
            for ($i = 0; $i < count($dt_searchs); $i++) {
                if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true") {
                    $column_search = $dt_searchs[$i];
                    if (strstr($column_search, "as") !== false) {
                        $serch_column = explode(" as ", $column_search);
                        $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    } else {
                        $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    }
                }
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= '))';
        }
        // search all
        for ($i = 0; $i < count($dt_searchs); $i++) {
            if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true" && $get_data['sSearch_' . $i] != '') {
                $column_search = $dt_searchs[$i];
                if (strstr($column_search, "as") !== false) {
                    if ($sWhere == "") {
                        $sWhere = $where;
                    } else {
                        $sWhere .= " AND ";
                    }
                    $serch_column = explode(" as ", $column_search);
                    $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                } else {
                    $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                }
            }
        }

        $dt_query = $this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $dt_columns)), false);
        $dt_query = $this->db->from($dt_table);
        $this->db->where($sWhere, null, false);
        $dt_result = $this->db->get() or die('MySQL Error: ' . $this->db->_error_number());
        // echo '<pre>'. $this->db->last_query(); die;

        $dt_filtered_total = $this->db->query('SELECT FOUND_ROWS() as count;')->row()->count;
        $dt_total = $this->db->count_all($dt_table);

        $output = array(
            "draw" => intval($get_data['sEcho']),
            "recordsTotal" => $dt_total,
            "recordsFiltered" => $dt_filtered_total,
            "data" => array()
        );
        $i = 1;

        foreach ($dt_result->result() as $pages) {

            $temp = '';
            $row = array();
            $row[] = $pages->title;
            $row[] = $pages->content;
            $url = site_url('admin/pages_edit/');
            $row[] = '<a data-id="' . $pages->id . '" class="btn btn-primary pop_edit edit_but" href=" ' . $url . $pages->id . '" ><i class="fa fa-pencil"></i>Edit</a>';

            $data[] = $row;
            $output['aaData'][] = $row;
        }
        return json_encode($output);
    }

    public function voucher_history_ajax_list() {
        $user_data = $this->session->all_userdata();
        $get_data = $this->input->get(NULL, TRUE);
        $where_date = '';
        $not_delete_oder = '';

        $dt_columns = array("users.user_firstname", "users.user_lastname", "voucher.voucher_code", "function_catering.fc_business_name", "voucher_logs.voucher_value", "voucher_logs.redeemed_ammount", "voucher_logs.create_date");

        $dt_searchs = array("voucher_logs.v_log_id", "users.user_firstname", "users.user_lastname", "voucher.voucher_code", "function_catering.fc_business_name", "voucher_logs.voucher_value", "voucher_logs.redeemed_ammount", "voucher_logs.create_date");

        $dt_table = "voucher_logs";

        $where = '';
        $where = '1=1';
        #$where = ""; // set where condition if any

        if (isset($get_data['from_date']) && !empty($get_data['from_date'])) {
            $converted_date = date('Y-m-d', strtotime($get_data['from_date']));
            $where_date .= " AND DATE(voucher_logs.create_date) >= '" . $converted_date . "'";
        }
        if (isset($get_data['to_date']) && !empty($get_data['to_date'])) {
            $converted_date = date('Y-m-d', strtotime($get_data['to_date']));
            $where_date .= " AND DATE(voucher_logs.create_date) <= '" . $converted_date . "'";
        }
        $where = $where . $where_date;

        //Pagination
        if (isset($get_data['iDisplayStart']) && $get_data['iDisplayLength'] != '-1') {
            $this->db->limit(intVal($get_data['iDisplayLength']), intVal($get_data['iDisplayStart']));
        }
        //Sorting
        if (isset($get_data['iSortCol_0'])) {
            for ($i = 0; $i < intval($get_data['iSortingCols']); $i++) {
                if ($get_data['bSortable_' . intval($get_data['iSortCol_' . $i])] == "true") {
                    $sort_column = $dt_searchs[intval($get_data['iSortCol_' . $i])];
                    if (strstr($sort_column, "as") !== false) {
                        $temp_sort_column = explode(" as ", $sort_column);
                        $this->db->order_by($temp_sort_column[$i], ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    } else {
                        $this->db->order_by($sort_column, ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    }
                }
            }
        }
        // search        
        $sWhere = $where;


        if (isset($get_data['sSearch']) && $get_data['sSearch'] != "") {
            $where = $where . " and (";
            $sWhere = " (" . $where;
            for ($i = 0; $i < count($dt_searchs); $i++) {
                if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true") {
                    $column_search = $dt_searchs[$i];
                    if (strstr($column_search, "as") !== false) {
                        $serch_column = explode(" as ", $column_search);
                        $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    } else {
                        $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    }
                }
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= '))';
        }
        // search all
        for ($i = 0; $i < count($dt_searchs); $i++) {
            if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true" && $get_data['sSearch_' . $i] != '') {
                $column_search = $dt_searchs[$i];
                if (strstr($column_search, "as") !== false) {
                    if ($sWhere == "") {
                        $sWhere = $where;
                    } else {
                        $sWhere .= " AND ";
                    }
                    $serch_column = explode(" as ", $column_search);
                    $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                } else {
                    $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                }
            }
        }

        $dt_query = $this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $dt_columns)), false);
        $dt_query = $this->db->from($dt_table);

        $this->db->join('users', 'voucher_logs.user_id = users.user_id', 'inner');
        $this->db->join('function_catering', 'voucher_logs.fc_id = function_catering.fc_id', 'inner');
        $this->db->join('voucher', 'voucher_logs.voucher_id = voucher.id', 'inner');




        $this->db->where($sWhere, null, false);
        $dt_result = $this->db->get() or die('MySQL Error: ' . $this->db->_error_number());
        // echo '<pre>'. $this->db->last_query(); die;

        $dt_filtered_total = $this->db->query('SELECT FOUND_ROWS() as count;')->row()->count;
        $dt_total = $this->db->count_all($dt_table);

        $output = array(
            "draw" => intval($get_data['sEcho']),
            "recordsTotal" => $dt_total,
            "recordsFiltered" => $dt_filtered_total,
            "data" => array()
        );
        $i = 1;

        foreach ($dt_result->result() as $voucher) {
            $row = array();
            $row[] = $voucher->voucher_code;
            $row[] = $voucher->user_firstname . ' ' . $voucher->user_lastname;
            $row[] = $voucher->fc_business_name;
            $row[] = $voucher->voucher_value;
            $row[] = $voucher->redeemed_ammount;
            $row[] = date('d-m-Y', strtotime($voucher->create_date));

            $data[] = $row;
            $output['aaData'][] = $row;
        }
        return json_encode($output);
    }

    public function payment_details_ajax_list() {
        $user_data = $this->session->all_userdata();
        $where_date = '';
        $not_delete_oder = '';
        $get_data = $this->input->get(NULL, TRUE);

        $dt_columns = array("users.user_firstname", "users.user_lastname", "payment_details.pay_txn_id", "function_catering.fc_business_name", "payment_details.pay_total_amount", "voucher.voucher_code", "payment_details.payment_method", "payment_details.payment_status", "payment_details.pay_created_on", "payment_details.pay_id", "payment_details.pay_created_on", "payment_details.total_amount");

        $dt_searchs = array("payment_details.pay_id", "concat(users.user_firstname,' ',users.user_lastname)", "payment_details.pay_txn_id", "function_catering.fc_business_name", "payment_details.pay_total_amount", "voucher.voucher_code", "payment_details.payment_method", "payment_details.payment_status", "payment_details.pay_created_on", "STR_TO_DATE(payment_details.pay_created_on,'%d/%m/%Y')", "payment_details.total_amount");

        $dt_table = "payment_details";

        $where = '';
        $where = '1=1';
        #$where = ""; // set where condition if any

        if (isset($get_data['from_date']) && !empty($get_data['from_date'])) {
            $converted_date = date('Y-m-d', strtotime($get_data['from_date']));
            $where_date .= " AND DATE(payment_details.pay_created_on) >= '" . $converted_date . "'";
        }
        if (isset($get_data['to_date']) && !empty($get_data['to_date'])) {
            $converted_date = date('Y-m-d', strtotime($get_data['to_date']));
            $where_date .= " AND DATE(payment_details.pay_created_on) <= '" . $converted_date . "'";
        }

        $where = $where . $where_date;
        //Pagination
        if (isset($get_data['iDisplayStart']) && $get_data['iDisplayLength'] != '-1') {
            $this->db->limit(intVal($get_data['iDisplayLength']), intVal($get_data['iDisplayStart']));
        }
        //Sorting
        if (isset($get_data['iSortCol_0'])) {
            for ($i = 0; $i < intval($get_data['iSortingCols']); $i++) {
                if ($get_data['bSortable_' . intval($get_data['iSortCol_' . $i])] == "true") {
                    $sort_column = $dt_searchs[intval($get_data['iSortCol_' . $i])];
                    if (strstr($sort_column, "as") !== false) {
                        $temp_sort_column = explode(" as ", $sort_column);
                        $this->db->order_by($temp_sort_column[$i], ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    } else {
                        $this->db->order_by($sort_column, ($get_data['sSortDir_' . $i] === 'asc' ? 'desc' : 'asc'));
                    }
                }
            }
        }
        // search        
        $sWhere = $where;
        $sch_str = isset($get_data['payment_method']) ? $get_data['payment_method'] : '';

        if (isset($sch_str) && $sch_str != "" && $sch_str == 'Stripe_srch') {
            $sWhere .= " AND payment_details.payment_method ='1'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'Account_srch') {
            $sWhere .= " AND payment_details.payment_method='2'";
        }
        $sch_str = isset($get_data['payment_status']) ? $get_data['payment_status'] : '';

        if (isset($sch_str) && $sch_str != "" && $sch_str == 'Pending_srch') {
            $sWhere .= " AND payment_details.payment_status ='1'";
        } else if (isset($sch_str) && $sch_str != "" && $sch_str == 'Paid_srch') {
            $sWhere .= " AND payment_details.payment_status ='2'";
        } elseif (isset($get_data['sSearch']) && $get_data['sSearch'] != "") {
            $where = $where . " and (";
            $sWhere = " (" . $where;
            for ($i = 0; $i < count($dt_searchs); $i++) {
                if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true") {
                    $column_search = $dt_searchs[$i];
                    if (strstr($column_search, "as") !== false) {
                        $serch_column = explode(" as ", $column_search);
                        $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    } else {
                        $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    }
                }
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= '))';
        }
        // search all
        for ($i = 0; $i < count($dt_searchs); $i++) {
            if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true" && $get_data['sSearch_' . $i] != '') {
                $column_search = $dt_searchs[$i];
                if (strstr($column_search, "as") !== false) {
                    if ($sWhere == "") {
                        $sWhere = $where;
                    } else {
                        $sWhere .= " AND ";
                    }
                    $serch_column = explode(" as ", $column_search);
                    $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                } else {
                    $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                }
            }
        }

        $dt_query = $this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $dt_columns)), false);
        $dt_query = $this->db->from($dt_table);

        $this->db->join('users', 'payment_details.pay_user = users.user_id', 'inner');
        $this->db->join('function_catering', 'payment_details. pay_fc_id = function_catering.fc_id', 'inner');
        // $this->db->join('voucher_logs', 'payment_details.pay_id = voucher_logs.v_log_id', 'inner');
        $this->db->join('voucher', 'payment_details.voucher_id  = voucher.id', 'left');

        $this->db->where($sWhere, null, false);
        $dt_result = $this->db->get() or die('MySQL Error: ' . $this->db->_error_number());
        // echo '<pre>'. $this->db->last_query(); die;

        $dt_filtered_total = $this->db->query('SELECT FOUND_ROWS() as count;')->row()->count;
        $dt_total = $this->db->count_all($dt_table);

        $output = array(
            "draw" => intval($get_data['sEcho']),
            "recordsTotal" => $dt_total,
            "recordsFiltered" => $dt_filtered_total,
            "data" => array()
        );
        $i = 1;

        foreach ($dt_result->result() as $payment_details) {
            $row = array();
            $row[] = $payment_details->user_firstname . ' ' . $payment_details->user_lastname;
            //$row[] = $payment_details->pay_txn_id;
            $row[] = $payment_details->fc_business_name;
            ;
            $row[] = $payment_details->pay_total_amount;
            $row[] = $payment_details->total_amount;
            $row[] = $payment_details->voucher_code;
            if ($payment_details->payment_method == 1) {
                $row[] = "Stripe";
            } elseif ($payment_details->payment_method == 2) {
                $row[] = "Pay by account";
            } elseif ($payment_details->payment_method == 3) {
                $row[] = "Pay by voucher";
            } elseif ($payment_details->payment_method == 0) {
                $row[] = "";
            } else {
                $row[] = "N/A";
            }

            if ($payment_details->payment_status == 1) {
                $row[] = "Pending";
            } elseif ($payment_details->payment_status == 0) {
                $row[] = "";
            } elseif ($payment_details->payment_status == 2) {
                $row[] = "Paid";
            } else {
                $row[] = "N/A";
            }

            $row[] = date('d-m-Y', strtotime($payment_details->pay_created_on));
            $url = site_url("admin/payment_details_edit/");
            if (empty($payment_details->pay_txn_id) && $payment_details->payment_status == 1) {
                $row[] = '<a data-id="' . $payment_details->pay_id . '"  class="btn btn-primary pop_edit edit_but" href="javascript:;" onclick="editPaymentDetails(' . $payment_details->pay_id . ')"><i class="fa fa-pencil"></i>Add Transaction</a> <a data-id="' . $payment_details->pay_id . '"  class="btn btn-primary pop_view edit_but" href="javascript:;" onclick="get_payment_detail(' . $payment_details->pay_id . ')"><i class= "fa fa-eye" aria-hidden="true"></i>Details view</a>';
            }
            $row[] = '<a data-id="' . $payment_details->pay_id . '"  class="btn btn-primary pop_view edit_but" href="javascript:;" onclick="get_payment_detail(' . $payment_details->pay_id . ')"><i class= "fa fa-eye" aria-hidden="true"></i>Details view</a>';
            $data[] = $row;
            $output['aaData'][] = $row;
        }
        return json_encode($output);
    }

    public function users_ajax_list() {
        $user_data = $this->session->all_userdata();
        $get_data = $this->input->get(NULL, TRUE);

        $dt_columns = array('users.user_id', 'users.user_email', 'users.user_business_name', 'users.user_abn', 'users.user_firstname', 'users.user_lastname', 'users.user_phone_no', 'users.user_city', 'users.user_suburb', 'users.user_address', 'users.user_state', 'users.user_postcode', 'users.user_country', 'users.user_status', 'users.is_registration', 'users.is_deleted');

        $dt_searchs = array('users.user_id', 'users.user_email', 'users.user_business_name', 'users.user_abn', 'users.user_firstname', 'users.user_lastname', 'users.user_phone_no', 'users.user_city', 'users.user_suburb', 'users.user_address', 'users.user_state', 'users.user_postcode', 'users.user_country', 'users.user_status', 'users.is_registration', 'users.is_deleted');


        $dt_table = "users";

        // $where = 'fc.fc_status NOT IN(2,5)';

        $where = "1=1";


        //Pagination
        if (isset($get_data['iDisplayStart']) && $get_data['iDisplayLength'] != '-1') {
            $this->db->limit(intVal($get_data['iDisplayLength']), intVal($get_data['iDisplayStart']));
        }
        //Sorting
        if (isset($get_data['iSortCol_0'])) {
            for ($i = 0; $i < intval($get_data['iSortingCols']); $i++) {
                if ($get_data['bSortable_' . intval($get_data['iSortCol_' . $i])] == "true") {
                    $sort_column = $dt_searchs[intval($get_data['iSortCol_' . $i])];
                    if (strstr($sort_column, "as") !== false) {
                        $temp_sort_column = explode(" as ", $sort_column);
                        $this->db->order_by($temp_sort_column[$i], ($get_data['sSortDir_' . $i] === 'asc' ? 'ASC' : 'DESC'));
                    } else {
                        $this->db->order_by($sort_column, ($get_data['sSortDir_' . $i] === 'asc' ? 'ASC' : 'DESC'));
                    }
                }
            }
        }

        // search        
        $sWhere = $where;

        $sch_str = isset($get_data['is_registration']) ? $get_data['is_registration'] : '';

        if (isset($sch_str) && $sch_str != "" && $sch_str == 'web_srch') {
            $sWhere .= " AND users.is_registration ='0'";
        }

        if (isset($sch_str) && $sch_str != "" && $sch_str == 'admin_srch') {
            $sWhere .= " AND users.is_registration ='1'";
        }


        #echo $sWhere;
        if (isset($get_data['sSearch']) && $get_data['sSearch'] != "") {
            $where = $where . " and (";
            $sWhere = " (" . $where;
            for ($i = 0; $i < count($dt_searchs); $i++) {
                if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true") {
                    $column_search = $dt_searchs[$i];
                    if (strstr($column_search, "as") !== false) {
                        $serch_column = explode(" as ", $column_search);
                        $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    } else {
                        $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                    }
                }
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= '))';
        }


        // search all
        for ($i = 0; $i < count($dt_searchs); $i++) {
            if (isset($get_data['bSearchable_' . $i]) && $get_data['bSearchable_' . $i] == "true" && $get_data['sSearch_' . $i] != '') {
                $column_search = $dt_searchs[$i];
                if (strstr($column_search, "as") !== false) {
                    if ($sWhere == "") {
                        $sWhere = $where;
                    } else {
                        $sWhere .= " AND ";
                    }
                    $serch_column = explode(" as ", $column_search);
                    $sWhere .= $serch_column[0] . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                } else {
                    $sWhere .= $column_search . " LIKE '%" . $this->db->escape_like_str($get_data['sSearch']) . "%' OR ";
                }
            }
        }

        $dt_query = $this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $dt_columns)), false);
        $dt_query = $this->db->from($dt_table);
        $this->db->where($sWhere, null, false);
        $dt_result = $this->db->get() or die('MySQL Error: ' . $this->db->_error_number());
        // echo '<pre>'. $this->db->last_query(); die;

        $dt_filtered_total = $this->db->query('SELECT FOUND_ROWS() as count;')->row()->count;
        $dt_total = $this->db->count_all($dt_table);

        $output = array(
            "draw" => intval($get_data['sEcho']),
            "recordsTotal" => $dt_total,
            "recordsFiltered" => $dt_filtered_total,
            "data" => array()
        );
        $i = 1;

        foreach ($dt_result->result() as $users) {


            $row = array();
            $row[] = $users->user_firstname . ' ' . $users->user_lastname;
            $row[] = $users->user_email;
            $row[] = $users->user_phone_no;
            if ($users->is_registration == 1) {
                $row[] = "Admin";
            }
            if ($users->is_registration == 0) {
                $row[] = "Web";
            }

            if ($users->is_deleted == 0) {
                $url = site_url('admin/edit_user/');
                $row[] = '<a data-id="' . $users->user_id . '" class="btn btn-primary pop_edit edit_but" href=" ' . $url . $users->user_id . '" ><i class="fa fa-pencil"></i>Edit</a><a  data-id="' . $users->user_id . '" class="btn btn-primary change_password"><i class="fa fa-key"></i>Change Password</a> <a class="btn btn-primary  new_pop" href="javascript:;"  onclick="ArchiveFnc(' . $users->user_id . ')" ><i class="fa fa-archive"></i>Archive</a>';
            } else {
                $row[] = 'Archived <a class="btn btn-primary active_pop" href="javascript:;"  onclick="ActiveFnc(' . $users->user_id . ')" ><i class="fa fa-thumbs-up" aria-hidden="true"></i>Active User</a>';
            }
            $data[] = $row;
            $output['aaData'][] = $row;
        }
        return json_encode($output);
    }

}
