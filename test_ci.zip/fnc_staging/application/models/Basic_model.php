<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Basic_model extends CI_Model {

    public function __construct()
    {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();    // Load database
    }
    
    // Function for getting records from table with where condition
    function get_record_where($table, $column = '', $where = '') {
        if ($column != '') {
            $this->db->select($column);
        } else {
            $this->db->select('*');
        }
        $this->db->from($table);
        if ($where != '') {
            $this->db->where($where);
        }
        $query = $this->db->get();
        return $query->result();
    }
    
    // Function for getting records from table with where condition and order by
    function get_record_where_orderby($table, $column = '', $where = '', $orderby = '', $direction = 'ASC') {
        if ($column != '') {
            $this->db->select($column);
        } else {
            $this->db->select('*');
        }
        $this->db->from($table);
        if ($where != '') {
            $this->db->where($where);
        }
        if($orderby != ''){
            $this->db->order_by($orderby, $direction);
        }
        
        $query = $this->db->get();
        return $query->result();
    }
    
    // Function for inserting records
    function insert_records($table, $data, $multiple = FALSE){
        if($multiple){
            $this->db->insert_batch($table, $data);
        } else {
            $this->db->insert($table, $data);
        }
        
        return $this->db->insert_id();
    }
    
    // Function for updating records
    function update_records($table, $data, $where) {
        $this->db->where($where);
        $this->db->update($table, $data);
        return $this->db->affected_rows();
    }
    
    // Function for deleting records
    function delete_records($table, $where) {
        $this->db->delete($table, $where);
        if (!$this->db->affected_rows()) {
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    // Function for getting records by joining tables
    function get_record_join_tables($table, $where = '', $column = '', $join = '', $like = '', $or_like = '', $orderby = '', $direction = 'ASC', $join_type = 'inner', $groupby = '') {
        if ($column != '') {
            $this->db->select($column);
        } else {
            $this->db->select('*');
        }
        $this->db->from($table);
        
        if ($join != '') {
            foreach ($join as $tables => $condition) {
                $this->db->join($tables, $condition, $join_type);
            }
        }
        
        if ($where != '') {
            $this->db->where($where);
        }
        
        if($like != ''){
            foreach ($like as $field => $value) {
                $this->db->like($field, $value);
            }
        }
        
        if($or_like != ''){
            foreach ($or_like as $field => $value) {
                $this->db->or_like($field, $value);
            }
        }
        
        if ($groupby != '') {
            $this->db->group_by($groupby);
        }
        
        if($orderby != ''){
            $this->db->order_by($orderby, $direction);
        }
        
        $query = $this->db->get();
        return $query->result();
    }
    
    // Function to get records with job and group by
    function get_record_join_tables_groupby($table, $where = '', $column = '*', $join = '', $groupby = '', $orderby = '', $direction = 'ASC') {
        $this->db->select($column);
        $this->db->from($table);

        if ($join != '') {
            foreach ($join as $tables => $condition) {
                $this->db->join($tables, $condition);
            }
        }

        if ($where != '') {
            $this->db->where($where);
        }

        if ($groupby != '') {
            $this->db->group_by($groupby);
        }
        
        if($orderby != ''){
            $this->db->order_by($orderby, $direction);
        }

        $query = $this->db->get();
        return $query->result();
    }

    public function get_row($table_name='', $id_array=array(),$columns=array())
    {
        if(!empty($columns)):
            $all_columns = implode(",", $columns);
            $this->db->select($all_columns);
        endif; 
        if(!empty($id_array)):      
            foreach ($id_array as $key => $value){
                $this->db->where($key, $value);
            }
        endif;
        $query=$this->db->get($table_name);

            //echo last_query();
        if($query->num_rows()>0)
            return $query->row();
        else
            return FALSE;
    }

}

