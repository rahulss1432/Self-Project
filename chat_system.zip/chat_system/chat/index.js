var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', function(socket){
  console.log('a user connected');
	socket.on('send-message',function(msg){
		io.sockets.emit('show-message',msg);
	});

	socket.on('typing',function(data){
		console.log(data);
		io.sockets.emit('show-typing',data);
	});	

	socket.on('stop-typing',function(data){
		io.sockets.emit('hide-typing',data);
	});		

});

io.on('disconnect', function(){
    console.log('user disconnected');
  });

http.listen(3000, function(){
  console.log('listening on *:3000');
});
