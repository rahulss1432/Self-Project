@extends('layouts.app')

@section('content')
  <div class="main-section">
    <div class="head-section">
      <div class="headLeft-section">
        <div class="headLeft-sub">
          <form method="post" action="javascript:void(0)" id="searchUser"  onSubmit="getRecentlist()">
            <input type="text" id="search" name="search" placeholder="Search...">
            <button type="submit"> Search </button>
        </form>
        </div>
      </div>
      <div class="headRight-section">
        <div class="headRight-sub">
          <h3><span id="userName"></span></h3>
          <span id="userTyping" style="display:none"> is typing....</span>
        </div>
      </div>
    </div>
    <div class="body-section">
      <div class="left-section" data-mcs-theme="minimal-dark" id="divRecentUsers">
        <!---recent chatted users listing-->
      </div>
      <div class="right-section">
        <div class="message" id="userMessages" data-mcs-theme="minimal-dark">
        </div>
        <div class="right-section-bottom" id="sendForm">
          <form method="post" action="javascript:void(0)" id="fromSendMessage" onSubmit="sendMessage()">
<!--             <div class="upload-btn">
                <button class="btn"><i class="fa fa-photo"></i></button>
                <input type="file" name="myfile" />
            </div> -->
              {{csrf_field()}}
            <input type="text" name="message" id="message" onkeydown='showTyping()' onkeyup='hideTyping()' placeholder="type here...">
            <input type="hidden" name="from_id" id="fromId" value="{{\Auth::user()->id}}">            
            <input type="hidden" name="to_id" id="toId">                        
            <button class="btn-send btn btn-primary" type="submit">Send</button>
          </form>
        </div>
      </div>
    </div>
  </div>

<script src="http://localhost:3000/socket.io/socket.io.js"></script>
<script>
 socket = io.connect('http://localhost:3000');
$(document).ready(function(){
    getRecentlist();
});

function showTyping(){
  var fromId = $('#fromId').val();
  var toId = $('#toId').val();  
  socket.emit('typing',{from_id:fromId , to_id:toId});
}

socket.on('show-typing',function(data){
  // $('#userTyping').show();
  if(data.to_id == "{{Auth::user()->id}}"){
    $('#listUserTyping_'+data.from_id).show();        
  }
});


function hideTyping(){
  var fromId = $('#fromId').val();
  var toId = $('#toId').val();    
  socket.emit('stop-typing',{from_id:fromId ,  to_id : toId}); 
}

socket.on('hide-typing',function(data){
  // $('#userTyping').hide();
  if(data.to_id == "{{Auth::user()->id}}"){  
   $('#listUserTyping_'+data.from_id).hide();
  }    
})


function getRecentlist(){
  var search = $('#search').val();
 $.ajax({
    url:"{{url('get-recent-list')}}",
    type : 'POST',
    data : {'_token':"{{csrf_token()}}",'search':search},
    success: function(data){
      $('#divRecentUsers').html(data.html);
      $('#divRecentUsers').mCustomScrollbar();
    }});  
}

function getUserMessges(id){
 $.ajax({
    url:"{{url('get-user-messages')}}/"+id,
    type : 'GET',
    success: function(data){
      $('#userMessages').html(data.html);
      $('#userMessages').mCustomScrollbar();
    }});  
}

function sendMessage(){
 $.ajax({
    url:"{{url('save-chat')}}",
    type : 'POST',
    data: $('#fromSendMessage').serializeArray(),
    success: function(response){
      if(response.success){
        socket.emit('send-message',response);
         $('#message').val('');             
       }else{
          console.log(response.message);
       }

     }
   });    
}

  socket.on('show-message',function(message){
    if(message.from_id == "{{Auth::user()->id}}"){
          var msg =  $(`<li class="msg-right">
          <div class="msg-left-sub">
            <img src="{{url('public/images/user.png')}}">
            <div class="msg-desc">
                `+message.message+`
            </div>
            <small>{{date('d M Y h:i:A')}}</small>
          </div>
        </li>`);        
        }else{  
        var msg = $(`<li class="msg-left">
            <div class="msg-left-sub">
              <img src="{{url('public/images/user.png')}}">
              <div class="msg-desc">
                  `+message.message+`
              </div>
              <small>{{date('d M Y h:i:A')}}</small>
            </div>
          </li>`);
        }
        $('.noRecord').hide();
        $('#chatList').find('ul').append(msg);
  });    
</script>
@endsection
