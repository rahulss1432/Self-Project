  <ul>
    @if($recentUsers->count() > 0)
    @foreach($recentUsers as $user)
      <li class="li-user" id="liUser_{{$user->id}}" onClick='setUser("{{$user->id}}","{{$user->name}}")'>
        <div class="chatList">
          <div class="img">
            <img src="{{url('public/images/user.png')}}">
          </div>
          <div class="desc">
            <small class="time">4 day</small>
            <h5>{{$user->name}}</h5>
            <small>mesage</small>
            <span id="listUserTyping_{{$user->id}}" style="display:none"> is typing....</span>
          </div>
        </div>
      </li>
      @endforeach
    @else
    <li><span class="alert alert-denger"> No Record Found. </span></li>
    @endif  
  </ul>

  <script>
  function setUser(id,name) {    
    $('.li-user').removeClass('active');
    $('#liUser_'+id).addClass('active');
    $('#toId').val(id);        
    $('#userName').text(name);
    $('#message').val('');
    getUserMessges(id);
  }


  </script>