  <ul>
    @if($messages->count() > 0)
    @foreach($messages as $message)
      @if($message->from_id != \Auth::user()->id)
      <li class="msg-left">
        <div class="msg-left-sub">
          <img src="{{url('public/images/user.png')}}">
          <div class="msg-desc">
              {{$message->message}}
          </div>
          <small>{{date('d M Y h:i:A',strtotime($message->created_at))}}</small>
        </div>
      </li>
      @else
      <li class="msg-right">
        <div class="msg-left-sub">
          <img src="{{url('public/images/user.png')}}">
          <div class="msg-desc">
              {{$message->message}}
          </div>
          <small>{{date('d M Y h:i:A',strtotime($message->created_at))}}</small>
        </div>
      </li>
      @endif
    @endforeach
    @else
    <li class="alert alert-danger">No record found.</li>            
    @endif
    <!-- <li class="msg-day"><small>Wednesday</small></li> -->
  </ul>