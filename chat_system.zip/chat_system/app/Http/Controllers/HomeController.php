<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Message;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }

    public function getRecentList(Request $request){
        $recentUsers = Message::getRecentUser($request->all());
        $html = View::make('chat._recent_user_list',compact('recentUsers'))->render();
        return Response::json(['html'=> $html]);
    }

    public function getUserMessages($id){
        $messages = Message::getMessageById($id);        
        $html = View::make('chat._chats',compact('messages'))->render();
        return Response::json(['html'=> $html]);
    }    
    

    public function saveChat(Request $request){
        return Message::saveChat($request->all());
    }    


}
