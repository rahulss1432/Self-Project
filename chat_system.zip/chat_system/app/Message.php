<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Response;
use App\User;	
class Message extends Model
{

	public function fromUser(){
		return $this->belongsTo('App\User','from_id');
	}

	public static function getMessageById($id){		
		$authId = \Auth::user()->id;
		return Message::where(function($q) use($authId,$id){
			$q->where(['from_id'=>$authId,'to_id'=>$id]);	
		})->orWhere(function($q1) use($authId,$id){
			$q1->where(['to_id'=>$authId,'from_id'=>$id]);	
		})->get();
	}

	public static function getRecentUser($post){
	    $authId = \Auth::user()->id;
		$query =  User::where('id','!=',$authId);
		if(isset($post['search'])){
			$query->where('name','like','%'.$post['search'].'%');
		}
		return $query->get();	
	}

	public static  function saveChat($post){
		try {
			$message =  new Message();
			$message->from_id = $post['from_id'];
			$message->to_id = $post['to_id'];		
			$message->message = $post['message'];				
			$message->save();									
	        return Response::json(['success' => true,'from_id'=> $post['from_id'] ,'to_id'=> $post['to_id'] , 'message'=> $post['message']]);		
		} catch (\Exception $e) {
	        return Response::json(['success' => false,'message'=> $e->getMessage()]);		
		}

	}

	public static function getMessage(){
		
	}
}
