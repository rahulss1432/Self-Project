<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RagisterController extends CI_Controller {
	function __construct()
	{
	  parent::__construct();
	}
	public function index()
	{
		redirect('RagisterController/register');
	}
	
	public function register()
	{
		$this->load->view('header');
		$this->load->view('register');
	}
}
