<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller {
	function __construct()
	{
	  parent::__construct();
	}
	public function index()
	{
		redirect('LoginController/login');
	}
	
	public function login()
	{
		$this->load->view('header');
		$this->load->view('login');
	}
}
