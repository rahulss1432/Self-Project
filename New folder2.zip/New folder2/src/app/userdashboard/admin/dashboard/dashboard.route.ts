﻿import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.Component';
import {dashboardModule } from './dashboard.module';

const Dashboard_ROUTE: Routes = [
  {
    path: '', component: DashboardComponent, children: [
       { path: '', component: DashboardComponent  },
    
   

    ]
  }
];

export const dashboardRouting = RouterModule.forChild(Dashboard_ROUTE);
