import { NgModule } from '@angular/core';
import { dashboardRouting } from './dashboard.route';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
    imports: [
        dashboardRouting,
        FormsModule,
        ReactiveFormsModule,
    ],
    declarations: [

    ]
})
export class dashboardModule { }
