import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { MessageService } from '../../../shared/service/message.service';
import { UserService } from '../../../shared/service/user.service';
import { ToastrService } from 'ngx-toastr';
import * as $ from "jquery";
import { AlertService } from 'src/app/shared/component/confirm-box/alert.service';/* confirm box service */
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  display = 'none';
  sendMsgForm: FormGroup;
  errorClass = 'red';
  loading: boolean;
  disabled: boolean;
  messageList: any = [];
  user: any = {};
  userId: any;
  type: any;
  msgId: any;
  userEmail = [];
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  submitted = false;
  page = 1;
  total: number;
  query = "";
  perPage: number;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private userService: UserService,
    private activatedRoute: ActivatedRoute,
    private messsageService: MessageService,
    private toastrService: ToastrService,
    private alertService: AlertService
  ) { }

  ngOnInit() {
    this.disabled = false;
    this.messsageService.getUserEmails().subscribe(data => {
      if (data['success'] == true) {
        this.userEmail = data.data;
        this.dropdownList = this.userEmail;
        //  console.log(this.userEmail);

      }
    });
    //  this.dropdownList = [
    //   { item_id: 1, item_text: 'Mumbai' },
    //   { item_id: 2, item_text: 'Bangaluru' },
    //   { item_id: 3, item_text: 'Pune' },
    //   { item_id: 4, item_text: 'Navsari' },
    //   { item_id: 5, item_text: 'New Delhi' }
    // ];
    this.selectedItems = [

    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };


    this.userService.getUserInformationByApi().subscribe(data => {
      if (data['success'] == true) {
        this.user = data.data;
        this.userId = this.user.id;
        this.getmessages(this.userId, 'entrance', this.page);

      }
    });

    this.sendMsgForm = this.fb.group({
      email: [''],
      subject: ['', Validators.required],
      message: ['', Validators.required],

    });

  }
  get check() { return this.sendMsgForm.controls; }

  getmessages(userId: any, type: any, page: number) {
    // console.log(page);
    this.messsageService.getMessages(userId, type, page).subscribe(res => {
      if (res['success'] == true) {
        this.messageList = res.data.data;
        this.perPage = res.data.per_page;
        this.total = res.data.total;
        this.page = page;
      } else {
        this.toastrService.error(res['message'], 'Group');
        this.router.navigate(['/admin']);
      }
    });
  }
  onItemSelect(item: any) {
    // console.log(item);
  }
  onSelectAll(items: any) {
    // console.log(items);
  }
  getMsg(selectedTab) {
    if (selectedTab.nextId == 'ngb-tab-0') {
      this.type = 'entrance';
    }
    if (selectedTab.nextId == 'ngb-tab-1') {
      this.type = 'exit';
    }
    if (selectedTab.nextId == 'ngb-tab-2') {
      this.type = 'favourite';
    }
    if (selectedTab.nextId == 'ngb-tab-3') {
      this.type = 'deleted';
    }
    this.getmessages(this.userId, this.type, 1);
  }
  mark_unfav(msgId) {
    this.messsageService.updateFavMessages(msgId).subscribe(res => {
      if (res['success'] == true) {
        this.toastrService.success(res['message'], 'Message');
        location.reload();

      } else {
        this.toastrService.error(res['message'], 'Message');
        this.router.navigate(['/admin']);
      }
    });

  }
  delete_message() {
    var id: any = [];
    $.each($("input[class='checkboxid']:checked"), function () {
      id.push($(this).val());
    });
    //  console.log(id);
    if (id != '') {
      this.alertService.confirmThis('Are you sure.! do you want to delete this messages', () => {
        // ACTION: Do this If user says YES
        this.messsageService.deletemessages(id).subscribe(res => {
          if (res['success'] == true) {
            this.toastrService.success(res['message'], 'Message');
            location.reload();
          } else {
            this.toastrService.error(res['message'], 'Message');
            this.router.navigate(['/admin']);
          }
        });
      }, function () {
        // ACTION: Do this If user says NO
      });
    } else {
      this.toastrService.error('Please select message First');
    }


  }
  sendMsg(): void {
    this.submitted = true;
    if (this.sendMsgForm.invalid) {
      return;
    }
    this.loading = true;
    this.disabled = true;
    this.messsageService.sendmessages(this.sendMsgForm.value).subscribe(res => {
      if (res['success'] == true) {
        this.loading = false;
        this.toastrService.success(res['message'], 'Message');
        location.reload();
      } else {
        this.toastrService.error(res['message'], 'Message');
        this.router.navigate(['/admin']);
      }
    });

  }
  open() {
    this.display = 'block';
  }
  closeModal() {
    this.display = 'none';
  }
}
