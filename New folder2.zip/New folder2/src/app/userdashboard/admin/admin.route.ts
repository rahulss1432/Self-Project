﻿import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin.Component';
import { DashboardComponent } from './dashboard/dashboard.component';
const Admin_ROUTE: Routes = [
  {
    path: '', component: AdminComponent, children: [
     { path: '', component: DashboardComponent  },
     
     ]
  }
];

export const adminRouting = RouterModule.forChild(Admin_ROUTE);
