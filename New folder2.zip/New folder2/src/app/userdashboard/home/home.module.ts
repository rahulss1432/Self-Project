﻿import { HomeComponent } from './home.component';
import { homeRouting } from './home.routes';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AccountComponent } from './account/account.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { FormsModule }    from '@angular/forms';

@NgModule({
  declarations: [
    HomeComponent,
    AccountComponent,
    DashboardComponent,
    EditprofileComponent
 ],
  imports: [CommonModule,RouterModule,FormsModule,homeRouting],
  providers: []
})

export class HomeModule { }
