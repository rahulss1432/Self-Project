import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../shared/service/auth.service';
import { FormBuilder, NgForm, FormGroup, Validators } from '@angular/forms';
import { ToursService } from '../../../shared/service/tour.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { first } from 'rxjs/operators';
import { UserService } from '../../../shared/service/user.service';

@Component({
  selector: 'app-editprofile',
  templateUrl: './editprofile.component.html',
  styleUrls: ['./editprofile.component.css']
})
export class EditprofileComponent implements OnInit {

  constructor(private authService: AuthenticationService, private userService: UserService, private formBuilder: FormBuilder,
    private tourService: ToursService,
    private router: Router,
    private toastrService: ToastrService,
  ) { }
  loading = false;
  userData: any = {};
  selectedFile: any;
  profile_picture: any;

  ngOnInit() {
    this.userService.getUserInformationByApi().subscribe(data => {
      if (data['success'] == true) {
        this.userData = data.data
      } else {
        this.toastrService.error('Token Expired');
      }
    });
  }

  uploadUserImage(event) {
      this.selectedFile = event.target.files[0]
      this.profile_picture = this.selectedFile;
  }

  onSubmit(frm: NgForm) {
    this.loading = true;
    const uploadData = new FormData();
    uploadData.append('profile_picture', this.profile_picture);
    uploadData.append('first_name', frm.value.first_name);
    uploadData.append('last_name', frm.value.last_name);
    uploadData.append('user_name', frm.value.user_name);
    uploadData.append('address', frm.value.address);
    uploadData.append('user_id', frm.value.user_id);
    this.userService.editProfile(uploadData)
      .pipe(first())
      .subscribe(
        data => {
          if (data['success'] == true) {
            this.loading = false;
           location.reload();
            this.toastrService.success('Profile updated successfully');
      } else {
            this.loading = false;
            this.toastrService.error('Something went wrong ');
          }
        });
  }

}
