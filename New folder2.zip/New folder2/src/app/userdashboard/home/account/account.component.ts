import { Component, OnInit } from '@angular/core';
import { FormBuilder, NgForm, FormGroup, Validators  } from '@angular/forms';
import { AuthenticationService } from '../../../shared/service/auth.service';
import { UserService } from '../../../shared/service/user.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {

  constructor(private authService: AuthenticationService, private userService: UserService, private toastrService: ToastrService) { }

  userData: any = {};

  ngOnInit() {
    this.userService.getUserInformationByApi().subscribe(data => {
      if (data['success'] == true) {
        this.userData = data.data
      } else {
        this.toastrService.error('Token Expired');
      }
    });
  }

}
