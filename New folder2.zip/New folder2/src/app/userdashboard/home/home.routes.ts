import { HomeComponent } from './home.component';
import { Routes, RouterModule } from '@angular/router';
import { AccountComponent } from './account/account.component';
import { DashboardComponent } from './dashboard/dashboard.component'
import { EditprofileComponent } from './editprofile/editprofile.component';
const home_ROUTE: Routes = [
{
    path: '', component: HomeComponent , children: [
      { path: '', component: DashboardComponent  },
      { path: 'user-account', component: AccountComponent  },
      { path: 'edit-user-profile', component: EditprofileComponent  },
    ]
  }
  ,
]

export const homeRouting = RouterModule.forChild(home_ROUTE);
