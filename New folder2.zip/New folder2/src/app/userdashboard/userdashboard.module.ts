import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { userRouting } from './userdashboard.route';
import { UserdashboardComponent } from './userdashboard.Component';
import { HeaderComponent } from '../shared/component/header/header.component';
import { SidebarComponent } from '../shared/component/sidebar/sidebar.component';
import { FooterbarComponent } from '../shared/component/footerbar/footerbar.component';
@NgModule({
  imports: [
    CommonModule,
    userRouting
  ],
  declarations: [
    UserdashboardComponent,
    HeaderComponent,
    SidebarComponent,
    FooterbarComponent,
    ]
})
export class UserdashboardModule { }
