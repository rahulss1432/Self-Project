﻿import { Routes, RouterModule } from '@angular/router';
import { UserdashboardComponent } from './userdashboard.Component';
import { UserdashboardModule } from './userdashboard.module';
import { AuthGuard } from '../auth/_guards';
const User_ROUTE: Routes = [
  {
    path: '', component: UserdashboardComponent, children: [

      { path: 'home', loadChildren: './home/home.module#HomeModule', canActivate: [AuthGuard] },
      { path: 'tours', loadChildren: './tours/tours.module#TourModule', canActivate: [AuthGuard] },
      { path: 'group', loadChildren: './group/group.module#GroupModule', canActivate: [AuthGuard] },
      { path: 'manage', loadChildren: './group/manage/manage.module#ManageModule', canActivate: [AuthGuard]},
      { path: 'admin', loadChildren: './admin/admin.module#AdminModule', canActivate: [AuthGuard] },
    ]
  }
];

export const userRouting = RouterModule.forChild(User_ROUTE);
