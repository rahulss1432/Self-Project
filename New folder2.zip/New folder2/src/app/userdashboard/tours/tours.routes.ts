import { ToursComponent } from './tours.component';
import { Routes, RouterModule } from '@angular/router';
import { TourslistComponent } from './tourslist/tourslist.component';
import { ToursaddComponent } from './toursadd/toursadd.component';
import { TourPlanComponent } from './tour-plan/tour-plan.component';

const tour_ROUTE: Routes = [
{
    path: '', component: ToursComponent , children: [
      { path: '', component: TourslistComponent  },
      { path: 'list', component: TourslistComponent  },
      { path: 'add', component: ToursaddComponent  },
      { path: 'edit/:id', component: ToursaddComponent },
      { path: 'group-list/:id', loadChildren: '../group/group.module#GroupModule'},
      { path: 'plan/list', component: TourPlanComponent },
    ]
  }
  ,
]

export const tourRouting = RouterModule.forChild(tour_ROUTE);
