﻿import { ToursComponent } from './tours.component';
import { tourRouting } from './tours.routes';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { TourslistComponent } from './tourslist/tourslist.component';
import { ToursaddComponent } from './toursadd/toursadd.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/module/shared.module';;
import { TourPlanComponent } from './tour-plan/tour-plan.component'
// import { LoaderComponent } from 'src/app/shared/component/loader/Loader.Component';
@NgModule({
  declarations: [
    ToursComponent,
    TourslistComponent,
    ToursaddComponent,
    TourPlanComponent
    
  ],
  imports: [CommonModule,RouterModule,tourRouting,FormsModule,SharedModule,
    ReactiveFormsModule,],
  providers: []
})

export class TourModule { }
