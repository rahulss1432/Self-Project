import { Component, OnInit } from '@angular/core';
import { ToursService } from 'src/app/shared/service/tour.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-tourslist',
  templateUrl: './tourslist.component.html',
  styleUrls: ['./tourslist.component.css']
})
export class TourslistComponent implements OnInit {
tourList: any[] = [];
 loading: boolean;
  constructor(
     private tourService: ToursService,
      private toastrService: ToastrService,
  ) { }

  ngOnInit() {
        this.getTourList();
  }
  getTourList() {
     this.loading = true;
      this.tourService.getTourList()
      .subscribe(
            data => {
            if (data['success'] == true) {
                  this.loading = false;
                  this.tourList = data.data;
            } else {
                  this.toastrService.error('Token Expired');
            }
      });

  }
}
