import { Component, OnInit } from '@angular/core';
import { ToursService } from '../../../shared/service/tour.service';
import { ToastrService } from 'ngx-toastr';
import { ModalService } from '../../../shared/service/modal.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CheckoutService } from '../../../shared/service/checkout.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { MenuService } from "src/app/shared/service/menu.service";
import { Subscription } from "rxjs";
import { OnDestroy } from "@angular/core";
@Component({
  selector: 'app-tour-plan',
  templateUrl: './tour-plan.component.html',
  styleUrls: ['./tour-plan.component.css']
})
export class TourPlanComponent implements OnInit, OnDestroy {
  message: any;
  subscription: Subscription;
  tourList: any[] = [];
  loading: boolean;
  disabled: boolean;
  planList: any;
  checkoutForm: FormGroup;
  submitted = false;
  errorClass = 'red';
  userDetail: any;
  id: number;
  constructor(
    private tourService: ToursService,
    private toastrService: ToastrService,
    private modalService: ModalService,
    private checkoutService: CheckoutService,
    private fb: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private menuservice: MenuService,
  ) { }

  ngOnInit() {
    this.getPlanList();
    this.userDetail = this.checkoutService.fetchStorageData();
    this.id = this.activatedRoute.snapshot.params['id'];
    this.menuservice.sendMessage('open-child', this.id);
    this.checkoutForm = this.fb.group({
      radios: ['', Validators.required],
    });
  }

  get check() { return this.checkoutForm.controls; }

  getPlanList() {
    this.loading = true;
    this.tourService.getPlanList()
      .subscribe(
      data => {
        if (data['success'] == true) {
          this.loading = false;
          this.planList = data.data;
        } else {
          this.toastrService.error('Token Expired');
        }
      });
  }

  open(content) {
    this.modalService.open(content);
  }

  checkout(plan: any) {
    this.submitted = true;
    if (this.checkoutForm.invalid) {
      return;
    }
    this.loading = true;
    this.disabled = true;
    const planReqBody = {
      'user_id': this.userDetail.userData.id,
      'plan_id': plan.id,
      'plan_amount': plan.plan_amount,
      'plan_type': this.checkoutForm.value.radios,
    };
    this.checkoutService.paymentCheckout(planReqBody)
      .pipe(first())
      .subscribe(
      data => {
        if (data['success'] == true) {
          this.loading = false;
          this.router.navigate(['/tours/plan/list']);
          this.toastrService.success('Plan Add successfully');
        } else {
          this.loading = false;
          this.toastrService.error('Something went wrong ');
        }
      });
  }
   ngOnDestroy() {
    this.menuservice.clearMessage();
  }


}
