import { Component, OnInit ,ViewChild} from '@angular/core';
import { FormBuilder, NgForm, FormGroup, Validators  } from '@angular/forms';
import { AppValidations } from 'src/app/shared/validators/app-validations';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { ToursService } from 'src/app/shared/service/tour.service';
@Component({
  selector: 'app-toursadd',
  templateUrl: './toursadd.component.html',
  styleUrls: ['./toursadd.component.css']
})
export class ToursaddComponent implements OnInit {
tourForm: FormGroup;
  errorClass = 'red';
  loading = false;
  model: any = {};
    disabled: boolean = false;
  constructor(
    private formBuilder: FormBuilder,
    private tourService: ToursService,
    private router: Router,
    private toastrService: ToastrService,
  ) { }

  ngOnInit() {
     this.tourForm = this.formBuilder.group({
            name: ['', Validators.required],
        });
  }
   onSubmit(tour: NgForm) {
        this.loading = true;
         this.disabled = true;
          this.tourService.addTours(tour.value.tour_name)
            .pipe(first())
            .subscribe(
            data => {
                 if (data['success'] == true) {
                     this.loading = false;
                     this.router.navigate(['/tours']);
                     this.toastrService.success('Tour Add successfully');
                } else {
                      this.loading = false;
                      this.toastrService.error('Something went wrong ');
                }
            });
    }

}
