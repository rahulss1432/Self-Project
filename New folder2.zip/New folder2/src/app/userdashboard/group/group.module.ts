import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GrouplistComponent } from './grouplist/grouplist.component';
import { GroupaddComponent } from './groupadd/groupadd.component';
import { groupRouting } from 'src/app/userdashboard/group/group.route';
import { GroupComponent } from 'src/app/userdashboard/group/group.component';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { GroupService } from 'src/app/shared/service/group.service';
import { SortablejsModule } from 'angular-sortablejs';
import { FormsModule } from '@angular/forms';
import { FloorplanComponent } from './floorplan/floorplan.component';
import { NgxCropperModule } from 'ngx-cropper';

@NgModule({
  imports: [
    CommonModule,
    groupRouting,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    NgxCropperModule,
           // global settings
    SortablejsModule.forRoot({
      animation: 200,
    }),

  ],
  declarations: [GrouplistComponent, GroupaddComponent, GroupComponent, FloorplanComponent],
  // providers: [GroupService]
})
export class GroupModule {

}
