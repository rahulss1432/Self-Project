import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { GroupService } from '../../../shared/service/group.service';
import { FloorService } from '../../../shared/service/floor.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as $ from "jquery";
import { MenuService } from "src/app/shared/service/menu.service";
import { Subscription } from "rxjs";
import { OnDestroy } from "@angular/core";
import { AlertService } from 'src/app/shared/component/confirm-box/alert.service'; /* confirm box service */
@Component({
  selector: 'app-floorplan',
  templateUrl: './floorplan.component.html',
  styleUrls: ['./floorplan.component.css']
})

export class FloorplanComponent implements OnInit, OnDestroy {
  public ngxCropperConfig: object;
  imageChangedEvent: any = '';
  croppedImage: any = '';
  setArrayForId = [];

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private groupService: GroupService,
    private floorService: FloorService,
    private toastrService: ToastrService,
    private alertService: AlertService,
    private menuservice: MenuService) {
    this.ngxCropperConfig = {
      url: 'http://localhost/property-tour-api/api/add-cropper-image', // image server url
      maxsize: 512000, // image max size, default 500k = 512000bit
      title: 'Apply your image size and position', // edit modal title, this is default
      uploadBtnName: 'Upload Image', // default Upload Image
      uploadBtnClass: null, // default bootstrap styles, btn btn-primary
      cancelBtnName: 'Cancel', // default Cancel
      cancelBtnClass: null, // default bootstrap styles, btn btn-default
      applyBtnName: 'Apply', // default Apply
      applyBtnClass: null, // default bootstrap styles, btn btn-primary
      fdName: 'file', // default 'file', this is  Content-Disposition: form-data; name="file"; filename="fire.jpg"
      aspectRatio: 1 / 1// default 1 / 1, for example: 16 / 9, 4 / 3 ...
    }
  }


  message: any;
  // subscription: Subscription;
  groupList: any[] = [];
  id: any;
  Id:number;
  selectedFile: any;
  ngOnInit() {
    this.id = this.activatedRoute.snapshot.params['id'];
    this.getFloorPlanDetails(this.id);
    this.menuservice.sendMessage('open-child', this.id);
  }

  getFloorPlanDetails(id: any): void {
    this.floorService.getFloorPlanDetails(id).subscribe(res => {
      if (res['success'] == true) {

        this.groupList = res.data;
        // console.log(this.groupList);
      } else {
        this.toastrService.error(res['message'], 'Group');
        this.router.navigate(['/group/']);
      }
    });
  }

  uploadFloorImage(event, groupId) {
    this.selectedFile = event.target.files[0]
    // console.log(this.selectedFile);
    const uploadData = new FormData();
    uploadData.append('floor_image', this.selectedFile);
    uploadData.append('group_id', groupId);
    this.floorService.uploadFloorPlainImage(uploadData).subscribe(res => {
      if (res['success'] == true) {
        this.toastrService.success(res['message'], 'Group');
        location.reload();
      } else {
        this.toastrService.error(res['message'], 'Group');
      }
    });
  }

  deleteFloorPlan(groupId) {
    if (confirm("Are you sure to delete Image?")) {
      this.floorService.deleteFloorPlan(groupId).subscribe(res => {
        if (res['success'] == true) {
          this.toastrService.success(res['message'], 'Group');
          location.reload();
        } else {
          this.toastrService.error(res['message'], 'Group');
        }
      })
    }

  }
  setFloorImage(filename) {
    // console.log(filename);
    $('#floorimg').attr('src', filename);

  }
  ngOnDestroy() {
    this.menuservice.clearMessage();
  }
  
window;callFn = function(Id) {
     this.setArrayForId.push(Id);
      this.Id= this.setArrayForId[1];
     
 }

  // deal callback data
  public onReturnData(data: any) {
    // do you want to do
    let cropperdata = JSON.parse(data);
    const groupId : any  = this.Id;
    const uploadData = new FormData();
    console.log(groupId);
    uploadData.append('name', cropperdata.data.name);
    uploadData.append('filename', cropperdata.data.filename);
    uploadData.append('group_id', groupId);
    this.floorService.uploadFloorPlainImage(uploadData).subscribe(res => {
      if (res['success'] == true) {
        this.toastrService.success(res['message'], 'Group');
        location.reload();
      } else {
        this.toastrService.error(res['message'], 'Group');
      }
      //  Here has three type of messages now
      //  a: `The size is max than ${this.viewConfig.maxsize}, now size is ${currentSize}k`
      //  b: 'The image was sent to server successly'
      //  c: ERROR: When sent to server, something wrong, please check the server url.'
    });
  }
  
}