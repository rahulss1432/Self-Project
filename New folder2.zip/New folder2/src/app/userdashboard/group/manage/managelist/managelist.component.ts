import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, NgZone, ViewChild, AfterViewInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ToursService } from 'src/app/shared/service/tour.service';
import { FormBuilder } from '@angular/forms';
import { MenuService } from "src/app/shared/service/menu.service";
import { Subscription, Observable } from "rxjs";
import { OnDestroy } from "@angular/core";
import { FormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { Address } from '../objects/address';
import * as $ from "jquery";
import { AgmMap } from '@agm/core';

@Component({ selector: 'app-managelist', templateUrl: './managelist.component.html', styleUrls: ['./managelist.component.css'] })
export class ManagelistComponent implements OnInit, OnDestroy, AfterViewInit {
  CategoryId: any = 0;
  selectedTourId: any = 0;
  @ViewChild(AgmMap)
  public agmMap: AgmMap
  // latt = 22.7195687; lngg = 75.85772580000003;
  updateTourSettingForm: FormGroup;
  lat: number;
  lng: number;
  tourList: any[] = [];
  id: any;
  errorClass = 'red';
  loading = false;
  disabled = false;
  tourDetail: any = {};
  tourName: any = {};
  categoryList: any[] = [];

  formatted_address: any = {};
  constructor(
    private formBuilder: FormBuilder,
    private tourService: ToursService,
    private router: Router,
    private toastrService: ToastrService,
    private activatedRoute: ActivatedRoute,
    private menuservice: MenuService,
    private zone: NgZone
  ) {
    this.id = this.activatedRoute.snapshot.params['id'];
    this.getTourDetail(this.id);
    if (navigator) {
      navigator.geolocation.getCurrentPosition(pos => {
        this.lng = +pos.coords.longitude;
        this.lat = +pos.coords.latitude;
        // console.log("navigator");

      });
    }
  }

  public handleAddressChange(address: Address) {
    console.log(address);
    this.lat = address.geometry.location.lat();
    this.lng = address.geometry.location.lng();
    this.formatted_address = address['formatted_address'];

    // Do some stuff
  }

  submitData(tourSettingData: any): void {
    tourSettingData.tour_address = this.formatted_address;
    tourSettingData.latitude = this.lat;
    tourSettingData.longitude = this.lng;
    if (this.updateTourSettingForm.valid) {
      this.disabled = true;
      this.loading = true;
      this.tourService.updateTourSetting(tourSettingData).subscribe(res => {
        if (res['success'] == true) {
          this.toastrService.success(res['message'], 'Tour');
          this.updateTourSettingForm.reset();
          this.router.navigate(['/manage/tour-edit/', this.id]);
          location.reload();
        } else {
          this.toastrService.error(res['message'], 'Tour');
          this.router.navigate(['/manage/tour-edit/', this.id]);
        }
        this.disabled = false;
        this.loading = false;
      });
    } else {
      this.disabled = false;
    }
  }
  ngAfterViewInit() {
    // console.log("After");
  }
  ngOnInit() {
    this.menuservice.sendMessage('open-child', this.id);
    this.getTourList();
    this.updateTourSettingForm = new FormGroup({
      'tour_address': new FormControl(null, [Validators.required]),
      'tour_information': new FormControl(null, [Validators.required]),
      'tour_id': new FormControl(this.id)
    });

    this.getMasterCategoryList();
  }




  getTourDetail(id) {
    this.tourService.getTourDetailById(id).subscribe(
      data => {
        if (data['success'] === true) {
          this.loading = false;
          this.tourDetail = data.data;
          this.lat = parseFloat(this.tourDetail.latitude);
          this.lng = parseFloat(this.tourDetail.longitude);
          this.agmMap.triggerResize();
        }

      });
  }

  getMasterCategoryList() {
    this.tourService.getAllMasterCategoryList().subscribe(
      data => {
        if (data['success'] === true) {
          this.loading = false;
          this.categoryList = data.data;
          // console.log(this.categoryList);
        }

      });
  }

  showTextBox(id: number): void {
    $('#div_' + id).hide();
    $('#form_' + id).show();
  }

  updateTourName(tourId: any, tourSettingData: any) {
    //console.log(tourId);
    this.tourName['tour_name'] = tourSettingData;
    this.tourName['tour_id'] = tourId;
    // console.log(this.tourName);
    this.tourService.updateTourSetting(this.tourName).subscribe(res => {
      if (res['success'] == true) {
        this.toastrService.success(res['message'], 'Tour');
        this.updateTourSettingForm.reset();
        this.router.navigate(['/manage/tour-edit/', this.id]);
        location.reload();
      } else {
        this.toastrService.error(res['message'], 'Tour');
        this.router.navigate(['/manage/tour-edit/', this.id]);
      }
      this.disabled = false;
      this.loading = false;
    });
  }

  ngOnDestroy() {
    this.menuservice.clearMessage();
  }
  getTourList() {
    this.tourService.getTourListwithGroup()
      .subscribe(
      data => {
        if (data['success'] == true) {
          this.tourList = data.data;
          //  console.log(this.tourList);
        } else {
          this.toastrService.error('Token Expired');
        }
      });

  }

  Changed(type: any, id) {
    // if (!id) {
      // if (type == 'tour') {
      //   this.selectedTourId = 0;
      //   this.toastrService.error('Please select tour');
      //   return false;
      // }
      // else {
      //   this.CategoryId = 0;
      //   this.toastrService.error('Please select tour category');
      //   return false;
      // }
    // }
    if (type == 'tour') {
      this.selectedTourId = id;
    }
    if (type == 'tourart') {
      this.CategoryId = id;
      if (this.selectedTourId <= 0) {
        this.toastrService.error('Please select tour first');
        return false;
      }
    }
    if (this.selectedTourId > 0 && this.CategoryId > 0) {
      // console.log(this.selectedTourId + "<= Tour cat=>" + this.CategoryId);
      const tourCategory = new FormData();
      tourCategory.append('tour_id', this.selectedTourId);
      tourCategory.append('category_id', this.CategoryId);
      this.tourService.updateCategory(tourCategory).subscribe(res => {
        if (res['success'] == true) {
          this.toastrService.success(res['message'], 'Category');
          // location.reload();
        } else {
          this.toastrService.error(res['message'], 'Category');
        }
      });
    }
  }


}
