import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageComponent } from './manage.component';
import { ManagelistComponent } from './managelist/managelist.component';
import { manageRouting } from './manage.routes';
import { RouterModule } from '@angular/router';
import { AgmCoreModule } from '@agm/core';
import { GooglePlaceModule } from "ngx-google-places-autocomplete";
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    GooglePlaceModule,
    manageRouting,
    RouterModule,
    AgmCoreModule.forRoot({ apiKey: 'AIzaSyBkRtGTnWRVRxjr9H1OoaSfro-Dd7qKmAk' }),
    ReactiveFormsModule,
    FormsModule
  ],
  declarations: [
    ManageComponent,
    ManagelistComponent,

  ]
})
export class ManageModule { }
