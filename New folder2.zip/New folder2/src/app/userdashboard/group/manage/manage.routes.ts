import { ManageComponent } from './manage.component';
import { Routes, RouterModule } from '@angular/router';
import { ManagelistComponent } from './managelist/managelist.component';

const Manage_ROUTE: Routes = [
{
    path: '', component: ManageComponent , children: [
{
  path: 'tour-edit/:id',
  component: ManagelistComponent
},
    ]
  }
  ,
];

export const manageRouting = RouterModule.forChild(Manage_ROUTE);
