import { Routes, RouterModule } from '@angular/router';
import { GroupComponent } from 'src/app/userdashboard/group/group.component';
import { GrouplistComponent } from 'src/app/userdashboard/group/grouplist/grouplist.component';
import { GroupaddComponent } from 'src/app/userdashboard/group/groupadd/groupadd.component';
import { FloorplanComponent } from './floorplan/floorplan.component';

const groupRoute: Routes = [
    {
        path: '', component: GroupComponent, children: [
            { path: '', component: GrouplistComponent },
            { path: 'add-groups/:id', component: GroupaddComponent },
            { path: 'floor-plans/:id', component: FloorplanComponent },
        ]
    }
]

export const groupRouting = RouterModule.forChild(groupRoute);
