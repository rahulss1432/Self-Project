import { Component, OnInit, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { GroupService } from 'src/app/shared/service/group.service';
import { ToastrService } from 'ngx-toastr';
import { SortablejsOptions } from 'angular-sortablejs';
import { FormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import * as $ from "jquery";
import { MenuService } from "src/app/shared/service/menu.service";
import { Subscription } from "rxjs";
import { OnDestroy } from "@angular/core";
import { AlertService } from 'src/app/shared/component/confirm-box/alert.service';/* confirm box service */
@Component({
  selector: 'app-grouplist',
  templateUrl: './grouplist.component.html',
  styleUrls: ['./grouplist.component.css']
})
export class GrouplistComponent implements OnInit, OnDestroy {
  message: any;
  subscription: Subscription;
  id: number;
  groupList: any[] = [];
  groupImage: any[] = [];
  errorClass = 'red';
  selectedFile: Array<any>;
  name: string;
  constructor(
    private router: Router,
    private _el: ElementRef,
    private activatedRoute: ActivatedRoute,
    private groupService: GroupService,
    private toastrService: ToastrService, private menuservice: MenuService,
    private alertService: AlertService) { }

  ngOnInit() {
    this.id = this.activatedRoute.snapshot.params['id'];
    this.getGroupListById(this.id);
    this.menuservice.sendMessage('open-child', this.id);
  }

  options: SortablejsOptions = {
    onUpdate: () => {
      this.updateList(this.groupList);
      // console.log(this.groupList);

    }

  };
  optionsimage: SortablejsOptions = {
    group: 'normal-group',
    onEnd: () => {
      this.updateGroupImageList(this.groupList);
    },
    onUpdate: () => {
      this.updateImageList(this.groupList);
      // console.log(this.groupList);

    }

  };

  getGroupListById(id: any): void {
    this.groupService.getGroupsById(id).subscribe(res => {
      if (res['success'] == true) {

        this.groupList = res.data;
        this.groupImage = res.data.get_group_images;
        //  console.log(this.groupImage);
        //  console.log(res.data);
        this.router.navigate(['/tours/group-list/', this.id]);
      } else {
        this.toastrService.error(res['message'], 'Group');
        this.router.navigate(['/group/']);
      }
    });
  }

  updateImageList(list): void {
    this.groupService.updateImageList(list).subscribe(res => {
      if (res['success'] == true) {
        this.toastrService.clear();
        this.toastrService.success(res['message'], 'Group');
        this.router.navigate(['/tours/group-list/', this.id]);
      } else {
        this.toastrService.error(res['message'], 'Group');
        this.router.navigate(['/tours/group-list/', this.id]);
      }
    });
  }

  updateGroupImageList(list): void {
    this.groupService.updateGroupImageList(list).subscribe(res => {
      if (res['success'] == true) {
        this.toastrService.clear();
        this.toastrService.success(res['message'], 'Group');
        this.router.navigate(['/tours/group-list/', this.id]);
      } else {
        this.toastrService.error(res['message'], 'Group');
        this.router.navigate(['/tours/group-list/', this.id]);
      }
    });
  }

  updateList(list): void {
    this.groupService.updateGroupList(list).subscribe(res => {
      if (res['success'] == true) {
        this.toastrService.success(res['message'], 'Group');
        this.router.navigate(['/tours/group-list/', this.id]);
      } else {
        this.toastrService.error(res['message'], 'Group');
        this.router.navigate(['/tours/group-list/', this.id]);
      }
    });
  }

  showTextBox(id: number): void {
    $('#div_' + id).hide();
    $('#form_' + id).show();
  }

  /* fucntion for update group name*/

  updateGroupName(groupId: number, name: string) {
    if (name.length > 0) {
      $('#error_' + groupId).hide();
      $('#form_' + groupId).hide();
      this.groupService.updateGroupNameById(groupId, name).subscribe(res => {
        if (res['success'] == true) {
          this.toastrService.success(res['message'], 'Group');
          // this.router.navigate(['/tours/group-list/', this.id]);
        } else {
          this.toastrService.error(res['message'], 'Group');
          this.router.navigate(['/tours/group-list/', this.id]);
        }
        $('#div_' + groupId).show();
        $('#span_' + groupId).html(name);
      });
    } else {
      $('#error_' + groupId).show();
      $('#form_' + groupId).show();
    }
  }

  /* fucntion for delete group*/
  deleteGroup(groupId: number) {
    this.alertService.confirmThis('Are you sure.! do you want to delete this group', () => {
      // ACTION: Do this If user says YES
      this.groupService.deleteGroup(groupId).subscribe(res => {
        if (res['success'] == true) {
          this.toastrService.success(res['message'], 'Group');
          location.reload();
        } else {
          this.toastrService.error(res['message'], 'Group');
        }
      });
    }, function () {
      // ACTION: Do this If user says NO
    });
  }

  /* fucntion for delete group's panaromas*/
  deletePanorama(imageId: number) {
    this.alertService.confirmThis('Are you sure.! do you want to delete this image', () => {
      // ACTION: Do this If user says YES
      this.groupService.deletePanorama(imageId).subscribe(res => {
        if (res['success'] == true) {
          this.toastrService.success(res['message'], 'Group');
          location.reload();
        } else {
          this.toastrService.error(res['message'], 'Group');
        }
      });
    }, function () {
      // ACTION: Do this If user says NO
    });
  }

  onFileChanged(event, groupId) {
    this.selectedFile = event.target.files
    if (this.selectedFile.length <= 10) {
      $('#imgerror_' + groupId).hide();
      // console.log(this.selectedFile);
      const uploadData = new FormData();
      for (let file of this.selectedFile) {
        uploadData.append('filename[]', file, file.name);
        uploadData.append('group_id', groupId);

      }
      this.groupService.uploadGroupFiles(uploadData).subscribe(res => {
        if (res['success'] == true) {
          this.toastrService.success(res['message'], 'Group');
          location.reload();
        } else {
          this.toastrService.error(res['message'], 'Group');
        }
      });
    } else {
      $('#imgerror_' + groupId).show();
    }
  }

  //  getGroupImages(groupId: number): void {
  //     this.groupService.getGroupsByImages(groupId).subscribe(res => {
  //       if (res['success'] == true) {
  //         this.groupImage = res.data;
  //         this.router.navigate(['/tours/group-list/', this.id]);
  //       } else {
  //         this.toastrService.error(res['message'], 'Group');
  //         this.router.navigate(['/group/']);
  //       }
  //     });
  //   }

  ngOnDestroy() {
    this.menuservice.clearMessage();
  }

}
