import { Component, OnInit } from '@angular/core';
import { FormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GroupService } from 'src/app/shared/service/group.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute } from '@angular/router';
import { MenuService } from "src/app/shared/service/menu.service";
import { Subscription } from "rxjs";
import { OnDestroy } from "@angular/core";
@Component({
  selector: 'app-groupadd',
  templateUrl: './groupadd.component.html',
  styleUrls: ['./groupadd.component.css']
})
export class GroupaddComponent implements OnInit,OnDestroy {
  addGroupForm: FormGroup;
  errorClass = 'red';
  loading = false;
  id: number;
  disabled = false;
  // tslint:disable-next-line:max-line-length
  constructor(private router: Router, private groupService: GroupService, private toastrService: ToastrService, private activatedRoute: ActivatedRoute,private menuservice: MenuService) { }
  ngOnInit() {
    this.id = this.activatedRoute.snapshot.params['id'];
    this.addGroupForm = new FormGroup({
      'group_name': new FormControl(null, [Validators.required, Validators.minLength(4)]),
      'tour_id': new FormControl(this.id)
    });
    this.menuservice.sendMessage('open-child',this.id);
  }

  submitData(groupData: any): void {
    if (this.addGroupForm.valid) {      
      this.disabled = true;
    this.loading = true;
      this.groupService.addGroup(groupData).subscribe(res => {
        if (res['success'] == true) {
          this.toastrService.success(res['message'], 'Group');
          this.addGroupForm.reset();
          this.router.navigate(['/tours/group-list/', this.id]);
        } else {
          this.toastrService.error(res['message'], 'Group');
          this.router.navigate(['/group/add']);
        }
        this.disabled = false;        
        this.loading = false;
      });
    } else {
      this.disabled = false;
    }
  }

    ngOnDestroy() {
  this.menuservice.clearMessage();
  }
}
