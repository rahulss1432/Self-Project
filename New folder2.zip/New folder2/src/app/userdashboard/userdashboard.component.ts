﻿import { Component, ViewChild, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'hb-userdashboard',
  templateUrl: './userdashboard.component.html',
  styleUrls: ['./userdashboard.component.css']
})
export class UserdashboardComponent implements OnInit {
  header_title = 'Dashboard';
  @ViewChild('content') content;
  constructor(private router: Router) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        // console.log(event.urlAfterRedirects);
        this.setHeading(event.urlAfterRedirects);
      }
    });

  }


  ngOnInit() {

  }

  setHeading(url: string) {
    switch (url) {
      case '/home':
        this.header_title = 'Home';
        break;
    
    }
  }
}
