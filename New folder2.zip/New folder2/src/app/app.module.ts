import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './auth/login';
import { routing } from './app.routing';
import { RegisterComponent } from './auth/register';
import { AuthenticationService } from 'src/app/shared/service/auth.service';
import { HttpClientModule } from '@angular/common/http';
import { AuthGuard } from './auth/_guards';
import { SecurityService } from './shared/service/security.service';

import {
    SocialLoginModule,
    AuthServiceConfig,
    GoogleLoginProvider,
    FacebookLoginProvider,
} from 'angular-6-social-login';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { ForgotComponent } from './auth/forgot/forgot.component';
import { CommonService } from './shared/service/common.service';
import { SharedModule } from './shared/module/shared.module';
import { MenuService } from 'src/app/shared/service/menu.service';
import { AlertComponent } from 'src/app/shared/component/confirm-box/alert.component';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { GooglePlaceModule } from 'ngx-google-places-autocomplete';
import { ModalService } from './shared/service/modal.service';


// Configs
export function getAuthServiceConfigs() {
  let config = new AuthServiceConfig(
      [
        {
          id: FacebookLoginProvider.PROVIDER_ID,
          provider: new FacebookLoginProvider('713614855637792')
        },
        {
          id: GoogleLoginProvider.PROVIDER_ID,
          provider: new GoogleLoginProvider('82855674672-suqvfqafvat9ut6sd59e6thdpg4cuamn.apps.googleusercontent.com')
        },
      ]
  );
  return config;
}

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ForgotComponent,
    AlertComponent,

  ],
  imports: [
    CommonModule,
    GooglePlaceModule,
    BrowserModule,
    routing,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    SocialLoginModule,
    NgbModalModule.forRoot(),
    BrowserAnimationsModule, // required animations module
    ToastrModule.forRoot({
            // closeButton: true,
            progressBar: true,
            timeOut: 2000,
            maxOpened: 1
        }),
  ],
  providers: [
    AuthGuard,
    AuthenticationService,
    CommonService,
    MenuService,
    ModalService,
    SecurityService,
    {
       provide: AuthServiceConfig,
       useFactory: getAuthServiceConfigs
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
