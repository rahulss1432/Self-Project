import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { LoginComponent } from './auth/login';
import { RegisterComponent } from './auth/register';
import { ForgotComponent } from './auth/forgot/forgot.component';
import { ResetComponent } from './auth/reset/reset.component';
const appRoutes: Routes = [

    { path: '', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'forgot', component: ForgotComponent },
    {
    path: 'passwords/reset/:token',
    loadChildren: './auth/reset/reset.module#ResetModule'
    },
    {
      path: '',
      loadChildren: './userdashboard/userdashboard.module#UserdashboardModule',
    },
       // otherwise redirect to login
    { path: '**', redirectTo: '' }
];
@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes, {
      // enableTracing: false
      useHash: true,
      onSameUrlNavigation: 'reload'
    })
  ],
  exports: [RouterModule],

})
export class AppRoutingModule { }
export const routing = RouterModule.forRoot(appRoutes);
