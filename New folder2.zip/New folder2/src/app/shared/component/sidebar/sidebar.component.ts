﻿import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { MenuService } from "src/app/shared/service/menu.service";
import { Subscription } from "rxjs";
import { UserService } from '../../service/user.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'hb-sidebar',
  templateUrl: './sidebar.component.html'
})

export class SidebarComponent implements OnInit, OnDestroy {
  route: any;
  checkurl: any;
  id: number;
  user: any = {};
  message: any;
  subscription: Subscription;
  constructor(private router: Router, private activatedRoute: ActivatedRoute, private menuservice: MenuService,private userService: UserService, private toastrService: ToastrService) {
    this.subscription = this.menuservice.getMessage().subscribe(message => {
      // console.log(message);
      if (message != null && message != undefined) {
        this.message = message.text;
        this.id=message.id;
        if (this.message == 'open-child') {
          this.route = this.router.url;
          this.checkurl = this.route.substring(0, 18);
          // console.log(this.checkurl);
         
        }
      } else {
        this.checkurl = '';
      }
    });
  }
  ngOnInit() {
  this.id = this.activatedRoute.snapshot.params['id'];
    //  console.log(this.activatedRoute.snapshot.params);
       this.userService.getUserInformationByApi().subscribe(data => {
      if (data['success'] == true) {
        this.user = data.data;
      } else {
        this.toastrService.error('Token Expired');
      }
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
   
  }

}
