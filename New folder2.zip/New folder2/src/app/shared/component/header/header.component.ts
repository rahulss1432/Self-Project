import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from 'src/app/shared/service/auth.service';
import { UserService } from '../../service/user.service';
import { ToastrService } from 'ngx-toastr';
import { MenuService } from 'src/app/shared/service/menu.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'hb-header',
  templateUrl: './header.component.html',

})
export class HeaderComponent implements OnInit {
  @Input() header_title = 'Home';
  user: any = {};
  route: any;
  checkurl: any;
  id: number;
  message: any;
  subscription: Subscription;
  // tslint:disable-next-line:max-line-length
  constructor(private authService: AuthenticationService, private menuservice: MenuService, private router: Router, private userService: UserService, private toastrService: ToastrService) {
    this.subscription = this.menuservice.getMessage().subscribe(message => {
      // console.log(message);
      if (message != null && message != undefined) {
        this.message = message.text;
        this.id = message.id;
        if (this.message == 'open-child') {
          this.route = this.router.url;
          this.checkurl = this.route.substring(0, 18);
          // console.log(this.checkurl);
        }
      } else {
        this.checkurl = '';
      }
    });
   }

  ngOnInit() {
    this.userService.getUserInformationByApi().subscribe(data => {
      if (data['success'] == true) {
        this.user = data.data;
      } else {
        this.toastrService.error('Token Expired');
      }
    });
  }

  dropDown() {
    var element = document.getElementById('account_item');
    element.classList.toggle('show-dropdown');
  }

  logout() {
    this.authService.logout();

  }

}
