export class Countries {
   id: number;
    name: string;
}