export class States {
   id: number;
    state_name: string;
    country_id: number;
}