import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { CommonService, RequestOptions } from 'src/app/shared/service/common.service';
@Injectable({
  providedIn: 'root'
})
export class GroupService {

  baseUrl = environment.baseUrl;
  constructor(private http: HttpClient, private router: Router, private commonService: CommonService) { }

  addGroup(groupData: any) {
    console.log(groupData);
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'add-group', groupData, options);
    return a.pipe(map((res: any) => res));
  }

  getGroupsById(id: any) {
    const body = {
      'tour_id': id
    };
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'all-group-list', body, options);
    return a.pipe(map((res: any) => res));
  }

  updateGroupList(list: any) {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'update-group-list', list, options);
    return a.pipe(map((res: any) => res));
  }

  updateImageList(list: any) {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'update-group-image-list', list, options);
    return a.pipe(map((res: any) => res));
  }

  updateGroupImageList(list: any) {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'update-group-image', list, options);
    return a.pipe(map((res: any) => res));
  }
  uploadGroupFiles(uploadData) {
    const a = this.http.post(this.baseUrl + 'add-group-panorama', uploadData);
    return a.pipe(map((res: any) => res));
  }

  updateGroupNameById(id: number, name: any) {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const body = {
      'group_id': id,
      'group_name': name,
    };
    const a = this.http.post(this.baseUrl + 'update-group-name', body, options);
    return a.pipe(map((res: any) => res));
  }

  // getGroupsByImages(groupId: any) {
  //     const body = {
  //     'group_id': groupId
  //   };
  //   const headers = this.commonService.getHeadersObject(true, true);
  //   const options = new RequestOptions({ headers: headers });
  //   const a = this.http.delete(this.baseUrl + 'delete-group/' + body, options);
  //   return a.pipe(map((res: any) => res));
  // }

  deleteGroup(id: any) {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.delete(this.baseUrl + 'delete-group/' + id, options);
    return a.pipe(map((res: any) => res));
  }

  deletePanorama(id: any) {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.delete(this.baseUrl + 'delete-group-image/' + id, options);
    return a.pipe(map((res: any) => res));
  }

}
