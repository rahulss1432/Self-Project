import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class MenuService {
    private subject = new Subject<any>();

    sendMessage(message: string,id:number) {
        this.subject.next({text:message,id:id});
    }

    clearMessage() {
        this.subject.next(null);
    }

    getMessage(): Observable<any> {
        return this.subject.asObservable();
    }
}