import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/shared/service/auth.service';
import {
  RequestOptions,
  CommonService
} from 'src/app/shared/service/common.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', })
};

@Injectable({
  providedIn: 'root'
})
export class CheckoutService {
  baseUrl = environment.baseUrl;
  user: any = {};
  // tslint:disable-next-line:max-line-length
  constructor(private authService: AuthenticationService, private http: HttpClient, private router: Router, private commonService: CommonService, ) { }

  paymentCheckout(requestBody) {
    this.user = this.authService.getUserDetail();
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'checkout', requestBody, options);
    return a.pipe(map((res: any) => res));
  }

  fetchStorageData() {
    const userData = localStorage.getItem('currentUser');
    let data = '';
    if (userData) {
        data = JSON.parse(userData);
    }
    return data;
}

}
