import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  baseUrl = environment.baseUrl;
  constructor(private http: HttpClient, private router: Router) { }

  registerUser(signupData: any) {
    const a = this.http.post(this.baseUrl + 'registration', signupData, httpOptions);
    return a.pipe(map((res: any) => res));
  }


  //user login method
  loginUser(email: string, password: string) {
    const body = {
      'email': email,
      'password': password
    };
    const a = this.http.post(this.baseUrl + 'login', body, httpOptions);
    return a.pipe(map(user => {
      // login successful if there's a jwt token in the response
      if (user) {
        // store user details and jwt token in local storage to keep user logged in between page refreshes
        localStorage.setItem('currentUser', JSON.stringify(user));
      }

      return user;
    }));
  }
  user: any = {};
  getUserDetail() {
    return JSON.parse(localStorage.getItem('currentUser'));
  }

  getToken() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    return currentUser ? currentUser.userData.access_token : false;
  }



  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    this.router.navigate(['/']);
    // location.reload();
  }
  socialLogin(data) {
    const formData = new FormData();
    formData.append('email', data.email);
    formData.append('user_type', 'customer');
    formData.append('first_name', data.name);
    formData.append('last_name', data.name);
    formData.append('user_name', data.name);
    formData.append('social_type', data.provider);
    return this.http.post(this.baseUrl + 'social_login', formData).pipe(map(res => {
      localStorage.setItem('currentUser', JSON.stringify(res));
      return res;
    }));

  }

  forgotpassword(forgotData: any) {
    const a = this.http.post(this.baseUrl + 'forgot-password', forgotData, httpOptions);
    return a.pipe(map((res: any) => res));
  }

  resetPassword(token: string, password: string) {
    const body = {
      'otp_code': token,
      'password': password
    };
    const a = this.http.post(this.baseUrl + 'reset-password', body, httpOptions);
    return a.pipe(map((res: any) => res));
  }

}
