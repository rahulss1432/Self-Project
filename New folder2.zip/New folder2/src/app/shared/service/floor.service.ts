import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { CommonService, RequestOptions } from 'src/app/shared/service/common.service';
@Injectable({
  providedIn: 'root'
})
export class FloorService {

  baseUrl = environment.baseUrl;
  constructor(private http: HttpClient, private router: Router, private commonService: CommonService) { }

  getFloorPlanDetails(id: number) {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    // console.log(headers);
    
    const a = this.http.get(this.baseUrl  + 'get-floor-plan-detail/' + id, options);
    return a.pipe(map((res: any) => res));
  }
  

  uploadFloorPlainImage(uploadData) {
    const a = this.http.post(this.baseUrl + 'update-group-floor-image', uploadData);
    return a.pipe(map((res: any) => res));
  }
  

  deleteFloorPlan(id: any) {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.delete(this.baseUrl + 'delete-group-floor-plan/' + id, options);
    return a.pipe(map((res: any) => res));
  }

}
