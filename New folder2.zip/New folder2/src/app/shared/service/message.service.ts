import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { CommonService, RequestOptions } from 'src/app/shared/service/common.service';
import { AuthenticationService } from 'src/app/shared/service/auth.service';

@Injectable({
  providedIn: 'root'
})
export class MessageService {

  baseUrl = environment.baseUrl;
  constructor(private http: HttpClient, private router: Router, private commonService: CommonService, private authservice: AuthenticationService) { }

  getMessages(id: any, type: any, page: number) {
    let body = {
      'id': id, 'type': type
    };
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'get-messages?page=' + page, body, options);
    return a.pipe(map((res: any) => res));
  }

  updateFavMessages(msgId: any) {
    let body = {
      'id': msgId
    }
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'update-fav-Messages', body, options);
    return a.pipe(map((res: any) => res));
  }


  deletemessages(id: any) {
    let body = {
      'id': id
    }
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'delete-message', body, options);
    return a.pipe(map((res: any) => res));
  }

  getUserEmails() {
    let id = this.authservice.getUserDetail().userData.id;
    let body = {
      'id': id
    };
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'get-user-emails', body, options);
    return a.pipe(map((res: any) => res));
  }

  sendmessages(msgdetals: any) {
    let body = {
      'messages': msgdetals
    }
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'send-Messages', body, options);
    return a.pipe(map((res: any) => res));
  }
}
