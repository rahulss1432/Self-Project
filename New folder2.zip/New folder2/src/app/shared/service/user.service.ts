import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { CommonService, RequestOptions } from 'src/app/shared/service/common.service';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl = environment.baseUrl;
  constructor(private http: HttpClient, private router: Router, private commonService: CommonService) { }


  //edit user profile
  editProfile(data) {
    console.log(data);
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'edit-profile', data, options);
    return a.pipe(map((res: any) => res));
  }

  //get user data by api
  getUserInformationByApi() {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.get(this.baseUrl + 'view-profile', options);
    return a.pipe(map((res: any) => res));
  }


}
