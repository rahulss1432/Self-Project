import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/shared/service/auth.service';
import {
  RequestOptions,
  CommonService
} from "src/app/shared/service/common.service";
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', })
};

@Injectable({
  providedIn: 'root'
})
export class ToursService {
  baseUrl = environment.baseUrl;
  user: any = {};
  // tslint:disable-next-line:max-line-length
  constructor(private authService: AuthenticationService, private http: HttpClient, private router: Router, private commonService: CommonService, ) { }

  addTours(tour_name: string, ) {
    this.user = this.authService.getUserDetail();
    const body = {
      'access-token': this.user.userData.access_token,
      'tour_name': tour_name

    };
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'add-tour', body, options);
    return a.pipe(map((res: any) => res));
  }

  getTourList() {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.get(this.baseUrl + 'all-tours-list', options);
    return a.pipe(map((response: any) => response));
  }

  getAllMasterCategoryList() {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.get(this.baseUrl + 'master-categories', options);
    return a.pipe(map((response: any) => response));
  }

  getTourDetailById(id: string) {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this
      .http.get(this.baseUrl + 'get-tour-detail/' + id, options);
    return a.pipe(map((response: any) => response));
  }

  getToken() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    return currentUser ? currentUser.userData.access_token : false;
  }

  updateTourSetting(tourData) {
    console.log(tourData);
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'update-tour-detail', tourData, options);
    return a.pipe(map((res: any) => res));
  }
  getTourListwithGroup() {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
       const a = this.http.get( this.baseUrl + 'all-tours-list-group', options);
       return a.pipe(map((response: any) => response));
  }


    updateCategory(tourCategory) {
    console.log(tourCategory);
    const headers = this.commonService.getHeadersObject(true, false);
    const options = new RequestOptions({ headers: headers });
    const a = this.http.post(this.baseUrl + 'update-category-tour', tourCategory, options);
    return a.pipe(map((res: any) => res));
  }

  getPlanList() {
    const headers = this.commonService.getHeadersObject(true, true);
    const options = new RequestOptions({ headers: headers });
       const a = this.http.get( this.baseUrl + 'all-plan-list', options);
       return a.pipe(map((response: any) => response));
  }


}
