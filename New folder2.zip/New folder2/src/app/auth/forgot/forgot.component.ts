import { Component, OnInit } from '@angular/core';
import { FormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { AppValidations } from 'src/app/shared/validators/app-validations';
import { AuthenticationService } from 'src/app/shared/service/auth.service';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css']
})
export class ForgotComponent implements OnInit {
forgotFrom: FormGroup;
  errorClass = 'red';
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
     loading = false;
  constructor(
    private authenticationService: AuthenticationService,
    private router: Router,
    private toastrService: ToastrService
  ) { }

  ngOnInit() {
    this.forgotFrom = new FormGroup({
      'email': new FormControl(null, [Validators.required, Validators.pattern(this.emailPattern)]),
     
       });
  }

  forgot(forgotData: any): void {
    // console.log(forgotData);
     this.loading = true;
      this.authenticationService.forgotpassword(forgotData).subscribe(res => {
       if (res['success'] == true) {
         this.loading = false;
       this.toastrService.success('Please check your email!');
        this.forgotFrom.reset();
        this.router.navigate(['/']);
      } else {
         this.toastrService.error(res['message'], 'Forgot');
           this.loading = false;
        this.router.navigate(['/']);
      }
    });
  }

}
