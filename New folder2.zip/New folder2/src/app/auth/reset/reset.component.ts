import { Component, OnInit } from '@angular/core';
import { FormsModule, FormGroup, FormControl, Validators} from '@angular/forms';
import { AppValidations } from 'src/app/shared/validators/app-validations';
import { AuthenticationService } from 'src/app/shared/service/auth.service';
import { Router,ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.css']
})
export class ResetComponent implements OnInit {
  errorClass = 'red';
  resetForm: FormGroup;
  token: string;
    loading = false;
  constructor(
    private activatedRoute: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private router: Router,
    private toastrService: ToastrService,
  
  ) {
     this.token = this.activatedRoute.snapshot.params['token'];
    }

  ngOnInit() {
      this.resetForm = new FormGroup({
      'password': new FormControl(null, [Validators.required, Validators.minLength(6)]),
      'confirmPassword': new FormControl(null, [Validators.required]),
      }, {
        validators: AppValidations.MatchPassword
      });
  }

 resetpassword(resetData: any): void {
    this.loading = true;
    // console.log(resetData);
    this.authenticationService.resetPassword(this.token, this.resetForm.controls['password'].value)
      .subscribe(result => {
        if (result.success === true) {
           this.loading = false;
          this.toastrService.success(result.message);
           this.router.navigate(['/']);
        } else {
            this.loading = false;
          this.toastrService.error(result.message);
        }
       
      })
  }

   
}
