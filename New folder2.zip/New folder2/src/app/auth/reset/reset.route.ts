import { Routes, RouterModule } from '@angular/router';
import { ResetComponent } from './reset.component';

const RESET_ROUTE: Routes = [
  {
    path: '', component: ResetComponent, children: [
      { path: '', component: ResetComponent }
    ]
  }
]

export const resetRouting = RouterModule.forChild(RESET_ROUTE);
