import { Component, OnInit } from '@angular/core';
import { FormBuilder, NgForm, FormGroup, Validators  } from '@angular/forms';
import { AppValidations } from 'src/app/shared/validators/app-validations';
import { AuthenticationService } from 'src/app/shared/service/auth.service';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { SecurityService } from "../../shared/service/security.service";
import {
    AuthService,
    FacebookLoginProvider,
    GoogleLoginProvider,
   } from 'angular-6-social-login';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
loginForm: FormGroup;
  errorClass = 'red';
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
      model: any = {};
      loading = false;
        disabled: boolean = false;
          UserData: any = {};
  constructor(
    private formBuilder: FormBuilder,
    private socialAuthService: AuthService,
    private authenticationService: AuthenticationService,
    private router: Router,
    private toastrService: ToastrService,
    private securityService: SecurityService,
    ) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
            email: ['', Validators.required],
            password: ['', Validators.required]
        });
        this.setRemember();
  }

    onSubmit(login: NgForm) {
        this.loading = true;
          this.disabled = true;
       this.authenticationService.loginUser(login.value.email, login.value.password)
            .pipe(first())
            .subscribe(
            data => {
                 if (data['success'] == true) {
                     this.loading = false;
                    this.setResetRemember();
                    this.UserData = data;
                    // console.log(data.userData.user_type);
                    if(this.UserData.userData.user_type == 'customer'){
                      this.router.navigate(["/home"]);
                    }else{
                       this.router.navigate(["/admin"]);
                    }

                    this.toastrService.success('login successfully');

                } else {
                      this.loading = false;
                    this.toastrService.error('Invaild email or password ');
                }
            });
    }

  public socialSignIn(socialPlatform : string) {
    let socialPlatformProvider;
    if(socialPlatform == "facebook"){
      socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
    }else if(socialPlatform == "google"){
      socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;
    }

    this.socialAuthService.signIn(socialPlatformProvider).then(
      (userData) => {
        // console.log(socialPlatform+" sign in data : " , userData);
        // Now sign-in with userData
        // ...
        this.authenticationService.socialLogin(userData)
            .pipe(first())
            .subscribe(
            data => {
                // console.log(data);
                if (data['success'] == true) {
                    this.toastrService.success('User login successfully!');
                    this.router.navigate(['/home']);
                } else {

                     this.toastrService.error('Invaild email or password ');
                }
            },
            error => {
               this.toastrService.success(userData['message'], 'Social')

            });

      }
    );

  }

  setResetRemember() {
          if (this.model.remember) {
            localStorage.setItem(
                "email",
                this.securityService.encode(this.model.email)
            );
            localStorage.setItem(
                "password",
                this.securityService.encode(this.model.password)
            );
            localStorage.setItem("remember", "true");
        } else {
            localStorage.email = "";
            localStorage.password = "";
            localStorage.remember = "";
        }
    }

    setRemember() {
        if (localStorage.getItem("remember") === "true") {
            this.model.email = this.securityService.decode(
                localStorage.getItem("email")
            );
            this.model.password = this.securityService.decode(
                localStorage.getItem("password")
            );
            this.model.remember = true;
        } else {
            this.model.email = "";
            this.model.password = "";
            this.model.remember = false;
        }
    }

}
