import { Component, OnInit } from '@angular/core';
import { FormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { AppValidations } from 'src/app/shared/validators/app-validations';
import { AuthenticationService } from 'src/app/shared/service/auth.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  signupFrom: FormGroup;
  errorClass = 'red';
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  loading = false;
  constructor(private authService: AuthenticationService, private router: Router, private toastrService: ToastrService) { }

  ngOnInit() {
    this.signupFrom = new FormGroup({
      'first_name': new FormControl(null, [Validators.required, Validators.minLength(4)]),
      'last_name': new FormControl(null, [Validators.required, Validators.minLength(4)]),
      'user_name': new FormControl(null, [Validators.required, Validators.minLength(4)]),
      'email': new FormControl(null, [Validators.required, Validators.pattern(this.emailPattern)]),
      'password': new FormControl(null, [Validators.required, Validators.minLength(6)]),
      'confirmPassword': new FormControl(null, [Validators.required]),
      'user_type': new FormControl('customer'),
    }, {
        validators: AppValidations.MatchPassword
      });
  }

  submitData(signupData: any): void {
    this.loading = true;
    this.authService.registerUser(signupData).subscribe(res => {
      if (res['success'] == true) {
        this.toastrService.success(res['message'], 'Register');
        this.signupFrom.reset();
        this.router.navigate(['/login']);
      } else {
        this.toastrService.error(res['message'], 'Register');
        this.router.navigate(['/register']);
      }
      this.loading = false;
    });
  }

}
