// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false
};

const base_url = "http://localhost:3700/api";


class Endpoints {
  AUTH_BASE = base_url + "/auth";
  DASHBOARD_BASE = base_url + "/admin/dashboard";
  MODEL_BASE = base_url + "/admin/model";
  REFERAL_SYSTEM_BASE = base_url + "/admin";
  MISCELLANEOUS_BASE = base_url + "";
  COUNTRIES_BASE = base_url + "/country";
  STATES_BASE = base_url + "/state";
  CUSTOMER_BASE = base_url + "/user";
  COLOR_BASE = base_url + "/color";
  CONDITION_BASE = base_url + "/condition";
  MAIN_CATEGORY_BASE = base_url + "/category-by-type";
  CATEGORY_BASE = base_url + "/category";
  FABRIC_BASE = base_url + "/fabric";
  DESIGNER_BASE = base_url + "/designer";
  BLOG_BASE = base_url + "/blog";
  CMS_BASE = base_url + "/cms";
  TESTIMONIAL_BASE = base_url + "/testimonial";
  FAQ_BASE = base_url + "/faq";
  CONTACT_BASE = base_url + "/contact-us";
  REPORT_POST_BASE = base_url + "/report-post";



  DASHBOARD_ENDPOINTS = {
    GET_HEADER_DETAILS: this.DASHBOARD_BASE,
    GET_LIVE_DRIVERS: this.joinPaths(this.DASHBOARD_BASE, "active-driver"),
    GET_INCOME_DISTRIBUTION: this.joinPaths(
      this.DASHBOARD_BASE,
      "income-distribution"
    ),
    GET_USER_GRAPH: this.joinPaths(this.DASHBOARD_BASE, "user-graph")
  };

  AUTH_ENDPOINTS = {
    LOG_IN: this.joinPaths(this.AUTH_BASE, "login"),
    FORGET_PASSWORD: this.joinPaths(this.AUTH_BASE, "forgot-password"),
    RESET_PASSWORD: this.joinPaths(this.AUTH_BASE, "reset-password"),
    CHANGE_PASSWORD: this.joinPaths(this.AUTH_BASE, "change-password"),
    LOGOUT: this.joinPaths(this.AUTH_BASE, "logout")
  };
  CUSTOMER_ENDPOINTS = {
    GET_CUSTOMER_LIST: this.CUSTOMER_BASE,
    GET_CUSTOMER_DETAIL: id => this.joinPaths(this.CUSTOMER_BASE, id),
    UPDATE_CUSTOMER: id => this.joinPaths(this.CUSTOMER_BASE, id),
    CUSTOMER_STATUS_UPDATE_URL: id =>
      this.joinPaths(this.CUSTOMER_BASE, id, "change-status"),
    DELETE_CUSTOMER: id => this.joinPaths(this.CUSTOMER_BASE, id),
  };
  COUNTRIES_ENDPOINTS = {
    GET_COUNTRIES_LIST: this.COUNTRIES_BASE
  };
  STATES_ENDPOINTS = {
    GET_STATES_LIST: id => this.joinPaths(this.STATES_BASE, id),
  };
  COLOR_ENDPOINTS = {
    GET_COLOR_LIST: this.COLOR_BASE,
    UPDATE_COLOR: id => this.joinPaths(this.COLOR_BASE, id),
    COLOR_STATUS_UPDATE_URL: id =>
      this.joinPaths(this.COLOR_BASE, id, "change-status"),
    DELETE_COLOR: id => this.joinPaths(this.COLOR_BASE, id),
    GET_COLOR_DETAIL: id => this.joinPaths(this.COLOR_BASE, id),
  };

  FABRIC_ENDPOINTS = {
    GET_FABRIC_LIST: this.FABRIC_BASE,
    UPDATE_FABRIC: id => this.joinPaths(this.FABRIC_BASE, id),
    FABRIC_STATUS_UPDATE_URL: id =>
      this.joinPaths(this.FABRIC_BASE, id, "change-status"),
    DELETE_FABRIC: id => this.joinPaths(this.FABRIC_BASE, id),
    GET_FABRIC_DETAIL: id => this.joinPaths(this.FABRIC_BASE, id),
  };
  TESTIMONIAL_ENDPOINTS = {
    GET_TESTIMONIAL_LIST: this.TESTIMONIAL_BASE,
    UPDATE_TESTIMONIAL: id => this.joinPaths(this.TESTIMONIAL_BASE, id),
    DELETE_TESTIMONIAL: id => this.joinPaths(this.TESTIMONIAL_BASE, id),
    GET_TESTIMONIAL_DETAIL: id => this.joinPaths(this.TESTIMONIAL_BASE, id),
  };

  BLOG_ENDPOINTS = {
    GET_BLOG_LIST: this.BLOG_BASE,
    UPDATE_BLOG: id => this.joinPaths(this.BLOG_BASE, id),
    GET_CATEGORY: type => this.joinPaths(this.MAIN_CATEGORY_BASE, type),
    BLOG_STATUS_UPDATE_URL: id =>
      this.joinPaths(this.BLOG_BASE, id, "change-status"),
    DELETE_BLOG: id => this.joinPaths(this.BLOG_BASE, id),
    GET_BLOG_DETAIL: id => this.joinPaths(this.BLOG_BASE, id),
  };

  CONDITION_ENDPOINTS = {
    GET_CONDITION_LIST: this.CONDITION_BASE,
    UPDATE_CONDITION: id => this.joinPaths(this.CONDITION_BASE, id),
    CONDITION_STATUS_UPDATE_URL: id =>
      this.joinPaths(this.CONDITION_BASE, id, "change-status"),
    DELETE_CONDITION: id => this.joinPaths(this.CONDITION_BASE, id),
    GET_CONDITION_DETAIL: id => this.joinPaths(this.CONDITION_BASE, id),
  };

  DESIGNER_ENDPOINTS = {
    GET_DESIGNER_LIST: this.DESIGNER_BASE,
    UPDATE_DESIGNER: id => this.joinPaths(this.DESIGNER_BASE, id),
    DESIGNER_STATUS_UPDATE_URL: id =>
      this.joinPaths(this.DESIGNER_BASE, id, "change-status"),
    DELETE_DESIGNER: id => this.joinPaths(this.DESIGNER_BASE, id),
    GET_DESIGNER_DETAIL: id => this.joinPaths(this.DESIGNER_BASE, id),
  };
  CATEGORIES_ENDPOINTS = {
    GET_CATEGORY_LIST: type => this.joinPaths(this.MAIN_CATEGORY_BASE, type),
    GET_CATEGORY_DETAIL: id => this.joinPaths(this.CATEGORY_BASE, id),
    UPDATE_CATEGORY: id => this.joinPaths(this.CATEGORY_BASE, id),
    CATEGORY_STATUS_UPDATE_URL: id =>
      this.joinPaths(this.CATEGORY_BASE, id, "change-status"),
    DELETE_CATEGORY: id => this.joinPaths(this.CATEGORY_BASE, id),
  };

  CMS_ENDPOINTS = {
    GET_CMS_LIST: this.CMS_BASE,
    GET_CMS_DETAIL: id => this.joinPaths(this.CMS_BASE, id),
    UPDATE_CMS: id => this.joinPaths(this.CMS_BASE, id),
  };

  FAQ_ENDPOINTS = {
    GET_FAQ_LIST: this.FAQ_BASE,
    GET_FAQ_DETAIL: id => this.joinPaths(this.FAQ_BASE, id),
    GET_CATEGORY: type => this.joinPaths(this.MAIN_CATEGORY_BASE, type),
    DELETE_FAQ: id => this.joinPaths(this.FAQ_BASE, id),
    UPDATE_FAQ: id => this.joinPaths(this.FAQ_BASE, id),
  };

  CONTACT_ENDPOINTS = {
    GET_CONTACT_LIST: this.CONTACT_BASE,
    GET_CONTACT_DETAIL: id => this.joinPaths(this.CONTACT_BASE, id),
  };

  REPORT_POST_ENDPOINTS = {
    GET_REPORT_POST_LIST: this.REPORT_POST_BASE,
    REPORT_POST_STATUS_UPDATE_URL: id =>
      this.joinPaths(this.REPORT_POST_BASE, id, "change-status"),
    GET_REPORT_POST_DETAIL: id => this.joinPaths(this.REPORT_POST_BASE, id),
  };

  private joinPaths(...params) {
    const newUrl = params.join("/");
    return newUrl;
  }

  private joinPathsWithQueryParams(...params) {
    const newUrl = params.join("?");
    return newUrl;
  }
}

export const API = new Endpoints();
