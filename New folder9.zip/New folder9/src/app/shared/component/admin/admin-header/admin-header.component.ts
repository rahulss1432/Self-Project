import { Component, OnInit, Input } from '@angular/core';
import { ManageDrawer } from '@app/shared/services/drawer.service';
import { Router } from '@angular/router';
import { ToasterService } from '@app/shared/services/toaster.service';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { default_const, error_msg } from '@app/shared/constants/consts';
import { TokenManager } from '@app/shared/services/token-manager.service';
import { AuthService } from '@app/auth/services/auth-service.service';
@Component({
  selector: 'app-admin-header',
  templateUrl: './admin-header.component.html',
  providers: [Idle, TokenManager]
})
export class AdminHeaderComponent implements OnInit {
   @Input() header_title = '';
  userName: any;

  constructor(
    public manageDrawer: ManageDrawer,
    private router: Router,
    private auth: AuthService,
    private toasterService: ToasterService,
    private idle: Idle,
    private manageToken: TokenManager
  ) {
    idle.setIdle(default_const.SESSION_TIMOUT_DURATION);
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    idle.onTimeout.subscribe(() => {
      this.toasterService.Success(error_msg.SESSION_TIMOUT_MESSAGE);
      localStorage.removeItem('currentUser');
      this.router.navigate(['/login']);
    });

    idle.watch();
  }

  ngOnInit() {
    this.getUserDetails();
  }

  handleToggle() {
    this.manageDrawer.drawerStatusSubject.next(
      this.manageDrawer.possibleStates.toggle
    );
  }

  onLogout(): void {
    this.auth.logout().subscribe(
      (result: any) => {
      
        if (result.success === true) {
          localStorage.removeItem('currentUser');
          this.router.navigate(['/login']);
          this.toasterService.Success(result.message);
        } else {
          this.toasterService.Error(result.message);
        }
      },
      err => {
        this.toasterService.ErrorTimeOut(err.message);
      }
    );
  }

  getUserDetails() {
    this.userName = 'Test';
  }
}
