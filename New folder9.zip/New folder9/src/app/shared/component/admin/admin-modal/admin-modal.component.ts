import { Router } from '@angular/router';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'admin-modal',
  templateUrl: './admin-modal.component.html'
})
export class AdminModalComponent implements OnInit {

  constructor() {}

  ngOnInit() {
        
  }


}
