import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';

@Injectable({
    providedIn: 'root'
})

export class AlertService {
    private subject = new Subject<any>();
    constructor() { }

    alert(message: string, yesFunction: () => void, noFunction: () => void) {

        this.setAlert(message, yesFunction, noFunction);
    }

    setAlert(message: string, yesFunction: () => void, noFunction: () => void) {
        console.log('hh');
        let that = this;
        this.subject.next({
            type: 'alert',
            text: message,
            yesFunction:
            function () {
                that.subject.next(); // this will close the modal
                yesFunction();
            },
            noFunction: function () {
                that.subject.next();
                noFunction();
            }
        });

    }

    getMessage(): Observable<any> {
        return this.subject.asObservable();
    }
}
