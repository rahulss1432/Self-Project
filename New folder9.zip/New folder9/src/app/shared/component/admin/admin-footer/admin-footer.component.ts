import { Router } from '@angular/router';
import { Component, OnInit, Input } from '@angular/core';
import * as $ from "jquery";

@Component({
  selector: 'admin-footer',
  templateUrl: './admin-footer.component.html'
})
export class AdminFooterComponent implements OnInit {


  constructor() { }

  ngOnInit() {
    $('#preloader').hide();  
  }

  ngAfterViewInit() {
    this.contentSectionHeight();
    window.onresize = () => {
      this.contentSectionHeight();
    };
  }
  ngAfterViewChecked() {
    this.contentSectionHeight();
  }
  contentSectionHeight() {
    const window_height = window.innerHeight;
    const footer_height = document.getElementById('footer').clientHeight;
    //const getPadding =   document.getElementById('pageContent').offsetHeight - document.getElementById('pageContent').clientHeight;
    const header_footer_height = document.getElementById('header').clientHeight + document.getElementById('footer').clientHeight;
    const mainContentHeight = window_height - footer_height;
    const cardHeight = window_height - header_footer_height - 40;
    let mainContenId = document.getElementById('mainContent');
    if (mainContenId) {
      mainContenId.style.minHeight = (mainContentHeight) + 'px';
    }
    let cardId = document.getElementById('card_height');
    if (cardId) {
      cardId.style.minHeight = (cardHeight) + 'px';
    }
  } 
}
