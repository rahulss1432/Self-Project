import { Component, OnInit, EventEmitter, Output, Input } from "@angular/core";
import { ExportCsvPdfService } from "@app/shared/component/export-csv-pdf/export-csv-pdf.service";

@Component({
  selector: "app-export-csv-pdf",
  templateUrl: "./export-csv-pdf.component.html",
  providers: [ExportCsvPdfService]
})
export class ExportCsvPdfComponent implements OnInit {
  @Input() URL: any;
  @Input() Params: any;
  @Input() ExternalClass: any;
  queryString: any;
  type: any;
  constructor(private exportService: ExportCsvPdfService) {}

  ngOnInit() {
    // console.log(this.Params);
  }

  getCSV() {
    this.type = "csv";
    const queryData = this.generateQueryString(this.type);
    // alert(this.URL + "<br/>" + queryData);
    this.exportService.getFile(this.URL, queryData);
  }

  getPDF() {
    this.type = "pdf";
    let queryData = this.generateQueryString(this.type);
    // alert(queryData);
    // this.exportService.getFile(this.URL, this.type);
  }

  generateQueryString(type: string): string {
    if (this.Params) {
      if (this.Params.hasOwnProperty("type")) {
        // console.log('this.Params["type"]', this.Params["type"]);
      } else {
        this.Params["type"] = type;
      }
      this.queryString = new URLSearchParams(this.Params);
      return this.queryString.toString();
    } else {
    }
  }
}
