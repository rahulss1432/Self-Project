import { Injectable } from "@angular/core";
import { ApiHandler } from "@app/shared/services/api-handler.service";
import { Observable } from "rxjs/Observable";
import * as objectMapper from "object-mapper";
import { API } from "environments/environment";

@Injectable()
export class BarChartService {
  constructor(private apiHandler: ApiHandler) {}

  getRecords(pastMonths) {
    // console.log("fetching records for", pastMonths, " months");
    // const records = RECORDS;
    // return new Observable(obs => {
    //   obs.next(records);
    // });

    return this.apiHandler
      .apiGet(API.DASHBOARD_ENDPOINTS.GET_USER_GRAPH)
      .map((res: any) => {
        const ratios = res.data;
        return { ratios: res.data };
      });
  }

  applyMapper(srcObj, mapper = Mapper) {
    // console.log(srcObj, mapper);
    return objectMapper(srcObj, mapper);
  }
}

const MONTH_ENUM = {
  0: "January",
  1: "February",
  2: "March",
  3: "April",
  4: "May",
  5: "June",
  6: "July",
  7: "August",
  8: "September",
  9: "October",
  10: "November",
  11: "December"
};

const Mapper = {
  ratios: {
    key: "ratios",
    transform: Ratios => {
      const newData = [];
      Ratios.map(ratio => {
        // console.log("These is ratio", ratio);
        const ratioObj = {
          month: ratio["month"],
          drivers: ratio["driver"],
          riders: ratio["customer"]
        };
        // console.log(ratioObj);
        newData.push(ratioObj);
      });
      return newData;
    },
    data: "data"
  }
};

function reStructureMonth(date: Date) {
  return `${MONTH_ENUM[date.getMonth()]}-${date.getUTCFullYear()}`;
}

const RECORDS = {
  ratios: [
    {
      from_date: "2018-02-01T13:38:46.000Z",
      to_date: "2018-02-28T13:38:46.000Z",
      customer: 26,
      driver: 52
    },
    {
      from_date: "2018-01-01T13:38:46.000Z",
      to_date: "2018-01-30T13:38:46.000Z",
      customer: 261,
      driver: 521
    },
    {
      from_date: "2017-12-01T13:38:46.000Z",
      to_date: "2017-12-31T13:38:46.000Z",
      customer: 261,
      driver: 521
    }
  ],
  data: 3
};
