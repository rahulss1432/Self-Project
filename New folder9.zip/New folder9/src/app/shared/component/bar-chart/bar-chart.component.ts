import { Component, OnInit, Input } from "@angular/core";
import { BarChartService } from "@app/shared/component/bar-chart/bar-chart.service";

@Component({
  selector: "app-bar-chart",
  templateUrl: "bar-chart.component.html",
  providers: [BarChartService]
})
export class BarChartComponent implements OnInit {
  @Input() fetchRecordsForMonths = 3;

  chartBarOptions = {
    xkey: "month",
    ykeys: ["drivers", "riders"],
    labels: ["Drivers", "Riders"],
    barColors: ["#4099ff", "#ff5370"]
  };

  chartBarData = [
    { month: "2006", drivers: 100, riders: 90 },
    { month: "2007", drivers: 75, riders: 65 },
    { month: "2008", drivers: 50, riders: 40 }
  ];

  allSubscriptions = [];

  constructor(private barChartService: BarChartService) {
    const subscription = this.barChartService.getRecords(3).subscribe({
      next: records => {
        this.chartBarData = this.barChartService.applyMapper(records)["ratios"];
      }
    });
    this.allSubscriptions.push(subscription);
  }

  ngOnInit() {}
}
