export const error_msg = {
  /****************FABRIC SECTION*****************/
  FABRIC_NAME_REQUIRED: "Fabric name field required",
  FABRIC_NAME_MAX_LENGTH: maxLength =>
    `Fabric name can't exceed ${maxLength} characters`,
  FABRIC_NAME_ONLY_CHARS: "Fabric name can only have alphabets",

  /****************CMS SECTION*****************/
  //title
  TITLE_REQUIRED: "Title required",
  TITLE_MIN_LENGTH: minLength =>
    `Title should have minimum ${minLength} characters`,
  TITLE_MAX_LENGHT: maxLength =>
    `Title can't exceed ${maxLength} characters`,
  TITLE_ONLY_CHARS: "Title can only have alphabets",
  //meta title
  META_TITLE_REQUIRED: "Meta title required",
  META_TITLE_MIN_LENGTH: minLength =>
    `Meta title should have minimum ${minLength} characters`,
  META_TITLE_MAX_LENGHT: maxLength =>
    `Meta title can't exceed ${maxLength} characters`,
  META_TITLE_ONLY_CHARS: "Meta title can only have alphabets",
  //meta desciption
  META_DESCRIPTION_REQUIRED: "Meta desciption required",

  // desciption
  DESCRIPTION_REQUIRED: "Desciption required",

  // status
  STATUS_REQUIRED: "Status required",




  /****************COLOR SECTION*****************/
  COLOR_NAME_REQUIRED: "Color name field required",
  COLOR_NAME_MAX_LENGTH: maxLength =>
    `Color name can't exceed ${maxLength} characters`,
  COLOR_NAME_ONLY_CHARS: "Color name can only have alphabets",
  /****************TESTIMONIAL SECTION*****************/
  RATING_REQUIRED: "Rating field required",
  /****************BLOG SECTION*****************/
  AUTHOR_REQUIRED: "Author field required",
  AUTHOR_MAX_LENGHT: maxLength => `Category name can't exceed ${maxLength} characters`,
  BLOG_IMAGE_REQUIRED: "Blog image required",
  /****************CATRGORY SECTION*****************/
  CATRGORY_NAME_REQUIRED: "Color name field required",
  CATRGORY_NAME_MAX_LENGTH: maxLength =>
    `Color name can't exceed ${maxLength} characters`,
  CATRGORY_NAME_ONLY_CHARS: "Color name can only have alphabets",

  /****************CONDITION SECTION*****************/
  CONDITION_NAME_REQUIRED: "Condition name field required",
  CONDITION_NAME_MAX_LENGTH: maxLength =>
    `Condition name can't exceed ${maxLength} characters`,
  CONDITION_NAME_ONLY_CHARS: "Condition name can only have alphabets",

  /****************DESIGNER SECTION*****************/
  DESIGNER_NAME_REQUIRED: "Designer name field required",
  DESIGNER_NAME_MAX_LENGTH: maxLength =>
    `Designer name can't exceed ${maxLength} characters`,
  DESIGNER_NAME_ONLY_CHARS: "Designer name can only have alphabets",

  /****************USER SECTION*****************/
  USER_NAME_REQUIRED: "Name field required",
  COUNTRY_NAME_REQUIRED: "Country field required",
  GENDER_NAME_REQUIRED: "Gender field required",
  STATE_NAME_REQUIRED: "State field required",
  CITY_NAME_REQUIRED: "Country field required",
  DATE_OF_BIRTH_REQUIRED: "Date of birth date required",
  /****************POST SECTION ***************/
  POST_QUESTION_REQUIRED: "Qestion field required",
  POST_QUESTION_CATEGORY_REQUIRED: "Category field required",
  POSTED_BY_NAME_MAX_LENGTH: maxLength =>
    `Posted by can't exceed ${maxLength} characters`,
  QUESTION_MAX_LENGTH: maxLength =>
    `Question by can't exceed ${maxLength} characters`,

  /**********Category Section ***************/
  CATEGORY_REQUIRED: "Category field required",
  CATEGORY_NAME_REQUIRED: "Category name required",
  CATEGORY_NAME_MAX_LENGTH: maxLength =>
    `Category name can't exceed ${maxLength} characters`,
  CATEGORY_TITLE_PATTERN: "Category name can only have alphabets",
  /* ----- DRIVER SECTION ------ */
  // First name field
  FIRST_NAME_REQUIRED: "First name required",
  FIRST_NAME_MIN_LENGTH: minLength =>
    `First name should have minimum ${minLength} characters`,
  FIRST_NAME_MAX_LENGTH: maxLength =>
    `First name can't exceed ${maxLength} characters`,
  FIRST_NAME_ONLY_CHARS: "First name can only have alphabets",
  // Full name field
  FULL_NAME_REQUIRED: "Full name required",
  FULL_NAME_MIN_LENGTH: minLength =>
    `Full name should have minimum ${minLength} characters`,
  FULL_NAME_MAX_LENGTH: maxLength =>
    `Full name can't exceed ${maxLength} characters`,
  FULL_NAME_ONLY_CHARS: "Full name can only have alphabets",
  // Last name field
  LAST_NAME_REQUIRED: "Last name required",
  LAST_NAME_MIN_LENGTH: minLength =>
    `Last name should have minimum ${minLength} characters`,
  LAST_NAME_MAX_LENGHT: maxLength =>
    `Last name can't exceed ${maxLength} characters`,
  LAST_NAME_ONLY_CHARS: "Last name can only have alphabets",
  // Address field
  ADDRESS_REQUIRED: "Addess required",
  ADDRESS_MIN_LENGTH: minLength =>
    `Addess should have minimum ${minLength} characters`,
  ADDRESS_MAX_LENGHT: maxLength =>
    `Addess can't exceed ${maxLength} characters`,
  ADDRESS_ONLY_CHARS: "Addess can only have alphabets",
  // City field
  CITY_REQUIRED: "City name required",
  CITY_MIN_LENGTH: minLength =>
    `City should have minimum ${minLength} characters`,
  CITY_MAX_LENGTH: maxLength =>
    `City can't exceed ${maxLength} characters`,
  CITY_ONLY_CHARS: "City can only have alphabets",
  // Zip code
  ZIP_NUMBER_REQUIRED: "Zip code required",
  ZIP_NUMBER_MIN_LENGTH: minLength =>
    `Zip code should have minimum ${minLength} numbers`,
  ZIP_NUMBER_MAX_LENGTH: maxLength =>
    `Zip code can't exceed ${maxLength} numbers`,
  ZIP_NUMBER_PATTERN: "Zip coder can only have numbers",



  // Email field
  EMAIL_REQUIRED: "Email is required",
  EMAIL_INCORRECT_FORMAT: "Email is not in correct format (abc@xyz.com)",
  EMAIL_MIN_LENGTH: minLength => `Email can't exceed ${minLength} characters`,
  EMAIL_MAX_LENGTH: maxLength => `Email can't exceed ${maxLength} characters`,

  // Profile image
  PROFILE_IMAGE_REQUIRED: "Profile image required",
  // gender
  GENDER_REQUIRED: "Gender required",

  /* ------------------------ FILTER  ------------------ */
  NAME_REQUIRED: "Name required",
  NAME: minLength => `Name should have minimum ${minLength} characters`,
  NAME_MAX_LENGTH: maxLength => `Name can't exceed ${maxLength} characters`,
  NAME_ONLY_CHARS: "Name can only have alphabets",

  DATE_COMPARER: "From date cannot be lesser than to date",

  /* -------------- Start Competition----------------- */

  /* -------------- END Competition------------------- */
  // Start Notification
  NOTIFICATION_MESSAGE_REQUIRED: "Message name required",
  // END Notification

  /*------------------- Promoted Post Start----------------------  */
  QUETION_MAX_LENGTH: maxLength =>
    `Quetion can't exceed ${maxLength} characters.`,
  ANSWER_MAX_LENGTH: maxLength =>
    `Answer can't exceed ${maxLength} characters.`,



  // Reset Password form
  CURRENT_PASSWORD_REQUIRED: "Current password required",
  NEW_PASSWORD_REQUIRED: "New password required",
  CONFIRM_PASSWORD_REQUIRED: "Confirm  password required",
  PASSWORD_MAX_LENGTH: maxLength =>
    `Password can't exceed ${maxLength} characters`,
  PASSWORD_MIN_LENGTH: minLength =>
    `Password should have minimum ${minLength} characters`,

  /**common error mesage */
  ONLY_ALPHA: "This field can only contain alphabatic characters",
  ONLY_NUMERIC: "Only numeric numbers are allowed.",
  FIELD_REQUIRED: "This field is required.",
  PHONE_REQUIRED: "Phone number is required.",
  MIN_LENGTH: minLength => `This field should have minimum ${minLength} characters`,
  MAX_LENGTH: maxLength => `This field can't exceed ${maxLength} characters`,
  PHONE_NUMBER_MIN_LENGTH: minLength =>
    `Phone number should have minimum ${minLength} numbers`,
  PHONE__NUMBER_MAX_LENGTH: maxLength =>
    `Phone number can't exceed ${maxLength} numbers`,

  SESSION_TIMOUT_MESSAGE: "Your session has been timed out"

};

export const notification_msg = {

  //Start : color section//
  COLOR_ADD_SUCCESS: "Color added successfully",
  COLOR_UPDATE_SUCCESS: "Color updated successfully",
  //End: color sectiom //
  CATEGORY_ADD_SUCCESS: "Category added successfully",
  // COLOR_UPDATE_SUCCESS: "Color updated successfully",

  //Start : testimonial section//
  TESTINOMIAL_ADD_SUCCESS: "Testimonial added successfully",
  TESTINOMIAL_UPDATE_SUCCESS: "Testimonial updated successfully",
  //End: testimonial sectiom //

  //Start : blog section//
  BLOG_ADD_SUCCESS: "Blog added successfully",
  BLOG_UPDATE_SUCCESS: "Blog updated successfully",
  //End: blog sectiom //

  //Start : Faq section//
  FAQ_ADD_SUCCESS: "Faq added successfully",
  FAQ_UPDATE_SUCCESS: "Faq updated successfully",
  //End: Faq sectiom //

  //Start : cms section//
  CMS_UPDATE_SUCCESS: "Cms updated successfully",
  //End: cms sectiom //
  
  //Start : Category section//
  CATEGORY_UPDATE_SUCCESS: "Category updated successfully",
  //End: Category sectiom //

  //Start : fabric section//
  FABRIC_ADD_SUCCESS: "Fabric added successfully",
  FABRIC_UPDATE_SUCCESS: "Fabric updated successfully",
  //End: fabric sectiom //

  //Start  : Condition section//
  CONDITION_ADD_SUCCESS: "Condition added successfully",
  CONDITION_UPDATE_SUCCESS: "Condition updated successfully",
  //end : Condition section //

  //Start  : designer section//
  DESIGNER_ADD_SUCCESS: "Designer added successfully",
  DESIGNER_UPDATE_SUCCESS: "Designer updated successfully",
  //end : designer section //

  // Start : customer Section//
  CUSTOMER_UPDATE_SUCCESS: "Customer details updated successfully",
  // End : customer Section//
  // Start : admin Section//
  ADMIN_UPDATE_SUCCESS: "Admin details updated successfully",
  // End : admin Section//
 // Start: change password
  PASSWORD_UPDATE_SUCCESS: "Password changed successfully",
  // EndL change password

  TEMPLATE_UPDATE_SUCCESS: "Email template updated successfully",

  SERVER_NOT_RESPONDING: "Server not responding",

  FILL_ALL_DETAILS: "Please fill all the necessary details",
  UNAUTHORIZED_ACCESS: "Unauthorized Access"
};

export const element_ids = {
  NAVBAR_ID: "navbarSupportedContent"
};

export const default_const = {
  NO_USER_IMAGE: "",
  // SESSION_TIMOUT_DURATION: 600,
  SESSION_TIMOUT_DURATION: 3600,
  ARRAY_LIMIT: 5,
  ROW_LIMIT: 5,
  PHONE_NUMBER_COUNTRY: "SG",
  PHONE_NUMBER_COUNTRY_CODE: "+65",

  MONTH_LIST: () => {
    const array = [
      {
        name: "January",
        short: "Jan",
        number: 1,
        days: 31
      },
      {
        name: "February",
        short: "Feb",
        number: 2,
        days: 28
      },
      {
        name: "March",
        short: "Mar",
        number: 3,
        days: 31
      },
      {
        name: "April",
        short: "Apr",
        number: 4,
        days: 30
      },
      {
        name: "May",
        short: "May",
        number: 5,
        days: 31
      },
      {
        name: "June",
        short: "Jun",
        number: 6,
        days: 30
      },
      {
        name: "July",
        short: "Jul",
        number: 7,
        days: 31
      },
      {
        name: "August",
        short: "Aug",
        number: 8,
        days: 31
      },
      {
        name: "September",
        short: "Sep",
        number: 9,
        days: 30
      },
      {
        name: "October",
        short: "Oct",
        number: 10,
        days: 31
      },
      {
        name: "November",
        short: "Nov",
        number: 11,
        days: 30
      },
      {
        name: "December",
        short: "Dec",
        number: 12,
        days: 31
      }
    ];
    return array;
  },

  YEAR_LIST: (START, END) => {
    const array = [];
    for (let index = START; index < END; index++) {
      array.push({ key: index, value: index });
    }
    return array;
  }
};
