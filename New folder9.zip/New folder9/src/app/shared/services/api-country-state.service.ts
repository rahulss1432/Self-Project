import { Injectable } from "@angular/core";
import { ApiHandler } from "@app/shared/services/api-handler.service";
import { ServiceBase } from "@app/shared/baseClass/services-base.class";
import { API } from "environments/environment";

@Injectable()
export class ApiCountryStateService extends ServiceBase {
  customer_id: any;
  constructor(apiHandler: ApiHandler) {
    super(apiHandler);
  }

  getCountries() {
    const url = API.COUNTRIES_ENDPOINTS.GET_COUNTRIES_LIST;
    return this.apiHandler.apiGet(url);
  }

  getStates(Country) {
    const url = API.STATES_ENDPOINTS.GET_STATES_LIST(Country);
    return this.apiHandler.apiGet(url);
  }



}
