import { Directive, DoCheck, Input, ElementRef, Renderer, Renderer2, AfterViewInit } from "@angular/core";

@Directive({
  selector: "[appInputFocus]"
})
export class InputFocusDirective implements DoCheck {
  public valLength;
  @Input()
  appInputFocus;
  constructor(public el: ElementRef, public renderer: Renderer2) {}

  ngDoCheck() {
    const valLength = this.el.nativeElement.value.length;
    // console.log("valLength " + valLength);
    if (valLength > 0) {
      // this.renderer.setElementClass(this.el.nativeElement.parentElement, "hasvalue", true);
      this.renderer.addClass(this.el.nativeElement.parentElement, "isfocused");
    } else {
      this.renderer.removeClass(this.el.nativeElement.parentElement, "isfocused");
    }
  }
}
