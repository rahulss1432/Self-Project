import { Injectable } from '@angular/core';
import {
  Router,
  NavigationEnd,
  ActivatedRoute,
  NavigationStart
} from '@angular/router';
import 'rxjs/add/operator/filter';
import { timeInterval } from 'rxjs/operator/timeInterval';
import { AuthService } from '@app/auth/services/auth-service.service';

declare var $: any;
@Injectable()
export class OnRouteService {
  constructor(private router: Router, private authService: AuthService) {
    this.router.events.filter(e => e instanceof NavigationStart).subscribe({
      next: (event: any) => {
        if (event.url === '/login' && this.authService.isLoggedIn()) {
          this.router.navigate(['/dashboard']);
        }
      }
    });

    this.router.events.filter(e => e instanceof NavigationEnd).subscribe({
      next: (event: any) => {
        setInterval(() => {
          $('.table-responsive').mCustomScrollbar({
            axis: 'x',
            theme: 'light'
          });
        }, 1000);
      }
    });
  }
}
