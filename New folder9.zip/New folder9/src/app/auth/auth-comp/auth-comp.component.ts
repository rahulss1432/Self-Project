import { ToasterService } from './../../shared/services/toaster.service';
import { NgForm, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth-service.service';
import { TokenManager } from '@app/shared/services/token-manager.service';
import { Title } from '@angular/platform-browser';
import { notification_msg } from '@app/shared/constants/consts';
import * as $ from "jquery";
export interface loginFormFields {
  email: any;
  password: any;
}

@Component({
  selector: 'app-auth-comp',
  templateUrl: './auth-comp.component.html'
})
export class AuthComponent implements OnInit {
  loading: boolean;
  loginModel: loginFormFields = {
    email: '',
    password: ''
  };
  login_form: FormGroup;
  isLoggedIn: boolean;
  constructor(
    private router: Router,
    private auth: AuthService,
    private tokenManager: TokenManager,
    private toasterService: ToasterService,
    private titleService: Title,
    private fb: FormBuilder
  ) {}

  ngOnInit() {
    $('#preloader').hide();
    this.titleService.setTitle('Login | Grooms Market');  
    this.tokenManager.deleteToken();
    this.createform();
  }

  ngAfterViewInit() {
     this.rippleEffect();
  }
  createform() {
    this.login_form = this.fb.group({
      email: [
        this.loginModel.email,
        Validators.compose([
          Validators.required,
          Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/)
        ])
      ],
      password: [
        this.loginModel.password,
        Validators.compose([Validators.required])
      ]
    });
  }

  login() {
    if (this.login_form.valid) {
      this.loading = true;
      this.auth
        .loginUser(this.login_form.value.email, this.login_form.value.password)
        .subscribe({
          next: response => {
            // console.log(response);
            if (response.success) {
              this.toasterService.Success('Login Successful');
              this.router.navigate(['/admin/dashboard']);
              this.loading = false;
            } else {
              this.toasterService.Error('Invalid email or password');
              this.loading = false;
            }
          },
          error: err => {
            this.loading = false;
            switch (err.status) {
              case 400:
                this.toasterService.Error('Invalid email or password');
                break;

              case 503:
                this.toasterService.Error('Service Unavailable');
                break;

              default:
                this.toasterService.Error('Please try again');
                break;
            }
          }
        });
    } else {
      // if form is not valid
      this.loading = false;
      Object.keys(this.login_form.controls).forEach(field => {
        const control = this.login_form.get(field);
        control.markAsTouched({ onlySelf: true });
        control.markAsDirty({ onlySelf: true });
      });
      this.toasterService.Error(notification_msg.FILL_ALL_DETAILS);
    }
  }



  get email() {
    return this.login_form.get('email');
  }
  get password() {
    return this.login_form.get('password');
  }
  rippleEffect() { 
    $(".ripple-effect, .ripple-effect-dark").click(function (e) {
      // Remove any old one
      $(".ripple").remove();
      // Setup
      var posX = $(this).offset().left,
        posY = $(this).offset().top,
        buttonWidth = $(this).width(),
        buttonHeight = $(this).height();
      // Add the element
      $(this).prepend("<span class='ripple'></span>");
      // Make it round!
      if (buttonWidth >= buttonHeight) {
        buttonHeight = buttonWidth;
      } else {
        buttonWidth = buttonHeight;
      }
      // Get the center of the element
      var x = e.pageX - posX - buttonWidth / 2;
      var y = e.pageY - posY - buttonHeight / 2;
      // Add the ripples CSS and start the animation
      $(".ripple").css({
        width: buttonWidth,
        height: buttonHeight,
        top: y + 'px',
        left: x + 'px'
      }).addClass("rippleEffect");
    });
  }
}
