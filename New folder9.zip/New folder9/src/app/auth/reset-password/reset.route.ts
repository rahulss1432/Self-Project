import { ResetPasswordComponent } from './reset-password.component';
import { Routes, RouterModule } from '@angular/router';

const route: Routes = [
  {
    path: '', component: ResetPasswordComponent, children: [
      { path: '', component: ResetPasswordComponent }
    ]
  }
]

export const resetRouting = RouterModule.forChild(route);
