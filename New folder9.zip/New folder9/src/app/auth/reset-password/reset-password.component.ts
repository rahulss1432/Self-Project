import { Subscription } from 'rxjs/subscription';
import { ToasterService } from './../../shared/services/toaster.service';
import { AuthService } from './../services/auth-service.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import * as $ from "jquery";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
  AbstractControl,
  ValidationErrors
} from '@angular/forms';
import { error_msg, notification_msg } from '@app/shared/constants/consts';


export interface ResetPasswordFormFields {
  new_password: any;
  confirm_password: any;
}
@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html'
})
export class ResetPasswordComponent implements OnInit {
  resetForm: FormGroup;
  loading: boolean;
  token: string;
  errorMsg = error_msg;

  initData: ResetPasswordFormFields = {
    new_password: '',
    confirm_password: ''
  };

  private subscription: Subscription;

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private auth: AuthService,
    private titleService: Title,
    private toasterService: ToasterService
  ) {
    this.token = this.activatedRoute.snapshot.params['token'];
    if (!this.token) {
      this.subscription = activatedRoute.queryParams.subscribe(
        (param: any) => (this.token = param['token'])
      );
    }
  }

  ngOnInit() {
    this.titleService.setTitle('Reset Password | Grooms Market');    
    this.createForm();
     this.rippleEffect();
  }

  createForm() {
    this.resetForm = this.fb.group(
      {
        new_password: [
          this.initData.new_password,
          Validators.compose([
            Validators.required,
            Validators.minLength(5),
            Validators.maxLength(12)
          ])
        ],
        confirm_password: [
          this.initData.confirm_password,
          Validators.compose([
            Validators.required,
            Validators.minLength(5),
            Validators.maxLength(12)
          ])
        ]
      },
      {
        validator: this.MatchPassword.bind(this)
      }
    );
  }

  resetPassword() {
    this.loading = true;
    if (this.resetForm.valid) {
      const formVal = this.resetForm.value;
      const formData = {};
      for (const key in formVal) {
        if (formVal.hasOwnProperty(key)) {
          {
            if (key === 'confirm_password') {
              continue;
            }
            if (key === 'new_password') {
              formData['password'] = formVal[key];
              continue;
            }
          }
        }
      }
      formData['token'] = this.token;
      this.auth.resetPassword(formData).subscribe(
        (result: any) => {
          if (result.success === true) {
            this.toasterService.Success(
              notification_msg.PASSWORD_UPDATE_SUCCESS
            );
            this.router.navigate(['/login']);
          } else {
            this.toasterService.Error(result.message);
          }
          this.loading = false;
        },
        err => {
          this.toasterService.Error(err.error.message);
          this.loading = false;
        }
      );
    } else {
      this.loading = false;
      Object.keys(this.resetForm.controls).forEach(key => {
        const control = this.resetForm.get(key);
        control.markAsTouched({ onlySelf: true });
        control.markAsDirty({ onlySelf: true });
      });
      this.toasterService.Error(notification_msg.FILL_ALL_DETAILS);
    }
  }

  MatchPassword(control: AbstractControl): ValidationErrors | null {
    const pass = control.get('new_password').value;
    const confirmedPass = control.get('confirm_password').value;
    if (pass !== confirmedPass) {
      return { passError: { msg: 'Password don\'t match' } };
    } else {
      return null;
    }
  }

  get new_password() {
    return this.resetForm.get('new_password');
  }

  get confirm_password() {
    return this.resetForm.get('confirm_password');
  }
    rippleEffect() { 
    $(".ripple-effect, .ripple-effect-dark").click(function (e) {
      // Remove any old one
      $(".ripple").remove();
      // Setup
      var posX = $(this).offset().left,
        posY = $(this).offset().top,
        buttonWidth = $(this).width(),
        buttonHeight = $(this).height();
      // Add the element
      $(this).prepend("<span class='ripple'></span>");
      // Make it round!
      if (buttonWidth >= buttonHeight) {
        buttonHeight = buttonWidth;
      } else {
        buttonWidth = buttonHeight;
      }
      // Get the center of the element
      var x = e.pageX - posX - buttonWidth / 2;
      var y = e.pageY - posY - buttonHeight / 2;
      // Add the ripples CSS and start the animation
      $(".ripple").css({
        width: buttonWidth,
        height: buttonHeight,
        top: y + 'px',
        left: x + 'px'
      }).addClass("rippleEffect");
    });
  }
}
