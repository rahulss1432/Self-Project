import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import * as $ from "jquery";
import {
  FormsModule,
  NgForm,
  FormGroup,
  FormBuilder,
  Validators
} from "@angular/forms";
import { ToasterService } from "@app/shared/services/toaster.service";
import { AuthService } from "@app/auth/services/auth-service.service";
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { Title } from '@angular/platform-browser';

export interface ForgetPasswordFormFields {
  email: any;
}
@Component({
  selector: "app-forget-password",
  templateUrl: "./forget-password.component.html"
})
export class ForgetPasswordComponent implements OnInit {
  forgetPasswordObject = { email: "" };

  forgetPasswordForm: FormGroup;
  loading = false;
  errorMsg = error_msg;

  initData: ForgetPasswordFormFields = {
    email: ""
  };

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private toasterService: ToasterService,
    private titleService: Title,
    private auth: AuthService
  ) {}

  ngOnInit() {
    $('#preloader').hide();
    this.titleService.setTitle('Forget Password | Grooms Market');    
    this.createForm();
    this.rippleEffect();
  }

  createForm() {
    this.forgetPasswordForm = this.fb.group({
      email: [
        this.initData.email,
        Validators.compose([
          Validators.required,
          Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/),
          Validators.maxLength(100)
        ])
      ]
    });
  }

  onSubmit() {
    this.loading = true;
    if (this.forgetPasswordForm.valid) {
      const formVal = this.forgetPasswordForm.value;
      const formData = {};
      for (const key in formVal) {
        if (formVal.hasOwnProperty(key)) {
          {
            formData[key] = formVal[key];
          }
        }
      }
      this.auth.forgetPassword(formData).subscribe(
        (result: any) => {
          if (result.success === true) {
            this.toasterService.Success(result.message);
          } else {
            this.toasterService.Error(result.message);
          }
          this.forgetPasswordForm.reset();
          this.loading = false;
        },
        err => {
          this.toasterService.Error(err.error.message);
          this.loading = false;
        }
      );
    } else {
      this.loading = false;
      Object.keys(this.forgetPasswordForm.controls).forEach(key => {
        const control = this.forgetPasswordForm.get(key);
        control.markAsTouched({ onlySelf: true });
      });
      this.toasterService.Error(notification_msg.FILL_ALL_DETAILS);
    }
  }


  get email() {
    return this.forgetPasswordForm.get("email");
  }
   rippleEffect() { 
    $(".ripple-effect, .ripple-effect-dark").click(function (e) {
      // Remove any old one
      $(".ripple").remove();
      // Setup
      var posX = $(this).offset().left,
        posY = $(this).offset().top,
        buttonWidth = $(this).width(),
        buttonHeight = $(this).height();
      // Add the element
      $(this).prepend("<span class='ripple'></span>");
      // Make it round!
      if (buttonWidth >= buttonHeight) {
        buttonHeight = buttonWidth;
      } else {
        buttonWidth = buttonHeight;
      }
      // Get the center of the element
      var x = e.pageX - posX - buttonWidth / 2;
      var y = e.pageY - posY - buttonHeight / 2;
      // Add the ripples CSS and start the animation
      $(".ripple").css({
        width: buttonWidth,
        height: buttonHeight,
        top: y + 'px',
        left: x + 'px'
      }).addClass("rippleEffect");
    });
  }
}
