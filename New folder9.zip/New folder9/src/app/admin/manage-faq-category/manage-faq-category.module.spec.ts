import { ManageFaqCategoryModule } from './manage-faq-category.module';

describe('ManageFaqCategoryModule', () => {
  let manageFaqCategoryModule: ManageFaqCategoryModule;

  beforeEach(() => {
    manageFaqCategoryModule = new ManageFaqCategoryModule();
  });

  it('should create an instance', () => {
    expect(manageFaqCategoryModule).toBeTruthy();
  });
});
