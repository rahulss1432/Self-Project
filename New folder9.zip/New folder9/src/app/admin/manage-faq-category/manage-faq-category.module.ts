import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from "@app/shared/module/shared.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { FaqCategoryListComponent } from './faq-category-list/faq-category-list.component';
import { ManageFaqCategoryComponent } from '@app/admin/manage-faq-category/manage-faq-category.component';
import { ManageFaqCategoryRoutingModule } from '@app/admin/manage-faq-category/manage-faq-category-routing.module';
import { ManageFaqCategoryService } from "@app/admin/manage-faq-category/service/manage-faq-category.service";
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    InfiniteScrollModule,
    ManageFaqCategoryRoutingModule
  ],
  declarations: [ManageFaqCategoryComponent, FaqCategoryListComponent],
   providers: [ManageFaqCategoryService]
})
export class ManageFaqCategoryModule { }
