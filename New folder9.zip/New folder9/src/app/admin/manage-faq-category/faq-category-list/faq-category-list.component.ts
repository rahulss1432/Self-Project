import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { API } from "environments/environment";
import { ManageListBase } from "@app/shared/baseClass/list-base.class";
import { ToasterService } from '@app/shared/services/toaster.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { ManageFaqCategoryService } from "@app/admin/manage-faq-category/service/manage-faq-category.service";

export interface FaqCategoryFormFileds {
  name: string;
}
@Component({
  selector: 'app-faq-category-list',
  templateUrl: './faq-category-list.component.html',
  styleUrls: ['./faq-category-list.component.scss']
})
export class FaqCategoryListComponent extends ManageListBase implements OnInit {
  faqCategory_id: number;
  errorMsg = error_msg;
  title = '';
  btnName = '';
  isSubmitted = false;
  faqCategoryDetail: any;
  addUpdateFaqCategoryForm: FormGroup;
  initData: FaqCategoryFormFileds = {
    name: "",
    };
  constructor(
    private titleService: Title,
    private faqcategoryService: ManageFaqCategoryService,
    public toasterService: ToasterService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    private router: Router
  ) {
    super(API.CATEGORIES_ENDPOINTS.GET_CATEGORY_LIST('FAQ'), faqcategoryService, toasterService);
  }

   ngOnInit() {
      this.createCategoryForm();
    this.titleService.setTitle('Manage FaqCategory | Grooms Market');
    super.ngOnInit();
    this.faqCategory_id = 0;
    this.hydrationUrl = API.CATEGORIES_ENDPOINTS.GET_CATEGORY_LIST('FAQ');
  }

   createCategoryForm() {
    this.addUpdateFaqCategoryForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20)
          ])
        ],
      },
    );
  }
  get name() {
    return this.addUpdateFaqCategoryForm.get("name");
  }


  onScroll() {
    if (!this.loading && this.dataList.length < this.totalQueryableData) {
      this.getList(this.page + 1);
    }
  }

  editCategory(id) {
    this.faqcategoryService.getCategoryDetail(API.CATEGORIES_ENDPOINTS.GET_CATEGORY_DETAIL(id)).subscribe({
      next: (result: any) => {
        this. faqCategoryDetail = Object.assign({}, result.data);
        this.faqCategory_id = this.faqCategoryDetail.id;
        this.title = 'Edit Faq Category';
        this.btnName = 'Update';
        this.addUpdateFaqCategoryForm.patchValue(this.faqCategoryDetail);
        this.loading = false;
      },

      error: err => {
        this.toasterService.Error("while fetching data", "Error");
        this.loading = false;
      }
    });

  }

   onSubmit() {
    this.isSubmitted = true;
    if (this.addUpdateFaqCategoryForm.valid) {
      this.loading = true;
      const formVal = this.addUpdateFaqCategoryForm.getRawValue();
      const formData = {};

      formData["name"] = formVal.name;
      formData["type"] = 'faq';
      this.faqcategoryService.addUpdateCategory(formData, this.faqCategory_id).subscribe({
        next: data => {
          this.loading = false;
          if (this.faqCategory_id > 0) {
            this.toasterService.Success(notification_msg.CATEGORY_UPDATE_SUCCESS);
          } else {
            this.toasterService.Success(notification_msg.CATEGORY_ADD_SUCCESS);
          }
          window.location.reload();
        },
        error: err => {
          if (err.error && err.error.error) {
            this.toasterService.Error((err.error.error[0].message));
          } else {
            this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
            //this.checkErrors(err);
          }
          this.loading = false;
        },
        complete: () => { }
      });
    }
  }

  deleteCategory(id) {

    this.confirmService.confirmThis('Are you sure.! do you want to delete this category', () => {
      // ACTION: Do this If user says YES
    super.deleteEntity(API.CATEGORIES_ENDPOINTS.DELETE_CATEGORY(id), id);
   }, function () {
      // ACTION: Do this If user says NO
    });
  }
  AddFaqModal() {
    this.title = 'Add Faq Category';
    this.btnName = 'Add';
    this.addUpdateFaqCategoryForm.reset();
  }
}
