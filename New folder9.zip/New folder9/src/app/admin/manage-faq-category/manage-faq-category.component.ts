import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-faq-category',
  templateUrl: './manage-faq-category.component.html',
  styleUrls: ['./manage-faq-category.component.scss']
})
export class ManageFaqCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
