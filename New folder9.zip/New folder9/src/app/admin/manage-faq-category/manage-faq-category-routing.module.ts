import { Routes, RouterModule } from '@angular/router';
import { ManageFaqCategoryComponent } from '@app/admin/manage-faq-category/manage-faq-category.component';
import { FaqCategoryListComponent } from '@app/admin/manage-faq-category/faq-category-list/faq-category-list.component';

const routes: Routes = [
  { 
    
        path: '', component: ManageFaqCategoryComponent, children: [
          { path: '', component: FaqCategoryListComponent },
        ]
  }
];

export const ManageFaqCategoryRoutingModule = RouterModule.forChild(routes);


