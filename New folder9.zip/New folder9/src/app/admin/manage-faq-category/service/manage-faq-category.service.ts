import { Injectable } from "@angular/core";
import { ApiHandler } from "@app/shared/services/api-handler.service";
import { ServiceBase } from "@app/shared/baseClass/services-base.class";
import { API } from "environments/environment";

@Injectable()
export class ManageFaqCategoryService extends ServiceBase {
  customer_id: any;
  constructor(apiHandler: ApiHandler) {
    super(apiHandler);
  }
 getCategoryDetail(url) {
    return this.apiHandler.apiGet(url);
  }

  addUpdateCategory(formData, id) {
       if(id>0)
    {
      const url = API.CATEGORIES_ENDPOINTS.UPDATE_CATEGORY(id);
    return this.apiHandler.apiPost(url, formData);
    }
    const url = API.CATEGORY_BASE;
    return this.apiHandler.apiPost(url, formData);
 
  }
 

  


}
