import { AdminComponent } from './admin.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChangePasswordComponent } from '@app/admin/manage-change-password/change-password.component';
import { EditProfileComponent } from '@app/admin/edit-profile/edit-profile.component';
import { ManageNotificationsComponent } from './manage-notifications/manage-notifications.component';
const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      {
        path: 'dashboard',
        loadChildren: './dashboard/dashboard.module#DashboardModule'

      },
      { path: "edit-profile", component: EditProfileComponent },
      { path: "change-passowrd", component: ChangePasswordComponent },
      { path: "notifications", component: ManageNotificationsComponent },
      {
        path: "customers",
        loadChildren:
        "./manage-customers/manage-customers.module#ManageCustomersModule"
      },
      {
        path: "categories",
        loadChildren:
        "./manage-category/manage-category.module#ManageCategoryModule"
      },
      {
        path: 'colors',
        loadChildren: './manage-colors/manage-colors.module#ManageColorsModule'
      },
      {
        path: 'conditions',
        loadChildren: './manage-conditions/manage-conditions.module#ManageConditionsModule'
      },
      {
        path: 'product-list',
        loadChildren: './manage-product/manage-product.module#ManageProductModule'
      },
      {
        path: 'fabrics',
        loadChildren: './manage-fabric/manage-fabric.module#ManageFabricModule'
      },
      {
        path: 'designers',
        loadChildren: './manage-designer/manage-designer.module#ManageDesignerModule'
      },
      {
        path: 'testimonials',
        loadChildren: './manage-testimonials/manage-testimonials.module#ManageTestimonialModule'
      },
      {
        path: 'reported-post',
        loadChildren: './manage-reported-post/manage-reported-post.module#ManageReportedPostModule'
      },
      {
        path: 'contacts',
        loadChildren: './manage-contact/manage-contact.module#ManageContactModule'
      },
      {
        path: 'blogs',
        loadChildren: './manage-blog/manage-blog.module#ManageBlogModule'
      },
      {
        path: 'cms',
        loadChildren: './manage-cms/manage-cms.module#ManageCmsModule'
      },
      {
        path: 'faqs',
        loadChildren: './manage-faq/manage-faq.module#ManageFaqModule'
      },
      {
        path: 'faq-categories',
        loadChildren: './manage-faq-category/manage-faq-category.module#ManageFaqCategoryModule'
      },
      {
        path: 'reports',
        loadChildren: './manage-reports/manage-reports.module#ManageReportsModule'
      }
    ]
  }
];

export const AdminRoutingModule = RouterModule.forChild(routes);
