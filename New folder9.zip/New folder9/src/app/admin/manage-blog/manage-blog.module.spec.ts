import { ManageBlogModule } from './manage-blog.module';

describe('ManageBlogModule', () => {
  let manageBlogModule: ManageBlogModule;

  beforeEach(() => {
    manageBlogModule = new ManageBlogModule();
  });

  it('should create an instance', () => {
    expect(manageBlogModule).toBeTruthy();
  });
});
