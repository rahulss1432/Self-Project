import { Routes, RouterModule } from '@angular/router';
import { BlogListComponent } from '@app/admin/manage-blog/blog-list/blog-list.component';
import { ManageBlogComponent } from '@app/admin/manage-blog/manage-blog.component';
import { BlogAddComponent } from './blog-add/blog-add.component';
import { BlogEditComponent } from './blog-edit/blog-edit.component';
const routes: Routes = [
  { 
    path: '', component: ManageBlogComponent, children: [
      { path: '', component: BlogListComponent },
      { path: 'add', component: BlogAddComponent },
      { path: 'edit/:id', component: BlogEditComponent },
    ]
  }
];

export const ManageBlogRoutingModule = RouterModule.forChild(routes);


