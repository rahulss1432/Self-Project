import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from "@app/shared/module/shared.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ManageBlogRoutingModule } from '@app/admin/manage-blog/manage-blog-routing.module';
import { ManageBlogComponent } from '@app/admin/manage-blog/manage-blog.component';
import { BlogListComponent } from '@app/admin/manage-blog/blog-list/blog-list.component';
import { ManageBlogService } from '@app/admin/manage-blog/service/manage-blog.service';
import { BlogAddComponent } from './blog-add/blog-add.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { BlogEditComponent } from './blog-edit/blog-edit.component';
import { NgSelectModule } from '@ng-select/ng-select';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    InfiniteScrollModule,
    ManageBlogRoutingModule,
    NgSelectModule
  ],
  declarations: [ManageBlogComponent, BlogListComponent, BlogAddComponent, BlogEditComponent],
  providers: [ManageBlogService]
})
export class ManageBlogModule { }
