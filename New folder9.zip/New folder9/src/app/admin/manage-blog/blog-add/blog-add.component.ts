import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ToasterService } from '@app/shared/services/toaster.service';
import { ManageBlogService } from '@app/admin/manage-blog/service/manage-blog.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { Router } from '@angular/router';
import { notification_msg, error_msg } from '@app/shared/constants/consts';
import $ from 'jquery'
declare var $: $
export interface blogFormFileds {
  title: string;
  category_id: string;
  description: string;
  author: string;
}

@Component({
  selector: 'app-blog-add',
  templateUrl: './blog-add.component.html',
  styleUrls: ['./blog-add.component.scss']
})
export class BlogAddComponent implements OnInit {
  filename: any;
  type: string;
  loading: boolean;
  categoryList: any;
  addblogForm: FormGroup;
  errorMsg = error_msg;
  isSubmitted: boolean;
  selectedFile: any;
  initData: blogFormFileds = {
    title: "",
    category_id: "",
    description: "",
    author: "",
  };
  constructor(
    private titleService: Title,
    public toasterService: ToasterService,
    private blogService: ManageBlogService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    private router: Router
  ) { }

  ngOnInit() {
    this.createForm();
     this.titleService.setTitle('Add Blog | Grooms Market');
    this.type = 'blog';
    this.blogService.getAllCategoryByType(this.type).subscribe({
      next: (result: any) => {
        this.categoryList = result.data.rows;
        this.loading = false;
      },
      error: err => {
        this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
        this.loading = false;
      },
      complete: () => {
        this.loading = false;
      }
    });
  }

  createForm() {
    this.addblogForm = this.fb.group(
      {
        category_id: [
          this.initData.category_id,
          Validators.compose([
            Validators.required,
          ])
        ],
        title: [
          this.initData.title,
          Validators.compose([
            Validators.required,
            Validators.maxLength(50),
            Validators.pattern(/^[A-za-z\s]+$/)
          ])
        ],
        description: [
          this.initData.description,
          Validators.compose([
            Validators.required,

          ])
        ],
        author: [
          this.initData.author,
          Validators.compose([
            Validators.required,
            Validators.maxLength(50),
            Validators.pattern(/^[A-za-z\s]+$/)

          ])
        ],

      },
    );
  }

  handleImage(event) {
    $('#imgerror').hide();
    this.selectedFile = event.target.files[0]
    this.filename = this.selectedFile.name;
    // console.log(this.selectedFile);
  }
  onSubmit() {
    this.isSubmitted = true;
     if (this.selectedFile) {
    if (this.addblogForm.valid) {
      this.loading = true;
      const formVal = this.addblogForm.value;
      const formData = new FormData();
      formData.append('title', formVal.title);
      formData.append('master_category_id', formVal.category_id);
      formData.append('description', formVal.description);
      formData.append('author', formVal.author);
      formData.append('blog_image', this.selectedFile);
      this.blogService.addblog(formData).subscribe({
        next: data => {
          this.loading = false;
          this.toasterService.Success(notification_msg.BLOG_ADD_SUCCESS);
          this.router.navigate(["/admin/blogs"]);
        },
        error: err => {
          if (err.error && err.error.error) {
            this.toasterService.Error(err.error.error[0].message);
          } else {
            this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
            //this.checkErrors(err);
          }
          this.loading = false;
        },
        complete: () => { }
      });
    }
    } else {
      this.loading = false;
      $('#imgerror').show();
      $('html,body').animate({ scrollTop: 100 });
    }
  }
  get title() {
    return this.addblogForm.get("title");
  }
  get category_id() {
    return this.addblogForm.get("category_id");
  }
  get description() {
    return this.addblogForm.get("description");
  }
  get author() {
    return this.addblogForm.get("author");
  }

}
