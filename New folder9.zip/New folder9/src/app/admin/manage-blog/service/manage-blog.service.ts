import { Injectable } from "@angular/core";
import { ApiHandler } from "@app/shared/services/api-handler.service";
import { ServiceBase } from "@app/shared/baseClass/services-base.class";
import { API } from "environments/environment";

@Injectable()
export class ManageBlogService extends ServiceBase {
  customer_id: any;
  constructor(apiHandler: ApiHandler) {
    super(apiHandler);
  }

 getAllCategoryByType(type:string){
    const url = API.BLOG_ENDPOINTS.GET_CATEGORY(type);
    return this.apiHandler.apiGet(url);
  }
 addblog(formData) {
    const url = API.BLOG_BASE;
    return this.apiHandler.apiPost(url, formData, {
      contentType: {
        isFormDataContent: true
      }
    });
  }

  updateblog(formData, id) {
    const url = API.BLOG_ENDPOINTS.UPDATE_BLOG(id);
    return this.apiHandler.apiPost(url, formData, {
      contentType: {
        isFormDataContent: true
      }
    });
  }

  getblogDetail(url) {
    return this.apiHandler.apiGet(url);
  }
  


}
