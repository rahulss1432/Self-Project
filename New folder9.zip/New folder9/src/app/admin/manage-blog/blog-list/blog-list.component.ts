import { Component, OnInit } from '@angular/core';
import { ManageListBase } from '@app/shared/baseClass/list-base.class';
import { ToasterService } from '@app/shared/services/toaster.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { API } from 'environments/environment';
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { ManageBlogService } from '@app/admin/manage-blog/service/manage-blog.service';
import { AlertService } from "@app/shared/component/admin/alert-box/alert.service";

@Component({
  selector: 'app-blog-list',
  templateUrl: './blog-list.component.html',
  styleUrls: ['./blog-list.component.scss']
})
export class BlogListComponent extends ManageListBase implements OnInit {
  constructor(
    private titleService: Title,
    public toasterService: ToasterService,
    private blogService: ManageBlogService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    private alertService: AlertService,
    private router: Router) {
    super(API.BLOG_ENDPOINTS.GET_BLOG_LIST, blogService, toasterService);
  }

  ngOnInit() {
    this.titleService.setTitle('Manage Blogs | Grooms Market');
    super.ngOnInit();
    this.hydrationUrl = API.BLOG_ENDPOINTS.GET_BLOG_LIST;
  }


  updateStatus(id, currentStatus) {
    this.alertService.alert('Are you sure.! do you want to change status', () => {
      // ACTION: Do this If user says YES
      let newStatus;
      if (currentStatus === "active") {
        newStatus = "inactive";
      } else {
        newStatus = "active";
      }
      super.updateStatus(
        API.BLOG_ENDPOINTS.BLOG_STATUS_UPDATE_URL(id),
        id,
        newStatus
      );

    }, function () {
      // ACTION: Do this If user says NO
    });
  }

  onScroll() {
    if (!this.loading && this.dataList.length < this.totalQueryableData) {
      this.getList(this.page + 1);
    }
  }

  deleteblog(id) {
    this.confirmService.confirmThis('Are you sure.! do you want to delete this blog', () => {
      // ACTION: Do this If user says YES
      super.deleteEntity(API.BLOG_ENDPOINTS.DELETE_BLOG(id), id);

    }, function () {
      // ACTION: Do this If user says NO
    });
  }

}
