import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { AdminComponent } from "./admin.component";
import { AdminFooterComponent } from '@app/shared/component/admin/admin-footer/admin-footer.component';
import { AdminModalComponent } from '@app/shared/component/admin/admin-modal/admin-modal.component';
import { Routes, RouterModule } from "@angular/router";
import { AdminRoutingModule } from "./admin-routing.module";
import { SharedModule } from "@app/shared/module/shared.module";
import { ConfirmComponent } from "@app/shared/component/admin/confirm-box/confirm.component";
import { AlertComponent } from "@app/shared/component/admin/alert-box/alert.component";
import { ChangePasswordComponent } from "@app/admin/manage-change-password/change-password.component";
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { ColorPickerModule } from 'ngx-color-picker';
import { EditProfileService } from "@app/admin/edit-profile/service/edit-profile.service";
import { ManageNotificationsComponent } from './manage-notifications/manage-notifications.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    AdminRoutingModule,
    ColorPickerModule,
    NgSelectModule,
    NgbModule
  ],
  declarations: [
    AdminComponent,
    AdminFooterComponent,
    AdminModalComponent,
    ConfirmComponent,
    AlertComponent,
    //ChangePasswordComponent
    ChangePasswordComponent,
    EditProfileComponent,
    ManageNotificationsComponent,

  ],
  providers: [EditProfileService]

})
export class AdminModule { }
