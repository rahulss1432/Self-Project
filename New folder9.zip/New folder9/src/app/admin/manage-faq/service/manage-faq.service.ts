import { Injectable } from "@angular/core";
import { ApiHandler } from "@app/shared/services/api-handler.service";
import { ServiceBase } from "@app/shared/baseClass/services-base.class";
import { API } from "environments/environment";

@Injectable()
export class ManageFaqService extends ServiceBase {
  customer_id: any;
  constructor(apiHandler: ApiHandler) {
    super(apiHandler);
  }

  getAllCategoryByType(type:string){
    const url = API.FAQ_ENDPOINTS.GET_CATEGORY(type);
    return this.apiHandler.apiGet(url);
  }


  addfaq(formData) {
    const url = API.FAQ_BASE;
    return this.apiHandler.apiPost(url, formData);
  }

  updateFaq(formData, id) {
    console.log(formData);
    const url = API.FAQ_ENDPOINTS.UPDATE_FAQ(id);
    return this.apiHandler.apiPost(url, formData);
  }

  getFaqDetail(url) {
    return this.apiHandler.apiGet(url);
  }
  


  


}
