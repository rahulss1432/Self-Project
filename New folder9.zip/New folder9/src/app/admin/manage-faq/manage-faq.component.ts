import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-faq',
  templateUrl: './manage-faq.component.html',
  styleUrls: ['./manage-faq.component.scss']
})
export class ManageFaqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
