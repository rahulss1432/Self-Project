import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ToasterService } from '@app/shared/services/toaster.service';
import { ManageFaqService } from '@app/admin/manage-faq/service/manage-faq.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { Router } from '@angular/router';
import { notification_msg, error_msg } from '@app/shared/constants/consts';

export interface faqFormFileds {
  title: string;
  category_id: string;
  description: string;
}


@Component({
  selector: 'app-faq-add',
  templateUrl: './faq-add.component.html',
  styleUrls: ['./faq-add.component.scss']
})
export class FaqAddComponent implements OnInit {
  type: string;
  loading: boolean;
  categoryList: any;
  addFaqForm:FormGroup;
  errorMsg = error_msg;

  initData: faqFormFileds = {
    title: "",
    category_id: "",
    description: "",
  };
  isSubmitted: boolean;

  constructor(private titleService: Title,
    public toasterService: ToasterService,
    private faqService: ManageFaqService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    private router: Router) { }

  ngOnInit() {
    this.createForm();
    this.type = 'faq';
    this.faqService.getAllCategoryByType(this.type).subscribe({
      next: (result: any) => {
        this.categoryList =  result.data.rows;
        console.log(this.categoryList);
        this.loading = false;
      },
      error: err => {
        this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
        this.loading = false;
      },
      complete: () => {
        this.loading = false;
      }});
  }

  createForm() {
    this.addFaqForm = this.fb.group(
      {
        category_id: [
          this.initData.category_id,
          Validators.compose([
            Validators.required,
          ])
        ],
        title: [
          this.initData.title,
          Validators.compose([
            Validators.required,
            Validators.maxLength(50),
          ])
        ],
        description: [
          this.initData.description,
          Validators.compose([
            Validators.required,

          ])
        ],

      },
    );
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.addFaqForm.valid) {
      this.loading = true;
      const formVal = this.addFaqForm.value;
      const formData = {};
      formData["title"] = formVal.title;
      formData["master_category_id"] = formVal.category_id;
      formData["description"] = formVal.description;

      this.faqService.addfaq(formData).subscribe({
        next: data => {
          this.loading = false;
          this.toasterService.Success(notification_msg.FAQ_ADD_SUCCESS);
          this.router.navigate(["/admin/faqs"]);
        },
        error: err => {
          if (err.error && err.error.error) {
            this.toasterService.Error(err.error.error[0].message);
          } else {
            this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
            //this.checkErrors(err);
          }
          this.loading = false;
        },
        complete: () => { }
      });
    }
  }

  get title() {
    return this.addFaqForm.get("title");
  }
  get category_id() {
    return this.addFaqForm.get("category_id");
  }
  get description() {
    return this.addFaqForm.get("description");
  }

}
