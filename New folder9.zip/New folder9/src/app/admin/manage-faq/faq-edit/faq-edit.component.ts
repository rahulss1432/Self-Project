import { Component, OnInit } from '@angular/core';
import { ManageListBase } from '@app/shared/baseClass/list-base.class';
import { ToasterService } from '@app/shared/services/toaster.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { API } from 'environments/environment';
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { ManageFaqService } from '@app/admin/manage-faq/service/manage-faq.service';

export interface faqFormFileds {
  title: string;
  master_category_id: string;
  description: string;
}

@Component({
  selector: 'app-faq-edit',
  templateUrl: './faq-edit.component.html',
  styleUrls: ['./faq-edit.component.scss']
})
export class FaqEditComponent implements OnInit {


  editFaqForm: FormGroup;
  errorMsg = error_msg;
  isSubmitted = false;

  initData: faqFormFileds = {
    title: "",
    master_category_id: "",
    description: "",
  };
  loading: boolean;
  faq_id: any;
  faqDetail: any;
  categoryList: any;
  type: string;
  selected_category: any;
  constructor(private titleService: Title,
    public toasterService: ToasterService,
    private faqService: ManageFaqService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    public activatedRoute: ActivatedRoute,
    private router: Router) {

  }

  ngOnInit() {
    this.getAllCategory();
    this.createForm();
    this.titleService.setTitle('Edit Cms | Grooms Market');
    this.loading = true;
    this.activatedRoute.paramMap
      .switchMap((params: ParamMap) => {
        this.faq_id = params.get("id");
        return this.faqService.getFaqDetail(
          API.FAQ_ENDPOINTS.GET_FAQ_DETAIL(this.faq_id)
        );
      })
      .subscribe({
        next: (result: any) => {
          this.faqDetail = Object.assign({}, result.data);
           this.selected_category =   this.faqDetail.master_category_id
          this.editFaqForm.patchValue(this.faqDetail);

          this.loading = false;
        },
        error: err => {
          this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
          this.loading = false;
        },
        complete: () => {
          this.loading = false;
        }
      });
  }

  getAllCategory(){
    this.type = 'faq';
    this.faqService.getAllCategoryByType(this.type).subscribe({
      next: (result: any) => {
        this.categoryList =  result.data.rows;
        this.loading = false;
      },
      error: err => {
        this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
        this.loading = false;
      },
      complete: () => {
        this.loading = false;
      }});
  }

  createForm() {
    this.editFaqForm = this.fb.group(
      {
        master_category_id: [
          this.initData.master_category_id,
          Validators.compose([
            Validators.required,
          ])
        ],
        title: [
          this.initData.title,
          Validators.compose([
            Validators.required,
            Validators.maxLength(50),
          ])
        ],
        description: [
          this.initData.description,
          Validators.compose([
            Validators.required,

          ])
        ],

      },
    );
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.editFaqForm.valid) {
      this.loading = true;
      const formVal = this.editFaqForm.value;
      const formData = {};
      formData["title"] = formVal.title;
      formData["master_category_id"] = formVal.master_category_id;
      formData["description"] = formVal.description;

      this.faqService.updateFaq(formData, this.faq_id).subscribe({
        next: data => {
          this.loading = false;
          this.toasterService.Success(notification_msg.FAQ_UPDATE_SUCCESS);
          this.router.navigate(["/admin/faqs"]);
        },
        error: err => {
          if (err.error && err.error.error) {
            this.toasterService.Error((err.error.error[0].message));
          } else {
            this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
            //this.checkErrors(err);
          }
          this.loading = false;
        },
        complete: () => { }
      });
    }
  }


  get title() {
    return this.editFaqForm.get("title");
  }
  get master_category_id() {
    return this.editFaqForm.get("master_category_id");
  }
  get description() {
    return this.editFaqForm.get("description");
  }


}
