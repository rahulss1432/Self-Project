import { ManageFaqModule } from './manage-faq.module';

describe('ManageFaqModule', () => {
  let manageFaqModule: ManageFaqModule;

  beforeEach(() => {
    manageFaqModule = new ManageFaqModule();
  });

  it('should create an instance', () => {
    expect(manageFaqModule).toBeTruthy();
  });
});
