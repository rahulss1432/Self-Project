import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from "@app/shared/module/shared.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ManageFaqComponent } from '@app/admin/manage-faq/manage-faq.component';
import { FaqListComponent } from './faq-list/faq-list.component';
import { ManageFaqRoutingModule } from '@app/admin/manage-faq/manage-faq-routing.module';
import { ManageFaqService } from '@app/admin/manage-faq/service/manage-faq.service';
import { FaqAddComponent } from './faq-add/faq-add.component';
import { FaqEditComponent } from './faq-edit/faq-edit.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { NgSelectModule } from '@ng-select/ng-select';
import { EditorModule } from '@tinymce/tinymce-angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    InfiniteScrollModule,
    ReactiveFormsModule,
    SharedModule,
    EditorModule,
    ManageFaqRoutingModule,
    NgSelectModule
  ],
  declarations: [ManageFaqComponent, FaqListComponent, FaqAddComponent, FaqEditComponent],
  providers: [ManageFaqService]
})
export class ManageFaqModule { }
