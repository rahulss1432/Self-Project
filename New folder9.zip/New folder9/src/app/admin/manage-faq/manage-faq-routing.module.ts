import { Routes, RouterModule } from '@angular/router';
import { ManageFaqComponent } from '@app/admin/manage-faq/manage-faq.component';
import { FaqListComponent } from '@app/admin/manage-faq/faq-list/faq-list.component';
import { FaqAddComponent } from '@app/admin/manage-faq/faq-add/faq-add.component';
import { FaqEditComponent } from '@app/admin/manage-faq/faq-edit/faq-edit.component';

const routes: Routes = [
  { 
    
        path: '', component: ManageFaqComponent, children: [
          { path: '', component: FaqListComponent },
          { path: 'add-faq', component: FaqAddComponent },
          { path: 'edit/:id', component: FaqEditComponent },
        ]
  }
];

export const ManageFaqRoutingModule = RouterModule.forChild(routes);


