import { Component, ViewChild, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import * as $ from "jquery";
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  header_title = 'Dashboard';
  constructor(private router: Router) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        // console.log(event.urlAfterRedirects);
        this.setHeading(event.urlAfterRedirects);  
        this.rippleEffect();
        
      }
    });

  }

  ngOnInit() {
    
  }
  ngAfterViewInit() {
     this.rippleEffect();
  }

  setHeading(url: string) {
    switch (url) {
      case '/admin/dashboard':
        this.header_title = 'DASHBOARD';
        break;
      case '/admin/customers':
        this.header_title = 'MANAGE CUSTOMERS';
        break;
      case '/admin/colors':
        this.header_title = 'MANAGE COLOR';
        break;
      case '/admin/categories':
        this.header_title = 'MANAGE CATEGORY';
        break;
      case '/admin/conditions':
        this.header_title = 'Manage CONDITIONS';
        break;
      case '/admin/change-passowrd':
        this.header_title = 'CHANGE PASSWORD';
        break;
      case '/admin/product-list':
        this.header_title = 'MANAGE PRODUCT';
        break;
      case '/admin/fabrics':
        this.header_title = 'MANAGE FABRICS';
        break;
      case '/admin/testimonials':
        this.header_title = 'MANAGE TESTIMONIALS';
        break;
      case '/admin/testimonials/add':
        this.header_title = 'ADD TESTIMONIALS';
        break;
      case '/admin/testimonials/edit':
        this.header_title = 'EDIT TESTIMONIALS';
        break;
      case '/admin/cms':
        this.header_title = 'MANAGE CMS';
        break;
      case '/admin/faq-categories':
        this.header_title = 'MANAGE FAQ CATEGORIES';
        break;
      case '/admin/faqs':
        this.header_title = 'MANAGE FAQ';
        break;
      case '/admin/faqs/add-faq':
        this.header_title = 'ADD FAQ';
        break;
      case '/admin/designers':
        this.header_title = 'MANAGE DESIGNERS';
        break;
      case '/admin/blogs':
        this.header_title = 'MANAGE BLOG';
        break;
      case '/admin/blogs/add':
        this.header_title = 'ADD BLOG';
        break;
      case '/admin/reported-post':
        this.header_title = 'MANAGE REPORTED POST';
        break;
      case '/admin/contacts':
        this.header_title = 'MANAGE CONTACT';
        break;
      case '/admin/reports':
        this.header_title = 'MANAGE REPORTS';
        break;
      case '/admin/notifications':
        this.header_title = 'MANAGE NOTIFICATIONS';
        break;
      default:
        if (url.includes('/customers/detail/')) {
          this.header_title = 'CUSTOMERS DETAILS';
        } else if (url.includes('/customers/edit/')) {
          this.header_title = 'EDIT CUSTOMERS';
        } else if (url.includes('/testimonials/detail/')) {
          this.header_title = 'TESTIMONIALS DETAILS';
        } else if (url.includes('/testimonials/edit/')) {
          this.header_title = 'EDIT TESTIMONIALS';
        } else if (url.includes('/cms/edit/')) {
          this.header_title = 'EDIT CMS';
        } else if (url.includes('/faqs/edit/')) {
          this.header_title = 'EDIT FAQ';
        } else if (url.includes('/contacts/contact-detail')) {
        } else if (url.includes('/blogs/edit/')) {
          this.header_title = 'EDIT BLOG';
        } else if (url.includes('/contacts/contact-detail')) {
          this.header_title = 'CONTACT DETAILS';
        }
        break;
    }
  }
   rippleEffect() { 
    $(".ripple-effect, .ripple-effect-dark").click(function (e) {
      // Remove any old one
      $(".ripple").remove();
      // Setup
      var posX = $(this).offset().left,
        posY = $(this).offset().top,
        buttonWidth = $(this).width(),
        buttonHeight = $(this).height();
      // Add the element
      $(this).prepend("<span class='ripple'></span>");
      // Make it round!
      if (buttonWidth >= buttonHeight) {
        buttonHeight = buttonWidth;
      } else {
        buttonWidth = buttonHeight;
      }
      // Get the center of the element
      var x = e.pageX - posX - buttonWidth / 2;
      var y = e.pageY - posY - buttonHeight / 2;
      // Add the ripples CSS and start the animation
      $(".ripple").css({
        width: buttonWidth,
        height: buttonHeight,
        top: y + 'px',
        left: x + 'px'
      }).addClass("rippleEffect");
    });
  }

}
