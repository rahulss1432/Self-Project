import { Injectable } from "@angular/core";
import { ApiHandler } from "@app/shared/services/api-handler.service";
import { ServiceBase } from "@app/shared/baseClass/services-base.class";
import { API } from "environments/environment";

@Injectable()
export class ManageDesignerService extends ServiceBase {
  customer_id: any;
  constructor(apiHandler: ApiHandler) {
    super(apiHandler);
  }

  addUpdateDesigner(formData,id:number) {
    if(id>0)
    {
      const url = API.DESIGNER_ENDPOINTS.UPDATE_DESIGNER(id);
      return this.apiHandler.apiPost(url, formData);
    }
    const url = API.DESIGNER_BASE;
    return this.apiHandler.apiPost(url, formData);
  }

  getDesignerDetail(url){
    return this.apiHandler.apiGet(url);
  }

 

  


}
