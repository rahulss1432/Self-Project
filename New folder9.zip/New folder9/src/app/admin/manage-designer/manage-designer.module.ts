import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RouterModule } from "@angular/router";
import { SharedModule } from "@app/shared/module/shared.module";
import { ManageDesignerRoutingModule } from '@app/admin/manage-designer/manage-designer-routing.module';
import { ManageDesignerComponent } from "@app/admin/manage-designer/manage-designer.component";
import { DesignerListComponent } from "@app/admin/manage-designer/designer-list/designer-list.component";
import { ManageDesignerService } from "@app/admin/manage-designer/service/manage-designer.service";
import { InfiniteScrollModule } from "ngx-infinite-scroll";
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    NgbModule,
    RouterModule,
    InfiniteScrollModule,
    ReactiveFormsModule,
    ManageDesignerRoutingModule
  ],
  declarations: [ManageDesignerComponent, DesignerListComponent],
   providers: [ManageDesignerService]
})
export class ManageDesignerModule { }
