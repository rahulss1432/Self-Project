import { ManageDesignerModule } from './manage-designer.module';

describe('ManageDesignerModule', () => {
  let manageDesignerModule: ManageDesignerModule;

  beforeEach(() => {
    manageDesignerModule = new ManageDesignerModule();
  });

  it('should create an instance', () => {
    expect(manageDesignerModule).toBeTruthy();
  });
});
