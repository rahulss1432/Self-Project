import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { API } from "environments/environment";
import { ManageListBase } from "@app/shared/baseClass/list-base.class";
import { ToasterService } from '@app/shared/services/toaster.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { ManageDesignerService } from "@app/admin/manage-designer/service/manage-designer.service";
import { AlertService } from "@app/shared/component/admin/alert-box/alert.service";
export interface DesignerFormFileds {
  name: string;
}
@Component({
  selector: 'app-designer-list',
  templateUrl: './designer-list.component.html',

})
export class DesignerListComponent extends ManageListBase implements OnInit {
  designer_id: number;
  errorMsg = error_msg;
  queryObj: {};
  title = '';
  btnName = '';
  isSubmitted = false;
  designerDetail: any;
  suggested_by_name: any;
  addUpdateDesignerForm: FormGroup;
  initData: DesignerFormFileds = {
    name: "",
  };
  constructor(
    private titleService: Title,
    private designerService: ManageDesignerService,
    public toasterService: ToasterService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    private alertService: AlertService,
    private router: Router) {
    super(API.DESIGNER_ENDPOINTS.GET_DESIGNER_LIST, designerService, toasterService);
  }

  ngOnInit() {
    this.createForm();
    this.titleService.setTitle('Manage Designers | Grooms Market');
    super.ngOnInit();
    this.designer_id = 0;
    this.hydrationUrl = API.DESIGNER_ENDPOINTS.GET_DESIGNER_LIST;
  }
  AddDesignerModal() {
    this.title = 'Add Designer';
    this.btnName = 'Add';
    this.addUpdateDesignerForm.reset();
  }


  onScroll() {
    if (!this.loading && this.dataList.length < this.totalQueryableData) {
      this.getList(this.page + 1, this.queryObj);
    }
  }

  createForm() {
    this.addUpdateDesignerForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.maxLength(20),
          ])
        ],
      },
    );
  }
  onSubmit() {
    this.isSubmitted = true;
    if (this.addUpdateDesignerForm.valid) {
      this.loading = true;
      const formVal = this.addUpdateDesignerForm.getRawValue();
      const formData = {};

      formData["name"] = formVal.name;
      console.log(formVal.name);
      this.designerService.addUpdateDesigner(formData, this.designer_id).subscribe({
        next: data => {
          this.loading = false;
          if (this.designer_id > 0) {
            this.toasterService.Success(notification_msg.DESIGNER_UPDATE_SUCCESS);
          } else {
            this.toasterService.Success(notification_msg.DESIGNER_ADD_SUCCESS);
          }
          window.location.reload();
        },
        error: err => {
          if (err.error && err.error.error) {
            this.toasterService.Error((err.error.error[0].message));
          } else {
            this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
            //this.checkErrors(err);
          }
          this.loading = false;
        },
        complete: () => { }
      });
    }
  }

  editDesignerDetail(id) {
    this.designerService.getDesignerDetail(API.DESIGNER_ENDPOINTS.GET_DESIGNER_DETAIL(id)).subscribe({
      next: (result: any) => {
        this.designerDetail = Object.assign({}, result.data);
        // console.log(this.designerDetail);
        this.designer_id = this.designerDetail.id;
        this.title = 'Edit Designer';
        this.btnName = 'Update';
        this.addUpdateDesignerForm.patchValue(this.designerDetail);
        this.loading = false;
      },

      error: err => {
        this.toasterService.Error("while fetching data", "Error");
        this.loading = false;
      }
    });


  }

  get name() {
    return this.addUpdateDesignerForm.get("name");
  }

  updateStatus(id, currentStatus) {
    this.alertService.alert('Are you sure.! do you want to change status', () => {
      // ACTION: Do this If user says YES
      let newStatus;
      if (currentStatus === "active") {
        newStatus = "inactive";
      } else {
        newStatus = "active";
      }
      super.updateStatus(
        API.DESIGNER_ENDPOINTS.DESIGNER_STATUS_UPDATE_URL(id),
        id,
        newStatus
      );

    }, function () {
      // ACTION: Do this If user says NO
    });
  }
  deleteDesigner(id) {

    this.confirmService.confirmThis('Are you sure.! do you want to delete this designer', () => {
      // ACTION: Do this If user says YES
      super.deleteEntity(API.DESIGNER_ENDPOINTS.DELETE_DESIGNER(id), id);

    }, function () {
      // ACTION: Do this If user says NO
    });
  }

}
