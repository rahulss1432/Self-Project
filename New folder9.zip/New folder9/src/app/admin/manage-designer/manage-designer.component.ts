import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-designer',
  templateUrl: './manage-designer.component.html',
  styleUrls: ['./manage-designer.component.scss']
})
export class ManageDesignerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
