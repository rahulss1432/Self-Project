
import { Routes, RouterModule } from '@angular/router';
import { ManageDesignerComponent } from "@app/admin/manage-designer/manage-designer.component";
import { DesignerListComponent } from "@app/admin/manage-designer/designer-list/designer-list.component";
const route: Routes = [

  {
    path: '', component: ManageDesignerComponent,children: [
      { path: '', component: DesignerListComponent },

    ]
  }
];
export const ManageDesignerRoutingModule = RouterModule.forChild(route);
