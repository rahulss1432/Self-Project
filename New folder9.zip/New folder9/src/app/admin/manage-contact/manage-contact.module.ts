import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RouterModule } from "@angular/router";
import { SharedModule } from "@app/shared/module/shared.module";
import { ManageContactRoutingModule } from '@app/admin/manage-contact/manage-contact-routing.module';
import { ManageContactComponent } from '@app/admin/manage-contact/manage-contact.component';
import { ContactListComponent } from "@app/admin/manage-contact/contact-list/contact-list.component";
import { ContactDetailComponent } from '@app/admin/manage-contact/contact-detail/contact-detail.component';
import { InfiniteScrollModule } from "ngx-infinite-scroll";
import { ManageContactService } from "@app/admin/manage-contact/service/manage-condition.service";

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    NgbModule,
    RouterModule,
    InfiniteScrollModule,
    ReactiveFormsModule,
    ManageContactRoutingModule
  ],
  declarations: [ManageContactComponent, ContactListComponent, ContactDetailComponent],
  providers: [ManageContactService]
})
export class ManageContactModule { }
