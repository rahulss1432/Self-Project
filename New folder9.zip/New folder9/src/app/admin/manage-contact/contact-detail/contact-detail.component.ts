import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ToasterService } from "@app/shared/services/toaster.service";
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { API } from "environments/environment";
import { notification_msg } from "@app/shared/constants/consts";
import { UtilityFunctionService } from "@app/shared/services/utility-function.service";
import { ManageContactService } from '@app/admin/manage-contact/service/manage-condition.service';
@Component({
  selector: 'app-contact-detail',
  templateUrl: './contact-detail.component.html',
  styleUrls: ['./contact-detail.component.scss']
})
export class ContactDetailComponent implements OnInit {
  loading: boolean;
  contact_id: string;
  contactDetail: any;

  constructor(
    private titleService: Title,
    public contactService: ManageContactService,
    public toasterService: ToasterService,
    public router: Router,
    public activatedRoute: ActivatedRoute,
  ) { }


  ngOnInit() {
    // this.getcountry();
    this.titleService.setTitle('Contact-Us Details | Grooms Market');
    this.loading = true;
    this.activatedRoute.paramMap
      .switchMap((params: ParamMap) => {
        this.contact_id = params.get("id");
        return this.contactService.getContactUsDetail(
          API.CONTACT_ENDPOINTS.GET_CONTACT_DETAIL(this.contact_id)
        );
      })
      .subscribe({
        next: (result: any) => {
          this.contactDetail = Object.assign({}, result.data);
          this.loading = false;
        },
        error: err => {
          this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
          this.loading = false;
        },
        complete: () => {
          this.loading = false;
        }
      });
  }
}
