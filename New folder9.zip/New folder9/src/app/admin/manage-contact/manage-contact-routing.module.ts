
import { Routes, RouterModule } from '@angular/router';
import { ManageContactComponent } from '@app/admin/manage-contact/manage-contact.component';
import { ContactListComponent } from "@app/admin/manage-contact/contact-list/contact-list.component";
import { ContactDetailComponent } from '@app/admin/manage-contact/contact-detail/contact-detail.component';

const route: Routes = [

  {
    path: '', component: ManageContactComponent, children: [
      { path: '', component: ContactListComponent },
      { path: 'contact-detail/:id', component: ContactDetailComponent },
    ]
  }
];
export const ManageContactRoutingModule = RouterModule.forChild(route);
