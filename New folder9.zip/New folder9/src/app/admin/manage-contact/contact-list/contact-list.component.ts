import { Component, OnInit } from '@angular/core';
import { ManageListBase } from '@app/shared/baseClass/list-base.class';
import { ToasterService } from '@app/shared/services/toaster.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { API } from 'environments/environment';
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { ManageContactService } from '@app/admin/manage-contact/service/manage-condition.service';


@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',

})
export class ContactListComponent extends ManageListBase implements OnInit {

  queryObj: {};
  cmsFilterForm: FormGroup;
  
  errorMsg = error_msg;
  isSubmitted = false;
  conditionDetail: any;


  constructor(private titleService: Title,
    public toasterService: ToasterService,
    private contactService: ManageContactService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    private router: Router) {
      super(API.CONTACT_ENDPOINTS.GET_CONTACT_LIST, contactService, toasterService);
     }

     ngOnInit() {
      this.titleService.setTitle('Manage Contacts | Grooms Market');
      super.ngOnInit();
      this.hydrationUrl = API.CONTACT_ENDPOINTS.GET_CONTACT_LIST;
    }

    onScroll() {
      if (!this.loading && this.dataList.length < this.totalQueryableData) {
        this.getList(this.page + 1, this.queryObj);
      }
    }

}
