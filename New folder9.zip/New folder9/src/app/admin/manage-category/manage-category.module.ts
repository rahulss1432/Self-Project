import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListCategoryComponent } from './list-category/list-category.component';
import { ManageCategoryComponent } from './manage-category.component';
import { SharedModule } from "@app/shared/module/shared.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ManageCategoryRoutingModule } from "./manage-category-routing.module";
import { ManageCategoryService } from "@app/admin/manage-category/service/manage-category.service";
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    ReactiveFormsModule,
    InfiniteScrollModule,
    ManageCategoryRoutingModule,
  ],
  declarations: [ManageCategoryComponent,ListCategoryComponent],
    providers: [ManageCategoryService]
})
export class ManageCategoryModule { }
