import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-manage-category',
  templateUrl: 'manage-category.component.html'
})

export class ManageCategoryComponent implements OnInit {

  constructor() {
    
  }

  ngOnInit() {
    
  }

}
