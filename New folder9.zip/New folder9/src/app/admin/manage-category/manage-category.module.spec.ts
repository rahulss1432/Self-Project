import { ManageCategoryModule } from './manage-category.module';

describe('ManageCategoryModule', () => {
  let manageCategoryModule: ManageCategoryModule;

  beforeEach(() => {
    manageCategoryModule = new ManageCategoryModule();
  });

  it('should create an instance', () => {
    expect(manageCategoryModule).toBeTruthy();
  });
});
