import { ListCategoryComponent } from './list-category/list-category.component';
import { Routes, RouterModule } from '@angular/router';
import { ManageCategoryComponent } from '@app/admin/manage-category/manage-category.component';

const routes: Routes = [
  { 
    path: '', component: ManageCategoryComponent, children: [
      { path: '', component: ListCategoryComponent },
    ]
  }
];

export const ManageCategoryRoutingModule = RouterModule.forChild(routes);


