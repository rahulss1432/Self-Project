import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { Title } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from "@app/shared/services/toaster.service";
import { ManageCategoryService } from "@app/admin/manage-category/service/manage-category.service";
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';/* confirm box service */
import { AlertService } from '@app/shared/component/admin/alert-box/alert.service';/* alert box service */
import { ManageListBase } from "@app/shared/baseClass/list-base.class";
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { API } from "environments/environment";
export interface CategoryFormFileds {
  name: string;
}
@Component({
  selector: 'app-list-category',
  templateUrl: './list-category.component.html',
  styleUrls: ['./list-category.component.scss']
})
export class ListCategoryComponent extends ManageListBase implements OnInit {
  UpdateCategoryForm: FormGroup;
  errorMsg = error_msg;
  category_id: number;
  categoryModel: any;
  isSubmitted = false;
  categoryDetail: any;
  initData: CategoryFormFileds = {
    name: "",
  };

  constructor(
    private titleService: Title,
    public fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public toasterService: ToasterService,
    public categoryService: ManageCategoryService,
    private confirmService: ConfirmService,
    private alertService: AlertService,
  ) {
    super(API.CATEGORIES_ENDPOINTS.GET_CATEGORY_LIST('product'), categoryService, toasterService);
  }

  ngOnInit() {
    this.titleService.setTitle('Manage Categories | Grooms Market');
    super.ngOnInit();
    this.createCategoryForm();

    this.hydrationUrl = API.CATEGORIES_ENDPOINTS.GET_CATEGORY_LIST('product');
  }

  createCategoryForm() {
    this.UpdateCategoryForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20)
          ])
        ],
      },
    );
  }
  get name() {
    return this.UpdateCategoryForm.get("name");
  }
   updateStatus(id, currentStatus) {
         this.alertService.alert('Are you sure.! do you want to change status', () => {
       // ACTION: Do this If user says YES
      let newStatus;
    if (currentStatus === "active") {
      newStatus = "inactive";
    } else {
      newStatus = "active";
    }
    super.updateStatus(
      API.CATEGORIES_ENDPOINTS.CATEGORY_STATUS_UPDATE_URL(id),
      id,
      newStatus
    );

    }, function () {
      // ACTION: Do this If user says NO
    });
  }
    
  
  onScroll() {
    if (!this.loading && this.dataList.length < this.totalQueryableData) {
      this.getList(this.page + 1);
    }
  }
  editCategory(id) {
    this.categoryService.getCategoryDetail(API.CATEGORIES_ENDPOINTS.GET_CATEGORY_DETAIL(id)).subscribe({
      next: (result: any) => {
        this. categoryDetail = Object.assign({}, result.data);
        this.category_id = this.categoryDetail.id;
        this.UpdateCategoryForm.patchValue(this.categoryDetail);
        this.loading = false;
      },

      error: err => {
        this.toasterService.Error("while fetching data", "Error");
        this.loading = false;
      }
    });

  }
  updateCategory() {
    this.isSubmitted = true;
    if (this.UpdateCategoryForm.valid) {
       this.loading = true;
      const formVal = this.UpdateCategoryForm.getRawValue();
      const formData = {};

      formData["name"] = formVal.name;
      console.log(formVal.name);
      this.categoryService.addUpdateCategory(formData, this.category_id).subscribe({
        next: data => {
          this.loading = false;
          this.toasterService.Success(notification_msg.CATEGORY_UPDATE_SUCCESS);
          window.location.reload();
        },
        error: err => {
          if (err.error && err.error.error) {
            this.toasterService.Error(err.error.error[0].message);
          } else {
            this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
            //this.checkErrors(err);
          }
          this.loading = false;
        },
        complete: () => { }
      });

    }
  }
  deleteCategory(id) {

    this.confirmService.confirmThis('Are you sure.! do you want to delete this category', () => {
      // ACTION: Do this If user says YES
    super.deleteEntity(API.CATEGORIES_ENDPOINTS.DELETE_CATEGORY(id), id);
   }, function () {
      // ACTION: Do this If user says NO
    });
  }
}
