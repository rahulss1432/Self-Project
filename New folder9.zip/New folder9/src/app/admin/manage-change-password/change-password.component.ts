import { Router } from "@angular/router";
import { ToasterService } from "./../../shared/services/toaster.service";
import { AuthService } from "./../../auth/services/auth-service.service";
import { Component, OnInit } from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  Validators,
  AbstractControl,
  ValidationErrors
} from "@angular/forms";
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { Title } from '@angular/platform-browser';
import * as $ from "jquery";

export interface PasswordResetFormFields {
  current_password: any;
  new_password: any;
  confirm_password: any;
}

@Component({
  selector: "app-change-password",
  templateUrl: "./change-password.component.html"
})
export class ChangePasswordComponent implements OnInit {
  passwordResetForm: FormGroup;
  loading = false;
  errorMsg = error_msg;

  initData: PasswordResetFormFields = {
    current_password: "",
    new_password: "",
    confirm_password: ""
  };

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router,
    private toasterService: ToasterService,
    private titleService: Title
  ) {}

  ngOnInit() {
    this.createForm();
    this.titleService.setTitle('Change Password | Grooms Market');
  }

  createForm() {
    this.passwordResetForm = this.fb.group(
      {
        current_password: [
          this.initData.current_password,
          Validators.compose([
            Validators.required,
            Validators.minLength(7),
            Validators.maxLength(14)
          ])
        ],
        new_password: [
          this.initData.new_password,
          Validators.compose([
            Validators.required,
            Validators.minLength(7),
            Validators.maxLength(14)
          ])
        ],
        confirm_password: [
          this.initData.confirm_password,
          Validators.compose([
            Validators.required,
            Validators.minLength(7),
            Validators.maxLength(14)
          ])
        ]
      },
      {
        validator: this.MatchPassword.bind(this)
      }
    );
  }

  onSubmit() {
    this.loading = true;
    if (this.passwordResetForm.valid) {
      const formVal = this.passwordResetForm.value;
      const formData = {};
      for (const key in formVal) {
        if (formVal.hasOwnProperty(key)) {
          {
            if (key === "confirm_password") {
              continue;
            }
            formData[key] = formVal[key];
          }
        }
      }
      this.auth
        .changePassword(formData)
        .subscribe(
          (result: any) => {
            if (result.success === true) {
              this.toasterService.Success(notification_msg.PASSWORD_UPDATE_SUCCESS);
              this.router.navigate(["/admin/dashboard"]);
            } else {
              this.toasterService.Error(result.error.message);
            }
            this.loading = false;
          },
          err => {
            this.loading = false;
            // TODO: Print proper message
            // this.toasterService.Error("Current Password Does not match");
            if (err.error && err.error.error) {
              this.toasterService.Error((err.error.error[0].message));
            }  else {
              this.toasterService.Error(
                notification_msg.SERVER_NOT_RESPONDING
              );
            }

          }
        );
    } else {
      this.toasterService.Error(notification_msg.FILL_ALL_DETAILS);
      Object.keys(this.passwordResetForm.controls).forEach(key => {
        const control = this.passwordResetForm.get(key);
        control.markAsTouched({ onlySelf: true });
      });
      this.loading = false;
    }
  }

  MatchPassword(control: AbstractControl): ValidationErrors | null {
    const pass = control.get("new_password").value;
    const confirmedPass = control.get("confirm_password").value;
    if (pass !== confirmedPass) {
      return { passError: { msg: "Password don't match" } };
    } else {
      return null;
    }
  }

  get current_password() {
    return this.passwordResetForm.get("current_password");
  }

  get new_password() {
    return this.passwordResetForm.get("new_password");
  }

  get confirm_password() {
    return this.passwordResetForm.get("confirm_password");
  }

}
