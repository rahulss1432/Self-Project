import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-reports',
  templateUrl: './manage-reports.component.html',
  styleUrls: ['./manage-reports.component.scss']
})
export class ManageReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
