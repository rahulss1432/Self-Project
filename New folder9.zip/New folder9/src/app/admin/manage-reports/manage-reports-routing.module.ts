import { Routes, RouterModule } from '@angular/router';
import { ManageReportsComponent } from '@app/admin/manage-reports/manage-reports.component';
import { ReportsListComponent } from "@app/admin/manage-reports/reports-list/reports-list.component";

const route: Routes = [

  {
    path: '', component: ManageReportsComponent,children: [
      { path: '', component: ReportsListComponent },

    ]
  }
];
export const ManageReportsRoutingModule = RouterModule.forChild(route);
