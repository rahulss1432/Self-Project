import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RouterModule } from "@angular/router";
import { SharedModule } from "@app/shared/module/shared.module";
import { ManageReportsRoutingModule } from '@app/admin/manage-reports/manage-reports-routing.module';
import { ManageReportsComponent } from '@app/admin/manage-reports/manage-reports.component';
import { ReportsListComponent } from "@app/admin/manage-reports/reports-list/reports-list.component";
import { InfiniteScrollModule } from "ngx-infinite-scroll";
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    NgbModule,
    RouterModule,
    ReactiveFormsModule,
    InfiniteScrollModule,
    ManageReportsRoutingModule
  ],
  declarations: [ManageReportsComponent, ReportsListComponent]
})
export class ManageReportsModule { }
