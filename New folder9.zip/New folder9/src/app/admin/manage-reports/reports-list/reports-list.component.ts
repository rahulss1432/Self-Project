import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reports-list',
  templateUrl: './reports-list.component.html',

})
export class ReportsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
