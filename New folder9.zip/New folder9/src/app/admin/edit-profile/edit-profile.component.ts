import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { ToasterService } from "@app/shared/services/toaster.service";
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { AuthService } from "./../../auth/services/auth-service.service";
import { EditProfileService } from "@app/admin/edit-profile/service/edit-profile.service";
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { API } from "environments/environment";
import $ from 'jquery'
declare var $: $
export interface EditprofileFormFileds {
  id: string;
  full_name: string;
  email: string;
}
@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss']
})
export class EditProfileComponent implements OnInit {
   currentuserDetails: any;
   userDetails: any;
   userdetail:any;
   profileImage:any;
  errorMsg = error_msg;
  editprofileForm: FormGroup;
  selectedFile: any;
  initData: EditprofileFormFileds = {
    id: "",
    full_name: "",
    email: "",
    };
  constructor(
    public fb: FormBuilder,
    public authService: AuthService,
    public profileService: EditProfileService,
    public toasterService: ToasterService,
    public router: Router,
    private route: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.createForm();
    this.currentuserDetails = this.authService.getUserDetail();
     this.getUserDetails(this.currentuserDetails.id);
    //  this.editprofileForm.patchValue(this.userDetails);
    // console.log(this.userDetails);
  }

 createForm() {
    this.editprofileForm = this.fb.group(
      {
        id: [
          this.initData.id,
        ],
        full_name: [
          this.initData.full_name,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20),
            Validators.pattern(/^[A-za-z\s]+$/)
          ])
        ],
        email: [
          this.initData.email,
          Validators.compose([
            Validators.required,
            Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/),
            Validators.maxLength(100)
          ])
        ]
       },
    );
  }
  getUserDetails(id) {
    this.profileService.getUserDetail(API.CUSTOMER_ENDPOINTS.GET_CUSTOMER_DETAIL(id)).subscribe({
      next: (result: any) => {
        this. userDetails = Object.assign({}, result.data);
         this.userdetail = this.userDetails.user_profile;
        this.profileImage = this.userdetail.profile_image;
        this.editprofileForm.patchValue(this.userDetails);
        this.editprofileForm.patchValue(this.userdetail);
        },
      error: err => {
        this.toasterService.Error("while fetching data", "Error");
       
      }
    });

  }
  handleImage(event) {
    $('#imgerror').hide();
    this.selectedFile = event.target.files[0]
  }
  updateProfile(){
      if (this.selectedFile) {
      $('#imgerror').hide();
       if (this.editprofileForm.valid) {
       const formVal = this.editprofileForm.value;
        const formData = new FormData();
        for (const key in formVal) {
          if (formVal.hasOwnProperty(key)) {
            {
              if (key === "update_profile") {
                continue;
              }
              formData.append(key, formVal[key]);
            }
          }
        }
        formData.append('profile_image', this.selectedFile);
          this.profileService.updateProfile(formData, this.userDetails.id).subscribe({
          next: data => {
            
            this.toasterService.Success(notification_msg.ADMIN_UPDATE_SUCCESS);
            this.router.navigate(["/admin/dashboard"]);
          },
          error: err => {
            if (err.error && err.error.error) {
              this.toasterService.Error(err.error.error[0].message);
            } else {
              this.toasterService.Error(
                notification_msg.SERVER_NOT_RESPONDING
              );
            }
          },
          complete: () => { }
        });
      }
    } else {
      $('#imgerror').show();
    }
  }
 get id() {
    return this.editprofileForm.get("id");
  }
  get full_name() {
    return this.editprofileForm.get("full_name");
  }
  get email() {
    return this.editprofileForm.get("email");
  }
}
