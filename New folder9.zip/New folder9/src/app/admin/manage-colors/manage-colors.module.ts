import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from "@app/shared/module/shared.module";
import { ManageColorsRoutingModule } from './manage-colors-routing.module';
import { ListColorComponent } from './list-color/list-color.component';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {Routes, RouterModule } from "@angular/router";
import { ManageColorService } from '@app/admin/manage-colors/service/manage-color.service';
import { ColorPickerModule } from 'ngx-color-picker';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    SharedModule,
    ManageColorsRoutingModule,
    InfiniteScrollModule,
    ColorPickerModule
  ],
  declarations: [ListColorComponent],
  providers: [ManageColorService]
})
export class ManageColorsModule { }
