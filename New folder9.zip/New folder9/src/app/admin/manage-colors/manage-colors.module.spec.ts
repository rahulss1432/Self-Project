import { ManageColorsModule } from './manage-colors.module';

describe('ManageColorsModule', () => {
  let manageColorsModule: ManageColorsModule;

  beforeEach(() => {
    manageColorsModule = new ManageColorsModule();
  });

  it('should create an instance', () => {
    expect(manageColorsModule).toBeTruthy();
  });
});
