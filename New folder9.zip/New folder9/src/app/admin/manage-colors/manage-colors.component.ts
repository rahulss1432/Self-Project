import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-colors',
  templateUrl: './manage-colors.component.html',
  styleUrls: ['./manage-colors.component.scss']
})
export class ManageColorsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
