import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import {
  FormGroup,
  FormBuilder,
  Validators
} from "@angular/forms";
import { ToasterService } from '@app/shared/services/toaster.service';
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { Router } from "@angular/router";
import { ManageListBase } from "@app/shared/baseClass/list-base.class";
import { API } from "environments/environment";
import { ManageColorService } from '@app/admin/manage-colors/service/manage-color.service';
import { ColorPickerService } from 'ngx-color-picker';
import { AlertService } from "@app/shared/component/admin/alert-box/alert.service";
declare var $: any;
export interface ColorFormFileds {
  name: string;
}
@Component({
  selector: 'app-list-color',
  templateUrl: './list-color.component.html',
  styleUrls: ['./list-color.component.scss']
})

export class ListColorComponent extends ManageListBase implements OnInit {

  public addColor: string = '#000000';
  public editColor: string = '#000000';
  addUpdateColorForm: FormGroup;

  queryObj: {};
  color_id: number;
  colorModel: any;
  isSubmitted = false;
  show = true;
  title = 'Add Color';
  btnName = 'Add'
  colorDetail: any;
  colorFilterForm: FormGroup;
  errorMsg = error_msg;
  initData: ColorFormFileds = {
    name: "",
  };

  constructor(
    private titleService: Title,
    private confirmService: ConfirmService,
    private fb: FormBuilder,
    private router: Router,
    public toasterService: ToasterService,
    private cpService: ColorPickerService,
    public colorService: ManageColorService,
    public alertService: AlertService,
  )  {
    super(API.COLOR_ENDPOINTS.GET_COLOR_LIST,colorService, toasterService);
  }

  ngOnInit() {
    this.createForm();
    this.createColorForm();
    this.titleService.setTitle('Manage Colors | Grooms Market');
    super.ngOnInit();
    this.hydrationUrl = API.COLOR_ENDPOINTS.GET_COLOR_LIST;
    this.color_id = 0;
  }
  AddColorModal() {
    this.title = 'Add Color';
    this.btnName = 'Add';
    this.addUpdateColorForm.reset();
  }
  createForm() {
    this.colorFilterForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.maxLength(50),
            Validators.pattern(/^[A-za-z\s]+$/)
          ])
        ],
      },
    );
  }

  createColorForm() {
    this.addUpdateColorForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20)
          ])
        ],
      },
    );
  }

  getColorList() {
    if (this.colorFilterForm.valid) {
      this.queryObj = this.getFormData();
      this.dataList = [];
      this.getList(1, this.queryObj);
    } else {
      this.toasterService.Error(notification_msg.FILL_ALL_DETAILS);
    }
  }

  getFormData() {
    const formVal = this.colorFilterForm.value;
    const queryObj = formVal;
    return queryObj;
  }

  updateStatus(id, currentStatus) {
      this.alertService.alert('Are you sure.! do you want to change status', () => {
       // ACTION: Do this If user says YES
      let newStatus;
    if (currentStatus === "active") {
      newStatus = "inactive";
    } else {
      newStatus = "active";
    }
    super.updateStatus(
      API.COLOR_ENDPOINTS.COLOR_STATUS_UPDATE_URL(id),
      id,
      newStatus
    );

    }, function () {
      // ACTION: Do this If user says NO
    });
  }
  onScroll() {
    if (!this.loading && this.dataList.length < this.totalQueryableData) {
      this.getList(this.page + 1, this.queryObj);
    }
  }
  onSubmit() {
    this.isSubmitted = true;
    if (this.addUpdateColorForm.valid) {
      this.loading = true;
      const formVal = this.addUpdateColorForm.getRawValue();
      const formData = {};

      formData["name"] = formVal.name;
      this.colorService.addUpdateColor(formData, this.color_id).subscribe({
        next: data => {
          this.loading = false;
          if(this.color_id > 0){
            this.toasterService.Success(notification_msg.COLOR_UPDATE_SUCCESS);

          }else{
            this.toasterService.Success(notification_msg.COLOR_ADD_SUCCESS);
          }

          window.location.reload();
          //this.router.navigate(["/admin/colors"]);
        },
        error: err => {
          if (err.error && err.error.error) {
            this.toasterService.Error(err.error.error[0].message);
          } else {
            this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
            //this.checkErrors(err);
          }
          this.loading = false;
        },
        complete: () => { }
      });
    }
  }

  get name() {
    return this.addUpdateColorForm.get("name");
  }

  deleteColor(id) {

    this.confirmService.confirmThis('Are you sure.! do you want to delete this color', () => {
      // ACTION: Do this If user says YES
      super.deleteEntity(API.COLOR_ENDPOINTS.DELETE_COLOR(id), id);

    }, function () {
      // ACTION: Do this If user says NO
    });
  }

  editColorDetail(id) {
    this.colorService.getColorDetail(API.COLOR_ENDPOINTS.GET_COLOR_DETAIL(id)).subscribe({
      next: (result: any) => {
        this.colorDetail = Object.assign({}, result.data);
        this.color_id = this.colorDetail.id;
        this.title = 'Edit Color';
        this.btnName = 'Update';
        this.addUpdateColorForm.patchValue(this.colorDetail);
        this.loading = false;
      },

      error: err => {
        this.toasterService.Error("while fetching data", "Error");
        this.loading = false;
      }
    });


  }

}
