import { Injectable } from "@angular/core";
import { ApiHandler } from "@app/shared/services/api-handler.service";
import { ServiceBase } from "@app/shared/baseClass/services-base.class";
import { API } from "environments/environment";

@Injectable()
export class ManageColorService extends ServiceBase {
  customer_id: any;
  constructor(apiHandler: ApiHandler) {
    super(apiHandler);
  }

  addUpdateColor(formData,id:number) {
    if(id>0)
    {
      const url = API.COLOR_ENDPOINTS.UPDATE_COLOR(id);
      return this.apiHandler.apiPost(url, formData);
    }
    const url = API.COLOR_BASE;
    return this.apiHandler.apiPost(url, formData);
  }

  
  getColorDetail(url) {
    return this.apiHandler.apiGet(url);
  }

  


}
