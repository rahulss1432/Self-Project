import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListColorComponent } from '@app/admin/manage-colors/list-color/list-color.component';

const route: Routes = [
  {
    path: "",
    component: ListColorComponent,
    children: [
      { path: "", component: ListColorComponent },
      ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(route)],
  exports: [RouterModule]
})
export class ManageColorsRoutingModule { }
