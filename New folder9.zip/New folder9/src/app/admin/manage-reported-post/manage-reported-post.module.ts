import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RouterModule } from "@angular/router";
import { SharedModule } from "@app/shared/module/shared.module";
import { ManageReportedPostRoutingModule } from '@app/admin/manage-reported-post/manage-reported-post-routing.module';
import { ManageReportedPostComponent } from '@app/admin/manage-reported-post/manage-reported-post.component';
import { ReportedPostListComponent } from "@app/admin/manage-reported-post/reported-post-list/reported-post-list.component";
import { InfiniteScrollModule } from "ngx-infinite-scroll";
import { ManageReportPostService } from "@app/admin/manage-reported-post/service/manage-report-post.service";
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    NgbModule,
    RouterModule,
    ReactiveFormsModule,
    InfiniteScrollModule,
    ManageReportedPostRoutingModule
  ],
  declarations: [ManageReportedPostComponent, ReportedPostListComponent],
  providers:[ManageReportPostService]
})
export class ManageReportedPostModule { }
