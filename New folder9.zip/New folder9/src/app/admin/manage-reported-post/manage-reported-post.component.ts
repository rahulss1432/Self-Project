import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-reported-post',
  templateUrl: './manage-reported-post.component.html',
  styleUrls: ['./manage-reported-post.component.scss']
})
export class ManageReportedPostComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
