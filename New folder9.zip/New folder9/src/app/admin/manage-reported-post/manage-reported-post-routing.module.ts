import { Routes, RouterModule } from '@angular/router';
import { ManageReportedPostComponent } from '@app/admin/manage-reported-post/manage-reported-post.component';
import { ReportedPostListComponent } from "@app/admin/manage-reported-post/reported-post-list/reported-post-list.component";

const route: Routes = [

  {
    path: '', component: ManageReportedPostComponent,children: [
      { path: '', component: ReportedPostListComponent },

    ]
  }
];
export const ManageReportedPostRoutingModule = RouterModule.forChild(route);
