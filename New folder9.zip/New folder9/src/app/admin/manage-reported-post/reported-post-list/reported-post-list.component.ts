import { Component, OnInit } from '@angular/core';
import { ManageListBase } from '@app/shared/baseClass/list-base.class';
import { ToasterService } from '@app/shared/services/toaster.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { API } from 'environments/environment';
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { ManageContactService } from '@app/admin/manage-contact/service/manage-condition.service';
import { ManageReportPostService } from '@app/admin/manage-reported-post/service/manage-report-post.service';
import { AlertService } from "@app/shared/component/admin/alert-box/alert.service";

@Component({
  selector: 'app-reported-post-list',
  templateUrl: './reported-post-list.component.html',

})
export class ReportedPostListComponent extends ManageListBase implements OnInit {

  queryObj: {};
  cmsFilterForm: FormGroup;

  errorMsg = error_msg;
  isSubmitted = false;
  conditionDetail: any;
  loading: any;


  constructor(private titleService: Title,
    public toasterService: ToasterService,
    private reportPostService: ManageReportPostService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    private alertService: AlertService,
    private router: Router) {
    super(API.REPORT_POST_ENDPOINTS.GET_REPORT_POST_LIST, reportPostService, toasterService);
  }

  ngOnInit() {
    this.titleService.setTitle('Manage Report Post | Grooms Market');
    super.ngOnInit();
    this.hydrationUrl = API.REPORT_POST_ENDPOINTS.GET_REPORT_POST_LIST;
  }

  onScroll() {
    if (!this.loading && this.dataList.length < this.totalQueryableData) {
      this.getList(this.page + 1, this.queryObj);
    }
  }
  updateStatus(id, currentStatus) {
    this.alertService.alert('Are you sure.! do you want to change status', () => {
      // ACTION: Do this If user says YES
      let newStatus;
      if (currentStatus === "active") {
        newStatus = "inactive";
      } else {
        newStatus = "active";
      }
      super.updateStatus(
        API.REPORT_POST_ENDPOINTS.REPORT_POST_STATUS_UPDATE_URL(id),
        id,
        newStatus
      );

    }, function () {
      // ACTION: Do this If user says NO
    });
  }

}
