import { Routes, RouterModule } from '@angular/router';
import { FabricListComponent } from '@app/admin/manage-fabric/fabric-list/fabric-list.component';
import { ManageFabricComponent } from '@app/admin/manage-fabric/manage-fabric.component';

const routes: Routes = [
  { 
    path: '', component: ManageFabricComponent, children: [
      { path: '', component: FabricListComponent },
    ]
  }
];

export const ManageFabricRoutingModule = RouterModule.forChild(routes);


