import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-fabric',
  templateUrl: './manage-fabric.component.html',
  styleUrls: ['./manage-fabric.component.scss']
})
export class ManageFabricComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
