import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageFabricComponent } from './manage-fabric.component';
import { FabricListComponent } from './fabric-list/fabric-list.component';
import { SharedModule } from "@app/shared/module/shared.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ManageFabricRoutingModule } from '@app/admin/manage-fabric/manage-fabric-routing.module';
import { ManageFabricService } from '@app/admin/manage-fabric/service/manage-fabric.service';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    InfiniteScrollModule,
    ManageFabricRoutingModule
  ],
  declarations: [ManageFabricComponent, FabricListComponent],
  providers: [ManageFabricService]
})
export class ManageFabricModule { }
