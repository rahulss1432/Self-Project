import { Component, OnInit } from '@angular/core';
import { ManageListBase } from '@app/shared/baseClass/list-base.class';
import { ToasterService } from '@app/shared/services/toaster.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { ManageFabricService } from '@app/admin/manage-fabric/service/manage-fabric.service';
import { API } from 'environments/environment';
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { AlertService } from "@app/shared/component/admin/alert-box/alert.service";

export interface FabricFormFileds {
  name: string;
}
@Component({
  selector: 'app-fabric-list',
  templateUrl: './fabric-list.component.html',
  styleUrls: ['./fabric-list.component.scss']
})
export class FabricListComponent extends ManageListBase implements OnInit {

  initData: FabricFormFileds = {
    name: "",
  };

  queryObj: {};
  fabricFilterForm: FormGroup;
  addUpdateFabricForm: FormGroup;
  errorMsg = error_msg;
  fabric_id: number;
  title = 'Add Fabric';
  btnName = 'Add'
  isSubmitted = false;
  conditionDetail: any;

  constructor(
    private titleService: Title,
    public toasterService: ToasterService,
    private fabricService: ManageFabricService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    private alertService: AlertService,
    private router: Router) {
    super(API.FABRIC_ENDPOINTS.GET_FABRIC_LIST, fabricService, toasterService);
  }

  ngOnInit() {
    this.createForm();
    this.createFabricForm();
    this.titleService.setTitle('Manage Fabrics | Grooms Market');
    super.ngOnInit();
    this.hydrationUrl = API.FABRIC_ENDPOINTS.GET_FABRIC_LIST;
  }

  createForm() {
    this.fabricFilterForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.maxLength(50),
            Validators.pattern(/^[A-za-z\s]+$/)
          ])
        ],
      },
    );
  }

  createFabricForm() {
    this.addUpdateFabricForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20)
          ])
        ],
      },
    );
  }

  getFabricList() {
    this.queryObj = this.getFormData();
    this.dataList = [];
    this.getList(1, this.queryObj);
  }

  AddFabricModal() {
    this.title = 'Add Fabric';
    this.btnName = 'Add';
    this.addUpdateFabricForm.reset();
  }


  onScroll() {
    if (!this.loading && this.dataList.length < this.totalQueryableData) {
      this.getList(this.page + 1, this.queryObj);
    }
  }


  onSubmit() {
    this.isSubmitted = true;
    if (this.addUpdateFabricForm.valid) {
      this.loading = true;
      const formVal = this.addUpdateFabricForm.getRawValue();
      const formData = {};
   formData["name"] = formVal.name;
        // console.log(formVal.name);
        this.fabricService.addUpdateFabric(formData, this.fabric_id).subscribe({
          next: data => {
            this.loading = false;
            if (this.fabric_id > 0) {
              this.toasterService.Success(notification_msg.FABRIC_UPDATE_SUCCESS);
            } else {
              this.toasterService.Success(notification_msg.FABRIC_ADD_SUCCESS);
            }
            window.location.reload();
          },
          error: err => {
            if (err.error && err.error.error) {
              this.toasterService.Error((err.error.error[0].message));
            }  else {
              this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
              //this.checkErrors(err);
            }
            this.loading = false;
          },
          complete: () => { }
        });
      }

    }
 


  updateStatus(id, currentStatus) {
    this.alertService.alert('Are you sure.! do you want to change status', () => {
      // ACTION: Do this If user says YES
      let newStatus;
      if (currentStatus === "active") {
        newStatus = "inactive";
      } else {
        newStatus = "active";
      }
      super.updateStatus(
        API.FABRIC_ENDPOINTS.FABRIC_STATUS_UPDATE_URL(id),
        id,
        newStatus
      );

    }, function () {
      // ACTION: Do this If user says NO
    });
  }
  editFabricDetail(id) {
    this.fabricService.getFabricDetail(API.FABRIC_ENDPOINTS.GET_FABRIC_DETAIL(id)).subscribe({
      next: (result: any) => {
        this.conditionDetail = Object.assign({}, result.data);
        console.log(this.conditionDetail);
        this.fabric_id = this.conditionDetail.id;
        this.title = 'Edit Fabric';
        this.btnName = 'Update';
        this.addUpdateFabricForm.patchValue(this.conditionDetail);
        this.loading = false;
      },

      error: err => {
        this.toasterService.Error("while fetching data", "Error");
        this.loading = false;
      }
    });


  }


  getFormData() {
    const formVal = this.fabricFilterForm.value;
    const queryObj = formVal;
    return queryObj;
  }

  get name() {
    return this.addUpdateFabricForm.get("name");
  }

  deleteFabric(id) {
    this.confirmService.confirmThis('Are you sure.! do you want to delete this fabric', () => {
      // ACTION: Do this If user says YES
      super.deleteEntity(API.FABRIC_ENDPOINTS.DELETE_FABRIC(id), id);

    }, function () {
      // ACTION: Do this If user says NO
    });
  }

}
