import { ManageFabricModule } from './manage-fabric.module';

describe('ManageFabricModule', () => {
  let manageFabricModule: ManageFabricModule;

  beforeEach(() => {
    manageFabricModule = new ManageFabricModule();
  });

  it('should create an instance', () => {
    expect(manageFabricModule).toBeTruthy();
  });
});
