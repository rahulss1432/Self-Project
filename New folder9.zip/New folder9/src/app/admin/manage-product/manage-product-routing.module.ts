import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from '@app/admin/manage-product/product-list/product-list.component';
import { ManageProductComponent } from '@app/admin/manage-product/manage-product.component';

const routes: Routes = [
  { 
    path: '', component: ManageProductComponent, children: [
      { path: '', component: ProductListComponent },
    ]
  }
];

export const ManageProductRoutingModule = RouterModule.forChild(routes);


