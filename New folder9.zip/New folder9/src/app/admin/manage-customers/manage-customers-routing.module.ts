import { ManageCustomersComponent } from './manage-customers.component';
import { RouterModule, Routes } from '@angular/router';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CustomerDetailComponent } from './customer-detail/customer-detail.component';
import { CustomerEditComponent } from './customer-edit/customer-edit.component';
const routes: Routes = [
  {
    path: '', component: ManageCustomersComponent,children: [
      { path: '', component: CustomerListComponent },
      { path: 'list', component: CustomerListComponent },
      { path: 'detail/:id', component: CustomerDetailComponent },
      { path: 'edit/:id', component: CustomerEditComponent },
    ]
  }
];

export const ManageCustomersRoutingModule = RouterModule.forChild(routes);
