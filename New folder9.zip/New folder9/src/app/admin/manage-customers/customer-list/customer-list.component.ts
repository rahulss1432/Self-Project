import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { Title } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from "@app/shared/services/toaster.service";
import { ManageCustomerService } from "@app/admin/manage-customers/service/manage-customer.service";
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';/* confirm box service */
import { AlertService } from '@app/shared/component/admin/alert-box/alert.service';/* alert box service */
import { ManageListBase } from "@app/shared/baseClass/list-base.class";
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { API } from "environments/environment";
declare var $: any;
export interface SearchFormFileds {
  customername: string;
}
@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.scss']
})
export class CustomerListComponent extends ManageListBase implements OnInit {
  queryObj: {};
  customerModel: any;
  show = true;
  customerFilterForm: FormGroup;
  errorMsg = error_msg;

  initData: SearchFormFileds = {

    customername: ""

  };
  constructor(
    public fb: FormBuilder,
    private titleService: Title,
    private route: ActivatedRoute,
    private router: Router,
    public toasterService: ToasterService,
    public customerService: ManageCustomerService,
    private confirmService: ConfirmService,
    private alertService: AlertService,
  ) {
    super(API.CUSTOMER_ENDPOINTS.GET_CUSTOMER_LIST, customerService, toasterService);
  }

  ngOnInit() {
    this.createForm();
    this.titleService.setTitle('Manage Customers | Grooms Market');
    super.ngOnInit();
    this.hydrationUrl = API.CUSTOMER_ENDPOINTS.GET_CUSTOMER_LIST;
  }

  createForm() {
    this.customerFilterForm = this.fb.group(
      {
        customername: [
          this.initData.customername,
          Validators.compose([
            Validators.maxLength(50),
            Validators.pattern(/^[A-za-z\s]+$/)
          ])
        ],
      },
    );
  }
  getCustomerList() {
    if (this.customerFilterForm.valid) {
      this.queryObj = this.getFormData();
      this.dataList = [];
      this.getList(1, this.queryObj);
    } else {
      this.toasterService.Error(notification_msg.FILL_ALL_DETAILS);
    }
  }

  getFormData() {
    const formVal = this.customerFilterForm.value;
    const queryObj = formVal;
    return queryObj;
  }

  updateStatus(id, currentStatus) {
    
       this.alertService.alert('Are you sure.! do you want to change status', () => {
       // ACTION: Do this If user says YES
      let newStatus;
    if (currentStatus === "active") {
      newStatus = "inactive";
    } else {
      newStatus = "active";
    }
    super.updateStatus(
      API.CUSTOMER_ENDPOINTS.CUSTOMER_STATUS_UPDATE_URL(id),
      id,
      newStatus
    );

    }, function () {
      // ACTION: Do this If user says NO
    });
  }
    
 
  onScroll() {
    if (!this.loading && this.dataList.length < this.totalQueryableData) {
      this.getList(this.page + 1, this.queryObj);
    }
  }
  get customername() {
    return this.customerFilterForm.get("customername");
  }
  /* fucntion for delete customer*/
  deleteCustomer(id) {
    this.confirmService.confirmThis('Are you sure.! do you want to delete this customer', () => {
      // ACTION: Do this If user says YES
      super.deleteEntity(API.CUSTOMER_ENDPOINTS.DELETE_CUSTOMER(id), id);

    }, function () {
      // ACTION: Do this If user says NO
    });
  }
}
