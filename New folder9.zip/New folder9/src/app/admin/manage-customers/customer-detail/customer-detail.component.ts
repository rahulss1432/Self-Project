import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ToasterService } from "@app/shared/services/toaster.service";
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { API } from "environments/environment";
import { notification_msg } from "@app/shared/constants/consts";
import { ManageCustomerService } from "@app/admin/manage-customers/service/manage-customer.service";
import { UtilityFunctionService } from "@app/shared/services/utility-function.service";
import { ApiCountryStateService } from "@app/shared/services/api-country-state.service";
import $ from 'jquery'
declare var $: $
@Component({
  selector: 'app-customer-detail',
  templateUrl: './customer-detail.component.html',
  styleUrls: ['./customer-detail.component.scss']
})
export class CustomerDetailComponent implements OnInit {
  loading: boolean;
  customerModel: any;
  customer_id: any;
  userdetail: any;
  profileImage: any;
  countryName: any;
  userCountry: any;
  countryList: any;
  stateName: any;
  userState: any;
  stateList: any;
  constructor(
    private titleService: Title,
    public util: UtilityFunctionService,
    public customerService: ManageCustomerService,
    public toasterService: ToasterService,
    public router: Router,
    public activatedRoute: ActivatedRoute,
    public countryStateService: ApiCountryStateService,
  ) { }


  ngOnInit() {
    // this.getcountry();
    this.titleService.setTitle('Customer Details | Grooms Market');
    this.loading = true;
    this.activatedRoute.paramMap
      .switchMap((params: ParamMap) => {
        this.customer_id = params.get("id");
        this.customerService.customer_id = this.customer_id;
        return this.customerService.getCustomerDetail(
          API.CUSTOMER_ENDPOINTS.GET_CUSTOMER_DETAIL(this.customer_id)
        );
      })
      .subscribe({
        next: (result: any) => {
          this.customerModel = Object.assign({}, result.data);
          this.userdetail = this.customerModel.user_profile
          this.profileImage = this.userdetail.profile_image
         this.loading = false;
          this.countryStateService.getCountries()
            .subscribe(
            countryData => {
              this.countryList = countryData['data'];
              this.userCountry = this.countryList.filter(element => {
                return element.id == this.userdetail.country_id;
              });
              this.countryName = this.userCountry[0].name;
            });
          this.countryStateService.getStates(this.userdetail.country_id)
            .subscribe(
            stateData => {
              this.stateList = stateData['data'];
              this.userState = this.stateList.filter(element => {
                return element.id == this.userdetail.state_id;
              });

              this.stateName = this.userState[0].name;
            });
        },
        error: err => {
          this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
          this.loading = false;
        },
        complete: () => {
          this.loading = false;
        }
      });
  }
}
