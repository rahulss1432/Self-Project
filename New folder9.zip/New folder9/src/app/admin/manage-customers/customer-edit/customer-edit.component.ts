import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { ToasterService } from "@app/shared/services/toaster.service";
import { ApiCountryStateService } from "@app/shared/services/api-country-state.service";
import { API } from "environments/environment";
import { ManageCustomerService } from "@app/admin/manage-customers/service/manage-customer.service";
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { NgbDateStruct, NgbDatepickerConfig } from "@ng-bootstrap/ng-bootstrap";
import $ from 'jquery'
import { ViewChild } from "@angular/core";
import { DatePipe } from "@angular/common";
declare var $: $
export interface EditcustomerFormFileds {
  id: string;
  full_name: string;
  email: string;
  phone_number: number | string;
  address: string;
  date_of_birth: string;
  zip_code: number | string;
  gender: string;
  country_id: number | string;
  state_id: number | string;
  city: string;
  // profile_image: string;
}
@Component({
  selector: 'app-customer-edit',
  templateUrl: './customer-edit.component.html',
  styleUrls: ['./customer-edit.component.scss']
})
export class CustomerEditComponent implements OnInit {
  dob: string;
  filename:any;
  today = new Date();
  futureDate: NgbDateStruct = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };
  @ViewChild('date_of_birth') d;
  customer_id: any;
  loading: boolean;
  customerModel: any;
  countryList: any;
  stateList: any;
  selectedFile: any;
  userdetail: any;
  profileImage: any;
  editCustomerForm: FormGroup;
  errorMsg = error_msg;
  initData: EditcustomerFormFileds = {
    id: "",
    full_name: "",
    email: "",
    phone_number: "",
    address: "",
    date_of_birth: "",
    zip_code: "",
    gender: "",
    country_id: "",
    state_id: "",
    city: "",
    // profile_image:""
  };
  constructor(
    private config: NgbDatepickerConfig,
    private titleService: Title,
    public fb: FormBuilder,
    public toasterService: ToasterService,
    public countryStateService: ApiCountryStateService,
    public router: Router,
    public activatedRoute: ActivatedRoute,
    public customerService: ManageCustomerService,
    public datepipe: DatePipe
  ) {
    const currentDate = new Date();
     config.minDate = { year: 1990, month: 12, day: 31 };
    config.maxDate = { year: currentDate.getFullYear(), month: currentDate.getMonth() + 1, day: currentDate.getDate() };
  }

  ngOnInit() {
    this.getcountry();
    this.createForm();
    this.titleService.setTitle('Edit Customer | Grooms Market');
    this.loading = true;
    this.activatedRoute.paramMap
      .switchMap((params: ParamMap) => {
        this.customer_id = params.get("id");
        this.customerService.customer_id = this.customer_id;
        return this.customerService.getCustomerDetail(
          API.CUSTOMER_ENDPOINTS.GET_CUSTOMER_DETAIL(this.customer_id)
        );
      })
      .subscribe({
        next: (result: any) => {
          this.customerModel = Object.assign({}, result.data);
          this.userdetail = this.customerModel.user_profile;
          if (this.userdetail.date_of_birth === null) {
          } else {
            var DDate = this.datepipe.transform(new Date(this.userdetail.date_of_birth), 'dd');
            var Month = this.datepipe.transform(new Date(this.userdetail.date_of_birth), 'MM');
            var Year = this.datepipe.transform(new Date(this.userdetail.date_of_birth), 'yyyy');
            this.userdetail.date_of_birth = { year: parseInt(Year), month: parseInt(Month), day: parseInt(DDate) };
          }
          this.profileImage = this.userdetail.profile_image;
          this.onChanegeCountry(this.userdetail.country_id);
          this.editCustomerForm.patchValue(this.userdetail);
          this.editCustomerForm.patchValue(this.customerModel);
          this.loading = false;
        },
        error: err => {
          this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
          this.loading = false;
        },
        complete: () => {
          this.loading = false;
        }
      });
  }

  getcountry() {
    return this.countryStateService.getCountries().subscribe(
      (result: any) => {
        if (result.success === true) {
          this.countryList = result.data;
          // console.log(this.countryList);
        } else {
          this.toasterService.Error();
        }
      });
  }

  onChanegeCountry(Country) {
    return this.countryStateService.getStates(Country).subscribe(
      (result: any) => {
        if (result.success === true) {
          this.stateList = result.data;
          // setTimeout(() => {
          //   $('select').selectpicker('refresh');
          // }, 150);

        } else {
          this.toasterService.Error();
        }
      });
  }
  onDateChange(dt: any) {
    //  console.log(dt);
     $('#doberror').hide();
    if (dt == null) {

    } else {
      this.dob = dt.year + '-' + dt.month + '-' + dt.day;
      // console.log(dt);
    }

  }
  // /**
  //  * Can be used to initiate the form with pre-defined value.
  //  * @param data The values that needs to be filled in the DriverForm
  //  */
  // initializeFormData(data?: EditcustomerFormFileds) {
  //   if (data) {
  //     for (const key in data) {
  //       if (data.hasOwnProperty(key)) {

  //           this.initData[key] = data[key];
  //         }
  //       }
  //     }
  //       const allControls = this.editCustomerForm.controls;
  //     for (const controlKey in allControls) {
  //       if (
  //         allControls.hasOwnProperty(controlKey) &&
  //         this.initData.hasOwnProperty(controlKey)
  //       ) {

  //         allControls[controlKey].setValue(this.initData[controlKey]);
  //       }
  //     }
  //     this.editCustomerForm.updateValueAndValidity();
  //   }

  createForm() {
    this.editCustomerForm = this.fb.group(
      {
        id: [
          this.initData.id,
        ],
        full_name: [
          this.initData.full_name,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20),
            Validators.pattern(/^[A-za-z\s]+$/)
          ])
        ],
        phone_number: [
          this.initData.phone_number,
          Validators.compose([
            Validators.required,
            Validators.pattern(/^[0-9]*$/),
            Validators.maxLength(10),
            Validators.minLength(6)
          ])
        ],

        email: [
          this.initData.email,
          Validators.compose([
            Validators.required,
            Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/),
            Validators.maxLength(100)
          ])
        ],
        address: [
          this.initData.address,
          Validators.compose([
            Validators.required,
            Validators.maxLength(50),
            Validators.pattern(/^[A-za-z\s]+$/)
          ])
        ],
        zip_code: [
          this.initData.zip_code,
          Validators.compose([
            Validators.required,
            Validators.pattern(/^[0-9]*$/),
            Validators.maxLength(10),
            Validators.minLength(6)
          ])
        ],
        gender: [
          this.initData.gender,
          Validators.compose([
            Validators.required,

          ])
        ],
        city: [
          this.initData.city,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20),
            Validators.pattern(/^[A-za-z\s]+$/)
          ])
        ],
        date_of_birth: [
          this.initData.date_of_birth,

        ],
        // profile_image: [
        //   this.initData.profile_image,

        // ],
        country_id: [
          this.initData.country_id,
          Validators.required,
        ],
        state_id: [
          this.initData.state_id,
          Validators.required,
        ],
      },
    );
  }


  handleImage(event) {
    $('#imgerror').hide();
    this.selectedFile = event.target.files[0]
    this.filename = this.selectedFile.name;
    // console.log(this.selectedFile.name);
  }

  onEdit() {
    this.loading = true;
    //  console.log(this.editCustomerForm.value);
    if (this.selectedFile) {
      $('#imgerror').hide();
       $('#doberror').hide();
    if (this.editCustomerForm.value.date_of_birth) {
      if (this.editCustomerForm.valid) {
        const formVal = this.editCustomerForm.value;
        const formData = new FormData();
        for (const key in formVal) {
          if (formVal.hasOwnProperty(key)) {
            {
              if (key === "update_customer") {
                continue;
              }
              formData.append(key, formVal[key]);
            }
          }
        }
        formData.append('profile_image', this.selectedFile);
        //  formData["profile_image"] = this.initData.profile_image;
        formData.delete("date_of_birth");
        formData.append("date_of_birth", this.dob);
        console.log(this.dob);
        this.customerService.updateCustomer(formData, this.customer_id).subscribe({
          next: data => {
            this.loading = false;
            this.toasterService.Success(notification_msg.CUSTOMER_UPDATE_SUCCESS);
            this.router.navigate(["/admin/customers"]);
          },
          error: err => {
            if (err.error && err.error.error) {
              this.toasterService.Error(err.error.error[0].message);
            } else {
              this.toasterService.Error(
                notification_msg.SERVER_NOT_RESPONDING
              );
              //this.checkErrors(err);
            }
            this.loading = false;
          },
          complete: () => { }
        });
      }
     } else {
      this.loading = false;
      $('#doberror').show();
      $('html,body').animate({ scrollTop: 300 });
    }
    } else {
      this.loading = false;
      $('#imgerror').show();
      $('html,body').animate({ scrollTop: 100 });
    }
  }
  get id() {
    return this.editCustomerForm.get("id");
  }
  get full_name() {
    return this.editCustomerForm.get("full_name");
  }
  get email() {
    return this.editCustomerForm.get("email");
  }
  get phone_number() {
    return this.editCustomerForm.get("phone_number");
  }
  get address() {
    return this.editCustomerForm.get("address");
  }
  get zip_code() {
    return this.editCustomerForm.get("zip_code");
  }
  // get date_of_birth() {
  //   return this.editCustomerForm.get("date_of_birth");
  // }
  get gender() {
    return this.editCustomerForm.get("gender");
  }
  get city() {
    return this.editCustomerForm.get("city");
  }
  get country_id() {
    return this.editCustomerForm.get("country_id");
  }
  get state_id() {
    return this.editCustomerForm.get("state_id");
  }
}
