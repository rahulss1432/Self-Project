import { Injectable } from "@angular/core";
import { ApiHandler } from "@app/shared/services/api-handler.service";
import { ServiceBase } from "@app/shared/baseClass/services-base.class";
import { API } from "environments/environment";

@Injectable()
export class ManageCustomerService extends ServiceBase {
  customer_id: any;
  constructor(apiHandler: ApiHandler) {
    super(apiHandler);
  }

  getCustomerDetail(url) {
    return this.apiHandler.apiGet(url);
  }

  updateCustomer(formData, id) {
    console.log(formData);
    const url = API.CUSTOMER_ENDPOINTS.UPDATE_CUSTOMER(id);
    return this.apiHandler.apiPost(url, formData, {
      contentType: {
        isFormDataContent: true
      }
    });
  }

 
}
