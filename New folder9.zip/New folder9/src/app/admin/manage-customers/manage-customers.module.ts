import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {RouterModule } from "@angular/router";
import { ManageCustomersRoutingModule } from "./manage-customers-routing.module";
import { SharedModule } from "@app/shared/module/shared.module";
import { ManageCustomersComponent } from './manage-customers.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { ManageCustomerService } from "@app/admin/manage-customers/service/manage-customer.service";
import { CustomerDetailComponent } from './customer-detail/customer-detail.component';
import { CustomerEditComponent } from './customer-edit/customer-edit.component';
import { InfiniteScrollModule } from "ngx-infinite-scroll";
import { NgSelectModule } from '@ng-select/ng-select';
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    NgbModule,
    RouterModule,
    InfiniteScrollModule,
    ReactiveFormsModule,
    ManageCustomersRoutingModule,
    NgSelectModule
  ],
  declarations: [
    ManageCustomersComponent,
   CustomerListComponent,
   CustomerDetailComponent,
   CustomerEditComponent
   ],
    providers: [ManageCustomerService]

})
export class ManageCustomersModule { }