import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-notifications',
  templateUrl: './manage-notifications.component.html',
  styleUrls: ['./manage-notifications.component.scss']
})
export class ManageNotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
