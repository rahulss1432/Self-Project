import { Injectable } from "@angular/core";
import { ApiHandler } from "@app/shared/services/api-handler.service";
import { ServiceBase } from "@app/shared/baseClass/services-base.class";
import { API } from "environments/environment";

@Injectable()
export class ManageCmsService extends ServiceBase {
  customer_id: any;
  constructor(apiHandler: ApiHandler) {
    super(apiHandler);
  }

  updateCms(formData, id) {
    console.log(formData);
    const url = API.CMS_ENDPOINTS.UPDATE_CMS(id);
    return this.apiHandler.apiPost(url, formData);
  }

  getCmsDetail(url) {
    return this.apiHandler.apiGet(url);
  }

  


}
