import { ManageCmsModule } from './manage-cms.module';

describe('ManageFabricModule', () => {
  let manageCmsModule: ManageCmsModule;

  beforeEach(() => {
    manageCmsModule = new ManageCmsModule();
  });

  it('should create an instance', () => {
    expect(manageCmsModule).toBeTruthy();
  });
});
