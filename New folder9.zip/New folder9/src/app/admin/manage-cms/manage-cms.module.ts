import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from "@app/shared/module/shared.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ManageCmsRoutingModule } from '@app/admin/manage-cms/manage-cms-routing.module';
import { ManageCmsComponent } from '@app/admin/manage-cms/manage-cms.component';
import { CmsListComponent } from './cms-list/cms-list.component';
import { CmsEditComponent } from './cms-edit/cms-edit.component';
import { ManageCmsService } from '@app/admin/manage-cms/service/manage-cms.service';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { EditorModule } from '@tinymce/tinymce-angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    EditorModule,
    InfiniteScrollModule,
    ManageCmsRoutingModule
  ],
  declarations: [ManageCmsComponent, CmsListComponent, CmsEditComponent],
  providers: [ManageCmsService]
})
export class ManageCmsModule { }
