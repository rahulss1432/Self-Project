import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-cms',
  templateUrl: './manage-cms.component.html',
  styleUrls: ['./manage-cms.component.scss']
})
export class ManageCmsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
