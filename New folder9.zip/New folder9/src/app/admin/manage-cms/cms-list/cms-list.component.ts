import { Component, OnInit } from '@angular/core';
import { ManageListBase } from '@app/shared/baseClass/list-base.class';
import { ToasterService } from '@app/shared/services/toaster.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { API } from 'environments/environment';
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { ManageCmsService } from '@app/admin/manage-cms/service/manage-cms.service';

export interface cmsFormFileds {
  name: string;
}

@Component({
  selector: 'app-cms-list',
  templateUrl: './cms-list.component.html',
  styleUrls: ['./cms-list.component.scss']
})
export class CmsListComponent extends ManageListBase implements OnInit {

  initData: cmsFormFileds = {
    name: "",
  };

  queryObj: {};
  cmsFilterForm: FormGroup;
  
  errorMsg = error_msg;
  isSubmitted = false;
  conditionDetail: any;


  constructor(private titleService: Title,
    public toasterService: ToasterService,
    private cmsService: ManageCmsService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    private router: Router) {
      super(API.CMS_ENDPOINTS.GET_CMS_LIST, cmsService, toasterService);
     }

     ngOnInit() {
      this.titleService.setTitle('Manage CMS | Grooms Market');
      super.ngOnInit();
      this.hydrationUrl = API.CMS_ENDPOINTS.GET_CMS_LIST;
    }

    onScroll() {
      if (!this.loading && this.dataList.length < this.totalQueryableData) {
        this.getList(this.page + 1, this.queryObj);
      }
    }

}
