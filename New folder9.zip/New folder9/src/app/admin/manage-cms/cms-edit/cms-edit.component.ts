import { Component, OnInit } from '@angular/core';
import { ManageListBase } from '@app/shared/baseClass/list-base.class';
import { ToasterService } from '@app/shared/services/toaster.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { API } from 'environments/environment';
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { ManageCmsService } from '@app/admin/manage-cms/service/manage-cms.service';


export interface cmsFormFileds {
  title: string;
  meta_title: string;
  meta_description: string;
  description: string;
}

@Component({
  selector: 'app-cms-list',
  templateUrl: './cms-edit.component.html',
  styleUrls: ['./cms-edit.component.scss']
})
export class CmsEditComponent extends ManageListBase implements OnInit {

  initData: cmsFormFileds = {
    title: "",
    meta_title: "",
    meta_description: "",
    description: "",
  };


  editCmsForm: FormGroup;
  errorMsg = error_msg;
  isSubmitted = false;
  cms_id: string;

  cmsDetail: any;


  constructor(private titleService: Title,
    public toasterService: ToasterService,
    private cmsService: ManageCmsService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    public activatedRoute: ActivatedRoute,
    private router: Router) {
    super(API.CMS_ENDPOINTS.GET_CMS_LIST, cmsService, toasterService);
  }

  ngOnInit() {

    this.createForm();
    this.titleService.setTitle('Edit Cms | Grooms Market');
    this.loading = true;
    this.activatedRoute.paramMap
      .switchMap((params: ParamMap) => {
        this.cms_id = params.get("id");
        return this.cmsService.getCmsDetail(
          API.CMS_ENDPOINTS.GET_CMS_DETAIL(this.cms_id)
        );
      })
      .subscribe({
        next: (result: any) => {
          this.cmsDetail = Object.assign({}, result.data);
          this.editCmsForm.patchValue(this.cmsDetail);

          this.loading = false;
        },
        error: err => {
          this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
          this.loading = false;
        },
        complete: () => {
          this.loading = false;
        }
      });
  }

  createForm() {
    this.editCmsForm = this.fb.group(
      {
        title: [
          this.initData.title,
          Validators.compose([
            Validators.required,
            Validators.maxLength(50),
          ])
        ],
        meta_title: [
          this.initData.meta_title,
          Validators.compose([
            Validators.required,
            Validators.maxLength(50),
          ])
        ],

        meta_description: [
          this.initData.meta_description,
          Validators.compose([
            Validators.required,


          ])
        ],
        description: [
          this.initData.description,
          Validators.compose([
            Validators.required,

          ])
        ],

      },
    );
  }

  onEdit() {
    this.isSubmitted = true;
    if (this.editCmsForm.valid) {
      this.loading = true;
      const formVal = this.editCmsForm.value;
      const formData = {};
      formData["title"] = formVal.title;
      formData["meta_title"] = formVal.meta_title;
      formData["description"] = formVal.description;
      formData["meta_description"] = formVal.meta_description;
      this.cmsService.updateCms(formData, this.cms_id).subscribe({
        next: data => {
          this.loading = false;
          this.toasterService.Success(notification_msg.CMS_UPDATE_SUCCESS);
          this.router.navigate(["/admin/cms"]);
        },
        error: err => {
          if (err.error && err.error.error) {
            this.toasterService.Error((err.error.error[0].message));
          }  else {
            this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
            //this.checkErrors(err);
          }
          this.loading = false;
        },
        complete: () => { }
      });
    }
  }

  
  get title() {
    return this.editCmsForm.get("title");
  }
  get meta_title() {
    return this.editCmsForm.get("meta_title");
  }
  get meta_description() {
    return this.editCmsForm.get("meta_description");
  }
  get description() {
    return this.editCmsForm.get("description");
  }


}
