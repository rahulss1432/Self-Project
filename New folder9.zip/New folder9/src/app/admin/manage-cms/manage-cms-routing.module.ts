import { Routes, RouterModule } from '@angular/router';
import { ManageCmsComponent } from '@app/admin/manage-cms/manage-cms.component';
import { CmsListComponent } from '@app/admin/manage-cms/cms-list/cms-list.component';
import { CmsEditComponent } from '@app/admin/manage-cms/cms-edit/cms-edit.component';

const routes: Routes = [
  { 
    
        path: '', component: ManageCmsComponent, children: [
          { path: '', component: CmsListComponent },
          { path: 'edit/:id', component: CmsEditComponent },
        ]
  }
];

export const ManageCmsRoutingModule = RouterModule.forChild(routes);


