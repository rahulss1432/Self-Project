import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-testimonials',
  templateUrl: './manage-testimonials.component.html',
  styleUrls: ['./manage-testimonials.component.scss']
})
export class ManageTestimonialsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
