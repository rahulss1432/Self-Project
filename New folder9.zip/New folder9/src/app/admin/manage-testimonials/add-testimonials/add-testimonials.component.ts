import { Component, OnInit } from '@angular/core';
import { NgbRatingConfig } from '@ng-bootstrap/ng-bootstrap';
import { Title } from '@angular/platform-browser';
import { ManageTestimonialService } from "@app/admin/manage-testimonials/service/manage-testimonial.service";
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from "@app/shared/services/toaster.service";
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';/* confirm box service */
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { API } from "environments/environment";
declare var $: any;
export interface TestimonialFormFileds {
  name: string;
  email: string;
  description: string;
}
@Component({
  selector: 'app-add-testimonials',
  templateUrl: './add-testimonials.component.html',
  styleUrls: ['./add-testimonials.component.scss']
})
export class AddTestimonialsComponent implements OnInit {
  initData: TestimonialFormFileds = {
    name: "",
    email: "",
    description: "",

  }
  errorMsg = error_msg;
  title = 'Add Testimonial';
  btnName = 'Add';
  addTestimonialForm: FormGroup;
  selectedFile: any;
  selected: any;
  id: any;
  loading: boolean;
  constructor(
    private titleService: Title,
    private testimonialService: ManageTestimonialService,
    public fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public toasterService: ToasterService,
    private confirmService: ConfirmService,
    config: NgbRatingConfig
  ) {
    config.max = 5;
  }

  ngOnInit() {
    this.createForm();
    this.titleService.setTitle('Add Testimonials | Grooms Market');
  }
  createForm() {
    this.addTestimonialForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20),
            Validators.pattern(/^[A-za-z\s]+$/)
          ])
        ],
        email: [
          this.initData.email,
          Validators.compose([
            Validators.required,
            Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/),
            Validators.maxLength(100)
          ])
        ],

        description: [
          this.initData.description,
          Validators.compose([
            Validators.required,


          ])
        ],
      },
    );
  }
  handleImage(event) {
    $('#imgerror').hide();
    this.selectedFile = event.target.files[0]
  }
  onsubmit() {
    this.loading = true;
    // console.log(this.addTestimonialForm.value);
    if (this.selectedFile) {
      $('#imgerror').hide();
      $('#ratingerror').hide();
      if (this.selected) {
        if (this.addTestimonialForm.valid) {
          const formVal = this.addTestimonialForm.value;
          const formData = new FormData();
          for (const key in formVal) {
            if (formVal.hasOwnProperty(key)) {
              {
                if (key === "add_testinomials") {
                  continue;
                }
                formData.append(key, formVal[key]);
              }
            }
          }
          formData.append('rating', this.selected);
          formData.append('testimonial_image', this.selectedFile);
          this.testimonialService.addupdateTestimonialCustomer(formData, this.id).subscribe({
            next: data => {
              this.toasterService.Success(notification_msg.TESTINOMIAL_ADD_SUCCESS);
              this.router.navigate(["/admin/testimonials"]);
            },
            error: err => {
              if (err.error && err.error.error) {
                this.toasterService.Error(err.error.error[0].message);
              } else {
                this.toasterService.Error(
                  notification_msg.SERVER_NOT_RESPONDING
                );
              }
            },
            complete: () => { }
          });
        }

      } else {
        this.loading = false;
        $('#ratingerror').show();
        $('html,body').animate({ scrollTop: 300 });
      }
    } else {
      $('#imgerror').show();
    }
  }
  get name() {
    return this.addTestimonialForm.get("name");
  }
  get email() {
    return this.addTestimonialForm.get("email");
  }
  get description() {
    return this.addTestimonialForm.get("description");
  }

}
