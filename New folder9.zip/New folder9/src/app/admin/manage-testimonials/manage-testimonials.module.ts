import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RouterModule } from "@angular/router";
import { SharedModule } from "@app/shared/module/shared.module";
import { ManageTestimonialsRoutingModule } from "@app/admin/manage-testimonials/manage-testimonials-routing.module";
import { ManageTestimonialsComponent } from "@app/admin/manage-testimonials/manage-testimonials.component";
import { ListTestimonialsComponent } from "@app/admin/manage-testimonials/list-testimonials/list-testimonials.component";
import { EditTestimonialsComponent } from './edit-testimonials/edit-testimonials.component';
import { DetailTestimonialsComponent } from './detail-testimonials/detail-testimonials.component';
import { AddTestimonialsComponent } from './add-testimonials/add-testimonials.component';
import {NgbRatingConfig} from '@ng-bootstrap/ng-bootstrap';
import { ManageTestimonialService } from "@app/admin/manage-testimonials/service/manage-testimonial.service";
import { InfiniteScrollModule } from "ngx-infinite-scroll";

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    NgbModule,
    InfiniteScrollModule,
    RouterModule,
    ReactiveFormsModule,
    ManageTestimonialsRoutingModule
  ],
  declarations: [ManageTestimonialsComponent, ListTestimonialsComponent, EditTestimonialsComponent, DetailTestimonialsComponent, AddTestimonialsComponent],
  providers: [NgbRatingConfig,ManageTestimonialService]
})
export class ManageTestimonialModule { }
