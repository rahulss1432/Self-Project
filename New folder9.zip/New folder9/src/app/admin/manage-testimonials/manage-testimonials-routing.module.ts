
import { Routes, RouterModule } from '@angular/router';
import { ListTestimonialsComponent } from "@app/admin/manage-testimonials/list-testimonials/list-testimonials.component";
import { AddTestimonialsComponent } from './add-testimonials/add-testimonials.component';
import { EditTestimonialsComponent } from '@app/admin/manage-testimonials/edit-testimonials/edit-testimonials.component';
import { DetailTestimonialsComponent } from '@app/admin/manage-testimonials/detail-testimonials/detail-testimonials.component';
import { ManageTestimonialsComponent } from "@app/admin/manage-testimonials/manage-testimonials.component";
const route: Routes = [
  {
    path: "", component: ManageTestimonialsComponent,children: [
       { path: "", component: ListTestimonialsComponent },
       { path: "add", component: AddTestimonialsComponent },
       { path: "edit/:id", component: EditTestimonialsComponent },
       { path: "detail/:id", component: DetailTestimonialsComponent },
      ]
  }
];
export const ManageTestimonialsRoutingModule = RouterModule.forChild(route); 