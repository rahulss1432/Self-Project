import { Injectable } from "@angular/core";
import { ApiHandler } from "@app/shared/services/api-handler.service";
import { ServiceBase } from "@app/shared/baseClass/services-base.class";
import { API } from "environments/environment";

@Injectable()
export class ManageTestimonialService extends ServiceBase {
  customer_id: any;
  constructor(apiHandler: ApiHandler) {
    super(apiHandler);
  }

  getTestimonialCustomerDetail(url) {
    return this.apiHandler.apiGet(url);
  }
 
  addupdateTestimonialCustomer(formData, id) {
      if(id>0)
    {
      const url = API.TESTIMONIAL_ENDPOINTS.UPDATE_TESTIMONIAL(id);
    return this.apiHandler.apiPost(url, formData, {
      contentType: {
        isFormDataContent: true
      }
    });
    }
    const url = API.TESTIMONIAL_BASE;
    return this.apiHandler.apiPost(url, formData, {
      contentType: {
        isFormDataContent: true
      }
    });
  }
}
