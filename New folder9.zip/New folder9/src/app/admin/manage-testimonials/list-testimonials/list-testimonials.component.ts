import { Component, OnInit } from '@angular/core';
import {NgbRatingConfig} from '@ng-bootstrap/ng-bootstrap';
import { Title } from '@angular/platform-browser';
import { ManageTestimonialService } from "@app/admin/manage-testimonials/service/manage-testimonial.service";
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from "@app/shared/services/toaster.service";
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';/* confirm box service */
import { ManageListBase } from "@app/shared/baseClass/list-base.class";
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { API } from "environments/environment";
declare var $: any;
@Component({
  selector: 'app-list-testimonials',
  templateUrl: './list-testimonials.component.html',
  styleUrls: ['./list-testimonials.component.scss']
})
export class ListTestimonialsComponent extends ManageListBase implements OnInit {
 errorMsg = error_msg;
  constructor(
    private titleService: Title,
    private testimonialService: ManageTestimonialService,
    public fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public toasterService: ToasterService,
    private confirmService: ConfirmService,
    config: NgbRatingConfig
    ) {
       super(API.TESTIMONIAL_ENDPOINTS.GET_TESTIMONIAL_LIST, testimonialService, toasterService);
    config.max = 5; 
    config.readonly = true;
   }

  ngOnInit() {
     this.titleService.setTitle('Manage Testimonials | Grooms Market');
      super.ngOnInit();
    this.hydrationUrl = API.TESTIMONIAL_ENDPOINTS.GET_TESTIMONIAL_LIST;
  }
deleteTestinomial(id) {

    this.confirmService.confirmThis('Are you sure.! do you want to delete this Testimonial', () => {
      // ACTION: Do this If user says YES
      super.deleteEntity(API.TESTIMONIAL_ENDPOINTS.DELETE_TESTIMONIAL(id), id);

    }, function () {
      // ACTION: Do this If user says NO
    });
  }
}
