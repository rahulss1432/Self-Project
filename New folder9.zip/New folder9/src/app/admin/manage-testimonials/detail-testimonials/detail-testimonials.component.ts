import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ToasterService } from "@app/shared/services/toaster.service";
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { API } from "environments/environment";
import { notification_msg } from "@app/shared/constants/consts";
import { ManageTestimonialService } from "@app/admin/manage-testimonials/service/manage-testimonial.service";
import { UtilityFunctionService } from "@app/shared/services/utility-function.service";
import {NgbRatingConfig} from '@ng-bootstrap/ng-bootstrap';
import $ from 'jquery'
declare var $: $
@Component({
  selector: 'app-detail-testimonials',
  templateUrl: './detail-testimonials.component.html',
  styleUrls: ['./detail-testimonials.component.scss']
})
export class DetailTestimonialsComponent implements OnInit {
  loading: boolean;
  testimonialModel: any;
  testimonial_id: any; 
  testimonialdetail: any;
  constructor(
    private titleService: Title, 
    public util: UtilityFunctionService,
    private testimonialService: ManageTestimonialService,
    public toasterService: ToasterService,
    public router: Router,
    public activatedRoute: ActivatedRoute,
    config: NgbRatingConfig

  ) { 
    config.max = 5; 
    config.readonly = true;
  }

  ngOnInit() {
    this.titleService.setTitle('Testimonial Detail | Grooms Market');
    this.loading = true;
    this.activatedRoute.paramMap
      .switchMap((params: ParamMap) => {
        this.testimonial_id = params.get("id");
        this.testimonialService.customer_id = this.testimonial_id;
        return this.testimonialService.getTestimonialCustomerDetail(
          API.TESTIMONIAL_ENDPOINTS.GET_TESTIMONIAL_DETAIL(this.testimonial_id)
        );
      })
      .subscribe({
        next: (result: any) => {
          this.testimonialModel = Object.assign({}, result.data);
          this.testimonialdetail = this.testimonialModel
          this.loading = false;
        }, 
        error: err => { 
          this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
          this.loading = false;
        },
        complete: () => {
          this.loading = false;
        }
      });
  }

}
