import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ManageTestimonialService } from "@app/admin/manage-testimonials/service/manage-testimonial.service";
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { ToasterService } from "@app/shared/services/toaster.service";
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';/* confirm box service */
import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { NgbRatingConfig } from '@ng-bootstrap/ng-bootstrap';
import { API } from "environments/environment";
declare var $: any;
export interface TestimonialFormFileds {
  name: string;
  email: string;
  description: string;
}
@Component({
  selector: 'app-edit-testimonials',
  templateUrl: './edit-testimonials.component.html',
  styleUrls: ['./edit-testimonials.component.scss']
})
export class EditTestimonialsComponent implements OnInit {
  initData: TestimonialFormFileds = {
    name: "",
    email: "",
    description: "",

  }
  title = 'Edit Testimonial';
  btnName = 'Update';
  testimonialId: any;
  testimonialModel: any;
  loading: boolean;
  editTestimonialForm: FormGroup;
  selectedFile: any;
  selected: any;
  currentRate:any;
  testimonialImage:any;
  errorMsg = error_msg;
  constructor(
    private titleService: Title,
    private testimonialService: ManageTestimonialService,
    public fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public toasterService: ToasterService,
    private confirmService: ConfirmService,
    config: NgbRatingConfig
  ) {  config.max = 5;config.readonly = false;}

  ngOnInit() {
    this.createForm();
    this.titleService.setTitle('Edit Testimonials | Grooms Market');
      this.route.paramMap
      .switchMap((params: ParamMap) => {
        this.testimonialId = params.get("id");
        this.loading = true;
        return this.testimonialService.getTestimonialCustomerDetail(
          API.TESTIMONIAL_ENDPOINTS.GET_TESTIMONIAL_DETAIL(this.testimonialId)
        );
      })
      .subscribe({
        next: (result: any) => {
          this.testimonialModel = Object.assign({}, result.data);
          this.editTestimonialForm.patchValue(this.testimonialModel);
          this.currentRate = this.testimonialModel.rating;
          this.testimonialImage = this.testimonialModel.testimonial_image;
          this.loading = false;
        },

        error: err => {
          this.toasterService.Error("while fetching data", "Error");
          this.loading = false;
        }
      });
  }
  createForm() {
    this.editTestimonialForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20),
            Validators.pattern(/^[A-za-z\s]+$/)
          ])
        ],
        email: [
          this.initData.email,
          Validators.compose([
            Validators.required,
            Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/),
            Validators.maxLength(100)
          ])
        ],

        description: [
          this.initData.description,
          Validators.compose([
            Validators.required,
          ])
        ],
      },
    );
  }
  handleImage(event) {
    $('#imgerror').hide();
    this.selectedFile = event.target.files[0]
  }
  onsubmit() {
    this.loading = true;
    // console.log(this.addTestimonialForm.value);
    if (this.selectedFile) {
      $('#imgerror').hide();
          if (this.editTestimonialForm.valid) {
          const formVal = this.editTestimonialForm.value;
          const formData = new FormData();
          for (const key in formVal) {
            if (formVal.hasOwnProperty(key)) {
              {
                if (key === "update_testinomials") {
                  continue;
                }
                formData.append(key, formVal[key]);
              }
            }
          }
          formData.append('rating', this.currentRate);
          formData.append('testimonial_image', this.selectedFile);
          this.testimonialService.addupdateTestimonialCustomer(formData, this.testimonialId).subscribe({
            next: data => {
              this.toasterService.Success(notification_msg.TESTINOMIAL_UPDATE_SUCCESS);
              this.router.navigate(["/admin/testimonials"]);
            },
            error: err => {
              if (err.error && err.error.error) {
                this.toasterService.Error(err.error.error[0].message);
              } else {
                this.toasterService.Error(
                  notification_msg.SERVER_NOT_RESPONDING
                );
              }
            },
            complete: () => { }
          });
        }

      } else {
      $('#imgerror').show();
    }
  }
  get name() {
    return this.editTestimonialForm.get("name");
  }
  get email() {
    return this.editTestimonialForm.get("email");
  }
  get description() {
    return this.editTestimonialForm.get("description");
  }


}
