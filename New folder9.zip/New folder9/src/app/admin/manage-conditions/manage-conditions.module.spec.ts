import { ManageConditionsModule } from './manage-conditions.module';

describe('ManageConditionsModule', () => {
  let manageConditionsModule: ManageConditionsModule;

  beforeEach(() => {
    manageConditionsModule = new ManageConditionsModule();
  });

  it('should create an instance', () => {
    expect(manageConditionsModule).toBeTruthy();
  });
});
