import { Injectable } from "@angular/core";
import { ApiHandler } from "@app/shared/services/api-handler.service";
import { ServiceBase } from "@app/shared/baseClass/services-base.class";
import { API } from "environments/environment";

@Injectable()
export class ManageConditionService extends ServiceBase {
  customer_id: any;
  constructor(apiHandler: ApiHandler) {
    super(apiHandler);
  }

  addUpdateCondition(formData,id:number) {
    if(id>0)
    {
      const url = API.CONDITION_ENDPOINTS.UPDATE_CONDITION(id);
      return this.apiHandler.apiPost(url, formData);
    }
    const url = API.CONDITION_BASE;
    return this.apiHandler.apiPost(url, formData);
  }

  getConditionDetail(url){
    return this.apiHandler.apiGet(url);
  }

 

  


}
