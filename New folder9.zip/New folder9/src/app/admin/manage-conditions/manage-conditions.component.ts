import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-conditions',
  templateUrl: './manage-conditions.component.html',
  styleUrls: ['./manage-conditions.component.scss']
})
export class ManageConditionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
