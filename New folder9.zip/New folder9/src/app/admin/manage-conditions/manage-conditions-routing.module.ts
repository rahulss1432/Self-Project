import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListConditionsComponent } from '@app/admin/manage-conditions/list-conditions/list-conditions.component';

const route: Routes = [
  {
    path: "", component: ListConditionsComponent,
     children: [
       { path: "", component: ListConditionsComponent }
      ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(route)],
  exports: [RouterModule]
})
export class ManageConditionsRoutingModule { }
