import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from "@app/shared/module/shared.module";
import { ManageConditionsRoutingModule } from './manage-conditions-routing.module';
import { ManageConditionsComponent } from './manage-conditions.component';
import { ListConditionsComponent } from './list-conditions/list-conditions.component';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {Routes, RouterModule } from "@angular/router";
import { InfiniteScrollModule } from "ngx-infinite-scroll";
import { ManageConditionService } from '@app/admin/manage-conditions/service/manage-condition.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    SharedModule,
    InfiniteScrollModule,
    ManageConditionsRoutingModule
  ],
  declarations: [ManageConditionsComponent, ListConditionsComponent],
  providers: [ManageConditionService]
})
export class ManageConditionsModule { }
