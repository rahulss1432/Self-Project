import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { API } from "environments/environment";
import { ManageListBase } from "@app/shared/baseClass/list-base.class";
import { ManageConditionService } from '@app/admin/manage-conditions/service/manage-condition.service';
import { ToasterService } from '@app/shared/services/toaster.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { error_msg, notification_msg } from "@app/shared/constants/consts";
import { ConfirmService } from '@app/shared/component/admin/confirm-box/confirm.service';
import { AlertService } from "@app/shared/component/admin/alert-box/alert.service";
export interface ConditionFormFileds {
  name: string;
}
@Component({
  selector: 'app-list-conditions',
  templateUrl: './list-conditions.component.html',
  styleUrls: ['./list-conditions.component.scss']
})
export class ListConditionsComponent extends ManageListBase implements OnInit {

  errorMsg = error_msg;
  queryObj: {};
  condition_id: number;
  title = 'Add Condition';
  btnName = 'Add'
  isSubmitted = false;
  conditionDetail: any;
  conditionFilterForm: FormGroup;
  addUpdateConditionForm: FormGroup;

  initData: ConditionFormFileds = {
    name: "",
  };

  constructor(
    private titleService: Title,
    private conditionService: ManageConditionService,
    public toasterService: ToasterService,
    private fb: FormBuilder,
    private confirmService: ConfirmService,
    private alertService: AlertService,
    private router: Router) {
    super(API.CONDITION_ENDPOINTS.GET_CONDITION_LIST, conditionService, toasterService);
  }

  ngOnInit() {
    this.createForm();
    this.createConditionForm();
    this.titleService.setTitle('Manage Conditions | Grooms Market');
    super.ngOnInit();
    this.condition_id = 0;
  }

  AddConditionModal() {
    this.title = 'Add Condition';
    this.btnName = 'Add';
    this.addUpdateConditionForm.reset();
  }

  onScroll() {
    if (!this.loading && this.dataList.length < this.totalQueryableData) {
      this.getList(this.page + 1, this.queryObj);
    }
  }

  createForm() {
    this.conditionFilterForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.maxLength(50)
          ])
        ],
      },
    );
  }


  createConditionForm() {
    this.addUpdateConditionForm = this.fb.group(
      {
        name: [
          this.initData.name,
          Validators.compose([
            Validators.required,
            Validators.maxLength(20)
          ])
        ],
      },
    );
  }

  getConditionList() {
    if (this.conditionFilterForm.valid) {
      this.queryObj = this.getFormData();
      this.dataList = [];
      this.getList(1, this.queryObj);
    } else {
      this.toasterService.Error(notification_msg.FILL_ALL_DETAILS);
    }
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.addUpdateConditionForm.valid) {
      this.loading = true;
      const formVal = this.addUpdateConditionForm.getRawValue();
      const formData = {};

      formData["name"] = formVal.name;
      this.conditionService.addUpdateCondition(formData, this.condition_id).subscribe({
        next: data => {
          this.loading = false;
          if (this.condition_id > 0) {
            this.toasterService.Success(notification_msg.CONDITION_UPDATE_SUCCESS);
          } else {
            this.toasterService.Success(notification_msg.CONDITION_ADD_SUCCESS);
          }
          window.location.reload();
        },
        error: err => {
          // alert(err.error[0].message);
          if (err.error && err.error.error) {
            this.toasterService.Error((err.error.error[0].message));
          } else {
            this.toasterService.Error(notification_msg.SERVER_NOT_RESPONDING);
            //this.checkErrors(err);
          }
          this.loading = false;
        },
        complete: () => { }
      });
    }
  }

  getFormData() {
    const formVal = this.conditionFilterForm.value;
    const queryObj = formVal;
    return queryObj;
  }

  get name() {
    return this.addUpdateConditionForm.get("name");
  }

  editConditionDetail(id) {
    this.conditionService.getConditionDetail(API.CONDITION_ENDPOINTS.GET_CONDITION_DETAIL(id)).subscribe({
      next: (result: any) => {
        this.conditionDetail = Object.assign({}, result.data);
        this.condition_id = this.conditionDetail.id;
        this.title = 'Edit Condition';
        this.btnName = 'Update';
        this.addUpdateConditionForm.patchValue(this.conditionDetail);
        this.loading = false;
      },

      error: err => {
        this.toasterService.Error("while fetching data", "Error");
        this.loading = false;
      }
    });


  }

 updateStatus(id, currentStatus) {
      this.alertService.alert('Are you sure.! do you want to change status', () => {
       // ACTION: Do this If user says YES
    let newStatus;
    if (currentStatus === "active") {
      newStatus = "inactive";
    } else {
      newStatus = "active";
    }
    super.updateStatus(
       API.CONDITION_ENDPOINTS.CONDITION_STATUS_UPDATE_URL(id),
      id,
      newStatus
    );

    }, function () {
      // ACTION: Do this If user says NO
    });
  }

  deleteColor(id) {

    this.confirmService.confirmThis('Are you sure.! do you want to delete this condition', () => {
      // ACTION: Do this If user says YES
      super.deleteEntity(API.CONDITION_ENDPOINTS.DELETE_CONDITION(id), id);

    }, function () {
      // ACTION: Do this If user says NO
    });
  }


}
