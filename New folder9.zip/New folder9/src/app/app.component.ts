import { Component, Output, EventEmitter } from "@angular/core";
import { NavigationEnd, NavigationStart, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  template: `<router-outlet></router-outlet>`
 
})
export class AppComponent {
  title = 'app';
  constructor(private router: Router ) {

       }
}
