<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatMessage extends Model
{
    
    protected $table = 'chat_messages';
    
    protected $fillable = [
        'chat_id', 'to_id', 'message', 'created_at'
    ];
    
    protected $hidden = [
        'updated_at'
    ];
    
    public function user(){
        return $this->belongsTo('App\User', 'to_id');
    }
    
}
