<?php

namespace App\Player\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Repositories\Player\MessageRepository;
use Auth;

class MessageController extends Controller
{
    /*
     * Class Construct.
     *
     * @param  array  $data
     * @return App\Player\Repositories\UserRepository;
     */
    public function __construct(MessageRepository $message) {
        $this->message = $message;
    }
    
    /*
     * Function for view messages.
     */
    public function index(){
        return view('player::player.messages');
    }
    
    /*
     * Function for get chat users.
     */
    public function getChatUsers(){
        try{
            $users = $this->message->getChatUsers();
            $html = View::make('player::ajax-content._get-chat-users', ['users' => $users])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    /*
     * Function for get chat users.
     */
    public function getUserMessages(Request $request){
        try{
            $userId = Auth::guard('player')->user()->id;
            $messages = $this->message->getUserMessages($request);
            $html = View::make('player::ajax-content._get-user-messages', ['messages' => $messages, 'from_id' => $userId, 'to_id' => $request->to_id, 'chat_id' => $request->chat_id])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
   
    /*
     * Function for send chat messages.
     */
    public function sendChatMessage(Request $request){
        try{
            $data = $this->message->sendChatMessage($request);
            return Response::json(['success' => true, 'data' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    /*
     * Function for check unread messages.
     */
    public function checkUnreadCount(){
       return $this->message->checkUnreadCount();
    }
    
    /*
     * Function for check unread messages.
     */
    public function updateReadCount(Request $request){
       return $this->message->updateReadCount($request);
    }
}
