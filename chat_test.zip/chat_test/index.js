var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.get('/', function (req, res) {
    res.sendfile('index.html');
});

var connectedUsers = {};
io.on('connection', function (socket) {
    socket.on('setUsername', function (userID) {
        //console.log('user connected.');
        var userJID = userID;
        socket.emit('userSet', {username: userID});
        connectedUsers[userJID] = socket;
    });
    socket.on('msg', function (data) {
        io.sockets.emit('newmsg', data);
    });
    socket.on('is typing', function (data) {
        io.sockets.emit('typing', data);
    });
    socket.on('stop_typing', function (data) {
        io.sockets.emit('hide_typing', data);
    });
    socket.on('leave-chat', function (data) {
        var userJID = data.userID;
        socket.disconnect();
        delete connectedUsers[userJID];
    });
    socket.on('disconnect', function () {
        //console.log('user disconnected.');
    });
});

http.listen(3000, function () {
    console.log('listening on localhost:3000');
});