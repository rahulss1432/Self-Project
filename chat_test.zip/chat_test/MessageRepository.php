<?php

namespace App\Repositories\Player;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Connection;
use App\Models\ChatMessage;
use Auth;

Class MessageRepository {

    /**
     * Class Construct.
     */
    public function __construct(Connection $connection, ChatMessage $chatMessage) {
        $this->connection = $connection;
        $this->chatMessage = $chatMessage;
    }
    
    /**
     * Function for list all users.
     */
    public function getChatUsers(){
        $userId = Auth::guard('player')->user()->id;
        return $this->connection->where(function($query) use($userId){
            $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
        })->where('type', 'accept')->orderBy('updated_at', 'DESC')->get();
    }
    
    /**
     * Function for list all users.
     */
    public function getUserMessages($request){
        $userId = Auth::guard('player')->user()->id;
        return $this->chatMessage->where('chat_id', $request->chat_id)->get();
    }
    
    /*
     * Function for send chat message.
     */
    public function sendChatMessage($request){
        $userId = Auth::guard('player')->user()->id;
        $current_time = \Carbon\Carbon::now()->toDateTimeString();
        $connection = $this->connection->where('id', $request->chat_id)->update(['updated_at' => $current_time]);
        $model = $this->chatMessage;
        $model->chat_id = $request->chat_id;
        $model->from_id = $userId;
        $model->to_id = $request->to_id;
        if ($request->hasFile('attachment')) {
            $attachment = $request->file('attachment');
            $name = uploadFile($attachment, 'player');
            $attachment = checkUserImage($name, 'player');
            $message = "<i class='fa fa-download fa-2x downloadAttachment' data-url='$attachment' data-name='$name'></i>";
            $model->message = $message;
        }else{
            $model->message = $request->message;
        }
        $model->save();
        $model->time = timeFormat($model->created_at);
        $model->userImg = checkUserImage(getUserById($userId, 'profile_image'), getUserById($userId, 'role'));
        $connection = $this->connection->find($model->chat_id);
        if( $connection->from_id == $userId ){
            $model->otherUser = $connection->to_id;
        }elseif( $connection->to_id == $userId ){
            $model->otherUser = $connection->from_id;
        }
        return $model;
    }
    
    /*
     * Function for check unread messages.
     */
    public function checkUnreadCount(){
       $userId = Auth::guard('player')->user()->id;
       return $this->chatMessage->where(['to_id' => $userId, 'is_read' => '0'])->count();
    }

    /*
     * Function for update read count.
     */
    public function updateReadCount($request){
        $this->chatMessage->where(['chat_id' => $request->chat_id, 'is_read' => '0'])->update(['is_read' => '1']);
    }

}

