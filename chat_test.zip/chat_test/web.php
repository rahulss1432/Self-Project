<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */
/* Route without middleware */
Route::group(['prefix' => 'player', 'middleware' => 'common'], function() {
    Route::get('player-profile/{slug?}', 'PlayerController@playerProfile');
    Route::get('player-timeline/{slug?}', 'PlayerController@playerTimeline');
    Route::get('get-timeline-post', 'PostController@getTimelinePost');
    Route::get('player-media/{slug?}', 'PlayerController@playerMedia');
    Route::get('get-select-media', 'PlayerController@getSelectMedia');

    Route::post('update-select-media', 'PlayerController@updateSelectedMedia');
    Route::get('get-my-media-view', 'PostController@getMyMediaView');

    Route::get('left-sidebar', 'PlayerController@leftSidebar');
    Route::get('right-sidebar', 'PlayerController@rightSidebar');
    Route::get('get-player-counts', 'PlayerController@getAllCount');

    Route::get('get-profile-media-list', 'PlayerController@getProfileMediaList');

    Route::post('get-recent-joined-members', 'PlayerController@getRecentJoinedMembers');
    Route::get('members-you-may-know/{slug?}', 'PlayerController@membersYouMayKnow');
    Route::post('get-member-list', 'PlayerController@getMemberList');

    /* My Connections Routes */
    Route::post('connect-dismiss-member', 'PlayerController@connectDismissMember');
    Route::get('user-connections-list', 'PlayerController@userConnectionsList');
    Route::get('connections/{slug?}', 'PlayerController@getConnections');
    Route::post('get-all-connections', 'PlayerController@getAllConnections');
    Route::post('get-all-friend-request', 'PlayerController@getAllFriendRequest');
    Route::post('accept-reject-connection', 'PlayerController@acceptRejectConnection');

    /* player procard and user profile routes */
    Route::get('get-player-procard', 'PlayerController@playerProCard');
    Route::get('get-accolades', 'PlayerController@getAccolades');
    Route::get('get-desired-benefites', 'PlayerController@getDesiredBenifites');
    Route::get('load-more-benefites', 'PlayerController@loadMoreBenefites');
    Route::get('get-coaching-experinces', 'PlayerController@getCoachingExperiences');
    Route::get('get-community-service-experince', 'PlayerController@getCommunityServiceExperience');

    /* route for slider page on home and timeline page */
    Route::post('get-matched-mutual-joined-members', 'PlayerController@getMatchedAndMutualJoinedMembers');
    Route::post('get-matched-mutual-joined-members-list', 'PlayerController@getMatchedMutualJoinedMembersList');


    Route::post('get-different-experience', 'PlayerController@getDifferentExperienceList');

    Route::get('get-social-page/{slug}/{type}', 'PlayerController@getSocialPage');

    Route::post('get-social-page', 'PlayerController@getSocialPage');

    Route::get('get-video-list', 'PlayerController@getMediaVideoList');
    Route::get('get-image-list', 'PlayerController@getMediaImageList');

    Route::get('get-post-view-modal', 'PostController@getPostViewModal');
    Route::get('media-comment-list', 'PostController@mediaCommentList');
    Route::post('save-media-comment', 'PostController@saveMediaComment');
    Route::get('save-media-like', 'PostController@saveMediaLike');
    Route::post('get-media-like-user', 'PostController@getMediaLikeUser');


    /* post routes */
    Route::post('add-post-comment', 'PostController@addPostComment');
    Route::post('get-post-comments', 'PostController@getPostComments');

    Route::get('get-post-like', 'PostController@getPostLike');
    Route::post('add-post-like', 'PostController@addPostLike');
    Route::post('check-post-like', 'PostController@checkPostLike');
    Route::post('get-like-user', 'PostController@getLikeUser');
    Route::post('logout', 'AuthController@logout');
});

/* Route with middleware */
Route::group(['prefix' => 'player', 'middleware' => 'player'], function() {
    Route::post('upload-multiple-file', 'PlayerController@uploadMultipleMedia'); 

    Route::get('new-job-list', 'PlayerController@newJobList');
    Route::get('applied-job-list', 'PlayerController@appliedJobList');
    Route::get('dashboard', 'PlayerController@index');
    Route::get('get-attribute-list', 'PlayerController@getValidateAttributeList');
    Route::get('other-player-attr-list', 'PlayerController@otherPlayerAttrList');
    Route::get('add-select-attribute', 'PlayerController@addSelectAttribute');

    Route::get('player-profile-form', 'PlayerController@playerProfileForm');
    Route::post('player-step-one', 'PlayerController@playerStepOne');
    Route::post('player-step-two', 'PlayerController@playerStepTwo');
    /* step 3 */
    Route::post('player-step-three-general', 'PlayerController@playerStepThreegeneral');
    Route::get('player-step-three', 'PlayerController@playerStepThree');
    Route::post('player-add-update-experience', 'PlayerController@playerAddUpdateExp');
    Route::get('player-edit-delete-experience', 'PlayerController@playerEditDeleteExp');
    /* End step 3 */
    /* step 4 */
    Route::post('save-season', 'PlayerController@saveSeason');
    Route::get('get-saved-past-season', 'PlayerController@getSavedPastSeason');
    Route::get('delete-season/{id}', 'PlayerController@deleteSeason');
    /* End step 4 */

    Route::post('player-step-five', 'PlayerController@playerStepFive');
    Route::post('player-step-six', 'PlayerController@playerStepSix');
    Route::post('player-step-seven', 'PlayerController@playerStepSeven');

    /* player events */
    Route::get('event/add', 'EventController@index');
    Route::post('save-event', 'EventController@saveEvent');
    Route::get('events', 'EventController@getEvent');
    Route::get('event/{id}', 'EventController@viewEvent');
    Route::get('event/edit/{id}', 'EventController@editEvent');
    Route::post('delete-event', 'EventController@deleteEvent');

    /* post routes */
    Route::get('get-post', 'PostController@index');

    Route::get('add-post-form', 'PostController@addPost');
    Route::get('edit-post', 'PostController@editPost');
    Route::post('save-post', 'PostController@savePost');
    Route::post('upload-post-media', 'PostController@uploadMultipleMediaPost');

    Route::post('delete-post', 'PostController@deletePost');

    Route::post('add-post-comment-reply', 'PostController@addPostCommentReply');
    Route::post('get-post-comments-reply', 'PostController@getPostCommentsReply');

    /* Messages routes */
    Route::get('messages', 'MessageController@index');
    Route::get('get-chat-users', 'MessageController@getChatUsers');
    Route::get('get-user-messages', 'MessageController@getUserMessages');
    Route::post('send-chat-message', 'MessageController@sendChatMessage');
    Route::get('check-unread-count', 'MessageController@checkUnreadCount');
    Route::get('update-read-count', 'MessageController@updateReadCount');

    /* Notifications Routes */
    Route::get('get-notification', 'PlayerController@getNotification');
    Route::get('notifications', 'PlayerController@getAllNotifications');
    Route::get('delete-all-notifications', 'PlayerController@deleteAllNotifications');
    Route::get('notification-paginate', 'PlayerController@notificationPaginate');
    
    /* friend requests */
    Route::get('my-friend-request', 'PlayerController@myFriendRequest');
    
    /* Compare player profiles */
    Route::get('compare', 'PlayerController@compare');
    Route::get('get-compare-users', 'PlayerController@getCompareUsers');
    Route::get('add-compare-user', 'PlayerController@addCompareUser');
    Route::get('get-compare-users-data', 'PlayerController@getCompareUsersData');

    /* Player experience routes */
    Route::post('get-experience-list', 'PlayerController@getExperienceList');

    /* friend requests Routes */
    Route::get('friend-request-unread-count', 'PlayerController@getRequestUnreadCount');
});
