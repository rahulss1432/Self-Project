@if( count($users) > 0 )
@foreach( $users as $user )
    @php
        $userId = \Auth::guard(getAuthGuard())->user()->id;
        if( $userId == $user->to_id ){
            $to_id = $user->from_id;
        }else{
            $to_id = $user->to_id;
        }
        $lstMsg=lastMessage($user->id);
    @endphp
<li id="user_{{ $user->id }}">
    <a href="javascript:void(0);" onclick="getUserMessages('{{ $user->id }}', '{{ $to_id }}')">
        <div class="user">
            <div class="user_img">
                @if( checkUnreadCount($user->id) > 0 )
                <span class="rounded-circle">{{ checkUnreadCount($user->id) }}</span>
                @endif
                <img class="rounded-circle" src="{{ checkUserImage(getUserById($to_id, 'profile_image'), getUserById($to_id, 'role')) }}" alt="user img">
            </div>	
            <div class="user_info">
                <h4>
                    <span class="title color-black chatUserName" data-user_id="{{ $user->id }}">{{ getUserById($to_id, 'first_name') }}</span>
                    <span class="date">{{ dateDayAgo($lstMsg->created_at) }}</span>
                </h4>
                <p class="sub_title mb-0" id="user-last-msg-{{ $to_id }}">{{ $lstMsg->message }}</p>
                <span id="typing-hint-{{ $user->id }}" style="display: none">Typing...</span>
            </div>
        </div>
    </a>
</li>
@endforeach
@else

<div class="alert alert-danger mt-5 ">No user found</div>

@endif
<div class="alert alert-danger mt-5" id="no_user" style="display: none;">No user found</div>

<script>
         $('#get-chat-users').mCustomScrollbar({
                    theme:"dark",
                     axis:"y"
                });
</script>
