<?php
//please enter the number which you want to check
$x=11;

echo "the number is:".$x."<br>";

if($x%2==0)
{
echo "number is even";
}
else
{
echo "number is odd";
}
?>