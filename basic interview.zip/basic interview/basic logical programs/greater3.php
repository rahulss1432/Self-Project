<?php
$x=34;
$y=33;
$z=32;

if($x>$y || $x>$z)
{
echo $x." is greater";
}
else if($y>$z)
{
echo $y." is greater";
}
else
{
echo $z." is greater";
}
?>