<?php
$string="1 2 3 4";

echo "String is:".$string."<br>";
echo "Reverse string is:".strrev($string);
?>