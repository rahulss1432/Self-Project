<?php
$x=17;

echo "your age is:",$x."<br><br>";
if($x>=18)
{
echo "You are eligible for vote";
}
else
{
echo "Sorry you are not eligible for vote..";
}
?>