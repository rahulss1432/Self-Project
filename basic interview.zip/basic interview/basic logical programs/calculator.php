<?php
$a=10;
$b=5;
echo "first no is:".$a."<br>";
echo "second no is:".$b."<br><br>";
$c=$a+$b;
$d=$a-$b;
$e=$a*$b;
$f=$a/$b;
$g=$a%$b;
echo "the sum of no is:".$c."<br>";
echo "the substraction of no is:".$d."<br>";
echo "the multiply of no is:".$e."<br>";
echo "the divide of no is:".$f."<br>";
echo "the modules of no is:".$g."<br>";
?>