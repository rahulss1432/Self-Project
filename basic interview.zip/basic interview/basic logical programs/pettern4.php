<?php
for($i=1;$i<=5;$i++)
{
for($j=5;$j>=$i;$j--)
{
echo "*";
}
echo "<br>";
}
for($i=1;$i<=5;$i++)
{
for($j=1;$j<=$i;$j++)
{
echo "*";
}
echo "<br>";
}
echo "<br>";
?>


<?php
for($i=1;$i<=5;$i++)
{
	for($k=1;$k<=$i;$k++)
	{
		echo "&nbsp;";
	}
for($j=5;$j>=$i;$j--)
{
echo "*";
}
echo "<br>";
}
for($i=2;$i<=5;$i++)
{
	for($k=5;$k>=$i;$k--)
	{
		echo "&nbsp;";
	}
for($j=1;$j<=$i;$j++)
{
echo "*";
}
echo "<br>";
}
?>