<?php
$x=33;
$y=34;

echo "Number before swapping is:".$x." and ".$y."<br>";
$z=$x;
$x=$y;
$y=$z;

echo "Number after swapping is :".$x." and ".$y."<br>";
?>