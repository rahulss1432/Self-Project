<?php
$var=5;
echo var_dump($var);
?>