<?php
$z="%";
echo "character is:".$z."<br>";

if($z=="a" || $z=="e" || $z=="i" || $z=="o" || $z=="u")
{
echo "character is vowel";
}
else
{
echo "character is consonant";
}
?>