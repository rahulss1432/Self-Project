<?php
$x=5;
echo "number which you want to find out factorial is:".$x."<br>";
$fact=1;

for($i=1;$i<=$x;$i++)
{
$fact=$i*$fact;
}
echo "factorial is:".$fact;
?>