<?php
$z="1996";
echo "you entered:".$z."<br>";

if($z%4==0)
{
echo "year is leap";
}
else
{
echo "year is not leap";
}
echo "<br></br>";
echo "divide is used to find quotient and module is used to find remainder suppose 15/3 answer is 5 and 15%3 answer is 0";
?>