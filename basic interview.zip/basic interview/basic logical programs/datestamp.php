<?php
date_default_timezone_set("Asia/Kolkata");
$date=date('y-m-d h:i:s');
$new_time=strtotime($date);
echo date('y-d-m h:i:s',$new_time);
echo "<br>";
?>
<?php
date_default_timezone_get("Asia/Kolkata");
echo date('y-d-m h:i:s');
?>
