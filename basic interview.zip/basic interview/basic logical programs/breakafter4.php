<?php
$var="100";
$j=0;

for($i=1;$i<=$var;$i++)
{
echo $i."-";
if($i%4==3)
{
echo "<br>";$j++;
}
}
echo "<br>";
echo "Numbers of lines is:".$j;
?>