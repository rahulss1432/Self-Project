<?php
mysql_connect("localhost","root","");
mysql_select_db("rahul_db");
if(isset($_POST["btnLogin"]))
{
 $nm=$_POST["txtNm"];
 $pass=$_POST["txtPass"];
 mysql_query("insert into rahul_tb(name,password)values('$nm','$pass')")or die (mysql_error());
}
?>
<html>
<head>
    <link rel="stylesheet" href="css/validationEngine.jquery.css" type="text/css">
	<link rel="stylesheet" href="css/template.css" type="text/css">
	<script src="js/jquery-1.8.2.min.js" type="text/javascript">
	</script>
	<script src="js/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8">
	</script>
	<script src="js/jquery.validationEngine.js" type="text/javascript" charset="utf-8">
	</script>
	<script>
        jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#form").validationEngine();
		});
	</script>
</head>
<body>
<form method="post" name="form" id="form">
<table border="1" align="center">
<tr>
<td>Name</td>
<td><input type="text" name="txtNm" class="validate[required] text-input"/></td>
</tr>
<tr>
<td>Password</td>
<td><input type="text" name="txtPass" class="validate[required,minSize[6]]"/></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="btnLogin" value="Login"/></td>
</tr>
</table>
</form>
</body>
</html>
<?php
 mysql_connect("localhost","root","");
 mysql_select_db("rahul_db");
if(isset($_GET["cid"]))
{
 $id=$_GET["cid"];
mysql_query("delete from rahul_tb where id='$id'");
}
$q=mysql_query("select * from rahul_tb");
?>
<?php 
if(isset($_POST["btnDel"]))
{
 $cid=$_POST["chk"];
 foreach($cid as $v)
 mysql_query("delete from rahul_tb where id='$v'");
}
$q=mysql_query("select * from rahul_tb");
?>
<form method="post">
<table border="1" align="center">
<tr>
<td>Link</td>
<td>Id</td>
<td>Name</td>
<td>Password</td>
<td>Check</td>
</tr>
<?php 
while($data=mysql_fetch_array($q))
{
?>
<tr>
<td><a href="login.php?cid=<?php echo $data["id"];?>">Delete</a></td>
<td><?php echo $data["id"];?></td>
<td><?php echo $data["name"];?></td>
<td><?php echo $data["password"];?></td>
<td><input type="checkbox" name="chk[]" value="<?php echo $data["id"];?>"/></td>
</tr>
<?php } ?>
<tr>
<td colspan="5" align="center"><input type="submit" name="btnDel" value="Delete"/></td>
</tr>
</table>
</form>
<?php
mysql_connect("localhost","root","");
mysql_select_db("rahul_db");
if(isset($_POST["btnUpdate"]))
{
 $cid=$_POST["chk"];
 foreach($cid as $v)
{
 $nm=$_POST["nm".$v];
 $pass=$_POST["pass".$v];
mysql_query("update rahul_tb set name='$nm',password='$pass' where id='$v'") or die (mysql_error());
}
}
$q=mysql_query("select * from rahul_tb");
?>
<form method="post">
<table border="1" align="center">
<tr>
<td>Link</td>
<td>Id</td>
<td>Name</td>
<td>Password</td>
<td>Check</td>
</tr>
<?php 
while($data=mysql_fetch_array($q))
{
?>
<tr>
<td><a href="edit.php?cid=<?php echo $data["id"];?>">Edit</a></td>
<td><?php echo $data["id"];?></td>
<td><input type="text" name="nm<?php echo $data["id"];?>" value="<?php echo $data["name"];?>"/></td>
<td><input type="text" name="pass<?php echo $data["id"];?>" value="<?php echo $data["password"];?>"/></td>
<td><input type="checkbox" name="chk[]" value="<?php echo $data["id"];?>"/></td>
</tr>
<?php } ?>
<tr>
<td colspan="5" align="center"><input type="submit" name="btnUpdate" value="Update"/></td>
</tr>
</table>
</form>