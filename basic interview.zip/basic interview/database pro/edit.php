<?php
mysql_connect("localhost","root","");
mysql_select_db("rahul_db");
$id=$_GET["cid"];
if(isset($_POST["btnEdit"]))
{
 $nm=$_POST["txtNm"];
 $pass=$_POST["txtPass"];
 mysql_query("update rahul_tb set name='$nm',password='$pass' where id='$id'");
 header("location:login.php");
}
$q=mysql_query("select * from rahul_tb where id='$id'");
$data=mysql_fetch_array($q);
?>
<form method="post">
<table border="1">
<tr> 
<td>Id</td>
<td><?php echo $data["id"];?></td>
</tr>
<tr>
<td>Name</td>
<td><input type="text" name="txtNm" value="<?php echo $data["name"];?>"/></td>
</tr>
<tr>
<td>Password</td>
<td><input type="text" name="txtPass" value="<?php echo $data["password"];?>"/></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="btnEdit" value="Edit"/></td>
</tr>
</table>
</form>