<?php
	$i=151;
	$c=$i;
	$a=0;
	while($i>=1)
	{
	  $b=$i%10;
	  $a=($a*10+$b);
	  $i=$i/10;
	}
	if($c==$a)
	{
	 echo("$c it's an polindrom no.");
	}
	else
	 {
	   echo("$c it's not an polindrom no.");
	 }
?>
<form method="post">
<input type="text" name="no"/>
<input type="submit" name="btnGo"/>
</form>
<?php
if(isset($_POST["btnGo"]))
{
	$no=$_POST["no"];
	$a=0;
	$c=$no;
	while($no>=1)
	{
		$b=$no%10;
		$a=($a*10+$b);
		$no=$no/10;
	}
	if($a==$c)
	{
		echo "no is polindrom";
	}
	else
	{
		echo "no is not polindrom";
	}
}
?>