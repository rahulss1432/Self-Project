<?php
     for($i=1; $i<=9; $i++)
     {
      echo  $c=$i*$i."</br>";
     }
     echo "<br>";
?>
<?php
for($i=1;$i<=8;$i++)
{
	$c=$i*$i;
}
echo $c;  
?>