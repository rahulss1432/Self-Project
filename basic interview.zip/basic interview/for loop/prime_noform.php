<form method="post">
	<input type="text" name="no"/>
	<input type="submit" name="sb" value="search"/>
</form>
<?php
if(isset($_POST["sb"]))
{
	$prime=$_POST["no"];
	$a=0;
	for($i=1;$i<$prime;$i++)
	{
		if($prime%$i==0)
		{
			$a=$a+$i;
		}
	}
	if($a==1)
	{
		echo "no is $i prime";
	}
	else
	{
		echo "no is not $i prime";
	}
}
?>