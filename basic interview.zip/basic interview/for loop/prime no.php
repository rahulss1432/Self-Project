<form method="post">
  <input type="text" name="no"/>
  <input type="submit" name="sb"/>
</form>
<?php
if(isset($_POST["sb"]))
{
  $a=$_POST["no"];
//$a=100;
   for($i=2; $i<=$a; $i++)
   {
    for($j=2; $j<=$i; $j++)
     {
      if($i%$j==0)
        {
         break;
        }
      }
       if($j==$i)
       echo("prime no $i</br>");
    }
  }
?>