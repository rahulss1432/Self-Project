<?php
   $i=1;
   $a=0;
     while($i<=10)
      {
       $a=$a+$i;
       $i++;
      }
       echo $a;
?>

<?php
$a=0;
for($i=0;$i<=10;$i++)
{
	$a=$a+$i;
}
echo $a;
?>

