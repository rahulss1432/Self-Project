<?php
$a=2;
for($i=0; $i<=10; $i++)
{
echo($i*$a);
echo("</br>");
}
?>