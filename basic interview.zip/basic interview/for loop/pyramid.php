<?php
    for($i=1; $i<=5; $i++)
     {
     for($k=5;$k>=$i;$k--)
     {
     	echo "&nbsp;";
     }
      for($j=1; $j<=$i; $j++)
       {
         echo "*";
        }
       echo"</br>";
     }
   for($i=1;$i<=5;$i++)
   {
   	for($k=1;$k<=$i;$k++)
   	{
   		echo "&nbsp;";
   	}
   	 for($j=5;$j>=$i;$j--)
   	 {
   	 	echo "*";
   	 }
   	 echo "<br>";
   }
?>
<?php
for($i=0;$i<=5;$i++)
{
	for($j=0;$j<=$i;$j++)
	{
		echo "*";
	}
	echo "<br>";
}
?>
<?php
for($i=0;$i<=5;$i++)
{
  for($k=4;$k>=$i;$k--)
  {
    echo "&nbsp;";
  }
  for($j=0;$j<=$i;$j++)
  {
    echo "*";
  }
  echo "<br>";
}
?>
<?php
for($i=0;$i<=10;$i++)
{
  for($k=10;$k>=$i;$k--)
  {
    echo  "&nbsp;";
  }
  for($j=0;$j<=$i;$j++)
  {
     if($i%2==0)
     {
      echo "*";
     }
  }
  echo "<br>";
}
?>
<?php
for($i=0;$i<=10;$i++)
{
  for($k=0;$k<=$i;$k++)
  {
    echo "&nbsp;";
  }
  for($j=10;$j>=$i;$j--)
  {
    if($i%2==0)
    {
    echo "*";
    }
  }
  echo "<br>";
}
?>