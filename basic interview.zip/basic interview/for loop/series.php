<?php
$a=0;
$i=1;
do
{
 echo $a=$a+$i;
 $i++;
 echo "<br>";
}
while($i<=5);
?>