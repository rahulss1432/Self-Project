<?php
$a=25;
$b=15;
   {
    $c=$a+~$b+1;
    echo $c;
   }
?>