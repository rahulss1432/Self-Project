<?php
$n=23;
$c=0;
for($i=1;$i<$n;$i++)
{
 if($n%$i==0)
 {
  $c=$c+$i;
 }
}
if($c==1)
{
 echo "no is prime";
}
else
{
 echo "no is not prime";
}
echo "<br>";
?>