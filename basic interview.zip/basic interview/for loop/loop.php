<?php
     $fact=5;
     for($i=6;$i>=1;$i--)
      {
          $fact =$i*$fact;
           echo $fact; 
           
      }



?>