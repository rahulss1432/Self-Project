<?php
	$a=1;
	for($i=7; $i>=1; $i--)
	{
	  $a=($i*$a);
	} echo "<br>";
?>
<?php
$a=1;
for($i=5;$i>=1;$i--)
{
$a=($i*$a);
}
echo $a;
echo "<br>";
?>
<?php
$a=1;
for($i=8;$i>=1;$i--)
{
$a=($i*$a);
}
echo $a;
?>

<form method="post">
<input type="text" name="nm"/>
<input type="submit" name="btn" value="search"/>
</form>
<?php
if(isset($_POST["btn"]))
{
	$no=$_POST["nm"];
	$a=1;
	for($i=$no;$i>=1;$i--)
	{
		$a=$a*$i;
	}
	echo $a;
}
?>