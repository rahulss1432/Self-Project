<?php
  $x=50;
  $y=750;

    $c=$x-~$y-1;
    echo $c;
?>
<?php
$x=30;
$y=20;
$c=$x+~$y+1;
echo $c;
?>