<?php
$i=156894;
$a=0;
while($i>=1)
{
$b=$i%10;
$a=($a*10+$b);
$i=$i/10;
}
echo($a);
echo "<br>";
?>
<?php
$a=49865;
$b=10;
echo ($a*$b);
echo "<br>";
?>
<?php
$i=123456;
$a=0;
while($i>=1)
{
$b=$i%10;
$a=($a*10+$b);
$i=$i/10;
}
echo($a);
echo "<br>";
?>