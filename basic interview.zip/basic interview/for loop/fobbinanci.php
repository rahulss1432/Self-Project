<html>
<head>
	<style>
		#fobi
		{
			border:0px solid black;
			box-shadow: 0px 5px 11px rgba(1,1,1,1.2);
			width: 100px;
			float: left;
		}
		#f
		{
			float: left;
		}
		#se
		{
			float: left;
			margin-left: 60px;
		}
	</style>
</head>
<div id="fobi">
<div id="f">
<?php
$i=0;
$a=0;
$b=1;
while($i<=5)
{
$c=$b+$a;
echo($c);
echo"</br>";
$a=$b;
$b=$c;
$i=$i+1;
}
?>
</div>
<div id="se">
<?php
$i=0;
$a=0;
$b=1;
for($i=0;$i<=5;$i++)
{
	$c=$b+$a;
	echo $c;
	echo "<br>";
	$a=$b;
	$b=$c;
}
?>
</div>
</div>
</html>