<script>
function ajaxdemo()
{
 var ob = new XMLHttpRequest();
 ob.onreadystatechange = function()
 {
  if(ob.readyState==4)
  {
    document.frm.txtNm.value = ob.responseText;
	alert("hello");
  }
 }
  ob.open("GET","date2.php",true);
  ob.send(null);
}
</script>
<form method="post" name="frm" id="frm">
first name:<input type="text" name="txtNm" id="txtNm"/>
<input type="button" name="btnGo" id="btnGo" value="Go" onclick="ajaxdemo()" />
</form>