<?php
	mysql_connect("localhost","root","");
	mysql_select_db("userdb");
	$name = $_GET["nm"];
	$q = mysql_query("select * from login3tb where id='$name'");
	$data = mysql_fetch_array($q);
	echo "Id = ".$data["id"]."<br>";
	echo "Name = ".$data["name"]."<br>";
	echo "Password = ".$data["password"]."<br>"; 
?>