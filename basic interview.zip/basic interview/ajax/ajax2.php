<script>
function ajaxdemo()
{
 var ob = new XMLHttpRequest();
 ob.onreadystatechange = function()
 {
  if(ob.readyState==4)
  {
    document.frm.txtDate.value = ob.responseText;
	alert("hello");
  }
 }
  ob.open("GET","date.php",true);
  ob.send(null);
}
</script>
<form method="post" name="frm" id="frm">
date:<input type="text" name="txtDate" id="txtDate"/>
<input type="button" name="btnGo" id="btnGo" value="Go" onclick="ajaxdemo()" />
</form>