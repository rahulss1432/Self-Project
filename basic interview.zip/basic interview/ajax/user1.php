<?php
	mysql_connect("localhost","root","");
	mysql_select_db("userdb");
	$name = $_GET["nm"];
    $q = mysql_query("select * from login3tb where name LIKE'%$name%'");	
	while($data = mysql_fetch_array($q))
	{
	 echo $data["name"]."<br>";
	}
?>