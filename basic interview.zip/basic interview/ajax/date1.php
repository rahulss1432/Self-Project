<?php
echo date("d-m-y");
?>