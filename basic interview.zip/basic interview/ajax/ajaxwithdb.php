<?php
mysql_connect("localhost","root","");
mysql_select_db("userdb");
$sql=mysql_query("select * from login3tb");
?>
<html>
<head>
<script>
function userCall(name)
{
	var ob = new XMLHttpRequest();
	//Response Handler
	
	ob.onreadystatechange = function()
	{
		if(ob.readyState == 4)
		{
		 document.getElementById("data").innerHTML	= ob.responseText;
		}
	}
	//Request
	ob.open("GET","user.php?nm="+name,true);
	ob.send(null);
}
</script>
</head>
<body>
<select name="selUser" id="selUser" onChange="userCall(this.value)">
<option value="">Pls select Name</option>
<?php while($result=mysql_fetch_array($sql))
{
?>
<option value="<?php echo $result['id'];?>"><?php echo $result['name'];?></option>
<?php } ?>
</select>
</body>
</html>
<div id="data">

</div>