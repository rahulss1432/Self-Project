<html>
<head>
<script>
function dogcall()
{
 var ob = new XMLHttpRequest();
 ob.onreadystatechange = function()
 {
  if(ob.readyState==4)
  {
    document.getElementById("data").innerHTML	= ob.responseText;	
  }
 }
  ob.open("GET","dog.php",true);
  ob.send(null);
}
</script>
<script>
function catcall()
{
 var ob = new XMLHttpRequest();
 ob.onreadystatechange = function()
 {
  if(ob.readyState==4)
  {
    document.getElementById("data").innerHTML	= ob.responseText;	
  }
 }
  ob.open("GET","cat.php",true);
  ob.send(null);
}
</script>
</head>
<table border="1">
<tr>
<td align="center"><input type="button" value="dog" onClick="dogcall(this.value)" />
    <input type="button" value="cat" onClick="catcall(this.value)" /></td>
</tr>
<tr>
<td width="200" height="200" align="center"><div id="data">
</div></td>
</tr>
</table>
</html>