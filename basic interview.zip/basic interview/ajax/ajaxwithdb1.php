<html>
<head>
<script>
function userCall(name)
{
	var ob = new XMLHttpRequest();
	//Response Handler
	
	ob.onreadystatechange = function()
	{
		if(ob.readyState == 4)
		{
		 document.getElementById("data").innerHTML	= ob.responseText;
		}
	}
	//Request
	ob.open("GET","user1.php?nm="+name,true);
	ob.send(null);
}
</script>
</head>
<body>
<form method="post" name="frm" id="frm">
name:<input type="text" name="txtNm" id="txtNm" onKeyUp="userCall(this.value);" autocomplete="off" />
</form>
</body>
</html>
<div id="data">

</div>