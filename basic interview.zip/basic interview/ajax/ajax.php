<script>
function ajaxdemo()
{
 var ob = new XMLHttpRequest();
 ob.onreadystatechange = function()
 {
  if(ob.readyState==4)
  {
      document.frm.txtDate.value = ob.responseText;
  }
 }
  ob.open("GET","date1.php",true);
  ob.send(null);
}
</script>
<form method="post" name="frm" id="frm">
name:<input type="text" name="txtNm" id="txtNm"/>
date:<input type="text" name="txtDate" id="txtDate" onclick="ajaxdemo()" />
</form>