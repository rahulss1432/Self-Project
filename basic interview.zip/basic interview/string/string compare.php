<?php
  $s1="hello nitin";
  $s2="hello";
     
  echo strcmp($s1, $s2)
?>