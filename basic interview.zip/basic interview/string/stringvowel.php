<?php
$str="hello sandeep how are you and i am very exited";
$arr=array("l");
for($i=0;$i<strlen($str);$i++)
{
    for($j=0;$j<1;$j++)
	{
		if($str[$i] == $arr[$j])
		{
			echo $i."<br>";
		}
	}
}
?>

<?php
$str="whats wrong with you i am rahul solanki";
$arr=array("i","a","o","e","u");
for($i=0;$i<strlen($str);$i++)
{
	for($j=0;$j<5;$j++)
	{
		if($str[$i] == $arr[$j])
		{
			echo $arr[$j]."&nbsp;";
		}
	}
}
echo "<br>";
?>
<?php
$str="whats wrong with whats you is whats am rahul is solanki";
$l=explode(" ",$str);
$arr=array("is");
for($i=0;$i<count($l);$i++)
{
	for($j=0;$j<1;$j++)
	{
		if($l[$i] == $arr[$j])
		{
			echo $arr[$j]."&nbsp;";
		}
	}
}
echo "<br>";
?>

<?php
$str="whats wrong with whats you is whats am rahul is solanki";
$l=explode(" ",$str);
$arr=array("is");
for($i=0;$i<count($l);$i++)
{
	for($j=0;$j<1;$j++)
	{
		if($l[$i] == $arr[$j])
		{
			echo $i."&nbsp;";
		}
	}
}
echo "<br>";
?>

<?php
$str="hello sandeep how are you and i am very exited";
$s=strtoupper($str);
$arr=array("L");
for($i=0;$i<strlen($s);$i++)
{
    for($j=0;$j<1;$j++)
	{
		if($s[$i] == $arr[$j])
		{
			echo $i."<br>";
		}
	}
}
?>

<?php
$str="hello sandeep how are you and i am very exited";
$s=strtoupper($str);
$arr=array("L");
for($i=0;$i<strlen($s);$i++)
{
    for($j=0;$j<1;$j++)
	{
		if($s[$i] == $arr[$j])
		{
			echo $s[$i]."<br>";
		}
	}
}
?>