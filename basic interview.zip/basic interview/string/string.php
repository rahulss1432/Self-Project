<?php
$s1="hello";
echo ($s1);

?>