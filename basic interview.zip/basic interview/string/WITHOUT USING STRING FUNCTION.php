<?php
$a= "123456";
$l= strlen($a);
for($i=$l; $i>0; $i--)
    {
	 echo $a[$i-1];
	}
	echo "<br>";
?>
<?php
$b="GHIJKL";
$l=strlen($b);
for($i=$l;$i>0;$i--)
{
 echo $b[$i-1];
}
echo  "<br>";
?>
<?php
$str="a b c d e f";
$rrev=explode(" ",$str);
$l=count($rrev);
for($i=$l-1;$i>=0;$i--)
{
 echo $rrev[$i].' ';
}
?>
<?php
$str="123456";
$s=strrev($str);
echo ($s);
echo "<br>";
?>
<?php
$i=654321;
$a=0;
$c=0;
while($i>=1)
{
	$b=$i%10;
	$a=($a*10+$b);
	$i=$i/10;
}
echo $a."&nbsp";
while($a>=1)
{
 $d=$a%10;
 $c=($c*10+$d);
 $a=$a/10;
}
echo $c;
?>