<?php
$s1="hello";

echo strlen ($s1);

?>