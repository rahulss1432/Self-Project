<?php
$str = 'My Name Is Solanki  '; 
$str_arr = explode(' ',$str); 
$l=count($str_arr);
for($i=$l-1;$i>=0;$i--)
{ 
  echo $str_arr[$i].' ';
}
echo "<br>";
?>
<?php
$str="my name is rahul";
$str_rvs = explode(' ',$str);
for($i=(count($str_rvs)-1);$i>=0;$i--)
{
 echo $str_rvs[$i].' ';
}
echo "<br>";
?>
<?php
$str="jai shree radhe maa";
$str_rev = explode(" ",$str);
$l=count($str_rev);
for($i=$l-1;$i>=0;$i--)
{
	echo $str_rev[$i].' ';
}
echo "<br>";
?>
<?php
$arr=array("my","name","is","solanki");;
$a=array_reverse($arr);
print_r(implode(" ",$a));
?>