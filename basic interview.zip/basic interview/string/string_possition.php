<?php

$s1="hello nitin";
echo strpos ($s1,'n')


?>