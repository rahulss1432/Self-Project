<?php
$str="hello india";
echo $str;
echo "<br>";
$l=substr_replace($str, "india",'hello');
echo $str;
echo  "<br>";
?>
<?php
$str="i am rahul solanki";
$s=substr_count($str, "rahul solanki");
echo $s;
?>
<?php 
$str="i am rahul solanki";
$s=substr_compare("rahul","solanki","am");
echo $s;
?>