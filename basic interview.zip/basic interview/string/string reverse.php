<?php
$a="MOM";
echo $a;
echo"</br>";
echo  "reverse string is"."  ". strrev($a);
echo"</br>";
if($a==strrev($a))
   {
     echo "polindrom";
  }
else
   {
     echo "not polindrom";
   }
   echo"<br>";
?>
<?php
$b="RAHUL";
echo $b;
echo "<br>";
echo strrev($b);
echo "<br>";
if($b==strrev($b))
{
 echo "polindrom";
}
else
{
 echo "not polindrom";
}
?>  