<?php
mysql_connect("localhost","root","");
mysql_select_db("prectise_db");
if(isset($_POST["newpass"]))
{
	$eid=$_POST["eid"];
	$pass=$_POST["pass"];
	$npass=$_POST["npass"];
	$q=mysql_query("select * from prectise_tb where email='$eid' && password='$pass'")or die (mysql_error());
	if($data=mysql_num_rows($q))
	{
		mysql_query("update prectise_tb set password='$npass' where email='$eid'")or die(mysql_error());
		header("location:login.php");
	}
}
?>
<form method="post">
	Email:<input type="text" name="eid"/><br>
	Password:<input type="password" name="pass"/><br>
	New_Password:<input type="password" name="npass"/><br>
	<input type="submit" name="newpass" value="ChangePass"/>
</form>
<a href="login.php">Back</a>