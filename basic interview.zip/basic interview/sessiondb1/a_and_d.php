<?php
mysql_connect("localhost","root","");
mysql_select_db("prectise_db");
if(isset($_GET["act"]))
{
	$act=$_GET["act"];
	mysql_query("update prectise_tb set status='Active' where id='$act'");
}
if(isset($_GET["dact"]))
{
	$act=$_GET["dact"];
	mysql_query("update prectise_tb set status='Deactive' where id='$act'");
}
$q=mysql_query("select * from prectise_tb");
?>
<form method="post">
	<table border="1">
		<tr>
			<td>Name</td>
			<td>Password</td>
			<td>Email</td>
			<td>Active</td>
			<td>Deactive</td>
		</tr>
		<?php 
        while($data=mysql_fetch_array($q))
        {
		?>
		<tr>
		    <td><?php echo $data["name"];?></td>
		    <td><?php echo $data["password"];?></td>
		    <td><?php echo $data["email"];?></td>
		    <td><a href="a_and_d.php?act=<?php echo $data["id"];?>">Active</a></td>
		    <td><a href="a_and_d.php?dact=<?php echo $data["id"];?>">Deactive</a></td>
		</tr>
		<?php 
	    }
	    ?>
	</table>
</form>