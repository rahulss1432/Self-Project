<?php
session_start();
mysql_connect("localhost","root","");
mysql_select_db("prectise_db");
if(isset($_POST["btnLogin"]))
{
	$eid=$_POST["eid"];
	$pass=$_POST["pass"];
	$q = mysql_query("select * from prectise_tb where email='$eid' && password='$pass'")or die(mysql_error());
    $data = mysql_fetch_array($q);
    $sts=$data["status"];
    $_SESSION["snm"] = $data["name"];
    $_SESSION["pnm"] = $data["password"];
    $_SESSION["em"] = $data["email"];
    //echo "<pre>";
    //$_GLOBAlS;
    if($sts == "Active")
    {
    	header("location:adminpannel.php");
    }
    else
    {
    	header("location:login.php?err=1");
    }
}
?>
<center>
<form method="post">
    <center><font color="red"><h2>
        <?php
        if(isset($_GET["err"]))
            echo "email and paaword is wrong";
        ?>
    </h2></font></center>
	Email:<input type="text" name="eid"/>
	Password:<input type="Password" name="pass"/>
	<input type="submit" name="btnLogin" value="Login"/>
	<a href="newpassword.php">New Password</a>
	<a href="signup.php">Signup</a>
</form>
</center>