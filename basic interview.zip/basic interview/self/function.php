<?php
include("db.php");
$id=(isset($_REQUEST["id"])?$_REQUEST["id"]:"");
if(isset($_REQUEST["h1"]))
{
 $action=$_REQUEST["h1"];
 call_user_func($action,$_REQUEST,$id);
}
function addUser()
{
 $nm=$_POST["nm"];
 $eid=$_POST["eid"];
 mysql_query("insert into utb(name,email)values('$nm','$eid')")or die(mysql_error());
 echo "Data Successfully Send";
}
function fetchUser()
{
?>
<form method="post" name="frm1" id="frm1" action="">
<table border="1">
<tr>
<td>Check</td>
<td>Name</td>
<td>Email</td>
<td>DLink</td>
<td>Elink</td>
</tr>
<?php
$q=mysql_query("select * from utb");
while($data=mysql_fetch_array($q))
{
?>
<tr>
<td><input type="checkbox" name="chk[]" id="chk" value="<?php echo $data["id"];?>"></td>
<td><input type="text" name="txtNm<?php echo $data["id"];?>" value="<?php echo $data["name"];?>" /></td>
<td><input type="text" name="txtEid<?php echo $data["id"];?>" value="<?php echo $data["email"];?>" /></td>
<td><input type="button" name="Userdel" id="Userdel" value="Delete" onclick="deleteUser(<?php echo $data["id"];?>);"/></td>
<td><input type="button" name="Useredit" id="Useredit" value="Update" onclick="UserEdit(<?php echo $data["id"];?>)" /></td>
</tr>
<?php } ?>
<tr>
<td colspan="5" align="center"><input type="button" name="delUser" id="delUser" value="Delete" onclick="delbtn(<?php echo $data["id"];?>);"/><input type="button" name="editUser" id="editUser" value="Update" onclick="editbtn(<?php echo $data["id"];?>)" /></td>
</tr>
</table>
</form>
<?php
}
//del Link//
function delUser($id)
{ 
 $id=$_REQUEST["id"];
 mysql_query("delete from utb where id='$id'");
 echo "Data Successfully Delete";
}
//edit link//
function editUser($id)
{
 $id=$_REQUEST["id"];
 $nm=$_POST["txtNm".$id];
 $eid=$_POST["txtEid".$id];
 mysql_query("update utb set name='$nm',email='$eid' where id='$id'")or die (mysql_error());
 echo "Data Successfully Update";
}
//del check//
function btndel($id)
{
  $id=$_REQUEST["chk"];
  foreach($id as $v)
  {
   mysql_query("delete from utb where id='$v'");
  }
  echo "Data Successfully Delete";
} 
//edit check//
function btnedit($id)
{
  $id=$_REQUEST["chk"];
  foreach($id as $v)
  {
  	$nm=$_POST["txtNm".$v];
  	$eid=$_POST["txtEid".$v];
  	mysql_query("update utb set name='$nm',email='$eid' where id='$v'");
  }
  echo "Data Successfully Update";
}
?>