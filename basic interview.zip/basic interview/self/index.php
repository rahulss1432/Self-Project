<html>
<head>
<script type="text/javascript" src="jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="script.js"></script>
</head>
<body>
<form method="post" name="frm" id="frm" action="">
<input type="text" name="nm" id="nm" placeholder="Enter your name" />
<input type="text" name="eid" id="eid" placeholder="Enter your email" />
<input type="hidden" name="h1" id="h1" value="addUser" />
<input type="button" name="btnGo" value="Go" id="btnGo" />
</form>
<div id="result" style="border:3px solid #666666; width:500px; height:50px;"></div>
<div id="res_data">
</div>
</body>
</html> 