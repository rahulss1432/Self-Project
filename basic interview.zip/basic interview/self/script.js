$(document).ready(function()
{
  $("#btnGo").click(function()
   {
	 $form_data=$("#frm").serialize();
	 $.ajax({
			url:"function.php",
			method:"POST",
			data:$form_data,
			success:function(response)
			{
		      $("#result").html(response);
			  getUser();
			}
			});
   });
});
function getUser()
{
  $.ajax({
		 url:"function.php?h1=fetchUser",
		 method:"POST",
		 success:function(response)
		 {
			$("#res_data").html(response);
		 }
		 });
}
//del link//
function deleteUser(id)
{
   $.ajax({
		  url:"function.php?h1=delUser&id="+id,
		  method:"POST",
		  success:function(response)
		  {
			$("#result").html(response);
		    getUser();
		  }
		  });
}
//edit link//
function UserEdit(id)
{
   $form_data=$("#frm1").serialize();
   $.ajax({
		  url:"function.php?h1=editUser&id="+id,
		  method:"POST",
		  data:$form_data,
		  success:function(response)
		  {
			 $("#result").html(response);
			 getUser(id);
		  }
		  });
}
//del btn//
function delbtn(id)
{
	$("#delUser").click(function()
	{
	$form_data=$("#frm1").serialize();
	$.ajax({
           url:"function.php?h1=btndel&chk="+id,
           method:"POST",
           data:$form_data,
           success:function(response)
           {
           	$("#result").html(response);
           	getUser(id);
           }
	});
});
}
//edit btn//
function editbtn(id)
{
	$("#editUser").click(function()
	{
      $form_data=$("#frm1").serialize();
      $.ajax({
             url:"function.php?h1=btnedit&chk="+id,
             method:"POST",
             data:$form_data,
             success:function(response)
             {
             	$("#result").html(response);
             	getUser(id);
             }
      });
	});
}