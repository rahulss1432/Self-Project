<?php
class Student
{
	function show()
	{
		echo "SHow Called..";
	} 
}
$ob = new Student();
$ob->show();
?>



