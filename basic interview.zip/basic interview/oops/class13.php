<?php
class Student
{
	function __construct($rno)
	{
		echo $rno;
	}
}
$ob = new Student(101);
?>