<?php
class Student
{
	 function __construct()
	{
		echo "Constructor Agian Called..";
	}
}
$ob = new Student();
?>
