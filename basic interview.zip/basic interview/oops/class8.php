<?php
class Year2015
{
	var $rno  ;
	var $name ;
	function set_detail()
	{
		$this->rno = 101;
		$this->name = "Admin";
	} 
	function get_detail()
	{
		echo $this->rno;
		echo $this->name;
	}
}
class Year2016
{
	var $rno  ;
	var $name ;
	function set_detail()
	{
		$this->rno = 102;
		$this->name = "Info";
	} 
	function get_detail()
	{
		echo $this->rno;
		echo $this->name;
	}
}
$ob = new Year2015();
$ob->set_detail();
$ob->get_detail();
$ob1 = new Year2016();
$ob1->set_detail();
$ob1->get_detail();
?>