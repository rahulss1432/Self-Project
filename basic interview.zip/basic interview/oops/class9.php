<?php
class Year2015
{
	var $rno  ;
	var $name ;
	function set_detail()
	{
		$this->rno = 101;
		$this->name = "Admin";
	} 
	function set_detail()
	
	{
		echo $this->rno;
		echo $this->name;
	}
}
?>