<?php
class Student
{
	function Student()
	{
		echo "Constructor Called..";
	}
}
$ob = new Student();
?>