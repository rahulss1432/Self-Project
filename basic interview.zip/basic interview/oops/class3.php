<?php
class Student
{
	function add()
	{
		$a = 10;
		$b = 22;
		echo $a + $b;
	} 
}
$ob = new Student();
$ob->add();
?>