<?php
class Student
{
	var $rno  ;
	var $name ;
	function set_detail()
	{
		$this->rno = 101;
		$this->name = "Admin";
	} 
	function get_detail()
	{
		echo $this->rno;
		echo $this->name;
	}
}
$ob = new Student();
$ob->set_detail();
$ob->get_detail();
?>