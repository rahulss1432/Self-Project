<?php
class Student
{
	var $rno = 101 ;
	var $name = "Admin";
	function detail()
	{
		echo "Rno = ".$this->rno;
		echo "Name = ".$this->name; 
	} 
}
$ob = new Student();
$ob->detail();
?>



