<?php
class Year2015
{
	var $rno  ;
	var $name ;
	protected function set_detail()
	{
		$this->rno = 101;
		$this->name = "Admin";
		echo $this->rno;
		echo $this->name;
	}
}
$ob = new Year2015();
$ob->set_detail();
?>