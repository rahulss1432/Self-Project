<?php
//this is a constructor over riding because not support constructor over loading//
	class A
	{
		function __construct()
		{
			echo "A called.";
		}
	}
	class B extends A
	{	
		function __construct()
		{
			parent::__construct();
			echo "B called.";
		}
	}
	$ob = new B();
?>
<?php
class C
{
 function demo()
 {
  echo "Demo Called..";
 }
}
class D extends C
{
  function demo()
 {
  parent::demo();
  echo "Show Called..";
 }
}
$ob=new D();
$ob->demo();  
?>