<?php
	interface A
	{
		function demo();
	}
	interface B extends A
	{
		function show();
	}
	class C implements A,B
	{
		function demo()
		{
			echo "Demo called.";
		}
		function show()
		{
			echo "Show called.";
		}
	}
	$ob = new C();
	$ob->demo();
	$ob->show(); 
?>