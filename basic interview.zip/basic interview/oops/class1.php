<?php
class Student
{
	var $rno = 101;
}
$ob = new Student();
echo $ob->rno;
?>
<?php
class S 
{
 var $rno=101;
}
$ob =new S();
echo $ob->rno;
?>