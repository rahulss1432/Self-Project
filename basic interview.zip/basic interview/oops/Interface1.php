<?php
/*
interface : is similar to classes.

it contain a function without any body

CANNOT CREATE A OBJECT OF INTERFACE

one interface can extends anouther interface

one class can implements ,more than one interface

-----------------------------------------------
*/
	interface A
	{
		function demo();
	}
	interface B
	{
		function show();
	}
	class C implements A,B
	{
		function demo()
		{
			echo "Demo called.";
		}
		function show()
		{
			echo "Show called.";
		}
	}
	$ob = new C();
	$ob->demo();
	$ob->show(); 
?>