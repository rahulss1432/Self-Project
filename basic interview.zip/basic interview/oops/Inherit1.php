<?php
class A
{
	function demo()
	{
		echo "Demo called..";
	}
}
class B extends A
{
}
$ob = new B();
$ob->demo();
?>