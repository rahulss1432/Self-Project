<?php
//multiple inheritance not support php for this use of interface//
class A
{
	 function demo()
	{
		echo "Demo called..";
	}
}
class B 
{
	function show()
	{
		echo "Show called..";
	}
}
class C extends A,B
{

}
$ob = new C();
?>