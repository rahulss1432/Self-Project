<?php
//multi level inheritance//
class A
{
	function demo()
	{
		echo "Demo called..";
	}
}
class B extends A
{
	function show()
	{
		echo "Show called..";
	}
}
class C extends B
{
	function hide()
	{
	 echo "Hide Called..";
	} 
}
class D extends C
{
 function get()
 {
  echo "Get Called...";
 }
}
$ob = new D();
$ob->demo();
$ob->show();
$ob->hide();
$ob->get();
?>