<?php
class Student
{
	var $rno;
	var $name;
	function detail()
	{
		$rno = 101;
		$name = "Admin";
		echo "Rno = ".$rno;
		echo "Name = ".$name; 
	} 
}
$ob = new Student();
$ob->detail();
?>