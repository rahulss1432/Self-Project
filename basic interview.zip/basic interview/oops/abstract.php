<?php
/*
	Abstract :
	
	apply  => class and function
	
	A abstract class contain abstract or non abstract function
	
	but A none abstrat class contain can not use of abstract function  

	cannot instantiate abstract class 
	
	cannot create of abstract class object
*/
	abstract class A
	{
		abstract function show();
		function demo()
		{
			echo "Demo called";
		}
	}
	abstract class B extends A
	{
		function show()
		{
			echo "Show called";
		}
	}
	class C extends B
	{
	 function get()
	 {
	  echo "Get Called";
	 }
	}  
	$ob = new C();
	$ob->show();
	$ob->demo();
	$ob->get();
?>