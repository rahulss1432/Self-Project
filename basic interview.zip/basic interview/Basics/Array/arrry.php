<?php

$arr[0][0]=10;

$arr[0][1]=20;

$arr[1][0]=30;

$arr[1][1]=40;
  
for($r=0; $r<=1; $r++)
{
 for($c=0; $c<=1; $c++)
  {
     echo $arr[$r][$c];
   }
     echo "<br>";
}
?>