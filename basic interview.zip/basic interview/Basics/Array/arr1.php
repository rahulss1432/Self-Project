<?php
 
 $arr=array(10,20,"admin",10.20);
 
 echo $arr[0]."<br>";
 echo $arr[1]."<br>";
 echo $arr[2]."<br>";
 echo $arr[3]."<br>";

?>
