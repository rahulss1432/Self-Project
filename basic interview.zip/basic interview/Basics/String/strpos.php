<?php
 
 $str="welcome";
 echo strpos("welcome",'l');

 ?>
