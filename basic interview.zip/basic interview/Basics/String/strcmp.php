<?php

 $str1="Hello";
 
 $str2="Hellooooooooooo";
 
 echo strcmp($str1,$str2);

?>

