<?php
 
  $str="welcome";

  echo strlen($str);
?>