<?php
 
$str="INDIAN";

 echo  stristr($str, 97);

?>
