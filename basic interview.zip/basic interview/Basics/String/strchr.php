<?php
 
 $str="welcome indore";
  
  echo  strrchr($str,'d');

 ?>
