<?php

  $str="Hello World india";

  $con=explode(" ",$str);
  
 print_r($con);

?>