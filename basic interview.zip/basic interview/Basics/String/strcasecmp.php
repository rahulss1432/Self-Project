<?php
  
 $str1="Helloooooo";
 
 $str2="Helloooooooooooooooooo";

 if(strcasecmp($str1,$str2)==0)
 {
   echo "str both are equal";
 }

elseif(strcasecmp($str1,$str2)>0)
      {
      echo "str1 is grater then str2";
      }
   else 
      {
         strcasecmp($str1,$str2)<0;
   
        echo "str2 is grater then str1";

      }

  
?>

    