<?php
 
$arr=array("hello","world","india");

$con=implode(" ",$arr);

echo $con;


?>

