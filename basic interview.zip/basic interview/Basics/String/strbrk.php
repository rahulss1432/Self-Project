<?php
  
 $str="welcome";
  
 echo  strpbrk($str,'el');

?>
