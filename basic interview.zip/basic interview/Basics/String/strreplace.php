<?php
 
$str="Hello world";
 
echo str_replace("world","demo",$str);

?>
