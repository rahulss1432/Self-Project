<?php
  
  function add($a,$b)
  {
   $c=$a+$b;
   echo $c;
  }
  add(30,40)
?>