<?php
  function add()
  {
   $a=10;
   $b=20;
   $c=$a+$b;
    return($c);
 }
  $d=add();
     function mul($e,$f)   
    {
      echo $e*$f;
   }
   mul($d,10);
?>