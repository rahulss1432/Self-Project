<?php
   
  function show()
 {
   echo "show called";
 }
  show();
?>
