<?php
   function add()
{
  $a=40;
  $b=20;
  $c=$a+$b;
  return($c);
}
   echo add();

?>
