<?php
   function geta()
    {
      getb();
      echo "geta called";
     
    }
   function getb()
    {
      getc();
      echo "getb called";
       
    }
     function getc()
     {
      echo "getc called";
     }
     geta();
 ?>
