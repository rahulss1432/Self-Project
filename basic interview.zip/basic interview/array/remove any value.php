<?php
$array = array(10, 20, 30, 40, 50, 60,20,20);
     function rmv_val($var)
     {
      return(!($var == '20'));
     }
    $array_res = array_filter($array, "rmv_val");
    array_push($array_res, 70,80);
    print_r($array_res);
    echo "<br>";
?>
<?php
$arr=array('rahul','nitin','sandeep');
function rmv($var)
{
 return(!($var=="rahul"));
} 
$arr_rev=array_filter($arr,"rmv");
print_r($arr_rev);
echo "<br>";
?>

<?php
$arr=array(10,20,30,40,50,60,10,10);
function remove($a)
{
	return(($a == '10'));
}
$array=array_filter($arr,"remove");
print_r($array);
?>