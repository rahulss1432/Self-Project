<?php

$arr= array("rno"=>101, "name"=> "admin", "email"=>"rahul@gmail.com");
echo $arr["rno"];
echo"</br>";
echo $arr["name"];
echo"</br>";
echo $arr["email"];
?>

<?php

$arr= array("10", "20", "30");
echo $arr["0"];
echo"</br>";
echo $arr["1"];
echo"</br>";
echo $arr["2"];

?>