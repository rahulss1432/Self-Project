<?php

$arr= array("rno"=>101, "name"=> "admin", "email"=>"rahul@gmail.com");

  foreach($arr as $a)
       {
         echo $a;
         echo "</br>";
       }

?>
<?php

$arr= array("rno"=>101, "name"=> "admin", "email"=>"rahul@gmail.com");

  foreach($arr as $a)
       {
         print_r($arr);
         echo "</br>";
       }
?>