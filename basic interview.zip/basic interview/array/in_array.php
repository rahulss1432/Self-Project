<?php
     $arr = array("vishal", "pratik", "rajesh", "nilesh");

  if (in_array("pratik", $arr))
   {
     echo "match found";
   }
  else
  {
    echo "match not found";
  }
  echo "<br>";
?>
<?php
$arr=array("rahul","sandeep","vinay","yogesh","atul");
if(in_array("ram",$arr))
{
 echo "match found";
}
else
{
 echo "match not found";
}
?>