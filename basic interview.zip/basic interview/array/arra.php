<!DOCTYPE html>
<html>
<body>
<?php
 $cars = array
  (
  array("Volvo",22,18),
  array("BMW",15,13),
  array("Saab",5,2),
  array("Land Rover",17,15)
  );
    
for ($row = 0; $row < 4; $row++) {
  echo "<p><b>Row number $row</b></p>";
  echo "<ul>";
  for ($col = 0; $col < 3; $col++) {
    echo "<li>".$cars[$row][$col]."</li>";
  }
  echo "</ul>";
}
?>
<?php
$arr=array(
array("rahul",22,"maheshwer"),
array("rohit",22,"maheshwer"),
array("nitin",23,"maheshwer")
);
for($row=0;$row<3;$row++)
{ 
 echo "<ul>";
 for($col=0;$col<3;$col++)
 {
  echo "<li>".$arr[$row][$col]."</li>";
 }
 echo "</ul>";
}  
?>
</body>
</html>