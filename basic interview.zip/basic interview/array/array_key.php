<?php
$arr=array("name"=>"rahul","password"=>"r12345");
foreach($arr as $key=>$v)
{
 echo $key."=".$v;
 echo "<br>";
}
?> 
<?php
$arr=array("name"=>"rahul","password"=>"r123");
foreach($arr as $key=>$v)
{
 echo $key."=".$v;
 echo "<br>"; 
}
?>