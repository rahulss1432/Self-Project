<?php
$arr=array("rahul","nitin","maheshwari","rajeshsolanki","abcdefg","asdfg");
$b="";
$c=count($arr);
for($i=0;$i<$c;$i++)
{
	$v=strlen($arr[$i]);
	if($v>$b)
	{
       $b=$v;
	}
}
echo $b;
echo "<br>";
?>
<?php
$arr=array("rahul","nitin","maheshwari","rajeshsolanki","abcdefg","asdfg","rsdfjkhdfdsdkh");
$b="";
$c=count($arr);
foreach($arr as $v)
{
	if($v>$b)
	{
       $b=$v;
	}
}
print_r($b);
echo "<br>";
?>
<?php
$arr=array("bhjsdfkjdfsdkhhdf","rahul","nitin","maheshwari","rajeshsolanki","abcdefg","asdfg","rsdfjkhdfdsdkhhkjhk54","mdasdhajkhdkjsh");
print_r($arr);
$b="";
$c=count($arr);
for($i=0;$i<$c;$i++)
{
	$s=strlen($arr[$i]);
	echo $s;
	echo "<br>";
	$l=explode(" ",$s);
	if($l>$b)
	{
		$b=$l;
	}
}
print_r($b);
echo "<br>";
?>