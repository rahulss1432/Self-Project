<?php
$arr= array(10, 20, 30, 40);
print_r($arr);
?>

<?php
$arr=array(10,20,30);
$arr1=array(40,50,60);
$result = array_merge($arr,$arr1);
print_r($result);
?>