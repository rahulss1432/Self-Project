<?php
      $arr = array(10, 20, 30, 40);
      array_pop ($arr);
      print_r ($arr);
      echo "<br>";
?>
<?php
$arr=array(10,20,30,40,50);
array_pop($arr);
print_r($arr);
echo "<br>";
?>
<?php
$arr=array(10,20,30,40);
$l=count($arr);
unset ($arr[$l-1]);
print_r($arr);
?>
<?php
$arr=array(10,20,30,40);
$l=count($arr);
unset ($arr[$l-2]);
$arr[$l-2]="50";
print_r($arr);
?>