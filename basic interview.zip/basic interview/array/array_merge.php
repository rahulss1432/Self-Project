<?php
$arr=array(10,20,30,40);
$arr1=array(50,60,70,80);
print_r(array_merge($arr,$arr1));
echo "<br>";
?>