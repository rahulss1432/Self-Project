<?php
    $str = "hello i am nitin";
 
    print_r (explode(" ",$str));

    echo "<br>";
?>
<?php
$str="i am rahul solanki";
$ex=explode(" ",$str);
$l = count($ex);
$ex[$l]="from";
$ex[$l+1]="maheshwer";
print_r($ex);
$im=implode(" ",$ex);
print_r($im);
echo "<BR>";
?>
<?php
$str="i am rahul solanki from maheshwer";
$ex=(explode(" ",$str));
$l=count($ex);
unset($ex[$l-1]);
print_r($ex);
print_r(implode(" ",$ex));
echo "<br>";
?>
<?php
$str="i am rahul solanki from maheshwer";
$ex=explode(" ",$str);
$search=array_search('from',$ex);
unset ($ex[$search]);
$e=implode(" ",$ex);
print_r($e);
echo "<br>";
?>
<?php
$str="i am rahul solanki";
$ex=(explode(" ",$str));
$l=array_search("solanki",$ex);
$ex[$l]="sharma";
$ex[$l+1]="from";
$ex[$l+2]="maheshwer";
print_r(implode(" ",$ex));
echo "<br>";
?>

<?php
$str="i am rahul solanki";
$ex=explode(" ",$str);
$search=array_search("am",$ex);
$ex[$search+1]="from";
$ex[$search+2]="maheshwer";
print_r(implode(" ",$ex));
?>