<?php
         $arr = array('hello', 'i', 'am', 'amit');

      echo implode(" ",$arr);
	  
	  echo"<br>";

?>
<?php
$arr=array("i", "am", "rahul", "solanki");
echo implode(" ",$arr);
echo "<BR>";
?>
<?php
$arr=array("i", "am", "rahul", "solanki");
$l=count($arr);
unset ($arr[$l-1]);
echo implode(" ",$arr);
echo "<br>";
?>
<?php
$arr=array();
$l=count($arr);
$arr[$l]="i";
$arr[$l+1]="am";
$arr[$l+2]="rahul";
$arr[$l+3]="solanki";
echo implode(" ",$arr);
echo "<br>";
?>
<?php
$arr=array(10,20,30,40,50);
echo (implode(",",$arr));
?>