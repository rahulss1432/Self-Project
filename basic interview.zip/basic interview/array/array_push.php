<?php
    $arr = array(10, 20, 30);

    array_push($arr, 40, 50,60,70);

    print_r ($arr);

    echo "<br>";
?>
<?php
$arr=array(10,20,30,40);
array_push($arr,50,60,70);
print_r($arr);
echo "<br>";
?>
<?php
$arr=array(10,20,30,40);
$l=count($arr);
$arr[$l]=50;
$arr[$l+1]=60;
$arr[$l+2]=70;
print_r($arr);
echo "<br>";
?>
<?php
$str="abcdefg";
$l=strlen($str);
$str[$l]="h";
$str[$l+1]="i";
$str[$l+2]="j";
echo($str);
?>