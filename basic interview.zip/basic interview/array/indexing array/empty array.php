<?php

$arr= array(  );

echo $arr;
?>