<?php

       $arr = array(10, 20, 30, 40, 50, 60);

       for($i=0; $i<=5; $i++)
        {
         echo $arr[$i];
         echo "</br>";
        }
?>