<?php

      $arr=array(10, 20, 30, "hello", 10.23);

     echo $arr[0];
     echo $arr[1];
    echo $arr[2];
    echo $arr[3];
    echo $arr[4];
?>