<?php

      $arr=array(10, 20, 30, "hello", 10.23);

     echo $arr;
?>