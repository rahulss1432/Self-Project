<?php
$arr[0]=10;
$arr[1]=20;
echo $arr[0];
echo $arr[1];
?>