<?php

$numbers = array(89,2,4,3,76,45,7,9,5,1,0,43,34,56,65,98);
 print_r($numbers);

echo "</br>";
echo "</br>";

echo "managed numbers are=".sort($numbers); 


echo "</br>";
echo "</br>";


print_r($numbers);

echo "</br>";
echo "</br>";

echo $removed= implode(",",$numbers);


echo "</br>";
echo "</br>";

print_r(rsort($numbers));
print_r($numbers);

echo "</br>";
echo "</br>";

echo $remove = implode(" ",$numbers);

echo "</br>";

echo "</br>";

echo $numbers= explode(" ",$remove);
print_r($numbers);
echo "</br>";
echo "</br>";

echo "".sort($numbers); 
print_r($numbers);

?>