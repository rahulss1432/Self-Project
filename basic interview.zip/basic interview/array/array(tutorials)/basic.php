<?php
$digits= array('11','12','13','14','15','16','17');
echo $digits[1];
?>