	<?php
$mixed= array('10','20','30','sumit','50');
$mixed[]=90;
$mixed[]=1200;
print_r($mixed); 
?>