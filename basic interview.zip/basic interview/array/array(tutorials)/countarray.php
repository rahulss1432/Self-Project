<?php

$numbers= array(5,6,7,4,8,4,2,0,4,56,65,45,34);

print_r($numbers);
echo ".</br></br>";

// for count array[.count(array)]

echo "the total numbers in pocket is =".count($numbers);
echo ".</br></br></br></br>";
 
// for find maximum value[.max(array)]
echo "the maximum value is =".max($numbers);

echo ".</br></br></br></br>";

// for find minimum value[.min(array)]

echo "the minimum value is =".min($numbers);
?>