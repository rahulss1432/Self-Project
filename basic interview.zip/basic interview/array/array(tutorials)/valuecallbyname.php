<?php
$digits= array('sumit'=>23,'ramukaka'=>43,'bob'=>15,'sunita'=>17);
print_r($digits);
?>