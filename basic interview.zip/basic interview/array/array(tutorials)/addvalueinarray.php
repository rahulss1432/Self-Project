<?php
$mixed= array('10','20','30','sumit','50');
$mixed[5]=90;
$mixed[]=1200;
$mixed[]=1400;
print_r($mixed); 
?>