<?php
$arr=array(10,20,30,40,50);
$search=array_search('20',$arr);
print_r($search);
$arr[$search]=80;
print_r($arr);
echo "<br>";
?>
<?php
$arr=array("rahul","mahesh","manoj","mukesh","munna");
$search=array_search('mahesh',$arr);
print_r($search);
unset ($arr[$search]);
print_r($arr);
echo "<br>";
?>
<?php
$arr=array(10,20,30,40,50);
$l=array_search('30',$arr);
print_r($l);
unset ($arr[$l]);
print_r($arr);
echo "<br>";
?>
<?php
$arr=array("rahul","mahesh","manoj","mukesh","munna");
$l=array_search("manoj",$arr);
print_r($l);
$arr[$l]="ram";
print_r($arr);
echo "<br>";
?>
<?php
$str="i am rahul solanki";
$ex=explode(" ",$str);
$search=array_search("am",$ex);
unset($ex[$search]);
print_r(implode(" ",$ex));
echo "<br>";
?>
<?php
$str="i am rahul solanki";
$ex=explode(" ",$str);
$search=array_search("am",$ex);
//$ex[$search]="amm";
$ex[$search+1]="ram";
print_r(implode(" ",$ex));
?>