<html>
<head>
<script type="text/javascript" src="jquery-1.9.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#btn").click(function()
 {
  $("#p").animate({right:'930px',bottom:'500px',top:'100px',border:'1px'});
 });
});  
</script>
</head>
<body>
<button id="btn">Onclick</button>
<div id="p" style="border:2px solid #000000; width:300px; height:200px; background:#000099; position:absolute; ">
</div>
</body>
</html>