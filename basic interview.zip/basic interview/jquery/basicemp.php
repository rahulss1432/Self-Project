<html>
<head>
<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 var a;
 var b;
 var c;
 var d;
 var e;
 var f;
 $("#emp1mon").change(function()
 {
  a=$("#emp1mon").val();
  $("#emp1anu").val(12*a);
  b=$("#emp1anu").val();
  $("#monthlyTotal").val(parseInt(a));
  g=$("#monthlyTotal").val();
  $("#anualTotal").val(parseInt(b));
  h=$("#anualTotal").val();
  $("#GrandTotal").val(parseInt(g)+parseInt(h));
  c=$("#GrandTotal").val();
 });
 $("#emp2mon").change(function()
 {
  d=$("#emp2mon").val();
  $("#emp2anu").val(12*d);
  e=$("#emp2anu").val();
  $("#monthlyTotal").val(parseInt(a)+parseInt(d));
  i=$("#monthlyTotal").val();
  $("#anualTotal").val(parseInt(b)+parseInt(e));
  j=$("#anualTotal").val();
  $("#GrandTotal").val(parseInt(i)+parseInt(j));
  f=$("#GrandTotal").val();
 });
});  
</script>
</head>
<body>
<form method="post">
<table border="1">
<tr>
<td></td>
<td>monthly Salary</td>
<td>Annual Salary</td>
</tr>
<tr>
<td>Emp1</td>
<td><input type="text" id="emp1mon" /></td>
<td><input type="text" id="emp1anu" /></td>
</tr>
<tr>
<td>Emp2</td>
<td><input type="text" id="emp2mon" /></td>
<td><input type="text" id="emp2anu" /></td>
</tr>
<tr>
<td>Total</td>
<td><input type="text" id="monthlyTotal" /></td>
<td><input type="text" id="anualTotal" /></td>
</tr>
<tr>
<td>Grand Total</td>
<td><input type="text" id="GrandTotal" /></td>
</tr>
</table>
</form>
</body>
</html>