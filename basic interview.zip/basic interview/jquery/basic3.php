<html>
<head>
<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
<script type="text/javascript">

$(document).ready(function()
{
	   $("#btn").click(function()
	   {
		   var username = $(".nm1").val();
	   		$("#unm").val(username);
	   });
	  
});
</script> 
</head>
<body>
	<input type="text" name="nm" id="nm" class="nm1">
    <button id="btn">Click me</button>
	<input type="text" name="unm" id="unm">
</body>
</html>