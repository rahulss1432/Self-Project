<html>
<head>
<script type="text/javascript" src="jquery-1.9.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("button").click(function()
 {
  $("p").hide("slow",function(){
  alert("hy Rahul");
  });
 });
}); 
</script>
</head>
<body>
<button>Hide</button>
<p>i am rahul solanki</p>
</body>
</html>