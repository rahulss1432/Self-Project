<html>
<head>
<script type="text/javascript" src="jquery-1.9.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("button").click(function()
 {
  var div=$("div");
  div.animate({left:'300px'},"slow");
  div.animate({fontSize:'3em'},"slow");
 });
});  
</script>
</head>
<body>
<button>Hello</button>
<div style="background:#CCFF33; width:100px; height:100px; position:absolute;">Radhe</div>
</body>
</html>