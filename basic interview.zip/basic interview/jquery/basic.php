<html>
<head>
<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
<script type="text/javascript">

$(document).ready(function()
{
	   alert("Hello.."); 
});

</script> 
</head>
</html>