<html>
<head>
<script type="text/javascript" src="jquery-1.9.1.min.js"></script>
<script type="text/javascript">
jQuery(document).ready(function()
{
	   jQuery("#btnchk").click(function()
	   {
		   var address = jQuery("#add1").val();
	   		jQuery("#add2").val(address);
	   });
	  
});
</script> 
</head>
<body>
	address<input type="text" name="txtAdd1" id="add1"/>
    <input type="checkbox" name="chk" id="btnchk" />
	per.address<input type="text" name="txtAdd2" id="add2"/>
</body>
</html>