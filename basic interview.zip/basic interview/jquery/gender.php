<html>
<head>
<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
<script type="text/javascript">

$(document).ready(function()
{
	   $("#r1").click(function()
	   {
		   var name = $(this).val();
	   		$("#gen").val(name);
	   });
	   $("#r2").click(function()
	   {
		   var name1 = $(this).val();
	   		$("#gen").val(name1);
	   }); 
});
</script> 
</head>
<body>
	male<input type="radio" name="rdbGen" id="r1" value="male"/>
    female<input type="radio" name="rdbGen" id="r2" value="female"/>
	<input type="text" name="gen" id="gen" />
</body>
</html>