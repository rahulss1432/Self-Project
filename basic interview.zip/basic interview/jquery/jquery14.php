<html>
<head>
	<script type="text/javascript" src="jquery-1.9.1.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function()
		{
          $("#btn").click(function()
          {
          	var a=$("#d");
          	a.animate({height:"200",width:"200"});
          	a.queue(function()
          	{
          		a.css("background-color","blue");
          	a.animate({height:"300",width:"300"});
          	$("#d").append('<img src="$@MEER ^015.jpg" width="200" height="200">');
            $("#d").show();
           });
          });
		});
	</script>
</head>
<body>
<input type="text" id="btn"/>
<div id="d" style="width:300px; height:300px; background:red;">
	
</div>
</body>
</html>