<html>
<head>
<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#btn").click(function()
 { 
  var a=$("#txtNm").val();
  var b=$("#txtNm1").val();
  $("#txtTotal").val(parseInt(a)+parseInt(b));
  });
});
</script>
</head>
<body>
No1:<input type="text" name="txt" id="txtNm" /><br />
No2:<input type="text" name="txt" id="txtNm1" /><br />
<input type="button" name="btn" id="btn" value="ADD"/>
Total:<input type="text" name="txtTotal" id="txtTotal" />
</body>
</html> 