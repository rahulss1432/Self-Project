<html>
<head>
<script type="text/javascript" src="jquery-2.1.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 var a;
 var b;
 var c;
 var d;
 var e;
 var f;
 var g;
 var h;
 var i;
 var j;
 var k;
 var l;
 $("#emp1mon").change(function()
 {
  a=$("#emp1mon").val();
  $("#emp1anu").val(12*a);
  b=$("#emp1anu").val();
  $("#monthlyTotal").val(parseInt(a));
  var month=$("#monthlyTotal").val();
  $("#anualTotal").val(parseInt(b));
  var anual=$("#anualTotal").val();
  $("#grantTotal").val(parseInt(month)+parseInt(anual));
  c=$("#grantTotal").val();
 });
 $("#emp2mon").change(function()
 {
  d=$("#emp2mon").val();
  $("#emp2anu").val(12*d);
  e=$("#emp2anu").val();
  $("#monthlyTotal").val(parseInt(a)+parseInt(d));
  var month1=$("#monthlyTotal").val();
  $("#anualTotal").val(parseInt(b)+parseInt(e));
  var anual1=$("#anualTotal").val();
  $("#grantTotal").val(parseInt(month1)+parseInt(anual1));
  f=$("#grantTotal").val();
  });
  $("#emp3mon").change(function()
  {
   g=$("#emp3mon").val();
   $("#emp3anu").val(12*g);
   h=$("#emp3anu").val();
   $("#monthlyTotal").val(parseInt(a)+parseInt(d)+parseInt(g));
   var month2=$("#monthlyTotal").val();
   $("#anualTotal").val(parseInt(b)+parseInt(e)+parseInt(h));
   var anual2=$("#anualTotal").val();
   $("#grantTotal").val(parseInt(month2)+parseInt(anual2));
   i=$("#grantTotal").val();
   });
   $("#emp4mon").change(function()
   {
    j=$("#emp4mon").val();
	$("#emp4anu").val(12*j);
	k=$("#emp4anu").val();
	$("#monthlyTotal").val(parseInt(j)+parseInt(a)+parseInt(d)+parseInt(g));
	var month3=$("#monthlyTotal").val();
	$("#anualTotal").val(parseInt(k)+parseInt(b)+parseInt(e)+parseInt(h));
	var anual3=$("#anualTotal").val();
	$("#grantTotal").val(parseInt(month3)+parseInt(anual3));
	l=$("#grantTotal").val();
   });
});
</script>
</head>
<body>
<table border="1">
<tr>
<td></td>
<td>Monthly Salary</td>
<td>Annual Salary</td>
</tr>
<tr>
<td>Emp 1</td>
<td><input type="text" name="txt" id="emp1mon" /></td>
<td><input type="text" name="txt1" id="emp1anu" /></td>
</tr>
<tr>
<td>Emp 2</td>
<td><input type="text" name="txt2" id="emp2mon" /></td>
<td><input type="text" name="txt3" id="emp2anu" /></td>
</tr>
<tr>
<td>Emp 3</td>
<td><input type="text" name="txt4" id="emp3mon" /></td>
<td><input type="text" name="txt5" id="emp3anu" /></td>
</tr>
<tr>
<td>Emp 4</td>
<td><input type="text" name="txt6" id="emp4mon" /></td>
<td><input type="text" name="txt7" id="emp4anu" /></td>
</tr>
<tr>
<td>Total</td>
<td><input type="text" name="txt6" id="monthlyTotal" /></td>
<td><input type="text" name="txt7" id="anualTotal" /></td>
</tr>
<tr>
<td>Grant Total</td>
<td colspan="2" align="center"><input type="text" name="txt8" id="grantTotal" /></td>
</tr>
</table>
</body>
</html>