<html>
<head>
<script type="text/javascript" src="jquery-2.1.4.min.js"></script>
 
 <script type="text/javascript">
 $(document).ready(function()
 {
  
     $("#txtNm").hide();
   
  $("#sel").change(function()
  {
      var a=$("#sel").val();
      if(a=="Other")
	  {
	  	$("#txtNm").show();
	  }
	  else
	  {
	     $("#txtNm").hide();
	  }
   
    });
 });
 </script>
</head>
<body>
<select name="sel" id="sel">
<option value="">select Naionality</option>
<option value="Indian">Indian</option>
<option value="Other">Other</option>
</select>

<input type="text" name="txtNm" id="txtNm"/>

</body>
</html>