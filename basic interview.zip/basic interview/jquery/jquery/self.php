<html>
<head>
<script type="text/javascript" src="jquery-2.1.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#text").hide();
 $("#sel").change(function()
 {
  var a=$("#sel").val();
  if(a=="Other")
  {
   $("#text").show();
  }
  else
  {
   $("#text").hide();
  }
 }); 
});
</script>
</head>
<body>
<select name="sel" id="sel">
<option value="">Select Nationality</option>
<option value="Indian">Indian</option>
<option value="Other">Other</option>
</select>
<input type="text" name="txtNm" id="text" />
</body>
</html>