<html>
<head>
<script type="text/javascript" src="jquery-2.1.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#tb").hide();
 $("#l").click(function()
 {
  $("#tb").show();
 });
}); 
</script>
</head>
<body>
<h1 id="l">Login</h1>
<table border="1" id="tb">
<tr>
<td>Name</td>
<td><input type="text" name="txtNm" id="txtNm" /></td>
</tr>
<tr>
<td>Password</td>
<td><input type="text" name="txtNm" id="txtNm" /></td>
</tr>
<tr>
<td>Email</td>
<td><input type="text" name="txtNm" id="txtNm" /></td>
</tr>
</table>
</body>
</html>