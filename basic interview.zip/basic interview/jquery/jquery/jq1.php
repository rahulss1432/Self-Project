<html>
<head>
<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#chk").click(function()
 {
  var add= $("#add1").val();
  $("#add2").val(add);
 });
});
</script>
</head>
<body>
Address:<input type="text" name="txtNm" id="add1" />
<input type="checkbox" name="chk" id="chk" />
Per.Address:<input type="text" name="txtNm1" id="add2" />
</body>
</html>
