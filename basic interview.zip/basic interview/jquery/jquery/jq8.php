<html>
<head>
<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#btn").click(function()
 { 
  var a=$("#add1").val();
  var b=$("#add2").val();
  $("#add").val(parseInt(a)+parseInt(b));
  $("#sub").val(parseInt(a)-parseInt(b));
  $("#mul").val(parseInt(a)*parseInt(b));
  $("#div").val(parseInt(a)/parseInt(b));
  $("#mod").val(parseInt(a)%parseInt(b));
 });
});
</script>
</head>
<body>
a:<input type="text" name="txt" id="add1" /><br />
b:<input type="text" name="txt" id="add2" /><br />
<input type="button" name="btn" id="btn" value="Arith" /><br />
Add:<input type="text" name="txt" id="add" /><br />
Sub:<input type="text" name="txt" id="sub" /><br />
Mul:<input type="text" name="txt" id="mul" /><br />
Div:<input type="text" name="txt" id="div" /><br />
Mod:<input type="text" name="txt" id="mod" />
</body>
</html>