<html>
<head>
<script type="text/javascript" src="jquery-2.1.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#tb").hide();
 $("#btn").mousemove(function()
 {
  $("#tb").fadeIn();
 }); 
});  
</script>
</head>
<body>
<input type="text" name="btn" id="btn"/>
<form method="post" name="calc">
<marquee direction="down" behavior="slide"><table border="1" id="tb">
<tr>
<td colspan="4"><input type="text" name="input"/></td>
</tr>
<tr>
<td align="center"><input type="button" name="txt" value="7" onClick="calc.input.value+='7'" /></td>
<td align="center"><input type="button" name="txt1" value="8" onClick="calc.input.value+='8'" /></td>
<td align="center"><input type="button" name="txt2" value="9" onClick="calc.input.value+='9'" /></td>
<td align="center"><input type="button" name="txt3" value="+" onClick="calc.input.value+='+'" /></td>
</tr>
<tr>
<td align="center"><input type="button" name="txt4" value="4" onClick="calc.input.value+='4'" /></td>
<td align="center"><input type="button" name="txt5" value="5" onClick="calc.input.value+='5'" /></td>
<td align="center"><input type="button" name="txt6" value="6" onClick="calc.input.value+='6'" /></td>
<td align="center"><input type="button" name="txt7" value="-" onClick="calc.input.value+='-'" /></td>
</tr>
<tr>
<td align="center"><input type="button" name="txt8" value="3" onClick="calc.input.value+='3'" /></td>
<td align="center"><input type="button" name="txt9" value="2" onClick="calc.input.value+='2'" /></td>
<td align="center"><input type="button" name="txt10" value="1" onClick="calc.input.value+='1'" /></td>
<td align="center"><input type="button" name="txt11" value="*" onClick="calc.input.value+='*'" /></td>
</tr>
<tr>
<td align="center"><input type="button" name="txt12" value="c" onClick="calc.input.value=''" /></td>
<td align="center"><input type="button" name="txt13" value="0" onClick="calc.input.value+='0'" /></td>
<td align="center"><input type="button" name="txt14" value="=" onClick="calc.input.value= eval(calc.input.value)" /></td>
<td align="center"><input type="button" name="txt15" value="/" onClick="calc.input.value+='/'" /></td>
</tr>
</table></marquee>
</form>