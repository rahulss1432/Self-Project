<html>
<head>
<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#r1").click(function()
 {
  var male=$("#r1").val();
  $("#gen").val(male);
 });
 $("#r2").click(function()
 {
  var female=$("#r2").val();
  $("#gen").val(female);
 });
}); 
</script>
</head>
<body>
Male<input type="radio" name="rg" id="r1" value="male" />
Female<input type="radio" name="rg" id="r2" value="female" />
<input type="text" name="gen" id="gen" />
</body>
</html>