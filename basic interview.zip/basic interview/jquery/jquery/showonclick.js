$(document).ready(function(){
			$('#chk').click(function(){
				$('#text').fadeIn();
				
				
			});
	});