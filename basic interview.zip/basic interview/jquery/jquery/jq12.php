<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>basic js </title>
<script type="text/javascript" src="jquery-1.11.3.min.js"></script>
<script>
	$(document).ready(function()
	{	
		var a;
		var b;
		var c;
		var d;
		var e;
		var f;
		var g;
		var h;
		var i;
		var p;
		var q;
		var r;
		var u;
		var v;
		var w;
		$("#emp1mon").change(function()
		{
			a=$("#emp1mon").val();//to get monthly income from using this tage
			$("#emp1anu").val(12*a);// This is for to calculate annuval income
			d=$("#emp1anu").val();// to asign annuva salery in a variable
			
			$("#monthyTotal").val(parseInt(a));//calculate total monthly income of employee
			var j=$("#monthyTotal").val();//Asigning monthly income of employee's in a vari
			
			$("#anualTotal").val(parseInt(d));// show annuval total
			var k=$("#anualTotal").val();//asign in a var
			$("#grantTotal").val(parseInt(j) + parseInt(k));//calculate grant total
			g=$("#grantTotal").val();//asign in a var 
		});
		$("#emp2mon").change(function()
		{
			b=$("#emp2mon").val();
			$("#emp2anu").val(12*b);
			e=$("#emp2anu").val();
			
			$("#monthyTotal").val(parseInt(b) + parseInt(a));
			var l=$("#monthyTotal").val();
			$("#anualTotal").val(parseInt(e) + parseInt(d));
			
			var m=$("#anualTotal").val();
			$("#grantTotal").val(parseInt(l) + parseInt(m));
			
			h=$("#grantTotal").val();
		
		});
		$("#emp3mon").change(function()
		{
			 c=$("#emp3mon").val();
			$("#emp3anu").val(12*c);
			f=$("#emp3anu").val()
			
			$("#monthyTotal").val(parseInt(c) + parseInt(b)+ parseInt(a));
			var n=$("#monthyTotal").val();
			
			$("#anualTotal").val(parseInt(e) + parseInt(d) + parseInt(f));
			var o=$("#anualTotal").val();
			
			$("#grantTotal").val(parseInt(n) + parseInt(o));
			
			i=$("#grantTotal").val();
		});
					
		$("#emp4mon").change(function()
		{
		 p=$("#emp4mon").val();
		 $("#emp4anu").val(12*p);
		 q=$("#emp4anu").val();
		 $("#monthyTotal").val(parseInt(p) + parseInt(c) + parseInt(b) + parseInt(a));
		 var s=$("#monthyTotal").val();
		 $("#anualTotal").val(parseInt(q) + parseInt(e) + parseInt(d) + parseInt(f));
		 var t=$("#anualTotal").val();
		 $("#grantTotal").val(parseInt(s)+parseInt(t));
		 r=$("#grantTotal").val();
		 });
		 
		 $("#emp5mon").change(function()
		 {
		  u=$("#emp5mon").val();
		  $("#emp5anu").val(12*u);
		  v=$("#emp5anu").val();
		  $("#monthyTotal").val(parseInt(u)+parseInt(p)+parseInt(c)+parseInt(b)+parseInt(a));
		  var x=$("#monthyTotal").val();
		  $("#anualTotal").val(parseInt(v) + parseInt(q) + parseInt(e) + parseInt(d) +  parseInt(f));
		  var y=$("#anualTotal").val();
		  $("#grantTotal").val(parseInt(x)+parseInt(y));
		  w=$("#grantTotal").val();
		  });
	});
</script>
</head>
<body>
	<table border="1">
  <tr>
    <td></td>
    <td>Monthly Selery </td>
    <td>Anuval Selery </td>
  </tr>
  <tr>
    <td>Emp 1 </td>
    <td>
        <input type="text" name="textfield" id="emp1mon" class="emp1mon">
    </td>
    <td><input type="text" name="textfield2" id="emp1anu" class="emp1anu"></td>
  </tr>
  <tr>
    <td>Emp 2 </td>
    <td><input type="text" name="textfield3" id="emp2mon" class="emp1mon"></td>
    <td><input type="text" name="textfield4" id="emp2anu"  class="emp1anu"></td>
  </tr>
  <tr>
    <td>Emp 3 </td>
    <td><input type="text" name="textfield5" id="emp3mon" class="emp1mon"></td>
    <td><input type="text" name="textfield6" id="emp3anu" class="emp1anu"></td>
  </tr>
  <tr>
  <td>Emp4</td>
  <td><input type="text" name="textfield7" id="emp4mon" class="emp1mon"></td>
  <td><input type="text" name="textfield8" id="emp4anu" class="emp1anu"></td>
  </tr>
  <tr>
  <td>Emp5</td>
  <td><input type="text" name="txt" id="emp5mon" class="emp1mon"></td>
  <td><input type="text" name="txt1" id="emp5anu" class="emp1anu"></td>
  </tr>
  <tr>
    <td>Total</td>
    <td><input type="text" name="textfield52" id="monthyTotal"></td>
    <td><input type="text" name="textfield53" id="anualTotal"></td>
  </tr>
  <tr>
    <td colspan="3">Grant Total
      <input type="text" name="textfield522" id="grantTotal"></td>
    </tr>
</table>
</body>
</html>