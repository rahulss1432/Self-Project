<html>
<head>
<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#btn").click(function()
 {
  var a=$("#sel").val();
  $("#nm").val(a);
 });
}); 
</script>
</head>
<body>
<select name="sel" id="sel">
<option value="">select Name</option>
<option value="Ram">ram</option>
<option value="rahul">rahul</option>
</select>
<button id="btn">Click Me</button>
<input type="text" name="nm" id="nm" />
</body>
</html>