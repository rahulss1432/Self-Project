<html>
<head>
<script type="text/javascript" src="jquery-2.1.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#txt").mouseover(function()
 {
  alert("hello");
 });
}); 
</script>
</head>
<body>
<input type="text" name="txtNm" id="txt" />
</body>
</html>