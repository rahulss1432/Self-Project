<html>
<head>
<script type="text/javascript" src="jquery-2.1.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#txt1").hide();
 $("#txt").click(function()
 {
  $("#txt1").show();
 });
 $("#txt2").hide();
 $("#txt1").click(function()
 {
  $("#txt2").show();
 });
});
</script>
</head>
<body>
Name:<input type="text" name="txtNm" id="txt" />
<div id="txt1">
Password:<input type="text" name="txtNm1"/>
</div>
<div id="txt2">
Email:<input type="text" name="txtNm2"/>
</div>
</body>
</html>