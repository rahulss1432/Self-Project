<!DOCTYPE html>
<html>
<head>
<script src="jquery-1.9.1.min.js"></script>
<script>
$(document).ready(function(){
    $("button").click(function(){
        $("p").hide(5000);
        alert("The paragraph is now hidden");
    });
});
</script>
</head>
<body>

<button>Hide</button>

<p>This is a paragraph with little content.</p>

</body>
</html>