<html>
<head>
	<script type="text/javascript" src="jquery-1.9.1.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function()
		{
          $("h2").click(function()
          {
          	var a=$("img");
          	a.animate({height:"200",width:"200"});
          	a.animate({height:"300",width:"300"});
          	a.animate({left:"+=500"});
          });
		});
	</script>
</head>
<body>
<h2 style="background:blue;width:200; color:white;">Jai Shree Ganesh</h2>
<img src="$@MEER ^015.jpg" style="position:absolute;">	
</body>
</html>