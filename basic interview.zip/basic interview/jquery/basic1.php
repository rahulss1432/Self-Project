<html>
<head>
<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
<script type="text/javascript">

$(document).ready(function()
{
	   $("#t").hide();
	   $("#btn").click(function()
	   {
		   	//$("#t").show();
			$("#t").toggle();	
	   });
	  
});
</script> 
</head>
<body>
	<p id="t">Welcome Jquery</p>
    <button id="btn">Click me</button>
</body>
</html>