<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script> 
$(document).ready(function(){
    $("#start").click(function(){
        $("div").animate({height: 300}, 1500);
        $("div").animate({width: 300}, 1500);
        $("div").animate({height: 100}, 1500);
        $("div").animate({width: 100}, 1500);
    });
    $("#stop").click(function(){
        $("div").clearQueue();
    });
});
</script> 
</head>
<body>

<button id="start">Start Animation</button>
<button id="stop">Stop Animation</button>
<br><br>

<div style="background:red;height:100px;width:100px;"></div>
 
</body>
</html>