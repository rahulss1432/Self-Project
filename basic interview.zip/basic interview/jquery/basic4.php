<html>
<head>
<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
<script type="text/javascript">

$(document).ready(function()
{
	   $("#btn").click(function()
	   {
		    var city = $("#sel").val();
	   		alert(city);
	   });
	  
});
</script> 
</head>
<body>
	<select name="sel" id="sel">
        <option value="">ANy one---</option>
        <option value="Indore">Indore</option>
        <option value="Ujjain">Ujjain</option>
    </select>	
    <button id="btn">Click me</button>
</body>
</html>