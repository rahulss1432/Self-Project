<?php
mysql_connect("localhost","root","");
mysql_select_db("rahul_db");
if(isset($_POST["btnUpload"]))
{
 $pic=$_FILES["pic"]['name'];
 $temp=$_FILES["pic"]['tmp_name'];
 echo $_FILES["pic"]["type"];
 echo $_FILES["pic"]["size"];
 echo $_FILES["pic"]["error"];
 move_uploaded_file($temp,'image/'.$pic);
 mysql_query("insert into image_tb(imgnm)values('$pic')")or die (mysql_error());
}
?>
<?php
if(isset($_GET["img"]))
{
	$id=$_GET["img"];
	mysql_query("delete from image_tb where id='$id'");
}
?>
<form method="post" enctype="multipart/form-data">
Profile:<input type="file" name="pic"/>
<input type="submit" name="btnUpload"/>
</form>
<?php
$q=mysql_query("select * from image_tb");
while($data=mysql_fetch_array($q))
{
?>
<a href="fileupload.php?img=<?php echo $data["id"];?>"><img src="<?php echo 'image/'. $data["imgnm"];?>" width="100" height="100"/></a>
<?php } ?>