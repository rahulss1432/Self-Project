<?php
if(isset($_COOKIE["admin"]))
{
 echo "welcome".$_COOKIE["admin"];
}
?>