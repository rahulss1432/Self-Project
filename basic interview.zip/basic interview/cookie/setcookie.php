<?php
if(isset($_POST["btnLogin"]))
{
 $nm=$_POST["txtNm"];
 setcookie("admin",$nm,time()+5);
 header("location:getcookie.php");
}
?>
<form method="post">
Name:<input type="text" name="txtNm">
<input type="submit" name="btnLogin" value="Login">
</form>