<?php
 $arr = array(2000,1800,349,1,6,9,5,3,101,99,115,112);
 $l = count($arr);
for($i=1; $i<$l; $i++)
{
  for($j=0; $j<$l-1; $j++)
  {
     if($arr[$j]>$arr[$j+1])
	 {
	   $temp = $arr[$j+1];
	   $arr[$j+1]=$arr[$j];
	   $arr[$j]=$temp;
	 }
  }
}
echo "sorted array is :";
print_r ($arr);
echo "<br>";
?>
<?php
$arr=array(2000,455,4548,1313,1000,155,45,8,78,4545);
$l=count($arr);
for($i=0;$i<$l;$i++)
{
 for($j=0;$j<$l-1;$j++)
 {
  if($arr[$j]>$arr[$j+1])
  {
   $temp=$arr[$j+1];
   $arr[$j+1]=$arr[$j];
   $arr[$j]=$temp;
  }
 }
}
echo "sorting array=";
print_r($arr);
echo "<br>";   
?>
<?php
$arr=array(1500,200,500,50,20,45,565,24,2148,12,1,2,25);
$l=count($arr);
for($i=0;$i<$l;$i++)
{
  for($j=0;$j<$l-1;$j++)
  {
    if($arr[$j]>$arr[$j+1])
    {
      $temp=$arr[$j+1];
      $arr[$j+1]=$arr[$j];
      $arr[$j]=$temp;
    }
  }
}
echo "Sorting of Array=";
print_r($arr);
?>