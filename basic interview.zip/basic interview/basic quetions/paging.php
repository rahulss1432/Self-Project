<!doctype html>
  <html>
    <script>
	    var a = ["page1","page2","page3","page4","page5","page6","page7","page8","page9","page10","page11","page12","page13","page14","page15"];
	  	var i = 0;
		
		function next()
		{
		  document.getElementById("f1").value = a[i++];
		}
		function previous()
		{
		  document.getElementById("f1").value = a[i--];
		}
	</script>
	<body>
	  <button onClick="previous()">Previous</button>
	  <input type="text" name="f1" id="f1"/>
	  <button onClick="next()">Next</button> 
	</body>
  </html>
  <html>
  <head>
  <script>
   var a=["page1","page2","page3","page4","page5","page6","page7","page8","page9","page10"];
   var i=0;
   function next1()
   {
    document.getElementById("f2").value=a[++i];
   }
   function previous1()
   {
    document.getElementById("f2").value=a[--i];
   }		
  </script>
  </head>
  <button onClick="previous1();">Previous</button>
  <input type="text" name="f2" id="f2">
  <button onClick="next1();">Next</button> 
  </html>