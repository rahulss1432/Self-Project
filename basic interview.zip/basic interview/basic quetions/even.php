<?php
  for($i=0; $i<=10; $i++)
  {
    if($i%2==0)
	{
	 echo $i;
	}
  }
  echo "<br>";
?>
<?php
for($i=0;$i<=20;$i++)
{
 if($i%2==0)
 {
  echo $i;
 }
}  
echo "<br>";
?>
<?php
$a=2;
for($i=0;$i<=10;$i++)
{
 echo $a*$i;
 echo "<BR>";
}  
?>