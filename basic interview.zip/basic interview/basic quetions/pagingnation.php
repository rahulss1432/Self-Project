<?php
include("db.php");
$per_pages=1;
$select_table("select * from pagination");
$variable=mysql_query($select_table);
$count=mysql_num_rows($variable);
$pages=ceil($count/$per_pages);
?>
<html>
<head>
<script type="text/javascript" src="jquery-1.9.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
 $("#content").load("function.php?page=1");
 $("#paginate li").click(function()
 {
  $("#paginate li")
  .css({'border':'solid:#000 1px'})
  .css({'color':'#blue'});
  $(this)
  .css({'color':'#red'})
  .css({'border':'none'});
  var pagenum=this.id;
  $("#content").load("function.php?page="+pagenum);
 });
});  
</script>
<style>
#paginate
{
text-align:center;
border:0px green solid;
width:500px;
margin:0 auto;
}
.link{
width:800px; 
margin:0 auto; 
border:0px green solid;
}

li{	
list-style: none; 
float: left;
margin-right: 16px; 
padding:5px; 
border:solid 1px #193d81;
color:#0063DC; 
}
li:hover
{ 
color:#FF0084; 
cursor: pointer; 
}
</style>
</head>
<body>
<div id="content"></div>
<div class="link">
<ul id="paginate">
<?php
for($i=1;$i<=$pages;$i++)
{
 echo '<li id="'.$i.'">'.$i.'</li>';
}
?>
</ul>
</div>
</body>
</html>