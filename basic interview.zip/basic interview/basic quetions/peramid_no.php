<?php
$a=1;
for($i=0;$i<4;$i++)
{
	for($j=0;$j<=$i;$j++)
	{
		echo "$a";
		$a++;
	}
	echo  "<br>";
}
echo "<br>";
?>
<?php
$a=1;
for($i=0;$i<4;$i++)
{
	echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	for($k=4;$k>$i;$k--)
	{
		echo  "&nbsp;";
	}
	for($j=0;$j<=$i;$j++)
	{
		echo "$a";
		$a++;
	}
	echo  "<br>";
}
echo "<br>";
?>
<?php
$a=1;
for($i=0;$i<4;$i++)
{
	echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	for($k=4;$k>$i;$k--)
	{
		echo  "&nbsp;&nbsp;";
	}
	for($j=0;$j<=$i;$j++)
	{
		echo "$a";
		$a++;
	}
	echo  "<br>";
}
echo "<br>";
?>
<?php
$a=10;
for($i=0;$i<4;$i++)
{
	for($j=4;$j>$i;$j--)
	{
		echo "$a";
		$a--;
	}
	echo "<br>";
}
echo "<br>";
?>
<?php
$a=10;
for($i=0;$i<4;$i++)
{
	echo  "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	for($k=0;$k<$i;$k++)
	{
		echo "&nbsp;";
	}
	for($j=4;$j>$i;$j--)
	{
		echo "$a";
		$a--;
	}
	echo "<br>";
}
echo "<br>";
?>
<?php
$a=10;
for($i=0;$i<4;$i++)
{
	echo  "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	for($k=0;$k<$i;$k++)
	{
		echo "&nbsp;&nbsp;";
	}
	for($j=4;$j>$i;$j--)
	{
		echo "$a";
		$a--;
	}
	echo "<br>";
}
echo "<br>";
?>
<?php 
$a=1;
for($i=0;$i<=4;$i++)
{
	echo "$a<br>";
	$a++;
}
for($j=0;$j<$i;$j++)
{
	echo "$a&nbsp;&nbsp;&nbsp;";
	$a++;
}
echo "<br>";
?>
<?php 
$a=11;
for($i=0;$i<=4;$i++)
{
	echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$a<br>";
	$a++;
}
for($j=0;$j<$i;$j++)
{
	echo "$a&nbsp;";
	$a++;
}
echo "<br>";
?>