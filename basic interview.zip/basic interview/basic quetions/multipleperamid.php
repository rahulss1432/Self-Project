<?php
for($i=0;$i<=10;$i++)
{
 for($j=0;$j<=$i;$j++)
 {
  if($i%2==1)
  {
   echo "*";
  }
 }
 echo "<br>";
}
?>
<?php
for($i=0;$i<=10;$i++)
{ 
 for($j=10;$j>=$i;$j--)
 {
  for($k=0;$k<=$i;$k++)
  {
  if($i%2==1)
  {
   echo "*";
  }
 }
 }
 echo "<br>";
}
?>
<?php
for($i=0;$i<=10;$i++)
{ 
 for($j=10;$j>=$i;$j--)
 {
  for($k=10;$k>=$i;$k--)
  {
  if($i%2==1)
  {
   echo "*";
  }
 }
 }
 echo "<br>";
}
?>
<?php
for($i=0;$i<=10;$i++)
{ 
 for($j=0;$j<=$i;$j++)
 {
  for($k=0;$k<=$i;$k++)
  {
  if($i%2==1)
  {
   echo "*";
  }
 }
 }
 echo "<br>";
}
?>
<?php
for($i=0;$i<=10;$i++)
{ 
 for($j=10;$j>=$i;$j--)
 {
  for($k=10;$k>=$i;$k--)
  {
  if($i%2==0)
  {
   echo "*";
  }
 }
 }
 echo "<br>";
}
?>
<?php
for($i=0;$i<=10;$i++)
{ 
 for($j=0;$j<=10;$j++)
 {
  for($k=0;$k<=$j;$k++)
  {
  if($i%2==1)
  {
   echo "*";
  }
 }
 }
 echo "<br>";
}
?>
<?php
for($i=0;$i<=10;$i++)
{ 
 for($j=10;$j>=$i;$j--)
 {
  for($k=0;$k<=$j;$k++)
  {
   for($l=10;$l>=$k;$l--)
   {
  if($i%2==1)
  {
   echo "*";
  }
 }
  echo "<br>";
}
}
}
?>
<?php
for($i=0;$i<=10;$i++)
{ 
 for($j=10;$j>=$i;$j--)
 {
  for($k=10;$k>=$j;$k--)
  {
   for($l=10;$l>=$k;$l--)
   {
  if($i%2==1)
  {
   echo "*";
  }
 }
  echo "<br>";
}
}
}
?>
<?php
for($i=0;$i<=10;$i++)
{ 
 for($j=0;$j<=$i;$j++)
 {
  for($k=0;$k<=$j;$k++)
  {
   for($l=10;$l>=$k;$l--)
   {
    for($o=0;$o<=$i;$o++)
	{
  if($i%2==1)
  {
   echo "*";
  }
 }
 }
  echo "<br>";
}
}
}
?>
<?php
for($i=0;$i<=10;$i++)
{ 
 for($j=10;$j>=$i;$j--)
 {
  for($k=10;$k>=$i;$k--)
  {
   for($l=10;$l>=$i;$l--)
   {
    for($o=10;$o>=$j;$o--)
	{
  if($i%2==1)
  {
   echo $j;
  }
 }
 }
  echo "<br>";
}
}
}
?>