<?php
  for($i=0; $i<=10; $i++)
  {
    for($j=0; $j<=$i; $j++)
	{
      if($i%2==1)
	  {
	   echo "*";
	  }
  }
	echo "<br>";
}
?>
<?php
for($i=0;$i<=10;$i++)
{
 for($j=10;$j>=$i;$j--)
 {
  if($i%2==1)
  {
   echo "*";
  }
 }
 echo "<br>";
}   
?>