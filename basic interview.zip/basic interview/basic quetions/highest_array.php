<?php
  $arr= array(50,100,5,99,195,189);
  $b=0;
  foreach($arr as $val)
  {
    if($val>$b)
	{
	  $b = $val;
	}  
  }
  echo $b;
  echo "<br>";
?>
<?php
$arr=array(52,56,45,78,68,190,100,23,180);
$b=0;
foreach($arr as $val)
{
 if($val>$b)
 {
  $b=$val;
 }
}
echo $b;  
?>