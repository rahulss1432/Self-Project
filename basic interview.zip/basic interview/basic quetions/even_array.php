<?php
 $str = "i am nitin lives in indore";
 $ex = explode(" ",$str);
 $l = count($ex);
 for($i=0; $i<$l; $i++)
{
  if($i%2==0)
  {
    echo $ex[$i];
	 echo " ";
   }
   else
   {
    // echo $ex[$i];
	 //echo " ";
   }
}
?>
<?php
$str="i am rahul solanki from maheshwer";
$ex=explode(" ",$str);
$l=count($ex);
for($i=0;$i<$l;$i++)
{
 if($i%2==0)
 {
  echo $ex[$i];
  echo " ";
 }
}   
?>
<?php
$arr=array(10,20,30,40,50,60,70,80);
$l=count($arr);
for($i=0;$i<$l;$i++)
{
  if($i%2==0)
  {
    echo $i;
  }
}
?>