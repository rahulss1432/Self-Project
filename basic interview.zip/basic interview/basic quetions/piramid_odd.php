<?php
  for($i=0; $i<=10; $i++)
  {
    for($j=0; $j<=$i; $j++)
	{
      if($i%2==0)
	  {
	   echo "*";
	  }
  }
    echo "<br>";
 }
?>
<?php
for($i=10;$i>=0;$i--)
{
 for($j=0;$j<=$i;$j++)
 { 
  if($i%2==0)
  {
   echo "*";
  }
  }
  echo "<br>";
 }  
?>

<?php 
$n=5;
$i=0;
for($i=0;$i<=$n;$i++)
{
  echo "<pre>";
  echo str_repeat("&nbsp;",$n-$i);
  echo str_repeat("*&nbsp;",$i);
}
?>

<?php 
$n=5;
$i=0;
for($i=0;$i<=$n;$i++)
{
  echo "<pre>";
  echo str_repeat("*&nbsp;",$i);
  echo str_repeat("&nbsp;",$n-$i);
}
?>

<?php 
$n=5;
$i=0;
for($i=0;$i<=$n;$i++)
{
  echo "<pre>";
  echo str_repeat("*&nbsp;",$n-$i);
  echo str_repeat("&nbsp;",$i);
}
?>

<?php 
$n=5;
$i=0;
for($i=0;$i<=$n;$i++)
{
  echo "<pre>";
  echo str_repeat("&nbsp;",$i);
  echo str_repeat("*&nbsp;",$n-$i);
}
?>

<?php 
$n=5;
$i=0;
for($i=0;$i<=$n;$i++)
{
  echo "<pre>";
  echo str_repeat("*&nbsp;",$n);
  echo str_repeat("&nbsp;",$n-$i);
}
echo "<br>";
?>

<?php 
$n=5;
$i=0;
for($i=0;$i<=$n;$i++)
{
  echo "<pre>";
  echo str_repeat("*&nbsp;",++$i);
  echo str_repeat("&nbsp;",$n-$i);
}
?>