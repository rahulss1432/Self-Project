<?php
//array_pop
$arr=array(10,20,30,40,50);
$l=count($arr);
unset ($arr[$l-2]);
print_r($arr);
?>
<?php
//array_push
$arr=array(10,20,30,40);
$l=count($arr);
$arr[$l]=50;
$arr[$l+1]=60;
print_r($arr);
?>