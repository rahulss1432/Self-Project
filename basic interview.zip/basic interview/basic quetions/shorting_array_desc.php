<?php
 $arr = array(2000,1800,349,1,6,9,5,3,101,99,115,112);
 $l = count($arr);
for($i=0; $i<$l; $i++)
{
  for($j=0; $j<$l-1; $j++)
  {
     if($arr[$j]<$arr[$j+1])
	 {
	   $temp = $arr[$j+1];
	   $arr[$j+1]=$arr[$j];
	   $arr[$j]=$temp;
	 }
  }
}
echo "sorted array is :";
print_r ($arr);
echo "<br>";
?>
<?php
$arr=array(45,87,121,454,6464,1154,2,8,848,31,449,1,1313);
$l=count($arr);
for($i=0;$i<$l-1;$i++)
{
 for($j=0;$j<$l-1;$j++)
 {
  if($arr[$j]<$arr[$j+1])
  {
   $temp=$arr[$j+1];
   $arr[$j+1]=$arr[$j];
   $arr[$j]=$temp;
  }
 }
}
echo "sorting array=";
print_r($arr);   
echo "<br>";
?>
<?php
$arr=array(54,64,468,21,48,12,46,12,45,21,46,798,31,4);
$l=count($arr);
for($i=0;$i<$l;$i++)
{
  for($j=0;$j<$l-1;$j++)
  {
    if($arr[$j]<$arr[$j+1])
    {
      $temp=$arr[$j+1];
      $arr[$j+1]=$arr[$j];
      $arr[$j]=$temp;
    }
  }
}
echo "Rsorting is Array=";
print_r($arr);
?>