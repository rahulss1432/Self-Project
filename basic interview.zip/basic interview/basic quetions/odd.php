<?php
  for($i=0; $i<=20; $i++)
  {
    if($i%2==1)
	{
	 echo $i;
	}
  }
  echo "<BR>";
?>
<?php
for($i=0;$i<=10;$i++)
{
 if($i%2==1)
 {
  echo $i;
 }
}  
?>
<?php
for($i=0;$i<=10;$i++)
{
 if($i%2==1)
 {
 	echo $i;
 }
 echo "<br>";
}
?>