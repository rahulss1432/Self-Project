<?php
 $str = "i am nitin lives in indore";
 $ex = explode(" ",$str);
 $l = count($ex);
for($i=0; $i<$l; $i++)
{
  if($i%2==1)
  {
   echo $ex[$i];
	 echo " ";
  }
  else
  {
   // echo $ex[$i];
//	echo " ";
  }
}
?>
<?php
$str="i am rahul solanki from maheshwer";
$ex=explode(" ",$str);
$l=count($ex);
for($i=0;$i<$l;$i++)
{
 if($i%2==1)
 {
  echo $ex[$i];
  echo " ";
 }
} 
?>
<?php
$str="hello rahul solanki hello";
$ex=explode(" ",$str);
$l=count($ex);
for($i=0;$i<$l;$i++)
{
  if($i%2==1)
  {
    echo $ex[$i];
    echo " ";
  }
}
?>