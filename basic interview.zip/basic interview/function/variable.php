
<?php
	
	$a = 40;
	$a = 10;
	echo $a;
	
?>