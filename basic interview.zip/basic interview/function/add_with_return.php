<?php
    function add($a,$b)
    {
     $c=$a+$b;
     return($c);
    }
    $d=add(10,20);
    function div($a,$b)
    {
     echo $d=$a/$b;
     echo"</br>";
    }
     $e=div(100,4); 
     echo($d);
	function mul($a,$b)
	{
	 echo $e=$a*$b;
	 echo "</br>";
	}
	 mul(15,2);
	 echo ($e);	  
?>