<?php
	
	function add($a,$b)
	{
		echo $a+$b;
	}
	add(10,20);	
?>