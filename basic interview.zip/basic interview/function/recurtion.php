<?php
	

	function amit()
	{
		echo "Name = Amit";
		amit();
	}
	amit();	
	

?>