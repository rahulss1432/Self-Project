<?php
    function fact($a)
  {  
    $b=1;
    for($i=$a; $i>=1; $i--)
    $b=$b*$i;
    echo $b;
    echo"</br>";
  }
  fact(7);
?>
<?php
function fac($c)
{
 $d=1;
 for($i=$c;$i>=1;$i--)
  $d=$d*$i;
  $c=$d;
  echo $c;
  echo"<br>";
 }
 fac(5); 
?>
<?php
$a=1;
for($i=7;$i>=1;$i--)
{
  $a=($i*$a);
}
echo $a;
echo "<br>";
?>
<?php
$a=1;
for($i=10;$i>=1;$i--)
{
  $a=($a*$i);
}
echo $a;
echo "<br>";
?>
<?php
function fact1($a)
{
  $b=1;
  for($i=1;$i<=$a;$i++)
  {
    $b=$b*$i;
  }
  echo  $b;
}
fact1(8)
?>