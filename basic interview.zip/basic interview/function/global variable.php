<?php
$a=10;
function show()
{
global $a;
echo($a);
}
show($a);
?>