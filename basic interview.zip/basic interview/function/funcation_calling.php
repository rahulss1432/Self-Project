<?php
	

	amit();	
	sumit();
	function sumit()
	{
		echo "Name = Sumit";
	}
	function amit()
	{
		echo "Name = Amit";
	}
	
?>