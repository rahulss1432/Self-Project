<?php
     function a()
     {
      b();
      echo "a";
      echo"</br>";
     }

    function b()
   {
     c();
     echo "b";
     echo"</br>";
    }


     function c()
     {
      echo "c";
       echo"</br>";
     }
    a();
    
?>