<?php
	
	$a = 10;
	$b = 20;
	echo " Addition of two no is"." = ".($a + $b);
	

?>