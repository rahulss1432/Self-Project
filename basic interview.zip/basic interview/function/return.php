<?php
function demo()
   {
     $a=10;
      return($a);
   }
$b=demo();
echo $b;
?>