<?php
     function p()
      {
	echo"pratik";
        echo"</br>";
      }
      function v()
	{
	echo "vishal";
         echo"</br>";
	}
     
      function s()
     {
      echo "sumit";
      echo"</br>";
     }

   function n()
   {
     echo "nitin";
echo"</br>";
    }
n();
v();
p();
s();
?>