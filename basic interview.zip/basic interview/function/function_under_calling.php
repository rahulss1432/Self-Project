<?php
	function sumit()
	{
		amit();
		echo "Name = Sumit";
	
	}
	function amit()
	{
		echo "Name = Amit";
	}
	sumit();	
?>