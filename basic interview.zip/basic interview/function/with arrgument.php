<?php
function add($a,$b)
{
echo($a+$b);
echo"</br>";
}
add(25,5);


     function sub($a, $b)
    {
     echo($a-$b);
     echo"</br>";
     }
     sub(25,5);


	function multi($a, $b)
	{
	echo($a*$b);
	echo"</br>";
	}
	 multi(25,4);


     function div($a, $b)
      {
        echo($a/$b);
        echo"</br>";
      }
       div(100,4);
?>