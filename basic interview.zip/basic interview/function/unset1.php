
<?php
	
	$a = 10;
	unset($a);
	echo $a;
	
?>