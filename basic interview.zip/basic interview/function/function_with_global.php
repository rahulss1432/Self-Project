<?php
       $b=20;
   	  function abc()
        {
           global $b;
           $a=10;
           echo $a;
           echo $b; 
        }
       abc();
?>