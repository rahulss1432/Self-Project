<?php
     $a=10;
     $b=20;
         function geta()
         {
          global $a,$b;
          $c=$a+$b;
          echo $c;

         $a=30;
         $b=40;
         $c=$a+$b;
         echo $c;
         
         $a=20;
         $b=40;
         $c=$a+$b;
         echo $c;
        }
        geta();


?>