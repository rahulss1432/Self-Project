<html>
<head>
<script type="text/javascript">
var a=10,b=20;
alert(a+b);
</script>
</head>
</html>