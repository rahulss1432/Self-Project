<html>
<head>
<script type="text/javascript">
var a="admin";
if(a=="admin")
{
	alert("valid");
}
else
{
	alert("invalid");
}

</script>
</head>
</html>