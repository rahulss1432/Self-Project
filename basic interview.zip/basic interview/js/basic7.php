<html>
<head>
<script type="text/javascript">
function add()
{
	var nm=document.getElementById("txtnm").value;
	alert(nm)
}

</script>
</head>
<body>
<input type="text" name="txtnm" id="txtnm" />
<button onClick="add()">click me</button>
</body>
</html>