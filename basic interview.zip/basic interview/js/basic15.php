<html>
<head>
<script type="text/javascript">
function show()
{
	var val1=document.getElementById("selCity").value;
	alert(val1);
}	
</script>
</head>
<body>
<select id="selCity">
	<option value="">select city</option>
	<option value="indore">indore</option>
	<option value="ujjain">ujjain</option>
</select>
<input type="button" name="btnGo" value="Clicke me.."  onclick="show();"/>
</body>
</html>