<html>
<head>
<script type="text/javascript">
document.write("hello");
</script>
</head>
</html>