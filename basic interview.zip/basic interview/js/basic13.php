<html>
<head>
<script type="text/javascript">
function show()
{
	var val1=document.getElementById("txtNm").value;
	document.getElementById("nm").value=val1;
}	
</script>

</head>
<body>
<input type="text" name="txtNm" id="txtNm"/>
<input type="button" name="btnGo" value="Clicke me.."  onclick="show();"/>
<input type="text" name="nm" id="nm" />
</body>
</html>