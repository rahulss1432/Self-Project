<html>
<head>
<script type="text/javascript">
function add()
{
	alert('ADD called');
}
add();
</script>
</head>
</html>