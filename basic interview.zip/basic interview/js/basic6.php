<html>
<head>
<script type="text/javascript">
function add()
{
	alert('ADD called');
}

</script>
</head>
<body>
<button onclick="add()">click me</button>
</body>
</html>