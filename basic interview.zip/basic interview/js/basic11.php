<html>
<head>
<script type="text/javascript">
function show()
{  
	alert("hello");
}	
</script>
</head>
<body>
<input type="text" name="txtNm" id="txtNm" onMouseOver="show();"/>
</body>
</html>