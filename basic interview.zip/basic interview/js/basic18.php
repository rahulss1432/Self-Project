<html>
<head>
<script type="text/javascript">
function total()
{
var a=parseInt(document.getElementById("txtNm").value);
var b=parseInt(document.getElementById("txtNm1").value);
      document.getElementById("txtNm2").value=a+b;
	  document.getElementById("txtNm3").value=a-b;
	  document.getElementById("txtNm4").value=a*b;
	  document.getElementById("txtNm5").value=a/b;
}
</script>
</head>
<body>
no1<input type="text" name="txtNm" id="txtNm" /><br>
no2<input type="text" name="txtNm1" id="txtNm1" /><br>
<input type="button" name="btnAri" value="Arith" onClick="total();" /><br>
add<input type="text" name="txtNm2" id="txtNm2" /><br>
sub<input type="text" name="txtNm3" id="txtNm3" /><br>
mul<input type="text" name="txtNm4" id="txtNm4" /><br>
div<input type="text" name="txtNm5" id="txtNm5" />
</body>
</html>