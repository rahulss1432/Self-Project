<html>
<head>
<script type="text/javascript">
function show()
{
	var val1=document.getElementById("txtNm").value;
	alert(val1);
}	
</script>

</head>
<body>
<input type="text" name="txtNm" id="txtNm"/>
<input type="button" name="btnGo" value="Clicke me.."  onclick="show();"/>
</body>
</html>