<html>
<head>
<script type="text/javascript">
alert("hello");
</script>
</head>
</html>