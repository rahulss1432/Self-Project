<html>
<head>
<script type="text/javascript">
var a=10;
alert("a is ="+a);
</script>
</head>
</html>