<html>
<head>
<script type="text/javascript">
function add()
{
var a=parseInt(document.getElementById("txtNm").value);
var b=parseInt(document.getElementById("txtNm1").value);
      document.getElementById("txtNm2").value=a+b;
}
</script>
</head>
<body>
no1<input type="text" name="txtNm" id="txtNm" /><br>
no2<input type="text" name="txtNm1" id="txtNm1" /><br>
<input type="button" name="btnAdd" value="Add" onClick="add();" />
total<input type="text" name="txtNm2" id="txtNm2" />
</body>
</html>