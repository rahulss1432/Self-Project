<html>
<head>
<script type="text/javascript">
function show()
{
	alert("helllo");
}	
</script>
</head>
<body>
<img src="../../html/Sunset.jpg" onMouseOver="show();"/>
</body>
</html>