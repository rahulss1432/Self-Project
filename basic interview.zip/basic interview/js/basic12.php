<html>
<head>
<script type="text/javascript">
function show()
{
	var val1=document.getElementById("r1").value;
	alert(val1);
}	
</script>


</head>

<body>
<input type="radio" name="rdbGen" value="male" id="r1" onClick="show()" />male
</body>
</html>