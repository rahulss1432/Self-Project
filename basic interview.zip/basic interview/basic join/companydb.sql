-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 17, 2016 at 06:45 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `companydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `emptb`
--

CREATE TABLE IF NOT EXISTS `emptb` (
  `eid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `emptb`
--

INSERT INTO `emptb` (`eid`, `name`) VALUES
(1, 'amit'),
(2, 'rajesh'),
(3, 'sumit'),
(4, 'nilesh'),
(5, 'rahul');

-- --------------------------------------------------------

--
-- Table structure for table `saltb`
--

CREATE TABLE IF NOT EXISTS `saltb` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `salary` varchar(50) NOT NULL,
  `eid` varchar(50) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `saltb`
--

INSERT INTO `saltb` (`sid`, `salary`, `eid`) VALUES
(1, '10000', '1'),
(2, '11000', '2'),
(3, '12000', '3'),
(4, '15000', '5'),
(5, '45000', '4');
