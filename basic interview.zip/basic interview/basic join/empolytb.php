<!doctype html>
  <html>
   <head>
   
   </head>
   <body>
     <form method="post" action="employe_insert.php">
        <table border="2">
		   
			<tr>
			    <td>name</td>
				<td><input type="text" name="nm"/></td>
			</tr>
			<tr>
			    <td><input type="submit" name="sub" value="Submit"/></td>
			</tr>
		</table>
	 </form>
   </body>
  </html>
  