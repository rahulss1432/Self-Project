<!doctype html>
  <html>
   <head>
   
   </head>
   <body>
     <form method="post" action="salary_insert.php">
        <table border="2">
		  
			<tr>
			    <td>salary</td>
				<td><input type="text" name="sal"/></td>
			</tr>
			<tr>
			    <td>eid</td>
				<td><input type="text" name="ei"/></td>
			</tr>
			<tr>
			    <td><input type="submit" name="sb" value="Submit"/></td>
			</tr>
		</table>
	 </form>
   </body>
  </html>
  