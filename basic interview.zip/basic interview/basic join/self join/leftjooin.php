<?php
mysql_connect("localhost","root","");
mysql_select_db("joining_tb");
$q=mysql_query("select emp_tb.eid,emp_tb.ename,empsal_tb.emp_salary from emp_tb left join empsal_tb ON emp_tb.eid=empsal_tb.eid")or die (mysql_error());
?>
<form method="post">
<table border="1" align="center">
<tr>
<td>ID</td>
<td>Emp_Name</td>
<td>Emp_Salary</td>
</tr>
<?php 
while($data=mysql_fetch_array($q))
{
?>
<tr>
<td><?php echo $data["eid"];?></td>
<td><?php echo $data["ename"];?></td>
<td><?php echo $data["emp_salary"];?></td>
</tr>
<?php } ?>
</table>
</form>