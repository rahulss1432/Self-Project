
<?php
mysql_connect("localhost","root","");
mysql_select_db("joining_tb");
$q=mysql_query("select emp_tb.eid,emp_tb.ename,empsal_tb.emp_salary,emp_address.address from emp_tb inner join empsal_tb inner join emp_address ON emp_tb.eid=empsal_tb.eid && empsal_tb.sid=emp_address.sid")or die (mysql_error());
?>
<form method="post">
<table border="1" align="center">
<tr>
<td>ID</td>
<td>Emp_Name</td>
<td>Emp_Salary</td>
<td>address</td>
</tr>
<?php 
while($data=mysql_fetch_array($q))
{
?>
<tr>
<td><?php echo $data["eid"];?></td>
<td><?php echo $data["ename"];?></td>
<td><?php echo $data["emp_salary"];?></td>
<td><?php echo $data["address"];?></td>
</tr>
<?php } ?>
</table>
</form>