<?php
mysql_connect("localhost","root","");
mysql_select_db("joining_tb");
if(isset($_POST["btnGo"]))
{
 $enm=$_POST["txtNm"];
 mysql_query("insert into emp_tb(ename)values('$enm')")or die (mysql_error());
}
?> 
<html>
<head>
<title>
</title>
</head>
<body>
<form method="post">
<table border="1" align="center">
<tr>
<td>Emp_Name</td>
<td><input type="text" name="txtNm" id="txtNm" /></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="btnGo" value="Submit" /></td>
</tr>
</table>
</form>
</body>
</html>