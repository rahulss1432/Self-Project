<?php
mysql_connect("localhost","root","");
mysql_select_db("joining_tb");
if(isset($_POST["btnSubmit"]))
{
 $esal=$_POST["txtSal"];
 $eid=$_POST["txtEid"];
 mysql_query("insert into empsal_tb(emp_salary,eid)values('$esal','$eid')")or die (mysql_error());
}
?>
<html>
<head>
<title>
</title>
</head>
<body>
<form method="post">
<table border="1" align="center">
<tr>
<td>Emp_Salary</td>
<td><input type="text" name="txtSal" id="txtSal" /></td>
</tr>
<tr>
<td>Emp_Id</td>
<td><input type="text" name="txtEid" id="txtEid" /></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="btnSubmit" value="Submit" /></td>
</tr>
</table>
</form>
</body>
</html> 