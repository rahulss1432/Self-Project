<?php
   mysql_connect("localhost","root","");
   mysql_select_db("companydb");
   if($_POST["sb"])
   {
    
     $sal=$_POST["sal"];
	 $eid=$_POST["ei"];
	 
	 
	  echo mysql_query("insert into saltb(salary,eid)values('$sal','$eid')");
   }
?>