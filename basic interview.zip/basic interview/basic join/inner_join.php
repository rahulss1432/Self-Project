<form method="post" action="">
	<table border="2">
	  <tr>
	     <td>eid</td>
		 <td>name</td>
		 <td>salary</td>
	  </tr>
<?php
   mysql_connect("localhost","root","");
   mysql_select_db("companydb");
   $q = mysql_query("select emptb.eid, emptb.name, saltb.salary from emptb inner join saltb  ON emptb.eid=saltb.eid ") or die (mysql_error());
	while($data = mysql_fetch_array($q))
	{
	 ?>
	<tr>
	     <td><?php echo $data["eid"]; ?></td>
		 <td><?php echo $data["name"]; ?></td>
		 <td><?php echo $data["salary"]; ?></td>
	</tr>
	<?php } ?>
	</table>
	</form>