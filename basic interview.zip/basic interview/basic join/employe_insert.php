<?php
   mysql_connect("localhost","root","");
   mysql_select_db("companydb");
   if($_POST["sub"])
   {
     $nm=$_POST["nm"];	 
	 
	  echo mysql_query("insert into emptb(name)values('$nm')");
   }
?>