<?php
session_start();
if(isset($_SESSION["snm"])?$_SESSION["snm"]:$_SESSION["pnm"])
{
	echo "welcome",$_SESSION["snm"];
	echo "",$_SESSION["pnm"];
	echo "",$_SESSION["em"];
}
if(!isset($_SESSION["snm"]))
{
	header("location:login.php");
}
?>
<a href="logout.php">Logout</a>