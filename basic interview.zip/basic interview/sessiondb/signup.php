<?php
mysql_connect("localhost","root","");
mysql_select_db("prectise_db");
if(isset($_POST["btnGo"]))
{
	$nm=$_POST["nm"];
	$eid=$_POST["eid"];
	$pass=$_POST["pass"];
	$cpass=$_POST["cpass"];
	mysql_query("insert into prectise_tb(name,email,password,conf_password)values('$nm','$eid','$pass','$cpass')")or die (mysql_error());
}
?>
<form method="post">
Name:<input type="text" name="nm"/></br>
Email:<input type="text" name="eid"/></br>
Password:<input type="password" name="pass"/></br>
Conf_Pass:<input type="text" name="cpass"/></br>
<input type="submit" name="btnGo" value="Sign" />
</form>

<form method="post">
	<table border="1">
		<tr>
		<td>Id</td>
		<td>Name</td>
		<td>Email</td>
		<td>Password</td>
		<td>Conf_Password</td>
		</tr>
		<?php
		if(isset($_POST["btnDel"]))
		{
			$id=$_POST["chk"];
			foreach($id as $v)
			mysql_query("delete from prectise_tb where id='$v'")or die (mysql_error());
		}
		if(isset($_POST["btnUpdate"]))
		{
			$id=$_POST["chk"];
			foreach ($id as $v)
			{
			$nm=$_POST["nm".$v];
			$eid=$_POST["eid".$v];
			$pass=$_POST["pass".$v];
			$cpass=$_POST["cpass".$v];
			mysql_query("update prectise_tb set name='$nm',email='$eid',password='$pass',conf_password='$cpass' where id='$v'")or die (mysql_error());
		    }
		}
        $q=mysql_query("select * from prectise_tb order by id desc");
        while($data=mysql_fetch_array($q))
        {
		?>
		<tr>
		<td><?php echo $data["id"];?></td>
		<td><input type="text" name="nm<?php echo $data["id"];?>" value="<?php echo $data["name"];?>"/></td>
		<td><input type="text" name="eid<?php echo $data["id"];?>" value="<?php echo $data["email"];?>"/></td>
		<td><input type="text" name="pass<?php echo $data["id"];?>" value="<?php echo $data["password"];?>"/></td>
		<td><input type="text" name="cpass<?php echo $data["id"];?>" value="<?php echo $data["conf_password"];?>"/></td>
		<td><input type="checkbox" name="chk[]" value="<?php echo $data["id"];?>"/></td>
		</tr>
		<?php } ?>
		<tr>
		 <td colspan="5" align="center"><input type="submit" name="btnDel" value="Delete"/>
		 <input type="submit" name="btnUpdate" value="Update"/>
		 </td>
		</tr>
	</table>
</form>
<a href="login.php">Login</a>