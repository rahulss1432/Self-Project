<?php
   mysql_connect("localhost","root","");
   mysql_select_db("entrydb");
   $q=mysql_query("select min(salary) from salartytable where salary >(select  min(salary) from salartytable)");
   $data=mysql_fetch_array($q);
  	 print_r($data);
	 ?>
	 <?php
	 mysql_connect("localhost","root","");
	 mysql_select_db("entrytb");
	 $q=mysql_query("select min(salary) from salartytable where salary>(select min(salary) from salartytable)");
	 $data=mysql_fetch_array($q);
	 print_r($data);
	 ?>