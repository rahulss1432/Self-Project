<?php
   mysql_connect("localhost","root","");
   mysql_select_db("entrydb");
   $q=mysql_query("select max(salary) from salartytable");
   $data=mysql_fetch_array($q);
   print_r ($data);
   echo "<br>";
   ?>
   <?php
   mysql_connect("localhost","root","");
   mysql_select_db("entrydb");
   $a=mysql_query("select min(salary) from salartytable");
   $data=mysql_fetch_array($a);
   print_r($data);
   echo "<br>";
   ?>
   <?php
   mysql_connect("localhost","root","");
   mysql_select_db("entrydb");
   $q=mysql_query("select avg(salary) from salartytable");
   while($data=mysql_fetch_array($q))
   {
      print_r($data)."<br>";
   }
   echo "<br>";
   ?>
   <?php
   mysql_connect("localhost","root","");
   mysql_select_db("entrydb");
   $q=mysql_query("select now() from salartytable");
   $data=mysql_fetch_array($q);
      print_r($data)."<br>";
   echo "<br>";
   ?>