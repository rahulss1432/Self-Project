<?php
   mysql_connect("localhost","root","");
   mysql_select_db("entrydb");
   if($_POST["sb"])
   {
    $nm=$_POST["nm"];
	$sal=$_POST["sal"];
	 echo mysql_query("insert into salartytable( name,salary) values('$nm','$sal')") or die (mysql_error());
   }
?>