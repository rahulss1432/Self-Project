<table border="2">
<tr>
	<td>name</td>
	<td>salary</td>
</tr>
<?php
   mysql_connect("localhost","root","");
   mysql_select_db("entrydb");
   $q=mysql_query("select * from salartytable where salary between 40000 and 45000");
  
   while($data=mysql_fetch_array($q))
    {?>
	<tr>
	     <td><?php echo $data["name"]; ?></td>
		 <td><?php echo $data["salary"]; ?></td>
	</tr>
	<?php } ?>
	</table>