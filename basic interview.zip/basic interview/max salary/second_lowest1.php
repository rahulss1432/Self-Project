<?php
mysql_connect("localhost","root","");
mysql_select_db("entrydb");
$q=mysql_query("select salary from salartytable order by salary asc")or die (mysql_error());
while($data=mysql_fetch_array($q))
{
 echo $data["salary"]."<br>";
}
echo "<br>";
?> 
<?php
mysql_connect("localhost","root","");
mysql_select_db("entrydb");
$q=mysql_query("select salary from salartytable order by salary asc limit 1,1")or die (mysql_error());
while($data=mysql_fetch_array($q))
{
 echo $data["salary"];
}
?> 
<?php 
mysql_connect("localhost","root","");
mysql_select_db("entrytb");
$q=mysql_query("select * from salartytable order by salary asc limit 1,1");
while($data=mysql_fetch_array($q))
{
echo $data["salary"];
}
?>