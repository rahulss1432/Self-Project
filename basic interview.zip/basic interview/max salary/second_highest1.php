<?php
mysql_connect("localhost","root","");
mysql_select_db("entrydb");
$q=mysql_query("select max(salary) from salartytable where salary<(select max(salary) from salartytable)")or die (mysql_error());
$data=mysql_fetch_array($q);
print_r ($data);
 ?>
<?php
 mysql_connect("localhost","root","");
 mysql_select_db("entrytb");
 $a=mysql_query("select max(salary) from salartytable where salary<(select max(salary) from salartytable)");
 $data=mysql_fetch_array($a);
 print_r($data);
 ?>