<?php
$con=mysqli_connect("localhost","root","","rahul_db");
$q=mysqli_query($con,"select DISTINCT name,password from rahul_tb");
?>
	<table border="1">
	<tr>
	 <td>Name</td>
	 <td>Password</td>
	</tr>
<?php
	while($data=mysqli_fetch_array($q))
{
?>
	<tr>
	<td><?php echo $data["name"];?></td>
	<td><?php echo $data["password"];?></td>
	</tr>
	<?php 
}
?>