<?php
$a=10;
$b=20;
$c=30;
echo("before swiping A=$a, B=$b, C=$c</br>");
$a=($a+$b+$c);//60=(10+20+30)//
$b=$a-($b+$c);//10=60-(20+30)//
$c=$a-($b+$c);//20=60-(10+30)//
$a=$a-($b+$c);//30=60-(10+20)//
echo("after swiping A=$a, B=$b, C=$c");
?>