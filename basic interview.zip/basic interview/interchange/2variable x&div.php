<?php
$a=10;
$b=20;
echo("before swiping A=$a, B=$b</br>");
$a=($a*$b);//200=(10*20)//
$b=($a/$b);//10=(200/20)//
$a=($a/$b);//20=(200/10)//
echo("after swiping A=$a, B=$b");
?>