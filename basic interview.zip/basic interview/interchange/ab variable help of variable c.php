<?php
$a=10;
$b=20;
echo("before swiping A=$a, B=$b</br>");
$c=$a;
$a=$b;
$b=$c;
echo("after swiping A=$a, B=$b");
?>