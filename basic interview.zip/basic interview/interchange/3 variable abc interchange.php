<?php
$a=10;
$b=20;
$c=30;
echo("before swiping value A=$a, B=$b, C=$c</br>");
$b=($a*$b*$c);//6000=(10*20*30)//
$a=$b/($a*$c);//20=6000/(10*30)//
$c=$b/($a*$c);//10=6000/(20*30)//
$b=$b/($a*$c);//30=6000/(20*10)//
echo("after swiping A=$a, B=$b, C=$c<br>");
?>