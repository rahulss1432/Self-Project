<?php
$a=10;
$b=20;
$c=30;
echo("before swiping value A=$a, B=$b, C=$c</br>");
$a=($a*$b*$c);
$b=$a/($b*$c);
$c=$a/($b*$c);
$a=$a/($b*$c);
echo("after swiping A=$a, B=$b, C=$c");
?>