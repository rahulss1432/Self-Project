<?php
$a=10;
$b=20;
$c;
echo "before swapping= A=$a,B=$b";
$a=$a+$b;
$b=$a-$b;
$a=$a-$b;
echo "after swapping= A=$a,B=$b";
echo "<br>";
echo "A=$a,B=$b";
$a=$a*$b;
$b=$a/$b;
$a=$a/$b;
echo "A=$a,B=$b";
echo "<br>";
echo "A=$a,B=$b";
$c=$a;
$a=$b;
$b=$c;
echo "A=$a,B=$b";
echo "<br>";
?>
<?php
$a=10;
$b=20;
$c=30;
echo "A=$a,B=$b,C=$c";
$a=($a*$b*$c);
$b=$a/($b*$c);
$c=$a/($b*$c);
$a=$a/($b*$c);
echo "A=$a,B=$b,C=$c";
echo "<br>";
echo "A=$a,B=$b,C=$c";
$a=($a+$b+$c);
$b=$a-($b+$c);
$c=$a-($b+$c);
$a=$a-($b+$c);
echo "A=$a,B=$b,C=$c";
echo "<br>";
?>

<?php
$a=10;
$b=20;
$c=30;
$d=40;
echo "before swap A=$a,B=$b,C=$c,D=$d";
$a=($a+$b+$c+$d);
$b=$a-($b+$c+$d);
$c=$a-($b+$c+$d);
$d=$a-($b+$c+$d);
$a=$a-($b+$c+$d);
echo "After swap A=$a,B=$b,C=$c,D=$d";
?>