<?php
$a=10;
$b=20;
echo("before swiping A=$a, B=$b</br>");
$a=($a+$b);//30=(10+20)//
$b=($a-$b);//10=(30-20)//
$a=($a-$b);//20=(30-10)//
echo("after swiping A=$a, B=$b");
?>
<?php
$a=10;
$b=20;
echo ("before swapping A=$a,B=$b</br>");
$b=($a+$b);
$a=($b-$a);
$b=($b-$a);
echo ("after swapping A=$a,B=$b");
?>