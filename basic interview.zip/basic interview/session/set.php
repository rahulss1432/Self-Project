<?php 
session_start();
if(isset($_POST["btnLogin"]))
{
 $nm=$_POST["txtNm"];
 $_SESSION["snm"]=$nm;
}
?>
<form method="post">
Name:<input type="text" name="txtNm">
<input type="submit" name="btnLogin" value="Login">
</form>