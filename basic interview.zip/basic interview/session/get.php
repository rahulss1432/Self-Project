<?php
session_start();
if(isset($_SESSION["snm"]))
{
 echo "welcome".$_SESSION["snm"];
}
if(!isset($_SESSION["snm"]))
{
 header("location:set.php");
}
?>
<a href="logout.php">Logout</a>