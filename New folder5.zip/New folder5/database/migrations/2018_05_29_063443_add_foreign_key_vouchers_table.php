<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddForeignKeyVouchersTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::table('vouchers', function (Blueprint $table) {
            $table->integer('vendor_id')->unsigned()->nullable()->after('id');
            $table->foreign('vendor_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::table('todolists', function(Blueprint $table) {
            $table->dropForeign('vouchers_vendor_id_foreign');
            $table->dropIndex('vouchers_vendor_id_index');
            $table->dropColumn('vendor_id');
        });
    }

}
