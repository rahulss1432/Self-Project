<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDriversTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('drivers', function (Blueprint $table) {
            $table->increments('id');
            $table->string('first_name');            
            $table->string('last_name');                        
            $table->string('phone_number');                                    
            $table->string('email');                                                
            $table->string('profile_image');                                                            
            $table->string('license_image')->nullable();                                                                        
            $table->integer('vehicle_category_id')->unsigned();                                                                                    
            $table->integer('deliver_company_id')->unsigned()->nullable();                                                                                    
            $table->string('license_number');                                                                                    
            $table->string('vehicle_number');                                                                                    
            $table->string('vehicle_description');                                                                                    
            $table->string('commision')->nullable();                                                                                   
            $table->enum('commission_type',['flat_fee','commission'])->nullable();                                                                                   
            $table->enum('status',['active','inactive'])->default('active');                                                                                               
            $table->timestamps();
            $table->foreign('vehicle_category_id')->references('id')->on('vehicle_categories')->onDelete('cascade');            
            $table->foreign('deliver_company_id')->references('id')->on('deliver_companies')->onDelete('cascade');                        
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('drivers');
    }
}
