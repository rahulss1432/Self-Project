<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->increments('id');
             $table->integer('vendor_id')->unsigned();   
             $table->integer('customer_id')->unsigned();   
             $table->string('picup_address')->nullable();   
             $table->string('drop_address')->nullable();   
             $table->string('payment_mode')->nullable();  
            $table->timestamps();
            $table->foreign('vendor_id')->references('id')->on('users')->onDelete('cascade');            
            $table->foreign('customer_id')->references('id')->on('users')->onDelete('cascade');    
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
