<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddFieldCommissionTypeAndForeignKeyFromDriverDetailsTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::table('driver_details', function (Blueprint $table) {
            $table->enum('commission_type', ['flat_fee', 'percentage'])->nullable();
            $table->foreign('vehicle_category_id')->references('id')->on('vehicle_categories')->onDelete('no action')->onUpdate('no action');
            $table->foreign('deliver_company_id')->references('id')->on('deliver_companies')->onDelete('no action')->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::table('driver_details', function (Blueprint $table) {
            //
        });
    }

}
