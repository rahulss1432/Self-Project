<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDeliveryAreasTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('delivery_areas', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('heading_id')->unsigned();
            $table->string('polygon_name');
            $table->string('shipping_charges');
            $table->text('poly_lat_long')->nullable();
            $table->text('polygon_lat_long')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('delivery_areas');
    }

}
