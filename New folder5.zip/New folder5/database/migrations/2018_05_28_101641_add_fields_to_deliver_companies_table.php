<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddFieldsToDeliverCompaniesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('deliver_companies', function (Blueprint $table) {
            $table->string('contact_email')->after('name')->nullable();
            $table->string('contact_mobile')->after('contact_email')->nullable();
            $table->string('contact_name')->after('contact_mobile')->nullable();
            $table->enum('commission_type', ['flat', 'percentage'])->after('contact_name')->default('flat');
            $table->dropColumn('status');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('deliver_companies', function (Blueprint $table) {
            //
        });
    }
}
