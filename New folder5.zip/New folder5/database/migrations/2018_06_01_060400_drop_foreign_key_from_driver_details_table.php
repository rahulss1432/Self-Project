<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DropForeignKeyFromDriverDetailsTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::table('driver_details', function (Blueprint $table) {
            $table->dropForeign('driver_details_vehicle_category_id_foreign');
            $table->dropForeign('driver_details_deliver_company_id_foreign');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::table('driver_details', function (Blueprint $table) {
            //
        });
    }

}
