<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Request;
use Braintree_Configuration;

class AppServiceProvider extends ServiceProvider {

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot() {
        Schema::defaultStringLength(191);
        Validator::extend('check_category', function ($attribute, $value, $parameters, $validator) {
            $post = request()->all();
            $property = \DB::table('categories')->where('business_id', '=', $post['businessId'])->where('category_name', '=', $post['categoryName'])->first();
            if (!empty($property)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('check_edit_category', function ($attribute, $value, $parameters, $validator) {
            $post = request()->all();
            $property = \DB::table('categories')->where('business_id', '=', $post['businessId'])->where('category_name', '=', $post['categoryName'])->where('id', '!=', $post['catId'])->first();
            if (!empty($property)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('check_matched_email', function ($attribute, $value, $parameters, $validator) {
            $post = request()->all();
            if (isset($post['user_id']) && isset($post['user_id']) != '') {
                $userId = $post['user_id'];
            } else {
                $userId = \Illuminate\Support\Facades\Auth::guard()->user()->id;
            }

            $user = \DB::table('users')->where('id', '!=', $userId)->where('email', '=', $value)->get();
            if ($user->count() > 0) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('validate_category', function ($attribute, $value, $parameters, $validator) {
            $businessId = request()->business_id;
            $catgoryName = request()->category_name;
            $category = \DB::table('categories')->where(['category_name' => $catgoryName, 'business_id' => $businessId])->first();
            if (!empty($category)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('edit_validate_category', function ($attribute, $value, $parameters, $validator) {
            $id = request()->catId;
            $businessId = request()->business_id;
            $catgoryName = request()->category_name;
            $category = \DB::table('categories')->where(['category_name' => $catgoryName, 'business_id' => $businessId])->where('id', '!=', $id)->first();
            if (!empty($category)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('validate_product', function ($attribute, $value, $parameters, $validator) {
            $businessId = request()->business_id;
            $catId = request()->category_id;
            $productName = request()->product_name;
            $item = \DB::table('items')->where(['product_name' => $productName, 'business_id' => $businessId, 'category_id' => $catId])->first();
            if (!empty($item)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('edit_validate_product', function ($attribute, $value, $parameters, $validator) {
            $businessId = request()->business_id;
            $catId = request()->category_id;
            $productName = request()->product_name;
            $item = \DB::table('items')->where(['product_name' => $productName, 'business_id' => $businessId, 'category_id' => $catId])
                            ->where('id', '!=', request()->itemId)->first();
            if (!empty($item)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('current_password', function ($attribute, $value, $parameters, $validator) {
            if (!empty(Auth::user()->id)) {
                $password = Auth::user()->password;
            }
            return Hash::check($value, $password);
        });
        Validator::extend('current_password_admin', function ($attribute, $value, $parameters, $validator) {
            $password = Auth::guard('admin')->user()->password;
            return Hash::check($value, $password);
        });

        Validator::extend('validate_vendor_product', function ($attribute, $value, $parameters, $validator) {
//            print_r(request()->all());die;
            $categoryId = request()->category_id;
            $category = \DB::table('items')->where('product_name', '=', $value)->where('category_id', '=', $categoryId)->first();
            if (!empty($category)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('remove_spaces', function($attribute, $value, $parameters, $validator) {
            if (trim($value) == '') {
                return false;
            }
            return true;
        });

        Validator::extend('phone_format', function ($attribute, $value, $parameters, $validator) {
            if ($value != "") {
                return preg_match("/^(\+\d{1,3}[- ]?)?\d{10}$/", $value);
            } else {
                return true;
            }
        });

        Validator::extend('check_email_format', function ($attribute, $value, $parameters, $validator) {
            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('price_format', function ($attribute, $value, $parameters, $validator) {
            if ($value != "") {
                return preg_match('/^\d*(\.\d{2})?$/', $value);
            } else {
                return true;
            }
        });

        Validator::extend('current_password_match', function ($attribute, $value, $parameters, $validator) {
            $userId = Auth::guard('web')->user()->password;
            return Hash::check($value, $userId);
        });

        Validator::extend('check_admin_commission', function ($attribute, $value, $parameters, $validator) {
            $post = request()->all();
            $commissioAmount = $post['admin_commission'];
            if ($commissioAmount < 100) {
                return true;
            } else {
                return false;
            }
        });

        Validator::extend('valid_percent', function ($attribute, $value, $parameters, $validator) {
            if ((request()->commission > 100) && (request()->commission_type == 'percentage')) {
                return false;
            } elseif (request()->commission_type == 'flat_fee') {
                return true;
            } else {
                return true;
            }
        });

        Validator::extend('admin_commission', function ($attribute, $value, $parameters, $validator) {
            if ((request()->value > 100) && (request()->unit == 'percent')) {
                return false;
            } elseif (request()->unit == 'flat_fee') {
                return true;
            } else {
                return true;
            }
        });

        Validator::extend('check_time', function ($attribute, $value, $parameters, $validator) {

            if ((request()->value > 60) && (request()->unit == 'minute')) {
                return false;
            } elseif ((request()->value > 60) && (request()->unit == 'second')) {
                return false;
            } elseif ((request()->value > 0 ) && (request()->unit == 'hour')) {

                return true;
            } else {
                return true;
            }
        });

        Validator::extend('valid_amount', function ($attribute, $value, $parameters, $validator) {
            if ((request()->voucher_amount <= 0)) {
                return false;
            } else {
                return true;
            }
        });
        
        Validator::extend('check_amount', function ($attribute, $value, $parameters, $validator) {
            if ((request()->amount <= 0)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('valid_price', function ($attribute, $value, $parameters, $validator) {
            if ((request()->price <= 0)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('valid_use', function ($attribute, $value, $parameters, $validator) {
            if ((request()->max_use <= 0)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('valid_commission', function ($attribute, $value, $parameters, $validator) {
            if ((request()->commission <= 0)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('valid_admin_commission', function ($attribute, $value, $parameters, $validator) {
            if ((request()->admin_commission <= 0)) {
                return false;
            } else {
                return true;
            }
        });


        Validator::extend('area_heading_unique', function ($attribute, $value, $parameters, $validator) {
            $post = request()->all();
            
            $property = \DB::table('area_headings')->where('id', '!=', $post['id'])->where('heading', '=', $value)->get();
            if ($property->count() > 0) {
                return false;
            } else {
                return true;
            }
        });

        Braintree_Configuration::environment(env('BRAINTREE_ENV'));
        Braintree_Configuration::merchantId(env('BRAINTREE_MERCHANT_ID'));
        Braintree_Configuration::publicKey(env('BRAINTREE_PUBLIC_KEY'));
        Braintree_Configuration::privateKey(env('BRAINTREE_PRIVATE_KEY'));
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register() {
        //
    }

}
