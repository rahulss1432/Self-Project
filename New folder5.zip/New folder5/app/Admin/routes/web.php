<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */
Route::group(['prefix' => 'admin', 'middleware' => 'admin'], function() {
    Route::get('/admin-dashboard', 'DashboardController@index')->name('admin/admin-dashboard');
    /* common routes for update status for all user */
    Route::get('/update-status/{id}', 'DashboardController@updateStatus');
    /* common routes for delete user for all user */
    Route::get('/delete-user/{id}', 'DashboardController@deleteUsers');
    Route::post('/load-order-graph', 'DashboardController@getOrderGraph');
    Route::get('/earning-csv-download', 'DashboardController@downloadEarningCsv');
// My Profile Routes 
    Route::get('my-profile', 'DashboardController@viewMyProfile');
    Route::get('edit-profile/{id}', 'DashboardController@editProfile');
    Route::get('change-password', 'DashboardController@changePasswordForm');
    Route::post('admin-save-change-password', 'DashboardController@saveChangePassword');
    Route::post('save-cropped-image', 'DashboardController@saveCroppedImage');
    Route::post('update-admin-profile', 'DashboardController@updateAdminProfile');
// Delete Notification   
    Route::get('/delete-notification/{id}', 'DashboardController@deleteNotification');

//Item Management
    Route::get('/item-management', 'ItemController@index')->name('admin/item-management');
    Route::post('/load-items', 'ItemController@getAllItems');
    Route::get('/create-item', 'ItemController@createItem')->name('admin/item-management');
    Route::post('/get-option-value', 'ItemController@getOptionValue');
    Route::post('/save-items', 'ItemController@actionSaveItems');
    Route::get('/get-category-by-business', 'ItemController@getCategoryByBusiness');
    Route::get('/delete-item/{id}', 'ItemController@deleteItem');
    Route::post('/change-item-stock-status/{id}', 'ItemController@changeItemStockStatus');
    Route::get('/edit-item/{id}', 'ItemController@editItem')->name('admin/item-management');
    Route::post('/update-items', 'ItemController@updateItem');

//Item croperu
    Route::post('/upload-item-image', 'ItemController@uploadItemImage');
    Route::get('/load-item-image-cropper', 'ItemController@loadItemImageCropper');
    Route::post('/upload-cropped-item-image', 'ItemController@uploadCroppedItemImage');

//Category Management
    Route::get('/category-management', 'CategoryController@index')->name('admin/category-management');
    Route::get('/create-category', 'CategoryController@createCategory')->name('admin/category-management');
    Route::post('/save-category', 'CategoryController@actionSaveCategory');
    Route::post('/load-categories', 'CategoryController@getAllCategories');
    Route::get('/delete-category/{id}', 'CategoryController@deleteCategory');
    Route::get('/edit-category/{id}', 'CategoryController@editCategory')->name('admin/category-management');
    Route::post('/update-category', 'CategoryController@updateCategory');

    /* Routes For Customer-Managment Section */
    Route::get('/customer', 'CustomerController@customerIndex');
    Route::get('/create-customer', 'CustomerController@creatCustomer');
    Route::post('/save-customer', 'CustomerController@saveCustomer');
    Route::post('/load-customers-list', 'CustomerController@allCustomersList');
    Route::post('/active-inactive/{id}', 'CustomerController@activeInactive');
    Route::post('/delete-customers', 'CustomerController@deleteCustomers');
    Route::get('/customer-view/{id}', 'CustomerController@viewCustomer');
    Route::get('/customer-edit/{id}', 'CustomerController@editCustomer');
    Route::post('/update-customer', 'CustomerController@customerUpdate');
    Route::get('/customer-csv-download', 'CustomerController@downloadCustomerCsv');
    /* End Route For Customer-Managment Section */

    /* Routes For Faqs */
    Route::get('/faqs', 'FaqController@faqIndex')->name('admin/faqs');
    Route::post('/load-faqs-list', 'FaqController@allFaqsList');
    Route::get('/create-faq', 'FaqController@creatFaq')->name('admin/faqs');
    Route::post('/save-faq', 'FaqController@saveFaq');
    Route::get('/delete-faq/{id}', 'FaqController@deleteFaq');
    Route::get('/faq-view/{id}', 'FaqController@viewFaq')->name('admin/faqs');
    Route::get('/faq-edit/{id}', 'FaqController@editFaq')->name('admin/faqs');
    Route::post('/update-faq', 'FaqController@updateFaq');
    /* End Routes */

    /* routes for driver-managment section */
    Route::get('/drivers-list', 'DriverController@index');
    Route::get('/create-driver', 'DriverController@createDriver');
    /* image cropper routes  for Driver profile image */
    Route::post('/upload-profile-image', 'DriverController@uploadProfileImage');
    Route::get('/load-image-cropper', 'DriverController@loadImageCropper');
    Route::post('/upload-cropped-profile-image', 'DriverController@uploadCroppedPicture');
    /* image cropper route for license image */
    Route::post('/upload-license-image', 'DriverController@uploadLicenseImage');
    Route::post('/save-driver', 'DriverController@saveDriver');
    Route::post('/load-driver-list', 'DriverController@loadDriverList');
    Route::get('/driver-vehicle-detail/{id}', 'DriverController@driverVehicleDetail');
    Route::get('/driver-edit/{id}', 'DriverController@showEditDriverForm');
    Route::post('/update-driver', 'DriverController@updateDriver');
    Route::get('/driver-csv-download', 'DriverController@downloadDriverCsv');
    Route::get('/driver-detail/{id}', 'DriverController@driverDetail');

    //Routes For Sub Admin
    Route::get('/sub-admin', 'SubadminController@showSubAdmin')->name('admin/sub-admin');
    Route::get('/create-sub-admin', 'SubadminController@createSubAdmin')->name('admin/sub-admin');
    Route::post('/save-subadmin', 'SubadminController@saveSubadmin');
    Route::post('/update-subadmin', 'SubadminController@updateSubadmin');
    Route::post('/list-subadmin', 'SubadminController@listSubadmin');
    Route::get('/edit-subadmin/{id}', 'SubadminController@editSubadmin')->name('admin/sub-admin');

    //vendor routes
    Route::get('/vendor-list', 'VendorController@index');
    Route::get('/create-vendor', 'VendorController@createVendor');
    Route::post('/load-vendor-list', 'VendorController@loadVendorList');
    Route::post('/save-vendor', 'VendorController@actionSaveVendor');
    Route::post('/change-vendor-status/{id}', 'VendorController@vendorChangeStatus');
    Route::post('/delete-vendors', 'VendorController@deleteVendors');
    Route::get('/edit-vendor/{id}', 'VendorController@editVendor');
    Route::post('/update-vendor', 'VendorController@updateVendor');
    Route::get('/vendor-csv-download', 'VendorController@downloadVendorCsv');
    Route::get('/vendor-details/{id}', 'VendorController@vendorDetails');
    Route::get('/change-vendor-password/{id}', 'VendorController@changeVendorPassword');
    Route::post('/update-password', 'VendorController@updatePassword');
    Route::post('/save-cropped-image', 'VendorController@saveCropperImage');
    Route::get('/order-management/{id}', 'VendorController@singleOrderList')->name('admin/order-management');
    Route::post('/list-singleuser-order', 'VendorController@listSingleUserOder');

    //business type routes
    Route::get('/business-type', 'BusinessController@index')->name('admin/business-type');
    Route::get('/create-business-type', 'BusinessController@addBusinessType')->name('admin/business-type');
    Route::post('/save-business-type', 'BusinessController@actionSaveBusinessType');
    Route::post('/load-business-list', 'BusinessController@loadBusinessTypeList');
    Route::post('/change-business-type-status/{id}', 'BusinessController@changeBusinessTypeStatus');
    Route::get('/edit-business-type/{id}', 'BusinessController@editBusinessType')->name('admin/business-type');
    Route::post('/update-business-type', 'BusinessController@updateBusinessType');
    Route::get('/delete-business-type/{id}', 'BusinessController@deleteBusinessType');

    /* routes for attribute-management section */
    Route::get('/attribute', 'AttributeController@index')->name('admin/attribute-list');
    Route::post('/save-attribute', 'AttributeController@saveAttribute');
    Route::get('/attribute-list', 'AttributeController@attributeList')->name('admin/attribute-list');
    Route::post('/load-attribute-list', 'AttributeController@loadAttributeList');
    Route::post('/delete-attributes', 'AttributeController@deleteAttributes');
    Route::get('/edit-attribute/{id}', 'AttributeController@editAttribute')->name('admin/attribute-list');
    Route::post('/update-attribute', 'AttributeController@updateAttribute');

    // Routes For Order Management
    Route::get('/order-management', 'OrderManagementController@orderIndex')->name('admin/order-management');
    Route::post('/list-order', 'OrderManagementController@listOder');
    Route::get('/create-order', 'OrderManagementController@createOder')->name('admin/order-management');
    Route::post('/get-location', 'OrderManagementController@getVendorLocation');
    Route::post('/save-order', 'OrderManagementController@saveOrder');
    Route::post('/get-category-item', 'OrderManagementController@getCategoryItem');
    Route::post('/get-item-detail', 'OrderManagementController@getItemDeatails');
    Route::get('/view-order/{id}', 'OrderManagementController@viewOrder')->name('admin/order-management');
    Route::post('check-delivery-area', 'OrderManagementController@checkDeliveryArea');
    Route::get('/assign-driver/{id}', 'OrderManagementController@assignDriver')->name('admin/order-management');
    Route::get('/assign-driver-onorder/{orderid}/{driverid} ', 'OrderManagementController@assignDriverOnorder')->name('admin/order-management');


    //settings routes
    Route::get('/settings', 'SettingController@index')->name('admin/settings');
    Route::get('/load-setting-list', 'SettingController@loadSettingList');
    Route::get('/edit-settings/{id}', 'SettingController@editSettingData')->name('admin/settings');
    Route::post('/update-setting', 'SettingController@updateSettingData');

    //cencellation-reasons
    Route::get('/load-cencellation-reasons', 'CencellationController@loadCencellationReasons');
    Route::get('/create-cancellation-reason', 'CencellationController@createCancellation')->name('admin/settings');
    Route::post('/save-cancellation-reason', 'CencellationController@saveCancellationReason');
    Route::get('/delete-cencellation-reason/{id}', 'CencellationController@deleteCancellationReason');
    Route::get('/edit-cencellatoin-reasons/{id}', 'CencellationController@editCancellationReason')->name('admin/settings');
    Route::post('/update-cancellation-reason', 'CencellationController@updateCancellationReason');

    //delivery-area-routes
    Route::post('/save-polygon', 'DeliveryAreaController@addPolygon');
    Route::post('/update-polygon', 'DeliveryAreaController@updatePolygon');
    //area-heading routes
    Route::get('/view-area-heading', 'AreaHeadingController@viewAreaHeading')->name('admin/settings');
    Route::get('/create-heading', 'AreaHeadingController@createHeading')->name('admin/settings');
    Route::post('/save-area-heading', 'AreaHeadingController@saveAreaHeading');
    Route::post('/load-area-heading', 'AreaHeadingController@loadAreaHeading');
    Route::get('/edit-heading/{id}', 'AreaHeadingController@editHeading')->name('admin/settings');
    Route::post('/update-area-heading', 'AreaHeadingController@updateHeading');
    Route::get('/delete-heading/{id}', 'AreaHeadingController@deleteHeading');

    //all-location routes
    Route::get('/view-all-location', 'AllLocationController@viewAllLocation')->name('admin/settings');
    Route::post('/load-all-location', 'AllLocationController@loadAllLocation');
    Route::get('/delete-location/{id}', 'AllLocationController@deleteLocation');
    Route::get('/edit-location', 'AllLocationController@loadEditLocation');

    /* routes for content-management section */
    Route::get('/content-list', 'ContentController@index')->name('admin/content-list');
    Route::get('/load-content-list', 'ContentController@loadContentList');
    Route::get('/add-content', 'ContentController@addContent')->name('admin/content-list');
    Route::post('/save-content', 'ContentController@saveContent');
    Route::get('/edit-content/{id}', 'ContentController@editContent')->name('admin/content-list');
    Route::post('/update-content', 'ContentController@updateContent');

    /* Route For Permissions */
    Route::get('/permissions', 'PermissionController@index')->name('admin/permissions');
    Route::post('/privileges-list', 'PermissionController@privilegesList');
    Route::post('/update-privileges', 'PermissionController@updatePrivileges');

    Route::post('/subadmin-list', 'PermissionController@subAdminList');
    /* End Route For Permissions */

    /* routes for voucher-management section */
    Route::get('/voucher-list', 'VoucherController@index')->name('admin/voucher-list');
    Route::get('/load-voucher-list', 'VoucherController@loadVoucherList');
    Route::get('/add-voucher', 'VoucherController@addVoucher')->name('admin/voucher-list');
    Route::post('/save-voucher', 'VoucherController@saveVoucher');
    Route::post('/delete-vouchers', 'VoucherController@deleteVouchers');
    Route::get('/edit-voucher/{id}', 'VoucherController@editVoucher')->name('admin/voucher-list');
    Route::post('/update-voucher', 'VoucherController@updateVoucher');

    //Deliver-Companies Routes
    Route::get('/deliver-company-management', 'DeliverCompanyController@index')->name('admin/deliver-company-management');
    Route::get('/create-deliver-company', 'DeliverCompanyController@createDeliverCompany')->name('admin/deliver-company-management');
    Route::post('/save-deliver-company', 'DeliverCompanyController@saveDeliverCompany');
    Route::post('/load-deliver-companies', 'DeliverCompanyController@getAllDeliverCompanies');
    Route::get('/delete-deliver-company/{id}', 'DeliverCompanyController@deleteDeliverCompany');
    Route::get('/edit-deliver-company/{id}', 'DeliverCompanyController@editDeliverCompany')->name('admin/deliver-company-management');
    Route::post('/update-deliver-company', 'DeliverCompanyController@updateDeliverCompany');

    // Routes for Drevier Tracking
    Route::get('/driver-tracking', 'DriverController@showDriverTrackingMap')->name('admin/driver-tracking');

    //Email Template Management
    Route::get('/email-templates', 'EmailTemplateController@index')->name('admin/email-templates');
    Route::get('/create-template', 'EmailTemplateController@createTemplate')->name('admin/email-templates');
    Route::post('/save-template', 'EmailTemplateController@saveTemplate');
    Route::get('/load-template-list', 'EmailTemplateController@loadTemplateList');
    Route::get('/edit-template/{id}', 'EmailTemplateController@editTemplate')->name('admin/email-templates');
    Route::post('/update-template', 'EmailTemplateController@updateTemplate');
    Route::post('/delete-template', 'EmailTemplateController@DeleteTemplate');
    Route::get('/send-mails', 'EmailTemplateController@sendMails');
    Route::post('/get-templates', 'EmailTemplateController@getTemplates');

//  order notifications
    Route::post('/load-all-notifications', 'DashboardController@loadAllNotifications');
    Route::get('/order-notifications', 'DashboardController@orderNotifications');
    Route::get('/check-all-order-status', 'DashboardController@checkOrderStatus');
    /* Transaction Management Routes */
    Route::get('/transactions', 'TransactionController@index')->name('admin/transactions');
    Route::get('/load-transaction-list', 'TransactionController@loadTransactionList');
    Route::get('/transaction-detail/{id}', 'TransactionController@transactionDetail')->name('admin/transactions');
    
    //report-section
    Route::get('/report', 'ReportController@index')->name('admin/report');
    Route::post('/load-report-list', 'ReportController@loadReportList');
    Route::get('/report/view-report/{id}/{slug}', 'ReportController@viewReport')->name('admin/report');
    Route::post('/amount-settle', 'ReportController@settleAmount');
    Route::post('/save-settle-amount', 'ReportController@saveSettleAmount');
    Route::get('/notification-status-delete/{id}', 'DashboardController@notificationStatusToDelete');
});
Route::group(['prefix' => 'admin'], function() {
    Route::get('/', 'Auth\LoginController@index')->name('login');
    Route::get('/login', 'Auth\LoginController@index')->name('login');
    Route::post('/login', 'Auth\LoginController@login');
    Route::post('/logout', 'Auth\LoginController@logout');
});
