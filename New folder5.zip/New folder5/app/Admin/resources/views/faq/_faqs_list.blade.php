<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Question</th>
            <th>Answer</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if(count($faq)>0)
        @php $serial = 1; @endphp
        @foreach($faq as $data)
        <tr id="{{'faq'.$data->id}}">
            <td>{{$serial}}</td>
            <td>@php echo (substr($data->question,0,50)); @endphp</td>
            <td>
                <?php
                $string = strip_tags($data->answer);
                if (strlen($string) > 50) {
                    $stringCut = substr($string, 0, 50);
                    $endPoint = strrpos($stringCut, ' ');
                    $string = $endPoint ? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
                    $string .= '... <a href="javascript:void(0);" class="d-block mt-2 showDescription" data-toggle="modal" data-target="#readmore_' . $data->id . '" >Read More</a>';
                }
                echo $string;
                ?>
            </td>
            <td>
                <ul class="list-inline action mb-0">
                    <li>
                        <a class="btn btn-primary" href="{{url('admin/faq-view',$data->id)}}">
                            <i class="fa fa-eye"> View</i>
                        </a>
                    </li>
                    <li>
                        <a class="btn btn-primary" href="{{url('admin/faq-edit',$data->id)}}">
                            <i class="fa fa-pencil-square-o"> Edit</i>
                        </a>
                    </li> 
                    <li>
                        <a class="btn btn-primary" href="javascript:void(0);" onclick="deleteFunction({{$data->id}})">
                            <i class="fa fa-trash-o"> Delete</i>
                        </a>
                    </li>
                </ul>
            </td>
        </tr>
        @php $serial++; @endphp
        <div class="modal edit_item fade" id="readmore_{{$data->id}}" tabindex="-1" role="dialog" aria-labelledby="edit_property">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close" aria-hidden="true" style="color:red;"></i></button>
                    </div>
                    <div class="modal-body">
                        <div class="panel panel-default credit-card-box customwidth center-block">
                            <div class="pamel-heading"><center><h1>Answer</h1></center></div>
                            <div class="panel-body">
                                <?php echo $data->answer; ?>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="reloadPage();">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    @endforeach
    @else
    <tr>
        <td colspan="7">
            <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
        </td>
    </tr>
    @endif
</tbody>
</table>

<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$faq->links()}}
    </ul>
</div>



<script>
            $(document).ready(function () {
    $(".pagination li a").on('click', function (e) {
    e.preventDefault();
            $("#faqList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
            var $this = $(this);
            var pageLink = $this.attr('href');
            var search_filter = $("#searchForm").serializeArray();
            search_filter.push('_token', '{{ csrf_token() }}');
            $.ajax({
            type: 'POST',
                    url: pageLink,
                    async: false,
                    data: search_filter,
                    success: function (response) {
                    $('.pagination:first').remove();
                            $('#faqList').html(response.html);
                    }
            });
    });
    });
</script>
