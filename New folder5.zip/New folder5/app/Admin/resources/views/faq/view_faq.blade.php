@extends('admin::layouts.app')
@section('title', 'MarketPlace : Faq Details')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Faq Details</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/faqs')}}">Faq Management</a></li>
            <li class="active">View Faq</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="nav-tabs-custom">
                    <div class="tab-content">
                        <div class="active tab-pane" id="activity">
                            <div class="post">
                                <p class="user-block">
                                <label>Quetion : </label>
                                <div><a>@php echo ($view->question); @endphp</a></div>
                                </p>
                                <p>
                                <label>Answer : </label>
                                <div>@php echo ($view->answer); @endphp</div>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
@stop