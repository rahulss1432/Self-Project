<main class="main_content admin_content error">
    <div class="col-sm-4 col-sm-offset-4">
        <img src="{{url('public/images/error.png')}}" alt="" class="img img-responsive">
    </div>
    <div class="col-sm-12">
        <p>THE LINK YOU FOLLOWED IS PROBABLY BROKEN OR THE PAGE HAS BEEN REMOVED.</p>                            
        <a href="{{url('/admin/logout')}}" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();"> <h2> RETURN TO THE HOME PAGE</h2>
        </a>
        <form id="logout-form" action="{{ url('/admin/logout') }}" method="POST" style="display: none;">
            {{ csrf_field() }}
        </form>
    </div>
</div>                     
</div>
</section>
</main>
<style>
    body{
        padding-left:0;
    }
</style>