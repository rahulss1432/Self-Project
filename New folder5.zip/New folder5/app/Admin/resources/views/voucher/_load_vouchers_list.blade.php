<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Voucher Code</th>
            <th>Amount</th>
            <th>Max Use</th>
            <th>Type</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Created Date</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if($voucherData->count()>0)
        <?php $i = 1; ?>
        @foreach ($voucherData as $vCode)
        <?php
        if ($voucherData->currentPage() == 1) {
            $srNo = $i++;
        } else {
            $srNo = ($voucherData->currentPage() - 1) * $voucherData->perPage() + $i++;
        }
        ?>
        <tr id="tr_{{$vCode->id}}">
            <td>{{ $srNo }}</td>
            <td>{{ $vCode->voucher_code }}</td>
            <td>{{ $vCode->voucher_amount }}</td>
            <td>{{ $vCode->max_use }}</td>
            <td>{{ $vCode->voucher_type }}</td>
            <td>{{ \App\Helpers\Helper::jqueryDateFormat($vCode->start_date) }}</td>
            <td>{{ \App\Helpers\Helper::jqueryDateFormat($vCode->end_date) }}</td>
            <td><?php $createTime = date('H:i A', strtotime($vCode->created_at)); ?>{{$createTime}}<br><span style="color:#c0c6eb;">{{ \App\Helpers\Helper::jqueryDateFormat($vCode->created_at) }}</span></td>
            <td>
                <a href="{{url('admin/edit-voucher/'.$vCode->id)}}" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i> Edit</a>
                <a href="javascript:void(0);" onclick="deleteVoucher('{{$vCode->id}}');" class="btn btn-primary"><i class="fa fa-trash-o"></i> Delete</a>
            </td>
        </tr>
        @endforeach
        @else 
        <tr>
            <td colspan="9">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>

<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$voucherData->links()}}
    </ul>
</div>
<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var loader = '<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>';
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({type: 'GET', url: pageLink, async: false,
                beforeSend: function () {
                    $('#voucherList').html(loader);
                },
                success: function (response) {
                    $('.pagination:first').remove();
                    $('#voucherList').html(response.html);
                }
            });
        });
    });
</script>

