@extends('admin::layouts.app')
@section('title', 'MarketPlace : Add Voucher')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Voucher Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/voucher-list')}}">Voucher Management</a></li>
            <li class="active">Create Voucher</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Add Voucher</h3>
                    </div>
                    <form id="frmEditVoucherForm" name="voucherForm" method="post" class="form-horizontal" action="{{url('admin/save-voucher')}}">
                        {{csrf_field()}}
                        <div class="box-body">
                            <div class="form-group">
                                <label class="control-label col-sm-3 desc-lebel">Description <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <textarea name="voucher_description" id="voucherDesc" class="form-control input-lg" placeholder="Description"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Amount <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="voucher_amount" id="voucherAmount" class="form-control input-lg commissionPrice" placeholder="Amount" autocomplete="off" onKeyPress="if (this.value.length == 10)
                                            return false;">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Type <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <select name="voucher_type" class="form-control input-lg">
                                        <option value="">-- Please Select --</option>
                                        <option value="Flat">Flat</option>
                                        <option value="Percent">Percent</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Max Use <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="max_use" id="maxUse" class="form-control numberOnly input-lg" placeholder="Max Use" autocomplete="off" onKeyPress="if (this.value.length == 10)
                                            return false;">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Start Date <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" readonly name="start_date" id="startDate" class="form-control input-lg" placeholder="Start Date" autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">End Date <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" readonly name="end_date" id="endDate" class="form-control input-lg" placeholder="End Date" autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Status <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <select name="voucher_status" class="form-control input-lg">
                                        <option value="">-- Please Select --</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Vendor <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <select name="vendor_id" class="form-control input-lg">
                                        <option value="">-- Select Vendor --</option>
                                        @if($getAllVendors->count() > 0)
                                        @foreach($getAllVendors as $val)
                                        <option value="{{$val->id}}" >{{$val->first_name}} {{$val->last_name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Voucher Code <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="voucher_code" id="voucherCode" class="form-control input-lg" placeholder="Voucher Code" autocomplete="off" readonly="readonly">
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button id="btnVoucher" type="submit" class="btn btn-primary pull-right submitButton">
                                Add Voucher <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\CreateVoucherRequest','#frmEditVoucherForm') !!}
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $(function () {
      generateVoucherCode();
      $("#startDate").datepicker({
        todayBtn: 1,
        autoclose: true,
        startDate: new Date(),
        todayHighlight: true,
      }).on('changeDate', function (selected) {
        var minDate = new Date(selected.date.valueOf());
        $('#endDate').datepicker('setStartDate', minDate);
      });
      $("#endDate").datepicker({
        todayHighlight: true,
        startDate: new Date(),
      }).on('changeDate', function (selected) {
        var maxDate = new Date(selected.date.valueOf());
        $('#startDate').datepicker('setEndDate', maxDate);
      });

      $(".numberOnly").keypress(function (e) {
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
          return false;
        }
      });

      $('.commissionPrice').keypress(function (event) {
        if (event.which != 46 && (event.which < 47 || event.which > 59))
        {
          event.preventDefault();
          if ((event.which == 46) && ($(this).indexOf('.') != -1)) {
            event.preventDefault();
          }
        }
      });

      $('#frmEditVoucherForm').on('submit', function (e) {
        if ($('#frmEditVoucherForm').valid()) {
          $('#addLoader').show();
          $("#btnVoucher").prop('disabled', true);
        } else {
          $('#addLoader').hide();
          $("#btnVoucher").prop('disabled', false);
        }
      });
    });
    function generateVoucherCode() {
      var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
      var string_length = 6;
      var randomstring = '';
      for (var i = 0; i < string_length; i++) {
        var rnum = Math.floor(Math.random() * chars.length);
        randomstring += chars.substring(rnum, rnum + 1);
      }
      document.voucherForm.voucher_code.value = randomstring;
    }
</script>
@stop