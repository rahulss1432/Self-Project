@extends('admin::layouts.app')
@section('title', 'MarketPlace : Voucher Management')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Voucher Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/voucher-list')}}">Voucher Management</a></li>
            <li class="active">Voucher Listing</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <a class="btn btn-primary" href="{{url('admin/add-voucher')}}"><i class="fa fa-plus-circle"></i> Create Voucher</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="voucherList">
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $().ready(function () {
      loadVouchersList();
    });
    function loadVouchersList() {
      var loader = '<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>';
      var url = "{{url('admin/load-voucher-list')}}";
      $.ajax({type: "GET", url: url,
        beforeSend: function () {
          $('#voucherList').html(loader);
        },
        success: function (data) {
          $("#voucherList").html(data.html);
        }
      });
    }

    function deleteVoucher(id) {
      bootbox.confirm('Are you sure you want to delete ?', function (result) {
        if (result) {
          var token = '{{ csrf_token() }}';
          $.ajax({type: "POST",
            url: "{{ url('admin/delete-vouchers') }}",
            data: {_token: token, id: id},
            success: function (response) {
              if (response) {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.success("{{\Config::get('constants.delete_voucher')}}", 'Success', {timeOut: 1000});
                $("#tr_" + id).hide(500);

              }
              else {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error("{{\Config::get('constants.something_wrong')}}", 'Error', {timeOut: 1000});
              }
            }
          });
        }
      });
    }
</script>
@stop
