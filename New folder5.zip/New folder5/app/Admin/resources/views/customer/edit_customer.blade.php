@extends('admin::layouts.app')
@section('title', 'MarketPlace : Edit Customer')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Edit Customer</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/customer')}}">User Management</a></li>
            <li class="active">Edit Customer</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Customer</h3>
                    </div>
                    <form id="EditCustomerForm" class="form-horizontal" method="POST" action="{{url('admin/update-customer')}}">
                        {{ csrf_field() }}
                        <input type="hidden" name="id" value="{{$edit->id}}">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="name" class="col-sm-3 control-label">Customer Name <span class="error-star">*</span></label>
                                <div class="col-sm-4">
                                    <input type="text" name="first_name" class="form-control input-lg" value="{{$edit->first_name}}">
                                </div>
                                <div class="col-sm-5">
                                    <input type="text" name="last_name" class="form-control input-lg" value="{{$edit->last_name}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email" class="col-sm-3 control-label">Email ID <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="email" readonly class="form-control input-lg" value="{{$edit->email}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="mobile" class="col-sm-3 control-label">Mobile <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="phone_number" class="form-control input-lg number_only" value="{{$edit->phone_number}}" maxlength="10">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="dob" class="col-sm-3 control-label">DOB <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" readonly id="datepicker22" name="date_of_birth" class="form-control input-lg" value="{{$edit->date_of_birth}}" autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="mobile" class="col-sm-3 control-label">Status <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <select class="form-control input-lg" name="status">
                                        <option value="">-- Select --</option>
                                        <option value="1"<?php if ($edit->is_active == '1') echo 'selected'; ?>>Active</option>
                                        <option value="0"<?php if ($edit->is_active == '0') echo 'selected'; ?>>Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button id="updateButton" type="submit" class="btn btn-primary pull-right">
                                <i id="updateLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> Update Customer
                            </button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\EditCustomerRequest','#EditCustomerForm') !!}
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $(".number_only").keypress(function (e) {
      if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        return false;
      }
    });
    $("#EditCustomerForm").on('submit', function (e) {
      if ($("#EditCustomerForm").valid()) {
        $("#updateLoader").show();
        $("#updateButton").prop('disabled', true);
      } else {
        $("#updateLoader").hide();
        $("#updateButton").prop('disabled', false);
      }
    });

    var dt = new Date();
    dt.setFullYear(new Date().getFullYear() - 18);
    $(function ()
    {
      $("#datepicker22").datepicker({
        dateFormat: 'dd/MM/yy',
        maxDate: 0,
        changeMonth: true,
        changeYear: true,
        weekStart: 0,
        calendarWeeks: true,
        autoclose: true,
        todayHighlight: true,
        orientation: "auto",
        endDate: dt,
      });
    });
</script>
@stop