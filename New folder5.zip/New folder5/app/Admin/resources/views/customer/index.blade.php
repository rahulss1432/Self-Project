@extends('admin::layouts.app')
@section('title', 'MarketPlace : Customer Management')
@section('content')

<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Customer Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/customer')}}">User Management</a></li>
            <li class="active">Customer Listing</li>
        </ol>
    </section>

    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" onclick="showSearchForm()" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class="btn btn-primary disabled" id="btnDownloadCsv" href="{{ url('/admin/customer-csv-download') }}"> <i class="fa fa-upload"></i>  Export Customer</a>               
                            <a class=" btn btn-primary" href="{{url('/admin/create-customer')}}">
                                <i class="fa fa-plus-circle"></i> Create Customer
                            </a>
                        </div>
                    </div>
                </div>
                <form id="searchForm" style="display: none;" action="javascript:loadCustomersList()" method="post" autocomplete="off">
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-2">
                            <label>Name</label>
                            <input id="searchByName" class="form-control" name="name" type="text" placeholder="Name">
                        </div>
                        <div class="col-md-2">
                            <label>Email address</label>
                            <input id="searchByEmail" class="form-control" type="text" placeholder="Email" name="email">
                        </div>
                        <div class="col-md-2">
                            <label>Mobile number</label>
                            <input id="searchByPhone" class="form-control" type="text" placeholder="Mobile number" name="phone_number">
                        </div>
                        <div class="col-md-2">
                            <label>Number of orders</label>
                            <input id="searchByOrder" class="form-control" type="number" placeholder="Number of orders" name="number_of_order">
                        </div>
                        <div class="col-md-2" style="margin-top: 24px;">
                            <button type="submit" class="btn btn-primary" onclick="loadCustomersList()">Filter</button>&nbsp;&nbsp;&nbsp;
                            <button id="resetButton" type="submit" class="btn btn-primary">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="customerList">

                    </div>
                </div>
            </div>
        </div>

    </section>
</main>


<script type="text/javascript">

    $(document).ready(function ()
    {
      loadCustomersList();
    });

    $("#resetButton").click(function ()
    {
      $('#searchByName').val('').change();
      $('#searchByEmail').val('').change();
      $('#searchByPhone').val('').change();
      $('#searchByOrder').val('').change();
      loadCustomersList();
    });

    function showSearchForm()
    {
      $("#searchForm").slideToggle("slow");
    }

    function loadCustomersList()
    {
      $("#customerList").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter = $("#searchForm").serializeArray();
      search_filter.push('_token', '{{ csrf_token() }}');
      $.ajax({
        type: "POST",
        url: "{{ url('/admin/load-customers-list') }}",
        data: search_filter,
        success: function (response)
        {
          $("#customerList").html(response.html);
        }
      });
    }

    function deleteFunction(id)
    {
      bootbox.confirm('Are you sure do you want to delete this customer?', function (result)
      {
        if (result)
        {
          var token = '{{ csrf_token() }}';
          $.ajax({
            type: "POST",
            url: "{{ url('admin/delete-customers') }}",
            data: {_token: token, id: id},
            success: function (response)
            {
              if (response)
              {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.success('Customer deleted successfully', 'Success', {timeOut: 1000});
                $("#customer" + id).remove();
              }
              else
              {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error('Something went wrong', 'Error', {timeOut: 1000});
              }
            }
          });
        }
      });
    }

    function activeInactive(id, status)
    {
      if (status == '1')
      {
        var msg = "Are you sure you want to deactivate this customer?";
      }
      else if (status == '0')
      {
        var msg = "Are you sure you want to activate this customer?";
      }
      bootbox.confirm(msg, function (result)
      {
        if (result)
        {
          $.ajax({
            type: "POST",
            url: "{{url('/admin/active-inactive')}}/" + id,
            data: {'_token': '{{csrf_token()}}'},
            success: function (response)
            {
              if (response)
              {
                toastr.remove();
                toastr.options.closeButton = true;
                loadCustomersList();
                toastr.success('Status updated successfully', 'Success', {timeOut: 2000});
              }
              else
              {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error('Something went wrong', 'Error', {timeOut: 2000});
              }
            }
          });
        }
        else
        {
          if (status == '1')
          {
            $('#enable_a_' + id).attr('checked', true);
          }
          else
          {
            $('#enable_a_' + id).attr('checked', false);
          }
        }
      });
    }

</script>
@stop