@extends('admin::layouts.app')
@section('title', 'MarketPlace : Create Customer')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Create Customer</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/customer')}}">User Management</a></li>
            <li class="active">Create Customer</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Create Customer</h3>
                    </div>
                    <form id="CreateCustomerForm" class="form-horizontal" method="POST" action="{{url('admin/save-customer')}}">
                        {{ csrf_field() }}
                        <input type="hidden" name="user_type" value="customer">
                        <input type="hidden" name="password" value="test123">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="first_name" class="col-sm-3 control-label">First Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="first_name" class="form-control input-lg" placeholder="First Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="last_name" class="col-sm-3 control-label">Last Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="last_name" class="form-control input-lg" placeholder="Last Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email" class="col-sm-3 control-label">Email ID <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="email" class="form-control input-lg" placeholder="Email">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="mobile" class="col-sm-3 control-label">Mobile <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="phone_number" class="form-control input-lg number_only" placeholder="Mobile Number" maxlength="10">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="dob" class="col-sm-3 control-label">DOB <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" readonly name="date_of_birth" class="form-control input-lg" id="datepicker11" placeholder="Date Of Birth" autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="mobile" class="col-sm-3 control-label">Status <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <select class="form-control input-lg" name="status">
                                        <option value="">-- Select --</option>
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button id="addButton" type="submit" class="btn btn-primary pull-right">
                                <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> Add Customer 
                            </button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\CreateCustomerRequest','#CreateCustomerForm') !!}
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $(".number_only").keypress(function (e) {
      if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        return false;
      }
    });
    $('#CreateCustomerForm').on('submit', function (e) {
      if ($("#CreateCustomerForm").valid()) {
        $("#addLoader").show();
        $("#addButton").prop('disabled', true);
      } else {
        $("#addLoader").hide();
        $("#addButton").prop('disabled', false);
      }
    });
    var dt = new Date();
    dt.setFullYear(new Date().getFullYear() - 18);
    $(function ()
    {
      $("#datepicker11").datepicker({
        dateFormat: 'dd/MM/yy',
        maxDate: 0,
        changeMonth: true,
        changeYear: true,
        weekStart: 0,
        calendarWeeks: true,
        autoclose: true,
        todayHighlight: true,
        orientation: "auto",
        endDate: dt,
      });
    });
</script>
@stop