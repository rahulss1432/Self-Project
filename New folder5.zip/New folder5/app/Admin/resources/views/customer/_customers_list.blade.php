<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>No of order</th>
            <th>Created Date</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if(count($customer)>0)
        <?php $i = 1; ?>
        @foreach($customer as $data)
        <?php $sno = $i++; ?>
        <tr id="{{'customer'.$data->id}}">
            <td>{{$sno}}</td>
            <td>{{ucfirst($data->first_name)}} {{ucfirst($data->last_name)}}</td>
            <td>{{$data->email}}</td>
            <td>{{$data->phone_number}}</td>
            <td>{{count($data->customerOrder)}}</td>
            <td>{{$data->created_at}}</td>
            <td>{{$data->is_active == 1 ? 'Active' : 'Inactive' }}</td>
            <td>
                <ul class="list-inline action mb-0">
                    <li>
                        <label class="switch" style="margin-bottom:-15px;">
                            <input id="enable_a_{{$data->id}}" type="radio" onclick="activeInactive({{$data->id}},'{{$data->is_active}}')" value="1" name="radio_{{$data->id}}" @if ($data->is_active=='1')) checked="checked" @endif >
                                   <span class="slider1 round" for="enable_{{$data->id}}"></span>
                        </label>
                    </li>
                    <li>
                        <a class="btn btn-primary" aria-hidden="true" href="{{url('admin/customer-view',$data->id)}}">
                            <i class="fa fa-eye"> View</i>
                        </a>
                    </li>
                    <li>
                        <a class="btn btn-primary" aria-hidden="true" href="{{url('admin/customer-edit',$data->id)}}">
                            <i class="fa fa-pencil-square-o"> Edit</i>
                        </a>
                    </li> 
                    <li>
                        <a class="btn btn-primary" aria-hidden="true" href="javascript:void(0);" onclick="deleteFunction({{$data->id}})">
                            <i class="fa fa-trash-o"> Delete</i>
                        </a>
                    </li>
                </ul>
            </td>
        </tr>
        @endforeach
        @else
        <tr>
            <td colspan="8">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>

<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$customer->links()}}
    </ul>
</div>

<script>
<?php if (count($customer) > 0) { ?>
        $('#btnDownloadCsv').removeClass('disabled');
<?php } ?>
    $(document).ready(function () {
    $(".pagination li a").on('click', function (e) {
    e.preventDefault();
            $("#customerList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
            var $this = $(this);
            var pageLink = $this.attr('href');
            var search_filter = $("#searchForm").serializeArray();
            search_filter.push('_token', '{{ csrf_token() }}');
            $.ajax({
            type: 'POST',
                    url: pageLink,
                    async: false,
                    data: search_filter,
                    success: function (response) {
                    $('.pagination:first').remove();
                            $('#customerList').html(response.html);
                    }
            });
    });
    });
</script>
