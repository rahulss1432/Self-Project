@extends('admin::layouts.app')
@section('title', 'MarketPlace : Customer Details')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Customer Details</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/customer')}}">User Management</a></li>
            <li class="active">Customer Details</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-4">
                <div class="box box-primary">
                    <div class="box-body box-profile">
                        <img class="profile-user-img img-responsive img-circle" src="{{\App\Helpers\Helper::defaultImage($customer->profile_picture,'profile_image')}}">
                        <h3 class="profile-username text-center">{{$customer->first_name}} {{$customer->last_name}}</h3>
                        <ul class="list-group list-group-unbordered">
                            <li class="list-group-item">
                                <b>Contact No.</b> <a class="pull-right">{{(!empty($customer->phone_number)) ? $customer->phone_number :'-'}}</a>
                            </li>
                            <li class="list-group-item">
                                <b>DOB</b> <a class="pull-right">{{(!empty($customer->date_of_birth)) ? $customer->date_of_birth :'-'}}</a>
                            </li>
                            <li class="list-group-item">
                                <b>Email</b> <a class="pull-right">{{$customer->email}}</a>
                            </li>
                            <li class="list-group-item">
                                <b>Status</b> 
                                @if($customer->is_active == '1')
                                <a class="pull-right">Active</a>
                                @else
                                <a class="pull-right">Inctive</a>
                                @endif
                            </li>
                        </ul>
                    </div>
                    <div class="box-body">
                        <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
                        <p class="text-muted">{{(!empty($customer->address)) ? $customer->address :'-'}}</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
@stop