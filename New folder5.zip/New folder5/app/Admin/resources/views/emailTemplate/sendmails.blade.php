@extends('admin::layouts.app')
@section('title', 'MarketPlace : Email Template Management')
@section('content')
<script src="{{url('public/js/tinymce/tinymce.min.js') }}"></script>
<script type="text/javascript">
tinymce.init({
  theme: "modern",
  selector: "textarea",
  setup: function (ed) {
    ed.on("keyup", function () {
      $('.desc-error').html("");
      $('#mceu_14').css('border-color', '#00a65a');
      $('.desc-lebel').css('color', '#00a65a');
    });
  },
  relative_urls: false,
  remove_script_host: false,
  height: 200,
  plugins: "image code",
  font_formats: 'Andale Mono=andale mono,times;Arial=arial,helvetica,sans-serif;Arial Black=arial black,avant garde;Book Antiqua=book antiqua,palatino;Comic Sans MS=comic sans ms,sans-serif;Courier New=courier new,courier;Georgia=georgia,palatino;Helvetica=helvetica;Impact=impact,chicago;Symbol=symbol;Tahoma=tahoma,arial,helvetica,sans-serif;Terminal=terminal,monaco;Times New Roman=times new roman,times;Trebuchet MS=trebuchet ms,geneva;Verdana=verdana,geneva;Webdings=webdings;Wingdings=wingdings,zapf dingbats',
});</script>
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>  Send Email </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Send Email</li>
         </ol>
    </section>
    <section class="page_content">
        <div class="col-sm-12">
            <div class="col-sm-2"></div>
            <div class="col-sm-8" style="margin-top: 20px;box-shadow: 0px 1px 4px 2px #888888;">
                <form id="templatetForm" method="post" class="form-horizontal" action="{{url('admin/save-template')}}" style="padding-top:20px;">
                    {{ csrf_field() }}
                   <div class="form-group">
                         <label class="control-label col-sm-2 desc-lebel">Select Template<span class="error-star">*</span> </label>
                         <div class="col-sm-10">
                        <select class="selectpicker form-control"  name="templates" data-size="6" title="Select Template" onchange="load_templates(this.value);">
                            <option value="">Select Template</option>
                            @foreach($templates as $temp)
                            <option value="{{$temp->id}}">{{$temp->page_title}}</option>
                            @endforeach
                        </select>
                         </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Subject <span class="error-star">*</span></label>
                        <div class="col-sm-10">
                            <input type="text" name="subject" id="subject" class="form-control" placeholder="Subject" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2 desc-lebel">Email Title <span class="error-star">*</span></label>
                        <div class="col-sm-10">
                            <textarea name="description" id="description"></textarea>
                            <span class="desc-error"></span>
                        </div>
                    </div>
                    <div class="form-group">
                         <label class="control-label col-sm-2 desc-lebel">Select User<span class="error-star">*</span> </label>
                         <div class="col-sm-10">
                        <select class="selectpicker form-control" onchange="$(this).valid()" name="users" data-size="6" title="Select user">
                            <option value="">Select user Type</option>
                            <option value="customers">All Customers</option>
                            <option value="drivers">All Drivers</option>
                            <option value="vendors">All Vendors</option>
                            <option value="Subscribed">Subscribed User</option>
                        </select>
                         </div>
                    </div> 
                    <div class="form-group text-center">
                        <label class="control-label col-sm-1"></label>
                        <div class="col-sm-10">
                            <button id="btn-content" type="submit" class="btn btn-info text-right submitButton">
                                Send <i id="add-loader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Admin\Http\Requests\SendMailRequest','#templatetForm') !!}
            </div>
            <div class="col-sm-2"></div>
        </div>
    </section>
</main>
<script>
    $('#templatetForm').on('submit', function (e) {
      $('.desc-error').html("");
      $('#mceu_14').css('border-color', '#00a65a');
      $('.desc-lebel').css('color', '#00a65a');
      var editorContent = tinyMCE.get('description').getContent();
      if (editorContent == '')
      {
        $('.desc-error').css('color', '#dd4b39').html("Email Title is required");
        $('#mceu_14').css('border-color', '#dd4b39');
        $('.desc-lebel').css('color', '#dd4b39');
        return false;
      } else {
        return true;
      }
      if ($('#templatetForm').valid()) {
        $('#add-loader').show();
        document.getElementById("btn-content").disabled = true;
      } else {
        $('#add-loader').hide();
        document.getElementById("btn-content").disabled = false;
      }
    });
     function load_templates(templateId) {
        var token = '{{ csrf_token() }}';
        $.ajax({
            url: "{{url('/admin/get-templates')}}",
            type: 'POST',
            data: {_token: token, templateId: templateId},
            success: function (data) {
                tinymce.activeEditor.setContent(data.html.page_description);
             },
            error: function (data) {
                console.log('an error occurred');
            }
        });


    }
</script>
@stop