@extends('admin::layouts.app')
@section('title', 'MarketPlace : Email Template Management')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Email Template Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/email-templates')}}">Email Template Management</a></li>
            <li class="active">Template Listing</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row">
                    <div class="col-sm-12 col-sm-offset-0">
                        <a class=" btn btn-primary pull-right" href="{{url('/admin/create-template')}}"> <i class="fa fa-plus-circle"></i> Create Template</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="template_list">

                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $().ready(function () {
      load_templates_list();
    });
    function load_templates_list() {
      var loader = '<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>';
      var url = "{{url('admin/load-template-list')}}";
      $.ajax({type: "GET", url: url,
        beforeSend: function () {
          $('#template_list').html(loader);
        },
        success: function (data) {
          $("#template_list").html(data.html);
        }
      });
    }
    
    function delete_template(id) {
            bootbox.confirm('Are you sure you want to delete', function (result) {
            if (result) {
            var token = '{{ csrf_token() }}';
            $.ajax({type: "POST",
            url: "{{ url('/admin/delete-template') }}",
            data: {_token: token, id: id},
            success: function (response) {
            if (response)
            {
              toastr.remove();
              toastr.options.closeButton = true;
             load_templates_list();
              toastr.success('Template deleted successfully', 'Success', {timeOut: 2000});
            }
            else
            {
              toastr.remove();
              toastr.options.closeButton = true;
              toastr.error('Something went wrong', 'Error', {timeOut: 2000});
            }
            }

            });
        }
        });
    }
</script>
@stop