<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Title</th>
            <!--<th>Description</th>-->
            <th>Created At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if($templateData->count()>0)
        <?php $i = 1; ?>
        @foreach($templateData as $cnt)
        <?php $sno = $i++; ?>
        <tr id="tr_{{$cnt->id}}">
            <td>{{ $sno }}</td>
            <td>{{ $cnt->page_title }}</td>
            <!--<td>{!! $cnt->page_description !!}</td>-->
            <td>{{date("M-d-Y", strtotime($cnt->created_at)) }}</td>
            <td>
                <a href="{{url('admin/edit-template/'.$cnt->id)}}" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i> Edit</a>
                <a href="javascript:void(0);" onclick="delete_template('{{$cnt->id}}');" class="btn btn-primary"><i class="fa fa-trash"></i> Delete</a>
            </td>
        </tr>
        @endforeach
        @else 
        <tr>
            <td colspan="5">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>

<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$templateData->links()}}
    </ul>
</div>




<script>
    $(document).ready(function () {
      $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        var loader = '<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>';
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({type: 'GET', url: pageLink, async: false,
          beforeSend: function () {
            $('#templatet_list').html(loader);
          },
          success: function (response) {
            $('.pagination:first').remove();
            $('#templatet_list').html(response.html);
          }
        });
      });
    });
</script>

