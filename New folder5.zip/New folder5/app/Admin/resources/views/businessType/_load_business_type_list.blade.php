<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Name</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if(count($businessData) > 0) 
        <?php $i = 1; ?>
        @foreach($businessData as $val)
        <?php
        if ($businessData->currentPage() == 1) {
            $srNo = $i++;
        } else {
            $srNo = ($businessData->currentPage() - 1) * $businessData->perPage() + $i++;
        }
        ?>
        <tr id="tr_{{$val->id}}">
            <td class="col-sm-3">{{ $srNo }}</td>
            <td class="col-sm-3">{{ $val->business_name }}</td>
            <td class="col-sm-3">
                <label class="switch">
                    <input id="enable_a_{{$val->id}}" type="radio" onclick="activeBusinessInactive({{$val->id}},'{{$val->status}}')" value="1" name="radio_{{$val->id}}" @if ($val->status=='active')) checked="checked" @endif >
                           <span class="slider1 round" for="enable_{{$val->id}}"></span>
                </label>
            </td>
            <td class="col-sm-3">
                <a href="{{url('admin/edit-business-type/'.$val->id)}}" class="btn btn-primary"><i class="fa fa-pencil-square-o"> Edit</i></a>
                <a href="javascript:void(0);" onclick="deleteBusinessType('{{$val->id}}');" class="btn btn-primary"><i class="fa fa-trash-o"> Delete</i></a>
            </td>
        </tr>
        @endforeach
        @else 
        <tr>
            <td colspan="4">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>

<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$businessData->links()}}
    </ul>
</div>
<script>
                    $(document).ready(function () {
            $(".pagination li a").on('click', function (e) {
            e.preventDefault();
                    $("#loadBusinessTypeList").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
                    var $this = $(this);
                    var pageLink = $this.attr('href');
                    var token = '{{ csrf_token() }}';
                    var txtSearch = $("#txtSearch").val();
                    $.ajax({type: 'POST', url: pageLink, data: {_token: token, txtSearch: txtSearch},
                            success: function (response) {
                            $('.pagination:first').remove();
                                    $("#loadBusinessTypeList").html(response.html);
                            }
                    });
            });
            });
</script>

