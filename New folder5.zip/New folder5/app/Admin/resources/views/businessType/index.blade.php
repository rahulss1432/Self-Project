@extends('admin::layouts.app')
@section('title', 'MarketPlace : Business Management')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Business Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('/admin/business-type')}}">Business Management</a></li>
            <li class="active">Business Type Listing</li>
        </ol>
    </section>    
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" onclick="showSerach()" id="filterbtn" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class=" btn btn-primary" href="{{url('/admin/create-business-type')}}"> <i class="fa fa-plus-circle"></i>  Create Business Type</a>
                        </div>
                    </div>
                </div>
                <form id="searchField" style="display: none;" action="javascript:void(0);">
                    <div class="row">
                        <div class="col-md-4">
                            <label> Name</label> 
                            <input class="form-control" id="txtSearch" name="txtSearch" type="text" placeholder="Name" onchange="loadBusinessType();">
                        </div>
                        <div class="col-md-2">
                            <br>
                            <button id="btn-sub" type="submit" class="btn btn-primary " onclick="loadBusinessType();">
                                Filter <i class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                            <button id="btn-sub" type="submit" class="btn btn-primary" onclick="resetFilter();">
                                Reset <i class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="loadBusinessTypeList">
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script type="text/javascript">
    $(document).ready(function () {
      $("#txtSearch").keypress(function (e) {
        if (e.which == 13) {
          loadBusinessType();
        }
      });
      loadBusinessType();
    });

    function loadBusinessType() {
      var txtSearch = $("#txtSearch").val();
      var token = '{{ csrf_token() }}';
      $("#loadBusinessTypeList").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      $.ajax({
        type: "POST",
        url: "{{ url('/admin/load-business-list') }}",
        data: {_token: token, search: txtSearch},
        success: function (response)
        {
          $("#loadBusinessTypeList").html(response.html);
        }
      });
    }

    function activeBusinessInactive(id, status) {
      if (status == 'active') {
        var msg = "Are you sure you want to deactivate this bussiness type?";
      } else if (status == 'inactive') {
        var msg = "Are you sure you want to activate this bussiness type?";
      }
      bootbox.confirm(msg, function (result) {
        if (result) {
          $.ajax({
            type: "POST",
            url: "{{url('/admin/change-business-type-status')}}/" + id,
            data: {'_token': '{{csrf_token()}}'},
            success: function (response)
            {
              if (response) {
                toastr.remove();
                toastr.options.closeButton = true;
                loadBusinessType();
                toastr.success("{{\Config::get('constants.change_status')}}", 'Success', {timeOut: 2000});
              } else {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error("{{\Config::get('constants.something_wrong')}}", 'Error', {timeOut: 2000});
              }
            }
          });
        }
        else {
          if (status == 'active') {
            $('#enable_a_' + id).attr('checked', true);
          } else {
            $('#enable_a_' + id).attr('checked', false);
          }
        }
      });
    }

    function deleteBusinessType(id) {
      bootbox.confirm('Are you sure do you want to delete Business type?', function (result)
      {
        if (result)
        {
          $.ajax({
            type: "GET",
            url: "{{url('/admin/delete-business-type')}}/" + id,
            success: function (response)
            {
              if (response) {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.success("{{\Config::get('constants.delete_business_type')}}", 'Success', {timeOut: 1000});
                $("#tr_" + id).hide(500);
              }
              else {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error("{{\Config::get('constants.something_wrong')}}", 'Error', {timeOut: 1000});
              }
            }
          });
        }
      });
    }

    function showSerach() {
      $("#searchField").slideToggle("slow");
    }

    function resetFilter() {
      $('#searchField')[0].reset();
      $('.selectpicker').selectpicker('refresh');
      loadBusinessType();
    }
</script>
@stop