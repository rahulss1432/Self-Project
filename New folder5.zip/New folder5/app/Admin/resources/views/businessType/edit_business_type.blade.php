@extends('admin::layouts.app')
@section('title', 'MarketPlace : Edit Business Type')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Business Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/business-type')}}">Business Management</a></li>
            <li class="active">Edit Business</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Business Type</h3>
                    </div>
                    <form id="editBusinessTypeForm" class="form-horizontal" method="POST" action="{{url('admin/update-business-type')}}">
                        {{ csrf_field() }}
                        <input type="hidden" name="id" value="{{$businessData->id}}">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="business_name" class="col-sm-3 control-label">Business Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="business_name" class="form-control input-lg" value="{{$businessData->business_name}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="status" class="col-sm-3 control-label">Status <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <select class="form-control input-lg" name="status">
                                        <option value="">Select</option>
                                        <option value="active"<?php if ($businessData->status == 'active') echo 'selected'; ?>>Active</option>
                                        <option value="inactive"<?php if ($businessData->status == 'inactive') echo 'selected'; ?>>Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <center>
                                <button id="btnBussinessType" type="submit" class="btn btn-primary pull-right">Update Business Type
                                    <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                                </button>
                            </center>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\EditBusinessTypeRequest','#editBusinessTypeForm') !!}
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $('#editBusinessTypeForm').on('submit', function (e) {
      if ($('#editBusinessTypeForm').valid()) {
        $('#addLoader').show();
        $('#btnBussinessType').prop('disabled', true);
      } else {
        $('#addLoader').hide();
        $('#btnBussinessType').prop('disabled', false);
      }
    });
</script>
@stop