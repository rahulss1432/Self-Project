<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>@yield('title')</title>       
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <!-- <link rel="stylesheet" href="{{ url('/public/css/jquery.dataTables.min.css')}}"> -->
        <link rel="stylesheet" href="{{ url('/public/css/dataTables.bootstrap.min.css')}}">
        <link rel="stylesheet" href="{{asset('public/css/bootstrap.min.css')}}">
        <link rel="stylesheet" href="{{asset('public/css/font-awesome.min.css')}}">
        <link rel="stylesheet" href="{{asset('public/css/ionicons.min.css')}}">
        <link rel="stylesheet" href="{{asset('public/css/AdminLTE.min.css')}}">
        <link rel="stylesheet" href="{{asset('public/css/_all-skins.min.css')}}">
        <link rel="stylesheet" href="{{asset('public/css/toastr.css')}}">   
        <link rel="stylesheet" href="{{ url('/public/css/bootstrap-slider.min.css')}}">
        <link rel="stylesheet" href="{{ url('/public/css/bootstrap-select.min.css')}}">           
        <link rel="stylesheet" href="{{ url('/public/css/admin.min.css')}}">
        <link rel="stylesheet" href="{{asset('public/css/basic.css')}}">
        <link rel="stylesheet" href="{{asset('public/css/dropzone.css')}}">
        <link rel="stylesheet" href="{{ url('/public/css/bootstrap-select.min.css')}}">
        <link rel="stylesheet" href="<?php echo url('public/css/chosen.min.css') ?>" type="text/css">

        <link rel="stylesheet"  href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
        <link rel="stylesheet" href="{{ url('/public/css/select2.min.css')}}">
        <link rel="stylesheet" href="{{url('public/css/jquery-ui.css')}}">   
        <link rel="stylesheet" href="{{ url('/public/css/cropper.css')}}">    
        <link rel="stylesheet" href="{{ url('/public/css/jquery.rateyo.min.css')}}"> 
        <link rel="stylesheet" href="{{ url('/public/css/sweetalert.css')}}">
        <style>
            .pagination>.active>a, .pagination>.active>a:focus, .pagination>.active>a:hover, .pagination>.active>span, .pagination>.active>span:focus, .pagination>.active>span:hover {
                background-color: #605ca8;
                border-color: #605ca8;
            }
        </style>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC6UvgQK_Ua6wHk9J5Up0IcGJVPvko1lvI&libraries=drawing,places"></script>
    </head>
    <body class="hold-transition skin-purple sidebar-mini">
        <div class="wrapper">

            @include('admin::layouts.include.adminheader')
            @include('admin::layouts.include.adminsidebar')

            <div class="content-wrapper">
                @yield('content')
            </div>



            @include('admin::layouts.include.footer')

            <div class="control-sidebar-bg"></div>
        </div>
    </body>
    <script>
//$(document).ready(function(){
$.validator.setDefaults({
//    ignore: [],           // any other default options and/or rules
  ignore: ":hidden:not(.do-not-ignore)", // not ignoring validation where .do-not-ignore class is used
});
// });
    </script>
    @if(session()->has('success'))
    <script>
        $(document).ready(function () {
          toastr.remove();
          toastr.options.closeButton = true;
          toastr.success("{!! session('success') !!}", 'Success', {timeOut: 2000});
        });
    </script>
    @endif
    @if(session()->has('error'))
    <script>
        $(document).ready(function () {
          toastr.remove();
          toastr.options.closeButton = true;
          toastr.error("{!! session('error') !!}", 'Error', {timeOut: 2000});
        });
    </script>
    @endif
</html>
