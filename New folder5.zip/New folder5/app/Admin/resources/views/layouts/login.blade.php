<!DOCTYPE HTML>
<html lang="{{ app()->getLocale() }}">
    <head>
        <title> Editor : Login</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <meta name="format-detection" content="telephone=no">
        <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link rel="stylesheet" href="<?php echo url('public/css/bootstrap.min.css') ?>" type="text/css"> 
        <link rel="stylesheet" href="<?php echo url('public/css/bootstrap-select.min.css') ?>" type="text/css"> 
        <link rel="stylesheet" href="<?php echo url('public/css/jquery.mCustomScrollbar.css') ?>" type="text/css"> 
        <link rel="stylesheet" href="<?php echo url('public/css/admin.min.css') ?>" type="text/css"> 
        <link rel="stylesheet" href="<?php echo url('public/css/themify-icons.css') ?>" type="text/css"> 
        
        
        <script src='<?php echo url('public/js/jquery.min.js') ?>'></script>
        <script src='<?php echo url('public/js/bootstrap.min.js') ?>'></script>
        <script src='<?php echo url('public/js/app.js') ?>'></script>
        <script src='<?php echo url('public/js/jsvalidation.js') ?>'></script>
      
    </head>

    <body class="loginpage">
        <div id="app">
        
        @yield('content')
    </body>
</html>
