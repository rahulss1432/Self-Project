@php
$id = Auth::guard('admin')->user()->id;
$unreadnotifications =\App\Models\OrderNotification::getAllNotificationsByIdcount($id); 
$notifications =\App\Models\OrderNotification::getAllNotificationsById($id); 
@endphp

<header class="main-header">
    <a href="{{url('/admin/admin-dashboard') }}" class="logo">
        <span class="logo-mini"><b>M</b>P</span>
        <span class="logo-lg"><b>Market</b>Place</span>
    </a>
    <nav class="navbar navbar-static-top">
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </a>
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <li class="dropdown notifications-menu">
                    <a href="javascript:void(0)" class="dropdown-toggle" onclick="loadNotification('bell_button')" data-toggle="dropdown" aria-expanded="true">
                        <i class="fa fa-bell-o"></i>
                        <span class="label label-danger">{{count($unreadnotifications)}}</span>
                    </a>
                    <ul class="dropdown-menu" id="notification">
                    </ul>
                </li>                
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </a>
                    <ul class="dropdown-menu">
                        <li >
                            <a href="{{ url('/admin/my-profile') }}" >
                                <i class="fa fa-user" aria-hidden="true"></i> My Profile
                            </a>
                            <a href="{{ url('/admin/change-password') }}">
                                <i class="fa fa-lock" aria-hidden="true"></i> Change Password
                            </a>
                            <form id="logout-form" action="{{ url('/admin/logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                        </li>
                        <li>
                            <a href="{{url('/admin/logout') }}"  onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                <i class="fa fa-power-off" aria-hidden="true"></i> Logout
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>

    <script src="{{asset('public/js/jquery-2.2.3.min.js')}}"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.9.1.js"></script>

    <!--=============newly added JS starts==============-->    
    <script src="{{asset('public/js/bootstrap-select.min.js')}}"></script>
    <script src="{{asset('public/js/jquery.form.js')}}"></script> 
    <script src="{{asset('public/js/jquery.slimscroll.min.js')}}"></script>
    <script src="{{asset('public/js/fastclick.js')}}"></script>
    <script src="{{asset('public/js/app.min.js')}}"></script>
    <script src="{{asset('public/js/demo.js')}}"></script>
    <script src="{{asset('public/js/toastr.js')}}"></script>
    <script src="{{ asset('/public/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{ asset('/public/js/dataTables.bootstrap.min.js')}}"></script>
    <script src="{{asset('public/js/jsvalidation.js')}}"></script>
    <script src="{{asset('public/js/bootbox.min.js')}}"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>  
    <script>$.fn.slider = null</script>
    <script src="{{asset('public/js/bootstrap-slider.min.js')}}"></script>
    <script src="{{asset('public/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('public/js/select2.min.js')}}"></script> 
    <script src='<?php echo url('public/js/chosen.jquery.min.js') ?>'></script>
    <script src='<?php echo url('public/js/chosen.proto.min.js') ?>'></script>
    <link rel="stylesheet" href="{{ url('/public/css/bootstrap-datepicker.min.css')}}">
    <link rel="stylesheet" href="{{ url('/public/css/themify-icons.css')}}">
    <script src="{{asset('public/js/timepicker-moment.js')}}"></script>
    <script src="{{asset('public/js/bootstrap-datepicker.min.js')}}"></script>
    <script src="{{asset('public/js/timepicker.js')}}"></script>
    <script src="{{asset('public/js/cropper.min.js')}}"></script>
    <script src="{{asset('/public/js/ajaxupload.3.5.js')}}"></script>    
    <script  src='{{asset('public/js/jquery.rateyo.js')}}'></script> 
    <script  src='{{asset('public/js/sweetalert.js')}}'></script> 
    <!--=============newly added JS ends==============-->
</header>
<script>
$(document).ready(function() {
    $("#datepicker").datepicker({
        dateFormat: 'dd/MM/yy',
        maxDate: 0,
        endDate: "today",
        changeMonth: true,
        changeYear: true,
        weekStart: 0,
        calendarWeeks: true,
        autoclose: true,
        todayHighlight: true,
        orientation: "auto",
    });
    
setInterval(CheckOrderStatusTimer, 10000);
});
function loadNotification(callFrom) {
    $.ajax({
        url: "{{url('admin/load-all-notifications')}}",
        type: 'POST',
        data: {
            _token: '{{ csrf_token() }}',
            call_from: 'bell_button'
        },
        success: function(response) {
            if (response.success) {
                $('#notification').html(response.html);
            } else {
                toastr.options.closeButton = true;
                toastr.error('message', response.message, {
                    timeOut: 1000
                });
            }
        }
    });
}

/* function for order status check if still pending or not */
function CheckOrderStatusTimer() {
    $.ajax({
        url: "{{url('admin/check-all-order-status')}}",
        type: 'GET',
        success: function(response) {
        }
    });
}          
</script>

<!-- =============================================== -->