@php $menuList  = \App\Models\Privilege::getAllMenuList();@endphp
<style>
    #dashboardmenu{
        padding-left: 0px;
        padding-top: 0px;
        line-height: 28px;
    }
    #dashboardmenu li a span {
        margin-top: -38px;
        margin-left: 10px;
    }
    #dashboardmenu li a:hover{
        color: #fff;
        background: #1e282c;
        border-left: 3px solid #605ca8;
    }
    .activate{
        background-color: #1e282c;
        color: #fff;
        border-left: 3px solid #605ca8;
    }
    .skin-purple .sidebar-menu li .activate{
        background-color: #1e282c;
        color: #fff !important;
        border-left: 3px solid #605ca8 !important;
    }
</style>
<aside class="main-sidebar">
    <section class="sidebar">
        <ul class="sidebar-menu main-menu">
            @foreach($menuList as $menu)
            @if(($menu->action != '#') && ($menu->parent_id != 3))
            <li class="treeview {{ ( \Request::route()->getName() == $menu->action) ? 'active' : '' }}">
                <a href="<?php echo url($menu->action) ?>">
                    <i class="{{$menu->icon}}"></i> <span>{{$menu->name}}</span>
                    <span class="pull-right-container"></span>
                </a>
            </li>
            @else
            <li class="treeview">
                <?php if (($menu->action == '#')) { ?>
                    <a data-target="#dashboardmenu" href="<?php echo url($menu->action) ?>" data-toggle="collapse" data-parent="#MainMenu" aria-expanded="false" aria-controls="dashboardmenu">
                        <i class="{{$menu->icon}}"></i> <span>{{$menu->name}}</span>
                        <span class="pull-right-container"></span>
                        &nbsp; &nbsp;<i class="fa fa-caret-down"></i>
                    </a>
                <?php } ?>
                <ul class="nav collapse" id="dashboardmenu">
                    @foreach($menuList as $menu1)
                    <?php if (($menu1->parent_id == 3)) { ?>
                        <li>
                            <a class="collapseLink" href="<?php echo url($menu1->action) ?>"><i class="{{$menu1->icon}}"></i> <span>{{$menu1->name}}</span></a>
                        </li>
                    <?php } ?>
                    @endforeach
                </ul>
            </li>
            @endif
            @endforeach
        </ul>
    </section>
</aside>
<script>
    jQuery(document).ready(function ($) {
      var baseUrl = "{{url('')}}";
      var path = window.location.pathname.split("/").pop();
      var path1 = window.location.href;
      var page = path1.split('/');
      var idBased = page[page.length - 2];
      var target = $('.nav a[href="' + path1 + '"]');
      if (path == "vendor-list" || path == "create-vendor" || idBased == "vendor-details" || idBased == "edit-vendor" || idBased == "change-vendor-password") {
        $('#dashboardmenu').addClass('in');
        var target = $('.nav a[href="' + baseUrl + '/admin/vendor-list"]');
        target.addClass('activate');
      } else if (path == "drivers-list" || path == "create-driver" || idBased == "driver-edit" || idBased == "driver-detail" || idBased == "driver-vehicle-deatail") {
        $('#dashboardmenu').addClass('in');
        var target = $('.nav a[href="' + baseUrl + '/admin/drivers-list"]');
        target.addClass('activate');
      } else if (path == "customer" || path == "create-customer" || idBased == "customer-edit" || idBased == "customer-view") {
        $('#dashboardmenu').addClass('in');
        var target = $('.nav a[href="' + baseUrl + '/admin/customer"]');
        target.addClass('activate');
      }
    });
</script>