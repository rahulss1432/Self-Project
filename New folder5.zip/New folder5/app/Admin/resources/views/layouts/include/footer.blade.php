<footer class="main-footer">    
    <strong>Copyright © {{date("Y")}} Technology West Group, LLC. All rights reserved.</strong>
</footer>

