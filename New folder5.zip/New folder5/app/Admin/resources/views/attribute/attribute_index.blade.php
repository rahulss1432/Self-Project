@extends('admin::layouts.app')
@section('title', 'MarketPlace : Attribute Management')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Attribute Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/attribute-list')}}">Attribute Management</a></li>
            <li class="active">Attribute Listing</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <span style="padding-bottom:10px;float:right;margin-right: 10px;">
                            <button type="button" class="btn btn btn-primary" onclick="showSerach()" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class="btn btn-primary" href="{{url('admin/attribute')}}"><i class="fa fa-plus-circle"></i> Create Attribute</a>
                        </span>
                    </div>
                </div>
                <form id="searchField" style="display: none;" action="javascript:void(0);" onsubmit="loadAttrsList();">
                    {{ csrf_field()}}
                    <div class="row">
                        <div class="col-md-4">
                            <label> Name of product</label> 
                            <input type="text" class="form-control" name="attrSearch" placeholder="search attribute" id="attrSearch">
                        </div>
                        <div class="col-md-2">
                            <br>
                            <button id="btn-sub" type="button" class="btn btn-primary " onclick="loadAttrsList();">
                                Filter <i id="add-loader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                            <button id="btn-sub" type="button" class="btn btn-primary" onclick="resetFilter();">
                                Reset <i id="add-loader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="" id="attrList" style="margin-top: 10px;"></div>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $().ready(function () {
      loadAttrsList();
    });
    function loadAttrsList() {
      var loader = '<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>';
      var url = "{{url('admin/load-attribute-list')}}";
      var attrSearch = $("#attrSearch").val();
      var token = '{{ csrf_token() }}';
      $.ajax({type: "POST", url: url, data: {_token: token, attrSearch: attrSearch},
        beforeSend: function () {
          $('#attrList').html(loader);
        },
        success: function (data) {
          $("#attrList").html(data.html);
        }
      });
    }

    function deleteAttr(id) {
      bootbox.confirm('Are you sure you want to delete?', function (result) {
        if (result) {
          var token = '{{ csrf_token() }}';
          $.ajax({type: "POST",
            url: "{{ url('admin/delete-attributes') }}",
            data: {_token: token, id: id},
            success: function (response) {
              if (response)
              {
                $("#tr_" + id).hide(500);
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.success("{{\Config::get('constants.delete_attribute')}}", 'Success', {timeOut: 2000});
              } else {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error("{{\Config::get('constants.something_wrong')}}", 'Error', {timeOut: 2000});
              }
            }
          });
        }
      });
    }

    function resetFilter() {
      $('#searchField')[0].reset();
      loadAttrsList();
    }

    function showSerach() {
      $("#searchField").slideToggle("slow");
    }
</script>
@stop
