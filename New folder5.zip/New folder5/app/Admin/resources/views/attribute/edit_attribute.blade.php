@extends('admin::layouts.app')
@section('title', 'MarketPlace : Edit Attribute')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Attribute Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/attribute-list')}}">Attribute Management</a></li>
            <li class="active">Edit Attribute</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Attribute</h3>
                    </div>
                    <form id="frmEditAttrForm" method="post" class="form-horizontal" action="{{url('admin/update-attribute')}}" style="padding-top:20px;">
                        {{ csrf_field() }}
                        <input type="hidden" name="attributeId" id="attributeId" value="{{$attrData->id}}">
                        <div class="box-body">
                            <div class="form-group">
                                <label class="control-label col-sm-4">Attribute Name <span class="error-star">*</span></label>
                                <div class="col-sm-6">
                                    <input type="text" name="attribute_name" id="attrbuteName" class="form-control attr_color required" onblur="onlyColor(this.value)" placeholder="Attribute Name" autocomplete="off" value="{{$attrData->attribute_name}}">
                                    <span></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-4"></label>
                                <div class="col-sm-6" style="text-align: right;">
                                    <div class="add_button clearfix">
                                        <button class="btn btn-primary" type="button" onclick="addMore()">Add Value</button>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2"></label>
                                <div class="col-sm-8">
                                    <table id="option-value" class="table table-bordered value_table">
                                        <thead>
                                            <tr>
                                                <th class="text-left">Name</th>
                                                <th class="text-left">Value</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $optionData = \App\Models\OptionValue::getOptionValues($attrData->id); ?>
                                            <?php
                                            $counter = 1;
                                            foreach ($optionData as $val) {
                                                ?>
                                                <tr id="tr_{{$counter}}">
                                                    <td class="text-left">
                                                        <input type="text" name="option_name[]" id="option_value_{{$counter}}" value="<?php echo $val->option_name; ?>" placeholder="Option Value" class="form-control required">
                                                        <span></span>
                                                    </td>
                                                    <?php
                                                    $style = "display:none";
                                                    $optionName = $attrData->attribute_name;
                                                    if ($optionName == "Color" || $optionName == "color" || $optionName == "COLOR") {
                                                        $style = "display:block";
                                                        ?>
                                                        <td class="text-left">
                                                            <input type="text" name="option_value[]" value="<?php echo $val->option_value; ?>" id="color_{{$counter}}" placeholder="Color Code" class="form-control color required" style="<?php echo $style; ?>">
                                                            <span></span>
                                                        </td>
                                                    <?php } else { ?>
                                                        <td class="text-left">
                                                            <input type="text" name="option_value[]" value="" id="color_{{$counter}}" placeholder="Color Code" class="form-control color" style="display:none;">
                                                            <span></span>
                                                        </td>
                                                    <?php } ?>
                                                    <td class="text-center">
                                                        <?php if (!empty($val->option_name) || !empty($val->option_value)) { ?>
                                                            <a href="javascript:void(0);" onclick="deleteRow('{{$counter}}')">Remove</a>
                                                        <?php } ?>
                                                    </td>
                                                </tr>
                                                <?php
                                                $counter++;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <center>
                                <button id="btnAttr" type="submit" class="btn btn-primary pull-right submitButton">
                                    <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> Update Attribute
                                </button>
                            </center>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\CreateAttributeRequest','#frmEditAttrForm') !!}
                </div>
            </div>
            <div class="col-sm-3"></div>
        </div>
    </section>
</main>
<script>
                    $(function () {
                    $('input').blur(function () {
                    $(this).val($.trim($(this).val()));
                    });
                            $('form#frmEditAttrForm .submitButton').click(function (event) {
                    var flag = 0;
                            $(".required").each(function () {
                    event.preventDefault();
                            if ($(this).val().trim() == "") {
                    $(this).next('span').css('color', 'red').html("This field is required");
                            flag++;
                    }
                    });
                            $('.required').keyup(function () {
                    $(this).next('span').css('color', 'green').html("");
                    });
                            if (flag == 0) {
                    $("#frmEditAttrForm").submit();
                    }
                    });
                            $('#frmEditAttrForm').on('submit', function (e) {
                    if ($('#frmEditAttrForm').valid()) {
                    $('#addLoader').show();
                            $("#btnAttr").prop('disabled', true);
                    } else {
                    $('#addLoader').hide();
                            $("#btnAttr").prop('disabled', false);
                    }
                    });
                    });
                    var counter = $('#option-value').find('tbody').find('tr').length + 1;
                    function addMore() {
                    var optionValue = $("#attrbuteName").val();
                            if (optionValue == 'COLOR' || optionValue == 'color' || optionValue == 'Color') {
                    var value = "block";
                            var inputClass = 'required';
                    } else {
                    var value = "none";
                            var inputClass = '';
                    }
                    var newTextBoxDiv = $(document.createElement('tr')).attr("id", 'tr_' + counter);
                            newTextBoxDiv.after().html('<td class="text-left"><input type="text" name="option_name[]" id="option_value_' + counter + '" value="" placeholder="Option Value" class="form-control required"><span></span></td><td class="text-left"><input type="text" name="option_value[]" value="" id="color_' + counter + '" placeholder="Color Code" class="form-control color ' + inputClass + '" style="display:' + value + '"><span></span></td><td class="text-center"><a href="javascript:void(0);" onclick="deleteRow(' + counter + ')">Remove</a></td>');
                            newTextBoxDiv.appendTo("#option-value");
                            counter++;
                    }

            function deleteRow(id) {
            $("#tr_" + id).remove();
            }

            function onlyColor(value) {
            if (value == "COLOR" || value == "color" || value == "Color") {
            $(".color").show();
                    $("#color_1").addClass('required');
            } else {
            $("#color_1").next('span').html('');
                    $("#color_1").removeClass('required');
                    $(".color").hide();
            }
            }
</script>
@stop