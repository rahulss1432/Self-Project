<table class="table table-hover">
    <thead>
        <tr>
            <th class="col-sm-4">S.No.</th>
            <th class="col-sm-4">Name</th>
            <th class="col-sm-4">Action</th>
        </tr>
    </thead>
    <tbody>
        @if($attrData->count()>0)
        <?php $i = 1; ?>
        @foreach ($attrData as $attr)
        <?php
        if ($attrData->currentPage() == 1) {
            $srNo = $i++;
        } else {
            $srNo = ($attrData->currentPage() - 1) * $attrData->perPage() + $i++;
        }
        ?>
        <tr id="tr_{{$attr->id}}">
            <td>{{ $srNo }}</td>
            <td>{{ $attr->attribute_name }}</td>
            <td><a href="{{url('admin/edit-attribute/'.$attr->id)}}" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i> Edit</a>
                <a href="javascript:void(0);" onclick="deleteAttr('{{$attr->id}}');" class="btn btn-primary"><i class="fa fa-trash-o"></i> Delete</a>
            </td>
        </tr>
        @endforeach
    </tbody>
    @else
    <tr class="text-center"><td colspan="10"><div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div></td></tr>
    @endif
</table>
<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {!!$attrData->links()!!}
    </ul>
</div>
<script>
            $(document).ready(function () {
    $(".pagination li a").on('click', function (e) {
    e.preventDefault();
            var loader = '<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>';
            var $this = $(this);
            var attrSearch = $("#attrSearch").val();
            var pageLink = $this.attr('href');
            var token = '{{ csrf_token() }}';
            $.ajax({type: 'POST', url: pageLink, async: false, data: {_token: token, attrSearch: attrSearch},
                    beforeSend: function () {
                    $('#attrList').html(loader);
                    },
                    success: function (response) {
                    $('.pagination:first').remove();
                            $('#attrList').html(response.html);
                    }
            });
    });
    });
</script>