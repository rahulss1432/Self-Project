@extends('admin::layouts.app')
@section('title', 'MarketPlace : Driver Details')
@section('content')
<style>
    .boxStyle {
        background-color: #fff;
        margin-bottom: 16px;
        border-radius: 6px;
        -webkit-box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
        -moz-box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
        box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
    }
</style>
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Driver Detail
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('/admin/drivers-list')}}">Driver Management</a></li>
            <li class="active">Driver Detail</li>
        </ol>
        <div class="pull-right">
            <a href="{{ URL::previous()}}" class="btn btn-primary">Back</a>            
        </div>        
    </section>

    <section class="content">
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane active" id="application">
                <section>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="btn-toolbar m-b-0">
                                <h2 class="md-headline green">Drive Detail</h2>
                            </div>
                            <div class="box box-primary">
                                <div class="box-body box-profile">
                                    <img class="profile-user-img img-responsive img-circle" src="{{\App\Helpers\Helper::defaultImage($driver->profile_picture,'profile_image')}}" alt="User profile picture">
                                    <h3 class="profile-username text-center">{{$driver->first_name}} {{$driver->last_name}}</h3>

                                    <ul class="list-group list-group-unbordered">
                                        <li class="list-group-item">
                                            <b>Email</b> <a class="pull-right">{{$driver->email}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Company Name</b> <a class="pull-right">{{ucfirst(empty($driver->driverDetail->deliver_company_id) ? '-' : $driver->driverDetail->deliverCompany->name)}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Mobile</b> <a class="pull-right">{{(!empty($driver->phone_number)) ? $driver->phone_number :'-'}}</a>
                                        </li>

                                        <li class="list-group-item">
                                            <b>Date of birth</b> <a class="pull-right">{{(!empty($driver->date_of_birth)) ? $driver->date_of_birth :'-'}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Commission</b> <a class="pull-right">                                                
                                                <span id="commission_type">&#x20B9; {{$driver->driverDetail->commission != '' ?  App\Helpers\Helper::getPriceFormatedValue($driver->driverDetail->commission) : '-' }}</span>                                            
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="box box-primary">
                                <div class="box-header with-border">
                                    <h3 class="box-title">Vehicle Detail</h3>
                                </div>

                                <div class="box-body">
                                    <ul class="list-group list-group-unbordered">
                                        <li class="list-group-item">
                                            <b>Vehicle</b> <a class="pull-right">{{ucfirst($driver->driverDetail->vehicleCategory->name)}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Vehicle Number</b> <a class="pull-right">{{strtoupper($driver->driverDetail->vehicle_number)}}</a>
                                        </li>

                                        <li class="list-group-item">
                                            <b>Vehicle Description</b> <a class="pull-right">{{$driver->driverDetail->vehicle_description}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Status</b> 
                                            @if($driver->is_active == '1')
                                            <a class="pull-right">Active</a>
                                            @else
                                            <a class="pull-right">Inctive</a>
                                            @endif
                                        </li>
                                    </ul>
                                </div>

                                <div class="box-body">
                                    <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
                                    <p class="text-muted">{{(!empty($driver->address)) ? $driver->address :'-'}}</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-6 col-sm-12">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h2 class="md-headline blue">Current Order</h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="boxStyle p-t-0 p-b-0 box-padding m-t-0">
                                        <div class="table-responsive">
                                            <table md-colresize="md-colresize" class="table inner-table">
                                                <thead>  
                                                    <tr class="md-table-headers-row">
                                                        <th>No.</th>
                                                        <th>Order ID</th>
                                                        <th>Order Type</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @if(!empty($currentOrder))        
                                                    <tr>
                                                        <td>1.</td>
                                                        <td>{{$currentOrder->id}}</td>
                                                        <td>{{ucfirst($currentOrder->order_state) }}</td>
                                                    </tr>
                                                    @else
                                                    <tr>
                                                        <td colspan="3">
                                                            <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
                                                        </td>
                                                    </tr>        
                                                    @endif         
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
</main>
<script>
    $(document).ready(function () {
      $(".rateYo").each(function () {
        $(this).rateYo({
          starWidth: "30px",
          rating: $(this).attr('data-rating'),
          readOnly: true
        });
      });
    });
</script>
@stop