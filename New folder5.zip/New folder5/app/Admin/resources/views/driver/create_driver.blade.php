@extends('admin::layouts.app')
@if(isset($driver))
@section('title', 'MarketPlace : Edit Driver')
@else
@section('title', 'MarketPlace : Create Driver')
@endif
@section('content') 
<style>
    /*image upload style starts*/    
    .upload-btn-wrapper {
        position: relative;
        overflow: hidden;
        display: inline-block;
        border: 1px solid #00BFFF;
        box-shadow: 0px 0px 1px 1px #00BFFF;
    }
    .img {
        border: 2px solid gray;
        color: gray;
        background-color: white;
        padding: 8px 20px;
        border-radius: 8px;
        font-size: 20px;
        font-weight: bold;
    }
    .upload-btn-wrapper input[type=file] {
        position: absolute;
        left: 0;
        top: 0;
        opacity: 0;
        height: 265px;
    }
    /*image upload style ends*/

</style>
<main class="main_content dashboardpage" id="createDriver">
    <section class="content-header">
        <h1>
            <a href="{{ URL::previous()}}" class="btn btn-primary">Back</a>            
            &nbsp;&nbsp;
            {{isset($driver) ? 'Edit Driver' : 'Create Driver'  }}
        </h1>        
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('/admin/drivers-list')}}">Driver Management</a></li>
            <li class="active">{{isset($driver) ? 'Edit Driver' : 'Create Driver'  }}</li>
        </ol>

    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                    </div>
                    @if(isset($driver))
                    <form class="form-horizontal" method="POST" action="{{url('/admin/update-driver')}}" id="updateDriverForm" enctype="multipart/form-data" autocomplete="off">                                            
                        <input type="hidden" name="user_id" value="{{$driver->id}}">
                        @else
                        <form class="form-horizontal" method="POST" action="{{url('/admin/save-driver')}}" id="addDriverForm" enctype="multipart/form-data" autocomplete="off">                                                                                        
                            @endif
                            {{csrf_field()}}
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="box-body">
                                        <input type="hidden" name="user_type" value="driver" >
                                        <div class="form-group">
                                            <label for="firstName" class="col-sm-3 control-label">First Name 
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input tabindex="1" type="text" name="first_name" class="form-control" value="{{isset($driver) && ($driver != '') ? $driver->first_name : ''  }}" id="firstName" placeholder="First Name">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="phoneNumber" class="col-sm-3 control-label">Mobile
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input tabindex="3" type="text" name="phone_number" class="form-control phone-number" value="{{isset($driver) && ($driver != '') ? $driver->phone_number : ''  }}" id="phoneNumber" placeholder="Mobile" maxlength="10">
                                            </div>
                                        </div>    
                                        @if(isset($driver))
                                        <div class="form-group">
                                            <label for="address" class="col-sm-3 control-label">Address
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input type="hidden" id="addressLat" name="address_lat" value="{{isset($driver) && ($driver != '') ? $driver->latitude : ''  }}">
                                                <input type="hidden" id="addressLong" name="address_long" value="{{isset($driver) && ($driver != '') ? $driver->longitude : ''  }}">                                                                    
                                                <input type="text" name="address" class="form-control" onkeyup="getAddress()" value="{{isset($driver) && ($driver != '') ? $driver->address : ''  }}" id="address" placeholder="Address">
                                            </div>
                                        </div>    
                                        @endif                                                        

                                        <div class="form-group">
                                            <label  for="profileImage" class="col-sm-3 control-label">Profile Image
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9">
                                                <div class="col-lg-6">
                                                    <div class="upload-btn-wrapper">
                                                        <img id="profileImagePreview" src="{{isset($driver) && ($driver != '') ? \App\Helpers\Helper::defaultImage($driver->profile_picture,'profile_image') : url('/public/images/upload-image.jpg')  }}" height="275" width="350" class="imagePreview"> 
                                                        <input tabindex="5" id="profilePicture" type="file" class="form-control" name="profile_picture">                  
                                                    </div>                                      
                                                    <input type="hidden" class="form-control do-not-ignore"  name="profile_image" id="profileImage">  
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group" id="vehicleTypeError">
                                            <label for="vehicleType" class="col-sm-3 control-label">Vehicle Type
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9" id="vehicleTypeInputError">
                                                <select tabindex="7" class="form-control selectpicker rounded-0" name="vehicle_type" id="vehicleType" data-live-search="true" data-size="5">
                                                    <option value="">Select Vehicle Type</option>                                                                    
                                                    @foreach($vehicleCategories as $category)                                                                        
                                                    <option value="{{$category->id}}" {{isset($driver) && ($driver->driverDetail->vehicle_category_id == $category->id) ? 'selected' : ''}}> {{$category->name}}</option>
                                                    @endforeach                                                           
                                                </select>                                                                
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="vehicleNumber" class="col-sm-3 control-label">Vehicle Number
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input tabindex="9" type="text" name="vehicle_number" class="form-control" id="vehicleNumber" value="{{isset($driver) && ($driver != '') ? $driver->driverDetail->vehicle_number : ''  }}" placeholder="Vehicle Number">
                                            </div>
                                        </div>   
                                        <div class="form-group">
                                            <label for="vehicleDescription *" class="col-sm-3 control-label">Vehicle Description
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input tabindex="11" type="text" name="vehicle_description" class="form-control" id="vehicleDescription" value="{{isset($driver) && ($driver != '') ? $driver->driverDetail->vehicle_description : ''  }}" placeholder="Vehicle Description">
                                            </div>
                                        </div>                                                           
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="box-body">
                                        <div class="form-group">
                                            <label for="lastName" class="col-sm-3 control-label">Last Name
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input tabindex="2" type="text" name="last_name" class="form-control" id="lastName" value="{{isset($driver) && ($driver != '') ? $driver->last_name : ''  }}" placeholder="Last Name">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="email" class="col-sm-3 control-label">Email ID
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input tabindex="4" type="text" name="email" class="form-control" id="email" value="{{isset($driver) && ($driver != '') ? $driver->email : ''  }}" placeholder="Email" {{isset($driver) && ($driver != '') ? 'readonly' : ''}}>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="LicenseImage" class="col-sm-3 control-label">License Image
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9">
                                                <div class="col-lg-6">
                                                    <div class="upload-btn-wrapper">
                                                        <img id="licenseImagePreview" src="{{isset($driver) && ($driver != '') ? \App\Helpers\Helper::defaultImage($driver->driverDetail->license_image,'license_image') : url('/public/images/upload-image.jpg')  }}" height="275" width="350" class="imagePreview"> 
                                                        <input tabindex="6" id="licensePicture" type="file" class="form-control"  name="license_picture">            
                                                    </div>                                        
                                                    <input type="hidden" class="form-control do-not-ignore" name="license_image" id="licenseImage">                                    
                                                </div>
                                            </div>                                                              
                                        </div>                                                                                                                
                                        <div class="form-group">
                                            <label for="licenseNumber" class="col-sm-3 control-label">License Number
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input tabindex="7" type="text" name="license_number" class="form-control" id="licenseNumber" value="{{isset($driver) && ($driver != '') ? $driver->driverDetail->license_number : ''  }}" placeholder="License Number">
                                            </div>
                                        </div>   
                                        <div class="form-group">
                                            <label for="deliverCompany" class="col-sm-3 control-label">Deliver Company</label>
                                            <div class="col-sm-9">
                                                <select tabindex="10" class="form-control selectpicker rounded-0" name="deliver_company" id="deliverCompany" onchange="selectDriverCompany(this)" data-live-search="true" data-size="5">
                                                    <option value="">Select Deliver Company</option>                                                                    
                                                    @foreach($deliverCompanies as $company)                                                                        
                                                    <option value="{{$company->id}}" {{isset($driver) && ($driver->driverDetail->deliver_company_id == $company->id) ? 'selected' : ''}}>{{$company->name}}</option>
                                                    @endforeach                                                           
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group div-commission-section" id="divComissionSection">
                                            <label for="commission" class="col-sm-3 control-label">Commission
                                                <span class="error-star">*</span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input tabindex="12" type="text" name="commission" class="form-control commission_price" value="{{isset($driver) && ($driver != '') ? $driver->driverDetail->commission : ''  }}" id="commission" placeholder="Commission in flat fee" onKeyPress="if(this.value.length==10) return false;">
                                            </div>
                                        </div>                                                 
                                    </div>
                                </div>                                                        
                            </div>
                            <div class="box-footer">
                                <button type="submit" id="btnSubmit" class="btn btn-primary pull-right"><i id="btnSubmitLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> Save Driver</button>
                            </div>                                        
                            </div>
                            </div>

                        </form>
                        @if(isset($driver))
                        {!! JsValidator::formRequest('App\Admin\Http\Requests\EditDriverRequest','#updateDriverForm') !!}    
                        @else
                        {!! JsValidator::formRequest('App\Admin\Http\Requests\AddDriverRequest','#addDriverForm') !!}    
                        @endif
                </div>
            </div>
        </div>
    </section>
    
    <!-- cropper-Modal -->
    <div class="modal fade" id="cropperImageModal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Modal Header</h4>
                </div>
                <div id="imageCropperForm">
                </div>                            
            </div>
        </div>
    </div>    
</main>
<script>
    $(document).ready(function() {
        $('.div-commission-section').show();
        var deliverCompanySelected = $('#deliverCompany').val();
        if ((deliverCompanySelected != '') && (deliverCompanySelected != null)) {
            $('.div-commission-section').hide();
        } else {
            $('.div-commission-section').show();
        }
    });
    
    $("#vehicleType").change(function() {
        var choice = jQuery(this).val();
        if ($(this).val() == '') {
            $('#vehicleType-error').show();
        } else {
            $('#vehicleType-error').hide();
            $('#vehicleTypeInputError .bootstrap-select .dropdown-toggle').css('border-color', '#00a65a');
            $('#vehicleTypeInputError .bootstrap-select .dropdown-menu .bs-searchbox .form-control').css('border-color', '#00a65a');
            $('#vehicleTypeError.form-group.has-error label').css('color', '#00a65a');
        }
    });
    
    $(".phone-number").keypress(function(e) {
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            return false;
        }
    });
    
    $('#updateDriverForm').on('submit', function(e) {
        $(this).find('.bootstrap-select').removeClass("form-control");
        $(this).find('.bootstrap-select').css('width', '100%');
        if ($('#updateDriverForm').valid()) {
            $('#btnSubmitLoader').show();
            document.getElementById("btnSubmit").disabled = true;
        } else {
            $('#btnSubmitLoader').hide();
            document.getElementById("btnSubmit").disabled = false;
        }
    });

    $('#addDriverForm').on('submit', function(e) {
        $(this).find('.bootstrap-select').removeClass("form-control");
        $(this).find('.bootstrap-select').css('width', '100%');
        if ($('#addDriverForm').valid()) {
            $('#btnSubmitLoader').show();
            document.getElementById("btnSubmit").disabled = true;
        } else {
            $('#btnSubmitLoader').hide();
            document.getElementById("btnSubmit").disabled = false;
        }
    });

    /* image uploading with cropper starts*/
    var profile_picture = $('#profilePicture');
    new AjaxUpload(profile_picture, {
        action: "{{url('/admin/upload-profile-image')}}",
        name: 'profile_picture',
        cache: false,
        method: 'post',
        data: {
            _token: '{{ csrf_token() }}'
        },
        responseType: "JSON",
        onSubmit: function(file, ext) {
            if (!(ext && /^(jpg|png|jpeg)$/.test(ext))) {
                bootbox.alert('Only jpg, jpeg, png files are allowed.');
                return false;
            }
        },
        onComplete: function(file, response) {
            if (file != "") {
                if (response.success) {
                    loadImageCropperModal(response.filename, 'profile-type-image');
                    $('#cropperImageModal').modal('show');
                } else {
                    toastr.remove();
                    toastr.options.closeButton = true;
                    toastr.error(response.message, 'Error', {
                        timeOut: 1000
                    });
                }
            } else {
                bootbox.alert("Error occured! please try again.");
            }
        }
    });

    var license_picture = $('#licensePicture');
    new AjaxUpload(license_picture, {
        action: "{{url('/admin/upload-license-image')}}",
        name: 'license_picture',
        cache: false,
        method: 'post',
        data: {
            _token: '{{ csrf_token() }}'
        },
        responseType: "JSON",
        onSubmit: function(file, ext) {
            if (!(ext && /^(jpg|png|jpeg)$/.test(ext))) {
                bootbox.alert('Only jpg, jpeg, png files are allowed.');
                return false;
            }
        },
        onComplete: function(file, response) {
            console.log(response.filename);
            if (file != "") {
                if (response.success) {
                    loadImageCropperModal(response.filename, 'license-type-image');
                    $('#cropperImageModal').modal('show');
                } else {
                    toastr.remove();
                    toastr.options.closeButton = true;
                    toastr.error(response.message, 'Error', {
                        timeOut: 1000
                    });
                }
            } else {
                bootbox.alert("Error occured! please try again.");
            }
        }
    });

    function loadImageCropperModal(imageName, type) {
        $.ajax({
            url: "{{url('/admin/load-image-cropper')}}",
            type: 'GET',
            data: {
                imageName: imageName,
                imageType: type
            },
            success: function(response) {
                $('#imageCropperForm').html(response.html);
            }
        });
    }
    /*image upload cropper ends*/
    
    function selectDriverCompany(thisElem) {
        if ($(thisElem).val() != '' && $(thisElem).val() != null) {
            $('.div-commission-section').hide();
        } else {
            $('.div-commission-section').show();
        }
    }

    /*get latitude longitude and google autosuggest address*/
    function getAddress() {
        var input = document.getElementById('address');
        var options = {
            types: ['geocode']
        };
        var autocomplete = new google.maps.places.Autocomplete(input, options);
        // Acting on Selecting a place
        google.maps.event.addListener(autocomplete, 'place_changed', function() {
            var place = autocomplete.getPlace();
            var lat = place.geometry.location.lat();
            var long = place.geometry.location.lng();
            $('#addressLat').val(lat);
            $('#addressLong').val(long);
        });
    }
</script>
@stop