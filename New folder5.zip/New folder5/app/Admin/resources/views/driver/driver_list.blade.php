@extends('admin::layouts.app')
@section('title', 'MarketPlace : Driver Management')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">

    <section class="content-header">
        <h1>
            Driver Management
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('/admin/drivers-list')}}">Driver Management</a></li>
            <li class="active">Driver</li>
        </ol>
    </section>

    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn btn-primary" onclick="showSearchBox()" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class="btn btn-primary disabled" id="btnDownloadCsv" href="{{ url('/admin/driver-csv-download') }}" onclick="exportButton()"> <i class="fa fa-upload"></i>  Export Driver <i id="exportLoader" class="fa fa-spinner fa-spin" style="display: none;"></i></a> 
                            <a class=" btn btn-primary" href="{{url('/admin/create-driver')}}"> <i class="fa fa-plus-circle"></i> Create Driver</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row" id="filterBox" style="display: none;">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <div class="innerfilterOption boxStyle clearfix" >
                            <form id="searchForm" action="javascript:void(0)" onsubmit="loadDrivers()" method="post" autocomplete="off">
                                {{ csrf_field() }}
                                <div class="row">
                                    <div class="col-md-2">
                                        <label> Name</label>
                                        <input id="searchName" class="form-control" name="name" type="text" placeholder="Name">
                                    </div>
                                    <div class="col-md-2">
                                        <label>Email address</label>
                                        <input id="searchEmail" class="form-control" name="email" type="text" placeholder="Email" >
                                    </div>
                                    <div class="col-md-2">
                                        <label>Mobile number</label>
                                        <input id="searchMobile" class="form-control" type="text"  name="phone_number" placeholder="Mobile number">
                                    </div>
                                    <div class="col-md-2">
                                        <label>Delivery Company</label>
                                        <select class="form-control select2" name="deliver_company" id="searchDeliverCompnay">
                                            <option value="">Select Deliver Company</option>                                                                    
                                            @foreach($deliverCompanies as $company)                                                                        
                                            <option value="{{$company->id}}">{{$company->name}}</option>
                                            @endforeach                                                           
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <label>Average Rating</label>
                                        <select class="form-control select2" name="average_rating" id="searchAverageRating">
                                            <option value="">Select Average Rating</option>                                                                    
                                            <option value=".5">.5</option>
                                            <option value="1">1</option>
                                            <option value="1.5">1.5</option>
                                            <option value="2">2</option>
                                            <option value="2.5">2.5</option>
                                            <option value="3">3</option>
                                            <option value="3.5">3.5</option>
                                            <option value="4">4</option>
                                            <option value="4.5">4.5</option>
                                            <option value="5">5</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <label>Number of orders</label>
                                        <input id="searchNumberOfOrder" class="form-control" type="text" name="number_of_order" placeholder="Number of orders">
                                    </div>
                                    <div class="col-md-2" style="margin-top: 24px;">
                                        <button id="btn-sub" type="submit" class="btn btn-primary">Filter</button>&nbsp;&nbsp;&nbsp;
                                        <button id="reset-btn" type="button" onclick="resetSearchForm()" class="btn btn-primary">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                    <div class="box-body table-responsive no-padding">
                    </div>
                </div>
            </div>
        </div>        

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title"></h3>
                    </div>
                    <div class="box-body table-responsive no-padding" id="loadDriverList">
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $(document).ready(function () {
        loadDrivers();
        hideExportLoader();
    });

    function resetSearchForm() {
        $('#searchForm')[0].reset();
        loadDrivers();
    }

    function hideExportLoader() {
        setInterval(function () {
            $('#exportLoader').hide();
            $('#btnDownloadCsv').removeClass('disabled');
        }, 2000);
    }

    function exportButton() {
        $('#exportLoader').show();
        $('#btnDownloadCsv').addClass('disabled');
    }

    $('#searchNumberOfOrder').keypress(function (event) {
        if (event.which != 46 && (event.which < 47 || event.which > 59))
        {
            event.preventDefault();
            if ((event.which == 46) && ($(this).indexOf('.') != -1)) {
                event.preventDefault();
            }
        }
    });

    function showSearchBox() {
        $("#filterBox").slideToggle("slow");
    }

    function loadDrivers() {
        var searchFilter = $("#searchForm").serializeArray();
        $("#loadDriverList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
        $.ajax({
            type: "POST",
            data: {_token: '{{ csrf_token() }}'},
            url: "{{url('/admin/load-driver-list')}}",
            data:searchFilter,
                    success: function (response) {
                        if (response.success = true) {
                            $('#loadDriverList').html(response.html);
                        } else {
                            $("#loadDriverList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
                        }
                    }
        });
    }

    function viewDetail(driverId)
    {
        $("#viewLoader_" + driverId).attr("disabled", true);
        $("#viewLoader_" + driverId).html('<i class="fa fa-spinner fa-spin"></i>');
    }

    function editDriver(id)
    {
        $("#EditLoader_" + id).attr("disabled", true);
        $("#EditLoader_" + id).html('<i class="fa fa-spinner fa-spin"></i>');
    }

    function deleteDriver(driverId)
    {
        $("#DeleteLoader_" + driverId).attr("disabled", true);
        $("#DeleteLoader_" + driverId).html('<i class="fa fa-spinner fa-spin"></i>');
        bootbox.confirm('Are you sure do you want to delete this Driver?', function (result)
        {
            if (result)
            {
                $.ajax({
                    type: "GET",
                    url: "{{url('/admin/delete-user')}}/" + driverId,
                    success: function (response)
                    {
                        if (response)
                        {
                            toastr.remove();
                            toastr.options.closeButton = true;
                            toastr.success(response.message, 'Success', {timeOut: 1000});
                            loadDrivers();
                        } else
                        {
                            toastr.remove();
                            toastr.options.closeButton = true;
                            toastr.error(response.message, 'Error', {timeOut: 1000});
                        }
                    }
                });
            } else {
                $("#DeleteLoader_" + driverId).attr("disabled", false);
                $("#DeleteLoader_" + driverId).html('<i class="fa fa-trash-o"> Delete</i>');
            }
        });
    }

    function changeStatus(id, status) {
        if (status == 1) {
            var msg = "Are you sure you want to deactivate this driver?";
        } else if (status == 0) {
            var msg = "Are you sure you want to activate this driver?";
        }
        bootbox.confirm(msg, function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "{{url('/admin/update-status')}}" + "/" + id,
                    success: function (response) {
                        if (response.success == true) {
                            toastr.remove();
                            toastr.options.closeButton = true;
                            toastr.success(response.message, 'Success', {
                                timeOut: 2000
                            });
                        } else {
                            toastr.remove();
                            toastr.options.closeButton = true;
                            toastr.error(response.message, 'Error', {
                                timeOut: 2000
                            });
                        }
                        loadDrivers();
                    }
                });
            } else {
                if (status == '1') {
                    $('#statusRadio_' + id).attr('checked', true);
                } else {
                    $('#statusRadio_' + id).attr('checked', false);
                }
            }
        });
    }
</script>
@stop