@extends('admin::layouts.app')
@section('title', 'MarketPlace : Driver Vehicle Detail')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Driver Vehicle Detail
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('/admin/drivers-list')}}">Driver Management</a></li>
            <li class="active">Driver Vehicle Detail</li>
        </ol>
        <div class="pull-right">
            <a href="{{ URL::previous()}}" class="btn btn-primary">Back</a>            
        </div>                
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-4">
                <div class="box box-primary">
                    <div class="box-body box-profile">
                        <img  src="{{\App\Helpers\Helper::defaultImage($driver->driverDetail->license_image,'license_image')}}" height="200px" width="400px">


                        <ul class="list-group list-group-unbordered">
                            <li class="list-group-item">
                                <b>License No.</b> <a class="pull-right">{{strtoupper($driver->driverDetail->license_number)}}</a>
                            </li>
                            <li class="list-group-item">
                                <b>Vehicle</b> <a class="pull-right">{{ucfirst($driver->driverDetail->vehicleCategory->name)}}</a>
                            </li>
                            <li class="list-group-item">
                                <b>Vehicle No.</b> <a class="pull-right">{{strtoupper($driver->driverDetail->vehicle_number)}}</a>
                            </li>
                            <li class="list-group-item">
                                <b>Status</b> 
                                @if($driver->is_active == '1')
                                <a class="pull-right">Active</a>
                                @else
                                <a class="pull-right">Inctive</a>
                                @endif
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">About Vehicle</h3>
                    </div>
                    <div class="box-body">
                        <strong><i class="fa fa-map-marker margin-r-5"></i> Vehicle Description</strong>
                        <p class="text-muted">{{$driver->driverDetail->vehicle_description}}</p>
                        <hr>

                        <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
                        <p class="text-muted">{{(!empty($driver->address)) ? $driver->address :'-'}}</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
@stop