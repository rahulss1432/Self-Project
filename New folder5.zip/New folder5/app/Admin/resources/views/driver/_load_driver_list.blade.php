<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>                
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>No of order</th>
            <th>Average Rating</th>
            <th>Company Name</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if(count($drivers)>0)        
        @php    
        $i = 1;
        @endphp            
        @foreach($drivers as $data)
        <?php
        if ($drivers->currentPage() == 1) {
            $srNo = $i++;
        } else {
            $srNo = ($drivers->currentPage() - 1) * $drivers->perPage() + $i++;
        }
        ?>
        <tr id="{{'driver'.$data->id}}">
            <td>{{$srNo}}</td>                    
            <td><a href="{{url('/admin/driver-detail',$data->id)}}">{{ucfirst($data->first_name)}} {{ucfirst($data->last_name)}}</a></td>
            <td>{{$data->email}}</td>
            <td>{{$data->phone_number}}</td>
            <td>{{count($data->driverOrder)}}</td>
            <td><div id="rateYo_{{$data->id}}" class="rate-yo" data-rating="{{count($data->ratingsAverage) > 0 ? $data->ratingsAverage[0]['rating'] : 0 }}"></div></td>
            <td>{{\App\Helpers\Helper::getDeliverCompanyById($data->driverDetail['deliver_company_id'])}}</td>
            <td>{{$data->is_active == 1 ? 'Active' : 'Inactive' }}</td>                    
            <td>
                <label class="switch">
                    <input id="statusRadio_{{$data->id}}" type="radio" onclick='changeStatus("{{$data->id}}","{{$data->is_active}}")' name="status_radio_{{$data->id}}" {{$data->is_active == 1 ? 'checked' : ''}}>
                    <span class="slider1 round" for="statusRadio_{{$data->id}}"></span>
                </label>
            </td>
            <td>
                <ul class="list-inline mb-0 ">
                    <li class="list-inline-item">
                        <a id="viewLoader_{{$data->id}}" class="btn btn-primary" onclick="viewDetail({{$data->id}})" href="{{url('/admin/driver-vehicle-detail',$data->id)}}">
                            <i class="fa fa-eye"> View</i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a id="EditLoader_{{$data->id}}" class="btn btn-primary" onclick="editDriver({{$data->id}})" href="{{url('admin/driver-edit',$data->id)}}">
                            <i class="fa fa-pencil-square-o"> Edit</i>
                        </a>
                    </li> 
                    <li class="list-inline-item">
                        <a id="DeleteLoader_{{$data->id}}" class="btn btn-primary" href="javascript:void(0);" onclick='deleteDriver("{{$data->id}}")'>
                            <i class="fa fa-trash-o"> Delete</i>
                        </a>
                    </li>
                </ul>
            </td>
        </tr>                         
        @endforeach
        @else
        <tr>
            <td colspan="9">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif 
    </tbody>
</table>
<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$drivers->links()}}
    </ul>
</div>

<script>
<?php if (count($drivers) > 0) { ?>
            $('#btnDownloadCsv').removeClass('disabled');
<?php } ?>
            $(document).ready(function() {
            $(".rate-yo").each(function() {
            $(this).rateYo({
            starWidth: "30px",
                    rating: $(this).attr('data-rating'),
                    readOnly: true
            });
            });
                    $(".pagination li a").on('click', function(e) {
            e.preventDefault();
                    $("#loadDriverList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
                    var $this = $(this);
                    var pageLink = $this.attr('href');
                    var searchFilter = $("#searchForm").serializeArray();
                    $.ajax({
                    type: 'POST',
                            url: pageLink,
                            async: false,
                            data: {_token: '{{ csrf_token() }}'},
                            data: searchFilter,
                            success: function(response) {
                            $('.pagination:first').remove();
                                    $('#loadDriverList').html(response.html);
                            }
                    });
            });
            });
</script>
