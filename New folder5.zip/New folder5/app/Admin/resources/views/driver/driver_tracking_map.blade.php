@extends('admin::layouts.app')
@section('title', 'MarketPlace : Tracking all drivers')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">

    <section class="content-header">
        <h1>
           Tracking all drivers
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">All Driver</a></li>
        </ol>
    </section>
    @php
    Mapper::map(22.7239117, 75.723764,['zoom' => 12,'marker' => false]);
    foreach($driverData as $driver)
    { 
    
    if($driver->getDriver->latitude)
    {
    $url = url('/admin/driver-vehicle-detail/'.$driver->user_id);
    $content="<div class='' style='text-align: left;'>\
         <a href='".$url."'>\
           <p>Driver Name :- ".$driver->getDriver->first_name."</p>\
           <p>Vehicle Number :- $driver->vehicle_number</p>\
       </a>\
    </div>";
     Mapper::informationWindow($driver->getDriver->latitude, $driver->getDriver->longitude, '', [
        'eventMouseOver' => 'infowindow.setContent("'.$content.'"); infowindow.open(map, this);'
    ]);
    }
    }
    @endphp
     <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                             <div style="width: 100%; height: 700px;">
                                    {!! Mapper::render() !!}
                             </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@stop
