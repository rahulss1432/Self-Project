<script type="text/javascript">
    $(function () {
        var $images = $('#cropbox');
        $images.cropper({
            viewMode: 1,
            dragMode: 'move',
            autoCropArea: 0.65,
            restore: false,
            guides: false,
            highlight: true,
            movable: false,
            zoomable: false,
            rotatable: true,
            center: false,
            scalable: false,
            responsive: true,
            strict: true,
            cropBoxResizable: true,
        });

        $("#cropbutton").click(function () {
            $("#cropbutton").attr('disabled', true);
            var imageCropedData = $images.cropper('getData');
            var croppedWidth = imageCropedData.width;
            var croppedHeight = imageCropedData.height;
            var croppedX = imageCropedData.x;
            var croppedY = imageCropedData.y;
            var rotate = imageCropedData.rotate;
            saveCroppedImage(croppedWidth, croppedHeight, croppedX, croppedY, rotate);
        });
    });

    function saveCroppedImage(croppedWidth, croppedHeight, croppedX, croppedY, rotate) {
        var imageName = '{{$imageName}}';
        var imageType = '{{$imageType}}';
        $.ajax({
            type: "POST",
            url: "{{url('/admin/upload-cropped-profile-image')}}",
            data: {croppedWidth: croppedWidth,
                croppedHeight: croppedHeight,
                croppedX: croppedX,
                croppedY: croppedY,
                rotate: rotate,
                _token: '{{ csrf_token() }}',
                imageName: imageName,
                imageType: imageType
            },
            success: function (response) {
                if (imageType == 'profile-type-image') {
                    $('#profileImage').val(response); // set input file name
                    var imagePath = '{{url("/public/uploads/profile-pictures")}}/';
                        $("#profileImagePreview").attr("src",imagePath + response);
                    $('#cropperImageModal').modal('hide');                               
                }
                else if (imageType == 'license-type-image') {
                    $('#licenseImage').val(response); // set input file name
                    var imagePath = '{{url("/public/uploads/license-pictures/")}}/';
                        $("#licenseImagePreview").attr("src",imagePath + response);
                    $('#cropperImageModal').modal('hide');                           
                }

            }
        });
    }

    function rotate_plus(rotate_angle) {
        $('#cropbox').cropper("rotate", rotate_angle);
    }

    function zoom_image(zoomRatio) {
        $('#cropbox').cropper("zoom", zoomRatio);
    }
</script>
<div class="modal-body">
    <div class="cropdiv">
        <img alt="image" src="{{ url('/public/uploads/temp-image/'.$imageName)}}"  value="{{$imageName}}" id="cropbox" class="img-responsive" />
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-primary waves-effect waves-button waves-light" data-dismiss="modal" id="cropbutton" >SAVE</button>
    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
</div>


