@extends('admin::layouts.app')
@section('title', 'MarketPlace : Edit Setting')
@section('content')
<style>
    .divElement{
        position: relative;
        left: 72px;
    }
    #value-error, #processingFee-error{
        color: #dd4b39;
    }
</style>
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Setting Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/settings')}}">Setting Management</a></li>
            <li class="active">Edit Setting</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Create Setting</h3>
                    </div>
                    <form id="frmEditSetting" class="form-horizontal" method="POST" action="{{url('admin/update-setting')}}">
                        {{ csrf_field() }}
                        <input type="hidden" name="id" value="{{$settingData->id}}">
                        <div class="box-body">
                            <div class="form-group" id="divError">
                                @if($settingData->key == 'processing_fee')
                                <label for="value" class="col-sm-5 control-label">Processing Fees</label><br><br>
                                <div class="col-sm-5 divElement">
                                    <input type="text" name="value" id="processingFee" class="form-control" value="{{$settingData->value}}">
                                </div>
                                <div class="col-sm-5 divElement">
                                    <select class="form-control" name="unit" onchange="changeCommissionValue();">
                                        <option value="">Select</option>
                                        <option value="percent" <?php if ($settingData->unit == 'percent') echo 'selected'; ?>>Percent</option>
                                        <option value="flat"  <?php if ($settingData->unit == 'flat') echo 'selected'; ?>>Flat</option>
                                    </select>
                                </div>
                                @elseif($settingData->key == 'time_of_acceptance_of_driver')
                                <label for="heading" class="col-sm-5 control-label">Time of acceptance of driver</label><br><br>
                                <div class="col-sm-5 divElement">
                                    <input type="text" id="acceptanceTime" name="value" class="form-control" value="{{$settingData->value}}">
                                </div>
                                <div class="col-sm-5 divElement">
                                    <select class="form-control" name="unit" onchange="changeTimeValue();">
                                        <option value="">Select</option>
                                        <option value="second" <?php if ($settingData->unit == 'second') echo 'selected'; ?>>Second</option>
                                        <option value="minute"  <?php if ($settingData->unit == 'minute') echo 'selected'; ?>>Minute</option>
                                        <option value="hour"  <?php if ($settingData->unit == 'hour') echo 'selected'; ?>>Hour</option>
                                    </select>
                                </div>
                                @else
                                <label for="heading" class="col-sm-5 control-label">Search radius for drivers</label><br><br>
                                <div class="col-sm-5 divElement">
                                    <input type="text" name="value" class="form-control" value="{{$settingData->value}}">
                                </div>
                                <div class="col-sm-5 divElement">
                                    <input type="text" class="form-control" name="unit" readonly value="{{$settingData->unit}}">
                                </div>
                                @endif
                            </div>
                        </div>
                        <div class="box-footer">
                            <center>
                                <button id="btnEditSetting" type="submit" class="btn btn-primary pull-right">Update Setting</button>
                            </center>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\UpdateSettingRequest','#frmEditSetting') !!}
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $("#btnEditSetting").on('click', (function (e) {
      var btn = $('#btnEditSetting');
      var form = $('#frmEditSetting');
      e.preventDefault();
      if (form.valid()) {
        btn.html('{{\App\Helpers\Helper::buttonLoader()}} Update Setting');
        btn.prop('disabled', true);
        $.ajax({
          url: "{{url('admin/update-setting')}}",
          type: "POST",
          data: form.serialize(),
          success: function (data)
          {
            btn.prop('disabled', false);
            window.location.href = '{{url("/admin/settings")}}';
          },
          error: function (data) {
            var obj = jQuery.parseJSON(data.responseText);
            for (var x in obj) {
              btn.prop('disabled', false);
              btn.html('Send');
              var errors = obj[x].length
              $('#' + x + '-error').html(obj[x]);
              $('#' + x + '-error').css("color", '#b30000');
              $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
            }
          },
        });
      }
    }));

    function changeCommissionValue() {
      $('#processingFee').val('');
      $('#divError').removeClass('has-error');
      $('#processingFee-error').html('');
      $('#divError').removeClass('has-success');
    }

    function changeTimeValue() {
      $('#acceptanceTime').val('');
      $('#divError').removeClass('has-error');
      $('#acceptanceTime-error').html('');
      $('#divError').removeClass('has-success');
    }
</script>
@stop