<form id="frmEditPolygon" class="form-horizontal" method="POST" action="{{url('/admin/update-polygon')}}">
    {{ csrf_field() }}
    <h4 class="modal-title">Name</h4>
    <input type="hidden" id="mapLocationId" name="id" value="{{$locationData->id}}">
    <input class="form-control" name="mapLocation" id="mapLocation" placeholder="" value="{{$locationData->polygon_name}}">
    <h4 class="modal-title">Shipping Price</h4>
    <input class="form-control price-input"  name="price" id="price" placeholder="" value="{{$locationData->shipping_charges}}" onKeyPress="if (this.value.length == 10)
                return false;">
    <h4 class="modal-title">Area Heading</h4>
    <?php $headingList = \App\Models\AreaHeading::all(); ?>
    <select id="selHeading" name="selHeading" class="form-control">
        <option value="">select City</option>
        @foreach($headingList as $heading)
        <option value="{{$heading->id}}" <?php
        if ($heading->id == $locationData->heading_id) {
            echo "selected";
        }
        ?>>{{$heading->heading}}</option>
        @endforeach
    </select>
    <div class="col-sm-4 boxStyle" id="map" style="width:100%;height: 500px;margin-top:20px;margin-bottom:20px;">
    </div>
    <div class="modal-footer">
        <button  id="updateMapDetail" class="btn btn-primary" type="submit">Update</button>
    </div>
</form>
{!! JsValidator::formRequest('App\Admin\Http\Requests\SavePolygonRequest','#frmEditPolygon') !!}

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAXtYBWd_BDPyNEWEEKGoZGiYSoDwllneA&libraries&libraries=drawing&callback=initMap"
async defer></script>
<script>
        function loadLocationList() {
          initMap();
        }
        var maps = [];
        var drawingManager = [];
        var LatLongArray = [];
        var map = '';
        var polyCoOrdinates = [];
        function initMap() {
          map = new google.maps.Map(document.getElementById('map'), {
            center: {lat: 22.7196, lng: 75.8577},
            zoom: 12
          });
<?php
$selectedMaps = \App\Models\DeliveryArea::actionSingalLocation($locationData->id);
if (!empty($selectedMaps)) {
    foreach ($selectedMaps as $key => $latlng) {
        ?>
                  polygonShapes = [];
                  polyCoOrdinates = [];
        <?php
        if (!empty($latlng)) {
            foreach ($latlng as $val) {
                $string = explode(' ', $val);
                ?>
                          polyCoOrdinates.push({lat:<?php echo $string[0]; ?>, lng:<?php echo $string[1]; ?>});
                          var polygonShapes = new google.maps.Polygon({
                            paths: polyCoOrdinates,
                            strokeColor: '#79cab7',
                            strokeOpacity: 0.8,
                            strokeWeight: 1.5,
                            fillColor: '#79cab7',
                            fillOpacity: 0.50,
                          });
                          polygonShapes.setMap(map);
                <?php
            }
        }
    }
}
?>
          var drawingManager = new google.maps.drawing.DrawingManager({
            drawingMode: google.maps.drawing.OverlayType.POLYGON,
            drawingControl: true,
            drawingControlOptions: {
              position: google.maps.ControlPosition.TOP_CENTER,
              drawingModes: ['polygon']
            },
          });
          drawingManager.setMap(map);
          google.maps.event.addListener(drawingManager, 'overlaycomplete', function (event) {
            var newShape = event.overlay;
            var vertices = newShape.getPath();
            for (var i = 0; i < vertices.getLength(); i++) {
              var myObj = {};
              var LatLong = vertices.getAt(i);
              myObj.lat = LatLong.lat();
              myObj.lng = LatLong.lng();
              var latititude_longitude = parseFloat(LatLong.lat()) + ' ' + parseFloat(LatLong.lng());
              LatLongArray.push(latititude_longitude);
            }
            $(".editLocationMap").modal('show');
            if (drawingManager.getDrawingMode()) {
              drawingManager.setDrawingMode(null);
            }
          });
        }
        var mapLocation = '';
        var mapLocationInArabic = '';
        var price = '';
        var mapLocationId = '';
        var selHeading = '';
        $("#updateMapDetail").on('click', (function (e) {
          var btn = $('#updateMapDetail');
          var form = $('#frmEditPolygon');
          e.preventDefault();
          if (form.valid()) {
            btn.html('{{\App\Helpers\Helper::buttonLoader()}} Update');
            btn.prop('disabled', true);
            mapLocation = $('#mapLocation').val();
            mapLocationId = $('#mapLocationId').val();
            price = $('#price').val();
            selHeading = $('#selHeading').val();
            var polyGon = LatLongArray;
            var token = '{{ csrf_token() }}';
            $.ajax({
              url: "{{url('/admin/update-polygon')}}",
              type: "POST",
              data: {_token: token, polyGon: polyGon, mapLocation: mapLocation, price: price, selHeading: selHeading, mapLocationId: mapLocationId},
              success: function (data)
              {
                LatLongArray = [];
                polyGon = '';
                $(".editLocationMap").modal('hide');
                $('#frmEditPolygon')[0].reset();
                btn.prop('disabled', false);
                $('#button-loader').css('display', 'none');
                location.reload();
              },
              error: function (data) {
                var obj = jQuery.parseJSON(data.responseText);
                for (var x in obj) {
                  btn.prop('disabled', false);
                  btn.html('Send');
                  var errors = obj[x].length
                  $('#' + x + '-error').html(obj[x]);
                  $('#' + x + '-error').css("color", '#b30000');
                  $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                }
              },
            });
          }
        }));
</script>