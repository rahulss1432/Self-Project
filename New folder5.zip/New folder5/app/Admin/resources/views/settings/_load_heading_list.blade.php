<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Area Heading</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if($headingData->count()>0)
        <?php $i = 1; ?>
        @foreach ($headingData as $val)
        <?php
        if ($headingData->currentPage() == 1) {
            $srNo = $i++;
        } else {
            $srNo = ($headingData->currentPage() - 1) * $headingData->perPage() + $i++;
        }
        ?>
        <tr id="tr_{{$val->id}}">
            <td>{{ $srNo }}</td>
            <td>{{ $val->heading }}</td>
            <td>
                <a href="{{url('admin/edit-heading/'.$val->id)}}" class="btn btn-primary"><i class="fa fa-pencil-square-o"> Edit</i></a>
                <a href="javascript:void(0);" onclick="deleteAreaHeading('{{$val->id}}');" class="btn btn-primary"><i class="fa fa-trash-o"> Delete</i></a>
        </tr>
        @endforeach
    </tbody>
    @else
    <tr><td colspan="10"><div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div></td></tr>
    @endif
</table>
<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$headingData->links()}}
    </ul>
</div>

<script>
            $(document).ready(function () {
    $(".pagination li a").on('click', function (e) {
    e.preventDefault();
            $("#loadAreaHeading").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
            var $this = $(this);
            var pageLink = $this.attr('href');
            var token = '{{ csrf_token() }}';
            var txtSearch = $("#txtSearch").val();
            $.ajax({type: 'POST', url: pageLink, data: {_token: token, txtSearch: txtSearch},
                    success: function (response) {
                    $('.pagination:first').remove();
                            $("#loadAreaHeading").html(response.html);
                    }
            });
    });
    });
</script>

