@extends('admin::layouts.app')
@section('title', 'MarketPlace : Add Area Heading')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Add Area Heading</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/view-area-heading')}}">Area Heading Management</a></li>
            <li class="active">Add Area Heading</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Add Area Heading</h3>
                    </div>
                    <form id="frmAddAreaHeading" class="form-horizontal" method="POST" action="{{url('admin/save-area-heading')}}">
                        {{ csrf_field() }}
                        <div class="box-body">
                            <div class="form-group">
                                <label for="heading" class="col-sm-2 control-label">Heading*</label>
                                <div class="col-sm-10">
                                    <input type="text" name="heading" class="form-control" placeholder="Heading">
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <center>
                                <button id="btnAddHeading" type="submit" class="btn btn-primary pull-right">
                                    <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> Add Area Heading
                                </button>
                            </center>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\AddAreaHeadingRequest','#frmAddAreaHeading') !!}
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $('#frmAddAreaHeading').on('submit', function (e) {
      if ($('#frmAddAreaHeading').valid()) {
        $('#addLoader').show();
        $("#btnAddHeading").prop('disabled', true);
      } else {
        $('#addLoader').hide();
        $("#btnAddHeading").prop('disabled', false);
      }
    });
</script>
@stop