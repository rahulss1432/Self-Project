@extends('admin::layouts.app')
@section('title', 'MarketPlace : Edit Area Heading')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Edit Area Heading</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/view-area-heading')}}">Area Heading Management</a></li>
            <li class="active">Edit Area Heading</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Area Heading</h3>
                    </div>
                    <form id="frmEditAreaHeading" class="form-horizontal" method="POST" action="{{url('admin/update-area-heading')}}">
                        {{ csrf_field() }}
                        <input type="hidden" name="id" value="{{$headingData->id}}">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="heading" class="col-sm-2 control-label">Heading</label>
                                <div class="col-sm-10">
                                    <input type="text" name="heading" class="form-control" value="{{$headingData->heading}}">
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <center>
                                <button id="btnEditHeading" type="submit" class="btn btn-primary pull-right">Update Area Heading</button>
                            </center>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\UpdateHeadingRequest','#frmEditAreaHeading') !!}
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $("#btnEditHeading").on('click', (function (e) {
      var btn = $('#btnEditHeading');
      var form = $('#frmEditAreaHeading');
      e.preventDefault();
      if (form.valid()) {
        btn.html('{{\App\Helpers\Helper::buttonLoader()}} Update Area Heading');
        btn.prop('disabled', true);
        $.ajax({
          url: "{{url('admin/update-area-heading')}}",
          type: "POST",
          data: form.serialize(),
          success: function (data)
          {
            btn.prop('disabled', false);
            window.location.href = '{{url("/admin/view-area-heading")}}';
          },
          error: function (data) {
            var obj = jQuery.parseJSON(data.responseText);
            for (var x in obj) {
              btn.prop('disabled', false);
              btn.html('Update');
              var errors = obj[x].length
              $('#' + x + '-error').html(obj[x]);
              $('#' + x + '-error').css("color", '#b30000');
              $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
            }
          },
        });
      }
    }));
</script>
@stop