@extends('admin::layouts.app')
@section('title', 'MarketPlace : Add Cancellation Reason')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Setting Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/settings')}}">Setting Management</a></li>
            <li class="active">Cancellation Reason</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Create Reason</h3>
                    </div>
                    <form id="frmCencellationReason" class="form-horizontal" method="POST" action="{{url('admin/save-cancellation-reason')}}">
                        {{ csrf_field() }}
                        <div class="box-body">
                            <div class="form-group">
                                <label class="control-label col-sm-4">Cancellation Reason:</label>
                                <div class="col-sm-6" style="text-align: right;">
                                    <div class="add_button clearfix">
                                        <button class="btn btn-primary" type="button" onclick="addMore()">Add Value</button>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2"></label>
                                <div class="col-sm-8">
                                    <table id="option-value" class="table table-bordered value_table">
                                        <tbody>
                                            <tr id="tr_1">
                                                <td class="text-left">
                                                    <input type="text" name="reasons[]" id="option_value_1" value="" placeholder="Reason" class="form-control required">
                                                    <span></span>
                                                </td>
                                                <td class="text-center">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <center>
                                <button  id="btnAddCancel" type="submit" class="btn btn-primary pull-right btnCancellationReason">
                                    <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> Add Reason 
                                </button>
                            </center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $('form#frmCencellationReason .btnCancellationReason').click(function (event) {
      var flag = 0;
      $(".required").each(function () {
        event.preventDefault();
        if ($(this).val().trim() == "") {
          $(this).next('span').css('color', 'red').html("This field is required");
          flag++;
        }
      });
      $('.required').keyup(function () {
        $(this).next('span').css('color', 'green').html("");

      });
      if (flag == 0) {
        $("#frmCencellationReason").submit();
      }
    });

    var counter = 2;
    function addMore() {
      var newTextBoxDiv = $(document.createElement('tr')).attr("id", 'tr_' + counter);
      newTextBoxDiv.after().html('<td class="text-left"><input type="text" name="reasons[]" id="option_value_' + counter + '" value="" placeholder="Reason" class="form-control required"><span></span></td><td class="text-center"><a href="javascript:void(0);" onclick="deleteRow(' + counter + ')">Remove</a></td>');
      newTextBoxDiv.appendTo("#option-value");
      counter++;
    }

    function deleteRow(id) {
      $("#tr_" + id).remove();
    }

    $('#frmCencellationReason').on('submit', function (e) {
      if ($('#frmCencellationReason').valid()) {
        $('#addLoader').show();
        $("#btnAddCancel").prop('disabled', true);
      } else {
        $('#addLoader').hide();
        $("#btnAddCancel").prop('disabled', false);
      }
    });
</script>
@stop