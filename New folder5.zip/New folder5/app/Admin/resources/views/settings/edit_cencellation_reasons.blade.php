@extends('admin::layouts.app')
@section('title', 'MarketPlace : Edit Cancellation Reason')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Setting Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/settings')}}">Setting Management</a></li>
            <li class="active">Cancellation Reason</li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Reason</h3>
                    </div>
                    <form id="frmEditCencellationReason" class="form-horizontal" method="POST" action="javascript:void(0)">
                        {{ csrf_field() }}
                        <input type="hidden" name="id" value="{{$reason->id}}">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="reason" class="col-sm-2 control-label">Reason</label>
                                <div class="col-sm-10">
                                    <input type="text" name="reason" class="form-control" value="{{$reason->reason}}">
                                </div>
                            </div>


                        </div>
                        <div class="box-footer">
                            <center>
                                <button id="btnEditReason" type="submit" class="btn btn-primary pull-right">Update Reason</button>
                            </center>
                        </div>

                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\UpdateCencellationReasonRequest','#frmEditCencellationReason') !!}

                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $("#btnEditReason").on('click', (function (e) {
        var btn = $('#btnEditReason');
        var form = $('#frmEditCencellationReason');
        e.preventDefault();
        if (form.valid()) {
            btn.html('{{\App\Helpers\Helper::buttonLoader()}} Update Reason');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{url('admin/update-cancellation-reason')}}",
                type: "POST",
                data: form.serialize(),
                success: function (data)
                {
                    btn.prop('disabled', false);
                    window.location.href = '{{url("/admin/settings")}}';
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Send');
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
</script>
@stop