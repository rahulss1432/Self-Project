<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Key</th>
            <th>Value</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if($settingData->count()>0)
        <?php $i = 1; ?>
        @foreach ($settingData as $val)
        <?php
        $srNo = $i++;
        ?>
        <tr id="tr_{{$val->id}}">
            <td>{{ $srNo }}</td>
            <td>{{ $val->name }}</td>
            <td>{{ $val->value }}
                @if($val->unit == 'percent')
                {{'Percentage'}}
                @elseif($val->unit == 'flat')
                {{'Flat'}}
                @elseif($val->unit == 'second')
                {{'Second'}}
                @elseif($val->unit == 'minute')
                {{'Minute'}}
                @elseif($val->unit == 'hour')
                {{'Hour'}}
                @elseif($val->unit == 'KM')
                {{'KM'}}
                @endif
            </td>
            <td>
                <a href="{{url('admin/edit-settings/'.$val->id)}}" class="btn btn-primary"><i class="fa fa-pencil-square-o"> Edit</i></a>
        </tr>
        @endforeach
    </tbody>
    @else
    <tr><td colspan="10"><div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div></td></tr>
    @endif
</table>

