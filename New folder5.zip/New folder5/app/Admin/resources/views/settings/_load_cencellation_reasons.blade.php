<table class="table table-hover">
    <thead>
        <tr>
            <th class="col-sm-4">S.No.</th>
            <th class="col-sm-4">Name</th>
            <th class="col-sm-4">Action</th>
        </tr>
    </thead>
    <tbody>
        @if($reasons->count()>0)
        <?php $i = 1; ?>
        @foreach ($reasons as $val)
        <?php
        $sNo = $i;
        ?>
        <tr id="tr11_{{$val->id}}">
            <td>{{ $sNo }}</td>
            <td>{{ $val->reason }}</td>
            <td>

                <a href="{{url('admin/edit-cencellatoin-reasons/'.$val->id)}}" class="btn btn-primary"><i class="fa fa-pencil-square-o"> Edit</i></a>
                <a href="javascript:void(0);" onclick="deleteCencellationReason('{{$val->id}}');" class="btn btn-primary"><i class="fa fa-trash-o"> Delete</i></a>
        </tr>
        <?php $i++ ?>
        @endforeach
    </tbody>
    @else
    <tr><td colspan="10"><div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div></td></tr>
    @endif
</table>
<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$reasons->links()}}
    </ul>
</div>
<script>
            $(document).ready(function () {
    $(".pagination li a").on('click', function (e) {
    e.preventDefault();
            $("#reasonList").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({type: 'POST', url: pageLink,
                    success: function (response) {
                    $('.pagination:first').remove();
                            $("#reasonList").html(response.html);
                    }
            });
    });
    });
</script>

