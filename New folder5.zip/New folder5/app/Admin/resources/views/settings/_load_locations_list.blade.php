<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Name</th>
            <th>Shipping Value</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if($locationData->count()>0)
        <?php $i = 1; ?>
        @foreach ($locationData as $val)
        <?php
        if ($locationData->currentPage() == 1) {
            $srNo = $i++;
        } else {
            $srNo = ($locationData->currentPage() - 1) * $locationData->perPage() + $i++;
        }
        ?>
        <tr id="tr_{{$val->id}}">
            <td>{{ $srNo }}</td>
            <td>{{ $val->polygon_name }}</td>
            <td>{{ $val->shipping_charges }}</td>
            <td>
                <a href="javascript:void(0);" onclick="editAllLocation('{{$val->id}}');" class="btn btn-primary"><i class="fa fa-pencil-square-o"> Edit</i></a>
                <a href="javascript:void(0);" onclick="deleteAllLocation('{{$val->id}}');" class="btn btn-primary"><i class="fa fa-trash-o"> Delete</i></a>

        </tr>
        @endforeach
    </tbody>
    @else
    <tr><td colspan="10"><div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div></td></tr>
    @endif
</table>
<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$locationData->links()}}
    </ul>
</div>

<script>
                    $(document).ready(function () {
            $(".pagination li a").on('click', function (e) {
            e.preventDefault();
                    $("#loadAllLocation").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
                    var $this = $(this);
                    var pageLink = $this.attr('href');
                    var token = '{{ csrf_token() }}';
                    var txtSearch = $("#txtSearch").val();
                    $.ajax({type: 'POST', url: pageLink, data: {_token: token, txtSearch: txtSearch},
                            success: function (response) {
                            $('.pagination:first').remove();
                                    $("#loadAllLocation").html(response.html);
                            }
                    });
            });
            });
</script>

