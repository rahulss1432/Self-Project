@extends('admin::layouts.app')
@section('title', 'MarketPlace : Area Heading Listing')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Area Heading Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/settings')}}">Location Management</a></li>
            <li class="active">Area Heading Listing</li>
        </ol>
        <div class="pull-right">
            <a href="{{url('admin/settings')}}" class="button btn btn-primary">Back</a>
        </div><br><br>
    </section>
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" onclick="showSerach()" id="filterbtnsearch" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class=" btn btn-primary" href="{{url('/admin/create-heading')}}"> <i class="fa fa-plus-circle"></i> Add Area Heading</a>
                        </div>
                    </div>
                </div>
                <form id="filterBox" style="display: none;" action="javascript:void(0);">
                    <div class="row">
                        <div class="col-md-4">
                            <span> Name</span> 
                            <input class="form-control"  id="txtSearch" name="txtSearch" type="text" placeholder="Area Heading" onchange="loadAreaHeading();">
                        </div>
                        <div class="col-md-2">
                            <br>
                            <button id="btn-sub" type="submit" class="btn btn-primary " onclick="loadAreaHeading();">
                                Filter <i id="add-loader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="loadAreaHeading">
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $(document).ready(function () {
      $("#txtSearch").keypress(function (e) {
        if (e.which == 13) {
          loadAreaHeading();
        }
      });
      loadAreaHeading();
    });

    function loadAreaHeading() {
      var txtSearch = $("#txtSearch").val();
      var token = '{{ csrf_token() }}';
      $("#loadAreaHeading").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      $.ajax({
        type: "POST",
        url: "{{ url('/admin/load-area-heading') }}",
        data: {_token: token, search: txtSearch},
        success: function (response)
        {
          $("#loadAreaHeading").html(response.html);
        }
      });
    }

    function showSerach() {
      $("#filterBox").slideToggle("slow");
    }

    function deleteAreaHeading(id)
    {
      bootbox.confirm('Are you sure do you want to delete heading ?', function (result)
      {
        if (result)
        {
          $.ajax({
            type: "GET",
            url: "{{url('/admin/delete-heading')}}/" + id,
            success: function (response)
            {
              if (response) {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.success("{{\Config::get('constants.delete_heading')}}", 'Success', {timeOut: 1000});
                $("#tr_" + id).hide(500);

              }
              else {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error("{{\Config::get('constants.something_wrong')}}", 'Error', {timeOut: 1000});
              }
            }
          });
        }
      });
    }
</script>
@stop