@extends('admin::layouts.app')
@section('title', 'MarketPlace : Location List')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Location List</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/settings')}}">Location Management</a></li>
            <li class="active">Location List</li>
        </ol>
        <div class="pull-right">
            <a href="{{url('admin/settings')}}" class="button btn btn-primary">Back</a>
        </div><br><br>
    </section>
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" onclick="showSerach()" id="filterbtnsearch" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                        </div>
                    </div>
                </div>
                <form id="filterBox" style="display: none;" action="javascript:void(0);">
                    <div class="row">
                        <div class="col-md-4">
                            <span>Location Name</span> 
                            <input class="form-control" id="txtSearch" name="txtSearch" type="text" placeholder="Location Name" onchange="loadAllLocation();">
                        </div>
                        <div class="col-md-2">
                            <br>
                            <button id="btn-sub" type="submit" class="btn btn-primary " onclick="loadAllLocation();">
                                Filter <i id="add-loader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="loadAllLocation">

                    </div>
                </div>
            </div>
        </div>

    </section>
</main>
<div class="modal editLocationMap fade" id="edit_property" tabindex="-1" role="dialog" aria-labelledby="edit_property">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><img src="{{url('public/images/cross.png')}}"></span></button>
                <h4 class="modal-title text-center">Edit Location</h4>
            </div>
            <div class="modal-body form-group" id="editLocation">

            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
      loadAllLocation();
    });

    function loadAllLocation() {
      var txtSearch = $("#txtSearch").val();
      var token = '{{ csrf_token() }}';
      $("#loadAllLocation").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      $.ajax({
        type: "POST",
        url: "{{ url('/admin/load-all-location') }}",
        data: {_token: token, search: txtSearch},
        success: function (response)
        {
          $("#loadAllLocation").html(response.html);
        }
      });
    }

    function showSerach() {
      $("#filterBox").slideToggle("slow");
    }

    function deleteAllLocation(id) {
      bootbox.confirm('Are you sure do you want to delete this location ?', function (result)
      {
        if (result)
        {
          $.ajax({
            type: "GET",
            url: "{{url('/admin/delete-location')}}/" + id,
            success: function (response)
            {
              if (response) {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.success('Location deleted successfully', 'Success', {timeOut: 1000});
                $("#tr_" + id).hide(500);

              }
              else {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error('Something went wrong', 'Error', {timeOut: 1000});
              }
            }
          });
        }
      });
    }

    function editAllLocation(id) {
      $.ajax({type: "GET",
        url: "{{url('/admin/edit-location')}}",
        data: {id: id},
        success: function (response) {
          $('#editLocation').html(response.html);
          $(".editLocationMap").modal();
        }
      });
    }
</script>
@stop