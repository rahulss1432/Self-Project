@extends('admin::layouts.app')
@section('title', 'MarketPlace : Setting Management')
@section('content')

<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Setting Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Setting Management</a></li>
        </ol>
    </section>
</main>
<section class="content">
    <div class="row">
        <div>
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li role="presentation" class="active"><a href="#application" id="settingTab" aria-controls="application" role="tab" data-toggle="tab" onclick="loadApplicationList();">Application management</a></li>
                <li role="presentation"><a href="#location" aria-controls="location" role="tab" id="locationTab" onclick="loadLocationList();" data-toggle="tab">Location management</a></li>
                <li role="presentation"><a href="#cancellation" aria-controls="cancellation" role="tab" id="cancellationTab" onclick="loadReasonList()" data-toggle="tab">Cancellation reasons</a></li>
            </ul>
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="application">
                    <div class="col-sm-12">
                        <div class="main-content inner-tab">
                            <div class="btn-toolbar">
                                <h2 class="md-headline green">Setting Management</h2>
                            </div>
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="box">
                                        <div class="box-body table-responsive no-padding" id="settingList">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
                <div role="tabpanel" class="tab-pane" id="location">
                    <div class="col-sm-12">
                        <div class="main-content inner-tab">
                            <div class="btn-toolbar">
                                <h2 class="md-headline green">Location Listing <span class="pull-right">
                                        <a href="{{url('/admin/view-area-heading')}}" class="btn btn-primary btn-rounded btn-pad"><span class="hidden-xs">View Area Heading</span></a> 
                                        <a href="{{url('/admin/view-all-location')}}" class="btn btn-primary btn-rounded btn-pad" style="margin-left: 10px;"><span class="hidden-xs">View All Location</span></a>
                                    </span>
                                </h2>
                            </div>
                            <div class="col-sm-4 boxStyle" id="map" style="width:100%;height: 500px;">
                            </div> 
                        </div>
                    </div>
                </div>
                <div role="tabpanel" class="tab-pane" id="cancellation">
                    <div class="col-sm-12">
                        <div class="main-content inner-tab">
                            <div class="btn-toolbar">
                                <h2 class="md-headline green">Cancellation Reasons <a href="{{url('/admin/create-cancellation-reason')}}" class="btn btn-primary btn-rounded btn-pad pull-right"><i class="fa fa-plus-circle"></i><span class="hidden-xs"> Create Cancellation Reason</span></a></h2>
                            </div>
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="box">
                                        <div class="box-body table-responsive no-padding" id="reasonList">

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal addPolygonModal fade" id="edit_property" tabindex="-1" role="dialog" aria-labelledby="edit_property">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><img src="{{url('public/images/cross.png')}}"></span></button>
                    <h4 class="modal-title text-center">Add Location</h4>
                </div>
                <div class="modal-body form-group">
                    <form id="frmAddPolygon" class="form-horizontal" method="POST" action="{{url('/admin/save-polygon')}}">
                        {{ csrf_field() }}
                        <h4 class="modal-title">Map Name</h4>
                        <input class="form-control" name="mapLocation" id="mapLocation" placeholder="">
                        <h4 class="modal-title">Shipping Price</h4>
                        <input class="form-control price-input"  name="price" id="price" placeholder="">
                        <h4 class="modal-title">Area Heading</h4>
                        <?php $headingList = \App\Models\AreaHeading::all(); ?>
                        <select id="selHeading" name="selHeading" class="form-control">
                            <option value="">select City</option>
                            @foreach($headingList as $heading)
                            <option value="{{$heading->id}}">{{$heading->heading}}</option>
                            @endforeach
                        </select>
                        <div class="modal-footer">
                            <button  id="saveMapDetail" class="btn btn-warning" type="submit">Save</button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\SavePolygonRequest','#frmAddPolygon') !!}
                </div>
            </div>
        </div>
    </div>
</section>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAXtYBWd_BDPyNEWEEKGoZGiYSoDwllneA&libraries&libraries=drawing&callback=initMap"
async defer></script>
<script>
                    $(document).ready(function ()
                    {
                      loadApplicationList();
                    });
                    function loadLocationList() {
                      initMap();
                    }
                    var maps = [];
                    var drawingManager = [];
                    var LatLongArray = [];
                    var map = '';
                    var polyCoOrdinates = [];
                    function initMap() {
                      map = new google.maps.Map(document.getElementById('map'), {
                        center: {lat: 22.7196, lng: 75.8577},
                        zoom: 12
                      });
<?php
$selectedMaps = App\Models\DeliveryArea::actionLoadMap();
if (!empty($selectedMaps)) {
    foreach ($selectedMaps as $key => $latLong) {
        ?>
                              polygonShapes = [];
                              polyCoOrdinates = [];
        <?php
        if (!empty($latLong)) {
            foreach ($latLong as $val) {
                $string = explode(' ', $val);
                ?>
                                      polyCoOrdinates.push({lat:<?php echo $string[0]; ?>, lng:<?php echo $string[1]; ?>});
                                      var polygonShapes = new google.maps.Polygon({
                                        paths: polyCoOrdinates,
                                        strokeColor: '#79cab7',
                                        strokeOpacity: 0.8,
                                        strokeWeight: 1.5,
                                        fillColor: '#79cab7',
                                        fillOpacity: 0.50,
                                      });
                                      polygonShapes.setMap(map);
                <?php
            }
        }
    }
}
?>
                      var drawingManager = new google.maps.drawing.DrawingManager({
                        drawingMode: google.maps.drawing.OverlayType.POLYGON,
                        drawingControl: true,
                        drawingControlOptions: {
                          position: google.maps.ControlPosition.TOP_CENTER,
                          drawingModes: ['polygon']
                        },
                      });
                      drawingManager.setMap(map);
                      google.maps.event.addListener(drawingManager, 'overlaycomplete', function (event) {
                        var newShape = event.overlay;
                        var vertices = newShape.getPath();
                        for (var i = 0; i < vertices.getLength(); i++) {
                          var myObj = {};
                          var LatLong = vertices.getAt(i);
                          myObj.lat = LatLong.lat();
                          myObj.lng = LatLong.lng();
                          var latititude_longitude = parseFloat(LatLong.lat()) + ' ' + parseFloat(LatLong.lng());
                          LatLongArray.push(latititude_longitude);
                        }
                        $(".addPolygonModal").modal('show');
                        if (drawingManager.getDrawingMode()) {
                          drawingManager.setDrawingMode(null);
                        }
                      });
                    }
                    var mapLocation = '';
                    var price = '';
                    var selHeading = '';
                    $("#saveMapDetail").on('click', (function (e) {
                      var btn = $('#saveMapDetail');
                      var form = $('#frmAddPolygon');
                      e.preventDefault();
                      if (form.valid()) {
                        btn.html('{{\App\Helpers\Helper::buttonLoader()}} Save');
                        btn.prop('disabled', true);
                        mapLocation = $('#mapLocation').val();
                        price = $('#price').val();
                        selHeading = $('#selHeading').val();
                        var polyGon = LatLongArray;
                        var token = '{{ csrf_token() }}';
                        $.ajax({
                          url: "{{url('/admin/save-polygon')}}",
                          type: "POST",
                          data: {_token: token, polyGon: polyGon, mapLocation: mapLocation, price: price, selHeading: selHeading},
                          success: function (data)
                          {
                            LatLongArray = [];
                            polyGon = '';
                            $(".addPolygonModal").modal('hide');
                            $('#frmAddPolygon')[0].reset();
                            btn.prop('disabled', false);
                            $('#button-loader').css('display', 'none');
                            location.reload();
                            toastr.remove();
                            toastr.options.closeButton = true;
                            toastr.success("{{\Config::get('constants.add_location')}}", 'Success', {timeOut: 2000});
                          },
                          error: function (data) {
                            var obj = jQuery.parseJSON(data.responseText);
                            for (var x in obj) {
                              btn.prop('disabled', false);
                              btn.html('Send');
                              var errors = obj[x].length
                              $('#' + x + '-error').html(obj[x]);
                              $('#' + x + '-error').css("color", '#b30000');
                              $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                            }
                          },
                        });
                      }
                    }));

                    function loadReasonList() {
                      $("#reasonList").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
                      $.ajax({
                        type: "get",
                        url: "{{ url('/admin/load-cencellation-reasons') }}",
                        success: function (response)
                        {
                          $("#reasonList").html(response.html);
                        }});
                    }

                    function loadApplicationList() {
                      $("#settingList").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
                      $.ajax({
                        type: "get",
                        url: "{{ url('/admin/load-setting-list') }}",
                        success: function (response)
                        {
                          $("#settingList").html(response.html);
                        }});
                    }

                    function deleteCencellationReason(id) {
                      bootbox.confirm('Are you sure do you want to delete reason ?', function (result)
                      {
                        if (result)
                        {
                          $.ajax({
                            type: "GET",
                            url: "{{url('/admin/delete-cencellation-reason')}}/" + id,
                            success: function (response)
                            {
                              if (response) {
                                toastr.remove();
                                toastr.options.closeButton = true;
                                toastr.success("{{\Config::get('constants.delete_reason')}}", 'Success', {timeOut: 1000});
                                $("#tr11_" + id).hide(500);

                              }
                              else {
                                toastr.remove();
                                toastr.options.closeButton = true;
                                toastr.error("{{\Config::get('constants.something_wrong')}}", 'Error', {timeOut: 1000});
                              }
                            }
                          });
                        }
                      });
                    }
</script>
@stop