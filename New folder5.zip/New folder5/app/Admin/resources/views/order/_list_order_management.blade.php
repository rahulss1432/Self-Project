<table class="table table-hover">
    <thead>
        <tr>
            <th>Order ID</th>
            <th>Customer Name</th>
            <th>Vendor Name</th>
            <th>Delivery Address</th>
            <th>Expected Arrival Time</th>
            <th>Payment Mode</th>
            <th>Driver Name</th>
            <th>Amount</th>
            <th>Order State</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if(count($orderData)>0)
        @foreach($orderData as $data)
        <tr id="{{'order'.$data->id}}">
            <td>{{$data->id}}</td>
            <td>{{$data->getCustomer->first_name}} {{$data->getCustomer->last_name}}</td>
            <td>{{$data->getVendor->first_name}} {{$data->getVendor->last_name}}  </td>
            <td col width="300">{{$data->drop_address}}</td>
            <td>
                @if($data->order_state == 'out_for_delivery')
                {{App\Helpers\Helper::getDistanceInMeters($data->current_location,$data->drop_address)}}
                @else 
                -
                @endif
            </td>
            <td>{{$data->payment_mode}}</td>
            <td>{{($data->getDriver)?$data->getDriver->first_name.' '.$data->getDriver->last_name :'-'}} </td>
            <td>{{App\Helpers\Helper::getPriceFormatedValue($data->total_amount)}}</td>
            <td>
                @if($data->order_state == 'out_for_delivery')
                Out For Delivery.
                @elseif($data->order_state == 'pending')
                Pending.
                @elseif($data->order_state == 'running')
                Running.
                @elseif($data->order_state == 'vendor_pending')
                Vendor Pending.
                @elseif($data->order_state == 'completed')
                Delivered.
                @elseif($data->order_state == 'cancelled')
                Cancelled.
                @elseif($data->order_state == 'out_for_pickup')
                Ready For Pickup.
                @endif
            </td>
            <td><ul class="list-inline mb-0 ">
                    <li class="list-inline-item">
                        <a id="edit-loader{{$data->id}}" class="btn btn-primary" href="{{url('admin/view-order/'.$data->id)}}">
                            <i class="fa fa-eye"> View</i>
                        </a>
                    </li> 
                </ul>
            </td>
        </tr>
        @endforeach
        @else 
        <tr>
            <td colspan="11">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>

<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$orderData->links()}}
    </ul>
</div>

<script>
    function deletefunction(id) {
        bootbox.confirm('Are you sure you want to delete?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "{{url('/admin/delete-subadmin')}}/" + id,
                    success: function (response) {
                        $('#subadmin' + id).remove();
                    }
                });
            }
        });
    }

    $(document).ready(function () {
        var search_filter = $("#searchForm").serializeArray();
        var token = '{{ csrf_token() }}';
        $('.pagination').addClass('pull-right');
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#listingOrder").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({type: 'POST', url: pageLink, async: false, data: {_token: token, search_filter: search_filter},
                success: function (response) {
                    $('.pagination:first').remove();
                    $('#listingOrder').html(response.html);
                }
            });
        });
    });


//change status function 
    function activeInactive(id, status)
    {
        if (status == '1')
        {
            var msg = "Are you sure you want to deactivate this customer?";
        }
        else if (status == '0')
        {
            var msg = "Are you sure you want to activate this customer?";
        }
        bootbox.confirm(msg, function (result)
        {
            if (result)
            {
                $.ajax({
                    type: "POST",
                    url: "{{url('/admin/active-inactive')}}/" + id,
                    data: {'_token': '{{csrf_token()}}'},
                    success: function (response)
                    {
                        if (response)
                        {
                            toastr.remove();
                            toastr.options.closeButton = true;
                            load_subadmin_list()
                            toastr.success('Status updated successfully', 'Success', {timeOut: 2000});
                        }
                        else
                        {
                            toastr.remove();
                            toastr.options.closeButton = true;
                            toastr.error('Something went wrong', 'Error', {timeOut: 2000});
                        }
                    }
                });
            }
            else
            {
                if (status == '1')
                {
                    $('#enable_a_' + id).attr('checked', true);
                }
                else
                {
                    $('#enable_a_' + id).attr('checked', false);
                }
            }
        });
    }

</script>