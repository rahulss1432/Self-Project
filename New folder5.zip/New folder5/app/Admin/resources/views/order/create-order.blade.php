@extends('admin::layouts.app')
@section('title', 'MarketPlace : Create Order')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Order Creation
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/order-management')}}">Order Management</a></li>
            <li class="active">Create Order</li>
        </ol> 
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                    </div>
                    <form class="form-horizontal" id="orderForm" method="post" action="{{url('/admin/save-order')}}">
                        {{csrf_field()}}
                        <div class="box-body">
                            <div class="form-group">
                                <label for="vendor" class="col-sm-3 control-label">Vendor</label>
                                <div class="col-sm-9">
                                    @php echo \App\Models\User::getVendorDropdown(0); @endphp
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="user" class="col-sm-3 control-label">Select User</label>
                                <div class="col-sm-9">
                                    @php echo \App\Models\User::getCustomerDropdown(0); @endphp
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="pickupAddress" class="col-sm-3 control-label">Pickup Address</label>

                                <div class="col-sm-9">
                                    <input type="text" name="pickup_address" class="form-control input-lg" id="pickupAddress" placeholder="Enter pickup Address">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="dropAddress" class="col-sm-3 control-label">Drop up Address </label>

                                <div class="col-sm-9">
                                    <input type="text" name="drop_address" class="form-control input-lg" id="dropAddress" placeholder="Drop up Address" onblur="viewmap()">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="payment_mode" class="col-sm-3 control-label">Payment Mode </label>

                                <div class="col-sm-9">
                                    <select class="form-control input-lg" name="payment_mode">
                                        <option value="">-- Select payment Mode--</option>
                                        <option value="cod">COD</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <span style="margin-left:150px;"><h3> Add Items From Restaurant<h3></span>
                                            <div class="col-sm-12" id="addItems" style="display: none">
                                                <table class="table table-hover">
                                                    <thead>
                                                        <tr>
                                                            <th>Category</th>
                                                            <th>Item</th>
                                                            <th>price </th>
                                                            <th>image</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr class="clone ">
                                                            <td ></td>
                                                            <td > </td>
                                                            <td ></td>
                                                            <td ></td>
                                                            <td></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <button id="btnAddMore" type="button" class="btn btn-primary" onclick="addMore();">
                                                    Add More</i>
                                                </button>
                                            </div>
                                            </div>
                                            </div>
                                            <div class="box-footer">
                                                <button id="btnOrder" type="submit" class="btn btn-primary ">
                                                    <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> Create Order
                                                </button>
                                            </div>
                                            </form>
                                            {!! JsValidator::formRequest('App\Admin\Http\Requests\CreateOrderRequest','#orderForm') !!}
                                            </div>
                                            </div>
                                            <div class="col-md-6">
                                                <h3>Store Location (set location)</h3>
                                                <div id="map" style=" width: 200;height: 600px;"></div>
                                            </div>
                                            </div>
                                            </section>
                                            </main>
                                            <script>
                                                $(document).ready(function () {
                                                  initAutocomplete();
                                                });
                                                $('#btnOrder').on('click', function (e) {
                                                  var i = 0;
                                                  var j = 0;
                                                  $('.category-id').each(function (index) {
                                                    i++;
                                                    if ($(this).val() == '') {
                                                      j++;
                                                      bootbox.alert('category can not be blank');
                                                    }
                                                  });
                                                  if (j == 0) {
                                                    $('.item-id1').each(function () {
                                                      if ($(this).val() == '') {
                                                        j++;
                                                        bootbox.alert('Item can not be blank');
                                                      }
                                                    });
                                                  }
                                                  if (i == 0) {
                                                    j++;
                                                    bootbox.alert('please add category');
                                                  }
                                                  event.preventDefault(e);
                                                  if (j == 0) {
                                                    if ($('#orderForm').valid()) {
                                                      $('#addLoader').show();
                                                      document.getElementById("btnOrder").disabled = true;
                                                      var form = $('#orderForm').serialize();
                                                      $.ajax({
                                                        type: "Post",
                                                        url: "{{url('/admin/save-order')}}",
                                                        data: form,
                                                        success: function (response) {
                                                          if (response.status == true) {
                                                            toastr.remove();
                                                            toastr.options.closeButton = true;
                                                            toastr.success(response.message, 'Success', {timeOut: 3000});
                                                            window.location.href = '{{url("/admin/order-management")}}';

                                                          } else
                                                          {
                                                            toastr.remove();
                                                            toastr.options.closeButton = true;
                                                            toastr.error(response.message, 'Error', {timeOut: 3000});
                                                            window.location.href = '{{url("/admin/create-order")}}';
                                                          }
                                                          document.getElementById("btnOrder").disabled = false;

                                                        }
                                                      });
                                                    }
                                                  }


                                                });

                                                function redirectTLink() {
                                                  var customer = $('#customer').val();
                                                  if (customer == 'create_new_user') {
                                                    window.location.href = '{{url("admin/create-customer")}}';
                                                  }
                                                }
                                                var category = '';
                                                function getaddress() {
                                                  var vendorId = $('#order').val();
                                                  var token = '{{ csrf_token() }}';
                                                  if (vendorId) {
                                                    $.ajax({
                                                      type: "Post",
                                                      url: "{{url('/admin/get-location')}}",
                                                      data: {_token: token, vendorId: vendorId},
                                                      success: function (response) {
                                                        category = response.category;
                                                        $("#pickupAddress").val(response.data.address);
                                                        $('.clone td:nth-child(1)').html(response.category);
                                                        $('.clone td').last().html('<button class="btn btn-danger" type="button" onclick="remove($(this));"><i class="fa fa-trash" aria-hidden="true"></i></button>');
                                                        getLatitudeLongitude(response.data.address);
                                                        setTimeout(function () {
                                                          setMarker();
                                                        }, 1000);
                                                        $('#addItems').show();
                                                      }
                                                    });
                                                  }
                                                  else {
                                                    window.location.reload();
                                                  }
                                                }
                                                //get category item 
                                                function getItem(obj) {
                                                  var categoryId = obj.val();
                                                  var token = '{{ csrf_token() }}';
                                                  if (categoryId) {
                                                    $.ajax({
                                                      type: "Post",
                                                      url: "{{url('/admin/get-category-item')}}",
                                                      data: {_token: token, categoryId: categoryId},
                                                      success: function (response) {
                                                        obj.parent().next('td').html(response.item);
                                                      }
                                                    });
                                                  }
                                                }

                                                // map source code 
                                                var locations = [];
                                                function getLatitudeLongitude(address) {

                                                  // If adress is not supplied, use default value 'Ferrol, Galicia, Spain'
                                                  address = address || '';
                                                  // Initialize the Geocoder
                                                  locations.splice(1, 1);
                                                  geocoder = new google.maps.Geocoder();
                                                  if (geocoder) {
                                                    geocoder.geocode({
                                                      'address': address
                                                    }, function (results, status) {
                                                      if (status == google.maps.GeocoderStatus.OK) {
                                                        var lat = results[0].geometry.location.lat();
                                                        var lng = results[0].geometry.location.lng();
                                                        var locationLatLng = [address, lat, lng];
                                                        locations.push(locationLatLng);

                                                      }
                                                    });
                                                  }
                                                }
                                                function setMarker() {
                                                  var map = new google.maps.Map(document.getElementById('map'), {
                                                    zoom: 8,
                                                    center: new google.maps.LatLng(locations[0][1], locations[0][2]),
                                                    mapTypeId: google.maps.MapTypeId.ROADMAP
                                                  });
                                                  var marker, i;

                                                  for (i = 0; i < locations.length; i++) {

                                                    marker = new google.maps.Marker({
                                                      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                                                      map: map
                                                    });
                                                  }

                                                }

                                                function initAutocomplete() {
                                                  var input = document.getElementById('dropAddress');
                                                  var searchBox = new google.maps.places.SearchBox(input);
                                                }
                                                function viewmap() {
                                                  var address = $('#dropAddress').val();
                                                  var vendor_id = $('#order').val();
                                                  var token = '{{ csrf_token() }}';
                                                  $.ajax({
                                                    type: "Post",
                                                    url: "{{url('/admin/check-delivery-area')}}",
                                                    data: {_token: token, address: address, vendorId: vendor_id, },
                                                    success: function (response) {
                                                      console.log(response.success);
                                                      if (response.success == true) {
                                                        $('#btnOrder').attr('disabled', false);
                                                        getLatitudeLongitude(address);
                                                        setTimeout(function () {
                                                          setMarker();
                                                        }, 1000);
                                                      }
                                                      else {
                                                        $('#btnOrder').attr('disabled', true);
                                                        bootbox.alert('We do not provide service in this area. ');
                                                      }
                                                    }
                                                  });


                                                }

                                                // Get Item Deatils
                                                function getItemDetail(obj) {
                                                  var itemId = obj.val();
                                                  var token = '{{ csrf_token() }}';
                                                  if (itemId) {
                                                    $.ajax({
                                                      type: "Post",
                                                      url: "{{url('/admin/get-item-detail')}}",
                                                      data: {_token: token, itemId: itemId},
                                                      success: function (response) {
                                                        obj.parent().next('td').html(response.itemData.price);
                                                        var src = '{{ url("/public/images/upload-image.jpg")}}';
                                                        if (response.itemData.item_image) {
                                                          var src = '{{ url("/public/uploads/item-pictures/")}}/' + response.itemData.item_image;
                                                        }
                                                        obj.parent().next('td').next('td').html('<img style="hieght:70px; width:70px;" src="' + src + '">');
                                                      }
                                                    });
                                                  }
                                                }
                                                // Remove Add Items From Restaurant 
                                                function remove(obj) {
                                                  obj.parent().parent().remove();
                                                }
                                                function addMore() {
                                                  $('.category-id:last').each(function (index) {
                                                    if ($(this).val() == '') {
                                                      bootbox.alert('category can not be blank');
                                                      return false;
                                                    } else {
                                                      $('.item-id1:last').each(function () {
                                                        if ($(this).val() == '') {
                                                          bootbox.alert('Item can not be blank');
                                                          return false;
                                                        } else {
                                                          $("table tbody").append('<tr class="clone">\
                                                    <td>' + category + '</td>\
                                                    <td> </td>\
                                                    <td></td>\
                                                    <td ></td>\
                                                    <td><button class="btn btn-danger" type="button" onclick="remove($(this));"><i class="fa fa-trash" aria-hidden="true"></i></button></td>\
                                                </tr>');
                                                        }
                                                      });
                                                    }
                                                  });
                                                }
                                            </script>
                                            @stop

