@extends('admin::layouts.app')
@section('title', 'MarketPlace : Order Details')
@section('content') 
<link href="{{url('/public/css/print.css')}}" rel="stylesheet" media="print" type="text/css">
<style>

    .boxStyle {
        background-color: #fff;
        margin-bottom: 16px;
        border-radius: 6px;
        -webkit-box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
        -moz-box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
        box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
    }   
    #map-canvas {
        height: 500px;
        width: 100%;
        margin: 0px;
        padding: 0px
    }
</style>
<main class="main_content dashboardpage" id="viewAllUsers">
    <div class="main-content" style="padding:15px;">
        <section class="content-header">
            <h1>
                Order Details  
            </h1>
            <ol class="breadcrumb">
                <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="{{url('admin/order-management')}}">Order Management</a></li>
                <li class="active">Order Details</li>
            </ol>
        </section>
        <section class="content">
            <div class="box">
                <div class="box-body">
                    <div class="row margin-bottom">
                        <div class="col-sm-12 col-sm-offset-0">
                            <div class="pull-right afterPrint" style="margin-left:10px;">
                                <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
                            </div>
                            <div style="padding: 0px 0px" class="text-right afterPrint">
                                <button type="button"  class="btn btn-primary pull-right" onclick="printWindow()" ><i class="fa fa-print" aria-hidden="true"></i></button></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="boxStyle">
                        <div class="detailBox clearfix">
                            <div class="table-responsive product_table" style="padding:15px;">
                                <table class="table admin-table table-responsive" >
                                    <?php
                                    $productData = \App\Models\OrderProduct::where('order_id', '=', $orderData->id)->get();
                                    ?>
                                    <thead>
                                        <tr>
                                            <th>Qty.</th>
                                            <th>Name</th>
                                            <th>Price</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-centre"><?php $subTotal = 0; ?>
                                        @if($productData->count() > 0)
                                        @foreach ($productData as $val)
                                        <?php $itemData = $val->getItems; ?>
                                        @foreach($itemData as $item)
                                        <tr>
                                            <?php
                                            if (!empty($val->quantity)) {
                                                $quantity = $val->quantity;
                                            } else {
                                                $quantity = 1;
                                            }
                                            $subTotal = $subTotal + ($quantity * $item->price)
                                            ?>
                                            <td>
                                                {{$quantity}}
                                            </td>
                                            <td>
                                                {{$item->product_name}}
                                            </td>
                                            <td>
                                                {{App\Helpers\Helper::getPriceFormatedValue($item->price)}}
                                            </td>
                                        </tr>

                                        @endforeach
                                        @endforeach
                                        @else
                                        <tr>
                                            <td class="alert alert-danger text-center" colspan="9">
                                                {{\Config::get('constants.no_record_found')}}.
                                            </td>
                                        </tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 col-md-8">
                    <div class="boxStyle">
                        <div class="detailBox clearfix">
                            <div class="table-responsive m-t-15" style="padding:15px;">
                                <table class="table table-bordered table_b_none" >
                                    <thead>
                                        <tr>
                                            <th scope="col">Order Id :</th>
                                            <td>{{$orderData->id}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Customer Name :</th>
                                            <td>{{$orderData->getCustomer->first_name}} {{$orderData->getCustomer->last_name}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Vendor Name :</th>
                                            <td>{{$orderData->getVendor->first_name}} {{$orderData->getVendor->last_name}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Delivery Address :</th>
                                            <td>{{$orderData->drop_address}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Vehicle Type :</th>
                                            @php
                                            if($orderData->driver_id != ''){
                                            $vehicleDetail =  App\Models\DriverDetail::getVehicleDeatail($orderData->driver_id);
                                            }
                                            @endphp
                                            <td>{{(!empty($vehicleDetail) && $vehicleDetail->getVehicleData->name)? $vehicleDetail->getVehicleData->name :'-'}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Created Order Time :</th>
                                            <td>{{$orderData->created_at}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Payment Mode :</th>
                                            <td>{{$orderData->payment_mode}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Promo Code :</th>
                                            <td>
                                                @if(!empty($transactionData->voucher_id))
                                                <?php $voucherData = App\Models\Voucher::where('id', $transactionData->voucher_id)->first();
                                                ?>
                                                @if(!empty($voucherData))
                                                {{$voucherData->voucher_code}} 
                                                @else
                                                -
                                                @endif
                                                @else
                                                -
                                                @endif

                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Driver Name :</th>
                                            <?php if ($orderData->order_state == 'running') { ?>
                                                <td><?php if ($orderData->getDriver) { ?>  <a href="{{url('admin/driver-detail/'.$orderData->driver_id)}}">{{$orderData->getDriver->first_name}}</a><?php } else { ?>-<?php } ?></td>
                                            <?php } else { ?>
                                                <td>{{($orderData->getDriver)?$orderData->getDriver->first_name:'-'}}</td>
                                            <?php } ?>
                                        </tr>
                                        <tr>
                                            <th scope="col">Amount :</th>
                                            <td>{{App\Helpers\Helper::getPriceFormatedValue(App\Models\OrderProduct::getAmountByOrderId($orderData->id))}} </td>
                                        </tr>
                                        <tr>    
                                            <th scope="col">Shipping Charges :</th>
                                            <td>{{App\Helpers\Helper::getPriceFormatedValue($orderData->shipping_charge)}} </td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Order State :</th>
                                            <td>
                                            @if($orderData->order_state == 'out_for_delivery')
                                            Out For Delivery.
                                            @elseif($orderData->order_state == 'pending')
                                            Pending.
                                            @elseif($orderData->order_state == 'running')
                                            Running.
                                            @elseif($orderData->order_state == 'vendor_pending')
                                            Vendor Pending.
                                            @elseif($orderData->order_state == 'completed')
                                            Delivered.
                                            @elseif($orderData->order_state == 'cancelled')
                                            Cancelled.
                                            @elseif($orderData->order_state == 'out_for_pickup')
                                            Ready For Pickup.
                                            @endif
                                        </td>
                                        </tr>
                                        @if($orderData->order_state == 'pending')
                                        <tr>
                                            <td colspan="2" class="text-right">
                                                <a class="btn btn-success m-t-15 m-r-10" href="{{url('admin/assign-driver/'.$orderData->id)}}">Assign Driver</a>
                                            </td>
                                        </tr>   
                                        @endif
                                    </thead>
                                </table>    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="boxStyle">
                        <div class="detailBox clearfix">
                            <div class="detail">
                                <div class="table-responsive m-t-15" style="padding:15px;">
                                    <table class="table table-bordered table_b_none" >
                                        <thead>
                                            <tr>
                                                <th scope="col">Subtotal :</th>
                                                <td class="text-right">{{ App\Helpers\Helper::getPriceFormatedValue($subTotal)}} </td>
                                            </tr>
                                            <tr>
                                                <th scope="col">Delivery Fee :</th>
                                                <td class="text-right">{{App\Helpers\Helper::getPriceFormatedValue($orderData->shipping_charge)}} </td>
                                            </tr>
                                            <tr>
                                                <th scope="col">Processing Fee :</th>
                                                <td class="text-right">{{App\Helpers\Helper::getPriceFormatedValue($orderData->processing_fee)}}</td>
                                            </tr>
                                            @if(!empty($voucherData))
                                            <tr>
                                                <th scope="col">Promo Code :</th>
                                                <td class="text-right">
                                                    - {{App\Helpers\Helper::getPriceFormatedValue($voucherData->voucher_amount)}} 
                                                </td>
                                            </tr>
                                            @endif
                                            <tr>
                                                <th scope="col">Total :</th>
                                                <th class="text-right">{{App\Helpers\Helper::getPriceFormatedValue($orderData->total_amount)}} </th>
                                            </tr>
                                        </thead>
                                    </table>    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @php 
            if($orderData->order_state == 'out_for_pickup'){
            $mapShow = 'block';
            $picupLatLong = App\Helpers\Helper::getLatLangByAddress($orderData->current_location);
            $piclatlong = explode(',', $picupLatLong);
            $deliveryLatLong = App\Helpers\Helper::getLatLangByAddress($orderData->drop_address);
            $droplatlong = explode(',', $deliveryLatLong);
            $latitudeFrom = (!empty($piclatlong) && $piclatlong[0] != '') ? $piclatlong[0] :  22.719568;
            $longitudeFrom = (!empty($piclatlong) && $piclatlong[0] != '') ? $piclatlong[1] : 75.857727;
            $latitudeTo = (!empty($droplatlong) && $droplatlong[0] != '') ? $droplatlong[0] :  22.719568;
            $longitudeTo = (!empty($droplatlong) && $droplatlong[0] != '') ? $droplatlong[1] : 75.857727;
            }
            else{
            $latitudeFrom = 0;
            $longitudeFrom = 0;
            $latitudeTo = 0;
            $longitudeTo =0;
            $mapShow = 'none';
            }
            @endphp
            @if($orderData->order_state == 'out_for_pickup')
            <div class="row">
                <div class="col-lg-8">
                    <div class="boxStyle">
                        <div class="detailBox clearfix">
                            <div class="table-responsive product_table" style="padding:15px;">

                                <div id="mapCanvas" style="height:500px; width: 100%; display: <?php echo $mapShow; ?>" > ></div>

                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            @endif
            <div class="clairfix"></div>
    </div>
</section>

</main>
<script>
            function printWindow() {
            $('.afterPrint').hide();
                    window.print();
            }
//location map

    window.onload = function () {
    var orderStatus = '{{$orderData->order_state}}';
            var testmarkers = [];
            var id = '';
            var markers = [
            {
            "title": 'Pickup Address',
                    "lat": '{{$latitudeFrom}}',
                    "lng": '{{$longitudeFrom}}',
                    "description": '<b>Pickup Address:</b><br>{{ $orderData->getVendor->address}}'
            }
            ,
            {
            "title": 'Delivery Address',
                    "lat": '{{ $latitudeTo}}',
                    "lng": '{{$longitudeTo}}',
                    "description": '<b>Delivery Address:</b><br>{{ $orderData->drop_address}}'
            }
            ];
            var mapOptions = {
            center: new google.maps.LatLng({{$latitudeFrom}}, {{ $longitudeFrom}}),
                    zoom: 12,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            var map = new google.maps.Map(document.getElementById("mapCanvas"), mapOptions);
            //moveMarker(map, marker);

            var infoWindow = new google.maps.InfoWindow();
            var lat_lng = new Array();
            var latlngbounds = new google.maps.LatLngBounds();
            for (i = 0; i < markers.length; i++) {
    var data = markers[i]
            var myLatlng = new google.maps.LatLng(data.lat, data.lng);
            lat_lng.push(myLatlng);
            var marker = new google.maps.Marker({
            position: myLatlng,
                    map: map,
                    title: data.title
            });
            latlngbounds.extend(marker.position);
            (function (marker, data) {
            google.maps.event.addListener(marker, "click", function (e) {
            infoWindow.setContent(data.description);
                    infoWindow.open(map, marker);
            });
            })(marker, data);
    }
    map.setCenter(latlngbounds.getCenter());
            map.fitBounds(latlngbounds);
            //***********ROUTING****************//

            //Initialize the Path Array
            var path = new google.maps.MVCArray();
            //Initialize the Direction Service
            var service = new google.maps.DirectionsService();
            //Set the Path Stroke Color
            var poly = new google.maps.Polyline({map: map, strokeColor: '#4986E7'});
            //Loop and Draw Path Route between the Points on MAP
            var i = 0;
            if ((i + 1) < lat_lng.length) {
    var src = lat_lng[i];
            var des = lat_lng[i + 1];
            path.push(src);
            poly.setPath(path);
            service.route({
            origin: src,
                    destination: des,
                    travelMode: google.maps.DirectionsTravelMode.DRIVING
            }, function (result, status) {
            if (status == google.maps.DirectionsStatus.OK) {
            for (var i = 0, len = result.routes[0].overview_path.length; i < len; i++) {
            path.push(result.routes[0].overview_path[i]);
            }
            }
            });
    }

    }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBGocP68eNm-t9-nlljUPFjnFU8DCNahIk&libraries=geometry,places,drawing&ext=.js"></script>
@stop
