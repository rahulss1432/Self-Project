@extends('admin::layouts.app')
@section('title', 'MarketPlace : Order Management')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Order Management
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/order-management')}}">Order Management</a></li>
            <li class="active">Order Listing</li>
        </ol>
    </section>
    
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" onclick="show_serach()" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class=" btn btn-primary" href="{{url('/admin/create-order')}}"> <i class="fa fa-plus-circle"></i>  Create Order</a>
                        </div>
                    </div>
                </div>
                <form id="searchForm" style="display: none;" action="javascript:load_order_list();" method="post">
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-2">
                            <label>Order ID</label> 
                            <input class="form-control" name="order_id" type="text" id="orderId" placeholder="Order ID">
                        </div>
                        <div class="col-md-2">
                            <label>Customer Name</label>
                            <input class="form-control" name="customer_name" type="text" id="customerName" placeholder="Customer Name">
                        </div>
                        <div class="col-md-2">
                            <label>Email</label> 
                            <input class="form-control" name="email" type="text" id="email" placeholder="Email">
                        </div>
                        <div class="col-md-2">
                            <label> Mobile Number</label> 
                            <input class="form-control" name="mobile" type="text" id="mobile" placeholder="Mobile Number ">
                        </div>
                        <div class="col-md-2">
                            <label> Vendor Name</label> 
                            @php echo \App\Models\User::getVendorNameDropdown(0); @endphp
                        </div>
                        <div class="col-md-2">
                            <label> Delivery address</label> 
                            <input class="form-control" name="delivery_address" type="text" id="deliveryAddress" placeholder="Delivery address ">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">
                            <label>  Payment mode</label>
                            <select class="form-control " id="paymentMode" name="payment_mode">
                                <option value="">--Select Payment Mode--</option>
                                <option value="cod">COD</option>
                            </select> 
                        </div>
                        <div class="col-md-2">
                            <label>  Driver Name</label> 
                            <input class="form-control" name="driver_name" type="text" id="driverName" placeholder="Driver Name">
                        </div>
                        <div class="col-md-2">
                            <label> Order state</label>
                            <select class="form-control " id='order_state' name="order_state">
                                <option value="">--Select Order State--</option>
                                <option value="pending">Pending</option>
                                <option value="completed">Completed </option>
                                <option value="cancelled">Cancelled </option>
                                <option value="running">Running </option>
                                <option value="vendor_pending ">Vendor Pending </option>
                            </select> 
                        </div>
                        
                        <div class="col-md-2">
                            <br>
                            <button id="btn-sub" type="submit" class="btn btn-primary">
                                Filter <i id="add-loader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                            <button id="btn-sub" type="submit" class="btn btn-primary" onclick="reset_order_list();">
                                Reset <i id="add-loader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>

                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="listingOrder">
                        
                    </div>
                </div>
            </div>
        </div>

    </section>
</main>

<script>
    function show_serach() {
        $("#searchForm").slideToggle("slow");
    }
    $(document).ready(function ()
    {
        load_order_list();
    });
    function reset_order_list() {
        $('#searchForm')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        load_order_list()
    }

    function load_order_list() {
        $("#listingOrder").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
        var search_filter = $("#searchForm").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "Post",
            url: "{{url('/admin/list-order')}}",
            data: search_filter,
            success: function (response) {
                $("#listingOrder").html(response.html);
            }
        });
    }
</script>
@stop