@extends('admin::layouts.app')
@section('title', 'MarketPlace : Create Content')
@section('content')
<script src="{{url('public/js/tinymce/tinymce.min.js') }}"></script>
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Content Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/content-list')}}">Content Management</a></li>
            <li class="active">Create Content</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Create Content</h3>
                    </div>
                    <form id="frmAddContentForm" method="post" class="form-horizontal" action="{{url('admin/save-content')}}" style="padding-top:20px;">
                        {{ csrf_field() }}
                        <div class="box-body">
                            <div class="form-group">
                                <label class="control-label col-sm-2">Page Title <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="page_title" id="pageTitle" class="form-control" placeholder="Page Title" autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2 descLebel">Description <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <textarea name="description" id="description"></textarea>
                                    <span class="descError"></span>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button id="btnAddContent" type="submit" class="btn btn-primary pull-right submitButton">
                                Add Content <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\CreateContentRequest','#frmAddContentForm') !!}
                </div>
            </div>
        </div>
    </section>
</main>
<script>
tinymce.init({
  theme: "modern",
  selector: "textarea",
  setup: function (ed) {
    ed.on("keyup", function () {
      $('.descError').html("");
      $('#mceu_14').css('border-color', '#00a65a');
      $('.descLebel').css('color', '#00a65a');
    });
  },
  relative_urls: false,
  remove_script_host: false,
  height: 200,
  plugins: "image code",
  font_formats: 'Andale Mono=andale mono,times;Arial=arial,helvetica,sans-serif;Arial Black=arial black,avant garde;Book Antiqua=book antiqua,palatino;Comic Sans MS=comic sans ms,sans-serif;Courier New=courier new,courier;Georgia=georgia,palatino;Helvetica=helvetica;Impact=impact,chicago;Symbol=symbol;Tahoma=tahoma,arial,helvetica,sans-serif;Terminal=terminal,monaco;Times New Roman=times new roman,times;Trebuchet MS=trebuchet ms,geneva;Verdana=verdana,geneva;Webdings=webdings;Wingdings=wingdings,zapf dingbats',
});
$('#frmAddContentForm').on('submit', function (e) {
  $('.descError').html("");
  $('#mceu_14').css('border-color', '#00a65a');
  $('.descLebel').css('color', '#00a65a');
  var editorContent = tinyMCE.get('description').getContent();
  if (editorContent == '')
  {
    $('.descError').css('color', '#dd4b39').html("Description field is required");
    $('#mceu_14').css('border-color', '#dd4b39');
    $('.descLebel').css('color', '#dd4b39');
    return false;
  } else {
    if ($('#frmAddContentForm').valid()) {
      $('#addLoader').show();
      $("#btnAddContent").prop('disabled', true);
    } else {
      $('#addLoader').hide();
      $("#btnAddContent").prop('disabled', false);
    }
  }
});
</script>
@stop