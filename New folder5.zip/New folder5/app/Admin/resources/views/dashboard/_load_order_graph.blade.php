<style>
    div.google-visualization-tooltip {
        position: absolute !important;
        margin-left: -104px;
        margin-top: -10px;
        border-color: rgb(51, 102, 204) !important;
    }
    div.google-visualization-tooltip > ul > li > span {
        color: rgb(51, 102, 204) !important;
    }
    div.google-visualization-tooltip::after {
        content: "";
        position: absolute;
        top: 100%;
        left: 50%;
        margin-left: -5px;
        border-width: 5px;
        border-style: solid;
        border-color: rgb(51, 102, 204) transparent transparent transparent;
    }
</style>
@if($ordersdetails->count()>0)
<div id="columnchartMaterial" style="width: 100%; height: 400px; padding: 15px;"></div>
<script type="text/javascript">
    google.charts.load('current', {'packages': ['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var dataTable = new google.visualization.DataTable();
      dataTable.addColumn('string', 'Day');
      dataTable.addColumn('number', 'Orders');
      dataTable.addColumn({type: 'string', role: 'tooltip'});
      dataTable.addRows([
<?php
foreach ($ordersdetails as $data) {
    ?>
            ["<?php echo date("d", strtotime($data->created_at)) ?>",<?php echo $data->count_order ?>, "Date:<?php echo date("d", strtotime($data->created_at)) ?>, Orders:<?php echo $data->count_order ?>"],
    <?php
}
?>
              ]);
              var options = {
                title: 'Order per day chart',
                vAxis: {
                  title: 'Values',
                },
                bar: {groupWidth: "50%"},
//                tooltip: {isHtml: true},
                vAxes: [{
                    title: 'Values',
                    titleTextStyle: {color: '#666666'},
                    textStyle: {color: '#666'},
                    gridlines: {color: '#f5f5f5', count: 4},
                    baselineColor: '#bbb'
                  }, {
                    minValue: 0,
                    min: 0,
                    titleTextStyle: {color: '#666666'},
                    textStyle: {color: '#666'},
                    gridlines: {color: '#f5f5f5', count: 4},
                    baselineColor: '#bbb'
                  }],
                hAxis: {
                  title: 'Day',
                  titleTextStyle: {color: '#666666'},
                  count: 1,
                  textStyle: {color: '#666666'}
                },
              };
              var chart = new google.visualization.ColumnChart(document.getElementById('columnchartMaterial'));
              google.visualization.events.addListener(chart, 'ready', titleCenter);
              chart.draw(dataTable, options);
            }
            function titleCenter() {
              var titleChart = $("#columnchartMaterial svg g").find('text').html();
              $("#columnchartMaterial svg").find('g:first').html('<text text-anchor="start" x="500" y="25" style="cursor: default; user-select: none; font-style: italic; font-family: Roboto; font-size: 18px; font-weight: bold;" fill="#757575" dx="0px">' + titleChart + '</text>');
            }
</script>
@else
<div class="alert alert-danger text-center">
    {{\Config::get('constants.no_record_found')}}
</div>
@endif
@if($ordersdetails->count()>0)
<div id="columnchartEarning" style="width: 100%; height: 400px; padding: 15px;"></div>
<script type="text/javascript">
    google.charts.load('current', {'packages': ['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var dataTable = new google.visualization.DataTable();
      dataTable.addColumn('string', 'Day');
      dataTable.addColumn('number', 'Earning');
      dataTable.addColumn({type: 'string', role: 'tooltip'});
      dataTable.addRows([
<?php
foreach ($ordersdetails as $data) {
    ?>
            ["<?php echo date("d", strtotime($data->created_at)) ?>", <?php echo $data->amount > 0 ? $data->amount : 0 ?>, "Date:<?php echo date("d", strtotime($data->created_at)) ?>, Earning:<?php echo $data->amount > 0 ? $data->amount : 0 ?>"],
    <?php
}
?>
              ]);
              var options = {
                title: 'Earning per day chart',
                vAxis: {
                  title: 'Values',
                },
                bar: {groupWidth: "50%"},
//                tooltip: {isHtml: true},
                vAxes: [{
                    title: 'Values',
                    titleTextStyle: {color: '#666666'},
                    textStyle: {color: '#666'},
                    gridlines: {color: '#f5f5f5', count: 4},
                    baselineColor: '#bbb'
                  }, {
                    minValue: 0,
                    min: 0,
                    titleTextStyle: {color: '#666666'},
                    textStyle: {color: '#666'},
                    gridlines: {color: '#f5f5f5', count: 4},
                    baselineColor: '#bbb'
                  }],
                hAxis: {
                  title: 'Day',
                  titleTextStyle: {color: '#666666'},
                  count: 1,
                  textStyle: {color: '#666666'}
                },
              };
              var chart = new google.visualization.ColumnChart(document.getElementById('columnchartEarning'));
              google.visualization.events.addListener(chart, 'ready', titleCenter1);
              chart.draw(dataTable, options);
            }
            function titleCenter1() {
              var titleChart = $("#columnchartEarning svg g").find('text').html();
              $("#columnchartEarning svg").find('g:first').html('<text text-anchor="start" x="500" y="25" style="cursor: default; user-select: none; font-style: italic; font-family: Roboto; font-size: 18px; font-weight: bold;" fill="#757575" dx="0px">' + titleChart + '</text>');
            }
</script>
<div style="padding: 15px; text-align:center;">
    <a class="btn btn-primary btn-pad btn-rounded m-t-15 text-center" id="btnDownloadCsv" href="{{ url('/admin/earning-csv-download') }}"> <i class="fa fa-upload"></i> Export Earning Report</a>
</div>
@else

@endif