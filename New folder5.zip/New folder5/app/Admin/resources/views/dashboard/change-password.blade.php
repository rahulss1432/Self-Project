@extends('admin::layouts.app')
@section('title', 'MarketPlace : Change Password')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Profile</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Change Password</li>
        </ol>
    </section>
    <section class="page_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="counter" style="padding: 10px;">
                            <div class="featured-box col-md-12" style="background-color: white; border-radius: 20px;">
                                <div class="table-responsive product_table" style="padding:15px;">
                                    <table class="table table-bordered table_b_none">
                                        <thead >
                                            <tr>
                                                <th colspan="2"><h4 class="md-headline blue">Change Password</h4></th>
                                            </tr>
                                            <tr style="border: none;">
                                                <th colspan="2"><div class="clairfix"></div></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td colspan="2">
                                                    <form id="change-password" class="col s12"  action="{{url('/admin/admin-save-change-password')}}" method="post" style="border: 1px black;">
                                                        {{csrf_field()}}
                                                        <div class="dashboard-list-box-static">
                                                            <div class="my-profile">
                                                                <div class="row">
                                                                    <div class="col-md-3 text-center">
                                                                        <label class="margin-top-0" label-for="current_password">Current Password : </label>
                                                                    </div>
                                                                    <div class="col-md-9 text-center">
                                                                        <div class="form-group">
                                                                            <input type="password" class="form-control input-lg" name="current_password" style="width: 100%;">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-3 text-center">
                                                                        <label class="margin-top-0" label-for="password">New Password :</label>
                                                                    </div>
                                                                    <div class="col-md-9 text-center">
                                                                        <div class="form-group">
                                                                            <input type="password" class="form-control input-lg" name="password" style="width: 100%;">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-3 text-center">
                                                                             <label class="margin-top-0" label-for="confirm_password">Confirm Password</label>
                                                                    </div>
                                                                    <div class="col-md-9 text-center">
                                                                        <div class="form-group">
                                                                            <input type="password" class="form-control input-lg" name="confirm_password" style="width: 100%;">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-3 text-center">
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <div class="form-group">
                                                                            <input type="submit" value="Change Password" id="changeBtn"  class="form-control input-lg btn btn-primary" style="width: 100%;"> 
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </td>
                                            </tr>                                            
                                        </tbody>
                                    </table>                                
                                {!! JsValidator::formRequest('App\Admin\Http\Requests\ChangePasswordRequest','#change-password') !!}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    window.addEventListener('beforeunload', function(event) {
        $("#changeBtn").attr("disabled", true);
        $("#changeBtn").attr("value",'Please wait...');
    });
</script>
@stop
