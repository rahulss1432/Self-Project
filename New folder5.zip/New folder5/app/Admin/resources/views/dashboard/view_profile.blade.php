@extends('admin::layouts.app')

@section('content') 
<style>
    table {
    width:50%;
}
table, th, td {
   
    border-collapse: collapse;
}
th, td {
    padding: 15px;
    text-align: left;
}
</style>
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            My Profile
        </h1>
    </section>
    <section class="content">
        <div class="box">                       
            <div class=" col-sm-4 box-body ">
                <div class="row margin-bottom"> 
                    <div class="">
                        <div style="padding: 10px 0px" class="text-right">

                            <a class=" btn btn-primary" href="{{url('/admin/edit-profile/' ).'/'.$userData->id}}"> <i class="fa fa-pencil-square-o"></i></a>
                            <center>
                                <table >
                                    <tr >
                                      
                                        <td colspan="2"><img src="{{App\Helpers\Helper::checkUserImage($userData->profile_picture)}}" style="border-radius: 50%;" hieght="200" width="200"> </td> 
                                    </tr>
                                    <tr >
                                        <th>Name:</th> 
                                        <td>{{$userData->first_name .' ' .$userData->last_name }}</td> 
                                    </tr>
                                    <tr >
                                        <th>Email:</th> 
                                        <td>{{$userData->email}} </td> 
                                    </tr>
                                </table>
                            </center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>
@stop