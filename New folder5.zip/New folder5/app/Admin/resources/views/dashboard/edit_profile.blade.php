@extends('admin::layouts.app')
@section('title', 'MarketPlace : Edit Profile')
@section('content') 
<style>
    table {
        width:50%;
    }
    table, th, td {

        border-collapse: collapse;
    }
    th, td {
        padding: 15px;
        text-align: left;
    }
</style>
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Edit Profile
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/my-profile')}}">My Profile</a></li>
            <li class="active">Edit Profile</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">    
            <div class="pull-right">
                <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
            </div>
            <div class="box-body">
                <div class="row margin-bottom">
                    <section class="content">
                        <div class="row">
                            <div class="col-md-3"></div>
                            <div class="col-md-6">
                                <div class="box box-info">
                                    <form class="form-horizontal" id="admin-edit-form" method="post" action="{{url('/admin/update-admin-profile')}}">
                                        {{csrf_field()}}
                                        <input type="hidden" id="id" name="adminId" value="{{$userData->id}}">

                                        <div class="box-body">
                                            <div class="form-group">
                                                <label for="" class="col-sm-3 control-label"></label>

                                                <div class="col-sm-9">
                                                    <img id="crop-img" src="{{App\Helpers\Helper::checkUserImage($userData->profile_picture)}}" style="border-radius: 50%; margin-left: 150px;" hieght="200" width="200">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="" class="col-sm-3 control-label">Profile Pictures</label>

                                                <div class="col-sm-9">
                                                    <input type="file" class="form-control input-lg" onchange="setImage(this)" id="cropImageInput" name="">
                                                    <input type="hidden" name="profile_picture" class="form-control input-lg" id="profile_picture" value="{{$userData->profile_picture}}">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="first_name" class="col-sm-3 control-label">first Name</label>

                                                <div class="col-sm-9">
                                                    <input type="text" name="first_name" class="form-control input-lg" id="first_name" value="{{$userData->first_name .' '.$userData->last_name}}">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="email" class="col-sm-3 control-label">Email</label>

                                                <div class="col-sm-9">
                                                    <input type="text" name="email" class="form-control input-lg" id="email" value="{{$userData->email}}">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="email" class="col-sm-3 control-label"></label>
                                                <div class=" col-sm-9">
                                                    <button id="btn-admin-edit" type="submit" class="btn btn-info" style="width:100%;">
                                                        Save <i id="add-loader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                                                    </button>
                                                </div>
                                            </div>
                                    </form>
                                    {!! JsValidator::formRequest('App\Admin\Http\Requests\EditAdminRequest','#admin-edit-form') !!} 
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </section>
</main>
<div id="imageCropperModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Crop Image</h4>
            </div>
            <div class="modal-body">

                <img alt="image" src="" id="crop_image" class="img-responsive"/>
                <input type="hidden" id="imageBaseCode">

                <div class="clearfix"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="cropbutton">Save</button>
            </div>
        </div>

    </div>
</div>

<script>

    $('#admin-edit-form').on('submit', function (e) {
      if ($('#admin-edit-form').valid()) {
        $('#add-loader').show();
        document.getElementById("btn-admin-edit").disabled = true;
      } else {
        $('#add-loader').hide();
        document.getElementById("btn-admin-edit").disabled = false;
      }
    });


    var fileTypes = ['jpg', 'jpeg', 'png'];
    function setImage(input) {
      $('#crop_image').attr('src', '');
      if (input.files && input.files[0]) {
        var extension = input.files[0].name.split('.').pop().toLowerCase(), isSuccess = fileTypes.indexOf(extension) > -1;
        if (isSuccess) {
          var reader = new FileReader();
          reader.onload = function (e) {
            $('#crop_image').attr('src', e.target.result);
            $('#imageBaseCode').val(e.target.result)
            loadCropper();
          };
          reader.readAsDataURL(input.files[0]);
        } else {
          bootbox.alert('Only jpg, jpeg, png files are allowed.');
          var $el = $('#cropImageInput');
          $el.wrap('<form>').closest('form').get(0).reset();
          $el.unwrap();
        }
      }
    }


    $('#imageCropperModal').on('hidden.bs.modal', function (e) {
      var $image = $("#crop_image");
      var input = $("#cropImageInput");
      input.replaceWith(input.val('').clone(true));
      $image.cropper("destroy");
    })
//cropper
    function loadCropper() {
      var $image = $("#crop_image");
      $("#imageCropperModal").modal("show");
      $image.cropper({
        viewMode: 1,
        dragMode: 'move',
        autoCropArea: 0.65,
        restore: false,
        highlight: true,
        movable: false,
        zoomable: true,
        rotatable: true,
        center: false,
        scalable: false,
        responsive: true,
        strict: true,
        cropBoxResizable: false,
      });
    }
    $("#cropbutton").click(function () {
      var $image = $("#crop_image");
      var imageBaseCode = $('#imageBaseCode').val();
      var imageCropedData = $image.cropper('getData');
      var croppedWidth = imageCropedData.width;
      var croppedHeight = imageCropedData.height;
      var croppedX = imageCropedData.x;
      var croppedY = imageCropedData.y;
      var rotate = imageCropedData.rotate;
      var url = "{{url('admin/save-cropped-image')}}";
      $.ajax({
        type: "POST",
        url: url,
        dataType: 'JSON',
        data: {
          imageBaseCode: imageBaseCode,
          croppedWidth: croppedWidth,
          croppedHeight: croppedHeight,
          croppedX: croppedX,
          croppedY: croppedY,
          rotate: rotate,
          _token: '{{csrf_token()}}'
        },
        success: function (response) {
          if (response.success) {
            $("#imageCropperModal").modal("hide");
            $image.cropper('destroy');
            var src = '{{ url("/public/uploads/temp/")}}/' + response.filename;
            $('#crop-img').attr('src', src);
            $('#profile_picture').val(response.filename);
            console.log(response.filename);
          }
        }
      });
    });


</script>
@stop