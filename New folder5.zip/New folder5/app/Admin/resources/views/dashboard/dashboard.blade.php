@extends('admin::layouts.app')
@section('title', 'MarketPlace : Dashboard')
@section('content') 
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<style>
    .row {
        margin-right: -15px;
        margin-left: -15px;
        margin-top: 15px;
        margin-bottom: 15px;
    }    
    .btn-filter {
        line-height: 40px;
        background-color: #3b7bfc;
        width: 40px;
        height: 40px;
        display: inline-block;
        text-align: center;
        top: -7px;
        border-radius: 50%;
    }
    .boxStyle {
        background-color: #fff;
        margin-bottom: 16px;
        padding-left: 15px;
        padding-right: 15px;
        border-radius: 6px;
        -webkit-box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
        -moz-box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
        box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
    }
    .btn-toolbar {
        margin-left: 15px;
    }
</style>
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="page_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="counter ">
                            <section class="content">
                                <div class="row">
                                    <div class="col-lg-4 col-xs-6">
                                        <div class="small-box bg-red">
                                            <div class="inner">
                                                <h3>{{ App\Helpers\Helper::getAllorderscount()}}</h3>
                                                <p><a href="{{url('/admin/order-management')}}" style="color: white;">Total Orders</a></p>
                                            </div>
                                            <div class="icon">
                                                <i class="fa fa-building-o"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-xs-6">
                                        <div class="small-box bg-aqua">
                                            <div class="inner">
                                                <h3>{{ App\Helpers\Helper::getAllitemscount()}}</h3>
                                                <p><a href="{{url('/admin/item-management')}}" style="color: white;">Total Items</a></p>
                                            </div>
                                            <div class="icon">
                                                <i class="fa fa-user"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-xs-6">
                                        <div class="small-box bg-blue">
                                            <div class="inner">
                                                <h3>{{ App\Helpers\Helper::getTotalearning()}}</h3>
                                                <p><a href="{{url('/admin/transactions')}}" style="color: white;">Total Earning</a></p>
                                            </div>
                                            <div class="icon">
                                                <i class="fa fa-usd"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <h2 class="md-headline green">Order and App Earning statistics</h2>
                                        <div class="innerfilterOption boxStyle clearfix" id="filterBox">
                                            <form id="searchForm" name="searchFrm">
                                                {{ csrf_field() }}
                                                <div class="row filterOption">
                                                    <div class="col-lg-3 col-md-3">
                                                        <label>Start Date</label>
                                                        <input type="text" name="orderStartDate" id="start_date" class="form-control time startTime datepicker" placeholder="Start Date" value="">
                                                    </div>
                                                    <div class="col-lg-3 col-md-3">
                                                        <label>End Date</label> <input type="text" id="end_date"  name="orderEndDate" class="form-control time startTime datepicker" placeholder="End Date" value="">
                                                    </div>
                                                    <div class="col-lg-3 col-md-3">
                                                        <label></label>
                                                        <button type="button" class="btn btn-primary btn-block" onclick="loadOrderGraph();">Filter</button>
                                                    </div>
                                                    <div class="col-lg-3 col-md-3">
                                                        <label></label>
                                                        <button type="reset" onclick="resetFunction();" class="btn btn-primary btn-block">Reset</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="boxStyle" id="orderGraph">

                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="content">
                                <div class="col-lg-6 boxStyle">
                                    <div class="btn-toolbar">
                                        <h2 class="md-headline green">Order statistics</h2>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="table-responsive">
                                                <h4 class="box-heading">Running Order (s)</h4>
                                                <table md-colresize="md-colresize" class="table inner-table">
                                                    <thead>  
                                                        <tr class="md-table-headers-row">
                                                            <th>No.</th>
                                                            <th>Order ID</th>
                                                            <th>Details</th>
                                                        </tr>
                                                    </thead>
                                                    @if(count($runningOrderData) > 0)
                                                    @php
                                                    $i = 1;
                                                    @endphp
                                                    @foreach($runningOrderData as $data)                                      
                                                    @if($i == 6)                          
                                                    @break;
                                                    @endif                                      
                                                    <tbody class="md-table-content">
                                                        <tr>
                                                            <td>{{$i}}</td>
                                                            <td>{{$data->id}}</td>
                                                            <td><a href="{{url('admin/view-order/'.$data->id)}}" class="detailBtn">Go to detail</a></td>
                                                        </tr>
                                                    </tbody> 
                                                    @php
                                                    $i++;
                                                    @endphp
                                                    @endforeach
                                                    @else
                                                    <tr class="text-center"><td colspan="10"><div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div></td></tr>
                                                    @endif
                                                </table>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="table-responsive">
                                                <h4 class="box-heading">New Order (s)</h4>
                                                <table md-colresize="md-colresize" class="table inner-table">
                                                    <thead>  
                                                        <tr class="md-table-headers-row">
                                                            <th>No.</th>
                                                            <th>Order ID</th>
                                                            <th>Details</th>
                                                        </tr>
                                                    </thead>
                                                    @if(count($newOrderData) > 0)
                                                    @php
                                                    $i = 1;
                                                    @endphp
                                                    @foreach($newOrderData as $newdata)                                      
                                                    @if($i == 6)                          
                                                    @break;
                                                    @endif                                      
                                                    <tbody class="md-table-content">
                                                        <tr>
                                                            <td>{{$i}}</td>
                                                            <td>{{$newdata->id}}</td>
                                                            <td><a href="{{url('admin/view-order/'.$newdata->id)}}" class="detailBtn">Go to detail</a></td>
                                                        </tr>
                                                    </tbody> 
                                                    @php
                                                    $i++;
                                                    @endphp
                                                    @endforeach
                                                    @else
                                                    <tr class="text-center"><td colspan="10"><div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div></td></tr>
                                                    @endif
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                    </section>
                    </main>
                    <script type="text/javascript">
                        $(document).ready(function () {
                          loadOrderGraph();
                          $("#start_date").datepicker({
                            todayBtn: 1,
                            autoclose: true,
                            //        startDate: new Date(),
                            todayHighlight: true,
                          }).on('changeDate', function (selected) {
                            var minDate = new Date(selected.date.valueOf());
                            $('#end_date').datepicker('setStartDate', minDate);
                          });
                          $("#end_date").datepicker({
                            todayHighlight: true,
                            startDate: new Date(),
                          }).on('changeDate', function (selected) {
                            var maxDate = new Date(selected.date.valueOf());
                            $('#start_date').datepicker('setEndDate', maxDate);
                          });
                        });
                        function loadOrderGraph() {
                          var order_filter = $("#searchForm").serializeArray();
                          var token = '{{ csrf_token() }}';
                          $.ajax({type: "POST",
                            url: "{{ url('admin/load-order-graph') }}",
                            data: order_filter,
                            success: function (response) {
                              $('#orderGraph').html(response.html);
                            }
                          });
                        }
                        function resetFunction() {
                          $('#searchForm')[0].reset();
                          $('.selectpicker').selectpicker('refresh');
                          loadOrderGraph();
                        }
                    </script>
                    @stop