@if($ordersdetails->count()>0)
<div id="columnchartMaterial" style="width: 100%; height: 400px; padding: 15px;"></div>
<script type="text/javascript">
    google.charts.load('current', {'packages': ['bar']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Day', 'Orders'],
<?php
foreach ($ordersdetails as $data) {
    ?>
            ["<?php echo date("d", strtotime($data->created_at)) ?>", "<?php echo $data->count_order ?>"],
    <?php
}
?>
      ]);
      var options = {
        title: 'Order per day chart',
        vAxis: {
          title: 'Values',
        },
        bar: {groupWidth: "30%"},
      };
      var chart = new google.charts.Bar(document.getElementById('columnchartMaterial'));
      google.visualization.events.addListener(chart, 'ready', titleCenter);
      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
    function titleCenter() {
      var titleChart = $("#columnchartMaterial svg g").find('text').html();
      $("#columnchartMaterial svg").find('g:first').html('<text text-anchor="start" x="500" y="25" style="cursor: default; user-select: none; font-style: italic; font-family: Roboto; font-size: 18px; font-weight: bold;" fill="#757575" dx="0px">' + titleChart + '</text>');
    }
</script>
@else
<div class="alert alert-danger text-center">
    {{\Config::get('constants.no_record_found')}}
</div>
@endif
@if($ordersdetails->count()>0)
<div id="columnchartEarning" style="width: 100%; height: 400px; padding: 15px;"></div>
<script type="text/javascript">
    google.charts.load('current', {'packages': ['bar']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Day', 'Earning'],
<?php
foreach ($ordersdetails as $data) {
    ?>
            ["<?php echo date("d", strtotime($data->created_at)) ?>", "<?php echo $data->amount > 0 ? $data->amount : 0 ?>"],
    <?php
}
?>
      ]);
      var options = {
        chart: {
          title: 'Earning per day chart',
          subtitle: '',
        },
        vAxis: {
          title: 'Values',
        },
        bar: {groupWidth: "25%"},
      };
      var chart = new google.charts.Bar(document.getElementById('columnchartEarning'));
      google.visualization.events.addListener(chart, 'ready', titleCenter1);
      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
    function titleCenter1() {
      var titleChart = $("#columnchartEarning svg g").find('text').html();
      $("#columnchartEarning svg").find('g:first').html('<text text-anchor="start" x="500" y="25" style="cursor: default; user-select: none; font-style: italic; font-family: Roboto; font-size: 18px; font-weight: bold;" fill="#757575" dx="0px">' + titleChart + '</text>');
    }
</script>
<div style="padding: 15px; text-align:center;">
    <a class="btn btn-primary btn-pad btn-rounded m-t-15 text-center" id="btnDownloadCsv" href="{{ url('/admin/earning-csv-download') }}"> <i class="fa fa-upload"></i> Export Earning Report</a>
</div>
@else

@endif