@extends('admin::layouts.app')
@section('title', 'MarketPlace : Edit Vendor')
@section('content')
<style>  
    .uplod-btn {
        position: relative;
        overflow: hidden;
        display: inline-block;
        border: 1px solid #00BFFF;
        box-shadow: 0px 0px 1px 1px #00BFFF;
    }
    .uplod-btn input[type=file] {
        position: absolute;
        left: 0;
        top: 0;
        opacity: 0;
        height: 255px;
        cursor: pointer;
    }
</style>
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Setup Vendor & Restaurant</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/vendor-list')}}">Vendor Management</a></li>
            <li class="active">Setup Vendor & Restaurant</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Setup Vendor & Restaurant</h3>
                    </div>
                    <form id="editVendorForm" class="form-horizontal" method="POST" action="{{url('admin/update-vendor')}}" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <input type="hidden" name="vendorId" id="vendorId" value="{{$editVendorData->id}}">
                        <input type="hidden" name="status" id="status" value="{{$editVendorData->is_active}}">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="businessName" class="col-sm-3 control-label">Business Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="business_name" class="form-control" id="businessName" placeholder="Business Name" value="{{$editVendorData->business_name}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="firstName" class="col-sm-3 control-label">First Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="first_name" class="form-control" id="firstName" placeholder="First Name" value="{{$editVendorData->first_name}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="lastName" class="col-sm-3 control-label">Last Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="last_name" class="form-control" id="lastName" placeholder="Last Name" value="{{$editVendorData->last_name}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="phoneNumber" class="col-sm-3 control-label">Mobile <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="phone_number" class="form-control numberOnly" id="phoneNumber" placeholder="Mobile number" value="{{$editVendorData->phone_number}}" maxlength="10">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email" class="col-sm-3 control-label">Email ID <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="email" name="email" class="form-control" readonly id="email" placeholder="Email" value="{{$editVendorData->email}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Time <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <div class="input-group input-timerange">
                                        <input type="text" name="start_time" id="startTime" class="form-control time startTime" placeholder="Start Time" value="{{$editVendorData->start_time}}">
                                        <div class="input-group-addon">to</div>
                                        <input type="text" name="end_time" id="endTime" class="form-control time endTime" placeholder="End Time" value="{{$editVendorData->end_time}}">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="commissionPrice" class="col-sm-3 control-label">Admin Commission <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="admin_commission" class="form-control commissionPrice" id="commissionPrice" placeholder="Admin Commission" value="{{$editVendorData->admin_commission}}" onKeyPress="if (this.value.length == 10)
                                            return false;">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="business_type" class="col-sm-3 control-label">Business Type <span class="error-star">*</span></label>
                                <div class="col-sm-9 removeClasses">
                                    <?php $businessType = App\Models\BusinessType::getActiveBusinessType() ?>
                                    <select name="business_type"  placeholder="Select Business Type" class="form-control selectpicker department rounded-0" title="Select Business Type" data-live-search="true" data-size="5">
                                        @if($businessType->count() > 0)
                                        @foreach($businessType as $val)
                                        <option value="{{$val->id}}" <?php
                                        if ($editVendorData->business_type == $val->id) {
                                            echo "selected";
                                        }
                                        ?> >{{$val->business_name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="delivery_location" class="col-sm-3 control-label">Select Location <span class="error-star">*</span></label>
                                <div class="col-sm-9 removeClasses">
                                    <?php $locations = App\Models\DeliveryArea::all(); ?>
                                    <?php $deliveryLocation = explode(' ', $editVendorData->delivery_location); ?>
                                    <select name="delivery_location[]"  placeholder="Select Work Location" class="form-control selectpicker department rounded-0" title="Select Work Location" data-live-search="true" data-size="5" multiple>
                                        @if($locations->count() > 0)
                                        @foreach($locations as $loc)
                                        <option value="{{$loc->id}}" <?php
                                        if (in_array($loc->id, $deliveryLocation)) {
                                            echo "selected";
                                        }
                                        ?>>{{$loc->polygon_name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="vendorAddress" class="col-sm-3 control-label">Address <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="address" class="form-control" id="vendorAddress" placeholder="Address" value="{{$editVendorData->address}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="tags" class="col-sm-3 control-label">Tags</label>
                                <div class="col-sm-9">
                                    <?php
                                    $tags = App\Models\Tag::getAllTagsData();
                                    ?>
                                    <?php
                                    $vendorTags = explode(' ', $editVendorData->tags);
                                    ?>
                                    <select data-placeholder="Choose a tag..." name="tags[]" id="tags" multiple="" class="form-control chzn-select">
                                        <option value="">Select Tag</option>
                                        @if($tags->count()>0)
                                        @foreach($tags as $tag)
                                        <option value="{{$tag->tag_name}}" <?php
                                        if (in_array($tag->id, $vendorTags)) {
                                            echo "selected";
                                        }
                                        ?>>{{$tag->tag_name}}</option>
                                        @endforeach 
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="storeImage" class="col-sm-3 control-label">Image <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <div class="uplod-btn">
                                        <img id="imagePreview" src="{{\App\Helpers\Helper::checkItemImage($editVendorData->store_image,'temp')}}" height="255" width="350" class="imagePreview"> 
                                        <input type="file" onchange="setImage(this)" class="form-control" name="store_image" id="storeImage">
                                        <input id="storeImg" type="hidden" value="{{$editVendorData->store_image}}" name="store_picture">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="vendor_acceptance" class="col-sm-3 control-label">Vendor Acceptance <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="radio" name="vendor_acceptance" value="yes" <?php
                                    if ($editVendorData->vendor_acceptance == "yes") {
                                        echo "checked";
                                    }
                                    ?>>Yes
                                    <input type="radio" name="vendor_acceptance" value="no" <?php
                                    if ($editVendorData->vendor_acceptance == "no") {
                                        echo "checked";
                                    }
                                    ?>>No
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <center>
                                <button id="btnVendor" type="submit" class="btn btn-primary"><i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> Update Vendor</button>
                            </center>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\EditVendorRequest','#editVendorForm') !!}
                </div>
            </div>
        </div>
    </section>
</main>
<div id="imageCropperModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Crop Image</h4>
            </div>
            <div class="modal-body">
                <img alt="image" src="" id="cropImage" class="img-responsive"/>
                <input type="hidden" id="imageBaseCode">
                <div class="clearfix"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="cropButton">Save</button>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyC12LNafoW1wGIvVTtkFtGM0RzsbgUaB0Y&libraries=places"></script>
<script>
                                            $(document).ready(function () {
                                              $('.commissionPrice').keypress(function (event) {
                                                if (event.which != 46 && (event.which < 47 || event.which > 59))
                                                {
                                                  event.preventDefault();
                                                  if ((event.which == 46) && ($(this).indexOf('.') != -1)) {
                                                    event.preventDefault();
                                                  }
                                                }
                                              });
                                              $(".numberOnly").keypress(function (e) {
                                                if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                                                  return false;
                                                }
                                              });
                                              $('#editVendorForm').on('submit', function (e) {
                                                $(this).find('.bootstrap-select').removeClass("form-control");
                                                $(this).find('.bootstrap-select').css('width', '100%');
                                                if ($('#editVendorForm').valid()) {
                                                  $('#addLoader').show();
                                                  $("#btnVendor").prop('disabled', true);
                                                } else {
                                                  $('#addLoader').hide();
                                                  $("#btnVendor").prop('disabled', false);
                                                }
                                              });
                                              $('.startTime').datetimepicker({
                                                format: 'hh:mm A',
                                                stepping: 5,
                                                useCurrent: true,
                                              }).on('dp.change', function (e) {
                                                var date = '2000-01-01';
                                                var startTime = Date.parse(date + ' ' + $('.startTime').val());
                                                var endTime = Date.parse(date + ' ' + $('.endTime').val());
                                                if (endTime) {
                                                  if (endTime < startTime) {
                                                    $('.endTime').val('');
                                                  }
                                                }
                                              });
                                              $('.endTime').datetimepicker({
                                                format: 'hh:mm A',
                                                stepping: 5,
                                                useCurrent: true,
                                              }).on('dp.change', function (e) {
                                                var date = '2000-01-01';
                                                var startTime = Date.parse(date + ' ' + $('.startTime').val());
                                                var endTime = Date.parse(date + ' ' + $('.endTime').val());
                                                if (endTime) {
                                                  if (endTime < startTime) {
                                                    $('.endTime').val('');
                                                  }
                                                }
                                              });
                                              $(".chzn-select").chosen();
                                              $("#tags_chosen ul>li>input").keydown(function (e) {
                                                if (e.which == 13) {
                                                  var checkPoint = $("#tags_chosen").find("li").hasClass("no-results");
                                                  if (checkPoint == true) {
                                                    $("#tags").append('<<option value="' + $(this).val() + '" selected="selected">' + $(this).val() + '</option>>');
                                                    $("#tags").trigger("chosen:updated");
                                                  }
                                                }
                                              });
                                              $("#cropButton").click(function () {
                                                var $image = $("#cropImage");
                                                var imageBaseCode = $('#imageBaseCode').val();
                                                var imageCropedData = $image.cropper('getData');
                                                var croppedWidth = imageCropedData.width;
                                                var croppedHeight = imageCropedData.height;
                                                var croppedX = imageCropedData.x;
                                                var croppedY = imageCropedData.y;
                                                var rotate = imageCropedData.rotate;
                                                var url = "{{url('admin/save-cropped-image')}}";
                                                $.ajax({
                                                  type: "POST",
                                                  url: url,
                                                  dataType: 'JSON',
                                                  data: {
                                                    imageBaseCode: imageBaseCode,
                                                    croppedWidth: croppedWidth,
                                                    croppedHeight: croppedHeight,
                                                    croppedX: croppedX,
                                                    croppedY: croppedY,
                                                    rotate: rotate,
                                                    _token: '{{csrf_token()}}'
                                                  },
                                                  success: function (response) {
                                                    if (response.success) {
                                                      $("#imageCropperModal").modal("hide");
                                                      $image.cropper('destroy');
                                                      $("#imagePreview").attr("src", "{{url('public/uploads/temp')}}" + '/' + response.filename);
                                                      $("#storeImg").val(response.filename);
                                                    }
                                                  }
                                                });
                                              });
                                              $('#imageCropperModal').on('hidden.bs.modal', function (e) {
                                                var $image = $("#cropImage");
                                                var input = $("#cropImageInput");
                                                input.replaceWith(input.val('').clone(true));
                                                $image.cropper("destroy");
                                              });
                                              initAutocomplete();
                                              $(".chzn-select").chosen();
                                            });

                                            function initAutocomplete() {
                                              var input = document.getElementById('vendorAddress');
                                              var searchBox = new google.maps.places.SearchBox(input);
                                            }

                                            var fileTypes = ['jpg', 'jpeg', 'png'];
                                            function setImage(input) {
                                              $('#cropImage').attr('src', '');
                                              if (input.files && input.files[0]) {
                                                var extension = input.files[0].name.split('.').pop().toLowerCase(), isSuccess = fileTypes.indexOf(extension) > -1;
                                                if (isSuccess) {
                                                  var reader = new FileReader();
                                                  reader.onload = function (e) {
                                                    $('#cropImage').attr('src', e.target.result);
                                                    $('#imageBaseCode').val(e.target.result)
                                                    loadCropper();
                                                  };
                                                  reader.readAsDataURL(input.files[0]);
                                                } else {
                                                  bootbox.alert('Only jpg, jpeg, png files are allowed.');
                                                  var $el = $('#storeImage');
                                                  $el.wrap('<form>').closest('form').get(0).reset();
                                                  $el.unwrap();
                                                }
                                              }
                                            }

                                            function loadCropper() {
                                              var $image = $("#cropImage");
                                              $("#imageCropperModal").modal("show");
                                              $image.cropper({
                                                viewMode: 1,
                                                dragMode: 'move',
                                                autoCropArea: 0.65,
                                                restore: false,
                                                guides: false,
                                                highlight: true,
                                                movable: false,
                                                zoomable: false,
                                                rotatable: true,
                                                center: false,
                                                scalable: false,
                                                responsive: true,
                                                strict: true,
                                                cropBoxResizable: true,
                                              });
                                            }
</script>
@stop