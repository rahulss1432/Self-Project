@extends('admin::layouts.app')
@section('title', 'MarketPlace : Vendor Management')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Vendor Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/vendor-list')}}">Vendor Management</a></li>
            <li class="active">Vendor Listing</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn btn-primary" onclick="showSerach()" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class="btn btn-primary disabled" id="btnDownloadCsv" href="{{ url('/admin/vendor-csv-download') }}"> <i class="fa fa-upload"></i> Export Vendor</a>
                            <a href="{{url('/admin/create-vendor')}}" class="btn btn-primary">
                                <i class="fa fa-plus-circle"></i> <span class="hidden-xs">Setup Vendor & Restaurant</span>
                            </a>
                        </div>
                    </div>
                </div>
                <form id="searchForm" style="display: none;" action="javascript:void(0)" onsubmit="loadVendorList()" method="post">
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-2">
                            <label>Business Name</label>
                            <input id="searchName" class="form-control StreamName" name="name" type="text" placeholder="Name">
                        </div>
                        <div class="col-md-2">
                            <label>Email address</label>
                            <input id="searchEmail" class="form-control StreamName" name="email" type="text" placeholder="Email" >
                        </div>
                        <div class="col-md-2">
                            <label>Mobile number</label>
                            <input id="searchMobile" class="form-control numberOnly" type="text"  name="phone_number" placeholder="Mobile number">
                        </div>
                        <div class="col-md-2">
                            <label>Business Type</label>
                            <select class="form-control select2" name="businessType" id="searchBusinessType">
                                <?php $businessType = App\Models\BusinessType::getActiveBusinessType(); ?>
                                <option value="">Select Business Type</option>
                                @if($businessType->count() > 0)
                                @foreach($businessType as $val)
                                <option value="{{$val->id}}">{{$val->business_name}}</option>
                                @endforeach
                                @endif
                            </select>
                        </div>
                        <div class="col-md-2" style="margin-top: 20px;">
                            <button type="submit" class="btn btn-primary">Filter</button>
                            <button type="submit" class="btn btn-primary" onclick="resetFilter();">
                                Reset <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="loadVendorList">

                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script type="text/javascript">
    $(document).ready(function () {
      loadVendorList();
      $(".numberOnly").keypress(function (e) {
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
          return false;
        }
      });
      $('body').on('keydown', '.StreamName', function (e) {
        if (e.which === 32 && e.target.selectionStart === 0) {
          return false;
        }
      });
    });
    function showSerach() {
      $("#searchForm").slideToggle("slow");
    }
    function loadVendorList() {
      var searchFilter = $("#searchForm").serializeArray();
      $("#loadVendorList").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      $.ajax({
        type: "POST",
        url: "{{ url('/admin/load-vendor-list') }}",
        data: {'_token': '{{csrf_token()}}'},
        data:searchFilter,
                success: function (response) {
                  $("#loadVendorList").html(response.html);
                }
      });
    }
    function deleteVendor(id) {
      bootbox.confirm('Are you sure you want to delete ?', function (result) {
        if (result) {
          var token = '{{ csrf_token() }}';
          $.ajax({type: "POST",
            url: "{{ url('admin/delete-vendors') }}",
            data: {_token: token, id: id},
            success: function (response) {
              if (response)
              {
                $("#tr_" + id).hide(500);
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.success("{{\Config::get('constants.delete_vendor')}}", 'Success', {timeOut: 2000});
              } else {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error("{{\Config::get('constants.something_wrong')}}", 'Error', {timeOut: 2000});
              }
            }
          });
        }
      });
    }

    function vendorChangeStatus(id, status)
    {
      if (status == '1') {
        var msg = "Are you sure you want to deactivate this vendor?";
      }
      else if (status == '0') {
        var msg = "Are you sure you want to activate this vendor?";
      }
      bootbox.confirm(msg, function (result)
      {
        if (result)
        {
          $.ajax({
            type: "POST",
            url: "{{url('/admin/change-vendor-status')}}/" + id,
            data: {'_token': '{{csrf_token()}}'},
            success: function (response)
            {
              if (response) {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.success("{{\Config::get('constants.change_status')}}", 'Success', {timeOut: 2000});
                loadVendorList();
              }
              else {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error("{{\Config::get('constants.something_wrong')}}", 'Error', {timeOut: 2000});
              }
            }
          });
        }
        else
        {
          if (status == '1') {
            $('#enable_a_' + id).attr('checked', true);
          }
          else {
            $('#enable_a_' + id).attr('checked', false);
          }
        }
      });
    }

    function resetFilter() {
      $('#searchForm')[0].reset();
      $('.selectpicker').selectpicker('refresh');
      loadVendorList();
    }
</script>
@stop