@extends('admin::layouts.app')
@section('title', 'MarketPlace : Setup Vendor & Restaurant')
@section('content')
<style>  
    .uplod-btn {
        position: relative;
        overflow: hidden;
        display: inline-block;
        border: 1px solid #00BFFF;
        box-shadow: 0px 0px 1px 1px #00BFFF;
    }
    .uplod-btn input[type=file] {
        position: absolute;
        left: 0;
        top: 0;
        opacity: 0;
        height: 255px;
        cursor: pointer;
    }
</style>
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Setup Vendor & Restaurant</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/vendor-list')}}">Vendor Management</a></li>
            <li class="active">Setup Vendor & Restaurant</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Setup Vendor & Restaurant</h3>
                    </div>
                    <form id="CreateVendorForm" class="form-horizontal" method="POST" action="{{url('admin/save-vendor')}}" enctype="multipart/form-data" onsubmit="checkImage();">
                        {{ csrf_field() }}
                        <input type="hidden" name="user_type" value="vendor">
                        <input type="hidden" name="password" value="test123">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="businessName" class="col-sm-3 control-label">Business Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="business_name" class="form-control" id="businessName" placeholder="Business Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="firstName" class="col-sm-3 control-label">First Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="first_name" class="form-control" id="firstName" placeholder="First Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="lastName" class="col-sm-3 control-label">Last Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="last_name" class="form-control" id="lastName" placeholder="Last Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="phoneNumber" class="col-sm-3 control-label">Mobile <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="phone_number" class="form-control numberOnly" id="phoneNumber" placeholder="Mobile number" maxlength="10">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email" class="col-sm-3 control-label">Email ID <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="email" name="email" class="form-control" id="email" placeholder="Email">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Time <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <div class="input-group input-timerange">
                                        <input type="text"  name="start_time" id="startTime" class="form-control time startTime" placeholder="Start Time">
                                        <div class="input-group-addon">to</div>
                                        <input type="text" name="end_time" id="endTime" class="form-control time endTime" placeholder="End Time">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="commissionPrice" class="col-sm-3 control-label">Admin Commission <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="admin_commission" class="form-control commissionPrice" id="commissionPrice" placeholder="Admin Commission" onKeyPress="if (this.value.length == 10)
                                            return false;">
                                </div>
                            </div>
                            <div class="form-group" id="businessError">
                                <label for="businessValid" class="col-sm-3 control-label">Business Type <span class="error-star">*</span></label>
                                <div class="col-sm-9 removeClasses" id="businessInputError">
                                    <?php $businessType = App\Models\BusinessType::getActiveBusinessType() ?>
                                    <select name="business_type"  placeholder="Select Business Type" class="form-control selectpicker department rounded-0" title="Select Business Type" data-live-search="true" data-size="5" id="businessValid">
                                        @if($businessType->count() > 0)
                                        @foreach($businessType as $val)
                                        <option value="{{$val->id}}" >{{$val->business_name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="form-group" id="locationError">
                                <label for="locationValid" class="col-sm-3 control-label">Select Location <span class="error-star">*</span></label>
                                <div class="col-sm-9 removeClasses" id="locationInputError">
                                    <?php $locations = App\Models\DeliveryArea::all(); ?>
                                    <select name="delivery_location[]"  placeholder="Select Work Location" class="form-control selectpicker department rounded-0" title="Select Work Location" data-live-search="true" data-size="5" multiple id="locationValid">
                                        @if($locations->count() > 0)
                                        @foreach($locations as $loc)
                                        <option value="{{$loc->id}}">{{$loc->polygon_name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="vendorAddress" class="col-sm-3 control-label">Address <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="address" class="form-control" id="vendorAddress" placeholder="Address">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="tags" class="col-sm-3 control-label">Tags</label>
                                <div class="col-sm-9">
                                    <?php
                                    $tagList = App\Models\Tag::getAllTagsData();
                                    ?>
                                    <select data-placeholder="Choose a tag..." id="tags" name="tags[]" multiple="" class="form-control chzn-select">
                                        @if($tagList->count()>0)
                                        @foreach($tagList as $tag)
                                        <option  value="{{$tag->tag_name}}">{{$tag->tag_name}}</option>
                                        @endforeach 
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="storeImage" class="col-sm-3 control-label">Image <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <div class="uplod-btn">
                                        <img id="imagePreview" src="{{\App\Helpers\Helper::checkItemImage('','images')}}" height="255" width="350" class="imagePreview"> 
                                        <input type="file"  onchange="setImage(this)" class="form-control" name="store_image" id="storeImage">
                                        <input id="storeImg" type="hidden" value="" name="store_picture">
                                    </div>
                                    <span id="storeImage-error" style="font-size: 13px;" class="help-block"></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="vendor_acceptance" class="col-sm-3 control-label">Vendor Acceptance <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="radio" name="vendor_acceptance" value="yes">Yes
                                    <input type="radio" name="vendor_acceptance" value="no">No
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <center>
                                <button id="btnVendor" type="submit" class="btn btn-primary"><i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> Add Vendor</button>
                            </center>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\CreateVendorRequest','#CreateVendorForm') !!}
                </div>
            </div>
        </div>
    </section>
</main>
<div id="imageCropperModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Crop Image</h4>
            </div>
            <div class="modal-body">
                <img alt="image" src="" id="cropImage" class="img-responsive"/>
                <input type="hidden" id="imageBaseCode">
                <div class="clearfix"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="cropButton">Save</button>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyC12LNafoW1wGIvVTtkFtGM0RzsbgUaB0Y&libraries=places"></script>
<script>
                                            $(document).ready(function () {
                                              $(".chzn-select").chosen();
                                              $("#businessValid").change(function () {
                                                var choice = jQuery(this).val();
                                                if ($(this).val() == '') {
                                                  $('#businessValid-error').show();
                                                } else {
                                                  $('#businessValid-error').hide();
                                                  $('#businessInputError .bootstrap-select .dropdown-toggle').css('border-color', '#00a65a');
                                                  $('#businessInputError .bootstrap-select .dropdown-menu .bs-searchbox .form-control').css('border-color', '#00a65a');
                                                  $('#businessError.form-group.has-error label').css('color', '#00a65a');
                                                }
                                              });
                                              $("#locationValid").change(function () {
                                                var choice = jQuery(this).val();
                                                if ($(this).val() == '') {
                                                  $('#locationValid-error').show();
                                                } else {
                                                  $('#locationValid-error').hide();
                                                  $('#locationInputError .bootstrap-select .dropdown-toggle').css('border-color', '#00a65a');
                                                  $('#locationInputError .bootstrap-select .dropdown-menu .bs-searchbox .form-control').css('border-color', '#00a65a');
                                                  $('#locationError.form-group.has-error label').css('color', '#00a65a');
                                                }
                                              });
                                              $('.commissionPrice').keypress(function (event) {
                                                if (event.which != 46 && (event.which < 47 || event.which > 59))
                                                {
                                                  event.preventDefault();
                                                  if ((event.which == 46) && ($(this).indexOf('.') != -1)) {
                                                    event.preventDefault();
                                                  }
                                                }
                                              });
                                              $(".numberOnly").keypress(function (e) {
                                                if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                                                  return false;
                                                }
                                              });
                                              $("#tags_chosen ul>li>input").keydown(function (e) {
                                                if (e.which == 13) {
                                                  var checkPoint = $("#tags_chosen").find("li").hasClass("no-results");
                                                  if (checkPoint == true) {
                                                    $("#tags").append('<<option value="' + $(this).val() + '" selected="selected">' + $(this).val() + '</option>>');
                                                    $("#tags").trigger("chosen:updated");
                                                  }
                                                }
                                              });
                                              $('#CreateVendorForm').on('submit', function (e) {
                                                $(this).find('.bootstrap-select').removeClass("form-control");
                                                $(this).find('.bootstrap-select').css('width', '100%');
                                                if ($('#CreateVendorForm').valid()) {
                                                  $('#addLoader').show();
                                                  $("#btnVendor").prop('disabled', true);
                                                } else {
                                                  $('#addLoader').hide();
                                                  $("#btnVendor").prop('disabled', false);
                                                }
                                              });
                                              $('.startTime').datetimepicker({
                                                format: 'hh:mm A',
                                                stepping: 5,
                                                useCurrent: true,
                                              }).on('dp.change', function (e) {
                                                var date = '2000-01-01';
                                                var startTime = Date.parse(date + ' ' + $('.startTime').val());
                                                var endTime = Date.parse(date + ' ' + $('.endTime').val());
                                                if (endTime) {
                                                  if (endTime < startTime) {
                                                    $('.endTime').val('');
                                                  }
                                                }
                                              });
                                              $('.endTime').datetimepicker({
                                                format: 'hh:mm A',
                                                stepping: 5,
                                                useCurrent: true,
                                              }).on('dp.change', function (e) {
                                                var date = '2000-01-01';
                                                var startTime = Date.parse(date + ' ' + $('.startTime').val());
                                                var endTime = Date.parse(date + ' ' + $('.endTime').val());
                                                if (endTime) {
                                                  if (endTime < startTime) {
                                                    $('.endTime').val('');
                                                  }
                                                }
                                              });
                                              $('#imageCropperModal').on('hidden.bs.modal', function (e) {
                                                var $image = $("#cropImage");
                                                var input = $("#cropImageInput");
                                                input.replaceWith(input.val('').clone(true));
                                                $image.cropper("destroy");
                                              });
                                              $("#cropButton").click(function () {
                                                var $image = $("#cropImage");
                                                var imageBaseCode = $('#imageBaseCode').val();
                                                var imageCropedData = $image.cropper('getData');
                                                var croppedWidth = imageCropedData.width;
                                                var croppedHeight = imageCropedData.height;
                                                var croppedX = imageCropedData.x;
                                                var croppedY = imageCropedData.y;
                                                var rotate = imageCropedData.rotate;
                                                var url = "{{url('admin/save-cropped-image')}}";
                                                $.ajax({
                                                  type: "POST",
                                                  url: url,
                                                  dataType: 'JSON',
                                                  data: {
                                                    imageBaseCode: imageBaseCode,
                                                    croppedWidth: croppedWidth,
                                                    croppedHeight: croppedHeight,
                                                    croppedX: croppedX,
                                                    croppedY: croppedY,
                                                    rotate: rotate,
                                                    _token: '{{csrf_token()}}'
                                                  },
                                                  success: function (response) {
                                                    if (response.success) {
                                                      $("#imageCropperModal").modal("hide");
                                                      $("#storeImage-error").hide();
                                                      $image.cropper('destroy');
                                                      $("#imagePreview").attr("src", "{{url('public/uploads/temp')}}" + '/' + response.filename);
                                                      $("#storeImg").val(response.filename);
                                                    }
                                                  }
                                                });
                                              });
                                              initAutocomplete();
                                            });

                                            function checkImage() {
                                              var image = $("#storeImg").val();
                                              if (image === undefined || image.length == 0) {
                                                $("#storeImage-error").html("Store image is required.");
                                                $("#storeImage-error").css('color', '#dd4b39');
                                                return false;
                                              } else {
                                                $("#storeImage-error").html("");
                                                return true;
                                              }
                                            }

                                            function initAutocomplete() {
                                              var input = document.getElementById('vendorAddress');
                                              var searchBox = new google.maps.places.SearchBox(input);
                                            }

                                            var fileTypes = ['jpg', 'jpeg', 'png'];
                                            function setImage(input) {
                                              $('#cropImage').attr('src', '');
                                              if (input.files && input.files[0]) {
                                                var extension = input.files[0].name.split('.').pop().toLowerCase(), isSuccess = fileTypes.indexOf(extension) > -1;
                                                if (isSuccess) {
                                                  var reader = new FileReader();
                                                  reader.onload = function (e) {
                                                    $('#cropImage').attr('src', e.target.result);
                                                    $('#imageBaseCode').val(e.target.result)
                                                    loadCropper();
                                                  };
                                                  reader.readAsDataURL(input.files[0]);
                                                } else {
                                                  bootbox.alert('Only jpg, jpeg, png files are allowed.');
                                                  var $el = $('#storeImage');
                                                  $el.wrap('<form>').closest('form').get(0).reset();
                                                  $el.unwrap();
                                                }
                                              }
                                            }

                                            function loadCropper() {
                                              var $image = $("#cropImage");
                                              $("#imageCropperModal").modal("show");
                                              $image.cropper({
                                                viewMode: 1,
                                                dragMode: 'move',
                                                autoCropArea: 0.65,
                                                restore: false,
                                                guides: false,
                                                highlight: true,
                                                movable: false,
                                                zoomable: false,
                                                rotatable: true,
                                                center: false,
                                                scalable: false,
                                                responsive: true,
                                                strict: true,
                                                cropBoxResizable: true,
                                              });
                                            }
</script>
@stop