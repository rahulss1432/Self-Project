<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Business Name</th>
            <th>Vendor Type</th>
            <th>Address</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>No of order</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if($vendorData->count()>0)
        <?php $i = 1; ?>
        @foreach ($vendorData as $vendor)
        <?php
        if ($vendorData->currentPage() == 1) {
            $srNo = $i++;
        } else {
            $srNo = ($vendorData->currentPage() - 1) * $vendorData->perPage() + $i++;
        }
        ?>
        <tr id="tr_{{$vendor->id}}">
            <td>{{ $srNo }}</td>
            <td><a href="{{url('admin/vendor-details/'.$vendor->id)}}">{{ $vendor->business_name }}</a></td>
            <td><?php
                $businessType = App\Helpers\Helper::getBusinesstypeNameById($vendor->business_type);
                if (!empty($businessType)) {
                    echo $businessType;
                } else {
                    echo "-";
                }
                ?></td>
            <td>{{ $vendor->address }}</td>
            <td>{{ $vendor->email }}</td>
            <td>{{ $vendor->phone_number }}</td>
            <td>{{count($vendor->vendorOrder)}}</td>
            <td>
                <?php
                if (!empty($vendor->is_active) == 1) {
                    $status = "Active";
                } else {
                    $status = "Inactive";
                }
                ?>
                {{ $status }}</td>
            <td>
                <label class="switch" style="margin-bottom:-15px;">
                    <input id="enable_a_{{$vendor->id}}" type="radio" onclick="vendorChangeStatus({{$vendor->id}},'{{$vendor->is_active}}')" value="1" name="radio_{{$vendor->id}}" @if ($vendor->is_active=='1')) checked="checked" @endif >
                           <span class="slider1 round" for="enable_{{$vendor->id}}"></span>
                </label>
                <a href="{{url('admin/change-vendor-password/'.$vendor->id)}}" class="btn btn-primary"><i class="fa fa-lock"></i></a>
                <a href="{{url('admin/edit-vendor/'.$vendor->id)}}" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></a>
                <a href="javascript:void(0);" onclick="deleteVendor('{{$vendor->id}}');" class="btn btn-primary"><i class="fa fa-trash-o"></i></a>
            </td>
        </tr>
        @endforeach
        @else 
        <tr>
            <td colspan="10">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>

<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$vendorData->links()}}
    </ul>
</div>
<script>
<?php if ($vendorData->count() > 0) { ?>
                $('#btnDownloadCsv').removeClass('disabled');
<?php } ?>

            $(document).ready(function () {
            $(".pagination li a").on('click', function (e) {
            e.preventDefault();
                    var loader = '<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>';
                    var $this = $(this);
                    var searchFilter = $("#searchForm").serializeArray();
                    var pageLink = $this.attr('href');
                    var token = '{{ csrf_token() }}';
                    $.ajax({type: 'POST', url: pageLink, async: false, data: {_token: token}, data:searchFilter,
                            beforeSend: function () {
                            $('#loadVendorList').html(loader);
                            },
                            success: function (response) {
                            $('.pagination:first').remove();
                                    $('#loadVendorList').html(response.html);
                            }
                    });
            });
            });
</script>