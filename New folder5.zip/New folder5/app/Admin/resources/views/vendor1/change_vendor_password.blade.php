@extends('admin::layouts.app')
@section('title', 'MarketPlace : Change Password')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Vendor Change Password</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/vendor-list')}}">User Management</a></li>
            <li class="active">Vendor Change Password</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Change Password</h3>
                    </div>
                    <form id="changePasswordForm" class="form-horizontal" method="POST" action="{{url('admin/update-password')}}">
                        {{ csrf_field() }}
                        <input type="hidden" name="userId" id="userId" value="{{$vendorDetails->id}}">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="new_password" class="col-sm-3 control-label">New Password <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="password" name="new_password" class="form-control" placeholder="New Password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password" class="col-sm-3 control-label">Confirm Password <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="password" name="confirm_password" class="form-control" placeholder="Confirm Password">
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <center>
                                <button id="btnChangePassword" type="submit" class="btn btn-primary">Save Changes
                                    <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                                </button>
                            </center>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\VendorChangePasswordRequest','#changePasswordForm') !!}
                </div>
            </div>
        </div>
    </section>
</main>

<script>
    $('#changePasswordForm').on('submit', function (e) {
      if ($('#changePasswordForm').valid()) {
        $('#addLoader').show();
        $("#btnChangePassword").prop('disabled', true);
      } else {
        $('#addLoader').hide();
        $("#btnChangePassword").prop('disabled', false);
      }
    });
</script>
@stop