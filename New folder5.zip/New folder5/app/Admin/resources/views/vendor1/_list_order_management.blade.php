<table class="table table-hover">
    <thead>
        <tr>
            <th>Order ID</th>
            <th>Customer Name</th>
            <th>Vendor Name</th>
            <th>Delivery Address</th>
            <th>Expected Arrival Time</th>
            <th>Payment Mode</th>
            <th>Driver Name</th>
            <th>Amount</th>
            <th>Order State</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if(count($orderData)>0)
        @foreach($orderData as $data)
        <tr id="{{'order'.$data->id}}">
            <td>{{$data->id}}</td>
            <td>{{$data->getCustomer->first_name}} {{$data->getCustomer->last_name}}</td>
            <td>{{$data->getVendor->first_name}} {{$data->getVendor->last_name}}  </td>
            <td>{{$data->drop_address}}</td>
           <td>
                @if($data->order_state == 'out_for_delivery')
                {{App\Helpers\Helper::getDistanceInMeters($data->current_location,$data->drop_address)}}
                @else 
                -
                @endif
            </td>
            <td>{{$data->payment_mode}}</td>
            <td>{{($data->getDriver)?$data->getDriver->first_name.' '.$data->getDriver->last_name:'-'}} </td>
            <td>{{$data->total_amount}}</td>
            <td>
                @if($data->order_state == 'out_for_delivery')
                Out For Delivery.
                @elseif($data->order_state == 'pending')
                Pending.
                @elseif($data->order_state == 'running')
                Running.
                @elseif($data->order_state == 'vendor_pending')
                Vendor Pending.
                @elseif($data->order_state == 'completed')
                Delivered.
                @elseif($data->order_state == 'cancelled')
                Cancelled.
                @elseif($data->order_state == 'out_for_pickup')
                Ready For Pickup.
                @endif
            </td>
            <td><ul class="list-inline mb-0 ">
                    <li class="list-inline-item">
                        <a class="btn btn-primary" href="{{url('admin/view-order/'.$data->id)}}">
                            <i class="fa fa-eye"> View</i>
                        </a>
                    </li> 
                </ul>
            </td>
        </tr>
        @endforeach
        <tr>
            <td colspan="11">
                <div class="box-footer clearfix">
                    <ul class="pagination pagination-sm no-margin pull-right">
                        {{$orderData->links()}}
                    </ul>
                </div>
            </td>
        </tr>
        @else 
        <tr>
            <td colspan="11">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>

<script>
    $(document).ready(function () {
      $('.pagination').addClass('pull-right');
      $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        var search_filter = $("#searchForm").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({type: 'POST', url: pageLink, async: false, data: search_filter,
          success: function (response) {
            $('.pagination:first').remove();
            $('#listingOrder').html(response.html);
          }
        });
      });
    });
</script>