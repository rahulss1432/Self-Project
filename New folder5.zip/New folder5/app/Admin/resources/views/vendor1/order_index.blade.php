@extends('admin::layouts.app')
@section('title', 'MarketPlace : Order Management')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Order Management
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Order Management</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" onclick="showSerach()" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class=" btn btn-primary" href="{{url('/admin/create-order')}}"> <i class="fa fa-plus-circle"></i>  Create Order</a>
                        </div>
                    </div>
                </div>
                <form id="searchForm" style="display: none;" action="javascript:void(0);" method="post" onsubmit="loadOrderList();">
                    {{ csrf_field() }}
                    <input type="hidden" name="vendorId" id="vendorId" value="{{$id}}">
                    <div class="row">
                        <div class="col-md-2" style="margin-top: 5px; margin-bottom: 5px; height: 50px;">
                            <span>Order ID</span> 
                            <input class="form-control" name="orderId" type="text" id="orderId" placeholder="Order ID">
                        </div>
                        <div class="col-md-2">
                            <span>Customer Name</span>
                            <input class="form-control" name="customerName" type="text" id="customerName" placeholder="Customer Name">
                        </div>
                        <div class="col-md-2">
                            <span>Email</span> 
                            <input class="form-control" name="email" type="text" id="email" placeholder="Email">
                        </div>
                        <div class="col-md-2">
                            <span> Mobile Number</span> 
                            <input class="form-control" name="mobile" type="text" id="mobile" placeholder="Mobile Number ">
                        </div>
                        <div class="col-md-2">
                            <span> Vendor Name</span> 
                            @php echo \App\Models\User::getVendorNameDropdown(0); @endphp
                        </div>
                        <div class="col-md-2">
                            <span> Delivery address</span> 
                            <input class="form-control" name="deliveryAddress" type="text" id="deliveryAddress" placeholder="Delivery address">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">
                            <span>  Payment mode</span>
                            <select class="form-control " id="paymentMode" name="paymentMode">
                                <option value="">--Select Payment Mode--</option>
                                <option value="cod">COD</option>
                            </select> 
                        </div>
                        <div class="col-md-2">
                            <span>  Driver Name</span> 
                            <input class="form-control" name="driverName" type="text" id="driverName" placeholder="Driver Name">
                        </div>
                        <div class="col-md-2">
                            <span> Order state</span>
                            <select class="form-control" id='orderState' name="orderState">
                                <option value="">--Select Order State--</option>
                                <option value="pending">Pending</option>
                                <option value="completed">Completed </option>
                                <option value="cancelled">Cancelled </option>
                                <option value="running">Running </option>
                                <option value="vendor_pending ">Vendor Pending </option>
                            </select> 
                        </div>
                        <div class="col-md-2">
                            <br>
                            <button type="submit" class="btn btn-info " style="width:100%;">
                                Filter <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>
                        <div class="col-md-2">
                            <br>
                            <button type="submit" class="btn btn-danger" onclick="resetOrderList();" style="width:100%;">
                                Reset <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>

                    </div>
                </form>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title"></h3>
                        </div>
                        <div class="box-body table-responsive no-padding" id="listingOrder"></div>
                    </div>
                </div>
            </div>
    </section>
</main>
<script>
    $(document).ready(function () {
      loadOrderList();
    });
    function showSerach() {
      $("#searchForm").slideToggle("slow");
    }
    function resetOrderList() {
      $('#searchForm')[0].reset();
      $('.selectpicker').selectpicker('refresh');
      loadOrderList()
    }
    function loadOrderList() {
      $("#listingOrder").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter = $("#searchForm").serializeArray();
      search_filter.push('_token', '{{ csrf_token() }}');
      $.ajax({
        type: "POST",
        url: "{{url('/admin/list-singleuser-order')}}",
        data: search_filter,
        success: function (response) {
          $("#listingOrder").html(response.html);
        }
      });
    }
</script>
@stop