@extends('admin::layouts.app')
@section('title', 'MarketPlace : Vendor Detail')
@section('content')
<style>
    .boxStyle {
        background-color: #fff;
        margin-bottom: 16px;
        border-radius: 6px;
        -webkit-box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
        -moz-box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
        box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
    }
    #map-canvas-0{
        height: 342px !important;
    }
</style>
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Vendor Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/vendor-list')}}">Vendor Management</a></li>
            <li class="active">Vendor Detail</li>
        </ol>
    </section>
    <section class="content">
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane active" id="application">
                <section>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="btn-toolbar m-b-0">
                                <h2 class="md-headline green">Vendor Detail</h2>
                            </div>
                            <div class="box box-primary">
                                <div class="box-body box-profile">
                                    <img class="profile-user-img img-responsive img-circle" src="{{\App\Helpers\Helper::checkUserImage($vendorDetails->profile_picture,'user')}}" alt="User profile picture">
                                    <h3 class="profile-username text-center">{{$vendorDetails->first_name}} {{$vendorDetails->last_name}}</h3>
                                    <p class="text-muted text-center">{{$vendorDetails->user_type}}</p>
                                    <ul class="list-group list-group-unbordered">
                                        <li class="list-group-item">
                                            <b>Email</b> <a class="pull-right">{{$vendorDetails->email}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Mobile</b> <a class="pull-right">{{$vendorDetails->phone_number}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <?php $startTime = date('h:i A', strtotime($vendorDetails->vendorDetail->start_time)); ?>
                                            <b>Opening Time</b> <a class="pull-right">{{$startTime}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <?php $endTime = date('h:i A', strtotime($vendorDetails->vendorDetail->end_time)); ?>
                                            <b>Closing Time</b> <a class="pull-right">{{$endTime}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <?php
                                            if ($vendorDetails->is_active == "1") {
                                                $status = "Active";
                                            } else {
                                                $status = "Inactive";
                                            }
                                            ?>
                                            <b>Status</b> <a class="pull-right">{{$status}}</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="box box-primary">
                                <div class="box-header">
                                    <h3 class="box-title">Store Detail</h3>
                                </div>
                                <div class="box-body">
                                    <ul class="list-group list-group-unbordered">
                                        <li class="list-group-item">
                                            <b>Business Type</b> <a class="pull-right">{{(!empty($vendorDetails->vendorDetail->businessType->business_name)) ? $vendorDetails->vendorDetail->businessType->business_name : '-' }}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Store Name</b> <a class="pull-right">{{(!empty($vendorDetails->vendorDetail->business_name)) ? $vendorDetails->vendorDetail->business_name : '-'}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <?php
                                            if ($vendorDetails->vendorDetail->vendor_acceptance == "yes") {
                                                $vendorAcceptance = "Yes";
                                            } else {
                                                $vendorAcceptance = "No";
                                            }
                                            ?>
                                            <b>Vendor Acceptance</b> <a class="pull-right">{{$vendorAcceptance}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Vendor</b> <a class="pull-right">{{$vendorDetails->first_name}} {{$vendorDetails->last_name}}</a>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Admin commission</b> <a class="pull-right">{{$vendorDetails->vendorDetail->admin_commission}} percentage</a>
                                        </li>
                                        <li class="list-group-item">
                                            <?php
                                            $polyGon = array();
                                            $locations = App\Models\DeliveryArea::all();
                                            $location = explode(' ', $vendorDetails->vendorDetail['delivery_location']);
                                            ?>
                                            @if($locations->count() > 0)
                                            @foreach($locations as $loc)
                                            <?php
                                            if (!empty($location)) {
                                                if (in_array($loc->id, $location)) {
                                                    $polyGon[] = $loc->polygon_name;
                                                }
                                            }
                                            ?>
                                            @endforeach
                                            @endif
                                            <b>Location</b> <a class="pull-right"><?php
                                                if (!empty($polyGon)) {
                                                    echo implode(', ', $polyGon);
                                                } else {
                                                    echo "-";
                                                }
                                                ?></a>
                                        </li>
                                        <li class="list-group-item">
                                            <?php
                                            $tagName = array();
                                            $allTags = App\Models\Tag::getAllTagsData();
                                            ?>
                                            <?php
                                            $tags = explode(' ', $vendorDetails->vendorDetail['tags']);
                                            ?>
                                            @if($allTags->count()>0)
                                            @foreach($allTags as $tag)
                                            <?php
                                            if (!empty($tags)) {
                                                if (in_array($tag->id, $tags)) {
                                                    $tagName[] = $tag->tag_name;
                                                }
                                            }
                                            ?>
                                            @endforeach
                                            @endif
                                            <b>Vendors Tags</b> <a class="pull-right"><?php
                                                if (!empty($tagName)) {
                                                    echo implode(', ', $tagName);
                                                } else {
                                                    echo "-";
                                                }
                                                ?></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-6 col-sm-12">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h2 class="md-headline blue">Current Order</h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="boxStyle p-t-0 p-b-0 box-padding m-t-0">
                                        <div class="table-responsive">
                                            <table md-colresize="md-colresize" class="table inner-table">
                                                <thead>  
                                                    <tr class="md-table-headers-row">
                                                        <th>No.</th>
                                                        <th>Order ID</th>
                                                        <th>Order Type</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <?php
                                                $orderDetails = \App\Helpers\Helper::getTopFiveRunningVendorOrders($vendorDetails->id);
                                                ?>
                                                <tbody class="md-table-content">
                                                    @if(!empty($orderDetails->count()>0))
                                                    <?php
                                                    $i = 1;
                                                    $orderRunning = "";
                                                    ?>
                                                    @foreach ($orderDetails as $order)
                                                    @php $srNo = $i++; @endphp
                                                    <?php
                                                    $orderType = $order->order_state;
                                                    ?>
                                                    <tr>
                                                        <td>{{$srNo}}</td>
                                                        <td><?php $orderId = 1000 + $order->id; ?>{{$orderId}}</td>
                                                        <td><?php
                                                            $orderType = $order->order_state;
                                                            if ($orderType == "running") {
                                                                $orderRunning = "Running";
                                                            }
                                                            ?>{{$orderRunning}}</td>
                                                        <td><a href="{{url('admin/view-order/'.$order->id)}}" class="btn btn-primary"><i class="glyphicon glyphicon-eye-open"></i></a></td>
                                                    </tr>
                                                    @endforeach
                                                </tbody>
                                                @else
                                                <tr class="text-center"><td colspan="10"><div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div></td></tr>
                                                @endif
                                            </table>
                                            @if(!empty($orderDetails->count()>0))
                                            <span style="padding-left: 10px;"><a href="{{url('admin/order-management/'.$vendorDetails->id)}}">View All</a></span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <h2 class="md-headline blue">Store Image & Location</h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="boxStyle p-t-0 p-b-0 box-padding m-t-0"  style="padding: 10px;">
                                        <article style="height: 200px;">
                                            <img src="{{\App\Helpers\Helper::checkItemImage($vendorDetails->vendorDetail->store_image,'temp')}}" class="img-responsive" style="height: 100%;">

                                        </article>
                                        <h4 class="box-heading"></h4>
                                        <article style="margin-top:25px;">
                                            <?php
                                            $address = \App\Helpers\Helper::getLatLangByAddress($vendorDetails->address);
                                            $newLatLong = explode(",", $address);
                                            $latitude = (isset($newLatLong[0])) ? $newLatLong[0] : '';
                                            $longitude = (isset($newLatLong[1])) ? $newLatLong[1] : '';
                                            if (!empty($newLatLong)) {
                                                ?>
                                                @php
                                                Mapper::map($latitude,$longitude,['zoom' => 8,'marker' => true]);
                                                @endphp
                                                <div style="width: 100%;height: 342px;">
                                                    {!! Mapper::render() !!}
                                                </div>
                                            <?php } ?>
                                        </article>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
</main>
<script>
    function styleMapAgent(map) {
      var styles = [{
          elementType: 'geometry',
          stylers: [{
              color: '#f5f5f5'
            }]
        }, {
          elementType: 'labels.icon',
          stylers: [{
              visibility: 'off'
            }]
        }, {
          elementType: 'labels.text.fill',
          stylers: [{
              color: '#616161'
            }]
        }, {
          elementType: 'labels.text.stroke',
          stylers: [{
              color: '#f5f5f5'
            }]
        }, {
          featureType: 'administrative.land_parcel',
          elementType: 'labels.text.fill',
          stylers: [{
              color: '#bdbdbd'
            }]
        }, {
          featureType: 'poi',
          elementType: 'geometry',
          stylers: [{
              color: '#eeeeee'
            }]
        }, {
          featureType: 'poi',
          elementType: 'labels.text.fill',
          stylers: [{
              color: '#757575'
            }]
        }, {
          featureType: 'poi.park',
          elementType: 'geometry',
          stylers: [{
              color: '#e5e5e5'
            }]
        }, {
          featureType: 'poi.park',
          elementType: 'labels.text.fill',
          stylers: [{
              color: '#9e9e9e'
            }]
        }, {
          featureType: 'road',
          elementType: 'geometry',
          stylers: [{
              color: '#ffffff'
            }]
        }, {
          featureType: 'road.arterial',
          elementType: 'labels.text.fill',
          stylers: [{
              color: '#757575'
            }]
        }, {
          featureType: 'road.highway',
          elementType: 'geometry',
          stylers: [{
              color: '#dadada'
            }]
        }, {
          featureType: 'road.highway',
          elementType: 'labels.text.fill',
          stylers: [{
              color: '#616161'
            }]
        }, {
          featureType: 'road.local',
          elementType: 'labels.text.fill',
          stylers: [{
              color: '#9e9e9e'
            }]
        }, {
          featureType: 'transit.line',
          elementType: 'geometry',
          stylers: [{
              color: '#e5e5e5'
            }]
        }, {
          featureType: 'transit.station',
          elementType: 'geometry',
          stylers: [{
              color: '#eeeeee'
            }]
        }, {
          featureType: 'water',
          elementType: 'geometry',
          stylers: [{
              color: '#6ec9eb'
            }]
        }, {
          featureType: 'water',
          elementType: 'labels.text.fill',
          stylers: [{
              color: '#6ec9eb'
            }]
        }

      ];
      map.setOptions({
        styles: styles
      });
    }
</script>
@stop