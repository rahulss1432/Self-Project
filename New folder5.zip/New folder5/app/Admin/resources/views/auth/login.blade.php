<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Admin | Log in</title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="stylesheet" href="{{url('public/bootstrap/css/bootstrap.min.css')}}">
        <link rel="stylesheet" href="{{url('public/fonts/font-awesome.min.css')}}">
        <link rel="stylesheet" href="{{url('public/fonts/ionicons.min.css')}}">
        <link rel="stylesheet" href="{{url('public/dist/css/AdminLTE.min.css')}}">
        <link rel="stylesheet" href="{{url('public/plugins/iCheck/square/blue.css')}}">
        <script src="{{ url('public/js/jquery.min.js') }}"></script>     
    </head>
    <body class="hold-transition login-page">
        <div class="login-box">
            <div class="login-logo">
                <a href="#"><b>MarketPlace Admin </b></a>
            </div>
            <div class="login-box-body">
                <form class="login" id="frmloginform" method="POST" action="javascript:void(0);">
                    {{ csrf_field() }}
                    <div class="form-group has-feedback">
                        <input type="email" class="form-control" name="email" placeholder="Email">
                        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                    </div>
                    <div class="form-group has-feedback">
                        <input type="password" class="form-control" name="password" placeholder="Password">
                        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                    </div>
                    <div class="row">
                        <div class="col-xs-8">
                            <div class="checkbox icheck">

                            </div>
                        </div>
                        <div class="col-xs-4">
                            <button type="submit" id="btn-login" class="btn btn-primary btn-block btn-flat">Login</button>
                        </div>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Admin\Http\Requests\LoginRequest','#frmloginform') !!}
            </div>
        </div>
        <script src="{{url('public/plugins/jQuery/jquery-2.2.3.min.js')}}"></script>
        <script src="{{url('public/bootstrap/js/bootstrap.min.js')}}"></script>
        <script src="{{url('public/plugins/iCheck/icheck.min.js')}}"></script>
        <script src="{{ url('public/js/jsvalidation.js') }}"></script>
        <script>
$(function () {
    $('input').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        radioClass: 'iradio_square-blue',
        increaseArea: '20%'
    });
});
        </script>
        <script>
            $("#btn-login").on('click', (function (e) {
                var btn = $('#btn-login');
                var form = $('#frmloginform');
                if (form.valid()) {
                    btn.html('{{\App\Helpers\Helper::buttonLoader()}} Login');
                    btn.prop('disabled', true);
                    $.ajax({
                        url: "{{url('/admin/login')}}",
                        type: "POST",
                        data: form.serialize(),
                        success: function (data)
                        {
                            btn.prop('disabled', false);
                            if (data.type == 'admin') {
                                window.location.href = '{{url("/admin/admin-dashboard")}}';
                            } else if (data.type == 'subadmin') {
                                window.location.href = '{{url("/admin/admin-dashboard")}}';
                            } else {
                                window.location.href = '{{url("/")}}';
                            }
                        },
                        error: function (data) {
                            var obj = jQuery.parseJSON(data.responseText);
                            for (var x in obj) {
                                btn.prop('disabled', false);
                                btn.html('LOGIN');
                                var errors = obj[x].length;
                                $('#' + x + '-error').html(obj[x]);
                                $('#' + x + '-error').css("color", '#b30000');
                                $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                            }
                        },
                    });
                }
            }));
        </script>
    </body>
</html>
