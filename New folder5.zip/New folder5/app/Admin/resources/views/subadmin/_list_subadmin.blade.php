<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Address</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @php $i = 1;
        @endphp
        @if(count($subadmin)>0)
        @foreach($subadmin as $data)
        <tr id="{{'subadmin'.$data->id}}">
            <td>{{$i}}</td>
            <td>{{ucfirst($data->first_name)}} {{ucfirst($data->last_name)}}</td>
            <td>{{$data->email}}</td>
            <td>{{$data->phone_number}}</td>
            <td>{{$data->address}}</td>
            <td>
                <label class="switch">
                    <input id="enable_aaa_{{$data->id}}" type="radio" onclick='changeStatus("{{$data->id}}","{{$data->is_active}}")' name="status_radio_{{$data->id}}" {{$data->is_active == 1 ? 'checked' : ''}}>                    
                    <span class="slider1 round" for="enable_{{$data->id}}"></span>
                </label>
            </td>
            <td>
                <ul class="list-inline mb-0 ">
                    <li class="list-inline-item">
                        <a id="edit-loader{{$data->id}}"  href="{{url('admin/edit-subadmin/'.$data->id)}}" class="btn btn-primary">
                            <i class="fa fa-pencil-square-o"> Edit</i>
                        </a>
                    </li> 
                    <li class="list-inline-item">
                        <a id="delete-loader{{$data->id}}" href="javascript:void(0);" class="btn btn-primary" onclick="deleteSubAdmin({{$data->id}})">
                            <i class="fa fa-trash-o"> Delete</i>
                        </a>
                    </li>
                </ul>
            </td>
        </tr>
        @php $i++;
        @endphp
        @endforeach
        @else 
        <tr>
            <td colspan="6">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>
<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$subadmin->links()}}
    </ul>
</div>
<script>
            $(document).ready(function() {
    var search_filter = $("#search_form").serializeArray();
            var token = '{{ csrf_token() }}';
            $('.pagination').addClass('pull-right');
            $(".pagination li a").on('click', function(e) {
    e.preventDefault();
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({type: 'POST', url: pageLink, async: false, data:{_token: token, search_filter:search_filter},
                    success: function(response) {
                    $('.pagination:first').remove();
                            $('#loadSubAdminList').html(response.html);
                    }
            });
    });
    });
            function deleteSubAdmin(id){
            bootbox.confirm('Are you sure do you want to delete this Sub Admin?', function (result)
            {
            if (result)
            {
            $.ajax({
            type: "GET",
                    url: "{{url('/admin/delete-user')}}/" + id,
                    success: function (response)
                    {
                    if (response)
                    {
                    toastr.remove();
                            toastr.options.closeButton = true;
                            toastr.success(response.message, 'Success', {timeOut: 1000});
                            $('#subadmin' + id).remove();
                    } else
                    {
                    toastr.remove();
                            toastr.options.closeButton = true;
                            toastr.error(response.message, 'Error', {timeOut: 1000});
                    }
                    }
            });
            }
            });
            }

    function changeStatus(id, status)
    {
    if (status == 1)
    {
    var msg = "Are you sure you want to deactivate this sub admin?";
    }
    else if (status == 0)
    {
    var msg = "Are you sure you want to activate this sub admin?";
    }
    bootbox.confirm(msg, function (result)
    {
    if (result)
    {
    $.ajax({
    type: "GET",
            url: "{{url('/admin/update-status')}}" + "/" + id,
            success: function (response)
            {
            if (response.success == true)
            {
            toastr.remove();
                    toastr.options.closeButton = true;
                    loadSubadminList();
                    toastr.success(response.message, 'Success', {timeOut: 2000});
            }
            else
            {
            toastr.remove();
                    toastr.options.closeButton = true;
                    toastr.error(response.message, 'Error', {timeOut: 2000});
                    loadSubadminList();
            }
            }
    });
    } else
    {
    if (status == 1)
    {
    $('#enable_aaa_' + id).attr('checked', true);
    }
    else
    {
    $('#enable_aaa_' + id).attr('checked', false);
    }
    }
    });
    }

</script>