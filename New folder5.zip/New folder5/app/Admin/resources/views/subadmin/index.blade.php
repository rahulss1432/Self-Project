@extends('admin::layouts.app')
@section('title', 'MarketPlace : Subadmin Management')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Subadmin Management
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/sub-admin')}}">Subadmin Management</a></li>
            <li class="active">Subadmin Listing</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" onclick="showSerach()" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class=" btn btn-primary" href="{{url('/admin/create-sub-admin')}}"> <i class="fa fa-plus-circle"></i>  Create Sub Admin</a>
                        </div>
                    </div>
                </div>
                <form class="form-horizontal" id="searchForm" action="javascript:loadSubadminList();" method="post"  style="display: none;" >
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-4">
                            <label> Name</label> 
                            <input class="form-control" type="text" name="name" placeholder="Name">
                        </div>
                        <div class="col-md-2">
                            <br>
                            <button type="submit" class="btn btn-primary ">Filter </button>
                            <button type="submit" class="btn btn-primary" onclick="resetSubadminList();"> Reset </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title"></h3>
                    </div>
                    <div class="box-body table-responsive no-padding" id="loadSubAdminList">
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $(document).ready(function () {
      loadSubadminList();
    });

    function showSerach() {
      $("#searchForm").slideToggle("slow");
    }

    function resetSubadminList() {
      $('#searchForm')[0].reset();
      $('.selectpicker').selectpicker('refresh');
      loadSubadminList();
    }

    function loadSubadminList() {
      $("#loadSubAdminList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter = $("#searchForm").serializeArray();
      search_filter.push('_token', '{{ csrf_token() }}');
      $.ajax({
        type: "Post",
        url: "{{url('/admin/list-subadmin')}}",
        data: search_filter,
        success: function (response) {
          $("#loadSubAdminList").html(response.html);
        }
      });
    }
</script>
@stop