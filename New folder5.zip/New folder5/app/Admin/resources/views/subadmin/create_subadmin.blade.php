@extends('admin::layouts.app')
@section('title', 'MarketPlace : Create Subadmin')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Subadmin Management
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/sub-admin')}}">Subadmin Management</a></li>
            <li class="active">Create Subadmin</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Create Subadmin</h3>
                    </div>
                    <form class="form-horizontal" id="subForm" method="post" action="{{url('/admin/save-subadmin')}}">
                        {{csrf_field()}}
                        <div class="box-body">
                            <div class="form-group">
                                <label for="firstName" class="col-sm-3 control-label">First Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="first_name" class="form-control input-lg" id="firstName" placeholder="Enter First Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="lastName" class="col-sm-3 control-label">Last Name  <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="last_name" class="form-control input-lg" id="lastName" placeholder="Enter Last Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="mobile" class="col-sm-3 control-label">Mobile  <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="mobile" class="form-control input-lg" id="mobile" maxlength="10" placeholder="Enter Mobile Number">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email" class="col-sm-3 control-label">Email  <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="email" class="form-control input-lg" id="email" placeholder="Enter email">
                                </div>
                            </div>
                            <input type="hidden" name="password" class="form-control input-lg" id="password" placeholder="Enter Password" value="test123">
                            <div class="form-group">
                                <label for="address" class="col-sm-3 control-label">Address  <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="address" class="form-control input-lg" id="address" placeholder="Enter Address">
                                </div>
                                <input type="hidden" name="addressLat" id="addressLat">
                                <input type="hidden" name="addressLong" id="addressLong">
                            </div>
                            <div class="form-group">
                                <label for="role" class="col-sm-3 control-label">Role  <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <select class="form-control input-lg" name="role">
                                        <option value="">-- Please Select--</option>
                                        <option value="customer executive">Customer Executive</option>
                                        <option value="call center">Call Center</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button id="btnAddSubAdmin" type="submit" class="btn btn-primary pull-right">
                                <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> Add Subadmin 
                            </button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\AddSubadminRequest','#subForm') !!} 
                </div>
            </div>
        </div>
    </section>
</main>

<script>
    getLatLong();
    function getLatLong() {
      var input = document.getElementById('address');
      var autocomplete = new google.maps.places.Autocomplete(input);
      google.maps.event.addListener(autocomplete, 'place_changed', function () {
        var place = autocomplete.getPlace();
        var lat = place.geometry.location.lat();
        var long = place.geometry.location.lng();
        $('#addressLat').val(lat);
        $('#addressLong').val(long);
      });
    }

    $('#subForm').on('submit', function (e) {
      getLatLong();
      if ($('#subForm').valid()) {
        $('#addLoader').show();
        $("#btnAddSubAdmin").prop('disabled', true);
      } else {
        $('#addLoader').hide();
        $("#btnAddSubAdmin").prop('disabled', false);
      }
    });
</script>
@stop

