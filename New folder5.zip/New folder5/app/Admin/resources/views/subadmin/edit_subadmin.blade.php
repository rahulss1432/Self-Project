@extends('admin::layouts.app')
@section('title', 'MarketPlace : Edit Subadmin')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Subadmin Management
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/sub-admin')}}">Subadmin Management</a></li>
            <li class="active">Edit Subadmin</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Subadmin</h3>
                    </div>
                    <form class="form-horizontal" id="frmEditSubAdminForm" method="post" action="{{url('/admin/update-subadmin')}}">
                        {{csrf_field()}}
                        <div class="box-body">
                            <input type="hidden" name="subId" class="form-control input-lg" id="id" placeholder="Enter First Name" value="{{$subAdminData->id}}">
                            <div class="form-group">
                                <label for="firstName" class="col-sm-3 control-label">first Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="first_name" class="form-control input-lg" id="firstName" placeholder="Enter First Name" value="{{$subAdminData->first_name}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="lastName" class="col-sm-3 control-label">Last Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="last_name" class="form-control input-lg" id="lastName" placeholder="Enter Last Name" value="{{$subAdminData->last_name}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="mobile" class="col-sm-3 control-label">Mobile <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="mobile" class="form-control input-lg" id="mobile" placeholder="Enter Mobile Number" value="{{$subAdminData->phone_number}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email" class="col-sm-3 control-label">Email <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="email" readonly class="form-control input-lg" id="email" placeholder="Enter email" value="{{$subAdminData->email}}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="address" class="col-sm-3 control-label">Address <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="address" class="form-control input-lg" id="address" placeholder="Enter Address" value="{{$subAdminData->address}}">
                                </div>
                                <input type="hidden" name="addressLat" id="addressLat">
                                <input type="hidden" name="addressLong" id="addressLong">
                            </div>
                            <div class="form-group">
                                <label for="role" class="col-sm-3 control-label">Role <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <select class="form-control input-lg" name="role" value="{{$subAdminData->role}}">
                                        <option value="">-- Select Role--</option>
                                        <option value="customer executive"<?php if ($subAdminData->role == 'customer executive') echo 'selected'; ?>>Customer Executive</option>
                                        <option value="call center"<?php if ($subAdminData->role == 'call center') echo 'selected'; ?>>Call Center</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button id="btnEditSubAdmin" type="submit" class="btn btn-primary pull-right">
                                <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> Update Subadmin 
                            </button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\EditSubadminRequest','#frmEditSubAdminForm') !!} 
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    getLatLong();
    function getLatLong() {
      var input = document.getElementById('address');
      var autocomplete = new google.maps.places.Autocomplete(input);
      google.maps.event.addListener(autocomplete, 'place_changed', function () {
        var place = autocomplete.getPlace();
        var lat = place.geometry.location.lat();
        var long = place.geometry.location.lng();
        $('#addressLat').val(lat);
        $('#addressLong').val(long);
      });
    }

    $('#frmEditSubAdminForm').on('submit', function (e) {
      getLatLong();
      if ($('#frmEditSubAdminForm').valid()) {
        $('#addLoader').show();
        $('#btnEditSubAdmin').prop('disabled', true);
      } else {
        $('#addLoader').hide();
        $('#btnEditSubAdmin').prop('disabled', false);
      }
    });
</script>
@stop

