@extends('admin::layouts.app')
@section('title', 'MarketPlace : Transaction Management')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Transaction Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/transactions')}}">Transaction Management</a></li>
            <li class="active">Transaction Listing</li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div id="transactionList" style="margin-top: 10px;"></div>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $().ready(function () {
      loadTransactionsList();
    });
    function loadTransactionsList() {
      var loader = '<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>';
      var url = "{{url('admin/load-transaction-list')}}";
      $.ajax({type: "GET", url: url,
        beforeSend: function () {
          $('#transactionList').html(loader);
        },
        success: function (data) {
          $("#transactionList").html(data.html);
        }
      });
    }
</script>
@stop
