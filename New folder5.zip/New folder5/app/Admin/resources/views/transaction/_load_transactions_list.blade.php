<table class="table table-hover">
    <thead>
        <tr>
            <th>No</th>
            <th>Order ID</th>
            <th>Driver Name</th>
            <th>Vendor Name</th>
            <th>Customer Name</th>
            <th>Order Type</th>
            <th>Transaction Date</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if($transactionData->count()>0)
        <?php $i = 1; ?>
        @foreach ($transactionData as $transaction)
        <?php
        if ($transactionData->currentPage() == 1) {
            $srNo = $i++;
        } else {
            $srNo = ($transactionData->currentPage() - 1) * $transactionData->perPage() + $i++;
        }
        ?>
        <tr id="tr_{{$transaction->id}}">
            <td>{{ $srNo }}</td>
            <td>{{ $transaction->order_id }}</td>
            <td>@if(!empty($transaction->getOrder->driver_id))
                {{App\Helpers\Helper::getDriverNameById($transaction->getOrder->driver_id)}}
                @else
                -
                @endif
            </td>
            <td>
                @if(!empty($transaction->getOrder->vendor_id))
                {{App\Helpers\Helper::getBusinessNameById($transaction->getOrder->vendor_id)}}
                @else
                -
                @endif
            </td>
            <td>
                {{App\Helpers\Helper::getBusinessNameById($transaction->user_id)}}
            </td>
            <td>{{$transaction->transaction_type}}</td>
            <td>{{ date('Y-m-d h:i:s', strtotime($transaction->created_at)) }}</td>
            <td><ul class="list-inline mb-0 ">
                    <li class="list-inline-item">
                        <a class="btn btn-primary" href="{{url('admin/transaction-detail/'.$transaction->order_id)}}">
                            <i class="fa fa-eye"> View</i>
                        </a>
                    </li>
                </ul>
            </td>
        </tr>
        @endforeach
    </tbody>
    @else
    <tr class="text-center"><td colspan="10"><div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div></td></tr>
    @endif
</table>
<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$transactionData->links()}}
    </ul>
</div>
<script>
    $(document).ready(function () {
      $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        var loader = '<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>';
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({type: 'GET', url: pageLink,
          beforeSend: function () {
            $('#transactionList').html(loader);
          },
          success: function (response) {
            $('.pagination:first').remove();
            $('#transactionList').html(response.html);
          }
        });
      });
    });
</script>

