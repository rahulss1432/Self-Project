@extends('admin::layouts.app')
@section('title', 'MarketPlace : Transaction Details')
@section('content') 
<link href="{{url('/public/css/print.css')}}" rel="stylesheet" media="print" type="text/css">
<style>
    .boxStyle {
        background-color: #fff;
        margin-bottom: 16px;
        border-radius: 6px;
        -webkit-box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
        -moz-box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
        box-shadow: 0 0 8px 1px rgba(154,165,238,.2);
    }   
</style>
<main class="main_content dashboardpage" id="viewAllUsers">
    <div class="main-content" style="padding:15px;">
        <section class="content-header">
            <h1>
                Transaction Details  
            </h1>
            <ol class="breadcrumb">
                <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="{{url('admin/transactions')}}">Transaction Management</a></li>
                <li class="active">Transaction Details</li>
            </ol>
        </section>
        <section class="content">
            <div class="box">
                <div class="box-body">
                    <div class="row margin-bottom">
                        <div class="col-sm-12 col-sm-offset-0">
                            <div class="pull-right afterPrint" style="margin-left:10px;">
                                <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
                            </div>
                            <div style="padding: 0px 0px" class="text-right afterPrint">
                                <button type="button"  class="btn btn-primary pull-right" onclick="printWindow()" ><i class="fa fa-print" aria-hidden="true"></i></button></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $productData = \App\Models\OrderProduct::where('order_id', '=', $orderData->id)->get();
            $subTotal = 0;
            ?>
            @if($productData->count() > 0)
            @foreach ($productData as $val)
            <?php $itemData = $val->getItems; ?>
            @foreach($itemData as $item)
            <?php
            if (!empty($val->quantity)) {
                $quantity = $val->quantity;
            } else {
                $quantity = 1;
            }
            $subTotal = $subTotal + ($quantity * $item->price)
            ?>
            @endforeach
            @endforeach
            @endif
            <div class="row">
                <div class="col-sm-12 col-md-8">
                    <div class="boxStyle">
                        <div class="detailBox clearfix">
                            <div class="table-responsive m-t-15" style="padding:15px;">
                                <table class="table table-bordered table_b_none" >
                                    <thead>
                                        <tr>
                                            <th scope="col">Order Id :</th>
                                            <td>{{$orderData->id}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Customer Name :</th>
                                            <td>{{$orderData->getCustomer->first_name}} {{$orderData->getCustomer->last_name}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Vendor Name :</th>
                                            <td>{{$orderData->getVendor->first_name}} {{$orderData->getVendor->last_name}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Transaction Date & Time :</th>
                                            <td>{{date('Y-m-d h:i:s',strtotime($transactionData->created_at))}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Payment Mode :</th>
                                            <td>{{$transactionData->transaction_type}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Driver Name :</th>
                                            <td>{{($orderData->getDriver)?$orderData->getDriver->first_name.' '.$orderData->getDriver->last_name:'-'}}</td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Amount :</th>
                                            <td>{{App\Helpers\Helper::getPriceFormatedValue(App\Models\OrderProduct::getAmountByOrderId($orderData->id))}} </td>
                                        </tr>
                                        <tr>    
                                            <th scope="col">Shipping Charges :</th>
                                            <td>{{App\Helpers\Helper::getPriceFormatedValue($orderData->shipping_charge)}} </td>
                                        </tr>
                                    </thead>
                                </table>    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="boxStyle">
                        <div class="detailBox clearfix">
                            <div class="detail">
                                <div class="table-responsive m-t-15" style="padding:15px;">
                                    <table class="table table-bordered table_b_none" >
                                        <thead>
                                            <tr>
                                                <th scope="col">Subtotal :</th>
                                                <td class="text-right">{{ App\Helpers\Helper::getPriceFormatedValue($subTotal)}} </td>
                                            </tr>
                                            <tr>
                                                <th scope="col">Delivery Fee :</th>
                                                <td class="text-right">{{App\Helpers\Helper::getPriceFormatedValue($orderData->shipping_charge)}} </td>
                                            </tr>
                                            <tr>
                                                <th scope="col">Processing Fee :</th>
                                                <td class="text-right">{{App\Helpers\Helper::getPriceFormatedValue($orderData->processing_fee)}}</td>
                                            </tr>
                                            @if(!empty($voucherData))
                                            <tr>
                                                <th scope="col">Promo Code :</th>
                                                <td class="text-right">
                                                    - {{App\Helpers\Helper::getPriceFormatedValue($voucherData->voucher_amount)}} 
                                                </td>
                                            </tr>
                                            @endif
                                            <tr>
                                                <th scope="col">Total :</th>
                                                <th class="text-right">{{App\Helpers\Helper::getPriceFormatedValue($orderData->total_amount)}} </th>
                                            </tr>
                                        </thead>
                                    </table>    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</main>
<script>
    function printWindow() {
      $('.afterPrint').hide();
      window.print();
    }
</script>
@stop
