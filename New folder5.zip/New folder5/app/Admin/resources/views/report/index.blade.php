@extends('admin::layouts.app')
@section('title', 'MarketPlace : Report Management')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Report Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('/admin/business-type')}}">Report Management</a></li>
            <li class="active">Report</li>
        </ol>
    </section>    
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" onclick="showSerach()" id="filterbtn" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>

                        </div>
                    </div>
                </div>
                <form id="searchField" style="display: none;" action="javascript:void(0);">
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-4">
                            <label>User Type</label> 
                            <select class="form-control" name="user_type">
                                <option value="">Select</option>
                                <option value="vendor">Vendor</option>
                                <option value="driver">Driver</option>
                                <option value="delivery_company">Delivery Company</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label>By Name</label> 
                            <input class="form-control" id="txtSearch" name="name" type="text" placeholder="Name" >
                        </div>
                        <div class="col-md-2">
                            <br>
                            <button id="btn-sub" type="submit" class="btn btn-primary " onclick="loadReportList();">
                                Filter <i class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                            <button id="btn-sub" type="submit" class="btn btn-primary" onclick="resetFilter();">
                                Reset <i class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="loadReportList">
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script type="text/javascript">
    $(document).ready(function () {
        $("#txtSearch").keypress(function (e) {
            if (e.which == 13) {
                loadReportList();
            }
        });
        loadReportList();
    });

    function loadReportList() {
        var searchFilter = $("#searchField").serializeArray();
        var token = '{{ csrf_token() }}';
        $("#loadReportList").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
        $.ajax({
            type: "POST",
            url: "{{ url('/admin/load-report-list') }}",
            data: {'_token': '{{csrf_token()}}'},
            data:searchFilter,
                    success: function (response)
                    {
                        $("#loadReportList").html(response.html);
                    }
        });
    }

    function showSerach() {
        $("#searchField").slideToggle("slow");
    }

    function resetFilter() {
        $('#searchField')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadReportList();
    }
</script>
@stop