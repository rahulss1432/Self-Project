@extends('admin::layouts.app')
@section('title', 'MarketPlace : Report Management')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Report Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('/admin/business-type')}}">Report Management</a></li>
            <li class="active">Report</li>
        </ol>
       
    </section>    
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" id="setlleAmountBtn" style="display: none;" onclick="settleAmount('{{$type}}');" id="filterbtn" style="margin-right:10px;">Settle</button>
                            <a class="btn btn-primary" id="btnDownloadCsv" onclick="exportCsvReport();" href="javascript:void(0);"> <i class="fa fa-upload"></i>  Export Report</a>   
                            
                            <a href="{{url('admin/report')}}" class="button btn btn-primary">Back</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="loadReportList">
                        <table class="table text-center table-hover" id="reportTable">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Description</th>
                                    <th>Debit</th>
                                    <th>Credit</th>
                                    <th>Line Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(count($reportData) > 0) 
                                <tr>
                                    <td class="col-sm-2"></td>
                                    <td class="col-sm-2">Remaining Amount</td>
                                    <td class="col-sm-2"></td>
                                    <td class="col-sm-2"></td>
                                    <td class="col-sm-2">{{isset($remainingAmount) ? (App\Helpers\Helper::getPriceFormatedValue($remainingAmount)) : '0'}}</td>


                                </tr>
                                @php 
                                $lineTotal = 0;
                                $creditTotal = 0;
                                $debitTotal = 0;

                                @endphp
                                @foreach($reportData as $transaction)
                                <?php
                                $val = $remainingAmount;
                                $remainingAmount = 0;
                                ?>
                                <tr>
                                    <td class="col-sm-3"><?php echo date('d/m/Y', strtotime($transaction->created_at)); ?></td>
                                    <td class="col-sm-3">{{'Sales of Order ID '.$transaction->id}}</td>
                                    <td class="col-sm-3">{{ App\Helpers\Helper::getPriceFormatedValue($transaction->total_amount)}}</td>
                                    <td class="col-sm-3"></td>
                                    <?php
                                    $lineTotal = $lineTotal + $transaction->total_amount + $val;
                                    $creditTotal = $creditTotal + $transaction->total_amount;
                                    $val = 0;
                                    ?>
                                    <td class="col-sm-3">{{ App\Helpers\Helper::getPriceFormatedValue($lineTotal)}}</td>


                                </tr>
                                <tr>
                                    <td class="col-sm-3"><?php echo date('d/m/Y', strtotime($transaction->created_at)); ?></td>
                                    @if($type == 'user')
                                    <?php $userData = App\Models\User::where('id', $userId)->first(); ?>
                                    @if($userData->user_type == 'vendor')
                                    <td class="col-sm-3">{{'Being '.$transaction->admin_commission. '% Commission of Order ID '.$transaction->id}}</td>
                                    @else
                                    <td class="col-sm-3">{{'Being '.$transaction->commission. ' flat Commission of Order ID '.$transaction->id}}</td>
                                    @endif
                                    @else
                                    <td class="col-sm-3">{{'Being '.$transaction->commission. ' flat Commission of Order ID '.$transaction->id}}</td>
                                    @endif

                                    <td class="col-sm-3"></td>

                                    <?php
                                    if ($type == 'user') {
                                        if ($userData->user_type == 'vendor') {
                                            $credit = ($transaction->total_amount * $transaction->admin_commission) / 100;
                                        } else {
                                            $credit = ($transaction->total_amount - $transaction->commission);
                                        }
                                    } else {
                                        $credit = ($transaction->total_amount - $transaction->commission);
                                    }
                                    $debitTotal = $debitTotal + $credit;
                                    $lineTotal = $lineTotal - $credit;
                                    ?>

                                    <td class="col-sm-3">{{ App\Helpers\Helper::getPriceFormatedValue($credit)}}</td>
                                    <td class="col-sm-3">{{ App\Helpers\Helper::getPriceFormatedValue($lineTotal)}}</td>


                                </tr>

                                @endforeach
                                <?php $lineTotal = $lineTotal + $remainingAmount; ?>
                                <tr>
                                    <th class="col-sm-3">Total</th>
                                    <th class="col-sm-3"></th>
                                    <th class="col-sm-3">{{ App\Helpers\Helper::getPriceFormatedValue($creditTotal)}}</th>
                                    <th class="col-sm-3">{{ App\Helpers\Helper::getPriceFormatedValue($debitTotal)}}</th>
                                    <th class="col-sm-3">{{ App\Helpers\Helper::getPriceFormatedValue($lineTotal)}}</th>


                                </tr>
                                @else
                                @if(isset($remainingAmount))
                                <tr>
                                    <td class="col-sm-2"></td>
                                    <td class="col-sm-2">Remaining Amount</td>
                                    <td class="col-sm-2"></td>
                                    <td class="col-sm-2"></td>
                                    <td class="col-sm-2">{{isset($remainingAmount) ? (App\Helpers\Helper::getPriceFormatedValue($remainingAmount)) : '0'}}</td>
                                </tr>
                                @endif
                                <tr>
                                    <td colspan="5">
                                        <div class="alert alert-danger text-center">{{\Config::get('constants.no_new_transaction')}}</div>
                                    </td>
                                </tr>
                                @endif
                            <input type="hidden" name="amount" value="{{isset($lineTotal) ? ($lineTotal) : (App\Helpers\Helper::getPriceFormatedValue($remainingAmount))}}" id="hddnAmount">
                            <input type="hidden" name="userId" value="{{$userId}}" id="hddnUserId">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<div class="modal settleAmount fade" id="edit_property" tabindex="-1" role="dialog" aria-labelledby="edit_property">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><img src="{{url('public/images/cross.png')}}"></span></button>
                <h4 class="modal-title text-center">Settle Amount</h4>
            </div>
            <div class="modal-body form-group" id="settleAmountModal">

            </div>
        </div>
    </div>
</div>
 <script src="{{url('public/js/jquery.table2excel.min.js')}}"></script>
<script>
function exportCsvReport(){
        $("#reportTable").table2excel({
            filename: "Report.xls"
        });
    }
</script>
<script type="text/javascript">
            $(document).ready(function () {
    var amount = $('#hddnAmount').val();
            if (amount > 0){
    $('#setlleAmountBtn').show();
    }
    });
            function loadReportList() {
            var txtSearch = $("#txtSearch").val();
                    var token = '{{ csrf_token() }}';
                    $("#loadReportList").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
                    $.ajax({
                    type: "POST",
                            url: "{{ url('/admin/load-report-list') }}",
                            data: {_token: token, search: txtSearch},
                            success: function (response)
                            {
                            $("#loadReportList").html(response.html);
                            }
                    });
            }

    function settleAmount(type) {
    var amount = $('#hddnAmount').val();
            var userId = $('#hddnUserId').val();
            var token = '{{ csrf_token() }}';
            $.ajax({type: "POST",
                    url: "{{url('/admin/amount-settle')}}",
                    data: {_token: token, amount: amount, userId: userId, type: type},
                    success: function (response) {
                    $('#settleAmountModal').html(response.html);
                            $(".settleAmount").modal();
                    }
            });
    }
</script>
@stop