<form id="frmSaveSettleAmount" class="form-horizontal" method="POST" action="{{url('/admin/save-settle-amount')}}">
    {{ csrf_field() }}
    <h4 class="modal-title">Amount *</h4>
    <input type="hidden" id="userId" name="userId" value="{{$userId}}">
    <input type="hidden" id="hddnType" name="type" value="{{$type}}">
    <input class="form-control" name="amount" placeholder="" value="{{$amount}}">
    <input type="hidden" name="totalAmount" placeholder="" value="{{$amount}}">
    <h4 class="modal-title">Remark *</h4>
    <input class="form-control price-input"  name="settle_remark" placeholder="" >
    
    <div class="modal-footer">
        <button  id="btnSettleAmount" class="btn btn-primary" type="submit">Save</button>
    </div>
</form>
{!! JsValidator::formRequest('App\Admin\Http\Requests\SettleAmountRequest','#frmSaveSettleAmount') !!}
<script>
    $("#btnSettleAmount").on('click', (function (e) {
      var btn = $('#btnSettleAmount');
      var form = $('#frmSaveSettleAmount');
      e.preventDefault();
      if (form.valid()) {
        btn.html('{{\App\Helpers\Helper::buttonLoader()}} Save');
        btn.prop('disabled', true);
        $.ajax({
          url: "{{url('admin/save-settle-amount')}}",
          type: "POST",
          data: form.serialize(),
          success: function (data)
          {
            btn.prop('disabled', false);
            location.reload();
          },
          error: function (data) {
            var obj = jQuery.parseJSON(data.responseText);
            for (var x in obj) {
              btn.prop('disabled', false);
              btn.html('Send');
              var errors = obj[x].length
              $('#' + x + '-error').html(obj[x]);
              $('#' + x + '-error').css("color", '#b30000');
              $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
            }
          },
        });
      }
    }));
</script>