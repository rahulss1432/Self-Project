<table class="table table-hover">
    <thead>
        <tr>
            <th>UserID</th>
            <th>Role</th>
            <th>Name</th>
            <th>Settle</th>
        </tr>
    </thead>
    <tbody>
        @if(count($userData) > 0) 

        @foreach($userData as $val)

        <tr>
            <td class="col-sm-3">
                @if(!empty($val->deliver_company_id))
                {{$val->deliver_company_id}}
                @else
                {{ $val->user_id }}
                @endif
            </td>
            <td class="col-sm-3">
                @if(!empty($val->deliver_company_id))
                {{ 'Delivery Company' }}
                @else
                {{ $val->user_type }}
                @endif
            </td>
            <td class="col-sm-3">
                @if(!empty($val->deliver_company_id))
                {{$val->company_name}}
                @else
                {{ $val->first_name }} {{$val->last_name}}
                @endif
            </td>
            <td class="col-sm-3">
                @if(!empty($val->deliver_company_id))
                <a href="{{url('admin/report/view-report/'.$val->deliver_company_id.'/company')}}" class="btn btn-primary"><i class="fa fa-eye"> View</i></a>
                @else
                <a href="{{url('admin/report/view-report/'.$val->user_id.'/user')}}" class="btn btn-primary"><i class="fa fa-eye"> View</i></a>
            @endif
            </td>
        </tr>
        @endforeach
        @else 
        <tr>
            <td colspan="4">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>

<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$userData->links()}}
    </ul>
</div>
<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#loadReportList").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
            var $this = $(this);
            var pageLink = $this.attr('href');
            var token = '{{ csrf_token() }}';
            var txtSearch = $("#txtSearch").val();
            $.ajax({type: 'POST', url: pageLink, data: {_token: token, txtSearch: txtSearch},
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#loadReportList").html(response.html);
                }
            });
        });
    });
</script>

