@extends('admin::layouts.app')
@section('title', 'MarketPlace : Order Notification')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Order Notification</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Order Notification Management</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="row">
                            </div>
                            <div class="boxStyle">
                                <div class="detailBox clearfix">
                                    <div class="table-responsive product_table" id="notification-list" style="padding:15px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $(document).ready(function () {
        loadNotifications()
    });
    function loadNotifications() {
        $("#load-drivers-list").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
        $.ajax({
            url: "{{url('admin/load-all-notifications')}}",
            type: 'POST',
            data: {_token: '{{ csrf_token() }}', call_from: 'order_notification_page'},
            success: function (response) {
                if (response.success = true) {
                    $('#notification-list').html(response.html);
                } else {
                    $("#notification-list").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
                }
            }
        });
    }

    function deleteNotification(notificationId) {
        bootbox.confirm('Are you sure you want to delete ?', function (result) {
            if (result) {
                $.ajax({
                    url: "{{url('admin/delete-notification')}}" + "/" + notificationId,
                    type: 'GET',
                    success: function (response) {
                        if (response.success = true) {
                            toastr.options.closeButton = true;
                            toastr.success('message', response.message, {timeOut: 1000});
                            $('#notification_' + notificationId).remove();
                            loadNotifications();
                        } else {
                            toastr.options.closeButton = true;
                            toastr.error('message', response.message, {timeOut: 1000});
                        }
                    }
                });
            }
        });
    }
    function changeStatusToDelete(notificationId) {
        bootbox.confirm('Are you sure you want to delete ?', function (result) {
            if (result) {
                $.ajax({
                    url: "{{url('admin/notification-status-delete')}}" + "/" + notificationId,
                    type: 'GET',
                    success: function (response) {
                        if (response.success = true) {
                            toastr.options.closeButton = true;
                            toastr.success('message', response.message, {timeOut: 1000});
                            $('#notification_' + notificationId).remove();
                            loadNotifications();
                        } else {
                            toastr.options.closeButton = true;
                            toastr.error('message', response.message, {timeOut: 1000});
                        }
                    }
                });
            }
        });
    }
</script>
@stop