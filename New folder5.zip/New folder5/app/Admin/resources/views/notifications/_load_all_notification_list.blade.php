@if($post['call_from'] == 'bell_button')
<!--bell notifications-->
@if(count($notifications)>0)             
<li class="header">You have notifications</li>
<li id="notification">
    <ul class="menu">
        @php    
        $i = 1;
        @endphp            
        @foreach($notifications as $data)    
        @if($i == 5)                          
        @break;
        @endif
        <li style="{{$data->status == 'unread' ? 'background-color: #d3cbef; font-weight: bold;' : '' }}">
            <a href="{{url('admin/order-notifications')}}">
                <i class="fa fa-shopping-cart text-green"></i>{{$data->message}}                
            </a>
        </li>
        @php 
        $i++;
        @endphp                                
        @endforeach
    </ul>
</li>
<li class="footer"><a href="{{url('admin/order-notifications')}}">View all</a></li>
@else
<li class="header alert-danger">{{\Config::get('constants.no_record_found')}}</li>
@endif
<!--bell notifications ends-->
@else
<table class="table admin-table">
    <thead>
        <tr>
            <th>No.</th>                
            <th>Oder ID</th>                
            <th>Subject</th>                
            <th>Message</th>                
            <th>Created At</th>                
            <th>Action</th>                
        </tr>
    </thead>
    <tbody>
        @if(count($notifications)>0)     
        @php    
        $i = 1;
        @endphp    
        @foreach($notifications as $data)
        <?php
        if ($notifications->currentPage() == 1) {
            $srNo = $i++;
        } else {
            $srNo = ($notifications->currentPage() - 1) * $notifications->perPage() + $i++;
        }
        ?>      
        <tr id="{{'notification_'.$data->id}}">
            <td>{{$srNo}}</td>
            <td><a href="{{url('admin/view-order',$data->order_id)}}">{{$data->order_id}}</a></td>
            <td>{{$data->subject}}</td>
            <td>{{$data->message}}</td>                
            <td>{{date('d-m-Y', strtotime( $data->created_at ))}}</td>
            <td class="md-table-td-more w-150" layout="">
                <ul class="list-inline action-btn">
                    @if($data->user->user_type == \Auth::guard('admin')->user()->user_type)
                    <button type="button" class="btn btn-danger" onclick='changeStatusToDelete("{{$data->id}}")'>delete</button>                                            
                    @else
                    <button type="button" class="btn btn-danger" onclick='deleteNotification("{{$data->id}}")'>delete</button>                                            
                    @endif
                </ul>
            </td>
        </tr>    
        @endforeach
        @else
        <tr>
            <td colspan="9">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif 
    </tbody>
</table>
<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$notifications->links()}}
    </ul>
</div>
<script>
    $(".pagination li a").on('click', function(e) {
        e.preventDefault();
        $("#load-drivers-list").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'POST',
            url: pageLink,
            async: false,
            data: {
                _token: '{{ csrf_token() }}',
                call_from: 'order_notification_page'
            },
            success: function(response) {
                $('.pagination:first').remove();
                $('#notification-list').html(response.html);
            }
        });
    });

    function deletenotification(notificationId) {
        bootbox.confirm('Are you sure you want to delete ?', function(result) {
            if (result) {
                $.ajax({
                    url: "{{url('admin/delete-notification')}}" + "/" + notificationId,
                    type: 'GET',
                    success: function(response) {
                        if (response) {
                            toastr.remove();
                            toastr.options.closeButton = true;
                            toastr.success("{{\Config::get('constants.delete_notification')}}", 'Success', {
                                timeOut: 3000
                            });
                            loadNotifications();
                        } else {
                            toastr.remove();
                            toastr.options.closeButton = true;
                            toastr.error("{{\Config::get('constants.something_wrong')}}", 'Error', {
                                timeOut: 3000
                            });
                        }
                    }
                });
            }
        });
    }
</script>
@endif