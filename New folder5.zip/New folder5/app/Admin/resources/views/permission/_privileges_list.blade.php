@if(count($list)>0)
    <form id="updatePrivileges" method="POST" action="{{url('admin/update-privileges')}}">
        {{ csrf_field() }}
        <table class="table admin-table">
            <thead>
                <tr>
                    <th>Type</th>
                    <th>Permissions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($list as $data)
                    <tr>
                        <td>{{$data->name}}</td>
                        <td>
                            <input type="hidden" name="role_id" value="{{$data->role_id}}">
                            <input name="status[]" value="{{$data->priv_id}}" type="checkbox" @if ($data->priv_status=='active')) checked="checked" @endif >
                        </td>
                    </tr>
                @endforeach
                <tr>
                    <td class="text-center" colspan="2">
                        <button id="assignButton" class="btn btn-primary"> 
                            <i id="assignLoader" class="fa fa-spinner fa-spin" style="display: none;"> </i> Assign 
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
@endif
<script type="text/javascript">
    $("#updatePrivileges").submit(function (e) {
        $("#assignButton").prop('disabled',true);
        $("#assignLoader").show();
    });
</script>