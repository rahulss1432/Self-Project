@extends('admin::layouts.app')
@section('title', 'MarketPlace : Permissions Management')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Permission Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Permissions Management</li>
        </ol>
    </section>

    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="form-group">
                    <label class="control-label col-sm-2">Role :-</label>
                    <div class="col-sm-2">
                        @if(count($role)>0)
                        <select class="form-control" name="name" onchange="getPrivileges(this.value)">
                            <option>Select Role</option>
                            @foreach($role as $val)
                            <option value="{{$val->id}}">{{$val->role}}</option>
                            @endforeach
                        </select>
                        @endif                            
                    </div>
                    <div id="subRoleBlock" style="display: none;">
                        <label class="control-label col-sm-2">Sub Role :-</label>
                        <div class="col-sm-2">
                            <select class="form-control" name="name" id="subRoleList" onchange="getPrivileges(this.value)">
                            </select>
                        </div>
                    </div>
                </div>
                <div class="form-group" id="privilegesList">

                </div>
            </div>
        </div>
    </section>
</main>

<script>

    function getPrivileges(id)
    {
      if (id != '')
      {
        if (id != '1')
        {
          $("#subRoleBlock").css("display", "block");
          getSubadminList(id);
          getAllPrivilegesList(id);
        }
        else
        {
          $("#subRoleBlock").css("display", "none");
        }
        getAllPrivilegesList(id);
      }
    }

    function getAllPrivilegesList(id)
    {
      var token = '{{ csrf_token() }}';
      $.ajax({
        url: "{{url('admin/privileges-list')}}",
        data: {_token: token, id: id},
        type: 'POST',
        success: function (response)
        {
          $("#privilegesList").html(response.html);
        }
      });
    }

    function getSubadminList(id)
    {
      var token = '{{ csrf_token() }}';
      $.ajax({
        url: "{{url('admin/subadmin-list')}}",
        data: {_token: token, id: id},
        type: 'POST',
        success: function (response)
        {
          $("#subRoleList").html(response.html);
        }
      });
    }

</script>
@stop