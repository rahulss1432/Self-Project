
<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Name</th>
            <th>Commission</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if(count($companyData) > 0) 
        <?php $i = 1; ?>
        @foreach($companyData as $result)
        <?php $sNo = $i++; ?>
        <tr id='delete_{{$result->id }}'>
            <td>{{$sNo}}</td>
            <td>{{$result->name}}</td>
            <td>&#x20B9; {{App\Helpers\Helper::getPriceFormatedValue($result->commission)}}</td>
            <td>
                <ul class="list-inline action mb-0">
                    <li><a href="{{url('/admin/edit-deliver-company/'.$result->id)}}" class="btn btn-primary" aria-hidden="true"> <i class="fa fa-pencil-square-o"></i> Edit</a></li>
                    <li><a href="javascript:void(0);" class="btn btn-primary" aria-hidden="true" onclick='deleteDeliverCompany("{{$result->id }}");' > <i class="fa fa-trash-o"></i> Delete</a></li>
                </ul>
            </td>
        </tr>
        @endforeach
        @else 
        <tr>
            <td colspan="5">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>

<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$companyData->links()}}
    </ul>
</div>

<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#loadDeliverCompanyList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
            var $this = $(this);
            var pageLink = $this.attr('href');
            var company = $('#companySearch').val();
            $.ajax({
                type: 'POST',
                url: pageLink, 
                async: false, 
                data: {_token: '{{ csrf_token() }}', company: company},
                success: function (response) {
                    $('.pagination:first').remove();
                    $('#loadDeliverCompanyList').html(response.html);
                }
            });
        });
    });
</script>
