@extends('admin::layouts.app')
@section('title', 'MarketPlace : Edit Deliver Company')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Deliver Company Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('admin/deliver-company-management')}}">Deliver Company Management</a></li>
            <li class="active">Edit Deliver Company</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Deliver Company</h3>
                    </div>
                    <form id="updateCompanyForm" class="form-horizontal" method="POST" action="{{url('admin/update-deliver-company')}}">
                        <input type="hidden" name="companyId" value="{{$companyData->id}}">
                        {{ csrf_field() }}

                        <div class="box-body">
                            <div class="form-group">
                                <label for="name" class="col-sm-3 control-label">Name <span class="error-star">*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" name="name" value="{{$companyData->name}}" class="form-control input-lg" placeholder="Name">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="contact_email" class="col-sm-3 control-label">Contact Person Email <span class="error-star">*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" name="contact_email" value="{{$companyData->contact_email}}" class="form-control input-lg" placeholder="Contact Person Email">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="contact_mobile" class="col-sm-3 control-label">Contact Person Mobile <span class="error-star">*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" name="contact_mobile" value="{{$companyData->contact_mobile}}" class="form-control input-lg" id="contactMobile" placeholder="Contact Person Mobile" maxlength="10">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="contact_name" class="col-sm-3 control-label">Contact Person Name <span class="error-star">*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" name="contact_name" value="{{$companyData->contact_name}}" class="form-control input-lg" placeholder="Contact Person Name">
                                </div>
                            </div>

                            <div class="form-group" id="validComission">
                                <label for="commission" class="col-sm-3 control-label">Commission <span class="error-star">*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" name="commission" value="{{$companyData->commission}}" class="form-control input-lg" id="commission" placeholder="Commission" onKeyPress="if(this.value.length==10) return false;">
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <center>
                                <button id="updateCompanyBtn" type="submit" class="btn btn-primary pull-right">Update Deliver Company</button>
                            </center>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\EditDeliverCompanyRequest','#updateCompanyForm') !!}
                </div>
            </div>
        </div>
    </section>
</main>
<script>
    $("#updateCompanyBtn").on('click', (function (e) {
        var btn = $('#updateCompanyBtn');
        var form = $('#updateCompanyForm');
        e.preventDefault();
        if (form.valid()) {
            btn.html('{{\App\Helpers\Helper::buttonLoader()}} Updating Deliver Company');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{url('admin/update-deliver-company')}}",
                type: "POST",
                data: form.serialize(),
                success: function (data)
                {
                    btn.prop('disabled', false);
                    window.location.href = '{{url("/admin/deliver-company-management")}}';
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
    
    $("#contactMobile").keypress(function (e) {
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
          return false;
        }
    });
</script>
@stop