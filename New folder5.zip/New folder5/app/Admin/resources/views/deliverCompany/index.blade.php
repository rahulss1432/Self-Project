@extends('admin::layouts.app')
@section('title', 'MarketPlace : Deliver Company Management')
@section('content')
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>Deliver Company Management</h1>
        <ol class="breadcrumb">
            <li><a href="{{url('admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Deliver Company Management</li>
        </ol>
    </section>
    
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" onclick="showSearch()" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class=" btn btn-primary" href="{{url('/admin/create-deliver-company')}}"> <i class="fa fa-plus-circle"></i> Create Company Category</a>
                        </div>
                    </div>
                </div>
                <form id="searchCompany" style="display: none;" action="javascript:void(0);">
                       <div class="row">
                        <div class="col-md-4">
                            <label> Deliver Company</label> 
                            <input class="form-control" type="text" id="companySearch" name="company_name" placeholder="Company Name">
                         </div>
                        <div class="col-md-2">
                            <br>
                            <button id="btnCompany" type="submit" class="btn btn-primary " onclick="loadDeliverCompanies();">Filter</button>
                            <button id="btnCompany" type="submit" class="btn btn-primary" onclick="resetFilter();">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="loadDeliverCompanyList">
                        
                    </div>
                </div>
            </div>
        </div>

    </section>
</main>
<script>
    $(document).ready(function(){
        loadDeliverCompanies();
    });
    
    function showSearch() {
        $("#searchCompany").slideToggle("slow");
    }
    
    function resetFilter() {
        $('#searchCompany')[0].reset();
        loadDeliverCompanies();
    }
    
    function loadDeliverCompanies(){
        $("#loadDeliverCompanyList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
        var company = $('#companySearch').val();
        $.ajax({
            type: "POST",
            data: {_token: '{{ csrf_token() }}',company: company},
            url: "{{url('/admin/load-deliver-companies')}}",
            success: function (response) {
                $('#loadDeliverCompanyList').html(response.html);
            }
        });
    }
    
    function deleteDeliverCompany(id) {
        bootbox.confirm('Are you sure you want to delete this deliver company?', function (result){
            if (result){
                $.ajax({
                type: "GET",
                    url: "{{url('/admin/delete-deliver-company')}}/" + id,
                    success: function(response) {
                        location.reload();
                    }
                });
            }
        });
    }
</script>
@stop