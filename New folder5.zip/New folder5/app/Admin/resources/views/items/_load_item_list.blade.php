<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Product Name</th>
            <th>Category</th>
            <th>Business Name</th>
            <th>Out Stock / In Stock</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if(count($itemData) > 0) 
        <?php $i = 1; ?>
        @foreach($itemData as $item)
        <?php $sNo = $i++; ?>
        <tr>
            <td>{{$sNo}}</td>
            <td>{{$item->product_name}}</td>
            <td>{{App\Helpers\Helper::getCategoryNameById($item->category_id)}}</td>
            <td>{{App\Helpers\Helper::getBusineessNameByVendorId($item->business_id)}}</td>
            <td>
                @if($item->stock_status == 'in')    
                <label class="switch">
                    <input type="checkbox" id="enabled_{{$item->id}}" onchange="updateStockStatus('{{$item->id}}', '{{$item->stock_status}}');" checked>
                    <span class="slider1 round"></span>
                </label>
                @else
                <label class="switch">
                    <input type="checkbox" id="disabled_{{$item->id}}" onchange="updateStockStatus('{{$item->id}}', '{{$item->stock_status}}');">
                    <span class="slider1 round"></span>
                </label>
                @endif
            </td>
            <td>
                <ul class="list-inline action mb-0">
                    <li><a href="{{url('/admin/edit-item/'.$item->id)}}" class="btn btn-primary" aria-hidden="true"> <i class="fa fa-pencil-square-o"></i> Edit</a></li>
                    <li><a href="javascript:void(0);" class="btn btn-primary" aria-hidden="true" onclick="deleteItem('{{$item->id}}');" > <i class="fa fa-trash-o"></i> Delete</a></li>
                </ul>
            </td>
        </tr>
        @endforeach
        @else 
        <tr>
            <td colspan="6">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>

<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$itemData->links()}}
    </ul>
</div>

<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#loadItemList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
            var $this = $(this);
            var pageLink = $this.attr('href');
            var itemFilter = $("#searchField").serialize();
            $.ajax({
                type: 'POST',
                url: pageLink, 
                async: false, 
                data: itemFilter,
                success: function (response) {
                    $('.pagination:first').remove();
                    $('#loadItemList').html(response.html);
                }
            });
        });
    });
</script>