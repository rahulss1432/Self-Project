@extends('admin::layouts.app')
@section('title', 'MarketPlace : Item Management')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">

    <section class="content-header">
        <h1>
            Item Management
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('/admin/item-management')}}">Item Management</a></li>
            <li class="active">Item Listing </li>
        </ol>
    </section>

    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" onclick="showSearch()" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class=" btn btn-primary" href="{{url('/admin/create-item')}}"> <i class="fa fa-plus-circle"></i>  Create Item</a>
                            <a class=" btn btn-primary" href="{{url('/admin/create-category')}}"> <i class="fa fa-plus-circle"></i>  Create Category</a>
                        </div>
                    </div>
                </div>
                <form id="searchField" style="display: none;" action="javascript:void(0);" onsubmit="loadItems()">
                    {{ csrf_field()}}
                    <div class="row">
                        <div class="col-md-2">
                            <label> Name of product</label> 
                            <input class="form-control" type="text" id="productSearch" name="product_name" placeholder="Product Name">
                        </div>
                        <div class="col-md-2">
                            <label> Category Name</label> 
                            @php echo \App\Models\Category::getCategoryDropdown(0); @endphp
                        </div>
                        <div class="col-md-2">
                            <label> Business Name</label> 
                            @php echo \App\Models\User::getBusinessDropdown(0); @endphp
                        </div>
                        <div class="col-md-2">
                            <br>
                            <button id="btnSubmit" type="button" class="btn btn-primary" onclick="loadItems();">Filter</button>
                            <button id="btnSubmit" type="button" class="btn btn-primary" onclick="resetFilter();">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="loadItemList">

                    </div>
                </div>
            </div>
        </div>

    </section>
</main>

<script>
    $(document).ready(function () {
        loadItems();

        $("select").removeClass("input-lg");
    });

    function showSearch() {
        $("#searchField").slideToggle("slow");
    }

    function loadItems() {
        $("#loadItemList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
        var itemFilter = $("#searchField").serialize();
        $.ajax({
            type: "POST",
            data: itemFilter,
            url: "{{url('/admin/load-items')}}",
            success: function (response) {
                $('#loadItemList').html(response.html);
            }
        });
    }

    function resetFilter() {
        $('#searchField')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadItems();
    }

    function deleteItem(id) {
        bootbox.confirm('Are you sure you want to delete this item?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "{{url('/admin/delete-item')}}/" + id,
                    success: function (response) {
                        location.reload();
                    }
                });
            }
        });
    }

    function updateStockStatus(id, status) {
        if (status == 'in') {
            var msg = "Are you sure that item is out of stock?";
        } else if (status == 'out') {
            var msg = "Are you sure that item is in stock?";
        }
        bootbox.confirm(msg, function (result) {
            if (result) {
                $.ajax({
                    type: "POST",
                    url: "{{url('/admin/change-item-stock-status')}}/" + id,
                    data: {'_token': '{{csrf_token()}}'},
                    success: function (response) {
                        if (response) {
                            location.reload();
                        }
                    }
                });
            } else {
                if (status == 'in'){
                $('#enabled_' + id).prop('checked', true);
                } else{
                $('#disabled_' + id).prop('checked', false);
                }
            }
        });
    }
</script>
@stop