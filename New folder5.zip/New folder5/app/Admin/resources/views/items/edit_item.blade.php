@extends('admin::layouts.app')
@section('title', 'MarketPlace : Edit Item')
@section('content') 
<style>
    /*image upload style starts*/    
    .upload-btn-wrapper {
        position: relative;
        overflow: hidden;
        display: inline-block;
        border: 1px solid #00BFFF;
        box-shadow: 0px 0px 1px 1px #00BFFF;
    }
    .img {
        border: 2px solid gray;
        color: gray;
        background-color: white;
        padding: 8px 20px;
        border-radius: 8px;
        font-size: 20px;
        font-weight: bold;
    }
    .upload-btn-wrapper input[type=file] {
        position: absolute;
        left: 0;
        top: 0;
        opacity: 0;
        height: 265px;
    }
    /*image upload style ends*/

</style>
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Item Management
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('/admin/item-management')}}">Item Management</a></li>
            <li class="active">Edit Item</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Item</h3>
                    </div>
                    <form role="form" id="itemUpdateForm" method="post" action="{{url('/admin/update-items')}}">
                        <input type="hidden" name="itemId" value="{{$itemData->id}}">
                        <input type="hidden" name="delete_id" id="deleteId" value="">
                        {{csrf_field()}}
                        <div class="box-body">
                            <div class="form-group col-lg-12 text-center"> 
                                <div class="upload-btn-wrapper">
                                    <img id="itemImagePreview" src="{{App\Helpers\Helper::checkItemImage($itemData->item_image,'item-pictures')}}" height="125" width="285" class="imagePreview"> 
                                    <input id="itemImage" type="file" class="form-control input-lg" name="item_image">                                                                                
                                </div>
                                <input type="hidden" name="item_picture" id="itemPicture" value="{{$itemData->item_image}}">
                            </div>

                            <div class="form-group col-lg-6">
                                <label for="business">Business Name <span class="error-star">*</span></label>
                                @php echo \App\Models\User::getBusinessDropdown($itemData->business_id); @endphp
                            </div>

                            <div class="form-group col-lg-6" id="cat">
                                <label for="category">Category <span class="error-star">*</span></label>
                                <select class="form-control input-lg" id="category" name="category_id" onchange="validateCategory();">
                                    <option value="">-- Select Category --</option>
                                </select>
                            </div>

                            <div class="form-group col-lg-6" id="validProductName">
                                <label for="product">Product Name <span class="error-star">*</span></label>
                                <input type="text" class="form-control input-lg" id="product" name="product_name"  value="{{$itemData->product_name}}" placeholder="Enter Product Name">
                            </div>

                            <div class="form-group col-lg-6">
                                <label for="price">Price <span class="error-star">*</span></label>
                                <input type="text" class="form-control input-lg" id="price" name="price" value="{{$itemData->price}}" placeholder="Enter Price" onKeyPress="if(this.value.length==10) return false;">
                            </div>

                            <div class="form-group col-lg-12">
                                <label for="description">Product Short Description <span class="error-star">*</span></label>
                                <textarea type="text" class="form-control input-lg" id="description" name="product_description" placeholder="Enter Description">{{$itemData->product_description}}</textarea>
                            </div>

                            <div class="form-group col-lg-12">
                                <label for="stock_status">Stock Status <span class="error-star">*</span></label>
                                <select class="form-control input-lg" name="stock_status" >
                                    <option value="" disabled selected>-- Please Select--</option>
                                    <option value="in" <?php
                                    if ($itemData->stock_status == 'in') {
                                        echo "selected";
                                    }
                                    ?>>In</option>
                                    <option value="out" <?php
                                    if ($itemData->stock_status == 'out') {
                                        echo "selected";
                                    }
                                    ?>>Out</option>
                                </select>
                            </div>

                            <div class="dynamicform_wrapper col-lg-12" data-dynamicform="dynamicform_3a64e3a9">
                                <button type="button" name="add" id="add" class="btn btn-primary pull-left" onclick="addMore();">Add Option Value</button>
                            </div>
                            <div class="clearfix"></div>
                            <div class="box-primary" id="addIcon">

                            </div>

                            @if($attrItem->count()>0)
                            <?php $counter = 1; ?>
                            @foreach($attrItem as $item)
                            <div id="addFields_<?php echo $counter; ?>" class="add_fields">
                                <input type="hidden" name="ids[]" value="{{$item->id}}">

                                <div class="box-body" id="addFields_<?php echo $counter; ?>">
                                    <div class="box-header with-border">
                                        <p class="box-title">Attribute</p><span class="pull-right"><i class="fa fa-close" onclick="deleteIcon(<?php echo $counter; ?>,'{{$item->id}}')"></i></span>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="attribute">Attribute Id</label>
                                        @php echo \App\Models\Attribute::getAttributeDropdown($item->attribute_id); @endphp
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="option_value">Option Value ID</label>
                                        @php echo \App\Models\OptionValue::getOptionValueDropdown($item->attribute_id,$item->option_id); @endphp
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="quantity">Quantity</label>
                                        <input type="text" class="form-control input-lg" id="quantity" name="product_options_quantity[]" value="{{$item->product_quantity}}" placeholder="Enter Quantity" onKeyPress="if(this.value.length==10) return false;">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label for="price">Price</label>
                                        <input type="text" class="form-control input-lg" id="price" name="product_options_price[]" value="{{$item->product_price}}" placeholder="Enter Price" onKeyPress="if(this.value.length==10) return false;">
                                    </div>
                                </div>
                            </div>
                            <?php $counter++; ?>
                            @endforeach
                            @endif
                        </div>
                        <div class="box-footer">
                            <button type="submit" id="btnUpdateItem" class="btn btn-primary pull-right">
                                Update Item <i id="add-loader" class="fa fa-spinner fa-spin" style="display: none;"></i>
                            </button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\EditItemsRequest','#itemUpdateForm') !!} 
                </div>
            </div>
        </div>
    </section>    
</main>
<!-- cropper-Modal -->
<div class="modal fade" id="itemImageCroperModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Modal Header</h4>
            </div>
            <div id="ItemImageCropperForm">
            </div>                            
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
    getCategoryByBusiness('{{$itemData->business_id}}');
        $('#category').val('{{$itemData->category_id}}');
    });
    
    $("#business").on("change", function(){
        var businessId = $(this).val();
        $('#product').val('');
        $('#validProductName').removeClass('has-error');
        $('#cat').removeClass('has-error');
        $('#product-error').html('');
        $('#category-error').html('');
        getCategoryByBusiness(businessId);
    });
    
    $("#btnUpdateItem").on('click', (function (e) {
        e.preventDefault();
        if ($('#itemUpdateForm').valid()) {
            $('#btnUpdateItem').html('{{\App\Helpers\Helper::buttonLoader()}} Updating Item');
            $('#btnUpdateItem').prop('disabled', true);
            $.ajax({
            url: "{{url('/admin/update-items')}}",
                    type: "POST",
                    data: new FormData($('#itemUpdateForm')[0]),
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function (data){
                        window.location.href = '{{url("/admin/item-management")}}';
                    },
                    error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        $("#btnUpdateItem").prop('disabled', false);
                        $("#btnUpdateItem").html('Submit');
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#dd4b39');
                        $('#' + x + '-error').parent().parent().removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
    
    function getOptionValue(obj) {
    var token = '{{ csrf_token() }}';
        $.ajax({
        url: "{{url('/admin/get-option-value')}}",
            type: 'POST',
            data: {_token: token, attrId: $(obj).val()},
            success: function (data) {
            console.log(data);
                    $(obj).parent().next('div').find('select').html(data.html);
            },
            error: function (data) {
            console.log('an error occurred');
            }
        });
    }

    function addMore() {
        var counter = 1;
        $(".add_fields").each(function(){
            counter++;
        });
        
        var attribute = '@php echo \App\Models\Attribute::getAttributeDropdown(0); @endphp';
        $('#addIcon').append('<div id="addFields_' + counter + '">\
                    <input type="hidden" name=ids[]>\
                    <div class="box-body" id="addFields_' + counter + '">\
                        <div class="box-header with-border">\
                            <p class="box-title">Attribute</p><span class="pull-right"><i class="fa fa-close" onclick="deleteIcon('+counter+','+null+')"></i></span>\
                        </div>\
                        <div class="form-group col-lg-6">\
                            <label for="attribute">Attribute Id</label>\
                            ' + attribute + '\
                        </div>\
                        <div class="form-group col-lg-6">\
                            <label for="optionValue">Option Value ID</label>\
                            <select id="optionValue" name="option_value_id[]" class="form-control input-lg hide_this" onchange="$(this).valid()"data-live-search="true">\
                                <option value="">-- Select Option Value --</option>\
                            </select>\
                        </div>\
                        <div class="form-group col-lg-6">\
                            <label for="quantity">Quantity</label>\
                            <input type="text" class="form-control input-lg" id="quantity" name="product_options_quantity[]" placeholder="Enter Quantity" onKeyPress="if(this.value.length==10) return false;">\
                        </div>\
                        <div class="form-group col-lg-6">\
                            <label for="price">Price</label>\
                            <input type="text" class="form-control input-lg" id="price" name="product_options_price[]" placeholder="Enter Price" onKeyPress="if(this.value.length==10) return false;">\
                        </div>\
                    </div>\
                </div>');
        counter++;
    }

    function deleteIcon(id, itemId) {
        if (itemId != ''){
            $('#deleteId').val($('#deleteId').val() + ',' + itemId);
            $("#addFields_" + id).remove();
        } else{
            $("#addFields_" + id).remove();
        }
    }

    function getCategoryByBusiness(businessId){
    var token = '{{ csrf_token() }}';
        $.ajax({
            url: "{{url('/admin/get-category-by-business')}}",
            type: 'GET',
            data: {_token: token, businessId: businessId},
            success: function (data) {
                var catId = '{{$itemData->category_id}}';
                $('#category').html(data.html);
                if (catId != ''){
                    $('#category').val('{{$itemData->category_id}}');
                }
            },
            error: function (data) {
                console.log('an error occurred');
            }
        });
    }

/* image uploading with cropper*/
    var profile_picture = $('#itemImage');
    new AjaxUpload(profile_picture, {
    action: "{{url('/admin/upload-item-image')}}", name: 'item_image',
    cache: false,
    method: 'post',
    data: {_token: '{{ csrf_token() }}'},
    responseType: "JSON",
        onSubmit: function (file, ext) {
        if (!(ext && /^(jpg|png|jpeg)$/.test(ext))) {
        bootbox.alert('Only jpg, jpeg, png files are allowed.');
                return false;
        }
    },
        onComplete: function (file, response) {
            if (file != ""){
                if (response.success){
                    loadItemImageCropperModal(response.filename, 'item-type-image');
                    $('#itemImageCroperModal').modal('show');
                } else {
                    toastr.remove();
                    toastr.options.closeButton = true;
                    toastr.error(response.message, 'Error', {timeOut: 1000});
                }
            } else {
                bootbox.alert("Error occured! please try again.");
            }
        }
    });
                    
    function loadItemImageCropperModal(imageName, type) {
        $.ajax({
            url: "{{url('/admin/load-item-image-cropper')}}",
            type: 'GET',
            data: {imageName: imageName, imageType: type},
            success: function (response) {
                $('#ItemImageCropperForm').html(response.html);
            }
        });
    }
/*image upload cropper ends*/

    function validateCategory(){
        $('#product').val('');
        $('#validProductName').removeClass('has-error');
        $('#product-error').html('');
    }
</script>
@stop

