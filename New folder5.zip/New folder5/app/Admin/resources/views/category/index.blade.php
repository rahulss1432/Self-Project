@extends('admin::layouts.app')
@section('title', 'MarketPlace : Category Management')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Category Management
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('/admin/category-management')}}">Product Category</a></li>
            <li class="active">Category Listing</li>
        </ol>
    </section>
    
    <section class="content">
        <div class="box">                       
            <div class="box-body">
                <div class="row margin-bottom">
                    <div class="col-sm-12 col-sm-offset-0">
                        <div style="padding: 10px 0px" class="text-right">
                            <button type="button" class="btn btn-primary" onclick="showSearch()" style="margin-right:10px;"><i class="fa fa-filter" aria-hidden="true"></i></button>
                            <a class=" btn btn-primary" href="{{url('/admin/create-category')}}"> <i class="fa fa-plus-circle"></i>  Create Category</a>
                        </div>
                    </div>
                </div>
                <form id="searchField" style="display: none;" action="javascript:void(0);">
                    <div class="row">
                        <div class="col-md-4">
                            <label> Order state</label> 
                            <input class="form-control" type="text" id="categorySearch" name="cat_name" placeholder="Category Name">
                        </div>
                        <div class="col-md-2">
                            <br>
                            <button id="btnSubmit" type="submit" class="btn btn-primary " onclick="loadCategories();">Filter</button>
                            <button id="btnSubmit" type="submit" class="btn btn-primary" onclick="resetFilter();">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding" id="loadCategoryList">
                        
                    </div>
                </div>
            </div>
        </div>

    </section>
</main>

<script>
    $(document).ready(function(){
        loadCategories();
    });
    
    function showSearch() {
        $("#searchField").slideToggle("slow");
    }
    
    function resetFilter() {
        $('#searchField')[0].reset();
        loadCategories();
    }
    
    function loadCategories(){
        $("#loadCategoryList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
        var category = $('#categorySearch').val();
        $.ajax({
            type: "POST",
            data: {_token: '{{ csrf_token() }}',category: category},
            url: "{{url('/admin/load-categories')}}",
            success: function (response) {
                $('#loadCategoryList').html(response.html);
            }
        });
    }
    
    function deleteCategory(id) {
        bootbox.confirm('Are you sure you want to delete this category?', function (result){
            if (result){
                $.ajax({
                type: "GET",
                    url: "{{url('/admin/delete-category')}}/" + id,
                    success: function(response) {
                        location.reload();
                    }
                });
            }
        });
    }
</script>
@stop