@extends('admin::layouts.app')
@section('title', 'MarketPlace : Create Category')
@section('content') 
<main class="main_content dashboardpage" id="viewAllUsers">
    <section class="content-header">
        <h1>
            Create Product Category
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/admin/admin-dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{url('/admin/category-management')}}">Product Category</a></li>
            <li class="active">Create Category</li>
        </ol>
        <div class="pull-right">
            <a href="{{URL::previous()}}" class="button btn btn-primary">Back</a>
        </div>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Add Category</h3>
                    </div>
                    <form class="form-horizontal" id="catForm" method="post" action="{{url('/admin/save-category')}}">
                        {{csrf_field()}}
                        <div class="box-body">

                            <div class="form-group">
                                <label for="business_name" class="col-sm-3 control-label">Business Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    @php echo \App\Models\User::getBusinessDropdown(0); @endphp
                                </div>
                            </div>
                            
                            <div class="form-group" id="validCatName">
                                <label for="categoryName" class="col-sm-3 control-label">Category Name <span class="error-star">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="categoryName" class="form-control input-lg" id="categoryName" placeholder="Enter Category">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="status" class="col-sm-3 control-label">Status <span class="error-star">*</span></label>

                                <div class="col-sm-9">
                                    <select class="form-control input-lg" name="status">
                                        <option value="">-- Please Select--</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <div class="box-footer">
                            <button id="btnCat" type="submit" class="btn btn-primary pull-right">Add Category</button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\AddCategoryRequest','#catForm') !!} 
                </div>
            </div>
        </div>
    </section>
</main>

<script>
    $("#business").on("change", function () {
        var businessId = $(this).val();
        $('#categoryName').val('');
        $('#validCatName').removeClass('has-error');
        $('#categoryName-error').html('');
    });
    
    $("#btnCat").on('click', (function (e) {
        e.preventDefault();
        if ($('#catForm').valid()) {
            $('#btnCat').html('{{\App\Helpers\Helper::buttonLoader()}} Adding Category');
            $('#btnCat').prop('disabled', true);
            $.ajax({
                url: "{{url('/admin/save-category')}}",
                type: "POST",
                data: new FormData($('#catForm')[0]),
                contentType: false,
                cache: false,
                processData: false,
                success: function (data)
                {
                    window.location.href = '{{url("/admin/category-management")}}';
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        $("#btnCat").prop('disabled', false);
                        $("#btnCat").html('Submit');
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#dd4b39');
                        $('#' + x + '-error').parent().parent().removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
</script>
@stop

