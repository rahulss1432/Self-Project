<table class="table table-hover">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Category Name</th>
            <th>Business Name</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if(count($categoryData) > 0) 
        <?php $i = 1; ?>
        @foreach($categoryData as $result)
        <?php $sNo = $i++; ?>
        <tr id='delete_{{$result->id }}'>
            <td>{{$sNo}}</td>
            <td>{{$result->category_name}}</td>
            <td>{{App\Helpers\Helper::getBusineessNameByVendorId($result->business_id)}}</td>
            <td>{{$result->status}}</td>
            <td>
                <ul class="list-inline action mb-0">
                    <li><a href="{{url('/admin/edit-category/'.$result->id)}}" class="btn btn-primary" aria-hidden="true"> <i class="fa fa-pencil-square-o"></i> Edit</a></li>
                    <li><a href="javascript:void(0);" class="btn btn-primary" aria-hidden="true" onclick='deleteCategory("{{$result->id }}");' > <i class="fa fa-trash-o"></i> Delete</a></li>
                </ul>
            </td>
        </tr>
        @endforeach
        @else 
        <tr>
            <td colspan="5">
                <div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
            </td>
        </tr>
        @endif
    </tbody>
</table>

<div class="box-footer clearfix">
    <ul class="pagination pagination-sm no-margin pull-right">
        {{$categoryData->links()}}
    </ul>
</div>

<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#loadCategoryList").html('<div class="text-center col-sm-12"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
            var $this = $(this);
            var pageLink = $this.attr('href');
            var category = $('#categorySearch').val();
            $.ajax({
                type: 'POST',
                url: pageLink, 
                async: false, 
                data: {_token: '{{ csrf_token() }}', category: category},
                success: function (response) {
                    $('.pagination:first').remove();
                    $('#loadCategoryList').html(response.html);
                }
            });
        });
    });
</script>
