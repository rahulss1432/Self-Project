<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DeliveryArea;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Admin\Http\Requests\SettleAmountRequest;
use App\Models\User;
use Excel;
use App\Helpers\Helper;

class ReportController extends Controller {

    public function index() {
        return view('admin::report.index');
    }

    public function loadReportList(Request $request) {
        $post = $request->all();
        $userData = \App\Models\Order::getAllUsersListForReport($post);
        $html = View::make('admin::report._load_report_list', ['userData' => $userData])->render();
        return Response::json(['html' => $html]);
    }

    public function settleAmount(Request $request) {
        $post = $request->all();
        $html = View::make('admin::report._settle_amount', ['amount' => $post['amount'], 'userId' => $post['userId'], 'type' => $post['type']])->render();
        return Response::json(['html' => $html]);
    }

    public function viewReport($id, $slug) {
        $reportData = \App\Models\Order::getOrderDetailForReport($id, $slug);
        if ($slug == 'company') {
            $remainingAmount = \App\Models\DeliverCompany::getRemainingAmountById($id);
        } else {
            $userData = User::where('id', $id)->first();
            $driverDetail = \App\Models\DriverDetail::where('user_id', $id)->first();
            if ($userData->user_type == 'vendor') {
                $remainingAmount = User::getRemainingAmountById($id);
            } else if ($userData->user_type == 'driver' && $driverDetail->deliver_company_id == null) {
                $remainingAmount = User::getRemainingAmountById($id);
            }
        }
        return view('admin::report.view_user_report', ['reportData' => $reportData, 'remainingAmount' => $remainingAmount, 'userId' => $id, 'type' => $slug]);
    }

    public function saveSettleAmount(SettleAmountRequest $request) {
        $post = $request->all();
        $result = \App\Models\Order::actionSaveSettleAmount($post);
        if ($result) {
            $request->session()->flash('success', \Config::get('constants.save_settle_amount'));
            return Response::json(['success' => true]);
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return Response::json(['success' => false]);
        }
    }

}
