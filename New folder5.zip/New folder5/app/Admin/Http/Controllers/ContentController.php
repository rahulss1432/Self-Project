<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Admin\Http\Controllers\Controller;
use App\Models\Content;
use App\Admin\Http\Requests\CreateContentRequest;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class ContentController extends Controller {

    public function index() {
        return view('admin::content.content_index');
    }

    public function addContent() {
        return view('admin::content.add_content');
    }

    public function loadContentList(Request $request) {
        $post = $request->all();
        $contentData = Content::getAllContents($post);
        $html = View::make('admin::content._load_contents_list', ['contentData' => $contentData])->render();
        return Response::json(['html' => $html, 'contentData' => $contentData]);
    }

    public function saveContent(CreateContentRequest $request) {
        $post = $request->all();
        $result = Content::saveContents($post);
        if ($result) {
            $request->session()->flash('success', 'Content');
            $request->session()->flash('success', \Config::get('constants.add_content'));
            return redirect('/admin/content-list');
        } else {
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response()->json(array('error' => false));
        }
    }

    public function editContent($id) {
        $contentData = Content::where(['id' => $id])->first();
        if (!empty($contentData)) {
            return view('admin::content.edit_content', ['contentData' => $contentData]);
        } else {
            abort(404);
        }
    }

    public function updateContent(CreateContentRequest $request) {
        $post = $request->all();
        $result = Content::updateContents($post);
        if ($result) {
            $request->session()->flash('success', 'Content');
            $request->session()->flash('success', \Config::get('constants.update_content'));
            return redirect('/admin/content-list');
        } else {
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response()->json(array('error' => false));
        }
    }

}
