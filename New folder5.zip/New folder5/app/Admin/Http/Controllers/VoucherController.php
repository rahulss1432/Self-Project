<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Admin\Http\Controllers\Controller;
use App\Models\Voucher;
use App\Admin\Http\Requests\CreateVoucherRequest;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class VoucherController extends Controller {

    public function index() {
        return view('admin::voucher.voucher_index');
    }

    public function addVoucher() {
        $getAllVendors = \App\Models\User::where('user_type', 'vendor')->get();
        return view('admin::voucher.add_voucher', ['getAllVendors' => $getAllVendors]);
    }

    public function loadVoucherList(Request $request) {
        $post = $request->all();
        $voucherData = Voucher::getAllVouchers($post);
        $html = View::make('admin::voucher._load_vouchers_list', ['voucherData' => $voucherData])->render();
        return Response::json(['html' => $html, 'voucherData' => $voucherData]);
    }

    public function saveVoucher(CreateVoucherRequest $request) {
        $post = $request->all();
        $result = Voucher::saveVouchers($post);
        if ($result) {
            $request->session()->flash('success', 'Voucher');
            $request->session()->flash('success', \Config::get('constants.add_voucher'));
            return redirect('/admin/voucher-list');
        } else {
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response()->json(array('error' => false));
        }
    }

    public function deleteVouchers(Request $request) {
        $post = $request->all();
        return Voucher::deleteVouchers($post);
    }

    public function editVoucher($id) {
        $voucherData = Voucher::where(['id' => $id])->first();
        if (!empty($voucherData)) {
            $getAllVendors = \App\Models\User::where('user_type', 'vendor')->get();
            return view('admin::voucher.edit_voucher', ['voucherData' => $voucherData, 'getAllVendors' => $getAllVendors]);
        } else {
            abort(404);
        }
    }

    public function updateVoucher(CreateVoucherRequest $request) {
        $post = $request->all();
        $result = Voucher::updateVouchers($post);
        if ($result) {
            $request->session()->flash('success', 'Voucher');
            $request->session()->flash('success', \Config::get('constants.update_voucher'));
            return redirect('/admin/voucher-list');
        } else {
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response()->json(array('error' => false));
        }
    }

}
