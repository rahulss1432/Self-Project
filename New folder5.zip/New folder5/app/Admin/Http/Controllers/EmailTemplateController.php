<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\TemplateEmail;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\CreateTemplateRequest;
use App\Models\ItemAttribute;
use Illuminate\Support\Facades\File;
use Image;
use App\Models\Attribute;
use App\Admin\Http\Requests\EditItemsRequest;

class EmailTemplateController extends Controller {

    public function index() {
        return view('admin::emailTemplate.index');
    }

    public function createTemplate() {
        return view('admin::emailTemplate.create_template');
    }

    public function saveTemplate(CreateTemplateRequest $request) {
        $post = $request->all();
        $result = TemplateEmail::saveTemplates($post);
        if ($result) {
            $request->session()->flash('success', 'Template');
            $request->session()->flash('success', "Template added successfully.");
            return redirect('/admin/email-templates');
        }
    }

    public function loadTemplateList(Request $request) {
        $post = $request->all();
        $templateData = TemplateEmail::getAllTemplates($post);
        $html = View::make('admin::emailTemplate._load_template_list', ['templateData' => $templateData])->render();
        return Response::json(['html' => $html, 'templateData' => $templateData]);
    }

    public function editTemplate($id) {
        $templateData = TemplateEmail::where(['id' => $id])->first();
        if (!empty($templateData)) {
            return view('admin::emailTemplate.edit_template', ['templateData' => $templateData]);
        } else {
            abort(404);
        }
    }

    public function updateTemplate(CreateTemplateRequest $request) {
        $post = $request->all();
        $result = TemplateEmail::updateTemplate($post);
        if ($result) {
            $request->session()->flash('success', 'Content');
            $request->session()->flash('success', "Template update successfully.");
            return redirect('/admin/email-templates');
        }
    }

    public function DeleteTemplate(Request $request) {
        $post = $request->all();
        $result = TemplateEmail::deleteTemplate($post['id']);
        if ($result) {
            return Response::json(['success' => true, 'message' => 'Template deleted successfully.']);
        } else {
            return Response::json(['success' => false, 'message' => 'something went wrong']);
        }
    }

    public function sendMails() {
        $alltemplates = TemplateEmail::all();
        return view('admin::emailTemplate.sendMails', ['templates' => $alltemplates]);
    }

    public function getTemplates(Request $request) {
        $post = $request->all();
        $templateId = $post['templateId'];
        $templateData = TemplateEmail::where('id', $templateId)->first(['page_description']);
        return Response::json(['html' => $templateData]);
    }

}
