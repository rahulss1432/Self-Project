<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\DeliverCompany;
use App\Models\VehicleCategory;
use App\Models\Driver;
use App\Models\User;
use App\Models\DriverDetail;
use App\Models\Order;
use File;
use Image;
use View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\AddDriverRequest;
use App\Admin\Http\Requests\EditDriverRequest;
use Excel;
use App\Helpers\Helper;

class DriverController extends Controller {

    public function index() {
        $deliverCompanies = DeliverCompany::getAllCompanies();
        if (!empty($deliverCompanies)) {
            return view('admin::driver.driver_list', compact('deliverCompanies'));
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect()->back();
        }
    }

    public function createDriver() {
        $deliverCompanies = DeliverCompany::getAllCompanies();
        $vehicleCategories = VehicleCategory::getAllCategories();
        if (!empty($deliverCompanies)) {
            if (!empty($vehicleCategories)) {
                return view('admin::driver.create_driver', compact('deliverCompanies', 'vehicleCategories'));
            } else {
                session()->flash('error', 'error');
                session()->flash('error', \Config::get('constants.something_wrong'));
                return redirect()->back();
            }
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect()->back();
        }
    }

    public function uploadProfileImage(Request $request) {

        $file = $request->file('profile_picture');
        $userProfileTempPath = public_path() . '/uploads/temp-image';
        if (!is_dir($userProfileTempPath)) {
            File::makeDirectory($userProfileTempPath, $mode = 0777, true, true);
        }
        $fileName = $file->getClientOriginalName();
        $fileExtendedName = time() . $fileName;
        if ($request->file('profile_picture')->move($userProfileTempPath, $fileExtendedName)) {
            return Response::Json(['success' => true, 'filename' => $fileExtendedName]);
        } else {
            return Response::Json(['success' => false, 'message' => \Config::get('constants.failed_upload')]);
        }
    }

    public function uploadLicenseImage(Request $request) {
        $file = $request->file('license_picture');
        $licenseUploadTempPath = public_path() . '/uploads/temp-image';
        if (!is_dir($licenseUploadTempPath)) {
            File::makeDirectory($licenseUploadTempPath, $mode = 0777, true, true);
        }
        $fileName = $file->getClientOriginalName();
        $fileExtendedName = time() . $fileName;
        if ($request->file('license_picture')->move($licenseUploadTempPath, $fileExtendedName)) {
            return Response::Json(['success' => true, 'filename' => $fileExtendedName]);
        } else {
            return Response::Json(['success' => false, 'message' => \Config::get('constants.failed_upload')]);
        }
    }

    public function loadImageCropper(Request $request) {
        $post = $request->all();
        $html = View::make('admin::driver._load_image_cropper', ['imageName' => $post['imageName'], 'imageType' => $post['imageType']])->render();
        return Response::json(['html' => $html]);
    }

    public function uploadCroppedPicture(Request $request) {
        $post = $request->all();
        if ($post['imageType'] == 'license-type-image') {

            $cropImgPath = base_path() . '/public/uploads/license-pictures/';
            if (!is_dir($cropImgPath)) {
                mkdir($cropImgPath, 0777, true);
            }
        } elseif ($post['imageType'] == 'profile-type-image') {

            $cropImgPath = base_path() . '/public/uploads/profile-pictures/';
            if (!is_dir($cropImgPath)) {
                mkdir($cropImgPath, 0777, true);
            }
        }
        $origanlImage = base_path() . '/public/uploads/temp-image/' . $post['imageName'];
        $destinationPath = $cropImgPath . $post['imageName'];
        $img = Image::make($origanlImage);
        $croppedImage = $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']));
        $croppedImage->save($destinationPath);
        unlink($origanlImage);
        return $post['imageName'];
    }

    public function saveDriver(AddDriverRequest $request) {
        $driver = User::createDriver($request->all());
        if ($driver) {
            session()->flash('success', 'success');
            session()->flash('success', \Config::get('constants.add_driver'));
            return redirect('/admin/drivers-list');
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect()->back();
        }
    }

    public function loadDriverList(Request $request) {
        $drivers = User::getAllDrivers($request->all());
        if (!empty($drivers)) {
            $html = View::make('admin::driver._load_driver_list', compact('drivers'))->render();
            return Response::json(['success' => true, 'html' => $html]);
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response::json(['success' => false]);
        }
    }

    public function driverVehicleDetail($id) {
        $driver = User::getDriverDetailById($id);
        if (!empty($driver)) {
            return view('admin::driver.driver_vehicle_detail', compact('driver'));
        } else {
            abort(404);
        }
    }

    public function showEditDriverForm($id) {
        $driver = User::getDriverDetailById($id);
        if (!empty($driver)) {
            $deliverCompanies = DeliverCompany::getAllCompanies();
            $vehicleCategories = VehicleCategory::getAllCategories();
            if (!empty($deliverCompanies)) {
                if (!empty($vehicleCategories)) {
                    return view('admin::driver.create_driver', compact('deliverCompanies', 'vehicleCategories', 'driver'));
                } else {
                    session()->flash('error', 'error');
                    session()->flash('error', \Config::get('constants.something_wrong'));
                    return redirect()->back();
                }
            } else {
                session()->flash('error', 'error');
                session()->flash('error', \Config::get('constants.something_wrong'));
                return redirect()->back();
            }
        } else {
            abort(404);
        }
    }

    public function updateDriver(EditDriverRequest $request) {
        $driver = User::updateDriver($request->all());
        if ($driver) {
            session()->flash('success', 'success');
            session()->flash('success', \Config::get('constants.update_driver'));
            return redirect('/admin/drivers-list');
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect()->back();
        }
    }

    public function downloadDriverCsv() {
        try {
            $post = [];
            $post['call_from'] = 'export_list';
            $post['number_of_order'] = '';
            $drivers = User::getAllDrivers($post);
            $excelDownload = Excel::create('driver_records', function($excel) use ($drivers) {
                        $excel->sheet('Sheet1', function($sheet) use($drivers) {
                            $arr = array();
                            foreach ($drivers as $driverData) {
                                $driverById = User::getDriverDetailById($driverData->id);
                                $deliverCompanyName = empty($driverById->driverDetail->deliver_company_id) ? '-' : $driverById->driverDetail->deliverCompany->name;
                                $fullName = ucfirst($driverData->first_name) . ' ' . ucfirst($driverData->last_name);
                                $status = $driverData->is_active == 1 ? 'Active' : 'Inactive';
                                $orderCount = count($driverData->driverOrder) > 0 ? count($driverData->driverOrder) : '0';
                                $data = array(
                                    $fullName,
                                    $driverData->email,
                                    $driverData->phone_number,
                                    $orderCount,
                                    $deliverCompanyName,
                                    $status,
                                    date_format($driverData->created_at, 'Y-m-d')
                                );
                                array_push($arr, $data);
                            }
                            /**
                             * Fill worksheet from values in array
                             *
                             * @param   array   $source                 Source array
                             * @param   mixed   $nullValue              Value in source array that stands for blank cell
                             * @param   string  $startCell              Insert array starting from this cell address as the top left coordinate
                             * @param   boolean $strictNullComparison   Apply strict comparison when testing for null values in the array
                             * @throws Exception
                             * @return PHPExcel_Worksheet
                             */
                            $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                                'Name', 'Email', 'Phone Number', 'No of order',
                                'Deliver Company Name', 'Status', 'Created Date')
                            );
                        });
                    })->export('csv');                      /* on the url call */
            return redirect()->back();
        } catch (Exception $exc) {
            session()->flash('error', 'error');
            session()->flash('error', $exc->getMessage());
            return redirect()->back();
        }
    }

    public function showDriverTrackingMap() {
        $result = DriverDetail::getAllDriversForTracking();
        return view('admin::driver.driver_tracking_map', ['driverData' => $result]);
    }

    public function driverDetail($id) {
        $driver = User::getDriverDetailById($id);
        if (!empty($driver)) {
            $currentOrder = Order::getCurrentOrderByDriverId($id);
            return view('admin::driver.driver_detail', compact('driver', 'currentOrder'));
        } else {
            abort(404);
        }
    }

}
