<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Admin\Http\Controllers\Controller;
use App\Models\OrderTransaction;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Models\Order;

class TransactionController extends Controller {

    public function index() {
        return view('admin::transaction.transaction_index');
    }

    public function loadTransactionList(Request $request) {
        $post = $request->all();
        $transactionData = OrderTransaction::getAllOrderTransactions($post);
        $html = View::make('admin::transaction._load_transactions_list', ['transactionData' => $transactionData])->render();
        return Response::json(['html' => $html, 'transactionData' => $transactionData]);
    }

    public function transactionDetail($id) {
        $result = Order::getOrderByAdmin($id);
        if (!empty($result)) {
            $transactionData = \App\Models\OrderTransaction::where('order_id', $result->id)->first();
            if (!empty($transactionData)) {
                return view('admin::transaction.transaction_detail', ['orderData' => $result, 'transactionData' => $transactionData]);
            } else {
                return view('admin::transaction.transaction_detail', ['orderData' => $result]);
            }
        } else {
            abort(404);
        }
    }

}
