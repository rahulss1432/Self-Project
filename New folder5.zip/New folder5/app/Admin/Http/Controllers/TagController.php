<?php

namespace App\Admin\Http\Controllers;

use App\Admin\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TagController extends Controller
{
    //
}
