<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Admin\Http\Requests\AddSubadminRequest;
use App\Models\User;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\EditSubadminRequest;

class SubadminController extends Controller {

    public function showSubAdmin() {
        return view('admin::subadmin.index');
    }

    public function createSubAdmin() {
        return view('admin::subadmin.create_subadmin');
    }

    public function listSubadmin(Request $request) {
        $result = User::listSubadmin($request);
        $html = View::make('admin::subadmin._list_subadmin', ['subadmin' => $result])->render();
        return Response::json(['html' => $html]);
    }

    public function saveSubadmin(AddSubadminRequest $request) {
        $result = User::saveSubAdmin($request);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.add_subadmin'));
            return redirect('/admin/sub-admin');
        } else {
            $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('/admin/create-sub-admin');
        }
    }

    public function updateSubadmin(EditSubadminRequest $request) {
        $result = User::updateSubadmin($request);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.update_subadmin'));
            return redirect('/admin/sub-admin');
        } else {
            $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('URL::previous()');
        }
    }

    public function editSubadmin($id) {
        $result = User::editSubadmin($id);
        if (!empty($result)) {
            return view('admin::subadmin.edit_subadmin', ['subAdminData' => $result]);
        } else {
            abort(404);
        }
    }

}
