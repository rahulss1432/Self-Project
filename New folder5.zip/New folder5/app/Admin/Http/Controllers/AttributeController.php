<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Admin\Http\Controllers\Controller;
use App\Models\Attribute;
use App\Admin\Http\Requests\CreateAttributeRequest;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class AttributeController extends Controller {

    public function index() {
        return view('admin::attribute.add_attribute');
    }

    public function attributeList() {
        return view('admin::attribute.attribute_index');
    }

    public function loadAttributeList(Request $request) {
        $post = $request->all();
        $attrData = Attribute::getAllAttributes($post);
        $html = View::make('admin::attribute._load_attributes_list', ['attrData' => $attrData])->render();
        return Response::json(['html' => $html, 'attrData' => $attrData]);
    }

    public function saveAttribute(CreateAttributeRequest $request) {
        $post = $request->all();
        $result = Attribute::saveAttributes($post);
        if ($result) {
            $request->session()->flash('success', 'Attribute');
            $request->session()->flash('success', \Config::get('constants.add_attribute'));
            return redirect('/admin/attribute-list');
        } else {
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response()->json(array('error' => false));
        }
    }

    public function deleteAttributes(Request $request) {
        $post = $request->all();
        return Attribute::deleteAttributes($post);
    }

    public function editAttribute($id) {
        $attrData = Attribute::where(['id' => $id])->first();
        if (!empty($attrData)) {
            return view('admin::attribute.edit_attribute', ['attrData' => $attrData]);
        } else {
            abort(404);
        }
    }

    public function updateAttribute(CreateAttributeRequest $request) {
        $post = $request->all();
        $result = Attribute::updateAttributes($post);
        if ($result) {
            $request->session()->flash('success', 'Attribute');
            $request->session()->flash('success', \Config::get('constants.update_attribute'));
            return redirect('/admin/attribute-list');
        } else {
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response()->json(array('error' => false));
        }
    }

}
