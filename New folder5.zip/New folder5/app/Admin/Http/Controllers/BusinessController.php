<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Admin\Http\Requests\BusinessTypeRequest;
use App\Models\BusinessType;
use App\Admin\Http\Requests\EditBusinessTypeRequest;

class BusinessController extends Controller {

    public function index() {
        return view('admin::businessType.index');
    }

    public function loadBusinessTypeList(Request $request) {
        $post = $request->all();
        $businessData = BusinessType::getAllBusinessType($post);
        $html = View::make('admin::businessType._load_business_type_list', ['businessData' => $businessData])->render();
        return Response::json(['html' => $html]);
    }

    public function addBusinessType() {
        return view('admin::businessType.create_business_type');
    }

    public function actionSaveBusinessType(BusinessTypeRequest $request) {
        $post = $request->all();
        $result = BusinessType::saveBusinessType($post);
        if ($result) {
            $request->session()->flash('success', \Config::get('constants.add_business_type'));
            return redirect('admin/business-type');
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('admin/business-type');
        }
    }

    public function changeBusinessTypeStatus($id) {
        $result = BusinessType::actionChangeBusinessTypeStatus($id);
        if ($result) {
            return Response()->json(array('status' => true, 'success.content' => 'Status', 'message' => \Config::get('constants.add_attribute')));
        } else {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => \Config::get('constants.something_wrong')));
        }
    }

    public function editBusinessType($id) {
        $businessData = BusinessType::where('id', $id)->first();
        if(!empty($businessData)){
        return view('admin::businessType.edit_business_type', ['businessData' => $businessData]);
        }else{
            abort(404);
        }
    }
    
    public function updateBusinessType(EditBusinessTypeRequest $request)
    {
        $post = $request->all();
        $result = BusinessType::updateBusinessType($post);
        if($result){
            $request->session()->flash('success', \Config::get('constants.update_business_type'));
            return redirect('admin/business-type');
        }else{
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('admin/business-type');
        }
    }
    
    public function deleteBusinessType($id)
    {  
        $result = BusinessType::deleteBusinessTypeById($id);
        if($result){
            return Response::json(['success' => true]);
        }else{
            return Response::json(['error' => true]);
        }
    }

}
