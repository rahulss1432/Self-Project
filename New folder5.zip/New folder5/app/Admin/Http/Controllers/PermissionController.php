<?php

namespace App\Admin\Http\Controllers;

use App\Models\UserRole;
use App\Models\RolePrivilege;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Controllers\Controller;

class PermissionController extends Controller {

    public function index() {
        $role = UserRole::where('parent_id', '=', 0)->get();
        return view('admin::permission.permission_index', ['role' => $role]);
    }

    public function privilegesList(Request $request) {
        $list = RolePrivilege::getAllPrivilegesList($request);
        $html = View::make('admin::permission._privileges_list', ['list' => $list])->render();
        return Response::json(['html' => $html]);
    }

    public function updatePrivileges(Request $request) {
        $post = $request->all();
        $update = RolePrivilege::allPrivilegesUpdate($post);
        if ($update) {
            $request->session()->flash('success', \Config::get('constants.update_permission'));
            return redirect('admin/permissions');
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('admin/permissions');
        }
    }

    public function subAdminList(Request $request) {
        $subRole = UserRole::allsubAdmins($request);
        if ($subRole) {
            return Response::json(['html' => $subRole]);
        } else {
            return false;
        }
    }

}
