<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Admin\Http\Requests\AddCategoryRequest;
use App\Models\Category;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\EditCategoryRequest;

class CategoryController extends Controller {

    public function index() {
        return view('admin::category.index');
    }

    public function createCategory() {
        return view('admin::category.create_category');
    }

    public function actionSaveCategory(AddCategoryRequest $request) {
        $post = $request->all();
        $result = Category::saveCategory($post);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.add_category'));
            return Response::json(['success' => true]);
        } else {
            $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return Response::json(['error' => false]);
        }
    }

    public function getAllCategories(Request $request) {
        $post = $request->all();
        $categoryData = Category::getAllCategories($post);
        $html = View::make('admin::category._load_category_list', ['categoryData' => $categoryData])->render();
        return Response::json(['html' => $html]);
    }

    public function deleteCategory($id) {
        $result = Category::deleteCategory($id);
        if($result){
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.delete_category'));
            return Response()->json(array('status' => true));
        } else{
            session()->flash('error', 'false');
            session()->flash('error',\Config::get('constants.something_wrong'));
            return Response()->json(array('error' => false));
        }
    }

    public function editCategory($id) {
        $result = Category::editCategory($id);
        if (!empty($result)) {
            return view('admin::category.edit_category', ['categoryData' => $result]);
        } else {
            abort(404, 'page not found');
        }
    }

    public function updateCategory(EditCategoryRequest $request) {
        $post = $request->all();
        $result = Category::updateCategory($post);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success',  \Config::get('constants.update_category'));
            return Response::json(['success' => true]);
        } else {
            $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return Response::json(['error' => false]);
        }
    }

}
