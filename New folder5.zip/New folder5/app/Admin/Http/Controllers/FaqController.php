<?php

namespace App\Admin\Http\Controllers;

use App\Models\Faq;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Controllers\Controller;
use App\Admin\Http\Requests\CreateFaqRequest;

class FaqController extends Controller {

    public function faqIndex() {
        return view('admin::faq.faq_index');
    }

    public function allFaqsList(Request $request) {
        $faq = Faq::getAllFaqsList($request);
        $html = View::make('admin::faq._faqs_list', ['faq' => $faq])->render();
        return Response::json(['html' => $html]);
    }

    public function creatFaq() {
        return view('admin::faq.create_faq');
    }

    public function saveFaq(CreateFaqRequest $request) {
        $faq = Faq::createFaq($request);
        if ($faq) {
            $request->session()->flash('success', \Config::get('constants.add_faq'));
            return redirect('admin/faqs');
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('admin/faqs');
        }
    }

    public function deleteFaq($id) {
        $model = Faq::where('id', '=', $id)->delete();
        if (!empty($model)) {
            return Response()->json(array('status' => false, 'success.content' => 'Status'));
        } else {
            return Response()->json(array('status' => false, 'success.content' => 'Status'));
        }
    }

    public function viewFaq($id) {
        $view = Faq::where('id', $id)->first();
        if (!empty($view)) {
            return view('admin::faq.view_faq', ['view' => $view]);
        } else {
            abort(404);
        }
    }

    public function editFaq($id) {
        $edit = Faq::where('id', $id)->first();
        if (!empty($edit)) {
            return view('admin::faq.edit_faq', ['edit' => $edit]);
        } else {
            abort(404);
        }
    }

    public function updateFaq(CreateFaqRequest $request) {
        $update = Faq::faqUpdate($request);
        if ($update) {
            $request->session()->flash('success', \Config::get('constants.update_faq'));
            return redirect('admin/faqs');
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('admin/faqs');
        }
    }
}