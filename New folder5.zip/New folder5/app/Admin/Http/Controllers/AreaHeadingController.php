<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AreaHeading;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Admin\Http\Requests\AddAreaHeadingRequest;
use App\Admin\Http\Requests\UpdateHeadingRequest;

class AreaHeadingController extends Controller {

    public function viewAreaHeading() {
        return view('admin::settings.view_area_heading');
    }

    public function createHeading() {
        return view('admin::settings.create_area_heading');
    }

    public function loadAreaHeading(Request $request) {
        $post = $request->all();
        $headingData = AreaHeading::getAllHeadings($post);
        $html = View::make('admin::settings._load_heading_list', ['headingData' => $headingData])->render();
        return Response::json(['html' => $html]);
    }
    
    public function editHeading($id) {
        $headingData = AreaHeading::where('id', $id)->first();
        if(!empty($headingData)){
        return view('admin::settings.edit_heading', ['headingData' => $headingData]);
        }else{
            abort(404);
        }
    }

    public function saveAreaHeading(AddAreaHeadingRequest $request) {
        $post = $request->all();
        $result = AreaHeading::saveHeading($post);
        if ($result) {
            $request->session()->flash('success', \Config::get('constants.add_heading'));
            return redirect('admin/view-area-heading');
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('admin/view-area-heading');
        }
    }
    
    public function updateHeading(UpdateHeadingRequest $request)
    {
        $post = $request->all();
        $result = AreaHeading::updateHeading($post);
        if ($result) {
            $request->session()->flash('success', \Config::get('constants.update_heading'));
            return Response::json(['success' => true]);
        }
        return Response::json(['success' => false]);
    }
    
    public function deleteHeading($id)
    {  
        $result = AreaHeading::deleteHeadingById($id);
        if($result){
            return Response::json(['success' => true]);
        }else{
            return Response::json(['error' => true]);
        }
    }

}
