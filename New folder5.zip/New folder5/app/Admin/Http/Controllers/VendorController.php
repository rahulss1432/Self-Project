<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Admin\Http\Requests\CreateVendorRequest;
use App\Admin\Http\Requests\EditVendorRequest;
use Excel;
use App\Admin\Http\Requests\VendorChangePasswordRequest;
use File;
use Image;
use App\Models\Order;

class VendorController extends Controller {

    public function index() {
        return view('admin::vendor1.index');
    }

    public function loadVendorList(Request $request) {
        $post = $request->all();
        $vendorData = User::getVendorData($post);
        $html = View::make('admin::vendor1._load_vendor_list', ['vendorData' => $vendorData])->render();
        return Response::json(['html' => $html]);
    }

    public function createVendor() {
        return view('admin::vendor1.create_vendor');
    }

    public function actionSaveVendor(CreateVendorRequest $request) {
        $post = $request->all();
        $vendor = User::createVendor($post, $request);
        if ($vendor) {
            $request->session()->flash('success', \Config::get('constants.add_vendor'));
            return redirect('admin/vendor-list');
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('admin/create-vendor');
        }
    }

    public function vendorChangeStatus($id) {
        $result = User::updateStatus($id);
        if ($result) {
            return Response()->json(array('status' => TRUE));
        } else {
            return Response()->json(array('status' => false));
        }
    }

    public function deleteVendors(Request $request) {
        $post = $request->all();
        return User::deleteVendors($post);
    }

    public function editVendor($id) {
        $editVendorData = User::editSingalVendorData($id);
        if (!empty($editVendorData)) {
            return view('admin::vendor1.edit_vendor', ['editVendorData' => $editVendorData]);
        } else {
            abort(404);
        }
    }

    public function updateVendor(EditVendorRequest $request) {
        $post = $request->all();
        $result = User::updateVendors($post, $request);
        if ($result) {
            $request->session()->flash('success', \Config::get('constants.update_vendor'));
            return redirect('admin/vendor-list');
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
        }
    }

    public function downloadVendorCsv() {
        $post = [];
        $post['call_from'] = 'export_list';
        $vendors = User::getVendorData($post);
        $excelDownload = Excel::create('vendor_records', function($excel) use ($vendors) {
                    $excel->sheet('Sheet1', function($sheet) use($vendors) {
                        $arr = array();
                        $status = "";
                        $noOfOrder = "";
                        foreach ($vendors as $vendorData) {
                            $businessName = $vendorData->business_name;
                            $businessType = \App\Helpers\Helper::getBusinesstypeNameById($vendorData->business_type);
                            if (!empty($businessType)) {
                                $businessType = $businessType;
                            } else {
                                $businessType = "-";
                            }
                            if ($vendorData->is_active == "1") {
                                $status = "Active";
                            } else {
                                $status = "Inactive";
                            }
                            $allComplete = count($vendorData->vendorOrder);
                            if (!empty($allComplete) != 0) {
                                $noOfOrder = $allComplete;
                            } else {
                                $noOfOrder = "-";
                            }
                            $data = array(
                                $businessName,
                                $businessType,
                                $vendorData->first_name,
                                $vendorData->last_name,
                                $vendorData->email,
                                $vendorData->phone_number,
                                $vendorData->address,
                                $noOfOrder,
                                $status,
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Business Name', 'Vendor Type', 'First Name', 'Last Name', 'Email', 'Phone Number',
                            'Address', 'No of order', 'Status')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.export_vendor'));
            return redirect()->back();
        }
    }

    public function vendorDetails($id) {
        $vendorDetails = User::getVendorDetailById($id);
        if (!empty($vendorDetails)) {
            return view('admin::vendor1.vendor_details', ['vendorDetails' => $vendorDetails]);
        } else {
            abort(404);
        }
    }

    public function changeVendorPassword($id) {
        $vendorDetails = User::getVendorDetailById($id);
        if (!empty($vendorDetails)) {
            return view('admin::vendor1.change_vendor_password', ['vendorDetails' => $vendorDetails]);
        } else {
            abort(404);
        }
    }

    public function updatePassword(VendorChangePasswordRequest $request) {
        $post = $request->all();
        $result = User::changeVendorPasswordById($post);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.change_password'));
            return redirect('/admin/vendor-list');
        } else {
            $request->session()->flash('error', 'Error');
            return Response::json(['success' => true]);
        }
        return redirect('/admin/vendor-list');
    }

    public function saveCropperImage(Request $request) {
        $post = $request->all();
        $image = $post['imageBaseCode'];
        if (!empty($image)) {
            $image_parts = explode(";base64,", $image);
            $image_type_aux = explode("image/", $image_parts[0]);
            $image_type = $image_type_aux[1];
            $image_base64 = base64_decode($image_parts[1]);
            $destinationPath = public_path() . '/uploads/store/';
            $tempPath = public_path() . '/uploads/temp/';
            $file = time() . '.jpg';
            if (!\File::exists($destinationPath)) {
                \File::makeDirectory($destinationPath, 0755, true);
            }
            if (!\File::exists($tempPath)) {
                \File::makeDirectory($tempPath, 0755, true);
            }
            file_put_contents($destinationPath . '/' . $file, $image_base64);
            $img = Image::make("public/uploads/store/" . $file);
            $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']))->save($tempPath . $file);
            return Response::json(array('success' => true, 'filename' => $file));
        }
    }

    public function singleOrderList($id) {
        return view('admin::vendor1.order_index', ['id' => $id]);
    }

    public function listSingleUserOder(Request $request) {
        $orderData = Order::getOrderByVendor($request);
        $html = View::make('admin::vendor1._list_order_management', ['orderData' => $orderData])->render();
        return Response::json(['html' => $html]);
    }

}
