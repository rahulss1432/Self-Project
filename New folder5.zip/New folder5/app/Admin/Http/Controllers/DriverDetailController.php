<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\DeliverCompany;
use App\Models\VehicleCategory;
use App\Models\Driver;
use File;
use Image;
use View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\AddDriverRequest;

class DriverDetailController extends Controller {

    public function index() {
        return view('admin::driver.driver-list');
    }

    public function createDriver() {
        $deliverCompanies = DeliverCompany::getAllCompanies();
        $vehicleCategories = VehicleCategory::getAllCategories();
        if (!empty($deliverCompanies)) {
            if (!empty($vehicleCategories)) {
                return view('admin::driver.create-driver', compact('deliverCompanies', 'vehicleCategories'));
            } else {
                session()->flash('error', 'error');
                session()->flash('error', \Config::get('constants.failed_categories'));
                return redirect()->back();
            }
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.failed_companies'));
            return redirect()->back();
        }
    }

    /*
      public function saveCropperImage(Request $request) {
      $post = $request->all();
      //$data = base64_decode($post['imageBaseCode']); // base64 decoded image data
      $image = $post['imageBaseCode'];
      if (!empty($image)) {
      $image_parts = explode(";base64,", $image);
      $image_type_aux = explode("image/", $image_parts[0]);
      $image_type = $image_type_aux[1];
      $image_base64 = base64_decode($image_parts[1]);
      $destinationPath = public_path() . '/uploads/user/';
      $file = time() . '.jpg';
      if (!\File::exists($destinationPath)) {
      \File::makeDirectory($destinationPath, 0755, true);
      }

      $tempPath = public_path() . '/uploads/temp/';
      if (!\File::exists($tempPath)) {
      \File::makeDirectory($tempPath, 0755, true);
      }

      file_put_contents($destinationPath . '/' . $file, $image_base64);
      $img = Image::make("public/uploads/user/" . $file);
      $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']))->save($tempPath. $file);
      return Response::json(array('success' => true, 'filename' => $file));
      }
      }
     */

    public function uploadProfileImage(Request $request) {

        $file = $request->file('profile_picture');
        $userProfileTempPath = public_path() . '/uploads/temp-image';
        if (!is_dir($userProfileTempPath)) {
            File::makeDirectory($userProfileTempPath, $mode = 0777, true, true);
        }
        $fileName = $file->getClientOriginalName();
        $fileExtendedName = time() . $fileName;
        $request->file('profile_picture')->move($userProfileTempPath, $fileExtendedName);
        return Response::Json(['filename' => $fileExtendedName]);
    }

    public function uploadLicenseImage(Request $request) {
        $file = $request->file('license_picture');
        $licenseUploadTempPath = public_path() . '/uploads/temp-image';
        if (!is_dir($licenseUploadTempPath)) {
            File::makeDirectory($licenseUploadTempPath, $mode = 0777, true, true);
        }
        $fileName = $file->getClientOriginalName();
        $fileExtendedName = time() . $fileName;
        $request->file('license_picture')->move($licenseUploadTempPath, $fileExtendedName);
        return Response::Json(['filename' => $fileExtendedName]);
    }

    public function loadImageCropper(Request $request) {
        $post = $request->all();
        $html = View::make('admin::driver._load-image-cropper', ['imageName' => $post['imageName'], 'imageType' => $post['imageType']])->render();
        return Response::json(['html' => $html]);
    }

    public function uploadCroppedPicture(Request $request) {
        $post = $request->all();
        if ($post['imageType'] == 'license-type-image') {
            $cropImgPath = base_path() . '/public/uploads/license-pictures/';
            if (!is_dir($cropImgPath)) {
                mkdir($cropImgPath, 0777, true);
            }
        } elseif ($post['imageType'] == 'profile-type-image') {
            $cropImgPath = base_path() . '/public/uploads/profile-pictures/';
            if (!is_dir($cropImgPath)) {
                mkdir($cropImgPath, 0777, true);
            }
        }
        $origanlImage = base_path() . '/public/uploads/temp-image/' . $post['imageName'];
        $destinationPath = $cropImgPath . $post['imageName'];
        $img = Image::make($origanlImage);
        $croppedImage = $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']));
        $croppedImage->save($destinationPath);
        unlink($origanlImage);
        return $post['imageName'];
    }

    public function saveDriver(AddDriverRequest $request) {
        $driver = Driver::saveDriver($request->all());
        if ($driver) {
            session()->flash('success', 'success');
            session()->flash('success',  \Config::get('constants.add_driver'));
            return redirect('/admin/drivers-list');
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect()->back();
        }
    }

    public function loadDriverList() {
        $drivers = Driver::getAllDrivers();
        if (!empty($drivers)) {
            $html = View::make('admin::driver._load_driver_list', compact('drivers'))->render();
            return Response::json(['success' => true, 'html' => $html]);
        } else {
            session()->flash('error', 'error');
            session()->flash('error', "failed to load drivers listing");
            return Response::json(['success' => false]);
        }
    }

    public function changeDriverStatus(Request $request) {
        $status = Driver::changeStatus($request->all());
        if ($status) {
            return Response::json(['success' => true, 'message' => \Config::get('constants.change_status')]);
        } else {
            return Response::json(['success' => false, 'message' => \Config::get('constants.something_wrong')]);
        }
    }

    public function viewDriverVehicleDetails($id) {
        $driver = Driver::getDriverDetailById($id);
        if (!empty($driver)) {
            $html = View::make('admin::driver._load_driver_vehicle', compact('driver'))->render();
            return Response::json(['html' => $html]);
        } else {
            abort(404);
        }
    }
}
