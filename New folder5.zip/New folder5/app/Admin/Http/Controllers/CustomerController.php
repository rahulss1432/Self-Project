<?php

namespace App\Admin\Http\Controllers;

use Excel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Controllers\Controller;
use App\Admin\Http\Requests\EditCustomerRequest;
use App\Admin\Http\Requests\CreateCustomerRequest;

class CustomerController extends Controller {

    public function customerIndex() {
        return view('admin::customer.index');
    }

    public function creatCustomer() {
        return view('admin::customer.create_customer');
    }

    public function saveCustomer(CreateCustomerRequest $request) {
        $customer = User::createCustomer($request);
        if ($customer) {
            $request->session()->flash('success', \Config::get('constants.add_customer'));
            return redirect('admin/customer');
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('admin/create-customer');
        }
    }

    public function allCustomersList(Request $request) {
        $customer = User::customersList($request);
        $html = View::make('admin::customer._customers_list', ['customer' => $customer])->render();
        return Response::json(['html' => $html]);
    }

    public function deleteCustomers(Request $request) {
        $id = $request->all();
        $result = User::deleteVendors($id);
        if ($result) {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => \Config::get('constants.delete_user')));
        } else {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => \Config::get('constants.something_wrong')));
        }
    }

    public static function activeInactive($id) {
        $model = User::where('id', $id)->first();
        if ($model->is_active == '1') {
            $model->is_active = '0';
        } else {
            $model->is_active = '1';
        }
        if ($model->save()) {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => \Config::get('constants.change_status')));
        } else {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => \Config::get('constants.something_wrong')));
        }
    }

    public function viewCustomer($id) {
        $customer = User::where('id', $id)->first();
        if (!empty($customer)) {
            return view('admin::customer.view_customer', ['customer' => $customer]);
        } else {
            abort(404);
        }
    }

    public function editCustomer($id) {
        $edit = User::where('id', $id)->first();
        if (!empty($edit)) {
            return view('admin::customer.edit_customer', ['edit' => $edit]);
        } else {
            abort(404);
        }
    }

    public function customerUpdate(EditCustomerRequest $request) {
        $update = User::updateCustomer($request);
        if ($update) {
            $request->session()->flash('success', \Config::get('constants.update_customer'));
            return redirect('admin/customer');
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('admin/customer');
        }
    }

    public function downloadCustomerCsv() {
        $post = [];
        $post['call_from'] = 'export_list';
        $post['number_of_order'] = '';
        $customers = User::customersList($post);
        try {
            $excelDownload = Excel::create('customer_records', function($excel) use ($customers) {
                        $excel->sheet('Sheet1', function($sheet) use($customers) {
                            $arr = array();
                            foreach ($customers as $customerData) {
                                $driverById = User::getDriverDetailById($customerData->id);
                                $fullName = ucfirst($customerData->first_name) . ' ' . ucfirst($customerData->last_name);
                                $status = $customerData->is_active == 1 ? 'Active' : 'Inactive';
                                $data = array(
                                    $fullName,
                                    $customerData->email,
                                    $customerData->phone_number,
                                    count($customerData->customerOrder),
                                    $status,
                                    date_format($customerData->created_at, 'Y-m-d')
                                );
                                array_push($arr, $data);
                            }
                            /**
                             * Fill worksheet from values in array
                             *
                             * @param   array   $source                 Source array
                             * @param   mixed   $nullValue              Value in source array that stands for blank cell
                             * @param   string  $startCell              Insert array starting from this cell address as the top left coordinate
                             * @param   boolean $strictNullComparison   Apply strict comparison when testing for null values in the array
                             * @throws Exception
                             * @return PHPExcel_Worksheet
                             */
                            $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                                'Name', 'Email', 'Phone Number', 'Order Count',
                                'Status', 'Created Date')
                            );
                            // Set black background
                            $sheet->row(1, function($row) {
                                // call cell manipulation methods
                                $row->setFontWeight('bold');
                            });
                        });
                    })->export('csv');
            return redirect()->back();
        } catch (Exception $exc) {
            session()->flash('error', 'error');
            session()->flash('error', $exc->getMessage());
            return redirect()->back();
        }
    }

}
