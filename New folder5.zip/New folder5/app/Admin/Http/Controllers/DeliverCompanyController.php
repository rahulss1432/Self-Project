<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AreaHeading;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Admin\Http\Requests\AddAreaHeadingRequest;
use App\Admin\Http\Requests\AddDeliverCompanyRequest;
use App\Models\DeliverCompany;
use App\Admin\Http\Requests\EditDeliverCompanyRequest;


class DeliverCompanyController extends Controller {

    public function index() {
        return view('admin::deliverCompany.index');
    }

    public function createDeliverCompany() {
        return view('admin::deliverCompany.create_deliver_company');
    }

    public function loadAreaHeading(Request $request) {
        $post = $request->all();
        $headingData = AreaHeading::getAllHeadings($post);
        $html = View::make('admin::settings._load_heading_list', ['headingData' => $headingData])->render();
        return Response::json(['html' => $html]);
    }
    
    public function editHeading($id) {
        $headingData = AreaHeading::where('id', $id)->first();
        if(!empty($headingData)){
        return view('admin::settings.edit_heading', ['headingData' => $headingData]);
        }else{
            abort(404);
        }
    }

    public function saveAreaHeading(AddAreaHeadingRequest $request) {
        $post = $request->all();
        $result = AreaHeading::saveHeading($post);
        if ($result) {
            $request->session()->flash('success',\Config::get('constants.add_heading'));
            return Response::json(['success' => true]);
        }
        return Response::json(['success' => false]);
    }
    
    public function updateHeading(AddAreaHeadingRequest $request)
    {
        $post = $request->all();
        $result = AreaHeading::updateHeading($post);
        if ($result) {
            $request->session()->flash('success', \Config::get('constants.update_heading'));
            return Response::json(['success' => true]);
        }
        return Response::json(['success' => false]);
    }
    
    public function deleteHeading($id)
    {  
        $result = AreaHeading::deleteHeadingById($id);
        if($result){
            return Response::json(['success' => true]);
        }else{
            return Response::json(['error' => true]);
        }
    }
    
    public function saveDeliverCompany(AddDeliverCompanyRequest $request)
    {  
        $post = $request->all();
        $result = DeliverCompany::saveDeliverCompany($post);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.add_deliver'));
            return Response::json(['success' => true]);
        } else {
            $request->session()->flash('error', 'true');
            $request->session()->flash('error',\Config::get('constants.something_wrong'));
            return Response::json(['error' => false]);
        }
    }
    
    public function getAllDeliverCompanies(Request $request) {
        $post = $request->all();
        $companyData = DeliverCompany::getAllDeliverCompanies($post);
        $html = View::make('admin::deliverCompany._load_deliver_company_list', ['companyData' => $companyData])->render();
        return Response::json(['html' => $html]);
    }
    
    public function deleteDeliverCompany($id) {
        $result = DeliverCompany::deleteDeliverCompany($id);
        if($result){
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.delete_deliver'));
            return Response()->json(array('status' => true));
        } else{
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response()->json(array('error' => false));
        }
    }
    
    public function editDeliverCompany($id) {
        $result = DeliverCompany::editDeliverCompany($id);
        if (!empty($result)) {
            return view('admin::deliverCompany.edit_deliver_company', ['companyData' => $result]);
        } else {
            abort(404, 'page not found');
        }
    }
    
    public function updateDeliverCompany(EditDeliverCompanyRequest $request) {
        $post = $request->all();
        $result = DeliverCompany::updateDeliverCompany($post);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.update_deliver'));
            return Response::json(['success' => true]);
        } else {
            $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return Response::json(['error' => false]);
        }
    }
}
