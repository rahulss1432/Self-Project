<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\DeliveryArea;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Admin\Http\Requests\SavePolygonRequest;


class DeliveryAreaController extends Controller
{
    public function addPolygon(SavePolygonRequest $request) {
        $post = $request->all();
        $result = DeliveryArea::saveDeliveryLocation($post);
        if ($result) {
            $request->session()->flash('success',  \Config::get('constants.add_location'));
            return Response::json(['success' => true]);
        }
        return Response::json(['success' => false]);
    }
    
    public function updatePolygon(SavePolygonRequest $request) {
        $post = $request->all();
        $result = DeliveryArea::updateDeliveryLocation($post);
        if ($result) {
            $request->session()->flash('success',  \Config::get('constants.update_location'));
            return Response::json(['success' => true]);
        }
        return Response::json(['success' => false]);
    }
}
