<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Item;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\AddItemsRequest;
use App\Models\ItemAttribute;
use Illuminate\Support\Facades\File;
use Image;
use App\Models\Attribute;
use App\Admin\Http\Requests\EditItemsRequest;

class ItemController extends Controller {

    public function index() {
        return view('admin::items.index');
    }

    public function getAllItems(Request $request) {
        $post = $request->all();
        $itemData = Item::getAllItems($post);
        $html = View::make('admin::items._load_item_list', ['itemData' => $itemData])->render();
        return Response::json(['html' => $html]);
    }

    public function createitem() {
        return view('admin::items.create_item');
    }

    public function getOptionValue(Request $request) {
        $post = $request->all();
        $attrId = $post['attrId'];
        $OptionValue = \App\Models\OptionValue::where('attr_id', $attrId)->get();
        $html = '';
        if (!empty($OptionValue)) {
            foreach ($OptionValue as $val) {
                $html.="<option value='" . $val->id . "'>" . $val->option_name . "</option>";
            }
        }
        return Response::json(['html' => $html]);
    }

    public function getCategoryByBusiness(Request $request) {
        $businessId = $request->businessId;
        $categories = \App\Models\Category::where('business_id', $businessId)->get();
        $html = '';
        $html .= '<option value="">-- Select Category --</option>';
        if (!empty($categories)) {
            foreach ($categories as $val) {
                $html.="<option value='" . $val->id . "'>" . $val->category_name . "</option>";
            }
        }
        return Response::json(['html' => $html]);
    }

    public function actionSaveItems(AddItemsRequest $request) {
        $post = $request->all();
        $id = Item::addItem($post);
        $result = ItemAttribute::addItemAttribute($id, $post);
        if ($id) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.add_item'));
            return Response::json(['success' => true]);
        } elseif ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.add_item'));
            return Response::json(['success' => true]);
        } else {
            $request->session()->flash('error', 'false');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return Response::json(['error' => false]);
        }
    }

    public function uploadItemImage(Request $request) {
        $file = $request->file('item_image');
        $userProfileTempPath = public_path() . '/uploads/temp-image';
        if (!is_dir($userProfileTempPath)) {
            File::makeDirectory($userProfileTempPath, $mode = 0777, true, true);
        }
        $fileName = $file->getClientOriginalName();
        $fileExtendedName = time() . $fileName;
        if ($request->file('item_image')->move($userProfileTempPath, $fileExtendedName)) {
            return Response::Json(['success' => true, 'filename' => $fileExtendedName]);
        } else {
            return Response::Json(['success' => false, 'message' => \Config::get('constants.failed_upload')]);
        }
    }

    public function loadItemImageCropper(Request $request) {
        $post = $request->all();
        $html = View::make('admin::items._load_item_cropper', ['imageName' => $post['imageName'], 'imageType' => $post['imageType']])->render();
        return Response::json(['html' => $html]);
    }

    public function uploadCroppedItemImage(Request $request) {
        $post = $request->all();
        $cropImgPath = base_path() . '/public/uploads/item-pictures/';
        if (!is_dir($cropImgPath)) {
            mkdir($cropImgPath, 0777, true);
        }

        $origanlImage = base_path() . '/public/uploads/temp-image/' . $post['imageName'];
        $destinationPath = $cropImgPath . $post['imageName'];
        $img = Image::make($origanlImage);
        $croppedImage = $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']));
        $croppedImage->save($destinationPath);
        unlink($origanlImage);
        return $post['imageName'];
    }

    public function deleteItem($id) {
        $result = Item::deleteItem($id);
        if ($result) {
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.delete_item'));
            return Response()->json(array('status' => true));
        } else {
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response()->json(array('status' => false));
        }
    }

    public function changeItemStockStatus($id) {
        $result = Item::ChangeItemStatus($id);
        if ($result) {
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.change_status'));
            return Response()->json(array('status' => true));
        } else {
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response()->json(array('status' => false));
        }
    }

    public function editItem($id) {
        $itemData = Item::where('id', $id)->first();
        $attrItem = ItemAttribute::where('item_id', $id)->get();
        $attributes = Attribute::all();
        if(!empty($itemData) && !empty($attrItem) && $attrItem){
            return view('admin::items.edit_item', ['itemData' => $itemData, 'attrItem' => $attrItem, 'attributes' => $attributes]);
        } else {
            abort(404, 'page not found');
        }
    }

    public function updateItem(EditItemsRequest $request) {
        $post = $request->all();
        $id = Item::updateitem($post);
        $result = ItemAttribute::updateItemAttribute($id, $post);
        if ($id) {
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.update_item'));
            return Response::json(['success' => true]);
        } elseif ($result) {
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.update_item'));
            return Response::json(['success' => true]);
        } else {
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response::json(['error' => false]);
        }
    }

}
