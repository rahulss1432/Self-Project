<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Models\User;
use App\Models\Category;
use App\Models\Item;
use App\Models\Order;
use App\Models\DeliveryArea;
use App\Admin\Http\Requests\CreateOrderRequest;
use App\Models\OrderNotification;

class OrderManagementController extends Controller {

    public function orderIndex() {
        return view('admin::order.order_index');
    }

    public function listOder(Request $request) {
        $orderData = Order::listOrderDeatils($request);
        $html = View::make('admin::order._list_order_management', ['orderData' => $orderData])->render();
        return Response::json(['html' => $html]);
    }

    public function createOder() {
        return view('admin::order.create-order');
    }

    public function saveOrder(CreateOrderRequest $request) {
        $result = Order::saveOrderDetail($request);
        if ($result) {
            return Response()->json(array('status' => true, 'success.content' => 'Status', 'message' => \Config::get('constants.add_order')));
        } else {
            return Response()->json(array('status' => false, 'error.content' => 'Status', 'message' => \Config::get('constants.not_provide_service')));
        }
    }

    public function getVendorLocation(Request $request) {
        $result = User::where('id', '=', $request->vendorId)->first();
        $category = Category::getCategoryDropdownForMultiCat($request->vendorId);
        if ($result) {
            return Response::json(['data' => $result, 'category' => $category]);
        }
        return Response::json(['data' => 'null']);
    }

    public function getCategoryItem(Request $request) {
        $item = Item::getCategoryItemDropdown($request->categoryId);
        return Response::json(['item' => $item]);
    }

    public function getItemDeatails(Request $request) {
        $itemData = Item::getItemDeatail($request->itemId);
        return Response::json(['itemData' => $itemData]);
    }

    public function viewOrder($id) {
        $result = Order::getOrderByAdmin($id);
        if (!empty($result)) {
            $transactionData = \App\Models\OrderTransaction::where('order_id', $result->id)->first();
            if (!empty($transactionData)) {
                return view('admin::order.detail-order', ['orderData' => $result, 'transactionData' => $transactionData]);
            } else {
                return view('admin::order.detail-order', ['orderData' => $result]);
            }
        } else {
            abort(404);
        }
    }

//     public function getPolyGonLatLong() {
//         $result = DeliveryArea::getPolyGonLatLong();
//         return Response::json(['itemData' => $result]);
//    }
    public function checkDeliveryArea(Request $request) {
        $result = Order::checkServiceArea($request);
        if (!empty($result)) {

            return Response::json(['success' => true]);
        }
        return Response::json(['error' => false]);
    }

    public function assignDriver($id) {

        $drivers = User::assignDriver();
        if (!empty($drivers)) {
            return view('admin::order.assign_driver', ['drivers' => $drivers, 'orderid' => $id]);
        } else {
            abort(404);
        }
    }

    public function assignDriverOnorder($orderid, $driverid) {
        $result = Order::assignDriverOnorder($orderid, $driverid);
        if ($result) {
            $notification = OrderNotification::sendOrderNotificationById($orderid, $driverid);
            if ($notification) {
                $driversNotification = OrderNotification::deleteSentNotificationToDriver($orderid, $driverid);
                session()->flash('success', 'true');
                session()->flash('success', \Config::get('constants.assign_driver'));
                return redirect('admin/order-management');
            } else {
                session()->flash('error', 'true');
                session()->flash('error', \Config::get('constants.something_wrong'));
                return redirect()->back();
            }
        } else {
            session()->flash('error', 'true');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect()->back();
        }
    }

}
