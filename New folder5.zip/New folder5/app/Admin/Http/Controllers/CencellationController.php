<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\CencellationReason;
use File;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\UpdateCencellationReasonRequest;

class CencellationController extends Controller {

    public function loadCencellationReasons() {
        $reasons = CencellationReason::getAllReasons();
        if (!empty($reasons)) {
            $html = View::make('admin::settings._load_cencellation_reasons', ['reasons' => $reasons])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } else {
            abort(404);
        }
    }

    public function createCancellation() {
        return view('admin::settings.create_cencellation_reasons');
    }

    public function saveCancellationReason(Request $request) {
        $post = $request->all();
        $result = CencellationReason::saveCancellationReasons($post);
        if ($result) {
            $request->session()->flash('success', \Config::get('constants.add_reason'));
            return redirect('admin/settings');
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('admin/settings');
        }
    }

    public function deleteCancellationReason($id) {
        $result = CencellationReason::deleteCancellationReasonById($id);
        if ($result) {
            return Response::json(['success' => true]);
        } else {
            return Response::json(['error' => false]);
        }
    }
    
     public function editCancellationReason($id) {
        $reason = CencellationReason::where('id', $id)->first();
        if(!empty($reason)){
        return view('admin::settings.edit_cencellation_reasons', ['reason' => $reason]);
        }else{
            abort(404);
        }
    }
    
    public function updateCancellationReason(UpdateCencellationReasonRequest $request)
    {
        $post = $request->all();
        $result = CencellationReason::updateCancellationReason($post);
        if ($result) {
            $request->session()->flash('success', \Config::get('constants.update_reason'));
            return Response::json(['success' => true]);
        }
        return Response::json(['success' => false]);
    }
    

}
