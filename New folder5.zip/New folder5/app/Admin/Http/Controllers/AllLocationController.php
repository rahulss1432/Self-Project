<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DeliveryArea;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Admin\Http\Requests\AddAreaHeadingRequest;

class AllLocationController extends Controller {

    public function viewAllLocation() {
        return view('admin::settings.view_all_location');
    }

    public function loadAllLocation(Request $request) {
        $post = $request->all();
        $locationData = DeliveryArea::getAllLocations($post);
        $html = View::make('admin::settings._load_locations_list', ['locationData' => $locationData])->render();
        return Response::json(['html' => $html]);
    }

    public function loadEditLocation(Request $request) {
        $post = $request->all();
        $id = $post['id'];
        $locationData = DeliveryArea::where(['id' => $id])->first();
        $html = View::make('admin::settings._load_edit_location', ['locationData' => $locationData])->render();
        return Response::json(['html' => $html]);
    }

    public function deleteLocation($id) {
        $result = DeliveryArea::deleteLocationById($id);
        if ($result) {
            return Response::json(['success' => true]);
        } else {
            return Response::json(['error' => true]);
        }
    }

}
