<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\OrderNotification;
use App\Models\Order;
use App\Models\Setting;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\ChangePasswordRequest;
use App\Admin\Http\Requests\EditAdminRequest;
use Image;
use Illuminate\Support\Facades\Auth;
use View;
use Excel;

class DashboardController extends Controller {

    public function index() {
        $runningOrderData = Order::runningOrderDetails();
        $newOrderData = Order::newOrderDetails();
        return view('admin::dashboard.dashboard', ['runningOrderData' => $runningOrderData, 'newOrderData' => $newOrderData]);
    }

    public function getOrderGraph(Request $request) {
        $post = $request->all();
        $ordersdetails = Order::getadminOrderDetails($post);
        $html = View::make('admin::dashboard._load_order_graph', ['ordersdetails' => $ordersdetails])->render();
        return Response::json(['html' => $html]);
    }

    public function downloadEarningCsv(Request $request) {
        $earnings = Order::getadminOrderDetails($request->all());

        $excelDownload = Excel::create('earning_records', function($excel) use ($earnings) {
                    $excel->sheet('Sheet1', function($sheet) use($earnings) {
                        $arr = array();
                        foreach ($earnings as $earningData) {
                            $data = array(
                                $earningData->created_at,
                                $earningData->count_order,
                                $earningData->amount,
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            ' Order Date', 'No of order', 'Earn')
                        );
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.export_vendor'));
            return redirect()->back();
        }
    }

    public function updateStatus($id) {
        $status = User::updateStatus($id);
        if ($status) {
            return Response::json(['success' => true, 'message' => \Config::get('constants.change_status')]);
        } else {
            return Response::json(['success' => false, 'message' => \Config::get('constants.something_wrong')]);
        }
    }

    public function deleteUsers($id) {
        $result = User::deleteUser($id);
        if ($result) {
            return Response::json(['success' => true, 'message' => \Config::get('constants.delete_user')]);
        } else {
            return Response::json(['success' => false, 'message' => \Config::get('constants.something_wrong')]);
        }
    }

    public function changePasswordForm() {

        return view('admin::dashboard.change-password');
    }

    public function viewMyProfile() {
        $result = User::getUserProfile();
        return view('admin::dashboard.view_profile', ['userData' => $result]);
    }

    public function editProfile($id) {
        $result = User::editProfile($id);
        if (!empty($result)) {
            return view('admin::dashboard.edit_profile', ['userData' => $result]);
        } else {
            abort(404);
        }
    }

    public function saveChangePassword(ChangePasswordRequest $request) {
        $post = $request->all();
        $result = User::changeAdminPassword($post);
        if ($result) {
            \Session::flash('success', 'success');
            \Session::flash('success', \Config::get('constants.change_password'));
            return redirect('admin/change-password');
        }
        \Session::flash('error', 'error');
        \Session::flash('error', \Config::get('constants.something_wrong'));
        return redirect()->back();
    }

    public function updateAdminProfile(EditAdminRequest $request) {
        $post = $request->all();
        $result = User::updateAdminProfile($post);
        if ($result) {
            \Session::flash('success', 'success');
            \Session::flash('success', \Config::get('constants.update_profile'));
            return redirect('admin/my-profile');
        }
        \Session::flash('error', 'error');
        \Session::flash('error', \Config::get('constants.something_wrong'));
        return redirect()->back();
    }

    public function saveCroppedImage(Request $request) {
        $post = $request->all();
        //$data = base64_decode($post['imageBaseCode']); // base64 decoded image data
        $image = $post['imageBaseCode'];
        if (!empty($image)) {
            $image_parts = explode(";base64,", $image);
            $image_type_aux = explode("image/", $image_parts[0]);
            $image_type = $image_type_aux[1];
            $image_base64 = base64_decode($image_parts[1]);
            $destinationPath = public_path() . '/uploads/temp/';
            $file = time() . '.jpg';


            if (!\File::exists($destinationPath)) {
                \File::makeDirectory($destinationPath, 0755, true);
            }
            file_put_contents($destinationPath . '/' . $file, $image_base64);
            $img = Image::make("public/uploads/temp/" . $file);
            $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']))->save("public/uploads/temp/" . $file);
            return Response::json(array('success' => true, 'filename' => $file));
        }
    }

    /* notification on all nofication page */

    public function loadAllNotifications(Request $request) {
        $post = $request->all();
        $toId = Auth::guard('admin')->user()->id;
        $notifications = OrderNotification::getAllNotificationsById($toId);
        if (!empty($notifications)) {
            if ($post['call_from'] == 'notification_count') {
                return Response::json(['success' => true, 'count' => count($notifications)]);
            } else {
                $html = View::make('admin::notifications._load_all_notification_list', compact('notifications', 'post'))->render();
                return Response::json(['success' => true, 'html' => $html]);
            }
        } else {
            return Response::json(['success' => false, 'message' => 'failed to load']);
        }
    }

    public function orderNotifications() {
        $status = OrderNotification::changeNotificationStatus();
        return view('admin::notifications.all-notifications');
    }

    public function checkOrderStatus() {
//        date_default_timezone_set('Asia/Kolkata');    /*  for current time zone */
        $timeInSeconds = 0;
        $orders = Order::getAllPendingOrders();
        $setting = Setting::getActiveSettingByKey('time_of_acceptance_of_driver');
        if (!empty($orders)) {
            if (!empty($setting)) {
                if ($setting->unit == 'second') {
                    $timeInSeconds = $setting->value;
                }
                if ($setting->unit == 'minute') {
                    $timeInSeconds = $setting->value * 60;
                }
                if ($setting->unit == 'hour') {
                    $timeInSeconds = $setting->value * 60 * 60;
                }
                foreach ($orders as $data) {
                    $currentTime = time();
                    $orderCreateTime = strtotime(date($data->created_at));
                    if (($currentTime - $orderCreateTime) > $timeInSeconds) {
                        $orderNotification = OrderNotification::sendNotificationToAdmin($data);
                        if ($orderNotification) {
                            continue;
                        } else {
                            return Response::json(['success' => false, 'message' => \Config::get('constants.failed_to_send_notification')]);
                        }
                    }
                }
                return Response::json(['success' => true, 'message' => \Config::get('constants.save_notification')]);
            }
        } else {
            return Response::json(['success' => false, 'message' => \Config::get('constants.failed_to_load_order')]);
        }
    }

    public function deleteNotification($id) {
        $notification = OrderNotification::deleteNotification($id);
        if ($notification) {
            return Response::json(['success' => true, 'message' => \Config::get('constants.delete_notification')]);
        } else {
            return Response::json(['success' => false, 'message' => \Config::get('constants.something_wrong')]);
        }
    }

    public function notificationStatusToDelete($id) {
        $status = OrderNotification::changeStatus($id, 'deleted');
        if ($status) {
            return Response::json(['success' => true, 'message' => \Config::get('constants.delete_notification')]);
        } else {
            return Response::json(['success' => false, 'message' => \Config::get('constants.something_wrong')]);
        }
    }

}
