<?php
namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Admin\Http\Requests\SavePolygonRequest;
use App\Models\Setting;
use App\Admin\Http\Requests\UpdateSettingRequest;

class SettingController extends Controller
{
    public function index() {
        return view('admin::settings.index');
    }
    
    public function loadSettingList() {
        $settingData = Setting::getActiveSettingdata();
        if (!empty($settingData)) {
            $html = View::make('admin::settings._load_setting_list', ['settingData' => $settingData])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } else {
            abort(404);
        }
    }
    
    public function editSettingData($id) {
        $settingData = Setting::where(['id' => $id])->first();
        if (!empty($settingData)) {
            return view('admin::settings.edit_settings', ['settingData' => $settingData]);
        } else {
            abort(404);
        }
    }
    
    public function updateSettingData(UpdateSettingRequest $request)
    {
        $post = $request->all();
        $result = Setting::updateSetting($post);
        if ($result) {
            $request->session()->flash('success', \Config::get('constants.update_setting'));
            return Response::json(['success' => true]);
        }
        return Response::json(['success' => false]);
    }
    
   
    
    
    

}