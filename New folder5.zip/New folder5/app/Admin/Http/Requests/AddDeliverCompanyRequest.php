<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Common\Models\Inquiry;

class AddDeliverCompanyRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'name' => 'required|string|max:50|remove_spaces|unique:deliver_companies,name',
            'contact_name' => 'required|string|max:20|remove_spaces',
            'contact_mobile' => 'required|string|remove_spaces|phone_format',
            'contact_email' => 'required||max:50|check_email_format|unique:deliver_companies,contact_email',
            'commission' => 'required|numeric|remove_spaces|valid_commission',
//            'commission_type' => 'required|string',
           
        ];
    }

    public function messages() {
        return [
            'name.remove_spaces' =>'Space is not allowed',
            'contact_name.remove_spaces' =>'Space is not allowed',
            'contact_mobile.remove_spaces' =>'Space is not allowed',
            'contact_mobile.phone_format' =>'Please enter valid phone number',
            'contact_email.check_email_format' => 'The email must be a valid email address',
            'commission.remove_spaces' =>'Space is not allowed',
//            'commission.valid_percent' => 'The commission percentage should not be greater then 100%.',
            'contact_email.required' =>'The contact person email field is required.',
            'contact_mobile.required' =>'The contact person mobile field is required.',
            'contact_name.required' =>'The contact person name field is required.',
            'commission.valid_commission' =>'The commission amount should be greater than 0.',
        ];
    }
    
}
