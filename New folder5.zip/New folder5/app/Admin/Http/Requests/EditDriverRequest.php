<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EditDriverRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        if (empty($this->deliver_company)) {
            return [
                'first_name' => 'required|string|max:20|remove_spaces',
                'last_name' => 'required|string|max:20|remove_spaces',
                'email' => 'required|email|max:50|check_matched_email|check_email_format',
                'phone_number' => 'required|numeric|min:10|phone_format',
                'address' => 'required|remove_spaces',
                'vehicle_type' => 'required',
                'license_number' => 'required|max:10|remove_spaces',
                'vehicle_number' => 'required|max:10|remove_spaces',
                'vehicle_description' => 'required|remove_spaces',
                "commission" => "required|numeric|price_format|remove_spaces|valid_commission",
            ];
        } else {
            return [
                'first_name' => 'required|string|remove_spaces',
                'last_name' => 'required|string|remove_spaces',
                'email' => 'required|email|check_matched_email|check_email_format', 
                'phone_number' => 'required|numeric|min:10|phone_format',
                'address' => 'required|remove_spaces',
                'vehicle_type' => 'required',
                'license_number' => 'required|remove_spaces',
                'vehicle_number' => 'required|remove_spaces',
                'vehicle_description' => 'required|remove_spaces',
            ];
        }
    }

    public function messages() {
        return [
            'first_name.remove_spaces' => 'Space is not allowed.',
            'last_name.remove_spaces' => 'Space is not allowed.',
            'email.check_email_format' => 'The email format is not valid.',
            'email.check_matched_email' => 'The email already taken by other user.',
            'license_number.remove_spaces' => 'Space is not allowed.',
            'vehicle_description.remove_spaces' => 'Space is not allowed.',
            'vehicle_number.remove_spaces' => 'Space is not allowed.',
            'commission.remove_spaces' => 'Space is not allowed.',
            'commission.price_format' => 'The price format is not valid.',
            'commission.valid_commission' => 'The commission amount must be greater than 0.',
        ];
    }

}
