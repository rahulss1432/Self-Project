<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EditItemsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'businessId' => 'required',
            'category_id' => 'required',
            'product_name' => 'required|max:20|remove_spaces|edit_validate_product',
            'price' => 'required|remove_spaces|price_format',
            'product_description' => 'required|remove_spaces',
            'stock_status' => 'required',
        ];
    }
    
    public function messages() {
        return [
            'product_name.edit_validate_product' => 'Product  "<b>' . $this->product_name . '</b>" has already been taken.',
            'product_name.remove_spaces' =>'Space is not allowed.',
            'price.remove_spaces' =>'Space is not allowed.',
            'product_description.remove_spaces' =>'Space is not allowed.',
            'price.price_format' => 'Please provide valid price format.',
            'category_id.required' =>'The category field is required.',
            'businessId.required' =>'The business name field is required.',
        ];
    }
}
