<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EditCategoryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'categoryName' => 'required|string|max:20|remove_spaces|edit_validate_category',
            'businessId' => 'required',
            'status' => 'required',
        ];
    }
    
    public function messages() {
        return [
            'categoryName.edit_validate_category' => 'Category  "<b>' . $this->category_name . '</b>" has already been taken.',
            'categoryName.remove_spaces' =>'Space is not allowed',
            'businessId.required' =>'The business name field is required.',
        ];
    }
}
