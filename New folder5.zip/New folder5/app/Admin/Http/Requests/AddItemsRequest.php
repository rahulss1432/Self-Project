<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AddItemsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'item_picture' => 'required',
            'businessId' => 'required',
            'category_id' => 'required',
            'product_name' => 'required|remove_spaces|max:20|validate_product',
            'price' => 'required|remove_spaces|price_format|valid_price',
            'product_description' => 'required|remove_spaces',
            'stock_status' => 'required',
        ];
    }
    
    public function messages() {
        return [
            'product_name.validate_product' => 'Product  "<b>' . $this->product_name . '</b>" has already been taken.',
            'price.price_format' => 'Please provide valid price format.',
            'product_name.remove_spaces' =>'Space is not allowed.',
            'price.remove_spaces' =>'Space is not allowed.',
            'product_description.remove_spaces' =>'Space is not allowed.',
            'category_id.required' =>'The category field is required.',
            'businessId.required' =>'The business name field is required.',
            'price.valid_price' => 'Price should be greater than 0.',
        ];
    }
}
