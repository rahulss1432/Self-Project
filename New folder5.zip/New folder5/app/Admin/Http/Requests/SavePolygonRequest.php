<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Common\Models\Inquiry;

class SavePolygonRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [

            'mapLocation' => 'required|max:20|',
            'price' => 'required|numeric|price_format|valid_price',
            'selHeading' => 'required'
        ];
    }

    public function messages() {
        return [
            'price.price_format' => 'Please provide valid price format.',
            'price.valid_price' => 'Price should be greater than 0.',
        ];
    }

}
