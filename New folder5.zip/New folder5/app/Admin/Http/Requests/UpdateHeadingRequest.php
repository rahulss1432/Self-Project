<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Common\Models\Inquiry;

class UpdateHeadingRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            
            'heading' => 'required|string|remove_spaces|max:20|area_heading_unique',
           
        ];
    }

    public function messages() {
        return [
            'heading.remove_spaces' =>'Space is not allowed',
            'heading.area_heading_unique' =>'The heading has already been taken.',
        ];
    }
    
}
