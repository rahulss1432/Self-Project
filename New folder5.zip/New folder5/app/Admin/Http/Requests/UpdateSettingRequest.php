<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Common\Models\Inquiry;

class UpdateSettingRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            
            'value' => 'required|numeric|admin_commission|check_time',
            'unit' => 'required'
        ];
    }

    public function messages() {
        return [
            'value.admin_commission' => 'The commission percentage is not greater than 100.',
            'value.check_time' => 'It should be less than 60.',
//            'unit.check_commission' => 'The commission percentage is not greater than 100.',
//            //'phone.digits' => 'The phone number must be 10 digits.'
        ];
    }
    
}
