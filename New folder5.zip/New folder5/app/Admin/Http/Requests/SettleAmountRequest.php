<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Common\Models\Inquiry;

class SettleAmountRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [

            'amount' => 'required|numeric|check_amount',
            'settle_remark' => 'required'
        ];
    }

    public function messages() {
        return [
            'amount.check_amount' => 'Amount must be greater than 0.',
        ];
    }

}
