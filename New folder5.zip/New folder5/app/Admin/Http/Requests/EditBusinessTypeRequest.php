<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EditBusinessTypeRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return
                [
                    'business_name' => 'required|string|max:50|remove_spaces',
                    'status' => 'required|string',
        ];
    }

    public function messages() {
        return [

            'business_name.remove_spaces' => 'Space is not allowed',
        ];
    }

}
