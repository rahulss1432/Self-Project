<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EditVendorRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return
                [
                    'business_name' => 'required|max:50|remove_spaces',
                    'first_name' => 'required|max:20|remove_spaces',
                    'last_name' => 'required|max:20|remove_spaces',
                    'phone_number' => 'required|phone_format',
                   // 'email' => 'required|email|unique:users,email,' . $this->vendorId,
                    'start_time' => 'required',
                    'end_time' => 'required',
                    'admin_commission' => 'required|valid_admin_commission|price_format',
                    'business_type' => 'required',
                    'delivery_location' => 'required',
                    'address' => 'required|string|remove_spaces',
                    'vendor_acceptance' => 'required',
        ];
    }

    public function messages() {
        return [
            'business_name.remove_spaces' => 'Space is not allowed.',
            'first_name.remove_spaces' => 'Space is not allowed.',
            'last_name.remove_spaces' => 'Space is not allowed.',
            'phone_number.phone_format' => 'Please enter valid phone number.',
            //'email.check_email_format' => 'The email must be a valid email address..',
            //'email.remove_spaces' => 'Space is not allowed.',
            'address.remove_spaces' => 'Space is not allowed.',
            'admin_commission.price_format' => 'Please provide valid price format.',
            'admin_commission.valid_admin_commission' => 'Commission Amount must be greater than 0.',
           
        ];
    }

}
