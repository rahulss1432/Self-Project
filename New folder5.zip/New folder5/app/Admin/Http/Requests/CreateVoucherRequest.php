<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateVoucherRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return
                [
                    'voucher_description' => 'required|remove_spaces',
                    'voucher_amount' => 'required|price_format|valid_amount',
                    'voucher_type' => 'required',
                    'max_use' => 'required|valid_use',
                    'start_date' => 'required|remove_spaces',
                    'end_date' => 'required|remove_spaces',
                    'voucher_status' => 'required',
                    'vendor_id' => 'required',
        ];
    }

    public function messages() {
        return [
            'voucher_description.remove_spaces' => 'Space is not allowed.',
            'voucher_amount.price_format' => 'Please provide valid price format.',
            'start_date.remove_spaces' => 'Space is not allowed.',
            'end_date.remove_spaces' => 'Space is not allowed.',
            'voucher_amount.valid_amount' => 'Amount should be greater than 0.',
            'max_use.valid_use' => 'Maximum use should be greater than 0.',
        ];
    }

}
