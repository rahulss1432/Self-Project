<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\OrderProduct;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Helpers\Helper;
use Session;
use App\Models\OrderTransaction;
use Illuminate\Support\Facades\Input;

class Order extends Model {

    public function getVendor() {
        return $this->hasOne('App\Models\User', 'id', 'vendor_id');
    }

    public function getCustomer() {
        return $this->hasOne('App\Models\User', 'id', 'customer_id');
    }

    public function getDriver() {
        return $this->hasOne('App\Models\User', 'id', 'driver_id');
    }

    public static function getadminOrderDetails($post) {
        $now = \Carbon\Carbon::now();
        $weekStart = $now->subDays($now->dayOfWeek)->setTime(0, 0);
        $weekStartDay = date('Y-m-d', strtotime($weekStart));
        $currentDate = date('Y-m-d');
        $orderData = Order::select('orders.*', DB::raw("count(DATE(created_at)) as count_order"), DB::raw("sum(total_amount) as amount"));
        if (!empty($post)) {
            $startdate = date("y-m-d", strtotime($post['orderStartDate']));
            $enddate = date("y-m-d", strtotime($post['orderEndDate']));
            if (strtotime($post['orderStartDate']) > 0 && strtotime($post['orderEndDate']) > 0) {
                $orderData = $orderData->whereBetween('created_at', array($startdate . " 00:00:00", $enddate . " 23:59:59"));
            } else {
                if (strtotime($startdate) > 0) {
                    $orderData = $orderData->whereDate('created_at', '=', $startdate);
                } else {
                    $orderData = $orderData->whereBetween(DB::raw("DATE(created_at)"), [$weekStartDay, $currentDate]);
                }
            }
        }
        $orderData = $orderData->groupBy(DB::raw("DATE(created_at)"));
        $orders = $orderData->get();
        return $orders;
    }

    public static function getadminEarningDetails($post) {
        $earningData = OrderTransaction::select('order_transactions.*', DB::raw("count(DATE(created_at)) as count_order"));
//            if (!empty($post)) {
//            $startdate = date("y-m-d", strtotime($post['orderStartDate']));
//            $enddate = date("y-m-d", strtotime($post['orderEndDate']));
//            if (strtotime($post['orderStartDate']) > 0 && strtotime($post['orderEndDate']) > 0) {
//                $orderData = $orderData->whereBetween('created_at', array($startdate . " 00:00:00", $enddate . " 23:59:59"));
//            } else {
//                if (strtotime($startdate) > 0) {
//                    $orderData = $orderData->whereDate('created_at', '=', $startdate);
//                }
//            }
//        }
        $orderData = $orderData->groupBy(DB::raw("DATE(created_at)"));
        $orders = $orderData->get();
        return $orders;
    }

    public static function saveOrderDetail($post) {

        $dropAddress = Helper::getLatLangByAddress($post->drop_address);
        $dropLatLong = explode(',', $dropAddress);
        $latitude = (!empty($dropLatLong) && $dropLatLong[0] != '') ? $dropLatLong[0] : 0;
        $longitude = (!empty($dropLatLong) && $dropLatLong[0] != '') ? $dropLatLong[1] : 0;

        $vendorProfile = DB::table('vendor_details')->where('user_id', $post->vendor_id)->first();
        $vendorLocation = explode(',', $vendorProfile->delivery_location);
        $area = DB::table('delivery_areas')->whereIn('id', $vendorLocation)->get();
        $i = 0;
        foreach ($area as $val) {

            $a = 'SELECT ST_CONTAINS(ST_GEOMFROMTEXT("POLYGON((' . $val->polygon_lat_long . '))"),ST_GEOMFROMTEXT("POINT(' . $latitude . ' ' . $longitude . ')")) as result';
            $getResult = DB::select($a);

            if ($getResult[0]->result == 1) {
                $i++;
                $shipping_fee = $val->shipping_charges;

                if (!empty($post)) {
                    $model = new Order();
                    $model->vendor_id = $post->vendor_id;
                    $model->customer_id = $post->customer_id;
                    $model->picup_address = $post->pickup_address;
                    $model->drop_address = $post->drop_address;
                    $model->payment_mode = $post->payment_mode;
                    $model->order_state = 'pending';
                    $model->shipping_charge = $shipping_fee;
                    $model->save();
                    if (!empty($model)) {
                        $orderId = $model->id;
                        $prodeucDetail = OrderProduct::saveproductDetail($orderId, $post);
                        $processing_fee = DB::table('settings')->where('key', 'processing_fee')->first();
                        if (!empty($processing_fee)) {
                            $processingAmount = OrderProduct::getProcessingAmountByOrderId($orderId, $processing_fee);
                            $itemAmount = OrderProduct::getAmountByOrderId($orderId);
                            $totalAmount = $itemAmount + $processingAmount + $shipping_fee;
                            $saveProcessingAmount = Order::where('id', $orderId)
                                    ->update(['processing_fee' => $processingAmount
                                , 'total_amount' => $totalAmount]);
                        }
                        if ($prodeucDetail) {
                            return true;
                        }
                        return false;
                    }
                    return false;
                }
            }
        }
        return false;
    }

    public static function listOrderDeatils($post) {
        $orderData = Order::select('orders.*');
        if (isset($post['order_id']) && !empty($post['order_id'])) {
            $orderData = $orderData->where('id', '=', $post['order_id']);
        }
        if (isset($post['delivery_address']) && !empty($post['delivery_address'])) {
            $orderData = $orderData->where('drop_address', 'like', '%' . $post['delivery_address'] . '%');
        }
        if (isset($post['payment_mode']) && !empty($post['payment_mode'])) {
            $orderData = $orderData->where('payment_mode', '=', $post['payment_mode']);
        }
        if (isset($post['order_state']) && !empty($post['order_state'])) {
            $orderData = $orderData->where('order_state', '=', $post['order_state']);
        }
        if (isset($post['email']) && !empty($post['email'])) {
            $cus_id = User::select('users.id')->where('email', '=', $post['email'])->first();
            $orderData = $orderData->where('customer_id', '=', $cus_id['id']);
        }
        if (isset($post['mobile']) && !empty($post['mobile'])) {
            $cus_id = User::select('users.id')->where('phone_number', '=', $post['mobile'])->first();
            $orderData = $orderData->where('customer_id', '=', $cus_id['id']);
        }
        if (isset($post['customer_name']) && !empty($post['customer_name'])) {
            $cus_id = User::select('users.id')
                    ->where(DB::raw('TRIM(CONCAT(users.first_name," ",users.last_name))'), 'like', '%' . $post['customer_name'] . '%')
                    ->first();
            $orderData = $orderData->where('customer_id', '=', $cus_id['id']);
        }
        if (isset($post['driver_name']) && !empty($post['driver_name'])) {
            $cus_id = User::select('users.id')
                    ->where(DB::raw('TRIM(CONCAT(users.first_name," ",users.last_name))'), 'like', '%' . $post['driver_name'] . '%')
                    ->first();
            if (!empty($cus_id)) {
                $driverId = $cus_id->id;
            } else {
                $driverId = '';
            }
            $orderData = $orderData->where('driver_id', '=', $driverId);
        }if (isset($post['vendor_id']) && !empty($post['vendor_id'])) {
            $orderData = $orderData->where('vendor_id', '=', $post['vendor_id']);
        }
        $orderData->orderBy('orders.created_at', 'desc');
        $data = $orderData->paginate(10);

        return $data;
//        $orserList = Order::select('orders.*');
//
//        $result = $orserList->orderBy('orders.id', 'desc')->paginate(10);
//        return $result;
    }

    //for vendor side Order Listing
    public static function getOrderByVendor($post) {
        $userId = (!empty($post['vendorId']) ? $post['vendorId'] : '');
        if ($userId) {
            $vendorId = $userId;
        } else {
            $vendorId = Auth::User()->id;
        }
        $orderData = Order::select('orders.*');
        $orderData = $orderData->where('vendor_id', '=', $vendorId);
        if (isset($post['orderId']) && !empty($post['orderId'])) {
            $orderData = $orderData->where('id', '=', $post['orderId']);
        }
        if (isset($post['deliveryAddress']) && !empty($post['deliveryAddress'])) {
            $orderData = $orderData->where('drop_address', 'like', '%' . $post['deliveryAddress'] . '%');
        }
        if (isset($post['paymentMode']) && !empty($post['paymentMode'])) {
            $orderData = $orderData->where('payment_mode', '=', $post['paymentMode']);
        }
        if (isset($post['orderState']) && !empty($post['orderState'])) {
            $orderData = $orderData->where('order_state', '=', $post['orderState']);
        }
        if (isset($post['email']) && !empty($post['email'])) {
            $cusId = User::select('users.id')->where('email', '=', $post['email'])->where('user_type', '=', 'customer')->first();
            $orderData = $orderData->where('customer_id', '=', $cusId['id']);
        }
        if (isset($post['mobile']) && !empty($post['mobile'])) {
            $cusId = User::select('users.id')->where('phone_number', '=', $post['mobile'])
                    ->where('user_type', '=', 'customer')
                    ->first();
            $orderData = $orderData->where('customer_id', '=', $cusId['id']);
        }
        if (isset($post['customerName']) && !empty($post['customerName'])) {
            $cusId = User::select('users.*')
                    ->where(DB::raw('TRIM(CONCAT(users.first_name," ",users.last_name))'), 'like', '%' . $post['customerName'] . '%')
                    ->where('user_type', '=', 'customer')
                    ->first();
            $orderData = $orderData->where('customer_id', '=', $cusId['id']);
        }
        if (isset($post['driverName']) && !empty($post['driverName'])) {
            $driverId = User::select('users.*')
                    ->where(DB::raw('TRIM(CONCAT(users.first_name," ",users.last_name))'), 'like', '%' . $post['driverName'] . '%')
                    ->where('user_type', '=', 'driver')
                    ->first();
            if (!empty($driverId)) {
                $driverId = $driverId->id;
            } else {
                $driverId = '';
            }
            $orderData = $orderData->where('driver_id', '=', $driverId);
        }
        if (isset($post['vendor_id']) && !empty($post['vendor_id'])) {
            $orderData = $orderData->where('vendor_id', '=', $post['vendor_id']);
        }
        $orderData->orderBy('orders.created_at', 'desc');
        $data = $orderData->paginate(10);
        return $data;
    }

    // for vendor side Detail order Listing
    public static function getOrderById($id) {
        $userId = Auth::User()->id;
        $userType = Auth::User()->user_type;
        if ($userType == "vendor") {
            return self::where('id', $id)->where('vendor_id', $userId)->first();
        } else if ($userType == "customer") {
            return self::where('id', $id)->where('customer_id', $userId)->first();
        } else {
            return self::where('id', $id)->where('driver_id', $userId)->first();
        }
    }

    // for vendor side Detail order Listing
    public static function getOrderByAdmin($id) {
        return self::where('id', $id)->first();
    }

    // for vendor side assign driver on order 
    public static function assignDriverOnorder($orderid, $driverid) {
        $model = Order::where('id', $orderid)->first();
        $model->driver_id = $driverid;
        $model->order_state = 'running';
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    // for vendor side assign driver on order 
    public static function changeOrderState($post) {
        $model = Order::where('id', $post['id'])->first();
        $model->order_state = $post['status'];
        if ($post['status'] == 'completed') {
            $model->current_location = $model->drop_address;
        }
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    // for vendor side change Order Status 
    public static function changeOrderStatus($orderid) {
        $model = Order::where('id', $orderid)->first();
        $model->order_state = 'pending';
        $customerid = $model->customer_id;
        if ($model->save()) {
            OrderNotification::sendNotificationtodrivers($orderid);
            OrderNotification::sendNotificationtocustomer($orderid, $customerid);
            return true;
        } else {
            return false;
        }
    }

    public static function getOrderDetails($post) {
        $vendor_id = Auth::User()->id;
        $orderData = Order::select('orders.*', DB::raw("count(DATE(created_at)) as count_order"), DB::raw("sum(total_amount) as amount"));
        $orderData = $orderData->where('vendor_id', '=', $vendor_id);
        if (!empty($post)) {
            $startdate = date("y-m-d", strtotime($post['orderStartDate']));
            $enddate = date("y-m-d", strtotime($post['orderEndDate']));
            if (strtotime($post['orderStartDate']) > 0 && strtotime($post['orderEndDate']) > 0) {
                $orderData = $orderData->whereBetween('created_at', array($startdate . " 00:00:00", $enddate . " 23:59:59"));
            } else {
                if (strtotime($startdate) > 0) {
                    $orderData = $orderData->whereDate('created_at', '=', $startdate);
                }
            }
        }
        $orderData = $orderData->groupBy(DB::raw("DATE(created_at)"));
        $orders = $orderData->get();
        return $orders;
    }

    public static function checkServiceArea($post) {
        $dropAddress = Helper::getLatLangByAddress($post->address);
        $dropLatLong = explode(',', $dropAddress);
        $latitude = (!empty($dropLatLong) && $dropLatLong[0] != '') ? $dropLatLong[0] : 0;
        $longitude = (!empty($dropLatLong) && $dropLatLong[0] != '') ? $dropLatLong[1] : 0;

        $vendorProfile = DB::table('vendor_details')->where('user_id', $post->vendorId)->first();
        $vendorLocation = explode(',', $vendorProfile->delivery_location);
        $area = DB::table('delivery_areas')->whereIn('id', $vendorLocation)->get();
        $i = 0;
        foreach ($area as $val) {

            $a = 'SELECT ST_CONTAINS(ST_GEOMFROMTEXT("POLYGON((' . $val->polygon_lat_long . '))"),ST_GEOMFROMTEXT("POINT(' . $latitude . ' ' . $longitude . ')")) as result';
            $getResult = DB::select($a);

            if ($getResult[0]->result == 1) {
                $i++;
                $shipping_fee = $val->shipping_charges;
                return $shipping_fee;
            }
        }
        return false;
    }

    public static function getCurrentOrderByDriverId($driverId) {
        $order = Order::where('order_state', '=', 'running')->where('driver_id', $driverId)->latest()->first();
        return $order;
    }

    public static function placeOrderDetails($post, $transactionType) {
        if (Session::get('voucherDetails') != "") {
            $details = Session::get('voucherDetails');
            $subTotal = $details['sub_total'];
            foreach ($details['cart_items'] as $cartData) {
                $vendorId = $cartData['business_id'];
            }
        } else {
            $details = Session::get('cartDetails');
            $subTotal = $details['sub_total'];
            if (isset($details['total_amount'])) {
                $netAmount = $details['total_amount'];
            }
            foreach ($details['cart_items'] as $cartData) {
                $vendorId = $cartData['business_id'];
            }
        }
        $pickupAddress = User::where('id', '=', $vendorId)->first();
        $vendorData = VendorDetail::where('user_id', '=', $vendorId)->first();
        if ($vendorData) {
            $vendorStatus = $vendorData->vendor_acceptance;
        }
        $order = new Order;
        $order->vendor_id = $vendorId;
        $order->customer_id = $details['customer_id'];
        $order->picup_address = $pickupAddress->address;
        $order->drop_address = $post['delivery_address'];
        $order->current_location = $pickupAddress->address;
        $order->payment_mode = $transactionType;
        if ($vendorStatus == 'yes') {
            $order->order_state = "vendor_pending";
        } else {
            $order->order_state = "pending";
        }
        $order->delivery_note = $post['delivery_note'];
        $order->shipping_charge = $post['shipping_charges'];
        if ($post['processing_fee_unit'] == 'percent') {
            $fees = $subTotal * $post['processing_fee'] / 100;
        } else {
            $fees = $post['processing_fee'];
        }
        $order->processing_fee = $fees;
        $order->total_amount = $post['payment_gross'];
        $save = $order->save();
        if ($save) {
            $orderId = $order->id;
            $post['order_id'] = $orderId;
            $orderProduct = OrderProduct::orderProductDetails($post, $transactionType);
            return true;
        } else {
            return false;
        }
    }

    public static function getCustomerOrderlist($post) {
        $customerId = Auth::User()->id;

        $orderData = Order::select('orders.*');
        $orderData = $orderData->where('customer_id', '=', $customerId);
        if (isset($post['order_id']) && !empty($post['order_id'])) {
            $orderData = $orderData->where('id', '=', $post['order_id']);
        }
        if (isset($post['delivery_address']) && !empty($post['delivery_address'])) {
            $orderData = $orderData->where('drop_address', 'like', '%' . $post['delivery_address'] . '%');
        }
        if (isset($post['payment_mode']) && !empty($post['payment_mode'])) {
            $orderData = $orderData->where('payment_mode', '=', $post['payment_mode']);
        }
        if (isset($post['order_state']) && !empty($post['order_state'])) {
            $orderData = $orderData->where('order_state', '=', $post['order_state']);
        }
        if (isset($post['email']) && !empty($post['email'])) {
            $cus_id = User::select('users.id')->where('email', '=', $post['email'])->where('user_type', '=', 'customer')->first();
            $orderData = $orderData->where('customer_id', '=', $cus_id['id']);
        }
        if (isset($post['mobile']) && !empty($post['mobile'])) {
            $cus_id = User::select('users.id')->where('phone_number', '=', $post['mobile'])
                    ->where('user_type', '=', 'customer')
                    ->first();
            $orderData = $orderData->where('customer_id', '=', $cus_id['id']);
        }
        if (isset($post['customer_name']) && !empty($post['customer_name'])) {
            $cus_id = User::select('users.*')
                    ->where(DB::raw('TRIM(CONCAT(users.first_name," ",users.last_name))'), 'like', '%' . $post['customer_name'] . '%')
                    ->where('user_type', '=', 'customer')
                    ->first();
            $orderData = $orderData->where('customer_id', '=', $cus_id['id']);
        }
        if (isset($post['driver_name']) && !empty($post['driver_name'])) {
            $driver_id = User::select('users.*')
                    ->where(DB::raw('TRIM(CONCAT(users.first_name," ",users.last_name))'), 'like', '%' . $post['driver_name'] . '%')
                    ->where('user_type', '=', 'driver')
                    ->first();
            if (!empty($driver_id)) {
                $driverId = $driver_id->id;
            } else {
                $driverId = '';
            }
            $orderData = $orderData->where('driver_id', '=', $driverId);
        }
        $orderData->orderBy('orders.created_at', 'desc');
        $data = $orderData->paginate(10);
        return $data;
    }

    public static function getAllPendingOrders() {
        $orders = Order::where('order_state', '=', 'pending')->get();
        return $orders;
    }

    public static function runningOrderDetails() {
        $orders = Order::where('order_state', '=', 'running')->get();
        return $orders;
    }

    public static function newOrderDetails() {
        $orders = Order::orderBy('created_at', 'desc')->get();
        return $orders;
    }

    public static function runningOrderDetailsById() {
        $userId = Auth::guard()->user()->id;
        $orders = Order::where('order_state', '=', 'running')->where('vendor_id', $userId)->get();
        return $orders;
    }

    public static function newOrderDetailsById() {
        $orders = Order::orderBy('created_at', 'desc')->get();
        return $orders;
    }

    public static function getAllOrderRating() {
        $userId = Auth::guard()->user()->id;
        $orderRatings = \App\Models\Order::Join('ratings', 'ratings.order_id', 'orders.id')
                ->select('ratings.*', 'orders.*', 'orders.created_at as order_date')
                ->where('orders.driver_id', $userId)
                ->orderBy('orders.created_at', 'desc')
                ->paginate(10);
        if (!empty($orderRatings)) {
            return $orderRatings;
        } else {
            return false;
        }
    }

    public static function getAllUsersListForReport($post) {
        $page = Input::get('page', 1);
        $paginate = 10;
        $query = '';
        if (!empty($post['name']) && $post['name'] != '') {
            $name = $post['name'];
            $query = "CONCAT(first_name,' ',last_name) like '%" . $name . "%' or name like '%" . $name . "%'";
        }

        $data = DB::table('orders')
                ->select('orders.vendor_id as user_id', 'driver_details.deliver_company_id', 'deliver_companies.name as company_name', 'orders.order_state', 'users.first_name', 'users.last_name', 'users.user_type')
                ->leftjoin('users', 'users.id', '=', 'orders.vendor_id')
                ->leftjoin('driver_details', 'users.id', '=', 'driver_details.user_id')
                ->leftjoin('deliver_companies', 'driver_details.deliver_company_id', '=', 'deliver_companies.id')
                ->where('orders.order_state', 'completed');
        if ($query != '') {
            $data->whereRaw($query);
        }
        $data->groupBy('orders.vendor_id');


        $driverData = DB::table('orders')
                ->select('orders.driver_id as user_id', 'driver_details.deliver_company_id', 'deliver_companies.name as company_name', 'orders.order_state', 'users.first_name', 'users.last_name', 'users.user_type')
                ->leftjoin('users', 'users.id', '=', 'orders.driver_id')
                ->leftjoin('driver_details', 'users.id', '=', 'driver_details.user_id')
                ->leftjoin('deliver_companies', 'driver_details.deliver_company_id', '=', 'deliver_companies.id')
                ->where('orders.order_state', 'completed');
        if ($query != '') {
            $driverData->whereRaw($query);
        }
        $driverData->groupBy('orders.driver_id')
                ->union($data);

        $driverData = $driverData->get();




        if (isset($post['user_type']) && !empty($post['user_type'])) {
            if ($post['user_type'] == 'vendor') {
                $driverData = $driverData->where('user_type', '=', $post['user_type']);
            }
            if ($post['user_type'] == 'driver') {
                $driverData = $driverData->where('user_type', '=', $post['user_type'])->where('deliver_company_id', '==', '');
            }
            if ($post['user_type'] == 'delivery_company') {
                $driverData = $driverData->where('deliver_company_id', '!=', '');
            }
        }


        $offSet = ($page * $paginate) - $paginate;
        $itemsForCurrentPage = array_slice($driverData->toArray(), $offSet, $paginate, true);
        $driverData = new \Illuminate\Pagination\LengthAwarePaginator($itemsForCurrentPage, count($driverData), $paginate, $page);
        $driverData->setPath(url('/admin/load-report-list'));
        if (!empty($driverData)) {
            return $driverData;
        } else {
            return false;
        }
    }

    public static function getOrderDetailForReport($id, $slug) {
        if ($slug == "company") {
            $driverList = DriverDetail::where('deliver_company_id', $id)->get();
            $driverIdList = array();
            foreach ($driverList as $list) {
                array_push($driverIdList, $list->user_id);
            }
            $data = DB::table('orders')
                            ->select('orders.*', 'deliver_companies.commission', 'deliver_companies.id as companyId', 'driver_details.user_id')
                            ->rightjoin('driver_details', 'driver_details.user_id', '=', 'orders.driver_id')
                            ->join('deliver_companies', 'driver_details.deliver_company_id', '=', 'deliver_companies.id')
                            ->where('orders.is_settled', 0)
                            ->whereIn('orders.driver_id', $driverIdList)
                            ->where('orders.order_state', 'completed')->get();
        } else {
            $userData = User::where('id', $id)->first();
            if ($userData->user_type == 'driver') {
                $driverDetail = DriverDetail::where('user_id', $id)->first();
            }
            if ($userData->user_type == 'vendor') {
                $data = DB::table('orders')
                                ->select('orders.*', 'vendor_details.admin_commission')
                                ->rightjoin('vendor_details', 'vendor_details.user_id', '=', 'orders.vendor_id')
                                ->where('orders.is_settled', 0)
                                ->where('orders.vendor_id', $id)
                                ->where('orders.order_state', 'completed')->get();
            } else if ($userData->user_type == 'driver' && $driverDetail->deliver_company_id == null) {
                $data = DB::table('orders')
                                ->select('orders.*', 'driver_details.commission')
                                ->rightjoin('driver_details', 'driver_details.user_id', '=', 'orders.driver_id')
                                ->where('orders.is_settled', 0)
                                ->where('orders.driver_id', $id)
                                ->where('orders.order_state', 'completed')->get();
            }
        }
        return $data;
    }

    public static function saveCurrentLocationById($post) {
        $order = Order::where('id', $post['orderId'])->first();
        $order->current_location = $post['currentLocation'];
        if ($order->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function getTotalearningbyId($id) {
        $userType = Auth::guard()->user()->user_type;
        if ($userType == "vendor") {
            $totalearnings = Order::where('vendor_id', $id)->sum('total_amount');
        } elseif ($userType == "driver") {
            $totalearnings = Order::where('driver_id', $id)->where('order_state', 'completed')->sum('total_amount');
        }
        return $totalearnings;
    }

    public static function getTotalearning() {
        $totalearnings = Order::sum('total_amount');
        return $totalearnings;
    }

    public static function actionSaveSettleAmount($post) {
        $type = $post['type'];
        if ($type == 'user') {
            $userData = User::where('id', $post['userId'])->first();
            if ($userData->user_type == 'vendor') {
                $model = Order::where('vendor_id', $post['userId'])
                        ->where('orders.order_state', 'completed')
                        ->get();
            } else {
                $model = Order::where('driver_id', $post['userId'])
                        ->where('orders.order_state', 'completed')
                        ->get();
            }
            foreach ($model as $order) {
                $order->is_settled = 1;
                $order->settle_remark = $post['settle_remark'];
                $data = $order->save();
            }
            if ($data) {
                $remainingAmount = $post['totalAmount'] - $post['amount'];
                $userModal = User::where('id', $post['userId'])->first();
                $userModal->remaining_amount = $remainingAmount;
                if ($userModal->save()) {
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            $driverList = DriverDetail::where('deliver_company_id', $post['userId'])->get();
            $driverIdList = array();
            foreach ($driverList as $list) {
                array_push($driverIdList, $list->user_id);
            }
            $model = Order::whereIn('driver_id', $driverIdList)
                    ->where('orders.order_state', 'completed')
                    ->get();
            foreach ($model as $order) {
                $order->is_settled = 1;
                $order->settle_remark = $post['settle_remark'];
                $data = $order->save();
            }
            if ($data) {
                $remainingAmount = $post['totalAmount'] - $post['amount'];
                $companyModal = DeliverCompany::where('id', $post['userId'])->first();
                $companyModal->remaining_amount = $remainingAmount;
                if ($companyModal->save()) {
                    return true;
                } else {
                    return false;
                }
            }
        }
    }

}
