<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OptionValue extends Model {

    public static function getOptionValues($post) {
        $options = OptionValue::where('attr_id', $post)->get();
        return $options;
    }

    public static function getOptionValuesByID($post) {
        $options = OptionValue::where('id', $post)->get();
        return $options;
    }

    public static function getOptionValueDropdown($attrId, $valueId) {
        $attribute = OptionValue::where('attr_id', $attrId)->get();
        $html = '';
        $html .= '<select id="option_value" name="option_value_id[]" class="form-control input-lg">';
        $html .= '<option value="">-- Select Category --</option>';
        if (!empty($attribute)) {
            foreach ($attribute as $info) {
                $data = ($valueId == $info['id']) ? 'selected="selected"' : '';
                $html .= '<option value="' . $info['id'] . '" ' . $data . '>' . $info['option_name'] . '</option>';
            }
        }
        $html .= '</select>';
        return $html;
    }

}
