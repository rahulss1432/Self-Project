<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\OptionValue;

class Attribute extends Model {

    public static function saveAttributes($post) {
        $model = new Attribute();
        $model->attribute_name = $post['attribute_name'];
        if ($model->save()) {
            if (!empty($post['option_name'])) {
                foreach ($post['option_name'] as $key => $value) {
                    $model1 = new OptionValue();
                    $model1->option_name = $post['option_name'][$key];
                    $model1->option_value = $post['option_value'][$key];
                    $model1->attr_id = $model->id;
                    $model1->save();
                }
            }
            return true;
        } else {
            return false;
        }
        return true;
    }

    public static function getAllAttributes($post) {
        if (!empty($post['attrSearch'])) {
            $search = $post['attrSearch'];
            $attrData = Attribute::where('attribute_name', 'like', '%' . $search . '%')->orderBy('created_at', 'desc');
        } else {
            $attrData = Attribute::orderBy('created_at', 'desc');
        }
        $attrData = $attrData->paginate(10);
        return $attrData;
    }

    public static function deleteAttributes($post) {
        $attr = Attribute::where('id', $post['id'])->first();
        if ($attr->delete()) {
            return 1;
        } else {
            return 0;
        }
    }

    public static function updateAttributes($post) {
        $attrId = $post['attributeId'];
        $model = Attribute::where('id', $attrId)->first();
        $model->attribute_name = $post['attribute_name'];
        if ($model->save()) {
            OptionValue::where('attr_id', $attrId)->delete();
            if (!empty($attrId)) {
                if (!empty($post['option_name'])) {
                    foreach ($post['option_name'] as $key => $value) {
                        $model1 = new OptionValue();
                        $model1->option_name = $post['option_name'][$key];
                        $model1->option_value = $post['option_value'][$key];
                        $model1->attr_id = $model->id;
                        $model1->save();
                    }
                }
            }
            return true;
        } else {
            return false;
        }
        return true;
    }

    public static function getAttributeDropdown($id) {
        $attribute = Attribute::get();
        $html = '';
        $html .= '<select id="attribute" name="attribute_id[]" class="form-control input-lg hide_this" onchange="getOptionValue(this); $(this).valid()" data-live-search="true">';
        $html .= '<option value="">-- Select Attribute --</option>';
        if (!empty($attribute)) {
            foreach ($attribute as $info) {
                $data = ($id == $info['id']) ? 'selected="selected"' : '';
                $html .= '<option value="' . $info['id'] . '" ' . $data . '>' . $info['attribute_name'] . '</option>';
            }
        }
        $html .= '</select>';
        return $html;
    }

}
