<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class WalletTransaction extends Model
{
    public static function saveWalletTransaction($post,$transactionType){
        $model = new WalletTransaction();
        $model->user_id = Auth::guard()->user()->id;
        $model->amount = $post['payment_gross'];
        $model->transaction_id = $post['txn_id'];
        $model->transaction_type = $transactionType;
        if($model->save()){
            return true;
        }else{
            return false;
        }
    }
}
