<?php

namespace App\Models;

use App\Helpers\Helper;
use Illuminate\Database\Eloquent\Model;
use App\Models\DriverDetail;
use App\Models\VendorDetail;
use App\Models\Order;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Auth;
use App\Models\Tag;
use Illuminate\Support\Facades\DB;

class User extends Model {

    protected $fillable = ['user_type', 'first_name', 'last_name', 'email', 'password', 'phone_number', 'profile_picture', 'address', 'zip_code', 'date_of_birth', 'state_id', 'city_id', 'is_active', 'role', 'latitude', 'longitude'];

    /* relation for get user type driver detail from driver_details table from user table */

    public function driverDetail() {
        return $this->hasOne('App\Models\DriverDetail');
    }

    /* relation for get user type vendor detail from vendor_details table from user table */

    public function vendorDetail() {
        return $this->hasOne('App\Models\VendorDetail');
    }

    /* return orders by driver_id */

    public function driverOrder() {
        return $this->hasMany('App\Models\Order', 'driver_id', 'id')->where('order_state', '=', 'completed');
    }

    /* return orders by customer_id */

    public function customerOrder() {
        return $this->hasMany('App\Models\Order', 'customer_id', 'id')->where('order_state', '=', 'completed');
    }

    /* return orders by vendor_id */

    public function vendorOrder() {
        return $this->hasMany('App\Models\Order', 'vendor_id', 'id')->where('order_state', '=', 'completed');
    }

    /* scope for with and where has */

    public function scopeWithAndWhereHas($query, $relation, $constraint) {
        return $query->whereHas($relation, $constraint)
                        ->with([$relation => $constraint]);
    }

    /* get average rating for user_id */

    public function ratingsAverage() {
        return $this->hasMany('App\Models\Rating', 'to_id')
                        ->selectRaw('avg(rating) as rating, to_id')
                        ->groupBy('to_id');
    }

    //to get business dropdown in admin
    public static function getBusinessDropdown($id) {
        $business = User::where('user_type', '=', 'vendor')->get();
        $html = '';
        $html .= '<select id="business" name="businessId" class="form-control input-lg">';
        $html .= '<option value="">-- Select Business --</option>';
        if (!empty($business)) {
            foreach ($business as $info) {
                $data = ($id == $info['id']) ? 'selected="selected"' : '';
                $html .= '<option value="' . $info['id'] . '" ' . $data . '>' . \App\Helpers\Helper::getBusineessNameByVendorId($info['id']) . '</option>';
            }
        }
        $html .= '</select>';
        return $html;
    }

    public static function getVendorDropdown($id) {
        $vendor = User::where('user_type', '=', 'vendor')->get();
        $html = '';
        $html .= '<select id="order" name="vendor_id" class="form-control " onchange="getaddress();">';
        $html .= '<option value="">-- Select Vendor --</option>';
        if (!empty($vendor)) {
            foreach ($vendor as $info) {
                $data = ($id == $info['id']) ? 'selected="selected"' : '';
                $html .= '<option value="' . $info['id'] . '" ' . $data . '>' . \App\Helpers\Helper::getBusineessNameByVendorId($info['id']) . '</option>';
            }
        }
        $html .= '</select>';
        return $html;
    }

    public static function getVendorNameDropdown($id) {
        $vendor = User::where('user_type', '=', 'vendor')->get();
        $html = '';
        $html .= '<select id="vendor" name="vendor_id" class="form-control " onchange="redirectTLink();">';
        $html .= '<option value="">-- Select Vendor --</option>';
        if (!empty($vendor)) {
            foreach ($vendor as $info) {
                $data = ($id == $info['id']) ? 'selected="selected"' : '';
                $html .= '<option value="' . $info['id'] . '" ' . $data . '>' . $info['first_name'] . ' ' . $info['last_name'] . '</option>';
            }
        }
        $html .= '</select>';
        return $html;
    }

    public static function getCustomerDropdown($id) {
        $customer = User::where('user_type', '=', 'customer')->get();
        $html = '';
        $html .= '<select id="customer" name="customer_id" class="form-control " onchange="redirectTLink();">';
        $html .= '<option value="">-- Select User --</option>';
        $html .= '<option value="create_new_user">Create New user</option>';
        if (!empty($customer)) {
            foreach ($customer as $info) {
                $data = ($id == $info['id']) ? 'selected="selected"' : '';
                $html .= '<option value="' . $info['id'] . '" ' . $data . '>' . $info['first_name'] . '</option>';
            }
        }
        $html .= '</select>';
        return $html;
    }

    public static function generateRandomString($length = 6) {
        return substr(str_shuffle(str_repeat($x = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / strlen($x)))), 1, $length);
    }

    public static function createCustomer($request) {
        $password = self::generateRandomString();
        $user = new User;
        $user->user_type = $request->user_type;
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->is_active = $request->status;
        $user->phone_number = $request->phone_number;
        $user->date_of_birth = $request->date_of_birth;
        $user->password = bcrypt($password);
        if ($user->save()) {
            $data = array();
            $data['request'] = 'create_user';
            $data['email'] = $request['email'];
            $data['password'] = $password;
            $data['name'] = $request['first_name'] . ' ' . $request['last_name'];
            $data['subject'] = 'Login Credentials';
            $mailSent = Helper::sendMail($data);
            if ($mailSent) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static function customersList($request) {
        $customer = User::where(['user_type' => 'customer']);
        if (!empty($request['email'])) {
            $customer->where('email', 'like', '%' . $request['email'] . '%');
        }
        if (!empty($request['phone_number'])) {
            $customer->where('phone_number', 'like', '%' . $request['phone_number'] . '%');
        }
        if (!empty($request['name'])) {
            $customer->where(function ($query) use ($request) {
                $query->where(DB::raw('TRIM(CONCAT(users.first_name," ",users.last_name))'), 'like', '%' . $request['name'] . '%');
            });
        }
        if ((!empty($request['number_of_order']) && $request['number_of_order'] != 'null') || ($request['number_of_order'] == "0")) {
            $customer->has('customerOrder', $request['number_of_order']);
        }
        $result = $customer->orderBy('id', 'desc');
        if (isset($request['call_from']) && $request['call_from'] == 'export_list') {
            $result = $result->get();
        } else {
            $result = $result->paginate(10);
        }
        if ($result) {
            return $result;
        } else {
            return false;
        }
    }

    public static function saveSubAdmin($post) {
        if (!empty($post)) {
            $user = new User;
            $user->user_type = 'subadmin';
            $user->first_name = $post->first_name;
            $user->last_name = $post->last_name;
            $user->email = $post->email;
            $user->is_active = 1;
            $user->phone_number = $post->mobile;
            $user->password = bcrypt($post->password);
            $user->address = $post->address;
            $user->latitude = (isset($post['addressLat']) ? $post['addressLat'] : '');
            $user->longitude = (isset($post['addressLong']) ? $post['addressLong'] : '');
            $user->role = $post->role;
            if ($user->save()) {
                $data = array();
                $data['request'] = 'create_user';
                $data['email'] = $post->email;
                $data['password'] = $post->password;
                $data['name'] = $post->first_name . ' ' . $post->last_name;
                $data['subject'] = 'Login Credentials';
                $mailsent = Helper::sendMail($data);
                return true;
            }
        } else {
            return false;
        }
    }

    public static function updateCustomer($request) {
        $model = User::where('id', $request->id)->first();
        if (!empty($model)) {
            $model->first_name = $request['first_name'];
            $model->last_name = $request['last_name'];
            $model->phone_number = $request['phone_number'];
            $model->date_of_birth = $request['date_of_birth'];
            $model->is_active = $request['status'];
            $result = $model->update();
        }
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public static function updateSubadmin($request) {
        $model = User::where('id', $request->subId)->first();
        if (!empty($model)) {
            $model->first_name = $request['first_name'];
            $model->last_name = $request['last_name'];
            $model->email = $request['email'];
            $model->phone_number = $request['mobile'];
            $model->address = $request['address'];
            $model->latitude = (isset($request['addressLat']) ? $request['addressLat'] : '');
            $model->longitude = (isset($request['addressLong']) ? $request['addressLong'] : '');
            $model->role = $request['role'];
        }
        if ($model->update()) {
            return true;
        } else {
            return false;
        }
    }

    public static function updateUser($post) {
        $model = User::where('id', $post['id'])->first();
        $model->first_name = $post['first_name'];
        $model->last_name = $post['last_name'];
        $model->email = $post['email'];
        $model->phone_number = $post['phone_number'];
        $model->profile_picture = $post['profile_picture'];
        $model->address = $post['address'];
        if ($model->save()) {

            if (!empty($post['id'])) {
                $vendor = VendorDetail::where('user_id', $post['id'])->first();
                $vendor->user_id = $model->id;
                $vendor->business_name = $post['business_name'];
                $vendor->start_time = date('H:i:s', strtotime($post['start_time']));
                $vendor->end_time = date('H:i:s', strtotime($post['end_time']));
                $vendor->business_type = $post['business_type'];
                $vendor->delivery_location = implode(', ', $post['delivery_location']);
                $vendor->vendor_acceptance = $post['vendor_acceptance'];
                if ($vendor->update()) {
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
    }

    public static function listSubadmin($post) {
        $subadmin = User::where(['user_type' => 'subadmin']);
        if (!empty($post['name'])) {
            $subadmin->where(function ($query) use ($post) {
                $query->where(DB::raw('CONCAT(users.first_name, " ", users.last_name)'), 'like', '%' . $post['name'] . '%');
            });
        }
        $result = $subadmin->orderBy('users.id', 'desc')->paginate(10);
        return $result;
    }

    public static function deleteUser($id) {
        $model = User::where('id', $id)->delete();
        if (!empty($model)) {
            return true;
        }
        return false;
    }

    public static function editSubadmin($id) {
        $model = User::where('id', $id)->first();
        if (!empty($model)) {
            return $model;
        }
        return false;
    }

    public static function createDriver($post) {
        DB::beginTransaction();
        $data = [];
        $password = self::generateRandomString();
        $data['user_type'] = $post['user_type'];
        $data['first_name'] = $post['first_name'];
        $data['last_name'] = $post['last_name'];
        $data['email'] = $post['email'];
        $data['is_active'] = 0;
        $data['phone_number'] = $post['phone_number'];
        $data['profile_picture'] = $post['profile_image'];
        $data['password'] = bcrypt($password);
        $user = User::create($data);
        if (!empty($user)) {
            $driver = new DriverDetail();
            $driver->user_id = $user->id;
            $driver->vehicle_category_id = $post['vehicle_type'];
            $driver->license_image = $post['license_image'];
            $driver->license_number = $post['license_number'];
            $driver->vehicle_number = $post['vehicle_number'];
            $driver->vehicle_description = $post['vehicle_description'];
            if (($post['deliver_company'] == '') && ($post['deliver_company'] == null)) {
                $driver->commission = $post['commission'];
            } else {
                $driver->deliver_company_id = $post['deliver_company'];
                $driver->commission = "";
            }
            if ($driver->save()) {
                $data = array();
                $data['request'] = 'create_user';
                $data['email'] = $post['email'];
                $data['password'] = $password;
                $data['name'] = $post['first_name'] . ' ' . $post['last_name'];
                $data['subject'] = 'Login Credentials';
                $mailsent = Helper::sendMail($data);
                if ($mailsent) {
                    DB::commit();
                    return true;
                } else {
                    return false;
                }
            } else {
                DB::rollBack();
                return false;
            }
        } else {
            DB::rollBack();
            return false;
        }
    }

    public static function getAllDrivers($post) {
        $query = User::with('driverDetail', 'ratingsAverage');         // select all users with user details                     
        if (!empty($post['name']) && $post['name'] != '') {
            $name = $post['name'];
            $query->where(function ($query1) use ($name) {
                $query1->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $name . '%');  // select user where first_namr or last name=' --'
            });
        }
        if (!empty($post['email']) && $post['email'] != '') {
            $query->where('email', 'like', '%' . $post['email'] . '%');        // select user where email=' --'
        }
        if (!empty($post['phone_number']) && $post['phone_number'] != '') {
            $query->where('phone_number', 'like', '%' . $post['phone_number'] . '%');      // select user where phone number=' --'
        }
        if (!empty($post['deliver_company']) && $post['deliver_company'] != '') {
            $query->withAndWhereHas('driverDetail', function($q) use ($post) {
                $q->where('deliver_company_id', $post['deliver_company']);
            });
        }
        if ((!empty($post['number_of_order']) && $post['number_of_order'] != 'null') || ($post['number_of_order'] == "0")) {
            $query->has('driverOrder', $post['number_of_order']);               // select all users where orders count=' ---' 
        }
        if ((!empty($post['average_rating']) && $post['average_rating'] != '')) {    // select all users where average rating =' ---' 
            $query->whereHas('ratingsAverage', function ($q) use($post) {
                $q->groupBy('to_id')->select(\DB::raw('avg(rating)'));
            }, $post['average_rating']);
        }
        $drivers = $query->where('user_type', 'driver')->orderBy('created_at', 'desc');
        if (isset($post['call_from']) && $post['call_from'] == 'export_list') {
            $drivers = $drivers->get();
        } else {
            $drivers = $drivers->paginate(10);
        }
        return $drivers;
    }

    public static function updateStatus($id) {
        $model = User::where('id', $id)->first();
        if ($model->is_active == 1) {
            $model->is_active = 0;
        } else {
            $model->is_active = 1;
        }
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function getDriverDetailById($id) {
        $driver = User::with(['driverDetail', 'driverDetail.vehicleCategory', 'driverDetail.deliverCompany'])->where('id', $id)->first();
        return $driver;
    }

    public static function updateDriver($post) {
        if (isset($post['user_id']) && isset($post['user_id']) != '') {
            $userId = $post['user_id'];
        } else {
            $userId = \Illuminate\Support\Facades\Auth::guard()->user()->id;
        }
        $model = User::where('id', $userId)->first();
        $model->first_name = $post['first_name'];
        $model->last_name = $post['last_name'];
        $model->phone_number = $post['phone_number'];
        $model->latitude = $post['address_lat'];
        $model->longitude = $post['address_long'];
        if (isset($post['profile_image']) && ($post['profile_image'] != '')) {
            $model->profile_picture = $post['profile_image'];
        }
        $model->address = $post['address'];
        if ($model->save()) {
            $driverDetail = DriverDetail::where('user_id', $userId)->first();
            $driverDetail->vehicle_category_id = $post['vehicle_type'];
            if (isset($post['license_image']) && ($post['license_image'] != '')) {
                $driverDetail->license_image = $post['license_image'];
            }
            $driverDetail->license_number = $post['license_number'];
            $driverDetail->vehicle_number = $post['vehicle_number'];
            $driverDetail->vehicle_description = $post['vehicle_description'];
            if (($post['deliver_company'] == '') && ($post['deliver_company'] == null)) {
                $driverDetail->deliver_company_id = NULL;
                $driverDetail->commission = $post['commission'];
            } else {
                $driverDetail->deliver_company_id = $post['deliver_company'];
                $driverDetail->commission = "";
            }
            if ($driverDetail->save()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static function createVendor($post, $request) {
        $model = new User();
        $password = self::generateRandomString();
        $model->user_type = $post['user_type'];
        $model->first_name = $post['first_name'];
        $model->last_name = $post['last_name'];
        $model->email = $post['email'];
        $model->is_active = 1;
        $model->phone_number = $post['phone_number'];
        $model->address = $post['address'];
        $model->password = bcrypt($password);
        if ($model->save()) {
            $vendor = new VendorDetail();
            $vendor->user_id = $model->id;
            $vendor->business_name = $post['business_name'];
            $vendor->start_time = date('H:i:s', strtotime($post['start_time']));
            $vendor->end_time = date('H:i:s', strtotime($post['end_time']));
            $vendor->admin_commission = $post['admin_commission'];
            $vendor->store_image = $post['store_picture'];
            $vendor->business_type = $post['business_type'];
            $vendor->delivery_location = implode(', ', $post['delivery_location']);
            if (!empty($post['tags'])) {
                foreach ($post['tags'] as $val) {
                    $allTags = Tag::where('tag_name', $val)->first();
                    if ($allTags == null) {
                        $tagModel = new Tag();
                        $tagModel->tag_name = $val;
                        $tagModel->save();
                        $tags[] = $tagModel->id;
                    } else {
                        $tags[] = $allTags->id;
                    }
                }
            }
            if (!empty($tags)) {
                $vendor->tags = implode(', ', $tags);
            } else {
                $vendor->tags = "";
            }
            $vendor->vendor_acceptance = $post['vendor_acceptance'];
            if ($vendor->save()) {
                $data = array();
                $data['request'] = 'create_user';
                $data['email'] = $post['email'];
                $data['password'] = $password;
                $data['name'] = $post['first_name'] . ' ' . $post['last_name'];
                $data['subject'] = 'Login Credentials';
                $mailSent = Helper::sendMail($data);
                if ($mailSent) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static function getVendorData($post) {
        $query = User::selectRaw('users.*, vendor_details.business_name, vendor_details.business_type')->Join('vendor_details', 'users.id', '=', 'vendor_details.user_id');
        if (!empty($post['name']) && $post['name'] != '') {
            $query->where('vendor_details.business_name', 'like', '%' . $post['name'] . '%');
        }
        if (!empty($post['email']) && $post['email'] != '') {
            $query->where('users.email', 'like', '%' . $post['email'] . '%');
        }
        if (!empty($post['phone_number']) && $post['phone_number'] != '') {
            $query->where('users.phone_number', 'like', '%' . $post['phone_number'] . '%');
        }
        if (!empty($post['businessType']) && $post['businessType'] != '') {
            $query->where('vendor_details.business_type', '=', $post['businessType']);
        }
        $getVendorData = $query->where('users.user_type', 'vendor')->orderBy('users.id', 'desc');
        if (isset($post['call_from']) && $post['call_from'] == 'export_list') {
            $getVendorData = $getVendorData->get();
        } else {
            $getVendorData = $getVendorData->paginate(10);
        }
        return $getVendorData;
    }

    public static function assignDriver() {
        $user = User::select('users.*')->leftJoin('orders', 'orders.driver_id', '=', 'users.id');
        $user = $user->where(function($q) {
            $q->orWhere('orders.order_state', '=', 'completed')
                    ->orWhereNull('orders.driver_id');
        });
        $user = $user->where('users.user_type', '=', 'driver');
        $user = $user->groupBy('users.id')->get();
        return $user;
    }

    public static function deleteVendors($post) {
        $attr = User::where('id', $post['id'])->first();
        if ($attr->delete()) {
            return 1;
        } else {
            return 0;
        }
    }

    public static function editSingalVendorData($post) {
        $getVendorData = User::selectRaw('users.*, vendor_details.business_name, vendor_details.start_time, vendor_details.end_time, vendor_details.admin_commission, vendor_details.business_type, vendor_details.delivery_location, vendor_details.tags, vendor_details.vendor_acceptance, vendor_details.store_image')
                ->Join('vendor_details', 'vendor_details.user_id', '=', 'users.id')
                ->where('users.user_type', 'vendor')
                ->where('users.id', $post)
                ->first();
        return $getVendorData;
    }

    public static function updateVendors($post, $request) {
        $vendorId = $post['vendorId'];
        $model = User::where('id', $vendorId)->first();
        $model->first_name = $post['first_name'];
        $model->last_name = $post['last_name'];
        $model->is_active = $post['status'];
        $model->phone_number = $post['phone_number'];
        $model->address = $post['address'];
        if ($model->save()) {
            if (!empty($vendorId)) {
                $vendor = VendorDetail::where('user_id', $vendorId)->first();
                $vendor->user_id = $model->id;
                $vendor->business_name = $post['business_name'];
                $vendor->start_time = date('H:i:s', strtotime($post['start_time']));
                $vendor->end_time = date('H:i:s', strtotime($post['end_time']));
                $vendor->admin_commission = $post['admin_commission'];
                $vendor->store_image = $post['store_picture'];
                $vendor->business_type = $post['business_type'];
                $vendor->delivery_location = implode(', ', $post['delivery_location']);
                if (!empty($post['tags'])) {
                    Tag::where(['user_id' => $model->id])->delete();
                    foreach ($post['tags'] as $val) {
                        $allTags = Tag::where('tag_name', $val)->first();
                        if ($allTags == null) {
                            $tagModel = new Tag();
                            $tagModel->tag_name = $val;
                            $tagModel->save();
                            $tags[] = $tagModel->id;
                        } else {
                            $tags[] = $allTags->id;
                        }
                    }
                }
                if (!empty($tags)) {
                    $vendor->tags = implode(', ', $tags);
                } else {
                    $vendor->tags = "";
                }
                $vendor->vendor_acceptance = $post['vendor_acceptance'];
                if ($vendor->update()) {
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
    }

    public static function getVendorDetailById($id) {
        $vendor = User::with(['vendorDetail', 'vendorDetail.businessType'])->where('id', $id)->first();
        return $vendor;
    }

//    public static function changePassword($post) {
//        $model = User::where('id', $post['userId'])->first();
//        if (!empty($model)) {
//            $model->password = bcrypt($post['new_password']);
//            if ($model->save()) {
//                return true;
//            }
//        }
//        return false;
//    }

    public static function changeVendorPasswordById($post) {
        $model = User::where('id', $post['userId'])->first();
        if (!empty($model)) {
            $model->password = bcrypt($post['new_password']);
            if ($model->save()) {
                if (!empty($post['new_password'])) {
                    $mailData = array();
                    $mailData['email'] = $model->email;
                    $mailData['fullname'] = ucfirst(trim($model->first_name));
                    $mailData['request'] = "admin_change_password";
                    $mailData['subject'] = 'Change Password';
                    $mailData['password'] = $post['new_password'];
                    \App\Helpers\Helper::sendMail($mailData);
                }
                return true;
            }
        }
        return false;
    }

    public static function customerProfileUpdate($request) {
        $model = User::where('id', $request->user_id)->first();
        $model->first_name = $request['first_name'];
        $model->last_name = $request['last_name'];
        if ($request['profile_image']) {
            $model->profile_picture = $request['profile_image'];
        }
        $model->email = $request['email'];
        $model->phone_number = $request['phone_number'];
        $model->address = $request['address'];
        $model->zip_code = $request['zip_code'];
        $model->date_of_birth = $request['date_of_birth'];
        $result = $model->update();
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public static function changeUserPassword($post) {
        $userId = Auth::user()->id;
        $model = User::where('id', $userId)->first();
        if (!empty($model)) {
            $model->password = bcrypt($post['password']);
            if ($model->save()) {
                return true;
            }
        }
        return false;
    }

    public static function changeAdminPassword($post) {
        $userId = Auth::guard('admin')->user()->id;
        $model = User::where('id', $userId)->first();
        if (!empty($model)) {
            $model->password = bcrypt($post['password']);
            if ($model->save()) {
                return true;
            }
        }
        return false;
    }

    public static function getUserProfile() {
        $userId = Auth::guard('admin')->user()->id;
        $model = User::where('id', $userId)->first();
        if (!empty($model)) {
            return $model;
        }
        return false;
    }

    public static function editProfile($id) {
        $model = User::where('id', $id)->first();
        if (!empty($model)) {
            return $model;
        }
        return false;
    }

    public static function driverRunningOrderDetails() {
        $userId = \Illuminate\Support\Facades\Auth::guard()->user()->id;
        $runningOrderData = User::selectRaw('orders.*, order_products.price')
                ->Join('orders', 'users.id', '=', 'orders.driver_id')
                ->Join('order_products', 'orders.id', '=', 'order_products.order_id')
                ->where('orders.driver_id', $userId)
                ->where('orders.order_state', 'running')
                ->orWhere('orders.order_state', 'out_for_pickup')
                ->orWhere('orders.order_state', 'out_for_delivery')
                ->orderBy('orders.created_at', 'desc')
                ->groupBy('order_products.order_id')
                ->first();
        return $runningOrderData;
    }

    public static function driverCompleteOrderDetails() {
        $userId = \Illuminate\Support\Facades\Auth::guard()->user()->id;
        $completeOrderData = User::selectRaw('orders.*, order_products.price')
                ->LeftJoin('orders', 'users.id', '=', 'orders.driver_id')
                ->LeftJoin('order_products', 'orders.id', '=', 'order_products.order_id')
                ->where('orders.driver_id', $userId)
                ->where('orders.order_state', 'completed')
                ->orderBy('orders.created_at', 'desc')
                ->groupBy('order_products.order_id')
                ->paginate(10);
        return $completeOrderData;
    }

    public static function updateAdminProfile($post) {
        $model = User::find($post['adminId']);
        if (!empty($model)) {
            $model->first_name = $post['first_name'];
            $model->email = $post['email'];
            $model->profile_picture = $post['profile_picture'];
            $model->update();
            if ($model) {
                return true;
            }
            return false;
        }
        return false;
    }

    public static function findUserByEmail($email) {
        $user = User::where('email', $email)->first();
        if (!empty($user)) {
            return $user;
        }
        return false;
    }

    public static function getRemainingAmountById($userId) {
        $user = User::where('id', $userId)->first();
        if (!empty($user)) {
            return $user->remaining_amount;
        }
        return false;
    }

    public static function findByToken($token) {
        return User::where(['reset_password_token' => $token])->first();
    }

}
