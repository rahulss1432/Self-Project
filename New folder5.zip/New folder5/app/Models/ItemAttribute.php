<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ItemAttribute extends Model {

    public function getItems() {
        return $this->hasOne('App\Models\Item', 'id', 'item_id');
    }

    public function getAttributes() {
        return $this->hasOne('App\Models\Attribute', 'id', 'attribute_id');
    }

    public function getOptions() {
        return $this->hasMany('App\Models\OptionValue', 'id', 'option_id');
    }

    //for vendor and admin side add ItemAttribute
    public static function addItemAttribute($id, $post) {
        if (!empty($post['attribute_id']) && !empty($post['option_value_id'])) {
            foreach ($post['attribute_id'] as $key => $value) {
                if (!empty($post['attribute_id'][$key]) && !empty($post['option_value_id'][$key])) {
                    $model1 = new ItemAttribute();
                    $model1->item_id = $id;
                    $model1->attribute_id = $post['attribute_id'][$key];
                    $model1->option_id = $post['option_value_id'][$key];
                    $model1->product_quantity = $post['product_options_quantity'][$key];
                    $model1->product_price = $post['product_options_price'][$key];
                    $model1->save();
                }
            }
            return true;
        } else {
            return true;
        }
    }

    //for vendor and admin side update ItemAttribute
    public static function updateItemAttribute($id, $post) {
        if (!empty($post['delete_id'])) {
            $deletedId = explode(',', $post['delete_id']);
            foreach ($deletedId as $val) {
                if (!empty($val)) {
                    ItemAttribute::where('id', $val)->delete();
                }
            }
        }

        if (!empty($post['attribute_id']) && !empty($post['option_value_id'])) {
            foreach ($post['attribute_id'] as $key => $value) {
                if (!empty($post['attribute_id'][$key]) && !empty($post['option_value_id'][$key])) {
                    if (!empty($post['ids'][$key])) {
                        $model = ItemAttribute::where('id', $post['ids'][$key])->first();
                        if (!empty($model)) {
                            $model->item_id = $id;
                            $model->attribute_id = $post['attribute_id'][$key];
                            $model->option_id = $post['option_value_id'][$key];
                            $model->product_quantity = $post['product_options_quantity'][$key];
                            $model->product_price = $post['product_options_price'][$key];
                            $model->update();
                        }
                    } else {
                        $model1 = new ItemAttribute();
                        $model1->item_id = $id;
                        $model1->attribute_id = $post['attribute_id'][$key];
                        $model1->option_id = $post['option_value_id'][$key];
                        $model1->product_quantity = $post['product_options_quantity'][$key];
                        $model1->product_price = $post['product_options_price'][$key];
                        $model1->save();
                    }
                }
            }
        }
        return true;
    }
}
