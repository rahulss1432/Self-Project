<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;

class Category extends Model {

    //for save category vendor and admin side
    public static function saveCategory($post) {
        $model = new Category();
        $model->category_name = ucwords(strtolower($post['categoryName']));
        $model->business_id = $post['businessId'];
        $model->status = $post['status'];
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    //for vendor side category Listing
    public static function getAllCategory($post) {
        $businessId = Auth::User()->id;
        $categoryData = Category::select('categories.*');
        $categoryData->where('business_id', '=', $businessId);
        if (isset($post['search']) && !empty($post['search'])) {
            $categoryData->where(function ($query) {
                $text = Input::get('search');
                $query->where(DB::raw('category_name'), 'like', '%' . $text . '%');
            });
        }

        $categoryData->orderBy('categories.created_at', 'desc');
        $data = $categoryData->paginate(10);
        return $data;
    }

    //For Admin side listing
    public static function getAllCategories($post) {
        $result = Category::select('categories.*');

        if (isset($post['category']) && !empty($post['category'])) {
            $result->where(function ($query) {
                $text = Input::get('category');
                $query->where('categories.category_name', 'like', '%' . $text . '%');
            });
        }

        $result->orderBy('categories.id', 'desc');
        $data = $result->paginate(10);
        return $data;
    }

    //For delete category Admin and vendor side
    public static function deleteCategory($id) {
        $model = Category::where('id', $id)->first();
        if ($model->delete()) {
            return true;
        } else {
            return false;
        }
    }

    //For Edit category Admin side
    public static function editCategory($id) {
        $categoryData = Category::where('id', $id)->first();
        return $categoryData;
    }

    //For Edit category Admin and vendor side
    public static function updateCategory($post) {
        $model = Category::where('id', $post['catId'])->first();
        if ($model) {
            $model->category_name = ucwords(strtolower($post['categoryName']));
            $model->business_id = $post['businessId'];
            $model->status = $post['status'];
            if ($model->save()) {
                return true;
            } else {
                return false;
            }
        }
    }

    public static function getCategoryDropdownForMultiCat($id) {
        $category = Category::where('business_id', '=', $id)->get();
        $html = '';
        $html .= '<select id="categoryId" name="category[]" class="form-control category-id " onchange="getItem($(this));">';
        $html .= '<option value="">-- Please Select Category --</option>';
        if (!empty($category)) {
            foreach ($category as $info) {
                $html .= '<option value="' . $info['id'] . '">' . $info['category_name'] . '</option>';
            }
        }
        $html .= '</select>';
        return $html;
    }

    public static function getCategoryDropdown($id) {
        $category = Category::get();
        $html = '';
        $html .= '<select id="category_id" name="category_id" class="form-control">';
        $html .= '<option value="">-- Select Category --</option>';
        if (!empty($category)) {
            foreach ($category as $info) {
                $data = ($id == $info['id']) ? 'selected="selected"' : '';
                $html .= '<option value="' . $info['id'] . '" ' . $data . '>' . $info['category_name'] . '</option>';
            }
        }
        $html .= '</select>';
        return $html;
    }

}
