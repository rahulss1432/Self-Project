<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use App\Models\OrderNotification;
class Rating extends Model
{
    public static function AddDriverRating($post) {
        $fromid = Auth::User()->id;
        $model = new Rating();
        $model->order_id = $post['orderId'];
        $model->from_id = $fromid;
        $model->to_id = $post['driverId'];
        $model->rating = $post['rating'];
        if ($model->save()) {
           return true;
        } else {
            return false;
        }
        
    }
}
