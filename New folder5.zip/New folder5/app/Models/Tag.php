<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
    public static function getAllTagsData(){
        $tagsData = Tag::select('tags.*');
        $tagsData = $tagsData->orderBy('id', 'desc')->get();
        return $tagsData;
    }
    
    public static function getTagsDataByVendorId($id){
     $data = Tag::where(['user_id' => $id ])->get();
     return $data;
    }
}
