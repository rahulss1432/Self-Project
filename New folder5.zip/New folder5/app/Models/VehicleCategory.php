<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VehicleCategory extends Model
{
    public static function getAllCategories() {
        $result = VehicleCategory::get();
        return $result;
    }
    
    public static function getDetailById($id) {
        $result = VehicleCategory::where('id',$id)->first();
        return $result;
    }

}
