<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Item extends Model {

    public function getBusiness()
    {
        return $this->hasOne('App\Models\User', 'id', 'business_id');
    }

    public function getCategory()
    {
        return $this->hasOne('App\Models\Category', 'id', 'category_id');
    }

    public function getItemAttribute()
    {
        return $this->hasMany('App\Models\ItemAttribute','item_id','id');
    }


    //for admin item listing
    public static function getAllItems($post) {
        $item = Item::select('items.*');
        if (isset($post['product_name']) && $post['product_name'] != '') {
            $item->where('product_name', 'like', '%' . $post['product_name'] . '%');
        }
            
        if (isset($post['category_id']) && $post['category_id'] != '') {
            $item->where('category_id', $post['category_id']);
        }
        
        if (isset($post['businessId']) && $post['businessId'] != '') {
            $item->where('business_id', $post['businessId']);
        }
        $item->orderBy('items.id', 'desc');
        $model = $item->paginate(10);
        return $model;
    }
    
   //for vendor side add item
    public static function addItem($post) {
        $model = new Item();
        $model->business_id = $post['businessId'];
        $model->category_id = $post['category_id'];
        $model->product_name = $post['product_name'];
        $model->item_image = $post['item_picture'];
        $model->unit = (isset($post['unit'])) ? $post['unit'] : '';
        $model->price = $post['price'];
        $model->product_description = $post['product_description'];
        $model->stock_status = $post['stock_status'];
        if ($model->save()) {
            return $model->id;
        } else {
            return false;
        }
    }

    //for vendor side itemListing
    public static function getAllitem($post) {
        $business_id = Auth::User()->id;
        $itemData = Item::select('items.*');
        $itemData->where('business_id', '=', $business_id);
        if (isset($post['product_name']) && $post['product_name'] != '') {
            $itemData->where('product_name', 'like', '%' . $post['product_name'] . '%');
        }
        if (isset($post['category_id']) && $post['category_id'] != '') {
            $itemData->where('category_id', $post['category_id']);
        }
        $itemData->orderBy('items.created_at', 'desc');
        $data = $itemData->paginate(10);
        return $data;
    }

    //For admin status change
    public static function ChangeItemStatus($id) {
        $model = Item::where('id', $id)->first();
        if ($model->stock_status == 'in') {
            $model->stock_status = 'out';
        } else {
            $model->stock_status = 'in';
        }
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }
    
   //for vendor side update item
    public static function updateItem($post) {
        $model = Item::where('id',$post['itemId'])->first();
        $model->business_id = $post['businessId'];
        $model->category_id = $post['category_id'];
        $model->product_name = $post['product_name'];
        $model->item_image = $post['item_picture'];
        $model->unit = (isset($post['unit'])) ? $post['unit'] : '';
        $model->price = $post['price'];
        $model->product_description = $post['product_description'];
        $model->stock_status = $post['stock_status'];
        if ($model->save()) {
             return $model->id;
        } else {
            return false;
        }
    }
            
      //for vendor and admin side delete item
      public static function deleteItem($id) {
        $model = Item::where('id', $id)->first();
        if($model->delete()){
            return true;
        }else{
            return false;
        }
    }
    
    public static function getCategoryItemDropdown($id) {
        $item = Item::where('category_id','=',$id)->get();
        $html = '';
        $html .= '<select  name="item[]" class="form-control item-id1 " onchange="getItemDetail($(this));">';
        $html .= '<option value="" >-- Please Select Items --</option>';
        if (!empty($item)) {
            foreach ($item as $info) {
                $html .= '<option value="' . $info['id'] . '">' . $info['product_name'] . '</option>';
            }
        }
        $html .= '</select>';
        return $html;
    }
    
    public static function getItemDeatail($id) {
        $itemData = Item::where('id','=',$id)->first();
        if($itemData){
          return $itemData;  
        }
        return false;
    }
    
    //Admin Edit Item
    public static function editItem($id) {
        $categoryData = Item::where('id', $id)->first();
        return $categoryData;
    }

    public static function getAllItemsList($request) {
        $itemData = Item::where('business_id','=',$request->id)->get();
        if($itemData) {
            return $itemData;
        } else {
            return false;
        }
    }

    public static function getItemDetails($id) {
        $itemDetails = Item::where('id',$id)->first();
        if($itemDetails) {
            return $itemDetails;
        } else {
            return false;
        }
    }
}
