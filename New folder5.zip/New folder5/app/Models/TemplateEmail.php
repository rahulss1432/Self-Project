<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TemplateEmail extends Model
{
   public static function saveTemplates($post) {
        $model = new TemplateEmail();
        $model->page_title = $post['page_title'];
        $model->page_description = $post['description'];
        $model->save();
        return true;
    }
     public static function getAllTemplates() {
        $templatesData = TemplateEmail::orderBy('created_at', 'asc');
        $templateData = $templatesData->paginate(10);
        return $templateData;
    }
    
    public static function updateTemplate($post) {
        $cntid = $post['templateId'];
        $model = TemplateEmail::where('id', $cntid)->first();
        $model->page_title = $post['page_title'];
        $model->page_description = $post['description'];
        $model->save();
        return true;
    }
    
      public static function deleteTemplate($id) {
        $model = TemplateEmail::where('id', $id)->first();
        if($model->delete()){
            return true;
        }else{
            return false;
        }
    }
     public static function getEmailTemplate($page) {
        $model = TemplateEmail::where('page_title', $page)->first();
        return $model;
    }
}
