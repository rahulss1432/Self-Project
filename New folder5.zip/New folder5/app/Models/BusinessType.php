<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use \Illuminate\Support\Facades\Input;

class BusinessType extends Model {

    public static function saveBusinessType($post) {
        $model = new BusinessType();
        $model->business_name = ucwords(strtolower($post['business_name']));
        $model->status = $post['status'];
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function getAllBusinessType($post) {
        $data = BusinessType::select('business_types.*');
        if (isset($post['search']) && !empty($post['search'])) {
            $data->where(function ($query) {
                $text = Input::get('search');
                $query->where('business_name', 'like', '%' . $text . '%');
            });
        }
        $result = $data->orderBy('created_at', 'desc')->paginate(10);
        return $result;
    }

    public static function actionChangeBusinessTypeStatus($id) {
        $model = BusinessType::where('id', $id)->first();
        if ($model->status == 'active') {
            $model->status = 'inactive';
        } else {
            $model->status = 'active';
        }
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function updateBusinessType($post) {
        $model = BusinessType::where('id', $post['id'])->first();
        if (!empty($model)) {
            $model->business_name = $post['business_name'];
            $model->status = $post['status'];
        }
        if ($model->update()) {
            return true;
        } else {
            return false;
        }
    }
    
    public static function deleteBusinessTypeById($id) {
        $model = BusinessType::where('id', $id)->first();
        if ($model->delete()) {
            return true;
        } else {
            return false;
        }
    }
    
    public static function getActiveBusinessType() {
        $model = BusinessType::where('status', 'active')->get();
        if ($model) {
            return $model;
        } else {
            return "";
        }
    }

}
