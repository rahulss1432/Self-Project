<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use \Illuminate\Support\Facades\Input;

class AreaHeading extends Model
{
    public static function saveHeading($post) {
        $model = new AreaHeading();
        $model->heading = ucwords(strtolower($post['heading']));
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }
    
    public static function getAllHeadings($post) {
        $data = AreaHeading::select('area_headings.*');
        if (isset($post['search']) && !empty($post['search'])) {
            $data->where(function ($query) {
                $text = Input::get('search');
                $query->where('heading', 'like', '%' . $text . '%');
            });
        }
        $result = $data->orderBy('id','desc')->paginate(10);
        return $result;
    }
    
    public static function updateHeading($post) {
        $model = AreaHeading::where('id', $post['id'])->first();
        if (!empty($model)) {
            $model->heading = $post['heading'];
        }
        if ($model->update()) {
            return true;
        } else {
            return false;
        }
    }
    
    public static function deleteHeadingById($id) {
        $model = AreaHeading::where('id', $id)->first();
        if ($model->delete()) {
            return true;
        } else {
            return false;
        }
    }
}
