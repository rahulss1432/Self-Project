<?php

namespace App\Models;

use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Model;

class Privilege extends Model {

    public static function getAllMenuList() {
        $userType = Auth::guard('admin')->user()->role;
        $menuList = Privilege::select('privileges.*', 'role_privileges.status as role_status', 'user_roles.role')
                ->leftJoin('role_privileges', 'role_privileges.privilege_id', '=', 'privileges.id')
                ->leftJoin('user_roles', 'user_roles.id', '=', 'role_privileges.role_id')
                ->where('role_privileges.status', '=', 'active')
                ->where('user_roles.role', '=', $userType)
                ->get();
        if ($menuList) {
            return $menuList;
        } else {
            return false;
        }
    }

}
