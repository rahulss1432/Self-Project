<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model {

    public static function getActiveSettingdata() {
        $data = Setting::where(['status' => 'active'])->get();
        return $data;
    }

    public static function updateSetting($post) {
        $model = Setting::where('id', $post['id'])->first();
        if (!empty($model)) {
            $model->value = $post['value'];
            $model->unit = $post['unit'];
        }
        if ($model->update()) {
            return true;
        } else {
            return false;
        }
    }

    public static function getActiveSettingByKey($key) {
        $data = Setting::where('key',$key)->where(['status' => 'active'])->first();
        return $data;
    }

}
