<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserRole extends Model
{
    public static function allsubAdmins($request)
    {
    	$subRole = UserRole::where('parent_id',$request->id)->orderBy('role', 'asc')->get();
        $subRoleHtml = "";
        $subRoleHtml .= '<option value="">' . 'Select Sub Role' . '</option>';
        if (count($subRole) > 0)
        {
            foreach ($subRole as $data)
            {
                $subRoleHtml .= '<option value="' . $data->id . '">' . $data->role . '</option>';
            }
            return $subRoleHtml;
        }
    }
}
