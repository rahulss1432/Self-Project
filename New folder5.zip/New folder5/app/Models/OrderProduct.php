<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use App\Models\OrderProductAttribute;

class OrderProduct extends Model
{
    public function getItems() {
        return $this->hasMany('App\Models\Item', 'id', 'item_id');
    }
    
    public static function saveproductDetail($id,$post){
        
        if(!empty($id)){
            foreach ($post->category as $key => $category){
            $model = new OrderProduct();
            $model->order_id = $id;
            $model->category_id = $category;
            $model->item_id = $post['item'][$key];
            $model->save();
            }
            if($model){
               return true; 
            }
             return false;
        }
    }
    public static function getAmountByOrderId($id) {
        
        $itemData = OrderProduct::where('order_id','=',$id)->get();
        $amount = 0;
        if($itemData){
          foreach($itemData as $data){
             $price = DB::table('items')->select('price')->where('id','=',$data->item_id)->first();
             $amount = $amount + $price->price;
          }
          //$amount = \App\Helpers\Helper::getPriceFormatedValue($amount);
          return $amount;
        }
        return false;
    }
    public static function getProcessingAmountByOrderId($id,$processData) {
        $itemData = OrderProduct::where('order_id','=',$id)->get();
        $amount = 0;
        if($itemData){
          foreach($itemData as $data){
             $price = DB::table('items')->select('price')->where('id','=',$data->item_id)->first();
             $amount = $amount + $price->price;
          }
        
          if($processData->unit == 'percent'){
           return $processcharge = ($amount*$processData->value)/100;
          }elseif($processData->unit == 'flat'){
            return $processData->value;
          }
        }
        return false;
    }
     public static function getProdutNameByOrderId($id) {
        
        $itemData = OrderProduct::where('order_id','=',$id)->first();
        if($itemData){
             $productName = DB::table('items')->select('product_name')->where('id',$itemData->item_id)->first();
          return $productName->product_name;
        }
        return false;
    }

    public static function orderProductDetails($post, $transactionType){
      $details = Session::get('cartDetails');
      foreach ($details['cart_items'] as $cartData){
        if (!empty($cartData['option_value_id'])){
          foreach ($cartData['attribute_id'] as $key => $value){
            $orderProduct = new OrderProduct;
            $orderProduct->order_id = $post['order_id'];
            $orderProduct->category_id = $cartData['category_id'];
            $orderProduct->attribute_id = $cartData['attribute_id'][$key];
            $orderProduct->option_value_id = $cartData['option_value_id'][$key];
            $orderProduct->price = $cartData['item_price'];
            $orderProduct->quantity = $cartData['quantity'];
            $orderProduct->product_image = $cartData['image'];
            $orderProduct->item_id = $cartData['itemId'];
            $save = $orderProduct->save();
          }
        } else{
          $orderProduct = new OrderProduct;
          $orderProduct->order_id = $post['order_id'];
          $orderProduct->category_id = $cartData['category_id'];
          $orderProduct->price = $cartData['item_price'];
          $orderProduct->quantity = $cartData['quantity'];
          $orderProduct->product_image = $cartData['image'];
          $orderProduct->item_id = $cartData['itemId'];
          $save = $orderProduct->save();
        }
      }
      if($save){
        $orderTransaction = OrderTransaction::orderTransactionDetails($post, $transactionType);
        return true;
      } else{
        return false;
      }
    }
    
    public static function getItemByOrderId($orderId){
        return $result = OrderProduct::where('order_id',$orderId)->get();
    }
    
    public static function getItemAttrByItemId($orderId,$itemId){
        return $result = OrderProduct::where(['order_id' => $orderId, 'item_id' => $itemId])->get();
    }
        
}
