<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Driver extends Model {

    public static function saveDriver($post) {  
        $driver = new Driver();
        $driver->first_name = $post['first_name'];
        $driver->last_name = $post['last_name'];
        $driver->phone_number = $post['phone_number'];
        $driver->email = $post['email'];
        $driver->profile_image = $post['profile_image'];
        $driver->license_image = $post['license_image'];
        $driver->vehicle_category_id = $post['vehicle_type'];
        $driver->license_number = $post['license_number'];
        $driver->vehicle_number = $post['vehicle_number'];
        $driver->vehicle_description = $post['vehicle_description'];
        if (($post['deliver_company'] == '') && ($post['deliver_company'] == null)  ) {            
            $driver->commission = $post['commission'];
        }else{
            $driver->deliver_company_id = $post['deliver_company'];            
        }
        if($driver->save()){
            return true;
        }else{
            return false;
        }
    }
    
    public static function getDriverDetailById($id){
        $drivers =  Driver::where('id',$id)->first();
        return $drivers;        
    }
}
