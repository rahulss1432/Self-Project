<?php

namespace App\Models;

use App\Models\Item;
use App\Models\VendorDetail;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    public static function getallVendorList(){
    	$vendorsList = VendorDetail::select('vendor_details.*','vendor_details.id as vendor_id','users.*','delivery_areas.polygon_name','business_types.business_name as type_name')
                              ->leftJoin('users','users.id','=','vendor_details.user_id')
                              ->leftJoin('delivery_areas','delivery_areas.id','=','vendor_details.delivery_location')
                              ->leftJoin('business_types','business_types.id','=','vendor_details.business_type')
                              ->where('users.user_type','=','vendor')
                              ->get();
    	if($vendorsList){
    		return $vendorsList;
    	} else{
    		return false;
    	}
    }

    public static function getVendorDetails($id){
        $vendorDetails = VendorDetail::select('vendor_details.*','vendor_details.id as vendor_id','users.*','delivery_areas.polygon_name','business_types.business_name as type_name')
                              ->leftJoin('users','users.id','=','vendor_details.user_id')
                              ->leftJoin('delivery_areas','delivery_areas.id','=','vendor_details.delivery_location')
                              ->leftJoin('business_types','business_types.id','=','vendor_details.business_type')
                              ->where('vendor_details.user_id','=',$id)
                              ->first();
        if($vendorDetails){
            return $vendorDetails;
        } else{
            return false;
        }
    }
}