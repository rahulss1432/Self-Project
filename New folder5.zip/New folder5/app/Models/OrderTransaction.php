<?php

namespace App\Models;

use Session;
use App\Models\OrderNotification;
use Illuminate\Database\Eloquent\Model;

class OrderTransaction extends Model {

    public function getOrder() {
        return $this->belongsTo('App\Models\Order', 'order_id');
    }

    // for vendor side Transaction Listing
    public static function getOrderTransactions($post) {
        $OrderTransaction = OrderTransaction::with('getOrder');
        if (isset($post['amount']) && $post['amount'] != '') {
            $OrderTransaction->where('amount', $post['amount']);
        }
        if (isset($post['driver']) && $post['driver'] != '') {
            $OrderTransaction->whereHas('getOrder', function($q) use ($post) {
                $q->where('driver_id', '=', $post['driver']);
            });
        }
        if (isset($post['status']) && $post['status'] != '') {
            $OrderTransaction->whereHas('getOrder', function($q) use ($post) {
                $q->where('order_state', '=', $post['status']);
            });
        }

        $OrderTransaction->orderBy('created_at', 'desc');
        $data = $OrderTransaction->paginate(10);
        return $data;
    }

    public static function orderTransactionDetails($post, $transactionType) {
        if (Session::get('voucherDetails') != "") {
            $details = Session::get('voucherDetails');
            $voucherId = $details['voucher_id'];
        } else {
            $details = Session::get('cartDetails');
            $voucherId = '';
        }
        $orderTransaction = new OrderTransaction;
        $orderTransaction->user_id = $details['customer_id'];
        $orderTransaction->order_id = $post['order_id'];
        if ($voucherId != '') {
            $orderTransaction->voucher_id = $voucherId;
        }
        $orderTransaction->amount = $post['payment_gross'];
        if (isset($post['txn_id'])) {
            $orderTransaction->transaction_id = $post['txn_id'];
        }
        $orderTransaction->transaction_type = $transactionType;
        if ($orderTransaction->save()) {
            $orderNotifications = OrderNotification::sendOrderNotification($post, $details);
            return true;
        } else {
            return false;
        }
    }

    public static function getAllOrderTransactions($post) {
        $OrderTransaction = OrderTransaction::with('getOrder');
        $OrderTransaction->orderBy('created_at', 'desc');
        $data = $OrderTransaction->paginate(10);
        return $data;
    }

    public static function getTransactionById($id) {
        $getTransaction = OrderTransaction::where('id', $id)->first();
        return $getTransaction;
    }

}
