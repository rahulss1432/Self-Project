<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class UserAddress extends Model {

    public static function getAlladdress($post) {
        $userId = Auth::User()->id;
        $addressData = self::select('user_addresses.*');
        $addressData->where('user_id', '=', $userId);
        if (isset($post['search']) && !empty($post['search'])) {
            $addressData = $addressData->where(function ($query) {
                $text = Input::get('search');
                $query->where(DB::raw('address'), 'like', '%' . $text . '%');
            });
        }

        $addressData = $addressData->orderBy('user_addresses.created_at', 'desc');
        $data = $addressData->paginate(10);
        return $data;
    }

    public static function saveAddress($post) {
        $model = new UserAddress();
        $model->user_id = Auth::User()->id;
        $model->address = ucwords(strtolower($post['address']));
        $model->latitude = (isset($post['addressLat']) ? $post['addressLat'] : '');
        $model->longitude = (isset($post['addressLong']) ? $post['addressLong'] : '');
        if (isset($post['default']) || !empty($post['default'])) {
            $userId = Auth::User()->id;
            $model1 = UserAddress::where('user_id', $userId)->get();
            foreach ($model1 as $model1) {
                $model1->default = 'false';
                $model1->save();
            }
            $model->default = 'true';
        } else {
            $model->default = 'false';
        }
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function deleteAddress($id) {
        $model = UserAddress::where('id', $id)->first();
        if ($model) {
            if ($model->delete()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static function updateAddress($post) {
        $model = UserAddress::where('id', $post['addressId'])->first();
        if ($model) {
            $model->address = ucwords(strtolower($post['address']));
            $model->latitude = (isset($post['addressLat']) ? $post['addressLat'] : '');
            $model->longitude = (isset($post['addressLong']) ? $post['addressLong'] : '');
            if ($model->save()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static function updateDefaultAddress($id) {
        $model = UserAddress::where('id', $id)->first();
        if ($model) {
            if ($model->default = 'true') {
                $default = 'false';
            }
            if ($model->default = 'false') {
                $userId = Auth::User()->id;
                $model1 = UserAddress::where('user_id', $userId)->get();
                foreach ($model1 as $model1) {
                    $model1->default = 'false';
                    $model1->save();
                }
                $default = 'true';
            }
            $model->default = $default;
            if ($model->save()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

}
