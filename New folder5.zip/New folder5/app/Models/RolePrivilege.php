<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RolePrivilege extends Model {

    public static function getAllPrivilegesList($request) {
        $list = RolePrivilege::select('role_privileges.*', 'role_privileges.id as priv_id', 'role_privileges.status as priv_status', 'privileges.*', 'user_roles.id as role_id', 'user_roles.parent_id', 'user_roles.role')
                ->leftJoin('privileges', 'privileges.id', '=', 'role_privileges.privilege_id')
                ->leftJoin('user_roles', 'user_roles.id', '=', 'role_privileges.role_id')
                ->where('role_privileges.role_id', '=', $request->id)
                ->where('privileges.name', '!=', 'Permissions')
                ->get();
        if ($list) {
            return $list;
        } else {
            return false;
        }
    }

    public static function allPrivilegesUpdate($post) {
        $cancel = RolePrivilege::where('role_id', '=', $post['role_id'])->where('id', '!=', 35)->update(['status' => 'cancel']);
        if (!empty($post['status'])) {
            foreach ($post['status'] as $value) {
                $model = RolePrivilege::where('id', $value)->first();
                $model->status = 'active';
                $model->save();
            }
        }
        return true;
    }

}
