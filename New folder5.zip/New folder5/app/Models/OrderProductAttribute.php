<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Session;

class OrderProductAttribute extends Model
{
    public static function saveOrderProductAttribute($post, $transactionType)
    {
    	$details = Session::get('cartDetails');
    	foreach ($details['cart_items'] as $cartData)
      	{
	        if (!empty($cartData['option_value_id']))
	        {
	          	foreach ($cartData['attribute_id'] as $key => $value)
	          	{
		            $OrderProductAttribute = new OrderProductAttribute;
		            $OrderProductAttribute->order_id = $post['order_id'];
		            $OrderProductAttribute->order_products_id = $post['order_product_id'];
		            $OrderProductAttribute->item_id = $cartData['itemId'];
		            $OrderProductAttribute->attribute_id = $cartData['attribute_id'][$key];
		            $OrderProductAttribute->option_value_id = $cartData['option_value_id'][$key];
		            $save = $OrderProductAttribute->save();
		            
	          	}
	          	if($save){
		            	$order_transaction = OrderTransaction::orderTransactionDetails($post, $transactionType);
		        		return true;
	            }else{
		            	return false;
		            }
        	}

        }
    }
}
