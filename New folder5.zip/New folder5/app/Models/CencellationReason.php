<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CencellationReason extends Model {

    public static function getAllReasons() {
        $data = CencellationReason::paginate(10);
        return $data;
    }

    public static function saveCancellationReasons($post) {
        if (!empty($post['reasons'])) {
            foreach ($post['reasons'] as $key => $value) {
                $model = new CencellationReason();
                $model->reason = $post['reasons'][$key];
                $model->save();
            }
        }
        return TRUE;
    }
    
    public static function deleteCancellationReasonById($id){
        $result = CencellationReason::where(['id' => $id])->first();
        if(!empty($result)){
            $result->delete();
            return true;
        }
    }
    
    public static function updateCancellationReason($post){
        $model = CencellationReason::where(['id' => $post['id']])->first();
        if(!empty($model)){
            $model->reason = $post['reason'];
            $model->save();
            return true;
        }  else {
            return false;    
        }
    }

}
