<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Content extends Model {

    public static function saveContents($post) {
        $model = new Content();
        $model->page_title = $post['page_title'];
        $model->description = $post['description'];
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function getAllContents($post) {
        $contentData = Content::orderBy('created_at', 'desc');
        $contentData = $contentData->paginate(10);
        return $contentData;
    }

    public static function updateContents($post) {
        $cntId = $post['contentId'];
        $model = Content::where('id', $cntId)->first();
        $model->page_title = $post['page_title'];
        $model->description = $post['description'];
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

}
