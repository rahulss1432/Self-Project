<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;

class Voucher extends Model {

    public static function saveVouchers($post) {
        $model = new Voucher();
        $model->voucher_desc = $post['voucher_description'];
        $model->voucher_amount = $post['voucher_amount'];
        $model->voucher_type = $post['voucher_type'];
        $model->max_use = $post['max_use'];
        $model->start_date = date('Y-m-d', strtotime($post['start_date']));
        $model->end_date = date('Y-m-d', strtotime($post['end_date']));
        $model->voucher_status = $post['voucher_status'];
        $model->vendor_id = $post['vendor_id'];
        $model->voucher_code = $post['voucher_code'];
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function getAllVouchers($post) {
        $voucherData = Voucher::orderBy('created_at', 'desc');
        $voucherData = $voucherData->paginate(10);
        return $voucherData;
    }

    public static function deleteVouchers($post) {
        $attr = Voucher::where('id', $post['id'])->first();
        if ($attr->delete()) {
            return 1;
        } else {
            return 0;
        }
    }

    public static function updateVouchers($post) {
        $voucherid = $post['voucherId'];
        $model = Voucher::where('id', $voucherid)->first();
        $model->voucher_desc = $post['voucher_description'];
        $model->voucher_amount = $post['voucher_amount'];
        $model->voucher_type = $post['voucher_type'];
        $model->max_use = $post['max_use'];
        $model->start_date = date('Y-m-d', strtotime($post['start_date']));
        $model->end_date = date('Y-m-d', strtotime($post['end_date']));
        $model->voucher_status = $post['voucher_status'];
        $model->vendor_id = $post['vendor_id'];
        $model->voucher_code = $post['voucher_code'];
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function getVoucherDetails($request){
        $voucherDetails = Voucher::where('voucher_code','=',$request->voucher)
                                 ->where('vendor_id','=',$request->vendorId)
                                 ->where('end_date','>=',DB::raw('CURDATE()'))
                                 ->first();
        if($voucherDetails){
            return $voucherDetails;
        } else{
            return false;
        }
    }
}