<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Helpers\Helper;

class OrderNotification extends Model {

    protected $fillable = ['order_id', 'from_id', 'to_id', 'message', 'status', 'subject'];

    public function order() {
        return $this->belongsTo('App\Models\Order', 'order_id');
    }

    public function user() {
        return $this->belongsTo('App\Models\User', 'from_id');
    }    

    /* for driver side all nofications listing (function may be use after checking conditions) */
    /*
      public static function getAllNotifications($toId, $post) {
      $user = User::where('user_type', 'admin')->first();         // notification which status are pending or status is running if send by admin
      $query = OrderNotification::Join('orders', 'order_notifications.order_id', 'orders.id')
      ->select('orders.*', 'order_notifications.*', 'order_notifications.created_at as notification_date')
      ->where('orders.order_state', 'pending')
      ->where('order_notifications.to_id', $toId)
      ->orWhere(function ($query) use ($toId, $user) {
      $query->where('orders.order_state', 'running')
      ->where('order_notifications.from_id', $user->id)
      ->where('order_notifications.to_id', $toId);
      })
      ->orderBy('order_notifications.created_at', 'desc');
      //        if ($post['call_from'] == 'home_page' || $post['call_from'] == 'notification_count') {
      //            $notifications = $query->get();
      //        } else {
      $notifications = $query->paginate(10);
      //        }
      return $notifications;
      }
     */
    /* for vendor side nofications */

    public static function getAllNotificationsBytoId($toId, $post) {
        $query = OrderNotification::Join('orders', 'order_notifications.order_id', 'orders.id')
                ->select('orders.*', 'order_notifications.*', 'order_notifications.created_at as notification_date')
                ->where('order_notifications.to_id', $toId)
                ->orderBy('order_notifications.created_at', 'desc');
        if ($post['call_from'] == 'home_page' || $post['call_from'] == 'notification_count') {
            $notifications = $query->get();
        } else {
            $notifications = $query->paginate(10);
        }
        return $notifications;
    }

    public static function getAllNotificationsByIdcount($id) {
        $notifications = OrderNotification::where('to_id', $id)
                        ->where('status', 'unread')->get();
        return $notifications;
    }

    public static function changeNotificationStatus() {
        if (!Auth::guard('admin')->check()) {
            $userId = Auth::user()->id;
        } else {
            $userId = Auth::guard('admin')->user()->id;
        }
        $result = OrderNotification::where('to_id', $userId)
                ->where('status', 'unread')
                ->update(['status' => 'read']);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    /* end vendor side nofications */

    public static function getNotificationById($id) {
        $notifications = OrderNotification::where('id', $id)->first();
        return $notifications;
    }

    public static function changeStatus($id,$status) {
        $notifications = OrderNotification::where('id', $id)->first();
        $notifications->status = $status;
        if ($notifications->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function deleteNotification($id) {
        $notifications = OrderNotification::where('id', $id)->delete();
        if ($notifications) {
            return true;
        } else {
            return false;
        }
    }

    // for vendor side reject order from vendor
    public static function saveRejectOrder($id, $customerid) {
        $fromid = Auth::User()->id;
        $notification = new OrderNotification();
        $notification->order_id = $id;
        $notification->from_id = $fromid;
        $notification->to_id = $customerid;
        $notification->message = 'your order has been rejected by ' . Helper::getBusinessNameById($fromid);
        if ($notification->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function sendNotificationtodrivers($orderid) {
        $allDrivers = User::assignDriver();
        $fromId = Auth::User()->id;
        if ($allDrivers->count() > 0) {
            foreach ($allDrivers as $allDriver) {
                $notification = new OrderNotification();
                $notification->order_id = $orderid;
                $notification->from_id = $fromId;
                $notification->to_id = $allDriver->id;
                $notification->message = 'new order request.';
                $notification->save();
            }
        }
        return true;
    }

    public static function sendNotificationtocustomer($orderid, $customerid) {
        $fromId = Auth::User()->id;
        $notification = new OrderNotification();
        $notification->order_id = $orderid;
        $notification->from_id = $fromId;
        $notification->to_id = $customerid;
        $notification->message = 'Vendor accepted your order.';
        $notification->save();
        return true;
    }

    public static function saveDriverAcceptanceNotification($post) {
        $notification = new OrderNotification();
        $notification->order_id = $post->order->id;
        $notification->from_id = $post->to_id;
        $notification->to_id = $post->order->customer_id;   /* notification sends to customer */
        $notification->subject = 'Order Placed';
        $notification->message = 'your order placed successfully';
        if ($notification->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function sendOrderNotification($post, $details) {
        foreach ($details['cart_items'] as $cartData) {
            $vendorId = $cartData['business_id'];
        }
        $user = User::select('users.*')
                ->leftJoin('orders', 'orders.driver_id', '=', 'users.id');
        $user = $user->where(function($q) {
            $q->orWhere('orders.order_state', '=', 'completed')
                    ->orWhereNull('orders.driver_id');
        });
        $user = $user->where('users.user_type', '=', 'driver')->get();
        $sentTo = array();
        foreach ($user as $driver) {
            array_push($sentTo, $driver->id);
        }
        $adminData = User::where('user_type', '=', 'admin')->where('role', '=', 'admin')->first();
        $vendorData = VendorDetail::where('user_id', '=', $vendorId)->first();
        if ($vendorData) {
            $vendorStatus = $vendorData->vendor_acceptance;
        }
        if ($vendorStatus == 'yes') {
            $vendorNotification = new OrderNotification;
            $vendorNotification->order_id = $post['order_id'];
            $vendorNotification->from_id = $details['customer_id'];
            $vendorNotification->to_id = $vendorId;
            $vendorNotification->subject = 'Order Request';
            $vendorNotification->message = 'You have a new order pending to approval';
            $saveNotification = $vendorNotification->save();

            $adminNotification = new OrderNotification;
            $adminNotification->order_id = $post['order_id'];
            $adminNotification->from_id = $details['customer_id'];
            $adminNotification->to_id = $adminData->id;
            $adminNotification->subject = 'Order Request';
            $adminNotification->message = 'Vendor has a new notification of order for approval';
            $saveAdminNotification = $adminNotification->save();
            if ($saveNotification && $saveAdminNotification) {
                return true;
            } else {
                return false;
            }
        } else {
            if (!empty($sentTo)) {
                foreach ($sentTo as $to) {
                    $driverNotification = new OrderNotification;
                    $driverNotification->order_id = $post['order_id'];
                    $driverNotification->from_id = $details['customer_id'];
                    $driverNotification->to_id = $to;
                    $driverNotification->subject = 'Order Request';
                    $driverNotification->message = 'You have a new notification to take order for delivery';
                    $saveNotification = $driverNotification->save();
                }
                $adminNotification = new OrderNotification;
                $adminNotification->order_id = $post['order_id'];
                $adminNotification->from_id = $details['customer_id'];
                $adminNotification->to_id = $adminData->id;
                $adminNotification->subject = 'New Order';
                $adminNotification->message = 'New order has been placed in marketplace';
                $saveAdminNotification = $adminNotification->save();
                if ($saveNotification && $saveAdminNotification) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }

    public static function getAllNotificationsById($id) {
        $notifications = OrderNotification::where('to_id', $id)->where('status','!=','deleted')->orderBy('created_at', 'desc')->paginate(10);
        return $notifications;
    }

    public static function sendOrderNotificationById($orderid, $driverid) {
        $userId = Auth::guard('admin')->user()->id;
        $notification = new OrderNotification();
        $notification->order_id = $orderid;
        $notification->from_id = $userId;
        $notification->to_id = $driverid;
        $notification->subject = 'New order assigned';
        $notification->message = 'You have new order to deliver';
        if ($notification->save()) {
            return true;
        } else {
            return false;
        }
    }

    /* function for sending notification to customer by logged in user */

    public static function sendOrderNotificationToCustomer($orderId, $customerId, $data) {
        $fromId = Auth::User()->id;
        $notification = new OrderNotification();
        $notification->order_id = $orderId;
        $notification->from_id = $fromId;
        $notification->to_id = $customerId;
        $notification->subject = $data['subject'];
        $notification->message = $data['message'];
        if ($notification->save()) {
            return true;
        } else {
            return false;
        }
    }

    /* function for sending notification to driver for rating */

    public static function sendNotificationtodriver($orderid, $driverid) {
        $fromid = Auth::User()->id;
        $notification = new OrderNotification();
        $notification->order_id = $orderid;
        $notification->from_id = $fromid;
        $notification->to_id = $driverid;
        $notification->subject = 'Rating';
        $notification->message = 'You Have Get Rating By ' . Helper::getBusinessNameById($fromid);
        if ($notification->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function sendNotificationToAdmin($post) {
        $user = User::where('user_type', 'admin')->first();
        if (!empty($user)) {
            $data = [];
            $data['to_id'] = $user->id;
            $data['from_id'] = $user->id;
            $data['order_id'] = $post->id;
            $data['subject'] = 'Assinging Driver';
            $data['message'] = 'Still driver not assigned';
            $notification = OrderNotification::firstOrCreate($data);
            if (!empty($notification)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static function deleteSentNotificationToDriver($orderId, $driverId) {
        $notifications = OrderNotification::Join('users', 'order_notifications.to_id', 'users.id')
                ->select('order_notifications.*')
                ->where('users.user_type', '=', 'driver')
                ->where('order_notifications.order_id', '=', $orderId)
                ->where('order_notifications.to_id', '!=', $driverId)
                ->get();
        if (!empty($notifications)) {
            foreach ($notifications as $data) {
                $deleteNotification = OrderNotification::where('order_id',$data->order_id)->where('to_id',$data->to_id)->delete();
                if($deleteNotification){
                    continue;
                }else{
                    return false;
                }
            }
        }
        return true;
    }

}
