<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use \Illuminate\Support\Facades\Input;

class DeliveryArea extends Model {

    public static function saveDeliveryLocation($post) {
        $polygonLatLong = "";
        $query = "(";
        $i = 0;
        foreach ($post['polyGon'] as $val) {
            if ($i == 0) {
                $query.= $val . ")";
                $polygonLatLong.= $val;
                $break = $val;
            } else {
                $query.= ",(" . $val . ")";
                $polygonLatLong.="," . $val;
            }
            $i++;
        }
        $polygonLatLong.= "," . $break;
        $sql = DB::insert("INSERT delivery_areas (`polygon_attributes`,`poly_lat_long`,`polygon_lat_long`,`polygon_name`,`shipping_charges`,`heading_id`) VALUES (ST_GeomFromText('POLYGON({$query})'),'{$query}','{$polygonLatLong}','{$post['mapLocation']}','{$post['price']}','{$post['selHeading']}')");
        if($sql){
            return true;
        }else{
            return false;
        }
    }
    
    public static function updateDeliveryLocation($post) {
        $query = "(";
        $poly_lat_long = "";
        $i = 0;
        if (!empty($post['polyGon'])) {
            foreach ($post['polyGon'] as $val) {
                if ($i == 0) {
                    $query.= $val . ")";
                    $poly_lat_long.= $val;
                    $first_point = $val;
                } else {
                    $query.= ",(" . $val . ")";
                    $poly_lat_long.=",".$val;
                }
                $i++;
            }
            $poly_lat_long.= ",".$first_point;
            $model = DB::update("UPDATE `delivery_areas` SET `polygon_attributes`=ST_GeomFromText('POLYGON({$query})'),`poly_lat_long`='{$query}',`polygon_lat_long`='({$poly_lat_long})',`polygon_name`='{$post['mapLocation']}',`shipping_charges`= '{$post['price']}' ,`heading_id`='{$post['selHeading']}' where id='{$post['mapLocationId']}'");
        } else {
            $model = DB::update("UPDATE `delivery_areas` SET `polygon_name`='{$post['mapLocation']}',`shipping_charges`= '{$post['price']}',`heading_id`='{$post['selHeading']}' where id='{$post['mapLocationId']}'");
        }
        return true;
    }

    public static function getAllLocations($post) {
        $data = DeliveryArea::select('delivery_areas.*');
        if (isset($post['search']) && !empty($post['search'])) {
            $data->where(function ($query) {
                $text = Input::get('search');
                $query->where('polygon_name', 'like', '%' . $text . '%');
            });
        }
        $result = $data->orderBy('id', 'desc')->paginate(10);
        return $result;
    }

    public static function deleteLocationById($id) {
        $model = DeliveryArea::where('id', $id)->first();
        if ($model->delete()) {
            return true;
        } else {
            return false;
        }
    }

    public static function actionLoadMap() {
        $result = DeliveryArea::all();
        $rsl = array();
        foreach ($result as $val) {
            $removeComma = explode(",", $val->poly_lat_long);
            $data = array();
            foreach ($removeComma as $brackets) {
                $string = trim($brackets, '(');
                $string = trim($string, ')');
                $data[] = $string;
            }
            $rsl[] = $data;
        }
        return $rsl;
    }

    public static function actionSingalLocation($id) {
        $result = DeliveryArea::where('id', $id)->first();
        $rsl = array();
        //foreach ($result as $val) {
        $removeComma = explode(",", $result->poly_lat_long);
        $data = array();
        foreach ($removeComma as $brackets) {
            $string = trim($brackets, '(');
            $string = trim($string, ')');
            $data[] = $string;
        }
        $rsl[] = $data;
        // }
        return $rsl;
    }
    
//    public static function getPolyGonLatLong(){
//        return $model = DeliveryArea::select('polygon_lat_long')->get();    
//    }
}
