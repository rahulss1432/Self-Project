<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use App\Admin\Http\Requests\EditDeliverCompanyRequest;

class DeliverCompany extends Model {

    public static function getAllCompanies() {
        $result = DeliverCompany::get();
        return $result;
    }

    public static function getCompanyById($id) {
        $company = DeliverCompany::where('id', $id)->first();
        return $company;
    }

    public static function saveDeliverCompany($post) {
        $model = new DeliverCompany();
        $model->name = ucwords(strtolower($post['name']));
        $model->commission = $post['commission'];
        $model->contact_email = $post['contact_email'];
        $model->contact_mobile = $post['contact_mobile'];
        $model->contact_name = ucwords(strtolower($post['contact_name']));
//        $model->commission_type = $post['commission_type'];
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function getAllDeliverCompanies($post) {
        $result = DeliverCompany::select('deliver_companies.*');

        if (isset($post['company']) && $post['company'] != '') {
            $result->where('name', 'like', '%' . $post['company'] . '%');
        }

        $result->orderBy('deliver_companies.id', 'desc');
        $data = $result->paginate(10);
        return $data;
    }

    public static function deleteDeliverCompany($id) {
        $model = DeliverCompany::where('id', $id)->first();
        if ($model->delete()) {
            return true;
        } else {
            return false;
        }
    }

    public static function editDeliverCompany($id) {
        $companyData = DeliverCompany::where('id', $id)->first();
        return $companyData;
    }

    public static function updateDeliverCompany($post) {
        $model = DeliverCompany::where('id', $post['companyId'])->first();
        $model->name = ucwords(strtolower($post['name']));
        $model->commission = $post['commission'];
        $model->contact_email = $post['contact_email'];
        $model->contact_mobile = $post['contact_mobile'];
        $model->contact_name = ucwords(strtolower($post['contact_name']));
//        $model->commission_type = $post['commission_type'];
        if ($model->save()) {
            return true;
        } else {
            return false;
        }
    }

    public static function getRemainingAmountById($id) {
        $data = DeliverCompany::where('id', $id)->first();
        if (!empty($data)) {
            return $data->remaining_amount;
        }
        return false;
    }

}
