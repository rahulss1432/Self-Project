<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorDetail extends Model {

    public function businessType() {
        return $this->belongsTo('App\Models\BusinessType', 'business_type');
    }

}
