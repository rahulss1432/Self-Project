<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DriverDetail extends Model {

    public function user() {
        return $this->belongsTo('App\Models\User');
    }
    
    public function getDriver() {
        return $this->hasOne('App\Models\User', 'id', 'user_id');
    }
    /*relation for get Vehicle Category name from VehicleCategory belongs to driverDetail*/
    public function vehicleCategory() {
        return $this->belongsTo('App\Models\VehicleCategory','vehicle_category_id');
    }    
    
    /*relation for get DeliverCompany name from VehicleCategory belongs to driverDetail*/
    public function deliverCompany() {
        return $this->belongsTo('App\Models\DeliverCompany','deliver_company_id');
    }   
     public function getVehicleData() {
        return $this->hasOne('App\Models\VehicleCategory', 'id', 'vehicle_category_id');
    }

    /*function may be use in future to create new driver if admin's all users used common function for create in user modal*/
    public static function saveDriverDetails($post, $user) {
        $driver = new DriverDetail();
        $driver->user_id = $user->id;
        $driver->vehicle_category_id = $post['vehicle_type'];
        $driver->license_image = $post['license_image'];
        $driver->license_number = $post['license_number'];
        $driver->vehicle_number = $post['vehicle_number'];
        $driver->vehicle_description = $post['vehicle_description'];
        if (($post['deliver_company'] == '') && ($post['deliver_company'] == null)) {
            $driver->commission = $post['commission'];
            $driver->commission_type = $post['commission_type'];
        } else {
            $driver->deliver_company_id = $post['deliver_company'];
        }
        if ($driver->save()) {
            return true;
        } else {
            return false;
        }
    }
    public static function getAllDriversForTracking(){
        $model = DriverDetail::get();
        return $model; 
    }
    
    public static function getVehicleDeatail($id){
        $vehicleDetail = DriverDetail::where('user_id',$id)->first();
        if($vehicleDetail){
         return $vehicleDetail; 
        }
        return false;
    }
    

}
