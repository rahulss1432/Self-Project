<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Faq extends Model
{
  public static function getAllFaqsList($request) {
    $faq = Faq::where('question','!=',NULL);
    if (!empty($request['ques'])) {
      $faq->where('question', 'like', '%' . $request['ques'] . '%');
    }
    if (!empty($request['ans'])) {
      $faq->where('answer', 'like', '%' . $request['ans'] . '%');
    }
    $result = $faq->orderBy('id', 'desc')->paginate(10);
    if ($result){
      return $result;
    } else {
      return false;
    }
  }

  public static function createFaq($request) {
    $faq = new Faq;
    $faq->question = $request->question;
    $faq->answer = $request->answer;
    $result = $faq->save();
    if ($result) {
      return true;
    } else {
      return false;
    }
  }

  public static function faqUpdate($request) {
    $model = Faq::where('id',$request->id)->first();
    if(!empty($model)) {
      $model->question = $request['question'];
      $model->answer = $request['answer'];
      $result = $model->update();
    }
    if ($result) {
      return true;
    } else {
      return false;    
    }
  }
}