<?php

namespace App\Http\Controllers\driver;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\DeliverCompany;
use App\Models\VehicleCategory;
use App\Models\OrderNotification;
use App\Models\Order;
use App\Http\Requests\EditDriverRequest;
use App\Http\Requests\ChangeLocationRequest;
use File;
use Image;
use View;
use Illuminate\Support\Facades\Response;
use App\Http\Requests\DriverChangePasswordRequest;

class DashboardController extends Controller {

    public function index() {
        return view('driver.dashboard');
    }

    public function viewProfile() {
        $userId = Auth::guard()->user()->id;
        $driver = User::getDriverDetailById($userId);
        return view('driver.view_profile', compact('driver'));
    }

    public function showEditProfileForm() {
        $userId = Auth::guard()->user()->id;
        $driver = User::getDriverDetailById($userId);
        if (!empty($driver)) {
            $deliverCompanies = DeliverCompany::getAllCompanies();
            $vehicleCategories = VehicleCategory::getAllCategories();
            if (!empty($deliverCompanies)) {
                if (!empty($vehicleCategories)) {
                    return view('driver.edit_profile', compact('deliverCompanies', 'vehicleCategories', 'driver'));
                } else {
                    session()->flash('error', 'error');
                    session()->flash('error', \Config::get('constants.failed_categories'));
                    return redirect()->back();
                }
            } else {
                session()->flash('error', 'error');
                session()->flash('error', \Config::get('constants.failed_companies'));
                return redirect()->back();
            }
        } else {
            abort(404);
        }
    }

    /* uplaoad image and cropper functions */

    public function uploadProfileImage(Request $request) {

        $file = $request->file('profile_picture');
        $userProfileTempPath = public_path() . '/uploads/temp-image';
        if (!is_dir($userProfileTempPath)) {
            File::makeDirectory($userProfileTempPath, $mode = 0777, true, true);
        }
        $fileName = $file->getClientOriginalName();
        $fileExtendedName = time() . $fileName;
        if ($request->file('profile_picture')->move($userProfileTempPath, $fileExtendedName)) {
            return Response::Json(['success' => true, 'filename' => $fileExtendedName]);
        } else {
            return Response::Json(['success' => false, 'message' => \Config::get('constants.failed_upload')]);
        }
    }

    public function uploadLicenseImage(Request $request) {
        $file = $request->file('license_picture');
        $licenseUploadTempPath = public_path() . '/uploads/temp-image';
        if (!is_dir($licenseUploadTempPath)) {
            File::makeDirectory($licenseUploadTempPath, $mode = 0777, true, true);
        }
        $fileName = $file->getClientOriginalName();
        $fileExtendedName = time() . $fileName;
        if ($request->file('license_picture')->move($licenseUploadTempPath, $fileExtendedName)) {
            return Response::Json(['success' => true, 'filename' => $fileExtendedName]);
        } else {
            return Response::Json(['success' => false, 'message' => \Config::get('constants.failed_upload')]);
        }
    }

    public function loadImageCropper(Request $request) {
        $post = $request->all();
        $html = View::make('driver._load_image_cropper', ['imageName' => $post['imageName'], 'imageType' => $post['imageType']])->render();
        return Response::json(['html' => $html]);
    }

    /* uplaoad image and cropper functions ends */

    public function uploadCroppedPicture(Request $request) {
        $post = $request->all();
        if ($post['imageType'] == 'license-type-image') {

            $cropImgPath = base_path() . '/public/uploads/license-pictures/';
            if (!is_dir($cropImgPath)) {
                mkdir($cropImgPath, 0777, true);
            }
        } elseif ($post['imageType'] == 'profile-type-image') {

            $cropImgPath = base_path() . '/public/uploads/profile-pictures/';
            if (!is_dir($cropImgPath)) {
                mkdir($cropImgPath, 0777, true);
            }
        }
        $origanlImage = base_path() . '/public/uploads/temp-image/' . $post['imageName'];
        $destinationPath = $cropImgPath . $post['imageName'];
        $img = Image::make($origanlImage);
        $croppedImage = $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']));
        $croppedImage->save($destinationPath);
        unlink($origanlImage);
        return $post['imageName'];
    }

    public function updateProfile(EditDriverRequest $request) {
        $driver = User::updateDriver($request->all());
        if ($driver) {
            session()->flash('success', 'success');
            session()->flash('success', \Config::get('constants.driver_updated'));
            return redirect('/driver/view-profile');
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('/driver/view-profile');
        }
    }

    public function viewAllNotifications() {
        $status = OrderNotification::changeNotificationStatus();
        return view('driver.all_notifications');
    }

    /* notification on all nofication page */

    public function loadAllNotifications(Request $request) {
        $post = $request->all();
        $userId = Auth::guard()->user()->id;
//        $notifications = OrderNotification::getAllNotifications($userId, $post);
        $notifications = OrderNotification::getAllNotificationsBytoId($userId, $post);
        if (!empty($notifications)) {
            $html = View::make('driver._load_all_notification_list', compact('notifications', 'post'))->render();
            return Response::json(['success' => true, 'html' => $html]);
        } else {
            return Response::json(['success' => false, 'message' => 'failed to load']);
        }
    }

    public function acceptOrder($id) {
        $userId = Auth::guard()->user()->id;
        $notification = OrderNotification::getNotificationById($id);
        if (!empty($notification)) {
            $changeNotificationStatus = OrderNotification::changeStatus($id,'read');       /* change unread to read */
            if ($changeNotificationStatus) {
                $orderAssign = Order::assignDriverOnorder($notification->order_id, $notification->to_id);   /* change order table driver id and status to running */
                if ($orderAssign) {
                    $saveNotification = OrderNotification::saveDriverAcceptanceNotification($notification);     /* driver accepted order */
                    if ($saveNotification) {
                        $driversNotification = OrderNotification::deleteSentNotificationToDriver($notification->order_id, $userId);
                        return Response::json(['success' => true, 'message' => \Config::get('constants.accept_order')]);
                    } else {
                        return Response::json(['success' => false, 'message' => \Config::get('constants.failed_send_accept_notification')]);
                    }
                } else {
                    return Response::json(['success' => false, 'message' => \Config::get('constants.failed_accept_order')]);
                }
            } else {
                return Response::json(['success' => false, 'message' => \Config::get('constants.failed_change_status')]);
            }
        } else {
            return abort(404);
        }
    }

    public function driverOrderList() {
        return view('driver.orders_lists');
    }

    public function loadRunningOrders(Request $request) {
        $runningOrderData = User::driverRunningOrderDetails();
        $html = View::make('driver._load_running_orders', ['runningOrderData' => $runningOrderData])->render();
        return Response::json(['html' => $html, 'runningOrderData' => $runningOrderData]);
    }

    public function loadCompleteOrders(Request $request) {
        $completeOrderData = User::driverCompleteOrderDetails();
        $html = View::make('driver._load_complete_orders', ['completeOrderData' => $completeOrderData])->render();
        return Response::json(['html' => $html, 'completeOrderData' => $completeOrderData]);
    }

    public function rejectOrder($id) {
        $notification = OrderNotification::deleteNotification($id);
        if ($notification) {
            return Response::json(['success' => true, 'message' => \Config::get('constants.reject_order')]);
        } else {
            return Response::json(['success' => false, 'message' => \Config::get('constants.something_wrong')]);
        }
    }

    public function viewOrderByDriverNotification($id) {
        $result = Order::getOrderById($id);
        if (!empty($result)) {
            $transactionData = \App\Models\OrderTransaction::where('order_id', $result->id)->first();
            if (!empty($transactionData)) {
                return view('driver.detail_order', ['orderData' => $result, 'transactionData' => $transactionData]);
            } else {
                return view('driver.detail_order', ['orderData' => $result]);
            }
        } else {
            abort(404);
        }
    }

    public function changeOrderState(Request $request) {
        $post = $request->all();
        $result = Order::changeOrderState($post);
        if ($result) {
            if ($post['status'] == 'completed') {
                return Response()->json(['success' => true, 'message' => \Config::get('constants.change_status')]);
            } elseif ($post['status'] == 'out_for_pickup') {
                $data['subject'] = 'Order out for pickup';
                $data['message'] = 'Your order out for pickup from the vendor';
            } else {
                $data['subject'] = 'Order out for delivery';
                $data['message'] = 'Your order out for delivery';
            }
            $notification = OrderNotification::sendOrderNotificationToCustomer($post['id'], $post['customerId'], $data);
            if ($notification) {
                return Response()->json(['success' => true, 'message' => \Config::get('constants.change_status')]);
            } else {
                return Response()->json(['success' => false, 'message' => \Config::get('constants.failed_to_send_notification')]);
            }
        } else {
            return Response()->json(['success' => false, 'message' => \Config::get('constants.failed_change_status')]);
        }
    }

    public function driverOrderRatingList() {
        return view('driver.order_ratings');
    }

    public function loadOrderRatingList(Request $request) {
        $orderRatings = Order::getAllOrderRating();
        $html = View::make('driver._load_order_rating_list', ['orderRatings' => $orderRatings])->render();
        return Response::json(['html' => $html]);
    }

    public function changeCurrentLocation(ChangeLocationRequest $request) {
        $order = Order::saveCurrentLocationById($request->all());
        if ($order) {
            session()->flash('success', 'success');
            session()->flash('success', \Config::get('constants.location_updated'));
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.location_updated_failed'));
            return redirect()->back();
        }
    }

}
