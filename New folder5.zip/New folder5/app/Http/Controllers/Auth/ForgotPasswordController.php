<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use App\Http\Requests\SendResetEmailRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Helpers\Helper;
use App\Models\User;
class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }
    public function showLinkRequestForm() {
        return view('auth.passwords.forgot-password');
    }
     protected function validateEmail(Request $request) {
        $this->validate($request, ['email' => 'required|email']);
    }
    
     public function sendResetLinkEmail(SendResetEmailRequest $request) {
//         echo 'fdfdsdf';die;
        if (!empty($request)) {
            $post = $request->all();
            $model = User::findUserByEmail($post['email']);
            if (!empty($model)) {
                if ($model->is_active == 1) {
                    $token = User::generateRandomString();
                    $model->reset_password_token = $token;  /* save random string to user model's token field */

                    if ($model->save()) {
                        $data = array();
                        $data['request'] = 'forgot_password';
                        $data['email'] = $post['email'];
                        $data['name'] = $model->first_name . ' ' . $model->last_name;
                        $data['subject'] = 'Reset Password Link';
                        $data['link'] = url('password/reset/' . $token);
                        $data['token'] = $token;

                        $mail =Helper::sendMail($data); /* sending mail */

                        if ($mail) {
                            \Session::flash('success', 'success');
                            \Session::flash('success',  \Config::get('constants.email_instruction'));
                            return redirect('/password/reset');
                        }
                    }
                } else {
                    \Session::flash('success', 'success');
                    \Session::flash('success', \Config::get('constants.email_account_istruction'));
                    return redirect('/password/reset');
                }
            }
           
        }
    }
}
