<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Password;
use App\Models\User;
// use Illuminate\Support\Facades\Session;
use App\Http\Requests\ResetPasswordRequest;

class ResetPasswordController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Password Reset Controller
      |--------------------------------------------------------------------------
      |
      | This controller is responsible for handling password reset requests
      | and uses a simple trait to include this behavior. You're free to
      | explore this trait and override any methods you wish to tweak.
      |
     */

use ResetsPasswords;

    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest');
    }

    /**
     * Display the password reset view for the given token.
     *
     * If no token is present, display the link request form.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string|null  $token
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function showResetForm(Request $request, $token) {
        $tokenExist = User::where(['reset_password_token' => $token])->first();
        if ($tokenExist) {
            return view('auth.passwords.resetpassword')->with(['token' => $request->token]);
        } else {
            \Session::flash('error', 'error');
            \Session::flash('error.content', \Config::get('constants.reset_password'));
            return redirect('/login');
        }
    }

    /**
     * Reset the given user's password.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function reset(ResetPasswordRequest $request) {
        if (!empty($request->token)) { /* find user details by token */
            $model = User::findByToken($request->token);
            if (!empty($model)) {
                $model->password = bcrypt($request->password);  /* storing new password */
                $model->reset_password_token = null;                  /* reseting remember token as null */
                if ($model->save()) {
                    \Session::flash('success', 'success');
                    \Session::flash('success', \Config::get('constants.reset_password_status'));
                    return redirect('/login');
                } else {
                    \Session::flash('error', 'error');
                    \Session::flash('error',  \Config::get('constants.try_again'));
                    return redirect('/login');
                }
            } else {
                \Session::flash('error', 'error');
                \Session::flash('error', \Config::get('constants.try_again'));
                dd(request()->seesion('error'));
                return redirect('/login');
            }
        }
    }

}
