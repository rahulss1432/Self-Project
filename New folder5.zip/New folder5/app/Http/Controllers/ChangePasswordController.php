<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ChangePasswordRequest;
use App\Models\User;

class ChangePasswordController extends Controller
{
    public function ChangePasswordForm(){
        return view('change_password');
    }
      public function saveChangePassword(ChangePasswordRequest $request){
        $post = $request->all();
        $result = User::changeUserPassword($post);
        if ($result) {
            \Session::flash('success', 'success');
            \Session::flash('success', \Config::get('constants.change_password'));
            return redirect('change-password');
        }
        \Session::flash('error', 'error');
        \Session::flash('error',  \Config::get('constants.try_again'));
        return redirect()->back();
    }
}
