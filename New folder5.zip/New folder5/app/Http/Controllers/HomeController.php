<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\OrderNotification;
use App\Models\Setting;
use App\Models\Order;
use App\Models\Rating;
use Illuminate\Support\Facades\Response;

class HomeController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        if (Auth::guest()) {
            return view('home');
        }
        if (Auth::guard()->user()->user_type == 'driver') {
            return redirect('/driver/driver-dashboard');
        }
        if (Auth::guard()->user()->user_type == 'customer') {
            return redirect('/customer/customer-dashboard');
        }
        if (Auth::guard()->user()->user_type == 'vendor') {
            return redirect('/vendor-dashboard');
        }
    }

    public function checkOrderStatus() {
//        date_default_timezone_set('Asia/Kolkata');    /*  for current time zone */
        $timeInSeconds = 0;
        $orders = Order::getAllPendingOrders();
        $setting = Setting::getActiveSettingByKey('time_of_acceptance_of_driver');
        if (!empty($orders)) {
            if (!empty($setting)) {
                if ($setting->unit == 'second') {
                    $timeInSeconds = $setting->value;
                }
                if ($setting->unit == 'minute') {
                    $timeInSeconds = $setting->value * 60;
                }
                if ($setting->unit == 'hour') {
                    $timeInSeconds = $setting->value * 60 * 60;
                }
                foreach ($orders as $data) {
                    $currentTime = time();
                    $orderCreateTime = strtotime(date($data->created_at));
                    if (($currentTime - $orderCreateTime) > $timeInSeconds) {
                        $orderNotification = OrderNotification::sendNotificationToAdmin($data);
                        if ($orderNotification) {
                            continue;
                        } else {
                            return Response::json(['success' => false, 'message' => \Config::get('constants.failed_to_send_notification')]);
                        }
                    }
                }
                return Response::json(['success' => true, 'message' => \Config::get('constants.save_notification')]); 
            }
        } else {
            return Response::json(['success' => false, 'message' => \Config::get('constants.failed_to_load_order')]);
        }
    }

    public function deleteNotification($id) {
        $notification = OrderNotification::deleteNotification($id);
        if ($notification) {
            return Response::json(['success' => true, 'message' => \Config::get('constants.delete_notification')]);
        } else {
            return Response::json(['success' => false, 'message' => \Config::get('constants.something_wrong')]);
        }
    }

    public function saveDriverRating(Request $request) {
        $post = $request->all();
        $orderid = $post['orderId'];
        $driverid = $post['driverId'];
        $result = Rating::AddDriverRating($post);
        if ($result) {
            $notification = OrderNotification::sendNotificationtodriver($orderid, $driverid);
            if ($notification) {
                return Response::json(['success' => true, 'message' => \Config::get('constants.rating')]);
            } else {
                return Response::json(['success' => false, 'message' => \Config::get('constants.something_wrong')]);
            }
        } else {
            return Response::json(['success' => false, 'message' => \Config::get('constants.something_wrong')]);
        }
    }

}
