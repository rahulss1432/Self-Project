<?php

namespace App\Http\Controllers\customer;

use DB;
use Session;
use App\Models\User;
use App\Models\Item;
use App\Models\Order;
use App\Models\Voucher;
use App\Models\OptionValue;
use App\Models\UserAddress;
use Illuminate\Http\Request;
use App\Models\ItemAttribute;
use App\Models\WalletTransaction;
use App\Models\OrderNotification;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Requests\UpdateCustomerRequest;
use App\Http\Requests\ChangePasswordRequest;

class CustomerController extends Controller {

    public function allvendoritems(Request $request) {
        $itemData = Item::getAllItemsList($request);
        $html = View::make('customer._list_items', ['itemData' => $itemData])->render();
        return Response::json(['html' => $html]);
    }

    public function viewProfile() {
        $profileDetails = User::where('id', '=', Auth::guard()->user()->id)->first();
        return view('customer/view_profile', ['profileDetails' => $profileDetails]);
    }

    public function showEditProfile() {
        $edit = User::where('id', '=', Auth::guard()->user()->id)->first();
        return view('customer/edit_profile', ['edit' => $edit]);
    }

    public function updateCustomerProfile(UpdateCustomerRequest $request) {
        $update = User::customerProfileUpdate($request);
        if ($update) {
            $request->session()->flash('success', \Config::get('constants.update_profile'));
            return redirect('customer/view-profile');
        } else {
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('customer/view-profile');
        }
    }

    public function viewItemDetails($id) {
        $itemDetails = Item::getItemDetails($id);
        if ($itemDetails) {
            return view('customer/item_details', ['itemDetails' => $itemDetails]);
        } else {
            abort(404);
        }
    }

    public function addItemToCart(Request $request) {
        $cart = $request->all();
        $cartItems = Session::get('cart.items');
        $count = count($cartItems);
        $cartId = $count + 1;
        if ($cartItems != NULL) {
            foreach ($cartItems as $data) {
                if ($data['business_id'] != $cart['business_id']) {
                    Session::forget('cart.items');
                    $cart['cartId'] = 1;
                    Session::push('cart.items', $cart);
                    $request->session()->flash('success', \Config::get('constants.add_cart'));
                    return redirect('customer/checkout-cart-items');
                } else {
                    $cart['cartId'] = $cartId;
                    Session::push('cart.items', $cart);
                    $request->session()->flash('success', \Config::get('constants.add_cart'));
                    return redirect('customer/checkout-cart-items');
                }
            }
        } else {
            $cart['cartId'] = $cartId;
            Session::push('cart.items', $cart);
            $request->session()->flash('success', \Config::get('constants.add_cart'));
            return redirect('customer/checkout-cart-items');
        }
    }

    public function checkoutCartItem() {
        $cartItems = Session::get('cart.items');
        $address = UserAddress::where('user_id', '=', Auth()->user()->id)->get();
        $wallet = WalletTransaction::where('user_id', '=', Auth()->user()->id)->get();
        return view('customer/checkout', ['cartItems' => $cartItems, 'address' => $address, 'wallet' => $wallet]);
    }

    public function deliveryAddressDetails(Request $request) {
        $shippingCharges = Order::checkServiceArea($request);
        $processingFee = DB::table('settings')->where('key', 'processing_fee')->first();
        $html = View::make('customer._shipping_charges', ['processingFee' => $processingFee, 'shippingCharges' => $shippingCharges])->render();
        return Response::json(['html' => $html]);
    }

    public function voucherDetails(Request $request) {
        $voucherDetails = Voucher::getVoucherDetails($request);
        $shippingDetails = Session::get('cartDetails');
        $voucherAmount = $voucherDetails['voucher_amount'];
        if ($voucherDetails['voucher_type'] == 'Percent') {
            $voucherProfite = $shippingDetails['total_amount'] * $voucherAmount / 100;
            $netAmount = $shippingDetails['total_amount'] - $voucherProfite;
            $shippingDetails['net_amount'] = $netAmount;
        } else {
            $netAmount = $shippingDetails['total_amount'] - $voucherAmount;
            $shippingDetails['net_amount'] = $netAmount;
        }
        $shippingDetails['voucher_id'] = $voucherDetails['id'];
        Session::put('voucherDetails', $shippingDetails);
        return Response::json(['voucherDetails' => $voucherDetails]);
    }

    public function getAllNotifications() {
        $status = OrderNotification::changeNotificationStatus();
        return view('customer.all_notifications');
    }

    public function loadAllNotifications(Request $request) {
        $userId = Auth::guard()->user()->id;
        $notifications = OrderNotification::getAllNotificationsById($userId);
        $html = View::make('customer._load_all_notifications', ['notifications' => $notifications])->render();
        return Response::json(['html' => $html]);
    }

    public function deleteCustomerNotification($id) {
        $notification = OrderNotification::deleteNotification($id);
        if ($notification) {
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.delete_notification'));
            return Response()->json(array('status' => true));
        } else {
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response()->json(array('error' => false));
        }
    }

    public function deleteCartItem($cartId) {
        $cartItems = Session::get('cart.items');
        foreach ($cartItems as $key => $value) {
            if ($cartId == $value['cartId']) {
                unset($cartItems[$key]);
            }
        }
        session(['cart.items' => $cartItems]);
        return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => 'Remove from cart successfully'));
    }

    public function editCartItem($cartId){
        $cartItems = Session::get('cart.items');
        foreach ($cartItems as $key => $itemData) {
            if ($cartId == $itemData['cartId']) {
               return view('customer.edit_cartitem',['itemData'=>$itemData]);
            }
        }
    }

    public function cartUpdate(Request $request){
        $updateCart = $request->all();
        $cartItems = Session::get('cart.items');
        foreach ($cartItems as $key => $itemData){
            if ($request->cartId == $itemData['cartId']){
                unset($cartItems[$key]);
            }
        }
        session(['cart.items' => $cartItems]);
        Session::push('cart.items', $updateCart);
        $request->session()->flash('success', 'Cart updated successfully');
        return redirect('customer/checkout-cart-items');
    }
}
