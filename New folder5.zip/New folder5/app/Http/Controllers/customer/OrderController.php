<?php

namespace App\Http\Controllers\customer;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class OrderController extends Controller
{
    public function index(){
        return view('customer.orders');
    }
    
    public function getCustomerOrderlist(Request $request){
        $post = $request->all();
        $orderData = Order::getCustomerOrderlist($post);
        $html = View::make('customer._load_order_listing', ['orderData' => $orderData])->render();
        return Response::json(['html' => $html]);
    }
    
    public function getCustomerOrderById($id){
       $orderData = Order::getOrderById($id);
       if(!empty($orderData)){
           $productData = \App\Models\OrderProduct::where('order_id', '=', $orderData->id)->get();
           $transactionData = \App\Models\OrderTransaction::where('order_id', '=', $orderData->id)->first();
           $ratingData = \App\Models\Rating::where('order_id', '=', $orderData->id)->first();
           $orderAttr = \App\Models\OrderProduct::where('order_id', '=', $orderData->id)->get();
           $items = \App\Models\OrderProduct::where('order_id', '=', $orderData->id)->groupBy('item_id')->get();
         return view('customer.order_details', ['orderData' => $orderData,'productData'=>$productData,'transactionData'=>$transactionData,'orderAttr'=>$orderAttr,'items'=>$items,'rating'=>$ratingData]);
        } else {
           abort(404);    
        }
    }
}
