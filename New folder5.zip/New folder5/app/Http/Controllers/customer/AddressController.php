<?php

namespace App\Http\Controllers\customer;

use App\Models\OptionValue;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Models\UserAddress;
use App\Http\Requests\EditAddressVendorRequest;
use App\Http\Requests\AddAddressVendorRequest;


class AddressController extends Controller
{
    public function getAddress(){
        return view('customer/address_management');
    }
    
    public function getAddresslist(Request $request){
        $post = $request->all();
        $addressData = UserAddress::getAlladdress($post);
        $html = View::make('customer._load_address_list', ['addressData' => $addressData])->render();
        return Response::json(['html' => $html]);
    }
    
    public function getAddressForm(){
        return view('customer/add_address');
    }
    
    public function actionSaveAddress(AddAddressVendorRequest $request){
        
        $post = $request->all();
        $result = UserAddress::saveAddress($post);
        if ($result) {
            $request->session()->flash('success', 'success');
            $request->session()->flash('success',\Config::get('constants.add_address'));
            return Response::json(['success' => true]);
        } else {
           $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong')); 
            return Response::json(['error' => true]);
        }
    }
    
    public function actionDeleteAddress(Request $request){
        $post = $request->all();
        $result = UserAddress::deleteAddress($post['id']);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.address_delete'));
            return Response::json(['success' => true]);
        } else {
           $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return Response::json(['error' => true]);
        }
    }
    
    public function getEditAddressForm(Request $request){
        $post = $request->all();
        $addressData = UserAddress::where('id', $post['id'])->first();
        $html = View::make('customer._load_address_edit_form', ['addressData' => $addressData])->render();
        return Response::json(['html' => $html]);
    }
    
    public function actionEditAddress(EditAddressVendorRequest $request){        
       $post = $request->all();
       $result = UserAddress::updateAddress($post);
        if ($result) {
            $request->session()->flash('success', 'success');
            $request->session()->flash('success',\Config::get('constants.address_update'));
            return Response::json(['success' => true]);
        } else {
           $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return Response::json(['error' => true]);
        }
    }
    
    public function actionChangeDefaultAddress($id){
       
        $result = UserAddress::updateDefaultAddress($id);
        if ($result) {
            session()->flash('success', 'success');
            session()->flash('success', \Config::get('constants.default_address_update'));
            return Response::json(['success' => true]);
        } else {
           session()->flash('error', 'true');
            session()->flash('error',\Config::get('constants.somethig_worng'));
            return Response::json(['error' => true]);
        }
    }
    
   
            

}    
