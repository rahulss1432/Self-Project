<?php

namespace App\Http\Controllers\customer;

use Session;
use Stripe\Stripe;
use Stripe\Charge;
use Stripe\Customer;
use App\Models\Order;
use SampleCode\Constants;
use Braintree_Transaction;
use Illuminate\Http\Request;
use App\Models\OrderTransaction;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use net\authorize\api\contract\v1 as AnetAPI;
use App\Http\Requests\AuthorizePaymentRequest;
use net\authorize\api\controller\CreateTransactionController;

class OrderTransactionController extends Controller
{
	public function orderPyamentByPaypal(Request $request){
        $post = $request->all();
        $feeAndUnit = explode(",", $request->invoice);
        $post['delivery_note'] = $request->item_number;
        $post['delivery_address'] = $request->item_name;
        $post['shipping_charges'] = $request->custom;
        $post['processing_fee'] = $feeAndUnit[0];
        $post['processing_fee_unit'] = $feeAndUnit[1];
        $transactionType = 'paypal';
        $order = Order::placeOrderDetails($post, $transactionType);
        if ($order){
        	Session::forget('cart.items');
    		Session::forget('cartDetails');
    		Session::forget('voucherDetails');
    		Session::forget('shippingDetails');
    		Session::forget('totalAmount');
            $request->session()->flash('success','Order has been placed successfully');
            return redirect('customer/customer-dashboard');
        } else{
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('customer/checkout-cart-items');
        }
    }

    public function orderPyamentByAuthorize(AuthorizePaymentRequest $request) {
        $transactionAmount = $request->amount;
        $deliveryNote = $request->delivery_note;
        $deliveryAddress = $request->delivery_address;
        $shippingCharges = $request->shipping_charges;
        $processingFee = $request->processing_fee;
        $processingFeeUnit = $request->processing_fee_unit;
        $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
        $merchantAuthentication->setName("9TzbRAB37E5n");
        $merchantAuthentication->setTransactionKey("5kc879fcLv5yEG8a");
        $creditCard = new AnetAPI\CreditCardType();
        $creditCard->setCardNumber($request->card_number);
        $creditCard->setExpirationDate($request->card_expiry);
        $creditCard->setCardCode($request->card_cvv);
        $paymentOne = new AnetAPI\PaymentType();
        $paymentOne->setCreditCard($creditCard);
        $order = new AnetAPI\OrderType();
        $order->setDescription("New Item");
        $transactionRequestType = new AnetAPI\TransactionRequestType();
        $transactionRequestType->setTransactionType("authCaptureTransaction");
        $transactionRequestType->setAmount($transactionAmount);
        $transactionRequestType->setOrder($order);
        $transactionRequestType->setPayment($paymentOne);
        $user = Auth::user();
        $cust = new AnetAPI\CustomerAddressType();
        $cust->setFirstName(Auth::guard()->user()->first_name);
        $cust->setLastName(Auth::guard()->user()->last_name);
        $cust->setCity(Auth::guard()->user()->city_id);
        $cust->setState(Auth::guard()->user()->state_id);
        $cust->setCountry('India');
        $cust->setZip(Auth::guard()->user()->zip_code);
        $cust->setPhoneNumber(Auth::guard()->user()->phone_number);
        $cust->setEmail(Auth::guard()->user()->email);
        $transactionRequestType->setBillTo($cust);
        $refId = 'ref' . time();
        $request = new AnetAPI\CreateTransactionRequest();
        $request->setMerchantAuthentication($merchantAuthentication);
        $request->setRefId($refId);
        $request->setTransactionRequest($transactionRequestType);
        $controller = new CreateTransactionController($request);
        $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::SANDBOX);
        if ($response != null) {
            if ($response->getMessages()->getResultCode() == \App\User::RESPONSE_OK) {
                $tresponse = $response->getTransactionResponse();
                if (!empty($tresponse->getTransId())){
                    $post = array();
                    $post['txn_id'] = $tresponse->getTransId();
                    $post['payment_gross'] = $transactionAmount;
                    $post['delivery_note'] = $deliveryNote;
                    $post['delivery_address'] = $deliveryAddress;
                    $post['shipping_charges'] = $shippingCharges;
                    $post['processing_fee'] = $processingFee;
                    $post['processing_fee_unit'] = $processingFeeUnit;
                    $transactionType = 'authorize';
                    $order = Order::placeOrderDetails($post, $transactionType);
                    if($order){
                        Session::forget('cart.items');
                        Session::forget('cartDetails');
                        Session::forget('voucherDetails');
                        Session::forget('shippingDetails');
                        Session::forget('totalAmount');
                        session()->flash('success', 'true');
                        session()->flash('success', 'Order has been placed successfully');
                        return redirect('customer/customer-dashboard');    
                    } else{
                        session()->flash('error', 'false');
                        session()->flash('error',\Config::get('constants.something_wrong'));
                        return redirect('customer/checkout-cart-items');
                    }
                }
            } else{
                session()->flash('error', 'false');
                session()->flash('error',\Config::get('constants.something_wrong'));
                return redirect('customer/checkout-cart-items');
            }
        } else{
            session()->flash('error', 'false');
            session()->flash('error',\Config::get('constants.something_wrong'));
            return redirect('customer/checkout-cart-items');
        }
    }

    public function orderPyamentByStripe(Request $request){
        $post = $request->all();
        Stripe::setApiKey(env('STRIPE_SECRET_KEY'));
        $customer = Customer::create(array(
                    'email' => $post['stripe_email'],
                    'source' => $post['stripe_token']
        ));
        $charge = Charge::create(array(
                    'customer' => $customer->id,
                    'amount' => $post['amount'] * 100,
                    'currency' => 'usd'
        ));
        $post['payment_gross'] = $charge->amount/100;
        $post['txn_id'] = $charge->id;
        $transactionType = 'stripe';
        $order = Order::placeOrderDetails($post,$transactionType);
        if ($order){
            Session::forget('cart.items');
            Session::forget('cartDetails');
            Session::forget('voucherDetails');
            Session::forget('shippingDetails');
            Session::forget('totalAmount');
            $request->session()->flash('success','Order has been placed successfully');
            return redirect('customer/customer-dashboard');
        } else{
            $request->session()->flash('error',\Config::get('constants.something_wrong'));
            return redirect('customer/checkout-cart-items');
        }
    }
    
    public function orderPyamentByBraintree(Request $request){
        $post = $request->all();
        $payload = $request->input('payload', false);
        $nonce = $payload['nonce'];
        $status = Braintree_Transaction::sale([
                    'amount' => $post['amount'],
                    'paymentMethodNonce' => $nonce,
                    'options' => [
                        'submitForSettlement' => True
                    ]
        ]);
        $post['txn_id'] = $status->transaction->id;
        $post['payment_gross'] = $post['amount'];
        $transactionType = 'braintree';
        $order = Order::placeOrderDetails($post,$transactionType);
        if ($order){
            Session::forget('cart.items');
            Session::forget('cartDetails');
            Session::forget('voucherDetails');
            Session::forget('shippingDetails');
            Session::forget('totalAmount');
            $request->session()->flash('success','Order has been placed successfully');
            return response()->json(['success'=>true]);
        } else{
            $request->session()->flash('error',\Config::get('constants.something_wrong'));
            return response()->json(['error'=>false]);
        }
    }

    public function orderPyamentByCod(Request $request){
        $post['payment_gross'] = $request['amount'];
        $post['delivery_note'] = $request['delivery_note'];
        $post['delivery_address'] = $request['delivery_address'];
        $post['shipping_charges'] = $request['shipping_charges'];
        $post['processing_fee'] = $request['processing_fee'];
        $post['processing_fee_unit'] = $request['processing_fee_unit'];
        $transactionType = 'cod';
        $order = Order::placeOrderDetails($post,$transactionType);
        if ($order){
            Session::forget('cart.items');
            Session::forget('cartDetails');
            Session::forget('voucherDetails');
            Session::forget('shippingDetails');
            Session::forget('totalAmount');
            $request->session()->flash('success', 'success');
            $request->session()->flash('success','Order has been placed successfully');
            return response()->json(['success'=>true]);
        } else{
            $request->session()->flash('error', 'error');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return response()->json(['error'=>false]);
        }
    }
}
