<?php

namespace App\Http\Controllers\customer;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\WalletTransaction;
use net\authorize\api\contract\v1 as AnetAPI;
use net\authorize\api\controller\CreateTransactionController;
use Illuminate\Support\Facades\Auth;
use SampleCode\Constants;
use App\Models\User;
use App\Http\Requests\AuthorizePaymentRequest;
use Stripe\Stripe;
use Stripe\Customer;
use Stripe\Charge;
use Braintree_Transaction;

class WalletController extends Controller {

    public function index() {
        $userId = Auth::guard()->user()->id;
        $userData = User::where('id', '=', $userId)->first();
        $wallet = WalletTransaction::where('user_id', '=', $userId)->get();
        return view('customer.wallet_management', ['userData' => $userData, 'wallet' => $wallet]);
    }

    public function paypalPayment(Request $request) {
        $post = $request->all();
        $transactionType = 'paypal';
        $result = WalletTransaction::saveWalletTransaction($post, $transactionType);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.add_wallet'));
            return redirect('customer/wallet-management');
        } else {
            $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return redirect('customer/wallet-management');
        }
    }

    public function authorizePayment(AuthorizePaymentRequest $request) {
        $payAmount = $request->amount;
        //set merchant ID and transaction key
        $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
        $merchantAuthentication->setName("9TzbRAB37E5n");
        $merchantAuthentication->setTransactionKey("5kc879fcLv5yEG8a");

        // Create the payment data for a credit card
        $creditCard = new AnetAPI\CreditCardType();
        $creditCard->setCardNumber($request->card_number);
        $creditCard->setExpirationDate($request->card_expiry);
        $creditCard->setCardCode($request->card_cvv);

        $paymentOne = new AnetAPI\PaymentType();
        $paymentOne->setCreditCard($creditCard);

        // Preparing the order data for the transaction
        $order = new AnetAPI\OrderType();
        $order->setDescription("New Item");

        //create a transaction
        $transactionRequestType = new AnetAPI\TransactionRequestType();
        $transactionRequestType->setTransactionType("authCaptureTransaction");
        $transactionRequestType->setAmount($request->amount);
        $transactionRequestType->setOrder($order);
        $transactionRequestType->setPayment($paymentOne);

        //Preparing customer information object
        $user = Auth::user();
        $cust = new AnetAPI\CustomerAddressType();
        $cust->setFirstName(Auth::guard()->user()->first_name);
        $cust->setLastName(Auth::guard()->user()->last_name);
        $cust->setAddress(Auth::guard()->user()->address);
        $cust->setCity(Auth::guard()->user()->city_id);
        $cust->setState(Auth::guard()->user()->state_id);
        $cust->setZip(Auth::guard()->user()->zip_code);
        $cust->setPhoneNumber(Auth::guard()->user()->phone_number);
        $cust->setEmail(Auth::guard()->user()->email);

        $transactionRequestType->setBillTo($cust);

        $refId = 'ref' . time();
        $request = new AnetAPI\CreateTransactionRequest();
        $request->setMerchantAuthentication($merchantAuthentication);
        $request->setRefId($refId);
        $request->setTransactionRequest($transactionRequestType);

        $controller = new CreateTransactionController($request);
        $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::SANDBOX);
        if ($response != null) {
            if ($response->getMessages()->getResultCode() == \App\User::RESPONSE_OK) {
                $tresponse = $response->getTransactionResponse();

                if (!empty($tresponse->getTransId())) {
                    $post['payment_gross'] = $payAmount;
                    $post['txn_id'] = $tresponse->getTransId();
                    $transactionType = 'authorize';
                    
                    $result = WalletTransaction::saveWalletTransaction($post,$transactionType);
                    if ($result) {
                        session()->flash('success', 'true');
                        session()->flash('success', \Config::get('constants.add_wallet'));
                        return redirect('customer/wallet-management');
                    } else {
                        session()->flash('error', 'false');
                        session()->flash('error',  \Config::get('constants.failed_add_amount'));
                        return redirect('customer/wallet-management');
                    }
                }
            } else {
                session()->flash('error', 'false');
                session()->flash('error',  \Config::get('constants.failed_add_amount'));
                return redirect('customer/wallet-management');
            }
        } else {
            session()->flash('error', 'false');
            session()->flash('error',  \Config::get('constants.no_response_found'));
            return redirect('customer/wallet-management');
        }
    }

    public function stripePayment(Request $request) {
        $post = $request->all();
        Stripe::setApiKey(env('STRIPE_SECRET_KEY'));
        $customer = Customer::create(array(
                    'email' => $post['stripe_email'],
                    'source' => $post['stripe_token']
        ));
        $charge = Charge::create(array(
                    'customer' => $customer->id,
                    'amount' => $post['amount'] * 100, /* total amount */
                    'currency' => 'usd'
        ));
        $post['payment_gross'] = $charge->amount/100; /* transaction amount */
        $post['txn_id'] = $charge->id; /* transaction id */
        $transactionType = 'stripe';
        
        $result = WalletTransaction::saveWalletTransaction($post,$transactionType);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.add_wallet'));
            return redirect('customer/wallet-management');
        } else {
            $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.failed_add_amount'));
            return redirect('customer/wallet-management');
        }
    }
    
    public function braintreePayment(Request $request) {
        $post = $request->all();
        $payload = $request->input('payload', false);
        $nonce = $payload['nonce'];

        $status = Braintree_Transaction::sale([
                    'amount' => $post['amount'],
                    'paymentMethodNonce' => $nonce,
                    'options' => [
                        'submitForSettlement' => True
                    ]
        ]);
        
        $post['txn_id'] = $status->transaction->id;
        $post['payment_gross'] = $post['amount'];
        $transactionType = 'braintree';
        $result = WalletTransaction::saveWalletTransaction($post,$transactionType);
        if ($result) {
            $request->session()->flash('success', 'success');
            $request->session()->flash('success', \Config::get('constants.add_wallet'));
            return response()->json(['success'=>true]);
        } else {
            $request->session()->flash('error', 'error');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return response()->json(['error'=>false]);
        }
    }
}
