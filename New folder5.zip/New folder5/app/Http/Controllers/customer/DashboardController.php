<?php

namespace App\Http\Controllers\customer;

use App\Models\Customer;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use File;
use Image;
use View;
use Illuminate\Support\Facades\Response;
use App\Models\Order;

class DashboardController extends Controller 
{
    public function index(){
        $vendorsList = Customer::getallVendorList();
        return view('customer.dashboard', ['vendorsList' => $vendorsList]);
    }

    public function vendorDetails($id){
        $vendorDetails = Customer::getVendorDetails($id);
        if (!empty($vendorDetails)) {
            return view('customer.vendor_details', ['vendorDetails' => $vendorDetails]);
        } else {
            abort(404);
        }
    }

    public function uploadProfileImage(Request $request){
        $file = $request->file('profile_picture');
        $userProfileTempPath = public_path() . '/uploads/temp-image';
        if (!is_dir($userProfileTempPath)){
            File::makeDirectory($userProfileTempPath, $mode = 0777, true, true);
        }
        $fileName = $file->getClientOriginalName();
        $fileExtendedName = time() . $fileName;
        if ($request->file('profile_picture')->move($userProfileTempPath, $fileExtendedName)){
            return Response::Json(['success' => true, 'filename' => $fileExtendedName]);
        } else{
            return Response::Json(['success' => false, 'message' => \Config::get('constants.failed_upload')]);
        }
    }

    public function loadImageCropper(Request $request){
        $post = $request->all();
        $html = View::make('customer._load_image_cropper', ['imageName' => $post['imageName'], 'imageType' => $post['imageType']])->render();
        return Response::json(['html' => $html]);
    }

    public function uploadCroppedPicture(Request $request){
        $post = $request->all();
        if ($post['imageType'] == 'license-type-image'){
            $cropImgPath = base_path() . '/public/uploads/license-pictures/';
            if (!is_dir($cropImgPath)){
                mkdir($cropImgPath, 0777, true);
            }
        } elseif ($post['imageType'] == 'profile-type-image'){
            $cropImgPath = base_path() . '/public/uploads/profile-pictures/';
            if (!is_dir($cropImgPath)){
                mkdir($cropImgPath, 0777, true);
            }
        }
        $origanlImage = base_path() . '/public/uploads/temp-image/' . $post['imageName'];
        $destinationPath = $cropImgPath . $post['imageName'];
        $img = Image::make($origanlImage);
        $croppedImage = $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']));
        $croppedImage->save($destinationPath);
        unlink($origanlImage);
        return $post['imageName'];
    }

    public function viewOrderByCustomerNotification($id){
        $result = Order::getOrderById($id);
        if (!empty($result)){
            return view('customer.detail-order', ['orderData' => $result]);
        } else{
            abort(404);
        }
    }
}