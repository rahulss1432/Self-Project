<?php

namespace App\Http\Controllers\vendor1;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\OrderTransaction;
use App\Models\Item;
use App\Models\User;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;

class TransactionController extends Controller
{
    
     public function Transaction() { 
        $drivers = User::where('user_type', 'driver')->get();
        return view('vendor1.transaction',['drivers' => $drivers]);
    }
   
   public function Transactionlist(Request $request){
        $post = $request->all();
        $transactions = OrderTransaction::getOrderTransactions($post);
        $html = View::make('vendor1._load_transaction_list', ['transactions' => $transactions])->render();
        return Response::json(['html' => $html]);
    }
    
    public function TransactionById($id){
        $transactionData = OrderTransaction::getTransactionById($id);
        return view('vendor1.transaction_detail', ['transaction' => $transactionData,]);
     }
   
}
