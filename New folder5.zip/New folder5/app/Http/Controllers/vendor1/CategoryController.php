<?php

namespace App\Http\Controllers\vendor1;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\AddCategoryVendorRequest;
use App\Models\Category;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\EditCategoryVendorRequest;

class CategoryController extends Controller
{
    public function index(){
        return view('vendor1.category');
    }

    public function getCategoryForm(){
         return view('vendor1.add_category');
    }
    
    public function actionSaveCategory(AddCategoryVendorRequest $request){
        $post = $request->all();
        $result = Category::saveCategory($post);
        if ($result) {
            $request->session()->flash('success', 'success');
            $request->session()->flash('success', \Config::get('constants.add_category'));
            return Response::json(['success' => true]);
        } else {
           $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong')); 
            return Response::json(['error' => true]);
        }
        
    }
    
    public function getCategorylist(Request $request){
        $post = $request->all();
        $categoryData = Category::getAllCategory($post);
        $html = View::make('vendor1._load_category_list', ['categoryData' => $categoryData])->render();
        return Response::json(['html' => $html]);
    }
    
    public function actionDeleteCategory(Request $request){
        $post = $request->all();
        $result = Category::deleteCategory($post['id']);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success',\Config::get('constants.delete_category'));
            return Response::json(['success' => true]);
        } else {
           $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong')); 
            return Response::json(['error' => true]);
        }
    }
    
    public function getEditCategoryForm(Request $request){
        $post = $request->all();
        $categoryData = Category::where('id', $post['id'])->first();
        $html = View::make('vendor1._load_category_edit_form', ['categoryData' => $categoryData])->render();
        return Response::json(['html' => $html]);
    }
    
    public function actionEditCategory(EditCategoryVendorRequest $request){        
       $post = $request->all();
       $result = Category::updateCategory($post);
        if ($result) {
            $request->session()->flash('success', 'success');
            $request->session()->flash('success', \Config::get('constants.update_category'));
            return Response::json(['success' => true]);
        } else {
           $request->session()->flash('error', 'true');
            $request->session()->flash('error',\Config::get('constants.something_wrong')); 
            return Response::json(['error' => true]);
        }
    }
}
