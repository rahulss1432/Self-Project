<?php

namespace App\Http\Controllers\vendor1;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\AddCategoryVendorRequest;
use App\Models\Category;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\EditCategoryVendorRequest;
use App\Models\Order;
use App\Models\User;
use App\Models\OrderNotification;


class OrderController extends Controller
{
    
    public function getOrderlist(Request $request){
        $post = $request->all();
        $orderData = Order::getOrderByVendor($post);
        $html = View::make('vendor1._load_order_list', ['orderData' => $orderData])->render();
        return Response::json(['html' => $html]);
    }
    
    public function getOrderById($id){
       $orderData = Order::getOrderById($id);
       if(!empty($orderData)){
           $productData = \App\Models\OrderProduct::where('order_id', '=', $orderData->id)->get();
           $transactionData = \App\Models\OrderTransaction::where('order_id', '=', $orderData->id)->first();
           return view('vendor1.detail_order', ['orderData' => $orderData,'productData'=>$productData,'transactionData'=>$transactionData]);
        } else {
          abort(404);
        }
    }
    public function assignDriver($id){ 
        $drivers = User::assignDriver();
        if($drivers){
        return view('vendor1.assigndriver', ['drivers' => $drivers,'orderid' => $id]);
        }  else {
            abort(404);    
        }
     }
     
    public function assignDriverOnorder($orderid,$driverid){ 
        $result = Order::assignDriverOnorder($orderid,$driverid);
        if ($result) {
            $notification = OrderNotification::sendOrderNotificationById($orderid, $driverid);            
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.assign_driver'));
           return  redirect('/orders');
        } else {
            session()->flash('error', 'true');
            session()->flash('error',\Config::get('constants.something_wrong')); 
            
        }
     }
    public function cancelOrder(Request $request){ 
        $result = Order::changeOrderState($request->all());
         if ($result) {
            return Response()->json(array('status' => true, 'success.content' => 'Status', 'message' =>\Config::get('constants.cancel_order')));
        } else {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => \Config::get('constants.something_wrong')));
        }
    }
    public function rejectOrder(Request $request){ 
        $id = $request->id;
        $customerid = $request->customerid;
        $result = OrderNotification::saveRejectOrder($id,$customerid);
         if ($result) {
            return Response()->json(array('status' => true, 'success.content' => 'Status', 'message' => \Config::get('constants.reject_order')));
        } else {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' =>\Config::get('constants.something_wrong')));
        }
     }
    
     public function acceptVendorOrder($orderid) {
         $result =  Order::changeOrderStatus($orderid);
         if ($result) {
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.accept_order'));
           return  redirect('/orders');
        } else {
            session()->flash('error', 'true');
            session()->flash('error',\Config::get('constants.something_wrong')); 
        }
     }
   
}
