<?php

namespace App\Http\Controllers\vendor1;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Models\User;
use App\Models\Category;
use App\Models\Item;
use App\Models\OrderTransaction;
use App\Models\Attribute;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\UserEditRequest;
use App\Http\Requests\VendorEditRequest;
use App\Http\Requests\ChangePasswordRequest;
use File;
use Image;

class VendorController extends Controller {

    public function index() {
        return view('vendor.index');
    }

    public function CreateVendor() {

        return view('vendor.createvendor');
    }

    public function Items() {
        $userId = Auth::guard()->user()->id;
        $cat = Category::where('business_id', $userId)->get();
        return view('vendor1.items', ['category' => $cat]);
    }

    public function CreateItem() {
        $userId = Auth::guard()->user()->id;
        $Attributes = Attribute::all();
        $cat = Category::where('business_id', $userId)->get();
        return view('vendor1.createitem', ['category' => $cat, 'attr' => $Attributes]);
    }

    public function saveCropperitemImage(Request $request) {
        $post = $request->all();
        $image = $post['imageBaseCode'];
        if (!empty($image)) {
            $image_parts = explode(";base64,", $image);
            $image_type_aux = explode("image/", $image_parts[0]);
            $image_type = $image_type_aux[1];
            $image_base64 = base64_decode($image_parts[1]);
            $destinationPath = public_path() . '/uploads/item-pictures/';
            $tempPath = public_path() . '/uploads/temp/';
            $file = time() . '.jpg';
            if (!\File::exists($destinationPath)) {
                \File::makeDirectory($destinationPath, 0755, true);
            }
            if (!\File::exists($tempPath)) {
                \File::makeDirectory($tempPath, 0755, true);
            }
            file_put_contents($destinationPath . '/' . $file, $image_base64);
            $img = Image::make("public/uploads/item-pictures/" . $file);
            $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']))->save($tempPath . $file);
            return Response::json(array('success' => true, 'filename' => $file));
        }
    }

    public function Orders() {
        return view('vendor1.orders');
    }
   public function MyProfile() {
        $userId = Auth::guard()->user()->id;
        $userdetail = User::where('id', $userId)->first();
        return view('vendor1.myprofile', ['userdetail' => $userdetail]);
    }

    public function EditProfile() {
        $userId = Auth::guard()->user()->id;
        $editVendorData = User::editsingalVendorData($userId);
        return view('vendor1.editprofile', ['editVendorData' => $editVendorData]);
    }

    public function saveCropperImage(Request $request) {
        $post = $request->all();
        $image = $post['imageBaseCode'];
        if (!empty($image)) {
            $image_parts = explode(";base64,", $image);
            $image_type_aux = explode("image/", $image_parts[0]);
            $image_type = $image_type_aux[1];
            $image_base64 = base64_decode($image_parts[1]);
            $destinationPath = public_path() . '/uploads/user/';
            $file = time() . '.jpg';
            if (!\File::exists($destinationPath)) {
                \File::makeDirectory($destinationPath, 0755, true);
            }
            file_put_contents($destinationPath . '/' . $file, $image_base64);
            $img = Image::make("public/uploads/user/" . $file);
            $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']))->save("public/uploads/temp/" . $file);
            return Response::json(array('success' => true, 'filename' => $file));
        }
    }

    public function UpdateProfile(VendorEditRequest $request) {
       $post = $request->all();
        $result = User::updateUser($post);
        if ($result) {
            session()->flash('success', 'true');
            session()->flash('success',  \Config::get('constants.update_profile'));
            return redirect('/my-profile');
        } else {
            session()->flash('error', 'false');
            session()->flash('error',  \Config::get('constants.something_wrong'));
        }
    }
}
