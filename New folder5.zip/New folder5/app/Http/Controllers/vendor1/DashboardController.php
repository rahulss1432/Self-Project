<?php

namespace App\Http\Controllers\vendor1;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderNotification;
use Illuminate\Support\Facades\Auth;
use Excel;

class DashboardController extends Controller
{
    public function index() {
        $runningOrderData = Order::runningOrderDetailsById();
        $newOrderData = Order::newOrderDetailsById();
        return view('vendor1.dashboard',['runningOrderData' => $runningOrderData ,'newOrderData' => $newOrderData]);
    }
       public function getOrderGraph(Request $request){
        $post = $request->all();
        $ordersdetails= Order::getOrderDetails($post);
        $html = View::make('vendor1._load_order_graph', ['ordersdetails' => $ordersdetails])->render();
        return Response::json(['html' => $html]);
    }
    
       public function downloadEarningCsv(Request $request) {
        $earnings = Order::getOrderDetails($request->all());

        $excelDownload = Excel::create('earning_records', function($excel) use ($earnings) {
                    $excel->sheet('Sheet1', function($sheet) use($earnings) {
                        $arr = array();
                        foreach ($earnings as $earningData) {
                            $data = array(
                                $earningData->created_at,
                                $earningData->count_order,
                                $earningData->amount,
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            ' Order Date', 'No of order', 'Earn')
                        );
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', \Config::get('constants.export_vendor'));
            return redirect()->back();
        }
    }
     /* for nofications */
    
    public function viewAllNotifications() {
        $status = OrderNotification::changeNotificationStatus();
        return view('vendor1.all_notifications');
    }
    public function loadAllNotifications(Request $request) {
        $post = $request->all();
        $userId = Auth::guard()->user()->id;
        $notifications = OrderNotification::getAllNotificationsBytoId($userId, $post);
        if (!empty($notifications)) {
            $html = View::make('vendor1._load_all_notification_list', compact('notifications', 'post'))->render();
                return Response::json(['success' => true, 'html' => $html]);
          } else {
            return Response::json(['success' => false, 'message' => 'failed to load']);
        }
    }
    
     public function deleteNotification($id) {
        $notification = OrderNotification::deleteNotification($id);
        if ($notification) {
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.delete_notification'));
            return Response::json(['success' => true]);
        } else {
            session()->flash('error', 'true');
            session()->flash('error', \Config::get('constants.something_wrong'));
            return Response::json(['error' => false]);
        }
    }
    
    public function viewOrderByVendorNotification($id) {
        $result = Order::getOrderById($id);
        if (!empty($result)) {
            return view('vendor1.detail-vendor-order', ['orderData' => $result]);
        } else {
            abort(404);
        }
    }
}
