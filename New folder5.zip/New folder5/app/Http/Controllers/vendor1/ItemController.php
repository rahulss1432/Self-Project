<?php

namespace App\Http\Controllers\vendor1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\ItemAddRequest;
use App\Http\Requests\EditItemRequest;
use App\Models\Category;
use App\Models\ItemAttribute;
use App\Models\Attribute;
use App\Models\Item;
use App\Models\OptionValue;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;

class ItemController extends Controller {

    public function AddItem(ItemAddRequest $request) {
        $post = $request->all();
        $id = Item::addItem($post);
        $result = ItemAttribute::addItemAttribute($id, $post);
        if ($id) {
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.add_item'));
            return redirect('/items');
        } elseif ($result) {
            session()->flash('success', 'true');
            session()->flash('success', \Config::get('constants.add_item'));
            return redirect('/items');
        } else {
            session()->flash('error', 'false');
            session()->flash('error', \Config::get('constants.something_wrong'));
        }
    }

    public function getItemlist(Request $request) {
        $post = $request->all();
        $itemData = Item::getAllitem($post);
        $html = View::make('vendor1._load_item_list', ['itemData' => $itemData])->render();
        return Response::json(['html' => $html]);
    }

    public function changeItemStatus($id) {
        $result = Item::ChangeItemStatus($id);
        if ($result) {
            return Response()->json(array('status' => true, 'success.content' => 'Status', 'message' => \Config::get('constants.change_status')));
        } else {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => \Config::get('constants.something_wrong')));
        }
    }

    public function DeleteItem(Request $request) {
        $post = $request->all();
        $result = Item::deleteItem($post['id']);
        if ($result) {
            $request->session()->flash('success', 'true');
            $request->session()->flash('success', \Config::get('constants.delete_item'));
            return Response::json(['success' => true]);
        } else {
            $request->session()->flash('error', 'true');
            $request->session()->flash('error', \Config::get('constants.something_wrong'));
            return Response::json(['error' => true]);
        }
    }

    public function getEditItemForm(Request $request) {
        $post = $request->all();
        $userId = Auth::guard()->user()->id;
        $itemData = Item::where('id', $post['id'])->first();
        $cat = Category::where('business_id', $userId)->get();
        $Attributes = Attribute::all();
        $attritem = ItemAttribute::where('item_id', $post['id'])->get();
        $html = View::make('vendor1._load_item_edit_form', ['itemData' => $itemData, 'category' => $cat, 'attritem' => $attritem, 'attr' => $Attributes])->render();
        return Response::json(['html' => $html]);
    }

    public function updateItem(EditItemRequest $request) {
        $post = $request->all();
        $id = Item::updateitem($post);
        $result = ItemAttribute::updateItemAttribute($id, $post);
        if ($result) {
            return Response::json(['success' => true, 'message' => \Config::get('constants.update_item')]);
        } else {
            return Response::json(['success' => false, 'message' => \Config::get('constants.something_wrong')]);
        }
    }

    public function getOptions(Request $request) {
        $post = $request->all();
        $attributeId = $post['attributeId'];
        $optionData = OptionValue::where('attr_id', $attributeId)->orderBy('option_name', 'asc')->get();
        $attrHtml = "";
        if ($optionData->count() > 0) {
            foreach ($optionData as $val) {
                $attrHtml.="<option value='" . $val->id . "'>" . $val->option_name . "</option>";
            }
        }
        return Response::json(['html' => $attrHtml]);
    }

    public function itemDetail($id) {
        $itemData = Item::where('id', $id)->first();
        if (!empty($itemData)) {
            $attritem = ItemAttribute::where('item_id', $id)->get();
            if (!empty($attritem)) {
                return view('vendor1.itemdetail', ['itemData' => $itemData, 'attritem' => $attritem]);
            } else {
                abort(404);
            }
        } else {
            abort(404);
        }
    }

}
