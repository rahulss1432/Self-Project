<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCustomerRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name' => 'required|string|max:20|remove_spaces',
            'last_name' => 'required|string|max:20|remove_spaces',
            'email' => 'required|email|max:50|check_email_format|unique:users,email,' . $this->user_id,
            'phone_number' => 'required|remove_spaces|phone_format',
            'address' => 'required|remove_spaces',
            'zip_code' => 'required|numeric|min:6',
            'date_of_birth' => 'required',
        ];
    }

    public function messages() {
        return [
            'phone_number.phone_format' =>'Please enter valid phone number',
            'phone_number.remove_spaces' =>'Space is not allowed',
            'address.remove_spaces' =>'Space is not allowed',
            'first_name.remove_spaces' =>'Space is not allowed',
            'last_name.remove_spaces' =>'Space is not allowed',
            'email.check_email_format' => 'The email must be a valid email address',
        ];
    }
}
