<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ChangePasswordRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
   public function rules() {
        return [
            'current_password' => 'required|current_password_match|remove_spaces',
            'password' => 'required|string|min:6|remove_spaces',
            'confirm_password' => 'required|string|min:6|same:password|remove_spaces',
        ];
    }

    public function messages() {
        return [
            'current_password.current_password_match' => 'Current password does not match.',
            'current_password.remove_spaces' => 'Space is not allowed.',
            'password.remove_spaces' => 'Space is not allowed..',
            'confirm_password.remove_spaces' => 'Space is not allowed..',
        ];
    }
}
