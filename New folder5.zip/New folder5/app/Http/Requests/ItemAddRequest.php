<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ItemAddRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
           'category_id' => 'required',
           'product_name' => 'required|validate_vendor_product|max:20|remove_spaces',
           'price' => 'required|price_format|numeric|valid_price',
           'product_description' => 'required|remove_spaces',
           'stock_status' => 'required',
           'unit' => 'required|numeric|valid_admin_commission',
      
        ];
    }
    public function messages() {
        return [

            'unit.integer' => 'Only numbers are allowed.',
            'price.integer' => 'Price must be a number.',
            'product_name.validate_vendor_product' => 'Product name already exist.',
            'price.price_format' => 'Check  product price format.',
            'price.valid_price' => 'Price should be greater than 0',
            'product_name.remove_spaces' => 'Space is not allowed.',
            'product_description.remove_spaces' => 'Space is not allowed.',
            'unit.valid_admin_commission' => 'Unit should be greater than 0.',
            ];
    }
}
