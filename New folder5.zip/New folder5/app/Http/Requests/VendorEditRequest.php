<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class VendorEditRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'business_name' => 'required|string|max:50|remove_spaces',
            'first_name' => 'required|string|max:20|remove_spaces',
            'last_name' => 'required|string|max:20|remove_spaces',
            'email' => 'required',
            'phone_number' => 'required|phone_format',
            'start_time' => 'required',
            'end_time' => 'required',
            'business_type' => 'required',
            'delivery_location' => 'required',
            'address' => 'required|string',
            'profile_picture' => 'required|string',
            'vendor_acceptance' => 'required|string',
        ];
    }
      public function messages() {
        return [

            
            'phone_number.phone_format' => 'Please enter valid phone number.',
            'business_name.remove_spaces' => 'Space is not allowed.',
            'first_name.remove_spaces' => 'Space is not allowed.',
            'last_name.remove_spaces' => 'Space is not allowed.',
            ];
    }
}
