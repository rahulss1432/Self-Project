<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class VendorCheck {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null) {
        if (!Auth::guard('admin')->check()) {
            if (Auth::guard()->check()) {
                if (Auth::guard($guard)->user()->user_type == 'vendor') {
                    return $next($request);
                }
                return redirect('/home');
            }
            return redirect('/home');
        } else {
            return redirect('/admin/admin-dashboard');
        }
        /*
          if (Auth::guard($guard)->user()->user_type == 'vendor') {
          return $next($request);
          }
          return redirect('/home');
         */
    }

}
