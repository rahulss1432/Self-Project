<?php

namespace App\Helpers;

use Illuminate\Support\Facades\File;
use App\Models\User;
use App\Models\TemplateEmail;
use App\Models\DeliverCompany;
use App\Models\VehicleCategory;
use Mail;
use DB;

class Helper {

    public static function buttonLoader() {
        echo '<i id="button-loader" class="fa fa-spinner fa-spin"></i>';
    }

    public static function checkUserImage($image) {
        $src = url('public/images/profile-img-placeholder.jpg');
        $fileName = public_path() . '/uploads/temp/' . $image;
        if (!empty($image) && file_exists($fileName)) {
            $src = url('public/uploads/temp/' . $image);
        }
        return $src;
    }

    public static function getImageById($userId) {
        $userData = User::where(['id' => $userId])->first();
        return self::checkUserImage($userData->profile_picture);
    }

    public static function sendMail($data) {
        try {
            switch ($data['request']) {
                case "create_user":
                    $emailModel = \App\Models\TemplateEmail::getEmailTemplate('create_customer');
                    $emailContent = $emailModel->page_description;
                    $emailContent = str_replace('{name}', ucwords(strtolower($data['name'])), $emailContent);
                    $emailContent = str_replace('{email}', $data['email'], $emailContent);
                    $emailContent = str_replace('{password}', $data['password'], $emailContent);
                    $emailContent = str_replace('{year}', date('Y'), $emailContent);
                    Mail::send([], [], function($message) use ($data, $emailContent) {
                        $message->to($data['email']);
                        $message->subject($data['subject']);
                        $message->setBody($emailContent, 'text/html');
                    });
                    break;
                case "forgot_password":
                    $emailModel = \App\Models\TemplateEmail::getEmailTemplate('forgot_password');
                    $emailContent = $emailModel->page_description;
                    $emailContent = str_replace('{name}', ucwords(strtolower($data['name'])), $emailContent);
                    $emailContent = str_replace('{link}', $data['token'], $emailContent);
                    $emailContent = str_replace('{year}', date('Y'), $emailContent);
                    Mail::send([], [], function($message) use ($data, $emailContent) {
                        $message->to($data['email']);
                        $message->subject($data['subject']);
                        $message->setBody($emailContent, 'text/html');
                    });
                    break;
                case "admin_change_password":
                    $emailModel = \App\Models\TemplateEmail::getEmailTemplate('admin_change_password');
                    $emailContent = $emailModel->page_description;
                    $emailContent = str_replace('{name}', ucwords(strtolower($data['fullname'])), $emailContent);
                    $emailContent = str_replace('{email}', $data['email'], $emailContent);
                    $emailContent = str_replace('{password}', $data['password'], $emailContent);
                    $emailContent = str_replace('{year}', date('Y'), $emailContent);
                    Mail::send([], [], function($message) use ($data, $emailContent) {
                        $message->to($data['email']);
                        $message->subject($data['subject']);
                        $message->setBody($emailContent, 'text/html');
                    });
                    break;

                default:
                    break;
            }
            return true;
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    public static function getCategoryNameById($categoryId) {
        $result = \App\Models\Category::where(['id' => $categoryId])->first();
        return ucfirst($result->category_name);
    }

    public static function getBusinessNameById($businessId) {
        $result = User::where(['id' => $businessId])->first();
        return ucfirst($result->first_name . ' ' . $result->last_name);
    }

    public static function getAttributeNameById($AttributeId) {
        $result = \App\Models\Attribute::where(['id' => $AttributeId])->first();
        return ucfirst($result->attribute_name);
    }

    public static function getBusinesstypeNameById($businessId) {
        $result = \App\Models\BusinessType::where(['id' => $businessId])->first();
        if (!empty($result)) {
            return ucfirst($result->business_name);
        }
    }

    public static function getOptionvalueNameById($optionvalueId) {
        $result = \App\Models\OptionValue::where(['id' => $optionvalueId])->first();
        return ucfirst($result->option_name);
    }

    public static function getItemNameById($itemId) {
        $result = \App\Models\Item::where(['id' => $itemId])->first();
        return ucfirst($result->product_name);
    }

    public static function getDeliverCompanyById($id) {
        if (!empty($id)) {
            $result = DeliverCompany::getCompanyById($id);
            return $result->name;
        } else {
            return '-';
        }
    }

    public static function getVehicleCategoryById($id) {
        if (!empty($id)) {
            $result = VehicleCategory::getDetailById($id);
            return $result->name;
        } else {
            return '-';
        }
    }

    public static function defaultImage($image, $type) {
        if ($type == 'profile_image') {
            $src = url('public/images/profile-img-placeholder.jpg');
            $fileName = public_path() . '/uploads/profile-pictures/' . $image;
            if (!empty($image) && file_exists($fileName)) {
                $src = url('public/uploads/profile-pictures/' . $image);
            }
            return $src;
        } elseif ($type == 'license_image') {
            $src = url('public/images/upload-image.jpg');
            $fileName = public_path() . '/uploads/license-pictures/' . $image;
            if (!empty($image) && file_exists($fileName)) {
                $src = url('public/uploads/license-pictures/' . $image);
            }
            return $src;
        }
    }

    public static function jqueryDateFormat($date) {
        if ($date) {
            $dates = date('m/d/Y', strtotime($date));
        }
        return $dates;
    }

//    public static function getLatLangByAddress($address) {
//        $latlangString = '';
//        $Address = urlencode($address);
//        $request_url = "http://maps.googleapis.com/maps/api/geocode/xml?address=" . $Address . "&sensor=true";
//        $xml = simplexml_load_file($request_url) or die("url not loading");
//        $status = $xml->status;
//        if ($status == "OK") {
//            $Lat = $xml->result->geometry->location->lat;
//            $Lon = $xml->result->geometry->location->lng;
//            $latlangString = "$Lat,$Lon";
//            return $latlangString;
//        } else {
//            return $latlangString;
//        }
//    }


    public static function getLatLangByAddress($address) {
        $latlangString = '';
        $Address = urlencode($address);
        $url = "https://maps.google.com/maps/api/geocode/json?key=AIzaSyC6UvgQK_Ua6wHk9J5Up0IcGJVPvko1lvI&address=$Address&sensor=true";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $response = curl_exec($ch);
        curl_close($ch);
        $response = json_decode($response);
        if ($response->status == "OK") {
            $lat = $response->results[0]->geometry->location->lat;
            $long = $response->results[0]->geometry->location->lng;
            $latlangString = $lat . "," . $long;
            return $latlangString;
        } else {
            return $latlangString;
        }
    }

    public static function getDistanceInMeters($picAddress, $dropAddress) {
        $picformtAddress = Helper::getLatLangByAddress($picAddress);
        $piclatlong = explode(',', $picformtAddress);
        $dropformtAddress = Helper::getLatLangByAddress($dropAddress);
        $droplatlong = explode(',', $dropformtAddress);
        $latitudeFrom = (!empty($piclatlong) && $piclatlong[0] != '') ? $piclatlong[0] : 22.719568;
        $longitudeFrom = (!empty($piclatlong) && $piclatlong[0] != '') ? $piclatlong[1] : 75.857727;
        $latitudeTo = (!empty($droplatlong) && $droplatlong[0] != '') ? $droplatlong[0] : 22.719568;
        $longitudeTo = (!empty($droplatlong) && $droplatlong[0] != '') ? $droplatlong[1] : 75.857727;
        $earthRadius = 6371000;
        $sql = " SELECT (
                    (
                        6373 *
                        acos(
                            cos( radians( '{$latitudeFrom}' ) ) *
                            cos( radians($latitudeTo ) ) *
                            cos(
                                radians( $longitudeTo ) - radians( '{$longitudeFrom}' )		
                            ) +
                            sin(radians('{$latitudeFrom}' ) ) *		
                            sin(radians( $latitudeTo) )
                        )
                        )
                    )  as distance";
        $miles = DB::select($sql);
        $distance = $miles[0]->distance;
        $time1 = $distance / 40;
        $time = $time1 * 3600;
        $days = floor($time / (60 * 60 * 24));
        if ($days < 10) {
            $days = '0' . $days;
        }
        $time -= $days * (60 * 60 * 24);
        $hours = floor($time / (60 * 60));
        if ($hours < 10) {
            $hours = '0' . $hours;
        }
        $time -= $hours * (60 * 60);
        $minutes = floor($time / 60);
        if ($minutes < 10) {
            $minutes = '0' . $minutes;
        }
        $time -= $minutes * 60;
        $seconds = floor($time);
        $time -= $seconds;
        return $value = $days . ' Days : ' . $hours . ' Hours : ' . $minutes . ' Minutes.';
    }

    public static function checkItemImage($image, $folder) {
        $src = url('public/images/upload-image.jpg');
        $fileName = public_path() . '/uploads/' . $folder . '/' . $image;
        if (!empty($image) && file_exists($fileName)) {
            $src = url('public/uploads/' . $folder . '/' . $image);
        }
        return $src;
    }

    public static function getDriverNameById($driverId) {
        $result = \App\Models\User::where(['id' => $driverId])->first();
        return ucfirst($result->first_name . ' ' . $result->last_name);
    }

    public static function getBusineessNameByVendorId($userId) {
        $data = \App\Models\VendorDetail::where(['user_id' => $userId])->first();
        return $data->business_name;
    }

    public static function getTopFiveRunningVendorOrders($userId) {
        $vendorOrderData = User::Join('orders', 'users.id', '=', 'orders.vendor_id')
                ->where('orders.vendor_id', $userId)
                ->where('orders.order_state', 'running')
                ->take(5)
                ->get();
        return $vendorOrderData;
    }

    public static function getVendorNameInOrdersByDriver($userId, $type) {
        $vendorOrderData = User::Join('orders', 'users.id', '=', 'orders.vendor_id')
                ->where('orders.vendor_id', $userId)
                ->where('orders.order_state', $type)
                ->first();
        return $vendorOrderData;
    }

    public static function getCustomerNameInOrdersByDriver($userId, $type) {
        $customerOrderData = User::Join('orders', 'users.id', '=', 'orders.customer_id')
                ->where('orders.customer_id', $userId)
                ->where('orders.order_state', $type)
                ->first();
        return $customerOrderData;
    }

    public static function getDriverRunningOrders($userId, $type) {
        $vendorOrderData = User::Join('orders', 'users.id', '=', 'orders.driver_id')
                ->where('orders.driver_id', $userId)
                ->where('orders.order_state', $type)
                ->get();
        return $vendorOrderData;
    }

    public static function getPriceFormatedValue($amount) {
        $amount = number_format($amount, 2);
        return $amount;
    }

    /*
     * This is for admin dashboard 
     */

    public static function getAllorderscount() {
        $orderscount = \App\Models\Order::all();
        $orders = $orderscount->count();
        return $orders;
    }

    public static function getAllitemscount() {
        $itemcount = \App\Models\Item::all();
        $items = $itemcount->count();
        return $items;
    }

    /*
     * This is for vendor dashboard 
     */

    public static function getorderscountbyId($id) {
        $orderscount = \App\Models\Order::where('vendor_id', $id)->get();
        $orders = $orderscount->count();
        return $orders;
    }

    public static function getitemscountbyId($id) {
        $itemcount = \App\Models\Item::where('business_id', $id)->get();
        $items = $itemcount->count();
        return $items;
    }
    public static function getTotalearningbyId($id) {
        $earnings =\App\Models\Order::getTotalearningbyId($id);
        return $earnings;
    }
    public static function getTotalearning() {
        $earnings =\App\Models\Order::getTotalearning();
        return $earnings;
    }

    public static function getNotificationCountById($id) {
        $notifications = \App\Models\OrderNotification::getAllNotificationsById($id);
        if (!empty($notifications)) {
            return $notifications->count();
        }
        return '0';
    }

    public static function getDriverCompletedOrders() {
        $userId = \Auth::user()->id;
        $orders = self::getDriverRunningOrders($userId, 'completed');
        if (!empty($orders)) {
            return $orders->count();
        }
        return '0';
    }

    public static function getPendingOrdersNotification($userId, $orderId) {
        $pendingOrderNotification = \App\Models\OrderNotification::Join('orders', 'order_notifications.order_id', 'orders.id')
                ->select('orders.*', 'order_notifications.*', 'order_notifications.created_at as notification_date')
                ->where('order_notifications.to_id', $userId)
                ->where('order_notifications.order_id', $orderId)
                ->where('orders.order_state', 'pending')
                ->first();
        if (!empty($pendingOrderNotification)) {
            return 'pending';
        } else {
            return 'not_pending';
        }
    }

    public static function getOrderRating($userId, $orderId) {
        $checkOrderRating = \App\Models\OrderNotification::leftJoin('ratings', 'order_notifications.order_id', 'ratings.order_id')
                ->select('order_notifications.*', 'ratings.*')
                ->where('ratings.order_id', $orderId)
                ->where('ratings.to_id', $userId)
                ->first();
        if (!empty($checkOrderRating)) {
            return 'rated';
        }
        return 'not_rated';
    }

    //get No of Days from Curent Date
    function getDaysCountFromDate($data) {
        $curentDate = date('Y-m-d');
        $fdate = $data;
        $tdate = $curentDate;
        $datetime1 = new DateTime($fdate);
        $datetime2 = new DateTime($tdate);
        $interval = $datetime1->diff($datetime2);
        $days = $interval->format('%a');
        return $days;
    }

}
