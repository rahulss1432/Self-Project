<?php if(count ($notifications) > 0): ?>
<div class="notification_list list-unstyled">
    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('admin.notifications._notification-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    <div id="appendanoti<?php echo e($notifications->currentPage()); ?>"></div>
    
    <?php echo e($notifications->links('vendor.pagination.simple-default')); ?>

    <?php else: ?>
      
            <?php echo \App\Helpers\Utility::emptyListMessage('notification'); ?></div>
     
    <?php endif; ?>
    <script>
        $(document).ready(function () {
            $(".pagination li a").on('click', function (e) {
                e.preventDefault();
                var pageLink = $(this).attr('href');
                $('#spinner').show();
                $.ajax({
                    type: 'POST',
                    url: pageLink,
                    data: {_token: '<?php echo e(csrf_token()); ?>'},
                    async: false,
                    success: function (response) {
                        $('.pagination:first').remove();
                        $("#appendanoti<?php echo e($notifications->currentPage()); ?>").append(response.html).hide().fadeIn(1000);
                        $('#spinner').hide();
                    }
                });
            });
        });
    </script>
