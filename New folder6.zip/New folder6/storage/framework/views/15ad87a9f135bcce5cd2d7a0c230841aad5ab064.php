<div class="search_section justify-content-between">
    <div class="row">
        <div class="col-12 text-right">
            <ul class="filter_right list-inline text-right mb-0">
                <li class="list-inline-item">
                    <a href="javascript:void(0);" class="btn btn-dark rounded-0 ripple-effect" onclick="getTestimonialcms(<?php echo e($pageId); ?>)">Add Testimonial</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="bg-white box-shadow common_table">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Customer Image</th>
                    <th>Name</th>
                    <th>Content</th>
                    <th>Action</th>
                </tr>
            </thead>
            <?php if($testimonialData->count()>0): ?>
            <?php $i=1; ?>
                <?php $__currentLoopData = $testimonialData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                if ($testimonialData->currentPage() == 1) {
                    $srNo = $i++;
                } else {
                    $srNo = ($testimonialData->currentPage() - 1) * $testimonialData->perPage() + $i++;
                }
            ?>
            <tbody>
                <tr>
                    <td width="150">
                        <img src="<?php echo e(url('public/uploads/testimonial/'.$data->customer_image)); ?>" alt="user" width="40" class="rounded-circle">
                    </td>
                    <td width="150"><?php echo e($data->customer_name); ?></td>
                    <td><?php echo e($data->customer_content); ?></td>
                    <td width="100">
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="javascript:void(0);" onclick="getTestimonialCmsEdit()">Edit</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
            <tr>
            <tr>
              <td colspan="6"><?php \App\Helpers\Utility::emptyListMessage('transaction'); ?></td>
            </tr>
            </tr>
            <?php endif; ?>
        </table>
        <!-- <div class="pagination_section box-shadow bg-white mt-3" id="paginationList" style="">
        <div class="d-sm-flex align-items-center">
            <div class="ml-sm-auto">
                <div class="pagination_right">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination mb-0">
                            <?php echo e($testimonialData->links()); ?>

                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div> -->
    </div>
</div>
