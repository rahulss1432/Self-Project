<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" id="home">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">        
        <meta name="format-detection" content="telephone=no">
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <!-- favi icon -->
        <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(url('public/assets/images/favi-icon/apple-touch-icon.png')); ?>">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('public/assets/images/favi-icon/favicon-32x32.png')); ?>">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('public/assets/images/favi-icon/favicon-16x16.png')); ?>">
        <link rel="manifest" href="<?php echo e(url('public/assets/images/favi-icon/site.webmanifest')); ?>">
        <link rel="mask-icon" href="<?php echo e(url('public/assets/images/favi-icon/safari-pinned-tab.svg')); ?>" color="#5bbad5">
        <meta name="msapplication-TileColor" content="#2d89ef">
        <meta name="theme-color" content="#2c72ff">

        <!-- link -->
        <link  href="<?php echo e(url('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <link  href="<?php echo e(url('public/assets/css/aos.css')); ?>" rel="stylesheet" type="text/css">
        <link  href="<?php echo e(url('public/assets/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('public/assets/css/custom.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('public/assets/css/toastr.min.css')); ?>" rel="stylesheet" type="text/css">
        <script src="<?php echo e(url('public/assets/js/jquery.min.js')); ?>"></script>


        <title> <?php echo $__env->yieldContent('title'); ?></title>
    </head>  
    <body>
        <?php if(\Request::route()->getName() == 'index'): ?> 
        <?php echo $__env->make('layouts.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php else: ?>
        <?php echo $__env->make('layouts.include.inner-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('layouts.include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php if(session()->has('success')): ?>
        <script>
$(document).ready(function () {
    toastr.remove();
    toastr.options.closeButton = true;
    toastr.success("<?php echo session('success'); ?>", 'Success', {timeOut: 3000});
});
        </script>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
        <script>
            $(document).ready(function () {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error("<?php echo session('error'); ?>", 'Error', {timeOut: 3000});
            });
        </script>
        <?php endif; ?>

        <script src="<?php echo e(url('public/assets/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/assets/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/assets/js/aos.js')); ?>"></script>
        <script src="<?php echo e(url('public/assets/js/toastr.js')); ?>"></script>
        <script src="<?php echo e(url('/public/assets/js/jsvalidation.js')); ?>"></script>
        <script>
            $(document).ready(function () {
                $(".tab1").click(function () {
                    $(this).addClass("active");
                    $(".tab2, .tab3").removeClass("active");
                });
                $(".tab2").click(function () {
                    $(this).addClass("active");
                    $(".tab1, .tab3").removeClass("active");
                });
                $(".tab3").click(function () {
                    $(this).addClass("active");
                    $(".tab1, .tab2").removeClass("active");
                });
            });

            $(window).scroll(function () {
                if ($(window).scrollTop() >= 300) {
                    $('nav').addClass('fixed-top');
                    $('header').addClass('stickynav');
                }
                else {
                    $('nav').removeClass('fixed-top');
                    $('header').removeClass('stickynav');
                }
            });

            $(document).ready(function () {
                //loadnav();
            });
            function loadnav() {
                var href = location.hash,
                        offsetTop = href === "#" ? 0 : $(href).offset() - topMenuHeight + 1;
                $('html, body').stop().animate({
                    scrollTop: offsetTop
                }, 1000);
                history.pushState(null, null, '#');
            }


            var lastId,
                    topMenu = $("#nav"),
                    topMenuHeight = topMenu.outerHeight() - 50,
                    // All list items
                    menuItems = topMenu.find("#homenav li a"),
                    // Anchors corresponding to menu items
                    scrollItems = menuItems.map(function () {

                        var item = $($(this).attr("href"));
                        if (item.length) {
                            return item;
                        }
                    });

            // Bind click handler to menu items
            // so we can get a fancy scroll animation
            menuItems.click(function (e) {

                var href = $(this).attr("href"),
                        offsetTop = href === "#" ? 0 : $(href).offset().top - topMenuHeight + 1;
                $('html, body').stop().animate({
                    scrollTop: offsetTop
                }, 1000);
                e.preventDefault();
                if ($(this).attr("href") == "#blog") {
                    window.location.href = "<?php echo e(url('/blog')); ?>";
                }
            });


            // Bind to scroll
            $(window).scroll(function () {
                // Get container scroll position
                var fromTop = $(this).scrollTop() + topMenuHeight;
                // Get id of current scroll item
                var cur = scrollItems.map(function () {

                    if ($(this).offset().top < fromTop)
                        return this;
                });
                // console.log(scrollItems);
                // Get the id of the current element
                cur = cur[cur.length - 1];
                var id = cur && cur.length ? cur[0].id : "";
                if (lastId !== id) {
                    lastId = id;
                    // Set/remove active class
                    menuItems
                            .parent().removeClass("active")
                            .end().filter("[href='#" + id + "']").parent().addClass("active");
                    //history.pushState(null, null, '#'+id);
                }
            });
        </script>
        <script type="text/javascript">
            var rotate = 1;

            function hide_preloader() {
                rotate = 0;
                $("#preloader").fadeOut('slow');
            }

        </script>
        <script>
            AOS.init({
                easing: 'ease-in-out-sine',
                disable: 'mobile'
            });

            $('.nav-link').on('shown.bs.tab', function (e) {
                AOS.init({
                    easing: 'ease-in-out-sine',
                    disable: 'mobile'
                });
            });



        </script>

    </body>
</html>


