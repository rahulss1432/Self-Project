<?php $__env->startSection('title', 'Add Lawyer'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray" onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content cms-edit" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent" >
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Add Lawyer</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a id="back-loader" onclick="backfunction()" href="<?php echo e(url('admin/lawyer')); ?>" class="nav-link">
                <i class="fa fa-long-arrow-left"></i>
              </a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <form class="f-field" id="addLawyerForm" method="POST" action="<?php echo e(url('admin/save-lawyer')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="row">
              <div class="col-md-3 col-sm-6">
                <div class="form-group">
                  <label class="control-label">First Name <span class="red-star">*</span></label>  
                  <input type="text" name="first_name" class="form-control form-control-lg">
                </div>
              </div> 
              <div class="col-md-3 col-sm-6">
                <div class="form-group">
                  <label class="control-label">Last Name <span class="red-star">*</span></label>  
                  <input type="text" name="last_name" class="form-control form-control-lg">
                </div>
              </div> 
              <div class="col-md-3 col-sm-6">
                <div class="form-group">
                  <label class="control-label">Email<span class="red-star"> *</span></label>
                  <input type="text" name="email" class="form-control form-control-lg">
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="form-group">
                  <label class="control-label">Phone Number<span class="red-star"> *</span></label>
                  <input type="text" name="phone" class="form-control form-control-lg">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-3 col-sm-6">
                <div class="form-group">
                  <label class="control-label">Title<span class="red-star"> *</span></label>
                  <input type="text" name="title" class="form-control form-control-lg">
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="form-group">
                  <label class="control-label">About<span class="red-star"> *</span></label>
                  <input type="text" name="about" class="form-control form-control-lg">
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="form-group">
                  <label class="control-label">Password<span class="red-star"> *</span></label>
                  <input type="password" name="password" class="form-control form-control-lg">
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="form-group">
                  <label class="control-label">Confirm Password<span class="red-star"> *</span></label>
                  <input type="password" name="confirm_password" class="form-control form-control-lg">
                  <input type="hidden" name="user_type" class="form-control form-control-lg" value="lawyer">
                </div>
              </div>           
            </div>
            <div class="from-group">
              <button type="submit" class="btn btn-primary btn_radius" id="save-loader"> Save</button>
            </div>
          </form>
          <?php echo JsValidator::formRequest('App\Http\Requests\AddLawyerRequest','#addLawyerForm'); ?>

        </div>
      </div>
    </div>
  </main>

  <script type="text/javascript">

    $('.form-group .form-control').focus(function () 
    {
      $(this).parent().addClass('isfocused');
    }).blur(function () 
    {
      $(this).parent().removeClass('isfocused');
    });

   
    function backfunction()
    {
      $("#back-loader").attr("disabled", true);
      $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    }

    window.addEventListener('beforeunload', function(event)
    {
      $("#save-loader").attr("disabled", true);
      $("#save-loader").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
    });

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>