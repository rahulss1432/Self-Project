<?php if(!empty($planList)): ?>
<?php $__currentLoopData = $planList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php  $userInfo=\App\Models\User::getUserById(Auth::user()->id); ?>
<div class="col-lg-3 col-sm-6 column">
    <div class="card <?php echo e(((!empty(Auth::user()->id)) && ($userInfo->getActivePlan->plan_id==$planInfo['id']))?'active':''); ?>">
        <div class="card-header text-center"><?php echo e($planInfo['plan_name']); ?>

            <span><?php echo e(\App\Helpers\Utility::getPriceFormat($planInfo['price'])); ?></span>
            <small>/ month</small>
        </div>
        <div class="card-body">
            <ul class="list-unstyled mb-0">
                <?php if(!empty($planInfo->getDetails)): ?>
                <?php $__currentLoopData = $planInfo->getDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($detailInfo['description']); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
            <?php if(!empty(Auth::user()->id)): ?>
                <?php
               
                    $activePrice=0;
                    if($userInfo->getActivePlan->plan_id==$planInfo['id']){
                        $activePrice=$planInfo['price'];
                    }
                ?>
                <?php if($activePrice<=$planInfo['price'] && $planInfo['price']>0): ?>
                    <a class="text-uppercase btn btn-success ripple-effect-dark" href="javascript:void(0);">UPGRADE NOW</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


