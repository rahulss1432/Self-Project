<?php if(count($police) > 0): ?>
  <table class="table admin-table" id="data_table">
    <thead>
      <tr>
        <th>State</th>
        <th>City</th>
        <th>Police Department</th>
        <th>Chief of Police</th>
        <th>Contact Number</th>
        <th>Email</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $police; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e('police'.$data->id); ?>">
          <td class="text-capitalize"><span style="display:none;">$data->id</span><?php echo e(ucfirst($data->state_name)); ?></td>
          <td class="text-capitalize"><?php echo e(ucfirst($data->city_name)); ?></td>
          <td><?php echo e(ucfirst($data->police_department)); ?></td>
          <td><?php echo e(ucfirst($data->chief_of_police)); ?></td>
          <td class="text-capitalize"><?php echo e($data->contact_number); ?></td>
          <td><?php echo e($data->email); ?></td>
          <td>
            <ul class="list-inline mb-0 ">
              <li class="list-inline-item">
                <a id="view-loader<?php echo e($data->id); ?>" onclick="viewfunction(<?php echo e($data->id); ?>)" href="<?php echo e(url('admin/police-department-view',$data->id)); ?>"><i class="fa fa-eye"></i></a>
              </li>
              <li class="list-inline-item">
                <a id="edit-loader<?php echo e($data->id); ?>" onclick="editfunction(<?php echo e($data->id); ?>)" href="<?php echo e(url('admin/police-department-edit',$data->id)); ?>"><i class="fa fa-pencil"></i></a>
              </li> 
              <li class="list-inline-item">
                <a id="delete-loader<?php echo e($data->id); ?>" href="javascript:void(0);" onclick="deletefunction(<?php echo e($data->id); ?>)"><i class="fa fa-trash"></i></a>
              </li>
            </ul>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php else: ?>
    <div class="alert alert-danger"><center>No police department available.</center></div>
<?php endif; ?>