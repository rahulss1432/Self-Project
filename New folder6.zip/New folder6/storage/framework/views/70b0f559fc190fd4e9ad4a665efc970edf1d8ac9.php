<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('content'); ?>

<link  href="<?php echo e(url('public/assets/css/jquery.mCustomScrollbar.css')); ?>" rel="stylesheet" type="text/css">
<script src="<?php echo e(url('public/js/jssocials.js')); ?>"></script>
<main class="main_content" id="maincontent" >
    <!-- Terms And Conditions -->
    <div class="blog-page" id="blog">
        <div class="container">
            <div class="heading clearfix float-left">
                <h2>Blog</h2>
                <hr class="float-left">

            </div>
            <div class="search_blog float-right">
                <form id="search_form" method="get" autocomplete="off">
                    <?php echo e(csrf_field()); ?>

                    <input class="form-control mr-sm-2" onkeyup="blogList()"name="title" type="search" placeholder="Search">
                </form>
            </div>
            <div class="clearfix"></div>
            <div class="blog-listing">
                <div class="">
                    <div class="row" id="blog_listtt"></div>
                </div>
            </div>
        </div>
    </div>
</main>
<!--  -->
<div class="modal fade modal-center users_like" id="postview" data-backdrop="static" data-keyboard="false" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="users_like" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="commentList">

        </div>
    </div>
</div>

<script src="<?php echo e(url('public/assets/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>

<script type="text/javascript">
// post view content list load
$(document).ready(function ()
{
    blogList();
});

function blogList() {
    console.log('hello');
    var search_filter = $("#search_form").serializeArray();
    search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
    $.ajax({
        type: "get",
        url: "<?php echo e(url('blog-list')); ?>",
        data: search_filter,
        success: function (response)
        {
            $("#blog_listtt").html('');
            $("#blog_listtt").html(response.html);

        }, error: function (err)
        {
            console.log(err);
        }
    });
}

function openModalone(id) {
    $("#commentList").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
    $.ajax({
        type: "get",
        url: "<?php echo e(url('blog-like-list')); ?>",
        data: {id: id},
        success: function (response)
        {
            $("#commentList").html(response.html);
            $("#postview").modal('show');

        }, error: function (err)
        {
            console.log(err);
        }, complete: function ()
        {
            $(".user_like_scroll").mCustomScrollbar({
                theme: "dark"
            });
            var custom_margin = 150;
            if ($(window).width() <= 767) {
                var custom_margin = 74;
            }
            if ($(window).width() <= 480) {
                var custom_margin = 90;
            }
            $(window).resize(function () {
                var chk_account_height = $('.modal-header').outerHeight(true);
                var window_height = $(window).height();
                $(".user_like_scroll").css('max-height', window_height - chk_account_height - custom_margin);
            }).resize();
        }
    });


}

</script>
<!--  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>