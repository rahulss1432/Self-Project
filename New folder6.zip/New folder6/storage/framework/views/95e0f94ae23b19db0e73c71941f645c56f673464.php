<?php $__env->startSection('content'); ?>
<main class="main-content home-page">
    <section class="banner-section">
        <div class="container">
            <div class="banner-content">
                <h1 class="font-bold">Get your copy of the <br class="d-none d-sm-block"> Book</h1>
                <h3 class="font-pro">Lorem Ipsum is simply dummy text of the printing and typesetting <br class="d-none d-md-block"> industry. Lorem Ipsum has been the industry's standard.</h3>

                <a href="product-detail.php" class="btn btn-primary ripple-effect text-uppercase">BUY NOW</a>
            </div>
        </div> 
    </section>

    <!-- xxxxxxx -->

    <section class="book-section common-pad" id="purchaseBook">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <img src="<?php echo e(url('public/images/book.png')); ?>" alt="book" class="img-fluid"/>
                </div>

                <div class="col-md-8">

                    <div class="row">
                        <div class="col-lg-6">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>

                            <p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containig Ipsum</p>

                            <p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containig Ipsum.</p>
                        </div>

                        <div class="col-lg-6">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>

                            <p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containig Ipsum</p>

                            <p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containig Ipsum.</p>

                            <a href="javscript:void(0);" class="font-bold text-right d-block read-more">read more...</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <a href="product-detail.php" class="btn btn-primary text-uppercase ripple-effect">buy now</a>
                        </div>
                    </div>

                </div>


            </div>
        </div>
    </section>

    <!-- xxxxxxx -->

    <section class="podcast-section common-pad" id="podcast">

        <h2 class="common-heading text-uppercase text-center">
            LISTEN TO THE PODCASTS
        </h2>

        <div class="container">


            <div class="row custom-gutters">
                <div class="col-lg-3 col-sm-6">
                    <div class="podcast-box" style="background-image: <?php echo e(url('pubilc/images/podcast01.jpg')); ?>">
                        <div class="position-div">
                            <h2>Contrary to popular belief, Lorem Ipsum is </h2>

                            <div class="hidden-item">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's</p>

                                <a href="javascript:void(0);">
                                    <img src="<?php echo e(url('public/images/play-icon.png')); ?>" alt="Play"/> Play
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-sm-6">
                    <div class="podcast-box" style="background-image: <?php echo e(url('public/images/podcast02.jpg')); ?>">
                        <div class="position-div">
                            <h2>Contrary to popular belief, Lorem Ipsum is </h2>

                            <div class="hidden-item">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's</p>

                                <a href="javascript:void(0);">
                                    <img src="<?php echo e(url('public/images/play-icon.png')); ?>" alt="Play"/> Play
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-sm-6">
                    <div class="podcast-box" style="background-image: <?php echo e(url('public/images/podcast03.jpg')); ?>">
                        <div class="position-div">
                            <h2>Contrary to popular belief, Lorem Ipsum is </h2>

                            <div class="hidden-item">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's</p>

                                <a href="javascript:void(0);">
                                    <img src="<?php echo e(url('public/images/play-icon.png')); ?>" alt="Play"/> Play
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-sm-6">
                    <div class="podcast-box" style="background-image: <?php echo e(url('public/images/podcast04.jpg')); ?>">
                        <div class="position-div">
                            <h2>Contrary to popular belief, Lorem Ipsum is </h2>

                            <div class="hidden-item">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's</p>

                                <a href="javascript:void(0);">
                                    <img src="<?php echo e(url('public/images/play-icon.png')); ?>" alt="Play"/> Play
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="view-more-wrap">
                <a href="podcast-listing.php" class="section-view-more">View More</a>
            </div>
        </div>
    </section>

    <!-- xxxxxxx -->

    <section class="blog-section common-pad" id="blog">
        <h2 class="common-heading text-uppercase text-center">
            blogs
        </h2>

        <div class="container">



            <div class="row">
                <div class="col-md-12 col-lg-4">
                    <a href="blog-detail.php" class="blog-wrap first-blog">
                        <div class="blog-img" style="background-image: <?php echo e(url('public/images/blog01.jpg')); ?>"></div>
                        <div class="blog-info">
                            <h2>Philosophy as a Science </h2>
                            <p class="mb-0">Mar 12 2018</p>
                        </div>
                    </a>
                </div>

                <!-- xxxxxxxxx -->

                <div class="col-md-12 col-lg-4">

                    <div class="row">
                        <div class="col-md-6 col-lg-12 col-12">
                            <a href="blog-detail.php" class="blog-wrap">
                                <div class="blog-img" style="background-image: <?php echo e(url('public/images/blog02.jpg')); ?>"></div>
                                <div class="blog-info">
                                    <h2>Philosophy as a Science </h2>
                                    <p class="mb-0">Mar 12 2018</p>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-6 col-lg-12 col-12">
                            <a href="blog-detail.php" class="blog-wrap">
                                <div class="blog-img" style="background-image: <?php echo e(url('public/images/blog03.jpg')); ?>"></div>
                                <div class="blog-info">
                                    <h2>Philosophy as a Science </h2>
                                    <p class="mb-0">Mar 12 2018</p>
                                </div>
                            </a>
                        </div>
                    </div>

                </div>

                <!-- xxxxxxxxx -->

                <div class="col-md-12 col-lg-4">
                    <div class="blog-list">
                        <ul class="list-unstyled">
                            <li>
                                <div class="img-wrap">
                                    <img src="<?php echo e(url('public/images/blog-more01.jpg')); ?>" alt="blog" class="img-fluid" />
                                </div>


                                <div class="right-side">
                                    <a href="blog-detail.php">Contrary to popular belief, Lorem Ipsum is not </a>
                                    <p>Mar 12 2018</p>
                                </div>
                            </li>

                            <li>
                                <div class="img-wrap">
                                    <img src="<?php echo e(url('public/images/blog-more02.jpg')); ?>" alt="blog" class="img-fluid" />
                                </div>


                                <div class="right-side">
                                    <a href="blog-detail.php">Contrary to popular belief, Lorem Ipsum is not </a>
                                    <p>Mar 12 2018</p>
                                </div>
                            </li>

                            <li>
                                <div class="img-wrap">
                                    <img src="<?php echo e(url('public/images/blog-more03.jpg')); ?>" alt="blog" class="img-fluid" />
                                </div>


                                <div class="right-side">
                                    <a href="blog-detail.php">Contrary to popular belief, Lorem Ipsum is not </a>
                                    <p>Mar 12 2018</p>
                                </div>
                            </li>

                            <li>
                                <div class="img-wrap">
                                    <img src="<?php echo e(url('public/images/blog-more04.jpg')); ?>"}} alt="blog" class="img-fluid" />
                                </div>


                                <div class="right-side">
                                    <a href="blog-detail.php">Contrary to popular belief, Lorem Ipsum is not </a>
                                    <p>Mar 12 2018</p>
                                </div>
                            </li>


                        </ul>
                    </div>
                </div>
            </div>

            <div class="view-more-wrap">
                <a href="blog-listing.php" class="section-view-more">View More</a>
            </div>
        </div>
    </section>


    <!-- xxxxxxx -->


    <section class="deniel-section common-pad" id="danielZeman">
        <div class="container">
            <div class="deniel-wrapper">
                <div class="row">
                    <div class="col-md-5">
                        <img src="<?php echo e(url('public/images/daniel-zeman.jpg')); ?>" alt="daniel-zeman" class="img-fluid" />
                    </div>

                    <!-- xxxxxxxx -->

                    <div class="col-md-7">
                        <div class="details">
                            <h2 class="font-bold">DANIEL ZEMAN</h2>
                            <h3>M.S. Bio</h3>


                            <h5>"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard."</h5>


                            <div class="row">
                                <div class="col-lg-12 col-xl-6">
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>

                                    <p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containig Ipsum.</p>
                                </div>

                                <div class="col-lg-12 col-xl-6">
                                    <p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containig Ipsum.</p>

                                    <p>
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <!-- xxxxxxx -->

    <section class="testimonial-section common-pad">
        <h2 class="common-heading text-center">
            What People Say...
        </h2>
        <p class="sub-heading text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <div class="container">
            <div class="testimonial-wrap">
                <div id="userTestimonial">
                    <div class="slide">
                        <div class="testimonial-box">
                            <div class="img-wrap">
                                <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" alt="user" class="rounded-circle img-fluid" />  
                            </div>

                            <p>
                                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                            </p>

                            <h5 class="text-center">Hunter Hemls</h5>
                        </div>
                    </div>

                    <!-- xxxxxxxxx -->

                    <div class="slide">
                        <div class="testimonial-box">
                            <div class="img-wrap">
                                <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" alt="user" class="rounded-circle img-fluid" />  
                            </div>

                            <p>
                                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                            </p>

                            <h5 class="text-center">Hunter Hemls</h5>
                        </div>
                    </div>

                    <!-- xxxxxxxxx -->

                    <div class="slide">
                        <div class="testimonial-box">
                            <div class="img-wrap">
                                <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" alt="user" class="rounded-circle img-fluid" />  
                            </div>

                            <p>
                                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                            </p>

                            <h5 class="text-center">Hunter Hemls</h5>
                        </div>
                    </div>

                    <!-- xxxxxxxxx -->

                    <div class="slide">
                        <div class="testimonial-box">
                            <div class="img-wrap">
                                <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" alt="user" class="rounded-circle img-fluid" />  
                            </div>

                            <p>
                                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                            </p>

                            <h5 class="text-center">Hunter Hemls</h5>
                        </div>
                    </div>

                    <!-- xxxxxxxxx -->

                    <div class="slide">
                        <div class="testimonial-box">
                            <div class="img-wrap">
                                <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" alt="user" class="rounded-circle img-fluid" />  
                            </div>
                            <p>
                                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                            </p>
                            <h5 class="text-center">Hunter Hemls</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- xxxxxxx -->
              <!--   <section class="signup-section common-pad" >
                    <div class="container">
                        <div class="signup-wrap">
                            <img src="assets/images/inbox-book01.png" alt="inbox-book0" class="signup-img01" />
                            <img src="assets/images/inbox-book02.png" alt="inbox-book0" class="signup-img02" />
    
                            <h2 class="font-bold">
                                Get the latest news and stories delivered to your inbox.
                            </h2>
    
                            <a href="javascript:void(0);" class="btn btn-secondary text-uppercase ripple-effect-dark">sign up</a>
                        </div>
                    </div>
                </section> -->
</main>

<script src="<?php echo e(url('public/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(url('public/js/slick.min.js')); ?>"></script> 
<script>
    $('#userTestimonial').slick({
        dots: true,
        arrows: false,
        autoplay: true,
        autoplaySpeed:3000,
        speed: 300,
        slidesToShow:1,
        slidesToScroll:1,
    });

    // menu scroll header
    var lastId,
    topMenu = $(".topheader"),
    topMenuHeight = topMenu.outerHeight() - 40,
    // All list items
    menuItems = topMenu.find("a"),
    // Anchors corresponding to menu items
    scrollItems = menuItems.map(function () {
        var item = $($(this).attr("href"));
        if (item.length) {
            return item;
        }
    });

    // Bind click handler to menu items
    // so we can get a fancy scroll animation
    menuItems.click(function (e) {
        var href = $(this).attr("href"), offsetTop = href === "#" ? 0 : $(href).offset().top - topMenuHeight + 1;
        $('html, body').stop().animate({
            scrollTop: offsetTop
        }, 1000);
        e.preventDefault();
    });

    // Bind to scroll
    $(window).scroll(function () {
        // Get container scroll position
        var fromTop = $(this).scrollTop() + topMenuHeight;

        // Get id of current scroll item
        var cur = scrollItems.map(function () {
            if ($(this).offset().top < fromTop)
                return this;
        });
        // Get the id of the current element
        cur = cur[cur.length - 1];
        var id = cur && cur.length ? cur[0].id : "";

        if (lastId !== id) {
            lastId = id;
            // Set/remove active class
            menuItems
                    .parent().removeClass("active")
                    .end().filter("[href='#" + id + "']").parent().addClass("active");
        }
    });

    // if redirect from other page to home page then
    //console.log(window.location.hash);

    if(window.location.hash == '#purchaseBook'){
        var href = '#purchaseBook';
        var offsetTop = $(href).offset().top - topMenuHeight + 1;
        $('html, body').stop().animate({
            scrollTop: offsetTop
        }, 1000);
        e.preventDefault();
    }

    if(window.location.hash == '#podcast'){
        var href = '#podcast';
        var offsetTop = $(href).offset().top - topMenuHeight + 1;
        $('html, body').stop().animate({
            scrollTop: offsetTop
        }, 1000);
        e.preventDefault();
    }

    if(window.location.hash == '#blog'){
        var href = '#blog';
        var offsetTop = $(href).offset().top - topMenuHeight + 1;
        $('html, body').stop().animate({
            scrollTop: offsetTop
        }, 1000);
        e.preventDefault();
    }

    if(window.location.hash == '#danielZeman'){
        var href = '#danielZeman';
        var offsetTop = $(href).offset().top - topMenuHeight + 1;
        $('html, body').stop().animate({
            scrollTop: offsetTop
        }, 1000);
        e.preventDefault();
    }
             
</script>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>