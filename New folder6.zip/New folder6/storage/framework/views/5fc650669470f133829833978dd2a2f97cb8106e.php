<table class="table mb-0">
    <thead>
        <tr>
            <th>Customer Name </th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Address</th>
            <th>Date & Time</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if(count($userList)>0): ?>
        <?php $__currentLoopData = $userList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($list->first_name); ?> <?php echo e($list->last_name); ?></td>
            <td><?php echo e($list->email); ?></td>
            <td><?php echo e($list->phone); ?></td>
            <td><?php echo e($list->address); ?></td>
            <td><?php echo e(\App\Helpers\Utility::getDateTimeFormat($list->created_at)); ?></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" <?php echo e(($list['status']=='enabled')?'checked="checked"':''); ?> onchange="updateStatus('<?php echo e($list["id"]); ?>');" name="status[]" value="<?php echo e($list['status']); ?>">
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <div class="action_dropdown">
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                            <a class="dropdown-item" href="<?php echo e(url('/admin/view/'.$list["id"])); ?>">View</a>
                            <a class="dropdown-item" href="<?php echo e(url('/admin/edit/'.$list["id"])); ?>">Edit</a>                            
                        </div>
                    </div>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td colspan="7">
                <?php echo e(\App\Helpers\Utility::emptyListMessage('user')); ?>

            </td>
        </tr>
        <?php endif; ?>

    </tbody>                    
</table>
<script>
    function updateStatus(id) {
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('/admin/update-user-status')); ?>",
            data: {
                '_token': "<?php echo e(csrf_token()); ?>",
                'id': id
            },
            success: function (response) {
                if (response.status) {
                    successToaster(response.message, 'User Status');
                }
            }
        });
    }
</script>