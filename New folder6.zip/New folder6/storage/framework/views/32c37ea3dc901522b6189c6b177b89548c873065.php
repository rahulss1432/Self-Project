<header class="<?php echo e((strpos(\Request::path(), 'user/') === false && \Request::route()->getName() != 'user.job-listing')?'dashboard-header header after_login':'dashboard-header fixed-top'); ?>" id="<?php echo e((strpos(\Request::path(), 'user/') === false && \Request::route()->getName() != 'user.job-listing')?'main_header':'top-header'); ?>">
    <div class="container-fluid">
        <?php if(auth()->guard()->guest()): ?>
        <nav class="navbar navbar-expand-md">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(url('public/images/logo.svg')); ?>" class="logo_white" alt="Rezieo">
            </a>
            <ul class="navbar-nav d-inline-block d-md-flex ml-auto">
                <li class="nav-item align-middle">
                    <a class="nav-link text-uppercase btn-success btn ripple-effect-dark" href="<?php echo e(url('/login')); ?>">Login</a>
                </li>
                <li class="nav-item align-middle">
                    <a class="nav-link text-uppercase btn btn-outline-light ripple-effect-dark" href="<?php echo e(url('/register')); ?>">Register Now</a>
                </li>
            </ul>
        </nav>
        <?php else: ?>
        <nav class="navbar navbar-light">
            <div class="navbar-brand">
                <a href="<?php echo e(url('/')); ?>" class="d-inline-block">
                    <div class="logo">
                        <img src="<?php echo e(url('public/images/logo.svg')); ?>" title="Rezieo" alt="logo">
                    </div>
                </a>
                <div class="toglle">
                    <div class="toggle-icon d-xl-none">
                        <i class="fa fa-bars"></i>
                    </div>
                </div>
            </div>
            <ul class="nav ml-auto right-utility seeker_header">
                <?php $activePlan=\App\Models\PlanSubscription::getActivePlan(); $alertDate=strtotime(date("Y-m-d"). ' + 10 day'); ?>
                <?php if(!empty($activePlan)): ?>
                <li class="nav-item d-none d-lg-inline-flex">
                    <?php if($alertDate >= strtotime($activePlan->expiry_date)): ?>
                    <a href="<?php echo e(url('/user/my-plan')); ?>" class="nav-link executive">The validity period of a plan is about to expire - <?php echo e(\App\Helpers\Utility::getDateFormat($activePlan->expiry_date)); ?>.</a>
                    <?php else: ?>
                    <?php $bigPlan=\App\Models\Plan::getBigPlan($activePlan->amount); ?>
                    <a href="<?php echo e(url('/user/my-plan')); ?>" class="nav-link executive">Get more out of Rezieo   <?php echo e((!empty($bigPlan))?'- Get '.$bigPlan->plan_name:''); ?></a>
                    <?php endif; ?>
                </li>
                <?php endif; ?>
                <?php if(Auth::user()->user_type!='employer'): ?>
                <li class="nav-item d-none d-lg-inline-flex <?php echo e(( \Request::route()->getName() == 'user.job-listing') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/job-listing')); ?>" class="nav-link">JOB LISTING</a>
                </li>
                <?php endif; ?>
                <li class="nav-item d-none d-lg-inline-flex <?php echo e(( \Request::route()->getName() == 'user.dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/user/dashboard')); ?>" class="nav-link">DASHBOARD</a>
                </li>
                <li class="nav-item dropdown notification">

                    <?php $notificationList=\App\Models\Notification::getNotifications(['userId'=>Auth::user()->id,'status'=>'unread']); ?>

                    <a class="nav-link dropdown-toggle bell <?php echo e((\Request::route()->getName() == 'user.notifications') ? 'active' : ''); ?>" href="#" role="button" id="notificationDrop" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-bell"></i>
                        <span class="count"><?php echo e($notificationList->count()); ?></span>
                    </a>
                    <div class="dropdown-menu common-box" aria-labelledby="notificationDrop">
                        <div class="headline">
                            <h3 class="font-md mb-0"> Notifications</h3>
                        </div>
                        <ul class="list-unstyled">

                            <?php if($notificationList->count()>0): ?>
                            <div class="scroll_notification">
                                <?php $__currentLoopData = $notificationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('user.notifications._notification-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php else: ?>
                            
                            <li class="no-record">
                            	<?php echo \App\Helpers\Utility::emptyListMessage('notification'); ?>
                            </li>
                            <?php endif; ?>

                            <li class="text-center d-block view-all">
                                <a href="<?php echo e(url('/user/notifications')); ?>" >VIEW ALL</a>
                            </li>
                        </ul>
                    </div>
                </li>
                <!--<li class="nav-item"><a href="#" class="nav-link"><i class="icon-feather-mail"></i><span class="count">4</span></a></li>-->
                <li class="nav-item dropdown user-avtar">
                    <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="<?php echo e(\App\Helpers\Utility::checkProfileImage(Auth::user()->profile_image)); ?>" class="rounded-circle img-thumbnail profileImage">
                        <span class="username"><?php echo e(Auth::user()->first_name.' '.Auth::user()->last_name); ?></span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                        <div class="user-details d-flex align-items-center">
                            <div class="user-avatar status-online"><img class="profileImage" src="<?php echo e(\App\Helpers\Utility::checkProfileImage(Auth::user()->profile_image)); ?>" alt=""></div>
                            <div class="user-name">
                                <?php echo e(Auth::user()->first_name.' '.Auth::user()->last_name); ?> <span> 
                                    <?php $userType=\App\Models\UserType::getUserTypeId(Auth::user()->user_type); ?>
                                    <?php echo e(ucfirst($userType->label_name)); ?>

                                </span>
                            </div>
                        </div>
                        <a class="dropdown-item <?php echo e((\Request::route()->getName() == 'user.view-profile') ? 'active' : ''); ?>" href="<?php echo e(url('/user/view-profile')); ?>">View Profile</a>
                        <a class="dropdown-item <?php echo e((\Request::route()->getName() == 'user.edit-profile') ? 'active' : ''); ?>" href="<?php echo e(url('/user/edit-profile')); ?>">Edit Profile</a>
                        <a class="dropdown-item <?php echo e((\Request::route()->getName() == 'user.change-password') ? 'active' : ''); ?>" href="<?php echo e(url('/user/change-password')); ?>">Change Password</a>
                        <a class="dropdown-item" href="<?php echo e(url('/logout')); ?>">Logout</a> 
                    </div>
                </li>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</header>

 <?php if(!empty(session()->get('userSession'))): ?>
    <?php $userData=session()->get('userSession'); ?>
        <?php if(empty($userData['user_type'])): ?>
<div class="modal fade modal-loginwith" id="loginWith" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="loginWith" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title m-auto" id="addskillsModal">CONTINUE WITH <span id="signupType"></span></h5>
                    </div>
                    <div class="modal-body">
                        <div class="content">
                            <form class="form-horizontal" id="update-account-form" method="POST" action="<?php echo e(url('/update-account-type')); ?>">
                                <?php echo e(csrf_field()); ?>

                            <div class="option_buttons text-center">
                                <h5>Choose User Type</h5>
                                 <?php 
                                        $userTypes=\App\Models\UserType::getListedType();
                                    ?>
                                    <?php if(!empty($userTypes)): ?>
                                        <?php $__currentLoopData = $userTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="list-box-label" for="item-<?php echo e($userType['user_type']); ?>">
                                                <input type="radio" id="item-<?php echo e($userType['user_type']); ?>" name="user_type" value="<?php echo e($userType['user_type']); ?>" <?php if($userType['user_type']=='candidate'): ?> checked="checked" <?php endif; ?>>
                                                <div class="inner">
                                                    <div class="user_img d-inline-flex align-items-center justify-content-center">
                                                        <img src="<?php echo e(url('public/images/'.$userType['user_type'].'_color.png')); ?>" class="img-fluid" alt="user">
                                                    </div>
                                                    <h6><?php echo e($userType['label_name']); ?></h6>    
                                                </div>                        
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?> 
                            </div>
                                <?php if(empty($userData['email'])): ?>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="email" id="email-accountinfo" placeholder="Email Address"/>
                                    </div>
                                <?php endif; ?>
                            <div class="form-group mb-0 text-center">
                                <button type="submit" class="btn btn-success">CONTINUE</button>
                            </div>
                                 </form>
                <?php echo JsValidator::formRequest('App\Http\Requests\SetAccountInfoRequest','#update-account-form'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
   
        <script>
            $(document).ready(function () {
                $('#signupType').html('<?php echo e(strtoupper($userData["signup_by"])); ?>');
                $('#loginWith').modal('show');
            });
        </script>
        <?php endif; ?>
    <?php endif; ?>