<div class="table-responsive">
    <table class="table mb-0">
        <thead>
            <tr>
                <th>Title </th>
                <th>Image</th>
                <th>Date and Time</th>
                <th>Total Comments</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($blogList)>0): ?>
            <?php $__currentLoopData = $blogList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($list->blog_title); ?></td>
                <td><img src="<?php echo e(\App\Helpers\Utility::checkBlogImage($list->blog_image,'blog-image')); ?>" alt="blog" height="57"></td>
                <td><?php echo e(\App\Helpers\Utility::getDateTimeFormat($list->created_at)); ?></td>
                <td><?php echo e($list->blog_title); ?></td>
                <td>
                    <div class="switch">
                        <label>
                            <input type="checkbox" <?php echo e(($list['status']=='enabled')?'checked="checked"':''); ?> onchange="updateStatus('<?php echo e($list["id"]); ?>');" name="status[]" value="<?php echo e($list['status']); ?>">
                            <span class="lever"></span>
                        </label>
                    </div>
                </td>
                <td>
                    <div class="action_dropdown">
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                <a class="dropdown-item" href="<?php echo e(url('/admin/view/'.$list["id"])); ?>">View</a>
                                <a class="dropdown-item" href="<?php echo e(url('/admin/edit-blog/'.$list["id"])); ?>">Edit</a>                            
                                <a class="dropdown-item" href="javascript:void(0);" onclick="deteleBlog('<?php echo e($list->id); ?>','<?php echo e($list->blog_title); ?>')">Delete</a>                            
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="7">
                    <?php echo e(\App\Helpers\Utility::emptyListMessage('blog')); ?>

                </td>
            </tr>
            <?php endif; ?>

        </tbody>                    
    </table>
</div>

<div class="pagination_section box-shadow bg-white mt-3" id="paginationList" style="display: none">
    <div class="d-sm-flex align-items-center">
        <div class="page_counter">
            <p class="mb-0">Page <span class="ml-1 left">1</span><span class="mx-1">of</span><span class="right">20</span></p>
        </div>
        <div class="ml-sm-auto">
            <div class="pagination_right">
                <?php echo e($blogList->links()); ?>

            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        var txtSearch = $("#txtSearch").val();
        var form = $("#frmFilter").serialize();
        $(".pagination li a").on('click', function (e) {
            $("#blogList").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
            e.preventDefault();
            var $this = $(this);
            var pageLink = $this.attr('href');
            var txtSearch = $("#txtSearch").val();
            $.ajax({type: 'POST', url: pageLink, async: false, data: {form: form, txtSearch: txtSearch, _token: '<?php echo e(csrf_token()); ?>'},
                success: function (response) {
                    $('.pagination:first').remove();
                    $('#blogList').html(response);
                }
            });
        });
    });

    function updateStatus(id) {
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('/admin/update-blog-status')); ?>",
            data: {
                '_token': "<?php echo e(csrf_token()); ?>",
                'id': id
            },
            success: function (response) {
                if (response.status) {
                    successToaster(response.message, 'User Status');
                }
            }
        });
    }
    
    function deteleBlog(id, name) {
        bootbox.confirm('Are you sure do you want to delete <b>' + name + '<b>?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('admin/delete-blog')); ?>",
                    data: {id: id},
                    success: function (response) {
                        if (response.status) {
                            successToaster(response.message, 'Podcast');
                            loadBlogList();
                        }
                    }
                });
            }
        });
    }
</script>
