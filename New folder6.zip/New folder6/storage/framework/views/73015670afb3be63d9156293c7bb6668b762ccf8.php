<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <main class="main-content inner-pages blog-list-page">
             <div class="container">
                 <h1 class="inner-heading">blogs</h1>
                 <?php if(count($blogList)>0): ?>
                  <?php $__currentLoopData = $blogList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="blog-list">
                    <div class="blog-img" style="background-image: url('<?php echo e(\App\Helpers\Utility::checkBlogImage($list->blog_image,'blog-image')); ?>');"></div>
                    <div class="right-side">
                        <h2><?php echo e($list->blog_title); ?></h2>
                        <p><?php echo e(\App\Helpers\Utility::getLimitText(200,$list->meta_description)); ?></p>
                        <div class="d-flex justify-content-between align-items-center blog-footer">
                            <div class="share-via">
                                <p class="mb-0">Share Via</p>
                                <ul class="list-inline mb-0">
                                    <li class="list-inline-item">
                                        <a href="javascript:void(0);"><i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="javascript:void(0);"><i class="fa fa-twitter"></i></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a>
                                    </li>
                                </ul>
                            </div>
                            <a href="<?php echo e(url('/blog-detail/'.$list->id)); ?>" class="read-more">Read more...</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <tr>
                    <td colspan="7">
                        <?php echo e(\App\Helpers\Utility::emptyListMessage('blog')); ?>

                    </td>
                </tr>
                <?php endif; ?>
             </div>
        </main>
        <?php echo e($blogList->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>