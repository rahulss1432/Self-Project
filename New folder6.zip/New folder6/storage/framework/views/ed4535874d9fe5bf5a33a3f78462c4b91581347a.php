<?php if(count($comments) > 0): ?>
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="comment_row d-flex">
    <img src="<?php echo e($comment->user_profile); ?>" class="rounded-circle" alt="user img">
    <div class="comment_content">
        <div class="title d-sm-flex align-items-center">
            <h6><?php echo e($comment->user_name); ?></h6>
            <span class="date ml-auto">
                <?php 
                $datetime = App\Common\Utility::converToTz($comment->created_at);
                echo $datetime->format('F d Y')
                 ?>
            </span>
        </div>
        <p class="mb-0"><?php echo e($comment->comment); ?></p>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div class="alert alert-danger">No Comments Found</div>
<?php endif; ?>
<?php if($comments->hasMorePages()): ?>
<div class="col-sm-12">
    <div class="loader text-center">
        <?php echo e($comments->links()); ?>

    </div>
</div>
<?php endif; ?>
<script>
    setTimeout(function () {
        $("ul.pagination li").first().remove();
        $("ul.pagination").addClass('d-block');
    }, 500);
    $(".pagination li a").on('click', function (e) {
        $(".pagination li a").attr("disabled", true);
        $(".pagination li a").html('<i class="fa fa-spin fa-spinner"></i> LOAD MORE');
        $(".pagination").parent().parent().remove();
        e.preventDefault();
        var $this = $(this);
        var blogId = $('#blogId').val();
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'GET',
            url: pageLink,
            data: {id: blogId},
            success: function (response) {
                $('.pagination:first').remove();
                $('#comment_listtt').append(response.html);
            }
        });
        $('.pagination:first').remove();
    });
    $(".pagination li a").addClass('');
    $(".pagination li a").html('<i class=""></i> LOAD MORE');
</script>