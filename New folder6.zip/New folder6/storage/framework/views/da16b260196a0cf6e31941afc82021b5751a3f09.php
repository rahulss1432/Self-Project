<?php $__env->startSection('title', 'Subadmin Details'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray"  onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content citizens_view common-grid-list" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent">
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Sub admin's Detail</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a id="back-loader" href="<?php echo e(url('admin/subadmin')); ?>" class="nav-link" onclick="backloader()" title="Back"><i class="fa fa-long-arrow-left"></i></a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <div class="view_sec">
            <div class="form-group">
              <div class="profileimg">
                <?php if(!empty($view->profile_picture)): ?>
                  <img id="uploadimg" class="rounded-circle avtar img-thumbnail" src="<?php echo e(url('public/uploads/'.$view->profile_picture)); ?>" alt="profile img">
                <?php else: ?>
                  <img id="uploadimg" class="rounded-circle avtar img-thumbnail" src="<?php echo e(url('public/assets/images/preview_img.jpg')); ?>" alt="profile img">
                <?php endif; ?>
              </div>
            </div>
            <div class="view_detail">
              <h2><?php echo e($view->first_name); ?> <?php echo e($view->last_name); ?></h2>
              <ul class="list-inline">
                <?php if($view->phone): ?>
                  <li class="list-inline-item"><i class="fa fa-phone"></i> <span><?php echo e($view->phone); ?></span></li>
                <?php endif; ?>
                <?php if($view->email): ?>
                  <li class="list-inline-item"><i class="fa fa-envelope"></i> <span><a><?php echo e($view->email); ?></a></span></li>
                <?php endif; ?>
              </ul>
              <?php if($view->gender): ?>
                <p><i class="fa fa-user"></i><b> <?php echo e($view->gender); ?></b></p>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <script type="text/javascript">

    function backloader()
    {
      $("#back-loader").attr("disabled", true);
      $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    };

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>