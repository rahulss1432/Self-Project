<div class="view_body about_info">
    <div class="row">
    	<div class="col-md-6">
    		<form method="post" id="testimonialCmsForm" enctype="multipart/form-data" action="<?php echo e(url('/admin/add-cms-testimonial')); ?>">
            <?php echo e(csrf_field()); ?>

                <div class="form-group">
		        	<label class="d-block">Customer Image</label>
		        	<label for="userImg" class="upload-img">
		        		<input type="file" name="customer_image" hidden id="userImg">
		        		<img src="<?php echo e(url('public/images/default-img.png')); ?>" alt="user">
		        	</label>
		        </div>
		        <div class="form-group">
		            <input type="text" name="customer_name" class="form-control" placeholder="Customer Name">
		        </div>
		        <div class="form-group">
		            <textarea rows="4"  name="customer_content" class="form-control" placeholder="Content"></textarea>
		        </div>
		        <div class="form-group  text-right mb-0">
		 			<button type="button" class="btn btn-success rounded-0 ripple-effect" id="testimonialCmsBtn">Save
						<i style="display:none;" class="btn_loader"></i>
		 			</button>
		 			<a href="javascript:void(0);" class="btn btn-dark rounded-0 ripple-effect ml-2">Cancel</a>
		 		</div>
		    </form>
    	</div>
    </div>
</div>
<script>
     $("#testimonialCmsBtn").on('click', (function (e) {
        var btn = $('#testimonialCmsBtn');
        var form = $('#testimonialCmsForm');
        if (form.valid()) {
            e.preventDefault();
            btn.html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?> Save');
            btn.prop('disabled', true);
            $.ajax({
                url: "<?php echo e(url('/admin/add-cms-testimonial')); ?>",
                type: "POST",
                data: new FormData($('#testimonialCmsForm')[0]),
                contentType: false,
                cache: false,
                processData: false,
                success: function (data)
                {
                    location.reload();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Save');
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
</script>
