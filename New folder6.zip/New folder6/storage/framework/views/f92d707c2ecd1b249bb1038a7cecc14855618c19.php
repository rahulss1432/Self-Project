<aside class="sidemenu">
  <div class="sidebar-wrapper">
    <div class="logo text-center">
      <img src="<?php echo e(url('public/assets/images/logo.png')); ?>" alt="logo">
      <a href="javascript:void(0);" class="toggle-icon d-xl-none sidemenu-icon">
        <i class="fa fa-outdent"></i>
      </a>
    </div>
    <ul id="sidemenu" class="nav flex-column sidenav" data-mcs-theme="minimal-dark"">
      <li class="nav-item  <?php echo e((Request::route()->getName()=='dashboard')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/dashboard')); ?>">
          <i class="fa fa-dashboard"></i> Dashboard
        </a>
      </li>
      <li class="nav-item <?php echo e((Request::route()->getName()=='citizens')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/citizens')); ?>">
          <i class="fa fa-building"></i> Citizens
        </a> 
      </li>
      <li class="nav-item <?php echo e((Request::route()->getName()=='lawyer')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/lawyer')); ?>">
          <i class="fa fa-user-secret "></i> Lawyers
        </a> 
      </li>
      <li class="nav-item <?php echo e((Request::route()->getName()=='bailbondsman')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/bailbondsman')); ?>">
          <i class="fa fa-user-secret"></i> Bail Bondsmans
        </a> 
      </li>
      <?php if(Auth::guard('admin')->user()->user_type == 'admin'): ?>
      <li class="nav-item <?php echo e((Request::route()->getName()=='subadmin')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/subadmin')); ?>">
          <i class="fa fa-users "></i> Sub admin
        </a> 
      </li>
      <?php endif; ?>
      <li class="nav-item <?php echo e((Request::route()->getName()=='videos')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/broadcasted-videos')); ?>">
          <i class="fa fa-video-camera"></i> Broadcasted Videos
        </a> 
      </li>
     
      <li class="nav-item <?php echo e((Request::route()->getName()=='ratingsreviews')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/ratings-and-reviews')); ?>">
          <i class="fa fa-star-half-o"></i> Ratings & Reviews
        </a> 
      </li>
      <li class="nav-item <?php echo e((Request::route()->getName()=='payment')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/payment')); ?>">
          <i class="fa fa-credit-card"></i> Payment
        </a> 
      </li> 
      <li class="nav-item <?php echo e((Request::route()->getName()=='police')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/police-department')); ?>">
          <i class="fa fa-building-o""></i> Police Departments
        </a> 
      </li>
      <li class="nav-item <?php echo e((Request::route()->getName()=='reports')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/reports')); ?>">
          <i class="fa fa-clipboard"></i> Reports
        </a> 
      </li>
       <li class="nav-item <?php echo e((Request::route()->getName()=='blog')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/blog')); ?>">
          <i class="fa fa-file-text"></i> Blogs
        </a> 
      </li>
      <li class="nav-item <?php echo e((Request::route()->getName()=='cms')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/cms')); ?>">
          <i class="fa fa-desktop"></i> CMS
        </a> 
      </li>
      <li class="nav-item <?php echo e((Request::route()->getName()=='settings')?'active':''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/change-password')); ?>">
          <i class="fa fa-cog"></i> Settings
        </a> 
      </li>
    </ul>
  </div>
</aside>