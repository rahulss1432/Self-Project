<?php $__env->startSection('title','Podcast'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main class="main-content inner-pages podcast-list-page">
    <section class="podcast-section common-pad" id="podcast">
        <div class="container">
            <h1 class="inner-heading">
                podcasts
            </h1>
            <div class="row custom-gutters">               
                <?php if(count($podcastList)>0): ?>
                    <?php $__currentLoopData = $podcastList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-sm-6">
                            <div class="podcast-box" style="background-image: url('<?php echo e(\App\Helpers\Utility::checkPodcastImage($list->podcast_image)); ?>')">
                                <div class="position-div">
                                    <h2><?php echo e($list->title); ?> </h2>

                                    <div class="hidden-item">
                                        <p><?php echo e($list->description); ?></p>

                                        <a href="javascript:void(0);">
                                            <img src="<?php echo e(url('public/images/play-icon.png')); ?>" alt="Play"/> Play
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="col-lg-3 col-sm-6">
                        <div>
                            <?php echo e(\App\Helpers\Utility::emptyListMessage('podcast')); ?>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>