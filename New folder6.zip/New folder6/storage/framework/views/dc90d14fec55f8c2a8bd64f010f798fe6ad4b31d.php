<div class="view_body">
<?php if($pages->count()>0): ?>
  <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form method="post" id="contentCmsForm" action="<?php echo e(url('/admin/save-cms-content')); ?>">
    <?php echo e(csrf_field()); ?>

        <input type="hidden" name="page_id" value="<?php echo e($pageId); ?>">
        <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
        <div class="form-group" id="divContent">
            <textarea rows="12" class="form-control tinymce" id="cms_content" name="cms_content" placeholder="Enter Home Content">
            <?php echo e($data->cms_content); ?>

            </textarea>
        </div>
        <div class="form-group  text-right mb-0">
            <button type="button" class="btn btn-success rounded-0 ripple-effect" id="contentCmsBtn">Save
                <i style="display:none;" class="btn_loader"></i>
            </button>
            <a href="javascript:void(0);" class="btn btn-dark rounded-0 ripple-effect ml-2">Cancel</a>
        </div>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\CmsRequest','#contentCmsForm'); ?>

</div>
<script>
    function getSavebtn() {
        $(".btn_loader").css('display', 'inline-block');
        setTimeout(function () {
            $(".btn_loader").hide();
        }, 1000);
    }

    $("#contentCmsBtn").on('click', (function (e) {
        var btn = $('#contentCmsBtn');
        var form = $('#contentCmsForm');
        if (form.valid()) {
            e.preventDefault();
            btn.html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?> Save');
            btn.prop('disabled', true);
            $.ajax({
                url: "<?php echo e(url('/admin/update-cms-content')); ?>",
                type: "POST",
                data: new FormData($('#contentCmsForm')[0]),
                contentType: false,
                cache: false,
                processData: false,
                success: function (data)
                {
                    location.reload();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Save');
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));

    // tinymce.init({
	// 	  selector: 'textarea',
	// 	  height: 500,
	// 	  theme: 'modern',
	// 	  plugins: 'print preview fullpage  searchreplace autolink directionality  visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists textcolor wordcount  code imagetools    contextmenu colorpicker textpattern help',
	// 	  toolbar1: 'formatselect | bold italic strikethrough forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat',
	// 	  image_advtab: true,
	// 	  templates: [
	// 	    { title: 'Test template 1', content: 'Test 1' },
	// 	    { title: 'Test template 2', content: 'Test 2' }
	// 	  ],
	// 	  content_css: [
	// 	    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
	// 	    '//www.tinymce.com/css/codepen.min.css'
	// 	  ]
	// 	 });
</script>
