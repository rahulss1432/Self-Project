<?php $__env->startSection('title','Job Listing'); ?>
<?php $__env->startSection('content'); ?>
<main class="dashboard-main-wrap applied_job_page" id="content">
        <div class="container-fluid">
            <div class="common-detail-section">
                <div class="content-body">
                      <!-- breadcrumb start-->
                   <nav aria-label="breadcrumb" class="text-right">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Job Listing</li>
                    </ol>
                </nav>
                <!-- breadcrumb end-->
                    <div class="job_listing_filter justify-content-between align-items-xl-center">
                        <!-- <h2 class="page-title mt-0">Job Listing</h2> -->
                        <div class="filter_fields ml-auto">
                            <form id="frmFilter" action="javascript:void(0);" onsubmit="loadJobList()">
                                 <?php echo e(csrf_field()); ?>

                                <div class="form-group list-inline-item">
                                    <input type="text" name="location" class="form-control map_marker" placeholder="Enter Location">
                                </div>
                                <div class="form-group list-inline-item">
                                    <select name="experience" title="Years of Experience" class="form-control width_custom selectpicker">
                                        <option value="">Select Experience</option>
                                        <option value="0-3">0-3</option>
                                        <option value="3-5">3-5</option>
                                        <option value="5-7">5-7</option>
                                        <option value="7-10">7-10</option>
                                        <option value="11-15">11-15</option>
                                        <option value="16-20">16-20</option>
                                        <option value="21-30">21-30</option>
                                        <option value="30+">30+</option>
                                    </select>
                                </div>
                                <div class="form-group list-inline-item">
                                    <select name="job_type" title="Job type" class="form-control width_custom selectpicker">
                                        <option value="">Select Type</option>
                                        <option value="Full-time">Full Time</option>
                                        <option value="Freelancer">Freelancer</option>
                                    </select>
                                </div>
                                <div class="form-group list-inline-item">
                                    <select name="industry_type" title="Industry type" id='industry_type'  onchange="getSkills()" class="form-control width_custom selectpicker">                          
                                        <?php 
                                            $industryData = \App\Models\Industry::get();
                                        ?>
                                        <option value="">Select Industry</option>
                                        <?php if(!empty($industryData)): ?>
                                            <?php $__currentLoopData = $industryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($val->id); ?>"><?php echo e($val->industry_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group list-inline-item">
                                    <select name="skills[]" id="skills" multiple="true" class="form-control width_custom selectpicker" title="Select Skills">
                                      <option value="">Select Skills</option>  
                                    </select>    
                                </div>
                                <div class="form-group list-inline-item">
                                    <button type="submit" class="btn btn-success text-uppercase ripple-effect-dark">Search</button>                                </div>
                                <div class="form-group list-inline-item">
                                    <button type="button" onclick="resetFilter();" class="btn btn-warning text-uppercase ripple-effect-dark">Reset</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="card">
                        <div class="card-body">
                            <!-- <div class="alert alert-danger text-center" id="alert" style="display: none;">No Record Found</div>
                            <div class="text-center spinner" id="listLoader"><i class="fa fa-2x fa-spin fa-spinner"></i></div> -->
                            <div id="jobList"></div>
                            <div class="text-center">
                            <div class="load_more" id="loadMore" style="display: none;">
                                    <a href="javascript:void(0);">
                                        <img src="<?php echo e(url('public/images/load_more.svg')); ?>" alt="icon">Load More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<script type="text/javascript">
    $(document).ready(function(){
        loadJobList();
    });
    
    function loadJobList(){
        $("#jobList").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        var form = $("#frmFilter").serialize();
        $.ajax({
            type: "POST",
            data: form,
            url: "<?php echo e(url('/load-job-list')); ?>",
            success: function (response) {
                $('#jobList').html(response);
            }
        });
    }
    
    function resetFilter(){
        $('#frmFilter')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadJobList();
        getSkills();
    }
    
    function getSkills() {
        var industryId = $('#industry_type').val();
        if (industryId != '') {
            $.ajax({
                type: "POST",
                url: "<?php echo e(url('/get-job-skills-by-industry')); ?>",
                data: {industryId: industryId,_token: '<?php echo e(csrf_token()); ?>'},
                success: function (response) {
                    $('#skills').html(response);
                    $('#skills').selectpicker('refresh');
                }
            });
        }
    }
    getSkills();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>