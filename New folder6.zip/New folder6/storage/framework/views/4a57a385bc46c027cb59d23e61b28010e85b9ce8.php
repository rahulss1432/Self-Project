<?php $__env->startSection('title','Portfolio'); ?>
<?php $__env->startSection('content'); ?>

<main class="dashboard-main-wrap step-form jobseeker-steps">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="content-body">
                <!-- <h2 class="page-title mt-0">Update Profile</h2> -->
                <!-- breadcrumb start-->
                <nav aria-label="breadcrumb" class="text-right">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Experience</li>
                    </ol>
                </nav>
                <!-- breadcrumb end-->
                <div class="form-wrap">
                    <?php echo $__env->make('user.profile.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!-- xxxxxxxxxxx -->
                    <section class="step-form-body">
                        <div class="form02 common-form" id="form02">
                            <div class="inner-body">
                                <div id="portfolioList"></div>
                                <!-- field-heading -->
                                <div class="clearfix"></div>

                                <div id="portfolioHtml">

                                </div>
                            </div>
                        </div>
                        <!-- xxxxxxxxxxx -->
                    </section>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    function addMore(obj) {
        if (obj.parent().parent().find('input').val() != '') {
            var html = obj.parent().parent().clone();
            $('#desc-list').append(html);
            obj.parent().html('<a href="javascript:void(0);" class="add-link link-disabled" onclick="deleteRow($(this))" id="deleteLinks"><img src="<?php echo e(url("public/images/remove-icon.png")); ?>" alt="add"></a>');
            $('.add-btn').parent().parent().find('input').val('');
        } else {
            errorToaster('Project link field can not be blank.', 'Portfolio');
        }
    }

    function deleteRow(obj) {
        obj.parent().parent().remove();
    }

    function actionPortfolio(id) {
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('/user/get-portfolio-form')); ?>",
            data: {id: id},
            success: function (response) {
                $('#portfolioHtml').html(response);
            },
            complete: function () {
                $('html,body').animate({scrollTop: 730});
            }
        });
    }
    actionPortfolio(0);
    function loadPortfolioList() {
        $("#portfolioList").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('/user/get-portfolio-list')); ?>",
            success: function (response) {
                $('#portfolioList').html(response);
            }
        });
    }
    loadPortfolioList();

    $('#expForm').on('submit', function (e) {
        if ($('#expForm').valid()) {
            $('#expBtn').html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?>  Submit');
            $("#expBtn").prop('disabled', true);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>