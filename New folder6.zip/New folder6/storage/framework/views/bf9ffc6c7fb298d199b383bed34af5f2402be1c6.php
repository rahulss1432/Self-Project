<?php if(($userExperience)->count()>0): ?>
<div class="row">
	<div class="col-12">
		<label class="field-heading font-md d-block w-100">Experience</label>
	</div>
</div>
<?php $__currentLoopData = $userExperience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
	<div class="col-12">
	   <div class="exprience-detail">
			<div class="action-btn">
				<a href="javascript:void(0);" onclick="actionExperience('<?php echo e($experience["id"]); ?>');" class="rounded-circle btn btn-success btn-sm ml-md-2" ><i class="fa fa-pencil"></i></a>
				<a href="javascript:void(0);" onclick="deleteExperience('<?php echo e($experience["id"]); ?>','<?php echo e($experience["title"]); ?>')" class="rounded-circle btn btn-warning btn-sm ml-md-2"><i class="fa fa-trash"></i></a>  
			</div>
			<p><strong><?php echo e($experience['title']); ?></strong></p>
			<p><?php echo e($experience['company_name']); ?></p>
			<p><strong>From :</strong> <?php echo e(\App\Helpers\Utility::getDateFormat($experience['duration_from'])); ?> <strong>To</strong> <?php echo e(($experience['is_working']=='no')?\App\Helpers\Utility::getDateFormat($experience['duration_to']):'Currently work here.'); ?></p>
	   </div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<script>
    var title = 'Experience';
    function deleteExperience(id, name) {
        bootbox.confirm('Are you sure do you want to delete <b>' + name + '<b>?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('user/delete-experience')); ?>",
                    data: {id: id},
                    success: function (response) {
                        if (response.status) {
                            successToaster(response.message, title);
                            loadExperienceList();
                        }
                    }
                });
            }
        });
    }
</script>