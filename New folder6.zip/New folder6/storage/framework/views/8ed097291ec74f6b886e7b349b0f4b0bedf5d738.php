<?php $__env->startSection('title', 'Edit CMS'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray" onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content cmsedit_page" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent" >
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">CMS Page </h4>
        </div>
        <div class="card-body ">
          <div class="common_tabs">
            <ul class="nav nav-pills mb-4" id="pills-tab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#home" role="tab" aria-controls="pills-home" aria-selected="true">Home</a>
              </li> 
              <li class="nav-item">
                <a class="nav-link" id="pills-about-tab" data-toggle="pill" href="#pills-about" role="tab" aria-controls="pills-about" aria-selected="false">About us </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="pills-faq-tab" data-toggle="pill" href="#pills-faq" role="tab" aria-controls="pills-faq" aria-selected="false"> FAQs </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false"> Contact Us </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="pills-terms-tab" data-toggle="pill" href="#pills-terms" role="tab" aria-controls="pills-terms" aria-selected="false"> Terms and Conditions </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="pills-privacypolice-tab" data-toggle="pill" href="#pills-privacypolice" role="tab" aria-controls="pills-privacypolice" aria-selected="false"> Privacy Policy</a>
              </li>
            </ul>
            <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane home_tab fade show active" id="home" role="tabpanel" aria-labelledby="pills-home-tab">
                <div class="row">
                  <div class="col-sm-6">
                    <div class="table-responsive">
                      <table class="table admin-table">
                        <thead>
                          <tr>
                            <th>SECTION</th>
                            <th width="80px" class="text-right">ACTION</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Banner</td>
                            <td>
                              <ul class="list-inline mb-0 text-center"> 
                                <li class="list-inline-item">
                                    <a id="edit-loader" class="edit-loader<?php echo e($banner->id); ?>" onclick="editCms(<?php echo e($banner->id); ?>)" href="<?php echo e(url('admin/home-edit',$banner->id)); ?>">
                                    <i class="fa fa-pencil"></i>
                                  </a>
                                </li> 
                              </ul>
                            </td>
                          </tr>
                          <tr>
                            <td>Title</td>
                            <td>
                              <ul class="list-inline mb-0 text-center"> 
                                <li class="list-inline-item">
                                    <a id="edit-loader" class="edit-loader<?php echo e($title->id); ?>" onclick="editCms(<?php echo e($title->id); ?>)" href="<?php echo e(url('admin/home-edit',$title->id)); ?>">
                                      <i class="fa fa-pencil"></i>
                                    </a>
                                </li> 
                              </ul>
                            </td>
                          </tr>
                          <tr>
                            <td>Tag</td>
                            <td>
                              <ul class="list-inline mb-0 text-center"> 
                                <li class="list-inline-item">
                                     <a id="edit-loader" class="edit-loader<?php echo e($tag->id); ?>" onclick="editCms(<?php echo e($tag->id); ?>)" href="<?php echo e(url('admin/home-edit',$tag->id)); ?>">
                                      <i class="fa fa-pencil"></i>
                                    </a>
                                </li> 
                              </ul>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane about_tab fade show" id="pills-about" role="tabpanel" aria-labelledby="pills-about-tab">
                <div class="row">
                  <div class="col-sm-6">
                    <form class="f-field" method="POST" onsubmit="return !!(checkDesc());" action="<?php echo e(url('admin/setting-edit',$about->id)); ?>" >
                      <?php echo e(csrf_field()); ?>

                      <div class="form-group mt-3">
                        <input type="hidden" name="title" value="About Us">
                        <input type="hidden" name="setting_key" value="about-us">
                        <textarea id="key_value" name="key_value" class="form-control form-control-lg pl-0" rows="6"><?php echo e($about->key_value); ?></textarea>
                        <span id="key_value-error" style="" class="help-block"></span><span class="chrt_limit d-block">600 Maximum characters</span>
                      </div>
                      <button id="save-loader" type="submit" class="btn btn-primary btn_radius">SAVE</button>
                    </form>
                  </div>
                </div>
              </div>
              <div class="tab-pane faq_tab fade show" id="pills-faq" role="tabpanel" aria-labelledby="pills-faq-tab">
                <div class="row">
                  <div class="col-xl-6 col-lg-8 col-md-12 col-sm-12 col-">
                    <form class="f-field" id="faq_form" method="POST" action="<?php echo e(url('admin/setting-edit',$faq->id)); ?>">
                      <?php echo e(csrf_field()); ?>

                      <div class="form-group mt-3">
                        <label class="control-label">Heading</label>
                        <input type="hidden" name="title" value="FAQ">
                        <input type="hidden" name="setting_key" value="faqs">
                        <input type="text" name="key_value" value="<?php echo e($faq->key_value); ?>" class="form-control form-control-lg">
                      </div>
                      <div class="questions_list">
                        <div class="card-header">
                          <h4 class="page-title float-left">Add Questions</h4>
                          <ul class="list-inline mb-0 text-right">
                            <li class="list-inline-item">
                              <a href="javascript:void(0);" class="add_questions nav-link">
                                <i class="fa fa-plus"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                        <?php if(count($faqQA) > 0): ?>
                        <?php $__currentLoopData = $faqQA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faqq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="common_list" id="divFaq<?php echo e($faqq->id); ?>">
                          <div class="row">
                            <div class="col-sm-6">
                              <div class="form-group has-error">
                                <input type="text" onkeyup="removeQueValid(this.value,<?php echo e($faqq->id); ?>)" name="question[]" class="form-control qquestion" value="<?php echo e($faqq->question); ?>">
                                <label class="control-label">Questions</label>
                                <span id="Question<?php echo e($faqq->id); ?>" class="help-block error-help-block question_error"></span>
                              </div>
                            </div>
                            <div class="col-sm-6">
                              <div class="form-group has-error">
                                <input type="text" onkeyup="removeAnsValid(this.value,<?php echo e($faqq->id); ?>)" name="answer[]" class="form-control aanswer" value="<?php echo e($faqq->answer); ?>">
                                <label class="control-label">Answer</label>
                                <span id="Answer<?php echo e($faqq->id); ?>" class="help-block error-help-block answer_error"></span>
                              </div>
                            </div>
                              <a href="javascript:void(0);"  onclick="deleteQueAns(<?php echo e($faqq->id); ?>)" class=" delete_icon"><i class="fa fa-close"></i></a>
                          </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="common_list" id="divFaq0">
                          <div class="row">
                            <div class="col-sm-6">
                              <div class="form-group has-error">
                                <input type="text" onkeyup="removeQueValid(this.value,0)" name="question[]" class="form-control qquestion" value="">
                                <label class="control-label">Questions</label>
                                <span id="Question0" class="help-block error-help-block question_error"></span>
                              </div>
                            </div>
                            <div class="col-sm-6">
                              <div class="form-group has-error">
                                <input type="text" onkeyup="removeAnsValid(this.value,0)" name="answer[]" class="form-control aanswer" value="">
                                <label class="control-label">Answer</label>
                                <span id="Answer0" class="help-block error-help-block answer_error"></span>
                              </div>
                            </div>
                           
                          </div>
                        </div>
                        <?php endif; ?>
                      </div>
                          <button id="save-loader-qa" type="button" onclick="return checkvalid();" class="btn btn-primary btn_radius">SAVE</button>
                    </form>
                       <?php echo JsValidator::formRequest('App\Http\Requests\AddFaqRequest','#faq_form'); ?>

                  </div>
                </div>
                
              </div>
              <div class="tab-pane fade show" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                <div class="row">
                  <div class="col-sm-6">
                    <form class="f-field" method="POST" onsubmit="return !!(checkContact());" action="<?php echo e(url('admin/setting-edit',$adminEmail->id)); ?>" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                      <div class="form-group mt-3">
                        <label class="control-label">Email</label>
                        <input type="hidden" name="admintitle" value="Email">
                        <input type="hidden" name="adminsetting_key" value="admin-email">
                        <?php if($adminEmail): ?>
                          <input type="email" name="adminkey_value" class="form-control form-control-lg" value="<?php echo e($adminEmail->key_value); ?>">
                          <?php else: ?>
                            <input type="email" name="adminkey_value" class="form-control form-control-lg">
                        <?php endif; ?>
                      </div>
                      <div class="form-group mt-3">
                        <label class="control-label">Description</label>
                        <input type="hidden" name="des_id" value="<?php echo e($contact->id); ?>">
                        <input type="hidden" name="title" value="Contact Us">
                        <input type="hidden" name="setting_key" value="contact-us">
                        <input type="text" name="key_value" id="contact" onkeyup="checkDescription(this.value)" class="form-control form-control-lg" value="<?php echo e($contact->key_value); ?>">
                        <span id="contact-error" style="" class="help-block"></span>
                      </div>
                      <button id="save-loader-contact" type="submit" class="btn btn-primary btn_radius">SAVE</button>
                    </form>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade show" id="pills-terms" role="tabpanel" aria-labelledby="pills-terms-tab">
                <div class="row">
                  <div class="col-sm-6">
                    <form class="f-field" method="POST" onsubmit="return !!(checkContent());" action="<?php echo e(url('admin/cms-edit',$terms->id)); ?>" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                      <div class="form-group mt-3">
                        <input type="hidden" name="title" value="Terms and Conditions">
                        <input type="hidden" name="slug" value="terms-and-condition">
                        <textarea name="content" id="content" class="form-control form-control-lg pl-0" rows="10"><?php echo e($terms->content); ?></textarea>
                          <span id="content-error" style="" class="help-block"></span>
                      </div>
                      <button id="save-loader-term" type="submit" class="btn btn-primary btn_radius">SAVE</button>
                    </form>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade show" id="pills-privacypolice" role="tabpanel" aria-labelledby="pills-privacypolice-tab">
                <div class="row">
                  <div class="col-sm-6">
                    <form class="f-field" method="POST" onsubmit="return !!(checkContentPrivacy());" action="<?php echo e(url('admin/cms-edit',$policy->id)); ?>" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                      <div class="form-group mt-3">
                        <input type="hidden" name="title" value="Privacy Policy">
                        <input type="hidden" name="slug" value="privacy-policy">
                        <textarea name="content" id="content1" class="form-control form-control-lg pl-0" rows="6"><?php echo e($policy->content); ?></textarea>
                         <span id="content1-error" style="" class="help-block"></span>
                      </div>
                      <button id="save-loader-privacy" type="submit" class="btn btn-primary btn_radius">SAVE</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <script type="text/javascript">
      
    window.addEventListener('beforeunload', function(event)
    {
      $("#save-loader").attr("disabled", true);
      $("#save-loader").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
      $("#save-loader-qa").attr("disabled", true);
      $("#save-loader-qa").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
      $("#save-loader-contact").attr("disabled", true);
      $("#save-loader-contact").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
      $("#save-loader-term").attr("disabled", true);
      $("#save-loader-term").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
      $("#save-loader-privacy").attr("disabled", true);
      $("#save-loader-privacy").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
    });
    
    var global=9999999; 
    $('.form-group .form-control').focus(function () 
    {
      $(this).parent().addClass('isfocused');
    }).blur(function ()
    {
      $(this).parent().removeClass('isfocused');
    });

    $('.add_questions').click(function() 
    {
      $('.questions_list').append('<div class="common_list"><div class="row"><div class="col-sm-6"><div class="form-group has-error"><input type="text" onkeyup="removeQueValid(this.value,'+global+')" name="question[]" class="form-control qquestion"><label class="control-label">Questions</label> <span id="Question'+global+'" class="help-block error-help-block question_error"></span></div></div><div class="col-sm-6"><div class="form-group has-error"><input onkeyup="removeAnsValid(this.value,'+global+')" name="answer[]" type="text" class="form-control aanswer"><label class="control-label">Answer</label> <span id="Answer'+global+'" class="help-block error-help-block answer_error"></span></div></div></div><a href="javascript:void(0);" class="close_icon"><i class="fa fa-close"></i></a></div>');
    global++;
    });

    $('.questions_list').on('click','.close_icon',function()
    {
      $(this).parent().remove();
    });

    $(document).ready(function() 
    {
      tinymce.init({
                    theme: "modern",
                    selector: "textarea",
                    relative_urls : false,
                    remove_script_host : false,
                    convert_urls : true,
                    plugins: 'image code',
                    height: 300,
                    toolbar: 'undo redo | image code',
                    images_upload_url : '<?php echo e(url("admin/admin-image-upload")); ?>',
                    images_upload_handler: function (blobInfo, success, failure)
                    {
                      var xhr, formData;
                      xhr = new XMLHttpRequest();
                      xhr.withCredentials = false;
                      xhr.open('POST', '<?php echo e(url("admin/admin-image-upload")); ?>');
                      xhr.setRequestHeader('X-CSRF-TOKEN', '<?php echo e(csrf_token()); ?>');
                      xhr.onload = function()
                      {
                        var json;
                        if (xhr.status != 200)
                        {
                          failure('HTTP Error: ' + xhr.status);
                          return;
                        }
                        json = JSON.parse(xhr.responseText);
                        if (!json || typeof json.location != 'string')
                        {
                          failure('Invalid JSON: ' + xhr.responseText);
                          return;
                        }
                        success(json.location);
                      };
                      formData = new FormData();
                      formData.append('file', blobInfo.blob(), blobInfo.filename());
                      xhr.send(formData);
                    },
                    init_instance_callback: function (editor)
                    {
                      editor.on('keyup', function (e)
                      {
                        var message = tinymce.get('key_value').getContent();
                        if (message === '')
                        {
                          $("#key_value-error").html('Field is required');
                          $("#key_value-error").css('color', '#ff0000');
                        }
                        else
                        {
                          $("#key_value-error").html('');
                        }
                        var message = tinymce.get('content').getContent();
                        if (message === '')
                        {
                          $("#content-error").html('Field is required');
                          $("#content-error").css('color', '#ff0000');
                        }
                        else
                        {
                          $("#content-error").html('');
                        }
                        var message = tinymce.get('content1').getContent();
                        if (message === '')
                        {
                          $("#content1-error").html('Field is required');
                          $("#content1-error").css('color', '#ff0000');
                        }
                        else
                        {
                          $("#content1-error").html('');
                        }
                      });
                    }
                  });
      $('a[data-toggle="pill"]').on('show.bs.tab', function (e)
      {
        localStorage.setItem('activeTab', $(e.target).attr('href'));
      });

      var activeTab = localStorage.getItem('activeTab');
      if (activeTab)
      {
        if (activeTab == '#pills-about')
        {
          $('#pills-tab a[href="' + activeTab + '"]').tab('show');
          $('#pills-tab ul li.active').removeClass('active show');
          $('#pills-about-tab').addClass('active show');
        }
        if(activeTab == '#pills-faq')
        {
          $('#pills-tab a[href="' + activeTab + '"]').tab('show');
          $('#pills-tab ul li.active').removeClass('active show');
          $('#pills-faq-tab').addClass('active show');
        }
        if(activeTab == '#pills-contact')
        {
          $('#pills-tab a[href="' + activeTab + '"]').tab('show');
          $('#pills-tab ul li.active').removeClass('active show');
          $('#pills-contact-tab').addClass('active show');
        }
        if(activeTab == '#pills-terms')
        {
          $('#pills-tab a[href="' + activeTab + '"]').tab('show');
          $('#pills-tab ul li.active').removeClass('active show');
          $('#pills-terms-tab').addClass('active show');
        }
        if(activeTab == '#pills-privacypolice')
        {
          $('#pills-tab a[href="' + activeTab + '"]').tab('show');
          $('#pills-tab ul li.active').removeClass('active show');
          $('#pills-privacypolice-tab').addClass('active show');
        }
      } 
    });

    function editCms(id)
    {
      $(".edit-loader"+id).attr("disabled", true);
      $(".edit-loader"+id).html('<i class="fa fa-spinner fa-spin"></i>');
    };
    
    function checkDesc()
    {
      var description = tinymce.get('key_value').getContent();
      if (description === undefined || description.length == 0)
      {
        $("#key_value-error").html("Field is required.");
        $("#key_value-error").css('color', '#ff0000');
        return false;
      }
      else
      {
        return true;
      }
    }
    
    //for terms and condition and privacy policy
    function checkContent()
    {
      var description = tinymce.get('content').getContent();
      if (description === undefined || description.length == 0)
      {
        $("#content-error").html("Field is required.");
        $("#content-error").css('color', '#ff0000');
        return false;
      }
      else
      {
        return true;
      }
    }

    //for terms and condition and privacy policy
    function checkContentPrivacy()
    {
      var description = tinymce.get('content1').getContent();
      if (description === undefined || description.length == 0)
      {
        $("#content1-error").html("Field is required.");
        $("#content1-error").css('color', '#ff0000');
        return false;
      }
      else
      {
        return true;
      }
    }

    function checkContact() 
    {
      var description = $('#contact').val();
      if (description === undefined || description.length == 0)
      {
        $("#contact-error").html("Field is required.");
        $("#contact-error").css('color', '#ff0000');
        return false;
      }
      else
      {
        return true;
      }
    }

    //for terms and condition and privacy policy
    function checkDescription(description)
    {
      if (description === undefined || description.length == 0)
      {
        $("#contact-error").html("Field is required.");
        $("#contact-error").css('color', '#ff0000');
        return false;
      }
      else
      {
        $("#contact-error").html('');
      }
    }
     
    function checkvalid()
    {
      var i = 0;
      $('.qquestion').each(function()
      {
        if($(this).val() == '')
        {
          $(this).parent().find('.question_error').html('Question field is required.');
          i++; 
        }
        else
        {
          $(this).parent().find('.question_error').html('');
        }
      });
      $('.aanswer').each(function()
      {
        if($(this).val() == '')
        {
          $(this).parent().find('.answer_error').html('Answer field is required.');
          i++; 
        }
        else
        {
          $(this).parent().find('.answer_error').html('');
        }
      });
      if(i < 1)
      {
        $('#faq_form').submit();
      }
      else
      {
        return false;
      }
    }

    function removeQueValid(value,id)
    {
      if (value === undefined || value.length == 0)
      {
        $("#Question"+id).html("Question field is required.");
        $("#Question"+id).css('color', '#ff0000');
        return false;
      }
      else
      {
        $("#Question"+id).html('');
      }
    }

    function removeAnsValid(value,id)
    {
      if (value === undefined || value.length == 0)
      {
        $("#Answer"+id).html("Answer field is required.");
        $("#Answer"+id).css('color', '#ff0000');
        return false;
      }
      else
      {
        $("#Answer"+id).html('');
      }
    }
            
    function deleteQueAns(id)
    {
      bootbox.confirm('Are you sure do you want to delete this FAQ?', function (result)
      { 
        if (result)
        {
          $.ajax({
                  type: "GET",
                  url: "<?php echo e(url('admin/delete-faq')); ?>/" + id,
                  success: function(response)
                  {
                    if (response)
                    {
                      toastr.remove();
                      toastr.options.closeButton = true;
                      toastr.success('FAQ deleted duccessfully', 'Success', {timeOut: 1000});
                      document.getElementById('divFaq'+id).style.display = 'none';
                    }
                    else
                    {
                      toastr.remove();
                      toastr.options.closeButton = true;
                      toastr.error('Something went wrong', 'Error', {timeOut: 1000});
                    }
                  }
                });
        }
      });
    }

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>