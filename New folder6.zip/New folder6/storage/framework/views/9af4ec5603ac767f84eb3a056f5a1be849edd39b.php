<script src="<?php echo e(url('public/assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/js/jstz.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/js/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/js/bootstrap-select.min.js')); ?>"></script>

<script type="text/javascript">

  $('.login-field .input-group .form-control').focus(function ()
  {
    $(this).parent().addClass('isfocused');
  }).blur(function ()
  {
    $(this).parent().removeClass('isfocused');
  });


  $('input[name="datefilter"]').daterangepicker({
                                                  autoUpdateInput: false,
                                                  autoApply:true,
                                                  locale: {format: 'DD-MM-YYYY'}
                                                });


  $('input[name="datefilter"]').on('apply.daterangepicker', function(ev, picker)
  {
    $(this).val(picker.startDate.format('DD-MM-YYYY') + ' To ' + picker.endDate.format('DD-MM-YYYY'));
  });


  $('input[name="datefilter"]').on('cancel.daterangepicker', function(ev, picker)
  {
    $(this).val('');
  });
  

  $(document).ready(function()
  {
    $('#payment').DataTable({
                              searching: false,
                            });
    
    $('#video').DataTable({
                            searching: false,  
                          });
         
    $('#live').DataTable({
                            searching: false,
                        });
    
    $('#citizens').DataTable({
                               searching: false,
                             });

    $('#lawyers').DataTable({
                              searching: false,
                            });
    });

    $(document).ready(function ()
    {
      if ($(window).width() >= 1025)
      {
        $('.toggle-icon').click(function ()
        {
          $("body").toggleClass("menu-toggle")
        });
      }
      if ($(window).width() <= 1024)
      {
        $('.toggle-icon').click(function ()
        {
          $("body").toggleClass("menu-toggle")
        });
        $('.page-content').click(function ()
        {
          $("body").removeClass("menu-toggle")
        });
      }
    });
  

    (function($)
    {
      $(window).on("load",function()
      {
        $(".sidenav").mCustomScrollbar();
      });
    })(jQuery);
  
    function setUserTimezone(){
      var tz = jstz.determine();
      var timezone = tz.name();
      $.ajax({
        type: "POST",
        url: "<?php echo e(url('set-user-timezone')); ?>",
        async: true,
        data: {timezone:timezone},
        success: function (response)
        {

        }
      });
    }

    $(document).ready(function()
    {
      $("#mySelect").change(function()
      {
        $(this).find("option:selected").each(function()
        {
          var optionValue = $(this).attr("value");
          if(optionValue)
          {
            if(optionValue=='payment')
            {
              subscription_list();
            }
            if(optionValue=='video')
            {
              video_download_list();
            }
            if(optionValue=='live')
            {
              live_broadcast_list();
            }
            if(optionValue=='Citizens')
            {
              citizen_list();
            }
            if(optionValue=='Lawyers')
            {
              lawyer_list();
            }
            $(".select-box").not("." + optionValue).hide();
            $("." + optionValue).show();
          }
          else
          {
            $(".select-box").hide();
          }
        });
      }).change();

      setUserTimezone();
    });


    $('.input-daterange input').each(function()
    {
      $(this).datepicker('clearDates');
    });


    setTimeout(function ()
    {
      $(window).resize(function ()
      {
        var getPadd = $("#pageContent");
        var getPadding = parseInt(getPadd.css('padding'));
        var totalPadding = getPadding + getPadding;
        var chk_account_height = $('#footer').outerHeight(true);
        var chk_card_height = $('#header').outerHeight(true) + $('#footer').outerHeight(true);
        var window_height = $(window).height();
        $("#mainContent").css('min-height', window_height - chk_account_height - 1);
        $("#card_height").css('min-height', window_height - chk_card_height - totalPadding);
      }).resize();
    },100);


    var rotate = 1;
    function hide_preloader()
    {
      rotate = 0;
      $("#preloader").fadeOut('slow');
    }
    
</script>