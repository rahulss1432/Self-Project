<footer class="main-footer">
    <div class="container">
        <div class="footer-wrap">
            <div class="row">
                <div class="col-md-12 col-lg-4">
                    <img src="<?php echo e(url('public/images/footer-logo.png')); ?>" alt="logo">
                    <p class="about-detail"><?php echo e(\App\Models\Settings::getSettingByKey('footer-content')->setting_value); ?></p>
                </div>

                <div class="col-sm-6 col-lg-5">
                    <ul class="list-unstyled">
                        <li><strong>Address : </strong> <?php echo e(\App\Models\Settings::getSettingByKey('address')->setting_value); ?> </li>
                        <li><strong>Phone : </strong><a href="tel:<?php echo e(\App\Models\Settings::getSettingByKey('phone')->setting_value); ?>"><?php echo e(\App\Models\Settings::getSettingByKey('phone')->setting_value); ?></a></li>
                        <li><strong>Email :</strong><a href="mailto: <?php echo e(\App\Models\Settings::getSettingByKey('email')->setting_value); ?>"> <?php echo e(\App\Models\Settings::getSettingByKey('email')->setting_value); ?></a></li>
                    </ul>
                </div>

                <div class="col-sm-6 col-lg-3">
                    <ul class="list-unstyled">
                        <li><a target="_blank" href="<?php echo e(\App\Models\Settings::getSettingByKey('facebbok-url')->setting_value); ?>"><i class="fa fa-facebook"></i> Facebook</a></li>
                        <li><a target="_blank" href="<?php echo e(\App\Models\Settings::getSettingByKey('twitter-url')->setting_value); ?>"><i class="fa fa-twitter"></i> Twitter</a></li>
                        <li><a target="_blank" href="<?php echo e(\App\Models\Settings::getSettingByKey('google-url')->setting_value); ?>"><i class="fa fa-google"></i>  Google</a></li>
                    </ul>
                </div>
            </div>
        </div>


        <!-- xxxxxx -->


        <div class="bottom-footer text-center">
            <p class="mb-0"><?php echo e(\App\Models\Settings::getSettingByKey('copy-right')->setting_value); ?></p>
        </div>
    </div>
</footer>
<div id="player"></div>
<script type="text/javascript">
    $(document).ready(function () {
        removePlayer();
        var chk_height = $('.topheader').outerHeight(true) + $('.main-footer').outerHeight(true);
        var window_height = $(window).height();
        $(".main-content").css('min-height', window_height - chk_height - 100);
    }).resize();
//ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });

// on scroll fix nav
    $(window).bind('scroll', function () {
        if ($(window).scrollTop() > 120) {
            $('.topheader').addClass('fixed');
        } else {
            $('.topheader').removeClass('fixed');
        }
    });

// focused class
    $('.form-control').on('focus blur', function (e) {
        $(this).parents('.form-group').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
    }).trigger('blur');

// profile menu open / close

    function openMenu() {
        $('.profile-wrapper').addClass('inner-menu-active');
    }

    function closeMenu() {
        $('.profile-wrapper , .navbar-toggler').removeClass('inner-menu-active');
    }
    
    function playMedia(obj,name,src){
        $('.playactive').removeClass('.playactive');
        $('.playBtn').show();
        $('.voicBar').hide();
        obj.parent().parent().parent().addClass('playactive');
        obj.find('.playBtn').hide();
        obj.find('.voicBar').show();
        var html='<div class="podcast-player">\
   <a href="javascript:void(0);" onclick=removePlayer()>\
        <img src="<?php echo e(url("public/images/close-button.png")); ?>" alt="">\
    </a>\
 <p>'+name+'</p>\
    <audio id="myVideo" controls>\
        <source src="'+src+'" type="audio/mpeg">\
        Your browser does not support the audio element.\
    </audio>\
</div>'
            $('#player').html(html);
            document.getElementById("myVideo").play();
            var aud = document.getElementById("myVideo");

aud.onplay = function() {
    obj.find('.playBtn').hide();
        obj.find('.voicBar').show();
}; 
aud.onended = function() {
    obj.find('.playBtn').show();
        obj.find('.voicBar').hide();
}; 
            
    }
    function removePlayer(){
        $('.podcast-player').remove();
        $('.playactive').removeClass('.playactive');
        $('.voicBar').hide();
        $('.playBtn').show();
    }
</script>