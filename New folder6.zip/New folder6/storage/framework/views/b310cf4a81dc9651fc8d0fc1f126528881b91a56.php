<?php $__env->startSection('title', 'Add Broadcast'); ?>
<?php $__env->startSection('content'); ?>
<link href="<?php echo e(url('public/assets/css/progressbar-plugin.css')); ?>" rel="stylesheet" type="text/css">
<script src="<?php echo e(url('public/assets/js/progressbar-plugin.js')); ?>"></script>
<body class="bg-light-gray" onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content cms-edit" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent" >
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Add Broadcasted Video</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a id="back-loader" onclick="backfunction()" href="<?php echo e(url('admin/broadcasted-videos')); ?>" class="nav-link">
                <i class="fa fa-long-arrow-left"></i>
              </a>
            </li>
          </ul>
        </div>
        <div class="card-body">
           <div class="common_tabs">
<!--            <ul class="nav nav-pills mb-4" id="pills-tab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="pills-browser-tab" data-toggle="pill" href="#browser" role="tab" aria-controls="pills-browser" aria-selected="true">BROWSE</a>
              </li> 
              <li class="nav-item">
                <a class="nav-link" id="pills-you-tab" data-toggle="pill" href="#pills-you" role="tab" aria-controls="pills-you" aria-selected="false">YOUTUBE</a>
              </li>
            </ul>-->
            <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane browser_tab fade show active" id="browser" role="tabpanel" aria-labelledby="pills-browser-tab">
                <form class="f-field" id="addVideoForm" method="POST" action="<?php echo e(url('admin/save-video')); ?>" enctype='multipart/form-data'>
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                          <div class="col-md-4 col-sm-6">
                            <div class="form-group">
                              <label class="control-label">Title<span class="red-star"> *</span></label>
                              <input type="text" name="title" class="form-control form-control-lg">
                            </div>
                          </div>
                          <div class="col-md-4 col-sm-6">
                            <div class="form-group">
                              <label class="control-label">Location<span class="red-star"> *</span></label>
                              <input type="text" name="location" class="form-control form-control-lg">
                            </div>
                          </div>        
                          <div class="col-md-4 col-sm-6">
                             <div class="form-group">
                              <label class="control-label">Video<span class="red-star"> *</span></label>
                                <div class="file-upload">
                                  <div class="file-select">
                                    <div class="file-select-button" id="fileName">Choose File</div>
                                    <div class="file-select-name" id="noFile">No file chosen...</div> 
                                    <input type="file" name="video" id="chooseFile">
                                  </div>
                             </div>
                          </div>
                            
                           
                          </div>
                        </div>
                         <div class="video_loder" style="display:none;">
                            <div class="overlay"></div>
                            <div id="progress-bar" class="my-progress-bar"></div>
                            <div id="targetLayer"></div>
                         </div>
                        <div class="from-group">
                          <button type="submit" class="btn btn-primary btn_radius saveLoader"> Save</button>
                        </div>
                  </form>
                  <?php echo JsValidator::formRequest('App\Http\Requests\AddVideoRequest','#addVideoForm'); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


  
  <script type="text/javascript">
    $('#chooseFile').bind('change', function () {
    var filename = $("#chooseFile").val();
    if (/^\s*$/.test(filename)) {
      $(".file-upload").removeClass('active');
      $("#noFile").text("No file chosen..."); 
    }
    else {
      $(".file-upload").addClass('active');
      $("#noFile").text(filename.replace(/C:\\fakepath\\/i, '')); 
    }
  });
    $('.form-group .form-control').focus(function () 
    {
      $(this).parent().addClass('isfocused');
    }).blur(function () 
    {
      $(this).parent().removeClass('isfocused');
    });
   
    function backfunction()
    {
      $("#back-loader").attr("disabled", true);
      $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    }

    window.addEventListener('beforeunload', function(event)
    {
      $(".saveLoader").attr("disabled", true);
      $(".saveLoader").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
    });

//    $("#embeded_url").blur(function() {
//      var url = $('#embeded_url').val();
//      if (url != undefined || url != '') {
//        var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/)([A-Za-z0-9]*).*/;
//        var match = url.match(regExp);
//        if (match && match[2].length == 11) {
//          $("#urlError").val("Valid url");
//          $("#embeded_url_error").display = 'none';
//          $("#urlError-error").display = 'none';
//          return true;
//        } else {
//          $("#embeded_url_error").html("Enter a valid embed url.");
//          return false;
//        }
//      }
//    });

//Add Progress Bar
$(document).ready(function() { 
  var progress_circle = $("#progress-bar").circularProgress({
        // color
        color: "#2c72ff",

        // height
        height: "180px",

        // width
        width: "180px",

        // line width
        line_width: 8,

        // stating value
        starting_position: 0,

        // max value
        percent: 0,

        // false = counterclockwise
        counter_clockwise: false,

        // show value
        percentage: true,

        // custom counter text
        text: 'Uploaded'

      });
  var oldValue = 0;
    $('#addVideoForm').submit(function(e) {	
        if($('#addVideoForm').valid()) {
            
            e.preventDefault();
             $(".saveLoader").attr("disabled", true);
             $(".saveLoader").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
            $(this).ajaxSubmit({ 
                target:   '#targetLayer', 
                beforeSubmit: function() {
                    //$("#progress-bar").width('0%');
                    $(".video_loder").css('display','block');
                },
                uploadProgress: function (event, position, total, percentComplete){
                    if(percentComplete > oldValue){
                      //$("#progress-bar").width(percentComplete + '%');
                      //$("#progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');
                      progress_circle.circularProgress('animate', percentComplete,3000);
                    }	
                    oldValue = percentComplete;
                },
                complete: function(xhr) {
                    var arr = JSON.parse(xhr.responseText);
                    $(".video_loder").css('display','none');
                    if (arr.status == true) {
                    $('#addVideoForm')[0].reset();
                      window.location.href = "<?php echo e(url('admin/broadcasted-videos')); ?>";
                }
                else {
                     $(".saveLoader").attr("disabled", false);
                     $(".saveLoader").html('SAVE');
                     $(".video_loder").css('display','none');
                     toastr.remove();
                     toastr.options.closeButton = true;
                     toastr.error(arr.message, 'Error', {timeOut: 2000});
                     return false;
                }
                }
               
            }); 
           
        }
    });
});
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>