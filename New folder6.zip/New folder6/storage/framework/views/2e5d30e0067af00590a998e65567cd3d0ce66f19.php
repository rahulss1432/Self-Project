<?php $__env->startSection('title', 'Police Department Add'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray" onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content cms-edit" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent" >
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Add Police Department</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a id="back-loader" onclick="backfunction()" href="<?php echo e(url('admin/police-department')); ?>" class="nav-link">
                <i class="fa fa-long-arrow-left"></i>
              </a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <form class="f-field" id="addPoliceDepartmentForm" method="POST" action="<?php echo e(url('admin/add-police-department')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="row">
              <div class="col-sm-4">
                <div class="form-group">
                  <label class="control-label">State</label>
                  <select name="state" onchange="selectCity(this.value,''),$(this).valid()" class="form-control form-control-lg selectpicker">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div> 
              <div class="col-sm-4">
                <div class="form-group">
                  <label class="control-label">City</label>
                  <select name="city" id="city" onchange="$(this).valid()" class="form-control form-control-lg selectpicker">
                    <option value="">Select City</option>
                  </select>
                </div>
              </div> 
              <div class="col-sm-4">
                <div class="form-group">
                  <label class="control-label">Enter Department Name <span class="red-star">*</span></label>  
                  <input type="text" name="police_department" class="form-control form-control-lg">
                </div>
              </div> 
            </div>
            <div class="row">
              <div class="col-sm-4">
                <div class="form-group">
                  <label class="control-label">Chief of Police <span class="red-star"> *</span></label>
                  <input type="text" name="chief_of_police" class="form-control form-control-lg">
                </div>
              </div> 
              <div class="col-sm-4">
                <div class="form-group">
                  <label class="control-label">Contact Number<span class="red-star"> *</span></label>
                  <input type="text" name="contact_number" class="form-control form-control-lg">
                </div>
              </div> 
              <div class="col-sm-4">
                <div class="form-group">
                  <label class="control-label">Enter Email<span class="red-star"> *</span></label>
                  <input type="text" name="email" class="form-control form-control-lg">
                </div>
              </div>
            </div>
            <div class="from-group">
              <button type="submit" class="btn btn-primary btn_radius" id="save-loader"> Save</button>
            </div>
          </form>
          <?php echo JsValidator::formRequest('App\Http\Requests\PoliceDepartmentRequest','#addPoliceDepartmentForm'); ?>

        </div>
      </div>
    </div>
  </main>

  <script type="text/javascript">

    $('.form-group .form-control').focus(function () 
    {
      $(this).parent().addClass('isfocused');
    }).blur(function () 
    {
      $(this).parent().removeClass('isfocused');
    });

   
    function backfunction()
    {
      $("#back-loader").attr("disabled", true);
      $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    }

    window.addEventListener('beforeunload', function(event)
    {
      $("#save-loader").attr("disabled", true);
      $("#save-loader").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
    });


    function selectCity(id,city_id) 
    {
      if(id !='')
      {
        var token = '<?php echo e(csrf_token()); ?>';
        $.ajax({
                  url: "<?php echo e(url('admin/select-cities')); ?>",
                  data: {_token: token,id:id,city_id:city_id},
                  type: 'POST',
                  success: function (city)
                  {
                    $('#city').html(city.html);
                    $('#city').selectpicker('refresh');
                  },
                  error: function (city)
                  {
                    console.log('an error occurred');
                  }
              });
      }
      else
      {
        $('#city').html('<option value="">Select City</option>');
        $('#city').selectpicker('refresh');
      }
    }

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>