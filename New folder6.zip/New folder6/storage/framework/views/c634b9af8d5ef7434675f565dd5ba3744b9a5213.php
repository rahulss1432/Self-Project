
<header id="header">
  <nav class="navbar navbar-light justify-content-between bg-transparent">
    <h3 class="page-title">
      <a href="javascript:void(0);" class="toggle-icon d-xl-none">
        <i class="fa fa-outdent"></i>
      </a>
    </h3> 
    <ul class="nav ml-auto">
      <li>
        <a class="btn btn-default btn-flat p-0" href="<?php echo e(url('admin/logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
          <i class="fa fa-power-off"></i><span> Logout</span>
        </a>
        <form id="logout-form" action="<?php echo e(url('admin/logout')); ?>" method="POST" style="display: none;">
          <?php echo e(csrf_field()); ?>

        </form>
      </li>
    </ul>
  </nav>
</header>