<?php $__env->startSection('title','Request Received'); ?>
<?php $__env->startSection('content'); ?>
<main class="dashboard-main-wrap applied_job_page" id="content">
        <div class="container-fluid">
            <div class="common-detail-section">
                <div class="content-body">
                    <!-- <h2 class="page-title mt-0">Request Received</h2> -->
                           <!-- breadcrumb start-->
                   <nav aria-label="breadcrumb" class="text-right">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Request Received</li>
                    </ol>
                </nav>
                <!-- breadcrumb end-->
                    <div class="card">
                        <div class="card-body">
                            <div id="requestReceivedlist">                               
                            </div>                            
                            <div class="text-center">
                                <div class="load_more" id="loadMore" style="display: none;">
                                    <a href="javascript:void(0);">
                                        <img src="<?php echo e(url('public/images/load_more.svg')); ?>" alt="icon">Load More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal -->
    <div class="modal fade" id="declineModal" tabindex="-1" role="dialog" aria-labelledby="declineModal" aria-hidden="true" data-backdrop="static" data-keyboard="false">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="declineModal">Decline Interview Request</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <i class="ti-close"></i>
            </button>
          </div>
          <div class="modal-body">
            Are you sure you want to decline interview request?             
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default btn-sm ripple-effect-dark text-uppercase" data-dismiss="modal">No</button>
            <button type="button" class="btn btn-success btn-sm ripple-effect-dark text-uppercase" onclick="declineInvitationreceived()">Yes</button>
          </div>
        </div>
      </div>
    </div>
<script type="text/javascript">
    $(document).ready(function(){
        loadInvitationReceivedList();
    });
    
    function loadInvitationReceivedList(){
        $("#requestReceivedlist").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        $.ajax({
            type: "GET",            
            url: "<?php echo e(url('/user/load-request-received-list')); ?>",
            success: function (response) {
                $('#requestReceivedlist').html(response);
            }
        });
    }
    function declineModal(id){
        var id = id;
        $('#hiddenJobInvitationId').val(id);
        $('#declineModal').modal();       
    }
    function declineInvitationreceived(){
        var id = $('#hiddenJobInvitationId').val();    
        $.ajax({
            url: "<?php echo e(url('/user/decline-invitation')); ?>",
            type: "POST",
            data: {id: id,_token: '<?php echo e(csrf_token()); ?>'},
            success: function (data)
            {   
                if (data.success == 'true') {
                    toastr.clear();
                    toastr.options.closeButton = true;
                    toastr.success(data.message, 'Success', {timeOut: 3000});
                    $('#declineModal').modal('hide');
                    loadInvitationReceivedList();        
                } else {
                    toastr.clear();
                    toastr.options.closeButton = true;
                    toastr.error(data.message, 'Error', {timeOut: 3000});
                }                
            }
        });
    }
    
</script>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>