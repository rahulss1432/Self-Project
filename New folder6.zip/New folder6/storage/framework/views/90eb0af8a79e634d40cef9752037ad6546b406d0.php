<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content dashboard_page">
    <div class="content_wrapper">


        <div class="row static_row mt-0">

            <div class="col-md-3">
                <div class="page_title"><h2>Dashboard</h2></div>


                <div class="static_box align-items-center bg-white box-shadow ">
                    <div class="icon">
                        <img src="<?php echo e(url('public/admin/images/users-ic.png')); ?>" alt="users">
                    </div>
                    <div class="total">
                        <h3 data-count="<?php echo e($data['usercount']); ?>">0</h3>
                        <span>Total Users</span>
                    </div>
                </div>



                <div class="static_box align-items-center bg-white box-shadow">
                    <div class="icon">
                        <img src="<?php echo e(url('public/admin/images/earning-ic.png')); ?>" alt="earning">
                    </div>
                    <div class="total">
                        <h3 data-count="<?php echo e($data['totalEarning']); ?>" class="currency">0</h3>
                        <span>Total Earnings </span>
                    </div>
                </div>



                <div class="static_box align-items-center bg-white box-shadow">
                    <div class="icon">
                        <img src="<?php echo e(url('public/admin/images/ebook-ic.png')); ?>" alt="ebook">
                    </div>
                    <div class="total">
                        <h3 data-count="<?php echo e($data['totalsold']); ?>">0</h3>
                        <span>Total EBook Copies Sold</span>
                    </div>
                </div>

            </div>

            <!-- xxxxxxx -->

            <div class="col-md-9">
                <div class="static_row">
                    <div class="page_title d-flex justify-content-between">
                        <h2>Recent Transaction </h2>
                        <a href="<?php echo e(url('/admin/manage-transactions')); ?>" class="view-all">View All</a>
                    </div>
                    <div class="bg-white box-shadow common_table">
                        <div class="table-responsive">
                            <?php echo $__env->make('admin.payment-history._load_table', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                </div>


                <!-- xxxxxxxxx -->

                <div class="static_row">
                    <div class="page_title d-flex justify-content-between">
                        <h2>New Users</h2>
                        <a href="<?php echo e(url('/admin/manage-users')); ?>" class="view-all">View All</a>
                    </div>
                    <div class="bg-white box-shadow common_table">
                        <div class="table-responsive">
                            <?php echo $__env->make('admin.user._load_table', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>




        </div>



    </div>
</div>
<script>
    $('.static_box .total h3').each(function () {
        var $this = $(this),
                countTo = $this.attr('data-count');

        $({countNum: $this.text()}).animate({
            countNum: countTo
        },
        {
            duration: 2300,
            easing: 'linear',
            step: function () {
                $this.text(Math.floor(this.countNum));
            },
            complete: function () {
                $this.text(this.countNum);
            }

        });


    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>