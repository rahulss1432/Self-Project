<header class="main_header">
    <nav class="navbar navbar-expand fixed-top bg-white  bg-light" >
        <div class="navbar-brand-wrapper  d-flex align-items-center">
            <a class="navbar-brand mx-auto" href="<?php echo e(url('/admin')); ?>">
                <img src="<?php echo e(url('public/admin/images/logo.png')); ?>" alt="logo" class="mx-auto">
            </a>
        </div>

        <div class="collapse navbar-collapse" >
            <button type="button" class="navbar_toggle btn">
                <span class="icon"></span>
        </div>
        <ul class="navbar-right ml-auto list-unstyled mb-0 d-flex align-items-center">
            <li class="notification list-inline-item">
                <a href="<?php echo e(url('/admin/notifications')); ?>">
                    <span class="notificationcount"><?php echo e(\App\Models\Notification::getNotificationCount()); ?></span>
                    <i class="icon-notifications-bell-button1"></i>
                </a>
            </li>
            <li>
                <div class="dropdown profile">
                    <a class="btn dropdown-toggle" href="javascript:void(0);" role="button" id="profile_dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"  onclick="filterClose()">
                        <div class=" d-flex align-items-center">
                            <img src="<?php echo e(\App\Helpers\Utility::checkProfileImage(Auth::guard('admin')->user()->profile_image)); ?>" class="rounded-circle" alt="user">
                            <div class="info">
                                <h6 class="mb-0"><?php echo e(Auth::guard('admin')->user()->first_name); ?> <?php echo e(Auth::guard('admin')->user()->last_name); ?></h6>
                            </div>
                        </div>
                    </a>
                    <div class="dropdown-menu right_swip" aria-labelledby="profile_dropdown">
                        <a class="dropdown-item ripple-effect" href="<?php echo e(url('/admin/user-profile')); ?>"> <i class="icon-edit-user"></i> Profile</a>
                        <a class="dropdown-item ripple-effect" href="<?php echo e(url('/admin/change-password')); ?>"> <i class="icon-nut-icon1"></i> Settings</a>
                        <a class="dropdown-item ripple-effect" href="<?php echo e(url('/admin/logout')); ?>"><i class="flaticon-power-button"></i> Logout</a>
                    </div>
                </div>
            </li>
        </ul>        
    </nav>
</header>
