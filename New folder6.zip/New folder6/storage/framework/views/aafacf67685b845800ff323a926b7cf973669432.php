<div class="notification-in">
    <span class="notification-icon"><i class="<?php echo e($notification['icon']); ?>"></i></span>
    <span class="notification-text">
        <?php echo $notification['message']; ?>

    </span>
    <?php if(!empty($showDate)): ?>
    <span class="ml-auto date_tym"><?php echo e(\App\Helpers\Utility::getDateFormat($notification['created_at'])); ?></span>
    <?php endif; ?>
</div>
