<div class="table-responsive hide_filter_page">
	<table class="table common-table admin-table w-100">
		<thead class="th-border">
			<tr>
				<th>Sr.</th>
				<th>Name</th>
				<th>Email</th>
				<th>Subscription</th>
                                <th>Amount</th>
				<th>Last Login</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php if(!empty($userList->count()>0)): ?> <?php $i=1; ?> <?php $__currentLoopData = $userList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $srNo = ($userList->currentPage() - 1) * $userList->perPage() + $i++; ?>
			<tr>
				<td><?php echo e($srNo); ?></td>
				<td><?php echo e($user['first_name'].' '.$user['last_name']); ?></td>
				<td><?php echo e($user['email']); ?></td>
				<td><?php echo e((!empty($user->getActivePlan->getPlan->plan_name))?$user->getActivePlan->getPlan->plan_name:''); ?></td>
                                <td><?php echo e(\App\Helpers\Utility::getPriceFormat($user->getActivePlan->amount)); ?></td>
				<td><?php echo e(\App\Helpers\Utility::getDateTimeFormat($user['last_login'])); ?></td>
				<td>
					<div class="switch">
						<label>
                            <input type="checkbox" <?php echo e(($user['status']=='enabled')?'checked="checked"':''); ?> onchange="updateStatus('<?php echo e($user["id"]); ?>');" name="status[]" value="<?php echo e($user['status']); ?>">
                            <span class="lever"></span>
                        </label>
					
					</div>
				</td>
				<td>
					<ul class="list-inline mb-0">
                                            <?php if(Auth::guard('admin')->user()->user_type == 'admin'): ?>
						<li class="list-inline-item"><a href="javascript:void(0);" onclick="editUser('<?php echo e($user['id']); ?>')" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
						</li>
                                            <?php endif; ?>
						<li class="list-inline-item"><a href="<?php echo e(url('/admin/user-detail/'.$user["id"])); ?>" data-toggle="tooltip" data-placement="top" title="View"><i class="fa fa-eye"></i></a>
						</li>
					</ul>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?>
			<tr>
				<td colspan="8">
					<?php \App\Helpers\Utility::emptyListMessage($user_type); ?>
				</td>
			</tr>
			<?php endif; ?>
		</tbody>
	</table>
</div>
<?php\ App\ Helpers\ Utility::getAdminPaginationDiv( $userList );
?>

<script>
	var title = '<?php echo e(ucfirst($user_type)); ?>';
	$( document ).ready( function () {
		$( ".pagination li a" ).on( 'click', function ( e ) {
			e.preventDefault();
			$( "#industryList" ).html( '<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>' );
			var pageLink = $( this ).attr( 'href' );
			$.ajax( {
				type: 'POST',
				url: pageLink,
				async: false,
				data: $( '#frmFilter' ).serialize(),
				success: function ( response ) {
					$( '.pagination:first' ).remove();
					$( "#industryList" ).html( response );
				}
			} );
		} );
	} );

	function updateStatus( id ) {
		$.ajax( {
			type: "POST",
			url: "<?php echo e(url('/admin/update-user-status')); ?>",
			data: {
				'_token': "<?php echo e(csrf_token()); ?>",
				'id': id
			},
			success: function ( response ) {
				if ( response.status ) {
					successToaster(response.message, title);
				}
			}
		} );
	}
</script>
