<header class="topheader innerheader">
    <nav class="navbar navbar-expand-md navbar-light" id="nav">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(url('public/assets/images/logo.png')); ?>" class="img-fluid" alt="logo">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#homenav" aria-controls="homenav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse  navbar-collapse " id="homenav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>#home" ><span data-hover="Home">Home</span></a>
                    </li>
                    <li class="nav-item separator">
                        |
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>#aboutus" ><span data-hover="About us">About us </span></a>
                    </li>
                    <li class="nav-item separator">
                        |
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>#features"><span data-hover="Features">Features</span></a>
                    </li>
                    <li class="nav-item separator">
                        |
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>#howitworks"><span data-hover="How it Works">How it Works</span></a>
                    </li>
                    <li class="nav-item separator">
                        |
                    </li>
                     <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/blog')); ?>"><span data-hover="Blogs">Blogs</span></a>
                    </li>
                    <li class="nav-item separator">
                        |
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>#faq"><span data-hover="FAQs">FAQs</span></a>
                    </li>
                    <li class="nav-item separator">
                        |
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>#contactus"><span data-hover="Contact Us">Contact Us</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>