<?php $__env->startSection('title','Video Views'); ?>
<?php $__env->startSection('content'); ?>
<main class="dashboard-main-wrap applied_job_page" id="content">
        <div class="container-fluid">
            <div class="common-detail-section">
                <div class="content-body">
                    <!-- <h2 class="page-title mt-0">Request Received</h2> -->
                           <!-- breadcrumb start-->
                   <nav aria-label="breadcrumb" class="text-right">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Video Views</li>
                    </ol>
                </nav>
                <!-- breadcrumb end-->
                    <div class="card">
                        <div class="card-body">
                            <div id="profileVideoViews">                                
                            </div>                            
                            <div class="text-center">
                                <div class="load_more" id="loadMore" style="display: none;">
                                    <a href="javascript:void(0);">
                                        <img src="<?php echo e(url('public/images/load_more.svg')); ?>" alt="icon">Load More
                                    </a>
                                </div>
                                <input type="hidden" id="activity_type" value="view_video">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<script type="text/javascript">
    $(document).ready(function(){
        loadVideoViewsList();
    });
    
    function loadVideoViewsList(){
        $("#profileVideoViews").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        var activity_type = $('#activity_type').val();
        var token = '<?php echo e(csrf_token()); ?>';
        $.ajax({
            type: "POST",            
            url: "<?php echo e(url('/user/load-profile-video-view-list')); ?>",
            data: {_token: token, activity_type: activity_type,is_pagination:'yes', page:''},
            success: function (response) {
                $('#profileVideoViews').html(response);
            }
        });
    }
</script>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>