<!-- field-heading -->
<form id="experienceForm" method="POST" action="<?php echo e(url('/user/save-experience')); ?>">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id" value="<?php echo e($model->id); ?>">
    <div class="row">
        <?php if(empty($model->id)): ?>
        <div class="col-12">
            <label class="field-heading font-md d-block w-100">Add New Experience</label>
        </div>
        <?php else: ?>
        <div class="col-12">
            <label class="field-heading font-md d-block w-100"> Edit Experience</label>
        </div>
        <?php endif; ?>
        <div class="col-sm-6">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Title" name="title" value="<?php echo e($model->title); ?>">
            </div>
        </div>

        <div class="col-sm-6">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Company Name" name="company_name" value="<?php echo e($model->company_name); ?>">
            </div>
        </div>

        <!-- field-heading -->
        <div class="col-12">
            <label class="field-heading font-md d-block w-100">Duration</label>
        </div>

        <div class="col-sm-6">
            <div class="form-group">

                <input type="text" readonly="true" name="duration_form" value="<?php echo e((strtotime($model->duration_from)>0)?date("d-m-Y",strtotime($model->duration_from)):''); ?>" class="form-control date from_date"  data-toggle="datetimepicker" data-target="#datetimepicker1" id="datetimepicker1" placeholder="From Date" />
            </div> 
        </div>

        <div class="col-sm-6">
            <div class="form-group">

                <input type="text" readonly="true"  name="duration_to" value="<?php echo e((strtotime($model->duration_to)>0)?date("d-m-Y",strtotime($model->duration_to)):''); ?>" class="form-control date to_date" data-toggle="datetimepicker" data-target="#datetimepicker2" id="datetimepicker2" placeholder="To Date">
            </div>
        </div>

        <div class="col-md-12">
            <div class="custom-control custom-checkbox mb-4">
                <input type="checkbox" onchange="disDurationTo()" class="custom-control-input" id="remeberme" <?php echo e(($model->is_working=='yes')?'checked="checked"':''); ?> name="is_working" value="yes"> 
                <label class="custom-control-label" for="remeberme"><span>I currently work here</span></label>
            </div>
        </div>
        <div class="col-md-12 btn-row">
            <?php if(empty($model->id)): ?>
            <button id="btn-experience" class="btn btn-success">Save <span class="and-font">&</span> Add More</button>
            <button id="submitBtn" type="submit" class="btn btn-warning ml-md-3">Save <span class="and-font">&</span> Next</button>
            <?php else: ?>
            <button id="btn-experience" class="btn btn-success">Update</button>
            <button type="button" class="btn btn-warning ml-md-3" onclick="actionExperience(0)">Cancel</button>
            <?php endif; ?>
        </div>
    </div>
</form>
<?php echo JsValidator::formRequest('App\Http\Requests\ExperienceRequest','#experienceForm'); ?>

<script>
    $("#btn-experience").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btn-experience');
        var form = $('#experienceForm');
        if (form.valid()) {
        btn.html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?> Submit');
                btn.prop('disabled', true);
                $.ajax({
                url: "<?php echo e((url('/user/experience-submit'))); ?>",
                        type: "POST",
                        data: form.serialize(),
                        success: function (data)
                        {
                            successToaster(data.message, 'Experience');
                            loadExperienceList();
                            actionExperience(0);
                        },
                        error: function (data) {
                            var obj = jQuery.parseJSON(data.responseText);
                            obj = obj['errors'];
                            for (var x in obj) {
                            btn.prop('disabled', false);
                                    btn.html('Submit');
                                    $('#' + x + '-error').html(obj[x]);
                                    $('#' + x + '-error').css("color", '#b30000');
                                    $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                        }
                        },
                });
    }
    }));
            $(function () {
                $('.from_date').datetimepicker({
                format: '<?php echo e(\App\Helpers\Utility::getDatePickerForamt()); ?>',
                        <?php if(strtotime($model->duration_to) > 0): ?>
                        maxDate: '<?php echo e(date("Y-m-d",strtotime($model->duration_to))); ?>',
                        <?php else: ?>
                        maxDate: moment(),
                        <?php endif; ?>
                        ignoreReadonly: true,
                        useCurrent: false,
                });
                        $('.to_date').datetimepicker({
                format: '<?php echo e(\App\Helpers\Utility::getDatePickerForamt()); ?>',
                        <?php if(strtotime($model->duration_to) > 0): ?>
                        minDate: '<?php echo e(date("Y-m-d",strtotime($model->duration_from))); ?>',
                        <?php else: ?>
                        maxDate: moment(),
                        <?php endif; ?>
                        ignoreReadonly: true,
                        useCurrent: false,
                });
                        $(".from_date").on("change.datetimepicker", function (e) {
                    $('.to_date').datetimepicker('minDate', e.date);
                });
                $(".to_date").on("change.datetimepicker", function (e) {
                    $('.from_date').datetimepicker('maxDate', e.date);
                });
            });

    $('#experienceForm').on('submit', function (e) {
        if ($('#experienceForm').valid()) {
            $('#submitBtn').html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?>  Save & Next');
            $("#submitBtn").prop('disabled', true);
        }
    });

    function disDurationTo() {
        if ($('#remeberme').prop('checked')) {
            $('#datetimepicker2').val('');
            $('#datetimepicker2').attr('disabled', true);
        } else {
            $('#datetimepicker2').attr('disabled', false);
            $('#datetimepicker2').val('');
        }
    }
</script>