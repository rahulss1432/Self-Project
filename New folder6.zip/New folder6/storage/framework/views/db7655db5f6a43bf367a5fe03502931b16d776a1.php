<aside class="left-side-wrap">
    <div class="text-right p-2">
        <a href="javascript:void(0);" onclick="closeMenu()">
            <img src="<?php echo e(url('public/images/close-button.png')); ?>" alt="close" class="d-lg-none">
        </a>
    </div>

    <ul class="list-unstyled">
        <li class="<?php echo e(( \Request::route()->getName() == 'user.profile') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('/user/my-profile')); ?>" class="first-option">
                My Profile
            </a>
        </li>
        <li class="<?php echo e(( \Request::route()->getName() == 'user.my-ebook') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('/user/my-ebook')); ?>">
                My eBook
            </a>
        </li>
        <li class="<?php echo e(( \Request::route()->getName() == 'user.change-password') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('/user/change-password')); ?>">
                Change Password
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('/logout')); ?>">
                Log Out
            </a>
        </li>
    </ul>
</aside>