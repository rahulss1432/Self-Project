<?php $__env->startSection('title', 'Ratings and Reviews'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray"  onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content common-grid-list" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent">
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Ratings & Reviews</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a href="#searchFilter" data-toggle="collapse"  class="nav-link"><i class="fa fa-search"></i></a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <div class="filter_section collapse show" id="searchFilter">
            <form id="search_form" action="javascript:load_ratings()" method="post" autocomplete="off">
              <?php echo e(csrf_field()); ?>

              <div class="row">
                <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                  <div class="form-group">
                    <label class="control-label">Star Rating</label>
                    <select id="star_rating_change" class="form-control form-control-lg selectpicker" name="rating">
                      <option value="">Star Rating</option>
                      <option value="1">1 Star</option>
                      <option value="2">2 Star</option>
                      <option value="3">3 Star</option>
                      <option value="4">4 Star</option>
                      <option value="5">5 Star</option>
                    </select>
                  </div>
                </div> 
                <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                  <div class="form-group">
                    <label class="control-label">Citizen Name</label>
                    <input id="user_name" type="text" name="name" class="form-control form-control-lg"/>
                  </div>
                </div> 
                <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                  <div class="form-group">
                    <label class="control-label">Officer Badge Number</label>
                    <input id="badge_number" type="text" name="badge_number" class="form-control form-control-lg"/>
                  </div>
                </div> 
                <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                  <div class="form-group">
                    <label class="control-label">Ticket Number</label>
                    <input id="ticket_number" type="text" name="warning_number" class="form-control form-control-lg">
                  </div>
                </div> 
                <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                  <div class="form-group d-inline-block mr-2">
                    <label class="btn-block">&nbsp;</label>
                    <button class="btn btn-primary" type="submit">Filter</button>
                  </div>
                  <div class="form-group d-inline-block mr-2">
                    <label class="btn-block">&nbsp;</label>
                    <input id="reset-btn" type="reset" class="btn btn-primary" value="reset">
                  </div>
                </div> 
              </div>
            </form>
          </div>
          <div class="table-responsive" id="list_rating_user">
          
          </div>
        </div>
      </div>
    </div>
  </main>
  
  <script type="text/javascript">

    $( "#reset-btn" ).click(function() 
    {
      $('#star_rating_change').val('').change();
    });
    
    
    $(document).ready(function()
    {
      load_ratings();
    });


    $( "#reset-btn" ).click(function() 
    {
      $('#star_rating_change').val('').change();
      $('#user_name').val('').change();
      $('#badge_number').val('').change();
      $('#ticket_number').val('').change();
      load_ratings();
    });

    
    function viewfunction(id)
    {
      $("#view-loader"+id).attr("disabled", true);
      $("#view-loader"+id).html('<i class="fa fa-spinner fa-spin"></i>');
    }


    function load_ratings()
    {
      $("#list_rating_user").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter=$("#search_form").serializeArray();
      search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
      $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/load-rating-list')); ?>",
                data: search_filter,
                success: function (response)
                {
                  $("#list_rating_user").html(response.html);
                  $('#data_table').DataTable({
                                                searching: false,
                                                "order": [],
                                                "columnDefs": [{"targets"  : [6],"orderable": false,}],
                                              });
                }
            });
    }
        
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>