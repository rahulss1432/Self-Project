<div class="view_body about_info">
    <div class="row">
    	<div class="col-md-6">
    		<form action="">
		        <div class="form-group">
		            <input type="text" class="form-control" placeholder="Enter Contact Email Id">
		        </div>

		        <div class="form-group  text-right mb-0">
		 			<button type="button" class="btn btn-success rounded-0 ripple-effect" onclick="getSavebtn()">Save
						<i style="display:none;" class="btn_loader"></i>
		 			</button>

		 			<a href="javascript:void(0);" class="btn btn-dark rounded-0 ripple-effect ml-2">Cancel</a>
		 		</div>
		    </form>
    	</div>
    </div>
    
</div>
