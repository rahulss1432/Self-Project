<?php $__env->startSection('title', 'Edit CMS'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray" onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content cmsedit_page" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent" >
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">CMS Page </h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a id="back-loader" href="<?php echo e(url('admin/cms')); ?>" class="nav-link" onclick="backloader()" title="Back"><i class="fa fa-long-arrow-left"></i></a>
            </li>
          </ul>
        </div>
        <div class="card-body ">
          <div class="common_tabs">
            <ul class="nav nav-pills mb-4" id="pills-tab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#home" role="tab" aria-controls="pills-home" aria-selected="true"><?php echo e($home->title); ?></a>
              </li> 
            </ul>
            <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane home_tab fade show active" id="home" role="tabpanel" aria-labelledby="pills-home-tab">
                <div class="row">
                  <div class="col-sm-6">
                    <form class="f-field" method="POST" onsubmit="return !!(checkDesc());" action="<?php echo e(url('admin/setting-edit',$home->id)); ?>" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                      <div class="form-group mt-3">
                        <input type="hidden" name="title" value="<?php echo e($home->title); ?>">
                        <input type="hidden" name="setting_key" value="<?php echo e($home->setting_key); ?>">
                        <textarea name="key_value" id="key_value" class="form-control form-control-lg pl-0" rows="6"><?php echo e($home->key_value); ?></textarea>
                         <span id="key_value-error" style="font-size: 12px;" class="help-block"></span>
                      </div>
                      <button type="submit" id="save-loader" class="btn btn-primary btn_radius">SAVE</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <script type="text/javascript">

    $(document).ready(function() 
    {
      tinymce.init({
                      theme: "modern",
                      selector: "textarea",
                      relative_urls : false,
                      remove_script_host : false,
                      convert_urls : true,
                      plugins: 'image code',
                      height: 300,
                      toolbar: 'undo redo | image code',
                      images_upload_url : '<?php echo e(url("admin/admin-image-upload")); ?>',
                      images_upload_handler: function (blobInfo, success, failure)
                      {
                        var xhr, formData;
                        xhr = new XMLHttpRequest();
                        xhr.withCredentials = false;
                        xhr.open('POST', '<?php echo e(url("admin/admin-image-upload")); ?>');
                        xhr.setRequestHeader('X-CSRF-TOKEN', '<?php echo e(csrf_token()); ?>');
                        xhr.onload = function()
                        {
                          var json;
                          if (xhr.status != 200)
                          {
                            failure('HTTP Error: ' + xhr.status);
                            return;
                          }
                          json = JSON.parse(xhr.responseText);
                          if (!json || typeof json.location != 'string')
                          {
                            failure('Invalid JSON: ' + xhr.responseText);
                            return;
                          }
                          success(json.location);
                        };
                        formData = new FormData();
                        formData.append('file', blobInfo.blob(), blobInfo.filename());
                        xhr.send(formData);
                      },
                      init_instance_callback: function (editor)
                      {
                        editor.on('keyup', function (e)
                        {
                          var message = tinymce.get('key_value').getContent();
                          if (message === '')
                          {
                            $("#key_value-error").html('Field is required');
                            $("#key_value-error").css('color', '#a94442');
                          }
                          else
                          {
                            $("#key_value-error").html('');
                          }
                        });
                      }
                  });
    });


    function checkDesc()
    {
      var description = tinymce.get('key_value').getContent();
      if (description === undefined || description.length == 0)
      {
        $("#key_value-error").html("Field is required.");
        $("#key_value-error").css('color', '#a94442');
        return false;
      }
      else
      {
        return true;
      }
    }


    function savefuntion()
    {
      $("#view-loader").attr("disabled", true);
      $("#view-loader").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
    };


    window.addEventListener('beforeunload', function(event)
    {
      $("#save-loader").attr("disabled", true);
      $("#save-loader").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
    });


    function backloader()
    {
      $("#back-loader").attr("disabled", true);
      $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    };

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>