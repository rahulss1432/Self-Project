<?php if(($userPortfolio)->count()>0): ?>
<?php $__currentLoopData = $userPortfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="rounded-0 rounded-bottom">
    <div class="">
        <h2 class="page-title m-0">Portfolio</h3>
    </div>
    <div class="card-body resume-box portfolio-box">
       
       
       
       
       
       
       
        <h2 class="font-bold"><?php echo e($portfolio->project_title); ?></h2>
        <div class="action-btn">
            <a href="javascript:void(0);" onclick="actionPortfolio('<?php echo e($portfolio["id"]); ?>');" class="rounded-circle btn btn-success btn-sm ml-md-2"><i class="fa fa-pencil"></i></a>
            <a href="javascript:void(0);" onclick="deletePortfolio('<?php echo e($portfolio["id"]); ?>','<?php echo e($portfolio["title"]); ?>')" class="rounded-circle btn btn-warning btn-sm ml-md-2" ><i class="fa fa-trash"></i></a>  
        </div>
        <p class="font-md color-yellow mb-2 mb-lg-3">Zigbee Based Room Temperature Controller Project</p>
        <div class="duration mb-1 mb-md-2">
            <h4 class="font-md d-inline-block">Duration:</h4>
            <span class="font-rg"><?php echo e($portfolio->duration); ?></span>
        </div>
        <div class="para">
            <h4 class="font-sm mb-1">Project Type</h4>
            <p class="mb-2 mb-lg-3"><?php echo e($portfolio->project_type); ?></p>
            <div class="duration mb-1 mb-md-2">
                <h4 class="font-md d-inline-block mb-0">Amount:</h4>
                <span class="font-rg"><?php echo e($portfolio->project_amount); ?></span>
            </div>
            <?php if($portfolio->project_links != ''): ?>
                <?php $projectLinks = explode(',',$portfolio->project_links);?>
                <?php if(!empty($projectLinks)): ?>
                    <?php $__currentLoopData = $projectLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3 mb-lg-4 link">
                            <a href="javascript:void(0);" class="font-rg color-green"><?php echo e($link); ?></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="para">
            <h4 class="font-sm mb-1">Client Detail</h4>
            <p class="mb-2 mb-lg-3"><?php echo e($portfolio->client_details); ?></p>
        </div>

        <div class="para">
            <h4 class="font-sm mb-1">Project Description</h4>
            <p><?php echo e($portfolio->description); ?></p>
        </div>

        <?php $userDocuments = App\Models\UserDocument::getUserDocumentByProjectId($portfolio->id); ?>
        <?php if(!empty($userDocuments)): ?>
        <div class="document-box mt-lg-4">
            <ul class="list-inline mb-0">
                <?php $__currentLoopData = $userDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-inline-item text-center">
                    <div class="icon" data-toggle="tooltip" data-placement="top" title="" data-original-title="Resume.docx">
                        <img src="http://localhost/rezieo-html/assets/images/pdf-icon.png" alt="icon" class="img-fluid">
                    </div>
                    <a href="javascript:void(0);" class="" "ripple-effect-dark"="">DOWNLOAD</a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<script>
                    var title = 'Portfolio';
                    function deletePortfolio(id, name) {
                    bootbox.confirm('Are you sure do you want to delete <b>' + name + '<b>?', function (result) {
                    if (result) {
                    $.ajax({
                    type: "GET",
                            url: "<?php echo e(url('user/delete-experience')); ?>",
                            data: {id: id},
                            success: function (response) {
                            if (response.status) {
                            successToaster(response.message, title);
                                    loadPortfolioList();
                            }
                            }
                    });
                    }
                    });
                    }
</script>