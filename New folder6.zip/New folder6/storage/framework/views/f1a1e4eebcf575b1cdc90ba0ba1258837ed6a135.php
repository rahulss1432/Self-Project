<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray"  onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content dashboard-page" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="page-content" id="pageContent">
        <div class="row">
          <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 col-400">
            <div class="box clearfix bg-orange">
              <i class="icon fa fa-building orange-color"></i>
              <div class="content">
                <h3><?php echo e($citizens); ?></h3>
                <p class="text-uppercase">Total Citizens</p>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 col-400">
            <div class="box clearfix bg-blue">
              <i class="icon fa fa-user-secret blue-color"></i>
              <div class="content">
                <h3><?php echo e($lawyers); ?></h3>
                <p class="text-uppercase">Total Lawyers</p>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 col-400">
            <div class="box clearfix bg-red">
              <i class="icon fa fa-video-camera red-color"></i>
              <div class="content">
                <h3><?php echo e($videoscount); ?></h3>
                <p class="text-uppercase">Total Videos</p>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 col-400">
            <div class="box clearfix bg-green">
              <i class="icon fa fa-line-chart green-color"></i>
              <div class="content">
                <h3>$ <?php echo e($transaction); ?></h3>
              <p class="text-uppercase">Total Revenue</p>
            </div>
          </div>
        </div>                       
      </div>
      <div class="list">
        <h2>Recent Broadcasts</h2>
        <div class="row">
          <div class="col-lg-6 col-md-12 col-sm-12 col-">
            <div class="common_box boxshadow">
              <h4 class="inner_heading">Live Broadcasts</h4>
              <div class="table-responsive">
                <table class="table list_table" id="data_table">
                  <thead>
                    <tr>
                      <th>Video</th>
                      <th>Posted by</th>
                      <th>Location</th>
                      <th>Date/Time</th>
                      <th>Views</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if(count($videos)>0): ?>
                      <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                          <?php if($data->video_thumb): ?>
<!--                            <?php if($data->video_type == "youtube"): ?>
                              <img src="<?php echo e($data->video_thumb); ?>" class="video_img">
                              <?php elseif($data->video_type == ""): ?>-->
                                <img src="<?php echo e(url('public/uploads/videos/thumb/'.$data->video_thumb)); ?>" class="video_img">
<!--                            <?php endif; ?>-->
                            <?php else: ?>
                              <img src="<?php echo e(url('public/assets/images/timeline_img02.jpg')); ?>" class="video_img">
                          <?php endif; ?>
                          </td>
                          <td><?php echo e(ucfirst($data->first_name)); ?> <?php echo e(ucfirst($data->last_name)); ?></td>
                          <?php if($data->location): ?>
                            <td><?php echo e(substr($data->location,0,20)); ?>...</td>
                            <?php else: ?>
                              <td></td>
                          <?php endif; ?>
                          <td><?php echo e(date('d-m-Y h:i A', strtotime($data->created_at))); ?></td>
                          <td><?php echo e($data->views); ?></td>
                          <td>
                            <a href="javascript:void(0);" onclick='showVideo("<?php echo e($data->id); ?>");'>
                              <i class="fa fa-eye"></i>
                            </a>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td colspan="6">
                            <div class="alert alert-danger"><center> No video available.</center></div>
                          </td>
                        </tr>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="col-lg-6 col-md-12 col-sm-12 col-">
            <div class="common_box boxshadow">
              <h4 class="inner_heading">Map View of Broadcasts</h4>
              <div class="map">
                <?php 
                  Mapper::map(37.0902,-95.7129,['zoom'=>3,'marker'=>false]);
                  foreach($maplocation as $mark){
                    if($mark->latitude){
                    
                        $video='<video class="img-fluid" controls src="'.$mark->video.'"></video>';
                     
                      $content = '<div id="content">
                                    <div id="siteNotice"></div>
                                    <h6 id="firstHeading" class="firstHeading">'.ucfirst($mark->title).'</h6>
                                    '.$video.'
                                  </div>';
                      Mapper::informationWindow($mark->latitude,$mark->longitude,$content,['autoClose'=>true,'maxWidth'=> 400, 'title' => $mark->location]);
                    }
                  }
                 ?>
                <?php echo Mapper::render(); ?>  
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  <div class="modal fade" id="videos_view" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">VIDEO VIEW</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" id="view_videos">
          
        </div>
      </div>
    </div>
  </div>

  <script>

    function showVideo(id)
    {
      $.ajax({
                type: "GET",
                url: "<?php echo e(url('admin/show-videos')); ?>/" + id,
                success: function(response)
                {
                  console.log(response);
                  $("#videos_view").modal("show");
                  $('#view_videos').html(response.html);
                }
            });
    }
  
  </script>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>