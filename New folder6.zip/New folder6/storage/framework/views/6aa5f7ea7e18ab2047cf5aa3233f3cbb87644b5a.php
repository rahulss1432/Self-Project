<?php $__env->startSection('title', 'Blog Detail'); ?>
<?php $__env->startSection('content'); ?>

<script src="<?php echo e(url('public/js/jssocials.js')); ?>"></script>
<main class="main_content blogdetail_page" id="maincontent" >
    <section class="blogdetail_info">
        <div class="container">
            <div class="banner text-center d-flex align-items-center justify-content-center" style="background-image: url('<?php echo e($detail->image); ?>');">
                <div class="overlay"></div>
                <h2><?php echo e($detail->title); ?></h2>
            </div>
            <input type="hidden" name="id" id="blogId" value="<?php echo e($detail->id); ?>">
            <div class="content bg-white"> 
                <div class="profile_info d-sm-flex p-30">
                    <div class="profile d-flex align-items-center ">
                        <img src="<?php echo e($detail->user_image); ?>" class="rounded-circle" alt="user img">
                        <div class="info">
                            <h5><?php echo e($detail->user_name); ?></h5>
                            <p class="mb-0">
                                <?php 
                                $datetime = App\Common\Utility::converToTz($detail->created_at);
                                echo $datetime->format('F d Y')
                                 ?>
                            </p>
                        </div>
                    </div>
                    <div class="action ml-sm-auto">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item">
                                <i class="fa fa-heart"></i> <span><?php echo e($detail->like_count); ?></span>
                            </li>
                            <li class="list-inline-item">
                                <a href="#commentScroll" class="commentScroll">
                                    <i class="fa fa-comment"></i> <span><?php echo e($detail->comment_count); ?></span>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <div class="share-button">
                                    <input class="toggle-input" id="toggle-input01_<?php echo $detail->id ?>" type="checkbox" name="share" />
                                    <label for="toggle-input01_<?php echo $detail->id ?>" class="toggle"></label>
                                    <ul class="network-list">
                                        <li class="twitter">
                                            <a href="javascript:void(0);" class='share-button-twitter'>Share on Twitter</a>
                                        </li>
                                        <li class="facebook">
                                            <a href="javascript:void(0);" class='share-button-facebook'>Share on Facebook</a>
                                        </li>
                                        <li class="googleplus">
                                            <a href="javascript:void(0);" class='share-button-google'>Share on Google+</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="discription p-30">
                    <?php echo $detail->description; ?>

                </div>
                <div class="link url p-30 align-items-center">
                    <div class="d-table-cell"><h3 class="h-24">External links</h3></div>
                    <div class="d-table-cell">
                         <?php
                        if (count($detail->blog_links) > 0) {

                            foreach ($detail->blog_links as $link) {
                                ?>
                                <a href="<?php echo e($link['link']); ?>"><u><?php echo e($link['link']); ?></u></a>
                                <?php
                            }
                        } else {
                            ?>
                            <div class="alert alert-danger"> no link found</div>
                        <?php } ?>
                    </div>
                </div>
                <div class="tags d-flex align-sm-items-center p-30">
                    <h3 class="h-24">Tags</h3>
                    <ul class="list-inline mb-0">
                        <?php
                        foreach ($detail->blog_tags as $tag) {
                            ?>
                            <li class="list-inline-item badge badge-pill"><?php echo e($tag->tag); ?> </li>
                        <?php } ?>
                    </ul>
                </div>
                <div class="comment p-30" id="commentScroll">
                    <h3 class="h-24">Comment</h3>
                    <div class="comment_list mt-3" id="comment_listtt">

                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script type="text/javascript">

$(document).ready(function () {
    detailCommentList();
    $(".share-button-twitter").jsSocials({
        url: "<?php echo e(url('blog-detail',$detail->id)); ?>",
        text: '<?= str_replace("'", "", $detail->title); ?>',
        showLabel: false,
        showCount: false,
        shareIn: "popup",
        shares: ["twitter"]
    });
    $(".share-button-facebook").jsSocials({
        url: "<?php echo e(url('blog-detail',$detail->id)); ?>",
        text: '<?= str_replace("'", "", $detail->title); ?>',
        showLabel: false,
        showCount: false,
        shareIn: "popup",
        shares: ["facebook"]
    });
    $(".share-button-google").jsSocials({
        url: "<?php echo e(url('blog-detail',$detail->id)); ?>",
        text: '<?= str_replace("'", "", $detail->title); ?>',
        showLabel: false,
        showCount: false,
        shareIn: "popup",
        shares: ["googleplus"]
    });
});


function detailCommentList() {
    var blogId = $('#blogId').val();
    $.ajax({
        type: "GET",
        url: "<?php echo e(url('detail-comment-list')); ?>",
        data: {id: blogId},
        success: function (response)
        {
            $("#comment_listtt").html(response.html);

        }, error: function (err)
        {
            console.log(err);
        }
    });
}

$(".commentScroll").on("click", function (e) {
    e.preventDefault();
    $("body, html").animate({
        scrollTop: $($(this).attr('href')).offset().top
    }, 600);
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>