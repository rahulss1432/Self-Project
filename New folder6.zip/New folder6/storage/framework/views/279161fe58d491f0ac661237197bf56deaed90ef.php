<html>
    <body bgcolor="#e8e8e8">
        <table align="center" style="box-sizing: border-box;background-color:#1ACD68;margin:0;padding:0; width: 730px;margin-left:auto; margin-right:auto;" cellpadding="0" cellspacing="0">
            <tbody>
                <tr>
                    <td style=" box-sizing: border-box" align="center">
                        <table style="box-sizing: border-box;margin:0;padding:0;width: 100%" cellpadding="0" cellspacing="0" width="100%">
                            <tbody>
                                <tr>
                                    <td style="box-sizing: border-box;padding: 25px 0;text-align: center;">
                                        <a href="<?php echo e(url('/')); ?>">
                                            <img src="http://hireo.codiant.com/public/images/logo.png" style="height: 50px;">
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="box-sizing: border-box;background-color:#ffffff;border: 1px solid #edeff2;margin: 0;padding: 0;width: 100%;" width="100%">
                                        <?php echo $__env->yieldContent('content'); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td style=" box-sizing: border-box;background:#1ACD68;">
                                        <table style="box-sizing: border-box;margin: 0 auto;padding: 0;text-align: center;width: 570px;" align="center" cellpadding="0" cellspacing="0" width="570">
                                            <tbody>
                                                <tr>
                                                    <td style=" box-sizing: border-box ; padding: 12px" align="center">
                                                        <p style="box-sizing: border-box;line-height: 1.5em;margin-top: 0;color: #aeaeae;font-size: 14px;text-align: center;color: white;font-family: 'avenir' , 'helvetica' , sans-serif;">© <?php echo e(date("Y")); ?> Rezieo. All rights reserved.</p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </body>
</html>