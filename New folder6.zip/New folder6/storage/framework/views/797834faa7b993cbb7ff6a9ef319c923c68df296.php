<?php $__env->startSection('title','Manage Cms'); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/admin/css/jquery.fancybox.min.css')); ?>" type="text/css" />
<div class="main-content view_page">
		<div class="content_wrapper">
			<div class="page_title">
				<h2 class="d-inline-block pr-3 mr-3 border-right">Manage CMS</h2>
				<nav aria-label="breadcrumb" class="d-inline-block">
	                <ol class="breadcrumb p-0 mb-0">
	                  <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
	                  <li class="breadcrumb-item">Manage CMS</li>
	                </ol>
	            </nav>
			</div>
				<ul class="common_tabs list-inline bg-white d-flex">
					<li class="list-inline-item active">
						<a href="javascript:void(0);" class="active" onclick="getCms(1)">Home</a>
					</li>
				  	<li class="list-inline-item">
				    	<a href="javascript:void(0);" onclick="getCms(2)">My eBook</a>
				  	</li>
				  	<li class="list-inline-item">
				    	<a href="javascript:void(0);" onclick="getCms(3)">About Daniel Zeman</a>
				  	</li>
				  	<li class="list-inline-item">
				    	<a href="javascript:void(0);" onclick="getCms(4)">Customer Testimonials</a>
				  	</li>
				  	<li class="list-inline-item">
				    	<a href="javascript:void(0);" onclick="getCms(5)">Contact us</a>
				  	</li>
				</ul>
				<div class="tabs_content">
					<div class="ajax_list_load">
						<div id="content"></div>
					</div>
				</div>
		</div>
	</div>
    <script src="<?php echo e(url('public/admin/js/jquery.fancybox.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/admin/js/tinymce.min.js')); ?>"></script>
<script type="text/javascript">
		$('.common_tabs li a').click(function() {
		    $('.common_tabs li.active').removeClass('active');
		    $(this).closest('li').addClass('active');
		});

		$(document).ready(function () {
	        getCms(1);
	    });

        function getCms(pageId) {
            $("#content").html('<span class="ajax_loader btn_ring"></span>');
            var url = "<?php echo e(url('/admin/load-manage-cms')); ?>";
            $.ajax({
                type: "GET",
                url: url,
                data: {pageId:pageId},
                  success: function (response) {
                          $("#content").html("");
                          $("#content").hide().html(response).fadeIn('1000');
                  }
            });
        }

        function getTestimonialcms(pageId) {
            $("#content").html('<span class="ajax_loader btn_ring"></span>');
            var url = "<?php echo e(url('/admin/load-testimonial-add')); ?>";
            $.ajax({
                type: "GET",
                url: url,
                data: {pageId:pageId},
                    success: function (response) {
                            $("#content").html("");
                            $("#content").hide().html(response).fadeIn('1000');
                    }
            });
        }
</script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>