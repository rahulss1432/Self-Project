<!-- Add Sub Category -->
<div class="modal fade" id="addsubCategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Sub Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name="">                    
          <div class="form-group">                       
              <label>Category Name</label>
              <input type="text" class="form-control" name="category_name"  placeholder="">
          </div>
          <div class="form-group">                       
              <label>Status</label>
              <select class="selectpicker form-control" title="Status">
                  <option value="Enabled">Enabled</option>
                  <option value="Disabled">Disabled</option>                                            
              </select>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Save</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Edit Sub Category -->
<div class="modal fade" id="editsubCategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Sub Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name="">                    
          <div class="form-group">                       
              <label>Category Name</label>
              <input type="text" class="form-control" name="category_name"  placeholder="">
          </div>
          <div class="form-group">                       
            <label>Status</label>
            <select class="selectpicker form-control" title="Status">
                <option value="Enabled">Enabled</option>
                <option value="Disabled">Disabled</option>                                            
            </select>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Edit Disapprove Product -->
<div class="modal fade" id="disapproveProduct" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Reason of Disapprove</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name="">                    
          <div class="form-group">                       
            <textarea class="form-control" name="disapprove_reason" rows="3" placeholder="write here.."></textarea>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Add Color -->
<div class="modal fade" id="addColor" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Color</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name="">                    
          <div class="form-group">
            <label>Color Name</label>
           <input type="text" class="form-control" name="color_name">
          </div>
           <div class="form-group">                       
              <label>Status</label>
              <select class="selectpicker form-control" title="Status">
                  <option value="Enabled">Enabled</option>
                  <option value="Disabled">Disabled</option>                                            
              </select>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Save</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Edit Color -->
<div class="modal fade" id="editColor" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Color</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name="">                    
          <div class="form-group">
            <label>Color Name</label>
           <input type="text" class="form-control" name="color_name">
          </div>
           <div class="form-group">                       
              <label>Status</label>
              <select class="selectpicker form-control" title="Status">
                  <option value="Enabled">Enabled</option>
                  <option value="Disabled">Disabled</option>                                            
              </select>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Add Size -->
<div class="modal fade" id="addSize" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Size</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name="">                    
          <div class="form-group">
            <label>Size Name</label>
           <input type="text" class="form-control" name="size_name">
          </div>
           <div class="form-group">                       
              <label>Status</label>
              <select class="selectpicker form-control" title="Status">
                  <option value="Enabled">Enabled</option>
                  <option value="Disabled">Disabled</option>                                            
              </select>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Save</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Edit Size -->
<div class="modal fade" id="editSize" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Size</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name="">                    
          <div class="form-group">
            <label>Size Name</label>
           <input type="text" class="form-control" name="size_name">
          </div>
           <div class="form-group">                       
              <label>Status</label>
              <select class="selectpicker form-control" title="Status">
                  <option value="Enabled">Enabled</option>
                  <option value="Disabled">Disabled</option>                                            
              </select>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Add Condition -->
<div class="modal fade" id="addCondition" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Condition</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name="">                    
          <div class="form-group">
            <label>Condition Name</label>
           <input type="text" class="form-control" name="condition_name">
          </div>
           <div class="form-group">                       
              <label>Status</label>
              <select class="selectpicker form-control" title="Status">
                  <option value="Enabled">Enabled</option>
                  <option value="Disabled">Disabled</option>                                            
              </select>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Save</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Edit Condition -->
<div class="modal fade" id="editCondition" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Condition</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name="">                    
          <div class="form-group">
            <label>Condition Name</label>
           <input type="text" class="form-control" name="condition_name">
          </div>
           <div class="form-group">                       
              <label>Status</label>
              <select class="selectpicker form-control" title="Status">
                  <option value="Enabled">Enabled</option>
                  <option value="Disabled">Disabled</option>                                            
              </select>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Send Mail -->
<div class="modal fade" id="sendMail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Send Mail</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name=""> 
          <div class="form-group">
            <label>To</label>
            <select class="selectpicker form-control">
                  <option value="all">Select All Registered Users</option>
                  <option value="multiple">Select Multiple Registered users</option>                                            
              </select>
          </div>                   
          <div class="form-group">
              <label>Subject</label>
              <input type="text" class="form-control" name="subject"  placeholder="">
          </div>
          <div class="form-group">
            <label>Message</label>                       
            <textarea class="form-control" name="message" rows="3" placeholder=""></textarea>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Send</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Message View -->
<div class="modal fade bd-example-modal-lg" id="viewMessage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Message View</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <div class="table-responsive">
          <table class="table table-bordered admin-table">
            <tbody>
              <tr>
                <th class="w180">To:</th>
                <td>Customers</td>
              </tr>
              <tr>
                <th class="w180">Subject:</th>
                <td>Test</td>
              </tr>
              <tr>
                <th class="w180">Date:</th>
                <td>2017-05-25</td>
              </tr>
              <tr>
                <th class="w180">Message:</th>
                <td>Test</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Edit Settings -->
<div class="modal fade" id="editSetting" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Settings</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <div class="table-responsive">
          <table class="table table-bordered admin-table">
            <tbody>
              <tr>
                <th>Setting Title:</th>
                <td>Facebook</td>
              </tr>
            </tbody>
          </table>
          <form>
            <div class="form-group">
              <label>Key Value</label>
              <input type="text" name="value" class="form-control">
            </div>
            <div class="form-group mb-0">
             <button type="button" class="btn btn-sm btn-primary">Update</button>
            </div>
            </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Add Blog -->
<div class="modal fade" id="addBlog" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Blog</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name="">                    
          <div class="form-group">
          <label>Image</label>
          <input type="file" class="form-control" name="image">
          </div>
          <div class="form-group">
          <label>Title</label>
          <input type="text" class="form-control" name="title">
          </div>
          <div class="form-group">
          <label>Description</label>                       
          <textarea class="form-control" name="description" rows="3" placeholder=""></textarea>
          </div>
           <div class="form-group">                       
              <label>Status</label>
              <select class="selectpicker form-control" title="Status">
                  <option value="Enabled">Enabled</option>
                  <option value="Disabled">Disabled</option>                                            
              </select>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Save</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Edit Blog -->
<div class="modal fade" id="viewBlog" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Blog</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <form name="">                    
          <div class="form-group">
          <label>Image</label>
          <input type="file" class="form-control" name="image">
          </div>
          <div class="form-group">
          <label>Title</label>
          <input type="text" class="form-control" name="title">
          </div>
          <div class="form-group">
          <label>Description</label>                       
          <textarea class="form-control" name="description" rows="3" placeholder=""></textarea>
          </div>
           <div class="form-group">                       
              <label>Status</label>
              <select class="selectpicker form-control" title="Status">
                  <option value="Enabled">Enabled</option>
                  <option value="Disabled">Disabled</option>                                            
              </select>
          </div>
          <div class="form-group mb-0">
            <button type="button" class="btn btn-sm btn-primary">Save</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- View Enquiries-->
<div class="modal fade bd-example-modal-lg" id="viewEnquiries" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">View Message</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body modalboot-select-class">
        <div class="table-responsive">
          <table class="table table-bordered admin-table">
            <tbody>
              <tr>
                <th class="w180">Name:</th>
                <td>Customers</td>
              </tr>
              <tr>
                <th class="w180">Email Address:</th>
                <td>test@codiant.com</td>
              </tr>
              <tr>
                <th class="w180">Message:</th>
                <td>Test..</td>
              </tr>
              <tr>
                <th class="w180">Received Date:</th>
                <td>2017-05-25</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>