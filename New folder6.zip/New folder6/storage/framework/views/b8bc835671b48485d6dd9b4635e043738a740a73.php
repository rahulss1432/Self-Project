<footer class="main-footer">
    <div class="container">
        <div class="footer-wrap">
            <div class="row">
                <div class="col-md-12 col-lg-4">
                    <img src="<?php echo e(url('public/images/footer-logo.png')); ?>" alt="logo">
                    <p class="about-detail">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's </p>
                </div>

                <div class="col-sm-3 col-md-3 col-lg-2">
                    <ul class="list-unstyled">
                        <li><a href="javascript:void(0);">Purchase book</a></li>
                        <li><a href="javascript:void(0);">Podcast</a></li>
                        <li><a href="javascript:void(0);">Blog</a></li>
                        <li><a href="javascript:void(0);">Daniel Zeman</a></li>
                        <li><a href="signup.php">Sign up</a></li>
                    </ul>
                </div>

                <div class="col-sm-5 col-md-6 col-lg-4">
                    <ul class="list-unstyled">
                        <li><strong>Address : </strong> 8037 Homewood Drive Lake Worth, FL 33460 </li>
                        <li><strong>Phone : </strong><a href="tel:+1 123456798">+1 123456798</a></li>
                        <li><strong>Email :</strong><a href="mailto: info@agingmmb.com"> info@agingmmb.com</a></li>
                        <li><a href="javascript:void(0);"></a></li>
                        <li><a href="javascript:void(0);"></a></li>
                    </ul>
                </div>

                <div class="col-sm-4 col-md-3 col-lg-2">
                    <ul class="list-unstyled">
                        <li><a href="javascript:void(0);"><i class="fa fa-facebook"></i> Facebook</a></li>
                        <li><a href="javascript:void(0);"><i class="fa fa-twitter"></i> Twitter</a></li>
                        <li><a href="javascript:void(0);"><i class="fa fa-google"></i>  Google</a></li>
                        <li><a href="javascript:void(0);"></a></li>
                        <li><a href="javascript:void(0);"></a></li>
                    </ul>
                </div>
            </div>
        </div>


        <!-- xxxxxx -->


        <div class="bottom-footer text-center">
            <p class="mb-0">&copy; 2018 copyright Aging MMB // All rights reserved</p>
        </div>
    </div>
</footer>

<script src="<?php echo e(url('public/js/popper.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('public/js/bootstrap.min.js')); ?>" type="text/javascript"></script>

<script type="text/javascript">
    
    //ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });

    // on scroll fix nav
    $(window).bind('scroll', function () {
        if ($(window).scrollTop() > 60) {
            $('.topheader').addClass('fixed');
        } else {
            $('.topheader').removeClass('fixed');
        }
    });

    // focused class
    $('.form-control').on('focus blur', function (e) {
        $(this).parents('.form-group').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
    }).trigger('blur');


     // validation
      (function() {
          'use strict';
          window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
              form.addEventListener('submit', function(event) {
                if (form.checkValidity() === false) {
                  event.preventDefault();
                  event.stopPropagation();
                }
                form.classList.add('was-validated');
                $('.fa-spin').css('display', 'inline-block');
                setTimeout(function () {
                    $('.fa-spin').css('display', 'none');
                }, 2000);
              }, false);
            });
          }, false);
        })();



    // profile menu open / close

    function openMenu(){
        $('.profile-wrapper').addClass('inner-menu-active');
    }

    function closeMenu(){
        $('.profile-wrapper , .navbar-toggler').removeClass('inner-menu-active');
    }



    // local storage

    $(document).ready(function () {
        var getLogin = localStorage.getItem('loginSession');
        if (getLogin == 'loggedin') {
            $("body").addClass("userlogin");
        } else {
            $("body").removeClass("userlogin");
        }
    });
    function validateForm() {
        var x = document.forms["loginForm"]["email"].value;
        var y = document.forms["loginForm"]["password"].value;
        if (x == "" || y == "") {
            return false;
        } else {
            localStorage.setItem('loginSession', 'loggedin');
        }
    }
    function logout() {
        localStorage.removeItem('loginSession');
        $("body").removeClass("userlogin");
    }
    
// function getbloghref(e){
//     if(window.location.pathname == '/agingmbb-html/signup.php'){
//         window.location.pathname = '/agingmbb-html/index.php' + '#' + 'blog';
//              //e.target.hash = "index.php#blog"
//         }
// }


    // if(window.location.pathname == '/agingmbb-html/signup.php'){
    //      window.location.hash = '#blog'
                    
    //         }
    //         else{
    //             window.location.hash = '#blog'
    //         }
</script>