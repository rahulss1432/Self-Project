<?php $__env->startSection('title', 'Blog Details'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray"  onload="hide_preloader();">
    <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="main-content manage_post_view common-grid-list" id="mainContent">
        <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--<link  href="<?php echo e(url('public/assets/css/jquery.mCustomScrollbar.css')); ?>" rel="stylesheet" type="text/css">-->
        <div class="page-content" id="pageContent">
            <div class="card custom_card" id="card_height">
                <div class="card-header">
                    <h4 class="page-title float-left">Blogs Detail</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item">
                            <a id="back-loader" href="<?php echo e(url('admin/blog')); ?>" class="nav-link" onclick="backloader()" title="Back"><i class="fa fa-long-arrow-left"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="bg-white box-shadow manage_post">
                    <div class="post_comment">
                        <div class="d-sm-flex">
                            <div class="">
                                <h2><?php echo e($viewBlogs->title); ?></h2>
                            </div>
                            <div class="ml-sm-auto right-side">
                                <p class="date_time text-sm-right mb-0">
                                    <?php 
                                    $datetime = App\Common\Utility::converToTz($viewBlogs->created_at);
                                    echo $datetime->format('d-m-Y h:i A')
                                     ?>
                                </p>
                                <ul class="list-inline mb-0 text-sm-right">
                                    <li class="list-inline-item"> 
                                        <a href="javascript:void(0);" onclick="openModalone()">
                                            <i class="fa fa fa-heart"></i>
                                            <?php echo e(\App\Models\Blog::likeCount($viewBlogs->id)); ?>

                                        </a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="#commentScroll" class="commentScroll">
                                            <i class="fa fa-comments"></i>
                                            <?php echo e(\App\Models\Blog::commentCount($viewBlogs->id)); ?>

                                        </a>
                                    </li>
                                    <li class="list-inline-item">
                                        <div class="share-button">
                                            <input class="toggle-input" id="toggle-input01_<?php echo $viewBlogs->id ?>" type="checkbox" name="share" />
                                            <label for="toggle-input01_<?php echo $viewBlogs->id ?>" class="toggle"></label>
                                            <ul class="network-list">
                                                <li class="twitter">
                                                    <a href="javascript:void(0);" class='share-button-twitter'>Share on Twitter</a>
                                                </li>
                                                <li class="facebook">
                                                    <a href="javascript:void(0);" class='share-button-facebook'>Share on Facebook</a>
                                                </li>
                                                <li class="googleplus">
                                                    <a href="javascript:void(0);" class='share-button-google'>Share on Google+</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="post_img_section mt-3" style="background-image: url(<?php echo e(\App\Common\Utility::checkBlogImage($viewBlogs->image)); ?>);">
                    </div>
                    <p class="description mt-3"><?php echo $viewBlogs->description; ?></p>
                    <div class="post_comment_listing" id="commentScroll">
                        <h2 class="heading">Comments</h2>
                        <?php if(count($blogComments) >0): ?>
                        <?php $__currentLoopData = $blogComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="comment_list">
                            <div class="d-sm-flex">
                                <div class="d-flex align-items-center">
                                    <div class="img-wrap">
                                        <img src="<?php echo e(\App\Common\Utility::checkProfileImage($data->user_profile)); ?>" class="img-fluid rounded-circle" alt="Profile">
                                    </div>
                                    <h3 class="mb-0"><?php echo e($data->user_name); ?></h3>
                                </div>
                                <div class="ml-auto text-right right-side">
                                    <div class="date_time">
                                        <span>
                                            <?php 
                                            $datetime = App\Common\Utility::converToTz($data->created_at);
                                            echo $datetime->format('d-m-Y h:i A')
                                             ?>
                                        </span>
                                        <a class="delete_comment" href="javascript:void(0);" onclick="deleteComment('<?php echo e($data->id); ?>')" data-toggle="tooltip" data-placement="top" title="Delete Comment"><i class="fa fa-close"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="description">
                                <p><?php echo e($data->comment); ?></p>
                                <div class="text-right">
                                    <a href="javascript:void(0);" class="btn btn-primary rounded-0" onclick="addReply('<?php echo e($data->id); ?>')">Reply</a>
                                </div>
                            </div>
                            <div id="reply_<?php echo e($data->id); ?>" class="add-reply pl-sm-5 mt-3 mt-sm-5" style="display: none">
                                <form id="addCommentForm" autocomplete="off" method="POST" action="<?php echo e(url('admin/add-comment')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="blogId" value="<?php echo e($viewBlogs->id); ?>">
                                    <input type="hidden" name="commentId" value="<?php echo e($data->id); ?>">
                                    <div class="form-group mb-2">
                                        <textarea class="form-control" name="comment" placeholder="Reply"></textarea>
                                    </div>
                                    <div class="form-group text-right">
                                        <button id="save-loader" type="submit" class="btn btn-primary rounded-0 btn-sm">Post</button>
                                    </div>
                                </form>
                            </div>
                            <?php
                            $blogReply = \App\Models\Blog::BlogCommentDetailByReply($data->id, $viewBlogs->id);
                            ?>
                            <?php if(count($blogReply) > 0 ): ?>
                            <?php $__currentLoopData = $blogReply; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <hr>
                            <div class="view-reply pl-sm-5">
                                <div class="comment_list">
                                    <div class="d-sm-flex">
                                        <div class="d-flex align-items-center">
                                            <div class="img-wrap">
                                                <img src="<?php echo e(\App\Common\Utility::checkProfileImage($data1->user_profile)); ?>" class="img-fluid rounded-circle" alt="Profile">
                                            </div>
                                            <h3 class="mb-0"><?php echo e($data1->user_name); ?></h3>
                                        </div>
                                        <div class="ml-auto text-right">
                                            <div class="date_time">
                                                <span>
                                                    <?php 
                                                    $datetime = App\Common\Utility::converToTz($data1->created_at);
                                                    echo $datetime->format('d-m-Y h:i A')
                                                     ?>
                                                </span>
                                                <a class="delete_comment" href="javascript:void(0);" onclick="deleteComment('<?php echo e($data1->id); ?>')" data-toggle="tooltip" data-placement="top" title="Delete Comment"><i class="fa fa-close"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="description mb-0">
                                        <p class="mb-0"><?php echo e($data1->comment); ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="alert alert-danger"><center>No Comments available.</center></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <div class="modal fade modal-center users_like" id="postview" data-backdrop="static" data-keyboard="false" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="users_like" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" id="commentList">
                <div class="modal-header">  
                    <h5 class="modal-title" id="exampleModalLabel">Users Likes (<?php echo e($likesCount); ?>)</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body mt-0">
                    <ul class="list-unstyled mb-0 black-scroll mCustomScrollbar user_like_scroll" data-mcs-theme="dark-3">
                        <?php if(count($likes)>0): ?>
                        <?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="imgdiv">
                                <img src="<?php echo e($like->user_profile); ?>" class="rounded-circle" alt="user">
                            </div>
                            <div class="caption">
                                <h4 class="text-capitalize"><?php echo e($like->user_name); ?></h4>
                                <p><?php echo e($like->comment); ?></p>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="alert alert-danger"><center>No like found.</center></div>
                        <?php endif; ?>            
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(url('public/assets/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/js/jssocials.js')); ?>"></script>
    <script type="text/javascript">
                                                                                    function deleteComment(id){
                                                                                    bootbox.confirm('Are you sure do you want to delete this comment?', function (result) {
                                                                                    if (result) {
                                                                                    $.ajax({
                                                                                    type: "GET",
                                                                                            url: "<?php echo e(url('admin/delete-comment')); ?>/" + id,
                                                                                            success: function (response) {
                                                                                            if (response)
                                                                                            {
                                                                                            toastr.remove();
                                                                                                    toastr.options.closeButton = true;
                                                                                                    toastr.success('Comment deleted successfully', 'Success', {timeOut: 2000});
                                                                                                    location.reload();
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                            toastr.remove();
                                                                                                    toastr.options.closeButton = true;
                                                                                                    toastr.error('Something went wrong', 'Error', {timeOut: 2000});
                                                                                            }
                                                                                            }
                                                                                    });
                                                                                    }
                                                                                    });
                                                                                    }

                                                                            $(document).ready(function () {
                                                                            $(".share-button-twitter").jsSocials({
                                                                            url: "<?php echo e(url(('http://copmerit.codiant.com/admin/blog-view'))); ?>/" + '<?php echo $viewBlogs->id ?>',
                                                                                    text: '<?= str_replace("'", "", $viewBlogs->title); ?>',
                                                                                    showLabel: false,
                                                                                    showCount: false,
                                                                                    shareIn: "popup",
                                                                                    shares: ["twitter"]
                                                                            });
                                                                                    $(".share-button-facebook").jsSocials({
                                                                            url: "<?php echo e(url(('http://copmerit.codiant.com/admin/blog-view'))); ?>/" + '<?php echo $viewBlogs->id ?>',
                                                                                    text: '<?= str_replace("'", "", $viewBlogs->title); ?>',
                                                                                    showLabel: false,
                                                                                    showCount: false,
                                                                                    shareIn: "popup",
                                                                                    shares: ["facebook"]
                                                                            });
                                                                                    $(".share-button-google").jsSocials({
                                                                            url: "<?php echo e(url(('http://copmerit.codiant.com/admin/blog-view'))); ?>/" + '<?php echo $viewBlogs->id ?>',
                                                                                    text: '<?= str_replace("'", "", $viewBlogs->title); ?>',
                                                                                    showLabel: false,
                                                                                    showCount: false,
                                                                                    shareIn: "popup",
                                                                                    shares: ["googleplus"]
                                                                            });
                                                                            });
                                                                                    function openModalone() {
                                                                                    $("#postview").modal('show');
                                                                                            var custom_margin = 150;
                                                                                            if ($(window).width() <= 767){var custom_margin = 74; }
                                                                                    if ($(window).width() <= 480){var custom_margin = 90; }
                                                                                    $(window).resize(function () {
                                                                                    var chk_account_height = $('.modal-header').outerHeight(true);
                                                                                            var window_height = $(window).height();
                                                                                            $(".user_like_scroll").css('max-height', window_height - chk_account_height - custom_margin);
                                                                                    }).resize();
                                                                                    }

                                                                            $(".commentScroll").on("click", function(e) {
                                                                            e.preventDefault();
                                                                                    $("body, html").animate({
                                                                            scrollTop: $($(this).attr('href')).offset().top
                                                                            }, 600);
                                                                            });
                                                                                    function backloader()
                                                                                    {
                                                                                    $("#back-loader").attr("disabled", true);
                                                                                            $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
                                                                                    }
                                                                            ;
                                                                                    function addReply(id) {
                                                                                    $('#reply_' + id).show();
                                                                                    }

                                                                            $('.form-group .form-control').focus(function ()
                                                                            {
                                                                            $(this).parent().addClass('isfocused');
                                                                            }).blur(function ()
                                                                            {
                                                                            $(this).parent().removeClass('isfocused');
                                                                            });
                                                                                    window.addEventListener('beforeunload', function (event)
                                                                                    {
                                                                                    $("#save-loader").attr("disabled", true);
                                                                                            $("#save-loader").html('POST <i class="fa fa-spinner fa-spin"></i>');
                                                                                    });
                                                                                    $(function () {
                                                                                    $('[data-toggle="tooltip"]').tooltip()
                                                                                    })

    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>