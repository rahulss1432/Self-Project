<?php
  $contact = \App\Models\Setting::getContactUs();
?>
<footer class="footer" >
  <div class="topfooter" id="contactus">
    <div class="app_img d-none d-xl-block">
      <img src="<?php echo e(url('public/assets/images/footer_img.png')); ?>" alt="appimg">
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="foot_info">
            <h3><?php echo e($contact->key_value); ?></h3>
            <div class="app_btn">
              <a href="javascript:void(0);">
                <img src="<?php echo e(url('public/assets/images/android_btn.png')); ?>" alt="button">
              </a>
              <a href="javascript:void(0);">
                <img src="<?php echo e(url('public/assets/images/ios_btn.png')); ?>" alt="button">
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="contact">
            <h4>Contact Us</h4>
            <form id="contact-frm" action="<?php echo e(url('/contact')); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <input type="text" class="form-control"  name="name" placeholder="Name">
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email" name="email">
                  </div>
                </div>
              </div>
              <div class="form-group">
                <textarea class="form-control" cols="30" rows="1" placeholder="Message" name="message"></textarea>
              </div>
              <div class="text-right">
                <button type="submit" class="btn btn-light">Submit</button>
              </div>
            </form>
            <?php echo JsValidator::formRequest('App\Http\Requests\ContactRequest','#contact-frm'); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright">
    <div class="container">
      <ul class=" list-inline">
        <li class="list-inline-item">Copyright © 2018 Cop Merit. All rights reserved.</li>		
        <li class="list-inline-item"><a href="<?php echo e(url('/terms-and-condition')); ?>">Terms and Conditions</a></li>
        <li class="list-inline-item"><a href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy</a></li>			
      </ul>
    </div>
  </div>
</footer>
<script src="<?php echo e(url('public/assets/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/js/jstz.min.js')); ?>"></script>
<script>
    function setUserTimezone(){
      var tz = jstz.determine();
      var timezone = tz.name();
      $.ajax({
        type: "POST",
        url: "<?php echo e(url('set-user-timezone')); ?>",
        async: true,
        data: {timezone:timezone},
        success: function (response)
        {

        }
      });
    }

    $(document).ready(function(){
      setUserTimezone();
    });
 </script>