<?php if(count($subscription) > 0): ?>
  <table class="table admin-table" id="payment_list">
    <thead>
      <tr>
        <th>Full Name</th>
        <th>User type</th>
        <th>Email</th>
        <th>Subscription Plans</th>
        <th>Start Date</th>
        <th>End Date</th>
        <th>Status</th>
        <th>Amount Paid</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $subscription; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e('subscription'.$data->id); ?>">
          <td><?php echo e(ucfirst($data->first_name)); ?> <?php echo e(ucfirst($data->last_name)); ?></td>
          <td class="text-capitalize">
            <span style="display:none;"><?php echo e($data->id); ?></span><?php echo e(ucfirst($data->user_type)); ?>

          </td>
          <td><?php echo e(ucfirst($data->email)); ?></td>
          <td class="text-capitalize"><?php echo e($data->name); ?></td>
          <td class="text-capitalize"><?php echo e($data->start_date); ?></td>
          <?php if($data->plans_status == 'active'): ?>
            <td class="text-capitalize">---</td>
            <?php else: ?>
              <td class="text-capitalize"><?php echo e($data->start_date); ?></td>
          <?php endif; ?>
          <?php if($data->plans_status == 'active'): ?>
            <td class="text-capitalize color-green"><?php echo e($data->plans_status); ?></td>
            <?php else: ?>
              <td class="text-capitalize color-red"><?php echo e($data->plans_status); ?></td>
          <?php endif; ?>
          <td class="text-capitalize">$ <?php echo e($data->price); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php else: ?>
    <div class="alert alert-danger"><center>No subscription available.</center></div>
<?php endif; ?>