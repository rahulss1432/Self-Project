<!-- <?php echo $__env->make('layouts.include.inner-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
<!DOCTYPE html>
<html>
    <head>
        <title>ERROR</title>
            <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(url('public/assets/images/favi-icon/apple-touch-icon.png')); ?>">
            <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('public/assets/images/favi-icon/favicon-32x32.png')); ?>">
            <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('public/assets/images/favi-icon/favicon-16x16.png')); ?>">
            <link rel="manifest" href="<?php echo e(url('public/assets/images/favi-icon/site.webmanifest')); ?>">
            <link rel="mask-icon" href="<?php echo e(url('public/assets/images/favi-icon/safari-pinned-tab.svg')); ?>" color="#5bbad5">
            <link  href="<?php echo e(url('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
            <link href="<?php echo e(url('public/assets/css/custom.min.css')); ?>" rel="stylesheet" type="text/css">
            <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    </head>
    <body class="error_page">
        <main class="main_content ">
            <section class="error_section">
                <div class="error_content " align="center">
        			<h2>404</h2>
        			<p class="text-center">THE LINK YOU FOLLOWED IS PROBABLY BROKEN OR THE <br clear="hidden-xs">PAGE HAS BEEN REMOVED.</p>
        			<a class="btn btn-primary" href="<?php echo e(url('/')); ?>">RETURN TO THE HOME PAGE</a>

    			</div>
            </section>
        </main>
    </body>
</html>
<!-- <?php echo $__env->make('layouts.include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->