<div class="modal-header">  
    <h5 class="modal-title" id="exampleModalLabel">Users Likes (<?php echo e($count); ?>)</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body mt-0">
    <ul class="list-unstyled mb-0 black-scroll mCustomScrollbar user_like_scroll">
        <?php
        if (!empty($comments)) {
            foreach ($comments as $comment) {
                ?>
                <li>
                    <div class="imgdiv">
                        <img src="<?php echo e($comment->user_profile); ?>" class="rounded-circle" alt="user">
                    </div>
                    <div class="caption">
                        <h4 class="text-capitalize"><?php echo e($comment->user_name); ?></h4>
                        <p><?php echo e($comment->comment); ?></p>
                    </div>
                </li>
                <?php
            }
        } else {
            ?>
            <div class="alert alert-danger"><center>No like found.</center></div>
                <?php } ?>
    </ul>
</div>



