<?php $__env->startSection('title', 'Subadmin'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray" onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content common-grid-list" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent">
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Sub admin</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
            <a href="<?php echo e(url('admin/add-subadmin')); ?>" id="add-loader" onclick="addloader()" class="nav-link"><i class="fa fa-plus"></i></a>
            </li>
            <li class="list-inline-item">
            <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="fa fa-search"></i></a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <div class="filter_section collapse show" id="searchFilter">
            <form id="search_form" action="javascript:load_subadmin_list()" method="post" autocomplete="off">
              <?php echo e(csrf_field()); ?>

              <div class="row"> 
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                  <div class="form-group">
                    <label class="control-label">Name</label>
                    <input type="text" id="user_name" name="name" class="form-control form-control-lg"/>
                  </div>
                </div> 
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                  <div class="form-group">
                    <label class="control-label">Email</label>
                    <input type="text" id="user_email" name="email" class="form-control form-control-lg"/>
                  </div>
                </div> 
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                  <div class="form-group">
                    <label class="control-label">Mobile</label>
                    <input type="text" id="user_phone" name="phone" class="form-control form-control-lg"/>
                  </div>
                </div> 
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                  <div class="form-group d-inline-block mr-2">
                    <label class="btn-block">&nbsp;</label>
                    <button class="btn btn-primary" type="submit">Filter</button>
                  </div>
                  <div class="form-group d-inline-block mr-2">
                    <label class="btn-block">&nbsp;</label>
                    <input type="reset" id="reset-btn" class="btn btn-primary" value="reset">
                  </div>
                </div> 
              </div>
            </form>
          </div>
          <div class="table-responsive" id="subadmin_list">
            
          </div>
        </div>
      </div>
    </div>
  </main>

  <script type="text/javascript">

    $(document).ready(function ()
    {
      load_subadmin_list();
    });

    $( "#reset-btn" ).click(function() 
    {
      $('#user_name').val('').change();
      $('#user_email').val('').change();
      $('#user_phone').val('').change();
      load_subadmin_list();
    });

    function load_subadmin_list()
    {
      $("#subadmin_list").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter=$("#search_form").serializeArray();
          search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
      $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/load-subadmin-list')); ?>",
                data: search_filter,
                success: function (response) 
                {
                  $("#subadmin_list").html(response.html);
                  $('#data_table').DataTable({
                                                searching: false,
                                                "order": [],
                                                "columnDefs": [{
                                                                  "targets"  : [4,5],
                                                                  "orderable": false,
                                                              }],
                                            });
                }
            });
    }

    function viewfunction(id)
    {
      $("#view-loader"+id).attr("disabled", true);
      $("#view-loader"+id).html('<i class="fa fa-spinner fa-spin"></i>');
    }

    function addloader()
    {
      $("#add-loader").attr("disabled", true);
      $("#add-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    }

    function editfunction(id)
    {
      $("#edit-loader"+id).attr("disabled", true);
      $("#edit-loader"+id).html('<i class="fa fa-spinner fa-spin"></i>');
    }

    function activeInacive(id , status)
    {
      if(status == 'active')
      {
        var msg = "Are you sure you want to deactivate this subadmin?";
      }
      else  if(status == 'inactive')
      {
        var msg = "Are you sure you want to activate this subadmin?";
      }
      bootbox.confirm(msg, function (result)
      {
        if (result)
        {
          $.ajax({
                    type: "POST",
                    url: "<?php echo e(url('admin/active-inactive')); ?>/" + id,
                    data: {'_token':'<?php echo e(csrf_token()); ?>'},
                    success: function (response)
                    {
                      if (response)
                      {
                        toastr.remove();
                        toastr.options.closeButton = true;
                        load_subadmin_list();
                        toastr.success('Status updated successfully', 'Success', {timeOut: 2000});
                      }
                      else
                      {
                        toastr.remove();
                        toastr.options.closeButton = true;
                        toastr.error('Something went wrong', 'Error', {timeOut: 2000});
                      }
                    }
                  });
        }
        else
        {
          if(status == 'active')
          {
            $('#enable_a_'+id).attr('checked',true);
          }
          else
          {
            $('#enable_a_'+id).attr('checked',false);
          }
        }
      });
    }

    function deletefunction(id)
    {
      bootbox.confirm('Are you sure do you want to delete this subadmin?', function (result)
      { 
        if (result)
        {
          $.ajax({
                  type: "GET",
                  url: "<?php echo e(url('admin/delete-subadmin')); ?>/" + id,
                  success: function(response)
                  {
                    if (response)
                    {
                      toastr.remove();
                      toastr.options.closeButton = true;
                      toastr.success('Subadmin deleted successfully', 'Success', {timeOut: 1000});
                      document.getElementById('subadmin'+id).style.display = 'none';
                    }
                    else
                    {
                      toastr.remove();
                      toastr.options.closeButton = true;
                      toastr.error('Something went wrong', 'Error', {timeOut: 1000});
                    }
                  }
                });
        }
      });
    }
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>