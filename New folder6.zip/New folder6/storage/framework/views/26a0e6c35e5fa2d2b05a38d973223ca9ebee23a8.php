<?php if(count($profileVideoViewData)>0): ?>
<div class="row">
    <?php $__currentLoopData = $profileVideoViewData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-4 col-sm-6">
        <div class="job_box">
            <div class="job_header">
                <div class="job_img d-inline-flex align-items-center justify-content-center">
                    <img src="<?php echo e(\App\Helpers\Utility::checkCompanyLogo($data->getUser->company_logo)); ?>" alt="icon" class="img-fluid">
                </div>
            </div>
            <div class="job_body">
                <h3><?php echo e($data->getUser->company_name); ?></h3>
            </div>
            <div class="job_footer">
                <a href="<?php echo e(url('/company-profile/'.$data->send_by.'/'.\App\Helpers\Utility::makeslug($data->getUser->company_name))); ?>" class="font-md">View Company Profile</a>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    <?php if($page != 'dashboard'): ?>
        <div id="profileVideoViews<?php echo e($profileVideoViewData->currentPage()); ?>"></div>
    <?php else: ?>
        <?php if($activity_type == 'video_view'): ?>
            <a href="<?php echo e(url('/user/video-views')); ?>"><img src="<?php echo e(url('public/images/load_more.svg')); ?>" alt="icon">Load More</a>
        <?php else: ?>
            <a href="<?php echo e(url('/user/profile-views')); ?>"><img src="<?php echo e(url('public/images/load_more.svg')); ?>" alt="icon">Load More</a>
        <?php endif; ?>
    <?php endif; ?>
<?php else: ?>
<div class="row">
    <div class="col-xl-12">
        <?php if($activity_type == 'view_video' ): ?>
            <?php echo e(\App\Helpers\Utility::emptyListMessage('video views')); ?>

        <?php elseif($activity_type == 'view_profile'): ?>
            <?php echo e(\App\Helpers\Utility::emptyListMessage('profile views')); ?>

        <?php endif; ?>
    </div>
</div>
<?php endif; ?>
<?php if($page != 'dashboard'): ?>
<?php echo e($profileVideoViewData->links('vendor.pagination.simple-default')); ?>

<script>
    $(document).ready(function () {
        $('#spinner').hide();
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var pageLink = $(this).attr('href');
            var activity_type = $('#activity_type').val();
            var token = '<?php echo e(csrf_token()); ?>';
            $('#spinner').show();
            $.ajax({
                type: 'POST',
                url: pageLink,
                data: {_token: token, activity_type: activity_type,is_pagination:'yes', page:''},
                async: false,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#profileVideoViews<?php echo e($profileVideoViewData->currentPage()); ?>").append(response).hide().fadeIn(1000);
                    $('#spinner').hide();
                }
            });
        });
    });
</script>
<?php endif; ?>

