<!-- Required meta tags -->

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

<!-- favicon -->
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url('public/admin/images/favicon/apple-touch-icon.png')); ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('public/admin/images/favicon/favicon-32x32.png')); ?>">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('public/admin/images/favicon/favicon-16x16.png')); ?>">
<link rel="manifest" href="/site.webmanifest">
<link rel="mask-icon" href="<?php echo e(url('public/admin/images/favicon/safari-pinned-tab.svg')); ?>" color="#5bbad5">
<meta name="msapplication-TileColor" content="#bee626">
<meta name="theme-color" content="#EF5350">
<meta name="mobile-web-app-capable" content="yes">

<!-- Bootstrap CSS -->

<link rel="stylesheet" href="<?php echo e(url('public/admin/css/bootstrap.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(url('public/admin/css/bootstrap-select.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(url('public/admin/css/jquery.mCustomScrollbar.min.css')); ?>"> 
<link rel="stylesheet" href="<?php echo e(url('public/admin/css/tempusdominus-bootstrap-4.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(url('public/admin/css/fontawesome-all.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(url('public/admin/css/flaticon.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(url('public/admin/css/iconmoon.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(url('public/admin/css/admin.min.css')); ?>" type="text/css">
