<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> | Copmerit</title>
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('public/assets/images/favi-icon/favicon-32x32.png')); ?>">
    <link href="<?php echo e(url('public/assets/css/bootstrap-select.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('public/assets/css/jquery.mCustomScrollbar.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('public/assets/css/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('public/assets/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('public/assets/css/daterangepicker.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('public/assets/css/custom.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('public/assets/css/admin.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('public/assets/css/toastr.min.css')); ?>" rel="stylesheet" type="text/css">
    <script src="<?php echo e(url('public/assets/js/tinymce/tinymce.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/assets/js/jquery.raty.min.js')); ?>"></script>
     <script src="<?php echo e(url('public/assets/js/jquery.form.js')); ?>"></script>
  </head>

  <div id="app">
    <div id="preloader">
      <div class="inner">
        <div class="spinner">
          <div class="rect1"></div>
          <div class="rect2"></div>
          <div class="rect3"></div>
          <div class="rect4"></div>
          <div class="rect5"></div>
        </div>
      </div>
    </div>
      <?php echo $__env->yieldContent('content'); ?>
  </div>
  <?php echo $__env->make('admin.layouts.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php if(session()->has('success')): ?>

    <script type="text/javascript">

      $(document).ready(function ()
      {
        toastr.remove();
        toastr.options.closeButton = true;
        toastr.success("<?php echo session('success'); ?>", 'Success', {timeOut: 3000});
      });

    </script>
  <?php endif; ?>
    <?php if(session()->has('error')): ?>
      <script type="text/javascript">

        $(document).ready(function ()
        {
          toastr.remove();
          toastr.options.closeButton = true;
          toastr.error("<?php echo session('error'); ?>", 'Error', {timeOut: 3000});
        });

      </script>
    <?php endif; ?>
    
    <script src="<?php echo e(url('public/assets/js/bootbox.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/assets/js/toastr.js')); ?>"></script>
    <script src="<?php echo e(url('public/assets/js/jsvalidation.min.js')); ?>"></script>
    
    <script type="text/javascript">

      $('.login-field .input-group .form-control').focus(function ()
      {
        $(this).parent().addClass('isfocused');
      }).blur(function ()
      {
        $(this).parent().removeClass('isfocused');
      });
      var rotate = 1;

      function hide_preloader()
      {
        rotate = 0;
        $("#preloader").fadeOut('slow');
      }

      $(document).ready(function()
      {
        $('.form-control').on('keyup',function()
        {
          if($(this).val()!='')
          {
            $(this).addClass('i-focused');
          }
          else 
          {
            $(this).removeClass('i-focused');
          }
        });
      });
    </script>

  </body>
</html>
