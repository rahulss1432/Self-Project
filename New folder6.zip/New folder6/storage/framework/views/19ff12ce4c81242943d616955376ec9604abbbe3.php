<!--Side-nav-->
<aside class="side_menu" id="nav-aside">
    <ul class="list-unstyled menu font-md mb-0" data-mcs-theme="light">
        <li class="<?php echo e(( \Request::route()->getName() == 'user.dashboard') ? 'active' : ''); ?>">
            <a class="dasboard" href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
        </li>
       <li class="<?php echo e(( \Request::route()->getName() == 'user.applied-jobs') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('/user/applied-jobs')); ?>">My Application</a>
        </li>
        <li class="<?php echo e(( \Request::route()->getName() == 'user.invitation-received') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('/user/invitation-received')); ?>">Invitation</a>
        </li>
        <li class="<?php echo e(( \Request::route()->getName() == 'user.video-views') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('/user/video-views')); ?>">Video Views</a>
        </li>
        <li class="<?php echo e(( \Request::route()->getName() == 'user.profile-views') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('/user/profile-views')); ?>">Profile Views</a>
        </li>
        
        <li class="<?php echo e(( \Request::route()->getName() == 'user.job-listing') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('/job-listing')); ?>">Job Listing</a>
        </li>
        <li class="<?php echo e(( \Request::route()->getName() == 'user.my-plan') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('/user/my-plan')); ?>">My Plan</a>
        </li>
        <li class="<?php echo e(( \Request::route()->getName() == 'user.payment-history') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('/user/payment-history')); ?>">Payment History</a>
        </li>
        <li>
            <a href="<?php echo e(url('/user/support')); ?>">Support</a>
        </li>
    </ul>
</aside>
