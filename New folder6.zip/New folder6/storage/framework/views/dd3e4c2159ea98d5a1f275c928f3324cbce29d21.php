<?php $__env->startSection('title', 'Police Department Directory'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray"  onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content common-grid-list" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent">
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Police Departments Directory</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a id="add-loader" onclick="addfunction()" href="<?php echo e(url('admin/police-department-add')); ?>" class="nav-link"><i class="fa fa-plus"></i></a>
            </li>
            <li class="list-inline-item">
              <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="fa fa-search"></i></a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <div class="filter_section collapse show" id="searchFilter">
            <form id="search_form" action="javascript:police_department_list();" method="post" autocomplete="off">
              <?php echo e(csrf_field()); ?>

              <div class="row"> 
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                  <div class="form-group">
                    <label class="control-label">State</label>
                    <select id="state_change" name="state" onchange="selectCity(this.value,''),$(this).valid()" class="form-control form-control-lg selectpicker">
                      <option value="">Select State</option>
                      <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  </div>
                </div> 
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                  <div class="form-group">
                    <label class="control-label">City</label>
                    <select name="city" id="city" onchange="$(this).valid()" class="form-control form-control-lg selectpicker">
                      <option value="">Select City</option>
                    </select>
                  </div>
                </div> 
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                  <div class="form-group">
                    <label class="control-label">Police Department</label>
                    <input id="department_name" type="text" name="police_department" class="form-control form-control-lg"/>
                  </div>
                </div> 
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                  <div class="form-group d-inline-block mr-2">
                    <label class="btn-block">&nbsp;</label>
                    <button class="btn btn-primary" type="submit">Filter</button>                         
                  </div>
                  <div class="form-group d-inline-block mr-2">
                    <label class="btn-block">&nbsp;</label>
                    <input id="reset-btn" type="reset" class="btn btn-primary" value="reset">
                  </div>
                </div> 
              </div>
            </form>
          </div>
          <div class="table-responsive" id="police_list">
            
          </div>
        </div>
      </div>
    </div>
  </main>

  <script type="text/javascript">

    $(document).ready(function ()
    {
      police_department_list();
    });


    $( "#reset-btn" ).click(function() 
    {
      $('#state_change').val('').change();
      $('#city').val('').change();
      $('#department_name').val('').change();
      police_department_list();
    });


    function viewfunction(id)
    {
      $("#view-loader"+id).attr("disabled", true);
      $("#view-loader"+id).html('<i class="fa fa-spinner fa-spin"></i>');
    };


    function addfunction()
    {
      $("#add-loader").attr("disabled", true);
      $("#add-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    };


    function editfunction(id)
    {
      $("#edit-loader"+id).attr("disabled", true);
      $("#edit-loader"+id).html('<i class="fa fa-spinner fa-spin"></i>');
    };


    function selectCity(id,city_id) 
    {
      if(id !='')
      {
        var token = '<?php echo e(csrf_token()); ?>';
        $.ajax({
                  url: "<?php echo e(url('admin/select-cities')); ?>",
                  data: {_token: token,id:id,city_id:city_id},
                  type: 'POST',
                  success: function (city)
                  {
                    $('#city').html(city.html);
                    $('#city').selectpicker('refresh');
                  },
                  error: function (city)
                  {
                    console.log('an error occurred');
                  }
              });
      }
      else
      {
        $('#city').html('<option value="">Select City</option>');
        $('#city').selectpicker('refresh');
      }
    }


    function police_department_list()
    {
      $("#police_list").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter=$("#search_form").serializeArray();
      search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
      $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/police-department-list')); ?>",
                data: search_filter,
                success: function (response)
                {
                  $("#police_list").html(response.html);
                  $('#data_table').DataTable({
                                                searching: false,
                                                "order": [],
                                                "columnDefs": [{"targets"  : [6],"orderable": false,}],
                                            });
                }
            });
    }


    function deletefunction(id)
    {
      bootbox.confirm('Are you sure do you want to delete this department?', function (result)
      { 
        if (result)
        {
          $.ajax({
                  type: "GET",
                  url: "<?php echo e(url('admin/delete-police')); ?>/" + id,
                  success: function(response)
                  {
                    if (response)
                    {
                      toastr.remove();
                      toastr.options.closeButton = true;
                      toastr.success('Police department deleted successfully', 'Success', {timeOut: 1000});
                      document.getElementById('police'+id).style.display = 'none';
                    }
                    else
                    {
                      toastr.remove();
                      toastr.options.closeButton = true;
                      toastr.error('Something went wrong', 'Error', {timeOut: 1000});
                    }
                  }
                });
        }
      });
    }

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>