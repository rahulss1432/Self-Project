<?php $__env->startSection('title', 'Payments'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray" onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content common-grid-list" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent">
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Payments</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="fa fa-search"></i></a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <div class="filter_section collapse show" id="searchFilter">
            <form id="search_form" action="javascript:load_payment_list();" method="post" autocomplete="off">
              <?php echo e(csrf_field()); ?>

              <div class="row">
                <div class="col-xl-2 col-lg-4 col-md-4 col-sm-6 col-">
                  <div class="form-group">
                    <label class="control-label">User Type</label>
                    <select id="user_type_change" name="user_type" class="form-control form-control-lg selectpicker">
                      <option value="">Select User Type</option>
                      <option value="citizen">Citizen</option>
                      <option value="lawyer">Lawyer</option>
                      <option value="bail bondsman">Bail Bondsman</option>
                    </select>
                  </div>
                </div> 
                <div class="col-xl-2 col-lg-4 col-md-4 col-sm-6 col-">
                  <div class="form-group">
                      <label class="control-label">Month</label>
                      <select id="month_change" name="month" class="form-control form-control-lg selectpicker">
                        <option value="">Select Month</option>>
                        <option value='-01-'>Janaury</option>
                        <option value='-02-'>February</option>
                        <option value='-03-'>March</option>
                        <option value='-04-'>April</option>
                        <option value='-05-'>May</option>
                        <option value='-06-'>June</option>
                        <option value='-07-'>July</option>
                        <option value='-08-'>August</option>
                        <option value='-09-'>September</option> 
                        <option value='-10-'>October</option>
                        <option value='-11-'>November</option>
                        <option value='-12-'>December</option>
                      </select>
                  </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-3 col-sm-6">
                  <div class="form-group">
                    <label class="control-label">Name</label>
                    <input id="user_name" type="text" name="user_name" class="form-control form-control-lg">
                  </div>
                </div> 
                <div class="col-xl-3 col-lg-4 col-md-3 col-sm-4 col-">
                  <div class="form-group">
                    <label class="control-label">Email</label>
                    <input id="user_email" type="text" name="user_email" class="form-control form-control-lg">
                  </div>
                </div> 
                <div class="col-xl-2 col-lg-2 col-md-2 col-sm-2 col-">
                  <div class="form-group d-inline-block mr-2">
                    <label class="btn-block">&nbsp;</label>
                    <button class="btn btn-primary" type="submit">Filter</button>
                  </div>
                  <div class="form-group d-inline-block mr-2">
                    <label class="btn-block">&nbsp;</label>
                    <input id="reset-btn" type="reset" class="btn btn-primary" value="reset">
                  </div>
                </div> 
              </div>
            </form>
          </div>
          <div class="table-responsive" id="payment_list">
                            
          </div>
        </div>
      </div>
    </div>
  </main>

  <script type="text/javascript">
            
    $( "#reset-btn" ).click(function() 
    {
      $('#user_type_change').val('').change();
      $('#subscription_plan').val('').change();
      $('#month_change').val('').change();
      $('#payment_status').val('').change();
      $('#user_name').val('').change();
      $('#user_email').val('').change();
      load_payment_list();
    });


    $(document).ready(function () 
    {
      load_payment_list();
    });


    function load_payment_list()
    {
      $("#payment_list").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter=$("#search_form").serializeArray();
      search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
      $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/load-payment-list')); ?>",
                data: search_filter,
                success: function (response)
                {
                    $("#payment_list").html(response.html);
                    $('#data_table').DataTable({
                                                  searching: false,
                                                  "order": [],
                                                  "columnDefs": [{
                                                                    "targets"  : [6],
                                                                    "orderable": false,
                                                                }],
                                              });
                }
            });
    }

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>