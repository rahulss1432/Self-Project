<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main class="main-content inner-pages signup-page">
    <div class="signup-wrap">
        <h2 class="text-uppercase font-bold theme-color">login</h2>
        <form id="user-login-frm" class="needs-validation" novalidate name="loginForm" method="POST" action="javascript:void(0);">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" name="email">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control"> 
            </div>
            <div class="d-flex justify-content-between align-items-center mt-5">
                <button type="submit" id="user-login-btn" class="btn btn-primary text-uppercase ripple-effect mt-0">Login</button>
                <a href="<?php echo e(url('/forgot-password')); ?>" class="forget-password">Forgot Password?</a>
            </div>
        </form>
        <div class="text-center">
            <p class="mb-0 info-text">Don't have an account?  <a href="<?php echo e(url('/register')); ?>"> Sign up</a></p>
        </div>
    </div>
</main>
<?php echo JsValidator::formRequest('App\Http\Requests\LoginRequest','#user-login-frm'); ?>

<script>
    $("#user-login-btn").on('click', (function (e) {
        var frm = $('#user-login-frm');
        var btn = $('#user-login-btn');
        if (frm.valid()) {
            btn.html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?> Login');
            btn.prop('disabled', true);
            $.ajax({
                url: "<?php echo e(url('/login')); ?>",
                type: "POST",
                data: frm.serialize(),
                success: function (data)
                {
                    btn.prop('disabled', false);
                    window.location.href='<?php echo e(url("/user/my-profile")); ?>';
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('LOGIN');
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>