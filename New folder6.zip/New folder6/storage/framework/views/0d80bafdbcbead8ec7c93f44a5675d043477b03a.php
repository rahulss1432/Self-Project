<?php $__env->startSection('title','Manage Blogs'); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content manage_user_page">
     <form id="frmFilter" action="javascript:void(0);">
         <?php echo e(csrf_field()); ?>

    <div class="content_wrapper">
        <div class="page_title">
            <h2 class="d-inline-block pr-3 mr-3 border-right">Manage Blogs</h2>
            <nav aria-label="breadcrumb" class="d-inline-block">
                <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item">Manage Blogs</li>
                </ol>
            </nav>
        </div>
        <!--  -->
        <div class="search_section justify-content-between">
            <div class="row">
                <div class="col-12 col-sm-6">
                    <ul class="list-inline mb-0">

                        <li class="list-inline-item">
                            <div class="input-group">
                                <input type="text" id="txtSearch" name="txtSearch" class="form-control" placeholder="Search by keyword ( Title )" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <button type="submit" class="input-group-text btn btn-dark rounded-0 ripple-effect" id="basic-addon2" onclick="loadBlogList()"> <i class="icon-search"></i> <span class="d-none d-md-block">Search</span></button>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-12 col-sm-6">
                    <ul class="filter_right list-inline text-right mb-0">
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="btn btn-white rounded-0 ripple-effect" onclick="filterOpen()"><i class="icon-filter-filled-tool-symbol"></i> Filter</a>
                        </li>
                        <li class="list-inline-item">
                            <a href="<?php echo e(url('/admin/add-blog')); ?>" class="btn btn-dark rounded-0 ripple-effect">Add Blog</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!--  -->
        <div class="filter_form bg-white" id="filterform">
            <div class="d-flex top_filter">
                <div class="filter_heading">
                    <h2>Filters</h2>
                </div>	
                <div class="ml-auto">
                    <div class="close_btn" id="filterclose" onclick="filterClose()">
                        <div class="x common rotate30 rotate45"></div>	
                        <div class="z common rotate150 rotate135"></div>
                    </div>
                </div>
            </div>
           
                <div class="comman_form">
                    <h4 class="form_heading">By status</h4>
                    <div class="form-group">
                        <label>Users status</label>
                        <select name="status" class="selectpicker select-custom form-control " data-size="3">
                            <option value="">Status</option> 
                            <option value="enabled">Active</option> 
                            <option value="disabled">Deactive</option> 
                        </select>
                    </div>
                </div>
                <div class="comman_form">
                    <h4 class="form_heading">By date range</h4>
                    <div class="form-group">
                        <label class="control-label">From date</label>
                        <div class="dateIcon">
                            <input type="text" name="from_date" id="from_date" class="form-control rounded-0  datetimepicker-input" data-target="#from_date"  data-toggle="datetimepicker" placeholder="Date" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">To date</label>
                        <div class="dateIcon">
                            <input type="text" name="to_date" id="to_date" class="form-control rounded-0  datetimepicker-input" data-target="#to_date"  data-toggle="datetimepicker" placeholder="Date"/>
                        </div>
                    </div>
                </div>
                <div class="form-group d-flex submit_btn mb-0">
                    <button type="button" onclick="resetFilter();" class="btn btn-light rounded-0 ripple-effect">Reset</button>
                    <div class="ml-auto">
                        <button onclick="loadBlogList()" type="submit" class="btn btn-dark rounded-0 ripple-effect"> Apply <i  style="display:none;" class="btn_loader"></i></button>
                    </div>

                </div>
           
        </div>
        <!--  -->
        <div class="bg-white box-shadow common_table">            
            <div id="blogList"></div> 
        </div>
    </div>
     </form>
</div>
<script>
    $(document).ready(function () {
        loadBlogList();
    });
   function loadBlogList() {
        $("#blogList").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('/admin/load-blog-list')); ?>",
            data: $("#frmFilter").serialize(),
            success: function (response)
            {
                $("#blogList").html(response);
            }
        });
    }
      $(function () {
        $('#from_date').datetimepicker({format: '<?php echo e(\App\Helpers\Utility::getDatePickerForamt()); ?>',maxDate:moment()});
        $('#to_date').datetimepicker({
            format: '<?php echo e(\App\Helpers\Utility::getDatePickerForamt()); ?>',
            useCurrent: false,
            maxDate:moment()
        });
        $("#from_date").on("change.datetimepicker", function (e) {
            $('#to_date').datetimepicker('minDate', e.date);
        });
        $("#to_date").on("change.datetimepicker", function (e) {
            $('#from_date').datetimepicker('maxDate', e.date);
        });
    });
    function resetFilter() {
        $('#frmFilter')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadBlogList();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>