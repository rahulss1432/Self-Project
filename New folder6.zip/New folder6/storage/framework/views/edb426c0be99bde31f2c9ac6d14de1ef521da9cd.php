<?php $__env->startSection('title','View Profile'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-wrapper dashboard-main-wrap view-profile-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">View Profile</li>
                </ol>
            </nav>
            <div class="row">
                <div class="col-lg-3 pr-md-0 left-section">
                    <div class="card">
                        <div class="card-body profile-box text-center">
                            <div class="text-right">
                                <a href="<?php echo e(url('/user/edit-profile')); ?>" class="edit-icon">
                                    <img src="<?php echo e(url('public/images/edit-icon.svg')); ?>" alt="icon">
                                </a>

                            </div>
                            <div class="user-img">
                                <img src="<?php echo e(\App\Helpers\Utility::checkProfileImage($userDetails->profile_image)); ?>" alt="user-img" class="img-fluid rounded-circle">
                            </div>
                            <h2 class="user-name font-md mb-0"><?php echo e($userDetails->first_name); ?> <?php echo e($userDetails->last_name); ?></h2>
                            <span class="d-block mb-2 color-gray"><?php echo e($userDetails->user_type); ?></span>
                            <?php $expIsWorking = \App\Models\UserExperience::getIsWorking($userDetails->id); ?>
                                <?php if(!empty($expIsWorking)): ?>
                                    <p class="mb-1"><?php echo e($expIsWorking->title); ?>, <?php echo e($expIsWorking->company_name); ?></p>
                                <?php endif; ?>

                            <?php $expIsWorking = \App\Models\UserEducation::getIsWorking($userDetails->id); ?>
                                <?php if(!empty($expIsWorking)): ?>
                                    <p><i class="fa fa-graduation-cap"></i> <?php echo e($expIsWorking->degree); ?>, <?php echo e($expIsWorking->university); ?></p>
                                <?php endif; ?>
                            <!-- <a href="javascript:void(0);" class="text-uppercase btn btn-sm btn-success ripple-effect-dark">REQUEST INTERVIEW</a> -->
                        </div>
                    </div>
                    <!-- xxxxxx -->
                    <?php if((!empty($userDetails->youtube_url)) || (!empty($userDetails->facebook_url)) || (!empty($userDetails->linkedin_url)) || (!empty($userDetails->twitter_url))): ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 font-md">See me on</h3>
                        </div>
                        <div class="card-body social-media-box text-center">
                            <ul class="list-inline mb-0">
                                <?php if(!empty($userDetails->youtube_url)): ?>
                                <li class="list-inline-item">
                                    <a target="_blank" href="<?php echo e($userDetails->youtube_url); ?>" class="youtube ripple-effect">
                                        <i class="fa fa-youtube"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(!empty($userDetails->facebook_url)): ?>
                                <li class="list-inline-item">
                                    <a target="_blank" href="<?php echo e($userDetails->facebook_url); ?>" class="facebook ripple-effect">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(!empty($userDetails->linkedin_url)): ?>
                                <li class="list-inline-item">
                                    <a target="_blank" href="<?php echo e($userDetails->linkedin_url); ?>" class="linkdin ripple-effect">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(!empty($userDetails->twitter_url)): ?>
                                <li class="list-inline-item">
                                    <a target="_blank" href="<?php echo e($userDetails->twitter_url); ?>" class="twitter ripple-effect">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- xxxxxxx -->
                    <?php if(count($userDetails->getUserEducation) > 0 ): ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 font-md">Education</h3>
                        </div>
                        <div class="card-body education-box">
                            <div class="education-cnt">
                                <?php $__currentLoopData = $userDetails->getUserEducation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="para mb-3">
                                    <h4 class="font-md mb-1"><?php echo e($education->course_name); ?></h4>
                                    <p class="education mb-1"><?php echo e($education->university); ?></p>
                                    <p class="date mb-0"><b>From :</b> <?php echo e($education->duration_from); ?> <b>To</b> <?php echo e(($education->is_working == 'yes') ? 'currently study here' : $education->duration_to); ?></p>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <!-- xxxxx -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 font-md">Contact Information</h3>
                        </div>
                        <div class="card-body education-box">
                            <?php if(!empty($userDetails->email)): ?>
                                <div class="para mb-3 mb-lg-4">
                                    <h4 class="font-md mb-1">Email address:</h4>
                                    <p class="mb-1 font-rg"><?php echo e($userDetails->email); ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if((!empty($userDetails->join_me)) || (!empty($userDetails->skype_id))): ?>
                            <div class="para mb-3 mb-lg-4">
                                <h4 class="font-md mb-2">Conferencing Platforms:</h4>
                                <div class="social-media-box">
                                    <ul class="list-inline mb-0">
                                        <?php if((!empty($userDetails->join_me))): ?>
                                        <li class="list-inline-item">
                                            <a href="javascript:void(0);" class="join ripple-effect" data-toggle="tooltip" data-original-title="<?php echo e($userDetails->join_me); ?>">
                                                <img src="http://localhost/rezieo-html/assets/images/join-icon.svg" alt="icon">
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php if((!empty($userDetails->skype_id))): ?>
                                        <li class="list-inline-item">
                                            <a href="javascript:void(0);" class="skype ripple-effect" data-toggle="tooltip" data-original-title="<?php echo e($userDetails->skype_id); ?>">
                                                <i class="fa fa-skype"></i>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if(!empty($userDetails->mobile_number)): ?>
                                <div class="para mb-3 mb-lg-4">
                                    <h4 class="font-md mb-1">Phone Number:</h4>
                                    <p class="mb-1 font-rg">+<?php echo e($userDetails->getCountry->phone_code); ?>-<?php echo e($userDetails->mobile_number); ?></p>
                                </div>
                            <?php endif; ?>
                            <?php if(!empty($userDetails->address)): ?>
                                <div class="para">
                                    <h4 class="font-md mb-1">Address:</h4>
                                    <p class="mb-1 font-rg"><?php echo e($userDetails->address); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- xxxxx -->
                </div>
                <!-- xxxxxxx -->
                <div class="col-xl-9 right-section">
                    <?php if(!empty($userDetails->getPromoVideo->video_url)): ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 font-md">Video Resume</h3>
                        </div>
                        <div class="card-body video_box">
                            <!--<iframe width="100%" src="https://www.youtube.com/embed/1mHjMNZZvFo" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>-->
                            <video onplay="saveVideoActivity('<?php echo e($userDetails->id); ?>');" alt="video-img" class="img-fluid" controls>
                                <source src="<?php echo e(url('public/uploads/promovideo/'.$userDetails->getPromoVideo->video_url)); ?>" type="video/mp4">
                            </video>
                        </div>
                    </div>
                    <?php endif; ?>
                    <!-- xxxxxx -->
                     <?php if(!empty($userDetails->profile_summary)): ?>
                        <div class="card mb-0 rounded-0 rounded-top">
                            <div class="card-header">
                                <h3 class="mb-0 font-md">Profile Summary</h3>
                            </div>
                            <div class="card-body resume-box">
                                <p class="font-rg mb-2">
                                    <?php echo e($userDetails->profile_summary); ?>

                                </p>
                            </div>
                        </div>
                     <?php endif; ?>
                    <!-- xxxxx -->
                    <?php if(count($userDetails->getUserExperience) >0 ): ?>
                    <div class="card rounded-0 mb-0">
                        <div class="card-header pt-0">
                            <h3 class="mb-0 font-md">Experience</h3>
                        </div>
                        <div class="card-body resume-box">
                            <?php if(!empty($userDetails->about_experience)): ?><p class="font-rg"><?php echo e($userDetails->about_experience); ?></p><?php endif; ?>
                            <?php if($userDetails->getUserExperience): ?>
                            <div class="slider_row">
                                <div class="slider-for">
                                    <?php $__currentLoopData = $userDetails->getUserExperience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="heading text-center">
                                            <h4 class="font-md"><?php echo e($experience->company_name); ?></h4>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="slider-nav">
                                    <?php $__currentLoopData = $userDetails->getUserExperience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item">
                                        <div class="top_info font-rg">
                                            <?php echo e($experience->duration_from); ?> <b>To</b> <?php echo e(($experience->is_working == 'yes') ? 'currently work here' : $experience->duration_to); ?>

                                        </div>
                                        <div class="line"></div>
                                        <div class="bottom_info">
                                            Product manager<br> Company1
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <!-- xxxxxx -->
                    <?php if(count($userDetails->getUserSkills) > 0): ?>
                    <div class="card rounded-0 mb-0">
                        <div class="card-header pt-0">
                            <h3 class="mb-0 font-md">Skills</h3>
                        </div>
                        <div class="card-body resume-box skills_box">
                            <ul class="list-inline tags mb-0">
                                <?php $__currentLoopData = $userDetails->getUserSkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-inline-item text-center">
                                    <span><?php echo e($skill->getSkill->skill_name); ?></span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- xxxxxxxx -->
                    <?php if(Auth::user()->user_type == 'freelancer'): ?>
                        <?php if(count($userDetails->getUserProject) > 0 ): ?>
                        <div class="card  rounded-0 rounded-bottom">
                            <div class="card-header">
                                <h3 class="mb-0 font-md">Portfolio</h3>
                            </div>
                            <?php $__currentLoopData = $userDetails->getUserProject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-body resume-box portfolio-box">
                                    <h2 class="font-bold"><?php echo e($portfolio->project_title); ?></h2>
                                    <?php if(!empty($portfolio->duration)): ?>
                                        <div class="duration mb-1 mb-md-2">
                                            <h4 class="font-md d-inline-block">Duration:</h4>
                                            <span class="font-rg"><?php echo e($portfolio->duration); ?></span>
                                        </div>
                                    <?php endif; ?>
                                    <div class="para">
                                        <?php if(!empty($portfolio->project_type)): ?>
                                            <h4 class="font-sm mb-1">Project Type</h4>
                                            <p class="mb-2 mb-lg-3"><?php echo e($portfolio->project_type); ?></p>
                                        <?php endif; ?>
                                        
                                        <?php if(!empty($portfolio->project_amount)): ?>
                                            <div class="duration mb-1 mb-md-2">
                                                <h4 class="font-md d-inline-block mb-0">Amount:</h4>
                                                <span class="font-rg">$ <?php echo e($portfolio->project_amount); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php $projectLink = explode(',',$portfolio->project_links); ?>
                                        <?php if(count($projectLink) > 0 ): ?>
                                            <?php $__currentLoopData = $projectLink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="mb-3 mb-lg-4 link">
                                                    <a target="_blank" href="<?php echo e($link); ?>" class="font-rg color-green"><?php echo e($link); ?></a>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if(!empty($portfolio->client_details)): ?>
                                    <div class="para">
                                        <h4 class="font-sm mb-1">Client Detail</h4>
                                        <p class="mb-2 mb-lg-3"><?php echo e($portfolio->client_details); ?></p>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if(!empty($portfolio->description)): ?>
                                    <div class="para">
                                        <h4 class="font-sm mb-1">Project Description</h4>
                                        <p><?php echo e($portfolio->description); ?></p>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php $userDocuments = App\Models\UserDocument::getUserDocumentByProjectId($portfolio->id); ?>
                                    <?php if(count($userDocuments) > 0): ?>
                                    <div class="document-box mt-lg-4">
                                        <ul class="list-inline mb-0">
                                            <?php $__currentLoopData = $userDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="list-inline-item text-center">
                                                    <div class="icon" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?php echo e($documents->document_name); ?>">
                                                        <img src="<?php echo e(url('public/images/pdf-icon.png')); ?>" alt="icon" class="img-fluid">
                                                    </div>
                                                    <a href="javascript:void(0);" class="ripple-effect-dark">DOWNLOAD</a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- xxxx -->
                        </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>
<script src="<?php echo e(url('public/js/slick.min.js')); ?>" type="text/javascript"></script>
<script>
		$( '.icon' ).tooltip();
		$( '.slider-for' ).slick( {
			slidesToShow: 1,
			slidesToScroll: 1,
			arrows: false,
			fade: true,
			asNavFor: '.slider-nav'
		} );
		$( '.slider-nav' ).slick( {
			slidesToShow: 3,
			slidesToScroll: 1,
			asNavFor: '.slider-for',
			dots: false,
			centerMode: true,
			focusOnSelect: false,
			prevArrow: "<img src='<?php echo e(url('public/images/left-arrow-icon.svg')); ?>' class='arrow-prev'>",
			nextArrow: "<img src='<?php echo e(url('public/images/right-arrow-icon.svg')); ?>' class='arrow-next'>",
			responsive: [ {
				breakpoint: 550,
				settings: {
					slidesToShow: 1,
				}
			} ]
		} );
		$( ".education-cnt" ).mCustomScrollbar( {
			scrollbarPosition: "outside"
		} );
                
                function saveVideoActivity(userId){
                    alert(userId);
                }
                
                function saveVideoActivity(userId){
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(url('/user/view-video')); ?>",
                        data: {'_token': "<?php echo e(csrf_token()); ?>", 'userId': userId},
                        success: function (response) {
                            if (response.status) {
                                console.log(response.status);
                            }
                        }
                    });
                }
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>