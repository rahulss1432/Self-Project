<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <title>Home | Rezieo </title>
        <?php echo $__env->make('layouts.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <link rel="stylesheet" href="<?php echo e(url('public/css/fullpage.min.css')); ?>" type="text/css">
            <?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>   
    </head>
    <body class="landing">
        <div class="loader" id="loader" onload="loader()">
            <div class="bg-load bg-green"></div>
            <div class="valign">
                <div class="icon-logo">
                    <img src="<?php echo e(url('public/images/logo-white.svg')); ?>" class="logo_white" alt="Rezieo">
                </div>
            </div>
        </div>
        <div class="home-page-header">
            <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="main-wrapper home-page-new" id="fullpage">
            <section class="banner-wrap vertical-scrolling fp-auto-height-responsive" id="bannar">
                <div class="container container-1350">
                    <div class="banner">
                        <div class="banner-content">
                            <p>Rezieo</p>
                            <h1>Build a Professional</h1>
                            <h3>Identity you can be Proud of</h3>
                            <a href="signup.php" class="btn btn-success ripple-effect-dark wow fadeInDown">GET STARTED</a>
                        </div>
                    </div>
                </div>
            </section>
            <section class="vertical-scrolling" id="section02">
                <div class="bnr-btm-sec">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6 col-6 pr-md-0">
                                <div class="about d-flex align-items-center justify-content-center border-right wow slideInLeft" data-wow-delay="0s" data-wow-duration="1s">
                                    <img src="<?php echo e(url('public/images/bee-seen.svg')); ?>" alt="Be Seen">
                                        <div class="dtl">
                                            <h1>Be Seen</h1>
                                            <p>FOR CANDIDATES</p>
                                        </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-6">
                                <div class="about d-flex align-items-center justify-content-center wow slideInRight" data-wow-delay="0s" data-wow-duration="1s">
                                    <img src="<?php echo e(url('public/images/find-talent.svg')); ?>" alt="Find Talent">
                                        <div class="dtl">
                                            <h1>Find Talent</h1>
                                            <p>FOR EMPLOYERS</p>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="services-sec common-section">
                    <header class="section-head text-center wow fadeInDown" data-wow-delay="1s">
                        <div class="container">
                            <h1>Modernizing the Job Seeking Process</h1>
                            <p>For Candidates and Freelancers</p>
                        </div>
                    </header>
                    <div class="services-content">
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-4 col-6 block-service-outer delay-100">
                                    <div class="content-wrap wow fadeInDown" data-wow-delay="1.2s">
                                        <div class="icon">
                                            <img src="<?php echo e(url('public/images/create-profile.svg')); ?>" alt="CREATE  PROFILE">
                                        </div>
                                        <div class="detail">
                                            <h3>CREATE  PROFILE</h3>
                                            <p>Start with providing all details </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-6 block-service-outer delay-200">
                                    <div class="content-wrap wow fadeInDown" data-wow-delay="1.5s">
                                        <div class="icon">
                                            <img src="<?php echo e(url('public/images/search-jobs.svg')); ?>" alt="SEARCH JOBS">
                                        </div>
                                        <div class="detail">
                                            <h3>SEARCH JOBS</h3>
                                            <p>Search for open positions based off your skill set.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-6 block-service-outer delay-300">
                                    <div class="content-wrap wow fadeInDown" data-wow-delay="1.8s">
                                        <div class="icon">
                                            <img src="<?php echo e(url('public/images/get-seen.svg')); ?>" alt="GET SEEN">
                                        </div>
                                        <div class="detail">
                                            <h3>GET SEEN</h3>
                                            <p>Provide a personallink to share on with a potentialemployer</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-6 block-service-outer delay-400">
                                    <div class="content-wrap wow fadeInDown" data-wow-delay="2.1s">
                                        <div class="icon">
                                            <img src="<?php echo e(url('public/images/record-interview.svg')); ?>" alt="RECORD INTERVIEW">
                                        </div>
                                        <div class="detail">
                                            <h3>RECORD INTERVIEW</h3>
                                            <p>Provide a recorded session that allows you to show off your talent.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-6 block-service-outer delay-500">
                                    <div class="content-wrap wow fadeInDown" data-wow-delay="2.3s">
                                        <div class="icon">
                                            <img src="<?php echo e(url('public/images/video-resume.svg')); ?>" alt="VIDEO RESUME">
                                        </div>
                                        <div class="detail">
                                            <h3>VIDEO RESUME</h3>
                                            <p>Record and upload a promotional video to capture your audience.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-6 block-service-outer delay-600">
                                    <div class="content-wrap wow fadeInDown" data-wow-delay="2.5s">
                                        <div class="icon">
                                            <img src="<?php echo e(url('public/images/get-hired.svg')); ?>" alt="GET HIRED">
                                        </div>
                                        <div class="detail">
                                            <h3>GET HIRED</h3>
                                            <p>Land the job that is the right fit not just for you but for the employer.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="simpletransparent-sec common-section vertical-scrolling" id="section03">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-6">
                            <div class="left">
                                <header class="section-head wow fadeInDown"  data-wow-delay="0.3s">
                                    <h1 class="text-white">Simple and Transparent</h1> 
                                </header>
                                <div class="detail text-white">
                                    <div class="wow fadeInDown" data-wow-delay="0.5s">
                                        <p class="font-md mb-2">Simplicity is a prerequisite for reliability</p>
                                        <p>- Edsger W. Dijkstra</p>
                                        <p>Our aim was to make asimple platform and easy to use. Rezieodoes what it was designed to do, bridging the gap between the right candidates and the companies in need of them. No more wasting time, screening resumes, setting up interviews, spending hours interviewing candidates that don’t fit your companies culture, team, or values.</p>
                                    </div>
                                    <ul class="list-inline">
                                        <li class="list-inline-item wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.6s">
                                            <img src="<?php echo e(url('public/images/simple.svg')); ?>" alt="SIMPLE">
                                                <h5>SIMPLE</h5>
                                        </li>
                                        <li class="list-inline-item wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.7s">
                                            <img src="<?php echo e(url('public/images/efficient.svg')); ?>" alt="EFFICIENT">
                                                <h5>EFFICIENT</h5>
                                        </li>
                                        <li class="list-inline-item wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s">
                                            <img src="<?php echo e(url('public/images/safe.svg')); ?>" alt="SAFE">
                                                <h5>SAFE</h5>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="right wow slideInRight">
                            <img src="<?php echo e(url('public/images/simple-transparent.png')); ?>" class="img-fluid">
                        </div>
                    </div>
                </div>
            </section>
            <section class="modernizing-process-sec common-section gray-bg vertical-scrolling" id="section04">
                <header class="section-head text-center">
                    <div class="container">
                        <h1>Modernizing the Hiring Process</h1>
                        <p>Setup your questions, request interviews from candidates, review their recorded interviews.</p>
                    </div>                
                </header>
                <div class="progress-steps mb-0">
                    <div class="container">
                        <div class="row">
                            <div class="col col-sm-3 process-item delay-200">
                                <div class="step one wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
                                    <img src="<?php echo e(url('public/images/add-interview-questions.png')); ?>">
                                        <p>Add interview<br> questions</p>
                                </div>
                            </div>
                            <div class="col col-sm-3 process-item delay-300">
                                <div class="step two wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
                                    <img src="<?php echo e(url('public/images/request-video-interviews.png')); ?>">
                                        <p>Request video<br> interviews</p>
                                </div>
                            </div>
                            <div class="col col-sm-3 process-item delay-400">
                                <div class="step three wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.7s">
                                    <img src="<?php echo e(url('public/images/access-applicants-video.png')); ?>">
                                        <p>Access applicants<br> video</p>
                                </div>
                            </div>
                            <div class="col col-sm-3 process-item delay-500">
                                <div class="step four wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.9s">
                                    <img src="<?php echo e(url('public/images/hire-the-right-candidate.png')); ?>">
                                        <p>Hire the right<br> candidate</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="choose-talent common-section vertical-scrolling" id="choose-talent">
                <div class="container container-1350">
                    <div class="talent-wrap">
                        <div class="row">
                            <div class="col-sm-7 order-1">
                                <div class="left wow slideInLeft">
                                    <img src="<?php echo e(url('public/images/best-talent.jpg')); ?>" class="img-fluid">
                                </div>
                            </div>
                            <div class="col-sm-5 order-md-1">
                                <div class="content">
                                    <div class="right-in">
                                        <header class="section-head wow fadeInDown" data-wow-delay="0.5s">
                                            <h1>Always Choose the <br>Best Talent</h1>
                                        </header>
                                        <p class="wow fadeInDown" data-wow-delay="0.8s">Competition for the best and brightest talent is nothing short of cutthroat. No matter how cliché it sounds, professionals know that the backbone of every good business is a great team.Rezieo can help your business find high performance people helping you create high performance teams.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="talent-wrap btm pr-0">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="content">
                                    <div class="right-in">
                                        <header class="section-head wow fadeInDown" data-wow-delay="0.5s">
                                            <h1>Easily Apply To Multiple Companies</h1>
                                        </header>
                                        <p class="wow fadeInDown" data-wow-delay="0.8s">Candidates can apply for consideration with a click of the mouse.  Browse and search for postings in our database. If there are no positions available during your search you can promote yourself with the unique link you are provided on your profile page.</p>
                                    </div>

                                </div>
                            </div>
                            <div class="col-sm-7">
                                <div class="left wow slideInRight">
                                    <img src="<?php echo e(url('public/images/easy-apply.png')); ?>" class="img-fluid">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="testimonial-sec common-section gray-bg vertical-scrolling fp-auto-height-responsive" id="testimonialSection">        
                <header class="section-head text-center wow fadeInDown">
                    <div class="container">
                        <h1>What People Say About Rezieo</h1>
                        <p>Don’t take our word for it see what others think about Rezieo</p>
                    </div>
                </header>
                <div class="testi-content">
                    <div class="container">
                        <div class="testimonial-slider" id="testimonialSlider">
                            <div class="item">
                                <div class="item_cnt">
                                    <div class="author-pic">
                                        <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" class="rounded-circle">
                                    </div>
                                    <div class="content wow pulse" data-wow-duration="1s" data-wow-delay="0.3s">
                                        <p>“Running a small company can be challenging but getting the right people on the team in the beginning is even more of a challenge.  Rezieo streamlined the process for us. Being able to watch and listen to candidates gave us good feel if the individual would be a good fit for our team.”</p>
                                        <div class="auth-dtl">
                                            <h6>Steven Chamorro, Partner of Departure Point Marketing</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="item_cnt">
                                    <div class="author-pic">
                                        <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" class="rounded-circle">
                                    </div>
                                    <div class="content">
                                        <p>“I hire remotely constantly so being able to see and hear the individual before spending all that time was very inciteful and help me better screen our applicants. I really loved the simplicity of the platform and of course you can’t beat the price.”</p>
                                        <div class="auth-dtl">
                                            <h6>Duane Wrobel, Owner and CEO of Avantility</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="item_cnt">
                                    <div class="author-pic">
                                        <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" class="rounded-circle">
                                    </div>
                                    <div class="content">
                                        <p>“I loved having a way to professionally promote myself using video and creating something to capture the attentions of my potential clients. Why didn’t anyone think of this sooner.”</p>
                                        <div class="auth-dtl">
                                            <h6>Steve Mizer, Owner and CEO of Business Growth Management Solutions</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="item_cnt">
                                    <div class="author-pic">
                                        <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" class="rounded-circle">
                                    </div>
                                    <div class="content">
                                        <p>“In this competitive world it is hard to find talent that really knows what they are doing.  I was please to use the Rezieo platform. I found one of the best coders on the market and I don’t think I would have found him if it not for Rezieo”</p>
                                        <div class="auth-dtl">
                                            <h6>Rodrigo Fuentes, Owner and CEO of Listen Loop </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>
            <section class="getstarted-sec common-section d-flex align-items-end vertical-scrolling p-0" id="getstartedSection">
                <div class="container">
                    <div class="careermove-box ">
                        <div class="box-in d-lg-flex justify-content-between align-items-center">
                            <div class="left">
                                <div class="section-head">
                                    <h1 class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">Make Your Next Career Move.</h1>
                                    <p class="wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.3s">Join Us today and show your talent among the many other members managing their professional profiles on Rezieo today.</p>
                                </div>
                            </div>
                            <div class="right">
                                <a href="signup.php" class="btn btn-success ripple-effect-dark">GET STARTED NOW</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </section>
        </div>
        <script src="<?php echo e(url('public/js/jquery.easing.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(url('public/js/jquery.slimscroll.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(url('public/js/fullpage.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(url('public/js/slick.min.js')); ?>" type="text/javascript"></script>
        <script type="text/javascript">
            if ($(window).width() > 1200) {
                $('#fullpage').fullpage({
                    afterResponsive: function (isResponsive) {

                    },
                    sectionSelector: '.vertical-scrolling',
                    fadingEffect: true,
                    scrollingSpeed: 500,
                    scrollOverflow: true,
                    responsiveWidth: 991,
                });
            }
            $('#testimonialSlider').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: true,
                arrows: false,
                focusOnSelect: false
            });

//header scroll effect
            var headerHeight = $('#main_header').height() + 80;
            function stickyheader() {
                scrtop = $(window).scrollTop();
                if (scrtop >= headerHeight) {
                    $('#main_header').addClass('fixed');
                } else {
                    $('#main_header').removeClass('fixed');
                }
            }

            $('html').bind('mousewheel DOMMouseScroll', function (e) {

                if ($('#bannar').hasClass('active')) {
                    $('#main_header').removeClass('fixed');
                }
                setTimeout(function () {
                    if ($('#banner').hasClass('active')) {
                        $('.process-item').addClass('display');
                    } else {
                        $('.process-item').removeClass('display');
                    }
                    if ($('#section02').hasClass('active')) {
                        $('#main_header').addClass('fixed');
                        $('.block-service-outer').addClass('display');
                        $('#section02 h1, #section02 p').addClass('fadeup');
                    } else {
                        $('.block-service-outer').removeClass('display');
                        $('#section02 h1, #section02 p').removeClass('fadeup');
                    }

                    if ($('#section04').hasClass('active')) {
                        $('#section04 h1, #section04 p').addClass('fadeup');
                        $('.process-item').addClass('display');
                    } else {
                        $('.process-item').removeClass('display');
                        $('#section04 h1, #section04 p').removeClass('fadeup');
                    }
                    if ($('#section03').hasClass('active')) {
                        $('#section03 h1, #section03 p').addClass('fadeup');
                        $('.simpletransparent-sec .right').addClass('display');
                    } else {
                        $('#section03 h1, #section03 p').removeClass('fadeup');
                        $('.simpletransparent-sec .right').removeClass('display');
                    }
                    if ($('#choose-talent').hasClass('active')) {
                        $('#choose-talent h1, #choose-talent p').addClass('fadeup');
                    } else {
                        $('#choose-talent h1, #choose-talent p').removeClass('fadeup');
                    }
                    if ($('#testimonialSection').hasClass('active')) {
                        $('#testimonialSection h1, #testimonialSection p').addClass('fadeup');
                    } else {
                        $('#testimonialSection h1, #testimonialSection p').removeClass('fadeup');
                    }
                    if ($('#getstartedSection').hasClass('active')) {
                        $('#getstartedSection .careermove-box h1, #getstartedSection .careermove-box p').addClass('fadeup');
                    } else {
                        $('#getstartedSection .careermove-box h1, #getstartedSection .careermove-box p').removeClass('fadeup');
                    }
                }, 100);
            });
            setTimeout(function () {
                $('.banner-content').addClass('fadeup');
            }, 1000);
            window.onload = function () {
                setTimeout(function () {
                    $('body').addClass('hide-loader');
                }, 300);
            };
        </script>

    </body>

</html>