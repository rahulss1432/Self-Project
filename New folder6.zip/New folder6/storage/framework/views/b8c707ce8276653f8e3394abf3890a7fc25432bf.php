<?php $__env->startSection('title', 'Add Sub Admin'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray"  onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content cms-edit" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent" >
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Add Sub admin</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a id="back-loader" onclick="backloader()" href="<?php echo e(url('admin/subadmin')); ?>" class="nav-link" title="Back">
                <i class="fa fa-long-arrow-left"></i>
              </a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <form id="addSubadminForm" autocomplete="off" class="f-field" method="POST" action="<?php echo e(url('admin/add-subadmin')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="row">
              <div class="col-sm-12">
                <div class="form-group">
                  <div class="profileimg">
                  <img id="uploadimg" class="rounded-circle avtar img-thumbnail" src="<?php echo e(url('public/assets/images/preview_img.jpg')); ?>" alt="profile img">
                    <label for="profileimg" class="edit_icon rounded-circle">
                      <input id="profileimg" name="profile_picture" type="file" onchange="document.getElementById('uploadimg').src = window.URL.createObjectURL(this.files[0])" hidden="">
                      <img src="<?php echo e(url('public/assets/images/edit_icon.png')); ?>" alt="icon">
                    </label>
                  </div>
                </div>
              </div>  
            </div>
            <div class="row">
              <div class="col-sm-6">
                <div class="form-group">
                  <label class="control-label">First Name</label>
                  <input type="text" name="first_name" class="form-control form-control-lg">
                </div>
              </div> 
              <div class="col-sm-6">
                <div class="form-group">
                  <label class="control-label">Last Name</label>
                  <input type="text" name="last_name" class="form-control form-control-lg">
                </div>
              </div> 
            </div>
            <div class="row">
              <div class="col-sm-6">
                <div class="form-group">
                  <label class="control-label">Email</label>
                  <input type="email" name="email" class="form-control form-control-lg">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <label class="control-label">Password</label>
                  <input type="password" name="password" class="form-control form-control-lg">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-6">
               <div class="form-group">
                  <label class="control-label">Mobile Number</label>
                  <input type="text" name="phone" class="form-control form-control-lg">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <label class="control-label">Gender</label>
                  <select class="selectpicker form-control form-control-lg" name="gender" title="Select">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="from-group">
              <button id="save-loader" type="submit" class="btn btn-sm btn-primary btn_radius"> Save</button>
            </div>
         </form>
         <?php echo JsValidator::formRequest('App\Http\Requests\addSubadminRequest','#addSubadminForm'); ?>

        </div>
      </div>
    </div>
  </main>

  <script type="text/javascript">

    $('.form-group .form-control').focus(function ()
    {
      $(this).parent().addClass('isfocused');
    }).blur(function () 
    {
      $(this).parent().removeClass('isfocused');
    });


    function backloader()
    {
      $("#back-loader").attr("disabled", true);
      $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    };


    window.addEventListener('beforeunload', function(event)
    {
      $("#save-loader").attr("disabled", true);
      $("#save-loader").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
    });

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>