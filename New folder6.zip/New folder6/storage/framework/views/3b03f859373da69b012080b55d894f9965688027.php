<?php $__env->startSection('title', 'Add Blog'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray"  onload="hide_preloader();">
    <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="main-content cms-edit" id="mainContent">
        <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="page-content" id="pageContent" >
            <div class="card custom_card" id="card_height">
                <div class="card-header">
                    <h4 class="page-title float-left">Add Blogs</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item">
                            <a id="back-loader" onclick="backloader()" href="<?php echo e(url('admin/blog')); ?>" class="nav-link" title="Back">
                                <i class="fa fa-long-arrow-left"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <form id="addBlogForm" autocomplete="off" class="f-field" method="POST" action="<?php echo e(url('admin/add-blog')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Blog Title</label>
                                    <input type="text" name="title" class="form-control form-control-lg">
                                </div>
                            </div> 
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Upload Image<span class="red-star"> *</span></label>
                                    <div class="file-upload">
                                        <div class="file-select">
                                            <div class="file-select-button" id="fileName">Choose File</div>
                                            <div class="file-select-name" id="noFile">No file chosen...</div> 
                                            <input type="file" name="image" id="chooseFile">
                                        </div>
                                    </div>  
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Meta Title</label>
                                    <input type="text" name="meta_title" class="form-control form-control-lg">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Tags</label>
                                    <?php
                                    $tagList = App\Models\Tags::getAllTagsData();
                                    ?>
                                    <select data-placeholder="Choose a tag..." id="tags" name="blog_tags[]" multiple="" class="form-control chzn-select">
                                        <?php if($tagList->count() > 0): ?>
                                        <?php $__currentLoopData = $tagList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($val->name); ?>" ><?php echo e($val->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="control-label">Description</label>
                                    <textarea class="form-control" name="description" id="description" rows="2"></textarea>
                                    <span id="description-error" style="font-size: 12px;" class="help-block"></span>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="control-label">Meta Description</label>
                                    <textarea name="meta_description" id="meta_description" class="form-control" rows="2"></textarea>
                                    <span id="meta_description-error" style="font-size: 12px;" class="help-block"></span>
                                </div>
                            </div>
                            <div class="col-sm-6 link_list">
                                <div class="form-group form-add" id="mainDiv_1">
                                    <label class="control-label">External links</label>
                                   <div class="from-grp">
                                     <input type="text" name="external_link[]" id="link_1" class="form-control form-control-lg required">
                                        <span></span>
                                        <a href="javascript:void(0);" class="add_questions add_links nav-link">
                                            <i class="fa fa-plus"></i>
                                        </a>
                                   </div>
                                </div>
                            </div> 
                        </div>
                        <div class="from-group">
                            <button id="save-loader" type="submit" class="btn btn-primary btn_radius submitButton"> Save</button>
                        </div>
                    </form>
                    <?php echo JsValidator::formRequest('App\Http\Requests\addBlogRequest','#addBlogForm'); ?>

                </div>
            </div>
        </div>
    </main>
    <link rel="stylesheet" href="<?php echo e(url('public/assets/css/chosen.min.css')); ?>" type="text/css">
    <script src='<?php echo e(url('public/assets/js/chosen.jquery.min.js')); ?>'></script>
    <script type="text/javascript">
                                        var global = 2;
                                $('.add_links').click(function ()
                                {
                                    $('.link_list').append('<div class="form-group form-add" id="mainDiv_' + global + '"><label class="control-label">External links</label><div class="from-grp"><input type="text" name="external_link[]" id="link_' + global + '" class="form-control form-control-lg required"><span></span><a href="javascript:void(0);" class="add_questions nav-link" onclick="deleteRow(' + global + ')"><i class="fa fa-minus"></i></a></div></div>');
                                    global++;
                                });

                                function deleteRow(id) {
                                    $("#mainDiv_" + id).remove();
                                }

                                $('form#addBlogForm .submitButton').click(function (event) {
                                    var flag = 0;
                                    $(".required").each(function () {
                                        event.preventDefault();
                                        if ($(this).val().trim() == "") {
                                            $(this).next('span').css('color', 'red').html("This field is required");
                                            flag++;
                                        } else if (isValidUrl($(this).val()) == 1) {
                                            $(this).next('span').css('color', 'red').html("");
                                        } else {
                                            $(this).next('span').css('color', 'red').html("Url is invalid");
                                            flag++;
                                        }
                                    });

                                    $('.required').keyup(function () {
                                        $(this).next('span').css('color', 'green').html("");
                                    });
                                    if (flag == 0) {
                                        $("#addBlogForm").submit();
                                    }

                                    var description = tinymce.get('meta_description').getContent();
                                    if (description === undefined || description.length == 0)
                                    {
                                        $("#meta_description-error").html("Meta Description field is required.");
                                        $("#meta_description-error").css('color', '#a94442');
                                        return false;
                                    }
                                    else
                                    {
                                        var description1 = tinymce.get('description').getContent();
                                        if (description1 === undefined || description1.length == 0)
                                        {
                                            $("#description-error").html("Description field is required.");
                                            $("#description-error").css('color', '#a94442');
                                            return false;
                                        }
                                        else
                                        {
                                            return true;
                                        }
                                        return true;
                                    }

                                });

                                function isValidUrl(url) {
                                    var myVariable = url;
                                    if (/^(http|https|ftp):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/i.test(myVariable)) {
                                        return 1;
                                    } else {
                                        return -1;
                                    }
                                }

                                $(document).ready(function () {
                                    $(".chzn-select").chosen();
                                    $("#tags_chosen ul>li>input").keyup(function (e) {
                                        if (e.which == 13) {
                                            var checkPoint = $("#tags_chosen").find("li").hasClass("no-results");
                                            if (checkPoint == true) {
                                                $("#tags").append('<<option value="' + $(this).val() + '" selected="selected">' + $(this).val() + '</option>>');
                                                $("#tags").trigger("chosen:updated");
                                            }
                                        }
                                    });
                                });

                                $(document).ready(function ()
                                {
                                    tinymce.init({
                                        theme: "modern",
                                        selector: "textarea",
                                        relative_urls: false,
                                        remove_script_host: false,
                                        convert_urls: true,
//                plugins: 'image code',
                                        height: 300,
//                toolbar: 'undo redo | image code',
                                        images_upload_url: '<?php echo e(url("admin/admin-image-upload")); ?>',
                                        images_upload_handler: function (blobInfo, success, failure) {
                                            var xhr, formData;
                                            xhr = new XMLHttpRequest();
                                            xhr.withCredentials = false;
                                            xhr.open('POST', '<?php echo e(url("admin/admin-image-upload")); ?>');
                                            xhr.setRequestHeader('X-CSRF-TOKEN', '<?php echo e(csrf_token()); ?>');
                                            xhr.onload = function () {
                                                var json;
                                                if (xhr.status != 200)
                                                {
                                                    failure('HTTP Error: ' + xhr.status);
                                                    return;
                                                }
                                                json = JSON.parse(xhr.responseText);
                                                if (!json || typeof json.location != 'string')
                                                {
                                                    failure('Invalid JSON: ' + xhr.responseText);
                                                    return;
                                                }
                                                success(json.location);
                                            };
                                            formData = new FormData();
                                            formData.append('file', blobInfo.blob(), blobInfo.filename());
                                            xhr.send(formData);
                                        },
                                        init_instance_callback: function (editor)
                                        {
                                            editor.on('keyup', function (e)
                                            {
                                                var message = tinymce.get('meta_description').getContent();
                                                var message1 = tinymce.get('description').getContent();
                                                if (message === '')
                                                {
                                                    $("#meta_description-error").html('Meta Description field is required');
                                                    $("#meta_description-error").css('color', '#a94442');
                                                }
                                                else
                                                {
                                                    $("#meta_description-error").html('');
                                                }
                                                if (message1 === '')
                                                {
                                                    $("#description-error").html('Description field is required');
                                                    $("#description-error").css('color', '#a94442');
                                                }
                                                else
                                                {
                                                    $("#description-error").html('');
                                                }
                                            });
                                        }
                                    });
                                });

                                $('#chooseFile').bind('change', function () {
                                    var filename = $("#chooseFile").val();
                                    if (/^\s*$/.test(filename)) {
                                        $(".file-upload").removeClass('active');
                                        $("#noFile").text("No file chosen...");
                                    }
                                    else {
                                        $(".file-upload").addClass('active');
                                        $("#noFile").text(filename.replace(/C:\\fakepath\\/i, ''));
                                    }
                                });

                                $('.form-group .form-control').focus(function ()
                                {
                                    $(this).parent().addClass('isfocused');
                                }).blur(function ()
                                {
                                    $(this).parent().removeClass('isfocused');
                                });


                                function backloader()
                                {
                                    $("#back-loader").attr("disabled", true);
                                    $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
                                }
                                ;

                                window.addEventListener('beforeunload', function (event)
                                {
                                    $("#save-loader").attr("disabled", true);
                                    $("#save-loader").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
                                });

    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>