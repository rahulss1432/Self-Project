<header class="topheader">
    <nav class="navbar navbar-expand-md">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(url('public/images/black-logo.png')); ?>" alt="logo" class="blk-logo" />
            <img src="<?php echo e(url('public/images/logo.png')); ?>" alt="logo" class="white-logo"/>
        </a>
        <button class="navbar-toggler ml-auto " type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation" onclick="closeMenu()">
            <span class="ti-menu">
                <img src="<?php echo e(url('public/images/menu.png')); ?>" alt="menu">
            </span>
        </button>
        <div class="right navbar-collapse collapse " id="navbarCollapse"> 
            <ul class="navbar-nav ml-auto align-items-md-center">
                <?php if(\Request::route()->getName() == 'home'): ?>
                <li><a class="front-links" href="#purchaseBook">Purchase book</a></li>
                <li><a class="front-links" href="#podcast">Podcast</a></li>
                <li><a class="front-links" href="#blog">Blog</a></li>
                <li><a class="front-links" href="#danielZeman">About Daniel Zeman</a></li>
                <?php else: ?>
                <li><a href="<?php echo e(url('/')); ?>#purchaseBook">Purchase book</a></li>
                <li><a href="<?php echo e(url('/')); ?>#podcast">Podcast</a></li>
                <li><a href="<?php echo e(url('/')); ?>#blog">Blog</a></li>
                <li><a href="<?php echo e(url('/')); ?>#danielZeman">About Daniel Zeman</a></li>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                <li class="<?php echo e(( \Request::route()->getName() == 'register') ? 'active' : ''); ?>"><a href="<?php echo e(url('/register')); ?>">Sign up</a></li>
                <li class="<?php echo e(( \Request::route()->getName() == 'login') ? 'active' : ''); ?>"><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                <?php else: ?>
                <li class="user-pic">
                    <a href="<?php echo e(url('/user/my-profile')); ?>">
                        <img class="profileImage" src="<?php echo e(\App\Helpers\Utility::checkProfileImage(Auth::user()->profile_image)); ?>" alt="user">
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>   
</header>
