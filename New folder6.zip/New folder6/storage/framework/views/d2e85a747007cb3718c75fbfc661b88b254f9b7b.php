<table class="table common-table admin-table w-100">
    <thead class="th-border">
        <tr>
            <th>Sr.</th>
            <th>User Type</th>
            <th>Plan Name</th>
            <th>Price</th>
            <th>Duration</th>
            <th>Video Duration</th>
            <th>Jobs Limit</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if(!empty($planList->count()>0)): ?>
        <?php $i=1; ?>
        <?php $__currentLoopData = $planList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $srNo = ($planList->currentPage() - 1) * $planList->perPage() + $i++; ?>
        <tr>
            <td><?php echo e($srNo); ?></td>
            <td><?php echo e(ucfirst($plan['user_type'])); ?></td>
            <td><?php echo e($plan['plan_name']); ?></td>
            <td><?php echo e(\App\Helpers\Utility::getPriceFormat($plan['price'])); ?></td>
            <td><?php echo e($plan['plan_duration']); ?> days</td>
            <td><?php echo e($plan['video_duration']); ?> seconds</td>
            <td><?php echo e($plan['jobs_limit']); ?></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" <?php echo e(($plan['status']=='enabled')?'checked="checked"':''); ?> onchange="updateStatus('<?php echo e($plan["id"]); ?>');" name="status[]" value="<?php echo e($plan['status']); ?>">
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul  class="list-inline mb-0">
                    <li class="list-inline-item"> <a href="<?php echo e(url('admin/edit-plan/'.$plan["id"])); ?>" title="View"><i class="fa fa-pencil"></i></a></li>
                    <li class="list-inline-item"> <a href="javascript:void(0);" onclick="deleteIndustry('<?php echo e($plan["id"]); ?>','<?php echo e($plan["plan_name"]); ?>')" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-trash"></i></a></li>
                </ul>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td colspan="9"><?php \App\Helpers\Utility::emptyListMessage('plan'); ?></td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php \App\Helpers\Utility::getAdminPaginationDiv($planList); ?>

<script>
                    var title = 'Plan';
                    $(document).ready(function () {
            $(".pagination li a").on('click', function (e) {
            e.preventDefault();
                    $("#planList").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
                    var pageLink = $(this).attr('href');
                    $.ajax({
                    type: 'POST',
                            url: pageLink,
                            async: false,
                            data: $('#frmFilter').serialize(),
                            success: function (response) {
                            $('.pagination:first').remove();
                                    $("#planList").html(response);
                            }
                    });
            });
            });
                    function updateStatus(id) {
                    $.ajax({
                    type: "POST",
                            url: "<?php echo e(url('/admin/update-plan-status')); ?>",
                            data: {'_token': "<?php echo e(csrf_token()); ?>", 'id': id},
                            success: function (response) {
                            if (response.status) {
                            successToaster(response.message, title);
                            }
                            }
                    });
                    }

            function deleteIndustry(id, name) {
            bootbox.confirm('Are you sure do you want to delete <b>' + name + '<b>?', function (result) {
            if (result) {
            $.ajax({
            type: "GET",
                    url: "<?php echo e(url('admin/delete-plan')); ?>",
                    data: {id: id},
                    success: function (response) {
                    if (response.status) {
                    successToaster(response.message, title);
                            loadPlanList();
                    }
                    }
            });
            }
            });
            }
</script>
