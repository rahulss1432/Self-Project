<?php if(count($myApplicationData)>0): ?>
<div class="row">
    <?php $__currentLoopData = $myApplicationData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicationData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xl-3 col-custom-1200 col-lg-4 col-sm-6">
        <div class="job_box">
            <div class="job_header">
                <div class="job_img d-inline-flex align-items-center justify-content-center">
                    <img src="<?php echo e(\App\Helpers\Utility::checkCompanyLogo($applicationData->getJob->getUser->company_logo)); ?>" alt="icon" class="img-fluid">
                </div>
            </div>
            <div class="job_body">
                <h3><?php echo e($applicationData->getJob->job_title); ?></h3>
                <h6><?php echo e($applicationData->getJob->city); ?> - <?php echo e($applicationData->getJob->state); ?></h6>
                <span class="font-rg">
                    <span class="color-green"><?php echo e($applicationData->getJob->job_type); ?></span>
                    <?php if(!empty($applicationData->getJob->experience)): ?>
                         <span class="color-yellow"><?php echo e($applicationData->getJob->experience); ?> Years</span>
                    <?php endif; ?>
                </span>
                <p><?php echo e(\App\Helpers\Utility::getLimitText(30,$applicationData->getJob->position_summary)); ?>&nbsp; </p>
                <?php if($applicationData->status == 'pending' ): ?>
                    <div class="row d-flex justify-content-between">
                        <div class="col col-sm-6">
                                <button type="button" class="btn btn-block btn-outline-success btn-sm ripple-effect-dark text-uppercase">ACCEPT</button>
                        </div>
                        <div class="col col-sm-6">
                            <input type="hidden" id="hiddenJobInvitationId" name="id" value="">
                                <button type="button" class="btn btn-block btn-outline-warning btn-sm ripple-effect-dark text-uppercase" onclick="declineModal(<?php echo e($applicationData->id); ?>);">DECLINE</button>
                        </div>
                    </div>
                <?php elseif($applicationData->status == 'decline'): ?>
                    <div class="d-flex justify-content-center">
                       <button type="button" class="btn d-inline-block btn-outline-success ripple-effect-dark btn-sm text-uppercase" disabled>Declined</button>
                    </div> 
                <?php elseif($applicationData->status == 'accepted'): ?>
                    <div class="d-flex justify-content-center">
                        <a href="video-interviews.php"  class="btn d-inline-block btn-outline-success ripple-effect-dark btn-sm text-uppercase">Record</a>
                    </div>
                <?php elseif($applicationData->status == 'interview_submitted'): ?>
                    <div class="d-flex justify-content-center">
                       <button type="button" class="btn d-inline-block btn-outline-success ripple-effect-dark btn-sm text-uppercase" disabled>Submitted</button> 
                    </div>
                <?php endif; ?>
               </div>
        
            <div class="job_footer d-flex justify-content-between">
                <a href="<?php echo e(url('/company-profile/'.$applicationData->getJob->user_id.'/'.\App\Helpers\Utility::makeslug($applicationData->getJob->getUser->company_name))); ?>" class="font-md">View Company Profile</a>
                <a href="<?php echo e(url('/view-job/'.$applicationData->job_id.'/'.\App\Helpers\Utility::makeslug($applicationData->getJob->job_title))); ?>" class="font-md color-yellow">View Job</a>
            </div>
        </div>        
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php else: ?>
<div class="row">
    <div class="col-xl-12">
        <?php echo e(\App\Helpers\Utility::emptyListMessage('invitation')); ?>

    </div>
</div>
<?php endif; ?>
<?php echo e($myApplicationData->links('vendor.pagination.simple-default')); ?>

<script>
    $(document).ready(function () {
        $('#spinner').hide();
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var pageLink = $(this).attr('href');
            $('#spinner').show();
            $.ajax({
                type: 'GET',
                url: pageLink,
                async: false,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#requestReceivedlist").append(response);
                    $('#spinner').hide();
                }
            });
        });
    });
</script>
