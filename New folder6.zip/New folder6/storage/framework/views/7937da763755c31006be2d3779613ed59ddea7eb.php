<?php
if (count($blogs) > 0) {
    foreach ($blogs as $blog) {
        ?>
        <div class="col-sm-6 col-md-6 col-lg-4">
            <div class="blog_list">
                <div class="card">
                     <div class="card-head" style="background-image: url('<?php echo e($blog->image); ?>');">
                      
                    </div> 
                    <div class="card-body card_contant">
                        <a class="color-black" href="<?php echo e(url('blog-detail',$blog->id)); ?>"><h5 class="card-title b-pink"><?php echo $blog->title ?></h5>
                            <h4 class="crad_time">
                                <?php 
                                $datetime = App\Common\Utility::converToTz($blog->created_at);
                                echo $datetime->format('F d Y')
                                 ?>
                            </h4>
                            <p class="card-text"><?php echo $blog->meta_description; ?></p>
                            <a class="blog_read" href="<?php echo e(url('blog-detail',$blog->id)); ?>">Read More</a>
                            <div class="card-bottom">
                                <ul class="list-inline mb-0 action">
                                    <li class="list-inline-item">
                                        <a href="javascript:void(0);" onclick="openModalone('<?php echo $blog->id ?>')">
                                            <i class="fa fa-heart"></i><span><?php echo e($blog->like_count); ?></span>
                                        </a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="<?php echo e(url('blog-detail',$blog->id)); ?>"><i class="fa fa-comment"></i> <span><?php echo e($blog->comment_count); ?></span></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <div class="share-button">
                                            <input class="toggle-input" id="toggle-input01_<?php echo $blog->id ?>" type="checkbox" name="share" />
                                            <label for="toggle-input01_<?php echo $blog->id ?>" class="toggle"></label>
                                            <ul class="network-list">
                                                <li class="twitter">
                                                    <a href="javascript:void(0);" id="share-button-twitter_<?php echo e($blog->id); ?>"class='share-button-twitter'>Share on Twitter</a>
                                                </li>
                                                <li class="facebook">
                                                    <a href="javascript:void(0);" id="share-button-facebook_<?php echo e($blog->id); ?>" class='share-button-facebook'>Share on Facebook</a>
                                                </li>
                                                <li class="googleplus">
                                                    <a href="javascript:void(0);" id="share-button-google_<?php echo e($blog->id); ?>" class='share-button-google'>Share on Google+</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            $("#share-button-twitter_<?php echo $blog->id ?>").jsSocials({
                url: "<?php echo e(url('blog-detail',$blog->id)); ?>",
                text: '<?= str_replace("'", "", $blog->title); ?>',
                showLabel: false,
                showCount: false,
                shareIn: "popup",
                shares: ["twitter"]
            });
            $("#share-button-facebook_<?php echo $blog->id ?>").jsSocials({
                url: "<?php echo e(url('blog-detail',$blog->id)); ?>",
                text: '<?= str_replace("'", "", $blog->title); ?>',
                showLabel: false,
                showCount: false,
                shareIn: "popup",
                shares: ["facebook"]
            });
            $("#share-button-google_<?php echo $blog->id ?>").jsSocials({
                url: "<?php echo e(url('blog-detail',$blog->id)); ?>",
                text: '<?= str_replace("'", "", $blog->title); ?>',
                showLabel: false,
                showCount: false,
                shareIn: "popup",
                shares: ["googleplus"]
            });

        </script>
        <?php
    }
} else {
    ?>
    <div class="col-sm-12 alert alert-danger"><center>No Blogs Available!</center></div>
<?php } ?>
<?php if($blogs->hasMorePages()): ?>
<div class="col-sm-12">
    <div class="loader text-center">
        <?php echo e($blogs->links()); ?>

    </div>
</div>
<?php endif; ?>
<script>

//    $(document).ready(function () {
    setTimeout(function () {
        $("ul.pagination li").first().remove();
        $("ul.pagination").addClass('d-block');
    }, 500);
    $(".pagination li a").on('click', function (e) {
        $(".pagination li a").attr("disabled", true);
        $(".pagination li a").html('<i class="fa fa-spin fa-spinner"></i> LOAD MORE');
        $(".pagination").parent().parent().remove();
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        var token = '<?php echo e(csrf_token()); ?>';
        $.ajax({
            type: 'GET',
            url: pageLink,
            data: {_token: token},
            success: function (response) {
                $('.pagination:first').remove();
                $('#blog_listtt').append(response.html);
            }
        });
        $('.pagination:first').remove();
    });
    $(".pagination li a").addClass('');
    $(".pagination li a").html('<i class=""></i> LOAD MORE');
//    });


</script>