<?php $__env->startSection('title', 'Citizens View'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray" onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content citizens_view common-grid-list" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent">
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Citizen's Detail</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a id="back-loader" href="<?php echo e(url('admin/citizens')); ?>" class="nav-link" onclick="backloader()" title="Back"><i class="fa fa-long-arrow-left"></i>
              </a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <div class="view_sec clearfix">
            <div class="form-group">
              <div class="profileimg">
                <?php if(!empty($view->profile_picture)): ?>
                  <img id="uploadimg" class="rounded-circle avtar img-thumbnail" src="<?php echo e(url('public/uploads/'.$view->profile_picture)); ?>" alt="profile img">
                <?php else: ?>
                  <img id="uploadimg" class="rounded-circle avtar img-thumbnail" src="<?php echo e(url('public/assets/images/preview_img.jpg')); ?>" alt="profile img">
                <?php endif; ?>
              </div>
            </div>
            <input id="users_id" type="hidden" name="user_id" value="<?php echo e($view->id); ?>">
            <div class="view_detail">
              <h2><?php echo e(ucfirst($view->first_name)); ?> <?php echo e(ucfirst($view->last_name)); ?></h2>
              <h4><?php echo e($view->business_name); ?></h4>
              <ul class="list-inline">
                <?php if($view->phone): ?>
                  <li class="list-inline-item"><i class="fa fa-phone"></i> <span><?php echo e($view->phone); ?></span></li>
                <?php endif; ?>
                <?php if($view->email): ?>
                  <li class="list-inline-item"><i class="fa fa-envelope"></i> <span><a><?php echo e($view->email); ?></a></span></li>
                <?php endif; ?>
              </ul>
              <ul class="list-inline">
                <?php if($view->gender): ?>
                  <li class="list-inline-item"><i class="fa fa-user"></i> <span><?php echo e($view->gender); ?></span></li>
                <?php endif; ?>
                <?php if($view->ethnicity != 7): ?>
                  <?php if($view->ethnicity_name): ?>
                    <li class="list-inline-item"><i class="fa fa-users"></i> 
                      <span><?php echo e($view->ethnicity_name); ?></span>
                    </li>
                  <?php endif; ?>
                  <?php else: ?>
                    <?php if($view->other_ethnicity): ?>
                      <li class="list-inline-item"><i class="fa fa-users"></i> <span><?php echo e($view->other_ethnicity); ?></span></li> 
                    <?php endif; ?>
                <?php endif; ?>
              </ul>
              <?php if($view->city_name OR $view->states_name OR $view->zipcode): ?>
                <p>
                  <i class="fa fa-building"></i>
                  <b> <?php echo e($view->city_name); ?> <?php echo e($view->states_name); ?> <?php echo e($view->zipcode); ?></b>
                </p>
              <?php endif; ?>
            </div>
          </div>
          <div class="common_tabs">
            <ul class="nav nav-pills mb-4" id="pills-tab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="pills-history-tab" data-toggle="pill" href="#pills-history" role="tab" aria-controls="pills-history" aria-selected="true">Subscription History </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="pills-payment-tab" data-toggle="pill" href="#pills-payment" role="tab" aria-controls="pills-payment" aria-selected="false"> Downloads </a>
              </li>
            </ul>
            <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane fade show active" id="pills-history" role="tabpanel" aria-labelledby="pills-history-tab">
                <div class="table-responsive" id="subscription_history">
                  
                </div>
              </div>
              <div class="tab-pane fade" id="pills-payment" role="tabpanel" aria-labelledby="pills-payment-tab">
                <div class="table-responsive" id="download_history">
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  <script type="text/javascript">

    function backloader()
    {
      $("#back-loader").attr("disabled", true);
      $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    };

    $(document).ready(function ()
    { 
      $("#subscription_history").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var token = ('<?php echo e(csrf_token()); ?>');
      var id = $('#users_id').val();
      $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/load-subscription-history')); ?>/"+id,
                data: {_token:token},
                success: function (response)
                {
                  $("#subscription_history").html(response.html);
                  // $('#data_table').DataTable({
                  //   searching: false,
                  //   "order": [],
                  //   "columnDefs": [{"targets"  : [],"orderable": false,}],
                  // });
                }
        });
    });

    $(document).ready(function ()
    { 
      $("#download_history").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var token = ('<?php echo e(csrf_token()); ?>');
      var id = $('#users_id').val();
      $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/load-download-history')); ?>/"+id,
                data: {_token:token},
                success: function (response)
                {
                  $("#download_history").html(response.html);
                  $('#data_table').DataTable({
                    searching: false,
                    "order": [],
                    "columnDefs": [{"targets"  : [],"orderable": false,}],
                  });
                }
        });
    });

  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>