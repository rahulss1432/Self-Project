<?php
  $homebanner = \App\Models\Setting::getHomebanner();
  $hometitle = \App\Models\Setting::getHometitle();
  $hometag = \App\Models\Setting::getHometag();
  $url = url('/blog');
?>
<header class="topheader homeheader">
            <nav class="navbar navbar-expand-md navbar-light" id="nav">
                <div class="container">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(url('public/assets/images/logo.png')); ?>" class="img-fluid" alt="logo">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#homenav" aria-controls="homenav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse  navbar-collapse " id="homenav">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item ">
                                <a class="nav-link" href="#home"><span data-hover="Home">Home</span></a>
                            </li>
                            <li class="nav-item separator">
                                |
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="#aboutus"><span data-hover="About us">About us </span></a>
                            </li>
                            <li class="nav-item separator">
                                |
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#features"><span data-hover="Features">Features</span></a>
                            </li>
                            <li class="nav-item separator">
                                |
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#howitworks"><span data-hover="How it Works">How it Works</span></a>
                            </li>
                            <li class="nav-item separator">
                                |
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#blog"><span data-hover="Blogs">Blogs</span></a>
                            </li>
                            <li class="nav-item separator">
                                |
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#faq"><span data-hover="FAQs">FAQs</span></a>
                            </li>
                            <li class="nav-item separator">
                                |
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#contactus"><span data-hover="Contact Us">Contact Us</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

            <div id="home">
                <div class="banner_content">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="info">
                                    <!-- <h1>At vero eos<br class="d-none d-md-block d-lg-block"> et accusamus <br class="d-none d-md-block d-lg-block">Et iusto odio</h1> -->
                                    <h1><?php  echo($homebanner->key_value)  ?></h1>
                                    <p><?php  echo($hometitle->key_value)  ?>
                                       <span class="d-block"><?php  echo($hometag->key_value)  ?></span>
                                    </p>
                                    <div class="app_btn">
                                        <a href="javascript:void(0);">
                                            <img src="<?php echo e(url('public/assets/images/android_btn.png')); ?>" alt="button">
                                        </a>
                                        <a href="javascript:void(0);">
                                            <img src="<?php echo e(url('public/assets/images/ios_btn.png')); ?>" alt="button">
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 d-none d-md-block">
                                <div class="aapimg">
                                    <img src="<?php echo e(url('public/assets/images/homeapp_img.png')); ?>" class="img-flu id" alt="">
                                </div>  
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>