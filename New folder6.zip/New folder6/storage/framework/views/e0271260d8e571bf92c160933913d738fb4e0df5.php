<?php $__env->startSection('title','Add Blog'); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content adduser_page">
		<div class="content_wrapper">
			<div class="page_title">
				<h2 class="d-inline-block pr-3 mr-3 border-right">Add Blog</h2>
				<nav aria-label="breadcrumb" class="d-inline-block">
					<ol class="breadcrumb p-0 mb-0">
						<li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Home</a>
						</li>
						<li class="breadcrumb-item"><a href="<?php echo e(url('/admin/manage-blog')); ?>">Manage Blog</a>
						</li>
						<li class="breadcrumb-item">Add Blog</li>
					</ol>
				</nav>
			</div>
			<div class="add_details">
				<div class="card">
					<div class="card-header">Add Blog Details</div>
					<div class="card-body">
						<form method="post" id="blogForm" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

							<div class="field_content">
								<div class="field_box">
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<label>Blog Title</label>
												<input type="text" class="form-control" name="blog_title">
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label class="d-block" for="uploadFile">Upload Image / Video
													<div class="uploadIcon">
														<span class="form-control" id="fileName"></span>
														<input id="uploadFile" type="file" hidden name="blog_images[]" multiple>
													</div>
												</label>
											</div>
										</div>
										<div class="col-12 order-3 order-sm-3">
											<ul class="list-inline preview-images" id="uploadImages">
												<!-- <li class="list-inline-item">
													<div class="preview-img">
														<a href="javascript:void(0);" class="remove-it"><i class="flaticon-cancel-music"></i></a>
														<img src="images/book.png" alt="book" class="img-fluid">
													</div>
												</li> -->
											</ul>
										</div>
									</div>
									<div class="form-group">
										<label>Add Meta Description</label>
										<textarea  class="form-control" rows="4" name="blog_description"></textarea>
									</div>
									<div class="form-group">
										<label>Content</label>
										<textarea  class="form-control" rows="4" name="blog_content"></textarea>
									</div>
									<div class="form-group  text-right mb-0">
							 			<button type="button" id="btnBlog" class="btn btn-success rounded-0 ripple-effect">Save
											<i style="display:none;" class="btn_loader"></i>
							 			</button>
							 			<a href="manage-blog.php" class="btn btn-dark rounded-0 ripple-effect ml-2">Cancel</a>
							 		</div>
								</div>
							</div>
					    </div>
					</form>
				</div>
			</div>
		</div>
	</div>
	</div>
    <?php echo JsValidator::formRequest('App\Http\Requests\BlogRequest','#blogForm'); ?>

<script>
$("#btnBlog").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btnBlog');
        var form = $('#blogForm');
        if (form.valid()) {
            btn.html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?> Save');
            btn.prop('disabled', true);
            $.ajax({
                url: "<?php echo e((url('/admin/add-blog-form'))); ?>",
                type: "POST",
                data: form.serialize(),
                success: function (data)
                {
                   window.location.href = "<?php echo e(url('admin/add-blogs')); ?>";
                   btn.prop('disabled', false);
                },
                error: function (data) {
                },
            });
        }
    }));

    $(document).ready(function() {
     if(window.File && window.FileList && window.FileReader) {
      $("#uploadFile").on("change",function(e) {
        var files = e.target.files ,
        filesLength = files.length ;
        for (var i = 0; i < filesLength ; i++) {
        var f = files[i]
        var fileReader = new FileReader();
        fileReader.onload = (function(e) {
        var file = e.target;
        $('#uploadImages').append('<li class="list-inline-item" id="imgList"><div class="preview-img"><a href="javascript:void(0);" id="removeImage" class="remove-it"><i class="flaticon-cancel-music"></i></a><img src="'+e.target.result+'" class="img-fluid"></div></li>');
        });
        fileReader.readAsDataURL(f);
        }
      });
     }
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>