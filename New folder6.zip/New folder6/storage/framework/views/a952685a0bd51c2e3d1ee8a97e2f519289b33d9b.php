<?php if(count($history) > 0): ?>  
  <table class="table table-bordered viewtable">
    <thead>
      <tr>
        <th>SUBSCRIPTION NAME</th>
        <th>START DATE</th>
        <th>BILLING DATE</th>
        <th>REGULAR PRICE</th>
        <th>PAYMENT MODE</th>
        <th>SUBSCRIPTION STATUS</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e('transaction'.$data->id); ?>">
          <td class="text-capitalize"><?php echo e($data->plan_name); ?></td>
          <td><?php echo e($data->start_date); ?></td>
          <td><?php echo e($data->billing_date); ?></td>
          <td>$ <?php echo e($data->price); ?></td>
          <td class="text-capitalize"><?php echo e($data->payment_mode); ?></td>
          <?php if($data->status == 'active'): ?>
            <td><span class="color-green"><?php echo e(ucfirst($data->status)); ?></span></td>
            <?php else: ?>
              <td><span class="color-red"><?php echo e(ucfirst($data->status)); ?></span></td>
          <?php endif; ?>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php else: ?>
    <div class="alert alert-danger"><center>No subscription available of this citizen.</center></div>
<?php endif; ?>