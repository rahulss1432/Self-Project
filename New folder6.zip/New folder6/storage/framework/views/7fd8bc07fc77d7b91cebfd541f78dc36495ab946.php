<form id="portfolioForm" method="POST" action="<?php echo e(url('/user/save-portfolio')); ?>" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo e($model->id); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="d-flex justify-content-between">
                <h2 class="page-title mt-0">Add Project</h2>
                <a href="javscript:void(0);" id="projectAddBtn" class="text-uppercase btn btn-sm btn-success mb-3 add-portfolio" style="display: none">add project</a>
            </div>
        </div>
        <!-- xxxxxxxxxxx -->
        <div class="col-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <input type="text" name="project_title" value="<?php echo e($model->project_title); ?>" class="form-control" placeholder="Project Title">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <input type="text" name="project_type" value="<?php echo e($model->project_type); ?>" class="form-control" placeholder="Project Type">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <input type="text" name="duration" value="<?php echo e($model->duration); ?>" class="form-control" placeholder="Duration">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <input type="text" name="client_details" value="<?php echo e($model->client_details); ?>" class="form-control" placeholder="Client details">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group currency-group">
                        <input type="text" name="project_amount" value="<?php echo e($model->project_amount); ?>" class="form-control" placeholder="Project amount in USD">
                        <span class="currency">USD</span>
                    </div>
                </div>
                
                <div class="col-md-12" id="desc-list">
                    <?php if($model->project_links != ''): ?>
                        <?php $projectLinks = explode(',',$model->project_links);?>
                        <?php if(!empty($projectLinks)): ?>
                            <?php $__currentLoopData = $projectLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($link != ''): ?>
                                    <div class="form-group link-group" >
                                        <input type="text" name="project_links[]" value="<?php echo e($link); ?>" class="form-control link-value" id="linkValue" placeholder="Project Link">
                                        <span>
                                            <a href="javascript:void(0);" class="add-link link-disabled" onclick="deleteRow($(this))" id="deleteLinks">
                                                <img src="<?php echo e(url("public/images/remove-icon.png")); ?>" alt="add">
                                            </a>
                                        </span>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>

                    <div class="form-group link-group">
                        <input type="text" name="project_links[]" class="form-control link-value" id="linkValue" placeholder="Project Link">
                        <span>
                            <a href="javascript:void(0);" class="add-link link-disabled add-btn" onclick="addMore($(this));" data-toggle="tooltip" data-placement="top" title="Add Link" id="addLinks">
                                <img src="<?php echo e(url('public/images/add-icon.png')); ?>" alt="add">
                            </a>
                        </span>
                    </div>
                </div>
                
               
                <div class="col-md-12">
                    <div class="form-group">
                        <textarea rows="4" name="description" class="form-control" placeholder="Description"><?php echo e($model->description); ?></textarea>
                    </div>
                </div>
                <!-- field-heading -->
                <div class="col-12">
                    <label class="field-heading font-md d-block w-100">Upload Document</label>
                </div>
                <div class="col-md-12">
                    <label class="upload-btn">
                        <input type="file" name="documents[]" multiple hidden>
                        <p href="javascript:void(0);" class="text-uppercase btn-success ripple-effect-dark btn mb-0">
                            <img src="<?php echo e(url('public/images/upload-ic.png')); ?>" alt="">
                            <small>upload document</small>
                        </p>
                    </label>
                    <div class="note mb-3">
                        <p class="font-rg mb-1">File upload in Docx, PDF, JPEG
                            <span style="font-family: sans-serif;">&</span> JPG format
                        </p>
                        <span id="documents-error" class="help-block error-help-block"></span>
                    </div>
                </div>
            </div>
        </div>
        <!-- xxxxxxxxxxx -->
        <div class="col-12">
            <div id="addon-portfolio"></div>
        </div>
        <?php if(empty($model->id)): ?>
        <div class="col-md-12 btn-row">
            <a id="btn-portfolio" href="javscript:void(0);" class="text-uppercase btn btn-success add-portfolio" id="addPortfolio">add more</a>
            <a href="skills.php" class="text-uppercase btn btn-warning ml-0 ml-sm-3"> save
                <span class="and-font">&</span> continue</a>
        </div>
        <?php else: ?>
            <button id="btn-portfolio" class="btn btn-success">Update</button>
            <button type="button" class="btn btn-warning ml-md-3" onclick="actionPortfolio(0)">Cancel</button>
        <?php endif; ?>
    </div>
    <!-- row end -->
</form>
<?php echo JsValidator::formRequest('App\Http\Requests\PortfolioRequest','#portfolioForm'); ?>

<script>
    $("#btn-portfolio").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btn-portfolio');
        var form = $('#portfolioForm');
        if (form.valid()) {
        btn.html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?> Submit');
            btn.prop('disabled', true);
            $.ajax({
            url: "<?php echo e((url('/user/portfolio-submit'))); ?>",
                type: "POST",
                data: new FormData($('#portfolioForm')[0]),
                contentType: false,
                cache: false,
                processData: false,
                success: function (data)
                {
                    successToaster(data.message, 'Portfolio');
                    loadPortfolioList();
                    actionPortfolio(0);
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    obj = obj['errors'];
                    for (var x in obj) { 
                        console.log(x);
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        if(x == 'documents.0'){
                            $('#documents-error').show();
                            $('#documents-error').html(obj[x]);
                        }
                        $('#' + x + '-error').show();
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));

    $('#portfolioForm').on('submit', function (e) {
        if ($('#portfolioForm').valid()) {
            $('#submitBtn').html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?>  Save & Next');
            $("#submitBtn").prop('disabled', true);
        }
    });
</script>