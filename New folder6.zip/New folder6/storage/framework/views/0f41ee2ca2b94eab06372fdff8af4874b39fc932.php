<?php $__env->startSection('title','Subscription Plans'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-wrapper dashboard-main-wrap" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Subscriptions</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">Subscription Plans</h3>
                    <ul class="list-inline mb-0 ml-auto">
                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                            <a href="#searchFilter" data-toggle="collapse" class="nav-link ripple-effect-dark">
                                <i class="fa fa-filter"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="<?php echo e(url('admin/add-plan')); ?>"  class="nav-link ripple-effect-dark" data-toggle="tooltip" data-placement="top" title="Add New Plan">
                                <i class="fa fa-plus"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body p-0">
                    <div class="filter_section collapse" id="searchFilter">
                        <form id="frmFilter">
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <select name="user_type" class="selectpicker form-control">
                                            <option value="">Select User Type</option>
                                            <?php if(!empty($userType)): ?>
                                                <?php $__currentLoopData = $userType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($type->user_type); ?>"><?php echo e($type->label_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                    <button type="button" class="btn btn-success ripple-effect-dark mr-2" onclick="loadPlanList();">Filter</button>
                                    <button type="button" class="btn btn-warning ripple-effect-dark" onclick="resetFilter();">Reset</button> 
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="table-responsive hide_filter_page">
                        <div class="text-center" id="planList">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="planModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="addCandidateModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCandidateModal">Subscription Plan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>

            </div>
            <div class="modal-body">
                <div id="plan-form">

                </div>
            </div>
            <div class="modal-footer">
                <button id="btn-plan" type="submit" class="btn ripple-effect-dark btn-success btn-sm text-uppercase">Submit</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        loadPlanList();
    });

    function loadPlanList() {
        $("#planList").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('/admin/load-plan-list')); ?>",
            data: $('#frmFilter').serialize(),
            success: function (response)
            {
                $("#planList").html(response);
            }
        });
    }

    function actionPlan(id) {
        $('#planModal').modal('show');
        $("#plan-form").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('admin/get-plan-form')); ?>",
            data: {id: id},
            success: function (response) {
                $('#plan-form').html(response);
            }
        });
    }
    
    function resetFilter(){
        $('#frmFilter')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadPlanList();
    }
</script>
<!-- category model start -->
<!--<div class="modal fade" id="planModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="addskillsModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addskillsModal">Subscription Plan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="plan-form"></div>
            </div>
        </div>
    </div>
</div>-->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>