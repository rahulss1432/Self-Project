<?php $__env->startSection('title', 'Broadcasted Videos'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray" onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content common-grid-list" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent">
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Broadcasted Videos</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a id="add-loader" onclick="addfunction()" href="<?php echo e(url('admin/add-videos')); ?>" class="nav-link"><i class="fa fa-plus"></i></a>
            </li>
            <li class="list-inline-item">
              <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="fa fa-search"></i></a>
            </li>
          </ul>
        </div>
        <div class="card-body ">
          <div class="filter_section collapse show" id="searchFilter">
            <form id="search_form" action="javascript:load_videos_list()" method="POST" autocomplete="off">
              <?php echo e(csrf_field()); ?>

              <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-">
                  <div class="form-group">  
                     <label class="control-label">Start Date - End Date</label>
                    <input type="text" id="daterange" class="form-control form-control-lg " name="datefilter" readonly required="" value="" / >
                  </div>
                </div> 
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-">
                  <div class="form-group">
                    <label class="control-label">Location</label>
                    <input type="text" id="video_location" name="location" class="form-control form-control-lg"/>
                  </div>
                </div> 
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-">
                  <div class="form-group">
                    <label class="control-label">Video Title</label>
                    <input type="text" id="video_title" name="title" class="form-control form-control-lg"/>
                  </div>
                </div> 
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-">
                  <div class="form-group">
                    <label class="control-label">Posted by</label>
                    <input type="text" id="user_name" name="name" class="form-control form-control-lg"/>
                  </div>
                </div> 
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-">
                  
                  <div class="form-group d-inline-block mr-2">
                    <label class="btn-block d-none d-lg-block">&nbsp;</label>
                    <button class="btn btn-primary" type="submit">Filter</button>                         
                  </div>
                  <div class="form-group d-inline-block mr-2">
                    <label class="btn-block d-none d-lg-block">&nbsp;</label>
                    <input type="reset" id="reset-btn" class="btn btn-primary" value="reset">
                  </div>
                </div> 
              </div>
            </form>
          </div>
          <div class="table-responsive" id="video_list">                
          </div>
        </div>
      </div>
    </div>
  </main>

  <script type="text/javascript">

    $(document).ready(function ()
    {
        load_videos_list();
    });

    function addfunction()
    {
      $("#add-loader").attr("disabled", true);
      $("#add-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    };

    function viewfunction(id)
    {
      $("#view-loader"+id).attr("disabled", true);
      $("#view-loader"+id).html('<i class="fa fa-spinner fa-spin"></i>');
    }

    function editfunction(id)
    {
      $("#edit-loader"+id).attr("disabled", true);
      $("#edit-loader"+id).html('<i class="fa fa-spinner fa-spin"></i>');
    }

    $( "#reset-btn" ).click(function() 
    {
      $('#daterange').val('').change();
      $('#video_location').val('').change();
      $('#video_title').val('').change();
      $('#user_name').val('').change();
      load_videos_list();
    });

    function deletefunction(id)
    {
      bootbox.confirm('Are you sure do you want to delete this video?', function (result)
      { 
        if (result)
        {
          $.ajax({
                  type: "GET",
                  url: "<?php echo e(url('admin/delete-video')); ?>/" + id,
                  success: function(response)
                  {
                    if (response)
                    {
                      toastr.remove();
                      toastr.options.closeButton = true;
                      toastr.success('Video deleted successfully', 'Success', {timeOut: 1000});
                      document.getElementById('video'+id).style.display = 'none';
                    }
                    else
                    {
                      toastr.remove();
                      toastr.options.closeButton = true;
                      toastr.error('Something went wrong', 'Error', {timeOut: 1000});
                    }
                  }
                });
        }
      });
    }

    function load_videos_list()
    {
        $("#video_list").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
        var search_filter=$("#search_form").serializeArray();
            search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
        $.ajax({
                  type: "POST",
                  url: "<?php echo e(url('admin/load-videos-list')); ?>",
                  data: search_filter,
                  success: function (response)
                  {
                    $("#video_list").html(response.html);
                    $('#data_table').DataTable({
                                                  searching: false,
                                                  "order": [],
                                                  "columnDefs": [{
                                                                    "targets"  : [9],
                                                                    "orderable": false,
                                                                }],
                                              });
                  }
              });
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>