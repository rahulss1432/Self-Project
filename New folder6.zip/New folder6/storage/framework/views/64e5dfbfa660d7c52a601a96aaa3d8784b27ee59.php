<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Aging MBB Admin Login</title>
        <!-- Bootstrap -->
        <?php echo $__env->make('layouts.admin.head-link', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body class="login-page ">
        <main >
            <div class="login-wrap mx-auto">
                <div class="login-header d-flex align-items-center justify-content-center">
                    <img src="<?php echo e(url('public/images/logo.png')); ?>" alt="logo">
                </div>
                <h3 class="title">Sign In</h3>
                <div class="login-field">
                    <form id="admin-login-frm" method="POST" action="javascript:void(0);">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <input type="email" class="form-control form-control-lg" name="email" placeholder="Email">

                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control form-control-lg" name="password" placeholder="Password">
                        </div>

                        <div class="form-group text-center">
                            <button id="admin-login-btn" type="submit" class="btn btn-dark btn_radius btn-block ripple-effect">LOGIN</button>
                        </div>
                    </form>
                </div>
                <div class="login-footer text-right">
                    <a href="<?php echo e(url('/admin/forgot-password')); ?>">FORGOT PASSWORD? <span class="fa fa-long-arrow-right"></span></a>
                </div>
            </div>
        </main>
        <?php echo JsValidator::formRequest('App\Http\Requests\LoginRequest','#admin-login-frm'); ?>

        <script>
            $("#admin-login-btn").on('click', (function (e) {
                var frm = $('#admin-login-frm');
                var btn = $('#admin-login-btn');
                if (frm.valid()) {
                    btn.html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?> Login');
                    btn.prop('disabled', true);
                    $.ajax({
                        url: "<?php echo e(url('/admin-login')); ?>",
                        type: "POST",
                        data: frm.serialize(),
                        success: function (data)
                        {
                            btn.prop('disabled', false);
                            location.reload();
                        },
                        error: function (data) {
                            var obj = jQuery.parseJSON(data.responseText);
                            for (var x in obj) {
                                btn.prop('disabled', false);
                                btn.html('LOGIN');
                                var errors = obj[x].length
                                $('#' + x + '-error').html(obj[x]);
                                $('#' + x + '-error').css("color", '#b30000');
                                $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                            }
                        },
                    });
                }
            }));
        </script>
    </body>
</html>

