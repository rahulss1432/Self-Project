<?php

/*
  |--------------------------------------------------------------------------
  | User Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */


Route::get('/dashboard', ['as' => 'user.dashboard', 'uses' => 'DashboardController@index']);

Route::get('/change-password', ['as' => 'user.change-password', 'uses' => 'ChangePasswordController@changePasswordForm']);
Route::post('/password-change', ['uses' => 'ChangePasswordController@passwordChange']);

Route::get('/payment-history', ['as' => 'user.payment-history', 'uses' => 'PaymentHistoryController@index']);
Route::post('/get-payment-history', ['uses' => 'PaymentHistoryController@getPaymentHistory']);

Route::get('/notifications', ['as' => 'user.notifications', 'uses' => 'NotificationController@index']);
Route::post('/load-notifications', ['uses' => 'NotificationController@loadNotifications']);

Route::get('/post-job/{id?}', ['as' => 'user.postjob', 'uses' => 'JobSettingController@postAJob']);
Route::post('/add-a-job', ['uses' => 'JobSettingController@addAJob']);
Route::get('/posted-jobs', ['as' => 'user.posted-jobs', 'uses' => 'JobSettingController@postedJobs']);
Route::get('/get-posted-jobs', ['uses' => 'JobSettingController@getPostedJobs']);
Route::post('/get-job-skills', ['uses' => 'JobSettingController@getSkillsByIndustry']);


Route::get('/my-plan', ['as' => 'user.my-plan', 'uses' => 'PaymentHistoryController@myPlan']);
Route::post('/get-paln-list', ['uses' => 'PaymentHistoryController@getPlanList']);

Route::get('/edit-profile', ['as' => 'user.edit-profile', 'uses' => 'ProfileController@editProfile']);
Route::post('/update-profile', 'ProfileController@updateProfile');
Route::post('/save-profile-image', 'ProfileController@saveProfileImage');
Route::post('/update-company', 'ProfileController@updateCompany');



Route::get('/portfolio', ['as' => 'user.portfolio', 'uses' => 'ProfileController@editPortfolio']);
Route::get('/get-portfolio-form', ['uses' => 'ProfileController@getPortfolioForm']);
Route::get('/get-portfolio-list', ['uses' => 'ProfileController@getPortfolio']);
Route::post('/portfolio-submit', ['uses' => 'ProfileController@portfolioSubmit']);
Route::get('/delete-portfolio', ['uses' => 'ProfileController@deletePortfolio']);
Route::post('/save-portfolio', ['uses' => 'ProfileController@savePortfolio']);

Route::get('/skills', ['as' => 'user.skills', 'uses' => 'ProfileController@editSkills']);

Route::get('/education', ['as' => 'user.education', 'uses' => 'ProfileController@editEducation']);
Route::get('/get-education-form', ['uses' => 'ProfileController@getEducationForm']);
Route::get('/get-education-list', ['uses' => 'ProfileController@getEducation']);
Route::post('/education-submit', ['uses' => 'ProfileController@educationSubmit']);
Route::post('/save-education', ['uses' => 'ProfileController@saveEducation']);
Route::get('/delete-education', ['uses' => 'ProfileController@deleteEducation']);

Route::get('/promo-video', ['as' => 'user.promo-video', 'uses' => 'ProfileController@editPromoVideo']);
Route::get('/delete-promo-video', ['uses' => 'ProfileController@deletePromoVideo']);

Route::get('/experience', ['as' => 'user.experience', 'uses' => 'ProfileController@editExperience']);
Route::get('/get-experience-form', ['uses' => 'ProfileController@getExperienceForm']);
Route::get('/get-experience-list', ['uses' => 'ProfileController@getExperience']);
Route::get('/get-skills-list/{id}', ['uses' => 'ProfileController@getSkillsByIndustry']);
Route::post('/experience-submit', ['uses' => 'ProfileController@experienceSubmit']);
Route::get('/delete-experience', ['uses' => 'ProfileController@deleteExperience']);
Route::post('/save-experience', ['uses' => 'ProfileController@saveExperience']);

Route::post('/submit-about-experience', ['uses' => 'ProfileController@saveAboutExperience']);
Route::post('/upload-video', ['uses' => 'ProfileController@uploadVideo']);

Route::get('/view-profile', ['as' => 'user.view-profile', 'uses' => 'ProfileController@viewProfile']);
Route::post('/submit-about-experience', ['uses' => 'ProfileController@saveAboutExperience']);
Route::post('/submit-about-experience', ['uses' => 'ProfileController@saveAboutExperience']);
Route::post('/user-skills-submit', ['uses' => 'ProfileController@saveUserSkills']);

Route::get('/view-matched-candidates/{id}', ['uses' => 'JobSettingController@viewMatchedCandidates']);
Route::post('/load-matched-candidates-list', ['uses' => 'JobSettingController@loadMatchedCandidates']);

Route::get('/view-profile/{id}/{slug}', 'ProfileController@viewUserProfile');
Route::post('/view-video', 'ProfileController@viewUserVideo');

//Applications Routes
Route::get('/applied-jobs', ['as' => 'user.applied-jobs', 'uses' => 'JobApplicationController@index']);
Route::post('/load-my-applied-list','JobApplicationController@getMyAppliedList');

//Invitation Routes
Route::get('/invitation-received', ['as' => 'user.invitation-received', 'uses' => 'JobApplicationController@getInvitations']);
Route::get('/load-request-received-list','JobApplicationController@getUserInvitationList');
Route::post('/decline-invitation','JobApplicationController@declineUserInvitation');

//Video-Profile View Routes
Route::get('/video-views', ['as' => 'user.video-views', 'uses' => 'NotificationController@getVideoViews']);
Route::get('/profile-views', ['as' => 'user.profile-views', 'uses' => 'NotificationController@getProfileViews']);
Route::post('/load-profile-video-view-list','NotificationController@getProfileVideoViewList');
