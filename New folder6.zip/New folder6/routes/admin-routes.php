<?php

/*
  |--------------------------------------------------------------------------
  | Admin Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */
Route::get('/dashboard', ['as' => 'admin.dashboard', 'uses' => 'DashboardController@index']);
Route::post('/change-password', ['as' => 'admin.password', 'uses' => 'ChangePasswordController@changePasswordForm']);
Route::post('/password-change', ['as' => 'admin.password', 'uses' => 'ChangePasswordController@passwordChange']);

//industries routes
Route::get('/industries', ['as' => 'admin.industries', 'uses' => 'IndustryController@index']);
Route::post('/load-industry-list', ['uses' => 'IndustryController@getIndustryList']);
Route::post('/update-industry-status', ['uses' => 'IndustryController@updateIndustryStatus']);
Route::get('/delete-industry', ['uses' => 'IndustryController@deleteIndustry']);
Route::get('/get-industry-form', ['uses' => 'IndustryController@getIndustryForm']);
Route::post('/industry-submit', ['uses' => 'IndustryController@submitIndustry']);
//industries routes
//skill routes
Route::get('/skills', ['as' => 'admin.skills', 'uses' => 'SkillController@index']);
Route::post('/load-skill-list', ['uses' => 'SkillController@getSkillList']);
Route::post('/update-skill-status', ['uses' => 'SkillController@updateSkillStatus']);
Route::get('/delete-skill', ['uses' => 'SkillController@deleteSkill']);
Route::get('/get-skill-form', ['uses' => 'SkillController@getSkillForm']);
Route::post('/skill-submit', ['uses' => 'SkillController@submitSkill']);
Route::post('/skill-csv-import', ['uses' => 'SkillController@importCsv']);
//skill routes
//country routes
Route::get('/countries', ['as' => 'admin.countries', 'uses' => 'CountryController@index']);
Route::post('/load-country-list', ['uses' => 'CountryController@getCountryList']);
Route::post('/update-country-status', ['uses' => 'CountryController@updateCountrtyStatus']);
//country routes
//cms pages
Route::get('/cms-pages', ['as' => 'admin.cms', 'uses' => 'CmsController@getCmsPage']);
Route::get('/edit-cms-page/{slug}', ['as' => 'admin.cms', 'uses' => 'CmsController@editCmsPage']);
Route::post('/update-cms', 'CmsController@updateCmsPage');
//cms pages
//user listings
Route::get('/candidates', ['as' => 'admin.user', 'uses' => 'UserController@candidates']);
Route::get('/freelancer', ['as' => 'admin.user', 'uses' => 'UserController@freelancer']);
Route::get('/employer', ['as' => 'admin.user', 'uses' => 'UserController@employer']);
Route::get('/sub-admin', ['as' => 'admin.user', 'uses' => 'UserController@subAdmin']);
Route::post('/load-user-list', ['as' => 'admin.user', 'uses' => 'UserController@getUserList']);
Route::post('/load-user-form', ['uses' => 'UserController@getEditUserForm']);
Route::post('/update-user-info', ['uses' => 'UserController@updateUserInfo']);
Route::post('/update-user-status', ['as' => 'admin.user', 'uses' => 'UserController@updateUserStatus']);
Route::get('/user-detail/{id}', ['as' => 'admin.user', 'uses' => 'UserController@getUserDetail']);
//user listings
//skill routes
Route::get('/plans', ['as' => 'admin.plans', 'uses' => 'PlanController@index']);
Route::post('/load-plan-list', ['uses' => 'PlanController@getPlanList']);
Route::post('/update-plan-status', ['uses' => 'PlanController@updatePlanStatus']);
Route::get('/delete-plan', ['uses' => 'PlanController@deletePlan']);
Route::get('/get-plan-form', ['uses' => 'PlanController@getPlanForm']);
Route::post('/plan-submit', ['uses' => 'PlanController@submitPlan']);
Route::get('/add-plan', ['uses' => 'PlanController@addPlan']);
Route::get('/edit-plan/{id}', ['uses' => 'PlanController@editPlan']);
//skill routes
//settings routes start
Route::get('/settings', ['as' => 'admin.configuration', 'uses' => 'SettingsController@index']);
Route::post('/load-setting-form', 'SettingsController@loadSettingForm');
Route::post('/setting-submit', 'SettingsController@settingSubmit');
Route::get('/side-menu', ['as' => 'admin.configuration', 'uses' => 'SettingsController@getSideMenuList']);
Route::post('/side-menu-save', 'SettingsController@saveSideMenu');

//settings routes start

Route::get('/payment-history', ['as' => 'admin.payment-history', 'uses' => 'PaymentHistoryController@index']);
Route::post('/load-payment-history', 'PaymentHistoryController@getPaymentList');

//notifications
Route::get('/notification', ['as' => 'admin.notification','uses' => 'NotificationController@index']);
Route::post('/load-notification', ['as' => 'admin.notification','uses' => 'NotificationController@loadNotifications']);

//users
Route::get('/send-mail', ['as' => 'admin.send-mail', 'uses' => 'UserController@userList']);
Route::post('/load-contact-user-list', ['uses' => 'UserController@getContactUserList']);
Route::post('/send-contact-email', ['uses' => 'UserController@sendContactEmail']);

//Question Category routes
Route::get('/question-category', ['as' => 'admin.questionnaire', 'uses' => 'QuestionnaireController@categoryList']);
Route::post('/load-category-list', ['uses' => 'QuestionnaireController@getCategoryList']);
Route::get('/get-category-form', ['uses' => 'QuestionnaireController@getCategoryForm']);
Route::post('/category-submit', ['uses' => 'QuestionnaireController@submitCategory']);
Route::get('/delete-category', ['uses' => 'QuestionnaireController@deleteCategory']);

//question routes
Route::get('/questionnaire', ['as' => 'admin.questionnaire', 'uses' => 'QuestionnaireController@index']);
Route::post('/load-questionnaire-list', ['uses' => 'QuestionnaireController@getQuestionnaireList']);
Route::get('/get-question-form', ['uses' => 'QuestionnaireController@getQuestionForm']);
Route::post('/question-submit', ['uses' => 'QuestionnaireController@submitQuestion']);
Route::get('/delete-question', ['uses' => 'QuestionnaireController@deleteQuestion']);

//testimonial routes
Route::get('/testimonials', ['as' => 'admin.configuration', 'uses' => 'TestimonialController@index']);
Route::get('/load-testimonial-list', ['uses' => 'TestimonialController@getTestimonialList']);
Route::get('/delete-testimonial', ['uses' => 'TestimonialController@deleteTestimonial']);
Route::get('/get-testimonial-form', ['uses' => 'TestimonialController@getTestimonialForm']);
Route::post('/testimonial-submit', ['uses' => 'TestimonialController@submitTestimonial']);

//Languages routes
Route::get('/languages', ['as' => 'admin.languages', 'uses' => 'LanguageController@index']);
Route::post('/load-language-list', ['uses' => 'LanguageController@getLanguageList']);
Route::post('/update-language-status', ['uses' => 'LanguageController@updateLanguageStatus']);
Route::get('/delete-language', ['uses' => 'LanguageController@deleteLanguage']);
Route::get('/get-language-form', ['uses' => 'LanguageController@getLanguageForm']);
Route::post('/language-submit', ['uses' => 'LanguageController@submitLanguage']);
//Languages routes
//closed-job routes
Route::get('/closed-job', ['as' => 'admin.closed-job', 'uses' => 'JobsController@index']);
Route::post('/load-job-list', ['uses' => 'JobsController@getJobList']);


//Banner-Setting Routes
Route::get('/banner-setting/{type}', ['as' => 'admin.configuration', 'uses' => 'BannerSettingController@index']);
Route::post('/load-banner-setting-form', 'BannerSettingController@loadBannerSettingForm');
Route::post('/banner-setting-submit', 'BannerSettingController@bannerSettingSubmit');
//Banner-Setting Routes
