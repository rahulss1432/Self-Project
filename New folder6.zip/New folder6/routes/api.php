<?php

use Illuminate\Http\Request;

/*
  |--------------------------------------------------------------------------
  | API Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register API routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | is assigned the "api" middleware group. Enjoy building your API!
  |
 */

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['namespace' => 'Api'], function() {
    Route::post('/login', 'LoginController@login');
    Route::post('/logout', 'LoginController@onLogout');


    Route::group(['middleware' => 'jwt.auth'], function () {
        Route::get('/logout', 'LoginController@onLogout');
        Route::post('/change-password', 'SettingsController@actionChangePassword');
        Route::post('/user-list', 'SettingsController@getUserList');
        Route::post('/country-list', 'SettingsController@getCountryList');
        Route::post('/industry-list', 'SettingsController@getIndustryList');
        Route::post('/add-industry', 'SettingsController@addIndustry');
        Route::get('/get-industry-byid/{id}', 'SettingsController@getIndustryById');
    });
});
