<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

Auth::routes();


Route::get('paypal/express-checkout', 'Auth\RegisterController@expressCheckout')->name('paypal.express-checkout');
Route::get('paypal/express-checkout-success', 'Auth\RegisterController@expressCheckoutSuccess');
Route::post('paypal/notify', 'Auth\RegisterController@notify');

Route::get('/', ['as' => 'home', 'uses' => 'HomeController@index']);
Route::get('/subscription-plan', ['as' => 'plans', 'uses' => 'HomeController@subscriptionPlan']);
Route::get('/logout', ['uses' => 'Auth\LoginController@logout']);
Route::get('/forgot-password', ['uses' => 'Auth\ForgotPasswordController@showLinkRequestForm']);
Route::post('/send-password-link', ['uses' => 'Auth\ForgotPasswordController@sendPasswordLink']);
Route::get('/reset-password/{token}', ['uses' => 'Auth\ForgotPasswordController@resetPassword']);
Route::post('/update-password', ['uses' => 'Auth\ForgotPasswordController@updatePassword']);
Route::get('/password-changed', ['uses' => 'Auth\ForgotPasswordController@passwordChanged']);


Route::post('/register-sub', ['uses' => 'Auth\RegisterController@create']);
Route::get('/payment', ['uses' => 'Auth\RegisterController@makePayment']);
Route::post('/make-payment', ['uses' => 'Auth\RegisterController@paymentSub']);
Route::get('/registration-success', ['uses' => 'Auth\RegisterController@registrationSuccess']);
Route::get('/user-verification/{token}', ['uses' => 'Auth\RegisterController@userVerification']);

// Admin Auth Routes
Route::get('/admin', ['uses' => 'Auth\Admin\LoginController@index']);
Route::post('/admin-login', ['uses' => 'Auth\Admin\LoginController@login']);
Route::get('/admin/logout', ['uses' => 'Auth\Admin\LoginController@logout']);
Route::get('/admin/forgot-password', ['uses' => 'Auth\Admin\ForgotPasswordController@showLinkRequestForm']);
Route::post('/admin/send-password-link', ['uses' => 'Auth\Admin\ForgotPasswordController@sendPasswordLink']);
Route::get('/admin/reset-password/{token}', ['uses' => 'Auth\Admin\ForgotPasswordController@resetPassword']);
Route::post('/admin/update-password', ['uses' => 'Auth\Admin\ForgotPasswordController@updatePassword']);


//Job Listing Routes
Route::get('/job-listing', ['as' => 'user.job-listing', 'uses' => 'JobListingController@index']);
Route::get('/view-job/{id}/{slug}', ['as' => 'user.job-listing', 'uses' => 'JobListingController@getJobDetails']);
Route::post('/load-job-list', 'JobListingController@getAllJobsList');
Route::post('/get-job-skills-by-industry', 'JobListingController@getSkillsByIndustryForSearching');

Route::get('/company-profile/{id}/{slug}', ['uses' => 'JobListingController@getCompanyDetails']);

//Social login Routes
Route::get('/login/{social}', 'Auth\SocialLoginController@socialLogin')->where('social', 'twitter|facebook|linkedin|google|github|bitbucket');
Route::get('/auth/{social}/callback', 'Auth\SocialLoginController@handleProviderCallback')->where('social', 'twitter|facebook|linkedin|google|github|bitbucket');
Route::post('/update-account-type', 'Auth\SocialLoginController@actionUpdateAccountType');

Route::group(['namespace' => 'User', 'prefix' => 'user', 'middleware' => 'auth'], function() {
    include 'user-routes.php';
});

Route::group(['namespace' => 'Admin', 'prefix' => 'admin', 'middleware' => 'admin'], function() {
    include 'admin-routes.php';
});

