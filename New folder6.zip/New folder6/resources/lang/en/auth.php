<?php

return [

    /*
      |--------------------------------------------------------------------------
      | Authentication Language Lines
      |--------------------------------------------------------------------------
      |
      | The following language lines are used during authentication for various
      | messages that we need to display to the user. You are free to modify
      | these language lines according to your application's requirements.
      |
     */

    'failed' => 'Incorrect email or password.',
    'email_status' => 'Please verify your email address to activate your account or before login to the website.',
    'status' => 'Your account for this login credentials is currently disabled.',
    'failed_status' => 'Only authorized user are allowed to enter.',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
];
