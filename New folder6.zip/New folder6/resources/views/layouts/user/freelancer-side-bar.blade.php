<!--Side-nav-->
<aside class="side_menu" id="nav-aside">
    <ul class="list-unstyled menu font-md mb-0" data-mcs-theme="light">
        <li class="{{ ( \Request::route()->getName() == 'user.dashboard') ? 'active' : '' }}">
            <a class="dasboard" href="{{url('/user/dashboard')}}">Dashboard</a>
        </li>
       <li class="{{ ( \Request::route()->getName() == 'user.applied-jobs') ? 'active' : '' }}">
            <a href="{{url('/user/applied-jobs')}}">My Application</a>
        </li>
        <li class="{{ ( \Request::route()->getName() == 'user.invitation-received') ? 'active' : '' }}">
            <a href="{{url('/user/invitation-received')}}">Invitation</a>
        </li>
        <li class="{{ ( \Request::route()->getName() == 'user.video-views') ? 'active' : '' }}">
            <a href="{{url('/user/video-views')}}">Video Views</a>
        </li>
        <li class="{{ ( \Request::route()->getName() == 'user.profile-views') ? 'active' : '' }}">
            <a href="{{url('/user/profile-views')}}">Profile Views</a>
        </li>
        
        <li class="{{ ( \Request::route()->getName() == 'user.job-listing') ? 'active' : '' }}">
            <a href="{{url('/job-listing')}}">Job Listing</a>
        </li>
        <li class="{{ ( \Request::route()->getName() == 'user.my-plan') ? 'active' : '' }}">
            <a href="{{url('/user/my-plan')}}">My Plan</a>
        </li>
        <li class="{{ ( \Request::route()->getName() == 'user.payment-history') ? 'active' : '' }}">
            <a href="{{url('/user/payment-history')}}">Payment History</a>
        </li>
        <li>
            <a href="{{url('/user/support')}}">Support</a>
        </li>
    </ul>
</aside>
