<!--Side-nav-->
<aside class="side_menu" id="nav-aside">
    <ul class="list-unstyled menu font-md mb-0">
        <li class="{{ ( \Request::route()->getName() == 'user.dashboard') ? 'active' : '' }}">
            <a class="dasboard" href="{{url('/user/dashboard')}}">Dashboard</a>
        </li>
        <li class="{{ ( \Request::route()->getName() == 'user.posted-jobs') ? 'active' : '' }}">
            <a href="{{url('/user/posted-jobs')}}">My Jobs</a>
        </li>
        <li class="{{ ( \Request::route()->getName() == 'user.postjob') ? 'active' : '' }}">
            <a href="{{url('/user/post-job')}}">Post Job</a>
        </li>
        <li class="{{ ( \Request::route()->getName() == 'user.my-plan') ? 'active' : '' }}">
            <a href="{{url('/user/my-plan')}}">My Plan</a>
        </li>
        <li class="{{ ( \Request::route()->getName() == 'user.payment-history') ? 'active' : '' }}">
            <a href="{{url('/user/payment-history')}}">Payment History</a>
        </li>
        <li class="{{ ( \Request::route()->getName() == 'user.support') ? 'active' : '' }}">
            <a href="{{url('/user/support')}}">Support</a>
        </li>
    </ul>
</aside>