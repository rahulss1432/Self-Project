<script src="https://maps.googleapis.com/maps/api/js?key={{env('GOOGLE_MAP_KEY')}}&libraries=places&language=gb"></script>
<script>
var autocompleteAddress;
var componentForm = {
    // street_number: 'short_name',
    //route: 'long_name',
    locality: 'long_name',
    administrative_area_level_1: 'long_name',
    country: 'long_name',
    postal_code: 'short_name'
};
function initPickup() {
    // Create the autocomplete object, restricting the search to geographical
    // location types.
    autocompleteAddress = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('address')),
            {types: ['geocode']});

    // When the user selects an address from the dropdown, populate the address
    // fields in the form.
    autocompleteAddress.addListener('place_changed', fillInAddress);
}
function fillInAddress() {
    // Get the place details from the autocomplete object.
    var place = autocompleteAddress.getPlace();

    for (var component in componentForm) {
        document.getElementById('user-' + component).value = '';
        document.getElementById('user-' + component).disabled = false;
    }

    // Get each component of the address from the place details
    // and fill the corresponding field on the form.
    for (var i = 0; i < place.address_components.length; i++) {
        var addressType = place.address_components[i].types[0];
        if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            if (addressType != 'country') {
                document.getElementById('user-' + addressType).value = val;
            } else {
                var countryId = $("[data-code=" + val + "]").val();
                $('#user-country').val(countryId);
                $('#user-country').selectpicker('refresh');
            }
        }
    }
    //document.getElementById('farmlatitude').value = place.geometry.location.lat();
    //document.getElementById('farmlongitude').value = place.geometry.location.lng();
}
initPickup();
</script>