<header class="{{(strpos(\Request::path(), 'user/') === false && \Request::route()->getName() != 'user.job-listing')?'dashboard-header header after_login':'dashboard-header fixed-top'}}" id="{{(strpos(\Request::path(), 'user/') === false && \Request::route()->getName() != 'user.job-listing')?'main_header':'top-header'}}">
    <div class="container-fluid">
        @guest
        <nav class="navbar navbar-expand-md">
            <a class="navbar-brand" href="{{url('/')}}">
                <img src="{{url('public/images/logo.svg')}}" class="logo_white" alt="Rezieo">
            </a>
            <ul class="navbar-nav d-inline-block d-md-flex ml-auto">
                <li class="nav-item align-middle">
                    <a class="nav-link text-uppercase btn-success btn ripple-effect-dark" href="{{url('/login')}}">Login</a>
                </li>
                <li class="nav-item align-middle">
                    <a class="nav-link text-uppercase btn btn-outline-light ripple-effect-dark" href="{{url('/register')}}">Register Now</a>
                </li>
            </ul>
        </nav>
        @else
        <nav class="navbar navbar-light">
            <div class="navbar-brand">
                <a href="{{url('/')}}" class="d-inline-block">
                    <div class="logo">
                        <img src="{{url('public/images/logo.svg')}}" title="Rezieo" alt="logo">
                    </div>
                </a>
                <div class="toglle">
                    <div class="toggle-icon d-xl-none">
                        <i class="fa fa-bars"></i>
                    </div>
                </div>
            </div>
            <ul class="nav ml-auto right-utility seeker_header">
                @php $activePlan=\App\Models\PlanSubscription::getActivePlan(); $alertDate=strtotime(date("Y-m-d"). ' + 10 day'); @endphp
                @if(!empty($activePlan))
                <li class="nav-item d-none d-lg-inline-flex">
                    @if($alertDate >= strtotime($activePlan->expiry_date))
                    <a href="{{url('/user/my-plan')}}" class="nav-link executive">The validity period of a plan is about to expire - {{\App\Helpers\Utility::getDateFormat($activePlan->expiry_date)}}.</a>
                    @else
                    @php $bigPlan=\App\Models\Plan::getBigPlan($activePlan->amount); @endphp
                    <a href="{{url('/user/my-plan')}}" class="nav-link executive">Get more out of Rezieo   {{(!empty($bigPlan))?'- Get '.$bigPlan->plan_name:''}}</a>
                    @endif
                </li>
                @endif
                @if(Auth::user()->user_type!='employer')
                <li class="nav-item d-none d-lg-inline-flex {{ ( \Request::route()->getName() == 'user.job-listing') ? 'active' : '' }}">
                    <a href="{{url('/job-listing')}}" class="nav-link">JOB LISTING</a>
                </li>
                @endif
                <li class="nav-item d-none d-lg-inline-flex {{ ( \Request::route()->getName() == 'user.dashboard') ? 'active' : '' }}">
                    <a href="{{url('/user/dashboard')}}" class="nav-link">DASHBOARD</a>
                </li>
                <li class="nav-item dropdown notification">

                    @php $notificationList=\App\Models\Notification::getNotifications(['userId'=>Auth::user()->id,'status'=>'unread']); @endphp

                    <a class="nav-link dropdown-toggle bell {{ (\Request::route()->getName() == 'user.notifications') ? 'active' : '' }}" href="#" role="button" id="notificationDrop" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-bell"></i>
                        <span class="count">{{$notificationList->count()}}</span>
                    </a>
                    <div class="dropdown-menu common-box" aria-labelledby="notificationDrop">
                        <div class="headline">
                            <h3 class="font-md mb-0"> Notifications</h3>
                        </div>
                        <ul class="list-unstyled">

                            @if($notificationList->count()>0)
                            <div class="scroll_notification">
                                @foreach($notificationList as $notification)
                                @include('user.notifications._notification-box')
                                @endforeach
                            </div>
                            @else
                            
                            <li class="no-record">
                            	@php echo \App\Helpers\Utility::emptyListMessage('notification'); @endphp
                            </li>
                            @endif

                            <li class="text-center d-block view-all">
                                <a href="{{url('/user/notifications')}}" >VIEW ALL</a>
                            </li>
                        </ul>
                    </div>
                </li>
                <!--<li class="nav-item"><a href="#" class="nav-link"><i class="icon-feather-mail"></i><span class="count">4</span></a></li>-->
                <li class="nav-item dropdown user-avtar">
                    <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="{{\App\Helpers\Utility::checkProfileImage(Auth::user()->profile_image)}}" class="rounded-circle img-thumbnail profileImage">
                        <span class="username">{{Auth::user()->first_name.' '.Auth::user()->last_name}}</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                        <div class="user-details d-flex align-items-center">
                            <div class="user-avatar status-online"><img class="profileImage" src="{{\App\Helpers\Utility::checkProfileImage(Auth::user()->profile_image)}}" alt=""></div>
                            <div class="user-name">
                                {{Auth::user()->first_name.' '.Auth::user()->last_name}} <span> 
                                    @php $userType=\App\Models\UserType::getUserTypeId(Auth::user()->user_type); @endphp
                                    {{ucfirst($userType->label_name)}}
                                </span>
                            </div>
                        </div>
                        <a class="dropdown-item {{ (\Request::route()->getName() == 'user.view-profile') ? 'active' : '' }}" href="{{url('/user/view-profile')}}">View Profile</a>
                        <a class="dropdown-item {{ (\Request::route()->getName() == 'user.edit-profile') ? 'active' : '' }}" href="{{url('/user/edit-profile')}}">Edit Profile</a>
                        <a class="dropdown-item {{ (\Request::route()->getName() == 'user.change-password') ? 'active' : '' }}" href="{{url('/user/change-password')}}">Change Password</a>
                        <a class="dropdown-item" href="{{url('/logout')}}">Logout</a> 
                    </div>
                </li>
            </ul>
        </nav>
        @endguest
    </div>
</header>

 @if(!empty(session()->get('userSession')))
    @php $userData=session()->get('userSession'); @endphp
        @if(empty($userData['user_type']))
<div class="modal fade modal-loginwith" id="loginWith" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="loginWith" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title m-auto" id="addskillsModal">CONTINUE WITH <span id="signupType"></span></h5>
                    </div>
                    <div class="modal-body">
                        <div class="content">
                            <form class="form-horizontal" id="update-account-form" method="POST" action="{{url('/update-account-type')}}">
                                {{csrf_field()}}
                            <div class="option_buttons text-center">
                                <h5>Choose User Type</h5>
                                 @php 
                                        $userTypes=\App\Models\UserType::getListedType();
                                    @endphp
                                    @if(!empty($userTypes))
                                        @foreach($userTypes as $userType)
                                            <label class="list-box-label" for="item-{{$userType['user_type']}}">
                                                <input type="radio" id="item-{{$userType['user_type']}}" name="user_type" value="{{$userType['user_type']}}" @if($userType['user_type']=='candidate') checked="checked" @endif>
                                                <div class="inner">
                                                    <div class="user_img d-inline-flex align-items-center justify-content-center">
                                                        <img src="{{url('public/images/'.$userType['user_type'].'_color.png')}}" class="img-fluid" alt="user">
                                                    </div>
                                                    <h6>{{$userType['label_name']}}</h6>    
                                                </div>                        
                                            </label>
                                        @endforeach
                                    @endif 
                            </div>
                                @if(empty($userData['email']))
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="email" id="email-accountinfo" placeholder="Email Address"/>
                                    </div>
                                @endif
                            <div class="form-group mb-0 text-center">
                                <button type="submit" class="btn btn-success">CONTINUE</button>
                            </div>
                                 </form>
                {!! JsValidator::formRequest('App\Http\Requests\SetAccountInfoRequest','#update-account-form') !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
   
        <script>
            $(document).ready(function () {
                $('#signupType').html('{{strtoupper($userData["signup_by"])}}');
                $('#loginWith').modal('show');
            });
        </script>
        @endif
    @endif