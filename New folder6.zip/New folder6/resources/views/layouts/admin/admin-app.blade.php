<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>@yield('title') : Rezieo</title>
        <meta name="theme-color" content="#ffffff">
        <link rel="apple-touch-icon" sizes="180x180" href="{{url('public/images/favicon/apple-touch-icon.png')}}">
        <link rel="icon" type="image/png" sizes="32x32" href="{{url('public/images/favicon/favicon-32x32.png')}}">
        <link rel="icon" type="image/png" sizes="16x16" href="{{url('public/images/favicon/favicon-16x16.png')}}">
        <link rel="manifest" href="{{url('public/images/favicon/site.webmanifest')}}">
        <link rel="mask-icon" href="{{url('public/images/favicon/safari-pinned-tab.svg')}}" color="#5bbad5">
        <meta name="msapplication-TileColor" content="#ffffff">
        <link rel="stylesheet" href="{{url('public/css/tempusdominus-bootstrap-4.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/jquery.mCustomScrollbar.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/icons.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/font-awesome.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/bootstrap.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/bootstrap-select.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/admin.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/toastr.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/rich-text-editor.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/themify-icons.css')}}" type="text/css">
        <!-- Styles -->
        <script src="{{url('public/js/popper.min.js')}}" type="text/javascript"></script>

        <script>
var token_laravel = '{{ csrf_token() }}';
var base_url = '{{ url('') }}';
        </script>
        <script src="{{url('public/js/nicEdit-latest.js')}}" type="text/javascript"></script>
        @include('layouts.scripts')
    </head>
    <body>
        <!--header-->
        <header class="dashboard-header fixed-top" id="top-header">
            <div class="container-fluid">
                <nav class="navbar navbar-light">
                    <div class="navbar-brand">
                        <a href="{{url('/admin')}}" class="d-inline-block">
                            <div class="logo">
                                <img src="{{url('public/images/logo.svg')}}" title="Rezieo" alt="logo">
                            </div>
                        </a>
                        <div class="toglle">
                            <div class="toggle-icon d-xl-none">
                                <i class="fa fa-bars"></i>
                            </div>
                        </div>
                    </div>
                    <ul class="nav ml-auto right-utility seeker_header">
                        <li class="nav-item dropdown notification">
                        <li class="nav-item dropdown notification">
                            @php $notificationList=\App\Models\Notification::getNotifications(['userId'=>Auth::guard('admin')->user()->id,'status'=>'unread']); @endphp
                            <a class="nav-link dropdown-toggle bell {{ (\Request::route()->getName() == 'user.notifications') ? 'active' : '' }}" href="#" role="button" id="notificationDrop" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-bell"></i>
                                <span class="count">{{$notificationList->count()}}</span>
                            </a>
                            <div class="dropdown-menu common-box" aria-labelledby="notificationDrop">
                                <div class="headline">
                                    <h3 class="font-md mb-0"> Notifications</h3>
                                </div>
                                <ul class="list-unstyled">

                                    @if($notificationList->count()>0)
                                    <div class="scroll_notification">
                                        @foreach($notificationList as $notification)
                                        @include('admin.notifications._notification-box')
                                        @endforeach
                                    </div>
                                    @else
                                    <li class="no-record">
                                        @php echo \App\Helpers\Utility::emptyListMessage('notification'); @endphp
                                    </li>
                                    @endif
                                    <li class="text-center d-block view-all">
                                        <a href="{{url('/admin/notification')}}" >VIEW ALL</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item dropdown user-avtar">
                            <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="{{url('public/images/admin/defaultUser.jpg')}}" class="rounded-circle img-thumbnail">
                                <span class="username">{{Auth::guard('admin')->user()->first_name.' '.Auth::guard('admin')->user()->last_name}}</span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a class="dropdown-item" href="javascript:void(0);" onclick="changePassword('admin');">Change Password</a>
                                <a class="dropdown-item" href="{{url('/admin/logout')}}">Logout</a>  
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
        </header>
        <!--Side-nav-->
        <aside class="side_menu" id="nav-aside">
            <ul class="list-unstyled menu font-md mb-0" data-mcs-theme="light">
                <li class="{{ ( \Request::route()->getName() == 'admin.dashboard') ? 'active' : '' }}">
                    <a class="dasboard" href="{{url('/admin/dashboard')}}">Dashboard</a>
                </li>
                <li class="sub-menu {{ ( \Request::route()->getName() == 'admin.user') ? 'active' : '' }}">
                    <a data-toggle="collapse" href="#my-job" role="button" aria-expanded="false" aria-controls="myjobcollapse">Manage Users
                        <span class="dropdown-icon pull-right"></span>
                    </a>
                    <div class="collapse {{ ( \Request::route()->getName() == 'admin.user') ? 'show' : '' }}" id="my-job">
                        <ul>
                            <li class="{{ ( \Request::path() == 'admin/candidates') ? 'active' : '' }}">
                                <a href="{{url('/admin/candidates')}}">Candidates</a>
                            </li>
                            <li class="{{ ( \Request::path() == 'admin/freelancer') ? 'active' : '' }}">
                                <a href="{{url('/admin/freelancer')}}">Freelancer</a>
                            </li>
                            <li class="{{ ( \Request::path() == 'admin/employer') ? 'active' : '' }}">
                                <a href="{{url('/admin/employer')}}">Employers</a>
                            </li>
                            @if(Auth::guard('admin')->user()->user_type == 'admin')
                                <li class="{{ ( \Request::path() == 'admin/sub-admin') ? 'active' : '' }}">
                                    <a href="{{url('/admin/sub-admin')}}">Sub Admin</a>
                                </li>
                            @endif
                        </ul>
                    </div>
                </li>
                @if(Auth::guard('admin')->user()->user_type == 'admin')
                    <li class="{{ ( \Request::route()->getName() == 'admin.plans') ? 'active' : '' }}">
                        <a href="{{url('/admin/plans')}}">Subscription</a>
                    </li>
                    <li class="sub-menu {{ ( \Request::route()->getName() == 'admin.questionnaire') ? 'active' : '' }}">
                        <a data-toggle="collapse" href="#my-questionnaire" role="button" aria-expanded="false" aria-controls="myjobcollapse">Questionnaire
                            <span class="dropdown-icon pull-right"></span>
                        </a>
                        <div class="collapse {{ ( \Request::route()->getName() == 'admin.questionnaire') ? 'show' : '' }}" id="my-questionnaire">
                            <ul>
                                <li class="{{ ( \Request::path() == 'admin/question-category') ? 'active' : '' }}">
                                    <a href="{{url('/admin/question-category')}}">Category</a>
                                </li>
                                <li class="{{ ( \Request::path() == 'admin/questionnaire') ? 'active' : '' }}">
                                    <a href="{{url('/admin/questionnaire')}}">Questions</a>
                                </li> 
                            </ul>
                        </div>
                    </li>
                    <li class="{{ ( \Request::route()->getName() == 'admin.closed-job') ? 'active' : '' }}">
                        <a href="{{url('/admin/closed-job')}}">Closed Job </a>
                    </li>
                    <li class="{{ ( \Request::route()->getName() == 'admin.industries') ? 'active' : '' }}">
                        <a href="{{url('/admin/industries')}}">Manage Industry </a>
                    </li>
                    <li class="{{ ( \Request::route()->getName() == 'admin.skills') ? 'active' : '' }}">
                        <a href="{{url('/admin/skills')}}">Manage Skills</a>
                    </li>
                    <li class="{{ ( \Request::route()->getName() == 'admin.languages') ? 'active' : '' }}">
                        <a href="{{url('/admin/languages')}}">Language Spoken</a>
                    </li>

                    <li class="{{ ( \Request::route()->getName() == 'admin.payment-history') ? 'active' : '' }}">
                        <a href="{{url('/admin/payment-history')}}">Manage Payments</a>
                    </li>
                    <li class="{{ ( \Request::route()->getName() == 'admin.cms') ? 'active' : '' }}">
                        <a href="{{url('/admin/cms-pages')}}">Manage CMS</a>
                    </li>
                    <li class="{{ ( \Request::route()->getName() == 'admin.send-mail') ? 'active' : '' }}">
                        <a href="{{url('/admin/send-mail')}}">Send Email</a>
                    </li>
                    <li class="sub-menu {{ ( \Request::route()->getName() == 'admin.configuration') ? 'active' : '' }}">
                        <a data-toggle="collapse" href="#my-configuration" role="button" aria-expanded="false" aria-controls="myjobcollapse">Site Configuration
                            <span class="dropdown-icon pull-right"></span>
                        </a>
                        <div class="collapse {{ ( \Request::route()->getName() == 'admin.configuration') ? 'show' : '' }}" id="my-configuration">
                            <ul>
                                <li class="{{ ( \Request::path() == "'/admin/banner-setting/'.'forgot_password'") ? 'active' : '' }}">
                                    <a href="{{url('/admin/banner-setting/'.'forgot_password')}}">Forgot Password</a>
                                </li>
                                <li class="{{ ( \Request::path() == "'/admin/banner-setting/'.'login'") ? 'active' : '' }}">
                                    <a href="{{url('/admin/banner-setting/'.'login')}}">Login</a>
                                </li>
                                <li class="{{ ( \Request::path() == 'admin/settings') ? 'active' : '' }}">
                                    <a href="{{url('/admin/settings')}}">Settings</a>
                                </li>
                                <li class="{{ ( \Request::path() == 'admin/side-menu') ? 'active' : '' }}">
                                    <a href="{{url('/admin/side-menu')}}">Side Menu</a>
                                </li>
                                <li class="{{ ( \Request::path() == 'admin/testimonials') ? 'active' : '' }}">
                                    <a href="{{url('/admin/testimonials')}}">Testimonials</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                @endif
            </ul>
        </aside>
        @yield('content')
        <!--footer-->
        <div class="overlay-screen"></div>
        <footer class="dashboard-footer" id="footer">
            <div class="footer-in text-center">
                <div class="copyright-text">
                    <span class="and-font">&copy;</span> {{date("Y")}} <strong>Rezieo</strong>. All Rights Reserved.
                </div>
            </div>
        </footer>
        <script src="{{url('public/js/moment.js')}}" type="text/javascript"></script>


        <script src="{{url('public/js/jquery.mCustomScrollbar.concat.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/tempusdominus-bootstrap-4.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/rich-text-editor.min.js')}}" type="text/javascript"></script>
        <script>
$(document).ready(function () {
    if ($(window).width() >= 1025) {
        $('.toggle-icon').click(function () {
            $("body").toggleClass("menu-toggle")
        });
    }
    if ($(window).width() <= 1024) {
        $('.toggle-icon').click(function () {
            $("body").toggleClass("menu-toggle")
        });
        $('.overlay-screen').click(function () {
            $("body").removeClass("menu-toggle")
        });

    }
});

(function ($) {
    $(window).on("load", function () {
        $(".side_menu").mCustomScrollbar();
    });
    $(window).on("load", function () {
        $(".scroll_notification").mCustomScrollbar();
    });
})(jQuery);

$(window).resize(function () {
    var chk_account_height = $('#top-header').outerHeight(true);
    var window_height = $(window).height();
    $("#content").css('min-height', window_height - chk_account_height + 28);

    if ($(window).width() <= 1199) {
        var chk_account_height = $('#top-header').outerHeight(true);
        var window_height = $(window).height();
        $("#content").css('min-height', window_height - chk_account_height + 18);
    }

}).resize();




$('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
    var rippleDiv = $('<span class="ripple-overlay">'),
            rippleOffset = $(this).offset(),
            rippleY = e.pageY - rippleOffset.top,
            rippleX = e.pageX - rippleOffset.left;

    rippleDiv.css({
        top: rippleY - (rippleDiv.height() / 2),
        left: rippleX - (rippleDiv.width() / 2),
        // background: $(this).data("ripple-color");
    }).appendTo($(this));

    window.setTimeout(function () {
        rippleDiv.remove();
    }, 800);
});

$(function () {
    $('[data-toggle="tooltip"]').tooltip()
});

        </script>

    </body>
</html>

<div class="modal fade" id="changePasswordModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="addskillsModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addskillsModal">Change Password</h5>
                <button aria-label="Close" data-dismiss="modal" class="close" type="button">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <div id="password-form"></div>
            </div>
            <div class="modal-footer">
                <button type="Submit"  id="btn-password"  class="btn ripple-effect-dark btn-success btn-sm text-uppercase">Update</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->

<!-- category model end -->
<script>
    function changePassword(user) {
        $('#changePasswordModal').modal('show');
        $('#password-form').html('{{\App\Helpers\Utility::ajaxLoader()}}');
        var url = '{{url("/admin/change-password")}}';
        $.ajax({
            url: url,
            type: 'POST',
            data: {_token: '{{csrf_token()}}', guard: user},
            success: function (result) {
                $("#password-form").html(result);
            }
        });
    }

    function addCategory(id) {
        $('#questionnaireModal').modal('show');
        $("#questionnaire-form").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "GET",
            url: "{{ url('admin/get-category-form') }}",
            data: {id: id},
            success: function (response) {
                $('#questionnaire-form').html(response);
                if (id == 0) {
                    $('#modal-title').html('Add Category');
                } else {
                    $('#modal-title').html('Edit Category');
                }
            }
        });
    }
</script>
