<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">

<meta name="theme-color" content="#ffffff">
<link rel="apple-touch-icon" sizes="180x180" href="{{url('public/images/favicon/apple-touch-icon.png')}}">
<link rel="icon" type="image/png" sizes="32x32" href="{{url('public/images/favicon/favicon-32x32.png')}}">
<link rel="icon" type="image/png" sizes="16x16" href="{{url('public/images/favicon/favicon-16x16.png')}}">
<link rel="manifest" href="{{url('public/images/favicon/site.webmanifest')}}">
<link rel="mask-icon" href="{{url('public/images/favicon/safari-pinned-tab.svg')}}" color="#5bbad5">
<meta name="msapplication-TileColor" content="#ffffff">
<link rel="stylesheet" href="{{url('public/css/tempusdominus-bootstrap-4.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{url('public/css/jquery.mCustomScrollbar.css')}}" type="text/css">
<link rel="stylesheet" href="{{url('public/css/icons.css')}}" type="text/css">
<link rel="stylesheet" href="{{url('public/css/font-awesome.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{url('public/css/bootstrap.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{url('public/css/bootstrap-select.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{url('public/css/slick.css')}}" type="text/css">
<link rel="stylesheet" href="{{url('public/css/slick-theme.css')}}" type="text/css">
<link rel="stylesheet" href="{{url('public/css/custom.min.css')}}" type="text/css">
