<script src="{{ url('public/js/moment.js')}}" type="text/javascript"></script>
<script src="{{ url('public/js/jquery.min.js') }}"></script>
<script src="{{ url('public/js/bootstrap.min.js') }}"></script>
<script src="{{ url('public/js/jsvalidation.js') }}"></script>
<script src="{{ url('public/js/toastr.min.js') }}"></script>
<script src="{{ url('public/js/bootbox.min.js') }}"></script>
<script src="{{url('public/js/bootstrap-select.min.js')}}" type="text/javascript"></script>
<script src="{{url('public/js/jquery.mCustomScrollbar.concat.min.js')}}" type="text/javascript"></script>
<script>
function successToaster(message, title) {
    toastr.remove();
    toastr.options.closeButton = true;
    toastr.success(message, title, {timeOut: 2000});
}
function errorToaster(message, title) {
    toastr.remove();
    toastr.options.closeButton = true;
    toastr.error(message, title, {timeOut: 2000});
}
</script>
@if(session()->has('success'))
<script>
    $(document).ready(function () {
        successToaster("{!! session('message') !!}", "{!! session('success') !!}");
    });
</script>
@endif
@if(session()->has('error'))
<script>
    $(document).ready(function () {
        errorToaster("{!! session('message') !!}", "{!! session('error') !!}");
    });
</script>
@endif