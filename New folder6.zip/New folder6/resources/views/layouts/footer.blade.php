<footer class="common-footer">
    <div class="container container-1350">
        <div class="row">
            <div class="col-sm-3">
                <div class="ftr-logo wow fadeInUP" data-wow-duration="1s" data-wow-delay="0.3s">
                    <img src="{{url('public/images/logo-white.svg')}}">
                    <a href="mailto:enquiries@rezieo.info">enquiries@rezieo.com</a>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="ftr-links wow fadeInUP" data-wow-duration="1s" data-wow-delay="0.4s">
                    <h3>Legal Terms</h3>
                    <ul class="list-unstyled">
                        <li>
                            <a href="javscript:void(0);">Terms <span>&</span> Conditions</a>
                        </li>
                        <li>
                            <a href="javscript:void(0);">Privacy Policies</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="ftr-links wow fadeInUP" data-wow-duration="1s" data-wow-delay="0.5s">
                    <h3>Social Media</h3>
                    <ul class="list-unstyled">
                        <li>
                            <a href="javscript:void(0);">LinkedIn</a>
                        </li>
                        <li>
                            <a href="javscript:void(0);">Facebook</a>
                        </li>
                        <li>
                            <a href="javscript:void(0);">Twitter</a>
                        </li>
                        <li>
                            <a href="javscript:void(0);">Google+</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="ftr-links wow fadeInUP" data-wow-duration="1s" data-wow-delay="0.6s">
                    <h3>Subscription Plans</h3>
                    <ul class="list-unstyled">
                        <li>
                            <a href="subscriptions-paln.php?id=1">Candidate</a>
                        </li>
                        <li>
                            <a href="subscriptions-paln.php?id=2">Freelancer</a>
                        </li>
                        <li>
                            <a href="subscriptions-paln.php?id=3">Employer</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container container-1350">
        <div class="copyright">
            <p class="m-0">Rezieo 2018</p>
        </div>
    </div>
</footer>

<script type="text/javascript">
$(window).resize(function () {
    var chk_account_height = $('#top-header').outerHeight(true);
    var window_height = $(window).height();
    $("#content").css('min-height', window_height - chk_account_height + 28);
}).resize();

//ripple-effect for button
$('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
    var rippleDiv = $('<span class="ripple-overlay">'),
            rippleOffset = $(this).offset(),
            rippleY = e.pageY - rippleOffset.top,
            rippleX = e.pageX - rippleOffset.left;

    rippleDiv.css({
        top: rippleY - (rippleDiv.height() / 2),
        left: rippleX - (rippleDiv.width() / 2),
        // background: $(this).data("ripple-color");
    }).appendTo($(this));

    window.setTimeout(function () {
        rippleDiv.remove();
    }, 800);
});

//header scroll effect
var headerHeight = $('#main_header').height() + 80;
function stickyheader() {
    scrtop = $(window).scrollTop();
    if (scrtop >= headerHeight) {
        $('#main_header').addClass('fixed');
    } else {
        $('#main_header').removeClass('fixed');
    }
}

$(window).scroll(function () {
    stickyheader();
});

// form validation
(function () {
    'use strict';
    window.addEventListener('load', function () {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function (form) {
            form.addEventListener('submit', function (event) {
                if (form.checkValidity() === false) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
                $('.fa-spin').css('display', 'inline-block');
                $('.fa-angle-right').css('display', 'none');
                setTimeout(function () {
                    $('.fa-spin').css('display', 'none');
                    $('.fa-angle-right').css('display', 'inline-block');
                }, 2000);
            }, false);
        });
    }, false);
})();
setTimeout(function () {
    $('.select_error').append('<div class="invalid-feedback">This field is required.</div>');
}, 1000);


//bootstrap select picker
$('.selectpicker').selectpicker({
    size: 4
});

(function ($) {
    $(window).on("load", function () {
        $(".inner-page .navbar-nav .nav-item .nav-link").removeClass('ripple-effect-dark');
    });
})(jQuery);

//Login Signup Banner
$(document).ready(function () {
    if (screen.width > 1200) {
        $(window).resize(function () {
            var window_height = window.innerHeight;
            var header_height = $('#main_header').outerHeight(true);
            $('#commonBanner').css('height', window_height - header_height);
        }).resize();
    }
});
</script>