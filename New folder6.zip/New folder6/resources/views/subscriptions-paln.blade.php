@extends( 'layouts.app' )
@section( 'title', 'Subscription Plans' )
@section( 'content' )
	<main class="main-wrapper subscription-plan-page public " id="content">
		<section class="content_section content-wrap pl-0 pr-0 gray-bg">
			<div class="container container-1350">
				<section class="page-header">
					<div class="page-heading font-md">
						<h1 class="">Subscription Plan</h1>
					</div>
				</section>
				<div class="content-in">
					<div class="option_buttons">
						<label class="list-box-label" for="item-1">
                        <input type="radio" name="choosetype" value="candidate" id="item-1" checked>
                        <div class="inner">
                            <div class="user_img d-inline-flex align-items-center justify-content-center">
                                <img src="{{url('public/images/color_seeker.png')}}" class="img-fluid" alt="user">
                            </div>
                            <h6>Candidate</h6>    
                        </div>                        
                    </label>
					

						<label class="list-box-label" for="item-2">
                        <input type="radio" name="choosetype" value="freelancer" id="item-2">
                        <div class="inner">  
                            <div class="user_img d-inline-flex align-items-center justify-content-center">
                                <img src="{{url('public/images/employee_color.png')}}" class="img-fluid" alt="user">
                            </div>
                            <h6>Freelancer</h6>    
                        </div>                        
                    </label>
					

						<label class="list-box-label" for="item-3">
                        <input type="radio" name="choosetype" value="employer" id="item-3">
                        <div class="inner">  
                            <div class="user_img d-inline-flex align-items-center justify-content-center">
                                <img src="{{url('public/images/employee_color.png')}}" class="img-fluid" alt="user">
                            </div>
                            <h6>Employer</h6>    
                        </div>                        
                    </label>
					
					</div>

					<div id="candidate-plan">
						<div class="row">
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Free
										<sup>$</sup>
										<span>0.00</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 30 Sec Promo Video</li>
											<li>Apply to 2 Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match (system)</li>
											<li>Profile Email Notifications</li>
											<li>Social Media Integration</li>
										</ul>
										<span class="checkmark"></span>
									</div>
								</div>
							</div>
							<!-- xxxxx -->
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Basic
										<sup>$</sup>
										<span>7.99</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 30 Sec Promo Video</li>
											<li>Apply to 4 Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match</li>
											<li>Receive Personal Profile Link</li>
											<li>Profile Email Notifications</li>
											<li>Social Media Integration</li>
										</ul>
									</div>
								</div>
							</div>

							<!-- xxxxxx -->
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Pro
										<sup>$</sup>
										<span>9.99</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 45 Sec Promo Video</li>
											<li>Apply to 8 Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match</li>
											<li>Receive Personal Profile Link</li>
											<li>Chat Support</li>
											<li>Social Media Integration</li>
										</ul>
									</div>
								</div>
							</div>
							<!-- xxxxxx -->
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Executive
										<sup>$</sup>
										<span>12.99</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 60 Sec Promo Video</li>
											<li>Apply to Unlimited Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match</li>
											<li>Receive Personal Profile Link</li>
											<li>Profile Email Notifications</li>
											<li>Chat Support</li>
											<li>U.S. Phone Support</li>
											<li>Social Media Integration</li>
										</ul>
									</div>
								</div>
							</div>
							<!-- xxxxxx -->
							<div class="col-sm-12">
								<div class="text-center">
									<a href="signup.php" class="text-uppercase btn btn-success ripple-effect-dark">REGISTER NOW</a>
								</div>
							</div>
						</div>
					</div>
					<div id="freelancer-plan" class="collapse fad" style="display: none">
						<div class="row">
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Free
										<sup>$</sup>
										<span>0.00</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 30 Sec Promo Video</li>
											<li>Apply to 2 Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match (system)</li>
											<li>Profile Email Notifications</li>
											<li>Social Media Integration</li>
										</ul>
										<span class="checkmark"></span>
									</div>
								</div>
							</div>
							<!-- xxxxx -->
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Basic
										<sup>$</sup>
										<span>7.99</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 30 Sec Promo Video</li>
											<li>Apply to 4 Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match</li>
											<li>Receive Personal Profile Link</li>
											<li>Profile Email Notifications</li>
											<li>Social Media Integration</li>
										</ul>
									</div>
								</div>
							</div>

							<!-- xxxxxx -->
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Pro
										<sup>$</sup>
										<span>9.99</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 45 Sec Promo Video</li>
											<li>Apply to 8 Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match</li>
											<li>Receive Personal Profile Link</li>
											<li>Chat Support</li>
											<li>Social Media Integration</li>
										</ul>
									</div>
								</div>
							</div>
							<!-- xxxxxx -->
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Executive
										<sup>$</sup>
										<span>12.99</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 60 Sec Promo Video</li>
											<li>Apply to Unlimited Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match</li>
											<li>Receive Personal Profile Link</li>
											<li>Profile Email Notifications</li>
											<li>Chat Support</li>
											<li>U.S. Phone Support</li>
											<li>Social Media Integration</li>
										</ul>
									</div>
								</div>
							</div>
							<!-- xxxxxx -->
							<div class="col-sm-12">
								<div class="text-center">
									<a href="signup.php" class="text-uppercase btn btn-success ripple-effect-dark">REGISTER NOW</a>
								</div>
							</div>
						</div>
					</div>
					<div id="employer-plan" class="collapse fad" style="display: none">
						<div class="row">
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Free
										<sup>$</sup>
										<span>0.00</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 30 Sec Promo Video</li>
											<li>Apply to 2 Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match (system)</li>
											<li>Profile Email Notifications</li>
											<li>Social Media Integration</li>
										</ul>
										<span class="checkmark"></span>
									</div>
								</div>
							</div>
							<!-- xxxxx -->
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Basic
										<sup>$</sup>
										<span>7.99</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 30 Sec Promo Video</li>
											<li>Apply to 4 Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match</li>
											<li>Receive Personal Profile Link</li>
											<li>Profile Email Notifications</li>
											<li>Social Media Integration</li>
										</ul>
									</div>
								</div>
							</div>

							<!-- xxxxxx -->
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Pro
										<sup>$</sup>
										<span>9.99</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 45 Sec Promo Video</li>
											<li>Apply to 8 Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match</li>
											<li>Receive Personal Profile Link</li>
											<li>Chat Support</li>
											<li>Social Media Integration</li>
										</ul>
									</div>
								</div>
							</div>
							<!-- xxxxxx -->
							<div class="col-lg-3 col-sm-6 column">
								<div class="card">
									<div class="card-header text-center">Executive
										<sup>$</sup>
										<span>12.99</span>
										<small>/ month</small>
									</div>
									<div class="card-body">
										<ul class="list-unstyled mb-0">
											<li>Upload 60 Sec Promo Video</li>
											<li>Apply to Unlimited Jobs postings</li>
											<li>Access to FAQ’s Support</li>
											<li>System Match</li>
											<li>Receive Personal Profile Link</li>
											<li>Profile Email Notifications</li>
											<li>Chat Support</li>
											<li>U.S. Phone Support</li>
											<li>Social Media Integration</li>
										</ul>
									</div>
								</div>
							</div>
							<!-- xxxxxx -->
							<div class="col-sm-12">
								<div class="text-center">
									<a href="signup.php" class="text-uppercase btn btn-success ripple-effect-dark">REGISTER NOW</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</main>

<script>
	$( 'input' ).change( function () {
		if ( $( '#item-1' ).prop( 'checked' ) == true ) {
			$( '#candidate-plan' ).show();
			$( '#freelancer-plan' ).hide();
			$( '#employer-plan' ).hide();
		}

		if ( $( '#item-3' ).prop( 'checked' ) == true ) {
			$( '#candidate-plan' ).hide();
			$( '#freelancer-plan' ).hide();
			$( '#employer-plan' ).show();
		}

		if ( $( '#item-2' ).prop( 'checked' ) == true ) {
			$( '#candidate-plan' ).hide();
			$( '#freelancer-plan' ).show();
			$( '#employer-plan' ).hide();
		}
	} );
	$( window ).on( 'load', function () {
		let prepend = 'item-';
		let elem = 'input[type=radio]';
		let url = window.location.href;
		let keyVal = '1';
		if ( url.indexOf( '?' ) !== -1 )
			keyVal = url.split( '?' )[ 1 ].split( '=' )[ 1 ];
		let id = prepend + keyVal;
		$( elem ).each( function ( i ) {
			if ( $( this ).prop( 'id' ) === id )
				$( this ).prop( 'checked', true );
		} );
	} );
</script>
@endsection