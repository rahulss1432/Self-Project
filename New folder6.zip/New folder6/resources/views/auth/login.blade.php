@extends('layouts.app')
@section('title','Login')
@section('content')
<main class="main-wrapper login_page" id="content">
    <section class="login_section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-6 pl-0 pr-0">
                    <div class="login_left_content">
                        <img src="{{url('public/images/logins-bg/login_bg.jpg')}}" alt="image" class="img-fluid" id="commonBanner">
                        <div class="content">
                            <h1>We empower future <br class="d-none d-xl-block"> industry experts</h1>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 pl-md-0 pr-md-0">
                    <div class="login_right_content">
                        <div class="form_content">
                            <h4>Login</h4>
                            <p>Get access to new opportunities.</p>
                            <form id="user-login-frm" class="form-horizontal" method="POST" action="javascript:void(0);">
                                {{ csrf_field() }}
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" placeholder="Email">
                                </div>
                                <div class="form-group">
                                    <input type="password" name="password" placeholder="Password*" class="form-control"> 
                                </div>
                                <div class="d-flex align-items-sm-center remebre_and_forgot">
                                    <div class="mr-auto">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="remeberme" name="remember"> 
                                            <label class="custom-control-label" for="remeberme"> <span>Remember me</span></label>
                                        </div>
                                    </div>  
                                    <div class="ml-auto">        
                                        <a href="{{ url('/forgot-password') }}">Forgot Password?</a>
                                    </div>
                                </div>
                                <button type="submit" id="user-login-btn" class="text-uppercase btn-success ripple-effect-dark btn">Login</button>
                                <span class="or d-block mx-auto">or</span>
                                <div class="text-center social_links">
<!--                                    <a href="{{ url('login/linkedin') }}" data-toggle="modal" data-target="#loginWith" class="comon_links linkedin text-uppercase d-inline-flex align-items-center">-->
<a href="{{ url('login/linkedin') }}"  class="comon_links linkedin text-uppercase d-inline-flex align-items-center">
                                        <i class="fa fa-linkedin"></i> Continue with Linkedin
                                    </a>
                                    <a href="{{ url('login/facebook') }}" class="comon_links facebook d-inline-flex align-items-center text-uppercase">
                                        <i class="fa fa-facebook"></i> Continue with Facebook
                                    </a>
                                </div>
                                <span class="dont_act d-block mx-auto">Don't have an account? <a href="{{url('/register')}}">Register Now</a></span>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Modal -->
</main>
{!! JsValidator::formRequest('App\Http\Requests\LoginRequest','#user-login-frm') !!}
<script>
    $("#user-login-btn").on('click', (function (e) {
        var frm = $('#user-login-frm');
        var btn = $('#user-login-btn');
        if (frm.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Login');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{url('/login')}}",
                type: "POST",
                data: frm.serialize(),
                success: function (data)
                {
                    btn.prop('disabled', false);
                    location.reload();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('LOGIN');
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
	
</script>
@endsection
