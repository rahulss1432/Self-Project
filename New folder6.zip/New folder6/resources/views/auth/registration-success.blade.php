@extends('layouts.app')
@section('title','Login')
@section('content')
<main class="main-wrapper login_page signup_page">
    <section class="login_section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-6 pl-0 pr-0">
                    <div class="login_left_content">
                        <img src="{{url('public/images/logins-bg/signup_payment02.jpg')}}" alt="image" class="img-fluid" id="commonBanner">
                        <div class="content">
                            <h1>We empower future <br class="d-none d-xl-block"> industry experts</h1>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6 pl-md-0 pr-md-0">
                    <div class="login_right_content">
                        <a href="{{url('/login')}}" class="back_login">
                            <img src="{{url('public/images/back.png')}}" alt="icon" class="img-fluid"> Back to login
                        </a>
                        <div class="form_content">
                            <form>
                                <div class="option_buttons">
                                    @if($userType == 'candidate')
                                    <label class="list-box-label" id="userJobseeker"  >
                                        <input type="radio" name="choosetype" value="candidate" checked>
                                        <div class="inner">
                                            <div class="user_img d-inline-flex align-items-center justify-content-center">
                                                <img src="{{url('public/images/color_seeker.png')}}" class="img-fluid" alt="user">
                                            </div>
                                            <h6>Candidate</h6>    
                                        </div>                        
                                    </label>
                                    @endif
                                    @if($userType == 'freelancer')
                                    <label class="list-box-label" id="userFreelancer">
                                        <input type="radio" name="choosetype" value="freelancer" checked>
                                        <div class="inner">  
                                            <div class="user_img d-inline-flex align-items-center justify-content-center"">
                                                <img src="{{url('public/images/employee_color.png')}}" class="img-fluid" alt="user">
                                            </div>
                                            <h6>Freelancer</h6>    
                                        </div>                        
                                    </label>
                                    @endif
                                    @if($userType == 'employer')
                                    <label class="list-box-label" id="userEmployer">
                                        <input type="radio" name="choosetype" value="employer" checked>
                                        <div class="inner">  
                                            <div class="user_img d-inline-flex align-items-center justify-content-center"">
                                                <img src="{{url('public/images/employee_color.png')}}" class="img-fluid" alt="user">
                                            </div>
                                            <h6>Employer</h6>    
                                        </div>                        
                                    </label> 
                                    @endif
                                </div>
                                <div class="sign_up_spce shield d-inline-flex align-items-center justify-content-center">
                                    <img src="{{url('public/images/right_circle.svg')}}" alt="icon" class="img-fluid w_80">
                                </div>
                                <div class="payment_successful">
                                    <h4>Registration Successful!</h4>
                                    <p>You are successfully registered with Rezeio <br class="d-none d-sm-block"> Please verify your email address to complete your registration process</p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
@endsection
