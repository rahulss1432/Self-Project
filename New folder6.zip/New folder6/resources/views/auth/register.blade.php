@extends('layouts.app')
@section('title','Register')
@section('content')
<main class="main-wrapper login_page signup_page">
    <section class="login_section">
        <div class="container-fluid">
            <form method="post" id="user-signup-frm" action="{{url('/register-sub')}}">
                {{csrf_field()}}
                <div class="row">
                    <div class="col-xl-6 pl-0 pr-0">
                        <div class="login_left_content">
                            <img src="{{url('public/images/logins-bg/signup_bg.jpg')}}" alt="image" class="img-fluid">
                            <div class="content">
                                <h1>We empower future <br class="d-none d-xl-block"> industry experts</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 pl-md-0 pr-md-0">
                        <div class="login_right_content">
                            <div class="form_content">
                                <div class="option_buttons">
                                    <h5>Choose User Type</h5>
                                    @php 
                                        $userTypes=\App\Models\UserType::getListedType();
                                    @endphp
                                    @if(!empty($userTypes))
                                        @foreach($userTypes as $userType)
                                            <label class="list-box-label" for="item-{{$userType['user_type']}}">
                                                <input type="radio" id="item-{{$userType['user_type']}}" name="user_type" value="{{$userType['user_type']}}" @if($userType['user_type']=='candidate') checked="checked" @endif>
                                                <div class="inner">
                                                    <div class="user_img d-inline-flex align-items-center justify-content-center">
                                                        <img src="{{url('public/images/'.$userType['user_type'].'_color.png')}}" class="img-fluid" alt="user">
                                                    </div>
                                                    <h6>{{$userType['label_name']}}</h6>    
                                                </div>                        
                                            </label>
                                        @endforeach
                                    @endif
                                </div>
                                <h4 class="mb-35">Register Now for <span class="color-green">Rezieo</span></h4>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <input type="text" name="first_name" placeholder="First Name*" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <input type="text" name="last_name" placeholder="Last Name*" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="email" placeholder="Email*" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="password" name="password" placeholder="Password*" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="password" name="confirm_password" placeholder="Confirm password*" class="form-control">
                                </div>
                                <button type="submit" class="text-uppercase btn-success ripple-effect-dark btn">NEXT STEP <i class="fa fa-angle-right"></i> <i class="fa fa-spin fa-spinner" style="display: none;"></i></button>
                                <span class="or d-block mx-auto">or</span>

                                <div class="text-center social_links">
                                    <a href="{{ url('login/linkedin') }}" class="comon_links linkedin text-uppercase d-inline-flex align-items-center">
                                        <i class="fa fa-linkedin"></i> Continue with Linkedin
                                    </a>
                                    <a href="{{ url('login/facebook') }}" class="comon_links facebook text-uppercase d-inline-flex align-items-center">
                                        <i class="fa fa-facebook"></i> Continue with Facebook
                                    </a>
                                </div>
                                <span class="dont_act d-block mx-auto">You have an account? <a href="{{url('/login')}}">Login</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Http\Requests\RegistrationRequest','#user-signup-frm') !!}
        </div>
    </section>
</main>
@endsection
