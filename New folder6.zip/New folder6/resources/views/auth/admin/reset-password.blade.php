<!doctype html>
<html lang="en">
    <head>
        <title>Rezieo Admin Login</title>
        <link rel="stylesheet" href="{{url('public/css/font-awesome.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/bootstrap.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/admin.min.css')}}" type="text/css">
        @include('layouts.scripts')
    </head>
    <body>
        <main class="login-page d-flex align-items-center justify-content-center">
            <div class="login-wrap shadow_body mx-auto">
                <div class="login-header d-flex align-items-center justify-content-center">
                    <img src="{{url('public/images/logo-white.svg')}}" alt="logo" class="img-fluid">
                </div>
                <div class="login-field">
                    <form id="admin-password-frm" class="form-horizontal" method="POST" action="javascript:void(0);">
                        <input type="hidden" name="token" value="{{$token}}">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <input type="password" class="form-control" name="password" placeholder="Password">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password">
                        </div>
                        <div class="form-group text-center">
                            <button id="admin-password-btn" type="submit" class="btn btn-success text-uppercase ripple-effect-dark">
                                Reset Password
                            </button>
                        </div>
                    </form>
                </div>
                <div class="login-footer">
                    <a href="{{ url('/admin') }}" class="ripple-effect text-uppercase">LOGIN <i class="fa fa-long-arrow-right"></i></a>
                </div>
            </div>
        </main>

        {!! JsValidator::formRequest('App\Http\Requests\ResetPasswordRequest','#admin-password-frm') !!}
        <script>
            $("#admin-password-btn").on('click', (function (e) {
                e.preventDefault();
                var frm = $('#admin-password-frm');
                var btn = $('#admin-password-btn');
                if (frm.valid()) {
                    btn.html('{{\App\Helpers\Utility::buttonLoader()}} Reset Password');
                    btn.prop('disabled', true);
                    $.ajax({
                        url: "{{ url('/admin/update-password') }}",
                        type: "POST",
                        data: frm.serialize(),
                        success: function (data)
                        {
                            window.location.href = '{{url("/admin")}}';
                        }
                    });
                }
            }));
        </script>
    </body>
</html>
