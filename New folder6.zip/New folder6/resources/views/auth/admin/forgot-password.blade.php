<!doctype html>
<html lang="en">
    <head>
        <title>Rezieo Admin Forgot Password</title>
        <link rel="stylesheet" href="{{url('public/css/font-awesome.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/bootstrap.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/admin.min.css')}}" type="text/css">
        @include('layouts.scripts')
    </head>
    <body>
        <main class="login-page d-flex align-items-center justify-content-center">
            <div class="login-wrap shadow_body mx-auto">
                <div class="login-header d-flex align-items-center justify-content-center">
                    <img src="{{url('public/images/logo-white.svg')}}" alt="logo" class="img-fluid">
                </div>
                <div class="login-field">
                    <form id="admin-password-frm" method="POST" action="{{ url('/admin/send-password-link') }}">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <input type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" id="admin-password-btn" class="btn btn-success text-uppercase ripple-effect-dark">Send Password Reset Link</button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Http\Requests\ForgotPasswordRequest','#admin-password-frm') !!}
                    <script>
                        $("#admin-password-btn").on('click', (function (e) {
                            e.preventDefault();
                            var frm = $('#admin-password-frm');
                            var btn = $('#admin-password-btn');
                            if (frm.valid()) {
                                btn.html('{{\App\Helpers\Utility::buttonLoader()}} Send Password Reset Link');
                                btn.prop('disabled', true);
                                $.ajax({
                                    url: "{{ url('/admin/send-password-link') }}",
                                    type: "POST",
                                    data: frm.serialize(),
                                    success: function (data)
                                    {
                                        btn.prop('disabled', false);
                                        window.location.href="{{url('/admin')}}";
                                    },
                                    error: function (data) {
                                        var obj = jQuery.parseJSON(data.responseText);
                                        for (var x in obj) {
                                            btn.prop('disabled', false);
                                            btn.html('Send Password Reset Link');
                                            var errors = obj[x].length
                                            $('#' + x + '-error').html(obj[x]);
                                            $('#' + x + '-error').css("color", '#b30000');
                                            $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                                        }
                                    },
                                });
                            }
                        }));
                    </script>
                </div>
                <div class="login-footer">
                    <a href="{{url('/admin')}}" class="ripple-effect text-uppercase"> <i class="fa fa-long-arrow-left"></i> &nbsp; LOGIN</a>
                </div>
            </div>
        </main>
    </body>
</html>