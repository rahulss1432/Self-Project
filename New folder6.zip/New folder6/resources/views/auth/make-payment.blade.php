@extends('layouts.app')
@section('title','Make Payment')
@section('content')
<main class="main-wrapper login_page signup_page">
    <section class="login_section">
        <div class="container-fluid">
            <form method="post" id="make-payment-frm" action="{{url('/make-payment')}}">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-xl-6 pl-0 pr-0">
                        <div class="login_left_content">
                            <img src="{{url('public/images/logins-bg/login_bg.jpg')}}" alt="image" class="img-fluid signupimg">
                            <div class="payment_sec">
                                <div class="row align-items-center justify-content-center">
                                    @if(!empty($planList))
                                    @foreach($planList as $plan)
                                    <div class="col-sm-6">
                                        <label class="list-box-label" for="{{$plan['id']}}_paymentbox">
                                            <input type="radio" data-name='{{$plan['plan_name']}}' data-price='{{number_format($plan['price'],2)}}' value="{{$plan['id']}}" class="paymentbox" id="{{$plan['id']}}_paymentbox" onchange="getCheckedPlan();" name="planId" {{($plan['price']==0)?'checked="checked"':''}}>
                                            <div class="card">
                                                <div class="card-header text-center">{{$plan['plan_name']}} <sup>$</sup> <span>{{number_format($plan['price'],2)}}</span><small>/ month</small></div>
                                                <div class="card-body">
                                                    <ul class="list-unstyled mb-0">
                                                        @if(!empty($plan->getDetails))
                                                        @foreach($plan->getDetails as $detailInfo)
                                                        <li>{{$detailInfo['description']}}</li>
                                                        @endforeach
                                                        @endif
                                                    </ul>
                                                    <span class="checkmark"></span>
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                    @endforeach
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6 pl-md-0 pr-md-0">
                        <div class="login_right_content">
                            <div class="form_content">
                                <div class="option_buttons">
                                    <label class="list-box-label" id="userJobseeker">
                                        <input type="radio" name="choosetype" value="candidate" checked="checked">
                                        <div class="inner">
                                            <div class="user_img d-inline-flex align-items-center justify-content-center">
                                                <img src="{{url('public/images/'.$typeInfo->user_type.'_color.png')}}" class="img-fluid" alt="user">
                                                <input type="hidden" name="validatePrice" id="validatePrice" value="">
                                            </div>
                                            <h6>{{$typeInfo->label_name}}</h6>    
                                        </div>                        
                                    </label>
                                </div>
                                <h4 class="mb-35" id="payTo">Pay to become <span id="planType" class="text-capitalize"></span> <span id="userType" class="text-capitalize"></span></h4>
                                <div class="form-group displayplan">
                                    <div class="display_subscription" id="freePlan">
                                        <h2 id="dName">Free</h2>
                                        <h1><sup>$</sup><span id="dPrice"></span><small>/ month</small></h1>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="card_number" placeholder="Card number*" class="form-control afield">
                                </div>
                                <div class="form-group">
                                    <input type="text" name="name_of_card" placeholder="Name on card*" class="form-control afield">
                                </div>
                                <div class="row">
                                    <div class="col-sm-2 pr-md-0">
                                        <div class="form-group">
                                            <input type="text" name="expiration_month" placeholder="MM*" maxlength="2" class="form-control text-md-center afield">                                                    
                                        </div>
                                    </div>
                                    <div class="col-sm-1"><div class="breaker">/</div></div>
                                    <div class="col-sm-2 pl-md-0 pr-md-0">
                                        <div class="form-group">
                                            <input type="text" name="expiration_year" maxlength="4" placeholder="YYYY*" class="form-control text-md-center afield">
                                        </div>
                                    </div>
                                    <div class="offset-sm-1 col-sm-6">
                                        <div class="form-group">
                                            <input type="text" name="cvc" placeholder="CVV / CVC*" maxlength="3" class="form-control afield">
                                        </div>
                                    </div>
                                </div>
                                <!--
                                <div class="form-group mb-md-5">
                                    <div class="custom-control custom-checkbox text-left">
                                        <input type="checkbox" class="custom-control-input" id="savecard"> 
                                        <label class="custom-control-label savelabel" for="savecard"> <span>Save this card for future</span></label>
                                    </div> 
                                </div>
                                -->
                                <div class="form_btn">
                                    <a href="{{url('/register')}}" class="text-uppercase bg-transparent btn-outline-dark btn mr-md-3 ripple-effect-dark"><i class="fa fa-angle-left left"></i> PREVIOUS </a>
                                    <button href="{{url('/make-payment')}}"class="free_btn text-uppercase btn-success btn ripple-effect-dark">NEXT STEP <i class="fa fa-angle-right"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
             {!! JsValidator::formRequest('App\Http\Requests\CreditCardRequest','#make-payment-frm') !!}
        </div>
    </section>
</main>
<script>
    function getCheckedPlan() {
        var price = $("input[name='planId']:checked").attr('data-price');
        $('#validatePrice').val(price);
        var planId = $("input[name='planId']:checked").val();
        $('#dName').text($("input[name='planId']:checked").attr('data-name'));
        $('#dPrice').text(price);
        if (price == 0) {
            $('.afield').attr('disabled', true);
            $('.help-block').html('');
        } else {
            $('.afield').attr('disabled', false);
        }
    }
    getCheckedPlan();
</script>
@endsection