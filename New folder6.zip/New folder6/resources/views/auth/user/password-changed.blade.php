@extends('layouts.app')
@section('title','Password Changed')
@section('content')
<main class="main-wrapper login_page">
    <section class="login_section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-6 pl-0 pr-0">
                    <div class="login_left_content">
                        <img src="{{url('public/images/logins-bg/login_bg.jpg')}}" alt="image" class="img-fluid" id="commonBanner">
                        <div class="content">
                            <h1>We empower future <br class="d-none d-xl-block"> industry experts</h1>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 pl-md-0 pr-md-0">
                    <div class="login_right_content">
                        <div class="form_content">
                            <div class="shield d-inline-flex align-items-center justify-content-center">
                                <img src="{{url('public/images/right_circle.svg')}}" alt="icon" class="img-fluid w_80">
                            </div>
                            <h2 class="mb-35">Password has been changed Successfully. </h2>
                            <a href="{{url('/login')}}" class="text-uppercase btn-success btn ripple-effect-dark">OK</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
@endsection