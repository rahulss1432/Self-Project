@extends('layouts.app')
@section('title','Forgot Password')
@section('content')
<main class="main-wrapper login_page">
    <section class="login_section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-6 pl-0 pr-0">
                    <div class="login_left_content">
                        <img src="{{url('public/images/logins-bg/forgot_password.jpg')}}" alt="image" class="img-fluid" id="commonBanner">
                        <div class="content">
                            <h1>We empower future <br class="d-none d-xl-block"> industry experts</h1>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 pl-md-0 pr-md-0">
                    <div class="login_right_content">
                        <a href="{{url('/login')}}" class="back_login">
                            <img src="{{url('public/images/back.png')}}" alt="icon" class="img-fluid"> Back to login
                        </a>
                        <div class="form_content">
                            <div class="shield d-inline-flex align-items-center justify-content-center"><img src="{{url('public/images/shield.svg')}}" alt="icon" class="img-fluid"></div>
                            <h4>Forgot Password</h4>
                            <p>Enter your registered email address and we will send you the instructions to reset your password</p>
                            <form id="user-password-frm" method="POST" action="{{ url('/send-password-link') }}">
                                {{ csrf_field() }}
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" placeholder="Email">
                                </div>
                                <button type="submit" id="user-password-btn" class="text-uppercase btn-success btn ripple-effect-dark">SUBMIT <i class="fa fa-spin fa-spinner" style="display: none;"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
{!! JsValidator::formRequest('App\Http\Requests\ForgotPasswordRequest','#user-password-frm') !!}
<script>
    $("#user-password-btn").on('click', (function (e) {
        e.preventDefault();
        var frm = $('#user-password-frm');
        var btn = $('#user-password-btn');
        if (frm.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{ url('/send-password-link') }}",
                type: "POST",
                data: frm.serialize(),
                success: function (data)
                {
                    btn.prop('disabled', false);
                    window.location.href = "{{url('/')}}";
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
</script>
@endsection
