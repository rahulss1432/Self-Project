@extends('layouts.app')
@section('title','Forgot Password')
@section('content')
<main class="main-wrapper login_page">
    <section class="login_section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-6 pl-0 pr-0">
                    <div class="login_left_content">
                        <img src="{{url('public/images/logins-bg/forgot_password01.jpg')}}" alt="image" class="img-fluid" id="commonBanner">
                        <div class="content">
                            <h1>We empower future <br class="d-none d-xl-block"> industry experts</h1>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 pl-md-0 pr-md-0">
                    <div class="login_right_content">
                        <div class="form_content">
                            <div class="shield d-inline-flex align-items-center justify-content-center"><img src="{{url('public/images/shield.svg')}}" alt="icon" class="img-fluid"></div>
                            <h4 class="mb-35">Reset Password?</h4>
                            <form id="user-password-frm" class="form-horizontal" method="POST" action="javascript:void(0);">
                                <input type="hidden" name="token" value="{{$token}}">
                                {{ csrf_field() }}
                                <div class="form-group">
                                    <input type="password" class="form-control" name="password" placeholder="Password">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password">
                                </div>
                                <button type="submit" id="user-password-btn" class="text-uppercase btn-success btn ripple-effect-dark">Reset Password</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
{!! JsValidator::formRequest('App\Http\Requests\ResetPasswordRequest','#user-password-frm') !!}
<script>
    $("#user-password-btn").on('click', (function (e) {
        e.preventDefault();
        var frm = $('#user-password-frm');
        var btn = $('#user-password-btn');
        if (frm.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Reset Password');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{ url('/update-password') }}",
                type: "POST",
                data: frm.serialize(),
                success: function (data)
                {
                    window.location.href = '{{url("/password-changed")}}';
                }
            });
        }
    }));
</script>
@endsection