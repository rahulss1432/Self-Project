@extends('layouts.user.app')
@section('title',$jobDetail->job_title)
@section('content')
<main class="main-wrapper dashboard-main-wrap jobdescription-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <!-- breadcrumb start-->
            <nav aria-label="breadcrumb" class="text-right">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Job Description</li>
                </ol>
            </nav>
            <!-- breadcrumb end-->
            <section class="content_section content-wrap">
                <div class="row details_row">
                    <div class="col-lg-9">
                        <h3 class="top-heading">
                            {{$jobDetail->job_title}} <span>at</span> {{$jobDetail->city}}
                        </h3>
                        <ul class="list-inline left-sec mb-0">
                            <li class="d-inline-flex align-items-center">
                                <div class="icon">
                                    <img src="{{url('public/images/calendar-icon.svg')}}" alt="icon">
                                </div>
                                <div class="info">
                                    <h4 class="font-md">Experience Required</h4>
                                    <p>{{$jobDetail->experience}} years</p>
                                </div>
                            </li>

                            <li class="d-inline-flex align-items-center">
                                <div class="icon">
                                    <img src="{{url('public/images/employer-icon.svg')}}" alt="icon">
                                </div>
                                <div class="info">
                                    <h4 class="font-md">Employment type</h4>
                                    <p>{{$jobDetail->job_type}}</p>
                                </div>
                            </li>

                            <li class="d-inline-flex align-items-center">
                                <div class="icon">
                                    <img src="{{url('public/images/industry-icon.svg')}}" alt="icon">
                                </div>
                                <div class="info">
                                    <h4 class="font-md">Industry</h4>
                                    <p>{{$jobDetail->getIndustry->industry_name}}</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-3">
                        <div class="right-sec float-lg-right mt-1 mt-sm-3 mt-lg-0">
                            <a href="{{url('/company-profile/'.$jobDetail->user_id.'/'.\App\Helpers\Utility::makeslug($jobDetail->getUser->company_name))}}" class="text-uppercase btn btn-success ripple-effect-dark mr-2 mr-lg-0 d-lg-block">VIEW COMPANY</a>
                            <a href="javascript:void(0);" class="text-uppercase btn btn-outline-success ripple-effect-dark mt-lg-3 d-lg-block">APPLY</a>
                        </div>
                    </div>
                </div>
                <!-- xxxx -->
                <div class="common_section">
                    <h3 class="sub-heading font-md">Posted On</h3>
                    <p class="para-text">{{ \App\Helpers\Utility::getDateFormat($jobDetail->created_at)}}</p>
                </div>
                <!-- xxxxx -->
                @php 
                    $skillData = \App\Models\JobSkill::where('job_id',$jobDetail->id)->get();                     
                @endphp
                @if($skillData->count()>0)
                    <div class="common_section ">
                        <h3 class="sub-heading font-md">Skills</h3>
                        <ul class="list-inline tags  mb-0">
                            @foreach($skillData as $skill)
                                <li class="list-inline-item">{{$skill->getSkills->skill_name}}</li>
                            @endforeach                       
                        </ul>
                    </div>
                @endif    
                <!-- xxxxx -->
                <div class="common_section">
                    <h3 class="sub-heading font-md">About this role</h3>
                    <p class="para-text mb-0">
                        {{$jobDetail->position_summary}}
                    </p>                    
                </div>
                <!-- xxxxxx -->
                <div class="common_section">
                    <h3 class="sub-heading font-md">Duties and Responsibilities</h3>
                    <p class="para-text mb-0">
                        {{$jobDetail->responsibilities}}
                    </p>
                </div>

                <!-- xxxxxx -->
                <div class="common_section">
                    <h3 class="sub-heading font-md">Other Qualifications</h3>
                    <p class="para-text mb-0">
                        {{$jobDetail->qualifications}}
                    </p>
                </div>

                <!-- xxxxxx -->
                <div class="common_section">
                    <h3 class="sub-heading font-md">Benefits</h3>
                    <p class="para-text mb-0">
                       {{$jobDetail->benefits}}
                    </p>
                </div>

                <!-- xxxxx -->
                <div class="common_section mb-0">
                    <h3 class="sub-heading font-md">Location</h3>
                    <p class="para-text">
                       {{$jobDetail->getUser->address}},{{$jobDetail->getUser->city}},{{$jobDetail->getUser->state}},{{$jobDetail->getUser->zipcode}},{{$jobDetail->getUser->getCountry->country_name}} 
</p>
                    <div class="map-box" id="map" style="height:400px;">

                    </div>
                </div>
                <!-- xxxxx -->
            </section>

        </div>
    </div>
</main>
<script>
//    function initMap() {
//        var uluru = {lat: -25.344, lng: 131.036};
//        var map = new google.maps.Map(
//                document.getElementById('map'), {zoom: 4, center: uluru});
//        var marker = new google.maps.Marker({position: uluru, map: map});
//    }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key={{env('GOOGLE_MAP_KEY')}}&callback=initMap"></script>
@endsection
