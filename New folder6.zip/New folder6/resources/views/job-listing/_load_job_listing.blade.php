@if(count($jobData)>0)
<div class="row">
    @foreach($jobData as $val)
    <div class="col-xl-3 col-custom-1200 col-lg-4 col-sm-6">
        <div class="job_box">
            <div class="job_header">
                <div class="job_img d-inline-flex align-items-center justify-content-center">
                    <img src="{{\App\Helpers\Utility::checkCompanyLogo($val->getUser->company_logo)}}" alt="icon" class="img-fluid">
                </div>
            </div>
            <div class="job_body">
                <h3>{{$val->job_title}}</h3>
                <h6>{{$val->city}} - {{$val->state}}</h6>
                <span class="font-rg">
                    <span class="color-green">{{$val->job_type}}</span>
                    @if(!empty($val->experience))
                        <span class="color-yellow">{{$val->experience}} Years</span>
                    @endif
                </span>
                <p>{{\App\Helpers\Utility::getLimitText(30,$val->position_summary)}}&nbsp;</p>
                <div class="row d-flex justify-content-between">
                    @php 
                        $jobApplicationData = \App\Models\JobApplication::where('job_id',$val->id)->where('user_id',Auth::user()->id)->where('action_by','application')->first();
                    @endphp
                    <div class="col col-sm-6">
                        @if(!empty($jobApplicationData) || count($jobApplicationData)>0)
                            @if($jobApplicationData->status == 'pending' )
                        <button type="button" class="btn btn-block btn-outline-success btn-sm ripple-effect-dark text-uppercase" disabled>pending</button>
                        @elseif($jobApplicationData->status == 'decline')
                        <button type="button" class="btn btn-block btn-outline-success btn-sm text-uppercase" disabled>Declined</button>
                        @elseif($jobApplicationData->status == 'accepted') 
                        <a href="video-interviews.php"  class="btn btn-block btn-outline-success ripple-effect-dark btn-sm text-uppercase">Record</a>
                        @elseif($jobApplicationData->status == 'interview_submitted')     
                        <button type="button" class="btn btn-block btn-outline-success btn-sm ripple-effect-dark text-uppercase" disabled>Submitted</button>     
                        @endif
                        
                        @else
                        <button type="button" class="btn btn-block btn-outline-success btn-sm ripple-effect-dark text-uppercase">Apply</button> 
                        @endif 
                    </div>
                    <div class="col col-sm-6">
                        <a href="{{url('/view-job/'.$val->id.'/'.\App\Helpers\Utility::makeslug($val->job_title))}}" class="btn btn-block btn-outline-warning btn-sm ripple-effect-dark text-uppercase">View Job</a>
                    </div>
                </div>
            </div>
            <div class="job_footer">
                <a href="{{url('/company-profile/'.$val->user_id.'/'.\App\Helpers\Utility::makeslug($val->getUser->company_name))}}" class="font-md">View Company Profile</a>
            </div>
        </div>
    </div>
    @endforeach
</div>
@else
<div class="row">
    <div class="col-xl-12">
        {{\App\Helpers\Utility::emptyListMessage('jobs')}}
    </div>
</div>
@endif
{{$jobData->links('vendor.pagination.simple-default')}}
<script>
    $(document).ready(function () {
        $('#spinner').hide();
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var pageLink = $(this).attr('href');
            var form = $("#frmFilter").serialize();
            $('#spinner').show();
            $.ajax({
                type: 'POST',
                url: pageLink,
                data: form,
                async: false,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#jobList").append(response);
                    $('#spinner').hide();
                }
            });
        });
    });
</script>
