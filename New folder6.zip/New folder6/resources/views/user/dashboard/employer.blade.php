@extends('layouts.user.app')
@section('title','Dashboard')
@section('content')
<main class="employer-main-wrap dashboard-main-wrap  dasboard-employer" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="content-body d-md-flex justify-content-between">
                <section class="page-header">
                    <div class="page-heading font-md">
                        <h1 class="">Howdy, Tom!</h1>
                        <p>We are glad to see you again!</p>
                    </div>
                </section>
                <nav aria-label="breadcrumb" class="text-right order-md-last">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                    </ol>
                </nav>
            </div>
            <section class="fun-fact dashboard-list">
                <div class="row box-row">
                    <div class="col-sm-6 col-lg-3">
                        <div class="wrap d-flex justify-content-between align-items-center">
                            <div class="text ">
                                <p>Posted Jobs</p>
                                <h2 class="font-md">22</h2>
                            </div>
                            <div class="icon bg-green d-flex align-items-center justify-content-center">
                                <i class="icon-material-outline-business-center"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="wrap d-flex justify-content-between align-items-center">
                            <div class="text ">
                                <p>Remaining Jobs</p>
                                <h2 class="font-md">32</h2>
                            </div>
                            <div class="icon bg-pink d-flex align-items-center justify-content-center">
                                <i class="icon-material-outline-business-center"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="wrap d-flex justify-content-between align-items-center">
                            <div class="text ">
                                <p>Sent Interview<br class="d-none d-lg-block"> Requests</p>
                                <h2 class="font-md">40</h2>
                            </div>
                            <div class="icon bg-yello d-flex align-items-center justify-content-center">
                                <i class="icon-material-outline-rate-review"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="wrap d-flex justify-content-between align-items-center mb-0">
                            <div class="text ">
                                <p>Total Applications</p>
                                <h2 class="font-md">35</h2>
                            </div>
                            <div class="icon bg-blue d-flex align-items-center justify-content-center">
                                <i class="icon-material-outline-assignment"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row box-row">
                    <div class="col-lg-6 col-sm-6">
                        <div class="common-box">
                            <div class="headline d-flex justify-content-between align-items-center">
                                <h3 class="font-md"><i class="icon-material-baseline-notifications-none"></i> Notifications</h3>
                                <div class="filter-btn">
                                    <ul class="list-inline mb-0 text-right">
                                        <li class="list-inline-item">
                                            <a href="{{url('/user/notifications')}}" >View All</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="content">
                                @php $notificationList=\App\Models\Notification::getNotifications(['userId'=>Auth::user()->id,'status'=>'unread']); @endphp
                                <div class="common-box-list list-unstyled mb-0">
                                    @if($notificationList->count()>0)
                                    @foreach($notificationList as $notification)
                                    <div class="list-box-inner">
                                        <span class="notification-icon"><i class="{{$notification['icon']}}"></i></span>
                                        <span class="notification-text">
                                            {!!$notification['message']!!}
                                        </span>
                                        @if(!empty($showDate))
                                        <span class="ml-auto date_tym">07/12/2018</span>
                                        @endif
                                    </div>
                                    @endforeach
                                    @else
                                    <div  class="list-box-inner d-block">
                                        @php echo \App\Helpers\Utility::emptyListMessage('notification'); @endphp
                                    </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6">
                        <div class="common-box ordrer-list">
                            <div class="headline d-flex justify-content-between align-items-center">
                                <h3 class="font-md"><i class="icon-material-outline-assignment"></i> Payment History</h3>
                                <div class="filter-btn">
                                    <ul class="list-inline mb-0 text-right">
                                        <li class="list-inline-item">
                                            <a href="payment-history.php" >View All</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="content">
                                <ul class="common-box-list list-unstyled mb-0">
                                    <li>
                                        <div class="invoice-list-item">
                                            <strong>Professional Plan</strong>
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><strong >ID : 85229416525</strong></li>
                                                <li class="list-inline-item">Date: 12/08/2018</li>
                                                <li class="list-inline-item">Amount : $ 9.99</li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="invoice-list-item">
                                            <strong>Basic Plan</strong>
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><strong>ID : 85229416525</strong></li>
                                                <li class="list-inline-item">Date: 12/08/2018</li>
                                                <li class="list-inline-item">Amount : $ 7.99</li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="invoice-list-item">
                                            <strong>Executive Plan</strong>
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><strong >ID : 85229416525</strong></li>
                                                <li class="list-inline-item">Date: 12/08/2018</li>
                                                <li class="list-inline-item">Amount : $ 12.99</li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="invoice-list-item">
                                            <strong>Free Plan</strong>
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><strong >ID : 85229416525</strong></li>
                                                <li class="list-inline-item">Date: 12/08/2018</li>
                                                <li class="list-inline-item">Amount : $ 0.00</li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</main>
@endsection