@extends('layouts.user.app')
@section('title','Notifications')
@section('content')
<main class="dashboard-main-wrap notifications-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="content-body">
                <!-- <h2 class="page-title mt-0">Notifications</h2> -->
                <!-- breadcrumb start-->
                <nav aria-label="breadcrumb" class="text-right">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Notifications</li>
                    </ol>
                </nav>
                <!-- breadcrumb end-->
                <div class="card">
                    <div class="card-body">
                        <div id="notification">
                            <!-- breadcrumb here-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function () {
        loadnotifications();
    });
    function loadnotifications() {
        $("#notification").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $('#spinner').show();
        var url = "{{url('/user/load-notifications')}}";
        var token = '{{ csrf_token() }}';
        $.ajax({
            type: "POST",
            url: url,
            data: {_token: token},
            success: function (data) {
                $("#notification").html(data.html);
                $('#spinner').hide();
            }
        });
    }

</script>
@endsection