@if(count ($notifications) > 0)
<div class="notification_list list-unstyled">
    @foreach($notifications as $notification)
        @include('user.notifications._notification-box')
    @endforeach
</div>
    <div id="appendanoti{{$notifications->currentPage()}}"></div>
    
    {{$notifications->links('vendor.pagination.simple-default')}}
    @else
      
            @php echo \App\Helpers\Utility::emptyListMessage('notification'); @endphp</div>
     
    @endif
    <script>
        $(document).ready(function () {
            $(".pagination li a").on('click', function (e) {
                e.preventDefault();
                var pageLink = $(this).attr('href');
                $('#spinner').show();
                $.ajax({
                    type: 'POST',
                    url: pageLink,
                    data: {_token: '{{csrf_token()}}'},
                    async: false,
                    success: function (response) {
                        $('.pagination:first').remove();
                        $("#appendanoti{{$notifications->currentPage()}}").append(response.html).hide().fadeIn(1000);
                        $('#spinner').hide();
                    }
                });
            });
        });
    </script>
