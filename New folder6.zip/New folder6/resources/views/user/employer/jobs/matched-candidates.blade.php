@extends('layouts.user.app')
@section('title','Matched Candidates')
@section('content')
<main class="employer-main-wrap dashboard-main-wrap manage-candidates" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="content-body">
                <div class="d-md-flex justify-content-between">
                    <section class="page-header">
                        <div class="page-heading font-md">
                            <h1 class="">View Matched Candidates</h1>
                            <p class="mb-0">Candidates for <a href="manage-job.php">{{$jobData->job_title}}</a></p>
                        </div>
                    </section>
                    <nav aria-label="breadcrumb" class="text-right">
                        <ol class="breadcrumb d-inline-flex">
                            <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="{{url('/user/posted-jobs')}}">My Jobs Listing</a></li>
                            <li class="breadcrumb-item active" aria-current="page">View Matched Candidates</li>
                        </ol>
                    </nav>
                </div>
                <section class="candidates-list">
                    <div class="common-box ordrer-list">
                        <div class="headline d-flex justify-content-between align-items-center">
                            <h3 class="font-md"><i class="icon-material-outline-business-center"></i>Candidates Listing</h3>
                            <div class="filter-btn">
                                <ul class="list-inline mb-0 text-right">
                                    <li class="list-inline-item">
                                        <a href="#searchFilter" data-toggle="collapse" class="nav-link" title="Search"><i class="icon-feather-filter"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="filter_section collapse" id="searchFilter">
                            <form id="frmFilter" action="javascript:void(0);" onsubmit="loadMatchedCandidateList()">
                                <input type="hidden" name="job_id" value="{{$jobData->id}}">
                                {{ csrf_field()}}
                                <div class="row">
                                    <div class="col-sm-6 col-md-3">
                                        <div class="form-group">
                                            <input type="text" name="location" placeholder="Location" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-3">
                                        <div class="form-group">
                                            <select class="form-control selectpicker select04" name="experience" title="Experience">
                                                <option value="">Experience</option>
                                                <option value="0-3">0-3</option>
                                                <option value="3-5">3-5</option>
                                                <option value="5-7">5-7</option>
                                                <option value="7-10">7-10</option>
                                                <option value="10+">10+</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-3">
                                        <div class="form-group">
                                            <select class="form-control selectpicker select04" name="candidate_type" title="Candidate Type">
                                                <option value="">Candidate Type</option>{{$userType}}
                                                @if(!empty($userType))
                                                    @foreach($userType as $type)
                                                        <option value="{{$type->user_type}}">{{$type->label_name}}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-3">
                                        <div class="form-group mb-0">
                                            <div class="row">
                                            <button class="btn btn-success ripple-effect-dark text-uppercase" type="submit">Filter</button>
                                            <button class="btn btn-warning ripple-effect-dark text-uppercase ml-md-3" type="button" onclick="resetFilter();">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="content all-candidate">
                            <div id="matchedCandidates"></div>
                        </div>
                    </div>
                    <div class="text-center mt-3">
                        <div class="load_more" id="loadMore" style="display: none;">
                            <a href="javascript:void(0);">
                                <img src="{{url('public/images/load_more.svg')}}" alt="icon">Load More
                            </a>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    $(document).ready(function(){
        loadMatchedCandidateList();
    });
    
    function loadMatchedCandidateList(){
        $("#matchedCandidates").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $('#spinner').show();
        var form = $("#frmFilter").serialize();
        $.ajax({
            type: "POST",
            data: form,
            url: "{{url('/user/load-matched-candidates-list')}}",
            success: function (response) {
                $('#matchedCandidates').html(response);
                $('#spinner').hide();
            }
        });
    }
    
    function resetFilter(){
        $('#frmFilter')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadMatchedCandidateList();
    }
</script>
@endsection