@if($jobList->count()>0)
<div class="common-box-list list-unstyled">
    @foreach($jobList as $job)
    <div class="list-box-inner">
        <div class="job-listing-description">
            <div class="job-listing-description">
                <h3 class="job-listing-title">
                    <a href="#">{{$job['job_title']}}</a></h3>
                <div class="job-listing-footer">
                    <ul class="list-inline">
                        <li class="list-inline-item"><i class="icon-material-outline-date-range"></i> Posted {{\App\Helpers\Utility::getDateFormat($job['created_at'])}}</li>
                        <li class="list-inline-item"><i class="icon-material-outline-date-range"></i> Expiring  {{\App\Helpers\Utility::getDateFormat($job['expiry_date'])}}</li>
                    </ul>
                </div>
            </div>
            <div class="buttons-to-right">
                <a href="manage-candidates.php" class="btn btn-success btn-sm ripple-effect-dark text-uppercase">
                    <i class="icon-material-outline-supervisor-account"></i> Manage Candidates <span class="info">0</span>
                </a>

                <a href="{{url('/user/view-matched-candidates/'.$job['id'])}}" class="btn btn-success btn-sm text-uppercase ripple-effect-dark">
                    View Matched Candidates
                </a>

                <a href="{{url('/user/post-job/'.$job['id'])}}" class="btn btn-sm btn-secondary ripple-effect-dark tips" data-tippy-placement="top" data-tippy="" data-original-title="Edit">
                    <i class="icon-feather-edit mr-0"></i>
                </a>


                <a href="#" class="btn btn-sm btn-secondary ripple-effect-dark tips" data-tippy-placement="top" data-tippy="" data-original-title="Deactivate">
                    <i class="icon-feather-eye-off mr-0"></i>
                </a>

            </div>
        </div>
    </div>
    @endforeach
</div>
<div id="appendJobList{{$jobList->currentPage()}}"></div>
{{$jobList->links('vendor.pagination.simple-default')}}
@else
<div class="common-box-list list-unstyled">
    <div class="list-box-inner d-block">
        {{\App\Helpers\Utility::emptyListMessage('job')}}
    </div>
</ul>
@endif
<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var pageLink = $(this).attr('href');
            $('#spinner').show();
            $.ajax({
                type: 'GET',
                url: pageLink,
                async: false,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#appendJobList{{$jobList->currentPage()}}").append(response).hide().fadeIn(1000);
                    $('#spinner').hide();
                }
            });
        });
    });
</script>