@extends('layouts.user.app')
@section('title','Post Job')
@section('content')
<main class="dashboard-main-wrap employer-main-wrap setupprofile-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item">
                        <a href="{{url('/user/dashboard')}}">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Post Job</li>
                </ol>
            </nav>  
            <form action="javascript:void(0);"  id="postjobForm" method="POST" autocomplete="off">
                {{ csrf_field() }}
                <input type="hidden" name="id" value="{{$model->id}}">
                <div class="common-box mt-0">
                    <div class="headline">
                        <h3 class="font-md mb-0">
                            <i class="icon-feather-folder-plus"></i> Job Submission Form
                        </h3>
                    </div>
                    <div class="content">
                        <form action="">
                            <div class="row">
                                <div class=" col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">Job Title</label>
                                        <input type="text" placeholder="Job Title" class="form-control" name="job_title" value="{{$model->job_title}}">
                                    </div>
                                </div>
                                
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">Job Type</label>
                                        <select id="select-job" class="form-control selectpicker" name="job_type" title="Job Type">
                                            <option value="">Select Job Type</option>
                                            <option {{($model->job_type == 'Full-time')?'selected="selected"':''}} value="Full-time">Full time</option>
                                            <option {{($model->job_type == 'Freelancer')?'selected="selected"':''}} value="Freelancer">Freelancer</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6" id="paymenttype" style="{{($model->job_type == 'Freelancer') ? 'display:block;' : 'display:none;' }}">
                                    <div class="form-group">
                                        <label class="control-label">Rate type</label>
                                        <div class="radio_box mt-2">
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="fixed-rate"  {{($model->rate_type == 'fixed')?'checked':''}} name="rate_type" value="fixed" class="custom-control-input">
                                                <label class="custom-control-label" for="fixed-rate">Fixed Rate</label>
                                            </div>
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="Hourly" {{($model->rate_type == 'hourly')?'checked':''}} name="rate_type" value="hourly" class="custom-control-input">
                                                <label class="custom-control-label" for="Hourly">Hourly Rate</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6" id="rate" style="{{($model->job_type == 'Freelancer') ? 'display:block;' : 'display:none;' }}">
                                    <div class="form-group">
                                        <label class="control-label">Rate</label>
                                        <input type="text" Placeholder="Enter Rate Amount" class="form-control" name="rate_amount" value="{{$model->rate_amount}}">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">Industry Type</label>
                                        <select name="industry_type" onchange="getSkills()" id="industry_type" class="form-control selectpicker" data-live-search="true" title="Select Industry type">
                                            <option>Select Industry Type</option>
                                            @if(!empty($industries))
                                            @foreach($industries as $industry)
                                            <option  {{($model->industry_type == $industry->id)?'selected="selected"':''}} value="{{$industry->id}}">{{$industry->industry_name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">Address</label>
                                        <input id="address" type="text" name="address" class="form-control" value="{{$model->address}}" placeholder="Address">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">Country</label>
                                        <select id="user-country" class="form-control selectpicker" title="Country" name="country" data-live-search="true">
                                            @php 
                                            $country = \App\Models\Country::getCountriesDropdown($model->country); 
                                            echo $country;
                                            @endphp
                                        </select>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">State</label>
                                        <input id="user-administrative_area_level_1" type="text"  value="{{$model->state}}" name="state" class="form-control" placeholder="State">
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">City</label>
                                        <input id="user-locality" type="text" name="city" class="form-control"  value="{{$model->city}}" placeholder="City">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">Zip</label>
                                        <input type="text" class="form-control" id="user-postal_code"  maxlength="7" name="zipcode" value="{{$model->zipcode}}"  placeholder="Zip" >
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">Skills Required</label>
                                        <select name="skills[]" id="skills" multiple="true" class="selectpicker form-control" title="Select Skills">
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6" id="showInput">
                                    <div class="form-group">
                                        <label for="" class="control-label">Select Experience</label>
                                        <select class="form-control selectpicker select04" name="experience" title="Select Experience" >
                                            <option value="">Select Experience</option>
                                            <option {{($model->experience == '0-2')?'selected="selected"':''}} value="0-2">0-2</option>
                                            <option {{($model->experience == '3-5')?'selected="selected"':''}} value="3-5">3-5</option>
                                            <option {{($model->experience == '6-10')?'selected="selected"':''}} value="6-10">6-10</option>
                                            <option {{($model->experience == '11-15')?'selected="selected"':''}} value="11-15">11-15</option>
                                            <option {{($model->experience == '16-20')?'selected="selected"':''}} value="16-20">16-20</option>
                                            <option {{($model->experience == '21-30')?'selected="selected"':''}} value="21-30">21-30</option>
                                            <option {{($model->experience == '30+')?'selected="selected"':''}}value="30+">30+</option>
                                        </select> 
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="" class="control-label">Position Summary Overview</label>
                                        <textarea class="form-control" name="position" id="position"  placeholder="Position Summary Overview" rows="3">{{$model->position_summary}}</textarea>
                                        <p class="note mb-0">(Max characters 800)
                                            <span class="text-warning font-md remaining-count" id="position-count"></span>
                                        </p> 
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="" class="control-label">Duties and Responsibilities</label>
                                        <textarea class="form-control" name="duties" id="duties" placeholder="Duties and Responsibilities" rows="3" >{{$model->responsibilities}}</textarea>
                                        <p class="note mb-0">(Max characters 600)
                                            <span class="text-warning font-md remaining-count" id="duties-count"></span>
                                        </p>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="" class="control-label">Other Qualifications</label>
                                        <textarea class="form-control" name="qualifications"   id="qualifications"  placeholder="Other Qualifications" rows="3">{{$model->qualifications}}</textarea>
                                        <p class="note mb-0">(Max characters 500)
                                            <span class="text-warning font-md remaining-count" id="qualifications-count"></span>
                                        </p>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label class="control-label">Benefits</label>
                                        <textarea class="form-control"  name="benefits"  id="benefits"  placeholder="Benefits" rows="3">{{$model->qualifications}}</textarea>
                                        <p class="note mb-0">(Max characters 1000)
                                            <span class="text-warning font-md remaining-count" id="benefits-count"></span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="question_section">
                                <div class="heading-row mb-3 d-flex justify-content-between align-items-center">
                                    <h3 class="font-md">Questionnaire</h3>
                                    <a id="questionAppend" class="btn btn-success ripple-effect-dark text-uppercase" onclick="addMore($(this))" href="javascript:void(0);">Add More Question</a>
                                </div>
                                <div class="form-group">
                                    <input type="text"placeholder="Question" name="question[]" id="questionValue" class="form-control que">
                                </div>
                                <div id="que-list">
                                @if(!empty($model->getQuestions))
                                    @foreach($model->getQuestions as $question)
                                <div class="form-group">
                                    <div class="text-right">
                                        <a href="javascript:void(0);"  onclick="deleteRow($(this))" class="remove-it"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                    </div>
                                    <input type="text" placeholder="Question" readonly="readonly" name="question[]" class="form-control que" value="{{$question['questions']}}">
                                </div>
                                    @endforeach
                               @endif
                                </div>
                            </div> 
                    </div>
                </div>
                <button type="submit" class="text-uppercase btn btn-success ripple-effect-dark mt-3 " id="AddJobBtn"> 
                    SUBMIT 
                </button>
            </form>
            {!! JsValidator::formRequest('App\Http\Requests\PostJobRequest','#postjobForm') !!}            
        </div>
    </div>
    <!-- footer-row -->
</main>
<script>
    $(document).ready(function ()
    {
        $("#select-job").change(function () {
            if ($(this).val() === "Freelancer") {
                $("#paymenttype").show();
                $("#rate").show();
            } else {
                $("#paymenttype").hide();
                $("#rate").hide();
            }
        });
    });

    function getSkills() {
        var industryId = $('#industry_type').val();
        if (industryId != '') {
            $.ajax({
                type: "POST",
                url: "{{ url('/user/get-job-skills') }}",
                data: {industryId: industryId, jobId: '{{$model->id}}', _token: '{{csrf_token()}}'},
                success: function (response) {
                    $('#skills').html(response);
                    $('#skills').selectpicker('refresh');
                }
            });
        }
    }
    getSkills();

    $("#AddJobBtn").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#AddJobBtn');
        var form = $('#postjobForm');
        if (form.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{url('/user/add-a-job')}}",
                type: "POST",
                data: $('#postjobForm').serialize(),
                success: function (data)
                {
                    btn.prop('disabled', false);
                    location.reload();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    obj = obj['errors'];
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));

    function addMore(obj) {
        if ($('.que').length <= 4) {
            if ($('#questionValue').val() != '') {
                $('#que-list').append('<div class="form-group">\
                                    <div class="text-right">\
                                        <a href="javascript:void(0);"  onclick="deleteRow($(this))" class="remove-it"><i class="fa fa-trash" aria-hidden="true"></i></a>\
                                    </div>\
                                    <input type="text" placeholder="Question" readonly="readonly" name="question[]" class="form-control que" value="'+$('#questionValue').val()+'">\
                                </div>');
                                        $('#questionValue').val('');
            } else {
                errorToaster('Question field can not be blank.', 'Question');
            }
        } else {
            $('#questionAppend').hide();
        }

    }

    function deleteRow(obj) {
        obj.parent().parent().remove();
        if ($('.que').length >= 4) {
            $('#questionAppend').show();
        }
    }
</script>
@include('layouts.address-autocomplete')
@endsection