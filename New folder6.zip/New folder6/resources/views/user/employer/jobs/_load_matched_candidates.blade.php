@if(count($matchCandidates) > 0)
<div class="row">
    @foreach($matchCandidates as $candidates)
    <div class="col-sm-6 col-md-6 col-lg-4">
        <div class="freelancer">
            <!-- Overview -->
            <div class="freelancer-overview">
                <div class="freelancer-overview-inner">
                    <!-- Avatar -->
                    <div class="freelancer-avatar">
                        <a href="#"><img src="{{url('/public/images/user-01.jpg')}}" alt=""></a>
                    </div>
                    <!-- Name -->
                    <div class="freelancer-name">
                        <h4><a href="#"><span>{{$candidates->getUser->first_name}} {{$candidates->getUser->last_name}}</span></a></h4>
                        <span class="designation">UI/UX Designer</span>
                    </div>
                    <div class="frlance-about">
                        <ul class="list-inline mb-0 mb-lg-2">
                            <li class="list-inline-item">
                                <span class="freelancer-detail-item"><a href="#"><i class="icon-feather-mail"></i> {{$candidates->getUser->email}}</a> </span>
                            </li>
                            <li class="list-inline-item">
                                <i class="icon-feather-phone"></i> +{{$candidates->getUser->getCountry->phone_code}}-{{$candidates->getUser->mobile_number}}
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Details -->
            <div class="freelancer-details">
                <div class="freelancer-details-list">
                    <ul class="list-inline">
                        <li class="list-inline-item">Location <strong><i class="icon-material-outline-location-on"></i> {{$candidates->getUser->city}}</strong></li>
                        <li class="list-inline-item">Experience <strong>{{ $candidates->days}}</strong></li>
                        @if(!empty($candidates->getUser->hourly_rate))
                            <li class="list-inline-item">Rate <strong>{{ $candidates->getUser->hourly_rate}}</strong></li>
                        @endif
                    </ul>
                </div>
                <div class="row">
                    <div class="col-6"><a href="{{url('user/view-profile/'.$candidates->getUser->id.'/'.\App\Helpers\Utility::makeSlug($candidates->getUser->first_name))}}" class="btn btn-block btn-success btn-sm ripple-effect-dark">View Profile</a></div>
                    <div class="col-6"><a href="#" class="btn btn-block btn-warning btn-sm ripple-effect-dark">Request Interview</a></div>
                </div>
            </div>
        </div>
    </div>
    @endforeach
</div>
{{$matchCandidates->links('vendor.pagination.simple-default')}}
@else
<div class="row">
    <div class="col-sm-12">
        <div class="freelancer">
    {{\App\Helpers\Utility::emptyListMessage('candidate')}}
        </div>
    </div>
</div>
@endif

<script>
    $(document).ready(function () {
        var form = $("#frmFilter").serialize();
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var pageLink = $(this).attr('href');
            $('#spinner').show();
            $.ajax({
                type: 'POST',
                data: form,
                url: pageLink,
                async: false,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#matchedCandidates").append(response);
                    $('#spinner').hide();
                }
            });
        });
    });
</script>