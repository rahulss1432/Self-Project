@extends('layouts.user.app')
@section('title','Posted Jobs')
@section('content')
<main class="dashboard-main-wrap employer-main-wrap joblisting-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">My Jobs Listings</li>
                </ol>
            </nav>
            <div class="content-body">
                <section class="job-listing">
                    <div class="common-box ordrer-list">
                        <div class="headline">
                            <h3 class="font-md"><i class="icon-material-outline-business-center"></i>My Job Listings</h3>
                        </div>
                        <div class="content">
                            <div id="jobList">

                            </div>
                        </div>
                    </div>
                </section>

                <div class="text-center">
                    <div class="load_more" id="loadMore" style="display: none;">
                        <a href="javascript:void(0);">
                            <img src="{{url('public/images/load_more.svg')}}" alt="icon">Load More
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function () {
        loadJobList();
    });

    function loadJobList() {
        $("#jobList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $('#spinner').show();
        $.ajax({
            type: "GET",
            url: "{{ url('/user/get-posted-jobs') }}",
            success: function (response)
            {
                $("#jobList").html(response);
                $('#spinner').hide();
            }
        });
    }
</script>
@endsection