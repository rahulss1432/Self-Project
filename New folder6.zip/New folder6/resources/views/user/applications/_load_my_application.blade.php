@if(count($myApplicationData)>0)
<div class="row">
    @foreach($myApplicationData as $applicationData)
    <div class="col-xl-3 col-custom-1200 col-lg-4 col-sm-6">
        <div class="job_box">
            <div class="job_header">
                <div class="job_img d-inline-flex align-items-center justify-content-center">
                    <img src="{{\App\Helpers\Utility::checkCompanyLogo($applicationData->getJob->getUser->company_logo)}}" alt="icon" class="img-fluid">
                </div>
            </div>
            <div class="job_body">
                <h3>{{$applicationData->getJob->job_title}}</h3>
                <h6>{{$applicationData->getJob->city}} - {{$applicationData->getJob->state}}</h6>
                <span class="font-rg">
                    <span class="color-green">{{$applicationData->getJob->job_type}}</span>
                    @if(!empty($applicationData->getJob->experience))
                        <span class="color-yellow">{{$applicationData->getJob->experience}} Years</span>
                    @endif
                </span>
                <p>{{\App\Helpers\Utility::getLimitText(30,$applicationData->getJob->position_summary)}}&nbsp;</p>
                <div class="row d-flex justify-content-between">
                    <div class="col col-sm-6">
                        @if($applicationData->status == 'pending' )
                        <button type="button" class="btn btn-block btn-outline-success btn-sm ripple-effect-dark text-uppercase" disabled>pending</button>
                        @elseif($applicationData->status == 'decline')
                        <button type="button" class="btn btn-block btn-outline-success btn-sm text-uppercase" disabled>Declined</button>
                        @elseif($applicationData->status == 'accepted') 
                        <a href="video-interviews.php"  class="btn btn-block btn-outline-success ripple-effect-dark btn-sm text-uppercase">Record</a>
                        @elseif($applicationData->status == 'interview_submitted')     
                        <button type="button" class="btn btn-block btn-outline-success btn-sm ripple-effect-dark text-uppercase" disabled>Submitted</button>     
                        @endif
                    </div>
                    <div class="col col-sm-6">
                        <a href="{{url('/view-job/'.$applicationData->job_id.'/'.\App\Helpers\Utility::makeslug($applicationData->getJob->job_title))}}" class="btn btn-block btn-outline-warning btn-sm ripple-effect-dark text-uppercase">View Job</a>
                    </div>
                </div>
            </div>
            <div class="job_footer">
                <a href="{{url('/company-profile/'.$applicationData->getJob->user_id.'/'.\App\Helpers\Utility::makeslug($applicationData->getJob->getUser->company_name))}}" class="font-md">View Company Profile</a>
            </div>
        </div>
    </div>
    @endforeach
</div>
@else
<div class="row">
    <div class="col-xl-12">
        {{\App\Helpers\Utility::emptyListMessage('applied jobs')}}
    </div>
</div>
@endif
{{$myApplicationData->links('vendor.pagination.simple-default')}}
<script>
    $(document).ready(function () {
        $('#spinner').hide();
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var pageLink = $(this).attr('href');
            var form = $("#frmFilter").serialize();
            $('#spinner').show();
            $.ajax({
                type: 'POST',
                url: pageLink,
                data: form,
                async: false,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#viewappliedList").append(response);
                    $('#spinner').hide();
                }
            });
        });
    });
</script>
