@extends('layouts.user.app')
@section('title','Applied Jobs')
@section('content')
<main class="dashboard-main-wrap applied_job_page" id="content">
        <div class="container-fluid">
            <div class="common-detail-section">
                <div class="d-md-flex justify-content-between align-items-md-center">
                    <div class="filter_fields status_field">
                        <form id="frmFilter" action="javascript:void(0);" onsubmit="loadMyApplicationList()">
                            {{csrf_field()}}
                            <div class="form-group list-inline-item ml-md-0">
                                <select name="status" title="Status" class="form-control width_custom selectpicker">
                                    <option value="">All Status</option>
                                    <option value="pending">Pending</option>
                                    <option value="accepted">Accepted</option>
                                    <option value="decline">Declined</option>
                                </select>
                            </div>
                            <div class="form-group list-inline-item">
                                <button type="submit"  class="btn btn-success text-uppercase ripple-effect-dark">Search</button>
                            </div>
                            <div class="form-group list-inline-item">
                                    <button type="button" onclick="resetFilter();" class="btn btn-warning text-uppercase ripple-effect-dark">Reset</button>
                            </div>
                        </form>
                    </div>
                    <div class="clearfix"></div>
                    <!-- breadcrumb start-->
                        <nav aria-label="breadcrumb" class="text-right">
                            <ol class="breadcrumb d-inline-flex">
                                <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Applied Job</li>
                            </ol>
                        </nav>
                    <!-- breadcrumb end-->
                </div>
                <div class="content-body">
                    <!-- <h2 class="page-title mt-0">Applied Jobs</h2> -->
                    <div class="card">
                        <div class="card-body">
                            <div id="viewappliedList"></div>
                        <div class="text-center">
                            <div class="load_more" id="loadMore" style="display: none;" >
                                <a href="javascript:void(0);">
                                    <img src="{{url('public/images/load_more.svg')}}" alt="icon">Load More
                                </a>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<script type="text/javascript">
    $(document).ready(function(){
        loadMyApplicationList();
    });
    
    function loadMyApplicationList(){
        $("#viewappliedList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        var form = $("#frmFilter").serialize();
        $.ajax({
            type: "POST",
            data: form,
            url: "{{url('/user/load-my-applied-list')}}",
            success: function (response) {
                $('#viewappliedList').html(response);
            }
        });
    }
    
    function resetFilter(){
        $('#frmFilter')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadMyApplicationList();
    }
</script>
@endsection
