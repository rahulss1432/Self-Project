@if(count($myApplicationData)>0)
<div class="row">
    @foreach($myApplicationData as $applicationData)
    <div class="col-xl-3 col-custom-1200 col-lg-4 col-sm-6">
        <div class="job_box">
            <div class="job_header">
                <div class="job_img d-inline-flex align-items-center justify-content-center">
                    <img src="{{\App\Helpers\Utility::checkCompanyLogo($applicationData->getJob->getUser->company_logo)}}" alt="icon" class="img-fluid">
                </div>
            </div>
            <div class="job_body">
                <h3>{{$applicationData->getJob->job_title}}</h3>
                <h6>{{$applicationData->getJob->city}} - {{$applicationData->getJob->state}}</h6>
                <span class="font-rg">
                    <span class="color-green">{{$applicationData->getJob->job_type}}</span>
                    @if(!empty($applicationData->getJob->experience))
                         <span class="color-yellow">{{$applicationData->getJob->experience}} Years</span>
                    @endif
                </span>
                <p>{{\App\Helpers\Utility::getLimitText(30,$applicationData->getJob->position_summary)}}&nbsp; </p>
                @if($applicationData->status == 'pending' )
                    <div class="row d-flex justify-content-between">
                        <div class="col col-sm-6">
                                <button type="button" class="btn btn-block btn-outline-success btn-sm ripple-effect-dark text-uppercase">ACCEPT</button>
                        </div>
                        <div class="col col-sm-6">
                            <input type="hidden" id="hiddenJobInvitationId" name="id" value="">
                                <button type="button" class="btn btn-block btn-outline-warning btn-sm ripple-effect-dark text-uppercase" onclick="declineModal({{$applicationData->id}});">DECLINE</button>
                        </div>
                    </div>
                @elseif($applicationData->status == 'decline')
                    <div class="d-flex justify-content-center">
                       <button type="button" class="btn d-inline-block btn-outline-success ripple-effect-dark btn-sm text-uppercase" disabled>Declined</button>
                    </div> 
                @elseif($applicationData->status == 'accepted')
                    <div class="d-flex justify-content-center">
                        <a href="video-interviews.php"  class="btn d-inline-block btn-outline-success ripple-effect-dark btn-sm text-uppercase">Record</a>
                    </div>
                @elseif($applicationData->status == 'interview_submitted')
                    <div class="d-flex justify-content-center">
                       <button type="button" class="btn d-inline-block btn-outline-success ripple-effect-dark btn-sm text-uppercase" disabled>Submitted</button> 
                    </div>
                @endif
               </div>
        
            <div class="job_footer d-flex justify-content-between">
                <a href="{{url('/company-profile/'.$applicationData->getJob->user_id.'/'.\App\Helpers\Utility::makeslug($applicationData->getJob->getUser->company_name))}}" class="font-md">View Company Profile</a>
                <a href="{{url('/view-job/'.$applicationData->job_id.'/'.\App\Helpers\Utility::makeslug($applicationData->getJob->job_title))}}" class="font-md color-yellow">View Job</a>
            </div>
        </div>        
    </div>
    @endforeach
</div>
@else
<div class="row">
    <div class="col-xl-12">
        {{\App\Helpers\Utility::emptyListMessage('invitation')}}
    </div>
</div>
@endif
{{$myApplicationData->links('vendor.pagination.simple-default')}}
<script>
    $(document).ready(function () {
        $('#spinner').hide();
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var pageLink = $(this).attr('href');
            $('#spinner').show();
            $.ajax({
                type: 'GET',
                url: pageLink,
                async: false,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#requestReceivedlist").append(response);
                    $('#spinner').hide();
                }
            });
        });
    });
</script>
