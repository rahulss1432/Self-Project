@if(($userEducation)->count()>0)
<div class="row">
<div class="col-12">
    <label class="field-heading font-md d-block w-100">Education</label>
</div>
</div>
@foreach($userEducation as $education)
<div class="row">
<div class="col-12">
    <div class="exprience-detail">
		<div class="action-btn">
			<a href="javascript:void(0);" onclick="actionEducation('{{$education["id"]}}');" class="rounded-circle btn btn-success btn-sm ml-md-2"><i class="fa fa-pencil"></i></a>
        	<a href="javascript:void(0);" onclick="deleteEducation('{{$education["id"]}}','{{$education["title"]}}')" class="rounded-circle btn btn-warning btn-sm ml-md-2"><i class="fa fa-trash"></i></a>
		</div>
		<p class="mb-0"><b>{{$education['university']}}</b></p>
        <p class="mb-0">{{$education['degree']}}</p>
        <p class="mb-0">{{$education['course_name']}}</p>
        <p><b>From :</b> {{\App\Helpers\Utility::getDateFormat($education['duration_from'])}} <b>To</b> {{($education['is_working']=='no')?\App\Helpers\Utility::getDateFormat($education['duration_to']):'Currently studying here.'}}</p>
	</div>
</div>
</div>

@endforeach
@endif

<script>
    var title = 'Education';
    function deleteEducation(id, name) {
        bootbox.confirm('Are you sure do you want to delete <b>' + name + '<b>?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "{{ url('user/delete-education') }}",
                    data: {id: id},
                    success: function (response) {
                        if (response.status) {
                            successToaster(response.message, title);
                            loadEducationList();
                        }
                    }
                });
            }
        });
    }
</script>