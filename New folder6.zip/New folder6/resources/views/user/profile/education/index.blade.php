@extends('layouts.user.app')
@section('title','Education')
@section('content')
<main class="dashboard-main-wrap step-form jobseeker-steps">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="content-body">
                <!-- <h2 class="page-title mt-0">Update Profile</h2> -->
                <!-- breadcrumb start-->
                <nav aria-label="breadcrumb" class="text-right">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Education</li>
                    </ol>
                </nav>
                <!-- breadcrumb end-->
                <div class="form-wrap">
                    @include('user.profile.links')

                    <!-- xxxxxxxxxxx -->


                    <section class="step-form-body">
                        <div class="form04 common-form" id="form02">
                            <div class="inner-body">
                                <div id="educationList"></div>
                                <!-- field-heading -->
                                <div class="clearfix"></div>

                                <div id="educationHtml">

                                </div>
                            </div>
                        </div>
                        <!-- xxxxxxxxxxx -->
                    </section>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    function actionEducation(id) {
        $.ajax({
            type: "GET",
            url: "{{ url('/user/get-education-form') }}",
            data: {id: id},
            success: function (response) {
                $('#educationHtml').html(response);
            },
            complete: function () {
                $('html,body').animate({scrollTop: 1000});
            }
        });
    }
    actionEducation(0);
    function loadEducationList() {
        $("#educationList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "GET",
            url: "{{ url('/user/get-education-list') }}",
            success: function (response) {
                $('#educationList').html(response);
            }
        });
    }
    loadEducationList();

    $('#expForm').on('submit', function (e) {
        if ($('#expForm').valid()) {
            $('#expBtn').html('{{\App\Helpers\Utility::buttonLoader()}}  Submit');
            $("#expBtn").prop('disabled', true);
        }
    });
</script>
@endsection