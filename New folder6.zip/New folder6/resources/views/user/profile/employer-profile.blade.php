@extends('layouts.user.app')
@section('title','Edit Profile')
@section('content')
<main class="dashboard-main-wrap employer-main-wrap  setupprofile-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
          <!--   <section class="page-header">
                <div class="page-heading font-md">
                    <h1 class="">Setup Profile</h1>
                </div>
            </section> -->
            <nav aria-label="breadcrumb" class="text-right">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Profile</li>
                </ol>
            </nav>
            <form autocomplete="off" id="editCompanyForm" method="POST" action="javascript:void(0);" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="common-box mt-0">
                    <div class="headline">
                        <h3 class="font-md">
                            <i class="icon-material-outline-account-circle"></i> Edit Profile</h3>
                    </div>
                    <div class="content">
                        <div class="row user-info">
                            <div class="col left-side">
                                <div class="profile-pic" data-toggle="tooltip" data-placement="bottom" title="Change Profile Picture">
                                    <img src="{{\App\Helpers\Utility::checkProfileImage($userDetails->profile_image)}}" alt="logo" class="profileImage">
                                    <input type="file"  onchange="setImage(this)" id="cropImageInput" class="logo-upload">
                                </div>
                            </div>
                            <div class="col right-side">
                                <div class="headline p-0">
                                    <h3 class="font-md"><i class="icon-material-outline-account-circle"></i> Personal Info</h3>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">First Name</label>
                                            <input type="text" name="first_name" placeholder="First Name" value="{{$userDetails->first_name}}" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Last Name</label>
                                            <input type="text" name="last_name" placeholder="Last Name" value="{{$userDetails->last_name}}" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Email</label>
                                            <input type="text" value="{{$userDetails->email}}" class="form-control" disabled>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Phone Number</label>
                                            <input type="text" name="phone_number" value="{{$userDetails->mobile_number}}" placeholder="Phone Number" maxlength="13" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col left-side">
                                <div class="profile-pic" data-toggle="tooltip" data-placement="bottom" title="Change Logo">
                                    <img src="{{\App\Helpers\Utility::checkCompanyLogo($userDetails->company_logo)}}" alt="logo" class="companyImage">
                                    <input type="file" onchange="setLogoImage(this)" id="cropLogoInput" class="logo-upload">
                                </div>
                            </div>
                            <div class="col right-side">
                                <div class="headline company p-0">
                                    <h3 class="font-md"><i class="fa fa-briefcase"></i> Company Info</h3>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Company Name</label>
                                            <input type="text" name="company_name" value="{{$userDetails->company_name}}" placeholder="Company Name" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Address</label>
                                            <input id="address" type="text" name="address" value="{{$userDetails->address}}" placeholder="Address" class="form-control" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Country</label>
                                            <select id="user-country" name="country" class="form-control selectpicker select02" title="Country" data-live-search="true"> 
                                                @php 
                                                $country = \App\Models\Country::getCountriesDropdown($userDetails->country); 
                                                echo $country;
                                                @endphp
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">State</label>
                                            <input id="user-administrative_area_level_1" type="text" name="state" value="{{$userDetails->state}}" placeholder="State" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">City</label>
                                            <input id="user-locality" type="text" name="city" value="{{$userDetails->city}}" placeholder="City" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Postal Code</label>
                                            <input id="user-postal_code" type="text" name="postal_code" value="{{($userDetails->zipcode != 0)? $userDetails->zipcode : ''}}" placeholder="Postal Code" maxlength="7" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Industry Type</label>
                                            <select name="industry_type" class="selectpicker form-control" data-live-search="true" title="Industry Type">
                                                <option value="">Industry Type</option>
                                                @if(!empty($industries))
                                                @foreach($industries as $industry)
                                                    <option {{($userDetails->industry_type == $industry->id)?'selected="selected"':''}} value="{{$industry->id}}">{{$industry->industry_name}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Employee Strength</label>
                                            <select name="employee_strength" class="form-control selectpicker select03" title="Employee Strength" required>
                                                <option value="">Employee Strength</option>
                                                <option {{($userDetails->employee_strength == '0-25')?'selected="selected"':''}} value="0-25">0-25</option>
                                                <option {{($userDetails->employee_strength == '25-50')?'selected="selected"':''}} value="25-50">25-50</option>
                                                <option {{($userDetails->employee_strength == '50-100')?'selected="selected"':''}} value="50-100">50-100</option>
                                                <option {{($userDetails->employee_strength == '100-150')?'selected="selected"':''}} value="100-150">100-150</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Website URL</label>
                                            <input name="website_url" type="text" value="{{$userDetails->website_url}}" placeholder="Website URL" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Linkedin Profile</label>
                                            <input type="text" name="linkedin_url" value="{{$userDetails->linkedin_url}}" placeholder="Linkedin Profile URL" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Facebook</label>
                                            <input type="text" name="facebook_url" value="{{$userDetails->facebook_url}}" placeholder="Facebook Page URL" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Twitter</label>
                                            <input type="text" name="twitter_url" value="{{$userDetails->twitter_url}}" placeholder="Twitter Profile URL" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group upload-image">
                                            <label class="control-label">Upload Banner Image</label>
                                            <div class="input-group">
                                                <input type="text" placeholder="Upload Banner Image" id="banner_image" class="form-control" value="{{$userDetails->banner_image}}" disabled>
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="fa fa-upload" aria-hidden="true"></i></div>
                                                    <input type="file" name="banner_image" class="Upload-file" id="banner_input"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group upload-image">
                                            <label class="control-label">Upload Video to showcase company</label>
                                            <div class="input-group">
                                                <input id="video" type="text" placeholder="Upload Video" class="form-control" value="{{$userDetails->showcase_video}}" disabled>
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="fa fa-upload" aria-hidden="true"></i>
                                                    </div>
                                                    <input type="file" name="video" class="Upload-file" id="video_input"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="control-label">Speciality</label>
                                                    <textarea rows="3" class="form-control" name="speciality" placeholder="Speciality">{{$userDetails->spaciality}}</textarea>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="control-label">About us</label>
                                                    <textarea rows="3" class="form-control" name="about_us" placeholder="About us">{{$userDetails->about_us}}</textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button type="submit" class="text-uppercase btn btn-success mt-3 ripple-effect-dark" id="updateCompanyBtn"> 
                    <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> SAVE CHANGES
                </button>
            </form>
            {!! JsValidator::formRequest('App\Http\Requests\EditCompanyProfileRequest','#editCompanyForm') !!}
        </div>
    </div>
    <!-- footer-row -->
</main>
<!-- category model end -->
<div class="modal fade" id="imageCropperModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="imageCropperModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addindustyModal">Profile Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="image_container">
                    <img alt="image" src="" id="crop_image" class="img-responsive" height="auto" width="100%"/>
                </div>
                <input type="hidden" id="imageBaseCode">
                <input type="hidden" id="imageType">
                <div class="clearfix"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn ripple-effect-dark btn-danger btn-sm text-uppercase" data-dismiss="modal">Close</button>
                <button type="button" class="btn ripple-effect-dark btn-success btn-sm text-uppercase" id="cropbutton">Save</button>
            </div>
        </div>
    </div>
</div>



<link href="{{ url('public/css/cropper.min.css') }}" rel="stylesheet">
<script src="{{ url('public/js/cropper.min.js') }}"></script>
<script>
    $("#banner_image").click(function () {
        $("input[id='banner_input']").click();
    });

    $("input[id='banner_input']").change(function (e) {
        var $this = $(this);
        $('#banner_image').val($this.val().split('\\').pop());
    });
    
    $("#video").click(function () {
        $("input[id='video_input']").click();
    });

    $("input[id='video_input']").change(function (e) {
        var $this = $(this);
        $('#video').val($this.val().split('\\').pop());
    });
    
    $("#updateCompanyBtn").on('click', (function(e) {
        e.preventDefault();
        var btn = $('#updateCompanyBtn');
        var form = $('#editCompanyForm');
        if (form.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{url('/user/update-company')}}",
                type: "POST",
                data: new FormData($('#editCompanyForm')[0]),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data)
                {
                    location.reload();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    obj = obj['errors'];
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
</script>
<script>
    function setImage(input) {
        $('#crop_image').attr('src', '');
        $('#imageBaseCode').val('');
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#addindustyModal').html('Profile Image');
                $("#imageCropperModal").modal("show");
                $("#imageType").val('profile_image');
                $('#crop_image').attr('src', e.target.result);
                $('#imageBaseCode').val(e.target.result);
                setTimeout(function () {
                    loadCropper();
                }, 200);

            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    $('#imageCropperModal').on('hidden.bs.modal', function (e) {
        var $image = $("#crop_image");
        var input = $("#cropImageInput");
        input.replaceWith(input.val('').clone(true));
        $image.cropper("destroy");
    });
//cropper
    function loadCropper() {
        var $image = $("#crop_image");
        $image.cropper({
            viewMode: 1,
            dragMode: 'move',
            aspectRatio: 1,
            movable: false,
            zoomable: true,
            rotatable: true,
            center: true,
            responsive: true,
            cropBoxResizable: true,
        });
    }
    
    $("#cropbutton").click(function () {
        $('#crop_image').attr('src', '');
        var $image = $("#crop_image");
        $("#cropbutton").html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
        $("#cropbutton").attr('disabled', true);
        var imageBaseCode = $('#imageBaseCode').val();
        var imageType = $("#imageType").val();
        var imageCropedData = $image.cropper('getData');
        var croppedWidth = imageCropedData.width;
        var croppedHeight = imageCropedData.height;
        var croppedX = imageCropedData.x;
        var croppedY = imageCropedData.y;
        var rotate = imageCropedData.rotate;
        var url = "{{url('/user/save-profile-image')}}";
        $.ajax({
            type: "POST",
            url: url,
            dataType: 'JSON',
            data: {
                imageBaseCode: imageBaseCode,
                imageType: imageType,
                croppedWidth: croppedWidth,
                croppedHeight: croppedHeight,
                croppedX: croppedX,
                croppedY: croppedY,
                rotate: rotate,
                _token: '{{csrf_token()}}'
            },
            success: function (response) {
                if (response.success) {
                    $("#imageCropperModal").modal("hide");
                    $image.cropper('destroy');
                    $("#cropbutton").attr('disabled', false);
                    $("#cropbutton").html('Save');
                    if(response.imageType=='profile_image'){
                    $('.profileImage').attr('src', response.filename);
                }else{
                    $('.companyImage').attr('src', response.filename);
                }
                }
            }
        });
    });
    
    function setLogoImage(input) {
       $('#crop_image').attr('src', '');
        $('#imageBaseCode').val('');
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                 $('#addindustyModal').html('Company Logo');
                 $("#imageType").val('company_logo')
                $("#imageCropperModal").modal("show");
                $('#crop_image').attr('src', e.target.result);
                $('#imageBaseCode').val(e.target.result);
                setTimeout(function () {
                    loadCropper();
                }, 200);

            };
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
@include('layouts.address-autocomplete')
@endsection