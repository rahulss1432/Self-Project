<section class="step-form-header">
    <ul class="list-unstyled mb-0 d-flex justify-content-center">
        <li class="{{ (\Request::route()->getName() == 'user.edit-profile') ? 'active' : '' }}"><a href="{{url('/user/edit-profile')}}">Personal Details</a></li>
        <li class="{{ (\Request::route()->getName() == 'user.experience') ? 'active' : '' }}"><a href="{{url('/user/experience')}}">Experience</a></li>
        @if(Auth::user()->user_type=='freelancer')
        <li class="{{ (\Request::route()->getName() == 'user.portfolio') ? 'active' : '' }}"><a href="{{url('/user/portfolio')}}">Portfolio</a></li>
        @endif
        <li class="{{ (\Request::route()->getName() == 'user.skills') ? 'active' : '' }}"><a href="{{url('/user/skills')}}">Skills</a></li>
        <li class="{{ (\Request::route()->getName() == 'user.education') ? 'active' : '' }}"><a href="{{url('/user/education')}}">Education</a></li>
        <li class="{{ (\Request::route()->getName() == 'user.promo-video') ? 'active' : '' }}"><a href="{{url('/user/promo-video')}}">Promo Video</a></li>
    </ul>
</section>