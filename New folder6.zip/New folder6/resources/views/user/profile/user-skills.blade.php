@extends('layouts.user.app')
@section('title','Skills')
@section('content')
@php $i=0; $skillsArray=array(); $industryId=0; @endphp
@if(!empty($userSkills))
@foreach($userSkills as $skill)
@php 
if($i==0){
$industryId = $skill->getSkill->industry_id;
} 
$skillsArray[]=$skill->skill_id; 
$i++; 
@endphp
@endforeach
@endif
<main class="dashboard-main-wrap step-form jobseeker-steps" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <!-- breadcrumb start-->
            <nav aria-label="breadcrumb" class="text-right">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Skills</li>
                </ol>
            </nav>
            <!-- breadcrumb end-->
            <div class="content-body">
                <!-- <h2 class="page-title mt-0">Update Profile</h2> -->
                <div class="form-wrap">
                    @include('user.profile.links')

                    <!-- xxxxxxxxxxx -->
                    <section class="step-form-body">
                        <div class="form03 common-form" id="form02">
                            <div class="inner-body">
                                <form id="skillsForm" method="post" action="{{url('/user/user-skills-submit')}}">
                                    {{csrf_field()}}
                                    <div class="row">

                                        <!-- field-heading -->
                                        <div class="col-12">
                                            <label class="field-heading font-md d-block w-100">Select Industry type</label>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <select name="industry_type" id="industry_type" onchange="getSkills()" class="selectpicker form-control" data-live-search="true" title="Industry Type">
                                                    <option value="">Industry Type</option>
                                                    @if(!empty($industries))
                                                    @foreach($industries as $industry)
                                                    <option {{($industryId==$industry->id)?'selected="selected"':''}} value="{{$industry->id}}">{{$industry->industry_name}}</option>
                                                    @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                        </div>


                                        <!-- field-heading -->
                                        <div class="col-12">
                                            <label class="field-heading font-md d-block w-100">What are your areas of expertises?</label>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <select name="skills[]" id="skills" multiple="true" class="selectpicker form-control" title="Select Skills">
                                                    
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-12 btn-row">
                                            <button type="submit" class="text-uppercase btn btn-success"> save <span class="and-font">&</span> continue</button>
                                        </div>
                                    </div><!-- row end -->
                                </form>
                                {!! JsValidator::formRequest('App\Http\Requests\UserSkillRequest','#skillsForm') !!}
                            </div>
                        </div>

                        <!-- xxxxxxxxxxx -->

                    </section>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    function getSkills() {
        var industryId = $('#industry_type').val();
        if (industryId != '') {
            $.ajax({
                type: "GET",
                url: "{{ url('/user/get-skills-list') }}/" + industryId,
                success: function (response) {
                    $('#skills').html(response);
                    $('#skills').selectpicker('refresh');
                }
            });
        }
    }
    getSkills();
</script>
@endsection