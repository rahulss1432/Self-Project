@extends('layouts.user.app')
@section('title','View Profile')
@section('content')
<main class="main-wrapper dashboard-main-wrap view-profile-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Company Profile</li>
                </ol>
            </nav>
            <div class="row">
                @if(!empty($userDetails->banner_image))
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 font-md">Company Banner</h3>
                        </div>
                        <div class="card-body video_box">
                            <img src="{{\App\Helpers\Utility::checkCompanyBanner($userDetails->banner_image)}}" class="img-fluid">
                        </div>
                    </div>
                </div>
                @endif
                <div class="col-lg-3 pr-md-0 left-section">
                    <div class="card">
                        <div class="card-body profile-box link_box text-center pt-2">
                            @if(Auth::user()->id == $userDetails->id)
                            <div class="text-right">
                                <a href="{{url('/user/edit-profile')}}" class="edit-icon">
                                    <img src="{{url('public/images/edit-icon.svg')}}" alt="icon">
                                </a>
                            </div>
                            @endif
                            <div class="user-img">
                                <img src="{{\App\Helpers\Utility::checkCompanyLogo($userDetails->company_logo)}}" alt="logo" class="img-fluid rounded-circle">
                            </div>
                            <h2 class="user-name font-md">{{$userDetails->company_name}}</h2>
                            <p class="">{{$userDetails->address}}</p>
                            <div class="form-group mb-0">
                                <div class="input-group">
                                    <input type="text" class="form-control" readonly value="https://rezieo.infoipsum....">
                                    <div class="input-group-append" id="button-addon4">
                                        <button class="btn btn-success ripple-effect-dark" type="button">COPY</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 font-md">See me on</h3>
                        </div>
                        <div class="card-body social-media-box">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <a target="_blank" href="{{$userDetails->facebook_url}}" class="facebook ripple-effect">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a target="_blank" href="{{$userDetails->linkedin_url}}" class="linkdin ripple-effect">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a target="_blank" href="{{$userDetails->twitter_url}}" class="twitter ripple-effect">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <!-- xxxxx -->

                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 font-md">Employee Strength</h3>
                        </div>
                        <div class="card-body">
                            <p class="font-md mb-0">{{$userDetails->employee_strength}}</p>
                        </div>
                    </div>

                    <!-- xxxxx -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 font-md">Contact Information</h3>
                        </div>
                        <div class="card-body education-box">
                            <div class="para mb-3 mb-lg-4">
                                <h4 class="font-md mb-1">Contact Person:</h4>
                                <p class="mb-1 font-rg">{{$userDetails->first_name}} {{$userDetails->last_name}}</p>
                            </div>
                            <div class="para mb-3 mb-lg-4">
                                <h4 class="font-md mb-1">Email address:</h4>
                                <p class="mb-1 font-rg">{{$userDetails->email}}</p>
                            </div>
                           @if(!empty($userDetails->mobile_number))
                            <div class="para mb-3 mb-lg-4">
                                <h4 class="font-md mb-1">Phone Number:</h4>
                                <p class="mb-1 font-rg">+{{$userDetails->getCountry->phone_code}}-{{$userDetails->mobile_number}}</p>
                            </div>
                           @endif
                           @if(!empty($userDetails->address))
                            <div class="para">
                                <h4 class="font-md mb-1">Address:</h4>
                                <p class="mb-1 font-rg">{{$userDetails->address}}</p>
                            </div>
                           @endif
                        </div>
                    </div>
                    <!-- xxxxx -->
                </div>
                <!-- xxxxxxx -->
                <div class="col-xl-9 right-section">
                    @if(!empty($userDetails->showcase_video))
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 font-md">Company Showcase Video</h3>
                        </div>
                        <div class="card-body video_box">
                            <video alt="video-img" class="img-fluid" controls>
                                <source src="{{url('public/uploads/company/showcase/'.$userDetails->showcase_video)}}" type="video/mp4">
                            </video>
                        </div>
                    </div> 
                    @endif
                    <!-- xxxxxx -->
                    @if(!empty($userDetails->about_us))
                    <div class="card mb-0 rounded-0 rounded-top">
                        <div class="card-header">
                            <h3 class="mb-0 font-md">About Company</h3>
                        </div>
                        <div class="card-body resume-box">
                            <p class="font-rg mb-2">
                                {{$userDetails->about_us}}
                            </p>
                        </div>
                    </div>
                    @endif

                    @if(!empty($userDetails->spaciality))
                    <!-- xxxxx -->
                    <div class="card rounded-0 mb-0">
                        <div class="card-header pt-0">
                            <h3 class="mb-0 font-md">Speciality</h3>
                        </div>
                        <div class="card-body resume-box">
                            <p class="font-rg">{{$userDetails->spaciality}}</p>
                        </div>
                    </div>
                    @endif
                    <!-- xxxxxx -->
                    <!-- xxxxxxxx -->
                </div>
            </div>

        </div>
    </div>
</main>
<!-- category model end -->
@endsection