@extends('layouts.user.app')
@section('title','Education')
@section('content')
<main class="dashboard-main-wrap step-form jobseeker-steps">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="content-body">
                <!-- <h2 class="page-title mt-0">Update Profile</h2> -->
                <!-- breadcrumb start-->
                <nav aria-label="breadcrumb" class="text-right">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Education</li>
                    </ol>
                </nav>
                <!-- breadcrumb end-->
                <div class="form-wrap">
                    @include('user.profile.links')

                    <!-- xxxxxxxxxxx -->


                    <section class="step-form-body">
                        <div class="form04 common-form" id="form02">
                            <div class="inner-body">
                                <form>
                                    <div class="row">                                            
                                        <!-- field-heading -->
                                        <div class="col-12">
                                            <label class="field-heading font-md d-block w-100">Education</label>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="University">
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Degree">
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Minor">
                                            </div>
                                        </div>


                                        <!-- field-heading -->
                                        <div class="col-12">
                                            <label class="field-heading font-md d-block w-100">Duration</label>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control datetimepicker-input date" id="datetimepicker1" data-toggle="datetimepicker" data-target="#datetimepicker1" placeholder="From" />
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control datetimepicker-input date" id="datetimepicker2" data-toggle="datetimepicker" data-target="#datetimepicker2" placeholder="To">
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="custom-control custom-checkbox mb-4">
                                                <input type="checkbox" class="custom-control-input" id="remeberme"> 
                                                <label class="custom-control-label" for="remeberme"><span>I currently study here.</span></label>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div id="addon-edu"></div>
                                        </div>

                                        <div class="col-md-12 text-center mt-3 btn-row mt-lg-5">
                                            <a href="javscript:void(0);" class="text-uppercase btn btn-success" onclick="addMoreEducation()">add more</a>
                                            <a href="promo-video.php" class="text-uppercase btn btn-warning ml-md-3"> save <span class="and-font">&</span> continue</a>
                                        </div>
                                    </div><!-- row end -->
                                </form>
                            </div>
                        </div>
                        <!-- xxxxxxxxxxx -->
                    </section>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection