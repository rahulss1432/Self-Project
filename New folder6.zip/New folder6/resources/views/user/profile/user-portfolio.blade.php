@extends('layouts.user.app')
@section('title','Skills')
@section('content')
<main class="dashboard-main-wrap step-form jobseeker-steps" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <!-- breadcrumb start-->
            <nav aria-label="breadcrumb" class="text-right">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Skills</li>
                </ol>
            </nav>
            <!-- breadcrumb end-->
            <div class="content-body">
                <!-- <h2 class="page-title mt-0">Update Profile</h2> -->
                <div class="form-wrap">
                    @include('user.profile.links')

                    <!-- xxxxxxxxxxx -->


                    <section class="step-form-body">
                        <div class="form02 common-form" id="form02">
                            <div class="inner-body">
                                <form>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="d-flex justify-content-between">
                                                <h2 class="page-title mt-0">Add Project</h2>
                                                <a href="javscript:void(0);" id="projectAddBtn" class="text-uppercase btn btn-sm btn-success mb-3 add-portfolio" style="display: none">add project</a>
                                            </div>

                                        </div>


                                        <!-- xxxxxxxxxxx -->


                                        <div class="col-12">
                                            <span id="deleteFirst" class="delete-it rounded-circle" data-toggle="tooltip" data-placement="top" title="Delete">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                            </span>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="Project Title">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="Project Type">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="Duration">
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="Client details">
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group currency-group">
                                                        <input type="text" class="form-control" placeholder="Project amount in USD">
                                                        <span class="currency">USD</span>
                                                    </div>
                                                </div>


                                                <div class="col-md-12">
                                                    <div class="form-group link-group" >
                                                        <input type="text" class="form-control link-value" id="linkValue" placeholder="Project Link" required>
                                                        <a href="javscript:void(0);" class="add-link link-disabled" onclick="link_append();" data-toggle="tooltip" data-placement="top" title="Add Link" id="addLinks">
                                                            <img src="{{url('public/images/add-icon.png')}}" alt="add">
                                                        </a>
                                                    </div>
                                                    <div id="moreLinks"></div>

                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <textarea rows="4" class="form-control" placeholder="Description"></textarea>
                                                    </div>
                                                </div>
                                                <!-- field-heading -->
                                                <div class="col-12">
                                                    <label class="field-heading font-md d-block w-100">Upload Document</label>
                                                </div>
                                                <div class="col-md-12">
                                                    <label class="upload-btn">
                                                        <input type="file" hidden>
                                                        <p href="javascript:void(0);" class="text-uppercase btn-success ripple-effect-dark btn mb-0">
                                                            <img src="{{url('public/images/upload-ic.png')}}" alt="">
                                                            <small>upload document</small>
                                                        </p>
                                                        <span>No file is selected...</span>
                                                    </label>
                                                    <div class="note mb-3">
                                                        <p class="font-rg mb-1">File upload in Docx, PDF, JPEG
                                                            <span style="font-family: sans-serif;">&</span> JPG format</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                        <!-- xxxxxxxxxxx -->


                                        <div class="col-12">
                                            <div id="addon-portfolio"></div>
                                        </div>


                                        <div class="col-md-12 text-center mt-3 btn-row mt-sm-5">
                                            <a href="javscript:void(0);" class="text-uppercase btn btn-success add-portfolio" id="addPortfolio">add more</a>
                                            <a href="skills.php" class="text-uppercase btn btn-warning ml-0 ml-sm-3"> save
                                                <span class="and-font">&</span> continue</a>
                                        </div>
                                    </div>
                                    <!-- row end -->
                                </form>
                            </div>
                        </div>
                        <!-- xxxxxxxxxxx -->
                    </section>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection