@if(($userExperience)->count()>0)
<div class="row">
	<div class="col-12">
		<label class="field-heading font-md d-block w-100">Experience</label>
	</div>
</div>
@foreach($userExperience as $experience)
<div class="row">
	<div class="col-12">
	   <div class="exprience-detail">
			<div class="action-btn">
				<a href="javascript:void(0);" onclick="actionExperience('{{$experience["id"]}}');" class="rounded-circle btn btn-success btn-sm ml-md-2" ><i class="fa fa-pencil"></i></a>
				<a href="javascript:void(0);" onclick="deleteExperience('{{$experience["id"]}}','{{$experience["title"]}}')" class="rounded-circle btn btn-warning btn-sm ml-md-2"><i class="fa fa-trash"></i></a>  
			</div>
			<p><strong>{{$experience['title']}}</strong></p>
			<p>{{$experience['company_name']}}</p>
			<p><strong>From :</strong> {{\App\Helpers\Utility::getDateFormat($experience['duration_from'])}} <strong>To</strong> {{($experience['is_working']=='no')?\App\Helpers\Utility::getDateFormat($experience['duration_to']):'Currently work here.'}}</p>
	   </div>
	</div>
</div>
@endforeach
@endif

<script>
    var title = 'Experience';
    function deleteExperience(id, name) {
        bootbox.confirm('Are you sure do you want to delete <b>' + name + '<b>?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "{{ url('user/delete-experience') }}",
                    data: {id: id},
                    success: function (response) {
                        if (response.status) {
                            successToaster(response.message, title);
                            loadExperienceList();
                        }
                    }
                });
            }
        });
    }
</script>