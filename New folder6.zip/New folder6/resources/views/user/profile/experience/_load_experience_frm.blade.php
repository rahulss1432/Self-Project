<!-- field-heading -->
<form id="experienceForm" method="POST" action="{{url('/user/save-experience')}}">
    {{csrf_field()}}
    <input type="hidden" name="id" value="{{$model->id}}">
    <div class="row">
        @if(empty($model->id))
        <div class="col-12">
            <label class="field-heading font-md d-block w-100">Add New Experience</label>
        </div>
        @else
        <div class="col-12">
            <label class="field-heading font-md d-block w-100"> Edit Experience</label>
        </div>
        @endif
        <div class="col-sm-6">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Title" name="title" value="{{$model->title}}">
            </div>
        </div>

        <div class="col-sm-6">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Company Name" name="company_name" value="{{$model->company_name}}">
            </div>
        </div>

        <!-- field-heading -->
        <div class="col-12">
            <label class="field-heading font-md d-block w-100">Duration</label>
        </div>

        <div class="col-sm-6">
            <div class="form-group">

                <input type="text" readonly="true" name="duration_form" value="{{(strtotime($model->duration_from)>0)?date("d-m-Y",strtotime($model->duration_from)):''}}" class="form-control date from_date"  data-toggle="datetimepicker" data-target="#datetimepicker1" id="datetimepicker1" placeholder="From Date" />
            </div> 
        </div>

        <div class="col-sm-6">
            <div class="form-group">

                <input type="text" readonly="true"  name="duration_to" value="{{(strtotime($model->duration_to)>0)?date("d-m-Y",strtotime($model->duration_to)):''}}" class="form-control date to_date" data-toggle="datetimepicker" data-target="#datetimepicker2" id="datetimepicker2" placeholder="To Date">
            </div>
        </div>

        <div class="col-md-12">
            <div class="custom-control custom-checkbox mb-4">
                <input type="checkbox" onchange="disDurationTo()" class="custom-control-input" id="remeberme" {{($model->is_working=='yes')?'checked="checked"':''}} name="is_working" value="yes"> 
                <label class="custom-control-label" for="remeberme"><span>I currently work here</span></label>
            </div>
        </div>
        <div class="col-md-12 btn-row">
            @if(empty($model->id))
            <button id="btn-experience" class="btn btn-success">Save <span class="and-font">&</span> Add More</button>
            <button id="submitBtn" type="submit" class="btn btn-warning ml-md-3">Save <span class="and-font">&</span> Next</button>
            @else
            <button id="btn-experience" class="btn btn-success">Update</button>
            <button type="button" class="btn btn-warning ml-md-3" onclick="actionExperience(0)">Cancel</button>
            @endif
        </div>
    </div>
</form>
{!! JsValidator::formRequest('App\Http\Requests\ExperienceRequest','#experienceForm') !!}
<script>
    $("#btn-experience").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btn-experience');
        var form = $('#experienceForm');
        if (form.valid()) {
        btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
                btn.prop('disabled', true);
                $.ajax({
                url: "{{(url('/user/experience-submit'))}}",
                        type: "POST",
                        data: form.serialize(),
                        success: function (data)
                        {
                            successToaster(data.message, 'Experience');
                            loadExperienceList();
                            actionExperience(0);
                        },
                        error: function (data) {
                            var obj = jQuery.parseJSON(data.responseText);
                            obj = obj['errors'];
                            for (var x in obj) {
                            btn.prop('disabled', false);
                                    btn.html('Submit');
                                    $('#' + x + '-error').html(obj[x]);
                                    $('#' + x + '-error').css("color", '#b30000');
                                    $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                        }
                        },
                });
    }
    }));
            $(function () {
                $('.from_date').datetimepicker({
                format: '{{\App\Helpers\Utility::getDatePickerForamt()}}',
                        @if (strtotime($model->duration_to) > 0)
                        maxDate: '{{date("Y-m-d",strtotime($model->duration_to))}}',
                        @else
                        maxDate: moment(),
                        @endif
                        ignoreReadonly: true,
                        useCurrent: false,
                });
                        $('.to_date').datetimepicker({
                format: '{{\App\Helpers\Utility::getDatePickerForamt()}}',
                        @if (strtotime($model->duration_to) > 0)
                        minDate: '{{date("Y-m-d",strtotime($model->duration_from))}}',
                        @else
                        maxDate: moment(),
                        @endif
                        ignoreReadonly: true,
                        useCurrent: false,
                });
                        $(".from_date").on("change.datetimepicker", function (e) {
                    $('.to_date').datetimepicker('minDate', e.date);
                });
                $(".to_date").on("change.datetimepicker", function (e) {
                    $('.from_date').datetimepicker('maxDate', e.date);
                });
            });

    $('#experienceForm').on('submit', function (e) {
        if ($('#experienceForm').valid()) {
            $('#submitBtn').html('{{\App\Helpers\Utility::buttonLoader()}}  Save & Next');
            $("#submitBtn").prop('disabled', true);
        }
    });

    function disDurationTo() {
        if ($('#remeberme').prop('checked')) {
            $('#datetimepicker2').val('');
            $('#datetimepicker2').attr('disabled', true);
        } else {
            $('#datetimepicker2').attr('disabled', false);
            $('#datetimepicker2').val('');
        }
    }
</script>