@extends('layouts.user.app')
@section('title','Experience')
@section('content')
<main class="dashboard-main-wrap step-form jobseeker-steps">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="content-body">
                <!-- <h2 class="page-title mt-0">Update Profile</h2> -->
                <!-- breadcrumb start-->
                <nav aria-label="breadcrumb" class="text-right">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Experience</li>
                    </ol>
                </nav>
                <!-- breadcrumb end-->
                <div class="form-wrap">
                    @include('user.profile.links')
                    <!-- xxxxxxxxxxx -->
                    <section class="step-form-body">
                        <div class="form02 common-form" id="form02">
                            <div class="inner-body">
                                <form id="expForm" method="POST" action="{{url('/user/submit-about-experience')}}">
                                    {{ csrf_field() }}
                                    <div class="row">
                                        <div class="col-12">
                                            <label class="field-heading font-md d-block w-100">Tell us about your experience </label>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group mb-0">
                                                <textarea  rows="4" name="about_experience" class="form-control" placeholder="Tell us about your experience">{{Auth::user()->about_experience}}</textarea>
                                            </div>
                                            <div class="extra-note text-right">
                                                <small class="mb-0 color-yellow">Maximum 500 characters</small>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-12 btn-row mb-4">
                                            <button type="submit" id="expBtn" class="btn btn-success">Submit</button>
                                        </div>
                                    </div>
                                </form>
                                {!! JsValidator::formRequest('App\Http\Requests\AboutYourExperienceRequest','#expForm') !!}
                                
                                <div id="experienceList"></div>
                                <!-- field-heading -->
                                <div class="clearfix"></div>

                                <div id="experienceHtml">

                                </div>
                            </div>
                        </div>
                        <!-- xxxxxxxxxxx -->
                    </section>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    function actionExperience(id) {
        $.ajax({
            type: "GET",
            url: "{{ url('/user/get-experience-form') }}",
            data: {id: id},
            success: function (response) {
                $('#experienceHtml').html(response);
            },
            complete: function () {
                $('html,body').animate({scrollTop: 1000});
            }
        });
    }
    actionExperience(0);
    function loadExperienceList() {
        $("#experienceList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "GET",
            url: "{{ url('/user/get-experience-list') }}",
            success: function (response) {
                $('#experienceList').html(response);
            }
        });
    }
    loadExperienceList();
    
    $('#expForm').on('submit', function (e) {
        if ($('#expForm').valid()) {
            $('#expBtn').html('{{\App\Helpers\Utility::buttonLoader()}}  Submit');
            $("#expBtn").prop('disabled', true);
        } 
    });
</script>
@endsection