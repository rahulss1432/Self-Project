@extends('layouts.user.app')
@section('title','Promo Video')
@section('content')
<main class="dashboard-main-wrap step-form jobseeker-steps" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="content-body">
                <!-- <h2 class="page-title mt-0">Update Profile</h2> -->
                <!-- breadcrumb start-->
                <nav aria-label="breadcrumb" class="text-right">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Promo Video</li>
                    </ol>
                </nav>
                <!-- breadcrumb end-->
                <div class="form-wrap">
                   @include('user.profile.links')

                    <!-- xxxxxxxxxxx -->
                    <section class="step-form-body">
                        <div class="form05 common-form" id="form02">
                            <div class="inner-body-full">
                                <div class="row">

                                    <div class="col-md-12 col-lg-6">
                                       

                                       

                                        <!-- xxxxxxxxxx -->

                                        <div class="left-wrap promo-vdo" id="uploadScreen03">
                                          

                                            <div class="vdo">
                                                <div class="embed-responsive embed-responsive-16by9">
                                                    
                                                </div>

                                            </div>



                                            <div class="btn-row mt-2 mt-sm-4" id="showWithScreen03" style="display: none">
                                                <a href="javascript:void(0);" class="text-uppercase btn ripple-effect-dark btn-success" onclick="successfullyModal()">SAVE</a>
                                                <a href="promo-video.php" class="text-uppercase btn ripple-effect-dark btn-success ml-0 ml-sm-2">RESET</a>
                                                <a href="javascript:void(0);" class="text-uppercase ripple-effect-dark btn btn-success ml-0 ml-sm-2">finish recording</a>
                                            </div>


                                        </div>
                                    </div>

                                    <!-- xxxxxx -->

                                    <div class="col-md-12 col-lg-6">
                                        @include('user.profile.promo-video.guideline')
                                    </div>
                                </div><!-- row end -->
                            </div>
                        </div>
                        <!-- xxxxxxxxxxx -->
                    </section>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection