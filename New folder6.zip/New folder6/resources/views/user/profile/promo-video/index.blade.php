@extends('layouts.user.app')
@section('title','Promo Video')
@section('content')
<main class="dashboard-main-wrap step-form jobseeker-steps" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="content-body">
                <!-- <h2 class="page-title mt-0">Update Profile</h2> -->
                <!-- breadcrumb start-->
                <nav aria-label="breadcrumb" class="text-right">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Promo Video</li>
                    </ol>
                </nav>
                <!-- breadcrumb end-->
                <div class="form-wrap">
                    @include('user.profile.links')

                    <!-- xxxxxxxxxxx -->
                    <section class="step-form-body">

                        <div class="form05 common-form" id="form02">
                            <div class="inner-body-full">
                                <div class="row">

                                    @if($userpromovideo)
                                    <div class="col-md-12 col-lg-6" id="promovideo" >
                                        <video alt="video-img" class="img-fluid " controls>
                                            <source src="{{url('public/uploads/promovideo/'.$userpromovideo->video_url)}}" type="video/mp4">
                                        </video>
                                        <div class="btn-set mt-2">
                                            <!--<a href="javascript:void(0);" class="text-uppercase btn btn-success ripple-effect-dark" onclick="()">UPLOAD ANOTHER </a>-->
                                            <a href="javascript:void(0);" class="text-uppercase btn btn-success ripple-effect-dark" onclick="showUploadScreen()"><i class="fa fa-cloud-upload" aria-hidden="true"></i>UPLOAD ANOTHER </a>
                                            <a href="javascript:void(0);" class="text-uppercase btn btn-warning ml-md-2 ml-lg-5 ripple-effect-dark" onclick="removePromoVideo({{$userpromovideo->id}})"> REMOVE VIDEO</a>
                                        </div>
                                    </div>
                                    @endif
                                    <div class="col-md-12 col-lg-6" id="Screen">
                                        <div class="left-wrap" id="uploadScreen01">
                                            <div class="btn-set">
                                                <a href="javascript:void(0);" class="text-uppercase btn btn-success ripple-effect-dark" onclick="showUploadScreen()"><i class="fa fa-cloud-upload" aria-hidden="true"></i> UPLOAD VIDEO </a>

                                                <a href="javascript:void(0);" class="text-uppercase btn btn-warning ml-md-2 ml-lg-5 ripple-effect-dark" onclick="showRecordScreen()"><i class="fa fa-video-camera" aria-hidden="true"></i> RECORD VIDEO </a>
                                            </div>
                                        </div>

                                        <!-- xxxxxxxxxx -->
                                        <form id="uploadVideoForm" method="post" enctype="multipart/form-data" action="{{url('/user/upload-video')}}">
                                            {{csrf_field()}}
                                            <div class="left-wrap upload-video" id="uploadScreen02" style="display: none">
                                                <div class="upload-screen">
<!--                                                    <input type="file" name="video" id="uploadVideo">-->
                                                    <div class="btn-row">
                                                        <div class="row">
                                                            <div class="col-sm-6">
                                                                <div class="upload">
                                                                    <label for="uploadVideo" href="javascript:void(0);" class="text-uppercase btn btn-success ripple-effect-dark"><i class="fa fa-cloud-upload" aria-hidden="true"></i> 	UPLOAD VIDEO
                                                                    </label>
                                                                    <input type="file" name="video" id="uploadVideo">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6">
                                                                <a href="javascript:void(0);" class="text-uppercase disabled btn btn-warning ripple-effect-dark float-md-right"><i class="fa fa-video-camera" aria-hidden="true"></i> RECORD VIDEO </a>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="progress-wrap">
                                                        <div class="progress" style="display: none;">
                                                            <div  class="progress-bar progress-bar-striped progress-bar-animated bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>
                                                        </div>
                                                    </div>

                                                    <div class="btn-row mt-2 mt-sm-4" id="showWithScreen02" style="display: none">
                                                        <button type="submit" class="text-uppercase ripple-effect-dark btn btn-success">SAVE</button>
                                                        <a href="{{url('/user/promo-video')}}" class="text-uppercase btn ripple-effect-dark btn-success ml-0 ml-sm-2">RESET</a>
                                                    </div>
                                                </div>

                                            </div>
                                        </form>
                                        {!! JsValidator::formRequest('App\Http\Requests\UploadVideoRequest','#uploadVideoForm') !!}
                                        <!-- xxxxxxxxxx -->
                                    </div>
                                    <!-- xxxxxx -->
                                    <div class="col-md-12 col-lg-6">
                                        @include('user.profile.promo-video.guideline')
                                    </div>
                                </div><!-- row end -->
                            </div>
                        </div>
                        <!-- xxxxxxxxxxx -->
                    </section>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="{{url('public/js/jquery.form.js')}}"></script>
<script>
                                                            $(document).ready(function() {

                                                    @if (!empty($userpromovideo))
                                                            $('#promoVideoDiv').show();
                                                            $('#uploadScreen01').hide();
                                                            $('#Screen').hide();
                                                            $('#uploadScreen01,#showWithScreen03').hide();
                                                            @endif

                                                            });
                                                            function successfullyModal() {
                                                            $("#successfullyModal").modal('show');
                                                            }

                                                    function showUploadScreen() {
                                                    $('#promovideo').hide();
                                                            $('#Screen').show();
                                                            $('#uploadScreen01').hide();
                                                            $('#uploadScreen02,#showWithScreen02').show();
                                                            }

                                                    function showRecordScreen() {
                                                    $('#uploadScreen01').hide();
                                                            $('#uploadScreen01,#showWithScreen03').show();
                                                            }

                                                    $(function () {
                                                    var bar = $('.bar');
                                                            //var percent = $('.percent');
                                                            var status = $('.progress');
                                                            if ($('#uploadVideoForm').valid()) {
                                                    $('#uploadVideoForm').ajaxForm({
                                                    beforeSend: function () {
                                                    status.show();
                                                            var percentVal = '0%';
                                                            bar.width(percentVal);
                                                            //percent.html(percentVal);
                                                            },
                                                            uploadProgress: function (event, position, total, percentComplete) {
                                                            var percentVal = percentComplete + '%';
                                                                    bar.width(percentVal);
                                                                    //percent.html(percentVal);
                                                            },
                                                            complete: function (xhr) {
                                                            status.hide();
                                                                    bar.width(0);
                                                                    var json = xhr.responseText;
                                                                    var arr = JSON.parse(json);
                                                                    if (arr.status == false) {
                                                            $('#uploadVideo-error').html(arr.uploadVideoError);
                                                            } else{
                                                            toastr.success(xhr.responseJSON.message, 'Success', {timeOut: 1000});
                                                                    location.reload();
                                                            }
                                                            }
                                                    });
                                                            }
                                                    });
                                                            function removePromoVideo(id){
                                                            bootbox.confirm('Are you sure do you want to delete promo video', function (result) {
                                                            if (result) {
                                                            $.ajax({
                                                            type: "GET",
                                                                    url: "{{ url('user/delete-promo-video') }}",
                                                                    data: {id: id},
                                                                    success: function (response) {
                                                                    if (response.status) {
                                                                    successToaster(response.message);
                                                                            location.reload();
                                                                    }
                                                                    }
                                                            });
                                                            }
                                                            });
                                                            }
</script>
@endsection
