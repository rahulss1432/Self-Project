<div class="right-wrap">
    <h2 class="page-title m-0 mb-2">Guidelines</h2>
    <p>Things you need to keep in mind before you upload your promotional video.</p>

    <ul class="list-unstyled">
        <li>Be Creative</li>
        <li>Prep Surroundings</li>
        <li>Dress to Impress</li>
        <li>Check Your Audio </li>
        <li>Have Good Lighting</li>
        <li>Script Your Dialog</li>
    </ul>

    <p>
        You only have 600 MB of storage for your video. This is equivalent to a 1 min 
        recording at H.264 1080p at 24 fps. We recommend you verify your video size before 
        uploading as the system will complete upload is limit is exceeded. Format should 
        be .mp4. or .mov. or .m-jpeg. See link for Video Space Calculator:
    </p>

    <a href="http://studiopost.com/contact/tech-specs/calculating-disk-space-" class="link" target="_blank">http://studiopost.com/contact/tech-specs/calculating-disk-space-</a>

</div>