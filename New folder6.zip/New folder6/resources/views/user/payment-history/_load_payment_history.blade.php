<div class="table-responsive">
    <table class="table common-table">
        <thead>
            <tr>
                <th>Sr.</th>
                <th>Transaction id</th>
                <th>Purchase Date</th>
                <th>Plan Type</th>
                <th>Amount</th>
                <th>Expiry Date</th>
            </tr>
        </thead>
        <tbody>
            @if($paymentList->count()>0)
            @php $i=1; @endphp
            @foreach($paymentList as $payment)
            @php $srNo = ($paymentList->currentPage() - 1) * $paymentList->perPage() + $i++; @endphp
            <tr>
                <td>{{$srNo}}</td>
                <td>{{$payment['transaction_id']}}</td>
                <td>{{\App\Helpers\Utility::getDateFormat($payment['created_at'])}}</td>
                <td>{{$payment->getPlan->plan_name}}</td>
                <td>{{\App\Helpers\Utility::getPriceFormat($payment['amount'])}}</td>
                <td>{{\App\Helpers\Utility::getDateFormat($payment['expiry_date'])}}</td>
            </tr>
            @endforeach
            @else
            <tr>
                <td colspan="6">
                    @php \App\Helpers\Utility::emptyListMessage('payment history'); @endphp
                </td>
            </tr>
            @endif
        </tbody>
    </table>
</div>
@if($paymentList->count()>0)
@php \App\Helpers\Utility::getAdminPaginationDiv($paymentList); @endphp
@endif
<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#paymentList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
            var pageLink = $(this).attr('href');
            $.ajax({
                type: 'POST',
                url: pageLink,
                async: false,
                data: {_token: '{{csrf_token()}}'},
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#paymentList").html(response);
                }
            });
        });
    });
</script>
