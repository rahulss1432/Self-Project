@if(!empty($planList))
@foreach($planList as $planInfo)
@php  $userInfo=\App\Models\User::getUserById(Auth::user()->id); @endphp
<div class="col-lg-3 col-sm-6 column">
    <div class="card {{((!empty(Auth::user()->id)) && ($userInfo->getActivePlan->plan_id==$planInfo['id']))?'active':''}}">
        <div class="card-header text-center">{{$planInfo['plan_name']}}
            <span>{{\App\Helpers\Utility::getPriceFormat($planInfo['price'])}}</span>
            <small>/ month</small>
        </div>
        <div class="card-body">
            <ul class="list-unstyled mb-0">
                @if(!empty($planInfo->getDetails))
                @foreach($planInfo->getDetails as $detailInfo)
                <li>{{$detailInfo['description']}}</li>
                @endforeach
                @endif
            </ul>
            @if(!empty(Auth::user()->id))
                @php
               
                    $activePrice=0;
                    if($userInfo->getActivePlan->plan_id==$planInfo['id']){
                        $activePrice=$planInfo['price'];
                    }
                @endphp
                @if($activePrice<=$planInfo['price'] && $planInfo['price']>0)
                    <a class="text-uppercase btn btn-success ripple-effect-dark" href="javascript:void(0);">UPGRADE NOW</a>
                @endif
            @endif
        </div>
    </div>
</div>
@endforeach
@endif


