@extends('layouts.user.app')
@section('title','Payment History')
@section('content')
<main class="main-wrapper dashboard-main-wrap payment-history-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="top_section align-items-start">
                <!--<a href="invoice.php" target="_blank" class="btn btn-success ripple-effect-dark text-uppercase invoice_btn">View invoice</a>-->
                <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item">
                            <a href="{{url('/user/dashboard')}}">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Payment History</li>
                    </ol>
                </nav>
            </div>
            <!--  <div class="content-body">
                <h1 class="page-title">Payment History</h1>
            </div> -->
            <div class="card common-card mt-0">
                <div class="card-body p-0" id="paymentList">

                </div>
            </div>

        </div>
    </div>
</div>
</main>
<script>
    $(document).ready(function () {
        loadPaymentList();
    });

    function loadPaymentList() {
        $("#paymentList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "POST",
            url: "{{ url('/user/get-payment-history') }}",
            data: {_token: '{{csrf_token()}}'},
            success: function (response)
            {
                $("#paymentList").html(response);
            }
        });
    }
</script>
@endsection