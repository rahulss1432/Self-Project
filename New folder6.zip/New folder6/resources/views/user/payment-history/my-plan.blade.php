@extends('layouts.user.app')
@section('title','My Plan')
@section('content')
<main class="main-wrapper dashboard-main-wrap subscription-plan-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/user/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">My Plan</li>
                </ol>
            </nav>
            <!-- <h2 class="page-title mt-0">Subscription Plan</h2> -->
            <section class="content_section content-wrap">
                <div class="row" id="planList">
                    <!--
                    <div class="col-lg-3 col-sm-6 column">
                        <div class="card">
                            <div class="card-header text-center">Free
                                <sup>$</sup>
                                <span>0.00</span>
                                <small>/ month</small>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled mb-0">
                                    <li>Upload 30 Sec Promo Video</li>
                                    <li>Apply to 2 Jobs postings</li>
                                    <li>Access to FAQ’s Support</li>
                                    <li>System Match (system)</li>
                                    <li>Profile Email Notifications</li>
                                    <li>Social Media Integration</li>
                                </ul>
                                <span class="checkmark"></span>
                            </div>
                        </div>
                    </div>
                   
                    <div class="col-lg-3 col-sm-6 column">
                        <div class="card">
                            <div class="card-header text-center">Basic
                                <sup>$</sup>
                                <span>7.99</span>
                                <small>/ month</small>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled mb-0">
                                    <li>Upload 30 Sec Promo Video</li>
                                    <li>Apply to 4 Jobs postings</li>
                                    <li>Access to FAQ’s Support</li>
                                    <li>System Match</li>
                                    <li>Receive Personal Profile Link</li>
                                    <li>Profile Email Notifications</li>
                                    <li>Social Media Integration</li>
                                </ul>
                                <a href="javascript:void(0);" class="text-uppercase btn btn-success ripple-effect-dark">UPGRADE NOW</a>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-lg-3 col-sm-6 column">
                        <div class="card active">
                            <div class="card-header text-center">Pro
                                <sup>$</sup>
                                <span>9.99</span>
                                <small>/ month</small>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled mb-0">
                                    <li>Upload 45 Sec Promo Video</li>
                                    <li>Apply to 8 Jobs postings</li>
                                    <li>Access to FAQ’s Support</li>
                                    <li>System Match</li>
                                    <li>Receive Personal Profile Link</li>
                                    <li>Chat Support</li>
                                    <li>Social Media Integration</li>
                                </ul>
                                <a href="javascript:void(0);" class="text-uppercase btn btn-success ripple-effect-dark">UPGRADE NOW</a>
                            </div>
                        </div>
                    </div>

                   
                    <div class="col-lg-3 col-sm-6 column">
                        <div class="card">
                            <div class="card-header text-center">Executive
                                <sup>$</sup>
                                <span>12.99</span>
                                <small>/ month</small>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled mb-0">
                                    <li>Upload 60 Sec Promo Video</li>
                                    <li>Apply to Unlimited Jobs postings</li>
                                    <li>Access to FAQ’s Support</li>
                                    <li>System Match</li>
                                    <li>Receive Personal Profile Link</li>
                                    <li>Profile Email Notifications</li>
                                    <li>Chat Support</li>
                                    <li>U.S. Phone Support</li>
                                    <li>Social Media Integration</li>
                                </ul>
                                <a href="javascript:void(0);" class="text-uppercase btn btn-success ripple-effect-dark">UPGRADE NOW</a>
                            </div>
                        </div>
                    </div>

                     xxxxxx -->
                </div>
            </section>
        </div>
    </div>
</main>
<script>
    function getPlanList(){
        $("#planList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "POST",
            url: "{{ url('/user/get-paln-list') }}",
            data: {_token: '{{csrf_token()}}', user_type: '{{Auth::user()->user_type}}'},
            success: function (response)
            {
                $("#planList").html(response);
            }
        });
    }
    getPlanList();
</script>
@endsection