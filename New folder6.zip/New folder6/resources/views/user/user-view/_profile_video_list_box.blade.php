@foreach($profileVideoViewData as $data)
<div class="col-lg-3 col-md-4 col-sm-6">
    <div class="job_box">
        <div class="job_header">
            <div class="job_img d-inline-flex align-items-center justify-content-center">
                <img src="{{\App\Helpers\Utility::checkCompanyLogo($data->getUser->company_logo)}}" alt="icon" class="img-fluid">
            </div>
        </div>
        <div class="job_body">
            <h3>{{$data->getUser->company_name}}</h3>
        </div>
        <div class="job_footer">
            <a href="{{url('/company-profile/'.$data->send_by.'/'.\App\Helpers\Utility::makeslug($data->getUser->company_name))}}" class="font-md">View Company Profile</a>
        </div>
    </div>
</div>
@endforeach