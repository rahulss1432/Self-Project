@extends('layouts.user.app')
@section('title','Change Password')
@section('content')
<main class="dashboard-main-wrap change_password_page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="content-body">
                <!-- <h2 class="page-title mt-0">Change Password</h2> -->
                <!-- breadcrumb start-->
                <nav aria-label="breadcrumb" class="text-right order-md-last">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item"><a href="{{url('/')}}">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Change Password</li>
                    </ol>
                </nav>
                <!-- breadcrumb end-->
                <div class="card">
                    <div class="card-body">
                        <div class="inner-body">
                            <form class="form-horizontal" id="passwordForm" method="POST" action="{{(url('/user/password-change'))}}">
                                <input type="hidden" name="guard" value="web">
                                {{ csrf_field() }}
                                <div class="form-group">
                                    <input type="password" class="form-control" name="current_password" placeholder="Current Password">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="password" placeholder="New Password">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="confirm_password" placeholder="Confirm New Password">
                                </div>
                                <div class="text-center">
                                    <button type="Submit"  id="btn-password"  class="btn ripple-effect-dark btn-warning text-uppercase">Update</button>
                                </div>
                            </form>
                            {!! JsValidator::formRequest('App\Http\Requests\ChangePasswordRequest','#passwordForm') !!}

                            <script>
                                $("#btn-password").on('click', (function (e) {
                                    e.preventDefault();
                                    var btn = $('#btn-password');
                                    var form = $('#passwordForm');
                                    if (form.valid()) {
                                        btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
                                        btn.prop('disabled', true);
                                        $.ajax({
                                            url: "{{(url('/user/password-change'))}}",
                                            type: "POST",
                                            data: form.serialize(),
                                            success: function (data)
                                            {
                                                btn.prop('disabled', false);
                                                window.location.href='{{url("/user/dashboard")}}';
                                            },
                                            error: function (data) {
                                                var obj = jQuery.parseJSON(data.responseText);
                                                for (var x in obj) {
                                                    btn.prop('disabled', false);
                                                    btn.html('Submit');
                                                    var errors = obj[x].length
                                                    $('#' + x + '-error').html(obj[x]);
                                                    $('#' + x + '-error').css("color", '#b30000');
                                                    $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                                                }
                                            },
                                        });
                                    }
                                }));
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection
