@extends('email-templates.email_layout')
@section('content')
<table style="box-sizing: border-box;background-color:#ffffff;margin: 0 auto;padding: 0;width: 570px;" align="center" cellpadding="0" cellspacing="0" width="570">
    <tbody>
        <tr>
            <td  style=" box-sizing: border-box ; padding: 35px">
                <h1 style="font-family: 'avenir' , 'helvetica' , sans-serif;box-sizing: border-box;color: #2f3133;font-size: 19px;font-weight: bold;margin-top: 0;text-align: left;">Hello {{$data['name']}}</h1>
                <p style=" font-family: 'avenir' , 'helvetica' , sans-serif;box-sizing: border-box;color: #74787e;font-size: 16px;line-height: 1.5em;margin-top: 0; text-align: left;">Rezieo admin has updated your account.</p>
                <p style=" font-family: 'avenir' , 'helvetica' , sans-serif;box-sizing: border-box;color: #74787e;font-size: 16px;line-height: 1.5em;margin-top: 0; text-align: left;">Your account credentials is: <br>
                    <b>Email:</b> {{$data['email']}} <br>
                    @if(!empty($data['password']))
                        <b>Password:</b> {{$data['password']}}
                    @endif
                </p>               
                <p style="font-family: 'avenir' , 'helvetica' , sans-serif; box-sizing: border-box ; color: #74787e ; font-size: 16px ; line-height: 1.5em ; margin-top: 0 ; text-align: left">Regards,<br>{{$data['regards']}}</p>
                <table class="subcopy" style=" box-sizing: border-box ; border-top: 1px solid #edeff2 ; margin-top: 25px ; padding-top: 25px" cellpadding="0" cellspacing="0" width="100%">
                    
                </table>
            </td>
        </tr>
    </tbody>
</table>
@endsection
