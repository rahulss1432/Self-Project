<!doctype html>
<html lang="en">

    <head>
        <title>invoice</title>
    </head>

    <body>
        <main class="dashboard-main-wrap invoice-page m-0 p-0" id="content">
            <div class="container-fluid">
                <div class="common-detail-section p-0">
                    <div class="text-center print_btn">
                        <a href="javascript:window.print()" class="btn text-uppercase ripple-effect-dark btn-success">Print this Invoice</a>
                    </div>
                    <div class="content-body rounded">
                        <div class="top-info d-flex justify-content-between align-items-center">
                            <div class="logo">
                                <img src="../assets/images/logo.svg" title="Rezieo" alt="logo">
                                <span class="font-rg ml-1">Rezieo</span>
                            </div>
                            <!-- xx -->
                            <div class="right_info">
                                <div class="label-text">
                                    <label for="">Order:</label>
                                    <span>#{{($data['txn_id']) ? $data['txn_id'] : ''}} </span>
                                </div>
                                <div class="label-text">
                                    <label for="">Issue Date:</label>
                                    <span>{{ \App\Helpers\Utility::getDateFormat($data['issue_date']) }} </span>
                                </div>
                            </div>
                            <!-- xxxxx -->
                        </div>
                        <!-- xxxxx -->
                        <div class="middle-info">
                            <h1 class="font-md">Invoice</h1>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="info mb-0">
                                        <h4 class="font-md">Supplier</h4>
                                        <p class="mb-1">Rezieo Ltd.</p>
                                        <p class="mb-0">21 St Andrews Lane <br> London, CF44 6ZL, UK</p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="info">
                                        <h4 class="font-md">Customer</h4>
                                        <p class="mb-1">{{$data['name']}} </p>
                                        <p >36 Edgewater Street <br> Melbourne, 2540, Australia </p>
                                    </div>
                                </div>
                            </div>
                            <!-- xxxxxx -->
                            <div class="table-responsive">
                                <table class="table common-table">
                                    <thead>
                                        <tr>
                                            <th>Description</th>
                                            <th>Price</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>{{$data['Plan_name']}}</td>
                                            <td>{{ \App\Helpers\Utility::getPriceFormat($data['amount']) }}</td>
                                            <td>{{ \App\Helpers\Utility::getPriceFormat($data['amount']) }}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="row">
                                <div class="col-xl-4 col-sm-6">
                                    <table class="table common-table">
                                        <tbody><tr>
                                                <th class="border-bottom">Total Amount</th> 
                                                <th class="border-bottom"><span>{{ \App\Helpers\Utility::getPriceFormat($data['amount']) }}</span></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="plan-feature">
                                <h2 class="font-md mb-3 text-uppercase">Plan Features</h2>
                                <ul class="list-unstyled">
                                    @php $planFeatures = explode(',',$data['description']); @endphp
                                    @if(!empty($planFeatures))
                                    @foreach($planFeatures as $features)
                                    <li>{{$features}}</li>
                                    @endforeach
                                    @endif
                                </ul>
                            </div>
                        </div>
                        <!-- xxxx -->
                        <div class="footer_info text-center">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <a href="javascript:void((0);" class="color-green">www.rezieo.com</a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="mailto:enquiries@rezieo.info" >enquiries@rezieo.com</a>
                                </li>

                                <li class="list-inline-item">
                                    (123) 123-456
                                </li>
                            </ul>
                        </div>
                        <!-- xxxxx -->
                    </div>
                </div>
            </div>
        </main>
    </body>

</html>