@extends('email-templates.email_layout')
@section('content')
<table style="box-sizing: border-box;background-color:#ffffff;margin: 0 auto;padding: 0;width: 570px;" align="center" cellpadding="0" cellspacing="0" width="570">
    <tbody>
        <tr>
            <td  style=" box-sizing: border-box ; padding: 35px">
                <h1 style="font-family: 'avenir' , 'helvetica' , sans-serif;box-sizing: border-box;color: #2f3133;font-size: 19px;font-weight: bold;margin-top: 0;text-align: left;">Hello {{$data['name']}}</h1>
                <p style=" font-family: 'avenir' , 'helvetica' , sans-serif;box-sizing: border-box;color: #74787e;font-size: 16px;line-height: 1.5em;margin-top: 0; text-align: left;">You need to activate your email before you can start using all of our services.</p>
                <table style="box-sizing: border-box ; margin: 30px auto ; padding: 0 ; text-align: center ; width: 100%  " align="center" cellpadding="0" cellspacing="0" width="100%">
                    <tbody>
                        <tr>
                            <td style=" box-sizing: border-box" align="center">
                                <table style=" box-sizing: border-box" border="0" cellpadding="0" cellspacing="0" width="100%">
                                    <tbody>
                                        <tr>
                                            <td style=" box-sizing: border-box" align="center">
                                                <table style=" box-sizing: border-box" border="0" cellpadding="0" cellspacing="0"><tbody><tr>
                                                            <td style=" box-sizing: border-box">
                                                                <a  href="{{$data['link']}}" style="font-family: 'avenir' , 'helvetica' , sans-serif;box-sizing: border-box ; border-radius: 3px ; box-shadow: 0 2px 3px rgba(0 , 0 , 0 , 0.16) ; color: #fff ; display: inline-block ; text-decoration: none ; background-color: #1acd68 ; border-top: 10px solid #1acd68 ; border-right: 18px solid #1acd68 ; border-bottom: 10px solid #1acd68 ; border-left: 18px solid #1acd68">Activate Your Account</a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p style="font-family: 'avenir' , 'helvetica' , sans-serif; box-sizing: border-box ; color: #74787e ; font-size: 16px ; line-height: 1.5em ; margin-top: 0 ; text-align: left">Thank you for register with us.</p>
                <p style="font-family: 'avenir' , 'helvetica' , sans-serif; box-sizing: border-box ; color: #74787e ; font-size: 16px ; line-height: 1.5em ; margin-top: 0 ; text-align: left">Regards,<br>{{$data['regards']}}</p>
                <table class="subcopy" style=" box-sizing: border-box ; border-top: 1px solid #edeff2 ; margin-top: 25px ; padding-top: 25px" cellpadding="0" cellspacing="0" width="100%">
                    <tbody>
                        <tr>
                            <td style=" box-sizing: border-box">
                                <p style="font-family: 'avenir' , 'helvetica' , sans-serif;box-sizing: border-box ; color: #74787e ; line-height: 1.5em ; margin-top: 0 ; text-align: left ; font-size: 12px">If you’re having trouble clicking the "Activate Your Account" button, copy and paste the URL below 
                                    into your web browser: <a href="{{$data['link']}}" style=" box-sizing: border-box ; color: #3869d4">{{$data['link']}}</a></p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
@endsection