<table align="center" style="box-sizing: border-box;background-color:#1ACD68;margin:0;padding:0; width: 730px;margin-left:auto; margin-right:auto;" cellpadding="0" cellspacing="0">
    <tbody>
        <tr>
            <td style=" box-sizing: border-box" align="center">
                <table style="box-sizing: border-box;margin:0;padding:0;width: 100%" cellpadding="0" cellspacing="0" width="100%">
                    <tbody>
                        <tr>
                            <td style="box-sizing: border-box;padding: 25px 0;text-align: center;">
                                <a href="{{url('/')}}">
                                    <img src="http://hireo.codiant.com/public/images/logo.png" style="height: 50px;">
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td style="box-sizing: border-box;background-color:#ffffff;border: 1px solid #edeff2;margin: 0;padding: 0;width: 100%;" width="100%">
                                <table style="box-sizing: border-box;background-color:#ffffff;margin: 0 auto;padding: 0;width: 570px;" align="center" cellpadding="0" cellspacing="0" width="570">
                                    <tbody>
                                        <tr>
                                            <td  style=" box-sizing: border-box ; padding: 35px">
                                                <h1 style="font-family: 'avenir' , 'helvetica' , sans-serif;box-sizing: border-box;color: #2f3133;font-size: 19px;font-weight: bold;margin-top: 0;text-align: left;">Hello</h1>

                                                <table style="box-sizing: border-box ; margin: 30px auto ; padding: 0 ; text-align: center ; width: 100%  " align="center" cellpadding="0" cellspacing="0" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td style=" box-sizing: border-box" align="center">
                                                                <table style=" box-sizing: border-box" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td style=" box-sizing: border-box">
                                                                                <p style=" font-family: 'avenir' , 'helvetica' , sans-serif;box-sizing: border-box;color: #74787e;font-size: 16px;line-height: 1.5em;margin-top: 0; text-align: left;">You need to activate your email before you can start using all of our services.</p>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <p style="font-family: 'avenir' , 'helvetica' , sans-serif; box-sizing: border-box ; color: #74787e ; font-size: 16px ; line-height: 1.5em ; margin-top: 0 ; text-align: left">Thank you for register with us.</p>
                                                <p style="font-family: 'avenir' , 'helvetica' , sans-serif; box-sizing: border-box ; color: #74787e ; font-size: 16px ; line-height: 1.5em ; margin-top: 0 ; text-align: left">Regards,<br>Rezieo Team</p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td style=" box-sizing: border-box;background:#1ACD68;">
                                <table style="box-sizing: border-box;margin: 0 auto;padding: 0;text-align: center;width: 570px;" align="center" cellpadding="0" cellspacing="0" width="570">
                                    <tbody>
                                        <tr>
                                            <td style=" box-sizing: border-box ; padding: 12px" align="center">
                                                <p style="box-sizing: border-box;line-height: 1.5em;margin-top: 0;color: #aeaeae;font-size: 14px;text-align: center;color: white;font-family: 'avenir' , 'helvetica' , sans-serif;">© {{date("Y")}} Rezieo. All rights reserved.</p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>