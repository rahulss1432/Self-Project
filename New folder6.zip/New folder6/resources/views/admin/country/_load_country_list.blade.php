@if(!empty($countryList->count()>0))
@php $i=1; @endphp
<table class="table">
    <tr>
        <th>Sr.</th>
        <th>Country Name</th>
        <th>Abbreviation</th>
        <th>Phone Code</th>
        <th>Status</th>
        
    </tr>
    @foreach($countryList as $industry)
    @php $srNo = ($countryList->currentPage() - 1) * $countryList->perPage() + $i++; @endphp
    <tr>
        <td>{{$srNo}}</td>
        <td>{{$industry['country_name']}}</td>
           <td>{{$industry['abbreviation']}}</td>
        <td>{{$industry['phone_code']}}</td>
        <td><input type="checkbox" {{($industry['status']=='enabled')?'checked="checked"':''}} onchange="updateStatus('{{$industry["id"]}}');" name="status[]" value="{{$industry['status']}}"> {{$industry['status']}}</td>
        
    </tr>
    @endforeach
</table>
@else
@php \App\Helpers\Utility::emptyListMessage('Country'); @endphp
@endif

@php \App\Helpers\Utility::getAdminPaginationDiv($countryList); @endphp

<script>
    var title='Country';
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
                e.preventDefault();
                $("#countryList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
                var pageLink = $(this).attr('href');
                $.ajax({
                    type: 'POST',
                    url: pageLink,
                    async: false,
                    data: $('#frmFilter').serialize(),
                    success: function (response) {
                            $('.pagination:first').remove();
                            $("#countryList").html(response);
                    }
                });
        });
    });
    function updateStatus(id){
        $.ajax({
            type: "POST",
            url: "{{url('/admin/update-country-status')}}",
            data: {'_token': "{{csrf_token()}}", 'id': id},
            success: function (response) {
                if (response.status) {
                    successToaster(response.message,title);
                }
            }
        });
    }
</script>
