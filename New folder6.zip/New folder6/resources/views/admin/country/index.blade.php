@extends('layouts.admin.admin-app')
@section('content')
<div class="container">
    <form id="frmFilter">
        {{csrf_field()}}
    </form>
    <div id="countryList">

    </div>
</div>
<script>
    $(document).ready(function () {
        loadCountryList();
    });

    function loadCountryList() {
        $("#countryList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "POST",
            url: "{{ url('/admin/load-country-list') }}",
            data: $('#frmFilter').serialize(),
            success: function (response)
            {
                $("#countryList").html(response);
            }
        });
    }
</script>
@endsection
