<div class="table-responsive">
    <table class="table common-table admin-table" id="tableList">
        <thead class="th-border">
            <tr>
                <th width="7%">Sr.</th>
                <th>LANGUAGE NAME</th>
                <th width="10%">Status</th>
                <th width="10%">Action</th>
            </tr>
        </thead>
        <tbody>
            @if(!empty($languageList->count()>0)) 
                @php $i=1; @endphp 
                @foreach($languageList as $language)
                    @php $srNo = ($languageList->currentPage() - 1) * $languageList->perPage() + $i++; @endphp
                    <tr>
                        <td>{{$srNo}}</td>
                        <td>{{$language['title']}}</td>
                        <td>
                            <div class="switch">
                                <label>
                                    <input type="checkbox" {{($language['status']=='enabled')?'checked="checked"':''}} onchange="updateStatus('{{$language["id"]}}');" name="status[]" value="{{$language['status']}}">
                                    <span class="lever"></span>
                                </label>
                            </div>
                        </td>
                        <td>
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <a href="javascript:void(0);" onclick="actionLanguage('{{$language["id"]}}');" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="javascript:void(0);" onclick="deleteLanguage('{{$language["id"]}}','{{$language["title "]}}')" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
                                </li>
                            </ul>
                        </td>
                    </tr>
                @endforeach 
            @else
            <tr>
                <td colspan="4">
                    @php \App\Helpers\Utility::emptyListMessage('language'); @endphp
                </td>
            </tr>
            @endif
        </tbody>
    </table>
</div>
@php \App\Helpers\Utility::getAdminPaginationDiv($languageList); @endphp

<script>
    var title = 'Language';
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#languageList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
            var pageLink = $(this).attr('href');
            $.ajax({
                type: 'POST',
                url: pageLink,
                async: false,
                data: $('#frmFilter').serialize(),
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#industryList").html(response);
                }
            });
        });
    });
    function updateStatus(id) {
        $.ajax({
            type: "POST",
            url: "{{url('/admin/update-language-status')}}",
            data: {
                '_token': "{{csrf_token()}}",
                'id': id
            },
            success: function (response) {
                if (response.status) {
                    successToaster(response.message, title);
                }
            }
        });
    }

    function deleteLanguage(id, name) {
        bootbox.confirm('Are you sure do you want to delete <b>' + name + '<b>?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "{{ url('admin/delete-language') }}",
                    data: {
                        id: id
                    },
                    success: function (response) {
                        if (response.status) {
                            successToaster(response.message, title);
                            loadLanguageList();
                        }
                    }
                });
            }
        });
    }
</script>
