<div class="notification-in">
    <span class="notification-icon"><i class="{{$notification['icon']}}"></i></span>
    <span class="notification-text">
        {!!$notification['message']!!}
    </span>
    @if(!empty($showDate))
    <span class="ml-auto date_tym">{{\App\Helpers\Utility::getDateFormat($notification['created_at'])}}</span>
    @endif
</div>
