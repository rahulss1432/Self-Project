@extends( 'layouts.admin.admin-app' )
@section( 'title', 'Edit'.ucfirst($type) )
@section( 'content' )
<main class="main-wrapper dashboard-main-wrap" id="content">
    <div class="container-fluid">
        <input type="hidden" id="pageType" value="{{$type}}">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">{{ucfirst($type)}}</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">{{ucfirst($type)}}</h3>
                </div>
                <div class="card-body view_page pb-0">                    
                        <div id="banner-setting-form">                            
                        </div>
                </div>
            </div>
        </div>
        
    </div>
</main>
<script>
    $(document).ready(function () {
       var type = $('#pageType').val();
        addBannerSetting(type);
    });
    function addBannerSetting(type) {   
        $('#banner-setting-form').html('{{\App\Helpers\Utility::ajaxLoader()}}');
        var url = '{{url("/admin/load-banner-setting-form")}}';
        $.ajax({
            url: url,
            type: 'POST',
            data: {_token: '{{csrf_token()}}',type: type},
            success: function(result) {
                $("#banner-setting-form").html(result);
            }
        });
    }
</script>
@endsection

