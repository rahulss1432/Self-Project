<form class="form-horizontal" id="banner-setting-form" enctype="multipart/form-data" method="POST" action="{{url('admin/banner-setting-submit')}}">
    {{ csrf_field() }}
    <input type="hidden" name="type" id="pageType" value="{{$type}}">
    <div class="row">
        @if($settingList->count()>0)
        @foreach($settingList as $list)
        @if($list['setting_type']=='image')
        <input type="hidden" name="oldBanner" id="oldBanner" value="{{$list['setting_value']}}">
        <div class="col-sm-6">
            <div class="form-group">
                <label class="control-label">{{$list['setting_title']}}</label>
                <label class="d-block" for="uploadFile">
                    <div class="uploadIcon">
                        <span class="form-control" id="fileName">{{$list['setting_value']}}</span>
                        <input name="{{$list['setting_key']}}" type="file" id="uploadFile">
                    </div>
                </label>
            </div>
        </div>
        @else
        <div class="col-sm-6">
            <div class="form-group">
                <label class="control-label">{{$list['setting_title']}}</label>
                <input type="text" name="{{$list['setting_key']}}" class="form-control" value="{{$list['setting_value']}}">
            </div>
        </div>
        @endif            
        @endforeach
        @endif
    </div>
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <button id="btn-banner-setting"  type="Submit" class="btn ripple-effect-dark btn-success btn-sm text-uppercase">Submit</button> 
            </div>
        </div>
    </div>
</form>
{!! JsValidator::formRequest('App\Http\Requests\BannerSettingRequest','#banner-setting-form') !!}
<script>
    $('#uploadFile').change(function () {
        var file = this.files[ 0 ];
        $("#fileName").html(file.name);
    });
</script>
