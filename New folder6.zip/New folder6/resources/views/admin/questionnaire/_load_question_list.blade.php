<div class="table-responsive">
    <table class="table common-table admin-table">
        <thead class="th-border">
            <tr>
                <th width="5%">Sr.</th>
                <th width="15%">Category</th>
                <th>Question</th>
                <th width="7%">Action</th>
            </tr>
        </thead>
        <tbody>
            @if(!empty($questionList->count()>0))
            @php $i=1; @endphp
            @foreach($questionList as $question)
            @php $srNo = ($questionList->currentPage() - 1) * $questionList->perPage() + $i++; @endphp
            <tr>
                <td>{{$srNo}}</td>
                <td>{{$question->getcategory->name}}</td>
                <td>{{$question['question']}}</td>
                <td>
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="addQuestion('{{$question["id"]}}');" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
                        </li>
                        <li  class="list-inline-item">
                            <a href="javascript:void(0);" onclick="deleteQuestionery('{{$question["id"]}}')" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-trash"></i></a>
                        </li>
                    </ul>
                </td>
            </tr>
            @endforeach
            @else
            <tr>
                <td colspan="5">@php \App\Helpers\Utility::emptyListMessage('question'); @endphp</td>
            </tr>
            @endif
        </tbody>
    </table>
</div>
@php \App\Helpers\Utility::getAdminPaginationDiv($questionList); @endphp

<script>
    var title = 'Question';
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#questionnaireList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
            var pageLink = $(this).attr('href');
            $.ajax({
                type: 'POST',
                url: pageLink,
                async: true,
                data: $('#frmFilter').serialize(),
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#questionnaireList").html(response);
                }
            });
        });
    });

    function deleteQuestionery(id) {
        bootbox.confirm('Are you sure do you want to delete?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "{{ url('admin/delete-question') }}",
                    data: {id: id},
                    success: function (response) {
                        if (response.status) {
                            successToaster(response.message, title);
                            loadQuestionnaireList();
                        }
                    }
                });
            }
        });
    }
</script>
