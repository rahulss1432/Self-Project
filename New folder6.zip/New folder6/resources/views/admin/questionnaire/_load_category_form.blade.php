<form class="form-horizontal" id="questionnaireForm" method="POST" action="{{(url('/admin/category-submit'))}}">
    <div class="modal-body">
        {{ csrf_field() }}
        <input type="hidden" name="id" value="{{$model->id}}">
        <div class="form-group">
            <label for="name" class="control-label">Category<span class="text-danger">*</span></label>
            <input type="text" class="form-control" name="name" placeholder="Category Name" value="{{$model->name}}">
        </div>
    </div>
    <div class="modal-footer">
        <button id="btn-category"  type="Submit" class="btn ripple-effect-dark btn-success btn-sm text-uppercase">Submit</button>
    </div>
</form>
{!! JsValidator::formRequest('App\Http\Requests\QuestionnaireRequest','#questionnaireForm') !!}

<script>
    $("#btn-category").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btn-category');
        var form = $('#questionnaireForm');
        if (form.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{(url('/admin/category-submit'))}}",
                type: "POST",
                data: form.serialize(),
                success: function (data) {
                    $('#questionnaireModal').modal('hide');
                    successToaster(data.message, 'Quetion Category');
                    btn.prop('disabled', false);
                    btn.html('Submit');
                    if ($('#listType').val() != 'category') {
                        loadQuestionnaireList();
                    } else {
                        loadCategoryList();
                    }
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    obj = obj['errors'];
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
</script>