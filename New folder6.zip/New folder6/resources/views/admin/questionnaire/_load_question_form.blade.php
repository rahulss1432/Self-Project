<form class="form-horizontal" id="questionForm" method="POST" action="{{(url('/admin/question-submit'))}}">
    <div class="modal-body"> 
        {{ csrf_field() }}
        <input type="hidden" name="id" value="{{$model->id}}">
        <div class="form-group">
            <label>Category<span class="text-danger">*</span></label>
            <select name="category_id" class="selectpicker form-control">
                <option value="">Select Category</option>
                @if(!empty($questionnaire))
                @foreach($questionnaire as $category)
                <option {{($model->category_id == $category->id)?'selected="selected"':''}} value="{{$category->id}}">{{$category->name}}</option>
                @endforeach
                @endif
            </select>
        </div>
        <div class="form-group">
            <label>Question<span class="text-danger">*</span></label>
            <input type="text" name="question" class="form-control" placeholder="Enter Question" value="{{$model->question}}">
        </div>
    </div>
    <div class="modal-footer">
        <button id="btn-questionnaire"  type="Submit" class="btn ripple-effect-dark btn-success btn-sm text-uppercase">Submit</button>
    </div>
</form>
{!! JsValidator::formRequest('App\Http\Requests\QuestionRequest','#questionForm') !!}

<script>
    $(".selectpicker").selectpicker();
    $("#btn-questionnaire").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btn-questionnaire');
        var form = $('#questionForm');
        if (form.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{(url('/admin/question-submit'))}}",
                type: "POST",
                data: form.serialize(),
                success: function (data)
                {
                    $('#questionModal').modal('hide');
                    successToaster(data.message, 'Quetion');
                    btn.prop('disabled', false);
                    btn.html('Submit');
                    loadQuestionnaireList();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    obj = obj['errors'];
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
</script>