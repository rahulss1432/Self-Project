<div class="table-responsive">
    <table class="table common-table admin-table">
        <thead class="th-border">
            <tr>
                <th width="50">Sr.</th>
                <th>Name</th>
                <th width="120">Action</th>
            </tr>
        </thead>
        <tbody>
            @if(!empty($categoryList->count()>0))
            @php $i=1; @endphp
            @foreach($categoryList as $category)
            @php $srNo = ($categoryList->currentPage() - 1) * $categoryList->perPage() + $i++; @endphp
            <tr>
                <td>{{$srNo}}</td>
                <td>{{$category->name}}</td>
                <td>
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="addCategory('{{$category["id"]}}');" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
                        </li>
                        <li  class="list-inline-item">
                            <a href="javascript:void(0);" onclick="deleteCategory('{{$category["id"]}}')" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-trash"></i></a>
                        </li>
                    </ul>
                </td>
            </tr>
            @endforeach
            @else
            <tr>
                <td colspan="5">@php \App\Helpers\Utility::emptyListMessage('category'); @endphp</td>
            </tr>
            @endif
        </tbody>
    </table>
</div>
@php \App\Helpers\Utility::getAdminPaginationDiv($categoryList); @endphp

<script>
                    var title = 'Question';
                    $(document).ready(function () {
            $(".pagination li a").on('click', function (e) {
            e.preventDefault();
                    $("#questionnaireList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
                    var pageLink = $(this).attr('href');
                    $.ajax({
                    type: 'POST',
                            url: pageLink,
                            async: true,
                            data: $('#frmFilter').serialize(),
                            success: function (response) {
                            $('.pagination:first').remove();
                                    $("#questionnaireList").html(response);
                            }
                    });
            });
            });
                    function deleteCategory(id) {
                    bootbox.confirm('Are you sure do you want to delete?', function (result) {
                    if (result) {
                    $.ajax({
                    type: "GET",
                            url: "{{ url('admin/delete-category') }}",
                            data: {id: id},
                            success: function (response) {
                            if (response.status) {
                            successToaster(response.message, title);
                                    loadCategoryList();
                            }
                            }
                    });
                    }
                    });
                    }
</script>
