@extends('layouts.admin.admin-app')
@section('title','Manage Questionnaire')
@section('content')
<main class="main-wrapper dashboard-main-wrap payment-history-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Category</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">Category List</h3>
                    <ul class="list-inline mb-0 ml-auto">
                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                            <a href="#searchFilter" data-toggle="collapse" class="nav-link ripple-effect-dark">
                                <i class="fa fa-filter"></i>
                            </a>
                        </li>
                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Add Category">
                            <a href="javascript:void(0)" onClick="addCategory(0)" data-toggle="collapse" class="nav-link ripple-effect-dark">
                                <i class="fa fa-plus"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body p-0">
                    <div class="filter_section collapse" id="searchFilter">
                        <form id="frmFilter">
                            {{csrf_field()}}
                            <div class="row align-items-center">
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <input type="text" name="name" class="form-control" placeholder="Category Name">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <button type="button" class="btn text-uppercase btn-warning ripple-effect-dark mr-2" onclick="resetFilter();">Reset</button>
                                        <button type="button" class="btn text-uppercase btn-success ripple-effect-dark" onclick="loadQuestionnaireList();">Filter</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="table-responsive hide_filter_page">
                        <div id="categoryList"  class="listloader">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Modal -->
<div class="modal fade" id="questionnaireModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="addCandidateModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCategory">Category</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div id="questionnaire-form">

            </div>
        </div>
    </div>
</div>
<input type="hidden" id="listType" value="category">
<script>
    $(document).ready(function () {
        loadCategoryList();
    });

    function loadCategoryList() {
        $("#categoryList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "POST",
            url: "{{ url('/admin/load-category-list') }}",
            data: $('#frmFilter').serialize(),
            success: function (response)
            {
                $("#categoryList").html(response);
            }
        });
    }

    function loadQuestionnaireList() {
        $("#questionnaireList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "POST",
            url: "{{ url('/admin/load-questionnaire-list') }}",
            data: $('#frmFilter').serialize(),
            success: function (response)
            {
                $("#questionnaireList").html(response);
            }
        });
    }

    function resetFilter() {
        $('#frmFilter')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadQuestionnaireList();
    }
</script>
@endsection