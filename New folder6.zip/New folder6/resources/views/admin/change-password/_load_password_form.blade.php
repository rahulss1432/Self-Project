<form class="form-horizontal" id="passwordForm" method="POST" action="{{(url('/admin/password-change'))}}">
    <input type="hidden" name="guard" value="{{$guard}}">
    {{ csrf_field() }}
    <div class="form-group">
        <label for="name" class="control-label">Current Password<span class="text-danger">*</span></label>
        <input type="password" class="form-control" name="current_password" placeholder="Current Password">
    </div>
    <div class="form-group">
        <label for="name" class="control-label">New Password<span class="text-danger">*</span></label>
        <input type="password" class="form-control" name="password" placeholder="New Password">
    </div>
    <div class="form-group">
        <label for="name" class="control-label">Confirm Password<span class="text-danger">*</span></label>
        <input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password">
    </div>
    
</form>
{!! JsValidator::formRequest('App\Http\Requests\ChangePasswordRequest','#passwordForm') !!}

<script>
    $("#btn-password").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btn-password');
        var form = $('#passwordForm');
        if (form.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{(url('/admin/password-change'))}}",
                type: "POST",
                data: form.serialize(),
                success: function (data)
                {
                    btn.prop('disabled', false);
                    location.reload();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
</script>
