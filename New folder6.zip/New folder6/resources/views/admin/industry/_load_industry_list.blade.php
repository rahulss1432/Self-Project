<div class="table-responsive">
    <table class="table common-table admin-table" id="tableList">
        <thead class="th-border">
            <tr>
                <th>Sr.</th>
                <th>Industry Name</th>
                <th width="150">Status</th>
                <th width="120">Action</th>
            </tr>
        </thead>
        <tbody>
            @if(!empty($industryList->count()>0)) @php $i=1; @endphp @foreach($industryList as $industry) @php $srNo = ($industryList->currentPage() - 1) * $industryList->perPage() + $i++; @endphp
            <tr>
                <td>{{$srNo}}</td>
                <td>{{$industry['industry_name']}}</td>
                <td>
                    <div class="switch">
                        <label>
                            <input type="checkbox" {{($industry['status']=='enabled')?'checked="checked"':''}} onchange="updateStatus('{{$industry["id"]}}');" name="status[]" value="{{$industry['status']}}">
                            <span class="lever"></span>
                        </label>
                    </div>
                </td>
                <td>
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="actionIndustry('{{$industry["id"]}}');" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="deleteIndustry('{{$industry["id"]}}','{{$industry["industry_name "]}}')" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
                        </li>
                    </ul>
                </td>
            </tr>
            @endforeach @else
            <tr>
                <td colspan="4">
                    @php \App\Helpers\Utility::emptyListMessage('industry'); @endphp
                </td>
            </tr>
            @endif
        </tbody>
    </table>
</div>
@php \App\Helpers\Utility::getAdminPaginationDiv($industryList); @endphp

<script>
    var title = 'Industry';
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#industryList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
            var pageLink = $(this).attr('href');
            $.ajax({
                type: 'POST',
                url: pageLink,
                async: false,
                data: $('#frmFilter').serialize(),
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#industryList").html(response);
                }
            });
        });
    });
    function updateStatus(id) {
        $.ajax({
            type: "POST",
            url: "{{url('/admin/update-industry-status')}}",
            data: {
                '_token': "{{csrf_token()}}",
                'id': id
            },
            success: function (response) {
                if (response.status) {
                    successToaster(response.message, title);
                }
            }
        });
    }

    function deleteIndustry(id, name) {
        bootbox.confirm('Are you sure do you want to delete <b>' + name + '<b>?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "{{ url('admin/delete-industry') }}",
                    data: {
                        id: id
                    },
                    success: function (response) {
                        if (response.status) {
                            successToaster(response.message, title);
                            loadIndustryList();
                        }
                    }
                });
            }
        });
    }
</script>