@extends( 'layouts.admin.admin-app' )
@section( 'title', 'Manage Industry' )
@section( 'content' )
<main class="main-wrapper dashboard-main-wrap" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Manage Industry</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">Manage Industry List</h3>
                    <ul class="list-inline mb-0 ml-auto">
                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                            <a href="#searchFilter" data-toggle="collapse" class="nav-link ripple-effect-dark">
                                <i class="fa fa-filter"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="actionIndustry(0)" class="nav-link ripple-effect-dark" data-toggle="tooltip" data-placement="top" title="Add Industry">
                                <i class="fa fa-plus"></i>
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="card-body p-0">
                    <div class="filter_section collapse" id="searchFilter">
                        <form id="frmFilter">
                            {{csrf_field()}}
                            <div class="row">
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <input type="text" name="name" class="form-control" placeholder="Industry Name">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                    <button type="button" class="btn btn-success mr-2 ripple-effect-dark" onclick="loadIndustryList();">Filter</button>
                                    <button type="button" class="btn btn-warning ripple-effect-dark" onclick="resetFilter();">Reset</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div id="industryList">

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- Modal -->
<div class="modal fade" id="industryModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="addCandidateModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCandidateModal">Industry</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div id="industry-form">

            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        loadIndustryList();
    });

    function loadIndustryList() {
        $("#industryList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "POST",
            url: "{{ url('/admin/load-industry-list') }}",
            data: $('#frmFilter').serialize(),
            success: function (response) {
                $("#industryList").html(response);
            }
        });
    }

    function actionIndustry(id) {
        $('#industryModal').modal('show');
        $("#industry-form").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "GET",
            url: "{{ url('admin/get-industry-form') }}",
            data: {
                id: id
            },
            success: function (response) {
                $('#industry-form').html(response);
            }
        });
    }

    function resetFilter() {
        $('#frmFilter')[ 0 ].reset();
        $('.selectpicker').selectpicker('refresh');
        loadIndustryList();
    }
</script>
@endsection

