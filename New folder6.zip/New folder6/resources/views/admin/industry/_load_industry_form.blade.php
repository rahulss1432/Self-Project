<form class="form-horizontal" id="industryForm" method="POST" action="{{(url('/admin/industry-submit'))}}">
    <div class="modal-body">
        {{ csrf_field() }}
        <input type="hidden" name="id" value="{{$model->id}}">
        <div class="form-group">
            <label class="control-label">Industry Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" name="industry_name" placeholder="Industry Name" value="{{$model->industry_name}}">
        </div>
        <div class="form-group">
            <label class="control-label">Status<span class="text-danger">*</span></label>
            <select name="status" class="selectpicker form-control">
                <option value="">Select Status</option>
                <option {{($model->status=='enabled')?'selected="selected"':''}} value="enabled">Enabled</option>
                <option {{($model->status=='disabled')?'selected="selected"':''}} value="disabled">Disabled</option>
            </select>
        </div>
    </div>
    <div class="modal-footer">
        <button id="btn-industry"  type="Submit" class="btn ripple-effect-dark btn-success btn-sm text-uppercase">Submit</button>
    </div>
</form>
{!! JsValidator::formRequest('App\Http\Requests\IndustryRequest','#industryForm') !!}

<script>
    $('.selectpicker').selectpicker();
    $("#btn-industry").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btn-industry');
        var form = $('#industryForm');
        if (form.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{(url('/admin/industry-submit'))}}",
                type: "POST",
                data: form.serialize(),
                success: function (data)
                {
                    btn.prop('disabled', false);
                    btn.text('Submit');
                    $('#industryModal').modal('hide');
                    successToaster(data.message,'Industry');
                    loadIndustryList();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
</script>