<table class="table common-table admin-table w-100">
    <thead class="th-border">
        <tr>
            <th>Sr.</th>
            <th>User Type</th>
            <th>Plan Name</th>
            <th>Price</th>
            <th>Duration</th>
            <th>Video Duration</th>
            <th>Jobs Limit</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @if(!empty($planList->count()>0))
        @php $i=1; @endphp
        @foreach($planList as $plan)
        @php $srNo = ($planList->currentPage() - 1) * $planList->perPage() + $i++; @endphp
        <tr>
            <td>{{$srNo}}</td>
            <td>{{ucfirst($plan['user_type'])}}</td>
            <td>{{$plan['plan_name']}}</td>
            <td>{{\App\Helpers\Utility::getPriceFormat($plan['price'])}}</td>
            <td>{{$plan['plan_duration']}} days</td>
            <td>{{$plan['video_duration']}} seconds</td>
            <td>{{$plan['jobs_limit']}}</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" {{($plan['status']=='enabled')?'checked="checked"':''}} onchange="updateStatus('{{$plan["id"]}}');" name="status[]" value="{{$plan['status']}}">
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul  class="list-inline mb-0">
                    <li class="list-inline-item"> <a href="{{url('admin/edit-plan/'.$plan["id"])}}" title="View"><i class="fa fa-pencil"></i></a></li>
                    <li class="list-inline-item"> <a href="javascript:void(0);" onclick="deleteIndustry('{{$plan["id"]}}','{{$plan["plan_name"]}}')" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-trash"></i></a></li>
                </ul>
            </td>
        </tr>
        @endforeach
        @else
        <tr>
            <td colspan="9">@php \App\Helpers\Utility::emptyListMessage('plan'); @endphp</td>
        </tr>
        @endif
    </tbody>
</table>
@php \App\Helpers\Utility::getAdminPaginationDiv($planList); @endphp

<script>
                    var title = 'Plan';
                    $(document).ready(function () {
            $(".pagination li a").on('click', function (e) {
            e.preventDefault();
                    $("#planList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
                    var pageLink = $(this).attr('href');
                    $.ajax({
                    type: 'POST',
                            url: pageLink,
                            async: false,
                            data: $('#frmFilter').serialize(),
                            success: function (response) {
                            $('.pagination:first').remove();
                                    $("#planList").html(response);
                            }
                    });
            });
            });
                    function updateStatus(id) {
                    $.ajax({
                    type: "POST",
                            url: "{{url('/admin/update-plan-status')}}",
                            data: {'_token': "{{csrf_token()}}", 'id': id},
                            success: function (response) {
                            if (response.status) {
                            successToaster(response.message, title);
                            }
                            }
                    });
                    }

            function deleteIndustry(id, name) {
            bootbox.confirm('Are you sure do you want to delete <b>' + name + '<b>?', function (result) {
            if (result) {
            $.ajax({
            type: "GET",
                    url: "{{ url('admin/delete-plan') }}",
                    data: {id: id},
                    success: function (response) {
                    if (response.status) {
                    successToaster(response.message, title);
                            loadPlanList();
                    }
                    }
            });
            }
            });
            }
</script>
