@extends('layouts.admin.admin-app')
@section('title','New Subscription')
@section('content')
<main class="main-wrapper dashboard-main-wrap" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{url('/admin/plans')}}">Subscriptions</a></li>
                    @if(!empty($model->id))
                    <li class="breadcrumb-item active" aria-current="page">Edit Subscription</li>
                    @else
                    <li class="breadcrumb-item active" aria-current="page">Create New Subscription</li>
                    @endif
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">Create New Subscription</h3>
                </div>
                <div class="card-body view_page">
                    <form class="form-horizontal" id="planForm" method="POST" action="{{(url('/admin/plan-submit'))}}">
                        {{ csrf_field() }}
                        <input type="hidden" name="id" value="{{$model->id}}">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name" class="control-label">User Type*</label>
                                    <select name="user_type" class="selectpicker form-control" onchange="blankPlan()">
                                        <option value="">Select User Type</option>
                                        @if(!empty($userType))
                                        @foreach($userType as $type)
                                        <option {{($model->user_type==$type->user_type)?'selected="selected"':''}} value="{{$type->user_type}}">{{$type->label_name}}</option>
                                        @endforeach
                                        @endif

                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name" class="control-label">Plan Name*</label>
                                    <input id="plan_name" type="text" class="form-control" name="plan_name" placeholder="Plan Name" value="{{$model->plan_name}}">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name" class="control-label">Price($)/Month*</label>
                                    <input type="text" class="form-control" name="price" placeholder="Price/Month in $" value="{{$model->price}}">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name" class="control-label">Jobs Limit*
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" value="unlimited" id="unlimited" name="unlimited" {{($model->jobs_limit=='unlimited')?'checked="checked"':''}}> 
                                            <label class="custom-control-label" for="unlimited"> <span>Unlimited</span></label>
                                        </div>
                                    </label>
                                    <input type="text" class="form-control" name="jobs_limit" id="jobs_limit" {{($model->jobs_limit=='unlimited')?'readonly="readonly"':''}} placeholder="Jobs Limit" value="{{($model->jobs_limit=='unlimited')?'':$model->jobs_limit}}">
                                </div>
                            </div>
                            <div class="col-md-6" style="display: none;">
                                <div class="form-group">
                                    <label for="name" class="control-label">Plan Duration*</label>
                                    <input type="text" class="form-control" name="plan_duration" placeholder="Plan Duration" value="30">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name" class="control-label">Video Duration(in seconds)*</label>
                                    <input type="text" class="form-control" name="video_duration" placeholder="Video Duration" value="{{$model->plan_duration}}">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group sele">
                                    <label for="name" class="control-label">Status*</label>
                                    <select name="status" class="selectpicker form-control" title="Select Status">
                                        <option {{($model->status=='enabled')?'selected="selected"':''}} value="enabled">Enabled</option>
                                        <option {{($model->status=='disabled')?'selected="selected"':''}} value="disabled">Disabled</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="name" class="control-label">Plan Description*</label>
                            @if(!empty($model->getDetails))
                            @foreach($model->getDetails as $detailInfo)
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="description[]" placeholder="Description" value="{{$detailInfo['description']}}">
                                </div>
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-danger add-btn" onclick="deleteRow($(this))">Remove</button>
                                </div>
                            </div>
                            @endforeach
                            @endif

                            <div id="desc-list">
                                <div class="row">
                                    <div class="col-md-6">
                                        <input type="text" class="form-control desc" name="description[]" placeholder="Description" value="">
                                    </div>
                                    <div class="col-md-6">
                                        <button type="button" class="btn btn-danger add-btn" onclick="addMore($(this))">Add More</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <button id="btn-plan-new" type="submit" class="btn ripple-effect-dark btn-success btn-sm text-uppercase">Submit</button>
                            </div>                            
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Http\Requests\PlanRequest','#planForm') !!}
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    function chekUnlimited(){
        if ($('#unlimited:checked').length) {
            $('#jobs_limit').attr('readonly', true);
            $('#jobs_limit').val('');
        } else {
            $('#jobs_limit').attr('readonly', false);
        }
    }
    $('#unlimited').change(function () {
        chekUnlimited();
    });
    $('.selectpicker').selectpicker();
    function blankPlan() {
        $('#plan_name').val('');
        $('#plan_name-error').html('');
    }
    $("#btn-plan-new").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btn-plan-new');
        var form = $('#planForm');
        if (form.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{(url('/admin/plan-submit'))}}",
                type: "POST",
                data: form.serialize(),
                success: function (data)
                {
                    btn.prop('disabled', false);
                    window.location.href = "{{url('admin/plans')}}";
//                    location.reload();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    obj = obj['errors'];
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));

    function addMore(obj) {
        if (obj.parent().parent().find('input').val() != '') {
            var html = obj.parent().parent().clone();
            $('#desc-list').append(html);
            obj.parent().html('<button type="button" class="btn btn-danger" onclick="deleteRow($(this))">Remove</button>');
            $('.add-btn').parent().parent().find('input').val('');
        } else {
            errorToaster('Description field can not be blank.', 'Description');
        }
    }

    function deleteRow(obj) {
        obj.parent().parent().remove();
    }
    chekUnlimited();
</script>
@endsection

