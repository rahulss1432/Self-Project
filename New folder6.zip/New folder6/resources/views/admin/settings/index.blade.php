@extends('layouts.admin.admin-app')
@section('title','Settings')
@section('content')
<main class="main-wrapper dashboard-main-wrap" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Manage Settings</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">Manage Settings</h3>
                    <ul class="list-inline mb-0 ml-auto">
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="addSetting(0)" class="nav-link ripple-effect-dark" data-toggle="tooltip" data-placement="top" title="Add Setting">
                                <i class="fa fa-plus"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table common-table admin-table" id="tableList">
                            <thead class="th-border">
                                <tr>
                                    <th>Title</th>
                                    <th>Key</th>
                                    <th>Value</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                @if(!empty($settingList))
                                @foreach($settingList as $setting)
                                <tr>
                                    <td>{{ $setting->setting_title }}</td>
                                    <td>{{ $setting->setting_key }}</td>
                                    <td>
                                        @if($setting->setting_type=='image')
                                        <img src="{{url('public/uploads/settings/'.$setting->setting_value)}}" width="50">
                                        @else
                                        {{ $setting->setting_value }}
                                        @endif
                                    </td>   
                                    <td>
                                        <ul class="list-inline mb-0">
                                            <li class="list-inline-item">
                                                <a title="Edit" data-placement="top" data-toggle="tooltip" href="javascript:void(0);" onclick="addSetting('{{$setting->id}}')"><i class="fa fa-edit"></i></a>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

</main> 
<!-- Modal -->
<div class="modal fade" id="settingsModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="addCandidateModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCandidateModal">Settings</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>

            </div>
            <div class="modal-body">
                <div id="settings-form">

                </div>
            </div>
            <div class="modal-footer">
                <button id="btn-setting"  type="Submit" class="btn ripple-effect-dark btn-success btn-sm text-uppercase">Submit</button>
            </div>
        </div>
    </div>
</div>

<!-- category model end -->
<script>
                    function addSetting(id) {
                    $('#settingsModal').modal('show');
                            $('#settings-form').html('{{\App\Helpers\Utility::ajaxLoader()}}');
                            var url = '{{url("/admin/load-setting-form")}}';
                            $.ajax({
                            url: url,
                                    type: 'POST',
                                    data: {_token: '{{csrf_token()}}', id:id},
                                    success: function(result) {
                                    $("#settings-form").html(result);
                                            if (id == 0) {
                                    $('#modelHeading').html('ADD SETTING');
                                    } else {
                                    $('#modelHeading').html('EDIT SETTING');
                                    }
                                    }
                            });
                    }
</script>
@endsection
