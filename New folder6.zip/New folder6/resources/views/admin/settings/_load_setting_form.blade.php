<form class="form-horizontal" id="settingForm" method="POST" action="{{(url('/admin/setting-submit'))}}" enctype="multipart/form-data">
    {{ csrf_field() }}
    <input type="hidden" name="id" value="{{$model->id}}">
    <div class="form-group">
        <label for="name" class="control-label">Setting Type*</label>
        <select onchange="settingValue()" name="setting_type" id="setting_type" class="form-control">
            <option value="">Select Type</option>
            <option {{($model->setting_type=='text')?'selected="selected"':''}} value="text">Text</option>
            <option {{($model->setting_type=='image')?'selected="selected"':''}} value="image">Image</option>
        </select>
    </div>
    <div class="form-group">
        <label for="name" class="control-label">Setting Title*</label>
        <input type="text" class="form-control" name="setting_title" id="setting_title" value="{{$model->setting_title}}">
    </div>
    <div class="form-group">
        <label for="name" class="control-label">Setting Key*</label>
        <input type="text" class="form-control" name="setting_key" id="setting_key" value="{{$model->setting_key}}">
    </div>
    <div class="form-group" id="txtHtml">
        <label for="name" class="control-label">Setting Value*</label>
        <input type="text" class="form-control" name="setting_value" value="{{$model->setting_value}}">
    </div>

    @if($model->setting_type=='image')
    <div class="form-group imageHtml">
        <label for="name" class="control-label">Setting Image</label>
        <img src="{{url('public/uploads/settings/'.$model->setting_value)}}" width="50">
    </div>
    @endif
    <div class="form-group imageHtml">
        <label for="name" class="control-label">Setting Image*</label>

        <input type="file" class="form-control" name="setting_image" value="">

    </div>
    <div class="form-group imageHtml">
        <label for="name" class="control-label">Image Width</label>

        <input type="text" class="form-control" name="thumbnail_width" value="">

    </div>
    <div class="form-group imageHtml">
        <label for="name" class="control-label">Image Height</label>

        <input type="text" class="form-control" name="thumbnail_height" value="">

    </div>
</form> 
{!!JsValidator::formRequest( 'App\Http\Requests\SettingRequest', '#settingForm' ) !!}


<script>
    $("#btn-setting").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btn-setting');
        var form = $('#settingForm');
        if (form.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{(url('/admin/setting-submit'))}}",
                type: "POST",
                data: new FormData(form[ 0 ]),
                contentType: false,
                cache: false,
                processData: false,
                success: function (data) {
                    btn.prop('disabled', false);
                    location.reload();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        var errors = obj[ x ].length
                        $('#' + x + '-error').html(obj[ x ]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));

    function settingValue() {
        $('#txtHtml').hide();
        $('.imageHtml').hide();
        var setting_type = $("#setting_type option:selected").val();
        if (setting_type == 'text') {
            $('#txtHtml').show();
            $('.imageHtml').hide();
        } else if (setting_type == 'image') {
            $('#txtHtml').hide();
            $('.imageHtml').show();
        }
    }
    settingValue();

    $("#setting_title").keyup(function () {
        var Text = $(this).val();
        Text = Text.toLowerCase();
        Text = Text.replace(/[^a-zA-Z0-9]+/g, '-');
        $("#setting_key").val(Text);
    });
</script>