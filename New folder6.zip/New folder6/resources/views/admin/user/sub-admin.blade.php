@extends('layouts.admin.admin-app')
@section('title','Sub Admin')
@section('content')
<main class="main-wrapper dashboard-main-wrap payment-history-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Sub Admin</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">Sub Admin</h3>
                </div>
                <div class="card-body view_page">
                    @include('admin.user._load_user_form') 
                </div>
            </div>
        </div>
    </div>
</main>
@endsection
