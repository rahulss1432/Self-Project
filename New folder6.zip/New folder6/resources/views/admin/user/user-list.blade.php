@extends('layouts.admin.admin-app')
@section('title', ' Send Email')
@section('content')
<main class="main-wrapper dashboard-main-wrap payment-history-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Send Email</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <form method="post" id="contact-email-form" action="javascript:void(0);">
                <div class="row box-row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="card common-card mt-0">
                            <div class="card-header d-flex align-items-center">
                                <h3 class="font-md">Send Email Form</h3>
                            </div>
                            <div class="card common-card mt-0">
                                <div class="card-body view_page">

                                    {{ csrf_field() }}
                                    
                                    <div class="form-group">
                                        <label class="control-label">User List</label>
                                         <select class="selectpicker form-control" name="user_type" title="Select User Type" onchange="loadUserList($(this));">
                                            @if(!empty($userType))
                                            @foreach($userType as $type)
                                            <option value="{{$type->user_type}}">{{$type->label_name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    
                                    <div class="card-body p-0">
                                
                                <div id="userList">

                                </div>
                            </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label">Subject</label>
                                        <input class="form-control" name="subject" id="subject" type="text" placeholder="Subject">
                                    </div>

                                    <div class="form-group text_editor" id="divContent">
                                        <label class="control-label">Content</label>
                                        <textarea rows="6" name="content" id="email-contant" class="form-control" placeholder="Content" >
                                            @include('email-templates.contact-email')
                                        </textarea>
                                        <span id="email-contant-error" class="help-block error-help-block"></span>
                                    </div>
                                    <button class="text-uppercase btn ripple-effect-dark btn-success" id="contact-email-btn" type="submit">Send Mail</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form> 
            {!! JsValidator::formRequest('App\Http\Requests\ContactEmailRequest','#contact-email-form') !!}
        </div>
    </div>
</main>

<script>
    var title = 'Email';
    
    function loadUserList(obj) {
        $("#userList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        var data = obj.val();
        $.ajax({
            type: "POST",
            url: "{{ url('/admin/load-contact-user-list') }}",
            data: {_token: '{{ csrf_token() }}', data: data},
            success: function (response)
            {
                $("#userList").html(response);
            }
        });
    }


    $("#contact-email-btn").on('click', (function (e) {
        var btn = $('#contact-email-btn');
        var form = $('#contact-email-form');
        var count = checkSelectBox();

        var i = 0;
        $('#email-contant').val($('#divContent').find('.nicEdit-main').html());
        form.valid();
        if ($('#email-contant').val().replace(/(<([^>]+)>)/ig, "") == '') {
            $('#email-contant-error').show();
            $('#email-contant-error').html('Content field is required.');
            i++;
        } else {
            $('#email-contant-error').hide();
            $('#email-contant-error').html('');
        }
        if (i > 0) {
            return false;
        }
        if (count == 1) {
            if (form.valid()) {
                e.preventDefault();
                btn.html('{{\App\Helpers\Utility::buttonLoader()}} Send Mail');
                btn.prop('disabled', true);
                $.ajax({
                    url: "{{url('/admin/send-contact-email')}}",
                    type: "POST",
                    data: new FormData($('#contact-email-form')[0]),
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function (data)
                    {
                        if ( data.status ) {
                            successToaster( data.message, title );
                        }else{
                            errorToaster( data.message, title );
                        }
                        location.reload();
                    },
                    error: function (data) {
                        var obj = jQuery.parseJSON(data.responseText);
                        for (var x in obj) {
                            btn.prop('disabled', false);
                            btn.html('Send');
                            var errors = obj[x].length
                            $('#' + x + '-error').html(obj[x]);
                            $('#' + x + '-error').css("color", '#b30000');
                            $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                        }
                    },
                });
            }
        } else {
            bootbox.alert('please select user to send contact email');
        }
    }));

    bkLib.onDomLoaded(function () {
        new nicEditor({fullPanel: true, maxHeight: 300}).panelInstance('email-contant');
    });
    
    function checkSelectBox() {
        var checkVal = '';
        $('.checkboxNews').each(function () {
            var checkProp = $(this).prop("checked");
            if (checkProp == true) {
                checkVal = 1;
            }else{
                $('#checkAll').prop('checked', false);
            }
        });
        if (checkVal == 1) {
            return checkVal;
        } else {
            $('#checkAll').prop('checked', false);
            return 0;
        }
    }
</script>
@endsection
