@php 
 if($userDetail['user_type'] == 'candidate'){
    $backUrl = 'candidates';
 } else if($userDetail['user_type'] == 'employer'){
    $backUrl = 'employer';
 } else if($userDetail['user_type'] == 'freelancer'){
    $backUrl = 'freelancer';
 }
@endphp
@extends('layouts.admin.admin-app')
@section('title',ucfirst($userDetail['user_type']).' List')
@section('content')
<main class="main-wrapper dashboard-main-wrap payment-history-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><a href="{{url('/admin/'.$backUrl)}}">{{ucfirst($userDetail['user_type'])}}</a></li>
                    <li class="breadcrumb-item active" aria-current="page">{{ucfirst($userDetail['user_type'])}} View</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0" id="card_height">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">{{ucfirst($userDetail['user_type'])}} View</h3>
                    <ul class="list-inline mb-0 ml-auto">
                        <li class="list-inline-item" >
                            <a href="javascript:void(0);" target="_blank" class="btn btn-sm btn-success ripple-effect-dark">
                                View Profile
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body view_page">
                    <div class="view_details">
                        <div class="info">
                            <label>Name </label>
                            <span>{{$userDetail['first_name'].' '.$userDetail['last_name']}}</span>
                        </div>
                        <div class="info">
                            <label>Email Id</label>
                            <span>{{$userDetail['email']}}</span>
                        </div>
                        <div class="info">
                            <label>Subscription Plan </label>
                            <span>{{(!empty($userDetail->getActivePlan->getPlan->plan_name))?$userDetail->getActivePlan->getPlan->plan_name:''}}</span>
                        </div>
                        <div class="info">
                            <label>Amount</label>
                            <span>{{\App\Helpers\Utility::getPriceFormat($userDetail->getActivePlan->amount)}}</span>
                        </div>
                        <div class="info">
                            <label>Last login</label>
                            <span>{{\App\Helpers\Utility::getDateTimeFormat($userDetail['last_login'])}}</span>
                        </div>
                        <div class="info">
                            <label>Signed up</label>
                            <span>{{\App\Helpers\Utility::getDateFormat($userDetail['created_at'])}}</span>
                        </div>
                        <div class="info">
                            <label>Status </label>
                            <span><strong class="{{($userDetail['status']=='enabled')? 'text-success':'text-danger'}}">{{($userDetail['status']=='enabled')? 'Active':'Inactive'}}</strong></span>
                        </div>
                    </div>
                </div>
            </div>
                @php 
                    $transactionData = \App\Models\PlanSubscription::getUserSubscriptuinsById($userDetail['id']);
                @endphp        
                        
                <div class="card common-card">
                    <div class="card-header">
                        <h3 class="font-md mb-0"> Subscriptions History</h3>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table common-table">
                                <thead>
                                    <tr>
                                        <th scope="col">Transaction id </th>
                                        <th scope="col">Purchase Date</th>
                                        <th scope="col">Plan Type</th>
                                        <th scope="col">Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if($transactionData->count()>0)
                                        @foreach($transactionData as $data)
                                            <tr>
                                                <td>{{$data['transaction_id']}}</td>
                                                <td>{{\App\Helpers\Utility::getDateFormat($data['created_at'])}}</td>
                                                <td>{{$data->getPlan->plan_name}}</td>
                                                <td>{{\App\Helpers\Utility::getPriceFormat($data['amount'])}}</td>
                                            </tr>
                                        @endforeach
                                    @else
                                    <tr>
                                        <td colspan="4">
                                            @php \App\Helpers\Utility::emptyListMessage('Subscription'); @endphp
                                        </td>
                                    </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                       
        </div>
    </div>
</main>
@endsection
