<form class="form-horizontal" id="userForm" method="POST" action="{{(url('/admin/update-user-info'))}}">
    <div class="modal-body">

        {{ csrf_field() }}
        <input type="hidden" name="id" value="{{$model->id}}">
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label class="control-label">First Name<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="first_name" placeholder="First Name" value="{{$model->first_name}}">
                </div>
            </div>
            <div class="col-sm-12">
                <div class="form-group">
                    <label class="control-label">Last Name<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="last_name" placeholder="Last Name" value="{{$model->last_name}}">
                </div>
            </div>
            <div class="col-sm-12">
                <div class="form-group">
                    <label class="control-label">Email<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="email" placeholder="Email" value="{{$model->email}}">
                </div>
            </div>
            <div class="col-sm-12">
                <div class="form-group">
                    <label class="control-label">Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Password">
                </div>
            </div>        
            <div class="col-sm-12" style="display:{{($model->id) == ''? 'none;':'block;'}}">            
                <div class="form-group">
                    <label for="name" class="control-label">Status<span class="text-danger">*</span></label>
                    <select name="status" class="selectpicker form-control" title="Select Status">
                        <option {{($model->status=='enabled')?'selected="selected"':''}} value="enabled">Enabled</option>
                        <option {{($model->status=='disabled')?'selected="selected"':''}} value="disabled">Disabled</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button id="btn-user" type="Submit" class="btn btn-sm ripple-effect-dark btn-success text-uppercase">Submit</button>
    </div>
</form>
{!! JsValidator::formRequest('App\Http\Requests\UpdateUserInfoRequest','#userForm') !!}

<script>
    $('.selectpicker').selectpicker();
    $("#btn-user").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btn-user');
        var form = $('#userForm');
        if (form.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{(url('/admin/update-user-info'))}}",
                type: "POST",
                data: form.serialize(),
                success: function (data)
                {
                    $('#edituserModal').modal('hide');
                    successToaster(data.message, '{{ucfirst($model->user_type)}}');
                    btn.prop('disabled', false);
                    btn.html('Submit');
                            @if ($model->user_type != 'sub_admin')
                            loadUserList();
                            @endif
                },
                error: function (data) {

                },
            });
        }
    }));
</script>
