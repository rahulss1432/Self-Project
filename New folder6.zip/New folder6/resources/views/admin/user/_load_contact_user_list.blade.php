<div class="table-responsive hide_filter_page">
    <table class="table common-table admin-table w-100">
        <thead class="gray-bg">
            <tr>
                <th>
<!--
                    <div class="checkbox">
                        <input type="checkbox" value="" onchange="checkSelectBox();"  id="checkAll">
                        <label for="checkAll"><span class="checkbox-icon"></span></label>
                    </div>
-->
               
               <div class="custom-control custom-checkbox">
					<input  type="checkbox"  onchange="checkSelectBox();"  class="custom-control-input" value="" id="checkAll"> 
					<label class="custom-control-label" for="checkAll"> </label>
				</div>
               
                </th>
                <th>Name</th>
                <th class="text-left">Email</th>
            </tr>
        </thead>
        <tbody>
            @if(!empty($userList->count()>0))
            @foreach($userList as $user)
            <tr>
                <td>
<!--
                    <div class="checkbox">
                        <input type="checkbox" name="users[]" onchange="checkSelectBox();" class="checkboxNews"  value="{{ $user->email }}" id="one{{ $user->id }}">
                            <label for="one{{ $user->id }}"><span class="checkbox-icon"></span> </label>
                    </div>
-->
               <div class="custom-control custom-checkbox">
					<input  type="checkbox" name="users[]" onchange="checkSelectBox();"  class="custom-control-input" value="{{ $user->email }}" id="one{{ $user->id }}"> 
					<label class="custom-control-label" for="one{{ $user->id }}"> </label>
				</div>
                </td>
                <td>{{$user['first_name'].' '.$user['last_name']}}</td>
                <td class="text-left">{{$user['email']}}</td>
            </tr> 
            @endforeach
            @else
            <tr>
                <td colspan="3">
                    @php \App\Helpers\Utility::emptyListMessage('User'); @endphp
                </td>
            </tr>
            @endif
        </tbody>
    </table>
</div>

<script>
    $('#checkAll').click(function () {
        $('input:checkbox').prop('checked', this.checked);
    });

    
</script>