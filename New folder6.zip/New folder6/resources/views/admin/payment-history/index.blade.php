@extends('layouts.admin.admin-app')
@section('title','Manage Payment')
@section('content')
<main class="main-wrapper dashboard-main-wrap" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Manage Payments</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">Manage Payments List</h3>
                    <ul class="list-inline mb-0 ml-auto">
                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                            <a href="#searchFilter" data-toggle="collapse" class="nav-link ripple-effect-dark">
                                <i class="fa fa-filter"></i>
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="card-body p-0">
                    <div class="filter_section collapse" id="searchFilter">
                        <form id="frmFilter">
                            {{csrf_field()}}
                            <div class="row">
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <select name="user_type" class="selectpicker form-control">
                                            <option value="">Select User Type</option>
                                            @if(!empty($userType))
                                            @foreach($userType as $type)
                                            <option value="{{$type->user_type}}">{{$type->label_name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control datepicker" id="from_date"  data-toggle="datetimepicker" name="from_date" data-target="#from_date" placeholder="From Date" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control datepicker" id="to_date"   data-toggle="datetimepicker" name="to_date" data-target="#to_date" placeholder="To Date" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                     <button type="button" class="btn btn-success ripple-effect-dark mr-2" onclick="loadPaymentList();">Filter</button>
                                     <button type="button" class="btn btn-warning ripple-effect-dark" onclick="resetFilter();">Reset</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div id="paymentList">

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    $(document).ready(function () {
        loadPaymentList();
    });

    function loadPaymentList() {
        $("#paymentList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "POST",
            url: "{{ url('/admin/load-payment-history') }}",
            data: $('#frmFilter').serialize(),
            success: function (response)
            {
                $("#paymentList").html(response);
            }
        });
    }
    $(function () {
        $('#from_date').datetimepicker({format: '{{\App\Helpers\Utility::getDatePickerForamt()}}'});
        $('#to_date').datetimepicker({
            format: '{{\App\Helpers\Utility::getDatePickerForamt()}}',
            useCurrent: false
        });
        $("#from_date").on("change.datetimepicker", function (e) {
            $('#to_date').datetimepicker('minDate', e.date);
        });
        $("#to_date").on("change.datetimepicker", function (e) {
            $('#from_date').datetimepicker('maxDate', e.date);
        });
    });

    function resetFilter() {
        $('#frmFilter')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadPaymentList();
    }
</script>
@endsection