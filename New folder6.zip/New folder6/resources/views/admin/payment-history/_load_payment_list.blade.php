<div class="table-responsive">
<table class="table common-table admin-table">
    <thead class="th-border">
        <tr>
            <th>Sr.</th>
            <th>Name</th>
            <th>User Type</th>
            <th>Plan</th>
            <th>Amount</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
@if(!empty($paymentList->count()>0))
@php $i=1; @endphp
        @foreach($paymentList as $payment)
        @php $srNo = ($paymentList->currentPage() - 1) * $paymentList->perPage() + $i++; @endphp
        <tr>
            <td>{{$srNo}}</td>
            <td>{{$payment->getUser->first_name.' '.$payment->getUser->last_name}}</td>
            <td>{{$payment->getUser->getUserType->label_name}}</td>
            <td>{{$payment->getPlan->plan_name}}</td>
            <td>{{\App\Helpers\Utility::getPriceFormat($payment['price'])}}</td>
             <td>{{\App\Helpers\Utility::getDateFormat($payment['created_at'])}}</td>
        </tr>
        @endforeach
        @else
        <tr>
            <td colspan="6">@php \App\Helpers\Utility::emptyListMessage('transaction'); @endphp</td>
        </tr>
@endif
    </tbody>
</table>
 </div>

@php \App\Helpers\Utility::getAdminPaginationDiv($paymentList); @endphp

<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#paymentList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
            var pageLink = $(this).attr('href');
            $.ajax({
                type: 'POST',
                url: pageLink,
                async: false,
                data: $('#frmFilter').serialize(),
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#paymentList").html(response);
                }
            });
        });
    });
</script>
