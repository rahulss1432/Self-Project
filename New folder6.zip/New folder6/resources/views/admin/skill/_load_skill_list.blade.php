<div class="table-responsive">
    <table class="table common-table admin-table">
        <thead class="th-border">
            <tr>
                <th>Sr.</th>
                <th>Industry Name</th>
                <th>Skill Name</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @if(!empty($skillsList->count()>0))
            @php $i=1; @endphp
            @foreach($skillsList as $skill)
            @php $srNo = ($skillsList->currentPage() - 1) * $skillsList->perPage() + $i++; @endphp
            <tr>
                <td>{{$srNo}}</td>
                <td>{{$skill['industry_name']}}</td>
                <td>{{$skill['skill_name']}}</td>
                <td>
                    <div class="switch">
                        <label>
                            <input type="checkbox" {{($skill['status']=='enabled')?'checked="checked"':''}} onchange="updateStatus('{{$skill["id"]}}');" name="status[]" value="{{$skill['status']}}">
                            <span class="lever"></span>
                        </label>
                    </div>


                </td>
                <td>
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="actionSkill('{{$skill["id"]}}');" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
                        </li>
                        <li  class="list-inline-item">
                            <a href="javascript:void(0);" onclick="deleteSkill('{{$skill["id"]}}','{{$skill["skill_name"]}}')" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-trash"></i></a>
                        </li>
                    </ul>
                </td>
            </tr>
            @endforeach
            @else
            <tr>
                <td colspan="5">@php \App\Helpers\Utility::emptyListMessage('skill'); @endphp</td>
            </tr>
            @endif
        </tbody>
    </table>
</div>
@php \App\Helpers\Utility::getAdminPaginationDiv($skillsList); @endphp

<script>
    var title = 'Skill';
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#skillList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
            var pageLink = $(this).attr('href');
            $.ajax({
                type: 'POST',
                url: pageLink,
                async: false,
                data: $('#frmFilter').serialize(),
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#skillList").html(response);
                }
            });
        });
    });
    function updateStatus(id) {
        $.ajax({
            type: "POST",
            url: "{{url('/admin/update-skill-status')}}",
            data: {'_token': "{{csrf_token()}}", 'id': id},
            success: function (response) {
                if (response.status) {
                    successToaster(response.message, title);
                }
            }
        });
    }

    function deleteSkill(id, name) {
        bootbox.confirm('Are you sure do you want to delete <b>' + name + '<b>?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "{{ url('admin/delete-skill') }}",
                    data: {id: id},
                    success: function (response) {
                        if (response.status) {
                            successToaster(response.message, title);
                            loadSkillList();
                        }
                    }
                });
            }
        });
    }
</script>
