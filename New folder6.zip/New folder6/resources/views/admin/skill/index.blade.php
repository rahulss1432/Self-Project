@extends('layouts.admin.admin-app')
@section('title','Manage Skills')
@section('content')
<main class="main-wrapper dashboard-main-wrap" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Manage Skills</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">Manage Skills List</h3>
                    <ul class="list-inline mb-0 ml-auto">
                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                            <a href="#searchFilter" data-toggle="collapse" class="nav-link ripple-effect-dark">
                                <i class="fa fa-filter"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);"  onclick="$('#importCsv').modal('show')" class="nav-link ripple-effect-dark" data-toggle="tooltip" data-placement="top" title="CSV Import">
                                <i class="fa fa-file"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="actionSkill(0);" class="nav-link ripple-effect-dark" data-toggle="tooltip" data-placement="top" title="Add Skills">
                                <i class="fa fa-plus"></i>
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="card-body p-0">
                    <div class="filter_section collapse" id="searchFilter">
                        <form id="frmFilter">
                            {{csrf_field()}}
                            <div class="row">
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <input type="text" name="name" class="form-control" placeholder="Industry Name">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <select name="industry_id" class="selectpicker form-control" title="Industry Type">
                                            <option value="">Industry Type</option>
                                            @if(!empty($industries))
                                            @foreach($industries as $industry)
                                            <option value="{{$industry->id}}">{{$industry->industry_name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">

                                    <button type="button" class="btn btn-success ripple-effect-dark mr-2" onclick="loadSkillList();">Filter</button>
                                    <button type="button" class="btn btn-warning ripple-effect-dark" onclick="resetFilter();">Reset</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div id="skillList"  class="listloader">

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="skillModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="addCandidateModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCandidateModal">Skills</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div id="skill-form">

            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        loadSkillList();
    });

    function loadSkillList() {
        $("#skillList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "POST",
            url: "{{ url('/admin/load-skill-list') }}",
            data: $('#frmFilter').serialize(),
            success: function (response)
            {
                $("#skillList").html(response);
            }
        });
    }

    function actionSkill(id) {
        $('#skillModal').modal('show');
        $("#skill-form").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "GET",
            url: "{{ url('admin/get-skill-form') }}",
            data: {id: id},
            success: function (response) {
                $('#skill-form').html(response);
            }
        });
    }

    function resetFilter() {
        $('#frmFilter')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadSkillList();
    }
</script>

<div id="importCsv" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Import Skills</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="name" class="col-md-12 control-label"><a href="{{url('public/skill_import_sample_file.csv')}}" download="skill_import_sample_file.csv">Download Sample File</a></label>
                </div>
                <form class="form-horizontal" enctype="multipart/form-data" id="csvForm" method="POST" action="{{(url('/admin/skill-csv-import'))}}">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label for="name" class="col-md-12 control-label">Browse CSV*</label>
                        <div class="col-md-12">
                            <input type="file" class="form-control" name="skill_csv">
                            <div class="progress" style="display:none;">
                                <div class="bar"></div >
                                <div class="percent">0%</div >
                            </div>
                            <div id="status"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                            <button type="submit" id="btn-csv"  class="btn btn-primary">
                                Submit
                            </button>
                        </div>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\ImportSkillRequest','#csvForm') !!}
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- category model end -->
@endsection