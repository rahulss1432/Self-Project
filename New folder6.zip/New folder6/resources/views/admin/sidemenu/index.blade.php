@extends( 'layouts.admin.admin-app' )
@section( 'title', 'Edit Side Menu' )
@section( 'content' )
<main class="main-wrapper dashboard-main-wrap" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Side Menu</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <form class="form-horizontal" id="menu-form" method="POST" action="{{(url('/admin/side-menu-save'))}}">
                {{ csrf_field() }}
                <div class="card common-card mt-0">
                    <div class="card-header d-flex align-items-center">
                        <h3 class="font-md">Candidate Menu</h3>
                    </div>
                    <div class="card-body view_page pb-0">                    
                        <div class="row">
                            @if($candidateMenuList->count() > 0)
                                @foreach($candidateMenuList as $list)
                                <div class="col-sm-6 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <input type="text" name="{{$list['menu_key']}}" class="form-control" placeholder="{{$list['menu_name']}}" value="{{$list['menu_name']}}">
                                    </div>
                                </div>
                                @endforeach
                            @endif
                        </div>
                        </form>
                    </div>
                    <div class="card-header d-flex align-items-center">
                        <h3 class="font-md">Employer Menu</h3>
                    </div>
                    <div class="card-body view_page pb-0">
                        <div class="row">
                            @if($employerMenuList->count() > 0)
                                @foreach($employerMenuList as $list)
                                <div class="col-sm-6 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <input type="text" name="{{$list['menu_key']}}" class="form-control" placeholder="{{$list['menu_name']}}" value="{{$list['menu_name']}}">
                                    </div>
                                </div>
                                @endforeach
                            @endif

                        </div>
                    </div>
                    <div class="card-header d-flex align-items-center">
                        <h3 class="font-md">Freelancer Menu</h3>
                    </div>
                    <div class="card-body view_page">
                        <div class="row">
                            @if($freelancerMenuList->count() > 0)
                                @foreach($freelancerMenuList as $list)
                                <div class="col-sm-6 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <input type="text" name="{{$list['menu_key']}}" class="form-control" placeholder="{{$list['menu_name']}}" value="{{$list['menu_name']}}">
                                    </div>
                                </div>
                                @endforeach
                            @endif
                        </div>
                        <button type="submit" id="btn-sidemenu" class="btn btn-success ripple-effect-dark text-uppercase">Update</button>                         
                    </div>
                </div>
            </form>
        </div>
        {!! JsValidator::formRequest('App\Http\Requests\SideMenuRequest','#menu-form') !!}
    </div>
</main>

<!-- Modal -->


<script>
$("#btn-sidemenu").on('click', (function (e) {
    e.preventDefault();
    var btn = $('#btn-sidemenu');
    var form = $('#menu-form');
    if (form.valid()) {
        btn.html('{{\App\Helpers\Utility::buttonLoader()}} Updating');
        btn.prop('disabled', true);
        $.ajax({
            url: "{{(url('/admin/side-menu-save'))}}",
            type: "POST",
            data: form.serialize(),
            success: function (data) {
                btn.prop('disabled', false);
                location.reload();
            },
            error: function (data) {
                var obj = jQuery.parseJSON(data.responseText);
                for (var x in obj) {
                    btn.prop('disabled', false);
                    btn.html('Submit');
                    var errors = obj[ x ].length
                    $('#' + x + '-error').html(obj[ x ]);
                    $('#' + x + '-error').css("color", '#b30000');
                    $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                }
            },
        });
    }
}));
</script>
@endsection

