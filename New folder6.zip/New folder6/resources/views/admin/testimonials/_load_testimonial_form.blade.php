<form class="form-horizontal" id="testimonialForm" method="POST" action="{{(url('/admin/testimonial-submit'))}}">
    {{ csrf_field() }}
    <input type="hidden" name="id" value="{{$model->id}}">
    <div class="form-group">
        <label>Image</label>
        <div class="uploadIcon">
            <label class="d-block" for="uploadImage">
                <span class="form-control" id="fileName">{{$model->testimonial_image}}</span>
                <input name="testimonial_image" type="file" id="uploadImage">
            </label>
        </div>
    </div>
    <div class="form-group">
        <label class="control-label">Name</label>
        <input type="text" class="form-control" name="name" placeholder="Name" value="{{$model->name}}">
    </div>
    <div class="form-group">
        <label class="control-label">Description</label>
        <textarea class="form-control" name="description" placeholder="Description" rows="6">{{$model->description}}</textarea>
    </div>
</form>
{!! JsValidator::formRequest('App\Http\Requests\TesimonialRequest','#testimonialForm') !!}

<script>
    $('#uploadImage').change( function () {
        var file = this.files[ 0 ];
        $( "#fileName" ).html( file.name );
    });
                
    $("#btn-testimonial").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#btn-testimonial');
        var form = $('#testimonialForm');
        if (form.valid()) {
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{(url('/admin/testimonial-submit'))}}",
                type: "POST",
                data: new FormData($('#testimonialForm')[0]),
                contentType: false,
                cache: false,
                processData: false,
                success: function (data)
                {
                    btn.prop('disabled', false);
                    location.reload();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
</script>