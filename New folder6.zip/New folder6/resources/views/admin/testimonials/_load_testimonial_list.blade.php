<div class="table-responsive">
    <table class="table common-table admin-table" id="tableList">
        <thead class="th-border">
            <tr>
                <th>Sr.</th>
                <th>Image</th>
                <th>Name</th>
                <th>Description</th>
                <th width="120">Action</th>
            </tr>
        </thead>
        <tbody>
            @if(!empty($testimonialList->count()>0)) 
            @php $i=1; @endphp 
            @foreach($testimonialList as $testimonial) 
            @php $srNo = ($testimonialList->currentPage() - 1) * $testimonialList->perPage() + $i++; 
            @endphp
            <tr>
                <td>{{$srNo}}</td>
                <td><img height="40" width="40" src="{{\App\Helpers\Utility::checkTestimonialImage($testimonial['testimonial_image'])}}"></td>
                <td>{{$testimonial['name']}}</td>
                <td>{{$testimonial['description']}}</td>
                <td>
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="actionTestimonial('{{$testimonial["id"]}}');" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="deleteIndustry('{{$testimonial["id"]}}')" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
                        </li>
                    </ul>
                </td>
            </tr>
            @endforeach @else
            <tr>
                <td colspan="4">
                    @php \App\Helpers\Utility::emptyListMessage('testimonial'); @endphp
                </td>
            </tr>
            @endif
        </tbody>
    </table>
</div>
@php \App\Helpers\Utility::getAdminPaginationDiv($testimonialList); @endphp

<script>
    var title = 'Testimonial';
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#testimonialList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
            var pageLink = $(this).attr('href');
            $.ajax({
                type: 'POST',
                url: pageLink,
                async: true,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#testimonialList").html(response);
                }
            });
        });
    });

    function deleteIndustry(id) {
        bootbox.confirm('Are you sure do you want to delete this testimonial?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "{{ url('admin/delete-testimonial') }}",
                    data: {
                        id: id
                    },
                    success: function (response) {
                        if (response.status) {
                            successToaster(response.message, title);
                            loadTestimonialList();
                        }
                    }
                });
            }
        });
    }
</script>