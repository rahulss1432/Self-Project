@extends( 'layouts.admin.admin-app' )
@section( 'title', 'Manage Testimonial' )
@section( 'content' )
<main class="main-wrapper dashboard-main-wrap" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="{{url('/admin/dashboard')}}">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Manage Testimonial</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">Testimonials</h3>
                    <ul class="list-inline mb-0 ml-auto">
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="actionTestimonial(0)" class="nav-link ripple-effect-dark" data-toggle="tooltip" data-placement="top" title="Add Testimonial">
                                <i class="fa fa-plus"></i>
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="card-body p-0">
                    <div id="testimonialList">

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Modal -->
<div class="modal fade" id="testimonialModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="addCandidateModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Add Testimonial</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>

            </div>
            <div class="modal-body">
                <div id="testimonial-form">

                </div>
            </div>
            <div class="modal-footer">
                <button id="btn-testimonial"  type="Submit" class="btn ripple-effect-dark btn-success btn-sm text-uppercase">Submit</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        loadTestimonialList();
    });

    function loadTestimonialList() {
        $("#testimonialList").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "GET",
            url: "{{ url('/admin/load-testimonial-list') }}",
            success: function (response) {
                $("#testimonialList").html(response);
            }
        });
    }

    function actionTestimonial(id) {
        $('#testimonialModal').modal('show');
        $("#testimonial-form").html('{{\App\Helpers\Utility::ajaxLoader()}}');
        $.ajax({
            type: "GET",
            url: "{{ url('admin/get-testimonial-form') }}",
            data: {
                id: id
            },
            success: function (response) {
                $('#modalTitle').text('Add Testimonial');
                if(id>0){
                    $('#modalTitle').text('Edit Testimonial');
                }
                $('#testimonial-form').html(response);
            }
        });
    }
</script>
@endsection

