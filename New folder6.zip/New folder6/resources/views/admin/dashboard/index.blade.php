@extends('layouts.admin.admin-app')
@section('title','Dashboard')
@section('content')
<main class="main-wrapper dashboard-main-wrap admin-dashboard" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <!-- <div class="top-row d-sm-flex align-items-center justify-content-between mb-sm-4"> -->
            <nav aria-label="breadcrumb" class="text-right order-sm-last">
                <ol class="breadcrumb d-inline-flex">   
                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                </ol>
            </nav>

            <!-- </div> -->
            <section class="admin-fun-fact">
                <!-- Candidate -->
                <div class="row box-row" id="showCandidate">
                    <div class="col-md-6">
                        <div class="wrap d-flex justify-content-between align-items-center">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Users</h2>
                                <ul class="list-inline">
                                    @php $userType=\App\Models\UserType::getListedType(); @endphp
                                    @if(!empty($userType))
                                    @foreach($userType as $type)
                                    <li class="list-inline-item">
                                        <h3 class="name">{{$type['label_name']}}</h3>
                                        <p class="count">{{\App\Models\User::where('user_type',$type['user_type'])->count()}}</p>
                                    </li>
                                    @endforeach
                                    @endif
                                </ul>
                            </div>
                            <div class="icon bg-pink d-flex align-items-center justify-content-center">
                                <img src="{{url('public/images/group-user-icon.svg')}}" alt="icon">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="wrap d-flex justify-content-between align-items-center">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Earnings</h2>
                                <ul class="list-inline">
                                    @if(!empty($userType))
                                    @foreach($userType as $type)
                                    <li class="list-inline-item">
                                        <h3 class="name">{{$type['label_name']}}</h3>
                                        <p class="count">{{\App\Helpers\Utility::getPriceformat(\App\Models\PlanSubscription::join('plans','plan_id','=','plans.id')->where('user_type',$type['user_type'])->sum('amount'))}}</p>
                                    </li>
                                    @endforeach
                                    @endif
                                </ul>
                            </div>
                            <div class="icon bg-yello d-flex align-items-center justify-content-center">
                                <i class="fa fa-database"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="wrap view-video d-flex justify-content-between align-items-center">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Jobs</h2>
                                <ul class="list-inline">
                                    <li class="list-inline-item">
                                        <h3 class="name">Posted</h3>
                                        <p class="count">{{\App\Models\Job::count()}}</p>
                                    </li>
                                    <li class="list-inline-item">
                                        <h3 class="name">Applied Jobs</h3>
                                        <p class="count">{{\App\Models\JobApplication::count()}}</p>
                                    </li>
                                    <li class="list-inline-item">
                                        <h3 class="name">Accepted</h3>
                                        <p class="count">{{\App\Models\JobApplication::where(['status'=>['accepted','awaiting_interview','interview_submitted','hired']])->count()}}</p>
                                    </li>
                                </ul>
                            </div>
                            <div class="icon bg-green d-flex align-items-center justify-content-center">
                                <img src="{{url('public/images/job-applied-icon.svg')}}" alt="icon">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="wrap view-video d-flex justify-content-between align-items-center">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Interviews</h2>
                                <ul class="list-inline">
                                    <li class="list-inline-item">
                                        <h3 class="name">Requested</h3>
                                        <p class="count">100</p>
                                    </li>
                                    <li class="list-inline-item">
                                        <h3 class="name">Accepted</h3>
                                        <p class="count">70</p>
                                    </li>
                                    <li class="list-inline-item">
                                        <h3 class="name">Declined</h3>
                                        <p class="count"> 60</p>
                                    </li>
                                </ul>
                            </div>
                            <div class="icon bg-pink d-flex align-items-center justify-content-center">
                                <img src="{{url('public/images/request-icon.svg')}}" alt="icon">
                            </div>
                        </div>
                    </div>
                </div> 
                <!-- for chart -->
                <div class="row box-row">
                    <div class="col-md-6">
                        <div class="card  common-card mt-0">
                            <div class="card-header d-xl-flex d-xs-block align-items-center justify-content-between">
                                <h3 class="font-md mb-xl-0 mb-2">Total Earnings</h3>
                                <div class="sort">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group m-0 dateIcon">
                                                <input type="text" class="form-control datetimepicker-input date" id="datetimepicker1" data-toggle="datetimepicker" data-target="#datetimepicker1" placeholder="From">
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group m-0 dateIcon">
                                                <input type="text" class="form-control datetimepicker-input date" id="datetimepicker2" data-toggle="datetimepicker" data-target="#datetimepicker2" placeholder="To">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <canvas id="hiringChart" width="100%"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card  common-card mt-0">
                            <div class="card-header d-xl-flex d-xs-block align-items-center justify-content-between">
                                <h3 class="font-md mb-xl-0 mb-2">Total Hiring</h3>
                                <div class="sort">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group m-0 dateIcon">
                                                <input type="text" class="form-control datetimepicker-input date" id="datetimepicker3" data-toggle="datetimepicker" data-target="#datetimepicker3" placeholder="From">
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group m-0 dateIcon">
                                                <input type="text" class="form-control datetimepicker-input date" id="datetimepicker4" data-toggle="datetimepicker" data-target="#datetimepicker4" placeholder="To">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <canvas id="myChart2" width="100%"></canvas>
                            </div>
                        </div>
                    </div>

                </div>
            </section>
        </div>
    </div>
</main>
<script src="{{url('public/js/moment.js')}}" type="text/javascript"></script>
<script src="{{url('public/js/chart.js')}}" type="text/javascript"></script>
<script>
// for chart
var ctx = document.getElementById("myChart2");
// Chart.defaults.global.animation.duration = 3000;
// ctx.height= 500;
Chart.defaults.global.defaultFontSize = 12;
var myChart1 = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        datasets: [{
                label: 'Total Earnings',
                data: [10000, 15000, 18000, 22000, 20000, 22000, 26000, 30000, 38000, 36000, 45000, 48000],
                backgroundColor: [
                    'transparent',
                ],
                pointBackgroundColor: 'rgba(255, 255, 255, 1)',
                pointHoverBorderColor: '#FFAC29',
                borderColor: [
                    '#FFAC29',
                ],
                borderWidth: 2
            }]
    },
    options: {
        scaleShowVerticalLines: false,
        legend: {
            display: false
        },
        responsive: true,
        scales: {
            xAxes: [{
                    gridLines: {
                        display: false
                    }
                }],
            yAxes: [{
                    gridLines: {
                        color: "rgba(122,122,122,0.1)",
                        zeroLineColor: "rgba(74,69,69,0.01)",
                    },
                    ticks: {
                        beginAtZero: true,
                        stepSize: 10000

                    }
                }]
        }
    }
});

// for chart
var ctx = document.getElementById("hiringChart");
// Chart.defaults.global.animation.duration = 3000;
// ctx.height= 500;
Chart.defaults.global.defaultFontSize = 12;
var myChart1 = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        datasets: [{
                label: 'Total Earnings',
                data: [10000, 15000, 18000, 22000, 20000, 22000, 26000, 30000, 38000, 36000, 45000, 48000],
                backgroundColor: [
                    'transparent',
                ],
                pointBackgroundColor: 'rgba(255, 255, 255, 1)',
                pointHoverBorderColor: 'rgba(26,205,104,1)',
                borderColor: [
                    'rgba(26,205,104,1)',
                ],
                borderWidth: 2
            }]
    },
    options: {
        scaleShowVerticalLines: false,
        legend: {
            display: false
        },
        responsive: true,
        scales: {
            xAxes: [{
                    gridLines: {
                        display: false
                    }
                }],
            yAxes: [{
                    gridLines: {
                        color: "rgba(122,122,122,0.1)",
                        zeroLineColor: "rgba(74,69,69,0.01)",
                    },
                    ticks: {
                        beginAtZero: true,
                        stepSize: 10000

                    }
                }]
        }
    }
});

$(function () {
    $('.date').datetimepicker({
        format: 'L',
    });
});

// function checkCandidate() {
//     $("#showCandidate").show();
//     $("#showFreelancer").hide();
//     $("#showEmployer").hide();
//     $("#showInterviews").hide();
// }
// function checkFreelancer() {
//     $("#showCandidate").hide();
//     $("#showFreelancer").show();
//     $("#showEmployer").hide();
//     $("#showInterviews").hide();
// }
// function checkEmployer() {
//     $("#showCandidate").hide();
//     $("#showFreelancer").hide();
//     $("#showEmployer").show();
//     $("#showInterviews").hide();
// }
// function checkInterviews() {
//     $("#showCandidate").hide();
//     $("#showFreelancer").hide();
//     $("#showEmployer").hide();
//     $("#showInterviews").show();
// }
</script>
@endsection