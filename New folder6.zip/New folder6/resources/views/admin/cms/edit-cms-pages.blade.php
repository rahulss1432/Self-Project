@extends('layouts.admin.admin-app')
@section('title','Edit CMS Page')
@section('content')
<main class="main-wrapper dashboard-main-wrap payment-history-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="manage-cms.php">Manage - CMS</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit-CMS</li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">Edit CMS</h3>
                </div>
                <div class="card-body view_page">
                    <form method="post" id="cms-form" action="{{url('/admin/update-cms')}}">
                        {{ csrf_field() }}
                        <input class="with-border" type="hidden" name="id" value="{{$pageData->id}}">
                        <div class="form-group">
                            <label class="control-label">Page Title</label>
                            <input class="form-control" type="text" name="title" placeholder="Page Title" value="{{$pageData->title}}">
                        </div>
                        <div class="form-group">
                            <label class="control-label">Meta Keyword</label>
                            <input type="text" class="form-control" placeholder="Meta Keyword" name="meta_keywords" value="{{$pageData->meta_keywords}}">
                        </div>
                        <div class="form-group">
                            <label class="control-label">Meta Description</label>
                            <input type="text" class="form-control" placeholder="Meta Description" name="meta_description" value="{{$pageData->meta_description}}">
                        </div>
                        <div class="form-group" id="divCms">
                            <label class="control-label">Description</label>
                            <textarea id="cms-contant" rows="6" class="form-control" placeholder="Description" name="content">{{$pageData->content}}</textarea>
                            <span id="cms-contant-error" class="help-block error-help-block"></span>
                        </div>

                        <button id="submit-btn" class="text-uppercase btn ripple-effect-dark btn-success" type="submit">Update Cms</button>

                    </form>
                    {!! JsValidator::formRequest('App\Http\Requests\CmsRequest','#cms-form') !!}
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    var title = 'CMS Page';
    $("#submit-btn").on('click', (function (e) {
        var btn = $('#submit-btn');
        var form = $('#cms-form');

        var i = 0;
        $('#cms-contant').val($('#divCms').find('.nicEdit-main').html());
        form.valid();
        if ($('#cms-contant').val().replace(/(<([^>]+)>)/ig, "") == '') {
            $('#cms-contant-error').show();
            $('#cms-contant-error').html('Description field is required.');
            i++;
        } else {
            $('#cms-contant-error').hide();
            $('#cms-contant-error').html('');
        }
        if (i > 0) {
            return false;
        }

        if (form.valid()) {
            e.preventDefault();
            btn.html('{{\App\Helpers\Utility::buttonLoader()}} Update Cms');
            btn.prop('disabled', true);
            $.ajax({
                url: "{{url('/admin/update-cms')}}",
                type: "POST",
                data: form.serialize(),
                success: function (data){
                    if (data.status) {
                        successToaster(data.message, title);
                    } else {
                        errorToaster(data.message, title);
                    }
                    location.reload();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Update Cms');
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));

    bkLib.onDomLoaded(function () {
        new nicEditor({fullPanel: true, maxHeight: 300}).panelInstance('cms-contant');
    });
</script>
@endsection