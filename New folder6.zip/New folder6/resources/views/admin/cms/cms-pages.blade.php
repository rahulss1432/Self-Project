@extends('layouts.admin.admin-app')
@section('title','Manage CMS')
@section('content')
<main class="main-wrapper dashboard-main-wrap payment-history-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item">
                        <a href="{{url('/admin/dashboard')}}">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Manage - CMS</li>
                </ol>
            </nav>
            <div class="content-body">
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md">Manage CMS</h3>
                </div>
                <div class="table-responsive hide_filter_page">
                    @if($pages->count()>0)
                    <table class="table common-table admin-table w-100">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Title</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php $i = 1; @endphp 
                            @foreach($pages as $data)
                            <tr>
                                <td>{{$i++}}</td>
                                <td>{{ucfirst($data->title)}}</td>
                                <td>
                                     <ul class="list-inline mb-0">
                                       <li class="list-inline-item"> <a href="{{url('admin/edit-cms-page/'.$data->slug)}}" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a></li>
                                   </ul>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @else
                    @php \App\Helpers\Utility::emptyListMessage('CMS Page'); @endphp
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
</main>
@endsection