<?php

namespace App\Http\Middleware;

use Closure;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;

class VerifyJWTToken {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        $token = $request->header('access-token');
        try {
            $user = JWTAuth::toUser($token);
        } catch (JWTException $e) {
            if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenExpiredException) {
                return response()->json(['success' => false, 'error' => ['message' => 'Token expired'], 'code' => $e->getStatusCode()], $e->getStatusCode());
            } else if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenInvalidException) {
                return response()->json(['success' => false, 'error' => ['message' => 'Invalid Token'], 'code' => $e->getStatusCode()]);
            } else {
                return response()->json(['success' => false, 'error' => ['message' => 'token is required'], 'code' => 401]);
            }
        }
        return $next($request);
    }

}
