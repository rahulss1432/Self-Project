<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class AdminAuthCheck {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = 'admin') {
        if (Auth::guard($guard)->check()) {
            if (Auth::guard($guard)->user()->user_type == 'sub_admin') {
                $route = $request->route()->getName();
                if ($route != 'admin.dashboard' && $route != 'admin.user' && $route != 'admin.password' && $route != 'admin.notification') {
                    abort(404);
                }
            }
            return $next($request);
        }
        return redirect('/admin');
    }

}
