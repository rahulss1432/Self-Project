<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\CmsPage;
use App\Http\Requests\CmsRequest;

class CmsController extends Controller {

    public function getCmsPage() {
        $pages = CmsPage::getAllCmsPages();
        return view('admin.cms.cms-pages', ['pages' => $pages]);
    }

    public function editCmsPage($slug) {
        $result = CmsPage::getPageBySlug($slug);
        if (!empty($result)) {
            return view('admin.cms.edit-cms-pages', ['pageData' => $result]);
        }
        abort(404);
    }

    public function updateCmsPage(CmsRequest $request) {
        $result = CmsPage::updateCmsPage($request->all());
        if ($result) {
            return response()->json(['status' => 'true', 'message' => 'Cms updated successfully.']);
        } 
        return response()->json(['status' => 'false', 'message' => 'please try again later.']);
    }
}
