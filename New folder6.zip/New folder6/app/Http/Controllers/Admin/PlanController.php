<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Plan;

class PlanController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $userType = \App\Models\UserType::getListedType();
        return view('admin.plans.index', ['userType' => $userType]);
    }

    public function getPlanList(Request $request) {
        $post = $request->all();
        $planList = Plan::getPlanList_Admin($post);
        return view('admin.plans._load_plan_list', ['planList' => $planList]);
    }

    public function updatePlanStatus(Request $request) {
        $post = $request->all();
        $model = Plan::updatePlanStatus($post);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Plan status ' . $model . ' successfully.']);
        }
        return false;
    }

    public function deletePlan() {
        $id = request()->get('id');
        $model = Plan::deletePlan($id);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Plan deleted successfully.']);
        }
        return false;
    }

    public function getPlanForm() {
        $id = request()->get('id');
        $model = new Plan();
        if (!empty($id)) {
            $model = Plan::getPlanById($id);
        }
        $userType = \App\Models\UserType::getListedType();
        return view('admin.plans._load_plan_form', ['model' => $model, 'userType' => $userType]);
    }
    
    public function addPlan() {
        $model = new Plan();
        $userType = \App\Models\UserType::getListedType();
        return view('admin.plans.add-new-plan', ['model' => $model, 'userType' => $userType]);
    }
    
    public function editPlan($id) {
        $model = Plan::getPlanById($id);
        $userType = \App\Models\UserType::getListedType();
        return view('admin.plans.add-new-plan', ['model' => $model, 'userType' => $userType]);
    }

    public function submitPlan(\App\Http\Requests\PlanRequest $request) {
        $data = $request->all();
        $countryData = \App\Models\Plan::addPlan($data);
        if (!empty($countryData)) {
            if (!empty($data['id'])) {
                return response()->json(['status' => true, 'message' => 'Industry updated successfully.']);
            }
            return response()->json(['status' => true, 'message' => 'Industry added successfully.']);
        } else {
            return response()->json(['status' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

}
