<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Image;
use File;
use App\Models\Settings;
use App\Http\Requests\SettingRequest;
use App\Models\SideMenu;
use App\Http\Requests\SideMenuRequest;
use Illuminate\Support\Facades\Redirect;
use App\Http\Requests\BannerSettingRequest;

class BannerSettingController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    public function index($type) {
        $settingList = Settings::get();
        return view('admin.banner-settings.index', ['type' => $type]);
    }

    public function loadBannerSettingForm(Request $request) {
        $data = $request->all();
        $type = $data['type'];
        $settingList = Settings::where('setting_for', 'like', $type)->get();
        return view('admin.banner-settings._load_banner_setting_form', ['settingList' => $settingList, 'type' => $type]);
    }

    public function bannerSettingSubmit(BannerSettingRequest $request) {
        $post = $request->all();
        $data = Settings::where('setting_for', $post['type'])->get();
        foreach ($data as $key) {
            $newkey = $key['setting_key'];
            if ($key['setting_type'] == 'image') {
                if (!empty($post[$newkey])) {
                    $destinationPath = public_path() . '/uploads/banner-settings/';
                    if (!is_dir($destinationPath)) {
                        File::makeDirectory($destinationPath, $mode = 0777, true, true);
                    }
                    $photo = $request->file($newkey);
                    $imageName = time() . '.' . $request->$newkey->getClientOriginalExtension();
                    $thumb_img = Image::make($photo->getRealPath())->resize(500, 500);
                    $thumb_img->save($destinationPath . $imageName, 100);
                    \App\Helpers\Utility::unlinkMedia($post['oldBanner'], 'banner-settings');
                    $post[$newkey] = $imageName;
                } else {
                    $post[$newkey] = $post['oldBanner'];
                }
            }
        }
        $model = Settings::saveBannerSettings($post);
        if ($model) {
            session()->flash('success', 'Banner Setting');
            session()->flash('message', "Setting updated successfully.");
//            return view('admin.banner-settings.index', ['type'=>$post['type']]);
            return Redirect::back();
        }
    }

}
