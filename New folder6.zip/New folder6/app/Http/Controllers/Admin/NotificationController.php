<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Notification;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class NotificationController extends Controller {
    public function index() {
         return view('admin.notifications.index');
    }

    public function loadNotifications() {
        $post = array();
        $post['userId'] = Auth::guard('admin')->user()->id;
        $post['is_paginate'] = 'yes';
        $notification = Notification::getNotifications($post);
        Notification::readNotification($post);
        $html = View::make('admin.notifications._notification-list', ['notifications' => $notification])->render();
        return Response::json(['html' => $html]);
    }

}
