<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Job;

class JobsController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin.jobs.index');
    }

    public function getJobList(Request $request) {
        $post = $request->all();
        $jobList = Job::getJobList_Admin($post);
        return view('admin.jobs._load_job_list', ['jobList' => $jobList]);
    }

    public function updatePlanStatus(Request $request) {
        $post = $request->all();
        $model = Plan::updatePlanStatus($post);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Plan status ' . $model . ' successfully.']);
        }
        return false;
    }

}
