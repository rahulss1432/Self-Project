<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function candidates() {
        return view('admin.user.index', ['user_type' => 'candidate']);
    }

    public function employer() {
        return view('admin.user.index', ['user_type' => 'employer']);
    }

    public function freelancer() {
        return view('admin.user.index', ['user_type' => 'freelancer']);
    }

    public function subAdmin() {
        $model = User::where('user_type', 'sub_admin')->first();
        if (empty($model)) {
            $model = new User();
        }
        return view('admin.user.sub-admin', ['model' => $model]);
    }

    public function getUserList(Request $request) {
        $post = $request->all();
        $userList = User::getUserList_Admin($post);
        return view('admin.user._load_user_list', ['userList' => $userList, 'user_type' => $post['user_type']]);
    }

    public function updateUserStatus(Request $request) {
        $post = $request->all();
        $model = User::updateUserStatus($post);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => ucfirst($model->first_name . ' ' . $model->last_name) . ' status has been ' . $model->status . ' successfully.']);
        }
        return false;
    }

    public function getEditUserForm(Request $request) {
        $id = $request->id;
        $model = User::getUserById($id);
        return view('admin.user._load_user_form', ['model' => $model]);
    }

    public function updateUserInfo(\App\Http\Requests\UpdateUserInfoRequest $request) {
        $post = $request->all();
        $model = User::updateUserInfo($post);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'User info updated successfully.']);
        }
        return false;
    }

    public function userList() {
        $userType = \App\Models\UserType::getListedType();
        return view('admin.user.user-list', ['userType' => $userType]);
    }

    public function getContactUserList(Request $request) {
        $post = $request->all();
        $userList = User::getContactUserList($post);
        return view('admin.user._load_contact_user_list', ['userList' => $userList]);
    }

    public function sendContactEmail(Request $request) {
        $post = $request->all();
        $result = User::sendContactEmail($post);
        if ($result) {
            return response()->json(['status' => 'true', 'message' => 'Email sent successfully.']);
        }
        return response()->json(['status' => 'false', 'message' => 'please try again later.']);
    }

    public function getUserDetail($id) {
        $userDetail = User::getUserById($id);
        if ($userDetail) {
            return view('admin.user.user-detail', ['userDetail' => $userDetail]);
        } else {
            
        }
    }

}
