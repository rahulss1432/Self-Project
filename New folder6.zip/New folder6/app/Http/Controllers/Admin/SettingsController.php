<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Image;
use File;
use App\Models\Settings;
use App\Http\Requests\SettingRequest;
use App\Models\SideMenu;
use App\Http\Requests\SideMenuRequest;

class SettingsController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    public function index() {
        $settingList = Settings::get();
        return view('admin.settings.index', ['settingList' => $settingList]);
    }

    public function loadSettingForm(Request $request) {
        $data = $request->all();
        $model = new Settings();
        if ($data['id'] != 0) {
            $model = Settings::getSettingById($data['id']);
        }
        return view('admin.settings._load_setting_form', ['model' => $model]);
    }

    public function settingSubmit(SettingRequest $request) {
        $data = $request->all();
        if (!empty($request->setting_image)) {
            $destinationPath = public_path() . '/uploads/settings/';
            if (!is_dir($destinationPath)) {
                File::makeDirectory($destinationPath, $mode = 0777, true, true);
            }
            $photo = $request->file('setting_image');
            $imageName = time() . '.' . $request->setting_image->getClientOriginalExtension();
            $thumb_img = Image::make($photo->getRealPath())->resize($request->thumbnail_height, $request->thumbnail_width);
            $thumb_img->save($destinationPath . $imageName, 100);
            $data['setting_value'] = $imageName;
        }
        $model = Settings::addNewSetting($data);
        if ($model) {
            $request->session()->flash('success', 'Setting');
            if (empty($data['id'])) {
                $request->session()->flash('message', "Setting added successfully.");
            } else {
                $request->session()->flash('message', "Setting updated successfully.");
            }
            return response()->json(['status' => true]);
        }
        return response()->json(['status' => false]);
    }

    //for side menu update
    public function getSideMenuList() {
        $employerMenuList = SideMenu::where('user_type', 'employer')->get();
        $candidateMenuList = SideMenu::where('user_type', 'candidate')->get();
        $freelancerMenuList = SideMenu::where('user_type', 'freelancer')->get();
        return view('admin.sidemenu.index', ['employerMenuList' => $employerMenuList, 'candidateMenuList' => $candidateMenuList, 'freelancerMenuList' => $freelancerMenuList]);
    }

    //for side menu save
    public function saveSideMenu(SideMenuRequest $request) {
        $post = $request->all();
        $result = SideMenu::saveSideMenu($post);
        if ($result) {
            $request->session()->flash('success', 'Setting');
            $request->session()->flash('message', "Side Menu updated successfully.");
            return response()->json(['status' => true]);
        }
        return response()->json(['status' => false]);
    }

}
