<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Skill;

class SkillController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $industries = \App\Models\Industry::getIndustryList([]);
        return view('admin.skill.index', ['industries' => $industries]);
    }

    public function getSkillList(Request $request) {
        $post = $request->all();
        $skillList = Skill::getSkillsList_Admin($post);
        return view('admin.skill._load_skill_list', ['skillsList' => $skillList]);
    }

    public function updateSkillStatus(Request $request) {
        $post = $request->all();
        $model = Skill::updateSkillStatus($post);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Skill status ' . $model . ' successfully.']);
        }
        return false;
    }

    public function deleteSkill() {
        $id = request()->get('id');
        $model = Skill::deleteSkill($id);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Skill deleted successfully.']);
        }
        return false;
    }

    public function getSkillForm() {
        $id = request()->get('id');
        $model = new Skill();
        if (!empty($id)) {
            $model = Skill::getSkillById($id);
        }
        $industryList = \App\Models\Industry::orderBy('industry_name', 'ASC')->get();
        return view('admin.skill._load_skill_form', ['model' => $model, 'industryList' => $industryList]);
    }

    public function submitSkill(\App\Http\Requests\SkillRequest $request) {
        $data = $request->all();
        $countryData = \App\Models\Skill::addSkill($data);
        if (!empty($countryData)) {
            if (!empty($data['id'])) {
                return response()->json(['status' => true, 'message' => 'Skill updated successfully.']);
            }
            return response()->json(['status' => true, 'message' => 'Skill added successfully.']);
        } else {
            return response()->json(['status' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

    public function importCsv(Request $request) {
        if ($request->hasFile('skill_csv')) {
            $filePath = base_path() . '/public/csv';
            $csvFile = $request->file('skill_csv');
            $fileName = $csvFile->getClientOriginalExtension();
            $csvFile->move($filePath, $fileName);
            $csvPath = $filePath . '/' . $fileName;
            $i = 0;
            $ic = 0;
            if (($handle = fopen($csvPath, "r")) !== FALSE) {
                while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                    if ($i > 0) {
                        $industryName = ucwords(strtolower(trim($data[0])));
                        $skillName = ucwords(trim($data[1]));
                        $model = \App\Models\Industry::where('industry_name', $industryName)->first();
                        if (empty($model)) {
                            $model = new \App\Models\Industry();
                            $model->industry_name = $industryName;
                            $model->status = 'enabled';
                            $model->save();
                        }
                        $industryId = $model->id;
                        $skillModal = Skill::where('skill_name', '=', $skillName)->where('industry_id', '=', $industryId)->first();
                        if (empty($skillModal)) {
                            $ic++;
                            $skillModal = new Skill();
                            $skillModal->skill_name = $skillName;
                            $skillModal->industry_id = $industryId;
                            $skillModal->status = 'enabled';
                            $skillModal->save();
                        }
                        if ($ic > 0) {
                            $request->session()->flash('success', 'Skills');
                            $request->session()->flash('message', $ic . ' skills imported successfully.');
                        } else {
                            $request->session()->flash('error', 'Skills');
                            $request->session()->flash('message', 'No new skills found.');
                        }
                    }
                    $i++;
                }

                fclose($handle);
            }
        }
        return redirect()->back();
    }

}
