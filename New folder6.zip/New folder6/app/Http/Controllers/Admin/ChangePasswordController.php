<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Requests\ChangePasswordRequest;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;

class ChangePasswordController extends Controller {

    public function changePasswordForm(Request $request) {
        $post = $request->all();
        return View::make('admin.change-password._load_password_form', ['guard' => $post['guard']])->render();
    }

    public function passwordChange(ChangePasswordRequest $request) {
        $post = $request->all();
        $result = User::changePassword($post);
        if ($result) {
            $request->session()->flash('success', 'Change Password');
            $request->session()->flash('message', "Password changed successfully.");
            return Response::json(['success' => true]);
        }
        return Response::json(['success' => true]);
    }

}
