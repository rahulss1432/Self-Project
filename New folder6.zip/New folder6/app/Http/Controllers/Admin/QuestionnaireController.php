<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\QuestionCategory;
use App\Models\Question;
use App\Http\Requests\QuestionnaireRequest;
use App\Http\Requests\QuestionRequest;

class QuestionnaireController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function index() {
        return view('admin.questionnaire.question');
    }

    public function getQuestionnaireList(Request $request) {
        $post = $request->all();
        $questionList = Question::getQuestionList($post);
        return view('admin.questionnaire._load_question_list', ['questionList' => $questionList]);
    }
    
    public function categoryList() {
        return view('admin.questionnaire.categories');
    }
    
    public function getCategoryList(Request $request) {
        $post = $request->all();
        $categoryList = QuestionCategory::getCategoryList($post);
        return view('admin.questionnaire._load_category_list', ['categoryList' => $categoryList]);
    }
        
    public function getCategoryForm() {
        $id = request()->get('id');
        $model = new QuestionCategory();
        if (!empty($id)) {
            $model = QuestionCategory::getQuetionCategoryById($id);
        }
        return view('admin.questionnaire._load_category_form', ['model' => $model]);
    }
    
    public function submitCategory(QuestionnaireRequest $request) {
        $data = $request->all();
        $questionnaireData = \App\Models\QuestionCategory::addQuestionCategory($data);
        if (!empty($questionnaireData)) {
            if (!empty($data['id'])) {
                return response()->json(['status' => true, 'message' => 'Question category updated successfully.']);
            }
            return response()->json(['status' => true, 'message' => 'Question category added successfully.']);
        } else {
            return response()->json(['status' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }
    
    public function deleteCategory() {
        $id = request()->get('id');
        $model = QuestionCategory::deleteCategory($id);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'questionnaire deleted successfully.']);
        }
        return false;
    }
    
    public function getQuestionForm() {
        $id = request()->get('id');
        $model = new Question();
        if (!empty($id)) {
            $model = Question::getQuestionById($id);
        }
        $questionnaire = QuestionCategory::get();
        return view('admin.questionnaire._load_question_form', ['model' => $model, 'questionnaire' => $questionnaire]);
    }
    
    public function submitQuestion(QuestionRequest $request) {
        $data = $request->all();
        $questionData = \App\Models\Question::addQuestion($data);
        if (!empty($questionData)) {
            if (!empty($data['id'])) {
                return response()->json(['status' => true, 'message' => 'Question updated successfully.']);
            }
            return response()->json(['status' => true, 'message' => 'Question added successfully.']);
        } else {
            return response()->json(['status' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }
    
    public function deleteQuestion() {
        $id = request()->get('id');
        $model = Question::deleteQuestion($id);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Question deleted successfully.']);
        }
        return false;
    }
}
