<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Testimonial;
use App\Http\Requests\TesimonialRequest;
use Illuminate\Support\Facades\File;
use Image;

class TestimonialController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin.testimonials.index');
    }

    public function getTestimonialList() {
        $testimonialList = Testimonial::getTestimonialList_Admin();
        return view('admin.testimonials._load_testimonial_list', ['testimonialList' => $testimonialList]);
    }

    public function getTestimonialForm() {
        $id = request()->get('id');
        $model = new Testimonial();
        if (!empty($id)) {
            $model = Testimonial::getTestimonialById($id);
        }
        return view('admin.testimonials._load_testimonial_form', ['model' => $model]);
    }

    public function submitTestimonial(TesimonialRequest $request) {
        $data = $request->all();
        if (!empty($request->testimonial_image)) {
            $destinationPath = public_path() . '/uploads/testimonial/';
            if (!is_dir($destinationPath)) {
                File::makeDirectory($destinationPath, $mode = 0777, true, true);
            }
            $photo = $request->file('testimonial_image');
            $imageName = time() . '-' . $request->testimonial_image->getClientOriginalName();
            $thumb_img = Image::make($photo->getRealPath())->resize(200, 200);
            $thumb_img->save($destinationPath . $imageName, 100);
            $data['testimonial_image'] = $imageName;
        }
        $testimonialData = Testimonial::addTestimonial($data);
        if (!empty($testimonialData)) {
            if (!empty($data['id'])) {
                return response()->json(['status' => true, 'message' => 'Testimonial updated successfully.']);
            }
            return response()->json(['status' => true, 'message' => 'Testimonial added successfully.']);
        } else {
            return response()->json(['status' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

    public function deleteTestimonial() {
        $id = request()->get('id');
        $model = Testimonial::deleteTestimonial($id);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Testimonial deleted successfully.']);
        }
        return false;
    }

}
