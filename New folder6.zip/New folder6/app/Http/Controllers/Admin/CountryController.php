<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Country;

class CountryController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin.country.index');
    }

    public function getCountryList(Request $request) {
        $data=$request->all();
        $countryList = Country::getCountryList_Admin($data);
        return view('admin.country._load_country_list', ['countryList' => $countryList]);
    }

    public function updateCountrtyStatus(Request $request) {
        $post = $request->all();
        $model = Country::updateCountrtyStatus($post);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Country status ' . $model . ' successfully.']);
        }
        return false;
    }

}
