<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Language;

class LanguageController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin.language.index');
    }

    public function getLanguageList(Request $request) {
        $post = $request->all();
        $languageList = Language::getLanguageList_Admin($post);
        return view('admin.language._load_language_list', ['languageList' => $languageList]);
    }

    public function updateLanguageStatus(Request $request) {
        $post = $request->all();
        $model = Language::updateLanguageStatus($post);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Language status ' . $model . ' successfully.']);
        }
        return false;
    }

    public function deleteLanguage() {
        $id = request()->get('id');
        $model = Language::deleteLanguage($id);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Language deleted successfully.']);
        }
        return false;
    }

    public function getLanguageForm() {
        $id = request()->get('id');
        $model = new Language();
        if (!empty($id)) {
            $model = Language::getLanguageById($id);
        }
        return view('admin.language._load_language_form', ['model' => $model]);
    }

    public function submitLanguage(\App\Http\Requests\LanguageRequest $request) {
        $data = $request->all();
        $result = Language::addLanguage($data);
        if ($result) {
            if (!empty($data['id'])) {
                return response()->json(['status' => true, 'message' => 'Language updated successfully.']);
            }
            return response()->json(['status' => true, 'message' => 'Language added successfully.']);
        } else {
            return response()->json(['status' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

}
