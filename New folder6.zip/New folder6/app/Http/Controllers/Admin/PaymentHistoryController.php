<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Plan;

class PaymentHistoryController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $userType = \App\Models\UserType::getListedType();
        return view('admin.payment-history.index', ['userType' => $userType]);
    }

    public function getPaymentList(Request $request) {
        $post = $request->all();
        $post['is_paginate'] = 'yes';
        $paymentList = \App\Models\PlanSubscription::getPaymentHistory($post);
        return view('admin.payment-history._load_payment_list', ['paymentList' => $paymentList]);
    }

}
