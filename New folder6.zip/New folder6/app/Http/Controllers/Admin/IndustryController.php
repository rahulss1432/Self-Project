<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Industry;

class IndustryController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin.industry.index');
    }

    public function getIndustryList(Request $request) {
        $post = $request->all();
        $industryList = Industry::getIndustryList_Admin($post);
        return view('admin.industry._load_industry_list', ['industryList' => $industryList]);
    }

    public function updateIndustryStatus(Request $request) {
        $post = $request->all();
        $model = Industry::updateIndustryStatus($post);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Industry status ' . $model . ' successfully.']);
        }
        return false;
    }

    public function deleteIndustry() {
        $id = request()->get('id');
        $model = Industry::deleteIndustry($id);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Industry deleted successfully.']);
        }
        return false;
    }

    public function getIndustryForm() {
        $id = request()->get('id');
        $model = new Industry();
        if (!empty($id)) {
            $model = Industry::getIndustryById($id);
        }
        return view('admin.industry._load_industry_form', ['model' => $model]);
    }

    public function submitIndustry(\App\Http\Requests\IndustryRequest $request) {
        $data = $request->all();
        $countryData = \App\Models\Industry::addIndustry($data);
        if (!empty($countryData)) {
            if (!empty($data['id'])) {
                return response()->json(['status' => true, 'message' => 'Industry updated successfully.']);
            }
            return response()->json(['status' => true, 'message' => 'Industry added successfully.']);
        } else {
            return response()->json(['status' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

}
