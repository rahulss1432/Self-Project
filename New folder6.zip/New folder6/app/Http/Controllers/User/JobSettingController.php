<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\PlanSubscription;
use App\Models\Job;
use App\Http\Requests\PostJobRequest;
use App\Models\Question;

class JobSettingController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function checkAddJob() {
        $subscription = \App\Models\PlanSubscription::checkUserPlans();
        if (!empty($subscription)) {
            $jobCount = Job::where('user_id', Auth::user()->id)->where('active_plan', Auth::user()->active_plan)->count();
            if ($subscription->jobs_limit > $jobCount) {
                return true;
            } else {
                session()->flash('error', 'Subscription Alert');
                session()->flash('message', "Your plan subscription job post limit is over.");
            }
        } else {
            session()->flash('error', 'Subscription Alert');
            session()->flash('message', "Your plan subscription is expired.");
        }
        return false;
    }

    public function postAJob($id = '') {
        $model = new Job();
        if (!empty($id)) {
            $model = Job::getJobById($id);
        } else {
            if (!$this->checkAddJob()) {
                return redirect('/user/my-plan');
            }
        }
        $industries = \App\Models\Industry::getIndustryList(['status' => 'enabled']);
        return view('user.employer.jobs.post-a-job', ['industries' => $industries, 'model' => $model]);
    }

    public function postedJobs() {
        return view('user.employer.jobs.posted-jobs');
    }

    public static function getPostedJobs(Request $request) {
        $post = array();
        $post['userId'] = Auth::user()->id;
        $post['is_paginate'] = 'yes';
        $jobList = Job::getJobList($post);
        return view('user.employer.jobs._load_posted_jobs', ['jobList' => $jobList]);
    }

    public function viewMatchedCandidates($id) {
        $jobData = Job::getJobById($id);
        $userType = \App\Models\UserType::getListedType();
        if (!empty($jobData)) {
            return view('user.employer.jobs.matched-candidates', ['jobData' => $jobData, 'userType' => $userType]);
        }
        abort(404);
    }

    public function loadMatchedCandidates(Request $request) {
        $post = $request->all();
        $matchCandidates = \App\Models\UserSkill::getMatchedCandidatesList($post);
        return view('user.employer.jobs._load_matched_candidates', ['matchCandidates' => $matchCandidates]);
    }

    public function addAJob(PostJobRequest $request) {
        $post = $request->all();
        $result = Job::addAJob($post);
        if ($result) {
            session()->flash('success', 'Job');
            session()->flash('message', "Job added successfully.");
        }
        return response()->json(array('success' => true));
    }

    public function getSkillsByIndustry(Request $request) {
        $post = $request->all();
        $skillsArray = array();
        if (!empty($post['jobId'])) {
            $jobSkills = \App\Models\JobSkill::getJobSkills($post['jobId']);
            if (!empty($jobSkills)) {
                foreach ($jobSkills as $skill) {
                    $skillsArray[] = $skill->skill_id;
                }
            }
        }
        $industryId = $post['industryId'];
        $skillsList = \App\Models\Skill::getSkillsByIndustry($industryId);
        $html = '';
        $html .= '<option value="" disabled>Select Skills</option>';
        if (!empty($skillsList)) {
            foreach ($skillsList as $skill) {
                $data = (in_array($skill['id'], $skillsArray)) ? 'selected=selected' : '';
                $html .= '<option value="' . $skill['id'] . '" ' . $data . '>' . $skill['skill_name'] . '</option>';
            }
        }
        return $html;
    }

}
