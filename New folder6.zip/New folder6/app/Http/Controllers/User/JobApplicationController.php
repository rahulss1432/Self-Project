<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Auth;
use App\Models\PlanSubscription;
use App\Models\Job;
use App\Models\JobApplication;

class JobApplicationController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('user.applications.my-application');
    }

    public function getInvitations() {
        return view('user.applications.invitation-received');
    }

//    public static function getPostedJobs() {
//        $post = array();
//        $post['userId'] = Auth::user()->id;
//        $post['is_paginate'] = 'yes';
//        $jobList = Job::getJobList($post);
//        return view('user.employer.jobs._load_posted_jobs', ['jobList' => $jobList]);
//    }

    public function getMyAppliedList(Request $request) {
        $post = $request->all();
        $post['userId'] = Auth::user()->id;
        $post['action_by'] = 'application';
        $myApplicationData = JobApplication::getMyApplicationList($post);
        return view('user.applications._load_my_application', ['myApplicationData' => $myApplicationData]);
    }

    public function getUserInvitationList() {
        $post = [];
        $post['userId'] = Auth::user()->id;
        $post['action_by'] = 'invitation';
        $invitationData = JobApplication::getMyApplicationList($post);
        return view('user.applications._load_invitation_received', ['myApplicationData' => $invitationData]);
    }

    public function declineUserInvitation(Request $request) {
        $post = $request->all();
        $post['userId'] = Auth::user()->id;
        $post['status'] = 'decline';
        $result = JobApplication::changeInvitationStatus($post);
        if($result){
            return Response::json(array('success' => 'true', 'message' => 'You have successfully decline this job.'));
        }else{
             return Response::json(array('success' => 'false', 'message' => 'Please try again.'));
        }
    }

}
