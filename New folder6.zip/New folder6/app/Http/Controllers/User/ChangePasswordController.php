<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Requests\ChangePasswordRequest;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;

class ChangePasswordController extends Controller {

    public function changePasswordForm() {
        return view('user.change-password.index');
    }

    public function passwordChange(ChangePasswordRequest $request) {
        $post = $request->all();
        $result = User::changePassword($post);
        if ($result) {
            $request->session()->flash('success', 'Change Password');
            $request->session()->flash('message', "Password changed successfully.");
            return Response::json(['success' => true]);
        }
        return Response::json(['success' => true]);
    }

}
