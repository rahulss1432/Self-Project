<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\PlanSubscription;

class PaymentHistoryController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('user.payment-history.index');
    }

    public function getPaymentHistory(Request $request) {
        $post = $request->all();
        $post['userId'] = Auth::user()->id;
        $post['is_paginate'] = 'yes';
        $paymentList = PlanSubscription::getPaymentHistory($post);
        return view('user.payment-history._load_payment_history', ['paymentList' => $paymentList]);
    }

    public function myPlan() {
        return view('user.payment-history.my-plan');
    }

    public function getPlanList(Request $request) {
        $post = $request->all();
        $planList = \App\Models\Plan::getPlanList($post);
        return view('user.payment-history._plan_box', ['planList' => $planList]);
    }

}
