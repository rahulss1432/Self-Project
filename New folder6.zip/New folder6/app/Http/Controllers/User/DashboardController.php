<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\JobApplication;
use App\Models\Notification;
use App\Models\PlanSubscription;

class DashboardController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $userId = Auth::user()->id;
        $jobsAppliedCount = JobApplication::getjobsAppliedOrInvitationCount('application',$userId);
        $invitationCount = JobApplication::getjobsAppliedOrInvitationCount('invitation',$userId);
        $videoViewsCount = Notification::getProfileOrVideoViewsCount('view_video',$userId);
        $profileViewsCount = Notification::getProfileOrVideoViewsCount('view_profile',$userId);
        $paymentHistoryData = PlanSubscription::getTopThreePaymentDistoryData($userId);
        return view('user.dashboard.' . Auth::user()->user_type,['jobsAppliedCount'=>$jobsAppliedCount,'invitationCount'=>$invitationCount,'videoViewsCount'=>$videoViewsCount,'profileViewsCount'=>$profileViewsCount,'paymentHistoryData'=>$paymentHistoryData]);
    }

}
