<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Notification;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class NotificationController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('user.notifications.index');
    }

    public function loadNotifications() {
        $post = array();
        $post['userId'] = Auth::user()->id;
        $post['is_paginate'] = 'yes';
        $notification = Notification::getNotifications($post);
        Notification::readNotification($post);
        $html = View::make('user.notifications._notification-list', ['notifications' => $notification])->render();
        return Response::json(['html' => $html]);
    }

    public function getVideoViews() {
        return view('user.user-view.video-views');
    }

    public function getProfileViews() {
        return view('user.user-view.profile-views');
    }

    public function getProfileVideoViewList(Request $request) {
        $post = $request->all();
        $post['userId'] = Auth::user()->id;
        $activity_type = $post['activity_type'];
        $page = $post['page'];
        $profileVideoViewData = Notification::getProfileVideoViewList($post);
        return view('user.user-view._load_profile_video_view_list', ['profileVideoViewData' => $profileVideoViewData, 'activity_type' => $activity_type, 'page' => $page]);
    }

}
