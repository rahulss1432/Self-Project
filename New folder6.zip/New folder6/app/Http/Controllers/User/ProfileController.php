<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\EditProfileRequest;
use Image;
use File;
use App\Http\Requests\EditCompanyProfileRequest;
use App\Http\Requests\AboutYourExperienceRequest;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\PortfolioRequest;
use Illuminate\Support\Facades\Response;
use App\Models\PlanSubscription;
use App\Models\PromoVideo;

class ProfileController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function editProfile() {
        $userId = Auth::user()->id;
        $userType = Auth::user()->user_type;
        $userDetails = \App\Models\User::getUserById($userId);
        if ($userType == 'employer') {
            $industries = \App\Models\Industry::getIndustryList(['status' => 'enabled']);
            return view('user.profile.employer-profile', ['userDetails' => $userDetails, 'industries' => $industries]);
        } else {
            return view('user.profile.user-profile', ['userDetails' => $userDetails]);
        }
    }

    public function updateProfile(EditProfileRequest $request) {
        $post = $request->all();
        $result = \App\Models\User::updateUserProfile($post);
        if ($result) {
            session()->flash('success', 'Personal Details');
            session()->flash('message', "Personal details updated successfully.");
        }
        return response()->json(array('success' => true));
    }

    public function updateCompany(EditCompanyProfileRequest $request) {
        $post = $request->all();
        if (!empty($request->banner_image)) {
            $destinationPath = public_path() . '/uploads/company/banner/';
            if (!is_dir($destinationPath)) {
                File::makeDirectory($destinationPath, $mode = 0777, true, true);
            }
            $photo = $request->file('banner_image');
            $imageName = time() . '-' . $request->banner_image->getClientOriginalName();
            $thumb_img = Image::make($photo->getRealPath())->resize(1285, 470);
            $thumb_img->save($destinationPath . $imageName, 100);
            $post['banner_image'] = $imageName;
        }
        if (!empty($request->video)) {
            $videoPath = public_path() . '/uploads/company/showcase/';
            if (!is_dir($videoPath)) {
                File::makeDirectory($videoPath, $mode = 0777, true, true);
            }
            $video = $request->file('video');
            $videoName = time() . '-' . $request->video->getClientOriginalName();
            $video->move($videoPath, $videoName);
            $post['video'] = $videoName;
        }
        $result = \App\Models\User::updateCompanyProfile($post);
        if ($result) {
            session()->flash('success', 'Copmany Details');
            session()->flash('message', "Copmany details updated successfully.");
        }
        return response()->json(array('success' => true));
    }

    public function saveProfileImage(Request $request) {
        $post = $request->all();
        $image = $post['imageBaseCode'];
        if (!empty($image)) {
            $image_parts = explode(";base64,", $image);
            $image_type_aux = explode("image/", $image_parts[0]);
            $image_type = $image_type_aux[1];
            $image_base64 = base64_decode($image_parts[1]);
            if($request->imageType == 'profile_image'){
            $destinationPath = public_path() . '/uploads/user/';
            }else{
                $destinationPath = public_path() . '/uploads/company/logo/'; 
            }
            $file = time() . '.jpg';
            if (!\File::exists($destinationPath)) {
                \File::makeDirectory($destinationPath, 0755, true);
            }
            file_put_contents($destinationPath . '/' . $file, $image_base64);
            $img = Image::make($destinationPath . $file);
            $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']))
                    ->resize(200, 200)
                    ->save($destinationPath . $file);
            $userInfo = \App\Models\User::getUserById(Auth::user()->id);
            if($request->imageType == 'profile_image'){
            \App\Helpers\Utility::unlinkMedia($userInfo->profile_image, 'user');
             $userInfo->profile_image = $file;
             $filepath = \App\Helpers\Utility::checkProfileImage($file);
            }else{
               \App\Helpers\Utility::unlinkMedia($userInfo->company_logo, 'company/logo');
                $userInfo->company_logo = $file;
                $filepath = \App\Helpers\Utility::checkCompanyLogo($file);
            }
            
            $userInfo->save();
            return response()->json(array('success' => true, 'filename' => $filepath,'imageType' => $request->imageType));
        }
        return response()->json(array('success' => false, 'message' => 'Please try again.'));
    }

    //Experience section start

    public function editExperience() {
        return view('user.profile.experience.index');
    }

    public function getExperience() {
        $userExperience = \App\Models\UserExperience::getUserExperience(Auth::user()->id);
        return view('user.profile.experience._load_list', ['userExperience' => $userExperience]);
    }

    public function getExperienceForm() {
        $id = request()->get('id');
        $model = new \App\Models\UserExperience();
        if (!empty($id)) {
            $model = \App\Models\UserExperience::getExperienceById($id);
        }
        return view('user.profile.experience._load_experience_frm', ['model' => $model]);
    }

    public function experienceSubmit(Request $request) {
        $data = $request->all();
        $experienceData = \App\Models\UserExperience::addUserExperience($data);
        if (!empty($experienceData)) {
            if (!empty($data['id'])) {
                return response()->json(['status' => true, 'message' => 'Experience updated successfully.']);
            }
            return response()->json(['status' => true, 'message' => 'Experience added successfully.']);
        } else {
            return response()->json(['status' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

    public function saveExperience(Request $request) {
        $data = $request->all();
        $experienceData = \App\Models\UserExperience::saveUserExperience($data);
        if ($experienceData) {
            session()->flash('success', 'Experience');
            session()->flash('message', 'Experience added successfully.');
            return redirect('/user/skills');
        }
        return redirect()->back();
    }

    public function saveAboutExperience(AboutYourExperienceRequest $request) {
        $data = $request->all();
        $userExpData = \App\Models\User::saveAboutExperience($data);
        if ($userExpData) {
            session()->flash('success', 'Experience');
            session()->flash('message', 'Experience added successfully.');
            return redirect()->back();
        }
        return redirect()->back();
    }

    //Experience section end
    public function editSkills() {
        $industries = \App\Models\Industry::getIndustryList(['status' => 'enabled']);
        $userSkills = \App\Models\UserSkill::getUserSkills(Auth::user()->id);
        return view('user.profile.user-skills', ['industries' => $industries, 'userSkills' => $userSkills]);
    }

    public function getSkillsByIndustry($industryId) {
        $userSkills = \App\Models\UserSkill::getUserSkills(Auth::user()->id);
        $skillsArray = array();
        if (!empty($userSkills)) {
            foreach ($userSkills as $skill) {
                $skillsArray[] = $skill->skill_id;
            }
        }

        $skillsList = \App\Models\Skill::getSkillsByIndustry($industryId);
        $html = '';
        $html .= '<option value="" disabled>Select Skills</option>';
        if (!empty($skillsList)) {
            foreach ($skillsList as $skill) {
                $data = (in_array($skill['id'], $skillsArray)) ? 'selected=selected' : '';
                $html .= '<option value="' . $skill['id'] . '" ' . $data . '>' . $skill['skill_name'] . '</option>';
            }
        }
        return $html;
    }

    public function saveUserSkills(Request $request) {
        $data = $request->all();
        $userExpData = \App\Models\UserSkill::saveUserSkills($data);
        if ($userExpData) {
            session()->flash('success', 'Skills');
            session()->flash('message', 'Skills added successfully.');
            return redirect('/user/education');
        }
        return redirect()->back();
    }

    //Education section start
    public function editEducation() {
        return view('user.profile.education.index');
    }

    public function getEducation() {
        $userEducation = \App\Models\UserEducation::getUserEducation();
        return view('user.profile.education._load_list', ['userEducation' => $userEducation]);
    }

    public function getEducationForm() {
        $id = request()->get('id');
        $userEducation = new \App\Models\UserEducation();
        if (!empty($id)) {
            $userEducation = \App\Models\UserEducation::getEducationById($id);
        }
        return view('user.profile.education._load_education_frm', ['userEducation' => $userEducation]);
    }

    public function educationSubmit(Request $request) {
        $data = $request->all();
        $educationData = \App\Models\UserEducation::addUserEducation($data);
        if (!empty($educationData)) {
            if (!empty($data['id'])) {
                return response()->json(['status' => true, 'message' => 'Education updated successfully.']);
            }
            return response()->json(['status' => true, 'message' => 'Education added successfully.']);
        } else {
            return response()->json(['status' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

    public function saveEducation(Request $request) {
        $data = $request->all();
        $experienceData = \App\Models\UserEducation::addUserEducation($data);
        if ($experienceData) {
            session()->flash('success', 'Education');
            session()->flash('message', 'Education added successfully.');
            return redirect('/user/promo-video');
        }
        return redirect()->back();
    }

    public function deleteEducation() {
        $id = request()->get('id');
        $model = \App\Models\UserEducation::deleteEducation($id);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Education deleted successfully.']);
        }
        return false;
    }

    //Education section end
    public function editPromoVideo() {
        $userpromovideo =  PromoVideo::where('user_id',\Illuminate\Support\Facades\Auth::user()->id)->first();
        return view('user.profile.promo-video.index', ['userpromovideo' => $userpromovideo]);
    }

    public function deletePromoVideo() {
        $id = request()->get('id');
        $model = \App\Models\PromoVideo::deletePromoVideo($id);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'PromoVideo deleted successfully.']);
        }
        return false;
    }
    public function deleteExperience() {
        $id = request()->get('id');
        $model = \App\Models\UserExperience::deleteExperience($id);
        if ($model) {
            return response()->json(['status' => 'true', 'message' => 'Education deleted successfully.']);
        }
        return false;
    }

    public function viewProfile() {
        $userId = Auth::user()->id;
        $userType = Auth::user()->user_type;
        $userDetails = \App\Models\User::getUserById($userId);
        if (!empty($userDetails)) {
            if ($userType == 'employer') {
                return view('user.profile.view-company-profile', ['userDetails' => $userDetails]);
            } else {
                return view('user.profile.view-user-profile', ['userDetails' => $userDetails]);
            }
        }
        abort(404);
    }

    public function editPortfolio() {
        if (Auth::user()->user_type == 'freelancer') {
            return view('user.profile.portfolio.index');
        }
        return redirect('/user/edit-profile');
    }

    public function getPortfolio() {
        $userPortfolio = \App\Models\UserProject::getUserProject(Auth::user()->id);
        return view('user.profile.portfolio._load_list', ['userPortfolio' => $userPortfolio]);
    }

    public function getPortfolioForm() {
        $id = request()->get('id');
        $model = new \App\Models\UserProject();
        if (!empty($id)) {
            $model = \App\Models\UserProject::getPortfolioById($id);
        }
        return view('user.profile.portfolio._load_portfolio_frm', ['model' => $model]);
    }

    public function portfolioSubmit(Request $request) {
        $data = $request->all();

        if (!empty($request->documents)) {
            $validator = $this->validate($request, [
                'documents.*' => 'mimes:jpeg,jpg,doc,pdf,docx,zip'
            ]);

//            if (!$validator->fails()) {
//                return Response::json(['success' => false, 'errors' => ['documents.0' => 'The documents must be a file of type : doc, docx, pdf, jpeg, and jpg.']], 422);
//            }
        }
        if ($request->hasFile('documents')) {
            $imagePath = base_path() . '/public/uploads/document';
            if (!is_dir($imagePath)) {
                File::makeDirectory($imagePath, $mode = 0777, true, true);
            }
            $fileDetails = array();
            $filesData = array();
            $files = $request->file('documents');
            foreach ($files as $file) {
                $fileInfo = pathinfo($file->getClientOriginalName());
                $fileDetails['filename'] = time() . $fileInfo['basename'];
                $fileDetails['extension'] = $fileInfo['extension'];
                $fileDetails['title'] = $fileInfo['filename'];
                $filesData[] = $fileDetails;
                $destinationPath = $imagePath;
                $file->move($destinationPath, $fileDetails['filename']);
            }
            $data['filesData'] = $filesData;
        }

        $experienceData = \App\Models\UserProject::addUserPortfolio($data);
        if (!empty($experienceData)) {
            if (!empty($data['id'])) {
                return response()->json(['status' => true, 'message' => 'Portfolio updated successfully.']);
            }
            return response()->json(['status' => true, 'message' => 'Portfolio added successfully.']);
        } else {
            return response()->json(['status' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

    public function savePortfolio(Request $request) {
        $data = $request->all();
        $experienceData = \App\Models\UserProject::addUserPortfolio($data);
        if ($experienceData) {
            session()->flash('success', 'Portfolio');
            session()->flash('message', 'Portfolio added successfully.');
            return redirect('/user/skills');
        }
        return redirect()->back();
    }

    public function uploadVideo(\App\Http\Requests\UploadVideoRequest $request) {
        if ($request->hasFile('video')) {
            $video = $request->file('video');
            $file = $video->getRealPath();
            require_once('public/getid3/getid3.php');
            $getID3 = new \getID3();
            $filename = $file;
            $fileinfo = $getID3->analyze($filename);
            $str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $fileinfo['playtime_string']);
            sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
            $time_seconds = isset($seconds) ? $hours * 3600 + $minutes * 60 + $seconds : $hours * 60 + $minutes;
            $userPlan = \App\Models\PlanSubscription::where('user_id', Auth::user()->id)->first();
            if ($time_seconds > $userPlan->video_duration) {
                return Response::json(['status' => false, 'uploadVideoError' => 'Your plan subscription  allowed upto 30 seconds video upload.'], 422);
            } else {
                $videoPath = public_path() . '/uploads/promovideo';
                if (!is_dir($videoPath)) {
                    File::makeDirectory($videoPath, $mode = 0777, true, true);
                }
                $video = $request->file('video');
                $videoName = time() . '-' . $request->video->getClientOriginalName();
                $video->move($videoPath, $videoName);
                $result = \App\Models\PromoVideo::saveVideo($videoName);
                if ($result) {
                     return Response::json(['status' => true, 'message' => 'Promovideo added successfully.']);
                    
                }
            }
        }
    }
    
    public function viewUserProfile($userId, $slug) {
        $userDetails = \App\Models\User::getUserById($userId);
        if (!empty($userDetails)) {
            $userSlug = \App\Helpers\Utility::makeSlug($userDetails->first_name);
            if ($userSlug != $slug) {
                return response()->view('errors.404', [], 404);
            }
            $notification = \App\Models\Notification::viewProfileNotification($userId);
            return view('user.profile.view-user-profile', ['userDetails' => $userDetails]);
        }
        return response()->view('errors.404', [], 404);
    }
    
    public function viewUserVideo(Request $request) {
        $post = $request->all();
        $notification = \App\Models\Notification::viewVideoNotification($post['userId']);
        return Response::json(['status' => true]);
    }
}
