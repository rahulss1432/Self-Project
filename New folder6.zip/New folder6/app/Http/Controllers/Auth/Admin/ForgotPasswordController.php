<?php

namespace App\Http\Controllers\Auth\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\ForgotPasswordRequest;
use App\User;

class ForgotPasswordController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Password Reset Controller
      |--------------------------------------------------------------------------
      |
      | This controller is responsible for handling password reset emails and
      | includes a trait which assists in sending these notifications from
      | your application to your users. Feel free to explore this trait.
      |
     */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest:admin');
    }

    /**
     * Display the form to request a password reset link.
     *
     * @return \Illuminate\Http\Response
     */
    protected function showLinkRequestForm() {
        return view('auth.admin.forgot-password');
    }

    protected function sendPasswordLink(ForgotPasswordRequest $request) {
        // We will send the password reset link to this user. Once we have attempted
        // to send the link, we will examine the response then see the message we
        // need to show to the user. Finally, we'll send out a proper response.
        $result = User::sendPasswordResetToken($request->email);
        return $response = $result ? $this->sendResetLinkResponse($result) : $this->sendResetLinkFailedResponse($result);
    }

    protected function sendResetLinkResponse($response) {
        session()->flash('success', 'Reset Password');
        session()->flash('message', "We have e-mailed your password reset link!");
        if (request()->expectsJson()) {
            return response()->json(['status' => true]);
        }
    }

    /**
     * Get the response for a failed password reset link.
     *
     * @param  \Illuminate\Http\Request
     * @param  string  $response
     * @return \Illuminate\Http\RedirectResponse
     */
    protected function sendResetLinkFailedResponse($response) {
        $errors = ['email' => 'We have not able to e-mailed your password reset link! Please try again'];
        if (request()->expectsJson()) {
            return response()->json($errors, 422);
        }
        return back()->withErrors(
                        ['email' => trans($response)]
        );
    }

    public function resetPassword($token) {
        $userInfo = User::getUserByToken($token);
        if (!empty($userInfo)) {
            return view('auth.admin.reset-password', ['token' => $token]);
        } else {
            session()->flash('error', 'Reset Password');
            session()->flash('message', "Forgot password link has been expired or you have already changed your password.");
            return redirect('/admin');
        }
    }

    public function updatePassword(\App\Http\Requests\ResetPasswordRequest $request) {
        $userInfo = User::getUserByToken($request->token);
        if (!empty($userInfo)) {
            $post = array();
            $post['userId'] = $userInfo->id;
            $post['password'] = $request->password;
            if (User::changePassword($post)) {
                session()->flash('success', 'Reset Password');
                session()->flash('message', "Your password has been succesfully udpdated.");
                return response()->json(['status' => true]);
            }
        }
        session()->flash('error', 'Reset Password');
        session()->flash('message', "Forgot password link has been expired or you have already changed your password.");
        return response()->json(['status' => false]);
    }

}
