<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use App\User;
use Laravel\Socialite\Facades\Socialite;
use App\Helpers\Helper;

class SocialLoginController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Login Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles authenticating users for the application and
      | redirecting them to your home screen. The controller uses a trait
      | to conveniently provide its functionality to your applications.
      |
     */

use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    public function __construct() {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Handle Social login request
     *
     * @return response

     */
    public function socialLogin($social) {
        return Socialite::driver($social)->redirect();
    }

    public function handleProviderCallback($social) {
        try {
            $user = Socialite::driver($social)->user();
            $user['signup_by'] = $social;
            $userInfo = User::where('social_id', $user->id)->orWhere('email', $user->email)->first();
            if (!empty($userInfo)) {
                \Illuminate\Support\Facades\Auth::loginUsingId($userInfo->id);
                return redirect('/user/dashboard');
            }
            $authUser = $this->findOrCreate($user);
            if ($authUser) {
                return redirect('/');
            }
        } catch (Exception $e) {
            return redirect('/login');
        }
        return redirect('/login');
    }

    public function actionUpdateAccountType(\App\Http\Requests\SetAccountInfoRequest $request) {
        $data = session()->get('userSession');
        $data['user_type'] = $request->user_type;
        if (!empty($request->email)) {
            $data['email'] = $request->email;
        }
        $data = session()->put('userSession', $data);
        return redirect('/payment');
    }

    public function findOrCreate($providerUser) {
        $data = array();
        if ($providerUser['signup_by'] == 'linkedin') {
            $data['first_name'] = $providerUser->user['firstName'];
            $data['last_name'] = $providerUser->user['lastName'];
            $data['email'] = $providerUser->email;
            $data['social_id'] = $providerUser->id;
            $data['signup_by'] = 'linkedin';
            $data['profile_image'] = \App\Helpers\Utility::getSocialProfileImage($providerUser->avatar_original, $providerUser->id);
            $countryCode = \App\Models\Country::where('abbreviation', strtoupper($providerUser->user['location']['country']['code']))->first();
            $data['country'] = $countryCode->id;
            $data['user_type'] = '';
            session()->put('userSession', $data);
            return true;
        }
        if ($providerUser['signup_by'] == 'facebook') {
            $name = explode(" ", $providerUser->name);
            $data['first_name'] = $name[0];
            $data['last_name'] = $name[1];
            $data['email'] = (!empty($providerUser->email)) ? $providerUser->email : NULL;
            $data['social_id'] = $providerUser->id;
            $data['signup_by'] = 'facebook';
            $data['profile_image'] = \App\Helpers\Utility::getSocialProfileImage($providerUser->avatar_original, $providerUser->id);
            $data['user_type'] = '';
            session()->put('userSession', $data);
            return true;
        }
        return false;
    }

}
