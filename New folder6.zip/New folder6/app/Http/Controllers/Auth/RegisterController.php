<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use App\Models\PlanSubscription;
use App\Helpers\MailUtility;
use Srmklive\PayPal\Services\ExpressCheckout;

class RegisterController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Register Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles the registration of new users as well as their
      | validation and creation. By default this controller uses a trait to
      | provide this functionality without requiring any additional code.
      |
     */

use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $provider;

    public function __construct() {
        $this->middleware('guest');
        $this->provider = new ExpressCheckout();
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(\App\Http\Requests\RegistrationRequest $request) {
        $request->session()->put('userSession', $request->all());
        return redirect('/payment');
    }

    public function makePayment() {
        $userData = session()->get('userSession');
        if (!empty($userData)) {
            $typeInfo = \App\Models\UserType::getUserTypeId($userData['user_type']);
            $planList = \App\Models\Plan::getPlanList(['user_type' => $userData['user_type']]);
            return view('auth.make-payment', ['planList' => $planList, 'typeInfo' => $typeInfo]);
        }
        return redirect('/');
    }

    public function paymentSub(Request $request) {
        $post = $request->all();
        $userData = session()->get('userSession');
        $userData['planId'] = $post['planId'];
        if ($post['validatePrice'] <= 0) {
            if (!empty($userData['signup_by'])) {
                $userData['email_status'] = 'verified';
            } else {
                $userData['email_status'] = 'pending';
            }
            $userData['price'] = 0.00;
            $userData['transaction_id'] = date('ymdhis');
            $rUrl = $this->saveUserData($userData);
            return redirect($rUrl);
        } else {

            $planId = $post['planId'];
            $recurring = 1;
            $invoice_id = date('ymdhis');
            $planIfo = \App\Models\Plan::getPlanById($planId);
            $cartData = array();
            $cartData['price'] = $planIfo->price;
            $cartData['invoice_id'] = $invoice_id;
            $cartData['recurring'] = $recurring;
            $userData['price'] = $planIfo->price;
            $userData['email_status'] = 'verified';
            // Get the cart data
            $cart = $this->getCart($cartData);
            // send a request to paypal 
            // paypal should respond with an array of data
            // the array should contain a link to paypal's payment system
            $response = $this->provider->setExpressCheckout($cart, $recurring);
            session()->put('userSession', $userData);
            // if there is no link redirect back with error message
            if (!$response['paypal_link']) {
                session()->flash('error', 'Payment');
                session()->flash('message', print_r($response));
                return redirect('/payment');
                // For the actual error message dump out $response and see what's in there
            }

            // redirect to paypal
            // after payment is done paypal
            // will redirect us back to $this->expressCheckoutSuccess
            return redirect($response['paypal_link']);
        }
        return false;
    }

    public function expressCheckoutSuccess(Request $request) {

        // check if payment is recurring
        $recurring = $request->input('recurring', false) ? true : false;

        $token = $request->get('token');

        $PayerID = $request->get('PayerID');

        // initaly we paypal redirects us back with a token
        // but doesn't provice us any additional data
        // so we use getExpressCheckoutDetails($token)
        // to get the payment details
        $response = $this->provider->getExpressCheckoutDetails($token);

        // if response ACK value is not SUCCESS or SUCCESSWITHWARNING
        // we return back with error
        if (!in_array(strtoupper($response['ACK']), ['SUCCESS', 'SUCCESSWITHWARNING'])) {
            return redirect('/')->with(['code' => 'danger', 'message' => 'Error processing PayPal payment']);
        }

        // invoice id is stored in INVNUM
        // because we set our invoice to be xxxx_id
        // we need to explode the string and get the second element of array
        // witch will be the id of the invoice
        $invoice_id = explode('_', $response['INVNUM'])[1];

        $cartData = array();
        $cartData['price'] = $response['AMT'];
        $cartData['invoice_id'] = $invoice_id;
        $cartData['recurring'] = $recurring;
        // get cart data
        $cart = $this->getCart($cartData);

        // check if our payment is recurring
        if ($recurring === true) {

            // if recurring then we need to create the subscription
            // you can create monthly or yearly subscriptions
            $response = $this->provider->createMonthlySubscription($response['TOKEN'], $response['AMT'], $cart['subscription_desc']);

            $status = 'Invalid';
            // if after creating the subscription paypal responds with activeprofile or pendingprofile
            // we are good to go and we can set the status to Processed, else status stays Invalid
            if (!empty($response['PROFILESTATUS']) && in_array($response['PROFILESTATUS'], ['ActiveProfile', 'PendingProfile'])) {
                $status = 'Processed';
            }
        } else {

            // if payment is not recurring just perform transaction on PayPal
            // and get the payment status
            $payment_status = $this->provider->doExpressCheckoutPayment($cart, $token, $PayerID);
            $status = $payment_status['PAYMENTINFO_0_PAYMENTSTATUS'];
        }
        $userData = session()->get('userSession');
        $userData['payment_status'] = $status;
        $userData['responce_json'] = $response;
        $userData['transaction_id'] = $invoice_id;

        // find invoice by id
        //$invoice = Invoice::find($invoice_id);
        // set invoice status
        //$invoice->payment_status = $status;
        // if payment is recurring lets set a recurring id for latter use
        if ($recurring === true) {
            $userData['recurring_id'] = $response['PROFILEID'];
        }

        // save the invoice
        //$invoice->save();
        $rUrl = $this->saveUserData($userData);
        // App\Invoice has a paid attribute that returns true or false based on payment status
        // so if paid is false return with error, else return with success message
        if ($rUrl) {
            session()->flash('success', 'Payment');
            session()->flash('message', 'Order has been paid successfully!');
            return redirect($rUrl);
        }
        session()->flash('error', 'Payment');
        session()->flash('message', "Error processing PayPal payment");
        return redirect('/payment');
    }

    public function saveUserData($userData) {
        $result = User::UserRegistration($userData);
        if ($result) {
            $subscription = PlanSubscription::saveUserPlan($result->id, $userData);
            if (!empty($subscription)) {
                $result->active_plan = $subscription->id;
                $result->save();
                if (!empty($result->social_id)) {
                    session()->flash('success', ucfirst($result->signup_by));
                    session()->flash('message', "You are successfully registered with Rezeio.");
                    \Illuminate\Support\Facades\Auth::loginUsingId($result->id);
                    return '/user/dashboard';
                }
                if ($userData['price'] > 0) {
                    \Illuminate\Support\Facades\Auth::loginUsingId($result->id);
                    return '/user/dashboard';
                }
                session()->put('userSession', '');
                session()->forget('userSession');
                return '/registration-success';
            }
        }
    }

    private function getCart($data) {
        $invoice_id = $data['invoice_id'];
        $recurring = $data['recurring'];
        $price = round($data['price'], 2);
        if ($recurring) {
            $subscription_desc = 'Monthly Plan Subscription #' . $invoice_id;
        } else {
            $subscription_desc = ' Plan Subscription #' . $invoice_id;
        }
        return [
            // if payment is recurring cart needs only one item
            // with name, price and quantity
            'items' => [
                [
                    'name' => $subscription_desc,
                    'price' => $price,
                    'qty' => 1,
                ],
            ],
            // return url is the url where PayPal returns after user confirmed the payment
            'return_url' => url('/paypal/express-checkout-success?recurring=' . $recurring),
            'subscription_desc' => $subscription_desc,
            // every invoice id must be unique, else you'll get an error from paypal
            'invoice_id' => config('paypal.invoice_prefix') . '_' . $invoice_id,
            'invoice_description' => "Order #" . $invoice_id . " Invoice",
            'cancel_url' => url('/'),
            // total is calculated by multiplying price with quantity of all cart items and then adding them up
            // in this case total is 20 because price is 20 and quantity is 1
            'total' => $price, // Total price of the cart
        ];
    }

    public function registrationSuccess() {
        $userData = session()->get('userSession');
        return view('auth.registration-success', ['userType' => $userData['user_type']]);
    }

    public function userVerification($token) {
        $model = User::getUserByToken($token);
        if (!empty($model)) {
            $model->remember_token = NULL;
            $model->email_status = 'verified';
            if ($model->save()) {
                session()->flash('success', 'Email verification');
                session()->flash('message', "Account verified successfully & we have e-mailed your subscription invoice.");
                PlanSubscription::sendInvoiceMail($model->active_plan);
                return redirect('/login');
            }
            session()->flash('error', 'Email verification');
            session()->flash('message', "please try again later.");
            return redirect('/');
        }
        session()->flash('error', 'Email verification');
        session()->flash('message', "Your email verification token is expired.");
        return redirect('/login');
    }

}
