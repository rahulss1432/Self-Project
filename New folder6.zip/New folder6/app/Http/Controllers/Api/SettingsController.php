<?php

namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use App\User;
use JWTAuth;
use App\Http\Requests\ChangePasswordRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SettingsController extends Controller {

    public function actionChangePassword(ChangePasswordRequest $request) {
        $post = $request->all();
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        $post['userId'] = $user->id;
        $result = User::changePassword($post);
        if ($result) {
            return response()->json(['success' => true, 'message' => 'Password changed successfully.']);
        } else {
            return response()->json(['success' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

    public function getUserList(Request $request) {
        $data = $request->all();
        $limit = env('RECORD_LIMIT', 10);
        $query = User::orderBy('id', 'DESC');
        if (!empty($data['searchKey'])) {
            $key = $data['searchKey'];
            $query = $query->where(DB::raw("concat(first_name,' ',last_name)"), 'like', '%' . $key . '%');
        }
        $userData = $query->paginate($limit);
        if ($userData) {
            return response()->json(['success' => true, 'data' => $userData]);
        } else {
            return response()->json(['success' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

    public function getCountryList(Request $request) {
        $data = $request->all();
        $countryData = \App\Models\Country::getCountryList_Admin($data);
        if (!empty($countryData)) {
            return response()->json(['success' => true, 'data' => $countryData]);
        } else {
            return response()->json(['success' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

    public function getIndustryList(Request $request) {
        $data = $request->all();
        $countryData = \App\Models\Industry::getIndustryList_Admin($data);
        if (!empty($countryData)) {
            return response()->json(['success' => true, 'data' => $countryData]);
        } else {
            return response()->json(['success' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

    public function addIndustry(\App\Http\Requests\IndustryRequest $request) {
        $data = $request->all();
        $countryData = \App\Models\Industry::addIndustry($data);
        if (!empty($countryData)) {
            if (!empty($data['id'])) {
                return response()->json(['success' => true, 'message' => 'Industry updated successfully.']);
            }
            return response()->json(['success' => true, 'message' => 'Industry added successfully.']);
        } else {
            return response()->json(['success' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

    public function getIndustryById($id) {
        $industryInfo = \App\Models\Industry::getIndustryById($id);
        if (!empty($industryInfo)) {
            return response()->json(['success' => true, 'data' => $industryInfo]);
        } else {
            return response()->json(['success' => false, 'error' => ['message' => 'Please try again.']], 422);
        }
    }

}
