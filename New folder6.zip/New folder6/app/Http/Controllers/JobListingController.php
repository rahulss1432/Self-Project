<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Job;

class JobListingController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('job-listing.index');
    }

    public function getJobDetails($id, $slug) {
        $jobDetail = \App\Models\Job::where('id', $id)->first();
        if (!empty($jobDetail)) {
            $jobSlug = \App\Helpers\Utility::makeSlug($jobDetail->job_title);
            if ($jobSlug != $slug) {
                return response()->view('errors.404', [], 404);
            }
            return view('job-listing.job-details', ['jobDetail' => $jobDetail]);
        }
        return response()->view('errors.404', [], 404);
    }
    
    public function getAllJobsList(Request $request){
        $post = $request->all();
        $jobData = Job::getAllJobsList($post);
        return view('job-listing._load_job_listing', ['jobData' => $jobData]);
    }
    
     public function getSkillsByIndustryForSearching(Request $request) {
        $post = $request->all();
        $skillsArray = array();
        $industryId = $post['industryId'];
        $skillsList = \App\Models\Skill::getSkillsByIndustry($industryId);
        $html = '';
        $html .= '<option value="" disabled>Select Skills</option>';
        if (!empty($skillsList)) {
            foreach ($skillsList as $skill) {
                $data = (in_array($skill['id'], $skillsArray)) ? 'selected=selected' : '';
                $html .= '<option value="' . $skill['id'] . '" ' . $data . '>' . $skill['skill_name'] . '</option>';
            }
        }
        return $html;
    }

    public function getCompanyDetails($id, $slug) {
        $companyDetail = \App\Models\User::where('id', $id)->first();
        if (!empty($companyDetail)) {
            $companySlug = \App\Helpers\Utility::makeSlug($companyDetail->company_name);
            if ($companySlug != $slug) {
                return response()->view('errors.404', [], 404);
            }
            return view('user.profile.view-company-profile', ['userDetails' => $companyDetail]);
        }
        return response()->view('errors.404', [], 404);
    }

}
