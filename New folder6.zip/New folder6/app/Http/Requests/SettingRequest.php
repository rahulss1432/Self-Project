<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SettingRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        if (empty($this->id)) {
            return [
                'setting_type' => 'required',
                'setting_title' => 'required',
                'setting_key' => 'required|unique:settings',
                'setting_value' => 'nullable|string|required_if:setting_type,text',
                'setting_image' => 'nullable|string|required_if:setting_type,image',
                'thumbnail_width' => 'nullable|string|required_if:setting_type,image',
                'thumbnail_height' => 'nullable|string|required_if:setting_type,image',
                'setting_image' => 'nullable|required_if:setting_type,image|mimetypes:image/jpeg,image/png,image/jpg'
            ];
        } else {
            return [
                'setting_type' => 'required',
                'setting_title' => 'required',
                'setting_key' => 'required|unique:settings,setting_key,' . $this->id,
                'setting_value' => 'nullable|string|required_if:setting_type,text',
                'setting_image' => 'nullable|string|required_if:setting_type,image',
                'thumbnail_width' => 'nullable|string|required_if:setting_type,image',
                'thumbnail_height' => 'nullable|string|required_if:setting_type,image',
                'setting_image' => 'nullable|required_if:setting_type,image|mimetypes:image/jpeg,image/png,image/jpg'
            ];
        }
    }

    public function messages() {
        return [
            'name.validate_category' => 'Category  "<b>' . $this->name . '</b>" has already been taken.',
            'name.edit_validate_category' => 'Category  "<b>' . $this->name . '</b>" has already been taken.',
        ];
    }

}
