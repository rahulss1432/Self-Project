<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MultipleExperienceRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        $rules = [];
        if (!empty($this->input('ids'))) {
            $i = 0;
            foreach ($this->input('ids') as $key => $value) {
                $rules["title.{$i}.title"] = ['required'];
                $rules["company.{$i}.company"] = ['required'];
                $i++;
            }
        }
        return $rules;
    }

    public function messages() {
        $message = [];
        if (!empty($this->input('ids'))) {
            $s = 0;
            foreach ($this->input('ids') as $key => $value) {
                $message["title.{$s}.title.required"] = 'The experience title field is required.';
                $message["company.{$s}.company.required"] = 'The experience company field is required.';
                $s++;
            }
        }
        return $message;
    }

}
