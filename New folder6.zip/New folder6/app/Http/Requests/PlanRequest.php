<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PlanRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        if (empty($this->id)) {
            return [
                'user_type' => 'required',
                'plan_name' => 'required|string|validate_plan',
                'price' => 'required|numeric',
                'plan_duration' => 'required|integer',
                'video_duration' => 'required|integer',
                'jobs_limit' => 'required_unless:unlimited,unlimited',
//                'plan_description' => 'required|string',
                'status' => 'required'
            ];
        } else {
            return [
                'user_type' => 'required',
                'plan_name' => 'required|edit_validate_plan',
                'price' => 'required|numeric',
                'plan_duration' => 'required|integer',
                'video_duration' => 'required|integer',
                'jobs_limit' => 'required_unless:unlimited,unlimited',
//                'plan_description' => 'required|string',
                'status' => 'required'
            ];
        }
    }

    public function messages() {
        return [
            'plan_name.validate_plan' => 'Plan  "<b>' . $this->plan_name . '</b>" has already been taken for ' . $this->user_type . '.',
            'plan_name.edit_validate_plan' => 'Plan  "<b>' . $this->plan_name . '</b>" has already been taken for ' . $this->user_type . '.',
            'jobs_limit.required_unless' => 'Jobs limit field is required.'
        ];
    }

}
