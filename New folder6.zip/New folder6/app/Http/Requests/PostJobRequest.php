<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PostJobRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'job_title' => 'required|max:151',
            'job_type' => 'required',
            'rate_type' => 'required_if:job_type,freelancer',
            'rate_amount' => 'required_if:job_type,freelancer',
            'industry_type' => 'required',
            'address' => 'required|string|max:150',
            'country' => 'required',
            'state' => 'required',
            'city' => 'required|string|max:50',
            'zipcode' => 'required|numeric',
            'skills' => 'required',
            'experience' => 'required',
            'position' => 'required|max:800',
            'duties' => 'required|max:600',
            'qualifications' => 'required|max:500',
            'benefits' => 'required|max:1000',
//            'question' => 'required',
          
        ];
    }

    public function messages() {
        return [
            'rate_type.required_if' => 'Rate type field is required.',
            'rate_amount.required_if' => 'Rate amount field is required.',
           
        ];
    }

}
