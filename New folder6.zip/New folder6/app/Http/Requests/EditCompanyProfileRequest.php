<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EditCompanyProfileRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'first_name' => 'required|string|max:50',
            'last_name' => 'required|string|max:50',
            'phone_number' => 'required|numeric',
            'company_name' => 'required|string|max:50',
            'address' => 'required|string|max:150',
            'country' => 'required',
            'state' => 'required|string|max:50',
            'city' => 'required|string|max:50',
            'postal_code' => 'required|integer',
            'industry_type' => 'required',
            'employee_strength' => 'required',
            'website_url' => 'url|nullable',
            'linkedin_url' => 'url|nullable',
            'facebook_url' => 'url|nullable',
            'twitter_url' => 'url|nullable',
            'speciality' => 'required|string|max:150',
            'about_us' => 'required|string|max:150',
            'banner_image' => 'nullable|mimetypes:image/jpeg,image/png,image/jpg|dimensions:min_width=1285,min_height=470',
            'video' => 'nullable|max:10240|mimetypes: video/x-flv,video/mp4',
        ];
    }

    public function messages() {
        return [
            'website_url.url' => 'The youtube url should be valid.',
            'linkedin_url.url' => 'The linkedin url should be valid.',
            'facebook_url.url' => 'The facebook url should be valid.',
            'twitter_url.url' => 'The twitter url should be valid.',
            'banner_image.dimensions' => 'Banner image dimensions should be 1285*470.',
        ];
    }

}
