<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UploadVideoRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'video' => 'required|mimetypes:video/mp4,video/3gpp,video/x-flv|max:30000',
        ];
    }

    public function messages() {
        return [
            'video.max' => 'The video may not be greater than 30MB.',
        ];
    }

}
