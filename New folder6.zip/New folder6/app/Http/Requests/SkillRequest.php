<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SkillRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        if (empty($this->id)) {
            return [
                'skill_name' => 'required|string|validate_skill',
                'industry_name' => 'required',
                'status' => 'required'
            ];
        } else {
            return [
                'skill_name' => 'required|string|edit_validate_skill',
                'industry_name' => 'required',
                'status' => 'required'
            ];
        }
    }

    public function messages() {
        return [
            'skill_name.validate_skill' => 'Skill  "<b>' . $this->skill_name . '</b>" has already been taken.',
            'skill_name.edit_validate_skill' => 'Skill  "<b>' . $this->skill_name . '</b>" has already been taken.',
        ];
    }

}
