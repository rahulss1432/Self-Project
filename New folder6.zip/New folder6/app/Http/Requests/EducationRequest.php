<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EducationRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'university' => 'required|string|max:100',
            'degree' => 'required|string|max:100',
            'minor' => 'required|string|max:100',
            'duration_form' => 'required',
            'duration_to' => 'required_without:is_working',
        ];
    }

    public function messages() {
        return [
            'duration_to.required_without' => 'Duration to field is required.'
        ];
    }

}
