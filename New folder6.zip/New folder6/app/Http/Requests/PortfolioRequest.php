<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PortfolioRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'project_title' => 'required|string|max:100',
            'project_type' => 'required|string|max:100',
            'duration' => 'required|string|max:100',
            'client_details' => 'required|string|max:255',
            'description' => 'required|string|max:255',
            'project_amount' => 'required|numeric|min:1|max:1000000',
            'project_links[]' => 'nullable|url',
        ];
    }
}
