<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EditProfileRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'first_name' => 'required|string|max:50',
            'last_name' => 'required|string|max:50',
            'mobile_number' => 'required|numeric',
            'hourly_rate' => 'nullable|numeric|min:1|max:100',
            'dob' => 'required',
            'profile_summary' => 'required|string|max:150',
            'address' => 'required|string|max:150',
            'country' => 'required',
            'state' => 'required',
            'city' => 'required|string|max:50',
            'zipcode' => 'required|numeric',
            'facebook_url' => 'url|nullable',
            'linkedin_url' => 'url|nullable',
            'twitter_url' => 'url|nullable',
            'youtube_url' => 'url|nullable',
        ];
    }

    public function messages() {
        return [
            'facebook_url.url' => 'The facebook url should be valid.',
            'linkedin_url.url' => 'The linkedin url should be valid.',
            'twitter_url.url' => 'The twitter url should be valid.',
            'youtube_url.url' => 'The youtube url should be valid.',
        ];
    }

}
