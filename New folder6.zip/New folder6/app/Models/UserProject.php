<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use App\Models\UserDocument;

class UserProject extends Model
{
    public static function getUserProject($userId) {
        $model = UserProject::where('user_id', $userId)->get();
        if ($model) {
            return $model;
        }
        return false;
    }
    
    public static function getPortfolioById($id) {
        $model = UserProject::where('user_id', Auth::user()->id)
                ->where('id', $id)
                ->first();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function addUserPortfolio($post) {
        $model = new UserProject();
        if (!empty($post['id'])) {
            $model = UserProject::getPortfolioById($post['id']);
        }
        $model->user_id = Auth::user()->id;
        $model->project_title = ucwords(strtolower($post['project_title']));
        $model->project_type = ucwords(strtolower($post['project_type']));
        $model->duration = $post['duration'];
        $model->client_details = ucfirst(strtolower($post['client_details']));
        $model->project_amount = $post['project_amount'];
        $projectLinks = implode(',', $post['project_links']);
        $model->project_links = $projectLinks;
        $model->description = ucfirst(strtolower($post['description']));
        if ($model->save()) {
            if(!empty($post['documents'])){
                UserDocument::saveUserDocument($model->id,$post['filesData']);
            }
            return true;
        }
        return false;
    }
    
    public static function deletePortfolio($id) {
        if (!empty($id)) {
            $model = UserProject::where('id', $id)->first();
            if ($model->delete()) {
                return true;
            }
        }
        return false;
    }
    
    public static function saveUserPortfolio($post) {
        if(self::UserProject($post)){
            
            return true;
        }
        return false;
    }
}
