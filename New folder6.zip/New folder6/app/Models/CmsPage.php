<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CmsPage extends Model {

    public static function getAllCmsPages() {
        $modal = CmsPage::orderBy('title', 'ASC')->get();
        return $modal;
    }

    public static function updateCmsPage($post) {
        $model = CmsPage::where('id', $post['id'])->first();
        $model->title = $post['title'];
        $model->meta_keywords = $post['meta_keywords'];
        $model->meta_description = $post['meta_description'];
        $model->content = $post['content'];
        if ($model->save()) {
            return true;
        }
        return false;
    }

    public static function getPageBySlug($slug) {
        $model = CmsPage::where(['slug' => $slug])->first();
        return $model;
    }

}
