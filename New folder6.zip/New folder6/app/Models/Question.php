<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Question extends Model {
    
    public function getcategory() {
        return $this->hasOne('App\Models\QuestionCategory', 'id', 'category_id');
    }

    public static function saveQuestions($jobId, $questions) {
        foreach ($questions as $question) {
            if (!empty($question)) {
                $model = new Question();
                $model->job_id = $jobId;
                $model->questions = $question;
                $model->save();
            }
        }
        return true;
    }
    
    public static function getQuestionList($post) {
        $limit = env('RECORD_LIMIT', 10);
        $query = Question::select('questions.*');       
        if (!empty($post['name']) && $post['name'] != '') {
            $name = $post['name'];
            $query->whereHas('getcategory', function ($query1) use ($name) {
                $query1->where('question_categories.name', 'like', '%' . $name . '%');  
            });
        }
        if (isset($post['question']) && !empty($post['question'])) {
            $query->where('questions.question', 'like', '%' . $post['question'] . '%');     
        }
        $questionList = $query->orderBy('created_at', 'desc')->paginate($limit);
        return $questionList;
    }
    
    public static function getQuestionById($id) {
        $model = Question::where('id', $id)->first();
        if ($model) {
            return $model;
        }
        return false;
    }
    
    public static function addQuestion($post) {
        $model = new Question();
        if (!empty($post['id'])) {
            $model = Question::getQuestionById($post['id']);
        }
        $model->category_id = $post['category_id'];
        $model->question = ucfirst($post['question']);
        if ($model->save()) {
            return true;
        }
        return false;
    }
    
    public static function deleteQuestion($id) {
        if (!empty($id)) {
            $model = Question::getQuestionById($id);
            if ($model->delete()) {
                return true;
            }
        }
        return false;
    }
}
