<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class JobApplication extends Model
{
    protected $table = 'job_applications';
    
    public function getJob() {
        return $this->hasOne('App\Models\Job', 'id', 'job_id');
    }
    
    
    
    public static function getMyApplicationList($post){
        $query = JobApplication::select('job_applications.*')
                ->where('user_id',$post['userId'])
                ->where('action_by',$post['action_by']);
        if(isset($post['status'])) {
            $query = $query -> where('status',$post['status']);
        }  
        $query = $query->orderBy('created_at','DESC');
        $data = $query->paginate(8);
        return $data;
    }
    
    public static function changeInvitationStatus($post){
        $model = JobApplication::where('user_id',$post['userId'])
                ->where('id',$post['id'])->first();
        $model->status = $post['status'];
        if($model->save()){
            return true;
        }
        return false;
    }
    
    public static function getjobsAppliedOrInvitationCount($action_by,$userId){
        $query = JobApplication::select('job_applications.*')
            ->where('user_id',$userId)
            ->where('action_by',$action_by)
            ->get();
        return $query->count();        
    }
}
