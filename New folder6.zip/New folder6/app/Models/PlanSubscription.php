<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use App\Helpers\MailUtility;
use Illuminate\Support\Facades\Auth;

class PlanSubscription extends Model {

    protected $table = 'plan_subscriptions';

    public function getUser() {
        return $this->hasOne('App\Models\User', 'id', 'user_id');
    }

    public function getPlan() {
        return $this->hasOne('App\Models\Plan', 'id', 'plan_id');
    }

    public static function getPaymentHistory($post) {
        $limit = env('RECORD_LIMIT', 10);
        $query = PlanSubscription::orderBy('created_at', 'DESC');

        if (!empty($post['userId'])) {
            $query->where('user_id', $post['userId']);
        }
        if (!empty($post['user_type'])) {
            $query->whereHas('getUser', function ($query1) use ($post) {
                $query1->where('user_type', $post['user_type']);
            });
        }
        if (!empty($post['from_date']) && !empty($post['to_date'])) {
            $fromDate = date("Y-m-d", strtotime($post['from_date']));
            $toDate = date("Y-m-d", strtotime($post['to_date']));
            $query->whereBetween(DB::raw('date(created_at)'), [$fromDate, $toDate]);
        }
        if (!empty($post['is_paginate'])) {
            $result = $query->paginate($limit);
        } else {
            $result = $query->get();
        }
        return $result;
    }

    public static function getActivePlan() {
        return PlanSubscription::where('id', \Illuminate\Support\Facades\Auth::user()->active_plan)->first();
    }

    public static function saveUserPlan($userId, $post) {
        $planInfo = Plan::getPlanById($post['planId']);
        $planDetails = $planInfo->getDetails;
        $descArray = array();
        if (!empty($planDetails)) {
            foreach ($planDetails as $description) {
                $descArray[] = $description['description'];
            }
        }
        $model = new PlanSubscription();
        $model->user_id = $userId;
        $model->plan_id = $planInfo->id;
        $model->amount = $post['price'];
        $model->plan_duration = $planInfo->plan_duration;
        $model->video_duration = $planInfo->video_duration;
        $model->jobs_limit = $planInfo->jobs_limit;
        $model->plan_description = implode(',', $descArray);
        $model->expiry_date = date('Y-m-d', strtotime(date("Y-m-d") . ' + ' . $planInfo->plan_duration . ' day'));

        if (!empty($post['recurring_id'])) {
            $model->recurring_id = $post['recurring_id'];
        }

        if (!empty($post['responce_json'])) {
            $model->responce_json = response()->json($post['responce_json']);
        }

        if (!empty($post['payment_status'])) {
            $model->payment_status = $post['payment_status'];
        }

        if (!empty($post['transaction_id'])) {
            $model->transaction_id = $post['transaction_id'];
        }


        if ($model->save()) {
            return $model;
        }
        return false;
    }

    public static function sendInvoiceMail($subscriptionId) {
        $subscriptionInfo = self::getSubscriptionById($subscriptionId);
        $data = array();
        $data['name'] = $subscriptionInfo->getUser->first_name . ' ' . $subscriptionInfo->getUser->last_name;
        $data['email'] = $subscriptionInfo->getUser->email;
        $data['address'] = $subscriptionInfo->getUser->address;
        $data['txn_id'] = $subscriptionInfo->transaction_id;
        $data['issue_date'] = $subscriptionInfo->created_at;
        $data['description'] = $subscriptionInfo->plan_description;
        $data['amount'] = $subscriptionInfo->amount;
        $data['Plan_name'] = $subscriptionInfo->getPlan->plan_name;
        $data['request'] = 'plan_invoice';
        MailUtility::sendMail($data);
        return true;
    }

    public static function getSubscriptionById($subscriptionId) {
        $model = PlanSubscription::where('id', $subscriptionId)->first();
        return $model;
    }

    public static function checkUserPlans() {
        return $subscription = self::select('plan_subscriptions.*')
                ->where('expiry_date', '>=', date("Y-m-d"))
                ->where('id', Auth::user()->active_plan)
                ->where('user_id', Auth::user()->id)
                ->first();
    }
    
    public static function getTopThreePaymentDistoryData($userId){
        $query = PlanSubscription::where('user_id', $userId)
                        ->orderBy('created_at', 'DESC')
                        ->limit(3)   
                        ->get();
        return $query;
    }
    
    //for Admin side user detail
    public static function getUserSubscriptuinsById($id){
        $query = PlanSubscription::where('user_id', $id)
                        ->orderBy('created_at', 'DESC')
                        ->get();
        return $query;
    }

}
