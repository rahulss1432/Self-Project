<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PlanDetails extends Model {

    protected $table = 'plan_details';

}
