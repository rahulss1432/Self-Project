<?php

namespace App\Models;

use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Model;
use App\Models\JobSkill;
use App\Models\Question;

class Job extends Model {

    protected $table = 'Jobs';

    public function getUser() {
        return $this->hasOne('App\Models\User', 'id', 'user_id');
    }

    public function getQuestions() {
        return $this->hasMany('App\Models\Question', 'job_id', 'id');
    }

//    public function getUserSkills() {
//        return $this->hasMany('App\Models\UserSkill', 'job_id', 'id');
//    }

    public function getIndustry() {
        return $this->hasOne('App\Models\Industry', 'id', 'industry_type');
    }

    public static function getJobById($id) {
        $model = Job::where('id', $id)->first();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function getJobList_Admin($post) {
        $limit = env('RECORD_LIMIT', 10);
        $planList = Job::orderBy('id', 'ASC')
                ->paginate($limit);
        return $planList;
    }

    public static function updatePlanStatus($post) {
        if (!empty($post['id'])) {
            $model = Job::getJobById($post['id']);
        }
        if ($model->status == 'enabled') {
            $model->status = 'disabled';
        } else {
            $model->status = 'enabled';
        }
        if ($model->save()) {
            return $model->status;
        }
        return false;
    }

    public static function getJobList($post) {
        $limit = env('RECORD_LIMIT', 1);
        $query = Job::orderBy('id', 'DESC');
        if (!empty($post['userId'])) {
            $query->where('user_id', $post['userId']);
        }
        if (!empty($post['is_paginate'])) {
            $result = $query->paginate($limit);
        } else {
            $result = $query->get();
        }
        return $result;
    }

    public static function addAJob($post) {
        $userId = Auth::user()->id;
        $model = new Job();
        if (!empty($post['id'])) {
            $model = Job::getJobById($post['id']);
        } else {
            $model->active_plan = Auth::user()->active_plan;
        }
        $model->user_id = $userId;
        $model->job_title = ucwords(strtolower($post['job_title']));
        $model->job_type = ucwords(strtolower($post['job_type']));
        if (!empty($post['rate_type'])) {
            $model->rate_type = $post['rate_type'];
        }
        if (!empty($post['rate_amount'])) {
            $model->rate_amount = $post['rate_amount'];
        }
        $model->industry_type = $post['industry_type'];
        $model->address = ucfirst(strtolower($post['address']));
        $model->country = $post['country'];
        $model->state = ucwords(strtolower($post['state']));
        $model->city = ucwords(strtolower($post['city']));
        $model->zipcode = $post['zipcode'];
        $model->experience = ucfirst(strtolower($post['experience']));
        $model->position_summary = ucfirst(strtolower($post['position']));
        $model->responsibilities = ucfirst(strtolower($post['duties']));
        $model->qualifications = ucfirst(strtolower($post['qualifications']));
        $model->benefits = ucfirst(strtolower($post['benefits']));
        if ($model->save()) {
            if (!empty($post['skills'])) {
                JobSkill::where('job_id', $model->id)->delete();
                Question::where('job_id', $model->id)->delete();
                JobSkill::saveJobSkills($model->id, $post['skills']);
                Question::saveQuestions($model->id, $post['question']);
            }
            return true;
        }
        return false;
    }

    public static function getAllJobsList($post) {
        $query = Job::select('jobs.*');
        if (isset($post['experience'])) {
            $query = $query->where('experience', $post['experience']);
        }
        if (isset($post['job_type'])) {
            $query = $query->where('job_type', $post['job_type']);
        }
        if (isset($post['industry_type'])) {
            $query = $query->where('industry_type', $post['industry_type']);
        }
        if (isset($post['skills'])) {
            $jobIdArray = array();
            $skillJobs = JobSkill::select('job_skills.job_id')->whereIn('skill_id', $post['skills'])->get();
            foreach ($skillJobs as $val) {
                array_push($jobIdArray, $val->job_id);
            }
            $query = $query->whereIn('id', $jobIdArray);
        }
        if (isset($post['location'])) {
            $query = $query->where('address', 'like', '%' . $post['location'] . '%')
                    ->orWhere('city', 'like', '%' . $post['location'] . '%')
                    ->orWhere('state', 'like', '%' . $post['location'] . '%');
        }
        $query = $query->orderBy('created_at', 'DESC');
        $data = $query->paginate(8);
        return $data;
    }

}
