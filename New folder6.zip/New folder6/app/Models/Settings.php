<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Image;
use File;

class Settings extends Model {

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'settings';
    protected $hidden = ['created_at', 'updated_at'];

    public static function addNewSetting($request) {
        $model = new Settings();
        if ($request['id'] != 0) {
            $model = Settings::getSettingById($request['id']);
            if ($model->setting_type == 'image') {
                \App\Helpers\Utility::unlinkMedia($model->setting_value, 'settings');
            }
        }
        $model->setting_title = ucwords(strtolower(trim($request['setting_title'])));
        $model->setting_value = $request['setting_value'];
        $model->setting_key = $request['setting_key'];
        $model->setting_type = $request['setting_type'];
        return $model->save();
    }

    public static function getSettingById($id) {
        $model = Settings::where('id', $id)->first();
        return $model;
    }
    
    public static function saveBannerSettings($post){
        $data = Settings::where('setting_key', 'like', '%' . $post['type'] . '%')->get();
        foreach ($data as $key) {
            $newkey = $key['setting_key'];
            $model = self::where('setting_key', $newkey)->first();  
            $model->setting_value = $post[$newkey];
            $model->save();
        }
        return true;        
    }
}
