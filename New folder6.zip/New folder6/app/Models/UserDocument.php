<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserDocument extends Model
{
    protected $table = 'upload_documents';
    
    public static function saveUserDocument($projectId, $documents){
        $userDocuments = UserDocument::where('project_id', $projectId)->get();
        if(!empty($userDocuments)){
            foreach($userDocuments as $doc){
                \App\Helpers\Utility::unlinkMedia($doc['document_url'], 'document');
                $doc->delete();
            }
        }
        
        if (!empty($documents)) {
            foreach ($documents as $doc) {
                $model = new UserDocument();
                $model->project_id = $projectId;
                $model->document_name = $doc['title'];
                $model->document_url = $doc['filename'];
                $model->document_type = $doc['extension'];
                $model->save();
            }
            return true;
        }
    }
    
    public static function getUserDocumentByProjectId($projectId){
        $userDocuments = UserDocument::where('project_id', $projectId)->get();
        return $userDocuments;
    }
}
