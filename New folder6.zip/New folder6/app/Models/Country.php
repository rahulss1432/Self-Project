<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Country extends Model {

    protected $table = 'countries';

    public static function getCountryById($id) {
        $model = Country::where('id', $id)->first();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function getCountryList() {
        $countryList = Country::where('status', 'enabled')
                ->orderBy('country_name', 'ASC')
                ->get();
        return $countryList;
    }

    public static function getCountryList_Admin($data) {
        $limit = env('RECORD_LIMIT', 10);
        $query = Country::orderBy('country_name', 'ASC');
        if (!empty($data['searchKey'])) {
            $key = $data['searchKey'];
            $query = $query->where('country_name', 'like', '%' . $key . '%');
        }
        $countryList = $query->paginate($limit);
        return $countryList;
    }

    public static function updateCountrtyStatus($post) {
        if (!empty($post['id'])) {
            $model = Country::getCountryById($post['id']);
        }
        if ($model->status == 'enabled') {
            $model->status = 'disabled';
        } else {
            $model->status = 'enabled';
        }
        if ($model->save()) {
            return $model->status;
        }
        return false;
    }
    
    public static function getCountriesDropdown($id) {
        $countries = Country::orderBy('country_name', 'asc')->get();
        $html = '';
        $html .= '<option value=""> Select Country </option>';
        if (!empty($countries)) {
            foreach ($countries as $country) {
                $data = ($id == $country['id']) ? 'selected="selected"' : '';
                $html .= '<option data-code="' . $country['country_name'] . '" value="' . $country['id'] . '" ' . $data . '>' . $country['country_name'] . '</option>';
            }
        }
        return $html;
    }
}
