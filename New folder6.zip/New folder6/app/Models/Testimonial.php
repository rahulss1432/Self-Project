<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Testimonial extends Model {
    
    public static function getTestimonialById($id) {
        $model = Testimonial::where('id', $id)->first();
        if ($model) {
            return $model;
        }
        return false;
    }
    
    public static function getTestimonialList_Admin() {
        $limit = env('RECORD_LIMIT', 10);
        $testimonialList = Testimonial::orderBy('created_at', 'DESC')->paginate($limit);
        return $testimonialList;
    }

    public static function addTestimonial($post) {
        $model = new Testimonial();
        if (!empty($post['id'])) {
            $model = Testimonial::getTestimonialById($post['id']);
        }
        $model->name = ucwords(strtolower($post['name']));
        $model->description = $post['description'];
        if (!empty($post['testimonial_image'])) {
            \App\Helpers\Utility::unlinkMedia($model->testimonial_image, 'testimonial');
            $model->testimonial_image = $post['testimonial_image'];
        }
        if ($model->save()) {
            return true;
        }
        return false;
    }

    public static function deleteTestimonial($id) {
        if (!empty($id)) {
            $model = Testimonial::getTestimonialById($id);
            \App\Helpers\Utility::unlinkMedia($model->testimonial_image, 'testimonial');
            if ($model->delete()) {
                return true;
            }
        }
        return false;
    }
}
