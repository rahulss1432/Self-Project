<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Auth;
use App\Helpers\MailUtility;

class User extends Model {

    protected $table = 'users';

    public function getCountry() {
        return $this->hasOne('App\Models\Country', 'id', 'country');
    }

    public function getUserExperience() {
        return $this->hasMany('App\Models\UserExperience', 'user_id', 'id');
    }

    public function getUserEducation() {
        return $this->hasMany('App\Models\UserEducation', 'user_id', 'id');
    }

    public function getUserProject() {
        return $this->hasMany('App\Models\UserProject', 'user_id', 'id');
    }

    public function getUserSkills() {
        return $this->hasMany('App\Models\UserSkill', 'user_id', 'id');
    }

    public function getPromoVideo() {
        return $this->belongsTo('App\Models\PromoVideo', 'id', 'user_id');
    }

    public function getActivePlan() {
        return $this->hasOne('App\Models\PlanSubscription', 'id', 'active_plan');
    }

    public function getUserType() {
        return $this->hasOne('App\Models\UserType', 'user_type', 'user_type');
    }

    public static function getUserById($id) {
        $model = User::where('id', $id)->first();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function getUserList_Admin($post) {
        $limit = env('RECORD_LIMIT', 10);
        $query = User::orderBy('id', 'DESC');
        if (!empty($post['user_type'])) {
            $query->where('user_type', $post['user_type']);
        }
        if (!empty($post['name'])) {
            $query->where(DB::raw('TRIM(CONCAT(users.first_name," ",users.last_name))'), 'like', '%' . $post['name'] . '%');
        }
        if (!empty($post['email'])) {
            $query->where('email', 'like', '%' . $post['email'] . '%');
        }

        if (!empty($post['plan_id'])) {
            $query->whereHas('getActivePlan', function ($query1) use ($post) {
                $query1->where('plan_id', $post['plan_id']);
            });
        }

        $userList = $query->paginate($limit);
        return $userList;
    }

    public static function updateUserStatus($post) {
        if (!empty($post['id'])) {
            $model = User::getUserById($post['id']);
        }
        if ($model->status == 'enabled') {
            $model->status = 'disabled';
        } else {
            $model->status = 'enabled';
        }
        if ($model->save()) {
            if (Auth::guard('admin')->user()->user_type == 'sub_admin') {
                $userName = $model->first_name . ' ' . $model->last_name;
                Notification::viewSubadminNotification(Auth::guard('admin')->user()->id, $userName);
            }
            return $model;
        }
        return false;
    }

    public static function changePassword($post) {
        $userId = \Illuminate\Support\Facades\Auth::guard($post['guard'])->user()->id;
        $model = User::find($userId);
        if (!empty($model)) {
            $model->password = bcrypt($post['password']);
            if ($model->save()) {
                return true;
            }
        }
        return false;
    }

    public static function updateUserInfo($post) {
        if (!empty($post['id'])) {
            $model = User::getUserById($post['id']);
        } else {
            $model = new User();
            $model->user_type = 'sub_admin';
            $model->email_status = 'verified';
        }
        $model->first_name = $post['first_name'];
        $model->last_name = $post['last_name'];
        $model->email = $post['email'];
        if (!empty($post['password'])) {
            $model->password = bcrypt($post['password']);
            $password_txt = $post['password'];
        }
        if ($model->save()) {
            $data = array();
            $data['email'] = $model->email;
            if (!empty($post['password'])) {
                $data['password'] = $password_txt;
            }
            $data['name'] = $model->first_name . ' ' . $model->last_name;
            $data['request'] = 'update_user_profile';
            MailUtility::sendMail($data);
            return true;
        }
        return false;
    }

    public static function updateUserProfile($post) {
        $userId = Auth::user()->id;
        $model = User::where('id', $userId)->first();
        $model->first_name = ucwords(strtolower(trim($post['first_name'])));
        $model->last_name = ucwords(strtolower(trim($post['last_name'])));
        $model->mobile_number = $post['mobile_number'];
        $model->dob = date('Y-m-d', strtotime($post['dob']));
        $model->profile_summary = ucfirst($post['profile_summary']);
        $model->address = ucfirst($post['address']);
        $model->country = $post['country'];
        $model->state = ucwords(strtolower($post['state']));
        $model->city = ucwords(strtolower($post['city']));
        $model->join_me = $post['join_me'];
        $model->zipcode = $post['zipcode'];
        $model->skype_id = $post['skype_id'];
        $model->facebook_url = $post['facebook_url'];
        $model->linkedin_url = $post['linkedin_url'];
        $model->twitter_url = $post['twitter_url'];
        $model->youtube_url = $post['youtube_url'];
        if (!empty($post['hourly_rate'])) {
            $model->hourly_rate = $post['hourly_rate'];
        }
        if ($model->save()) {
            return true;
        }
        return false;
    }

    public static function updateCompanyProfile($post) {
        $userId = Auth::user()->id;
        $model = User::where('id', $userId)->first();
        $model->first_name = ucwords(strtolower(trim($post['first_name'])));
        $model->last_name = ucwords(strtolower(trim($post['last_name'])));
        $model->mobile_number = $post['phone_number'];
        $model->company_name = ucwords(strtolower(trim($post['company_name'])));
        $model->address = ucfirst($post['address']);
        $model->country = $post['country'];
        $model->state = ucwords(strtolower($post['state']));
        $model->city = ucwords(strtolower($post['city']));
        $model->zipcode = $post['postal_code'];
        $model->industry_type = $post['industry_type'];
        $model->employee_strength = $post['employee_strength'];
        $model->website_url = $post['website_url'];
        $model->linkedin_url = $post['linkedin_url'];
        $model->facebook_url = $post['facebook_url'];
        $model->twitter_url = $post['twitter_url'];
        $model->spaciality = $post['speciality'];
        $model->about_us = $post['about_us'];
        if (!empty($post['banner_image'])) {
            \App\Helpers\Utility::unlinkMedia($model->banner_image, 'company/banner');
            $model->banner_image = $post['banner_image'];
        }
        if (!empty($post['video'])) {
            \App\Helpers\Utility::unlinkMedia($model->showcase_video, 'company/showcase');
            $model->showcase_video = $post['video'];
        }
        if ($model->save()) {
            return true;
        }
        return false;
    }

    public static function saveAboutExperience($data) {
        $model = User::where('id', Auth::user()->id)->first();
        if (!empty($model)) {
            $model->about_experience = $data['about_experience'];
        }
        if ($model->save()) {
            return true;
        }
        return false;
    }

    public static function getContactUserList($post) {
        $query = User::orderBy('id', 'DESC');
        if (!empty($post['data'])) {
            $query->where('user_type', $post['data']);
        }
        $userList = $query->get();
        return $userList;
    }

    public static function sendContactEmail($post) {
        if (!empty($post['users'])) {
            \Illuminate\Support\Facades\Mail::send([], [], function ($message) use ($post) {
                $message->to($post['users'])
                        ->subject($post['subject'])
                        ->from('testing@codiant.com', 'Rezieo')
                        ->setBody($post['content'], 'text/html');
            });
            return true;
        }
        return false;
    }

    public static function getUserId($type) {
        $data = \App\User::where('user_type', $type)->first();
        if (!empty($data)) {
            return $data->id;
        }
        return NULL;
    }

}
