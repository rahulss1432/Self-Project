<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Industry extends Model {

    protected $table = 'industries';

    public static function getIndustryById($id) {
        $model = Industry::where('id', $id)->first();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function getIndustryList($post) {
        $query = Industry::select('industries.*');
        if (!empty($post['status'])) {
            $query->where('status', $post['status']);
        }
        $query->orderBy('industry_name', 'ASC');
        $industryList = $query->get();
        return $industryList;
    }

    public static function getIndustryList_Admin($post) {
        $limit = env('RECORD_LIMIT', 10);
        $query = Industry::orderBy('industry_name', 'ASC');
        if (!empty($post['name'])) {
            $query->where('industry_name', 'like', '%' . $post['name'] . '%');
        }
        $industryList = $query->paginate($limit);
        return $industryList;
    }

    public static function addIndustry($post) {
        $model = new Industry();
        if (!empty($post['id'])) {
            $model = Industry::getIndustryById($post['id']);
        }
        $model->industry_name = ucwords(strtolower($post['industry_name']));
        $model->status = $post['status'];
        if ($model->save()) {
            return true;
        }
        return false;
    }

    public static function updateIndustryStatus($post) {
        if (!empty($post['id'])) {
            $model = Industry::getIndustryById($post['id']);
        }
        if ($model->status == 'enabled') {
            $model->status = 'disabled';
        } else {
            $model->status = 'enabled';
        }
        if ($model->save()) {
            return $model->status;
        }
        return false;
    }

    public static function deleteIndustry($id) {
        if (!empty($id)) {
            $model = Industry::getIndustryById($id);
            if ($model->delete()) {
                return true;
            }
        }
        return false;
    }

}
