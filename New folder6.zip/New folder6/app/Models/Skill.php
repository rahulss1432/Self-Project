<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Skill extends Model {

    protected $table = 'skills';

    public function getIndustry() {
        return $this->hasOne('App\Models\Industry', 'id', 'industry_id');
    }

    public static function getSkillById($id) {
        $model = Skill::where('id', $id)->first();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function getSkillsByIndustry($industryId) {
        $skillsList = Skill::where('industry_id', $industryId)
                ->where('status', 'enabled')
                ->orderBy('skill_name', 'ASC')
                ->get();
        return $skillsList;
    }

    public static function getSkillsList_Admin($post) {
        $limit = env('RECORD_LIMIT', 10);
        $query = Skill::select('skills.*', 'industries.industry_name')->join('industries', 'industries.id', '=', 'skills.industry_id');
        if (!empty($post['industry_id'])) {
            $query->where('industry_id', $post['industry_id']);
        }
        if (!empty($post['name'])) {
            $query->where('skill_name', 'like', '%' . $post['name'] . '%');
        }

        $skillsList = $query->paginate($limit);
        return $skillsList;
    }

    public static function addSkill($post) {
        $model = new Skill();
        if (!empty($post['id'])) {
            $model = Skill::getSkillById($post['id']);
        }
        $model->skill_name = ucwords(($post['skill_name']));
        $model->industry_id = $post['industry_name'];
        $model->status = $post['status'];
        if ($model->save()) {
            return true;
        }
        return false;
    }

    public static function updateSkillStatus($post) {
        if (!empty($post['id'])) {
            $model = Skill::getSkillById($post['id']);
        }
        if ($model->status == 'enabled') {
            $model->status = 'disabled';
        } else {
            $model->status = 'enabled';
        }
        if ($model->save()) {
            return $model->status;
        }
        return false;
    }

    public static function deleteSkill($id) {
        if (!empty($id)) {
            $model = Skill::getSkillById($id);
            if ($model->delete()) {
                return true;
            }
        }
        return false;
    }

}
