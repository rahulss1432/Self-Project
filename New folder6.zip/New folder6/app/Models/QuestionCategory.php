<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuestionCategory extends Model
{
    public function getQuestions() {
        return $this->hasMany('App\Models\Question', 'questionery_id', 'id');
    }
    
    public static function getCategoryList($post) {
        $limit = env('RECORD_LIMIT', 10);
        $query = QuestionCategory::orderBy('created_at', 'desc');
        if (!empty($post['name'])) {
            $query->where('name', 'like', '%' . $post['name'] . '%');
        }
        $questioneryList = $query->paginate($limit);
        return $questioneryList;
    }
    
    public static function getQuetionCategoryById($id) {
        $model = QuestionCategory::where('id', $id)->first();
        if ($model) {
            return $model;
        }
        return false;
    }
    
    public static function addQuestionCategory($post) {
        $model = new QuestionCategory();
        if (!empty($post['id'])) {
            $model = QuestionCategory::getQuetionCategoryById($post['id']);
        }
        $model->name = ucwords(strtolower(trim($post['name'])));
        if ($model->save()) {
            return true;
        }
        return false;
    }
    
    public static function deleteCategory($id) {
        if (!empty($id)) {
            $model = QuestionCategory::getQuetionCategoryById($id);
            if ($model->delete()) {
                return true;
            }
        }
        return false;
    }
}
