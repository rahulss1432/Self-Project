<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobSkill extends Model {
    
    public function getSkills() {
        return $this->hasOne('App\Models\Skill', 'id', 'skill_id');
    }

    public static function saveJobSkills($jobId, $skills) {
        foreach ($skills as $skill) {
            $model = new JobSkill();
            $model->job_id = $jobId;
            $model->skill_id = $skill;
            $model->save();
        }
        return true;
    }

    public static function getJobSkills($jobId) {
        return JobSkill::where('job_id', $jobId)->get();
    }

}
