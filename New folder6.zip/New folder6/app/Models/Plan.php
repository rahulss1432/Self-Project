<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Plan extends Model {

    protected $table = 'plans';

    public function getDetails() {
        return $this->hasMany('App\Models\PlanDetails', 'plan_id', 'id');
    }

    public static function getPlanById($id) {
        $model = Plan::where('id', $id)->first();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function getPlanList($post) {
        $query = Plan::where('status', 'enabled');
        if (!empty($post['user_type'])) {
            $query->where('user_type', $post['user_type']);
        }
        $query->orderBy('price', 'ASC');
        $planList = $query->get();
        return $planList;
    }

    public static function getPlanList_Admin($post) {
        $limit = env('RECORD_LIMIT', 10);
        $query = Plan::orderBy('user_type', 'ASC');
        if (!empty($post['user_type'])) {
            $query->where('user_type', $post['user_type']);
        }
        $planList = $query->paginate($limit);
        return $planList;
    }

    public static function addPlan($post) {
        $model = new Plan();
        if (!empty($post['id'])) {
            $model = Plan::getPlanById($post['id']);
        }
        $model->user_type = $post['user_type'];
        $model->plan_name = ucwords(strtolower(trim($post['plan_name'])));
        $model->price = round($post['price'], 2);
        $model->plan_duration = $post['plan_duration'];
        $model->video_duration = $post['video_duration'];
        if (isset($post['unlimited'])) {
            $model->jobs_limit = $post['unlimited'];
        } else {
            $model->jobs_limit = $post['jobs_limit'];
        }
        $model->status = $post['status'];
        if ($model->save()) {
            $planId = $model->id;
            if (!empty($post['description'])) {
                PlanDetails::where('plan_id', $planId)->delete();
                foreach ($post['description'] as $desc) {
                    if ($desc != '') {
                        $modelDetail = new PlanDetails();
                        $modelDetail->plan_id = $planId;
                        $modelDetail->description = $desc;
                        $modelDetail->save();
                    }
                }
                return true;
            }
            return true;
        }
        return false;
    }

    public static function updatePlanStatus($post) {
        if (!empty($post['id'])) {
            $model = Plan::getPlanById($post['id']);
        }
        if ($model->status == 'enabled') {
            $model->status = 'disabled';
        } else {
            $model->status = 'enabled';
        }
        if ($model->save()) {
            return $model->status;
        }
        return false;
    }

    public static function deletePlan($id) {
        if (!empty($id)) {
            $model = Plan::getPlanById($id);
            if ($model->delete()) {
                return true;
            }
        }
        return false;
    }

    public static function getPlanDropdown($userType) {
        $plans = Plan::where('user_type', $userType)->get();
        $html = '';
        $html .= '<option value="">Subscription Plan</option>';
        if (!empty($plans)) {
            foreach ($plans as $info) {
                $html .= '<option value="' . $info['id'] . '">' . $info['plan_name'] . '</option>';
            }
        }
        return $html;
    }

    public static function getBigPlan($price) {
        return Plan::where('user_type', \Illuminate\Support\Facades\Auth::user()->user_type)
                        ->where('status', 'enabled')
                        ->where('price', '>', $price)
                        ->first();
    }

}
