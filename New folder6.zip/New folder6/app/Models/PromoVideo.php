<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PromoVideo extends Model {

    protected $table = 'promo_video';

    public static function saveVideo($videoName) {
        $userplan =  PromoVideo::where('user_id',\Illuminate\Support\Facades\Auth::user()->id)->first();
        if(!empty($userplan)){
            \App\Helpers\Utility:: unlinkMedia($userplan->video_url,'promovideo');
             PromoVideo::where('id', $userplan->id)->delete();
        }
        $model = new PromoVideo();
        $model->user_id = \Illuminate\Support\Facades\Auth::user()->id;
        $model->video_url = $videoName;
        if ($model->save()) {
            return true;
        }
        return false;
    }
    
    public static function deletePromoVideo($id) {
        if (!empty($id)) {
            $model = PromoVideo::where('id', $id)->first();
            \App\Helpers\Utility:: unlinkMedia($model->video_url,'promovideo');
            if ($model->delete()) {
                return true;
            }
        }
        return false;
    }

}
