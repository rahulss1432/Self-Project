<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Notification extends Model {

    protected $table = 'notifications';

    public function getUser() {
        return $this->hasOne('App\Models\User', 'id', 'send_by');
    }

    public static function getNotifications($post) {
        $limit = env('RECORD_LIMIT', 1);
        $query = Notification::where('send_to', $post['userId']);

        if (!empty($post['status'])) {
            $query->where('status', $post['status']);
        }

        $query->orderBy('created_at', 'DESC');
        if (!empty($post['is_paginate'])) {
            $result = $query->paginate($limit);
        } else {
            $result = $query->get();
        }
        return $result;
    }

    public static function readNotification($post) {
        $result = Notification::where('send_to', $post['userId'])
                ->update(['status' => 'read']);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public static function viewProfileNotification($userId) {
        $loggedInUser = Auth::user()->id;
        $notification = Notification::where(['send_to' => $userId, 'send_by' => $loggedInUser, 'activity_type' => 'view_profile'])->first();
        if (empty($notification)) {
            if ($userId != $loggedInUser) {
                $model = new Notification();
                $model->send_to = $userId;
                $model->send_by = $loggedInUser;
                $model->message = '{name} viewed your profile.';
                ;
                $model->status = 'unread';
                $model->activity_type = 'view_profile';
                if ($model->save()) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function viewVideoNotification($userId) {
        $loggedInUser = Auth::user()->id;
        $notification = Notification::where(['send_to' => $userId, 'send_by' => $loggedInUser, 'activity_type' => 'view_video'])->first();
        if (empty($notification)) {
            if ($userId != $loggedInUser) {
                $model = new Notification();
                $model->send_to = $userId;
                $model->send_by = $loggedInUser;
                $model->message = '{name} viewed your video.';
                ;
                $model->status = 'unread';
                $model->activity_type = 'view_video';
                if ($model->save()) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function getProfileVideoViewList($post) {
        $query = Notification::select('notifications.*')
                ->where('send_to', $post['userId'])
                ->where('activity_type', $post['activity_type']);
        $query = $query->orderBy('created_at', 'DESC');
        if (!empty($post['is_pagination'])) {
            $data = $query->paginate(1);
        } else {
            $data = $query->limit(4)->get();
        }
        return $data;
    }

    public static function getProfileOrVideoViewsCount($activity_type, $userId) {
        $query = Notification::where('send_to', $userId)
                ->where('activity_type', $activity_type)
                ->get();
        return $query->count();
    }

    public static function viewSubadminNotification($subId, $userName) {
        $adminId = \App\Models\User::getUserId('admin');
        $model = new Notification();
        $model->send_to = $adminId;
        $model->send_by = $subId;
        $model->message = $userName . ' user status change by subadmin.';
        $model->status = 'unread';
        $model->icon = '';
        if ($model->save()) {
            return true;
        }
        return false;
    }

}
