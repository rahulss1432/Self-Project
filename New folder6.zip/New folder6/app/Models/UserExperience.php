<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class UserExperience extends Model {

    protected $table = 'user_experience';

    public static function getExperienceById($id) {
        $model = UserExperience::where('user_id', Auth::user()->id)
                ->where('id', $id)
                ->first();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function getUserExperience($userId) {
        $model = UserExperience::where('user_id', $userId)->get();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function addUserExperience($post) {
        $model = new UserExperience();
        if (!empty($post['id'])) {
            $model = UserExperience::getExperienceById($post['id']);
        }
        $model->user_id = Auth::user()->id;
        $model->title = ucwords(strtolower($post['title']));
        $model->company_name = ucwords(strtolower($post['company_name']));
        $model->duration_from = date("Y-m-d", strtotime($post['duration_form']));
        if (!empty($post['is_working'])) {
            $oldWorking = UserExperience::where('user_id', Auth::user()->id)->where('is_working', 'yes')->first();
            if (!empty($oldWorking)) {
                $oldWorking->is_working = 'no';
                $oldWorking->duration_to = date("Y-m-d");
                $oldWorking->save();
            }
            $model->is_working = 'yes';
        } else {
            $model->is_working = 'no';
            $model->duration_to = date("Y-m-d", strtotime($post['duration_to']));
        }
        if ($model->save()) {
            return true;
        }
        return false;
    }

    public static function deleteExperience($id) {
        if (!empty($id)) {
            $model = UserExperience::where('id', $id)->first();
            if ($model->delete()) {
                return true;
            }
        }
        return false;
    }

    public static function saveUserExperience($post) {
        if (self::addUserExperience($post)) {
            return true;
        }
        return false;
    }
    
    public static function getIsWorking($userId) {
        $model = UserExperience::where('user_id', $userId)
                ->where('is_working', 'yes')
                ->first();
        if ($model) {
            return $model;
        }
        return false;
    }

}
