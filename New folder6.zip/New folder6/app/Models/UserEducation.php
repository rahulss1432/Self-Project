<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class UserEducation extends Model {

    public static function getUserEducation() {
        $model = UserEducation::where('user_id', Auth::user()->id)->get();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function getEducationById($Id) {
        $model = UserEducation::where('id', $Id)->first();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function addUserEducation($post) {
        $model = new UserEducation();
        if (!empty($post['id'])) {
            $model = UserEducation::getEducationById($post['id']);
        }
        $model->user_id = Auth::user()->id;
        $model->university = ucwords(strtolower($post['university']));
        $model->degree = ucwords(strtolower($post['degree']));
        $model->course_name = ucwords(strtolower($post['minor']));
        $model->duration_from = date("Y-m-d", strtotime($post['duration_form']));
        if (!empty($post['is_working'])) {
            $oldWorking = UserEducation::where('user_id', Auth::user()->id)->where('is_working', 'yes')->first();
            if (!empty($oldWorking)) {
                $oldWorking->is_working = 'no';
                $oldWorking->duration_to = date("Y-m-d");
                $oldWorking->save();
            }
            $model->is_working = 'yes';
        } else {
            $model->is_working = 'no';
            $model->duration_to = date("Y-m-d", strtotime($post['duration_to']));
        }
        if ($model->save()) {
            return true;
        }
        return false;
    }

    public static function deleteEducation($id) {
        if (!empty($id)) {
            $model = UserEducation::where('id', $id)->first();
            if ($model->delete()) {
                return true;
            }
        }
        return false;
    }
    
    public static function getIsWorking($userId) {
        $model = UserEducation::where('user_id', $userId)
                ->where('is_working', 'yes')
                ->first();
        if ($model) {
            return $model;
        }
        return false;
    }

}
