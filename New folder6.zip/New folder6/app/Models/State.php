<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class State extends Model {

    protected $table = 'states';

    public function getCountry() {
        return $this->hasOne('App\Models\Country', 'id', 'country_id');
    }

    public static function getStateByCountry($countryId) {
        $stateList = State::where('country_id', $countryId)
                ->where('status', 'enabled')
                ->orderBy('state_name', 'ASC')
                ->get();
        return $stateList;
    }

    public static function getStateList_Admin() {
        $limit = env('RECORD_LIMIT', 10);
        $stateList = State::whereHas('getCountry', function($q) {
                    $q->orderBy('countries.country_name', 'ASC');
                })
                ->paginate($limit);
        return $stateList;
    }

}
