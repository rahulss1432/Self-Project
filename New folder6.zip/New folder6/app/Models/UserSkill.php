<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use DB;

class UserSkill extends Model {

    public function getSkill() {
        return $this->hasOne('App\Models\Skill', 'id', 'skill_id');
    }

    public function getUser() {
        return $this->hasOne('App\Models\User', 'id', 'user_id');
    }

    public static function getUserSkills($userId) {
        $model = UserSkill::where('user_id', $userId)->get();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function saveUserSkills($post) {
        if (!empty($post['skills'])) {
            UserSkill::where('user_id', Auth::user()->id)->delete();
            foreach ($post['skills'] as $skill) {
                $model = new UserSkill();
                $model->user_id = Auth::user()->id;
                $model->skill_id = $skill;
                $model->save();
            }
            return true;
        }
        return false;
    }

//    DB::Raw(DB::select('SELECT sum(DATEDIFF(`durationTo`,`duration_from`)) as dayCount  FROM
//    (SELECT (CASE
//        WHEN `duration_to` IS NULL THEN CURDATE()
//        ELSE `duration_to` END) as `durationTo`,`duration_from` from user_experience ) as days'))
    public static function getMatchedCandidatesList($post) {
        $query = UserSkill::select('user_skills.user_id', DB::Raw('(SELECT sum(DATEDIFF(`durationTo`,`duration_from`)) '
                . 'FROM (SELECT (CASE WHEN `duration_to` IS NULL THEN CURDATE() ELSE `duration_to` END) as durationTo,`duration_from` '
                . 'from user_experience) as days) as days'))
                ->join('job_skills', 'user_skills.skill_id', '=', 'job_skills.skill_id')
                ->where('job_skills.job_id', $post['job_id'])
                ->groupBy('user_skills.user_id');

        if (!empty($post['location'])) {
            $query->whereHas('getUser', function ($query1) use ($post) {
                $query1->where('city', $post['location']);
            });
        }

        if (!empty($post['candidate_type'])) {
            $query->whereHas('getUser', function ($query1) use ($post) {
                $query1->where('user_type', $post['candidate_type']);
            });
        }
        
//        if (!empty($post['experience'])) {
//            $query->whereHas('getUser', function ($query1) use ($post) {
//                $query1->where('user_type', $post['candidate_type']);
//            });
//        }
        $candidateList = $query->paginate(9);
//        echo $sql = $query->toSql();
        return $candidateList;
    }

}
