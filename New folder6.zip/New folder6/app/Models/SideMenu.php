<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SideMenu extends Model {

    protected $table = 'side_menus';

    public static function saveSideMenu($post){
       
        $data = self::get();
        foreach ($data as $key) {
            $key = $key['menu_key'];
            $model = self::where('menu_key', $key)->first();  
            $model->menu_name = $post[$key];
            $model->save();
        };  
         return true;
    }
  
}
