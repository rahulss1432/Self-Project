<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Language extends Model {

    protected $table = 'languages';

    public static function getLanguageById($id) {
        $model = Language::where('id', $id)->first();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function getLanguageList($post) {
        $query = Language::select('languages.*');
        if (!empty($post['status'])) {
            $query->where('status', $post['status']);
        }
        $query->orderBy('title', 'ASC');
        $languageList = $query->get();
        return $languageList;
    }

    public static function getLanguageList_Admin($post) {
        $limit = env('RECORD_LIMIT', 10);
        $query = Language::orderBy('title', 'ASC');
        if (!empty($post['txtSearch'])) {
            $query->where('title', 'like', '%' . $post['txtSearch'] . '%');
        }
        $languageList = $query->paginate($limit);
        return $languageList;
    }

    public static function addLanguage($post) {
        $model = new Language();
        if (!empty($post['id'])) {
            $model = Language::getLanguageById($post['id']);
        }
        $model->title = ucwords(strtolower($post['title']));
        $model->status = $post['status'];
        if ($model->save()) {
            return true;
        }
        return false;
    }

    public static function updateLanguageStatus($post) {
        if (!empty($post['id'])) {
            $model = Language::getLanguageById($post['id']);
        }
        if ($model->status == 'enabled') {
            $model->status = 'disabled';
        } else {
            $model->status = 'enabled';
        }
        if ($model->save()) {
            return $model->status;
        }
        return false;
    }

    public static function deleteLanguage($id) {
        if (!empty($id)) {
            $model = Language::getLanguageById($id);
            if ($model->delete()) {
                return true;
            }
        }
        return false;
    }

}
