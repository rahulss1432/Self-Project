<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserType extends Model {

    protected $table = 'user_type';

    public static function getUserTypeId($user_type) {
        $model = UserType::where('user_type', $user_type)->first();
        if ($model) {
            return $model;
        }
        return false;
    }

    public static function getListedType() {
        $userTypes = UserType::where('listed', 'yes')->get();
        return $userTypes;
    }

}
