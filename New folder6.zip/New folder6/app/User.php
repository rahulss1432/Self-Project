<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Helpers\MailUtility;
use \Illuminate\Support\Facades\Request;

class User extends Authenticatable {

    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public static function sendPasswordResetToken($email) {
        $userInfo = User::where('email', $email)->first();
        if (!empty($userInfo)) {
            $data = array();
            $token = Helpers\Utility::generateRandomString();
            $data['email'] = $userInfo->email;
            $data['name'] = $userInfo->first_name . ' ' . $userInfo->last_name;
            $data['link'] = url('/reset-password/' . $token);
            if ($userInfo->user_type == 'admin' || $userInfo->user_type == 'sub_admin') {
                $data['link'] = url('admin/reset-password/' . $token);
            }
            $data['request'] = 'forgot_password';
            $userInfo->remember_token = $token;
            if ($userInfo->save()) {
                MailUtility::sendMail($data);
                return true;
            }
        }
        return false;
    }

    public static function changePassword($post) {
        $userId = $post['userId'];
        $model = User::find($userId);
        if (!empty($model)) {
            $model->password = bcrypt($post['password']);
            $model->remember_token = NULL;
            if ($model->save()) {
                return true;
            }
        }
        return false;
    }

    public static function getUserByToken($token) {
        return User::where('remember_token', $token)
                        ->first();
    }

    public static function UserRegistration($post) {
        $userInfo = Models\User::where('email', $post['email'])->first();
        if (empty($userInfo)) {
            $token = Helpers\Utility::generateRandomString();
            $model = new User();
            $model->user_type = $post['user_type'];
            $model->first_name = ucwords(strtolower($post['first_name']));
            $model->last_name = ucwords(strtolower($post['last_name']));
            $model->email = $post['email'];
            if (!empty($post['password'])) {
                $model->password = bcrypt($post['password']);
                $model->remember_token = $token;
            }
            $model->social_id = (!empty($post['social_id'])) ? $post['social_id'] : NULL;
            $model->signup_by = (!empty($post['signup_by'])) ? $post['signup_by'] : 'website';
            $model->profile_image = (!empty($post['profile_image'])) ? $post['profile_image'] : NULL;
            $model->country = (!empty($post['country'])) ? $post['country'] : NULL;
            $model->email_status = $post['email_status'];
            if ($model->save()) {
                if ($model->email_status == 'pending') {
                    $data = array();
                    $token = $model->remember_token;
                    $data['email'] = $model->email;
                    $data['name'] = $model->first_name . ' ' . $model->last_name;
                    $data['link'] = url('/user-verification/' . $token);
                    $data['request'] = 'user_verification';
                    MailUtility::sendMail($data);
                    session()->flash('success', 'Email verification');
                    session()->flash('message', "We have e-mailed your email verification link!");
                }
                return $model;
            }
        }
        return false;
    }

}
