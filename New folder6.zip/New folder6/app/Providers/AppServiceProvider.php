<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use \App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use JWTAuth;

class AppServiceProvider extends ServiceProvider {

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot() {
        Schema::defaultStringLength(191);

        Validator::extend('validate_skill', function ($attribute, $value, $parameters, $validator) {
            $industry_id = request()->industry_name;
            $category = \App\Models\Skill::where('skill_name', '=', $value)->where('industry_id', '=', $industry_id)->first();
            if (empty($category)) {
                return true;
            } else {
                return false;
            }
        });
        Validator::extend('edit_validate_skill', function ($attribute, $value, $parameters, $validator) {
            $industry_id = request()->industry_name;
            $category = \App\Models\Skill::where('skill_name', '=', $value)
                    ->where('industry_id', '=', $industry_id)
                    ->where('id', '!=', request()->id)
                    ->first();
            if (empty($category)) {
                return true;
            } else {
                return false;
            }
        });

        Validator::extend('validate_plan', function ($attribute, $value, $parameters, $validator) {
            $user_type = request()->user_type;
            $category = \App\Models\Plan::where('plan_name', '=', $value)->where('user_type', '=', $user_type)->first();
            if (empty($category)) {
                return true;
            } else {
                return false;
            }
        });
        Validator::extend('edit_validate_plan', function ($attribute, $value, $parameters, $validator) {
            $user_type = request()->user_type;
            $category = \App\Models\Plan::where('plan_name', '=', $value)
                    ->where('user_type', '=', $user_type)
                    ->where('id', '!=', request()->id)
                    ->first();
            if (empty($category)) {
                return true;
            } else {
                return false;
            }
        });

        Validator::extend('current_password', function ($attribute, $value, $parameters, $validator) {
            if (!empty(Auth::guard(request()->guard)->user()->id)) {
                $password = Auth::guard(request()->guard)->user()->password;
            }
            return \Illuminate\Support\Facades\Hash::check($value, $password);
        });

        Validator::extend('validate_email', function ($attribute, $value, $parameters, $validator) {
            $user = User::where('email', '=', $value)->first();
            if (!empty($user)) {
                return true;
            } else {
                return false;
            }
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register() {
        //
    }

}
