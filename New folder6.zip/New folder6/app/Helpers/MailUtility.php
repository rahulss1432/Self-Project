<?php

namespace App\Helpers;

use Illuminate\Support\Facades\Mail;

class MailUtility {

    public static function sendMail($data) {

        $data['fromEmail'] = 'testing@codiant.com';
        $data['fromName'] = 'Rezio';
        $data['regards'] = 'Rezio Team';

        switch ($data['request']) {
            case "forgot_password":
                return Mail::send('email-templates.password-reset-link', ['data' => $data], function ($message) use ($data) {
                            $message->to($data['email'])
                                    ->subject('Reset Password')
                                    ->from($data['fromEmail'], $data['fromName']);
                        });
                break;
            case "user_verification":
                return Mail::send('email-templates.verify-email-link', ['data' => $data], function ($message) use ($data) {
                            $message->to($data['email'])
                                    ->subject('Email verification')
                                    ->from($data['fromEmail'], $data['fromName']);
                        });
                break;
            case "plan_invoice":
                return Mail::send('email-templates.invoice', ['data' => $data], function ($message) use ($data) {
                            $message->to($data['email'])
                                    ->subject('Invoice')
                                    ->from($data['fromEmail'], $data['fromName']);
                        });
                break;
             case "update_user_profile":
                return Mail::send('email-templates.update_user_profile', ['data' => $data], function ($message) use ($data) {
                            $message->to($data['email'])
                                    ->subject('Rezieo admin has updated your account.')
                                    ->from($data['fromEmail'], $data['fromName']);
                        });
                break;
            default:
                return false;
        }
        return false;
    }

}
