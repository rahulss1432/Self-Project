<?php

namespace App\Helpers;

use Illuminate\Pagination\UrlWindow;

class Utility {

    public static function getDatePickerForamt() {
        return 'DD-MM-YYYY';
    }

    public static function checkProfileImage($image) {
        $src = url('public/images/default-user.png');
        $fileName = public_path() . '/uploads/user/' . $image;
        if (!empty($image) && file_exists($fileName)) {
            $src = url('public/uploads/user/' . $image);
        }
        return $src;
    }

    public static function checkCompanyLogo($image) {
        $src = url('public/images/default-user.png');
        $fileName = public_path() . '/uploads/company/logo/' . $image;
        if (!empty($image) && file_exists($fileName)) {
            $src = url('public/uploads/company/logo/' . $image);
        }
        return $src;
    }

    public static function checkCompanyBanner($image) {
        $src = url('public/images/default-user.png');
        $fileName = public_path() . '/uploads/company/banner/' . $image;
        if (!empty($image) && file_exists($fileName)) {
            $src = url('public/uploads/company/banner/' . $image);
        }
        return $src;
    }
    
    public static function checkTestimonialImage($image) {
        $src = url('public/images/default-user.png');
        $fileName = public_path() . '/uploads/testimonial/' . $image;
        if (!empty($image) && file_exists($fileName)) {
            $src = url('public/uploads/testimonial/' . $image);
        }
        return $src;
    }

    public static function getLimitText($limit, $text) {
        $string = substr($text, 0, $limit);
        if (strlen($text) > $limit) {
            $string .= '...';
        };
        return $string;
    }

    public static function getAdminPaginationDiv($listArray) {
        echo $listArray->links('vendor.pagination.default');
    }

    public static function buttonLoader() {
        echo '<span id="button-loader" class="fa fa-spinner fa-spin"></span>';
    }

    public static function ajaxLoader() {
        echo '<div class="listloader text-center"><i class="fa fa-spin fa-spinner fa-2x"></i></div>';
    }

    public static function emptyListMessage($type) {
        echo '<div class="alert alert-danger mb-0 text-center">Sorry! we could not find any ' . ($type) . '.</div>';
    }

    public static function getInputDateFormat($date) {
        if (strtotime($date) > 0) {
            return date("d-m-Y", strtotime($date));
        }
        return '';
    }

    public static function getDateFormat($date) {
        if (strtotime($date) > 0) {
            return date("d-m-Y", strtotime($date));
        }
        return '-';
    }

    public static function getDateTimeFormat($date) {
        if (strtotime($date) > 0) {
            return date("d-m-y h:i A", strtotime($date));
        }
        return '-';
    }

    public static function getPriceFormat($price) {
        return '$' . number_format($price, 2);
    }

    public static function getTimeFormat($time) {
        if (strtotime($time) > 0) {
            return date("h:i A", strtotime($time));
        }
        return '-';
    }

    public static function makeSlug($text) {
        // replace non letter or digits by -
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);
        // transliterate
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
        // remove unwanted characters
        $text = preg_replace('~[^-\w]+~', '', $text);
        // trim
        $text = trim($text, '-');
        // remove duplicate -
        $text = preg_replace('~-+~', '-', $text);
        // lowercase
        $text = strtolower($text);
        return $text;
    }

    public static function unlinkMedia($file_name, $folder) {
        if (!empty($file_name)) {
            $destinationPath = public_path() . '/uploads/' . $folder . '/';
            if (file_exists($destinationPath . $file_name)) {
                unlink($destinationPath . $file_name);
            }
        }
    }

    public static function changeTimeAgo($val) {
        $full = false;
        $now = new \DateTime(date('Y-m-d H:i:s'));
        $ago = new \DateTime($val);
        $diff = $now->diff($ago);
        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;
        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }
        if (!$full)
            $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }

    public static function generateRandomString($length = 60) {
        return substr(str_shuffle(str_repeat($x = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / strlen($x)))), 1, $length);
    }

    public static function getSocialProfileImage($url, $uid) {
        $upload_path = public_path() . '/uploads/user/';
        if (!is_dir($upload_path)) {
            File::makeDirectory($upload_path, $mode = 0777, true, true);
        }
        $ch = curl_init();
        $user_agent = 'Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0';
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 120);
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        // Download the given URL, and return output
        $data = curl_exec($ch);
        curl_close($ch);
        $file = $upload_path . $uid . '.jpg';
        $profile_image = $uid . '.jpg';
        file_put_contents($file, $data);
        return $profile_image;
    }

}
