<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Stripe, Mailgun, SparkPost and others. This file provides a sane
    | default location for this type of information, allowing packages
    | to have a conventional place to find your various credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
    ],

    'ses' => [
        'key' => env('SES_KEY'),
        'secret' => env('SES_SECRET'),
        'region' => 'us-east-1',
    ],

    'sparkpost' => [
        'secret' => env('SPARKPOST_SECRET'),
    ],

    'stripe' => [
        'model' => App\User::class,
        'key' => env('STRIPE_KEY'),
        'secret' => env('STRIPE_SECRET'),
    ],
    'facebook' => [
        'client_id' => '299010727553276',
        'client_secret' => '5ba8b42f6ccd55e9e19d1c03d90a43fc',
        'redirect' => env('APP_URL') . '/auth/facebook/callback',
    ],
    'linkedin' => [
        'client_id' => '78amwnp5mc6yf9',
        'client_secret' => '5uWrffbnXe6dt9c4',
        'redirect' =>  env('APP_URL') . '/auth/linkedin/callback'
    ],

];
