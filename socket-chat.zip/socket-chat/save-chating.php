<?php
$hostName = 'localhost';
$userName = 'root';
$password = '';
$dataBaseName = 'test_db';
session_start();

$connection = mysqli_connect($hostName, $userName, $password, $dataBaseName);
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$fromId = $_POST['from_id'];
$toId = $_POST['to_id'];
$message = $_POST['message'];

$sql = 'INSERT INTO chat_message(from_id,to_id,message)VALUES("'.$fromId.'","'.$toId.'","'.$message.'")';

if (mysqli_query($connection, $sql)) {
    echo "success";
 } else {
    echo "Error: " . $sql . "" . mysqli_error($connection);
 }

?>