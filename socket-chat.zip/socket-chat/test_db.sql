-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2019 at 12:03 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_message`
--

CREATE TABLE `chat_message` (
  `id` int(11) NOT NULL,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_message`
--

INSERT INTO `chat_message` (`id`, `from_id`, `to_id`, `message`, `created_at`, `updated_at`) VALUES
(1, 3, 2, 'hello', '2019-03-09 09:37:44', '0000-00-00 00:00:00'),
(2, 3, 2, 'dfgdgsdfg', '2019-03-09 09:37:49', '0000-00-00 00:00:00'),
(3, 2, 3, 'dfgsdfg', '2019-03-09 09:37:51', '0000-00-00 00:00:00'),
(4, 2, 3, 'dfgsdfg', '2019-03-09 09:38:01', '0000-00-00 00:00:00'),
(5, 3, 1, 'sdfasdf', '2019-03-09 09:39:07', '0000-00-00 00:00:00'),
(6, 3, 1, 'dfasdfasdf', '2019-03-09 09:39:12', '0000-00-00 00:00:00'),
(7, 1, 3, 'sadfasdf', '2019-03-09 09:39:13', '0000-00-00 00:00:00'),
(8, 1, 3, 'sdfasdf', '2019-03-09 09:39:15', '0000-00-00 00:00:00'),
(9, 1, 3, 'sadfasdf', '2019-03-09 09:39:16', '0000-00-00 00:00:00'),
(10, 1, 3, 'sadfasdf', '2019-03-09 09:39:17', '0000-00-00 00:00:00'),
(11, 2, 4, 'dfghdfgh', '2019-03-09 09:39:24', '0000-00-00 00:00:00'),
(12, 2, 4, 'fsghfdgh', '2019-03-09 09:39:25', '0000-00-00 00:00:00'),
(13, 2, 4, 'dfghdfgh', '2019-03-09 09:39:26', '0000-00-00 00:00:00'),
(14, 2, 4, 'ghjfghj', '2019-03-09 09:39:32', '0000-00-00 00:00:00'),
(15, 2, 4, 'ghjfghj', '2019-03-09 09:39:34', '0000-00-00 00:00:00'),
(16, 2, 4, 'fghjfgh', '2019-03-09 09:39:36', '0000-00-00 00:00:00'),
(17, 2, 4, 'fghjfghj', '2019-03-09 09:39:37', '0000-00-00 00:00:00'),
(18, 2, 4, 'ghjfghj', '2019-03-09 09:39:41', '0000-00-00 00:00:00'),
(19, 2, 4, 'fghjfghj', '2019-03-09 09:39:42', '0000-00-00 00:00:00'),
(20, 2, 4, 'fghjfghj', '2019-03-09 09:39:44', '0000-00-00 00:00:00'),
(21, 2, 4, 'fghjfghj', '2019-03-09 09:39:45', '0000-00-00 00:00:00'),
(22, 2, 4, 'fghjfghj', '2019-03-09 09:39:47', '0000-00-00 00:00:00'),
(23, 1, 3, 'fghdfgh', '2019-03-09 09:40:04', '0000-00-00 00:00:00'),
(24, 3, 1, 'fdghdfgh', '2019-03-09 09:40:05', '0000-00-00 00:00:00'),
(25, 3, 1, 'fdghdfgh', '2019-03-09 09:40:09', '0000-00-00 00:00:00'),
(26, 1, 3, 'dfghdfgh', '2019-03-09 09:40:12', '0000-00-00 00:00:00'),
(27, 3, 1, 'fdghfdgh', '2019-03-09 09:40:15', '0000-00-00 00:00:00'),
(28, 3, 1, 'dfghfdghdfgh', '2019-03-09 09:40:18', '0000-00-00 00:00:00'),
(29, 2, 4, 'fdghfdhfdgh', '2019-03-09 09:40:32', '0000-00-00 00:00:00'),
(30, 2, 4, 'dfgsdfgsdfg', '2019-03-09 09:40:44', '0000-00-00 00:00:00'),
(31, 2, 1, 'sfdgsdfg', '2019-03-09 09:40:50', '0000-00-00 00:00:00'),
(32, 2, 1, 'dfgsdfg', '2019-03-09 09:40:56', '0000-00-00 00:00:00'),
(33, 2, 1, 'dfgsdfg', '2019-03-09 09:41:02', '0000-00-00 00:00:00'),
(34, 2, 1, 'dfgsdfg', '2019-03-09 09:41:03', '0000-00-00 00:00:00'),
(35, 1, 2, 'sdfgsdfg', '2019-03-09 09:41:05', '0000-00-00 00:00:00'),
(36, 1, 2, 'dfgsdfg', '2019-03-09 09:41:07', '0000-00-00 00:00:00'),
(37, 1, 2, 'xcbcxvbcxvb', '2019-03-09 09:41:11', '0000-00-00 00:00:00'),
(38, 1, 2, 'cxvbxcvb', '2019-03-09 09:41:14', '0000-00-00 00:00:00'),
(39, 1, 4, 'fghdfghfdgh', '2019-03-09 09:42:50', '0000-00-00 00:00:00'),
(40, 3, 4, 'dfghdfgh', '2019-03-09 09:42:52', '0000-00-00 00:00:00'),
(41, 3, 4, 'fsgsdfg', '2019-03-09 09:42:54', '0000-00-00 00:00:00'),
(42, 3, 4, 'sdfgsdfgdfg', '2019-03-09 09:42:58', '0000-00-00 00:00:00'),
(43, 1, 4, 'sdfgsdfg', '2019-03-09 09:43:00', '0000-00-00 00:00:00'),
(44, 1, 4, 'sdfgsdfg', '2019-03-09 09:43:02', '0000-00-00 00:00:00'),
(45, 3, 4, 'sdfgsdfg', '2019-03-09 09:43:03', '0000-00-00 00:00:00'),
(46, 3, 4, 'fdgsdfg', '2019-03-09 09:43:07', '0000-00-00 00:00:00'),
(47, 3, 1, 'dfgsdfg', '2019-03-09 09:43:14', '0000-00-00 00:00:00'),
(48, 3, 1, 'sdfgsdfg', '2019-03-09 09:43:16', '0000-00-00 00:00:00'),
(49, 1, 3, 'sdfgsdfgsdfg', '2019-03-09 09:43:19', '0000-00-00 00:00:00'),
(50, 1, 3, 'sfdgsdfgsdfg', '2019-03-09 09:43:21', '0000-00-00 00:00:00'),
(51, 1, 3, 'dsfgsdfg', '2019-03-09 09:43:24', '0000-00-00 00:00:00'),
(52, 1, 3, 'sdfgsdfg', '2019-03-09 09:43:27', '0000-00-00 00:00:00'),
(53, 3, 1, 'fdgsdfg', '2019-03-09 09:43:30', '0000-00-00 00:00:00'),
(54, 1, 3, 'sdfgsdfg', '2019-03-09 09:43:33', '0000-00-00 00:00:00'),
(55, 1, 5, 'dfgsdfg', '2019-03-09 09:48:23', '0000-00-00 00:00:00'),
(56, 1, 5, 'gsdfgsdfg', '2019-03-09 09:48:26', '0000-00-00 00:00:00'),
(57, 1, 5, 'dfgsdfgggggggggggggggggggggggg', '2019-03-09 09:48:29', '0000-00-00 00:00:00'),
(58, 1, 5, 'xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc', '2019-03-09 09:48:35', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` text,
  `password` text,
  `profile_image` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `profile_image`, `created_at`, `updated_at`) VALUES
(1, 'sumit patidar', 'sumit@gmail.com', '123456', 'agent-2.jpg', '2019-03-08 09:44:00', '0000-00-00 00:00:00'),
(2, 'rahul solanki', 'rahul@gmail.com', '123456', 'agent-3.jpg', '2019-03-08 09:44:03', '0000-00-00 00:00:00'),
(3, 'ganesh suryawansi', 'ganesh@gmail.com', '123456', 'agent-4.jpg', '2019-03-08 09:44:07', '0000-00-00 00:00:00'),
(4, 'neeraj upadhayay', 'neeraj@gmail.com', '123456', 'img-1.jpg', '2019-03-08 09:44:10', '0000-00-00 00:00:00'),
(5, 'mayank ', 'mayank@gmail.com', '123456', 'jon.jpg', '2019-03-08 09:44:14', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_salary`
--

CREATE TABLE `user_salary` (
  `id` int(11) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `salary` varchar(250) DEFAULT NULL,
  `amount` varchar(250) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_salary`
--

INSERT INTO `user_salary` (`id`, `name`, `salary`, `amount`, `created_at`, `updated_at`) VALUES
(1, 'test1', '3000', '3000', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'test2', '4000', '4000', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'test3', '5000', '5000', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'test4', '6000', '6000', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'test5', '7000', '7000', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'test6', '8000', '8000', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_message`
--
ALTER TABLE `chat_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_salary`
--
ALTER TABLE `user_salary`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_message`
--
ALTER TABLE `chat_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_salary`
--
ALTER TABLE `user_salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
