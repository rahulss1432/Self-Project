<?php
 session_start();
 if(!isset( $_SESSION['id'])){
?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <link href="http://localhost/socket-chat/login-from.css" rel="stylesheet">
<!------ Include the above in your HEAD tag ---------->

<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Login Form -->
    <form id="login-from" action="javascript:void(0)" method="POST" >
      <input type="text" id="email" class="fadeIn second" name="email" placeholder="email">
      <input type="text" id="password" class="fadeIn third" name="password" placeholder="password">
      <div id="validation-msg"> </div>
      <input onclick="loginUser()" type="submit" class="fadeIn fourth" value="Log In">
    </form>
   </div>
</div>
<script>
    function loginUser(){
          var fromData = $("#login-from").serialize(); 
          $.ajax({
             url: 'http://localhost/socket-chat/auth-login.php',
             type:'POST',
             data: fromData, 
             success:function(response){
                 if(response == 'validation'){
                    $('#validation-msg').html('not a valid user');    
                 }else if(response == 'success'){
                    alert('Login Successfully!')
                    window.location.href = "./chating.php";
                }
             }
         });  
      }
</script>
 <?php 
 }else{
   header("Location:chating.php");
 }
 ?>