<?php
 session_start();
 if(isset( $_SESSION['id'])){
 $loginUserId = $_SESSION['id'];
?>
<html>
    <head>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.0.4/socket.io.js"></script>
        <script src="https://code.jquery.com/jquery-1.11.1.js"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" type="text/css" rel="stylesheet">
        <link href="http://localhost/socket-chat/chat-from.css" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <h3 class=" text-center">Messaging</h3>
            <div class="messaging">
                <div class="inbox_msg">
                    <div class="inbox_people">
                        <div class="headind_srch">
                            <div class="recent_heading">
                                <h4>Recent</h4>
                            </div>
                            <div class="srch_bar">
                                <div class="stylish-input-group">
                                    <input type="text" class="search-bar"  placeholder="Search" >
                                    <span class="input-group-addon">
                                        <button type="button"> <i class="fa fa-search" aria-hidden="true"></i> </button>
                                    </span> </div>
                            </div>
                        </div>
                        <div class="inbox_chat">
                            <!--user-list--> 
                            <div id="get-user-list"></div>
                        </div>
                    </div>
                    <div class="mesgs">
                        <div id="get-message-list">
                            <h1 class="aligment-center"> WEL-COME</h1>
                            <!--get-message-list-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            var loginUser = '<?php echo $loginUserId; ?>';
            var socket = io.connect('http://localhost:3000');
            $(document).ready(function () {
                getUserLIst();
                socket.emit('setUsername', loginUser)
            })
            
            socket.on('res-message', function(response){
                   if(response.from_id == loginUser){
                        $('#user-message-box-'+ response.to_id).append('<div class="outgoing_msg"><div class="sent_msg">\n\
                                                    <p>'+response.message+'</p>\n\
                                                  <span class="time_date">2019-03-09 14:08:53</span></div>\n\
                                                </div>');
                   }else if(response.to_id == loginUser){
                       $('#user-message-box-'+response.from_id).append('<div class="incoming_msg"><div class="received_msg">\n\
                                                    <div class="received_withd_msg">\n\
                                                       <p>'+response.message+'</p>\n\
                                                        <span class="time_date">2019-03-09 14:34:08</span>\n\
                                                       </div></div>\n\
                                                 </div>');
                   }
            });
            
            socket.on('typing', function(response){
                if(response.to_id == loginUser){
                    $('#user-typing-'+response.from_id).html('typing...')
                }
            });
            
            socket.on('typing-hide', function(response){
                if(response.to_id == loginUser){
                    $('#user-typing-'+response.from_id).html(' ')
                }
            });
            
            socket.on('set-online', function(response){             
                if(response != loginUser){
                    $('#user-online-'+ response).html('Online');
                }
            });
            
            $(document).on('keyup', '#message', function(event){
                      var userData = {};
                        userData['from_id'] = $('#from_id').val();
                        userData['to_id'] = $('#to_id').val();
                       socket.emit('is typing', userData);
              });
              
             $(document).on('blur', '#message', function(event){
                       var userData = {};
                        userData['from_id'] = $('#from_id').val();
                        userData['to_id'] = $('#to_id').val();
                       socket.emit('typing-stop', userData);
              }); 
            
            
            function sendMessage(){
                if($('#message').val() !=''){
                    var formData = $("#save-chat-message").serialize();
                    $.ajax({
                        url: 'http://localhost/socket-chat/save-chating.php',
                        type:'POST',
                        data:formData,
                        success:function(response){
                            if(response == 'success'){
                                var userData = {};
                                userData['from_id'] = $('#from_id').val();
                                userData['to_id'] = $('#to_id').val();
                                userData['message'] = $('#message').val();
                                socket.emit('send-message', userData);
                                $('#message').val('');
                                return true;
                            }else{
                                return false;                    
                            }
                         }
                     });     
                }
            }
            
            function getUserLIst(){
              $.ajax({
                  url: 'http://localhost/socket-chat/_user-list.php',
                  type:'GET',
                  success:function(response){
                      $('#get-user-list').html(response);
                  }
              });      
            }
            
            function getMessageList(id){
               $.ajax({
                  url: 'http://localhost/socket-chat/_message-list.php',
                  type:'GET',
                  data:{id:id},
                  success:function(response){
                      $('#get-message-list').html(response);
                  }
              });  
            }
            
        </script>  
    </body>
</html>
 <?php 
 }else{
   header("Location:index.php");
 }
 ?>