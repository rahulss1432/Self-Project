<?php
header("Access-Control-Allow-Origin: *");

$hostName = 'localhost';
$userName = 'root';
$password = '';
$dataBaseName = 'test_db';
session_start();
$connection = mysqli_connect($hostName, $userName, $password, $dataBaseName);
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$email = $_POST['email'];
$pass = $_POST['password'];

$sql = 'SELECT * FROM user WHERE email="'.$email.'" AND password="'.$pass.'"';
$result = mysqli_query($connection, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $_SESSION['id'] = $row['id'];
    $_SESSION['name'] = $row['name'];
    $_SESSION['profile_image'] = $row['profile_image'];
    echo 'success';
}else{
    echo  'validation';
}

?>