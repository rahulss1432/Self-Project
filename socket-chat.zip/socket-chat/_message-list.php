<?php
$hostName = 'localhost';
$userName = 'root';
$password = '';
$dataBaseName = 'test_db';

$connection = mysqli_connect($hostName, $userName, $password, $dataBaseName);
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

session_start();
$loginUserId = $_SESSION['id'];
$selectUserId = $_GET['id'];

$sql = 'SELECT * FROM  chat_message WHERE (from_id="' . $loginUserId . '" AND to_id="' . $selectUserId . '" OR from_id="' . $selectUserId . '" AND to_id="' . $loginUserId . '")';
$result = mysqli_query($connection, $sql);
?>
<div class="msg_history" id="user-message-box-<?php echo $selectUserId?>">
    <?php
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <?php if ($row['to_id'] == $loginUserId) { ?>
                <div class="incoming_msg">
                    <div class="received_msg">
                        <div class="received_withd_msg">
                            <p><?php echo $row['message'] ?></p>
                            <span class="time_date"><?php echo $row['created_at'] ?></span></div>
                    </div>
                </div>
            <?php } else { ?>
                <div class="outgoing_msg">
                    <div class="sent_msg">
                        <p><?php echo $row['message'] ?></p>
                        <span class="time_date"><?php echo $row['created_at'] ?></span> </div>
                </div>
            <?php } ?>
            <?php
        }
    }
    ?>
</div>
<div class="type_msg">
    <div class="input_msg_write">
        <form id="save-chat-message" action="javascript:void(0)" method="post">
            <input type="hidden" id="to_id" name="to_id" value="<?php echo $selectUserId; ?>">
            <input type="hidden" id="from_id" name="from_id" value="<?php echo $loginUserId; ?>">
            <input type="text" id="message" name="message" class="write_msg" placeholder="Type a message" />
            <button class="msg_send_btn"  type="button" onclick="sendMessage()"><i class="fa fa-paper-plane-o" aria-hidden="true"></i></button>
        </form>
    </div>
</div>
