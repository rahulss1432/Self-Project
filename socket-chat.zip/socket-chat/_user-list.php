<?php

$hostName = 'localhost';
$userName = 'root';
$password = '';
$dataBaseName = 'test_db';

$connection = mysqli_connect($hostName, $userName, $password, $dataBaseName);
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

session_start();
$loginUsertId = $_SESSION['id'];
$sql = 'SELECT * FROM user WHERE id <> "'.$loginUsertId.'"';
$result = mysqli_query($connection, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
            ?>
           <a href="javascript:void(0)" onclick="getMessageList('<?php echo $row['id'] ?>')">
                <div class="chat_list active_chat">
                    <div class="chat_people">
                        <div class="chat_img"> <img src="http://localhost/socket-chat/uploads/<?php echo $row['profile_image'] ?>" alt="sunil"> </div>
                        <div class="chat_ib">
                            <h5><?php echo $row['name'] ?>
                                <span class="chat_date" id="user-online-<?php echo $row['id']; ?>"></span><br>
                                <span class="chat_date" id="user-typing-<?php echo $row['id']; ?>"></span>
                            </h5>
                        </div>
                    </div>
                </div> 
            </a>
            <?php
    }
} else {
    echo "0 results";
}
?> 
