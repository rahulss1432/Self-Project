var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

var connectedUsers = {};
 io.on('connection', function(socket){
     socket.on('setUsername', function (userID) {
        var userJID = userID;
        io.sockets.emit('set-online', userID);
        connectedUsers[userJID] = socket;
    }); 
     
   socket.on('send-message',function(data){
      io.sockets.emit('res-message', data);
   })
   
   socket.on('is typing',function(data){
      io.sockets.emit('typing', data);
   })
   
   socket.on('typing-stop',function(data){
      io.sockets.emit('typing-hide', data);
   })
  
});

http.listen(3000, function(){
  console.log('listening on *:3000');
});