(function () {
    'use strict';
    var express = require('express');
    var app = express();
    app.use(express.static(__dirname + '/public'));
    var server = app.listen(2111);
    var io = require('socket.io')(server);
    var request = require('request');
    var connectedUsers = {};


app.get('/', function(request, response){
    response.sendfile('index.html');
});

 io.sockets.on('connection', function (socket) {
        socket.on('register', function (packet) {
            var userJID = packet.userID
            if (connectedUsers.hasOwnProperty(userJID)) {
                connectedUsers[userJID].removeAllListeners();
                connectedUsers[userJID].disconnect();
                delete connectedUsers[userJID];
            };

            if (!connectedUsers.hasOwnProperty(userJID)) {
                socket.userId = userJID;
                connectedUsers[userJID] = socket;
            };
            socket.broadcast.emit('show-online', {'userJID':userJID});
        });

        socket.on('presence', function (packet) {
            var presence = packet.presence;
            var userJID = packet.userID;
            //updateStatus(presence,userJID);
        });

        

        socket.on('disconnect', function () {
            if (connectedUsers.hasOwnProperty(socket.userId)) {
                //updateStatus('offline',socket.userId);
                delete connectedUsers[socket.userId];
                socket.removeAllListeners();
                socket.leave();
                socket.emit('show-offline', {'userJID':socket.userId});
            }
            ;
        });
        
        socket.on('show-offline', function (a) {
           $('#'.a.userJID).removeClass('online').addClass('offline'); 
        });
    });
})();