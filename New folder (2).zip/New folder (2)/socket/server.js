(function () {
    'use strict';
    var express = require('express');
    var bodyParser = require('body-parser');
    var https = require('https');
    var fs = require('fs');
    var app = express();
    var connectedUsers = {};
    var socketConnectedUsers = {};
    var request = require('request');

//    app.use(express.static(__dirname + '/public'));
    app.use(bodyParser.urlencoded({
        extended: false
    }));
    app.use(bodyParser.json());

    //var server = app.listen(9800);
    
    var server = https.createServer({
        key: fs.readFileSync('/etc/ssl/certs/prortc.key'),
        cert: fs.readFileSync('/etc/ssl/certs/prortc.com.chained.crt'),
        requestCert: true,
        rejectUnauthorized: false
    }, app).listen(9800);

    app.use(function (req, res, next) {
        res.header('Access-Control-Allow-Origin', '*');
        res.header(
                'Access-Control-Allow-Headers',
                'Origin, X-Requested-With, Content-Type, Accept');
        next();
    });

    app.use(function (err, req, res, next) {
        res.status(err.status || 500);
        res.json({
            success: false,
            message: err.message,
            error: err
        });
    });

    var io = require('socket.io')(server);

    var rooms = {};
    var line_history = [];
    io.sockets.on('connection', function (socket) {
        console.log('New socket connection.');

        socket.on('register', function (packet) {
            console.log(packet);
            console.log("Register", packet.userID)
            var userJID = packet.userID
            if (connectedUsers.hasOwnProperty(userJID)) {
                connectedUsers[userJID].removeAllListeners();
                connectedUsers[userJID].disconnect();
                delete connectedUsers[userJID];
            };

            if (!connectedUsers.hasOwnProperty(userJID)) {
                socket.userId = userJID;
                connectedUsers[userJID] = socket;
                socketConnectedUsers[socket.id] = userJID;
            };
            socket.broadcast.emit('show-online', {'userJID': userJID});

        });

        socket.on('presence', function (packet) {
            var presence = packet.presence;
            var userJID = packet.userID;
        });

        socket.on('show-offline', function (packet) {
            var userJID = packet.userJID;
            console.log("Show Offline", userJID);
            socket.broadcast.emit('get-offline', {'userJID': userJID});
            delete connectedUsers[userJID];
        });

        socket.on('disconnect', function (packet) {
            var userID = socket.userId;
            //socket.broadcast.emit('show-offline', {'userJID': userID});
            socket.broadcast.emit('get-offline', {'userJID': userID});
            var options = {
                url: 'https://linked-assist.codiant.com/update-disconnct-user',
                method: 'POST',
                body: JSON.stringify({"userID": userID, "online": false}),
                headers: {
                    'Content-Type': 'application/json'
                }
            };
            request(options, function (error, response, body) {

            });
            delete connectedUsers[userID];
        });

        socket.on('end-current-call', function (packet) {
            console.log('end-current-call',packet);
            var userId = packet.userId;
            var ticketId = packet.ticketId;
            if (connectedUsers.hasOwnProperty(userId)) {
                connectedUsers[userId].emit('get-current-call-request');
            }
            var options = {
                url: 'https://linked-assist.codiant.com/update-call-status',
                method: 'POST',
                body: JSON.stringify({"receiverId": userId, "ticketId": ticketId, status: 'missed_request', "online": false}),
                headers: {
                    'Content-Type': 'application/json'
                }
            };
            request(options, function (error, response, body) {

            });
        });

        socket.on('join_room', function (message) {
            var room = message.room || '';
            console.log("Room", room);
            var connections = rooms[room] = rooms[room] || [];
            if (connections.length < 10) {
                socket.join(room);
                socket.broadcast.to(room).emit('new_peer', {
                    socketId: socket.id
                });
                connections.push(socket);
                
                var connectionsId = [];
                for (var i = 0, len = connections.length; i < len; i++) {
                    var id = connections[i].id;
                    if (id !== socket.id) {
                        connectionsId.push(id);
                    }
                }

                socket.emit(
                        'get_peers', {
                            connections: connectionsId,
                            socketId: socket.id
                        });

                socket.on('get-user', function (packet) {

                });

                socket.on('send-call-request', function (packet) {
                    console.log('send-call-request', packet);
                    var userJID = packet.userJID;
                    var callerId = packet.callerId;
                    var ticketId = packet.ticketId;
                    var name = packet.name;
                    var image = packet.image;
                    if (connectedUsers.hasOwnProperty(userJID)) {
                        connectedUsers[userJID].emit('receive-call-request', {'userJID': callerId, 'ticketId': ticketId, receiverId: userJID, name: name, image: image});
                    } else {
                        console.log("Notification", ticketId);
                        var options = {
                            url: 'https://linked-assist.codiant.com/api/save-call-notification',
                            method: 'POST',
                            body: JSON.stringify({"receiverId": userJID, "callerId": callerId, "ticketId": ticketId, "online": false}),
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        };
                        request(options, function (error, response, body) {

                        });
                    }
                });

                socket.on('end-user-call', function (packet) {
                    var userId = packet.userId;
                    var ticketId = packet.ticketId;
                    if (connectedUsers.hasOwnProperty(userId)) {
                        connectedUsers[userId].emit('user-end-call', {ticketId: ticketId});
                    } else {
                       var options = {
                            url: 'https://linked-assist.codiant.com/end-call-notification',
                            method: 'POST',
                            body: JSON.stringify({"receiverId": userId,"online": false}),
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        };
                        request(options, function (error, response, body) {

                        }); 
                    }
                    console.log("Remove Peer")
                    socket.leave(ticketId);
                    socket.broadcast.to(ticketId).emit(
                            'remove_peer', {
                                socketId: socket.id
                            });
                });

                function endCall(room, socket, isEndCall) {
                    var connections = rooms[room];
                    for (var i = 0; i < connections.length; i++) {
                        var id = connections[i].id;
                        if (id === socket.id) {
                            connections.splice(i, 1);
                            i--;
                            if (isEndCall) {
                                socket.broadcast.to(room).emit('end_call', {
                                    socketId: socket.id
                                });
                            } else {
                                socket.broadcast.to(room).emit(
                                        'remove_peer', {
                                            socketId: socket.id
                                        });
                            }
                            socket.leave(room);
                        }
                    }
                }

                socket.on('send-image', function (packet) {
                    var receiverId = packet.receiverId;
                    var imageUrl = packet.image;
                    if (connectedUsers.hasOwnProperty(receiverId)) {
                        connectedUsers[receiverId].emit('get-image', {imageUrl: imageUrl});
                    }
                })

                socket.on('end_call', function () {
                    console.log('end call');
                    endCall(room, socket, true);
                });

                socket.on('ice_candidate', function (data) {
                    var client = getSocket(room, data.socketId);
                    if (client) {
                        client.emit('ice_candidate', {
                            label: data.label,
                            candidate: data.candidate,
                            socketId: socket.id
                        });
                    }
                });

                socket.on('send_offer', function (data) {
                    var client = getSocket(room, data.socketId);
                    console.log("send_offer111",data);
                    console.log("client",client);
                    if (client) {
                        console.log("client1",client);
                        client.emit('receive_offer', {
                            sdp: data.sdp,
                            socketId: socket.id
                        });
                    }
                });

                socket.on('send_answer', function (data) {
                    var client = getSocket(room, data.socketId);
                    if (client) {
                        client.emit('receive_answer', {
                            sdp: data.sdp,
                            socketId: socket.id
                        });
                    }
                });
                socket.on('whiteboard', function (data) {
                    var client = getSocket(room, data.socketId);

                    if (client) {
                        client.emit(
                                'whiteboard', {
                                    canvasData: data.canvasJson,
                                    socketId: socket.id
                                });
                    }
                });

                socket.on('message', function (data) {
                    var client = getSocket(room, data.socketId);
                  //  console.log('message', data);
                    if (client) {
                        client.emit('message', {
                            message: data,
                            socketId: socket.id
                        });
                    }
                });
                socket.on('group_message', function (data) {
                    socket.broadcast.to(room).emit(
                            'group_message', {
                                socketId: socket.id,
                                message: data
                            });
                });



                socket.on('end_session_request', function (data) {
                    socket.broadcast.to(room).emit(
                            'end_session_request', {
                                socketId: socket.id,
                                message: data
                            });
                });

                socket.on('accept-call', function (packet) {
                    console.log("Accept Call", packet);
                    var userJID = packet.userJID;
                    var tickedId = packet.ticketId;
                    var receiverId = packet.receiverId;
                    var name = packet.name;
                    var image = packet.image;
                    console.log(userJID);
                    if (connectedUsers.hasOwnProperty(userJID)) {
                        connectedUsers[userJID].emit('get-accept-request', {'socketId': socket.id, tickedId: tickedId, userJID: receiverId,name:name,image:image});

                        var options = {
                            url: 'https://linked-assist.codiant.com/update-call-status',
                            method: 'POST',
                            body: JSON.stringify({
                                "userId": userJID,
                                "tickedId": tickedId,
                                "status": 'pending',
                                "online": false
                            }),
                            headers: {
                                'Content-Type': 'application/json',
                            }
                        };
                        request(options, function (error, response, body) {

                        });
                    } else {
                        console.log('accept!!!!');
                    }
                });

                socket.on('add_text', function (data) {
                    socket.broadcast.to(room).emit('add_text', data);
                });

                socket.on('object:added', function (data) {
                    socket.broadcast.to(room).emit('object:added', data);
                });
                socket.on('object:modified', function (data) {
                    socket.broadcast.to(room).emit('object:modified', data);
                });
                socket.on('object:removed', function (data) {
                    socket.broadcast.to(room).emit('object:removed', data);
                });

                socket.on('path:created', function (data) {
                    socket.broadcast.to(room).emit('path:created', data);
                });
            } else {
                console.log('room_full');
                socket.emit('room_full', {
                    socketId: socket.id,
                });
            }
        });
    });


    function getSocket(room, id) {
        var connections = rooms[room];
        if (!connections) {
            return;
        }

        for (var i = 0; i < connections.length; i++) {
            var socket = connections[i];
            if (id === socket.id) {
                return socket;
            }
        }
    }
})();