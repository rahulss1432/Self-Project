(function () {
  'use strict'
  let express = require('express')
  let bodyParser = require('body-parser')
  let https = require('https')
  let fs = require('fs')
  let app = express()
  let request = require('request')

  app.use(express.static(__dirname + '/public'))
  app.use(bodyParser.urlencoded({
    extended: false
  }))
  app.use(bodyParser.json())

  // let server = app.listen(9800)

  let server = https.createServer({
    key: fs.readFileSync('/etc/ssl/certs/prortc.key'),
    cert: fs.readFileSync('/etc/ssl/certs/prortc.com.chained.crt'),
    requestCert: true,
    rejectUnauthorized: false
  }, app).listen(9800)

  app.use(function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*')
    res.header(
      'Access-Control-Allow-Headers',
      'Origin, X-Requested-With, Content-Type, Accept')
    next()
  })

  app.use(function (err, req, res, next) {
    res.status(err.status || 500)
    res.json({
      success: false,
      message: err.message,
      error: err
    })
  })

  let io = require('socket.io')(server)

  let rooms = {}
  let sockets = []
  let connectedUsers = {}
  let socketConnectedUsers = {}

  io.sockets.on('connection', function (socket) {
    console.log('New socket connection.')

    socket.on('se_join', data => {
        //let SeResponse = checkSEExists(data.userId||'');
      //if(!checkSEExists(data.userId||'')){
      socket.userType = 'se'
      socket.userId = data.userId
      socket.isAvailable = true
      socket.room = ''
      // console.log('se id',socket.userId)
      sockets.push({
        type: 'se',
        socket: socket,
        isAvailable: true,
        room: '',
        userId: data.userId
      })
      socket.emit('se_joined', {
        socket_id: socket.id
      })
      socket.broadcast.emit('show-online', {'userJID': data.userId,'code':data.code})
      console.log('se id',data.userId);
//    }else{
//      socket.emit('se_exist', {
//        socket_id: socket.id
//      })
//    }
    })

    socket.on(
      'user_join',
      data => {
        //if(!checkUserExists(data.userId||'')){
        socket.room = ''
        socket.userId = data.userId
        socket.userType = 'user'
        socket.isAvailable = true
        sockets.push({
          type: 'user',
          socket: socket,
          isAvailable: true,
          room: '',
          userId: data.userId
        })
        socket.emit('user_joined', {
          socket_id: socket.id
        })
        socket.broadcast.emit('show-online', {'userJID': data.userId,'code':data.code})
//      }else{
//        socket.emit('user_exist', {
//          socket_id: socket.id
//        })
//      }
      })

    socket.on('set_available', data => {
      //if (socket.userType === 'se') {
        //socket.isAvailable = data.status
        socket.isAvailable = true
      //}
    })

    socket.on('set_active',data=>{
    	//console.log("set_active");
    });

    socket.on('show-offline', function (data) {
      var userJID = data.userJID
      socket.broadcast.emit('get-offline', {'userJID': userJID})
    })



    socket.on('send_offer', data => {
      let room = generateRoom(10)
      let connections = rooms[room] = rooms[room] || []
      socket.join(room)
      socket.room = room
      connections.push(socket)
      console.log('receive_offer Data',data);
      if (data.customerId) {
        let connection = getConnectionFromUserId(data.customerId)
        let otherSocket = connection && connection.socket || false
        if (otherSocket) {
            console.log("otherSocket.isAvailable",otherSocket.isAvailable);
            console.log("otherSocket.isAvailable",otherSocket.userId);
            if(otherSocket.isAvailable){
              socket.isAvailable = false;
                otherSocket.isAvailable = false;
          console.log('receive_offer to customer');
          setTimeout(function(){
            otherSocket.emit('receive_offer', {
                from: socket.id,
                room: room,
                sdp: data.sdp,
                name: data.name || '',
                image: data.image || '',
                isOneToOneCall:data.isOneToOneCall || false,
                //fromUserId: socket.userId,
                fromUserId: data.fromUserId,
                ticketId: data.ticketId
              })  
          },1000);
          
            } else {
//                socket.emit("user_busy");
                socket.emit("user_busy",{customerId:data.customerId,ticketId:data.ticketId});
            }
        } else {
            //console.log("Notification", ticketId);
            var options = {
                url: 'https://linked-assist.codiantdev.com/api/save-call-notification',
                method: 'POST',
                body: JSON.stringify({"receiverId": data.customerId, "callerId": data.fromUserId, "ticketId": data.ticketId, "online": false}),
                headers: {
                    'Content-Type': 'application/json'
                }
            };
            request(options, function (error, response, body) {

            });
        }
      }
      if (data.seList) {
        console.log('receive_offer to se');
        sendRequestToSE(data.seList,
          {
            from: socket.id,
            room: socket.room,
            sdp: data.sdp,
            name: data.name || '',
            image: data.image || '',
            //fromUserId: socket.userId,
            fromUserId: data.fromUserId,
            isOneToOneCall:data.isOneToOneCall || false,
            ticketId: data.ticketId,
            seList: data.seList
          })
      }
    })

    socket.on('send_answer', data => {
      console.log('send answer', data.fromUserId);
      console.log('send answer1', data.from);
      let connection = getConnection(data.from)
      let room = connection && connection.room || ''
      let otherSocket = connection && connection.socket || false
      room = otherSocket.room
      let connections = rooms[room] = rooms[otherSocket.room] || []
      // console.log(room,otherSocket.room,connections.length)
      if (connections.length < 2) {
        if (otherSocket) {
          socket.join(room)
          connections.push(socket)
          socket.isAvailable = false
          otherSocket.isAvailable = false
          socket.room = room
        //  console.log('receive_answer', otherSocket.id)
          /* socket.broadcast.emit('room_full', {
             room: room
           });*/
                
            socket.broadcast.emit('call_accepted', {
             senderId: socket.userId
           })

           sendRoomFullRequestToSE((data.seList||[]),socket.userId,otherSocket.userId);

          otherSocket.emit('receive_answer', {
            sdp: data.sdp,
            socketId: socket.id,
            name: data.name || '',
            image: data.image || '',
            userJID: data.userJID,
            ticketId: data.ticketId
          })
          console.log('sender_user_id',socket.userId);
          console.log('receiver_user_id',data.userJID);
          console.log('other_user_id',otherSocket.userId); 
          
           var options = {
                url: 'https://linked-assist.codiantdev.com/update-call-status',
                method: 'POST',
                body: JSON.stringify({
                    "userId": socket.userId,
                    "ticketId": data.ticketId,
                    'senderId':data.userJID,
                    'otherUserId':otherSocket.userId,
                    "status": 'pending',
                    "socketId":socket.id,
                    "online": false
                }),
                headers: {
                    'Content-Type': 'application/json',
                }
            };
            request(options, function (error, response, body) {

            });
            console.log("isAvailable",socket.isAvailable)
        }
      } else {
        socket.emit('room_full', {
          room: room
        });
        console.log("Room Full First",room);
      }
    })


    socket.on('reject_request', data => {
      socket.leave(socket.room)
      socket.isAvailable = true
      if (data.customerId) {
        let connection = getConnectionFromUserId(data.customerId)
        let otherSocket = connection && connection.socket || false
        if (otherSocket) {
         // console.log('reject request to customer');
          otherSocket.emit('reject_request', {
            from: socket.id,
            name: data.name || '',
            image: data.image || '',
            fromUserId: socket.userId,
            ticketId: data.ticketId
          })
        }
      }
      if (data.seList) {
       // console.log('reject request to se');
        sendRejectRequestToSE(data.seList,
          {
            from: socket.id,
            name: data.name || '',
            image: data.image || '',
            fromUserId: socket.userId,
            ticketId: data.ticketId
          })
      }
    })    

    socket.on('camera_not_found', data => {
      let connection = getConnection(data.to)
      let otherSocket = connection && connection.socket || false
      if (otherSocket) {
        otherSocket.emit('camera_not_found', {
          from: socket.id
        })
      }
    })


    socket.on('leave_room', data => {
      console.log('leave room')
      //if (socket.userType === 'provider') {
        socket.isAvailable = true
      //}
      socket.leave(socket.room)
    })

    socket.on('disconnect', function () {
      setTimeout(function () {
      console.log('socket disconnected', socket.id, socket.room)
      console.log('socket disconnected', socket.userId)
        let connectionLength = sockets.length
        let userType='';
        let userId='';
        let reason='';
        for (let i = 0; i < connectionLength; i++) {
          let connection = sockets[i];
          userType=connection.socket.userType;
          userId=connection.socket.userId;
          if (socket.id == connection.socket.id) {
            sockets.splice(i, 1)
            break
          }
        }
      //  console.log('socket userId', userId)
      reason = 'user_disconnect';
      socket.broadcast.emit('user_disconnect', {
          socketId: socket.id,
          usertype:userType||'',
          userId:userId||''
        })
        
      if(socket.room!=''){
        reason = 'user left from room';
        socket.leave(socket.room)
        socket.broadcast.to(socket.room).emit('user_left', {
          socketId: socket.id
        })

      } else {
        reason = 'user left';
        socket.broadcast.emit('user_left', {
          socketId: socket.id,
          usertype:userType||'',
          userId:userId||''
        })
      }
    //  console.log('update-disconnct-user-call-request');
         var options = {
            url: 'https://linked-assist.codiantdev.com/update-disconnct-user-call-request',
            method: 'POST',
            body: JSON.stringify({"userId": userId,"socketId":socket.id,'reason':reason,"online": false}),
            headers: {
                'Content-Type': 'application/json'
            }
        };
        request(options, function (error, response, body) {

        });
    
      }, 1000)
    })

    socket.on('message', function (data) {
      let connection = getConnection(data.to)
      let otherSocket = connection && connection.socket || false

      if (otherSocket) {
        otherSocket.emit('message', {
          message: data.message,
          from: socket.id
        })
      }
    })
    
    //Praveen: Event For Send Image From SE to Customer
     socket.on('send-image', data => {
        let connection = getConnectionFromUserId(data.receiverId);
        let otherSocket = connection && connection.socket || false;
        if (otherSocket) {
          otherSocket.emit('get-image', {
            imageUrl: data.image,
            from: socket.id
          });
        }
      })


    socket.on('ice_candidate', function (data) {
      let connection = getConnection(data.socketId)
      let client = connection && connection.socket || false

      if (client) {
        client.emit('ice_candidate', {
          label: data.label,
          candidate: data.candidate,
          socketId: socket.id
        })
      }
    })
   

    socket.on('end_call', function () {
     // console.log('end call')
     socket.isAvailable = true
      endCall(socket.room, socket, true)
    })

    socket.on('add_text', function (data) {
      socket.broadcast.to(socket.room).emit('add_text', data)
    })

    socket.on('object:added', function (data) {
      socket.broadcast.to(socket.room).emit('object:added', data)
    })
    socket.on('object:modified', function (data) {
      socket.broadcast.to(socket.room).emit('object:modified', data)
    })
    socket.on('object:removed', function (data) {
      socket.broadcast.to(socket.room).emit('object:removed', data)
    })

    socket.on('path:created', function (data) {
      socket.broadcast.to(socket.room).emit('path:created', data)
    })
  })

  function endCall (room, socket, isEndCall) {
      let connectionLength = sockets.length
      let executiveList = [];
//console.log('length',connectionLength);
    for (var i = 0; i <  connectionLength; i++) {
if(sockets[i]&&sockets[i].socket){
      var id = sockets[i].socket&& sockets[i].socket.id;


      if (id === socket.id) {
          executiveList.push(sockets[i].socket.userId);
       // sockets.splice(i, 1)
        //i--
        if (isEndCall) {
          socket.broadcast.to(room).emit('end_call', {
            socketId: socket.id
          })
        } else {
          socket.broadcast.to(room).emit(
            'remove_peer', {
              socketId: socket.id
            })
        }
        socket.leave(room)
}
      }
    }
    sockets.forEach(element => {
      if (element.type === 'se' && element.isAvailable && element.socket.isAvailable && (executiveList.indexOf(element.userId) != -1)) {
        if (element.socket) {
            element.socket.isAvailable = true;
            element.isAvailable = true;
          
        } 
      }
    })
  }

  function getConnection (id) {
    let connectionLength = sockets.length

    for (let i = 0; i < connectionLength; i++) {
      let connection = sockets[i]
      if (id == connection.socket.id) {
        return connection
        break
      }
    }
  }

  function getConnectionFromUserId (id) {
    let connectionLength = sockets.length

    for (let i = 0; i < connectionLength; i++) {
      let connection = sockets[i]
      if (connection.type === 'user' && connection.userId === id) {
        return connection
        break
      }
    }
  }

  
  function checkSEExists (id) {
    let connectionLength = sockets.length

    for (let i = 0; i < connectionLength; i++) {
      let connection = sockets[i]
      if (connection.type === 'se' && connection.userId === id) {
        return connection
        break
      }
    }
    return false;
  }

  
  function checkUserExists (id) {
    let connectionLength = sockets.length

    for (let i = 0; i < connectionLength; i++) {
      let connection = sockets[i]
      if (connection.type === 'user' && connection.userId === id) {
        return connection
        break
      }
    }
    return false;
  }

  function sendRequestToSE (seList, data) {
    // console.log(seList,data)
    let userCount = 0;
    sockets.forEach(element => {
        console.log("seList",seList);
        console.log("element.isAvailable",element.isAvailable);
        console.log("element.socket.isAvailable",element.socket.isAvailable);
        console.log("element.userId",element.userId);
      //if (element.type === 'se' && element.isAvailable && element.socket.isAvailable && (seList.indexOf(element.userId) != -1)) {
      if (element.type === 'se' && element.socket.isAvailable && (seList.indexOf(element.userId) != -1)) {
          userCount++;
        if (element.socket) {
            element.socket.isAvailable = false;
            element.isAvailable = false;
          element.socket.emit('receive_offer', data)
        } else {
             var options = {
                url: 'https://linked-assist.codiantdev.com/api/save-call-notification',
                method: 'POST',
                body: JSON.stringify({"receiverId": data.customerId, "callerId": data.fromUserId, "ticketId": data.ticketId, "online": false}),
                headers: {
                    'Content-Type': 'application/json'
                }
            };
            request(options, function (error, response, body) {

            });
        }
      }
    })
    
    if(userCount == 0){
        let connection = getConnectionFromUserId(data.fromUserId);
        let otherSocket = connection && connection.socket || false
       // console.log("otherSocket",otherSocket);
        if (otherSocket) {
            otherSocket.emit("user_busy");
        }
    }
  }

  function sendRejectRequestToSE (seList, data) {
    // console.log(seList,data)
    sockets.forEach(element => {
       //console.log(element.type,element.isAvailable,element.userId,seList.indexOf(element.userId))
      if (element.type === 'se' && (seList.indexOf(element.userId) != -1)) {
        if (element.socket) {
            element.socket.isAvailable = true;
            element.isAvailable = true;
          element.socket.emit('reject_request', data)
        }
      }
    })
  }

  function sendRoomFullRequestToSE (seList, id,senderId) {    
    sockets.forEach(element => {     
      if (element.type === 'se' && (element.userId != id) &&(seList.indexOf(element.userId) != -1)) {
        if (element.socket) {
            element.socket.isAvailable = true;
            element.isAvailable = true;
            element.socket.emit('room_full', {senderId: senderId})
            console.log("Room Full Second",senderId);
          //element.socket.emit('room_full', {})
        }
      }
    })
  }

  function generateRoom (length) {
    let alphaNumString =
    'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    let room = ''

    for (let i = 0; i < length; i++) {
      room += alphaNumString.charAt(Math.floor(Math.random() * 62))
    }

    return room
  }
})();
