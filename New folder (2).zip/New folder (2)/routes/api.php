<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['namespace' => 'Api'], function() {
    Route::post('login', 'AccountController@login');
    Route::post('/logout', 'AccountController@logout');
    Route::post('/contact-admin', 'ContactController@contactAdmin');
    Route::post('save-call-notification','ExecutiveController@sendcallnotification');
        Route::post('share-image','ExecutiveController@shareImage');
        
    Route::group(['middleware' => 'jwt.auth'], function () {
       
        Route::post('/online-offline', 'AccountController@doOnlineOffline');
        // customer routes
        Route::post('/request-call-category', 'RequestCallController@requestCallByCategory');
        Route::get('/customer-profile', 'CustomerController@getProfile');
        Route::post('/rate-executive', 'CustomerController@rateToexecutive');
        Route::get('/customer-notification', 'CustomerController@getNotificationList');
        Route::get('/linked-history', 'CustomerController@getLinkedHistory');
        Route::get('/home-detail', 'CustomerController@getHomeDetail');
        Route::post('/customer-assist', 'CustomerController@sendRequestToExecutive');
        Route::post('/customer-link-call', 'CustomerController@linkCall');
        
        // executive routes
        Route::get('/customer-profile-detail', 'ExecutiveController@getCustomerProfile');
        Route::get('/bank-document', 'ExecutiveController@getDocumentList');
        Route::get('/executive-profile', 'ExecutiveController@getProfile');
        Route::get('/executive-linked-history', 'ExecutiveController@getLinkedHistory');
        Route::get('/customer-notes-history', 'ExecutiveController@getCustomerNotesHistory');
        Route::get('/executive-notification', 'ExecutiveController@getNotificationList');
        Route::get('/executive-linked-detail', 'ExecutiveController@getHostoryDetail');
        Route::get('/executive-list', 'ExecutiveController@getExecutiveList');
        Route::get('/category-list', 'ExecutiveController@getCategoryList');
        Route::post('/finish-call', 'ExecutiveController@saveRequestDetail');
        Route::get('/executive-home', 'ExecutiveController@executiveHomeDetail');
        Route::post('/link-call', 'ExecutiveController@linkcall');
        Route::post('/send-missed-notification', 'ExecutiveController@sendMissedNotification');
        
        
        
        Route::get('/check-session', 'CustomerController@checkSession');
        
        
        
        //
        
    });
});