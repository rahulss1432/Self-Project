<?php

use Illuminate\Http\Request;

/*
  |--------------------------------------------------------------------------
  | API Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register API routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | is assigned the "api" middleware group. Enjoy building your API!
  |
 */

Route::group(['namespace' => 'Api'], function() {

    Route::get('country-list', 'CommonController@getCountry');
    Route::get('state-list', 'CommonController@getState');
    Route::get('city-list', 'CommonController@getCity');

    Route::post('signup', 'UserController@signup');
    Route::post('login', 'AccountController@login');
    Route::post('resend-code', 'UserController@sendOTP');
    Route::post('verify-code', 'UserController@OTPVerify');
    Route::post('check-verification', 'UserController@checkVerification');
    Route::post('forgot-password', 'UserController@forgotPassword');
    Route::post('reset-password', 'UserController@resetPassword');
    Route::post('social-login', 'UserController@saveSocialUser');

	Route::post('/message', 'ChatController@postMessage');
	Route::post('/notification', 'NotificationController@saveNotification');
	
	// Transaction
	Route::post('/connect-account', 'TransactionController@createConnectAccount');
	Route::delete('/connect-account/{account_id}', 'TransactionController@deleteConnectAccount');

    Route::group(['middleware' => 'jwt.auth'], function () {

        
        Route::post('/logout', 'AccountController@logout');
        Route::post('/change-password', 'AccountController@changePassword');
        Route::post('/update-profile', 'UserController@updateProfile');
        Route::get('/user-detail', 'UserController@getUser');
        Route::post('/availability', 'MentorController@addAvailability');
        Route::put('/availability', 'MentorController@editAvailability');
        Route::get('/availability', 'MentorController@getAvailability');
        Route::delete('/availability/{id}', 'MentorController@deleteAvailability');

        // Notification
        Route::get('/notification', 'NotificationController@getNotification');
        Route::delete('/notification/{id}', 'NotificationController@deleteNotification');
        Route::delete('/clear-all', 'NotificationController@deleteAllNotification');

        // User Appointment
        Route::post('/appointment', 'MenteeController@saveAppointment');

        Route::post('/complaints', 'CommonController@saveComplaints');
        Route::post('/toggle-favorite', 'MenteeController@saveFavorite');

        // Skill
        Route::post('/service', 'MentorController@addService');
        Route::get('/service', 'MentorController@getService');
        Route::delete('/service/{id}', 'MentorController@deleteService');

        // Mentor Appointment
        Route::get('/appointment', 'CommonController@getAppointment');
        Route::put('/appointment/{id}', 'CommonController@updateAppointment');
        Route::post('/appointment-cancel-complete/{id}', 'CommonController@cancelCompleteAppointment');
        Route::get('/appointment-detail/{id}', 'CommonController@getAppointmentDetail');

        // Chat routes
        Route::get('/inbox', 'ChatController@getInbox');
        Route::get('/chat-list', 'ChatController@getChatList');
        Route::delete('/chat/{to_id}', 'ChatController@deleteChat');

        // Offer
        Route::post('/offer', 'MentorController@saveOffer');
        Route::get('/offer', 'CommonController@getOffer');

        // Portfolio
        Route::post('/portfolio', 'MentorController@savePortfolio');
        Route::get('/portfolio', 'MentorController@getPortfolio');
        Route::get('/my-earning', 'MentorController@getEarning');

        // Rating and Services
        Route::post('/rating', 'CommonController@giveRating');
        Route::get('/rating', 'CommonController@getRatingReview');
        Route::get('/category', 'MenteeController@categoryList');
        Route::get('/services', 'MenteeController@serviceList');

        // Post
        Route::post('/post', 'CommonController@savePost');
        Route::get('/post', 'CommonController@getPost');
		
        Route::post('/contact-us', 'CommonController@contactUs');
        Route::get('/users', 'MentorController@explorUsers');
        Route::get('/mentors', 'MentorController@getMentorList');

        Route::post('/verify-with', 'CommonController@verifyWith');
        Route::get('/my-favourite', 'MenteeController@myFavourite');

        // Transaction
        Route::post('/card', 'TransactionController@addCard');
        Route::get('/card', 'TransactionController@getCard');
        Route::delete('/card/{card_id}', 'TransactionController@deleteCard');
        Route::post('/payment', 'TransactionController@payment');
        Route::post('/refund', 'TransactionController@refundPayment');
        Route::get('/transactions', 'TransactionController@getAllTransactions');
        Route::post('/payment-complete', 'TransactionController@capturePayment');

        // update lat long
        Route::post('/update-lat-long', 'MenteeController@updateLatLong');
       
        
        Route::get('/mentor-home', 'MentorController@mentorHome');
        Route::get('/user-home', 'MenteeController@userHome');
        Route::get('/offer-detail', 'MenteeController@offerDetail');
        Route::post('/offer-accept-decline', 'MenteeController@offerAcceptDecline');
        Route::get('/faq', 'CommonController@faqList');
        Route::get('/check-availability', 'MenteeController@checkAvailability');
		
    });
});
