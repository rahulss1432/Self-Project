<?php

/* notifications routes */
Route::get('/notification', 'NotificationController@index')->name('executive-notification');
Route::get('/notification-list', 'NotificationController@notificationList');

/* customer request routes */
Route::get('/customer-request', 'CustomerRequestController@index')->name('executive-request');
Route::get('/customer-request-list', 'CustomerRequestController@customerRequestList');
Route::post('/create-call-request', 'CustomerRequestController@createCallRequest');
Route::post('/get-call-content', 'LinkedNotesController@getCallContent');



/* linked history routes */
Route::get('/linked-history', 'LinkedHistoryController@index')->name('executive-history');
Route::get('/linked-history-list', 'LinkedHistoryController@linkedHistoryList');
Route::get('/linked-history-view', 'LinkedHistoryController@linkedHistoryView');
Route::get('/linked-history-edit', 'LinkedHistoryController@linkedHistoryEdit');
Route::post('/update-se-request', 'LinkedHistoryController@updateExecutiveRequest');
Route::post('/update-dropped-user-call-request', 'LinkedNotesController@updateExecutiveDroppedRequest');


/* linked notes routes */
Route::post('/linked-notes', 'LinkedNotesController@index');
Route::post('/executive-document-list', 'LinkedNotesController@executiveDocumentsList');
Route::get('/linked-merchant-notes-history-list/{id}', 'LinkedNotesController@linkedMerchantNotesHistoryList');
Route::get('/load-add-note-modal/{id}/{time}', 'LinkedNotesController@loadAddNoteModal');
Route::post('/notes-history-list-by-date', 'LinkedNotesController@getNotesDataByDate');

/* dashboard rouets */
Route::get('/user-profile', 'DashboardController@viewUserProfile');

/* select executive by category */
Route::post('get-executive-by-category', 'DashboardController@getExecutiveByCategory');

Route::post('/upload-image', 'LinkedNotesController@uploadImage');
Route::post('/check-login-code', 'DashboardController@checkLoginCode');
Route::post('/check-current-call-status', 'CustomerRequestController@checkCurrentCallStatus');
Route::post('/update-user-call-status', 'CustomerRequestController@updateUserCallStatus');
Route::post('/send-busy-notification', 'CustomerRequestController@sendBusyNotification');
//Route::post('/check-customer-status', 'LinkedNotesController@uploadImage');

Route::get('/free-user/{id}', 'HomeController@freeUser');