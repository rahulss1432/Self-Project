<?php
return [
    'paths' => [
       
         "/customer-profile" => [
            "get" => [
                "tags" => [
                    "Customer"
                ],
                "summary" => "Customer Profile",
                "description" => "Customer Profile",
                "operationId" => "profile",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
         "/check-session" => [
            "get" => [
                "tags" => [
                    "Customer"
                ],
                "summary" => "Check User Session",
                "description" => "Check User Session",
                "operationId" => "Check User Session",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
         "/customer-notification" => [
            "get" => [
                "tags" => [
                    "Customer"
                ],
                "summary" => "Notification List",
                "description" => "Notification List",
                "operationId" => "notification",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                     [
                        "in" => "query",
                        "name" => "page",
                        "description" => "page",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ],
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/contact-admin" => [
            "post" => [
                "tags" => [
                    "Customer"
                ],
                "summary" => "Contact Admin",
                "description" => "Contact Admin",
                "operationId" => "contact",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "Contact Admin",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/contact"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/home-detail" => [
            "get" => [
                "tags" => [
                    "Customer"
                ],
                "summary" => "Home detail",
                "description" => "Home detail",
                "operationId" => "Home detail",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                   [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/rate-executive" => [
            "post" => [
                "tags" => [
                    "Customer"
                ],
                "summary" => "Rate Executive",
                "description" => "Rate Executive",
                "operationId" => "rate",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                     [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "rate to executive",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/rating"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/linked-history" => [
            "get" => [
                "tags" => [
                    "Customer"
                ],
                "summary" => "Linked History",
                "description" => "Linked History",
                "operationId" => "history",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                     [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "query",
                        "name" => "page",
                        "description" => "page",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/customer-assist" => [
            "post" => [
                "tags" => [
                    "Customer"
                ],
                "summary" => "customer assist",
                "description" => "customer assist",
                "operationId" => "assist",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                     [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                        [
                        "in" => "body",
                        "name" => "body",
                        "description" => "Request a call",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/request-call"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/customer-link-call" => [
            "post" => [
                "tags" => [
                    "Customer"
                ],
                "summary" => "link call",
                "description" => "link call",
                "operationId" => "link call",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/customerlinkcall"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/request-call-category" => [
            "post" => [
                "tags" => [
                    "Customer"
                ],
                "summary" => "Request a Call By Category",
                "description" => "Request a Call By Category",
                "operationId" => "request",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "Request a call",
                        "required" => false,
                        "schema" => [
//                            '$ref' => "#/definitions/request-call"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ]
    ],
    'definitions' => [
           'contact' => [
            'type' => "object",
            'properties' => [
                'name' => [
                    'type' => 'string'
                ],
                'business_name' => [
                    'type' => 'string'
                ],
                'phone_no' => [
                    'type' => 'string'
                ],
                'email' => [
                    'type' => 'string'
                ],
                'message' => [
                    'type' => 'string'
                ],
                'device_type' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "Contact"
            ]
        ],
           'rating' => [
            'type' => "object",
            'properties' => [
                'ticket_id' => [
                    'type' => 'string'
                ],
                'executive_rating' => [
                    'type' => 'string'
                ],
                'waiting_rating' => [
                    'type' => 'string'
                ],
                'overall_rating' => [
                    'type' => 'string'
                ],
                'review' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "rating"
            ]
        ],
           'request-call' => [
            'type' => "object",
            'properties' => [
                'category_id' => [
                    'type' => 'string'
                ],
                'notes' => [
                    'type' => 'string'
                ],
               
            ],
            'xml' => [
                'name' => "rating"
            ]
        ],
        'customerlinkcall' => [
            'type' => "object",
            'properties' => [
                'executive_id' => [
                    'type' => 'string'
                ],
                'ticket_id' => [
                    'type' => 'string'
                ]
                
            ],
            'xml' => [
                'name' => "customerlinkcall"
            ]
        ]
    ]
    ];
