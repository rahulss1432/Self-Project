<?php

$params = require_once('params.php');

$account = require_once('account.php');
$customer = require_once('customer.php');
$executive = require_once('executive.php');
$paths = array_merge($account['paths'],$customer['paths'],$executive['paths']);

$definitions = array_merge($account['definitions'],$customer['definitions'],$executive['definitions']);

echo json_encode([
    'tags' => [
        [
            'name' => 'account',
            'description' => 'guest user operations.',
        ],
//        [
//            'name' => 'Contact Admin',
//            'description' => 'Customer Side.',
//        ],
//        [
//            'name' => 'Request a call by category',
//            'description' => 'Request a Call By Category.',
//        ],
        [
            'name' => 'Customer',
            'description' => 'Operation about Customer.',
        ],
        [
            'name' => 'Executive',
            'description' => 'Operation about Executive.',
        ],
    ],
    "swagger" => "2.0",
    "info" => [
        "version" => "2.0.0",
        "title" => "Linked Assist API"
    ],
    "host" => $params['host'],
    "basePath" => $params['basePath'],
    "schemes" => [
       // "http",
        "https"
    ],
    'paths' => $paths,
    'definitions' => $definitions
]);
