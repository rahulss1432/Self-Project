<?php
return [
    'paths' => [
       
         "/login" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "Login a user",
                "description" => "Login for User",
                "operationId" => "login",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "Login for user_type should be customer/executive",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/login"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
          "/logout" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "Logout User",
                "description" => "",
                "consumes" => [
                    "application/json"
                ], "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                ],
                "responses" => [
                    "405" => [
                        "description" => "Invalid input"
                    ]
                ],
            ],
        ],
          "/online-offline" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "online/offline",
                "description" => "online/offline",
                "consumes" => [
                    "application/json"
                ], "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "status",
                        "in" => "query",
                        "description" => "status should be online/offline",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                ],
                "responses" => [
                    "405" => [
                        "description" => "Invalid input"
                    ]
                ],
            ],
        ],
    ],
    'definitions' => [
           'login' => [
            'type' => "object",
            'properties' => [
                'username' => [
                    'type' => 'string'
                ],
                'password' => [
                    'type' => 'string'
                ],
                'device_id' => [
                    'type' => 'string'
                ],
                'call_device_id' => [
                    'type' => 'string'
                ],
                'device_type' => [
                    'type' => 'string'
                ],
                'timezone' => [
                    'type' => 'string'
                ],
                'certification_type' => [
                    'type' => 'string'
                ],
                'user_type' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "Login"
            ]
        ],
    ]
    ];
