<?php
$baseUrl = '//localhost/mentor-locator';
//$baseUrl = '//mentorlocator.codiantdev.com';
return array_merge([
    'apiVersion' => '1.0.0',
    'swaggerVersion' => '3.2.0',
    'host' => 'localhost/mentor-locator',
    //'host' => 'mentorlocator.codiantdev.com',
    'basePath' => '/api',
    'baseUrl' => $baseUrl
]);