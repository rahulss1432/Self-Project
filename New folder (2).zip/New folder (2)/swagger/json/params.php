<?php
$baseUrl = 'https://localhost/linked_assist';
//$baseUrl = 'http://linked-assist.codiant.com';
return array_merge([
    'apiVersion' => '1.0.0',
    'swaggerVersion' => '3.2.0',
    'host' => 'localhost/linked_assist',
    'basePath' => '/api',
    'baseUrl' => $baseUrl
]);