<?php

return [
    'paths' => [
        "/toggle-favorite" => [
            "post" => [
                "tags" => [
                    "user"
                ],
                "summary" => "Toggle favorite",
                "description" => "Toggle favorite",
                "operationId" => "post",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "query",
                        "name" => "user_id",
                        "description" => "",
                        "required" => true,
                        "type" => "integer",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                ]
            ],
        ],
        "/category" => [
            "get" => [
                "tags" => [
                    "user"
                ],
                "summary" => "category list",
                "description" => "category list",
                "operationId" => "category list",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                ]
            ],
        ],
        "/services" => [
            "get" => [
                "tags" => [
                    "user"
                ],
                "summary" => "service list",
                "description" => "service list",
                "operationId" => "service list",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "catery_id",
                        "in" => "query",
                        "description" => "catery_id",
                        "required" => true,
                        "type" => "integer",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                ]
            ],
        ],
         "/mentors" => [
            "get" => [
                "tags" => [
                    "user"
                ],
                "summary" => "mentor list",
                "description" => "mentor list",
                "operationId" => "mentor list",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                     [
                        "name" => "distance",
                        "in" => "query",
                        "description" => "distance will be in miles as 1,25",
                        "required" => true,
                        "type" => "string",
                        
                    ],
                     [
                        "name" => "category_id",
                        "in" => "query",
                        "description" => "category_id",
                        "required" => false,
                        "type" => "string",
                        
                    ],
                     [
                        "name" => "service_id",
                        "in" => "query",
                        "description" => "service_id",
                        "required" => false,
                        "type" => "string",
                        
                    ],
                     [
                        "name" => "mentor_id",
                        "in" => "query",
                        "description" => "mentor_id",
                        "required" => false,
                        "type" => "string",
                        
                    ],
                    [
                        "name" => "rating",
                        "in" => "query",
                        "description" => "rating will be as 1,5",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "date",
                        "in" => "query",
                        "description" => "date will yyyy-mm-dd",
                        "required" => false,
                        "type" => "string",
                      
                    ],
                    [
                        "name" => "time",
                        "in" => "query",
                        "description" => "time will be 00:00:00 in 24 format",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "experince",
                        "in" => "query",
                        "description" => "experince will be as 1,5",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "price",
                        "in" => "query",
                        "description" => "price will be as 100,200",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ],
                     [
                        "in" => "query",
                        "name" => "meeting_place",
                        "description" => "meeting",
                        "type" => "string",
                        "enum" => ["public", "user_home","mentor_home"],
                        "required" => false
                    ],
                ],
                "responses" => [
                ]
            ],
        ],
         "/my-favourite" => [
            "get" => [
                "tags" => [
                    "user"
                ],
                "summary" => "my-favourite",
                "description" => "my-favourite",
                "operationId" => "my-favourite",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                  
                ],
                "responses" => [
                ]
            ],
        ],
         "/user-home" => [
            "get" => [
                "tags" => [
                    "user"
                ],
                "summary" => "user-home",
                "description" => "user-home",
                "operationId" => "user-home",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                  
                ],
                "responses" => [
                ]
            ],
        ],
         "/offer-detail" => [
            "get" => [
                "tags" => [
                    "user"
                ],
                "summary" => "offer-detail",
                "description" => "offer-detail",
                "operationId" => "offer-detail",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "mentor_id",
                        "in" => "query",
                        "description" => "mentor_id",
                        "required" => false,
                        "type" => "string",
                      
                    ],
                  
                ],
                "responses" => [
                ]
            ],
        ],
         "/check-availability" => [
            "get" => [
                "tags" => [
                    "user"
                ],
                "summary" => "check availability",
                "description" => "check availability",
                "operationId" => "check availability",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "mentor_id",
                        "in" => "query",
                        "description" => "mentor_id",
                        "required" => true,
                        "type" => "string",
                      
                    ],
                    [
                        "name" => "category_id",
                        "in" => "query",
                        "description" => "category",
                        "required" => true,
                        "type" => "string",
                      
                    ],
                    [
                        "name" => "sub_category_id",
                        "in" => "query",
                        "description" => "sub_category",
                        "required" => true,
                        "type" => "string",
                      
                    ],
                    [
                        "name" => "date",
                        "in" => "query",
                        "description" => "date will in yyyy-mm-dd formate",
                        "required" => false,
                        "type" => "string",
                      
                    ],
                  
                ],
                "responses" => [
                ]
            ],
        ],
         "/offer-accept-decline" => [
            "post" => [
                "tags" => [
                    "user"
                ],
                "summary" => "offer accept decline",
                "description" => "offer accept decline",
                "operationId" => "offer accept decline",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                     [
                        "in" => "body",
                        "name" => "body",
                        "description" => "status will be accept/decline",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/offer_update"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ],
        ],
         "/update-lat-long" => [
            "post" => [
                "tags" => [
                    "user"
                ],
                "summary" => "update lat long",
                "description" => "update lat long",
                "operationId" => "update lat long",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                     [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/lat_long"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ],
        ]
    ],
    'definitions' => [
        'favorite-post' => [
            'type' => "object",
            'properties' => [
                'to_id' => [
                    'type' => 'integer'
                ],
            ],
            'xml' => [
                'name' => "appointment"
            ]
        ],
        'lat_long' => [
            'type' => "object",
            'properties' => [
                'latitude' => [
                    'type' => 'integer'
                ],
                'longitude' => [
                    'type' => 'integer'
                ],
            ],
            'xml' => [
                'name' => "appointment"
            ]
        ],
        'offer_update' => [
            'type' => "object",
            'properties' => [
                'offer_id' => [
                    'type' => 'integer'
                ],
                'status' => [
                    'type' => 'string'
                ],
               
            ],
            'xml' => [
                'name' => "appointment"
            ]
        ],
    ]
];
