<script src="https://webrtc.github.io/adapter/adapter-latest.js"></script>
<?php
// To Get Current Call Detail
    $executiveId = Auth::guard('web')->user()->id;
    $ticketData = App\Http\Models\Ticket::where(['ticket_number' => $ticketData->ticket_number])->first();
    $request = \App\Http\Models\CallRequest::where(['ticket_id' => $ticketData->id,'executive_id'=>$executiveId])->orderBy('id', 'DESC')->first();
?>
    <section class="tabs_section">
        <div class="row">
            <div class="col-lg-5 col-xl-6 left">
                <ul class="list-unstyled tabs_links d-flex justify-content-start nav nav-tabs" id="myTab" role="tablist">
                    <li class="text-uppercase nav-item"><a id="note-tab" onclick="noteTab();" data-toggle="tab" href="#note" role="tab" aria-controls="note" aria-selected="true" class="nav-link active">NOTE</a></li>
                    <li class="text-uppercase nav-item"><a id="documents-tab" onclick="documentTab();" data-toggle="tab" href="#documents" role="tab" aria-controls="documents" aria-selected="false" class="nav-link">DOCUMENTS</a></li>
                    <li class="text-uppercase nav-item"><a id="history-tab" onclick="historyTab();" data-toggle="tab" href="#notesHistory" role="tab" aria-controls="notesHistory" aria-selected="false" class="nav-link">NOTES HISTORY</a></li>

                    <div class="search_box ml-auto" id="searchBox">
                        <form id="searchFilterForm" action="javascript:void(0)" onsubmit="documentTab()" method="post" autocomplete="off">
                            {{ csrf_field() }}
                            <input type="hidden" name="manager_id" value="{{getManagerByExecutiveId(Auth::guard(getAuthGuard())->user()->id)}}">
                            <div class="input-group">
                                <input type="text" id="nameFilter" name="document_name" class="form-control" placeholder="Document name" aria-label="Document name" aria-describedby="document_button">
                                <div class="input-group-append">
                                    <button class="btn bg-transparent border-0" type="submit" id="document_button"><i class="icon-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </ul>
                <div class="tab-content tabs_content" id="myTabContent">
                    <div class="tab-pane fade show active" id="note" role="tabpanel" aria-labelledby="note-tab">
                        <div class="note_box">
                            <h5>Note</h5>
                            <div class="form-group mb-0">
                                <textarea class="form-control border-0 shadow-none" id="textAddNote" rows="8" cols="80" onkeyup="setGetNote($(this).val());">{{@$request->notes}}</textarea>
                            </div>
                        </div>
                    </div>
                    <!--document listing and view document-->
                    <div class="tab-pane fade" id="documents" role="tabpanel" aria-labelledby="documents-tab">
                        <div id="divDocumentList"></div>
                        <div class="document_view" id="viewContent">
                            <div class="d-flex justify-content-between">
                                <h4>Operation function</h4>
                                <a href="javascript:void(0);" onclick="documentClose();">Close</a>
                            </div>
                            <div class="content_text">
                                <span id="divTitle"></span>
                                <div id="divContent"></div>
                            </div>
                        </div>                        
                    </div>
                    <!-- customer and executive linked previous notes listing-->                    
                    <div class="tab-pane fade" id="notesHistory" role="tabpanel" aria-labelledby="history-tab"></div>
                </div>
            </div>
            <div class="custom-col-4 col-lg-4 col-sm-8">
                <div class="machine_sec">
                    <div class="machine_inner" id="machinInner">
                        <div class="loader" id="callScreenLoader">
                            <div class="inner-item d-flex align-items-center">
                                <i class="fa fa-spinner fa-pulse fa-3x"></i>
                            </div>
                        </div>
                        <canvas id="canvasElement"></canvas>
                        <audio id="remote_audio" autoplay></audio>
                        <span id="play_video"></span>
                        <div class="linediv">
                            <div id="drawing-mode-options">
                                <!--To Select Drawing Type-->
                                <select id="drawing-mode-selector" style="display: none">
                                    <option>Pencil</option>
                                </select>
                                <span class="info"></span>
                                <input type="range" value="10" min="10" max="30" id="drawing-line-width" style="display: none">
                                <input type="color" value="#FFFFFF" id="drawing-color" style="display: none">
                                <input type="hidden" value="#FFFFFF" id="draw-color">
                            </div>
                        </div>
                    </div>
                    <ul class="btn_list list-inline">
                        <li class="list-inline-item">
                            <div id="myEditDropdown" class="dropdown-content">
                                <a href="javascript:void(0);" id="clear-canvas" onclick="clear_canvas(this.id)" class="ripple-effect-dark canvas-option"><i class="icon-close"></i><span>Clear</span></a>
                                <a href="javascript:void(0);" id="draw_text" class="ripple-effect-dark canvas-option" onclick="addCanvasText(this.id)"><i class="icon-text"></i><span>Text</span></a>
                                <a href="javascript:void(0);" id="draw_canvas" class="ripple-effect-dark canvas-option active" onclick="draw_canvas(this.id)"><i class="icon-highlighter"></i><span>Draw</span></a>
                                <a href="javascript:void(0);" id="draw_size" class="ripple-effect-dark canvas-option" onclick="toggle_size(this.id)"><i class="size_text" ><span id="draw_width">10</span></i><span>Pt Size</span></a>
                                <a href="javascript:void(0);" id="draw_color" class="ripple-effect-dark canvas-option" onclick="toggle_color(this.id)"><i class="icon-fill"></i><span>Color</span></a>
                            </div>
                            <a href="javascript:void(0);" onclick="myEditToggle()" class="icons edit_btn ripple-effect-dark"><i class="icon-edit"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="openAddNoteModal();" class="icons callend_btn ripple-effect-dark"><i class="icon-call-cut"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="icons camera_btn ripple-effect-dark" id="addImage"><i class="icon-photo-camera"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Show Customer Detail in Right Side Bar -->
            <div class="custom-col-2 col-lg-3 col-sm-4 right">
                <div class="profile_detail">
                    <img src="{{getImage(!empty($request->customerDetail->profile_image) ? $request->customerDetail->profile_image : '' ,'users','users')}}" alt="user" class="img-fluid rounded-circle">
                    <h3>{{!empty($request->customerDetail->contact_name) ? $request->customerDetail->contact_name : ''}}</h3>
                    <span class="bank_name">{{!empty($request->customerDetail->bank->name) ? $request->customerDetail->bank->name : ''}}</span>
                    <div class="info_list">
                        <div class="list  d-sm-block d-xl-flex justify-content-between merchant">
                            <p>Merchant no.</p>
                            <span>{{!empty($request->UserProfile->merchant_number) ? $request->UserProfile->merchant_number : ''}}</span>
                        </div>
                        <div class="list  d-sm-block d-xl-flex justify-content-between merchant-process">
                            <p>Merchant Processor</p>
                            @php
                            $manager = \App\Http\Models\CustomerExecutiveRelation::select(['users.first_name', 'users.last_name'])->join('users', 'users.id', '=', 'customer_executive_relations.manager_id')->where(['customer_id' => @$request->customer_id])->first();
                            $managerName = '-';
                            if(!empty($manager)){
                                $managerName = @$manager->first_name.' '.@$manager->last_name;
                            }
                            
                            @endphp
                            <span>{{@$managerName}}</span>
                        </div>
                        <div class="list d-sm-block d-xl-flex justify-content-between company">
                            <p>Company</p>
                            <span>{{!empty($request->customerDetail->bank->name) ? $request->customerDetail->bank->name  : '-'}}</span>
                        </div>
                        <div class="list  d-sm-block d-xl-flex justify-content-between card-machine">
                            <p>Credit Card Machine Model</p>
                            <span>{{!empty($request->UserProfile->machine_model) ? $request->UserProfile->machine_model  : '-'}}</span>
                        </div>
                        <div class="list  d-sm-block d-xl-flex justify-content-between business-name">
                            <p>Business name</p>
                            <span>{{!empty($request->UserProfile->bussiness_name) ? $request->UserProfile->bussiness_name : '-'}}</span>
                        </div>
                        <div class="list address d-sm-block d-xl-flex justify-content-between business-add">
                            <p>Business address</p>
                            <span>{{!empty($request->UserProfile->bussiness_address) ? $request->UserProfile->bussiness_address : '-'}}</span>
                        </div>
                        <div class="list d-sm-block d-xl-flex justify-content-between mobile">
                            <p>Mobile</p>
                            <span>{{!empty($request->customerDetail->phone_number) ? $request->customerDetail->phone_number : '-'}}</span>
                        </div>
                        <div class="list d-sm-block d-xl-flex justify-content-between email">
                            <p>Email</p>
                            <span>{{!empty($request->customerDetail->email) ? $request->customerDetail->email : '-'}}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Modal For Call Note-->
    <div class="modal fade common-modal add_note" id="AddNote" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="viewHestoryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header justify-content-center">
                    <h5 class="modal-title" id="viewHestoryModalLabel">ADD NOTE</h5>
                </div>
                <div class="modal-body" id="divAddNoteModalBody">
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="{{asset('public/')}}/js/ajaxupload.3.5.js"></script>
    <script>
    // For Image Upload During Call
            var add_image = $('#addImage');
            new AjaxUpload(add_image, {
                action: '{{ url("/upload-image") }}',
                name: 'add_image',
                cache: false,
                method: 'post',
                data: {_token: '{{ csrf_token() }}', ticket_id: $('#hdnTicketId').val()},
                responseType: "JSON",
                onSubmit: function (file, ext) {
                    if (!(ext && /^(jpg|png|jpeg)$/.test(ext))) {
                        toastrAlertMessage('error', 'Only jpg, jpeg, png files are allowed.');
                        return false;
                    }
                },
                onComplete: function (file, response) {
                    if (file != "") {
                        if (response.success == 1) {
                            var receiverId = $("#hdnCustomerId").val();
                            socket.emit('send-image', {image: response.filename, receiverId: receiverId})
                            toastrAlertMessage('success', "Image Sent Succcessfully");
                        } else {
                            toastrAlertMessage('error', response.error);
                        }
                    } else {
                        toastrAlertMessage('error', "Error occured! please try again.");
                    }
                }
            });

            function status_radio(value) {
                $(".field_box").hide();
                $("." + value).show();
            }

            function notify_radio(value) {
                $(".notify_box").hide();
                $("." + value).show();
                                }

            $(document).ready(function () {
                var noteText = $('#textAddNote').val();
                setGetNote(noteText);
                $('#searchBox').hide();
            });



            /* set input text to add note textarea and request add note textarea*/
            function setGetNote(noteText) {
                $('#textRequestAddNote').val(noteText);
                $('#textAddNote').val(noteText);
            }

            function myEditToggle() {
                $("#drawing-line-width").hide();
                $("#myEditDropdown").toggleClass("active");
            }

            //To Open Color Bar
            function toggle_color(id) {
                $("#drawing-line-width").hide();
                $(".canvas-option").each(function(){
                   $(this).removeClass('active'); 
                });
                $("#"+id).addClass('active');
                 $("#drawing-color").trigger('click');
            }
            
            //To Open Size Bar
            function toggle_size(id) {
                $(".canvas-option").each(function(){
                   $(this).removeClass('active'); 
                });
                $("#"+id).addClass('active');
                $("#drawing-line-width").toggle();
            }

            //To Open Note Modal
            function openAddNoteModal() {
                $("#isFeedbackFormOpen").val(1);
                socket.emit('end_call');
                var customerId = $("#hdnCustomerId").val();
                socket.emit('end-user-call', {customerId: customerId});
                $("#canvasElement").hide();
                $.ajax({
                    type: "GET",
                    url: "{{url('load-add-note-modal')}}" + '/' + '{{@$request->id}}' + '/' + callTime,
                    success: function (response) {
                        if (response.success) {
                            $("#AddNote").modal('show');
                            $('#divAddNoteModalBody').html(response.html);
                            $('.selectpicker').selectpicker('refresh');
                            setGetNote($('#textAddNote').val());
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                        }
                    }
                });
            }
            
            //To Open Note Tab
            function noteTab() {
                $('#searchBox').hide();
            }
            
            //To Open Document Tab
            function documentTab() {
                $('#viewContent').hide();
                $('#divDocumentList').show();
                pageDivLoader('show', 'divDocumentList');
                var searchString = $("#searchFilterForm").serializeArray();
                $.ajax({
                    type: "POST",
                    url: "{{url('executive-document-list')}}",
                    data: searchString,
                    success: function (response) {
                        if (response.success) {
                            $('#searchBox').show();
                            $('#divDocumentList').html(response.html);
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                        // toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            }

            //To Open History Tab
            function historyTab() {
                $('#searchBox').hide();
                $('#notesHistory').show();
                var ticketId = $("#hdnTicketId").val();
                pageDivLoader('show', 'notesHistory');
                $.ajax({
                    type: "GET",
                    url: "{{url('linked-merchant-notes-history-list')}}" + '/' + '{{@$request->customerDetail->id}}',
                    success: function (response) {
                        if (response.success) {
                            $('#notesHistory').html(response.html);
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            //toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            }

            //To View Document
            function documentView(title,id) {
                $('#viewContent').show();
                $('#divDocumentList').hide();
                $('#divTitle').html('<h6>' + title + '</h6>');
                var content = $("#hdnValue_"+id).val();
                $('#divContent').html(content);
            }
            
            // To Close Document
            function documentClose() {
                $('#viewContent').hide();
                $('#divDocumentList').show();
            }
        
            // Used  When Screen Resize than according to screen Size it manage the canvas size
            var getMachineHeight =$('#machinInner').outerHeight(true);
            var getMachineWidth = $('#machinInner').outerWidth(true);
            
            window.onresize = function() {
                var getMachineHeight =$('#machinInner').outerHeight(true);
                var getMachineWidth =$('#machinInner').outerWidth(true);
               var canvas = new fabric.Canvas('canvasElement');
               canvas.setWidth(getMachineWidth);      
               canvas.setHeight(getMachineHeight);      
            }

            // Create Canvas Object
             canvas = this.__canvas = new fabric.Canvas('canvasElement', {
                 isDrawingMode: true,
                 preserveObjectStacking: true ,
                 width:getMachineWidth, height:getMachineHeight
             });

             var oText = "";

             $(document).ready(function () {
                 var $ = function (id) {
                     return document.getElementById(id)
                 };
                 var drawingOptionsEl = $('drawing-mode-options'),drawingColorEl = $('drawing-color'),drawingLineWidthEl = $('drawing-line-width');
                 var currentHistoryState = -1;
                 var historyStates = [];


                 function getQueryVariable(variable) {
                     var query = window.location.search.substring(1);
                     var vars = query.split("&");
                     for (var i = 0; i < vars.length; i++) {
                         var pair = vars[i].split("=");
                         if (pair[0] == variable) {
                             return pair[1];
                         }
                     }
                     return (false);
                 }

                 //Set Canvas Default Options
                 var videoE = document.createElement('video');
                 videoE.width = canvas.width;
                 videoE.height = canvas.height;
                 videoE.muted = false;
                 videoE.setAttribute('autoplay',true);

                 // To Show Video Stream on Canvas object
                 prortc.on('remote_stream', function (stream, id) {
                         if (stream.id=='vsender0') {
                             videoE.srcObject = stream;
                             var fab_video = new fabric.Image(videoE, {
                                 left: 0,
                                 top: 0,
                                 selectable:false,
                                 width:canvas.width,
                                 height:canvas.height
                             });
                             canvas.add(fab_video);
                             fab_video.getElement().play();

                     }else{
                          $('remote_audio').srcObject = stream;
                     }
                 });

                 prortc.on('path:created', function (data) {
                     console.log('path:created ', data);
                     var pathLength = data.path.length;
                     var pathArray = [];
                     for (var i = 0; i < pathLength; i++) {
                         var subPath = data.path[i];
                         var subPathLength = subPath.length;
                         for (var j = 0; j < subPathLength; j++) {
                             pathArray.push(subPath[j]);
                         }
                     }
                     var path = new fabric.Path(pathArray.join(' '), data);
                     canvas.add(path);
                     canvas.forEachObject(function (o) {
                         o.selectable = false;
                     });
                     canvas.selectable = false;
                     canvas.renderAll();
                 });


                 prortc.on('object:removed', function (data) {
                     if (userType == 'user') {
                         var obj = canvas.getObjects();
                         for (var z = 0; z < obj.length; z++) {
                             if (z > 0) {
                                 canvas.remove(obj[z]);
                             }
                         }
                     }
                 });

                 function generateId() {
                     function s4() {
                         return Math.floor((1 + Math.random()) * 0x10000)
                                 .toString(16)
                                 .substring(1);
                     }
                     return s4();
                 }

                 /* Saves canvas history of changes. */
                 function saveHistoryState() {
                     if (currentHistoryState != -1) {
                         historyStates = historyStates.slice(0, currentHistoryState + 1);
                     }
                     historyStates.push(canvas.toJSON(['id']));
                     currentHistoryState = historyStates.length - 1;
                 }

                 fabric.util.requestAnimFrame(function render() {
                         canvas.selectable = false;
                         canvas.renderAll();
                         fabric.util.requestAnimFrame(render);
                 });

                 canvas.on('object:modified', function (event) {
                     var data = (event.target).toJSON(['id']);
                 });

                 canvas.on('object:added', function (event) {

                 });

                 canvas.on('object:hoverCursor',function(event){
                     alert("test");
                 });

                 canvas.on('hoverCursor',function(event){
                     alert("test");
                 });

                 canvas.on('text:changed', function(e) {
                     emit_text();
                 });

                 canvas.observe('object:scaling', function (e) {
                     //canvas.isDrawingMode = true;
                 });

                 // When Text Move in Canvas
                 canvas.observe('object:moving', function (e) {
                    console.log('object:moving');
                    var text = "";
                     var brushColor = jQuery("#draw-color").val();
                     var obj = canvas.getActiveObject();
                     if (obj && obj.isType('textbox')) {
                         text = obj
                     } else {
                         canvas.isDrawingMode = true;
                     }
                     if(text != ""){
                         var drawinglinewidth = jQuery("#drawing-line-width").val();

                         jQuery("#lastWrittedText").val(text.text);
                         //console.log(type: 'text', stroke: brushColor, device_height: getMachineHeight, device_width: getWidth,stroke_size:drawinglinewidth, text: text.text, X: text.left, Y: text.top,platform:'web');
                         socket.emit('path:created', {type: 'text', stroke: brushColor, device_height: getMachineHeight, device_width: getMachineWidth,stroke_size:drawinglinewidth, text: text.text, X: text.left, Y: text.top,platform:'web'});
                     }
                 });

                 canvas.on('object:removed', function (event) {
                     console.log('object:removed', event.target);
                     prortc.socket.emit('object:removed', (event.target).toJSON(['id']));
                     saveHistoryState();
                 });

                 canvas.on('path:created', function (event) {
                     console.log(event);
                     jQuery("#drawing-line-width").hide();
                     jQuery(".canvas-option").each(function(){
                        jQuery(this).removeClass('active'); 
                     });
                     event.path.id = generateId();
                     var brushColor = jQuery("#draw-color").val();
                     var drawinglinewidth = jQuery("#drawing-line-width").val();

                     console.log(event.path);
                     //prortc.socket.emit('path:created', (event.path).toJSON(['id']));
                        socket.emit('path:created', {type:'path', stroke: brushColor, device_height: getMachineHeight, device_width: getMachineWidth,stroke_size:drawinglinewidth,aCoords:event.path.aCoords,oCoords:event.path.oCoords,path:event.path.path,stroke_size:event.path.strokeWidth,top:event.path.top,platform:'web'});    
                     
                     saveHistoryState();
                 });

                 fabric.Object.prototype.transparentCorners = false;

                 $('drawing-mode-selector').onchange = function () {
                     canvas.freeDrawingBrush = new fabric[this.value + 'Brush'](canvas);
                     if (canvas.freeDrawingBrush) {
                         canvas.freeDrawingBrush.color = drawingColorEl.value;
                         canvas.freeDrawingBrush.width = parseInt(drawingLineWidthEl.value, 10) || 1;
                     }
                 };

                 drawingColorEl.onchange = function () {
                     canvas.freeDrawingBrush.color = this.value;
                     document.getElementById("draw-color").value= this.value;
                 };

                 drawingLineWidthEl.onchange = function () {
                     canvas.freeDrawingBrush.width = parseInt(this.value, 10) || 1;
                     var canvasWidth = canvas.freeDrawingBrush.width;
                     setTimeout(function () {
                         document.getElementById('draw_width').innerHTML = canvasWidth;
                     }, 100);
                     this.previousSibling.innerHTML = this.value;

                     var obj = canvas.getActiveObject();
                     if (obj && obj.isType('textbox')) {
                         canvas.getActiveObject().set("fontSize", canvasWidth);
                         canvas.renderAll(); 
                         emit_text();
                     } 
                 };

                 if (canvas.freeDrawingBrush) {
                     canvas.freeDrawingBrush.color = drawingColorEl.value;
                     canvas.freeDrawingBrush.width = parseInt(drawingLineWidthEl.value, 10) || 1;
                 }
             });

             //To Clear Canvas
             var clearCounter = 0;
             function clear_canvas(id){
                 $("#lastWrittedText").val('');
                 $(".canvas-option").each(function(){
                    $(this).removeClass('active'); 
                 });
                 $("#"+id).addClass('active');
                 clearCounter++;
                 var obj = canvas.getObjects();
                     var objLenght = obj.length*2;
                     for (var z = 0; z < objLenght; z++) {
                         if (z > 0) {
                             canvas.remove(obj[z]);
                         }
                     }
                     if(clearCounter < 5){
                         clear_canvas(id);
                     } else {
                         clearCounter = 0;
                     }
                     canvas.remove(oText);
                     socket.emit('path:created', {type: 'clear'});
             }

             //Add Canvas Text
             function addCanvasText(id) {
                 $("#drawing-line-width").hide();
                 var obj = canvas.getObjects();
                 var objLenght = obj.length
                 for (var z = 0; z < objLenght; z++) {
                         if (z > 0) {
                              if (obj[z] && obj[z].isType('textbox')) {
                                 canvas.remove(obj[z]);
                             }
                         }
                     }

                 var lastWrittedText = $("#lastWrittedText").val();
                 var drawinglinewidth = $("#drawing-line-width").val();
                 $(".canvas-option").each(function(){
                    $(this).removeClass('active'); 
                 });
                 if(drawinglinewidth > 10){
                     drawinglinewidth = 8;
                 }
                 $("#"+id).addClass('active');
                 canvas.selection  = false;
                 var brushColor = $("#draw-color").val();
                 canvas.isDrawingMode = false;
                 oText = new fabric.Textbox(lastWrittedText, {
                     width: 150,
                     top: 50,
                     left: 50,
                     hasRotatingPoint: false,
                     fontSize: drawinglinewidth,
                     textAlign: 'center',
                     fill: brushColor
                 });
                 canvas.add(oText);
                 canvas.setActiveObject(oText);
                 canvas.renderAll(); 
             }

            // Function called when SE wants to draw something on canvas
             function draw_canvas(id) {
                 $("#drawing-line-width").hide();
                 $(".canvas-option").each(function(){
                    $(this).removeClass('active'); 
                 });
                 var drawinglinewidth = $("#drawing-line-width").val();
                 $("#"+id).addClass('active');
                 var text = "";
                 var brushColor = $("#draw-color").val();
                 var obj = canvas.getActiveObject();
                 if (obj && obj.isType('textbox')) {
                     text = obj
                     obj.fontSize = drawinglinewidth;
                 }
                 if(text != ""){
                     $("#lastWrittedText").val(text.text);
                     socket.emit('path:created', {type: 'text', stroke: brushColor, device_height: getMachineHeight, device_width: getMachineWidth,stroke_size:drawinglinewidth, text: text.text, X: text.left, Y: text.top,platform:'web'});
                 }
                 canvas.isDrawingMode = true;
                 canvas.selectable = false;
             }

            //Function call to emit written text on canvas
             function emit_text() {
                 $("#drawing-line-width").hide();
                 var drawinglinewidth = $("#drawing-line-width").val();
                 var text = "";
                 var brushColor = $("#draw-color").val();
                 var obj = canvas.getActiveObject();
                 if (obj && obj.isType('textbox')) {
                     text = obj
                     obj.fontSize = drawinglinewidth;
                     obj.fill = brushColor;
                 }

                 if(text != ""){
                     if(drawinglinewidth < 5){
                         drawinglinewidth = 8;
                     }
                     $("#lastWrittedText").val(text.text);
                     socket.emit('path:created', {type: 'text', stroke: brushColor, device_height: getMachineHeight, device_width: getMachineWidth,stroke_size:drawinglinewidth, text: text.text, X: text.left, Y: text.top,platform:'web'});
                 }
                 canvas.selectable = false;
             }

             // This is for developer testing
             function load_streaming(){
                 var videoE = document.createElement('video');
                     videoE.width = canvas.width;
                     videoE.height = canvas.height;
                     videoE.muted = false;
                     videoE.setAttribute('autoplay',true);

                     prortc.on('remote_stream',
                         function (stream, id) {
                             if (stream.id=='vsender0') {
                             //$('remote').srcObject = stream;
                                 //console.log('remote_stream', stream);

                                 videoE.srcObject = stream;
                                 var fab_video = new fabric.Image(videoE, {
                                     left: 0,
                                     top: 0,
                                     selectable:false,
                                     width:canvas.width,
                                     height:canvas.height
                                 });
                                 canvas.add(fab_video);
                                 fab_video.getElement().play();

                         }else{
                              $('remote_audio').srcObject = stream;
                            }
                         }
                 );

             }

             (function () {
                 fabric.util.addListener(fabric.window, 'load', function () {
                     var canvas = this.__canvas || this.canvas,
                             canvases = this.__canvases || this.canvases;
                     canvas && canvas.calcOffset && canvas.calcOffset();
                     if (canvases && canvases.length) {
                         for (var i = 0, len = canvases.length; i < len; i++) {
                             canvases[i].calcOffset();
                         }
                     }
                 });
             })();
    </script>