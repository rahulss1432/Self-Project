@if($documents->count() >0)
<ul class="document_list list-unstyled" id="documentList">
    @foreach($documents as $document)
    @if($document->document_type == 'doc')
    <li><a href="{{getDocUrl($document->pdf_upload)}}" target="_blank">{{$document->title}}</a></li>
    @else
    <input type="hidden" name="hdnValue_{{$document->id}}" id="hdnValue_{{$document->id}}" value='{{$document->content}}'>
    <li><a href="javascript:void(0);" onclick="documentView('{{$document->title}}',{{$document->id}});">{{$document->title}}</a></li>
    @endif
    @endforeach
</ul>
{{$documents->links()}}
<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            pageDivLoader('show', 'divDocumentList');
            var $this = $(this);
            var pageLink = $this.attr('href');
            var searchString = $("#searchFilterForm").serializeArray();
            $.ajax({
                type: 'POST',
                url: pageLink,
                data: searchString,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#divDocumentList").html(response.html);
                }
            });
        });
    });

</script>

@else
<div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
@endif
