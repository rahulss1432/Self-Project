@if($notesHistory->count() >0)
<div class="document_info">
     <div class="accordion" id="accordionExample">
    @foreach($notesHistory as $note)    
       
            <div class="card">
                <div class="card-header" id="historyheadingOne">
                    <a href="javascript:void(0);" class="bg-transparent p-0 border-0 collapseClass collapsed" data-toggle="collapse" onclick="getNotesData('<?php echo $note->created_at ?>','<?php echo $note->customer_id ?>','<?php echo $note->id ?>')" data-target="#historyOne_{{$note->id}}" aria-expanded="false" aria-controls="historyOne">
                        <i class="icon-calendar"></i> {{showFullMonthDateFormat($note->created_at)}} <i class="more-less"></i>
                    </a>
                </div>

                <div id="historyOne_{{$note->id}}" class="collapse" aria-labelledby="historyheadingOne" data-parent="#accordionExample">
                    
                </div>
            </div>
    @endforeach
        </div>    
    </div>
@else
<div class="alert alert-danger text-center">{{\Config::get('constants.no_record_found')}}</div>
@endif
{{$notesHistory->links()}}
<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            pageDivLoader('show', 'divDocumentList');
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: 'GET',
                url: pageLink,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#notesHistory").html(response.html);
                }
            });
        });
    });

// Get All Notes Data
function getNotesData(callDate,customerId,noteId){

    console.log($("#historyOne_"+noteId).hasClass('show'));
    if(!$("#historyOne_"+noteId).hasClass('show')){
        $.ajax({
                type: 'POST',
                data:{callDate:callDate,customerId:customerId,_token: '{{ csrf_token() }}'},
                url: "{{url('notes-history-list-by-date')}}",
                success: function (response) {
                    $("#historyOne_"+noteId).html(response.html);
                }
            });
    } else {
        setTimeout(function(){
            $("#historyOne_"+noteId).removeClass('show');
            $(".collapse").each(function(){
                $(this).collapse('hide');
                $(this).html("");
            });
            console.log("else");
            $(".collapseClass").addClass('collapsed');
            $(".collapseClass").each(function(){
                
                $(this).attr('aria-expanded','false');
            });
        },1000);
        
    }
    
}
</script>
