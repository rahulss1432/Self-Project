<?php
if (!empty($callData)) {
    foreach ($callData as $val) {
        ?>
        <div class="card-body">
            <div class="d-flex riqst-detail-headin align-items-start justify-content-between">
                <div class="se-name">
					<span>SE Name</span> <?php echo \App\Http\Models\User::getUserDataByKey($val->executive_id, 'contact_name') ?>
                </div> 
                <div class="time d-flex align-items-center">
                   <i class="icon-clock "></i>
                    <span>Time:</span>  <?php echo date("H:i:s", strtotime($val->created_at)); ?>
				</div>
            </div>
            <div class="notes">
            	<span>Notes</span>
            	<p class="m-0">{!!$val->notes!!}</p>
            </div>
            
        </div>            
        <?php
    }
}
?>