
<div class="user-dtl-top d-sm-flex justify-content-between">
    <div class="left-dtl d-flex align-items-center">
        <div class="user-avtar">
            <img src="{{getImage($user->profile_image,'users','users')}}" alt="User" class="rounded-circle">
        </div>
        <div class="user-name ">
            <h3 class="font-hy">{{ucfirst($user->contact_name)}}</h3>
            <p>{{!empty(getCategoryByExecutive($user->id)) ? getCategoryByExecutive($user->id) : ''}}</p>
        </div>
    </div>
</div>
<div class="user-dtl-in">
    <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
        <div class="label">Company</div>
        <div class="right font-hy">{{!empty($user->company_name) ? $user->company_name : '-'}}</div>
    </div>
    <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
        <div class="label">Email Address</div>
        <div class="right font-hy">{{$user->email}}</div>
    </div>
    <div class="wrap d-block d-sm-flex align-items-center justify-content-between">
        <div class="label">Location</div>
        @php 
        $location = '';
        if($user->city != '' && $user->state != ''){
            $location = $user->city.', '.$user->state;
        } else if($user->city == '' && $user->state == ''){
            $location = '-';
        } else if($user->city == ''){
            $location = $user->state;
        } else if($user->state == ''){
            $location = $user->city;
        }
        @endphp
        <div class="right font-hy">{{ $location }}</div>
    </div>
    <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
        <div class="label">Phone No.</div>
        <div class="right font-hy">{{!empty($user->phone_number) ? $user->phone_number : '-'}}</div>
    </div>
    
    
</div>

<h4>Supervisor Detail</h4>
<div class="user-dtl-in">
    <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
        <div class="label">Name</div>
        <div class="right font-hy">{{!empty($userSuperVisor->name) ? $userSuperVisor->name : '-'}}</div>
    </div>
    <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
        <div class="label">Email Address</div>
        <div class="right font-hy">{{!empty($userSuperVisor->email) ? $userSuperVisor->email : '-'}}</div>
    </div>
    <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
        <div class="label">Phone Number</div>
        <div class="right font-hy">{{!empty($userSuperVisor->phone_number) ? $userSuperVisor->phone_number : '-'}}</div>
    </div>
</div>

