<main class="main-content calling-page call-screen" id="" style="display:none">
    <section class="colling-wrapper">
        <div class="call-detail">
            <div class="call-detail-in">
                <div class="avtar-wrap">
                    <div class="circle-ripple"></div>
                    <img id="calling_customer_image" src="">
                </div>
                <div class="name">
                    <h3 class="font-hy" id="calling_customer_name"></h3>
                    <p class="font-md">Linking...</p>
                </div>
                <div class="btn-box">
                    <a href="javascript:void(0);" class="incomming  align-items-center justify-content-center" onclick="accept_call()" style="display:none; pointer-events:none;" ><i class="icon-call"></i></a>
                    <a href="javascript:void(0);" class="outgoing1  align-items-center justify-content-center" onclick="reject_call()" style="display:none"><i class="fas fa-phone"></i></a>
                </div>
            </div>
        </div>
    </section>
</main>
<input type="hidden" name="hdnSocketId" id="hdnSocketId" value="">
<input type="hidden" name="requestId" id="requestId" value="212">