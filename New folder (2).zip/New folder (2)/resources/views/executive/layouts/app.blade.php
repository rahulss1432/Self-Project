<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link rel="apple-touch-icon" sizes="76x76" href="{{url('public/images/favicon/apple-touch-icon.png')}}">
	<link rel="icon" type="image/png" sizes="32x32" href="{{url('public/images/favicon/favicon-32x32.png')}}">
	<link rel="icon" type="image/png" sizes="16x16" href="{{url('public/images/favicon/favicon-16x16.png')}}">
	<link rel="manifest" href="{{url('public/images/favicon/site.webmanifest')}}">
	<link rel="mask-icon" href="{{url('public/images/favicon/safari-pinned-tab.svg')}}" color="#00c7ff">
	<meta name="msapplication-TileColor" content="#2d89ef">
	<meta name="theme-color" content="#0ab1ff">
        <meta http-equiv="Cache-control" content="no-cache">
        <link rel="stylesheet" href="{{url('public/css/iocnmoon.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/dataTables.bootstrap4.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/bootstrap.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/fontawesome.min.all.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/bootstrap-select.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/tempusdominus-bootstrap-4.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/custom.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/toastr.min.css')}}" type="text/css">
        
        <!-- js script -->

        
        <script src="{{url('public/js/jquery.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/jquery.dataTables.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/dataTables.bootstrap4.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/popper.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/bootstrap.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/bootstrap-select.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/moment.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/tempusdominus-bootstrap-4.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/jsvalidation.min.js')}}"></script>
        <script src="{{url('public/js/toastr.js')}}"></script>
        <script src="{{url('public/js/fabric.js')}}"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js" type="text/javascript"></script>
        <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/2.3.6/fabric.min.js"></script>-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.0.4/socket.io.js"></script>
        <script src="{{url('public/js/prortc.js')}}"></script>
        <title>Linked-Assist | @yield('title')</title>
    </head>
    <body class="">
        @guest
        <header class="header" id="main_header">
            <nav class="navbar navbar-light pl-0 pr-0">
                <div class="container">
                    <a href="{{url('/')}}" class="navbar-brand text-uppercase font-hy">
                        linked assist
                    </a>
                </div>
            </nav>
        </header>          
        @else        
        @include('executive.layouts.header_inner')   
        @endguest
        @yield('content')
        @include('executive.layouts.footer')    

        @php $waitingTime = 0; $code=0; @endphp
            @if(!empty(Auth::guard()->user()->id))
            @php  $userId = Auth::guard()->user()->id; 
             $userName = \App\Http\Models\User::getUserDataByKey($userId, 'contact_name'); 

             $image = \App\Http\Models\User::getUserDataByKey($userId, 'profile_image'); 

                $callerImage = getImage($image, 'users', 'users'); 
                $waitingTime = getWaitingTimeByUserId($userId);
                $waitingTime = $waitingTime*60;
                
                $code = session()->get('login_code');
                @endphp
            @endif
            
        <input type="hidden" name="hdnCustomerId" id="hdnCustomerId" value="">
        <input type="hidden" name="hdnTicketId" id="hdnTicketId" value="">
        <input type="hidden" name="hdnReceiverId" id="hdnReceiverId" value="">
        <input type="hidden" name="waitingTime" id="waitingTime" value="{{$waitingTime}}">
        <input type="hidden" name="isCallContinew" id="isCallContinew" value="0">
        <input type="hidden" name="hdnSeLIst" id="hdnSeLIst" value="">
        <input type="hidden" name="isCallAccepted" id="isCallAccepted" value="0">
        <input type="hidden" name="lastWrittedText" id="lastWrittedText" value="">
        <input type="hidden" name="socketHdnId" id="socketHdnId" value="">
        <input type="hidden" name="isFeedbackFormOpen" id="isFeedbackFormOpen" value="0">
        <input type="hidden" name="hdnLoginCode" id="hdnLoginCode" value="{{$code}}">
        <input type="hidden" name="hdnRoom" id="hdnRoom" value="">
        <input type="hidden" name="isPeerConnected" id="isPeerConnected" value="0">
        @guest

@else
        <script>
            $().ready(function(){
               check_login_staus(); 
            });

            var callTime = 0;
            var callInterval  = "";
             prortc.socket = io.connect('https://prortc.com:9800/');
             

                $(window).on('load', function() {
                    let options;
                    options = {
                        video: false,
                        audio: true
                    }
                    prortc.startCall(options,function (stream) {},
                        function (error) {
                        console.log(error);
                        }
                    );
                });
            

            var socket=prortc.socket;
            prortc.createPeerConnection(prortc.socket.id);
                setTimeout(function(){
                    prortc.addStreams(); 
                },1000);
            console.log("Connect");

            prortc.joinRoom({
                type: 'se',
                userId:'<?php echo @$userId ?>'
            });

            socket.on('se_joined', function (data) {
              console.log('se_joined',data);
            });

        socket.on('show-online', function (data) {
            console.log('show-online',data);
            var userId = '{{Auth::guard()->user()->id}}'
            $(".customer_"+data.userJID).removeClass('offline').addClass('online');
            $(".show_login_status_"+data.userJID).html('online');
            $(".link_"+data.userJID).show();
            if(data.userJID == userId){
                var hdnLoginCode = $("#hdnLoginCode").val();
                $.ajax({
                    type: "POST",
                    data: {hdnLoginCode:hdnLoginCode, _token: '{{csrf_token()}}'},
                    url: "{{url('check-login-code')}}",
                    dataType: "JSON",
                    success: function (response) {
                        console.log(response.success);
                        if(!response.success){
                            var isCallAccepted = jQuery("#isCallAccepted").val();
                            //if(isCallAccepted == 0){
                            $("#isCallAccepted").val(0);
                            $("#logout-btn").trigger('click')
                            //}
                        }
                    }

                });
                
            }
        });

        // Check SE Exist
        socket.on('se_exist', function (data) {
          console.log("se_exist",data);
        });

        /*When User Goes Offline*/
        socket.on('get-offline', function (data) {
          $(".customer_"+data.userJID).removeClass('online').addClass('offline');
          $(".show_login_status_"+data.userJID).html('offline');
          $(".link_"+data.userJID).hide();
        });
        
        //Receive Accept Confirmation Back to caller
         prortc.on('get-accept-request',function(packet){
            $("#hdnSocketId").val(packet.socketId);  
            $(".call-screen").hide();
            $(".main-page").show();
            $("#content").hide();
            $("#call-page-content").css({"position":'relative',"opacity":'1','top':'inherit','z-index':'inherit'});
        });

        //When User Manually End Current Call
        prortc.on('end_call',function(data){
            console.log("openAddNoteModal3",data);
            toastrAlertMessage('error', 'End Call');
            openAddNoteModal();
            $.ajax({
                type: "POST",
                data: {_token: '{{csrf_token()}}'},
                url: "{{url('mark-as-free')}}",
                async: false,
                success: function (response) {
                    
                }
            });
       });

        // Receive Call Request Offer From Customer
        prortc.on("receive_offer",function(packet){
            console.log("receive_offer",packet);
            var flag = 0;
             $.ajax({
                type: "POST",
                data: {_token: '{{csrf_token()}}'},
                url: "{{url('check-current-call-status')}}",
                dataType: "JSON",
                async: false,
                success: function (response) {
                    if(!response.success){
                        flag = 1;
                    } 
                }
            });
            var isCallContinew = $("#isCallContinew").val();
            var hdnCustomerId = $("#hdnCustomerId").val();
            // Check is SE already has on another call if so than it will not show calling Screen
            if(isCallContinew == "0" && flag == 0 && hdnCustomerId == ""){
                var userJID = packet.fromUserId;          
                var ticketId = packet.ticketId;
                $("#hdnRoom").val(packet.room);
                $("#isCallContinew").val(1);
                $("#hdnSeLIst").val(packet.seList);
                $("#hdnTicketId").val(packet.ticketId);
                $("#hdnTicketId").val(ticketId);
                $("#hdnCustomerId").val(userJID);
                $("#EditHistory").modal('hide');
                $("#viewHestory").modal('hide');
                $("#profile").modal('hide');
                get_call_page_content();
                setTimeout(function(){
                    $(".main-page").hide();
                    $(".actual-content").hide();
                    $(".call-screen").show();
                    $('body').css('overflow','hidden');
                    $("#calling_customer_name").html(packet.name);
                    $("#calling_customer_image").attr('src',packet.image);
                    $("#calling_customer_name").html($("#customerName_"+userJID).html());
                    var customerImage = $("#customer_image_"+userJID).attr('src');


                    $(".incomming").show();
                    $(".outgoing").hide();
                    var i = 0;
                    callInterval = setInterval(function(){ 
                        i = parseInt(i)+1;
                        if(i == {{$waitingTime}}){
                            $(".incomming").hide();
                            toastrAlertMessage('error', 'Call Timeout');
                            setTimeout(function(){
                               location.reload(true);
                            },2000);
                        }
                    }, 1000);
                },2000);
                setTimeout(function(){
                    $(".incomming").css('pointer-event',"default");
                },3000);

            }
        });
        
        // When Customer Accept Call Request Than this is call back event
        prortc.on('receive_answer',function(packet){
            console.log("socketHdnId",packet.socketId);
            $("#socketHdnId").val(packet.socketId);
            $("#isCallContinew").val(1);
            $("#isCallAccepted").val(1);
            setInterval(function(){ 
                callTime = parseInt(callTime)+1;
            }, 1000);
        })
        
        // Receive When Customer manually Reject Call Before Call accepting 
        socket.on("reject_request",function(packet){
            var isFeedbackFormOpen = $("#isFeedbackFormOpen").val();
            if(isFeedbackFormOpen == 0){
            console.log("Reject Call",packet);
            var hdnCustomerId = $("#hdnCustomerId").val();
            var isCallAccepted = $("#isCallAccepted").val();
            var isCallContinew = $("#isCallContinew").val();
            console.log('hdnCustomerId',hdnCustomerId);
            console.log('packet.fromUserId',packet.fromUserId);
            if(hdnCustomerId == packet.fromUserId){
                $(".incomming").hide();
                toastrAlertMessage('error', 'Customer Reject Call Request');
                setTimeout(function(){
                        location.reload(true);
                     },2000);
            }
            setTimeout(function(){
                if(hdnCustomerId == packet.fromUserId){
                    $(".incomming").hide();
                toastrAlertMessage('error', 'Customer Reject Call Request');
                setTimeout(function(){
                        location.reload(true);
                     },2000);
                }
            },3000);
        }
        });
        
        //Customer Disconnect
        socket.on('user_disconnect',function(packet){
           console.log('user_disconnect1',packet);
           var hdnCustomerId = $("#hdnCustomerId").val();
           var isCallAccepted = $("#isCallAccepted").val();
           var userId = '{{Auth::guard()->user()->id}}'
           if(isCallAccepted == 0){
            if(hdnCustomerId == packet.userId){
                $(".incomming").hide();
                toastrAlertMessage('error', 'Customer Disconnected from socket');
                 setTimeout(function(){
                     location.reload(true);
                  },2000);
            } else if(userId == packet.userId) {
                //toastrAlertMessage('error', 'You are disconnected from socket please wait we are trying to reconnect');
                 setTimeout(function(){
                   //  location.reload(true);
                  },2000);
            }
          }
        });
        
        // Receive When Customer Left Room Or Socket
        socket.on("user_left",function(packet){
            var reason = "";
            console.log('user_left1',packet);
            var isCallAccepted = $("#isCallAccepted").val();
            var hdnCustomerId = $("#hdnCustomerId").val();
            var socketHdnId = $("#socketHdnId").val();
            var isPeerConnected = $("#isPeerConnected").val();
            console.log('hdnCustomerId',hdnCustomerId);
            console.log('packet.userId',packet.userId);
            // Check whether the user left id is same as my current customer id
            if(hdnCustomerId == packet.userId){
                // Check If Call accepted or not
                if(isCallAccepted == 1){
                    if(isPeerConnected == 1){
                        console.log("openAddNoteModal1");
                        reason = 'User Left From Socket';
                        toastrAlertMessage('error', 'User Left From Socket');
                        openAddNoteModal();
                        update_call_status();
                    } else {
                        toastrAlertMessage('error', 'Call Dropped');
                        $("#isCallAccepted").val(0);
                        setTimeout(function(){
                            location.reload(true);
                        },2000);
                        
                    }
                } else{
                    $("#isCallAccepted").val(0);
                   //toastrAlertMessage('error', 'User Left From Socket');
                    //setTimeout(function(){
                        location.reload(true);
                     //},2000);
                }
            } else {
                if(isCallAccepted == 1){
                    console.log(prortc.offerData);
                    if(typeof prortc.offerData === "undefined"){
                        if(socketHdnId == packet.socketId){
                           // reason = 'User Left';
                           // toastrAlertMessage('error', 'User Left');
                           // openAddNoteModal();
                           // console.log("openAddNoteModal5");    
                        }
                    } else if(prortc.offerData.from === packet.socketId){
                        if(isPeerConnected == 1){
                            reason = 'User Left From Room';
                            toastrAlertMessage('error', 'User Left From Room');
                            console.log("openAddNoteModal2");
                            openAddNoteModal();
                            update_call_status();
                        } else {
                            toastrAlertMessage('error', 'Call Dropped');
                            $("#isCallAccepted").val(0);
                            setTimeout(function(){
                                location.reload(true);
                            },2000);
                        }
                    }
                }
            }
            setTimeout(function(){
                $("#hdnCallDisconnectReason").val(reason);
            },2000);
        });
        
        // Receive When Romm Full
        socket.on("room_full",function(packet){
            console.log('room_full',packet);
            var hdnCustomerId = $("#hdnCustomerId").val();
            var hdnRoom = $("#hdnRoom").val();
            var isCallAccepted = $("#isCallAccepted").val();
            var isCallContinew = $("#isCallContinew").val();
            // Check whether the senderId is same as my current customer id
            if(hdnCustomerId == packet.senderId){
                $(".incomming").hide();
                $("#isCallAccepted").val(0);
                toastrAlertMessage('error', 'Your Call Request has been accepted by another user');
                setTimeout(function(){
                    location.reload(true);
                 },2000);
            }
            if(typeof(packet.room) != "undefined"){
                if(packet.room == hdnRoom){
                    $(".incomming").hide();
                    $("#isCallAccepted").val(0);
                    toastrAlertMessage('error', 'Your Call Request has been accepted by another user');
                    setTimeout(function(){
                        location.reload(true);
                     },2000);
                }
            }
//            if(isCallAccepted != 1){
//                if(hdnCustomerId!=""){
//                    $(".incomming").hide();
//                    
//                toastrAlertMessage('error', 'Your Call Request has been accepted by another user');
//                setTimeout(function(){
//                        location.reload(true);
//                     },2000);
//                 }
//            }
        });
        
        // Received When the user which we have called is busy on another call
        socket.on('user_busy',function(data){
            var customerId = data.customerId;
            var ticketId = data.ticketId;
            $.ajax({
                type: "POST",
                data: {customerId:customerId,ticketId:ticketId, _token: '{{csrf_token()}}'},
                url: "{{url('send-busy-notification')}}",
                dataType: "JSON",
                success: function (response) {
                }
            });
           toastrAlertMessage('error', 'Customer is busy');
           setTimeout(function(){
               location.reload(true);
           },3000);
        });
        
        // Received When Call is accepted by my self
        socket.on('call_accepted',function(packet){
           console.log("call_accepted",packet);
           var isCallAccepted = $("#isCallAccepted").val();
           var userId = '{{Auth::guard()->user()->id}}'
           if(userId == packet.senderId){
                if(isCallAccepted == 0){
                    location.reload();
                }
            }
        });
        
        // Received When Customer Ice Failed
        prortc.on('ice_failed',function(data){
            var reason = "";
            var isCallContinew = jQuery("#isCallContinew").val();
            var isCallAccepted = jQuery("#isCallAccepted").val();
            var isFeedbackFormOpen = jQuery("#isFeedbackFormOpen").val();
            if(isCallContinew == 1 && isCallAccepted){
                if(isFeedbackFormOpen == 0){
                    toastrAlertMessage('error', 'Customer ice failed');
                    reason = 'Customer ice failed';
                    openAddNoteModal();
                    setTimeout(function(){
                        $("#hdnCallDisconnectReason").val(reason);
                    },2000);
                }
            } else {
                location.reload();
            }
        });

        // To Initiate Call to Customer
        function request_to_call(customerId,ticketId,requestType,$requestId,image,name,callFrom){
            $(".requestBtn").css('pointer-events','none');
            $("#isCallContinew").val(1);
            var userId = '{{Auth::guard()->user()->id}}'
            $.ajax({
                type: "POST",
                data:{'customerId':customerId,ticketId:ticketId,requestType:requestType,$requestId:$requestId,_token: '{{csrf_token()}}' },
                url: "{{url('create-call-request')}}",
                dataType:"JSON",
                success: function (response) {
                    if (response.success) {
                        if(requestType == "pending"){
                            $(".main-page").show();                                
                            $(".call-screen").hide();
                            $('body').css('overflow','inherit');
                            socket.emit('reject_request',{'customerId':customerId,'ticketId':ticketId,name:'<?php echo @$userName ?>',image:'<?php echo @$callerImage ?>'})
                              toastrAlertMessage('error', 'Call TimeOut');
                              setTimeout(function(){
                                location.reload(true);
                             },2000);
                        } else{
                            
                            $(".main-page").hide();
                            $(".actual-content").hide();                                
                            $(".call-screen").show();
                            $('body').css('overflow','hidden');
                            $("#hdnTicketId").val(ticketId);
                            get_call_page_content();
                            if(callFrom == "customer_request"){
                                $("#calling_customer_name").html($("#customerName_"+customerId).html());
                                var customerImage = $("#customer_image_"+customerId).attr('src');
                                console.log(customerImage);
                                $("#calling_customer_image").attr("src",customerImage);
                            } else {
                                $("#calling_customer_name").html(name);
                                $("#calling_customer_image").attr("src",image);
                            }

                            // For Initiate Call
                            $("#hdnCustomerId").val(customerId);
                            //Send Call Offer to Customer
                            prortc.sendOffer({'customerId':customerId,'ticketId':ticketId,name:'<?php echo @$userName ?>',image:'<?php echo @$callerImage ?>','fromUserId':userId,'isOneToOneCall':true});

                           // socket.emit('send-call-request', {'userJID': customerId,'callerId':<?php echo @$userId ?>,'ticketId':ticketId,name:'<?php echo @$userName ?>',image:'<?php echo @$callerImage ?>'});

                        }

                        $("#requestId").val(response.request_id);
                        var waitingTime = $("#waitingTime").val();
                        waitingTime = waitingTime*1000;
                        // Run till waiting time is over
                        setTimeout(function () {
                            var isCallAccepted = $("#isCallAccepted").val();
                            if(isCallAccepted == 0){
                                request_to_call(customerId,ticketId,'pending',response.request_id,image,name,callFrom);
                            }
                        }, waitingTime);
                    } else {
                        $(".requestBtn").css('pointer-events','');
                        toastrAlertMessage('error', response.message);
                    }
                }
            });

            socket.emit('join_room',{
                  room: ticketId
            });

            prortc.joinRoom({
                room: ticketId
            });
        }

        //When SE Accept Call
        function accept_call(){
            var hdnCustomerId = $("#hdnCustomerId").val();
            var hdnTicketId = $("#hdnTicketId").val();
            var hdnReceiverId = $("#hdnReceiverId").val();
            var hdnSeLIst = $("#hdnSeLIst").val();
            //Accept Call Request
            $("#isCallAccepted").val(1);
            $("#isCallContinew").val(1);
            //Clear Time Interval After SE Accept Call
            clearInterval(callInterval);
            prortc.sendAnswerToCustomer({'userJID':hdnCustomerId, 'ticketId':hdnTicketId,'name':'<?php echo @$userName ?>','image':'<?php echo @$callerImage ?>','seList':hdnSeLIst});
            $(".call-screen").hide();
            $('body').css('overflow','inherit');
            $(".main-page").show();
            $("#content").hide();
             $("#call-page-content").css({"position":'relative',"opacity":'1','top':'inherit','z-index':'inherit'});
                setInterval(function(){ 
                    callTime = parseInt(callTime)+1;
                }, 1000);

             if($(".main-page").is(":visible")){
                var getMachineWidth = $('#machinInner').outerWidth(true);
                localStorage.setItem('width', getMachineWidth);  
                var canvas = new fabric.Canvas('canvasElement');

                canvas.setWidth(getMachineWidth);
            }
            setTimeout(function(){
                console.log("Visible",$(".main-page").is(":visible"));
                if(!$(".main-page").is(":visible")){
                       $(".call-screen").hide();
                       $('body').css('overflow','inherit');
                        $(".main-page").show();
                        $("#content").hide();
                        $("#call-page-content").css({"position":'relative',"opacity":'1','top':'inherit','z-index':'inherit'});
                        load_streaming();
                    }
                    updateCallStatus();
            },3000);
        }
    
        //To Check When Login through Multiple device
        function check_login_code(){
            var hdnLoginCode = $("#hdnLoginCode").val();
            $.ajax({
                type: "POST",
                data: {hdnLoginCode:hdnLoginCode, _token: '{{csrf_token()}}'},
                url: "{{url('check-login-code')}}",
                dataType: "JSON",
                success: function (response) {
                    return response.success;
                }

            });
        }
    
        //To Update Current Call Status
        function updateCallStatus(){
            var ticketId = $("#hdnTicketId").val();
            $.ajax({
                type: "POST",
                data: {ticketId:ticketId, _token: '{{csrf_token()}}'},
                url: "{{url('update-user-call-status')}}",
                success: function (response) {
                }
            });
        }

        //To Get Call Screen
        function get_call_page_content() {
            var ticketId = $("#hdnTicketId").val();
            $.ajax({
                type: "POST",
                data: {ticketId:ticketId, _token: '{{csrf_token()}}'},
                url: "{{url('linked-notes')}}",
                dataType: "JSON",
                success: function (response) {
                    $(".incomming").css('pointer-events','');
                    //$("#call-page-content").hide();
                    $("#call-page-content").html(response.html);
                }
            });
        }
        
        function reject_call(){
            var socketId = $("#hdnSocketId").val();
            var userId = $("#hdnCustomerId").val();
            var ticketId = $("#hdnTicketId").val();
            console.log("Test end");
            socket.emit('end-user-call',{userId:userId,ticketId:ticketId});
            toastrAlertMessage('error', 'Reject_call');
            setTimeout(function(){
                location.reload(true);
            },1000);
        }

        // To Update Call Dropped Status
        function update_call_status(){
            $.ajax({
                type: "POST",
                data:{_token: '{{csrf_token()}}' },
                url: "{{url('update-dropped-user-call-request')}}",
                success: function (response) {
                }
           });   

        }
        
        //For My Testing
        function emitevent(){
            $.ajax({
                type: "POST",
                data:{'userId':5,_token: '{{csrf_token()}}' },
                url: "{{url('update-disconnct-user-call-request')}}",
                success: function (response) {

                }
           });
        }
        
        // Check login Status
        function check_login_staus(){
            var hdnLoginCode = $("#hdnLoginCode").val();
            $.ajax({
                type: "POST",
                data: {hdnLoginCode:hdnLoginCode, _token: '{{csrf_token()}}'},
                url: "{{url('check-login-code')}}",
                dataType: "JSON",
                success: function (response) {
                    console.log(response.success);
                    if(!response.success){
                        var isCallAccepted = jQuery("#isCallAccepted").val();
                        //if(isCallAccepted == 0){
                        $("#isCallAccepted").val(0);
                        $("#logout-btn").trigger('click')
                        //}
                    }
                }

            });
        }
    
        // Alert When User Refresh When User have current call
        $(window).bind('beforeunload',function(){
            var isCallAccepted = jQuery("#isCallAccepted").val();
            var isCallContinew = jQuery("#isCallContinew").val();
            if(isCallAccepted == 1){
               return 'are you sure you want to leave?';
            }
        });
    
        // To Check Internet Connection
        var timeInt = 0;
        setInterval(function(){ 
            // To set active user on socket
            timeInt = parseInt(timeInt)+1;
            if(timeInt == 6){
                timeInt = 0;
                console.log('set_active');
                socket.emit('set_active');
            }
            var online = window.navigator.onLine;
            console.log("online",online);
            if(!online){
                jQuery("#isCallContinew").val(0);
                jQuery("#isCallAccepted").val(0);
                toastrAlertMessage('error', 'Internet Connection goes down');
                setTimeout(function(){
                    location.reload(true);
                },2000);
            }
        }, 5000);
        
</script>
@endguest
</body>
</html>