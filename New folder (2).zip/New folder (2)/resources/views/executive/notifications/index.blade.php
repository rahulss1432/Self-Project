@extends('executive.layouts.app')
@section('title', 'Notification')
@section('content')
@php
$currentRoute = Request::route()->getName();
$userId = Auth::guard()->user()->id;
use Illuminate\Support\Facades\Auth;
@endphp
<main class="main-content requests-page main-page" id="content">
    <section class="tabs_section">
        <ul class="list-unstyled tabs_links d-flex justify-content-start">
            <li class="text-uppercase {{($currentRoute == 'executive-notification' )?'active':''}}"><a href="{{url('notification')}}">NOTIFICATIONS <span id="notificationCount">({{getUnreadNotificationCountByUserId($userId)}})</span></a></li>
            <li class="text-uppercase {{($currentRoute == 'executive-request' )?'active':''}}"><a href="{{url('customer-request')}}">CUSTOMER REQUESTS</a></li>
            <li class="text-uppercase {{($currentRoute == 'executive-history' )?'active':''}}"><a href="{{url('linked-history')}}">LINKED HISTORY</a></li>
        </ul>
        <div class="tabs_content">
            <div class="actual-content" id="getnotifications">
            </div>
        </div>
    </section>
</main>
<main class="main-content requests-page" id="call-page-content" style="position:absolute;opacity:0;width: 100%;top:0;z-index: -1"></main>
<!--<main class="main-content requests-page" id="call-page-content" style="display:none"></main>-->
<!--Include Calling Screen page to show incomming and outgoing calling screen-->
@include('executive.layouts.call-screen')
<script>
    $(document).ready(function () {        
        getNotificationslist();
    });
    
    //Function to get all notification list 
    function getNotificationslist() {
        $("#getnotifications").html('<div class="listloader text-center pb-4"><i class="fa-2x fa-spin fas fa-spinner"></i></div>');
        var url = '{{url("notification-list")}}';
        $.ajax({type: "GET", url: url,dataType: 'JSON',
            success: function (response) {
                
                    $("#getnotifications").html("");
                    $("#getnotifications").html(response.html);
                
            }
        });
    }
</script>
@endsection