<div class="table-responsive">
<table class="table no-border" id="notificationData">
    <thead>
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Message</th>
            <th>Date</th>
            <th width="140">ACTION</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if (count($notificationList) > 0) {
            foreach ($notificationList as $val) {
                $notificationData = json_decode($val->notification_data);
                ?>
                <tr>
                    <td width="100">
                        <div class="user_img">
                            <?php $image = \App\Http\Models\User::getUserDataByKey($val->from_id, 'profile_image'); ?>
                            <img src="{{getImage($image,'users','users')}}" alt="user" class="rounded-circle">
                        </div>
                    </td>
                    <td>
                        <div class="user_detail">
                            <h4><?php echo \App\Http\Models\User::getUserDataByKey($val->from_id, 'contact_name') ?></h4>
                            <p class="mb-0"><?php echo \App\Http\Models\User::getUserProfileDataByKey($val->from_id, 'bussiness_name') ?></p>
                        </div>
                    </td>
                    <td class="min1100"><?php echo $val->message; ?></td>
                    <td width="200">
                        <div class="user_tym">
                            <?php $data = json_decode($val->notification_data);?>
                            <i class="icon-clock"></i>{{showDateTime($val->created_at)}}
                        </div>
                    </td>
                    <td>
                    <?php
                    
                    $getTimeZone = getTimeZoneByUserId($val->to_id);
                    $currentTime = date('Y-m-d H:i:s');
                    
                    $time = strtotime($currentTime)- strtotime($val->created_at);
                    if($val->type == "missed_call_request"){
                    if($time < 300){ ?>
                        <!--<a href="{{url('/linked-notes')}}" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a>-->
                        <a href="javascript:void(0)" onclick="request_to_call('{{$notificationData->userJID}}','{{$notificationData->ticketId}}','missed_request','','{{$notificationData->caller_image}}','{{$notificationData->caller_name}}','notification')" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a>
                    <?php } }?>
                        </td>
                </tr>
            <?php }
        } else {
            ?>
            <tr>
                <td colspan="5"><div class="alert alert-danger">{{\Config::get('constants.no_record_found')}}</div></td>
            </tr>
        <?php } ?>
    </tbody>
</table>
</div>
<div class="pagination-wrap d-flex">{{ $notificationList->links() }}</div>
<script>
    
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
//            pageDivLoader('show', 'getlinkedhistory');
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: 'GET',
                url: pageLink,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#getnotifications").html(response.html);
                }
            });
        });
       
    });
    
    //ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });
</script>