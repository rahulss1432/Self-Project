@extends('executive.layouts.app')
@section('title', 'Linked History')
@section('content')
@php
$currentRoute = Request::route()->getName();
use Illuminate\Support\Facades\Auth;
$userId = Auth::guard()->user()->id;
@endphp
<main class="main-content requests-page main-page" id="content">
    <section class="tabs_section">
        <ul class="list-unstyled tabs_links d-flex justify-content-start">
            <li class="text-uppercase {{($currentRoute == 'executive-notification' )?'active':''}}"><a href="{{url('notification')}}">NOTIFICATIONS <span>({{getUnreadNotificationCountByUserId($userId)}})</span></a></li>
            <li class="text-uppercase {{($currentRoute == 'executive-request' )?'active':''}}"><a href="{{url('customer-request')}}">CUSTOMER REQUESTS</a></li>
            <li class="text-uppercase {{($currentRoute == 'executive-history' )?'active':''}}"><a href="{{url('linked-history')}}">LINKED HISTORY</a></li>
        </ul>
        <div class="tabs_content">
            <div class="actual-content" id="getlinkedhistory">
            </div>
            
        </div>
    </section>
</main>
<main class="main-content requests-page" id="call-page-content" style="position:absolute;opacity:0;width: 100%;top:0;z-index: -1"></main>
<!--<main class="main-content requests-page" id="call-page-content" style="display:none"></main>-->
@include('executive.layouts.call-screen')

<!-- Modal -->
<div class="modal fade common-modal" id="viewHestory" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="viewHestoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content history-modal" id="getViewHistory">            
        </div>
    </div>
</div>

<!-- edit history Modal -->
<div class="modal fade common-modal add_note" id="EditHistory" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="editHestoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header ">
                <div class="col text-left p-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="col p-0 text-center">
                    <h5 class="modal-title" id="editHestoryModalLabel">Note</h5>
                </div>
                <div class="col p-0 text-center">

                </div>
            </div>
            <div class="modal-body" id="getEditHistory">

            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {        
        getlinkedhistorylist();
    });

    // Load Linked History
    function getlinkedhistorylist() {
        pageDivLoader('show', 'getlinkedhistory');
        $.ajax({
            type: "GET",
            url: '{{url("linked-history-list")}}',
            success: function (response) {
                if (response.success) {
                    $("#getlinkedhistory").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    //History Modal
    function viewHestory(id) {
        $.ajax({
            type: "GET",
            url: '{{url("linked-history-view")}}',
            data: {id: id},
            success: function (response) {
                if (response.success) {
                    $("#getViewHistory").html(response.html);
                    $("#viewHestory").modal('show');
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    // Open Modal For Edit notes
    function editModalNote(id) {
        $("#viewHestory").modal('hide');
        editNote(id);
    }

    //Save Edit Notes
    function editNote(id) {
        $.ajax({
            type: "GET",
            url: '{{url("linked-history-edit")}}',
            data: {id: id},
            success: function (response) {
                if (response.success) {
                    $("#getEditHistory").html(response.html);
                    $("#EditHistory").modal('show');
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection