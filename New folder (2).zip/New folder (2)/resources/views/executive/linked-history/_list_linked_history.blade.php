<div class="table-responsive">
    <table class="table no-border linkedhistory" id="data_table">
        <thead>
            <tr>
                <th>IMAGE</th>
                <th>NAME</th>
                <th>ID</th>
                <th>CATEGORY</th>
                <th>TOTAL CALL TIME</th>
                <th>DATE OF CALL</th>
                <th>TIME</th>
                <th>STATUS</th>
                <th width="140">ACTION</th>
            </tr>
        </thead>
        <tbody>
            @if(count($seRequest) > 0) 
            @foreach($seRequest as $data)
            <tr>
                <td width="100">                
                    <div class="user_img">
                        <img src="{{checkProfileImage(!empty($data->customerDetail->profile_image) ? $data->customerDetail->profile_image : '')}}" alt="user" class="rounded-circle">
                    </div>                   
                </td>
                <td>
                    <div class="user_detail">
                        <h4>{{!empty($data->customerDetail->contact_name) ? ucfirst($data->customerDetail->contact_name) : ''}}</h4>
                        <p class="mb-0">{{!empty($data->UserProfile->bussiness_name) ? $data->UserProfile->bussiness_name : ''}}</p>
                    </div>
                </td>
                <td>ID: {{getTicketById($data->ticket_id)}}</td>
                <td>{{!empty($data->BankCategory->name) ? $data->BankCategory->name : ''}}</td>
                <td>
                    <div class="user_tym">
                        <i class="icon-clock"></i> {{gmdate("H:i:s", $data->call_time)}} mins
                    </div>
                </td>
                <td>
                    <div class="user_date">
                        <i class="icon-calendar"></i> 
                        {{ date('d M Y H:i', strtotime($data->created_at)) }}
                    </div>
                </td>
                <td>
                    <div class="user_date">
                        <i class="icon-calendar"></i> 
                        {{changeTimeAgo($data->created_at)}}
                    </div>
                </td>
                <td>
                    <div class="user_status {{$data->status == 'resolved' ? 'resolved' : 'pending'}}">
                        <span>{{$data->status}}</span>
                    </div>
                </td>
                <td>
                    <ul class="list_btns list-inline mb-0">
                        <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary btn-icon ripple-effect-dark" onClick="viewHestory('{{$data->id}}')"><i class="icon-eye"></i></a></li>
                        <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary ripple-effect-dark btn-icon" onclick="editNote('{{$data->id}}');"><i class="icon-pencil"></i></a></li>
                    </ul>
                </td>
            </tr>
            @endforeach
            @else
            <tr>
                <td colspan="9"><div class="alert alert-danger">{{\Config::get('constants.no_record_found')}}</div></td>
            </tr>
            @endif
        </tbody>
    </table>
</div>
<div class="pagination-wrap d-flex"> {{ $seRequest->links() }}</div>
<script>

            $(document).ready(function () {
                $(".pagination li a").on('click', function (e) {
                e.preventDefault();
                    pageDivLoader('show', 'getlinkedhistory');
                    var $this = $(this);
                    var pageLink = $this.attr('href');
                    $.ajax({
                    type: 'GET',
                            url: pageLink,
                            success: function (response) {
                            $('.pagination:first').remove();
                                    $("#getlinkedhistory").html(response.html);
                            }
                    });
                });
            });
            
            //ripple-effect for button
            $('.ripple-effect, .ripple-effect-dark').on('click', function(e) {
                var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;
                rippleDiv.css({
                top: rippleY - (rippleDiv.height() / 2),
                        left: rippleX - (rippleDiv.width() / 2),
                }).appendTo($(this));
                window.setTimeout(function() {
                    rippleDiv.remove();
                }, 800);
            });

</script>