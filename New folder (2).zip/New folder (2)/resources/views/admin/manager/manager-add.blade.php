@extends('admin.layouts.app')
@section('title', 'Add Merchant Processor')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Add Merchant Processor</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/manager')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <form id="addManagerForm" autocomplete="off" method="POST" action="{{url('admin/add-manager')}}" enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                
                                <input type="text" name="username" class="form-control username_field" autocomplete="off">
                           <label>Username<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                               
                                <input type="password" name="password" class="form-control" autocomplete="off">
                                 <label>Password<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>First Name<span class="text-danger">*</span></label>
                                <input type="text" name="first_name" class="form-control form-control-lg">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Last Name<span class="text-danger">*</span></label>
                                <input type="text" name="last_name" class="form-control form-control-lg">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Email<span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control form-control-lg">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Phone<span class="text-danger">*</span></label>
                                <input type="text" name="phone" class="form-control form-control-lg">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Company<span class="text-danger">*</span></label>
                                <input type="text" name="company" class="form-control form-control-lg">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Upload Image</label>
                                <div class="file-upload">
                                    <div class="file-select">
                                        <div class="file-select-button" id="fileName">Choose image</div>
                                        <div class="file-select-name" id="spanFileName"> &nbsp; No image chosen...</div> 
                                        <input type="file" name="image_file" id="imageUpload" onchange="uploadFile(this)">
                                        <input type="hidden" name="hiddenFileName" class="do-not-ignore" id="hiddenMediaFileName">                                                                                        
                                    </div>
                                </div>  
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <select name="waiting_time" title="Select Time" onchange="$(this).valid();" data-size="5" class="form-control selectpicker">
                                    <option value="">Select Waiting Time</option>
                                    @php
                                    for ($x = 1; $x <= 10; $x++) {
                                    @endphp
                                    <option value="{{$x}}" >{{$x}} Minute</option>
                                    @php
                                    } 
                                    @endphp
                                </select>
                                <label class="control-label">Select Waiting Time<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Customer limit<span class="text-danger">*</span></label>
                                <input type="text" name="customer_limit" class="form-control form-control-lg">
                            </div>
                        </div>
                    </div>
                    <div class="from-group">
                        <button id="btnAddManager" type="submit" class="btn btn-primary btn_radius submitButton">Save
                            <i id="addManagerFormLoader" class="fa fa-spin fa-spinner" style="display: none;"></i> 
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Admin\AddManagerRequest','#addManagerForm') !!}
            </div>
        </div>
    </div>
</main>

<!-- cropper-Modal -->
<div class="modal fade" id="cropper-image-modal" role="dialog" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" onclick="remove_image()">&times;</button>
            </div>
            <div id="image-cropper-form">
            </div>                            
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).on('submit', '#addManagerForm', function (e) {
        e.preventDefault();
        if ($('#addManagerForm').valid()) {
            $('#btnAddManager').prop('disabled', true);
            $('#addManagerFormLoader').show();
            var formData = new FormData($('#addManagerForm')[0]);
            $.ajax({
                url: "{{url('admin/add-manager')}}",
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('/admin/manager')}}";
                        }, 1000);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnAddManager').prop('disabled', false);
                    }
                    $('#addManagerFormLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#addManagerFormLoader').hide();
                        $('#btnAddManager').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });

    /* image uploading with cropper*/
    function uploadFile(thisEl) {
        if (thisEl.files[0]) {
            var inputFile = thisEl.files[0].name;
            var extension = inputFile.substr(inputFile.lastIndexOf('.') + 1); /*get file exension*/
            /*check file type and exension*/
            if (extension != 'jpg' && extension != 'jpeg' && extension != 'png') {
                toastrAlertMessage('error', 'Image allows only in jpeg, png or jpg format');
                $('#imageUpload').val('');
                $('#hiddenMediaFileName').val('');
                return false;
            }
            var formData = new FormData($('#addManagerForm')[0]); /*uploading on server via ajax call*/
            formData.append('_token', '{{ csrf_token() }}');
            $.ajax({
                url: "{{url('admin/upload-media-image')}}",
                type: 'POST',
                data: formData,
                processData: false,
                cache: false,
                contentType: false,
                beforeSend: function () {
                    $('#preloader').show();
                    pageDivLoader('show', 'image-cropper-form');
                },
                success: function (response) {
                    setTimeout(function () {
                        loadImageCropperModal(response.filename);
                    }, 1000);
                    $('#cropper-image-modal').modal('show');
                    $('#preloader').hide();
                }
            });
        }
    }

    function loadImageCropperModal(imageName) {
        $.ajax({
            url: "{{url('admin/load-image-cropper')}}",
            type: 'GET',
            data: {imageName: imageName, type: 'profile_image'},
            success: function (response) {
                $('#image-cropper-form').html(response.html);
            }
        });
    }

    function remove_image() {
        $('#imageUpload').val('');
        $('#hiddenMediaFileName').val('');
    }

</script>
@endsection