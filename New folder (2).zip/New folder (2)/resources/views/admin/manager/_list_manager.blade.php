@if(count($managers) >0)
<div class="table-responsive">
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Company Name</th>
            <th>Email</th>
            <th>Phone number</th>
            <th>Created Date</th>
            <th>Status</th>
            <th class="th_action no-sort">Action</th>
        </tr>
    </thead>
    <tbody>        
        @foreach($managers as $data)
        @php
        $bankName = \App\Http\Models\Bank::getBankByDucument($data->bank_id);
        @endphp
        <tr id="{{'managers'.$data->id}}">
            <td>{{$data->first_name.' '.$data->last_name}}</td>
            <td>{{$data->company_name}}</td>
            <td>{{$data->email}}</td>
            <td>{{$data->phone_number}}</td>
            <td>{{showFullMonthDateFormat($data->created_at)}}</td>
            <td>
                <div class="switch">
                    <label>
                        <input id="userStatus_{{$data->id}}" type="checkbox" onclick='changeStatus("{{$data->id}}" , "{{$data->status}}")' {{$data->status == 'active' ? 'checked':'' }} >
                        <span class="lever" for="userStatus_{{$data->id}}"></span>
                    </label>
                </div>
            </td>
            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="{{url('admin/manager-view',$data->id)}}">View</a>
                        <a class="dropdown-item" href="{{url('admin/manager-edit',$data->id)}}">Edit</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick='changeStatus("{{$data->id}}" , "deleted")'>Delete</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="changePassword('{{$data->id}}')">Change Password</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="sendDetail('{{$data->id}}')">Send Detail</a>
                    </div>
                     <span class="upload-icon d-inline-block ml-2">
                         <form id="csvImportForm{{$data->id}}" autocomplete="off" method="POST" action="javaScript:void(0);" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <label for="uploadCsv{{$data->id}}">
                            <input type="hidden" name="manager_id" class="form-control manager" value="{{$data->id}}">
                            <input type="file" name="csv_file" id="uploadCsv{{$data->id}}" class="csvUpload{{$data->id}} d-none"  onchange="csvUpload(this)">
                            <i class="fas fa-cloud-upload-alt"></i>
                            </label>
                         </form>
                    </span>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
</div>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
<div style='float:right; margin-top : 10px;'>{{ $managers->links() }}</div>
<script>
  /* Csv uploading*/
    function csvUpload(thisEl) {
        if (thisEl.files[0]) {
            var inputFile = thisEl.files[0].name;
            var extension = inputFile.substr(inputFile.lastIndexOf('.') + 1); /*get file exension*/
            var managerId = $(thisEl).parent().parent('form').find('.manager').val();
            /*check file type and exension*/
            if (extension != 'csv') {
                toastrAlertMessage('error', 'File allows only in csv format');
                $('.csvUpload'+managerId).val('');
                return false;
            }
            var formData = new FormData($('#csvImportForm'+managerId)[0]); 
            formData.append('_token', '{{ csrf_token() }}');
            $.ajax({
                url: "{{url('admin/csv-import')}}",
                type: 'POST',
                data: formData,
                processData: false,
                cache: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('/admin/manager')}}";
                        }, 2000);
                    } else {
                        toastrAlertMessage('error', response.message);
                        setTimeout(function () {
                           location.reload();
                        }, 2000);
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    }
    
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            pageDivLoader('show', 'manager_list');
            var search_filter = $("#search_form").serializeArray();
            search_filter.push('_token', '{{ csrf_token() }}');
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: "POST",
                url: pageLink,
                data: search_filter,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#manager_list").html(response.html);
                }
            });
        });
    });
</script>