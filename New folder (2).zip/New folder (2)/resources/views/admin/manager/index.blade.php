@extends('admin.layouts.app')
@section('title', 'Manage Merchant Processor')
@section('content')


<main class="main-content innerpages" id="mainContent">
    <!--  preloader-->

    <div id="preloader">
        <div class="inner">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Merchant Processor</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" id="sampleCsv">
                        <a href="{{url('public/CSV_Sample.csv')}}" download class="nav-link" data-toggle="tooltip" data-placement="top" title="Sample File">
                            <i class="fas fa-cloud-download-alt"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="{{ url('admin/manager-csv-download') }}" class="nav-link"><i class="fas fa-cloud-download-alt"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="{{url('admin/add-manager')}}" class="nav-link"><i class="fa fa-plus"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="fa fa-search"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <div class="filter_section collapse" id="searchFilter">
                    <form id="search_form" action="javascript:load_manager_list()" method="post" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label>Search By Name</label>
                                    <input type="text" id="name" name="name" class="form-control form-control-lg"/>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                                <div class="form-group">
                                    <label>Search By Company Name</label>
                                    <input type="text" name="company_name" class="form-control form-control-lg"/>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-5">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary ripple-effect-dark mr-2">Search</button>
                                    <button type="reset" id="reset-btn" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div id="manager_list">
                </div>
            </div>
        </div>
    </div>
</main>

<script type="text/javascript">

    $(document).ready(function ()
    {
        $('#preloader').hide();
        load_manager_list();
    });

    $("#reset-btn").click(function ()
    {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        load_manager_list();
    });

    function load_manager_list()
    {
        pageDivLoader('show', 'manager_list');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "POST",
            url: "{{ url('admin/manager-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#manager_list").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function changeStatus(id, status) {
        var token = '{{ csrf_token() }}';
        if (status == 'deleted') {
            var newStatus = status;
            var confirmMsg = "Are you sure want to delete this manager ?";
        } else {
            var newStatus = status == 'active' ? 'inactive' : 'active';
            var confirmMsg = "Are you sure want to change manager status ?";
        }
        bootbox.confirm(confirmMsg, function (result) {
            if (result == true) {
                $.ajax({
                    url: "{{url('/admin/change-user-status')}}",
                    type: 'POST',
                    data: {_token: token, id: id, status: newStatus},
                    success: function (response) {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            setTimeout(function () {
                                location.reload();
                            }, 1500);
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            } else {
                if (status == 'active') {
                    $('#userStatus_' + id).prop("checked", true);
                }
                if (status == 'inactive') {
                    $('#userStatus_' + id).prop("checked", false);
                }
            }
        });
    }
	$(function () {
	  $('[data-toggle="tooltip"]').tooltip()
	})

</script>
@endsection