@if(count($callRequest) >0)
<div class="table-responsive">
<table class="table admin-table" id="data_table">
    <thead>
    <th>Name</th>
    <th>Generate Date</th>
    <th>Status</th>
    <th>SE Assigned</th>
    <th>Category</th>
    <th>Call of Time</th>
    <th class="th_action no-sort">Action</th>
</thead>
<tbody>
    @foreach($callRequest as $call)
    <tr>
        <td class="min200">
            <div class="user_detail">
                <h4>
                    {{!empty($call->customerDetail->contact_name) ? ucfirst($call->customerDetail->contact_name) : ''}}                    
                </h4>
                <p class="mb-0">
                    {{!empty($call->UserProfile->bussiness_name) ? $call->UserProfile->bussiness_name : ''}}</p>
            </div>
        </td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 
                {{showFullMonthDateFormat($call->created_at)}}
            </div>
        </td>
        <td>
<!--            <div class="user_status {{$call->status == 'resolved' ? 'resolved' : 'pending'}}">
                <span>{{ucfirst($call->status)}}</span>
            </div>-->
            <div class="user_status {{$call->status == 'resolved' ? 'resolved' : 'pending'}}">
                    <?php if($call->is_call_dropped == 1 && $call->status == "pending"){ ?>
                        <span>Call Dropped</span>
                <?php } else { ?>
                    <span>{{ucfirst($call->status)}}</span>
                    
                <?php } ?>
                </div>
        </td>
        <td>
            {{!empty($call->executiveDetail->contact_name) ? $call->executiveDetail->contact_name : ''}}   
        </td>
        <td>
            {{!empty($call->BankCategory->name) ? $call->BankCategory->name : ''}}   
        </td>
        <td>
            <div class="user_tym">
                <i class="far fa-clock"></i> {{gmdate("i:s", $call->call_time)}} mins
            </div>
        </td>
        <td class="action">
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-h"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="{{url('admin/merchant-request-view/'.$call->id)}}">View</a>
                </div>
            </div>
        </td>
    </tr>
    @endforeach
</tbody>
</table>
</div>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}jghjhj</center></div>
@endif
<div style='float:right; margin-top : 10px;'>{{ $callRequest->links() }}</div>
@if(count($callRequest) >0)
<script>
    $(document).ready(function () {
        $('#merhantRequestCsv').show();
        $(".pagination li a").on('click', function (e) {
            pageDivLoader('show', 'divMerchantRequestList');
            var searchString = $("#searchFilterForm").serializeArray();
            e.preventDefault();
            //pageDivLoader('show', 'getlinkedhistory');
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: 'GET',
                data: searchString,
                url: pageLink,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#divMerchantRequestList").html(response.html);
                }
            });
        });
        
    });
</script>
@endif