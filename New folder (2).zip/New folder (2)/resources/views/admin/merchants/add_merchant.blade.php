@extends('admin.layouts.app')
@section('title', 'Add Merchant')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">add merchant</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/manage-merchant')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <form id="addMerchantForm" autocomplete="off" class="f-field" method="POST" action="{{url('admin/save-merchant')}}" enctype="multipart/form-data">
                    {{csrf_field()}}
                    <div class="row">
                        <div class="col-sm-6">
                            @php
                            $managers = \App\Http\Models\User::getManagerLinkedById();
                            @endphp                          
                            <div class="form-group">
                                <select class="selectpicker form-control" id="manager_id" name="manager_id" data-size="5" onchange="getAllExecutiveByManager($(this).val());$(this).valid();" title="Support Manager">
                                    <option value="">Select Support Manager<span class="text-danger">*</span></option>
                                    @if(count($managers)>0)
                                    @foreach($managers as $manager)
                                    <option value="{{$manager->id}}">{{getFullName($manager->first_name ,$manager->last_name)}}</option>
                                    @endforeach
                                    @endif
                                </select>
                                <label class="control-label">Select Support Manager<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <select class="form-control selectpicker" onchange="$(this).valid()" id="selectExecutive" name="executive[]"  multiple data-actions-box="true" data-size="5">
                                </select>
                                <label class="control-label">Select Support Executive<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="username" class="form-control username_field" autocomplete="off">
                                <label class="control-label">Username<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="password" name="password" class="form-control" autocomplete="off">
                                <label class="control-label">Password<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="merchant_number" class="form-control">
                                <label class="control-label">Merchant Number</label>
                            </div>
                        </div>
<!--                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="terminal_model" class="form-control">
                                <label class="control-label">Terminal Model<span class="text-danger">*</span></label>
                            </div>
                        </div>-->
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="contact_name" class="form-control">
                                <label class="control-label">Contact Name<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="bussiness_name" class="form-control" >
                                <label class="control-label">Business Name<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="bussiness_address" class="form-control" >
                                <label class="control-label">Business Address</label>
                            </div>
                        </div>
<!--                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="product" class="form-control" >                                
                                <label class="control-label">Merchant Processor</label>
                            </div>
                        </div>-->
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="machine_model" class="form-control" >
                                <label class="control-label">Credit Card Machine Model<span class="text-danger">*</span></label>
                            </div>
                        </div>                                               
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="phone" class="form-control" >
                                <label class="control-label">Phone Number</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="email" class="form-control" >
                                <label class="control-label">Email Address<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Upload Image</label>
                                <div class="file-upload">
                                    <div class="file-select">
                                        <div class="file-select-button" id="fileName">Choose image</div>
                                        <div class="file-select-name" id="spanFileName"> &nbsp; No image chosen...</div> 
                                        <input type="file" name="image_file" id="imageUpload" onchange="uploadFile(this)">
                                        <input type="hidden" name="hiddenFileName" class="do-not-ignore" id="hiddenMediaFileName">                                                                                        
                                    </div>
                                </div>  
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="city" class="form-control" >
                                <label class="control-label">City</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="state" class="form-control" >
                                <label class="control-label">State</label>
                            </div>
                        </div>                        
                    </div>
                    <div class="form-group">
                        <button id="btnSubmitForm" type="submit" class="btn btn-primary ripple-effect-dark">Save
                            <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                    
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Admin\AddMerchantRequest','#addMerchantForm') !!}                
            </div>
        </div>
    </div>
</main>

<!-- cropper-Modal -->
<div class="modal fade" id="cropper-image-modal" role="dialog" data-backdrop="static">
    <div class="modal-dialog ">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" onclick="remove_image()">&times;</button>
            </div>
            <div id="image-cropper-form">
            </div>                            
        </div>
    </div>
</div>

<script type="text/javascript">
    // get all execuitive by manager id
    function getAllExecutiveByManager(managerId) {
        $.post("{{ url('admin/get-executive-by-manager') }}",
                {_token: "{{ csrf_token() }}", manager_id: managerId}, function (data) {
            $('#selectExecutive').html(data);
            $('#selectExecutive').selectpicker('refresh');
            if (managerId != '' && managerId != undefined)
            {
                $('#selectExecutive').selectpicker('render');
            }
        });
    }



    $(document).on('submit', '#addMerchantForm', function (e) {
        e.preventDefault();
        if ($('#addMerchantForm').valid()) {
            $('#btnSubmitForm').prop('disabled', true);
            $('#btnSubmitLoader').show();
            var formData = new FormData($('#addMerchantForm')[0]);
            $.ajax({
                url: "{{ url('admin/save-merchant') }}",
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('admin/manage-merchant')}}";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnSubmitForm').prop('disabled', false);
                    }
                    $('#btnSubmitLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#btnSubmitForm').prop('disabled', false);
                }
            });
        }
    });

    /* image uploading with cropper*/
    function uploadFile(thisEl) {
        if (thisEl.files[0]) {
            var inputFile = thisEl.files[0].name;
            var extension = inputFile.substr(inputFile.lastIndexOf('.') + 1); /*get file exension*/
            /*check file type and exension*/
            if (extension != 'jpg' && extension != 'jpeg' && extension != 'png') {
                toastrAlertMessage('error', 'Image allows only in jpeg, png or jpg format');
                $('#imageUpload').val('');
                $('#hiddenMediaFileName').val('');
                return false;
            }
            var formData = new FormData($('#addMerchantForm')[0]); /*uploading on server via ajax call*/
            formData.append('_token', '{{ csrf_token() }}');
            $.ajax({
                url: "{{url('admin/upload-media-image')}}",
                type: 'POST',
                data: formData,
                processData: false,
                cache: false,
                contentType: false,
                beforeSend: function () {
                    $('#preloader').show();
                    pageDivLoader('show', 'image-cropper-form');
                },
                success: function (response) {
                    setTimeout(function () {
                        loadImageCropperModal(response.filename);
                    }, 1000);
                    $('#cropper-image-modal').modal('show');
                    $('#preloader').hide();
                }
            });
        }
    }

    function loadImageCropperModal(imageName) {
        $.ajax({
            url: "{{url('admin/load-image-cropper')}}",
            type: 'GET',
            data: {imageName: imageName, type: 'profile_image'},
            success: function (response) {
                $('#image-cropper-form').html(response.html);
            }
        });
    }

    function remove_image() {
        $('#imageUpload').val('');
        $('#hiddenMediaFileName').val('');
    }

</script>
@endsection