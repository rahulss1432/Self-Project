@if(count($users) >0)
<div class="table-responsive">
<table class="table admin-table" id="data_table">
    <thead>
        <tr>           
            <th>Merchant Number</th>
            <th>Business Name</th>
            <th>Contact Name</th>
            <th>Phone Number</th>
            <th>Machine Model</th>
            <th>City/State</th>
            <th class="th_action no-sort">Action</th>
        </tr>
    </thead>
    <tbody>                 
        @foreach($users as $user)             
        <tr id="{{'merchant_'.$user->id}}">
            <td>{{!empty($user->merchant_number) ? $user->merchant_number : '-'}}</td>
            <td>{{$user->bussiness_name}}</td>
            <td>{{!empty($user->contact_name) ? ucfirst($user->contact_name) : '-'}}</td>
            <td>{{!empty($user->phone_number) ? $user->phone_number : '-'}}</td>
            <td>{{$user->machine_model}}</td>
            <td>
                @php
                $string = $user->city.','.$user->state;
                $string  = trim($string, ',');
                @endphp
                {{!empty($user->city || $user->state) ? $string : '-'}}
            </td>
            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="{{url('admin/linked-support/'.$user->user_id)}}">View Request</a>
                        <a class="dropdown-item" href="{{url('admin/merchant-linked-executive/'.$user->user_id)}}">Linked Support</a>
                        <a class="dropdown-item" href="{{url('admin/edit-merchant',$user->user_id)}}">Edit Profile</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick='changeStatus("{{$user->user_id}}" , "deleted")'>Delete</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="changePassword('{{$user->user_id}}');">Change Password</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="sendDetail('{{$user->user_id}}')">Send Detail</a>
                    </div>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
</div>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
<div style='float:right; margin-top : 10px;'>{{ $users->links() }}</div>
@if(count($users) >0)
<script>
    $(document).ready(function(){
        $('#merhantCsv').show();
    });
</script>

<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            pageDivLoader('show', 'divMerchantList');
            var searchString = $("#searchFilterForm").serializeArray();
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: "POST",
                url: pageLink,
                 data: searchString,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#divMerchantList").html(response.html);
                }
            });
        });
    });
</script>
@endif
