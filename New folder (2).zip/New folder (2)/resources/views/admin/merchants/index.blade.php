@extends('admin.layouts.app')
@section('title', 'Manage Merchant')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">merchants List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" id="merhantCsv" style="display: none;">
                        <a href="{{url('admin/merchant-csv-download')}}" class="nav-link">
                            <i class="fas fa-cloud-download-alt"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="{{url('admin/add-merchant')}}" class="nav-link">
                            <i class="fa fa-plus"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link">
                            <i class="fa fa-search"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <div class="filter_section collapse" id="searchFilter">
                    <form id="searchFilterForm" action="javascript:void(0)" onsubmit="getMerchantList()" method="post" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <input type="text" id="filterMurchantNumber" name="merchant_number" class="form-control">
                                    <label class="control-label">Merchant Number </label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <input type="text" id="filterBusinessName" name="bussiness_name" class="form-control" >
                                    <label class="control-label">Business Name</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <input type="text" id="filterPhoneNumber" name="phone_number" class="form-control">
                                    <label class="control-label">Phone Number</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <input type="text"  id="filterBusinessAddress" name="bussiness_address" class="form-control">
                                    <label class="control-label">Business Address</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <button type="submit" id="btnSubmitForm" class="btn btn-primary ripple-effect-dark mr-2">Search
                                        <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>  
                                    </button>
                                    <button type="button" id="btnResetForm" onclick="resetForm()"class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div id="divMerchantList">                      
                </div>
            </div>
        </div>
    </div>
</main>

<script type="text/javascript">
    $(document).ready(function () {
        getMerchantList();
    });

    function resetForm() {
        $('#searchFilterForm')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        getMerchantList();
    }

    function getMerchantList() {
        pageDivLoader('show', 'divMerchantList');
        var searchString = $("#searchFilterForm").serializeArray();
        $.ajax({
            type: "POST",
            url: "{{ url('admin/merchant-list') }}",
            data: searchString,
            success: function (response) {
                if (response.success) {
                    $('#divMerchantList').html(response.html);
//                    $("#data_table").DataTable({
//                        searching: false,
//                        lengthChange: false,
//                        "order": [],
//                        "columnDefs": [{
//                                "targets": [6, 6],
//                                "orderable": false,
//                            }]
//                    });
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    // change user status
    function changeStatus(id, status) {
        var token = '{{ csrf_token() }}';
        if (status == 'deleted') {
            var newStatus = status;
            var confirmMsg = "Are you sure want to delete this user?";
        } else {
            var newStatus = status == 'active' ? 'inactive' : 'active';
            var confirmMsg = "Are you sure want to change user's status?";
        }
        bootbox.confirm(confirmMsg, function (result) {
            if (result == true) {
                $.ajax({
                    url: "{{url('/admin/change-user-status')}}",
                    type: 'POST',
                    data: {_token: token, id: id, status: newStatus},
                    success: function (response) {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            setTimeout(function () {
                                location.reload();
                            }, 1500);
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            } else {
                if (status == 'active') {
                    $('#userStatus_' + id).prop("checked", true);
                }
                if (status == 'inactive') {
                    $('#userStatus_' + id).prop("checked", false);
                }
            }
        });
    }
</script>
@endsection