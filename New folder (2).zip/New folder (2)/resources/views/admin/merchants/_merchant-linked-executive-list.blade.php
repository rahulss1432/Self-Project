@if($merchantSE->count()>0)
<div class="table-responsive">
<table class="table admin-table" id="data_table">
    <thead>
    <th>ID</th>
    <th>Name</th>
    <th>Manager Name</th>
    <th>Phone Number</th>
</thead>
<tbody>
    @foreach($merchantSE as $user)
    @php
    $managerName = \App\Http\Models\User::getManagerByDocument($user->manager_id);
    @endphp
    <tr>
        <td>{{!empty($user->userProfile->executive_number) ? $user->userProfile->executive_number : ''}}</td>
        <td>{{!empty($user->userDetail->contact_name) ? $user->userDetail->contact_name : ''}}</td>
        <td>{{!empty($managerName) ? ucfirst($managerName->first_name.' '.$managerName->last_name): '-'}}</td>
        <td>{{!empty($user->userDetail->phone_number) ? $user->userDetail->phone_number : ''}}</td>
    </tr>
    @endforeach
</tbody>
</table>
</div>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
@if($merchantSE->count()>0)
<script>
    $(document).ready(function () {
        $('#merchantSE').show();
    });
</script>
@endif
<div style='float:right; margin-top : 10px;'>{{ $merchantSE->links() }}</div>
<script>
    
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            //pageDivLoader('show', 'getlinkedhistory');
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: 'GET',
                data: {id:{{$id}}},
                url: pageLink,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#getSelist").html(response.html);
                }
            });
        });
       
    });
</script>