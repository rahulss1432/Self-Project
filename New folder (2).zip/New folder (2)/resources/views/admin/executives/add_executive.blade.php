@extends('admin.layouts.app')
@section('title', 'Add Executive')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Add Support Executive</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/manage-executives')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <form id="addExecutiveForm" autocomplete="off" class="f-field" method="POST" action="{{url('admin/save-executive')}}" enctype="multipart/form-data">
                    {{csrf_field()}}
                    <div class="row">
                        <div class="col-sm-6">
                            @php
                            $managers = \App\Http\Models\User::getManagerLinkedById();
                            @endphp                          
                            <div class="form-group">
                                <select class="selectpicker form-control" data-size="5" id="manager_id" name="manager_id" onchange="getAllCustomerByManager($(this).val());$(this).valid();" title="Merchant Processor">
                                    <option value="">Select Merchant Processor</option>
                                    @if(count($managers)>0)
                                    @foreach($managers as $manager)
                                    <option value="{{$manager->id}}">{{getFullName($manager->first_name ,$manager->last_name)}}</option>
                                    @endforeach
                                    @endif
                                </select>
                                <label class="control-label">Select Merchant Processor<span class="text-danger">*</span></label>
                            </div>
                        </div>
                            <div class="col-sm-6">
                                                     
                            <div class="form-group">
                                <select class="form-control selectpicker" data-size="5"onchange="$(this).valid()" id="selectSupervisorCustomer" name="supervisor_customer[]" multiple data-actions-box="true" title="Select Merchant" data-size="5">
                                </select>
                                <label class="control-label">Select Merchant</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                               
                                <input type="text" name="username" class="form-control username_field">
                                 <label>Username<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                
                                <input type="password" name="password" class="form-control">
                                <label>Password<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Contact Name<span class="text-danger">*</span></label>
                                <input type="text" name="contact_name" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>ID Number</label>
                                <input type="text" name="executive_number" class="form-control" >
                            </div>
                        </div>
                        <div class="col-sm-6">
                            @php
                            $categories = \App\Http\Models\BankingCategory::getActiveCategories();
                            @endphp                            
                            <div class="form-group">
                                <select class="selectpicker form-control" data-size="5" id="selectCategory" name="category[]" onchange="$(this).valid();" title="Support Department" data-actions-box="true"  multiple>
                                    @if(count($categories)>0)
                                    @foreach($categories as $category)
                                    <option value="{{$category->id}}">{{$category->name}}</option>
                                    @endforeach
                                    @endif
                                </select>
                                <label class="control-label">Select Support Department<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Company</label>
                                <input type="text" name="company" class="form-control" >
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="text" name="phone" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>City</label>
                                <input type="text" name="city" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>State</label>
                                <input type="text" name="state" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Email Address<span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Upload Image</label>
                                <div class="file-upload">
                                    <div class="file-select">
                                        <div class="file-select-button" id="fileName">Choose image</div>
                                        <div class="file-select-name" id="spanFileName"> &nbsp; No image chosen...</div> 
                                        <input type="file" name="image_file" id="imageUpload" onchange="uploadFile(this)">
                                        <input type="hidden" name="hiddenFileName" class="do-not-ignore" id="hiddenMediaFileName">                                                                                        
                                    </div>
                                </div>  
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Business Address</label>
                                <input type="text" name="bussiness_address" class="form-control" placeholder="">
                                <!-- <textarea rows="3" name="bussiness_address" class="form-control" placeholder=""></textarea> -->
                            </div>
                        </div>
                    </div>
                    <h5 class="mb-3">Supervisor </h5>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="supervisor_name" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" name="supervisor_email" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="text" name="supervisor_phone" class="form-control" placeholder="">
                            </div>
                        </div>

<!--                        <div class="col-sm-6">
                            @php
                            $customers = \App\Http\Models\User::getCustomerLinkedById();
                            @endphp                            
                            <div class="form-group">
                                <select class="form-control selectpicker" data-size="5" id="selectSupervisorCustomer" name="supervisor_customer[]" multiple data-actions-box="true" title="Select Merchant" data-size="5">
                                    @if(count($customers)>0)
                                    @foreach($customers as $customer)
                                    <option value="{{$customer->id}}">{{$customer->contact_name}}</option>
                                    @endforeach
                                    @endif
                                </select>
                                <label class="control-label">Select Merchant</label>
                            </div>
                        </div>-->
                    </div>       

                    <div class="col-sm-12">
                        <div class="form-group">
                            <button id="btnSubmitForm" type="submit" class="btn btn-primary ripple-effect-dark">Save
                                <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                    
                            </button>                                
                        </div>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Admin\AddExecutiveRequest','#addExecutiveForm') !!}                
            </div>
        </div>
</main>

<!-- cropper-Modal -->
<div class="modal fade" id="cropper-image-modal" role="dialog" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" onclick="remove_image()">&times;</button>
            </div>
            <div id="image-cropper-form">
            </div>                            
        </div>
    </div>
</div>

<script type="text/javascript">
    
    // get all customer by manager id
    function getAllCustomerByManager(managerId) {
        $.post("{{ url('admin/get-customer-by-manager') }}",
                {_token: "{{ csrf_token() }}", manager_id: managerId}, function (data) {
            $('#selectSupervisorCustomer').html(data);
            $('#selectSupervisorCustomer').selectpicker('refresh');
            if (managerId != '' && managerId != undefined)
            {
                $('#selectSupervisorCustomer').selectpicker('render');
            }
        });
    }
    
    $(document).on('submit', '#addExecutiveForm', function (e) {
        e.preventDefault();
        if ($('#addExecutiveForm').valid()) {
            $('#btnSubmitForm').prop('disabled', true);
            $('#btnSubmitLoader').show();
            var formData = new FormData($('#addExecutiveForm')[0]);
            $.ajax({
                url: "{{ url('admin/save-executive') }}",
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('admin/manage-executives')}}";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnSubmitForm').prop('disabled', false);
                    }
                    $('#btnSubmitLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#btnSubmitForm').prop('disabled', false);
                }
            });
        }
    });

    /* image uploading with cropper*/
    function uploadFile(thisEl) {
        if (thisEl.files[0]) {
            var inputFile = thisEl.files[0].name;
            var extension = inputFile.substr(inputFile.lastIndexOf('.') + 1); /*get file exension*/
            /*check file type and exension*/
            if (extension != 'jpg' && extension != 'jpeg' && extension != 'png') {
                toastrAlertMessage('error', 'Image allows only in jpeg, png or jpg format');
                $('#imageUpload').val('');
                $('#hiddenMediaFileName').val('');
                return false;
            }
            var formData = new FormData($('#addExecutiveForm')[0]); /*uploading on server via ajax call*/
            formData.append('_token', '{{ csrf_token() }}');
            $.ajax({
                url: "{{url('admin/upload-media-image')}}",
                type: 'POST',
                data: formData,
                processData: false,
                cache: false,
                contentType: false,
                beforeSend: function () {
                    $('#preloader').show();
                    pageDivLoader('show', 'image-cropper-form');
                },
                success: function (response) {
                    setTimeout(function () {
                        loadImageCropperModal(response.filename);
                    }, 1000);
                    $('#cropper-image-modal').modal('show');
                    $('#preloader').hide();
                }
            });
        }
    }

    function loadImageCropperModal(imageName) {
        $.ajax({
            url: "{{url('admin/load-image-cropper')}}",
            type: 'GET',
            data: {imageName: imageName, type: 'profile_image'},
            success: function (response) {
                $('#image-cropper-form').html(response.html);
            }
        });
    }

    function remove_image() {
        $('#imageUpload').val('');
        $('#hiddenMediaFileName').val('');
    }

</script>
@endsection