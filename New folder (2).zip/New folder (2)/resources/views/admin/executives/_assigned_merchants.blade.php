@if($seMerchant->count()>0)
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Merchant Name</th>
            <!--<th>Merchant Processor</th>-->
            <th>Credit Card Machine Model</th>
            <th>Phone Number</th>
            <th>Business name</th>
        </tr>
    </thead>
    <tbody>
        @foreach($seMerchant as $user)
        <tr>
            <td>{{!empty($user->userCustomerDetail->contact_name) ? $user->userCustomerDetail->contact_name : '-'}}</td>
            <!--<td>{{!empty($user->userCustomerProfile->product) ? $user->userCustomerProfile->product : '-'}}</td>-->
            <td>{{!empty($user->userCustomerProfile->machine_model) ? $user->userCustomerProfile->machine_model : '-'}}</td>
            <td>{{!empty($user->userCustomerDetail->phone_number) ? $user->userCustomerDetail->phone_number : '-'}}</td>
            <td>{{!empty($user->userCustomerProfile->bussiness_name) ? $user->userCustomerProfile->bussiness_name : '-'}}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif