<div class="page-overlay" onclick="closeMenu();">
</div>

<!--change password model-->
<div class="modal fade" id="divChangePassword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog common-modal modal-dialog-centered" id="divChangePasswordModelBody" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title font-hy" id="exampleModalLabel">Change Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="f-field" id="changeUserPasswordForm" action="{{url('admin/update-user-password')}}" method="post" autocomplete="off">
                {{ csrf_field() }}
                <input type="hidden" id='user_id' name="user_id">
                <div class="modal-body">
<!--                    <div class="form-group">
                        <input type="password" name="current_password" class="form-control">
                        <label class="control-label">Enter Current Password</label>
                    </div>-->

                    <div class="form-group">
                        <input type="password" name="password" class="form-control">
                        <label class="control-label">New Password</label>
                    </div>

                    <div class="form-group">
                        <input type="password" name="password_confirmation" class="form-control">
                        <label class="control-label">Confirm New Password</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="btnChangeUserPassword" class="btn btn-primary ripple-effect-dark">Save
                        <i id="btnChangeUserPasswordLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                    
                    </button>
                    <button type="button" class="btn btn-warning ripple-effect-dark" data-dismiss="modal">Close</button>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Http\Requests\ChangeUserPasswordRequest','#changeUserPasswordForm') !!}    
        </div>
    </div>
</div>
<div id="preloader" style="display: none;">
    <div class="inner">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
</div>
<script>
    //Rahul : remove space from username field
    $(function () {
        var txt = $(".username_field");
        var func = function () {
            txt.val(txt.val().replace(/\s/g, ''));
        }
        txt.keyup(func).blur(func);
    });

    /**selectpicker on selected value add class */
    $('.selectpicker').change(function () {
        if ($(this).val()) {
            $(this).closest('.bootstrap-select').addClass('selected');
        } else {
            $(this).closest('.bootstrap-select').removeClass('selected');
        }
    });

    //Rahul : send user detail scripts starts
    function sendDetail(id)
    {
        bootbox.confirm('Are you sure do you want to send user detail?', function (result)
        {
            if (result)
            {
                $('#preloader').show();
                $.ajax({
                    type: "GET",
                    url: "{{url('admin/send-detail')}}/" + id,
                    success: function (response)
                    {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            $('#preloader').hide();
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            }
        });
    }

    /* change password scripts starts*/
    function changePassword(id) {
        $('#user_id').val(id);
        $("#divChangePassword").modal('show');
    }

    $(document).on('submit', '#changeUserPasswordForm', function (e) {
        e.preventDefault();
        if ($('#changeUserPasswordForm').valid()) {
            $('#btnChangeUserPassword').prop('disabled', true);
            $('#btnChangeUserPasswordLoader').show();
            $.ajax({
                url: "{{url('admin/update-user-password')}}",
                data: $('#changeUserPasswordForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            location.reload();
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnChangeUserPassword').prop('disabled', false);
                    }
                    $('#btnChangeUserPasswordLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#btnChangeUserPasswordLoader').hide();
                        $('#btnChangeUserPassword').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });

// toaster common function
    function toastrAlertMessage(type, msg) {
        if (type == 'success') {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.success(msg, {timeOut: 2000});
        } else {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.error(msg, {timeOut: 2000});
        }
    }
    function pageDivLoader(type, id) {
        if (type === 'show') {
            $('#' + id).html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-2x"></i></div>');
        } else {
            $('#' + id).html('');
        }
    }
    $.validator.setDefaults({
        ignore: ":hidden:not(.do-not-ignore)", // not ignoring validation where .do-not-ignore class is used
    });
</script>
<script>
    $('#SelectDate, #SelectDate01, #SelectDate03').datetimepicker({
        focusOnShow: false,
        format: 'L',
        ignoreReadonly: true,
        maxDate: new Date(Date.now() + 1*24*60*60*1000),
        disabledDates: [new Date(Date.now() + 1*24*60*60*1000)],
    });
	
    $('.form-control').on('focus blur', function (e) {
				$(this).parents('.form-group').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
			}).trigger('blur');

    function getHeight() {
        $(window).resize(function () {
            var headerHeight = $("#topHeader").outerHeight(true);
            var window_height = $(window).height();
            var check_height = window_height - headerHeight;
            $("#cardBox").css('min-height', check_height - 50);
        }).resize();
    }
    getHeight();

    //ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });

    $(".selectpicker").selectpicker();

    $(".i-checks").each(function () {
        var intElem = $(this);
        intElem.on('click', function () {
            intElem.addClass('interactive-effect');
            setTimeout(function () {
                intElem.removeClass('interactive-effect');
            }, 400);
        });
    });

    function sideMenu() {
        $("body").toggleClass("sidemenu-open");
    }
    function closeMenu() {
        $("body").removeClass("sidemenu-open");
    }

    // for menu
    $(".sub_menu.active a ").attr('aria-expanded', 'true');

    if ($(window).width() <= 991) {
        $(".filter_section").removeClass("show");
    }
    ;

    if ($(window).width() <= 1199) {
        $(document).ready(function () {
            $("body").removeClass("sidemenu-open");
        });
    }
</script>


