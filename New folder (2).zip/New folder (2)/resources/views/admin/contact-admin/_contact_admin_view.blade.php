<div class="modal-header">
    <h5 class="modal-title font-hy" id="viewContactModalLabel">Contact Admin Detail</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <div class="user-dtl-in mb-0">
        <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
            <div class="label"> Name</div>
            <div class="right font-hy">{{$contactAdmin->name}}</div>
        </div>
        <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
            <div class="label">Business Name</div>
            <div class="right font-hy">{{$contactAdmin->business_name}}</div>
        </div>
        <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
            <div class="label">Phone Number</div>
            <div class="right font-hy">{{$contactAdmin->phone_no}}</div>
        </div>
        <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
            <div class="label">Email</div>
            <div class="right font-hy">{{$contactAdmin->email}}</div>
        </div>
        <div class=" wrap d-block justify-content-between border-0 pb-0">
            <div class="label">Message</div>
            <div class="font-hy">{{$contactAdmin->message}}</div>
        </div>
    </div>
</div>
