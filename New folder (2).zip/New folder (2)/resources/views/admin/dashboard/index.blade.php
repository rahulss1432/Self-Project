@extends('admin.layouts.app')
@section('title', 'Dashboard')
@section('content')
<main class="main-content dashboard-page" id="mainContent">
    <div class="container-fluid">
        <div class="top-boxes">
            <div class="row">
                <div class="col-md-4 col-sm-6 col-400">
                    <a href="{{url('admin/manage-executives')}}" class="box clearfix bg-orange">
                        <i class="icon fas fa-user-tie orange-color"></i>
                        <div class="content">
                            <h3>{{$excutiveCount}}</h3>
                            <p class="text-uppercase">Total Support Executive</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 col-sm-6 col-400">
                    <a href="{{url('admin/call-request')}}" class="box clearfix bg-blue">
                        <i class="icon fas fa-user-friends blue-color"></i>
                        <div class="content">
                            <h3>{{$callrequestCount}}</h3>
                            <p class="text-uppercase">Total  Number of Request Raised</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 col-sm-6 col-400">
                    <a href="{{url('admin/manage-merchant')}}" class="box clearfix bg-red">
                        <i class="icon fas fa-clock red-color"></i>
                        <div class="content">
                            <h3>{{$merchantCount}}</h3>
                            <p class="text-uppercase">Total Number of Merchant</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <section class="perfomance-section">
        <div class="container-fluid">
            <h2 class="text-uppercase font-hy">Performance report of SE</h2>	
            <div class="row">
                <div class="col-lg-6">
                    <div class="common_box boxshadow">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="inner_heading">Performance Graph</h4>
                            <ul class="list-inline mb-0 text-right">
                                <li class="list-inline-item">
                                    <a href="#searchFilter" data-toggle="collapse" class="nav-link  p-0" aria-expanded="true">
                                        <i class="fa fa-filter"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="filter_section collapse" id="searchFilter">
                            <form id="search_form" action="javascript:load_callRequest_month()" method="post" autocomplete="off">
                                {{ csrf_field() }}
                                <div class="row">
                                    <div class="col-md-4 col-sm-6 col-">
                                        <div class="form-group">
                                            @php $executive = \App\Http\Models\User::getExecutivesLinkedById(); @endphp
                                            <select class="form-control selectpicker" name="executive_id" title="Select SE" data-live-search="true" data-size="5">
                                                <option value="">Select SE</option>
                                                @if(count($executive)>0)
                                                @foreach($executive as $data)
                                                <option value="{{$data->id}}">{{ucfirst($data->contact_name)}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                            <label class="control-label">Select SE</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-">
                                        <div class="form-group">
                                            <label>From</label>
                                            <div class="dateicon">
                                                <input type="text" readonly id="selectDate" name="from_date" class="form-control datetimepicker-input" data-target="#selectDate" data-toggle="datetimepicker" placeholder="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-">
                                        <div class="form-group">
                                            <label>To</label>
                                            <div class="dateicon">
                                                <input type="text" readonly id="selectDate01" name="to_date" class="form-control datetimepicker-input" data-target="#selectDate01" data-toggle="datetimepicker" placeholder="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary ripple-effect-dark mr-2">Search</button>
                                            <button type="reset" onclick="resetForm();" class="btn btn-warning ripple-effect-dark">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div class="perfomance-graph">
                            <canvas id="subscriptionsChart" width="100%"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="common_box boxshadow se-rating">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="inner_heading">Rating of Support Executive</h4>
                            <ul class="list-inline mb-0 text-right">
                                @if(count($getRatings)>0)
                                <li class="list-inline-item">
                                    <a href="{{url('admin/ratings')}}">
                                        VIEW ALL
                                    </a>
                                </li>
                                @endif
                            </ul>
                        </div>
                        <div class="table-responsive">
                            @if(count($getRatings)>0)
                            <table class="table list_table admin-table mb-0">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Rating</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($getRatings as $val)
                                    <tr>
                                        <td>{{!empty($val->executiveDetail->contact_name) ? $val->executiveDetail->contact_name : ''}}</td>
                                        <td class="rating">
                                            @for($i=1; $i<=$val->avgRating; $i++)
                                            <i class="fa fa-star" aria-hidden="true" data-rating="{{$val->avgRating}}"></i>
                                            @endfor
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            @else
                            <div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </section>
</main>
<script>
    var myChart1;
    $(document).ready(function () {
        load_callRequest_month();
        $("#selectDate").val("");
    });

    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        load_callRequest_month();
    }

    function sum(input) {
        if (toString.call(input) !== "[object Array]")
            return false;

        var total = 0;
        for (var i = 0; i < input.length; i++)
        {
            if (isNaN(input[i])) {
                continue;
            }
            total += Number(input[i]);
        }
        return total;
    }

    function load_callRequest_month()
    {
        pageDivLoader('show', 'subscriptionsChart');
        var search_filter = $("#search_form").serializeArray();
        $.ajax({
            type: "POST",
            url: "{{ url('admin/request-chart-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    var resolve = sum(response.userResolvedMonth);
                    var pending = sum(response.userPendingMonth);
                    var stepSize = 20;
                    if (resolve >= stepSize || pending >= stepSize) {
                        stepSize = 50;
                    }
                   // var ctx = $("#subscriptionsChart");
                    var ctx = document.getElementById("subscriptionsChart").getContext('2d');
                    Chart.defaults.global.defaultFontSize = 12;
                    console.log(myChart1);
                    if (myChart1) {
                        myChart1.destroy();
                      }
                     myChart1 = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: response.months,
                            datasets: [
                                {
                                    label: 'Resolved',
                                    data: response.userResolvedMonth,
                                    backgroundColor: [
                                        'transparent',
                                    ],
                                    pointBackgroundColor: 'rgba(255, 255, 255, 1)',
                                    pointHoverBorderColor: '#81D8D0',
                                    borderColor: [
                                        '#81D8D0',
                                    ],
                                    borderWidth: 2
                                },
                                {
                                    label: 'Pending',
                                    data: response.userPendingMonth,
                                    backgroundColor: [
                                        'transparent',
                                    ],
                                    pointBackgroundColor: 'rgba(255, 255, 255, 1)',
                                    pointHoverBorderColor: '#FF5E3A',
                                    borderColor: [
                                        '#FF5E3A',
                                    ],
                                    borderWidth: 2
                                },
                            ]
                        },
                        options: {
                            scaleShowVerticalLines: false,
                            legend: {
                                display: true,
                                position: 'top',
                            },
                            responsive: true,
                            scales: {
                                xAxes: [{
                                        gridLines: {
                                            display: false
                                        },
                                        scaleLabel: {
                                            display: true,
                                            labelString: 'Months',
                                            fontSize: 14,
                                            fontColor: '#c3c3c3',
                                        },
                                    }],
                                yAxes: [{
                                        gridLines: {
                                            color: "rgba(122,122,122,0.1)",
                                            zeroLineColor: "rgba(74,69,69,0.01)",
                                        },
                                        scaleLabel: {
                                            display: true,
                                            labelString: 'Number Of Request',
                                            fontSize: 14,
                                            fontColor: '#c3c3c3',
                                        },
                                        ticks: {
                                            beginAtZero: true,
                                            stepSize: stepSize,
                                            tickMarkLength: 100,
                                        }
                                    }]
                            }
                        }
                    });
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    $('#selectDate').datetimepicker({
        focusOnShow: false,
        format: 'L',
        ignoreReadonly: true,
        useCurrent: true,
        maxDate: new Date(),
    });

    $('#selectDate01').datetimepicker({
        focusOnShow: false,
        format: 'L',
        ignoreReadonly: true,
        useCurrent: false,
        maxDate: new Date(),
    });

    $("#selectDate").on("change.datetimepicker", function (e) {
        //$('#selectDate01').datetimepicker('maxDate', new Date(e.date + (365 * 24 * 60 * 60 * 1000)));
    });

    $("#selectDate01").on("change.datetimepicker", function (e) {
        $('#selectDate').datetimepicker('maxDate', e.date);
    });

</script>
@endsection