@extends('admin.layouts.app')
@section('title', 'Add Category')
@section('content')
<body class="bg-light-gray"  onload="hide_preloader();">
    @include('admin.layouts.side-menu')
    <main class="main-content cms-edit" id="mainContent">
        @include('admin.layouts.header')
        <div class="page-content" id="pageContent" >
            <div class="card custom_card" id="card_height">
                <div class="card-header">
                    <h4 class="page-title float-left">Add Category</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item">
                            <a id="back-loader" onclick="backloader()" href="{{url('admin/categories')}}" class="nav-link" title="Back">
                                <i class="fa fa-long-arrow-left"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <form id="addCategoryForm" onsubmit="return !!(checkDesc());" autocomplete="off" class="f-field" method="POST" action="{{url('admin/add-category')}}">
                        {{csrf_field()}}
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Name<span class="text-danger">*</span></label>
                                    <input type="text" name="name" class="form-control form-control-lg">
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="control-label">Description<span class="text-danger">*</span></label>
                                    <textarea class="form-control" name="description" id="description" rows="2"></textarea>
                                    <span id="description-error" style="font-size: 12px;" class="help-block"></span>
                                </div>
                            </div>
                        </div>
                        <div class="from-group">
                            <button id="btnAddCategory" type="submit" class="btn btn-primary btn_radius submitButton">
                                <i id="addCategoryFormLoader" class="fa fa-spin fa-spinner" style="display: none;"></i> Save
                            </button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Http\Requests\Admin\AddCategoryRequest','#addCategoryForm') !!}
                </div>
            </div>
        </div>
    </main>
    <script type="text/javascript">
        $(document).on('submit', '#addCategoryForm', function (e) {
            e.preventDefault();
            if ($('#addCategoryForm').valid()) {
                $('#btnAddCategory').prop('disabled', true);
                $('#addCategoryFormLoader').show();
                $.ajax({
                    url: "{{url('admin/add-category')}}",
                    data: $('#addCategoryForm').serialize(),
                    type: 'POST',
                    dataType: 'JSON',
                    success: function (response) {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            setTimeout(function () {
                                window.location = "{{url('/admin/categories')}}";
                            }, 1000);
                        } else {
                            toastrAlertMessage('error', response.message);
                            $('#btnAddCategory').prop('disabled', false);
                        }
                        $('#addCategoryFormLoader').hide();
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            $('#addCategoryFormLoader').hide();
                            $('#btnAddCategory').prop('disabled', false);
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            }
        });

        $(document).ready(function ()
        {
            tinymce.init({
                theme: "modern",
                selector: "textarea",
                relative_urls: false,
                remove_script_host: false,
                convert_urls: true,
//                plugins: 'image code',
                height: 300,
//                toolbar: 'undo redo | image code',
//                images_upload_url: '{{ url("admin/admin-image-upload") }}',
                images_upload_handler: function (blobInfo, success, failure) {
                    var xhr, formData;
                    xhr = new XMLHttpRequest();
                    xhr.withCredentials = false;
//                    xhr.open('POST', '{{ url("admin/admin-image-upload") }}');
                    xhr.setRequestHeader('X-CSRF-TOKEN', '{{ csrf_token() }}');
                    xhr.onload = function () {
                        var json;
                        if (xhr.status != 200)
                        {
                            failure('HTTP Error: ' + xhr.status);
                            return;
                        }
                        json = JSON.parse(xhr.responseText);
                        if (!json || typeof json.location != 'string')
                        {
                            failure('Invalid JSON: ' + xhr.responseText);
                            return;
                        }
                        success(json.location);
                    };
                    formData = new FormData();
                    formData.append('file', blobInfo.blob(), blobInfo.filename());
                    xhr.send(formData);
                },
                init_instance_callback: function (editor)
                {
                    editor.on('keyup', function (e)
                    {
                        var message = tinymce.get('description').getContent();
                        if (message === '')
                        {
                            $("#description-error").html('Description field is required');
                            $("#description-error").css('color', 'red');
                        }
                        else
                        {
                            $("#content-error").html('');
                        }
                    });
                }
            });
        });

        function checkDesc()
        {
            var description = tinymce.get('description').getContent();
            if (description === undefined || description.length == 0)
            {
                $("#description-error").html("Description field is required.");
                $("#description-error").css('color', 'red');
                return false;
            }
            else
            {
                return true;
            }
        }

        function backloader()
        {
            $("#back-loader").attr("disabled", true);
            $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
        }
        ;
    </script>

    @endsection