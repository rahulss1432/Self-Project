@extends('admin.layouts.app')
@section('title', 'Edit Category')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Edit Category</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/categories')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <form id="editCategoryForm" autocomplete="off" class="f-field" method="POST" action="{{url('admin/category-update')}}">
                    {{csrf_field()}}
                    <input type="hidden" name="categoryId" value="{{$editCategory->id}}">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Name<span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control form-control-lg" value="{{$editCategory->name}}">
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                               <label class="control-label">Description<span class="text-danger">*</span></label>
                                <textarea class="form-control" name="description" id="description" rows="3">{!!$editCategory->description!!}</textarea>
                                <span id="description-error" style="font-size: 12px;" class="help-block"></span>
                            </div>
                        </div>
                    </div>
                    <div class="from-group">
                        <button id="btnEditCategory" type="submit" class="btn btn-primary btn_radius submitButton">
                            <i id="editCategoryFormLoader" class="fa fa-spin fa-spinner" style="display: none;"></i> Update
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Admin\AddCategoryRequest','#editCategoryForm') !!}
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    $(document).on('submit', '#editCategoryForm', function (e) {
        e.preventDefault();
        if ($('#editCategoryForm').valid()) {
            $('#btnEditCategory').prop('disabled', true);
            $('#editCategoryFormLoader').show();
            $.ajax({
                url: "{{url('admin/category-update')}}",
                data: $('#editCategoryForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('/admin/categories')}}";
                        }, 1000);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnEditCategory').prop('disabled', false);
                    }
                    $('#editCategoryFormLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#editCategoryFormLoader').hide();
                        $('#btnEditDocument').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });
</script>

@endsection