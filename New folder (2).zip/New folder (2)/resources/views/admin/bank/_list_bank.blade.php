@if(count($banks) >0)
<div class="table-responsive">
<table class="table admin-table" id="data_table">
    <thead>
        <tr>           
            <th>Name</th>
            <th>Created Date</th>                        
            <th class="th_action no-sort">Action</th>
        </tr>
    </thead>
    <tbody>                 
        @foreach($banks as $data)
        <tr id="{{'banks'.$data->id}}">
            <td>{{$data->name}}</td>
            <td>{{$data->created_at}}</td>
<!--            <td>
                <div class="switch">
                    <label>
                        <input id="userStatus_{{$data->id}}" type="checkbox" onclick='activeInacive("{{$data->id}}" , "{{$data->status}}")' {{$data->status == 'active' ? 'checked':'' }} >
                        <span class="lever" for="userStatus_{{$data->id}}"></span>
                    </label>
                </div>
            </td>-->
            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="{{url('admin/bank-edit',$data->id)}}">Edit</a>
                        <!--<a class="dropdown-item" href="javascript:void(0);" onclick="deletefunction({{$data->id}})">Delete</a>-->
                    </div>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
</div>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif