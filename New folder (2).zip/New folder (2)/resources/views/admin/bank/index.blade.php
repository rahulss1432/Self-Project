@extends('admin.layouts.app')
@section('title', 'Manage Bank')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Bank List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link">
                            <i class="fa fa-search"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <div class="filter_section collapse" id="searchFilter">
                    <form id="search_form" action="javascript:load_bank_list()" method="post" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Search by Name</label>
                                    <input type="text" id="name" name="name" class="form-control form-control-lg"/>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary ripple-effect-dark mr-2">Search</button>
                                    <button type="reset" id="reset-btn" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div  id="bank_list">
                </div>
            </div>
        </div>
    </div>
</main>

<script type="text/javascript">

    $(document).ready(function ()
    {
        load_bank_list();
    });

    $("#reset-btn").click(function ()
    {
        $('#name').val('').change();
        load_bank_list();
    });

    function load_bank_list() {
        pageDivLoader('show', 'bank_list');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "POST",
            url: "{{ url('admin/bank-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#bank_list").html(response.html);
                    $("#data_table").DataTable({
                        searching: false,
                        lengthChange: false,
                        order: [],
                    });
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    /*
     function load_bank_list() {
     pageDivLoader('show', 'bank_list');
     var search_filter = $("#search_form").serializeArray();
     search_filter.push('_token', '{{ csrf_token() }}');
     $.ajax({
     type: "POST",
     url: "{{ url('admin/merchant-list') }}",
     data: searchString,
     success: function (response) {
     if (response.success) {
     $('#divMerchantList').html(response.html);
     $("#data_table").DataTable({
     searching: false,
     "order": [],
     "columnDefs": [{
     "targets": [4, 5],
     "orderable": false,
     }]
     });
     } else {
     toastrAlertMessage('error', response.message);
     }
     },
     error: function (err) {
     var obj = jQuery.parseJSON(err.responseText);
     for (var x in obj) {
     toastrAlertMessage('error', obj[x]);
     }
     }
     });
     }
     
     */
    function deletefunction(id)
    {
        bootbox.confirm('Are you sure do you want to delete this bank?', function (result)
        {
            if (result)
            {
                $.ajax({
                    type: "GET",
                    url: "{{url('admin/delete-bank')}}/" + id,
                    success: function (response)
                    {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            document.getElementById('banks' + id).style.display = 'none';
                            window.location.reload();
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            }
        });
    }

    function activeInacive(id, status)
    {
        if (status == 'active')
        {
            var msg = "Are you sure you want to deactivate this bank?";
        } else if (status == 'inactive')
        {
            var msg = "Are you sure you want to activate this bank?";
        }
        bootbox.confirm(msg, function (result)
        {
            if (result)
            {
                $.ajax({
                    type: "POST",
                    url: "{{url('admin/active-inactive-bank')}}/" + id,
                    data: {'_token': '{{csrf_token()}}'},
                    success: function (response)
                    {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            load_bank_list();
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            } else
            {
                if (status == 'active') {
                    $('#userStatus_' + id).prop("checked", true);
                }
                if (status == 'inactive') {
                    $('#userStatus_' + id).prop("checked", false);
                }
            }
        });
    }
</script>
@endsection