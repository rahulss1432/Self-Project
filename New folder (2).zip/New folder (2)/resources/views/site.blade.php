<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/2.3.6/fabric.min.js"></script>
        <script src="https://webrtc.github.io/adapter/adapter-latest.js"></script>
        <script src="https://linked-assist-webrtc.codiant.com/socket.io/socket.io.js"></script>
        <script src="{{url('public/js/prortc.js')}}"></script>

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <canvas id="c" width="600" height="400" style="border:1px solid #aaa"></canvas>
        <video id="remote"></video>
        <span id="play_video"></span>
        <div style="display: inline-block; margin-left: 10px">

            <div id="drawing-mode-options">
                <button id="text-canvas" class="font-size:inherit;">Write Text</button><br>
                <label for="drawing-mode-selector">Mode:</label>
                <select id="drawing-mode-selector">
                    <option>Pencil</option>
                </select><br>

                <label for="drawing-line-width">Line width:</label>
                <span class="info">2</span><input type="range" value="2" min="0" max="10" id="drawing-line-width"><br>

                <label for="drawing-color">Line color:</label>
                <input type="color" value="#005E7A" id="drawing-color"><br>
                <button id="clear-canvas" style="font-size:inherit;">Clear</button>
            </div>
        </div>
        <br />
        <br />
        <script id="main">
            
$(document).ready(function () {
    var $ = function (id) {
        return document.getElementById(id)
    };
    var drawingOptionsEl = $('drawing-mode-options'),
            drawingColorEl = $('drawing-color'),
            drawingLineWidthEl = $('drawing-line-width');

    var canvas = this.__canvas = new fabric.Canvas('c', {
        isDrawingMode: true
    });
    var currentHistoryState = -1;
    var historyStates = [];

    function getQueryVariable(variable) {
        var query = window.location.search.substring(1);
        var vars = query.split("&");
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] == variable) {
                return pair[1];
            }
        }
        return (false);
    }
    let userType = getQueryVariable('type');

    prortc.on('remote_stream',
            function (stream, id) {
                if (!userType) {
                    console.log('remote_stream', stream);
                    var videoE = document.createElement('video');
                    videoE.width = 1000;
                    videoE.height = 700;
                    videoE.muted = false;
                    videoE.srcObject = stream;

                    var fab_video = new fabric.Image(videoE, {
                        left: 0,
                        top: 0
                    });
                    canvas.add(fab_video);
                    fab_video.getElement().play();
                } else {
                    $('remote').srcObject = stream;
                    $('remote').play();
                }
            }
    );

    prortc.on('path:created', function (data) {
        console.log('path:created ', data);
        var pathLength = data.path.length;
        var pathArray = [];
        for (var i = 0; i < pathLength; i++) {
            var subPath = data.path[i];
            var subPathLength = subPath.length;
            for (var j = 0; j < subPathLength; j++) {
                pathArray.push(subPath[j]);
            }
        }
        var path = new fabric.Path(pathArray.join(' '), data);
        canvas.add(path);

        canvas.forEachObject(function (o) {
            o.selectable = false;
        });
        canvas.selectable = false;
        canvas.renderAll();
    });

    prortc.on('object:removed', function (data) {
        if (userType == 'user') {
            var obj = canvas.getObjects();
            for (var z = 0; z < obj.length; z++) {
                if (z > 0) {
                    canvas.remove(obj[z]);
                }
            }
        }
    });

    prortc.init('/');
    prortc.joinRoom({
        room: 'test'
    });
    let options;
    if (userType === 'user') {
        canvas.isDrawingMode = false;
        drawingOptionsEl.style.display = 'none';
        options = {
            video: true,
            audio: true
        }
    } else {
        options = {
            video: false,
            audio: true
        }
    }

    prortc.startCall(options,
            function (stream) {
                var videoE = document.createElement('video');
                videoE.width = 1000;
                videoE.height = 700;
                videoE.muted = true;
                videoE.srcObject = stream;

                var fab_video = new fabric.Image(videoE, {
                    left: 0,
                    top: 0
                });
                canvas.add(fab_video);
                fab_video.getElement().play();
            },
            function (error) {
                console.log(error);
            }
    );

    function generateId() {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000)
                    .toString(16)
                    .substring(1);
        }

        return s4();
    }

    /**
     * Saves canvas history of changes.
     */
    function saveHistoryState() {
        if (currentHistoryState != -1) {
            historyStates = historyStates.slice(0, currentHistoryState + 1);
        }
        historyStates.push(canvas.toJSON(['id']));
        currentHistoryState = historyStates.length - 1;
    }


    fabric.util.requestAnimFrame(function render() {
        canvas.renderAll();
        fabric.util.requestAnimFrame(render);
    });

    canvas.on('object:modified', function (event) {
        var data = (event.target).toJSON(['id']);
        console.log('object:modified id before ', data.id);

        prortc.socket.emit('object:modified', data);

        saveHistoryState();
    });
    canvas.on('object:added', function (event) {
        //console.log('object:added', (event.target).toJSON(['id']));
        //saveHistoryState();
    });
    canvas.on('object:removed', function (event) {
        console.log('object:removed', event.target);
        prortc.socket.emit('object:removed', (event.target).toJSON(['id']));
        saveHistoryState();

    });
    canvas.on('path:created', function (event) {
        event.path.id = generateId();
        prortc.socket.emit('path:created', (event.path).toJSON(['id']));
        saveHistoryState();

    });

    fabric.Object.prototype.transparentCorners = false;

    clearEl = $('clear-canvas');
    clearEl.onclick = function () {
        var obj = canvas.getObjects();
        for (var z = 0; z < obj.length; z++) {
            if (z > 1) {
                canvas.remove(obj[z]);
            }
        }
    };

    $('drawing-mode-selector').onchange = function () {
        canvas.freeDrawingBrush = new fabric[this.value + 'Brush'](canvas);
        if (canvas.freeDrawingBrush) {
            canvas.freeDrawingBrush.color = drawingColorEl.value;
            canvas.freeDrawingBrush.width = parseInt(drawingLineWidthEl.value, 10) || 1;
        }
    };

    drawingColorEl.onchange = function () {
        canvas.freeDrawingBrush.color = this.value;
    };

    drawingLineWidthEl.onchange = function () {
        canvas.freeDrawingBrush.width = parseInt(this.value, 10) || 1;
        this.previousSibling.innerHTML = this.value;
    };


    if (canvas.freeDrawingBrush) {
        canvas.freeDrawingBrush.color = drawingColorEl.value;
        canvas.freeDrawingBrush.width = parseInt(drawingLineWidthEl.value, 10) || 1;
    }

});
        </script>

        <script>
            (function () {
                fabric.util.addListener(fabric.window, 'load', function () {
                    var canvas = this.__canvas || this.canvas,
                            canvases = this.__canvases || this.canvases;

                    canvas && canvas.calcOffset && canvas.calcOffset();

                    if (canvases && canvases.length) {
                        for (var i = 0, len = canvases.length; i < len; i++) {
                            canvases[i].calcOffset();
                        }
                    }
                });
            })();
        </script>
      
    </body>
</html>
