@extends('manager.layouts.app')
@section('title', 'Manager Login')
@section('content')
<main class="login-page d-flex align-items-center justify-content-center">
    <div class="login-wrap mx-auto">
        <div class="login-header d-flex align-items-center justify-content-center">
            <h2 class="mb-0 text-uppercase text-center">linked assist<br><span>support manager</span></h2>
        </div>
        <div class="login-field">
            <form id="managerLoginForm" method="POST" action="{{url('manager/login')}}">
               {{ csrf_field() }}
               <div class="form-group input_wrap">
					<label class="control-label">Username</label>
					<input type="text" name="username" value="{{old('username')}}" class="form-control" placeholder="Enter Username"/>
				</div>
				<div class="form-group input_wrap">
					<label class="control-label">Password</label>
					<input type="password" name="password" value="{{old('password')}}" onkeyup="remove_error()" class="form-control" placeholder="Enter Password"/>
                    @if ($errors->has('username'))
                    <span class="help-block error-help-block"><b>{{ $errors->first('username') }}</b></span>
                    @endif 
                    <div id="spanLoginError"></div>
				</div>
               
               
               
               
<!--
                {{ csrf_field() }}
                <div class="form-group">
                    <i class="fas fa-user"></i>
                    <input type="text" name="username" value="{{old('username')}}" class="form-control form-control-lg"/>
                    <label class="control-label">Username</label>
                </div>
                <div class="form-group">
                    <i class="fa fa-lock"></i>
                    <input type="password" name="password" value="{{old('password')}}" onkeyup="remove_error()" class="form-control form-control-lg"/>
                    <label class="control-label">Password</label>
                    @if ($errors->has('username'))
                    <span class="help-block error-help-block"><b>{{ $errors->first('username') }}</b></span>
                    @endif  
                    <div id="spanLoginError"></div>   
                </div>                  
-->
                <div class="form-group text-center pl-0 mb-0">
                    <button type="submit" id="btnLogin" class="btn btn-primary ripple-effect-dark">SUBMIT
                        <span id="loginFormLoader" class="fas fa-spin fa-spinner" style="display: none"></span>
                    </button>                
                </div>
            </form>
            {!! JsValidator::formRequest('App\Http\Requests\Manager\ManagerLoginRequest','#managerLoginForm') !!}
        </div>
        <div class="login-footer">
            <a href="{{url('/manager/forgot-password')}}" class="ripple-effect-dark">FORGOT PASSWORD <i class="fas fa-long-arrow-alt-right"></i></a>
        </div>
    </div>
</main>

@include('manager.layouts.footer')

<script>
    $(document).on('submit', '#managerLoginForm', function (e) {
        $('#spanLoginError').text('');
        e.preventDefault();
        if ($('#managerLoginForm').valid()) {
            $('#btnLogin').prop('disabled', true);
            $('#loginFormLoader').show();
            $.ajax({
                url: "{{ url('manager/login') }}",
                data: $('#managerLoginForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = response.redirectUrl;
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnLogin').prop('disabled', false);
                        $('#loginFormLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        if (obj[x].username) {
                            $('#spanLoginError').html('<span class="help-block error-help-block">' + obj[x].username + '</span>');
                        } else {
                            $('#spanLoginError').html('<span class="help-block error-help-block">' + obj[x] + '</span>');
                        }
                        $('#loginFormLoader').hide();
                        $('#btnLogin').prop('disabled', false);
                    }
                }
            });
        }
    });

    function remove_error() {
        $('#spanLoginError').html('');
    }

</script>
@endsection
