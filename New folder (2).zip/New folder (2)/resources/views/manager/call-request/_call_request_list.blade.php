@if(count($callRequest) >0)
<div class="table-responsive">
    <table class="table admin-table" id="data_table">
        <thead>
            <tr>
                <th>Business Name</th>
                <th>Merchant Number</th>
                <th>Date of Call</th>
                <th>Time of Call</th>
                <th>Status of Call</th>
                <th>SE Assigned</th>
                <th>Category</th>
                <th class="th_action no-sort">Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($callRequest as $data)
            <tr>
                <td>{{!empty($data->UserProfile->bussiness_name) ? $data->UserProfile->bussiness_name : '-'}}</td>
                <td>{{!empty($data->UserProfile->merchant_number) ? $data->UserProfile->merchant_number : '-'}}</td>
                <td>{{showDateFormat($data->created_at)}}</td>
                <td>{{showTimeFormat($data->created_at)}}</td>
                <td>
                    <div class="user_status {{$data->status == 'resolved' ? 'resolved' : 'pending'}}">
                        <?php if ($data->is_call_dropped == 1 && $data->status == "pending") { ?>
                            <span>Call Dropped</span>
                        <?php } else { ?>
                            <span>{{ucfirst($data->status)}}</span>
                        <?php } ?>
                    </div>
                </td>
                <td>{{!empty($data->executiveDetail->contact_name) ? ucfirst($data->executiveDetail->contact_name) : '-'}}</td>
                <td>{{!empty($data->BankCategory->name) ? $data->BankCategory->name : '-'}}</td>

                <td class="action">
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-h"></i>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="{{url('manager/call-request-view/'.$data->id)}}">View</a>
                        </div>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
<!--For Pagination links-->
<div style='float:right; margin-top : 10px;'>{{ $callRequest->links() }}</div>

@if(count($callRequest) >0)
<script>
    $(document).ready(function () {
        $('#callRequestCsv').show();
    });
</script>
@endif

<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            pageDivLoader('show', 'call_request_list');
            var search_filter = $("#search_form").serializeArray();
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: "POST",
                url: pageLink,
                data: search_filter,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#call_request_list").html(response.html);
                }
            });
        });
    });
</script>