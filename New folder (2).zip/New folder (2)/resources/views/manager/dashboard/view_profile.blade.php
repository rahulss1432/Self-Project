@extends('manager.layouts.app')
@section('title', 'View Profile')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header"> 
                <h4 class="page-title float-left">{{Request::route()->getName()== 'manager-view-profile' ? 'View Profile':''}}</h4>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="profile-img">
                            <img src="{{getImage($user->profile_image,'users','users')}}" alt="user-img" class="rounded-circle img-fluid">
                        </div>
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                <label>Name </label>
                                <span>{{getFullName($user->first_name ,$user->last_name )}}</span>
                            </li>
                            <li>
                                <label>Email Address</label>
                                <span> {{$user->email}}</span>
                            </li>
                            <li>
                                <label>Phone Number </label>
                                <span> {{$user->phone_number}}</span>
                            </li>
                            <li>
                                <label>No. of Linked Support Executives</label>
                                <span>{{getAllExectiveCountByManager(Auth::guard(getAuthGuard())->user()->id)}}</span>
                            </li>
                            <li>
                                <label>No. of Linked Merchants</label>
                                <span>{{getAllMerchantCountByManager(Auth::guard(getAuthGuard())->user()->id)}}</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection