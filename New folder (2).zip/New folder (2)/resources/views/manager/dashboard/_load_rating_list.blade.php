@if(count($ratings)>0)
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Ratting</th>
        </tr>
    </thead>
    <tbody>
        @foreach($ratings as $data)
        <tr>
            <td>{{!empty($data->executiveDetail->contact_name) ? $data->executiveDetail->contact_name : ''}}</td>
            <?php 
            $ratingData = App\Http\Models\Rating::getAverageRatingByExecutiveId($data->executiveDetail->id);
            ?>
            <td class="rating">
                @for($i=0; $i<=$ratingData; $i++)
                <i class="fa fa-star" aria-hidden="true" data-rating="{{$data->$ratingData}}"></i>
                @endfor
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif