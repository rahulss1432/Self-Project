@extends('manager.layouts.app')
@section('title', 'Document')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Documents List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/add-document')}}" class="nav-link">
                            <i class="fa fa-plus"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link">
                            <i class="fa fa-search"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <div class="filter_section collapse" id="searchFilter">
                    <form id="searchFilterForm" action="javascript:void(0)" onsubmit="getDocumentList()" method="post" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="row">
<!--                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                @php
                                $banks = \App\Http\Models\Bank::getBankList();
                                @endphp                                                                        
                                <div class="form-group">
                                    <select class="form-control selectpicker"  id="selectBankFilter" name="bank_id" title="Select Bank" data-size="5">
                                        <option value="">Select Bank</option>
                                        @if(count($banks)>0)
                                        @foreach($banks as $bank)
                                        <option value="{{$bank->id}}">{{$bank->name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                    <label class="control-label">Select Bank</label>
                                </div>
                            </div>-->
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label>Title</label>
                                    <input type="text" id="titleFilter" name="title" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <button class="btn btn-primary ripple-effect-dark mr-2" type="submit" id="btnSubmitForm">Search
                                        <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                                                                
                                    </button>                                        
                                    <button type="button" id="btnResetForm" onclick="resetForm()" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div id="divDocumentList">
                </div>
            </div>
        </div>
    </div>
</main>

<script type="text/javascript">
    $(document).ready(function () {
        getDocumentList();
    });

//      function for reset form  
    function resetForm() {
        $('#searchFilterForm')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        getDocumentList();
    }

//      function for get document list  
    function getDocumentList() {
        pageDivLoader('show', 'divDocumentList');
        var searchString = $("#searchFilterForm").serializeArray();
        $.ajax({
            type: "POST",
            url: "{{ url('manager/document-list') }}",
            data: searchString,
            success: function (response) {
                if (response.success) {
                    $('#divDocumentList').html(response.html);
//                    $("#data_table").DataTable({
//                        searching: false,
//                        lengthChange: false,
//                        "order": [],
//                        "columnDefs": [{
//                                "targets": [3, 3],
//                                "orderable": false,
//                            }]
//                    });
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

//      delete document  
    function deleteDocument(id) {
        bootbox.confirm('Are you sure do you want to delete this document?', function (result) {
            if (result) {
                $.ajax({
                    type: "GET",
                    url: "{{url('manager/delete-document')}}/" + id,
                    success: function (response) {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            getDocumentList();
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            }
        });
    }
</script>

@endsection