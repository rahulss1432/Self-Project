@extends('manager.layouts.app')
@section('title', 'View Documents')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">View Documents</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/manage-document')}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                @php
                                $managerName = \App\Http\Models\User::getManagerByDocument($document->manager_id);
                                @endphp
                                <label>Manager Name</label>
                                <span>{{!empty($managerName) ? ucfirst($managerName->first_name.' '.$managerName->last_name): '-'}}</span>
                            </li>
                            <li>
                                <label>Title</label>
                                <span>{{$document->title}}</span>
                            </li>
                            <li>
                                <label>Created Date</label>
                                <span>{{showDateTimeFormatSecond($document->created_at)}}</span>
                            </li>
                            <li class="d-block">
                                <label>File/Content</label>
                                
									<span>@if($document->document_type == 'doc')
                                    <a href="{{getDocUrl($document->pdf_upload)}}" target="_blank">{{$document->pdf_upload}}</a>
                                    </span>
                                    @else
                                    <p>{!!$document->content!!}</p>
                                    @endif
                                
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection