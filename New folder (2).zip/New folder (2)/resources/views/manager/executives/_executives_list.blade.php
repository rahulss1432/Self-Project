@if(count($executives) >0)
<div class="table-responsive">
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Phone Number</th>
            <th>Merchant</th>
            <th>City/State</th>            
            <th class="th_action no-sort">Action</th>
        </tr>
    </thead>
    <tbody>                  
        @foreach($executives as $user)
        <tr id="{{'merchant_'.$user->id}}">
            <td>{{!empty($user->executive_number) ? $user->executive_number : '-'}}</td>            
            <td>{{ucfirst($user->contact_name)}}</td>            
            <td>{{!empty($user->phone_number) ? $user->phone_number : '-'}}</td>            
            <td>{{getMerhcantCountByExcutive($user->id)}}</td>
            <td>
                @php
                $string = $user->city.','.$user->state;
                $string  = trim($string, ',');
                @endphp
                {{!empty($user->city || $user->state) ? $string : '-'}}
            </td>         
            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="{{url('manager/view-executive',$user->id)}}">View</a>
                        <a class="dropdown-item" href="{{url('manager/edit-executive',$user->id)}}">Edit</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick='changeStatus("{{$user->id}}" , "deleted")'>Delete</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="changePassword('{{$user->id}}')">Change Password</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="sendDetail('{{$user->id}}')">Send Detail</a>
                    </div>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
</div>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif

<div style='float:right; margin-top : 10px;'>{{ $executives->links() }}</div>

@if(count($executives) >0)
<script>
    $(document).ready(function(){
    $('#executiveCsv').show();
    });
</script>
@endif

<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            pageDivLoader('show', 'divExecutivesList');
            var searchString = $("#searchFilterForm").serializeArray();
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: "POST",
                url: pageLink,
                data: searchString,
                success: function (response) {
                    $('.pagination:first').remove();
                    $('#divExecutivesList').html(response.html);
                }
            });
        });
    });
</script>
