@extends('manager.layouts.app')
@section('title', 'Executive Detail')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Support Executive View</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/manage-executives')}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="profile-img">
                            <img src="{{getImage($user->profile_image,'users','users')}}" alt="user-img" class="rounded-circle img-fluid">
                        </div>
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                <label>Name</label>
                                <span>{{ucfirst($user->username)}}</span>
                            </li>
                            <li>
                                <label>Email Address</label>
                                <span>{{$user->email}}</span>
                            </li>
                            <li>
                                <label>Contact Name</label>
                                <span>{{ucfirst($user->contact_name)}}</span>
                            </li>
                            <li>
                                <label>Support Department (Category)</label>
                                <span>{{getCategoryByExecutive($user->id)}}</span>
                            </li>
                            <li>
                                <label>Phone Number</label>
                                <span>{{!empty($user->phone_number) ? $user->phone_number : '-'}}</span>
                            </li>
                            <li>
                                <label>Id Number</label>
                                <span>{{!empty($user->executive_number) ? $user->executive_number : '-'}}</span>
                            </li>
                            <li>
                                <label>Company</label>
                                <span>{{!empty($user->company_name) ? $user->company_name : '-'}}</span>
                            </li>
                            <li>
                                <label>Bussiness Address</label>
                                <span>{{!empty($user->bussiness_address) ? $user->bussiness_address : '-'}}</span>
                            </li>
                            <li>
                                <label>City</label>
                                <span>{{!empty($user->city) ? $user->city : '-'}}</span>
                            </li>
                            <li>
                                <label>State</label>
                                <span>{{!empty($user->state) ? $user->state : '-'}}</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <h5 class="theme-color01 mt-4 mb-3">Merchant Assigned</h5>
                <div id="divMerchantAssignedlist">
                </div>
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    $(document).ready(function () {
        getMerchantAssignedlist();
    });
    function getMerchantAssignedlist() {
        pageDivLoader('show', 'divMerchantAssignedlist');
        var searchString = $("#searchFilterForm").serializeArray();
        $.ajax({
            type: "GET",
            url: "{{ url('manager/merchant-assigned-list') }}" + '/' + '{{$user->id}}',
            success: function (response) {
                if (response.success) {
                    $('#divMerchantAssignedlist').html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection