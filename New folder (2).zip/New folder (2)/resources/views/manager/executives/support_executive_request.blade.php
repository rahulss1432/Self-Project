@extends('manager.layouts.app')
@section('title','Support Executive')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Support Executive Request List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/executive-request-csv-download')}}" class="nav-link">
                            <i class="fas fa-cloud-download-alt"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link">
                            <i class="fa fa-search"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="filter_section collapse" id="searchFilter">
                    <form id="searchFilterForm" action="javascript:void(0)" onsubmit="getSupportlist()" method="post" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" id="nameFilter" name="name" class="form-control" placeholder="">
                                </div>
                            </div>
                            <!--                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                                            <div class="form-group">
                                                                <label>By Date</label>
                                                                <div class="dateicon">
                                                                    <input type="text" readonly id="SelectDate03" class="form-control datetimepicker-input" data-target="#SelectDate03" data-toggle="datetimepicker">
                                                                </div>
                                                            </div>
                                                        </div>-->
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <button type="submit" id="btnSubmitForm" class="btn btn-primary ripple-effect-dark mr-2">Search
                                        <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                                                                
                                    </button>
                                    <button id="btnResetForm" onclick="resetForm()" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div id="getSupportlist">
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function () {
        getSupportlist();
    });
    function resetForm() {
        $('#searchFilterForm')[0].reset();
        getSupportlist();
    }
    function getSupportlist() {
        pageDivLoader('show', 'getSupportlist');
        var searchString = $("#searchFilterForm").serializeArray();
        var url = '{{url("manager/se-request-list")}}';
        $.ajax({type: "POST", url: url, data: searchString,
            success: function (response) {
                if (response.success) {
                    $('#getSupportlist').html(response.html);
//                    $("#data_table").DataTable({
//                        searching: false,
//                        lengthChange: false,
//                        "columnDefs": [{
//                                "targets": 'no-sort',
//                                "orderable": false,
//                            }]
//                    });
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection