@extends('manager.layouts.app')
@section('title', 'Edit Merchant')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">edit Merchant</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/manage-merchant')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <form id="EditMerchantForm" autocomplete="off" class="f-field" method="POST" action="{{url('manager/update-merchant')}}"  enctype="multipart/form-data">
                    {{csrf_field()}}
                    <input type="hidden" name="user_id" value="{{$user->id}}">
                    <input type="hidden" name="manager_id" value="{{Auth::guard(getAuthGuard())->user()->id}}">
                    <div class="row">
                        <div class="col-sm-6">                            
                            <div class="form-group">
                                @php
                                $executives = \App\Http\Models\User::getAllExecutivesByManager('','listing');
                                $linkedExecutives = \App\Http\Models\CustomerExecutiveRelation::getAssignExecutiveByCustomerId($user->id);
                                $data = array();                                                                 
                                foreach($linkedExecutives as $linkedExecutive){
                                $data[] = $linkedExecutive->executive_id;
                                }     
                                @endphp                            
                                <select class="form-control selectpicker" onchange="$(this).valid()" id="selectExecutive" name="executive[]" multiple data-actions-box="true" title="Select Support Executive" data-size="5">
                                    @if(count($executives)>0)
                                    @foreach($executives as $executive)
                                    <option value="{{$executive->id}}" {{in_array($executive->id,$data) ? 'selected' : ''}}>{{ucfirst($executive->contact_name)}}</option>
                                    @endforeach
                                    @endif
                                </select>
                                <label class="control-label">Select Support Executive<span class="text-danger">*</span></label>
                            </div>
                        </div>  
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="username" class="form-control" value="{{$user->username}}" autocomplete="off" readonly="readonly">
                                <label class="control-label">Username<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="merchant_number" value="{{!empty($user->userDetail->merchant_number) ? $user->userDetail->merchant_number : ''}}" class="form-control">
                                <label class="control-label">Merchant Number</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="contact_name"  value="{{$user->contact_name}}" class="form-control">
                                <label class="control-label">Contact Name<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="bussiness_name" value="{{!empty($user->userDetail->bussiness_name) ? $user->userDetail->bussiness_name : ''}}" class="form-control" >
                                <label class="control-label">Business Name<span class="text-danger">*</span></label>
                            </div>
                        </div>                

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="phone" value="{{$user->phone_number}}" class="form-control">
                                <label class="control-label">Phone Number</label>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="email" name="email" value="{{$user->email}}" class="form-control">
                                <label class="control-label">Email Address<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Upload Image</label>
                                <div class="file-upload">
                                    <div class="file-select">
                                        <div class="file-select-button" id="fileName">Choose image</div>
                                        <div class="file-select-name" id="spanFileName">{{!empty($user->profile_image) ? $user->profile_image : 'No Image chosen...'}}</div> 
                                        <input type="file" name="image_file" id="imageUpload" onchange="uploadFile(this)">
                                        <input type="hidden" value="{{$user->profile_image}}" name="hiddenFileName" class="do-not-ignore" id="hiddenMediaFileName">
                                    </div>
                                </div>  
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="machine_model" value="{{!empty($user->userDetail->machine_model) ? $user->userDetail->machine_model : ''}}" class="form-control" >
                                <label class="control-label">Credit Card Machine Model<span class="text-danger">*</span></label>
                            </div>
                        </div>                        

<!--                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="terminal_model" value="{{!empty($user->userDetail->terminal_model) ? $user->userDetail->terminal_model : ''}}"  class="form-control">
                                <label class="control-label">Terminal Model<span class="text-danger">*</span></label>
                            </div>
                        </div>-->
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="bussiness_address"  value="{{!empty($user->userDetail->bussiness_address) ? $user->userDetail->bussiness_address : ''}}" class="form-control" >
                                <label class="control-label">Business Address</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="city" value="{{$user->city}}" class="form-control" >
                                <label class="control-label">City</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="state"  value="{{$user->state}}" class="form-control" >
                                <label class="control-label">State</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <button id="btnSubmitForm" type="submit" class="btn btn-primary ripple-effect-dark">Save
                            <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                    
                        </button>                        
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Manager\EditMerchantRequest','#EditMerchantForm') !!}                
            </div>
        </div>
    </div>
</main>

<!-- cropper-Modal -->
<div class="modal fade" id="cropper-image-modal" role="dialog" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" onclick="remove_image()">&times;</button>
            </div>
            <div id="image-cropper-form">
            </div>                            
        </div>
    </div>
</div>

<script type="text/javascript">
//       submit add executive form
    $(document).on('submit', '#EditMerchantForm', function (e) {
        e.preventDefault();
        if ($('#EditMerchantForm').valid()) {
            $('#btnSubmitForm').prop('disabled', true);
            $('#btnSubmitLoader').show();
            var formData = new FormData($('#EditMerchantForm')[0]);
            $.ajax({
                url: "{{ url('manager/update-merchant') }}",
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('manager/manage-merchant')}}";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnSubmitForm').prop('disabled', false);
                    }
                    $('#btnSubmitLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#btnSubmitForm').prop('disabled', false);
                }
            });
        }
    });
    /* image uploading with cropper*/
    function uploadFile(thisEl) {
        if (thisEl.files[0]) {
            var inputFile = thisEl.files[0].name;
            var extension = inputFile.substr(inputFile.lastIndexOf('.') + 1); /*get file exension*/
            /*check file type and exension*/
            if (extension != 'jpg' && extension != 'jpeg' && extension != 'png') {
                toastrAlertMessage('error', 'Image allows only in jpeg, png or jpg format');
                $('#imageUpload').val('');
                $('#hiddenMediaFileName').val('');
                return false;
            }
            var formData = new FormData($('#EditMerchantForm')[0]); /*uploading on server via ajax call*/
            formData.append('_token', '{{ csrf_token() }}');
            $.ajax({
                url: "{{url('manager/upload-media-image')}}",
                type: 'POST',
                data: formData,
                processData: false,
                cache: false,
                contentType: false,
                beforeSend: function () {
                    $('#preloader').show();
                    pageDivLoader('show', 'image-cropper-form');
                },
                success: function (response) {
                    setTimeout(function () {
                        loadImageCropperModal(response.filename);
                    }, 1000);
                    $('#cropper-image-modal').modal('show');
                    $('#preloader').hide();
                }
            });
        }
    }

    function loadImageCropperModal(imageName) {
        $.ajax({
            url: "{{url('manager/load-image-cropper')}}",
            type: 'GET',
            data: {imageName: imageName, type: 'profile_image'},
            success: function (response) {
                $('#image-cropper-form').html(response.html);
            }
        });
    }

    function remove_image() {
        $('#imageUpload').val('');
    }

</script>
@endsection