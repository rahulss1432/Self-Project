<div class="edit-form">
    <form id="EditMerchantRequestForm" autocomplete="off" class="f-field" method="POST" action="{{url('manager/update-merchant-request')}}">
        {{csrf_field()}}
        <input type="hidden" name="request_id" value="{{$callRequest->id}}">    
        <div class="row">
            <?php 
                if($callRequest->status == "resolved"){
                    $divVisibility = "display:none";
                } else {
                    $divVisibility = "display:block";
                }
            ?>
            <div class="col-sm-6" style="<?php echo $divVisibility ?>">
                <div class="form-group">
                    <select class="selectpicker form-control" onchange="$(this).valid()" name="status" title="Request Status">
                        <option value="resolved" {{$callRequest->status == 'resolved' ? 'selected' : ''}}>Resolved</option>
                        <option value="pending"  {{$callRequest->status == 'pending' ? 'selected' : ''}} >Pending</option>
                    </select>
                    <label class="control-label">Request Status<span class="text-danger">*</span></label>
                </div>
            </div>
            <div class="col-sm-6" style="<?php echo $divVisibility ?>">
                @php
                $categories = \App\Http\Models\BankingCategory::getActiveCategories();
                @endphp                                                                       
                <div class="form-group">
                    <select class="selectpicker form-control" name="category_id" onchange="$(this).valid()" title="Request Category" id="selectCategoryFilter" data-size="5">
                        <option value="">Select Category</option>                                        
                        @if(count($categories)>0)
                        @foreach($categories as $category)
                        <option value="{{$category->id}}" {{$category->id == $callRequest->category_id ? 'selected' : ''}}>{{$category->name}}</option>
                        @endforeach
                        @endif
                    </select>
                    <label class="control-label">Select Category<span class="text-danger">*</span></label>
                </div>
            </div>        

            <div class="col-sm-12">
                <div class="form-group">
                    <textarea rows="3" class="form-control" name="notes">{{$callRequest->notes}}</textarea>
                    <label class="control-label">Notes<span class="text-danger">*</span></label>
                </div>
            </div>
        </div>
        <div class="text-center">
            <button id="btnSubmitForm" type="submit" class="btn btn-primary mb-3 text-uppercase ripple-effect-dark font-bk">Update
                <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                    
            </button>                        
        </div>        
    </form>
    {!! JsValidator::formRequest('App\Http\Requests\Manager\EditMerchantCallRequest','#EditMerchantRequestForm') !!}   
    <script>
    $('.form-control').on('focus blur', function (e) {
        $(this).parents('.form-group').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
    }).trigger('blur');
    </script>                 
</div>
<script>
//       submit edit executive request form
    $(document).on('submit', '#EditMerchantRequestForm', function (e) {
        e.preventDefault();
        if ($('#EditMerchantRequestForm').valid()) {
            $('#btnSubmitForm').prop('disabled', true);
            $('#btnSubmitLoader').show();
            $.ajax({
                url: "{{ url('manager/update-merchant-request') }}",
                data: $('#EditMerchantRequestForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            location.reload();
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnSubmitForm').prop('disabled', false);
                    }
                    $('#btnSubmitLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    console.log(obj);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#btnSubmitForm').prop('disabled', false);
                }
            });
        }
    });
</script>

