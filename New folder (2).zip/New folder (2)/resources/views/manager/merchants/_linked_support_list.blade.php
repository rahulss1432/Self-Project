@if(count($merchantCall) >0)
<div class="table-responsive">
<table class="table admin-table" id="data_table">
    <thead>
    <th>Name</th>
    <th>Generate Date</th>
    <th>Status</th>
    <th>SE Assigned</th>
    <th>Category</th>
    <th>Length of Call</th>
    <th class="th_action no-sort">Action</th>
</thead>
<tbody>
    @foreach($merchantCall as $call)
    <tr>
        <td class="min200">
            <div class="user_detail">
                <h4>{{!empty($call->customerDetail->contact_name) ? $call->customerDetail->contact_name : ''}}</h4>
                <p class="mb-0">{{!empty($call->UserProfile->bussiness_name) ? $call->UserProfile->bussiness_name : ''}}</p>
            </div>
        </td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 
                @php
                echo $generateDate = date('d M Y',strtotime($call->created_at));
                @endphp
            </div>
        </td>
        <td>
            <div class="user_status {{$call->status == 'resolved' ? 'resolved' : 'pending'}}">
                <span><?php if($call->is_call_dropped == 1 && $call->status == "pending"){ ?>
                                        Call Dropped
                                    <?php } else { ?>
                                        {{ucfirst($call->status)}}
                                    <?php } ?></span>
            </div>
        </td>
        <td>{{!empty($call->executiveDetail->contact_name) ? $call->executiveDetail->contact_name : ''}}</td>
        <td>{{!empty($call->BankCategory->name) ? $call->BankCategory->name : ''}}</td>
        <td>
            <div class="user_tym">
                <i class="far fa-clock"></i>{{gmdate("i:s", $call->call_time)}} mins
            </div>
        </td>
        <td class="action">
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-h"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="{{url('manager/merchant-request-view/'.$call->id)}}">View</a>
                </div>
            </div>
        </td>
    </tr>
    @endforeach
</tbody>
</table>
</div>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif

<div style='float:right; margin-top : 10px;'>{{ $merchantCall->links() }}</div>

<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            pageDivLoader('show', 'getlinkedSupport');
            var searchString = $("#searchFilterForm").serializeArray();
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: "POST",
                url: pageLink,
                data: searchString,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#getlinkedSupport").html(response.html);
                }
            });
        });
    });
</script>