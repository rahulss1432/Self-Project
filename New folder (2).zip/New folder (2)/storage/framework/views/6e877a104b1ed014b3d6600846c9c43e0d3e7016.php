<!-- Manage Cms Listing Start -->
<?php if(count($cms) > 0): ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Page Name</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $cms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(!empty($data->title) ? $data->title : '-'); ?></td>
            <td>
                <ul class="list-inline mb-0">
                    <li class="list-inline-item">
                        <a href="<?php echo e(url('admin/edit-cms/'.base64_encode($data->id))); ?>"><i class="ti-pencil-alt"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<!-- Manage Cms Listing End -->
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($cms->links()); ?>

<script>
    // cms list pagination
    $(".pagination li a").on('click', function (e) {
        pageDivLoader('show', 'getCmsList');
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'GET',
            url: pageLink,
            async: false,
            success: function (response) {
                $('.pagination:first').remove();
                $('#getCmsList').html(response.html);
            }
        });
    });
</script>