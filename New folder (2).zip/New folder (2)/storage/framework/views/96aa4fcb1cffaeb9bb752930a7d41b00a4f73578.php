<!-- Manage Services Listing Start -->
<?php if(count($services) > 0): ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Service Name</th>
            <th class="w150 text-center">Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(!empty($service->name) ? $service->name : '-'); ?></td>
            <td>
                <div class="switch text-center">
                    <label>
                        <?php if($service->status == 'active'): ?>
                        <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this,'<?php echo e($service->id); ?>')">
                        <?php else: ?>
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'<?php echo e($service->id); ?>')">
                        <?php endif; ?>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<!-- Manage Services Listing End -->
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($services->links()); ?>

<script>
    // service list pagination
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getServiceList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    var search_filter = $("#search_form").serializeArray();
    search_filter.push({'_token': '<?php echo e(csrf_token()); ?>'});
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: search_filter,
            success: function (response) {
            $('.pagination:first').remove();
            $('#getServiceList').html(response.html);
            }
    });
    });
</script>     