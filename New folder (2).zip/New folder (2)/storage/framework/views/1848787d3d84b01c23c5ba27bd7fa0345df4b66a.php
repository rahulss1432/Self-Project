<?php $__env->startSection('title', 'Manage Chat'); ?>
<?php $__env->startSection('content'); ?>
<!-- all chats (connection) list page -->
<main class="main-content" id="mainContent">
    <div class="page-content pt-1">
        <!-- tab -->
        <ul class="nav nav-tabs admin-tabs border-0" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="flagged-activity-tab" onclick="showFlaggedActi();" data-toggle="tab" href="#flagged-activity" role="tab" aria-controls="home" aria-selected="true">Chats</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="flagged-terms-tab" onclick="showFlaggedTerms();" data-toggle="tab" href="#flagged-terms" role="tab" aria-controls="profile" aria-selected="false">Flagged Terms</a>
            </li>
        </ul>
        <!-- tab content -->
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="flagged-activity" role="tabpanel" aria-labelledby="flagged-activity-tab">
                <div class="card custom_card" id="card_height">
                    <div class="card-header">
                        <h4 class="page-title float-left">Chats List</h4>
                        <ul class="list-inline mb-0 text-right">
                            <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                                <a href="#searchFilter" data-toggle="collapse"  class="nav-link"><i class="ti-filter"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <!-- Search Filter Start -->
                        <div class="filter_section collapse" id="searchFilter">
                            <form method="post" action="javascript:loadChatList()" id="search_form">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <div class="dateicon">
                                                <input type="text" readonly name="from_date" id="fromDate" class="form-control form-control-lg datetimepicker-input" data-target="#fromDate" data-toggle="datetimepicker" placeholder="">
                                                <label class="control-label">From</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <div class="dateicon">
                                                <input type="text" readonly name="to_date" id="toDate" class="form-control form-control-lg datetimepicker-input" data-target="#toDate" data-toggle="datetimepicker" placeholder="">
                                                <label class="control-label">To</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-4 col-sm-6">
                                        <div class="form-group d-inline-block mr-2">
                                            <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                        </div>
                                        <div class="form-group d-inline-block">
                                            <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="reset">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Search Filter End -->
                        <div class="table-responsive" id="getChatList">
                        </div>                        
                    </div>
                </div>
            </div>
            <!-- flagged terms tab start -->
            <div class="tab-pane fade" id="flagged-terms" role="tabpanel" aria-labelledby="flagged-terms-tab">
                <div class="card custom_card" id="card_height">
                    <div class="card-header">
                        <h4 class="page-title float-left">Flagged Terms List</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive" id="getFlaggedTermsList">
                        </div>
                    </div>
                </div>
            </div>
            <!-- tab end -->
        </div>
    </div>
</main>
<!-- Main Content End -->
<script>
    // onload chat(connection) list
    $(document).ready(function ()
    {
        $('#preloader').hide();
        loadChatList();
    });
    // reset form after search data
    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadChatList();
    }
    ;
    // function using for get chat(connection) list
    function loadChatList()
    {
        pageDivLoader('show', 'getChatList');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('admin/load-chat-list')); ?>",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getChatList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    // function using for change status
    function changeStatus(el, id) {
        if ($(el).is(':checked')) {
            var status = 'active';
        } else {
            var status = 'inactive';
        }
        bootbox.confirm({
            message: "Are you sure you want to change the status ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                }
            },
            callback: function (result) {
                if (result) {
                    update_status(id, status);
                } else {
                    if (status == 'active') {
                        $(el).prop('checked', false);
                    } else {
                        $(el).prop('checked', true);
                    }
                    return true;
                }
            }
        });
    }
    // function using for update status
    function update_status(id, status) {
        $.ajax({
            url: "<?php echo e(url('admin/change-connection-status')); ?>",
            type: 'GET',
            data: {id: id, status: status},
            cache: false,
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    toastrAlertMessage('success', data.message);
                    loadChatList();
                } else {
                    toastrAlertMessage('error', data.message);
                }
            },
            error: function (err) {
                toastrAlertMessage('error', err);
            },
            complete: function () {
            }
        });
    }
    // function using for delete connection by id
    function removeConnection(id) {
        bootbox.confirm({
            message: "Are you sure you want to delete this ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                },
            },
            callback: function (result) {
                if (result) {
                    var url = "<?php echo e(url('admin/remove-connection')); ?>/ " + id;
                    $.ajax({type: "GET", url: url,
                        success: function (response) {
                            if (response.success) {
                                toastrAlertMessage('success', response.message);
                                loadChatList();
                            } else {
                                toastrAlertMessage('error', response.message);
                            }
                        }
                    });
                }
            }
        });
    }
    // function using for get flagged list
    function getFlaggedTermslist()
    {
        pageDivLoader('show', 'getFlaggedTermsList');
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('admin/load-flagged-terms-list')); ?>",
            success: function (response)
            {
                if (response.success) {
                    $("#getFlaggedTermsList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    // function using for change tabs
    function showFlaggedActi() {
        loadChatList();
    }
    // function using for change tabs
    function showFlaggedTerms() {
        getFlaggedTermslist();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>