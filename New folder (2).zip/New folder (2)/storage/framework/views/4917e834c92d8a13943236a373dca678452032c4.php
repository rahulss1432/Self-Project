<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<!-- dashboard count and mentor list page -->
<!-- Main Content Start -->
<main class="main-content dashboard-page" id="mainContent">
    <div class="page-content">
        <div class="container-fluid">
            <section class="admin-fun-fact">
                <div class="row box-row">
                    <div class="col-md-6 col-xl-4">
                        <a href="<?php echo e(url('admin/manage-payment')); ?>" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">2019 Earned Total</h2>
                                <p class="mb-0" id="getEarnCount">

                                </p>
                            </div>
                            <div class="icon bg-pink">
                                <i class="ti-money"></i>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-6 col-xl-4">
                        <a href="<?php echo e(url('admin/manage-contractor')); ?>" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Mentors</h2>
                                <p class="mb-0" id="getMentorsCount">

                                </p>
                            </div>
                            <div class="icon bg-yello">
                                <i class="ti-layers-alt"></i>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-6 col-xl-4">
                        <a href="<?php echo e(url('admin/manage-user')); ?>" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Mentees</h2>
                                <p class="mb-0" id="getMenteesCount">

                                </p>
                            </div>
                            <div class="icon bg-green">
                                <i class="ti-user"></i>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-6 col-xl-4">
                        <a href="javascript:void(0);" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Impressions</h2>
                                <p class="mb-0" id="getImpressionsCount">

                                </p>
                            </div>
                            <div class="icon bg-green-light">
                                <i class="ti-gallery"></i>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-6 col-xl-4">
                        <a href="<?php echo e(url('admin/manage-category')); ?>" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Categories</h2>
                                <p class="mb-0" id="getCategoryCount">

                                </p>
                            </div>
                            <div class="icon bg-red-light">
                                <i class="ti-view-list-alt"></i>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-6 col-xl-4">
                        <a href="javascript:void(0);" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Flagged</h2>
                                <p class="mb-0">200</p>
                            </div>
                            <div class="icon bg-blue">
                                <i class="ti-pencil-alt"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </section>
            <!-- filter by country, state and city -->
            <section class="admin-fun-fact">
                <div class="row box-row">
                    <div class="col-md-6 col-xl-4">
                        <div class="form-group">
                            <select name="country_id" id="country" data-size="6" onchange="getAllCounts($(this).val(), '', '');" class="form-control form-control-lg selectpicker" title="Select Country">
                            </select>
                            <label class="control-label">Select Country</label>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-4">
                        <div class="form-group">
                            <select name="state_id" id="state" data-size="6" onchange="getAllCounts('', $(this).val(), '');" class="form-control form-control-lg selectpicker" title="Select State">
                            </select>
                            <label class="control-label">Select State</label>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-4">
                        <div class="form-group">
                            <select name="city_id" id="city" data-size="6" onchange="getAllCounts('', '', $(this).val());" class="form-control form-control-lg selectpicker" title="Select City">
                            </select>
                            <label class="control-label">Select City</label>
                        </div>
                    </div>
                </div>
            </section>
            <input type="hidden" id="countryId">
            <input type="hidden" id="stateId">
            <input type="hidden" id="cityId">
            <!-- top 20 user list table -->
            <div class="card custom_card h-auto mt-4" id="getUserList">

            </div>
        </div>
    </div>
</main>
<!-- Main Content End -->
<script>
    // get all countries
    $(document).ready(function () {
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('admin/get-all-country')); ?>",
            success: function (data)
            {
                $('#country').html(data);
                $('#country').selectpicker('refresh');
            }
        });
        getAllCounts('', '', '');
    });
    // function using for get all counts by country, state and city
    function getAllCounts(countryId, stateId, city) {
        $('#countryId').val(countryId);
        $('#stateId').val(stateId);
        $('#cityId').val(city);
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('admin/get-all-counts')); ?>",
            data: {country_id: countryId, state_id: stateId, city_id: city},
            success: function (data)
            {
                if (data.success) {
                    $("#getMentorsCount").html(data.mentors);
                    $("#getMenteesCount").html(data.mentees);
                    $("#getImpressionsCount").html(data.inpressions);
                    $("#getEarnCount").html(data.earns);
                    $("#getCategoryCount").html(data.category);
                    if (countryId) {
                        $('#state').html(data.getStates);
                        $('#state').selectpicker('refresh');
                    }
                    if (stateId) {
                        $('#city').html(data.getCities);
                        $('#city').selectpicker('refresh');
                    }
                    if (city) {
                        getUsersOnDashboard(countryId, stateId, city);
                    }
                } else {
                    toastrAlertMessage('error', data.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    // function using for get all counts
    function getUsersOnDashboard(countryId, stateId, city) {
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('admin/get-dashboard-users')); ?>",
            data: {country_id: countryId, state_id: stateId, city_id: city},
            success: function (data)
            {
                if (data.success) {
                    $("#getUserList").html(data.html);
                } else {
                    toastrAlertMessage('error', data.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>