<!-- Manage Faq Listing Start -->
<?php if(count($faqs) > 0): ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Question</th>
            <th>Answer</th>
            <th class="w170 text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(!empty($faq->question) ? $faq->question : '-'); ?></td>
            <td><?php echo e(!empty($faq->answer) ? $faq->answer : '-'); ?></td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item">
                        <a href="<?php echo e(url('admin/edit-faq/'.base64_encode($faq->id))); ?>"><i class="ti-pencil-alt"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onclick="removeFaq('<?php echo e($faq->id); ?>');"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<!-- Manage Faq Listing End -->
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($faqs->links()); ?>

<script>
    // faq list pagination
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getFaqList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'GET',
            url: pageLink,
            async: false,
            success: function (response) {
            $('.pagination:first').remove();
            $('#getFaqList').html(response.html);
            }
    });
    });
</script>