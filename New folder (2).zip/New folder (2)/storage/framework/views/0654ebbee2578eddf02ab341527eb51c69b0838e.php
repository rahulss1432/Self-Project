<!-- load post image list on popup -->
<?php if(count($postImages) > 0): ?>
<div class="row">
    <?php $__currentLoopData = $postImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-4">
        <div class="img_wrap">
            <img src="<?php echo e(checkPostImage($postImage->image_title,'posts')); ?>" class="img-fluid" alt="media-img">  
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>