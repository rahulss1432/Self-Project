<?php $__env->startSection('title', 'Manage Cms'); ?>
<?php $__env->startSection('content'); ?>
<!-- manage faq list page -->
<!-- Main Content Start -->
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content" id="pageContent">
        <div class="card custom_card" id="card_height">
            <div class="card-header">
                <h4 class="page-title float-left">FAQ List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="<?php echo e(url('admin/add-faqs')); ?>" class="nav-link"><i class="ti-plus"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="admin-tabs">
                    <div class="tab-content">
                        <div class="tab-pane fade show active">
                            <div class="table-responsive" id="getFaqList">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- Main Content End -->
<script>
    /*
     * Run function when page refresh
     *  loadFaqList(): Faq list function call
     */
    $(document).ready(function ()
    {
        $('#preloader').hide();
        loadFaqList();
    });
    /*
     * Ajax Content Load
     * var url : Path faq list page
     */
    function loadFaqList()
    {
        pageDivLoader('show', 'getFaqList');
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('admin/load-faq-list')); ?>",
            success: function (response)
            {
                if (response.success) {
                    $("#getFaqList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    // function using for delete faq list data by id
    function removeFaq(id) {
        bootbox.confirm({
            message: "Are you sure you want to delete this ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                },
            },
            callback: function (result) {
                if (result) {
                    var url = "<?php echo e(url('admin/remove-faq')); ?>/ " + id;
                    $.ajax({type: "GET", url: url,
                        success: function (response) {
                            if (response.success) {
                                toastrAlertMessage('success', response.message);
                                loadFaqList();
                            } else {
                                toastrAlertMessage('error', response.message);
                            }
                        }
                    });
                }
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>