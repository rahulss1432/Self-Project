<!-- load user profile detail -->
<div class="info_row">
    <div class="img_wrap">
        <img src="<?php echo e(checkUserImage($getContractors->profile_image, 'user')); ?>" alt="profile-img" class="img-fluid">
    </div>
    <div class="details">
        <ul class="right_side list-unstyled">
            <li>
                <label>Name</label>
                <span><?php echo e(!empty($getContractors->first_name) ? getFullName($getContractors->first_name, $getContractors->last_name) : '-'); ?></span>
            </li>
            <li>
                <label>Email</label>
                <span><?php echo e(!empty($getContractors->email) ? $getContractors->email : '-'); ?></span>
            </li>
            <li>
                <label>Phone Number</label>
                <span><?php echo e((!empty($getContractors->phone_number)) ? $getContractors->phone_number : '-'); ?></span>
            </li>
            <li>
                <label>DOB</label>
                <span><?php echo e((!empty($getContractors->date_of_birth)) ? showDateFormat($getContractors->date_of_birth) : '-'); ?></span>
            </li>
            <li>
                <label>Experience </label>
                <span><?php echo e((!empty(getExperienceByUserId($getContractors->id))) ? getExperienceByUserId($getContractors->id) : '-'); ?></span>
            </li>
            <li>
                <label>Profile Status</label>
                <span class="text-success"><?php echo e((!empty($getContractors->status)) ? ucfirst($getContractors->status) : '-'); ?></span>
            </li>
        </ul>
    </div>
</div>
<div class="full-dtl">
    <ul class="right_side list-unstyled">
        <li>
            <label>Ratings</label>
            <span class="rating d-block">
                <?php 
                $ratings = getRatingsByUserId($getContractors->id);
                 ?>
                <?php if(count($ratings)>0): ?>
                <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php for($i=1; $i<=$data->avgRating; $i++): ?>
                <i class="fa fa-star" aria-hidden="true" data-rating="<?php echo e($data->avgRating); ?>"></i>
                <?php endfor; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                -
                <?php endif; ?>
            </span>
        </li>
        <li>
            <label>Registration Date</label>
            <span class="d-block">
                <?php echo e(!empty($getContractors->created_at) ? showDateFormat($getContractors->created_at) : '-'); ?>

            </span>
        </li>
        <li>
            <label>Mentor Locator unique URL</label>
            <span class="d-block"><a href="javascript:void(0);" class="theme-color">https://www.mentolocator.com/Garrettbird</a></span>
        </li>
        <li>
            <label>Address</label>
            <span class="d-block"><?php echo e((!empty($getContractors->address)) ? $getContractors->address : '-'); ?></span>
        </li>
    </ul>
</div>