<?php $__env->startSection('title', 'Manage Contractors'); ?>
<?php $__env->startSection('content'); ?>
<!-- manage mentor(contractor) list page -->
<!-- Main Content Start -->
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Mentors List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <!-- Search Filter Start -->
                <div class="filter_section collapse" id="searchFilter">
                    <form method="post" action="javascript:getContractorslist()" id="search_form">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control form-control-lg">
                                    <label class="control-label">Name</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="email" class="form-control form-control-lg" />
                                    <label class="control-label">Email Address</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <select name="status" class="selectpicker form-control form-control-lg">
                                        <option value=""> Select Status</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                     <label class="control-label">Select Status</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group d-inline-block mr-2">
                                    <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                </div>
                                <div class="form-group d-inline-block">
                                    <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="submit">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- Search Filter End -->
                <div class="table-responsive" id="getcontractorslist">

                </div>
            </div>
        </div>
    </div>
</main>
<!-- Main Content Start -->
<!-- profile modal -->
<div class="modal fade" id="customerProfile" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="customerprofile" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md profile-modal" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Mentors Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="user_info" id="getCotractorDetailsList">

                </div>
            </div>
        </div>
    </div>
</div>
<!-- check availability modal -->
<div class="modal fade" id="viewAvailibility" tabindex="-1" role="dialog" aria-labelledby="customerprofile" data-backdrop="static" data-keyword="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md availibility-modal" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">View Availability </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body px-0">
                <div class="mCustomScrollbar list_scr" data-mcs-theme="minimal-dark">
                    <ul class="availibility-list list-unstyled mb-0" id="getCheckAvailability">

                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- view document modal -->
<div class="modal fade" id="viewDocument" tabindex="-1" role="dialog" aria-labelledby="customerprofile" data-backdrop="static" data-keyword="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md category-modal" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">View Document </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body px-0">
                <div class="mCustomScrollbar list_scr" data-mcs-theme="minimal-dark">
                    <ul class="document-list list-unstyled mb-0" id="getDocument">

                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- view category modal -->
<div class="modal fade" id="viewCategory" tabindex="-1" role="dialog" aria-labelledby="customerprofile" data-backdrop="static" data-keyword="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md category-modal" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">View Category </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body px-0">
                <div class="mCustomScrollbar list_scr" data-mcs-theme="minimal-dark">
                    <ul class="category-list list-unstyled mb-0" id="getCategory">

                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    // reset form after search data
    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        getContractorslist();
    }
    /*
     * Run function when page refresh
     *  getContractorslist(): contractor(mentor) list function call
     */
    $(document).ready(function () {
        getContractorslist();
        setTimeout(function () {
            $("#listPagination").fadeIn();
        }, 2000);
    });

    /*
     * Ajax Content Load
     * var url : Path contractor(mentor) list page
     */
    function getContractorslist() {
        pageDivLoader('show', 'getcontractorslist');
        var formData = $("#search_form").serializeArray();
        formData.push('_token', '<?php echo e(csrf_token()); ?>');
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('/admin/load-contractors-list')); ?>",
            data: formData,
            success: function (response)
            {
                if (response.success) {
                    $("#getcontractorslist").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    /** @returns  update status */
    function changeStatus(el, id) {
        if ($(el).is(':checked')) {
            var status = 'active';
        } else {
            var status = 'inactive';
        }
        bootbox.confirm({
            message: "Are you sure you want to change the status ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                }
            },
            callback: function (result) {
                if (result) {
                    updateStatus(id, status);
                } else {
                    if (status == 'active') {
                        $(el).prop('checked', false);
                    } else {
                        $(el).prop('checked', true);
                    }
                    return true;
                }
            }
        });
    }

    /** @returns  update status */
    function updateStatus(id, status) {
        $.ajax({
            url: "<?php echo e(url('admin/update-contractor-status')); ?>",
            type: 'GET',
            data: {id: id, status: status},
            cache: false,
            dataType: 'JSON',
            success: function (data) {
                console.log(data);
                if (data.success) {
                    toastrAlertMessage('success', data.message);
                    getContractorslist();
                } else {
                    toastrAlertMessage('error', data.message);
                }
            },
            error: function (err) {
                toastrAlertMessage('error', err);
            },
            complete: function () {
                return true;
            }
        });
    }

    /** @returns  delete mentor(contractor) */
    function removeContractor(id) {
        bootbox.confirm({
            message: "Are you sure you want to delete this ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                },
            },
            callback: function (result) {
                if (result) {
                    var url = "<?php echo e(url('admin/remove-contractor')); ?>/ " + id;
                    $.ajax({
                        type: "GET",
                        url: url,
                        success: function (response) {
                            if (response.success) {
                                toastrAlertMessage('success', response.message);
                                getContractorslist();
                            } else {
                                toastrAlertMessage('error', response.message);
                            }
                        }
                    });
                }
            }
        });
    }

    /** @returns  load mentor(contractor) details */
    function loadContractorDetails(id) {
        $('#customerProfile').modal('show');
        pageDivLoader('show', 'getCotractorDetailsList');
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('/admin/load-contractor-details')); ?>/" + id,
            success: function (response)
            {
                if (response.success) {
                    $("#getCotractorDetailsList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            }
        });
    }

    /** @returns  load check availability */
    function loadCheckAvailability(id) {
        $('#viewAvailibility').modal('show');
        pageDivLoader('show', 'getCheckAvailability');
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('/admin/load-check-availability')); ?>/" + id,
            success: function (response)
            {
                if (response.success) {
                    $("#getCheckAvailability").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            }
        });
    }
    
    /** @returns  load view document */
    function loadViewDocument(id) {
        $('#viewDocument').modal('show');
        pageDivLoader('show', 'getDocument');
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('/admin/load-view-document')); ?>/" + id,
            success: function (response)
            {
                if (response.success) {
                    $("#getDocument").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            }
        });
    }
    
    /** @returns  load view category */
    function loadViewCategory(id) {
        $('#viewCategory').modal('show');
        pageDivLoader('show', 'getCategory');
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('/admin/load-view-category')); ?>/" + id,
            success: function (response)
            {
                if (response.success) {
                    $("#getCategory").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>