<!-- Post Listing Start -->
<?php if(count($posts) > 0): ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th>Mentor Name</th>
            <th>Mentee Name</th>
            <th>Date and time </th>
            <th>View Media File</th>
            <th class="w350">Comment</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(!empty($post->postAppointment->reference_id) ? '#'.$post->postAppointment->reference_id : '-'); ?></td>
            <td><?php echo e(!empty($post->postFromUser->first_name) ? getFullName($post->postFromUser->first_name, $post->postFromUser->last_name) : '-'); ?></td>
            <td><?php echo e(!empty($post->postToUser->first_name) ? getFullName($post->postToUser->first_name, $post->postToUser->last_name) : '-'); ?></td>
            <td><?php echo e(!empty($post->created_at) ? dateTimeFormat($post->created_at) : '-'); ?></td>
            <td><a href="javascript:void(0);" class="btn-blue" onclick="viewMedia('<?php echo e($post->id); ?>');">View Media</a></td>
            <td>
                <?php echo e(getLimitText(30,$post->comment)); ?>

                <?php 
                $stringLength = strlen($post->comment);
                if($stringLength > 30){
                 ?>
                <a href="javascript:void(0);" onclick="commentsView('<?php echo e($post->id); ?>', 'post')" class="theme-color">Read More</a>
                <?php 
                }
                 ?>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="removePostReview('<?php echo e($post->id); ?>', 'post');"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<!-- Post Listing End -->
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($posts->links()); ?>

<script>
    // post list pagination
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getPostsList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '<?php echo e(csrf_token()); ?>'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getPostsList').html(response.html);
            }
    });
    });
</script>