<?php $__env->startSection('title', 'Message'); ?>
<?php $__env->startSection('content'); ?>
<!-- message list page -->
<!-- Main Content Start -->
<main class="main-content messages-page" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Message List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Back" >
                        <a href="<?php echo e(url('admin/manage-chat')); ?>" class="nav-link"><i class="ti-arrow-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body message-body">
                <div class="row">
                    <!-- right section start -->
                    <div class="right_section col">
                        <!-- chat section -->
                        <ul class="mCustomScrollbar list-unstyled chat_sec" data-mcs-theme="minimal-dark">
                            <?php if(count($messages)>0): ?>
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($message->from_id == $fromId): ?>
                            <li class="left">
                                <div class="img_wrap">
                                    <img src="<?php echo e(checkUserImage($message->profile_image, '')); ?>" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                                <div class="chat_box">
                                    <p><?php echo $message->message; ?></p>
                                    <span class="time"><?php echo e(chatTimeShow($message->created_at)); ?></span>
                                </div>
                            </li>
                            <?php else: ?>
                            <li class="right">
                                <div class="chat_box">
                                    <p><?php echo $message->message; ?></p>
                                    <span class="time"><?php echo e(chatTimeShow($message->created_at)); ?></span>
                                </div>
                                <div class="img_wrap">
                                    <img src="<?php echo e(checkUserImage($message->profile_image, '')); ?>" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?> 
                            <div class="alert alert-danger text-center">No record found.</div>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- Main Content End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>