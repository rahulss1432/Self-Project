<!-- Reviews Start -->
<?php if(count($reviews) > 0): ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th>Mentor Name</th>
            <th>Mentee Name</th>
            <th>Rating counts</th>
            <th>Date and time </th>
            <th class="w350">Comment</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(!empty($review->ratingAppointment->reference_id) ? '#'.$review->ratingAppointment->reference_id : '-'); ?></td>
            <td><?php echo e(!empty($review->ratingFromUser->first_name) ? getFullName($review->ratingFromUser->first_name, $review->ratingFromUser->last_name) : '-'); ?></td>
            <td><?php echo e(!empty($review->ratingToUser->first_name) ? getFullName($review->ratingToUser->first_name, $review->ratingToUser->last_name) : '-'); ?></td>
            <td>
                <div class="rating d-inline-block">
                    <?php for($i=1; $i<=$review->rating; $i++): ?>
                    <i class="fa fa-star" aria-hidden="true" data-rating="<?php echo e($review->rating); ?>"></i>
                    <?php endfor; ?>
                </div>
                <span>(<?php echo e($review->rating); ?>.0)</span>
            </td>
            <td><?php echo e(!empty($review->created_at) ? dateTimeFormat($review->created_at) : '-'); ?></td>
            <td>
                <?php echo e(getLimitText(30,$review->reviews)); ?>

                <?php 
                $stringLength = strlen($review->reviews);
                if($stringLength > 30){
                 ?>
                <a href="javascript:void(0);" onclick="commentsView('<?php echo e($review->id); ?>', 'review')" class="theme-color">Read More</a>
                <?php 
                }
                 ?>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="removePostReview('<?php echo e($review->id); ?>', 'review');"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<!-- Reviews End -->
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($reviews->links()); ?>

<script>
    // review list pagination
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getReviewsList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '<?php echo e(csrf_token()); ?>'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getReviewsList').html(response.html);
            }
    });
    });
</script>