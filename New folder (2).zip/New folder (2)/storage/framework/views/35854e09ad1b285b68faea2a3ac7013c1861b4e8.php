<!-- Manage Complaint Listing Start -->
<?php if(count($complaints) > 0): ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>From user</th>
            <th>To User</th>
            <th>Comments</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(!empty($complaint->fromUser->first_name) ? getFullName($complaint->fromUser->first_name, $complaint->fromUser->last_name) : '-'); ?></td>
            <td><?php echo e(!empty($complaint->toUser->first_name) ? getFullName($complaint->toUser->first_name, $complaint->toUser->last_name) : '-'); ?></td>
            <td><?php echo e(getLimitText(100,$complaint->comments)); ?>

                <?php 
                $stringLength = strlen($complaint->comments);
                if($stringLength > 100){
                 ?>
                <a href="javascript:void(0);" onclick="commentsView('<?php echo e($complaint->id); ?>')" class="theme-color">Read More</a>
                <?php 
                }
                 ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<!-- Manage Complaint Listing End -->
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($complaints->links()); ?>

<script>
    // complaint list pagination
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getComplaintList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'GET',
            url: pageLink,
            async: false,
            success: function (response) {
            $('.pagination:first').remove();
            $('#getComplaintList').html(response.html);
            }
    });
    });
    function commentsView(id)
    {
    $("#commentsModal").modal('show');
    pageDivLoader('show', 'commentsView');
    $.ajax({
    type: "GET",
            url: "<?php echo e(url('admin/load-complaints-view')); ?>/" + id,
            success: function (response)
            {
            if (response.success) {
            $("#commentsView").html(response.complaints);
            } else {
            toastrAlertMessage('error', response.message);
            }
            },
            error: function (err) {
            var obj = jQuery.parseJSON(err.responseText);
            for (var x in obj) {
            toastrAlertMessage('error', obj[x]);
            }
            }
    });
    }
</script>