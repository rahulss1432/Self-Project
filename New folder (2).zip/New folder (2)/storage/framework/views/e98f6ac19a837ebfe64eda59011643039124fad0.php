<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
<!-- login page -->
<!-- Main Content Start -->
<main class="login-page ">
    <div class="login-wrap mx-auto">
        <div class="login-header d-flex align-items-center justify-content-center">
            <img src="<?php echo e(asset('public/images/logo.png')); ?>" alt="logo" class="img-fluid">
        </div>
        <div class="login-field">
            <form id="adminLoginForm" method="POST" action="<?php echo e(url('admin/login')); ?>" autocomplete="off">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <i class="ti-email icon"></i>
                    <input type="text" name="email" class="form-control form-control-lg" id="inlineFormInputGroup" placeholder="Email"/>
                </div>
                <div class="form-group">
                    <i class="ti-lock icon"></i>
                    <input type="password" name="password" class="form-control form-control-lg" placeholder="Password"/>

                    <div id="spanLoginError"></div>
                </div>
                <div class="form-group pl-0 text-center">
                    <button type="submit" id="btnLogin" class="btn btn-primary ripple-effect">LOGIN 
                        <i id="loginFormLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none"></i>
                    </button>
                </div>
            </form>
            <?php echo JsValidator::formRequest('App\Admin\Http\Requests\AdminLoginRequest','#adminLoginForm'); ?>

        </div>
        <div class="login-footer">
            <a href="<?php echo e(url('admin/forgot-password')); ?>">FORGOT PASSWORD <span class="ti-arrow-right"></span></a>
        </div>
    </div>
</main>
<!-- Main Content End -->
<script type="text/javascript">
    // for login on submit
    $(document).on('submit', '#adminLoginForm', function (e) {
        $('#spanLoginError').text('');
        e.preventDefault();
        if ($('#adminLoginForm').valid()) {
            $('#btnLogin').prop('disabled', true);
            $('#loginFormLoader').show();
            $.ajax({
                url: "<?php echo e(url('admin/login')); ?>",
                data: $('#adminLoginForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = response.redirectUrl;
                        }, 500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnLogin').prop('disabled', false);
                        $('#loginFormLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = $.parseJSON(err.responseText);
                    for (var x in obj) {
                        if (obj[x].email) {
                            $('#spanLoginError').html('<span class="help-block error-help-block">' + obj[x].email + '</span>');
                        } else {
                            $('#spanLoginError').html('<span class="help-block error-help-block">' + obj[x] + '</span>');
                        }
                        $('#loginFormLoader').hide();
                        $('#btnLogin').prop('disabled', false);
                    }
                }
            });
        }
    });
    // function using for remove error
    function remove_error() {
        $('#spanLoginError').html('');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>