<!-- load user category list -->
<?php if(count($getCategory)>0): ?>
<?php $__currentLoopData = $getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
        <i class="ti-layout-grid3"></i><?php echo e(!empty($data->mentorCategory->category_name) ? $data->mentorCategory->category_name : '-'); ?>

</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>