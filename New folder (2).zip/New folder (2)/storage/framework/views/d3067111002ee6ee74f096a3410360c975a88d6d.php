<li class="left">
    <div class="img_wrap">
        <img src="user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
    <div class="chat_box">
        <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
        <span class="time">05.00 pm</span>
    </div>
</li>
<li class="right">
    <div class="chat_box">
        <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
        <span class="time">05.00 pm</span>
    </div>
    <div class="img_wrap">
        <img src="user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
</li>
<li class="left">
    <div class="img_wrap">
        <img src="user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
    <div class="chat_box">
        <p>Pnec rutrum congue</p>
        <span class="time">05.00 pm</span>
    </div>
</li>
<li class="right">
    <div class="chat_box">
        <p>Pnec rutrum congue</p>
        <span class="time">05.00 pm</span>
    </div>
    <div class="img_wrap">
        <img src="user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
</li>
<li class="left">
    <div class="img_wrap">
        <img src="user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
    <div class="chat_box">
        <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
        <span class="time">05.00 pm</span>
    </div>
</li>
<li class="right">
    <div class="chat_box">
        <p>Pnec rutrum congue</p>
        <span class="time">05.00 pm</span>
    </div>
    <div class="img_wrap">
        <img src="user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
</li>
<li class="left">
    <div class="img_wrap">
        <img src="user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
    <div class="chat_box">
        <p>Pnec rutrum congue</p>
        <span class="time">05.00 pm</span>
    </div>
</li>
<li class="right">
    <div class="chat_box">
        <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
        <span class="time">05.00 pm</span>
    </div>
    <div class="img_wrap">
        <img src="user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
</li>
<li class="left">
    <div class="img_wrap">
        <img src="user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
    <div class="chat_box">
        <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
        <span class="time">05.00 pm</span>
    </div>
</li>
<li class="right">
    <div class="chat_box">
        <p>Pnec rutrum congue</p>
        <span class="time">05.00 pm</span>
    </div>
    <div class="img_wrap">
        <img src="user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
</li>
<li class="left">
    <div class="img_wrap">
        <img src="user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
    <div class="chat_box">
        <p>Pnec rutrum congue</p>
        <span class="time">05.00 pm</span>
    </div>
</li>
<li class="right">
    <div class="chat_box">
        <p>Pnec rutrum congue</p>
        <span class="time">05.00 pm</span>
    </div>
    <div class="img_wrap">
        <img src="user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
</li>
<li class="left">
    <div class="img_wrap">
        <img src="user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
    <div class="chat_box">
        <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
        <span class="time">05.00 pm</span>
    </div>
</li>
<li class="right">
    <div class="chat_box">
        <p>Pnec rutrum congue</p>
        <span class="time">05.00 pm</span>
    </div>
    <div class="img_wrap">
        <img src="user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
</li>
<li class="left">
    <div class="img_wrap">
        <img src="user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
    <div class="chat_box">
        <p>Pnec rutrum congue</p>
        <span class="time">05.00 pm</span>
    </div>
</li>
<li class="right">
    <div class="chat_box">
        <p>Pnec rutrum congue</p>
        <span class="time">05.00 pm</span>
    </div>
    <div class="img_wrap">
        <img src="user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
    </div>
</li>