<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<!-- links -->
<link href="<?php echo e(asset('public/css/bootstrap-select.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/css/themify-icons.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/css/jquery.mCustomScrollbar.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/css/tempusdominus-bootstrap-4.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/css/admin.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/css/toastr.min.css')); ?>" rel="stylesheet" type="text/css">

<script src="<?php echo e(asset('public/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/moment.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/toastr.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/bootbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/jsvalidation.min.js')); ?>"></script>
<script src="<?php echo e(url('public/js/tinymce/tinymce.min.js')); ?>"></script>