<!-- Manage Booking Listing Start -->
<?php if(count($bookings) > 0): ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th class="w250">Address</th>
            <th>Job Date and Time</th>
            <th>Status</th>
            <th>Service Type</th>
            <th>Mentor Name</th>
            <th>User Name</th>
            <th>Amount</th>
            <th class="w120 text-center">Invoice</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
        $getData = getMentorAvailability($booking->to_id,$booking->date);
         ?>
        <tr>
            <td><?php echo e(!empty($booking->reference_id) ? '#'.$booking->reference_id : '-'); ?></td>
            <td><?php echo e(!empty($getData->address) ? $getData->address : '-'); ?></td>
            <td><?php echo e(!empty($booking->created_at) ? dateTimeFormat($booking->created_at) : '-'); ?></td>
            <td>
                <?php 
                $status = "";
                $statusType = "";
                if($booking->status == "complete"){
                $status = 'Completed';
                $statusType = 'success';
                }elseif($booking->status == "pending"){
                $status = 'Pending';
                $statusType = 'warning';
                }elseif($booking->status == "cancelled"){
                $status = 'Cancelled';
                $statusType = 'danger';
                }else{
                $status = 'Active';
                $statusType = '';
                }
                 ?>
                <span class="text-<?php echo e($statusType); ?>"><?php echo e($status); ?></span>
            </td>
            <td><?php echo e(!empty($booking->bookingService->name) ? $booking->bookingService->name : '-'); ?></td>
            <td><?php echo e(!empty($booking->bookingToUser->first_name) ? getFullName($booking->bookingToUser->first_name, $booking->bookingToUser->last_name) : '-'); ?></td>
            <td><?php echo e(!empty($booking->bookingFromUser->first_name) ? getFullName($booking->bookingFromUser->first_name, $booking->bookingFromUser->last_name) : '-'); ?></td>
            <td><?php echo e(!empty($booking->bookingAmount->total_amount)? '$ '.$booking->bookingAmount->total_amount:'-'); ?></td>
            <td class="text-center"><a href="<?php echo e(url('admin/invoice/'.base64_encode($booking->id))); ?>" target="_blank" class="btn-blue ripple-effect">View Invoice</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<!-- Manage Booking Listing End -->
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($bookings->links()); ?>

<script>
    // booking list pagination
    $(".pagination li a").on('click', function (e) {
        pageDivLoader('show', 'getBookingList');
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '<?php echo e(csrf_token()); ?>'},
            success: function (response) {
                $('.pagination:first').remove();
                $('#getBookingList').html(response.html);
            }
        });
    });
</script>