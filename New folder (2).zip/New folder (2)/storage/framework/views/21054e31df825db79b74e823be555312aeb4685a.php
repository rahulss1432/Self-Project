<!-- Manage Notification Listing Start -->
<?php if(count($notification) > 0): ?>
<?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="notification-box">
    <span class="custom-control-description">
        <!--<p>Editorial Collections</p>-->
        <p><?php echo e(!empty($notify->fromUser->first_name) ? getFullName($notify->fromUser->first_name, $notify->fromUser->last_name) : '-'); ?></p>
        <span><?php echo e(!empty($notify->message) ? $notify->message : '-'); ?></span>
    </span>
</div>
<!-- Manage Notification Listing End -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($notification->links()); ?>

<script type="text/javascript">
    // user notification list pagination
    $(".pagination li a").on('click', function (e) {
        pageDivLoader('show', 'getNotificationList');
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'GET',
            url: pageLink,
            async: false,
            success: function (response) {
                $('.pagination:first').remove();
                $('#getNotificationList').html(response.html);
            }
        });
    });
</script>