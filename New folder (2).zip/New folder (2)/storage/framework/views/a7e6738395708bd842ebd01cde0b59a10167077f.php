<?php $__env->startSection('title', 'Manage Category'); ?>
<?php $__env->startSection('content'); ?>
<!-- manage category list page -->
<!-- Main Content Start -->
<main class="main-content" id="mainContent">
    <div class="page-content">
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="Category" role="tabpanel" aria-labelledby="sub-category-tab">
                <div class="card custom_card">
                    <div class="card-header">
                        <h4 class="page-title float-left">Category List</h4>
                        <ul class="list-inline mb-0 text-right">
                            <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Add Category">
                                <a href="javascript:void(0);" class="nav-link" onclick="showAddCategoryModal();" ><i class="ti-plus"></i></a>
                            </li>
                            <li class="list-inline-item"data-toggle="tooltip" data-placement="top" title="Filter">
                                <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <!-- Search Filter Start -->
                        <div class="filter_section collapse" id="searchFilter">
                            <form method="post" action="javascript:loadCategoryList()" id="search_form">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <input type="text" name="name" class="form-control form-control-lg">
                                            <label class="control-label">Category Name</label>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <select name="status" class="form-control form-control-lg selectpicker">
                                                <option value="">Select Status</option>
                                                <option value="active">Active</option>
                                                <option value="inactive">Inactive</option>
                                            </select>
                                            <label class="control-label">Select Status</label>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-4 col-sm-6">
                                        <div class="form-group d-inline-block mr-2">
                                            <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                        </div>
                                        <div class="form-group d-inline-block">
                                            <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="reset">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Search Filter End -->
                        <div class="table-responsive" id="getCategoryList">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- Main Content End -->

<!-- Add Category Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Category</h5>
                <button type="button" class="close" data-dismiss="modal" onclick="resetAddForm();" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" id="addCategory" class="f-field" action="<?php echo e(url('admin/add-category')); ?>" enctype="multipart/form-data">
                    <input type="hidden" name="category_id" id="category_id">
                    <div class="form-group">
                        <input type="text" name="category_name" class="form-control form-control-lg" />
                        <label class="control-label">Category Name</label>
                    </div>
                    <div class="form-group">
                        <input type="file" name="category_icon" class="form-control form-control-lg" />
                    </div>
                    <div class="form-group mb-0 text-right">
                        <button type="button" onclick="addCategory();" id="btnCategory" class="btn btn-sm btn-primary ripple-effect">
                            Submit <i id="categoryFormLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none"></i>
                        </button>
                    </div>
                </form>
                <?php echo JsValidator::formRequest('App\Admin\Http\Requests\AddCategoryRequest','#addCategory'); ?>

            </div>
        </div>
    </div>
</div>
<script>
    /*
     * Add category modal show
     */
    function showAddCategoryModal() {
        $("#addModal").modal('show');
    }
    // function using for reset add form after add data
    function resetAddForm() {
        window.location.reload();
    }
    // function using for add category
    function addCategory() {
        var formData = new FormData($('#addCategory')[0]);
        formData.append('_token', '<?php echo e(csrf_token()); ?>');
        if ($('#addCategory').valid()) {
            $('#btnCategory').prop('disabled', true);
            $('#categoryFormLoader').show();
            $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/add-category')); ?>",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response)
                {
                    if (response.success) {
                        $("#addModal").modal('hide');
                        toastrAlertMessage('success', response.message);
                        $('#addCategory')[0].reset();
                        $('#btnCategory').prop('disabled', false);
                        $('#categoryFormLoader').hide();
                        loadCategoryList();
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnCategory').prop('disabled', false);
                        $('#categoryFormLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#categoryFormLoader').hide();
                    $('#btnCategory').prop('disabled', false);
                }
            });
        }
    }
    /*
     * Run function when page refresh
     *  loadCategoryList(): Category list function call
     */
    $(document).ready(function ()
    {
        $('#preloader').hide();
        loadCategoryList();
    });
    // function using for reset form after filter data
    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadCategoryList();
    }
    /*
     * Ajax Content Load
     * var url : Path category list page
     */
    function loadCategoryList()
    {
        pageDivLoader('show', 'getCategoryList');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('admin/load-category-list')); ?>",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getCategoryList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    // function using for change category status
    function changeStatus(el, id) {
        if ($(el).is(':checked')) {
            var status = 'active';
        } else {
            var status = 'inactive';
        }
        bootbox.confirm({
            message: "Are you sure you want to change the status ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                }
            },
            callback: function (result) {
                if (result) {
                    update_status(id, status);
                } else {
                    if (status == 'active') {
                        $(el).prop('checked', false);
                    } else {
                        $(el).prop('checked', true);
                    }
                    return true;
                }
            }
        });
    }
    // function using for update category status
    function update_status(id, status) {
        $.ajax({
            url: "<?php echo e(url('admin/change-category-status')); ?>",
            type: 'GET',
            data: {id: id, status: status},
            cache: false,
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    toastrAlertMessage('success', data.message);
                    loadCategoryList();
                } else {
                    toastrAlertMessage('error', data.message);
                }
            },
            error: function (err) {
                toastrAlertMessage('error', err);
            },
            complete: function () {
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>