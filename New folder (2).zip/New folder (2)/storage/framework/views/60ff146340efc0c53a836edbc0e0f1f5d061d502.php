<!DOCTYPE HTML>
<html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <title>Mentor Locator</title>
    </head>
    <style type="text/css">
        body {
            margin: 0;
            padding: 0;
        }

        table {
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }

        td,
        th {
            border-collapse: collapse;
        }

        td a img {
            text-decoration: none;
            border: none;
        }
    </style>

    <body style="background: #07B1F3;"><br><br><br>
        <table cellpadding="0" cellspacing="0" align="center" width="800px" height="auto" style="border-collapse:collapse;border:1px solid #ddd;padding:50px;font-family:Tahoma, Geneva, sans-serif; font-size:14px;color:#060613;">
            <tr style="padding:0">
                <th colspan="1" align="center" style="padding:10px 0px; background-color:#07B1F3;"  valign="top">
                    <img src="http://caption.neuroninc.com/neuron/mentor_locator/www/email/images/logo.png">
                </th>
            </tr>
            <tr>
                <th style="text-align:left;font-size:18px;padding:20px 0px 0px 38px;">Hello <?php echo e($data['username']); ?></th>
            </tr>
            <tr>
                <td style="padding:20px 38px 0px;font-size:16px;">You are receiving this email because we received a password reset request for your Mentor locator admin account !!
                </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td style="padding:20px 38px 0px;font-size:16px;">
            <center><a style="padding:10px 30px; font-size:14px;text-decoration:none;background-color:#07B1F3;color: #fff;border-radius:12px;"  href="<?php echo e($data['link']); ?>"> Reset Password</a></center>
        </td>
    </tr>
    <tr>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td style="padding:20px 38px 0px;font-size:16px;">Thanks & Regards</td>
    </tr>
    <tr>
        <td style="padding:5px 38px 20px;font-size:16px;">Mentor Locator</td>
    </tr>
    <tr>
        <td valign="top" style="background:#07B1F3;padding:5px 0 5px 40px;">
            <p style="font-family:Tahoma, Geneva, sans-serif; font-size:13px;margin:8px 0;color:#FFFFFF;text-align:center;">© <?php echo e(date('Y')); ?> Mentor Locator. All Rights Reserved.</p>
        </td>
    </tr>
</table>
</body>

</html>