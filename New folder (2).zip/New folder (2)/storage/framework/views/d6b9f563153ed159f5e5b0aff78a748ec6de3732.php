<table class="table admin-table">
    <thead>
        <tr>
            <th>Title</th>
            <th>value</th>
            <th class="w100 text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Commission rate in Percentage %</td>
            <td><?php echo e($commission['value']); ?></td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                        <a href="javascript:void(0);" onclick="editCommissionModal('<?php echo e($commission['id']); ?>');"><i class="ti-pencil-alt"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
    </tbody>
</table>