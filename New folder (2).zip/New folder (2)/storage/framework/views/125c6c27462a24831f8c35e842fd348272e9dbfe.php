<!-- booking invoice page -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url('public/images/favicon/apple-touch-icon.png')); ?>">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('public/images/favicon/favicon-32x32.png')); ?>">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('public/images/favicon/favicon-16x16.png')); ?>">
        <link rel="manifest" href="<?php echo e(url('public/images/favicon/site.webmanifest')); ?>">
        <link rel="mask-icon" href="<?php echo e(url('public/images/favicon/safari-pinned-tab.svg')); ?>" color="#5bbad5">
        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="theme-color" content="#ffffff">
        <title>Invoice</title>
        <?php echo $__env->make('admin::include.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body class="bg-light-gray">
        <!-- Main Content Start -->
        <main class="dashboard-main-wrap invoice-page m-0 p-0" id="content">
            <div class="container-fluid">
                <div class="common-detail-section p-0">
                    <div class="content-body rounded">
                        <div class="top-info d-flex align-items-center justify-content-between">
                            <div class="logo">
                                <img src="<?php echo e(url('public/images/blue-logo.png')); ?>" title="mentor" alt="logo">
                            </div>
                            <h1 class="font-md">Invoice</h1>
                        </div>
                        <?php 
                        $getData = getMentorAvailability($invoice->to_id,$invoice->date);
                         ?>
                        <!-- Middle Info Start-->
                        <div class="middle-info">
                            <div class="info">
                                <div class="label-text">
                                    <label for="">Booking ID : </label>
                                    <span><?php echo e(!empty($invoice->reference_id) ? '#'.$invoice->reference_id : '-'); ?> </span>
                                </div>
                                <div class="label-text">
                                    <label for="">Job Date & Time : </label>
                                    <span><?php echo e(!empty($invoice->created_at) ? dateTimeFormat($invoice->created_at) : '-'); ?></span>
                                </div>
                                <div class="label-text">
                                    <label for="">Meeting Place : </label>
                                    <span><?php echo e(!empty($getData->meeting_place) ? $getData->meeting_place : '-'); ?></span>
                                </div>
                                <div class="label-text">
                                    <label for="">Service Type : </label>
                                    <span><?php echo e(!empty($invoice->bookingService->name) ? $invoice->bookingService->name : '-'); ?></span>
                                </div>
                                <div class="label-text">
                                    <label for="">Address : </label>
                                    <span><?php echo e(!empty($getData->address) ? $getData->address : '-'); ?></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="info">
                                        <h4 class="font-md">Mentor</h4>
                                        <p class="mb-1"><?php echo e(!empty($invoice->bookingToUser->first_name) ? $invoice->bookingToUser->first_name.' '.$invoice->bookingToUser->last_name : '-'); ?></p>
                                        <p class="mb-0"><?php echo e(!empty($invoice->bookingToUser->email) ? $invoice->bookingToUser->email : '-'); ?></p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="info">
                                        <h4 class="font-md">User</h4>
                                        <p class="mb-1"><?php echo e(!empty($invoice->bookingFromUser->first_name) ? $invoice->bookingFromUser->first_name.' '.$invoice->bookingFromUser->last_name : '-'); ?></p>
                                        <p><?php echo e(!empty($invoice->bookingFromUser->email) ? $invoice->bookingFromUser->email : '-'); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table common-table">
                                    <tbody>
                                        <tr>
                                            <td>Service Cost</td>
                                            <td><?php echo e(!empty($invoice->bookingAmount->total_amount)? '$ '.$invoice->bookingAmount->total_amount:'-'); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Commission Cost</td>
                                            <td>
                                                <?php 
                                                $commission = getSetting('commision_percent');
                                                $amount = !empty($invoice->bookingAmount->total_amount)? $invoice->bookingAmount->total_amount:'0';
                                                $total = "";
                                                if(is_numeric($amount)){
                                                $total = ($commission / 100) * $amount;
                                                }
                                                echo (!empty($total))? '$ '.$total:'-';
                                                 ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Total Fare (via credit)</th>
                                            <th>
                                                <?php 
                                                $totalAmount = $amount + $total;
                                                 ?>
                                                <?php echo e(!empty($totalAmount)? '$ '.$totalAmount:'-'); ?>

                                            </th>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- Middle Info End-->
                    </div>
                </div>
            </div>
        </main>
        <!-- Main Content End -->
    </body>
</html>