<!-- load check availability list -->
<?php if(count($getAvailability)>0): ?>
<?php $__currentLoopData = $getAvailability; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
    <div class="location_row">
        <i class="fa fa-map-marker"></i>
        <h3><?php echo e(!empty($data->state) ? $data->state : '-'); ?> <span><?php echo e(!empty($data->city) ? $data->city : '-'); ?></span></h3>
    </div>
    <ul class="list-inline date_row mb-0">
        <li class="list-inline-item">
            <i class="fa fa-calendar"></i><span><?php echo e(startEndDateFormat($data->from_date_time,$data->to_date_time)); ?></span>
        </li>
        <li class="list-inline-item">
            <i class="fa fa-clock-o"></i><span><?php echo e(startEndTimeFormat($data->from_date_time,$data->to_date_time)); ?></span>
        </li>
    </ul>
    <div class="meeting_row">
        <label><i class="fa fa-home"></i> Meeting Place :</label>
        <span>
            <?php 
            $meetingPlace = $data->meeting_place;
            if($meetingPlace == "public"){
            echo "Public Place";
            }elseif($meetingPlace == "user_home"){
            echo "User Home";
            }else{
            echo "My Home";
            }
             ?>
        </span>
    </div>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>