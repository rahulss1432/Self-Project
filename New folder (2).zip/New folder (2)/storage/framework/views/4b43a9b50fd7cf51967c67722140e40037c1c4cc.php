<!-- variable for Current page Top Text -->
<?php 
$currentRoute = Request::route()->getName();
 ?>
<header id="header">
    <nav class="navbar navbar-light justify-content-between bg-transparent">
        <h3 class="page-title">
            <a href="javascript:void(0);" onclick="openSideMenu();" class="toggle-icon">
                <i class="ti-menu-alt"></i>
            </a>
            <?php if($currentRoute == 'manage-dashboard'): ?>
            Dashboard
            <?php elseif($currentRoute == 'manage-user'): ?>
            Manage Mentee
            <?php elseif($currentRoute == 'manage-category'): ?>
            Manage Category List
            <?php elseif($currentRoute == 'manage-booking'): ?>
            Manage Booking
            <?php elseif($currentRoute == 'get-service'): ?>
            Manage Service
            <?php elseif($currentRoute == 'notifications'): ?>
            Notifications
            <?php elseif($currentRoute == 'change-password'): ?>
            Change Password
            <?php elseif($currentRoute == 'manage-payment'): ?>
            Manage Payment Report
            <?php elseif($currentRoute == 'manage-commission'): ?>
            Manage Commission
            <?php elseif($currentRoute == 'manage-review-post'): ?>
            Reviews & Posts
            <?php elseif($currentRoute == 'manage-chat'): ?>
            All Chats
            <?php elseif($currentRoute == 'messages'): ?>
            Message
            <?php elseif($currentRoute == 'faq' || $currentRoute == 'cms'): ?>
            Manage Cms
            <?php elseif($currentRoute == 'manage-contractor'): ?>
            Manage Mentors
            <?php elseif($currentRoute == 'pending-contractor'): ?>
            Pending Mentors
            <?php elseif($currentRoute == 'manage-complaint'): ?>
            Manage Complaints
            <?php endif; ?>
            <?php  $id = \Illuminate\Support\Facades\Auth::guard('admin')->user()->id;  ?>
        </h3>
        <ul class="nav">
            <li class="dropdown notification ">
                <a href="javascript:void(0);" class="dropdown-toggle" onclick="readNotification()" id="dropdownMenuButton01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="ti-bell"></i>
                    <span class="notificationCount"></span>
                </a>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton01">
                    <div class="head">
                        <h3 class="font-hy mb-0">Notifications</h3>
                    </div>
                    <div class="noti_body" id="notificationList">

                    </div>
                    <?php if(getNotificationCount($id)>0): ?>
                    <div class="noti_footer text-center">
                        <a onclick="readNotification()" href="<?php echo e(url('admin/notifications')); ?>" class="d-block">View All</a>
                    </div>
                    <?php endif; ?>
                </div>
            </li> 
            <li class="dropdown nav-item mr-0 user-dropdwon">
                <a class="bg-transparent dropdown-toggle" href="javascript:void(0);" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="ti-user"></i>
                </a>
                <div class="dropdown-menu border-0" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="<?php echo e(url('admin/change-password')); ?>"><i class="ti-key"></i> Change Password</a>
                    <a class="dropdown-item" href="<?php echo e(url('admin/logout')); ?>" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                        <i class="ti-power-off"></i>Log Out
                    </a>
                    <form id="logout-form" action="<?php echo e(url('admin/logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </li>

        </ul>
    </nav>
</header>

<script>
    /*
     * Run function when page refresh
     *  loadNotificationList(): Notification list function call
     */
    $(document).ready(function () {
        loadNotificationList();
        setInterval(countNotificationList, 5000);
    });

    /*
     * Ajax Content Load
     * var url : Path notification list page
     */
    function loadNotificationList() {
        pageDivLoader('notificationList', 'show');
        var url = "<?php echo e(url('admin/load-notification-list')); ?>";
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.success) {
                    $("#notificationList").html(response.html);
                    $(".notifi-list").mCustomScrollbar();
                }
            }
        });
    }

    /*
     * function using for notification count show
     */
    function countNotificationList() {
        var url = "<?php echo e(url('admin/load-notification-count')); ?>";
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.data > 0) {
                    $('.notificationCount').addClass('count');
                    $('.notificationCount').html(response.data);
                } else {
                    $('.notificationCount').removeClass('count');
                    $('.notificationCount').html('');
                }
            },
            error: function (err) {
            }
        });
    }
    
    /*
     * function using for notification status (read) update
     */
    function readNotification() {
        var url = "<?php echo e(url('admin/update-notification-list')); ?>";
        $.ajax({
            url: url,
            type: 'POST',
            data: {_token: '<?php echo e(csrf_token()); ?>'},
            success: function (response) {
                loadNotificationList();
                countNotificationList();
            },
            error: function (err) {
            }
        });
    }
</script>