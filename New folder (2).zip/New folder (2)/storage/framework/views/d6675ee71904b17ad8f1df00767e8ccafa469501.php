<?php $__env->startSection('title', 'Manage Payment'); ?>
<?php $__env->startSection('content'); ?>
<!-- commission list page -->
<!-- Main Content Start -->
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Commission List</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive" id="getCommissionList">
                    <table class="table admin-table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>value</th>
                                <th class="w100 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $commisionPercent = getSetting('commision_percent');
                            $servicePercent = getSetting('service_percent');
                            $refundPercent = getSetting('refund_percent');
                             ?>
                            <?php if($commisionPercent > 0): ?>
                            <tr>
                                <td>Commission rate in Percentage %</td>
                                <td><?php echo e($commisionPercent); ?></td>
                                <td>
                                    <ul class="list-inline mb-0 text-center">
                                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                            <a href="javascript:void(0);" onclick="editCommissionModal('commision_percent','<?php echo e($commisionPercent); ?>');"><i class="ti-pencil-alt"></i></a>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php if($servicePercent > 0): ?>
                            <tr>
                                <td>Service fees rate in percentage (%) for Mentee</td>
                                <td><?php echo e($servicePercent); ?></td>
                                <td>
                                    <ul class="list-inline mb-0 text-center">
                                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                            <a href="javascript:void(0);" onclick="editCommissionModal('service_percent','<?php echo e($servicePercent); ?>');"><i class="ti-pencil-alt"></i></a>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php if($refundPercent > 0): ?>
                            <tr>
                                <td>Refund Commision rate in percentage (%) for Mentee </td>
                                <td><?php echo e($refundPercent); ?></td>
                                <td>
                                    <ul class="list-inline mb-0 text-center">
                                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                            <a href="javascript:void(0);" onclick="editCommissionModal('refund_percent','<?php echo e($refundPercent); ?>');"><i class="ti-pencil-alt"></i></a>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- Main Content End -->
<!-- Edit Commission modal -->
<div class="modal fade" id="editCommissionModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" id="editCommission" class="f-field" action="<?php echo e(url('admin/edit-commission')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="commission_key" id="commissionKey">
                    <div class="form-group">
                        <input type="text" class="form-control form-control-lg" id="commissionValue" name="commission"/>
                        <label class="control-label" id="labelName"></label>
                    </div>
                    <div class="form-group mb-0 text-right">
                        <button type="submit" id="btnCommission" onclick="editCommission()" class="btn btn-sm btn-primary ripple-effect">
                            Submit <i id="formLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none"></i>
                        </button>
                    </div>
                </form>
                <?php echo JsValidator::formRequest('App\Admin\Http\Requests\EditCommissionRequest','#editCommission'); ?>

            </div>
        </div>
    </div>
</div>
<script>
    //function using for show edit commission modal
    function editCommissionModal(key, value) {
        $('#commissionKey').val(key);
        $('#commissionValue').val(value);
        $('.form-control').on('focus blur', function (e) {
            $(this).parents('.form-group').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
        }).trigger('blur');
        if (key == "commision_percent"){
            $('#labelName').text('Commission rate');
            $('#exampleModalLabel').text('Edit Commission');
        } else if (key == "service_percent"){
            $('#labelName').text('Service Commission rate');
            $('#exampleModalLabel').text('Edit Service Commission');
        } else{
            $('#labelName').text('Refund Commission rate');
            $('#exampleModalLabel').text('Edit Refund Commission');
        }
        $("#editCommissionModal").modal("show");
    }
    //function using for edit commission data
    function editCommission() {
        var formData = $("#editCommission").serializeArray();
        if ($('#editCommission').valid()) {
            $('#btnCommission').prop('disabled', true);
            $('#formLoader').show();
            $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/edit-commission')); ?>",
                data: formData,
                success: function (response)
                {
                    if (response.success) {
                        $("#editCommissionModal").modal('hide');
                        toastrAlertMessage('success', response.message);
                        window.location.reload();
                        $('#formLoader').hide();
                        $('#btnCommission').prop('disabled', false);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnCommission').prop('disabled', false);
                        $('#formLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#formLoader').hide();
                    $('#btnCommission').prop('disabled', false);
                }
            });
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>