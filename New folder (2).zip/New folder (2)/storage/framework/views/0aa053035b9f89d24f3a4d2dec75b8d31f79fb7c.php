<?php $__env->startSection('title', 'Manage Payment'); ?>
<?php $__env->startSection('content'); ?>
<!-- payment report list page -->
<!-- Main Content Start -->
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Payment Report List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <!-- Search Filter Start -->
                <div class="filter_section collapse" id="searchFilter">
                    <form method="post" action="javascript:loadPaymentList()" id="search_form">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="dateicon">
                                        <input type="text" readonly name="from_date" id="fromDate" class="form-control form-control-lg datetimepicker-input" data-target="#fromDate" data-toggle="datetimepicker">
                                        <label class="control-label">From Date</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="dateicon">
                                        <input type="text" readonly name="to_date" id="toDate" class="form-control form-control-lg datetimepicker-input" data-target="#toDate" data-toggle="datetimepicker">
                                        <label class="control-label">To Date</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="booking_id" class="form-control form-control-lg">
                                    <label class="control-label">Booking ID</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <?php 
                                    $mentors = getUserByRole('mentor');
                                     ?>
                                    <select name="mentor_name" class="form-control form-control-lg selectpicker" data-size="5">
                                        <option value="">Select Mentor</option>
                                        <?php if(count($mentors) > 0): ?>
                                        <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($mentor->id); ?>"><?php echo e(getFullName($mentor->first_name,$mentor->last_name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <label class="control-label">Select Mentor</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <?php 
                                    $users = getUserByRole('user');
                                     ?>
                                    <select name="user_name" class="form-control form-control-lg selectpicker" data-size="5">
                                        <option value="">Select Mentee</option>
                                        <?php if(count($users) > 0): ?>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e(getFullName($user->first_name,$user->last_name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <label class="control-label">Select Mentee</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group d-inline-block mr-2">
                                    <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                </div>
                                <div class="form-group d-inline-block">
                                    <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="reset">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- Search Filter End -->
                <div class="table-responsive" id="getPaymentList">
                </div>
            </div>
        </div>
    </div>
</main>
<!-- Main Content End -->
<script>
    /*
      * Run function when page refresh
      *  loadPaymentList(): Payment report list function call
    */
    $(document).ready(function ()
    {
        $('#preloader').hide();
        loadPaymentList();
    });
    // reset form after search data
    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadPaymentList();
    }
    ;
    /*
      * Ajax Content Load
      * var url : Path payment report list page
    */
    function loadPaymentList()
    {
        pageDivLoader('show', 'getPaymentList');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('admin/load-payment-list')); ?>",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getPaymentList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>