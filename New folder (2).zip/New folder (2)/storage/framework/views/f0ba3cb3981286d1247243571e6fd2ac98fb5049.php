<!-- load user document list -->
<?php if(count($getDocument)>0): ?>
<?php $__currentLoopData = $getDocument; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
        <i class="fa fa-file-text-o"></i>
        <a href="<?php echo e(asset('public/uploads/portfolio/'.$data->link)); ?>" target="_blank" download><?php echo e(!empty($data->link) ? $data->link : '-'); ?></a>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>