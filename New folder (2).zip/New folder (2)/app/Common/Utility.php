<?php

namespace App\Common;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\models\ContestListings;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Exception;
//use App\Models\User;
use App\Http\Models\Notification;
use App\Http\Models\User;

class Utility {

    // To Push Notification In Android 
    public static function FcmPushNotification($registatoinIds, $message, $user_type, $notificationData, $userId, $to_id,$notifyType="") {
        error_reporting(0);
        if ($user_type == 'executive') {
            $API_ACCESS_KEY = \Config::get('constants.executive_api_access_key');
        } else {
            $API_ACCESS_KEY = \Config::get('constants.customer_api_access_key');
        }
        if (!isset($API_ACCESS_KEY)) {
            return false;
        }

        $url = 'https://fcm.googleapis.com/fcm/send';
        $fields = array(
            'registration_ids' => $registatoinIds,
            'data' => $notificationData,
        );
        $headers = array
            (
            'Authorization: key=' . $API_ACCESS_KEY,
            'Content-Type: application/json'
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
         
        $data = json_decode($result);
        
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }
        if($notifyType == ''){
            if($userId != 0){
            $notificationType = $notificationData['notification_type'];
                self::saveNotification($userId, $message, $notificationType, $notificationData, $to_id);
            }
            }
        if ($data->success == 1) {
            
            $data = [];
            
            curl_close($ch);
            return true;
        } else {
            curl_close($ch);
            return false;
        }
    }

    // Send Ios Notification Using P8 File
    public static function APNSPushDeviceNotification($deviceId, $message, $user_type, $data, $userId, $to_id,$notifyType="") {
        error_reporting(0);
        try {
            // your p8 file 
            $authKeyId = \Config::get('constants.auth_key');
            // Your Bundle ID
            $keyId = \Config::get('constants.key_id');
            //Your Team ID (see Developer Portal)
            $teamId = \Config::get('constants.team_id');
            // Your Key ID
            if($notifyType == "call"){
                $bundelId = ($user_type == 'executive') ? 'com.codiant.LinkedAssistSE.voip' : 'com.codiant.LinkedAssistCustomer.voip'; 
            } else {
                //$bundelId = ($user_type == 'executive') ? 'com.codiant.enterprise.linkedassistse' : 'com.codiant.enterprise.linkedassistcustomer';
                $bundelId = ($user_type == 'executive') ? 'com.codiant.LinkedAssistSE' : 'com.codiant.LinkedAssistCustomer';
            }
            
            $authKey = "$authKeyId";
            $arClaim = ['iss' => $teamId, 'iat' => time()];
            $arParam['p_key'] = file_get_contents(app_path() . $authKey);
            $arParam['header_jwt'] = \App\Http\Models\Jwt::encode($arClaim, $arParam['p_key'], $keyId, 'RS256');
            //body message Start
            $body = $message; 
            $arSendData = array();
            $arSendData['aps']['alert']['title'] = sprintf("Linked Assist"); // Notification title
            $arSendData['aps']['alert']['body'] = sprintf($body); // body text
            $arSendData['data']['notification_data'] = $data; // other parameters to send to the app
            $arSendData['data']['notification_type'] = $data['notification_type']; // other parameters to send to the app
            $sendDataJson = json_encode($arSendData);
            //body message End
            
            //End Point For sendion notification in different form
            //"For Production" --- https://api.push.apple.com/3/device 
            
            //For Developement
            //$endPoint = 'https://api.development.push.apple.com/3/device'; 
            
            $userDevice = \App\Http\Models\UserDevice::where(['user_id'=>$to_id])->first();
            if($userDevice->certification_type == "development"){
                $endPoint = 'https://api.development.push.apple.com/3/device'; 
            } else {
                $endPoint = 'https://api.push.apple.com/3/device'; 
            }
            
            
            $ar_request_head[] = sprintf("content-type: application/json");
            $ar_request_head[] = sprintf("authorization: bearer %s", $arParam['header_jwt']);
            $ar_request_head[] = sprintf("apns-topic: %s", $bundelId);
            // Device token
            $dev_token = $deviceId;
            $url = sprintf("%s/%s", $endPoint, $deviceId);
            $ch = curl_init($url);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $sendDataJson);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $ar_request_head);
            $response = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            $logFile = 'ios_log' . date("ymdhis") . '.txt';
            \Storage::disk('local')->put($logFile, print_r($deviceId, true));
            
            if (empty(curl_error($ch))) {
                // echo "empty curl error \n";
            }
            curl_close($ch);
            $notification_type = $data['notification_type'];
            if($notifyType == ''){
                if($userId != 0){
                    self::saveNotification($userId, $message, $notification_type, $data, $to_id);
                }
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    public static function sendNotification($userIds, $message, $type, $data = array(),$userId,$toId) {
        try {
            $users = User::whereIn('id', $userIds)->with('UserDevices')->get();
            if (!empty($users)) {
                foreach ($users as $user) {
                    if ($user->userDevices && $user->userDevices->device_type == 'ios') {
                        self::APNSPushDeviceNotification($user->userDevices->device_id, $message, $type, $user->role, $data,$userId,$toId);
                    }
                    if ($user->userDevices && $user->userDevices->device_type == 'android') {
                        return self::FcmPushNotification(array($user->userDevices->device_id), $message, $type, $user->role, $data,$userId,$toId);
                    }
                }
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            return false;
        }
    }

    // To Save Notification In DB
    public static function saveNotification($userId, $message, $notification_type, $data, $to_id = null) {
        $userDevice = \App\Http\Models\UserDevice::where(['user_id'=>$to_id])->first();
        $defaultTimeZone = \Config::get('constants.default_time_zone');
        if(!empty($userDevice)){
            if($userDevice->timezone == "India Standard Time"){
                $userDevice->timezone = "$defaultTimeZone";
            }
             date_default_timezone_set("$userDevice->timezone");
        } else {
            
            date_default_timezone_set("$defaultTimeZone");
        }
        $date = date('Y-m-d H:i:s');
        try {
            $notification = new Notification();
            $notification->from_id = $userId;
            $notification->to_id = $to_id;
            $notification->message = $message;
            $notification->type = $notification_type;
//            if(isset($data['ticketId']) && $data['ticketId'] !=""){
//                $notification->ticket_id = $data['ticketId'];
//            }
            $notification->notification_data = json_encode($data);
            $notification->read_status = 'unread';
            
            $notification->status = 'active';
            $notification->created_at = $date;
            $notification->updated_at = $date;
            if ($notification->save()) {
                return true;
            }
        } catch (Exception $e) {
            return false;
        }
    }

    public static function getCategoryLogo($logo) {
        $src = url('public/admin-manager-assets/images/default-user.jpg');
        $fileName = public_path() . '/uploads/category/' . $logo;
        if (filter_var($logo, FILTER_VALIDATE_URL) != FALSE) {
            $src = $logo;
        } elseif (!empty($logo) && file_exists($fileName)) {
            $src = url('public/uploads/category/' . $logo);
        }
        return $src;
    }

    public static function generateTicket() {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomStr = substr(str_shuffle($characters), 0, 10);
        return $randomStr;
    }
    
    public static function getTimeZone($data) {
        $defaultTimeZone = \Config::get('constants.default_time_zone');
        $fromDate = new \DateTime($data['date'], new \DateTimeZone($defaultTimeZone));
        if($data['timezone'] == ""){
             $fromDate->setTimeZone(new \DateTimeZone($data['timezone']));
        } else {
             $fromDate->setTimeZone(new \DateTimeZone("$defaultTimeZone"));
        }
        $today_date = $fromDate->format('Y-m-d H:i:s');
        return $today_date;
    }

}
