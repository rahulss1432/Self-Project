<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class sendMail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:sendMail';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send Mail';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        
        $mails = \App\Http\Models\MailQueue::get();
        if(!empty($mails)){
            foreach($mails as $mail){
                \Illuminate\Support\Facades\Mail::send('emails.cronMail', ['data' => $mail], function ($message) use ($mail) {
                    $message->from(\Config::get('constants.from_email'), 'Linked Assist')->subject('User Credentials');
                    $message->to($mail->email);
                });
                $mail->delete();
            }
        }
//        \App\Models\Notification::sendTodaysClassNotification();
        
    }
}
