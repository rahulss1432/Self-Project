<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Auth;

class User extends Authenticatable {

    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
    protected $appends = ['average_rating', 'country', 'state', 'city_name'];

    public function getAverageRatingAttribute() {
        $rating = getAverageRating($this->id);
        return $rating['average'];
    }

    public function getCountryAttribute() {
        $country = [];
        if (!empty($this->country_id)) {
            $country = Models\Country::where(['id' => $this->country_id])->first();
        }
        return $name = ($country) ? $country['name'] : '';
    }

    public function getStateAttribute() {
        $state = [];
        if (!empty($this->state_id)) {
            $state = Models\State::where(['id' => $this->state_id])->first();
        }
        return $name = ($state) ? $state['name'] : '';
    }

    public function getCityNameAttribute() {
        $city = [];
        if (!empty($this->city)) {
            $city = Models\City::where(['id' => $this->city])->first();
        }
        return $name = ($city) ? $city['name'] : '';
    }

    public function mentorServces() {
        return $this->hasMany('App\Models\MentorCategory', 'user_id', 'id');
    }

    public function mentorPrice() {
        return $this->hasOne('App\Models\Transaction', 'mentor_id', 'id');
    }

    public static function forgotEmail($post, $callFrom) {
        try {
            $user = User::where('email', $post['email'])->first();
            if (!empty($user)) {
                $reset_password_token = str_random(30);
                $data = [];
                if ($callFrom == 'admin') {
                    $data['request'] = 'admin_forgot_password';
                    $data['link'] = url('admin/reset-password/' . $reset_password_token);
                }
                $data['username'] = $user->first_name;
                $data['email'] = $user->email;
                $data['subject'] = 'Reset password link';
                $mail = sendMail($data);
                if (!empty($user)) {
                    $user->reset_token = $reset_password_token;
                    if ($user->save()) {
                        return Response::json(['success' => true, 'message' => \StaticMessage::$admin['send_mail']]);
                    }
                } else {
                    return Response::json(['success' => false, 'message' => \StaticMessage::$admin['something_wrong']]);
                }
                return redirect('/admin');
            }
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function ResetPassword($post) {
        try {
            $reset_token = $post['reset_token'];
            $password = $post['password'];
            $user = User::where('reset_token', $reset_token)->first();
            if (!empty($user)) {
                $user->reset_token = NULL;
                $user->password = bcrypt($password);
                $user->save();
                return Response::json(['success' => true, 'message' => \StaticMessage::$admin['password_reset']]);
            } else {
                return Response::json(['success' => false, 'message' => \StaticMessage::$admin['reset_token']]);
            }
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
