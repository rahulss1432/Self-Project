<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Auth;

class User extends Authenticatable {

    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public static function forgotEmail($post, $callFrom) {
        try {
            $user = User::where('email', $post['email'])->where('status', '!=', 'deleted')->first();
            if (!empty($user)) {
                $reset_password_token = str_random(30);
                $data = [];
                if ($callFrom == 'admin') {
                    $data['request'] = 'admin_forgot_password';
                    $data['link'] = url('admin/reset-password/' . $reset_password_token);
                }
                if ($callFrom == 'manager') {
                    $data['request'] = 'manager_forgot_password';
                    $data['link'] = url('manager/reset-password/' . $reset_password_token);
                }
                $data['username'] = $user->first_name;
                $data['email'] = $user->email;
                $data['subject'] = 'Reset password link';
                $mail = sendMail($data);
                if (!empty($user)) {
                    $user->reset_token = $reset_password_token;
                    if ($user->save()) {
                        return Response::json(['success' => true, 'message' => \Config::get('constants.forgot_mail_send')]);
                    }
                } else {
                    return Response::json(['success' => false, 'message' => \Config::get('constants.something_went_wrong')]);
                }
                return redirect('/login');
            }
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function ResetPassword($post) {
        try {
            $reset_token = $post['reset_token'];
            $password = $post['password'];
            $user = User::where('reset_token', $reset_token)->first();
            if (!empty($user)) {
                $user->reset_token = NULL;
                $user->password = bcrypt($password);
                $user->password_base64 = base64_encode($password);
                $user->save();
                return Response::json(['success' => true, 'message' => \Config::get('constants.password_reset_success')]);
            } else {
                return Response::json(['success' => false, 'message' => \Config::get('constants.reset_token_not_found')]);
            }
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * update password by users id
     */

    public static function updatePassword($post) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $model = User::where('id', $userId)->first();
            $model->password = bcrypt($post['password']);
            $model->password_base64 = base64_encode($post['password']);
            $model->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.password_updated')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function updateProfile($post) {
        try {
            $model = User::where('id', $post['id'])->first();
            $model->email = $post['email'];
            if (isset($post['password'])) {
                $model->password = bcrypt($post['password']);
            }
            $model->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.profile_updated')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
