<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Service extends Model {
    protected $table = 'services';
    
     protected $fillable = [
        'category_id', 'name', 'status'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];
}
