<?php

/**
 * model to add mentor availability  
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Availability extends Model {

    protected $table = 'availability';
    protected $fillable = [
        'user_id', 'state', 'city', 'address', 'latitude', 'longitude', 'from_date_time', 'to_date_time', 'meeting_place'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    /**
     * get user state by state id
     */
    public function userState() {
        return $this->belongsTo('App\Models\State', 'state', 'id');
    }

}
