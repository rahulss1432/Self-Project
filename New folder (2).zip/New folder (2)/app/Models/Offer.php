<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\User;

class Offer extends Model {

    protected $table = 'offers';
    protected $fillable = [
        'from_id', 'to_id', 'category_id', 'service_id', 'date_time', 'price'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    protected $appends = [ 'user_full_name', 'user_profile_image','category','service'];

    
    public function getUserProfileImageAttribute() {
        $user = User::where(['id' => $this->from_id])->first();
        if ($user) {
            return checkUserImage($user->profile_image, 'users');
        } else {
            return checkUserImage('', 'users');
        }
    }

    public function getUserFullNameAttribute() {
        $user = User::find($this->to_id);
        if ($user) {
            return $user->first_name . ' ' . $user->last_name;
        } else {
            return '';
        }
    }
    public function getCategoryAttribute() {
        $category = Category::find($this->category_id);
        if ($category) {
            return $category->category_name;
        } else {
            return '';
        }
    }
    
    public function getServiceAttribute() {
        $service = Service::find($this->service_id);
        if ($service) {
            return $service->name;
        } else {
            return '';
        }
    }


}
