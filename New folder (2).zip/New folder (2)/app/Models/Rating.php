<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Rating extends Model {

    protected $table = 'ratings';
    protected $fillable = [
        'from_id', 'to_id', 'rating', 'reviews', 'appointment_id'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    protected $appends = ['rating_date'];

    public function getRatingDateAttribute() {
        $dateFormat = getSetting('date_time_format');
        return date($dateFormat, strtotime($this->created_at));
    }

    /**
     * get rating from user by from_id
     */
    public function ratingFromUser() {
        return $this->belongsTo('App\User', 'from_id', 'id');
    }

    /**
     * get from user first_name,last_name,profile_image by from_id
     */
    public function fromUser() {
        return $this->belongsTo('App\User', 'from_id', 'id')->select('first_name', 'last_name', 'profile_image');
    }

    /**
     * get rating to user by to_id
     */
    public function ratingToUser() {
        return $this->belongsTo('App\User', 'to_id', 'id');
    }

    /**
     * get rating appointment(booking) id by appointment_id
     */
    public function ratingAppointment() {
        return $this->belongsTo('App\Models\Appointment', 'appointment_id', 'id');
    }

}
