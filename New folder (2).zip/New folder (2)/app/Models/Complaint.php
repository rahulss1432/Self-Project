<?php

/**
 * model for save complaint 
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Complaint extends Model {

    protected $table = 'complaints';
    protected $fillable = [
        'from_id', 'to_id', 'comments'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    /**
     * get from user by from_id
     */
    public function fromUser() {
        return $this->belongsTo('App\User', 'from_id', 'id');
    }

    /**
     * get to user by to_id
     */
    public function toUser() {
        return $this->belongsTo('App\User', 'to_id', 'id');
    }

}
