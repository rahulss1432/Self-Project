<?php
/**
 * model for to add cms 
 */
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cms extends Model {
    
}
