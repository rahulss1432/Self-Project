<?php

namespace App\Models;
/**
 * model to add card for payment  
 */
use Illuminate\Database\Eloquent\Model;

class Card extends Model {

    protected $table = 'cards';
	
    protected $fillable = [
        'user_id', 'card_id', 'card_type', 'card_number', 'exp_month', 'exp_year'
    ];
	
    protected $hidden = [
        'created_at', 'updated_at'
    ];

}
