<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\PostImage;

class Post extends Model {

    protected $table = 'posts';
    protected $fillable = [
        'from_id', 'to_id', 'appointment_id', 'comment'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    protected $appends = ['post_images', 'post_date', 'from_full_name', 'to_full_name', 'from_profile_image', 'from_user_rating'];

    public function getPostDateAttribute() {
        $dateFormat = getSetting('date_time_format');
        return date($dateFormat, strtotime($this->created_at));
    }

    /*
     * Get date format
     */

    public function getPostImagesAttribute() {
        return PostImage::select('image_title')->where('post_id', $this->id)->get();
    }

    public function getFromFullNameAttribute() {
        $user = \App\User::select('first_name', 'last_name')->where('id', $this->from_id)->first();
        return $user['first_name'] . ' ' . $user['last_name'];
    }

    public function getToFullNameAttribute() {
        $user = \App\User::select('first_name', 'last_name')->where('id', $this->to_id)->first();
        return $user['first_name'] . ' ' . $user['last_name'];
    }

    public function getFromProfileImageAttribute() {
        $user = \App\User::select('first_name', 'last_name')->where('id', $this->from_id)->first();
        return checkUserImage($user['profile_image'], 'users');
    }

    public function getFromUserRatingAttribute() {
        $rating = getAverageRating($this->from_id);
        return $rating['average'];
    }

    /**
     * get post from user by from_id
     */
    public function postFromUser() {
        return $this->belongsTo('App\User', 'from_id', 'id');
    }

    /**
     * get post to user by to_id
     */
    public function postToUser() {
        return $this->belongsTo('App\User', 'to_id', 'id');
    }

    /**
     * get post appointment(booking) id by appointment_id
     */
    public function postAppointment() {
        return $this->belongsTo('App\Models\Appointment', 'appointment_id', 'id');
    }

}
