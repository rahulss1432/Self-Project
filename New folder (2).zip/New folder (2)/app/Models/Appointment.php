<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\Models\MentorCategory;
use App\Models\Rating;
use App\User;
use App\Models\Availability;
use JWTAuth;

class Appointment extends Model {

    protected $table = 'appointments';
    protected $fillable = [
        'reference_id', 'from_id', 'to_id', 'category_id', 'service_id', 'date', 'meeting_place', 'meeting_address', 'level_of_knowledge', 'offer_id', 'description'
    ];
    protected $appends = ['appointment_date', 'user_full_name', 'category_name', 'service_name', 'price', 'rating', 'user_profile_image', 'address', 'meeting_place'];

//    protected $hidden = [
//        'created_at', 'updated_at'
//    ];

    /**
     * Get user profile image
     * $param null 
     * @return type url string
     */
    public function getUserProfileImageAttribute() {
        $user = User::where(['id' => $this->to_id])->first();
        if ($user) {
            return checkUserImage($user->profile_image, 'users');
        } else {
            return checkUserImage('', 'users');
        }
    }

    /**
     * Get appointment price
     * $param null 
     * @return int
     */
    public function getPriceAttribute() {
        $user = MentorCategory::where(['user_id' => $this->from_id, 'category_id' => $this->category_id, 'service_id' => $this->service_id])->first();
        if ($user) {
            return $user->amount;
        } else {
            return 0;
        }
    }

    /*
     * Get rating
     */

    /**
     * Get rating
     * $param null 
     * @return int
     */
    public function getRatingAttribute() {
        $token = app('request')->header('access_token');
        $user = JWTAuth::toUser($token); // to get login user detail
        $user_id = ($user->role == 'mentor') ? $this->from_id : $this->to_id;
        $rating = getAverageRating($user_id);
        ;
        if ($rating) {
            return $rating['average'];
        } else {
            return 0;
        }
    }

    /**
     * Get user full name
     * $param null
     * @return string
     */
    public function getUserFullNameAttribute() {
        $user = User::find($this->to_id);
        if ($user) {
            return $user->first_name . ' ' . $user->last_name;
        } else {
            return '';
        }
    }

    /**
     * Get category name
     * @return string
     */
    public function getCategoryNameAttribute() {
        $user = Category::find($this->category_id);
        if ($user) {
            return $user->category_name;
        } else {
            return '';
        }
    }

    /**
     * Get service name
     * @return string
     */
    public function getServiceNameAttribute() {
        $user = Service::find($this->service_id);
        if ($user) {
            return $user->name;
        } else {
            return '';
        }
    }

    /**
     * Get appointment date
     * @return string
     */
    public function getAppointmentDateAttribute() {
        $dateFormat = getSetting('date_format');
        if ($dateFormat) {
            return date($dateFormat, strtotime($this->date));
        } else {
            return '';
        }
    }

    /**
     * Get appointment address
     * @return type string
     */
    public function getAddressAttribute() {
        $date = "'" . $this->date . "'";
        $getData = Availability::where('user_id', $this->to_id)
                        ->whereRaw("DATE(from_date_time) <= $date and DATE(to_date_time) >= $date")->first();
        return ($getData) ? $getData['address'] : '';
    }

    /**
     * Get appointment place
     * @return type string
     */
    public function getMeetingPlaceAttribute() {
        $date = "'" . $this->date . "'";
        $getData = Availability::where('user_id', $this->to_id)
                        ->whereRaw("DATE(from_date_time) <= $date and DATE(to_date_time) >= $date")->first();
        return ($getData) ? $getData['meeting_place'] : '';
    }

    /**
     * get booking from user by from_id
     */
    public function bookingFromUser() {
        return $this->belongsTo('App\User', 'from_id', 'id');
    }

    /**
     * get booking to user by to_id
     */
    public function bookingToUser() {
        return $this->belongsTo('App\User', 'to_id', 'id');
    }

    /**
     * get user transaction amount by appointment_id
     */
    public function bookingAmount() {
        return $this->hasOne('App\Models\Transaction', 'appointment_id', 'id');
    }

    /**
     * get user service by service_id
     */
    public function bookingService() {
        return $this->belongsTo('App\Models\Service', 'service_id', 'id');
    }

}
