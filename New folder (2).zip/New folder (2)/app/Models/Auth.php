<?php

namespace App\Models;
/**
 * model to store source id of social media when login by social  
 */
use Illuminate\Database\Eloquent\Model;

class Auth extends Model
{
    protected $table = 'auth';
    
    protected $fillable = [
            'user_id', 'source_id'
    ];
}
