<?php

/**
 * model for chat connection between to user 
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Connection extends Model {

    /**
     * get connection to user by from_id
     */
    public function connectionFromUser() {
        return $this->belongsTo('App\User', 'from_id', 'id');
    }

    /**
     * get connection from user by to_id
     */
    public function connectionToUser() {
        return $this->belongsTo('App\User', 'to_id', 'id');
    }

}
