<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model {

    protected $table = 'transactions';
    protected $fillable = [
        'user_id', 'mentor_id', 'appointment_id', 'transaction_id', 'total_amount', 'commission', 'type', 'status'
    ];

    /**
     * get transaction mentor detail by mentor_id
     */
    public function transactionMentor() {
        return $this->belongsTo('App\User', 'mentor_id', 'id');
    }

    /**
     * get transaction mentee(user) detail by user_id
     */
    public function transactionUser() {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }

    /**
     * get transaction booking(appointment) by appointment_id
     */
    public function transactionBooking() {
        return $this->belongsTo('App\Models\Appointment', 'appointment_id', 'id');
    }

}
