<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MentorCategory extends Model {

    protected $table = 'mentor_categories';
    protected $fillable = [
        'user_id', 'category_id', 'service_id', 'exp_year', 'exp_month', 'amount', 'level_of_knowledge'
    ];

    /**
     * get mentor category by category_id
     */
    public function mentorCategory() {
        return $this->belongsTo('App\Models\Category', 'category_id', 'id');
    }

    /**
     * get category name by category_id
     */
    public function category() {
        return $this->belongsTo('App\Models\Category', 'category_id', 'id')->select('category_name');
    }

    /**
     * get mentor service by service_id
     */
    public function mentorService() {
        return $this->belongsTo('App\Models\Service', 'service_id', 'id');
    }

    /**
     * get service name by service_id
     */
    public function service() {
        return $this->belongsTo('App\Models\Service', 'service_id', 'id')->select('name');
    }

}
