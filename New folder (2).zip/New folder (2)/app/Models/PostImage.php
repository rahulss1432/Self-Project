<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PostImage extends Model {

    protected $table = 'post_images';
    protected $fillable = [
        'post_id', 'image_title'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    protected $appends = ['post_image_url'];

    /**
     * Get Post Image Url
     */
    public function getPostImageUrlAttribute() {
        return url('public/uploads/post/' . $this->image_title);
    }

}
