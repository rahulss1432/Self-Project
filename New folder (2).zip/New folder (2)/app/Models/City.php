<?php
/**
 * model for city list
 */
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class City extends Model {

    protected $table = 'cities';

}
