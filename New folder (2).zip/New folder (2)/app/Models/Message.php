<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Message extends Model {

    /**
     * get message from user by from_id
     */
    public function messageFromUser() {
        return $this->belongsTo('App\User', 'from_id', 'id');
    }

    /**
     * get message to user by to_id
     */
    public function messageToUser() {
        return $this->belongsTo('App\User', 'to_id', 'id');
    }

}
