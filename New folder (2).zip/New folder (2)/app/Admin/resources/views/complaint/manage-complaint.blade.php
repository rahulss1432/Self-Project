@extends('admin::include.app')
@section('title', 'Manage Complaint')
@section('content')
<!-- manage complaint list page -->
<!-- Main Content Start -->
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content" id="pageContent">
        <div class="card custom_card" id="card_height">
            <div class="card-header">
                <h4 class="page-title float-left">Complaints List</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive" id="getComplaintList">

                </div>
            </div>
        </div>
    </div>
</main>
<!-- Main Content End -->
<!-- Comments Details modal -->
<div class="modal fade" id="commentsModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="commentsModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md profile-modal" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Comment</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body" id="commentsView">

            </div>
        </div>
    </div>
</div>
<script>
    /*
     * Run function when page refresh
     *  loadComplaintList(): Complaint list function call
     */
    $(document).ready(function ()
    {
        $('#preloader').hide();
        loadComplaintList();
    });
    /*
     * Ajax Content Load
     * var url : Path complaint list page
     */
    function loadComplaintList()
    {
        pageDivLoader('show', 'getComplaintList');
        $.ajax({
            type: "GET",
            url: "{{ url('admin/load-complaints-list') }}",
            success: function (response)
            {
                if (response.success) {
                    $("#getComplaintList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection