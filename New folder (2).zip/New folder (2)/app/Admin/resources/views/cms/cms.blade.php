@extends('admin::include.app')
@section('title', 'Manage Cms')
@section('content')
<!-- manage cms list page -->
<!-- Main Content Start -->
<main class="main-content cms-page" id="mainContent">
    <div class="page-content" id="pageContent">
        <div class="card custom_card" id="card_height">
            <div class="card-header">
                <h4 class="page-title float-left">CMS Pages List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/add-cms')}}" class="nav-link"><i class="ti-plus"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class=" table-responsive" id="getCmsList">

                </div>
            </div>
        </div>
    </div>
</main>
<!-- Main Content End -->
<script>
    /*
     * Run function when page refresh
     *  loadCmsList(): Cms list function call
     */
    $(document).ready(function ()
    {
        $('#preloader').hide();
        loadCmsList();
    });
    /*
     * Ajax Content Load
     * var url : Path cms list page
     */
    function loadCmsList()
    {
        pageDivLoader('show', 'getCmsList');
        $.ajax({
            type: "GET",
            url: "{{ url('admin/load-cms-list') }}",
            success: function (response)
            {
                if (response.success) {
                    $("#getCmsList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection