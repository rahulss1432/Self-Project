@extends('admin::include.app')
@section('title', 'Manage Service')
@section('content')
<!-- manage service list page -->
<!-- Main Content Start -->
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Service List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Back">
                        <a href="{{url('admin/manage-category')}}" class="nav-link"><i class="ti-arrow-left"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Add Service">
                        <a href="javascript:void(0);" class="nav-link" onclick="showAddCategoryModal();" ><i class="ti-plus"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter" ></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <!-- Search Filter Start -->
                <div class="filter_section collapse" id="searchFilter">
                    <form method="post" action="javascript:loadServiceList()" id="search_form">
                        {{csrf_field()}}
                        <input type="hidden" name="category_id" id="categoryId">
                        <div class="row">
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control form-control-lg">
                                    <label class="control-label">Service Name</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <select name="status" class="form-control form-control-lg selectpicker">
                                        <option value="">Select Status</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                    <label class="control-label">Select Status</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group d-inline-block mr-2">
                                    <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                </div>
                                <div class="form-group d-inline-block">
                                    <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="reset">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- Search Filter End -->
                <div class="select_category">
                    <form>
                        <div class="form-group col-sm-6 col-md-4 pl-0">
                            @php
                            $getAllCategories = getAllCategories();
                            @endphp
                            @if(count($getAllCategories) > 0)
                            <select class="form-control form-control-lg selectpicker" onchange="changeService(this.value)" data-size="5">
                                @foreach($getAllCategories as $data)
                                <option value="{{$data->id}}" {{($data->id == $categoryId) ? 'selected' : ''}}>{{$data->category_name}}</option>
                                @endforeach
                            </select>
                            @endif
                            <label class="control-label">Select Category</label>
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="getServiceList">

                </div>
            </div>
        </div>
    </div>
</main>
<!-- Main Content End -->

<!-- add service modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Service</h5>
                <button type="button" class="close" data-dismiss="modal" onclick="resetAddForm();" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" id="addService" class="f-field" action="{{ url('admin/add-service') }}">
                    {{csrf_field()}}
                    <input type="hidden" name="category_id" id="category_id">
                    <div class="form-group">
                        <input type="text" name="service_name" class="form-control form-control-lg" />
                        <label class="control-label">Service Name</label>
                    </div>
                    <div class="form-group mb-0 text-right">
                        <button type="button" onclick="addService();" id="btnService" class="btn btn-sm btn-primary ripple-effect">
                            Submit <i id="serviceFormLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none"></i>
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Admin\Http\Requests\AddServiceRequest','#addService') !!}
            </div>
        </div>
    </div>
</div>
<script>
    // function using for on change service list by on change category 
    function changeService(id) {
        pageDivLoader('show', 'getServiceList');
        $('#category_id').val(id);
        $('#categoryId').val(id);
        var search_filter = $("#search_form").serializeArray();
        search_filter.push({'_token': '{{ csrf_token() }}'});
        $.ajax({
            type: "POST",
            url: "{{ url('admin/load-service-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getServiceList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    /*
     * Add service modal show
     */
    function showAddCategoryModal() {
        $("#addModal").modal('show');
    }
    // function using for reset add form after add data
    function resetAddForm() {
        window.location.reload();
    }
    // function using for add service
    function addService() {
        var formData = $("#addService").serializeArray();
        formData.push('_token', '{{ csrf_token() }}');
        if ($('#addService').valid()) {
            $('#btnService').prop('disabled', true);
            $('#serviceFormLoader').show();
            $.ajax({
                type: "POST",
                url: "{{ url('admin/add-service') }}",
                data: formData,
                success: function (response)
                {
                    if (response.success) {
                        $("#addModal").modal('hide');
                        toastrAlertMessage('success', response.message);
                        $('#addService')[0].reset();
                        $('#btnService').prop('disabled', false);
                        $('#serviceFormLoader').hide();
                        loadServiceList();
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnService').prop('disabled', false);
                        $('#serviceFormLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#serviceFormLoader').hide();
                    $('#btnService').prop('disabled', false);
                }
            });
        }
    }
    // onload service list
    $(document).ready(function ()
    {
        $('#preloader').hide();
        $('#category_id').val('{{$categoryId}}');
        $('#categoryId').val('{{$categoryId}}');
        loadServiceList('');
    });
    // function using for reset form after filter data
    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadServiceList('');
    }
    ;
    /*
     * Run function when page refresh
     *  loadServiceList(): Service list function call
     */
    function loadServiceList()
    {
        pageDivLoader('show', 'getServiceList');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push({'_token': '{{ csrf_token() }}'});
        $.ajax({
            type: "POST",
            url: "{{ url('admin/load-service-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getServiceList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    // function using for change service status
    function changeStatus(el, id) {
        if ($(el).is(':checked')) {
            var status = 'active';
        } else {
            var status = 'inactive';
        }
        bootbox.confirm({
            message: "Are you sure you want to change the status ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                }
            },
            callback: function (result) {
                if (result) {
                    update_status(id, status);
                } else {
                    if (status == 'active') {
                        $(el).prop('checked', false);
                    } else {
                        $(el).prop('checked', true);
                    }
                    return true;
                }
            }
        });
    }
    // function using for update service status
    function update_status(id, status) {
        $.ajax({
            url: "{{ url('admin/change-service-status') }}",
            type: 'GET',
            data: {id: id, status: status},
            cache: false,
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    toastrAlertMessage('success', data.message);
                    loadServiceList();
                } else {
                    toastrAlertMessage('error', data.message);
                }
            },
            error: function (err) {
                toastrAlertMessage('error', err);
            },
            complete: function () {
            }
        });
    }
</script>
@endsection