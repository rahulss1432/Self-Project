@extends('admin::include.app')
@section('title', 'Forget Password')
@section('content')
<!-- forget password page -->
<main class="login-page">
    <div class="login-wrap mx-auto">
        <div class="login-header d-flex align-items-center justify-content-center">
            <img src="{{ asset('public/images/logo.png') }}" alt="logo" class="img-fluid">
        </div>
        <div class="login-field">
            <form id="forgotPasswordForm" method="POST" action="{{url('admin/send-forgot-email')}}">
                {{ csrf_field() }}
                <div class="form-group">
                    <i class="ti-email icon"></i>
                        <input type="text" name="email" class="form-control form-control-lg" placeholder="Email" />
                </div>
                <div class="form-group pl-0 text-center">
                    <button type="submit" id="btnForgotPassword" class="btn btn-primary ripple-effect">SUBMIT 
                        <i id="forgotFormLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none;"></i></button>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Admin\Http\Requests\ForgotPasswordRequest','#forgotPasswordForm') !!}
        </div>
        <div class="login-footer">
            <a href="{{url('/admin')}}"> <span class="ti-arrow-left"></span> &nbsp; LOGIN</a>
        </div>
    </div>
</main>
<script type="text/javascript">
    // for forget password send mail by email id
    $(document).on('submit', '#forgotPasswordForm', function (e) {
        e.preventDefault();
        if ($('#forgotPasswordForm').valid()) {
            $('#btnForgotPassword').prop('disabled', true);
            $('#forgotFormLoader').show();
            $.ajax({
                url: "{{url('admin/send-forgot-email')}}",
                data: $('#forgotPasswordForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('/admin')}}";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnForgotPassword').prop('disabled', false);
                    }
                    $('#forgotFormLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#forgotFormLoader').hide();
                        $('#btnForgotPassword').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });
</script>
@endsection