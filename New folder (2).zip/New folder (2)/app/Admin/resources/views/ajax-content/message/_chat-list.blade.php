<!-- Chat (connection) listing Start -->
@if(count($connections) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>User Name</th>
            <th>Mentor Name</th>
            <th>Date and Time</th>
            <th>Status</th>
            <th class="w100 text-center">View / Delete Message</th>
        </tr>
    </thead>
    <tbody>
        @foreach($connections as $connection)
        <tr>
            <td>{{!empty($connection->connectionFromUser->first_name) ? getFullName($connection->connectionFromUser->first_name, $connection->connectionFromUser->last_name) : '-'}}</td>
            <td>{{!empty($connection->connectionToUser->first_name) ? getFullName($connection->connectionToUser->first_name, $connection->connectionToUser->last_name) : '-'}}</td>
            <td>{{!empty($connection->created_at) ? dateTimeFormat($connection->created_at) : '-'}}</td>
            <td>
                <div class="switch">
                    <label>
                        @if($connection->status == 'active')
                        <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this,'{{$connection->id}}')">
                        @else
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'{{$connection->id}}')">
                        @endif
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Message">
                        <a href="{{url('admin/messages/'.base64_encode($connection->id).'/'.base64_encode($connection->from_id))}}"><i class="ti-comment-alt"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="removeConnection('{{$connection->id}}');"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
<!-- Chat (connection) listing End -->
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $connections->links() }}
<script type="text/javascript">
    // user chat(connection) list pagination
    $('[data-toggle="tooltip"]').tooltip({trigger: "hover"});
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getChatList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getChatList').html(response.html);
            }
    });
    });
</script>