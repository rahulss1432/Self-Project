<!-- Flagged Terms Listing Start -->
<table class="table admin-table">
    <thead>
        <tr>
            <th>Flagged Terms Name</th>
            <th class="w100 text-center">Status</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>{{!empty(getSetting('flagged_number')) ? getSetting('flagged_number') : '-'}}</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        <tr>
            <td>{{!empty(getSetting('flagged_contact')) ? getSetting('flagged_contact') : '-'}}</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        <tr>
            <td>{{!empty(getSetting('flagged_skype')) ? getSetting('flagged_skype') : '-'}}</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        <tr>
            <td>{{!empty(getSetting('flagged_whatsapp')) ? getSetting('flagged_whatsapp') : '-'}}</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        <tr>
            <td>{{!empty(getSetting('flagged_email')) ? getSetting('flagged_email') : '-'}}</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
    </tbody>
</table>
<!-- Flagged Terms Listing End -->