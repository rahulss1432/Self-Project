<!--  Manage Payment Listing Start -->
@if(count($payments) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th>Transaction ID</th>
            <th>Mentor Name</th>
            <th>Mentee Name</th>
            <th>Job Date and Time</th>
            <th>Total Amount</th>
            <th>Commission</th>
            <th>Job Status </th>
            <th>Payment Method </th>
        </tr>
    </thead>
    <tbody>
        @foreach($payments as $payment)
        <tr>
            <td>{{!empty($payment->transactionBooking->reference_id) ? '#'.$payment->transactionBooking->reference_id : '-'}}</td>
            <td>{{!empty($payment->transaction_id) ? $payment->transaction_id : '-'}}</td>
            <td>{{!empty($payment->transactionMentor->first_name) ? getFullName($payment->transactionMentor->first_name, $payment->transactionMentor->last_name) : '-'}}</td>
            <td>{{!empty($payment->transactionUser->first_name) ? getFullName($payment->transactionUser->first_name, $payment->transactionUser->last_name) : '-'}}</td>
            <td>{{!empty($payment->created_at) ? dateTimeFormat($payment->created_at) : '-'}}</td>
            <td>{{!empty($payment->total_amount) ? '$ '.$payment->total_amount : '-'}}</td>
            <td>{{!empty($payment->commission) ? '$ '.$payment->commission : '-'}}</td>
            <td>{{!empty($payment->status) ? ucfirst($payment->status) : '-'}}</td>
            <td>{{!empty($payment->payment_method) ? ucfirst($payment->payment_method) : '-'}}</td>
        </tr>
        @endforeach
    </tbody>
</table>
<!--  Manage Payment Listing End -->
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $payments->links() }}
<script>
    // payment report list pagination
    $(".pagination li a").on('click', function (e) {
        pageDivLoader('show', 'getPaymentList');
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
                $('.pagination:first').remove();
                $('#getPaymentList').html(response.html);
            }
        });
    });
</script>