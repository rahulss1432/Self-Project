<!-- load user(mentee) profile detail -->
<div class="user_info">
    <div class="info_row">
        <div class="img_wrap">
            <img src="{{checkUserImage($user->profile_image, '')}}" alt="profile-img" class="img-fluid">
        </div>
        <div class="details">
            <ul class="right_side list-unstyled">
                <li>
                    <label>Name</label>
                    <span>{{!empty($user->first_name) ? getFullName($user->first_name,$user->last_name) : '-'}}</span>
                </li>
                <li>
                    <label>Email</label>
                    <span>{{!empty($user->email) ? $user->email : '-'}}</span>
                </li>
                <li>
                    <label>Phone Number</label>
                    <span>{{(!empty($user->phone_number)) ? $user->phone_number : '-'}}</span>
                </li>
                <li>
                    <label>DOB</label>
                    <span>{{ (!empty($user->date_of_birth)) ? showDateFormat($user->date_of_birth) : '-' }}</span>
                </li>
                <li>
                    <label>Status</label>
                    <span class="text-success">
                        {{($user->status == "active") ? 'Active' : 'Inactive'}}
                    </span>
                </li>
                <li>
                    <label>Date Added</label>
                    <span>{{!empty($user->created_at) ? showDateFormat($user->created_at) : '-'}}</span>
                </li>
            </ul>
        </div>
    </div>
    <div class="full-dtl">
        <ul class="right_side list-unstyled">
            <li>
                <label>User  Unique URL </label>
                <span class="d-block"><a href="javascript:void(0);" class="theme-color">https://www.mentolocator.com/Garrettbird</a></span>
            </li>
            <li>
                <label>Address</label>
                <span class="d-block">{{(!empty($user->address)) ? $user->address : '-'}}</span>
            </li>

            <li>
                <label>Bio</label>
                <span class="d-block">{{(!empty($user->bio)) ? $user->bio : '-'}}</span>
            </li>
        </ul>
    </div>
</div>