<!-- Manage User(mentee) Listing Start -->
@if(count($users) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Mentee Name</th>
            <th>Email</th>
            <th>Unique url</th>
            <th>Date Added</th>
            <th>Status</th>
            <th class="w120 text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($users as $user)
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView('{{$user->id}}')">{{!empty($user->first_name) ? getFullName($user->first_name,$user->last_name) : '-'}}</a>
            </td>
            <td>{{!empty($user->email) ? $user->email : '-'}}</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td>{{!empty($user->created_at) ? showDateFormat($user->created_at) : '-'}}</td>
            <td>
                <div class="switch">
                    <label>
                        @if($user->status == 'active')
                        <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this,'{{$user->id}}')">
                        @else
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'{{$user->id}}')">
                        @endif
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="removeUser('{{ $user->id }}');"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
<!-- Manage User(mentee) Listing End -->
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $users->links() }}
<script>
    // user(mentee) list pagination
    $('[data-toggle="tooltip"]').tooltip({trigger: "hover"});
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getUserList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getUserList').html(response.html);
            }
    });
    });
</script>  