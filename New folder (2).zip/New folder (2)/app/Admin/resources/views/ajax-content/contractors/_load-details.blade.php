<!-- load user profile detail -->
<div class="info_row">
    <div class="img_wrap">
        <img src="{{ checkUserImage($getContractors->profile_image, 'user') }}" alt="profile-img" class="img-fluid">
    </div>
    <div class="details">
        <ul class="right_side list-unstyled">
            <li>
                <label>Name</label>
                <span>{{!empty($getContractors->first_name) ? getFullName($getContractors->first_name, $getContractors->last_name) : '-'}}</span>
            </li>
            <li>
                <label>Email</label>
                <span>{{!empty($getContractors->email) ? $getContractors->email : '-'}}</span>
            </li>
            <li>
                <label>Phone Number</label>
                <span>{{ (!empty($getContractors->phone_number)) ? $getContractors->phone_number : '-' }}</span>
            </li>
            <li>
                <label>DOB</label>
                <span>{{ (!empty($getContractors->date_of_birth)) ? showDateFormat($getContractors->date_of_birth) : '-' }}</span>
            </li>
            <li>
                <label>Experience </label>
                <span>{{ (!empty(getExperienceByUserId($getContractors->id))) ? getExperienceByUserId($getContractors->id) : '-' }}</span>
            </li>
            <li>
                <label>Profile Status</label>
                <span class="text-success">{{ (!empty($getContractors->status)) ? ucfirst($getContractors->status) : '-' }}</span>
            </li>
        </ul>
    </div>
</div>
<div class="full-dtl">
    <ul class="right_side list-unstyled">
        <li>
            <label>Ratings</label>
            <span class="rating d-block">
                @php
                $ratings = getRatingsByUserId($getContractors->id);
                @endphp
                @if(count($ratings)>0)
                @foreach($ratings as $data)
                @for($i=1; $i<=$data->avgRating; $i++)
                <i class="fa fa-star" aria-hidden="true" data-rating="{{$data->avgRating}}"></i>
                @endfor
                @endforeach
                @else
                -
                @endif
            </span>
        </li>
        <li>
            <label>Registration Date</label>
            <span class="d-block">
                {{!empty($getContractors->created_at) ? showDateFormat($getContractors->created_at) : '-'}}
            </span>
        </li>
        <li>
            <label>Mentor Locator unique URL</label>
            <span class="d-block"><a href="javascript:void(0);" class="theme-color">https://www.mentolocator.com/Garrettbird</a></span>
        </li>
        <li>
            <label>Address</label>
            <span class="d-block">{{ (!empty($getContractors->address)) ? $getContractors->address : '-' }}</span>
        </li>
    </ul>
</div>