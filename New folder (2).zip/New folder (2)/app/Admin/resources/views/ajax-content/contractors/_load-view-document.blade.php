<!-- load user document list -->
@if(count($getDocument)>0)
@foreach($getDocument as $data)
<li>
        <i class="fa fa-file-text-o"></i>
        <a href="{{asset('public/uploads/portfolio/'.$data->link)}}" target="_blank" download>{{!empty($data->link) ? $data->link : '-'}}</a>
</li>
@endforeach
@else 
<div class="alert alert-danger"><center>No record found</center></div>
@endif