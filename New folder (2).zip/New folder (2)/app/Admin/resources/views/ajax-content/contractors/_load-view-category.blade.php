<!-- load user category list -->
@if(count($getCategory)>0)
@foreach($getCategory as $data)
<li>
        <i class="ti-layout-grid3"></i>{{!empty($data->mentorCategory->category_name) ? $data->mentorCategory->category_name : '-'}}
</li>
@endforeach
@else 
<div class="alert alert-danger"><center>No record found</center></div>
@endif