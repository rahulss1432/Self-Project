<!-- Manage Mentor(Contractor) Listing Start -->
@if(!empty($getContractors) && count($getContractors) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Unique url</th>
            <th class="w-150 text-center">View Documents</th>
            <th class="w-150 text-center">View Categories </th>
            <th>View Availability </th>
            <th>Status</th>
            <th class="w100 text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($getContractors as $contractor)
        <tr>
            <td><a href="javascript:void(0);" class="theme-color" onclick="loadContractorDetails('{{ $contractor->id }}')">{{!empty($contractor->first_name) ? getFullName($contractor->first_name, $contractor->last_name) : '-'}}</a></td>
            <td>{{!empty($contractor->email) ? $contractor->email : '-'}}</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td class="text-center"><a href="javascript:void(0);" onclick="loadViewDocument('{{ $contractor->id }}');" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="javascript:void(0);" onclick="loadViewCategory('{{ $contractor->id }}');" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="loadCheckAvailability('{{ $contractor->id }}');">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        @if($contractor->status == 'active')
                        <input type="checkbox" name="activeInactive"  checked onchange="changeStatus(this,'{{ $contractor->id}}')">
                        @else
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'{{ $contractor->id}}')">
                        @endif
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="removeContractor('{{ $contractor->id }}');"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
<!-- Manage Mentor(Contractor) Listing End -->
@else 
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $getContractors->links() }}
<script>
    // manage mentor(contractor) list pagination
    $('[data-toggle="tooltip"]').tooltip({ trigger: "hover" });
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getcontractorslist');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getcontractorslist').html(response.html);
            }
    });
    });
</script>