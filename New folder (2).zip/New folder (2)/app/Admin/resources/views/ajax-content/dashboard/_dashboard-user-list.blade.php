<!-- load dashboard count and mentor list after filter city -->
<div class="card-header">
    <h4 class="page-title float-left">Mentor List</h4>
</div>
<div class="card-body">
    <div class="table-responsive">
        @if(count($getAllUsers) > 0)
        <table class="table admin-table">
            <thead>
                <tr>
                    <th>Booking Id</th>
                    <th>Mentor Name</th>
                    <th>Price</th>
                    <th>Rating</th>
                    <th>Url</th>
                </tr>
            </thead>
            <tbody>
                @foreach($getAllUsers as $users)
                <tr>
                    <td>{{!empty($users->mentorPrice->transactionBooking->reference_id) ? '#'.$users->mentorPrice->transactionBooking->reference_id : '-'}}</td>
                    <td>{{!empty($users->first_name) ? getFullName($users->first_name,$users->last_name) : '-'}}</td>
                    <td>{{!empty($users->mentorPrice->total_amount) ? $users->mentorPrice->total_amount : '-'}}</td>
                    <td>
                        <span class="rating d-block">
                            @php
                            $ratings = getRatingsByUserId($users->id);
                            @endphp
                            @if(count($ratings)>0)
                            @foreach($ratings as $data)
                            @for($i=1; $i<=$data->avgRating; $i++)
                            <i class="fa fa-star" aria-hidden="true" data-rating="{{$data->avgRating}}"></i>
                            @endfor
                            @endforeach
                            @else
                            -
                            @endif
                        </span>
                    </td>
                    <td>
                        <a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @else
        <div class="alert alert-danger"><center>No record found</center></div>
        @endif
        {{ $getAllUsers->links() }}
    </div>
</div>
<script>
    // top 20 mentor list pagination on dashobard after filter city
    $('[data-toggle="tooltip"]').tooltip({trigger: "hover"});
    $(".pagination li a").on('click', function (e) {
        pageDivLoader('show', 'getUserList');
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        var countryId = $('#countryId').val();
        var stateId = $('#stateId').val();
        var city = $('#cityId').val();
        $.ajax({
            type: 'GET',
            url: pageLink,
            async: false,
            data: {country_id: countryId, state_id: stateId, city_id: city},
            success: function (response) {
                $('.pagination:first').remove();
                $('#getUserList').html(response.html);
            }
        });
    });
</script>