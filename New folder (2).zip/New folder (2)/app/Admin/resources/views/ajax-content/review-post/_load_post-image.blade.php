<!-- load post image list on popup -->
@if(count($postImages) > 0)
<div class="row">
    @foreach($postImages as $postImage)
    <div class="col-4">
        <div class="img_wrap">
            <img src="{{checkPostImage($postImage->image_title,'posts')}}" class="img-fluid" alt="media-img">  
        </div>
    </div>
    @endforeach
</div>
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif