<!-- Reviews Start -->
@if(count($reviews) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th>Mentor Name</th>
            <th>Mentee Name</th>
            <th>Rating counts</th>
            <th>Date and time </th>
            <th class="w350">Comment</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($reviews as $review)
        <tr>
            <td>{{!empty($review->ratingAppointment->reference_id) ? '#'.$review->ratingAppointment->reference_id : '-'}}</td>
            <td>{{!empty($review->ratingFromUser->first_name) ? getFullName($review->ratingFromUser->first_name, $review->ratingFromUser->last_name) : '-'}}</td>
            <td>{{!empty($review->ratingToUser->first_name) ? getFullName($review->ratingToUser->first_name, $review->ratingToUser->last_name) : '-'}}</td>
            <td>
                <div class="rating d-inline-block">
                    @for($i=1; $i<=$review->rating; $i++)
                    <i class="fa fa-star" aria-hidden="true" data-rating="{{$review->rating}}"></i>
                    @endfor
                </div>
                <span>({{$review->rating}}.0)</span>
            </td>
            <td>{{!empty($review->created_at) ? dateTimeFormat($review->created_at) : '-'}}</td>
            <td>
                {{getLimitText(30,$review->reviews)}}
                @php
                $stringLength = strlen($review->reviews);
                if($stringLength > 30){
                @endphp
                <a href="javascript:void(0);" onclick="commentsView('{{$review->id}}', 'review')" class="theme-color">Read More</a>
                @php
                }
                @endphp
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="removePostReview('{{ $review->id }}', 'review');"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
<!-- Reviews End -->
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $reviews->links() }}
<script>
    // review list pagination
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getReviewsList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getReviewsList').html(response.html);
            }
    });
    });
</script>