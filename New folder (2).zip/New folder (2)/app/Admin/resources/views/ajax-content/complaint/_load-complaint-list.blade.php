<!-- Manage Complaint Listing Start -->
@if(count($complaints) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>From user</th>
            <th>To User</th>
            <th>Comments</th>
        </tr>
    </thead>
    <tbody>
        @foreach($complaints as $complaint)
        <tr>
            <td>{{!empty($complaint->fromUser->first_name) ? getFullName($complaint->fromUser->first_name, $complaint->fromUser->last_name) : '-'}}</td>
            <td>{{!empty($complaint->toUser->first_name) ? getFullName($complaint->toUser->first_name, $complaint->toUser->last_name) : '-'}}</td>
            <td>{{getLimitText(100,$complaint->comments)}}
                @php
                $stringLength = strlen($complaint->comments);
                if($stringLength > 100){
                @endphp
                <a href="javascript:void(0);" onclick="commentsView('{{$complaint->id}}')" class="theme-color">Read More</a>
                @php
                }
                @endphp
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
<!-- Manage Complaint Listing End -->
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $complaints->links() }}
<script>
    // complaint list pagination
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getComplaintList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'GET',
            url: pageLink,
            async: false,
            success: function (response) {
            $('.pagination:first').remove();
            $('#getComplaintList').html(response.html);
            }
    });
    });
    function commentsView(id)
    {
    $("#commentsModal").modal('show');
    pageDivLoader('show', 'commentsView');
    $.ajax({
    type: "GET",
            url: "{{ url('admin/load-complaints-view') }}/" + id,
            success: function (response)
            {
            if (response.success) {
            $("#commentsView").html(response.complaints);
            } else {
            toastrAlertMessage('error', response.message);
            }
            },
            error: function (err) {
            var obj = jQuery.parseJSON(err.responseText);
            for (var x in obj) {
            toastrAlertMessage('error', obj[x]);
            }
            }
    });
    }
</script>