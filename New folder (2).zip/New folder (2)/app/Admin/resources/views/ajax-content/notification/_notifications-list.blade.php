<!-- Manage Notification Listing Start -->
@if(count($notification) > 0)
@foreach($notification as $notify)
<div class="notification-box">
    <span class="custom-control-description">
        <!--<p>Editorial Collections</p>-->
        <p>{{!empty($notify->fromUser->first_name) ? getFullName($notify->fromUser->first_name, $notify->fromUser->last_name) : '-'}}</p>
        <span>{{!empty($notify->message) ? $notify->message : '-'}}</span>
    </span>
</div>
<!-- Manage Notification Listing End -->
@endforeach
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $notification->links() }}
<script type="text/javascript">
    // user notification list pagination
    $(".pagination li a").on('click', function (e) {
        pageDivLoader('show', 'getNotificationList');
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'GET',
            url: pageLink,
            async: false,
            success: function (response) {
                $('.pagination:first').remove();
                $('#getNotificationList').html(response.html);
            }
        });
    });
</script>