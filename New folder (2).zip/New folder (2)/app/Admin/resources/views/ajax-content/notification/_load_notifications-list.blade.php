<!-- load notification list on header popup -->
@if(count($notification)>0)
<ul class="list-unstyled mCustomScrollbar notifi-list" data-mcs-theme="minimal-dark">
    @foreach($notification as $notify)
    <li>
        <a href="javascript:void(0);">
            {{!empty($notify->message) ? $notify->message : '-'}}
        </a>
    </li>
    @endforeach
</ul>
@else
<div class="alert alert-danger text-center">No record found.</div>
@endif