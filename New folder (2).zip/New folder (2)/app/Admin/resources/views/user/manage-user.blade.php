@extends('admin::include.app')
@section('title', 'Manage User')
@section('content')
<!-- manage user(mentee) list page -->
<!-- Main Content Start -->
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Mentee List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <!-- Search Filter Start -->
                <div class="filter_section collapse" id="searchFilter">
                    <form method="post" action="javascript:loadUserList()" id="search_form">
                        {{csrf_field()}}
                        <div class="row">
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control form-control-lg">
                                    <label class="control-label">Mentee Name</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="email" class="form-control form-control-lg">
                                    <label class="control-label">Email</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <select name="status" class="form-control form-control-lg selectpicker">
                                        <option value="">Select Status</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                    <label class="control-label">Select Status</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group d-inline-block mr-2">
                                    <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                </div>
                                <div class="form-group d-inline-block">
                                    <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="submit">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- Search Filter End -->
                <div class="table-responsive" id="getUserList">

                </div>
            </div>
        </div>
    </div>
</main>
<!-- Main Content End -->
<!-- profile modal -->
<div class="modal fade" id="customerProfile" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="customerprofile" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md profile-modal" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Mentee Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body" id="viewUserProfile">

            </div>
        </div>
    </div>
</div>
<script>
    // function using for show user profile detail
    function profileView(id) {
        $.ajax({
            type: "GET",
            url: "{{ url('admin/load-user-profile') }}",
            data: {id: id},
            success: function (response)
            {
                if (response.success) {
                    $("#customerProfile").modal('show');
                    $("#viewUserProfile").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    /*
     * Run function when page refresh
     *  loadUserList(): user(mentee) list function call
     */
    $(document).ready(function ()
    {
        $('#preloader').hide();
        loadUserList();
    });
    // reset form after search data
    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadUserList();
    }
    ;
    /*
     * Ajax Content Load
     * var url : Path sub user(mentee) list page
     */
    function loadUserList()
    {
        pageDivLoader('show', 'getUserList');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "POST",
            url: "{{ url('admin/load-user-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getUserList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    // function using for change status
    function changeStatus(el, id) {
        if ($(el).is(':checked')) {
            var status = 'active';
        } else {
            var status = 'inactive';
        }
        bootbox.confirm({
            message: "Are you sure you want to change the status ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                }
            },
            callback: function (result) {
                if (result) {
                    update_status(id, status);
                } else {
                    if (status == 'active') {
                        $(el).prop('checked', false);
                    } else {
                        $(el).prop('checked', true);
                    }
                    return true;
                }
            }
        });
    }
    // function using for update status
    function update_status(id, status) {
        $.ajax({
            url: "{{ url('admin/change-user-status') }}",
            type: 'GET',
            data: {id: id, status: status},
            cache: false,
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    toastrAlertMessage('success', data.message);
                    loadUserList();
                } else {
                    toastrAlertMessage('error', data.message);
                }
            },
            error: function (err) {
                toastrAlertMessage('error', err);
            },
            complete: function () {
            }
        });
    }

    /** @returns delete user(mentee) */
    function removeUser(id) {
        bootbox.confirm({
            message: "Are you sure you want to delete this ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                },
            },
            callback: function (result) {
                if (result) {
                    var url = "{{ url('admin/remove-user') }}/ " + id;
                    $.ajax({
                        type: "GET",
                        url: url,
                        success: function (response) {
                            if (response.success) {
                                toastrAlertMessage('success', response.message);
                                loadUserList();
                            } else {
                                toastrAlertMessage('error', response.message);
                            }
                        }
                    });
                }
            }
        });
    }
</script>
@endsection