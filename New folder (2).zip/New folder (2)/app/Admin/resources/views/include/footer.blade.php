<!-- Page overlay for mobile -->
<div class="page-overlay" onclick="closeSidemenu();"></div>
<script type="text/javascript">
    /*
     * Selectpicker on selected value add class
     * if : When value select by user then add class selected in bootstrap-select 
     * else : When value not select by user then remove class selected in bootstrap-select 
     */
    $('.selectpicker').change(function () {
        if ($(this).val()) {
            $(this).closest('.bootstrap-select').addClass('selected');
        } else {
            $(this).closest('.bootstrap-select').removeClass('selected');
        }
    });

    //Date Picker on change events
    $("#fromDate").on("change.datetimepicker", function (e) {
        $('#toDate').datetimepicker('minDate', e.date);
    });
    $("#toDate").on("change.datetimepicker", function (e) {
        $('#fromDate').datetimepicker('maxDate', e.date);
    });
    /*
     *  Date Picker select date 
     *  focusOnShow :      Focus in input box
     *  format     :       Only date format show
     *  ignoreReadonly  :   Readonly input
     */
    $('#fromDate, #toDate').datetimepicker({
        useCurrent: false,
        focusOnShow: false,
        format: 'L',
        ignoreReadonly: true,
        maxDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
        disabledDates: [
            new Date(Date.now() + 1 * 24 * 60 * 60 * 1000)],

    });
    //Date Picker
    $("#fromDate1").on("change.datetimepicker", function (e) {
        $('#toDate1').datetimepicker('minDate', e.date);
    });
    $("#toDate1").on("change.datetimepicker", function (e) {
        $('#fromDate1').datetimepicker('maxDate', e.date);
    });
    /*
     *  Date Picker select date 
     *  focusOnShow :      Focus in input box
     *  format     :       Only date format show
     *  ignoreReadonly  :   Readonly input
     */
    $('#fromDate1, #toDate1').datetimepicker({
        useCurrent: false,
        focusOnShow: false,
        format: 'L',
        ignoreReadonly: true,
        maxDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
        disabledDates: [
            new Date(Date.now() + 1 * 24 * 60 * 60 * 1000)],

    });
    /*
     * When user focus on input then add class focused in this parent form-group
     */
    $('.form-control').on('focus blur', function (e) {
        $(this).parents('.form-group').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
    }).trigger('blur');

    /*
     * When user click toggle icon then side Open Close For Mobile, Tab and Ipad Devices     
     */
    function openSideMenu() {
        $("body").toggleClass("menu-toggle");
    }
    /*
     * When user click overlay then side menu close for Mobile, Tab and Ipad Devices
     */
    function closeSidemenu() {
        $("body").removeClass("menu-toggle");
    }
    // for side menu end

    /*
     * Button Ripple Effect 
     * <span class="ripple-overlay"> Append span tag on click button
     * rippleDiv.remove()  Remove span tag at 0.8ms
     */
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });

    /*
     * Page loader 
     * rotate = 1  Rotate preloader variable
     * fadeOut('slow')  Show and hide  preloader on page
     */
    var rotate = 1;
    function hide_preloader() {
        rotate = 0;
        $("#preloader").fadeOut('slow');
    }

    /*
     * Textarea dynamic height
     * el.style.cssText : Textarea input auto adjust height and padding.
     */
    $("textarea").keydown(function () {
        var el = this;
        el.style.cssText = 'height:auto; padding:0';
        el.style.cssText = 'height:' + el.scrollHeight + 'px';
    });

    /*
     * Tooltp trigger hover
     */
    if ($(window).width() > 767) {
        $('[data-toggle="tooltip"]').tooltip({trigger: "hover"});
    }

    /*
     * toastr message show 
     * if type = success for success message
     * and else = error for error message
     */
    function toastrAlertMessage(type, msg) {
        if (type == 'success') {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.success(msg, {timeOut: 2000});
        } else {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.error(msg, {timeOut: 2000});
        }
    }
    // page loader common function
    function pageDivLoader(type, id) {
        if (type === 'show') {
            $('#' + id).html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-2x"></i></div>');
        } else {
            $('#' + id).html('');
        }
    }
</script>