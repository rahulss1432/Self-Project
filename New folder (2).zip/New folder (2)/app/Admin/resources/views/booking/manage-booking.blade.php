@extends('admin::include.app')
@section('title', 'Manage Booking')
@section('content')
<!-- booking list page -->
<!-- Main Content Start -->
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content" id="pageContent">
        <div class="card custom_card" id="card_height">
            <div class="card-header">
                <h4 class="page-title float-left">Booking List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <!-- Search Filter Start -->
                <div class="filter_section collapse" id="searchFilter">
                    <form method="post" action="javascript:loadBookingList()" id="search_form">
                        {{csrf_field()}}
                        <div class="row">
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="dateicon">
                                        <input type="text" readonly name="from_date" id="fromDate" class="form-control form-control-lg datetimepicker-input" data-target="#fromDate" data-toggle="datetimepicker">
                                        <label class="control-label">From Date</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="dateicon">
                                        <input type="text" readonly name="to_date" id="toDate" class="form-control form-control-lg datetimepicker-input" data-target="#toDate" data-toggle="datetimepicker">
                                        <label class="control-label">To Date</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    @php
                                    $categories = getAllCategories();
                                    @endphp
                                    <select name="category" class="form-control form-control-lg selectpicker" data-size="5">
                                        @if(count($categories) > 0)
                                        <option value="">Select Category</option>
                                        @foreach($categories as $category)
                                        <option value="{{$category->id}}">{{$category->category_name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                    <label class="control-label">Select Category</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="booking_id" class="form-control form-control-lg">
                                    <label class="control-label">Booking ID</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <select name="status" class="form-control form-control-lg selectpicker" data-size="5">
                                        <option value="">Select Status</option>
                                        <option value="pending">Pending</option>
                                        <option value="active">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                    <label class="control-label">Select Status</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="mentor_name" class="form-control form-control-lg">
                                    <label class="control-label">Mentor Name</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="user_name" class="form-control form-control-lg">
                                    <label class="control-label">User Name</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group d-inline-block mr-2">
                                    <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                </div>
                                <div class="form-group d-inline-block">
                                    <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="reset">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- Search Filter End -->
                <div class="table-responsive" id="getBookingList">
                </div>
            </div>
        </div>
    </div>
</main>
<!-- Main Content End -->
<script>
    /*
     * Run function when page refresh
     *  load_booking_list(): Booking list function call
     */
    $(document).ready(function ()
    {
        $('#preloader').hide();
        loadBookingList();
    });

    // reset form after search data
    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadBookingList();
    }

    /*
     * Ajax Content Load
     * var url : Path booking list page
     */
    function loadBookingList()
    {
        pageDivLoader('show', 'getBookingList'); // show loader before get listing
        var search_filter = $("#search_form").serializeArray(); // get form data
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "POST", // send post type data
            url: "{{ url('admin/load-booking-list') }}", // send data on this url
            data: search_filter, // send form data on server side
            success: function (response)
            {
                if (response.success) {
                    $("#getBookingList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection