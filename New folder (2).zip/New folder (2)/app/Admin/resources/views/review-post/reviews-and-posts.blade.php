@extends('admin::include.app')
@section('title', 'Review & Post')
@section('content')
<!-- review and post list page -->
<!-- Main Content Start -->
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content pt-1">
        <!-- tab -->
        <ul class="nav nav-tabs admin-tabs border-0" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="reviews-tab" onclick="showReviewsTab();" data-toggle="tab" href="#Reviews" role="tab" aria-controls="home" aria-selected="true">Reviews</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="post-tab" onclick="showPostsTab();" data-toggle="tab" href="#Posts" role="tab" aria-controls="profile" aria-selected="false">Posts</a>
            </li>
        </ul>
        <!-- tab content -->
        <div class="tab-content" id="myTabContent">
            <!-- review tab start -->
            <div class="tab-pane fade show active" id="Reviews" role="tabpanel" aria-labelledby="reviews-tab">
                <div class="card custom_card">
                    <div class="card-header">
                        <h4 class="page-title float-left">Reviews List</h4>
                        <ul class="list-inline mb-0 text-right">
                            <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                                <a href="#searchFilter" data-toggle="collapse"  class="nav-link"><i class="ti-filter"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <!-- Search Filter Start -->
                        <div class="filter_section collapse" id="searchFilter">
                            <form method="post" action="javascript:getReviewslist()" id="search_form">
                                {{csrf_field()}}
                                <div class="row">
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <div class="dateicon">
                                                <input type="text" readonly name="from_date" id="fromDate" class="form-control form-control-lg datetimepicker-input" data-target="#fromDate" data-toggle="datetimepicker" placeholder="">
                                                <label class="control-label">From</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <div class="dateicon">
                                                <input type="text" readonly name="to_date" id="toDate" class="form-control form-control-lg datetimepicker-input" data-target="#toDate" data-toggle="datetimepicker" placeholder="">
                                                <label class="control-label">To</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-4 col-sm-6">
                                        <div class="form-group d-inline-block mr-2">
                                            <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                        </div>
                                        <div class="form-group d-inline-block">
                                            <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="reset">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Search Filter End -->
                        <div class="table-responsive" id="getReviewsList">
                        </div>
                    </div>
                </div>
            </div>
            <!-- posts tab start -->
            <div class="tab-pane fade" id="Posts" role="tabpanel" aria-labelledby="post-tab">
                <div class="card custom_card">
                    <div class="card-header">
                        <h4 class="page-title float-left">Posts List</h4>
                        <ul class="list-inline mb-0 text-right">
                            <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                                <a href="#searchFilter01" data-toggle="collapse"  class="nav-link"><i class="ti-filter"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <!-- Search Filter Start -->
                        <div class="filter_section collapse" id="searchFilter01">
                            <form method="post" action="javascript:getPostslist()" id="search_form1">
                                {{csrf_field()}}
                                <div class="row">
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <div class="dateicon">
                                                <input type="text" name="from_date" readonly id="fromDate1" class="form-control form-control-lg datetimepicker-input" data-target="#fromDate1" data-toggle="datetimepicker" placeholder="">
                                                <label class="control-label">From</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <div class="dateicon">
                                                <input type="text" name="to_date" readonly id="toDate1" class="form-control form-control-lg datetimepicker-input" data-target="#toDate1" data-toggle="datetimepicker" placeholder="">
                                                <label class="control-label">To</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-4 col-sm-6">
                                        <div class="form-group d-inline-block mr-2">
                                            <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                        </div>
                                        <div class="form-group d-inline-block">
                                            <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="reset">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Search Filter End -->
                        <div class="table-responsive" id="getPostsList">
                        </div>
                    </div>
                </div>
            </div>
            <!-- tab end -->
        </div>
    </div>
</main>
<!-- Main Content End -->
<!-- upload media file modal Start -->
<div class="modal fade" id="mediaModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered media-modal" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Media File</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body pb-1 postImages" id="viewPostImages">

            </div>
        </div>
    </div>
</div>
<!-- Comments Details modal-->
<div class="modal fade" id="commentsModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="commentsModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md profile-modal" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Comment</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body" id="commentsView">

            </div>
        </div>
    </div>
</div>
<script>
    /*
     * Run function when page refresh
     *  getReviewslist(): reviews list function call
     */
    $(document).ready(function ()
    {
        $('#preloader').hide();
        getReviewslist();
    });
    // reset form after search data
    function resetForm() {
        $('#search_form')[0].reset();
        $('#search_form1')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        getReviewslist();
        getPostslist();
    }
    /*
     * Ajax Content Load
     * var url : Path reviews list page
     */
    function getReviewslist()
    {
        pageDivLoader('show', 'getReviewsList');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "POST",
            url: "{{ url('admin/load-reviews-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getReviewsList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    /*
     * Ajax Content Load
     * var url : Path post list page
     */
    function getPostslist()
    {
        pageDivLoader('show', 'getPostsList');
        var search_filter = $("#search_form1").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "POST",
            url: "{{ url('admin/load-posts-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getPostsList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    // function using for get post media image
    function viewMedia(id) {
        $("#mediaModal").modal('show');
        pageDivLoader('show', 'viewPostImages');
        $.ajax({
            type: "GET",
            url: "{{ url('admin/load-postimage-view') }}/" + id,
            success: function (response)
            {
                if (response.success) {
                    $("#viewPostImages").html(response.html);
                    $(".postImages").mCustomScrollbar();
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    /*
     * Run function when click reviews tab
     *  getReviewslist(): Reviews list function call
     */
    function showReviewsTab() {
        getReviewslist();
    }
    /*
     * Run function when click post tab
     *  getPostslist(): Post list function call
     */
    function showPostsTab() {
        getPostslist();
    }
    // function using for show comments on review and post
    function commentsView(id, type)
    {
        $("#commentsModal").modal('show');
        pageDivLoader('show', 'commentsView');
        $.ajax({
            type: "GET",
            url: "{{ url('admin/load-postcomment-view') }}/" + id + '/' + type,
            success: function (response)
            {
                if (response.success) {
                    $("#commentsView").html(response.postComment);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    /** @returns delete reviews and post */
    function removePostReview(id, type) {
        bootbox.confirm({
            message: "Are you sure you want to delete this ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                },
            },
            callback: function (result) {
                if (result) {
                    var url = "{{ url('admin/remove-post-review') }}/ " + id + '/' + type;
                    $.ajax({
                        type: "GET",
                        url: url,
                        success: function (response) {
                            if (response.success) {
                                toastrAlertMessage('success', response.message);
                                if (type == "review") {
                                    getReviewslist();
                                } else {
                                    getPostslist();
                                }
                            } else {
                                toastrAlertMessage('error', response.message);
                            }
                        }
                    });
                }
            }
        });
    }
</script>
@endsection