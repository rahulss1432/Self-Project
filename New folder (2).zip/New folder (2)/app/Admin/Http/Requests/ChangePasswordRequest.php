<?php

/**
 * Description: this request is used only for admin change password fields validation related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ChangePasswordRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {

        return [
            'current_password' => 'required|min:6|max:20|current_password_match',
            'new_password' => 'required|min:6|max:20',
            'confirm_password' => 'required|max:20|same:new_password'
        ];
    }

    /*
     * Function for show validation messages.
     */

    public function messages() {
        return [
            'current_password.current_password_match' => 'Current password does not match'
        ];
    }

}
