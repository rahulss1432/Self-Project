<?php

/**
 * Description: this controller is used only for admin related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\AdminRepository;
use DB;
use Session;
use App\User;
use Illuminate\Support\Facades\Auth;
use App\Admin\Http\Requests\ResetPasswordRequest;
use App\Admin\Http\Requests\ForgotPasswordRequest;

class AdminController extends Controller {

    /**
     * Class Construct.
     * @param $admin
     */
    public function __construct(AdminRepository $admin) {
        $this->adminRepository = $admin;
    }

    /**
     * function using for show forget password page
     * @param null
     * @return html
     */
    public function forgotPassword() {
        return $this->adminRepository->forgotPassword();
    }

    /**
     * send forget password email with email validation.
     * @param type $request
     * @return json
     */
    public function sendForgotEmail(ForgotPasswordRequest $request) {
        return User::forgotEmail($request->all(), 'admin');
    }

    /**
     * function using for show reset password page.
     * @param type $token
     * @return html
     */
    public function resetPassword($token) {
        return $this->adminRepository->resetPassword($token);
    }

    /**
     * change reset password.
     * @param type $request
     * @return json
     */
    public function Reset(ResetPasswordRequest $request) {
        return User::ResetPassword($request->all()); // for reset password method
    }

}
