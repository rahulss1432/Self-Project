<?php

/**
 * Description: this controller is used only for notification related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\AdminRepository;

class NotificationController extends Controller {

    /**
     * Class Construct.
     * @param $adminRepository
     */
    public function __construct(AdminRepository $adminRepository) {
        $this->adminRepository = $adminRepository;
    }

    /**
     * get load notification list in admin side.
     * @param null
     * @return json
     */
    function manageNotificationList() {
        $notification = $this->adminRepository->getNotificationList(); // for get all admin notifications
        $html = View::make('admin::ajax-content.notification._load_notifications-list', ['notification' => $notification])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * update load notification list in admin side.
     * @param null
     * @return json
     */
    function updateReadNotification() {
        $userId = \Illuminate\Support\Facades\Auth::guard('admin')->user()->id; // for get admin login id
        return updateNotificationList($userId); // for update unread notifications
    }

    /**
     * get load notification list count in admin side.
     * @param null
     * @return json
     */
    public function loadNotificationCount() {
        $userId = \Illuminate\Support\Facades\Auth::guard('admin')->user()->id; // for get admin login id
        $notificationCount = loadNotificationCount($userId); // for get unread notifications counts
        return Response::json(['success' => true, 'data' => $notificationCount]);
    }

    /**
     * show notification page in admin side.
     * @param null
     * @return html
     */
    public function notifications() {
        return view('admin::notification.notifications');
    }

    /**
     * get notification list in admin side.
     * @param null
     * @return json
     */
    function notificationList() {
        $notification = $this->adminRepository->getAllNotificationList(); // for get all notifications
        $html = View::make('admin::ajax-content.notification._notifications-list', ['notification' => $notification])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

}
