<?php

/**
 * Description: this controller is used only for message related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\MessageRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class MessageController extends Controller {

    /**
     * Class Construct.
     * @param $message
     */
    public function __construct(MessageRepository $message) {
        $this->message = $message;
    }

    /**
     * Display User Connections Page.
     * @param null
     * @return html
     */
    public function index() {
        return view('admin::message.all-chats');
    }

    /**
     * Display a listing of the user connections.
     * @param type $request
     * @return json
     */
    public function getAllConnections(Request $request) {
        $connections = $this->message->getAllConnections($request); // for get all user connections with filter
        $html = View::make('admin::ajax-content.message._chat-list', ['connections' => $connections])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Change user connection status.
     * @param type $request
     * @return json
     */
    public function changeConnectionStatus(Request $request) {
        return $this->message->changeConnectionStatus($request); // for changes connections status
    }

    /**
     * Delete user connection.
     * @param type $id
     * @return json
     */
    public function deleteConnection($id) {
        return $this->message->deleteConnection($id); // for delete connections
    }

    /**
     * Display a listing of the flagged terms.
     * @param type $request
     * @return json
     */
    public function getAllFlaggedTerms(Request $request) {
        $html = View::make('admin::ajax-content.message._flagged-terms')->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display a user messages.
     * @param type $id and $fromId
     * @return array of object
     */
    public function userMessages($id, $fromId) {
        $messages = $this->message->getAllMessages(base64_decode($id)); // for get all messages according to connections
        return view('admin::message.messages', ['messages' => $messages, 'fromId' => base64_decode($fromId)]);
    }

}
