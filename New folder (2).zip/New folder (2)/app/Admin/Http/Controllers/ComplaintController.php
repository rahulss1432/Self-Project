<?php

/**
 * Description: this controller is used only for complaint related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\ComplaintRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\AddFaqRequest;

class ComplaintController extends Controller {

    /**
     * Class Construct.
     * @param $complaint
     */
    public function __construct(ComplaintRepository $complaint) {
        $this->complaint = $complaint;
    }

    /**
     * Display a complaint page.
     * @param null
     * @return html
     */
    public function index() {
        return view('admin::complaint.manage-complaint');
    }

    /**
     * Display a listing of the complaint.
     * @param type $request
     * @return json
     */
    public function getAllComplaints(Request $request) {
        $complaints = $this->complaint->getAllComplaints($request); // for get all complaints
        $html = View::make('admin::ajax-content.complaint._load-complaint-list', ['complaints' => $complaints])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display a view of the complaint.
     * @param type $id
     * @return json
     */
    public function getComplaintsView($id) {
        $complaints = $this->complaint->getComplaintsView($id); // for get complaints comment view
        $data = $complaints->comments;
        return Response::json(['success' => true, 'complaints' => $data]);
    }

}
