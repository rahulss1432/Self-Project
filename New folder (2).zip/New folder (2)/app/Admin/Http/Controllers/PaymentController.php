<?php

/**
 * Description: this controller is used only for payment report related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\PaymentRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\EditCommissionRequest;

class PaymentController extends Controller {

    /**
     * Class Construct.
     * @param $payment
     */
    public function __construct(PaymentRepository $payment) {
        $this->payment = $payment;
    }

    /**
     * Display payments report page.
     * @param null
     * @return html
     */
    public function index() {
        return view('admin::payment-report.manage-payment-report');
    }

    /**
     * Display a listing of the payments report.
     * @param type $request
     * @return json
     */
    public function getAllPayments(Request $request) {
        $payments = $this->payment->getAllPayments($request); // for get all payment report data with filter
        $html = View::make('admin::ajax-content.payment-report._manage-payment-report-list', ['payments' => $payments])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display commission page.
     * @param null
     * @return html
     */
    public function commission() {
        return view('admin::commission.manage-commission');
    }

    /**
     * edit commission.
     * @param type $request
     * @return json
     */
    public function editCmmission(EditCommissionRequest $request) {
        return $this->payment->editCmmission($request); // for edit commission method
    }

}
