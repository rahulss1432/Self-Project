<?php

/**
 * Description: this controller is used only for Cms and Faq related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\CmsRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\EditCmsRequest;
use App\Admin\Http\Requests\AddFaqRequest;

class CmsController extends Controller {

    /**
     * Class Construct.
     * @param $cms
     */
    public function __construct(CmsRepository $cms) {
        $this->cms = $cms;
    }

    /**
     * Display a faq page.
     * @param null
     * @return html
     */
    public function showFaq() {
        return view('admin::cms.faq');
    }

    /**
     * Display a listing of the faqs.
     * @param type $request
     * @return json
     */
    public function getAllFaqs(Request $request) {
        $faqs = $this->cms->getAllFaqs($request); // for get all faqs
        $html = View::make('admin::ajax-content.cms._faq-list', ['faqs' => $faqs])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display a add faq page.
     * @param null
     * @return html
     */
    public function showAddFaqs() {
        return view('admin::cms.add-faq');
    }

    /**
     * add faqs.
     * @param type $request
     * @return json
     */
    public function addFaqs(AddFaqRequest $request) {
        return $this->cms->addFaqs($request); // for add faqs
    }

    /**
     * Delete Faqs.
     * @param type $id
     * @return json
     */
    public function deleteFaqs($id) {
        return $this->cms->deleteFaqs($id); // for delete faqs
    }

    /**
     * Show Edit Faqs.
     * @param type $id
     * @return json
     */
    public function showEditFaqs($id) {
        $editFaqs = $this->cms->showEditFaqs(base64_decode($id)); // for show edit faqs by faq id
        return view('admin::cms.edit-faq', ['editFaqs' => $editFaqs]);
    }

    /**
     * edit faqs.
     * @param type $request
     * @return json
     */
    public function editFaqs(AddFaqRequest $request) {
        return $this->cms->addFaqs($request); // for edit faqs method
    }

    /**
     * Display a cms page.
     * @param null
     * @return html
     */
    public function showCms() {
        return view('admin::cms.cms');
    }

    /**
     * Display a listing of the cms.
     * @param type $request
     * @return json
     */
    public function getAllCms(Request $request) {
        $cms = $this->cms->getAllCms($request); // for get all cms
        $html = View::make('admin::ajax-content.cms._cms-list', ['cms' => $cms])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Show Add Cms Page.
     * @param null
     * @return html
     */
    public function showAddCms() {
        return view('admin::cms.add-cms');
    }

    /**
     * add cms method.
     * @param type $request
     * @return json
     */
    public function addCms(EditCmsRequest $request) {
        return $this->cms->editCms($request); // for add cms
    }

    /**
     * Show Edit Cms Page.
     * @param type $id
     * @return array of object
     */
    public function showEditCms($id) {
        $editCms = $this->cms->showEditCms(base64_decode($id)); // for show edit cms by cms id
        return view('admin::cms.edit-cms', ['editCms' => $editCms]);
    }

    /**
     * edit cms method.
     * @param type $request
     * @return array of object
     */
    public function editCms(EditCmsRequest $request) {
        return $this->cms->editCms($request); // for edit cms method
    }

}
