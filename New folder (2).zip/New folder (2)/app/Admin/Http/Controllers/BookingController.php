<?php

/**
 * Description: this controller is used only for booking related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\BookingRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class BookingController extends Controller {

    /**
     * Class Construct.
     * @param $booking
     */
    public function __construct(BookingRepository $booking) {
        $this->booking = $booking;
    }

    /**
     * show booking list page.
     * @param null
     * @return html
     */
    public function index() {
        return view('admin::booking.manage-booking');
    }

    /**
     * Display a listing of the booking.
     * @param type $request
     * @return json
     */
    public function getAllBookings(Request $request) {
        $bookings = $this->booking->getAllBookings($request); // for get all bookings with filter
        $html = View::make('admin::ajax-content.booking._load-booking-list', ['bookings' => $bookings])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * get booking invoice.
     * @param type $id
     * @return array of object
     */
    public function getInvoice($id) {
        $invoice = $this->booking->getInvoice(base64_decode($id)); // for get booking invoice data nu booking id
        return view('admin::booking.invoice', ['invoice' => $invoice]);
    }

}
