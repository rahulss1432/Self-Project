<?php

/**
 * Description: this controller is used only for Category and Service related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\CategoryRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\AddCategoryRequest;
use App\Admin\Http\Requests\AddServiceRequest;

class CategoryController extends Controller {

    /**
     * Class Construct.
     * @param $category
     */
    public function __construct(CategoryRepository $category) {
        $this->category = $category;
    }

    /**
     * show category list page.
     * @param null
     * @return html
     */
    public function index() {
        return view('admin::category.manage-category');
    }

    /**
     * Display a listing of the categories.
     * @param type $request
     * @return json
     */
    public function getAllCategories(Request $request) {
        $categories = $this->category->getAllCategories($request); // for get all categories with filter
        $html = View::make('admin::ajax-content.category._load-category-list', ['categories' => $categories])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Change categories status.
     * @param type $request
     * @return json
     */
    public function changeCategoryStatus(Request $request) {
        return $this->category->changeCategoryStatus($request); // for changes category status
    }

    /**
     * get all service by category id.
     * @param type $id
     * @return array of object
     */
    public function getServiceById($id) {
        $categoryId = base64_decode($id);
        return view('admin::category.manage-service', ['categoryId' => $categoryId]);
    }

    /**
     * Display a listing of the service.
     * @param type $request
     * @return json
     */
    public function getAllService(Request $request) {
        $services = $this->category->getServiceById($request); // for get all services with filter
        $html = View::make('admin::ajax-content.category._load-service', ['services' => $services])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Change service status.
     * @param type $request
     * @return json
     */
    public function changeServiceStatus(Request $request) {
        return $this->category->changeServiceStatus($request); // for changes service status
    }

    /**
     * add category method.
     * @param type $request
     * @return json
     */
    public function addCategory(AddCategoryRequest $request) {
        return $this->category->addCategory($request); // for add category
    }

    /**
     * add service method.
     * @param type $request
     * @return json
     */
    public function addService(AddServiceRequest $request) {
        return $this->category->addService($request); // for add service
    }

}
