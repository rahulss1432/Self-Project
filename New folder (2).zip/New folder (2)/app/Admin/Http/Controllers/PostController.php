<?php

/**
 * Description: this controller is used only for review and post related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\PostRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class PostController extends Controller {

    /**
     * Class Construct.
     * @param $post
     */
    public function __construct(PostRepository $post) {
        $this->post = $post;
    }

    /**
     * Display review and post page.
     * @param null
     * @return html
     */
    public function index() {
        return view('admin::review-post.reviews-and-posts');
    }

    /**
     * Display a listing of the reviews.
     * @param type $request
     * @return json
     */
    public function getAllReviews(Request $request) {
        $reviews = $this->post->getAllReviews($request); // for get all review with filter
        $html = View::make('admin::ajax-content.review-post._reviews-list', ['reviews' => $reviews])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display a listing of the posts.
     * @param type $request
     * @return json
     */
    public function getAllPosts(Request $request) {
        $posts = $this->post->getAllPosts($request); // for get all post with filter
        $html = View::make('admin::ajax-content.review-post._post-list', ['posts' => $posts])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display a view of the post and review comments.
     * @param type $id and $type (post and review)
     * @return json
     */
    public function getPostCommentView($id, $type) {
        $postComment = $this->post->getPostCommentView($id, $type); // for get post and review comments view 
        $data = "";
        if ($type == "post") {
            $data = $postComment->comment; // for get post comments
        } else {
            $data = $postComment->reviews; // for get review comments
        }
        return Response::json(['success' => true, 'postComment' => $data]);
    }

    /**
     * Display a view of the post images.
     * @param type $id
     * @return json
     */
    public function getPostImageView($id) {
        $postImages = $this->post->getPostImageView($id); // for get post images by post id
        $html = View::make('admin::ajax-content.review-post._load_post-image', ['postImages' => $postImages])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * delete review and post.
     * @param type $id and $type (post and review)
     * @return json
     */
    public function removePostReview($id, $type) {
        return $this->post->removePostReview($id, $type); // for delete post and review by id and type
    }

}
