<?php

/**
 * Description: this controller is used only for user(mentee) related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\UserRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\ChangePasswordRequest;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller {

    /**
     * Class Construct.
     * @param $user
     */
    public function __construct(UserRepository $user) {
        $this->user = $user;
    }

    /**
     * Display users page.
     * @param null
     * @return html
     */
    public function index() {
        return view('admin::user.manage-user');
    }

    /**
     * Display a listing of the users.
     * @param type $request
     * @return json
     */
    public function getAllUsers(Request $request) {
        $users = $this->user->getAllUsers($request); // for get all users(mentee) with filter
        $html = View::make('admin::ajax-content.user._load-user-list', ['users' => $users])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Change user status.
     * @param type $request
     * @return json
     */
    public function changeUserStatus(Request $request) {
        return $this->user->changeUserStatus($request);  // for change users(mentee) status
    }

    /**
     * load user profile detail.
     * @param type $request
     * @return json
     */
    public function loadUserProfile(Request $request) {
        $user = $this->user->loadUserProfile($request); // for get users(mentee) profile detail
        $html = View::make('admin::ajax-content.user._load-user-profile', ['user' => $user])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display change password page.
     * @param null
     * @return array of object
     */
    public function changePassword() {
        $userId = Auth::guard('admin')->user()->id; // for get admin login id
        return View('admin::change-password', ['id' => $userId]);
    }

    /**
     * Update user password.
     * @param type $request
     * @return json
     */
    public function updatePassword(ChangePasswordRequest $request) {
        return $this->user->updatePassword($request); // for update admin password
    }

    /**
     * function using for delete mentee user.
     * @param type $id
     * @return json
     */
    public function removeUser($id) {
        return $this->user->removeUser($id); // for delete users(mentee) by id
    }

}
