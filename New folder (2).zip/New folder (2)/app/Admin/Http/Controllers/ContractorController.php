<?php

/**
 * Description: this controller is used only for contractor(mentor) related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Repositories\Admin\UserRepository;

class ContractorController extends Controller {

    /**
     * Class Construct.
     * @param $user
     */
    public function __construct(UserRepository $user) {
        $this->user = $user;
    }

    /**
     * Display manage contractors page.
     * @param null
     * @return html
     */
    public function index() {
        return view('admin::manage-contractor.index');
    }

    /**
     * load contractor user listing.
     * @param type $request
     * @return json
     */
    public function loadContractorsList(Request $request) {
        $getContractors = $this->user->getContractorList($request->all()); // for get all users(mentor) with filter
        $html = View::make('admin::ajax-content.contractors._contractors-list', ['getContractors' => $getContractors])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * load contractor user detail.
     * @param type $id
     * @return json
     */
    public function loadContractorDetails($id) {
        $getContractors = $this->user->getUserById($id); // for get users(mentor) detail by id
        $html = View::make('admin::ajax-content.contractors._load-details', ['getContractors' => $getContractors])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * update contractor status.
     * @param type $request
     * @return json
     */
    public function updateContractorStatus(Request $request) {
        return $this->user->updateContractorStatus($request); // for change users(mentor) status
    }

    /**
     * function using for delete contractor user.
     * @param type $id
     * @return json
     */
    public function removeContractor($id) {
        return $this->user->removeContractor($id); // for remove users(mentor) data by id
    }

    /**
     * Display pending contractors page.
     * @param null
     * @return html
     */
    public function pendingContractors() {
        return view('admin::manage-contractor.pending-contractors');
    }

    /**
     * load pending contractor listing.
     * @param type $request
     * @return json
     */
    public function loadPendingContractorsList(Request $request) {
        $getContractors = $this->user->getPendingContractorList($request->all()); // for all pending users(mentor) with filter
        $html = View::make('admin::ajax-content.contractors._pending-contractors', ['getContractors' => $getContractors])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * load contractor check availability listing.
     * @param type $id
     * @return json
     */
    public function loadCheckAvailability($id) {
        $getAvailability = $this->user->getAvailability($id); // for get all availabilities by user id
        $html = View::make('admin::ajax-content.contractors._load-check-availability', ['getAvailability' => $getAvailability])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * load contractor view document listing.
     * @param type $id
     * @return json
     */
    public function loadViewDocument($id) {
        $getDocument = $this->user->getDocument($id); // for get all documents by user id
        $html = View::make('admin::ajax-content.contractors._load-view-document', ['getDocument' => $getDocument])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * load contractor view category listing.
     * @param type $id
     * @return json
     */
    public function loadViewCategory($id) {
        $getCategory = $this->user->getCategory($id); // for get all categories by user id
        $html = View::make('admin::ajax-content.contractors._load-view-category', ['getCategory' => $getCategory])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

}
