<?php

/**
 * Description: this controller is used only for dashboard related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\DashboardRepository;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;

class DashboardController extends Controller {

    /**
     * Class Construct.
     * @param $dashboard
     */
    public function __construct(DashboardRepository $dashboard) {
        $this->dashboard = $dashboard;
    }

    /**
     * Display dashboard page.
     * @param null
     * @return html
     */
    public function index() {
        return $this->dashboard->index();
    }

    /**
     * get country.
     * @param type $request
     * @return json
     */
    public function getAllCountry(Request $request) {
        return getAllCountry($request->all()); // for get all countries
    }

    /**
     * get state by country id.
     * @param type $request
     * @return json
     */
    public function getStatesByCountryId(Request $request) {
        return getStatesByCountryId($request->all()); // for get all states by country id
    }

    /**
     * get city by state id.
     * @param type $request
     * @return json
     */
    public function getCitiesByStateId(Request $request) {
        return getCitiesByStateId($request->all()); // for get all cities by state id
    }

    /**
     * Display a dashboard counts.
     * @param type $request
     * @return json
     */
    public function getAllCounts(Request $request) {
        $totalMentors = $this->dashboard->getDetailBytype($request, 'mentor'); // for get mentor count
        $totalMentees = $this->dashboard->getDetailBytype($request, 'user'); // for get mentee count
        $totalEarn = $this->dashboard->getDetailBytype($request, 'total_earned'); // for get mentor total earning count
        $totalCategory = $this->dashboard->getDetailBytype($request, 'category'); // for get mentor total category count
        $mentors = "";
        $mentees = "";
        $earns = "";
        $categories = "";
        // for mentor counts check
        if ($totalMentors <= 9) {
            $mentors = '0' . $totalMentors; // for less then 9 to add 0 before count
        } else {
            $mentors = $totalMentors; // for greater then 9 to remove 0 before count
        }
        // for mentee counts check
        if ($totalMentees <= 9) {
            $mentees = '0' . $totalMentees; // for less then 9 to add 0 before count
        } else {
            $mentees = $totalMentees; // for greater then 9 to remove 0 before count
        }
        // for mentor and mentee counts equal check
        $totalInpressions = $totalMentors + $totalMentees;
        if ($totalInpressions <= 9) {
            $inpressions = '0' . $totalInpressions; // for less then 9 to add 0 before count
        } else {
            $inpressions = $totalInpressions; // for greater then 9 to remove 0 before count
        }
        // for mentor total earning counts check
        if ($totalEarn <= 9) {
            $earns = '0' . $totalEarn; // for less then 9 to add 0 before count
        } else {
            $earns = $totalEarn; // for greater then 9 to remove 0 before count
        }
        // for mentor total categories counts check
        if ($totalCategory <= 9) {
            $categories = '0' . $totalCategory; // for less then 9 to add 0 before count
        } else {
            $categories = $totalCategory; // for greater then 9 to remove 0 before count
        }
        $getStates = getStatesByCountryId($request->all()); // for get all states by country id
        $getCities = getCitiesByStateId($request->all()); // for get all cities by state id
        return Response::json(['success' => true, 'mentors' => $mentors, 'mentees' => $mentees, 'inpressions' => $inpressions, 'earns' => $earns, 'category' => $categories, 'getStates' => $getStates, 'getCities' => $getCities]);
    }

    /**
     * Display a listing of the top 20 mentors.
     * @param type $request
     * @return json
     */
    public function getUsersOnDashboard(Request $request) {
        $getAllUsers = $this->dashboard->getUsersOnDashboard($request); // for get users(mentor) on dashbaord after select city 
        $html = View::make('admin::ajax-content.dashboard._dashboard-user-list', ['getAllUsers' => $getAllUsers])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

}
