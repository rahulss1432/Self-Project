<?php

/**
 * Description: this route file is used only for admin routes related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */
/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */
Route::group(['prefix' => 'admin', 'middleware' => 'guest'], function() {

    Route::get('/', function () {
        if (\Auth::guard('admin')->check()) {
            return redirect('admin/dashboard');
        }
        return view('admin::index');
    });

    // login, forget password, reset password routes
    Route::post('login', 'Auth\LoginController@login');
    Route::get('forgot-password', 'AdminController@forgotPassword');
    Route::post('send-forgot-email', 'AdminController@sendForgotEmail');
    Route::get('reset-password/{token}', 'AdminController@resetPassword');
    Route::post('reset-password', 'AdminController@reset');
});

Route::group(['prefix' => 'admin', 'middleware' => 'admin'], function() {
    Route::post('logout', 'Auth\LoginController@logout');
    // dashboard routes
    Route::get('/dashboard', 'DashboardController@index')->name('manage-dashboard');
    Route::get('/get-all-counts', 'DashboardController@getAllCounts');
    Route::get('/get-dashboard-users', 'DashboardController@getUsersOnDashboard');
    // manage user routes
    Route::get('/manage-user', 'UserController@index')->name('manage-user');
    Route::post('/load-user-list', 'UserController@getAllUsers');
    Route::get('/change-user-status', 'UserController@changeUserStatus');
    Route::get('/load-user-profile', 'UserController@loadUserProfile');
    Route::get('/remove-user/{id}', 'UserController@removeUser');
    // manage category routes
    Route::get('/manage-category', 'CategoryController@index')->name('manage-category');
    Route::post('/load-category-list', 'CategoryController@getAllCategories');
    Route::get('/change-category-status', 'CategoryController@changeCategoryStatus');
    Route::post('/add-category', 'CategoryController@addCategory');
    // manage service routes
    Route::get('/get-service/{id}', 'CategoryController@getServiceById')->name('get-service');
    Route::post('/load-service-list', 'CategoryController@getAllService');
    Route::get('/change-service-status', 'CategoryController@changeServiceStatus');
    Route::post('/add-service', 'CategoryController@addService');
    // manage Notifications routes
    Route::get('/notifications', 'NotificationController@notifications')->name('notifications');
    Route::get('/notification-list', 'NotificationController@notificationList');
    Route::get('/load-notification-list', 'NotificationController@manageNotificationList');
    Route::get('/load-notification-count', 'NotificationController@loadNotificationCount');
    Route::post('/update-notification-list', 'NotificationController@updateReadNotification');
    // change password routes
    Route::get('/change-password', 'UserController@changePassword')->name('change-password');
    Route::post('/update-password', 'UserController@updatePassword');
    // manage payment transaction routes
    Route::get('/manage-payment', 'PaymentController@index')->name('manage-payment');
    Route::post('/load-payment-list', 'PaymentController@getAllPayments');
    // manage payment commission routes
    Route::get('/manage-commission', 'PaymentController@commission')->name('manage-commission');
    Route::post('/edit-commission', 'PaymentController@editCmmission');
    // manage message and flagged terms routes
    Route::get('/manage-chat', 'MessageController@index')->name('manage-chat');
    Route::post('/load-chat-list', 'MessageController@getAllConnections');
    Route::get('/change-connection-status', 'MessageController@changeConnectionStatus');
    Route::get('/remove-connection/{id}', 'MessageController@deleteConnection');
    Route::get('/load-flagged-terms-list', 'MessageController@getAllFlaggedTerms');
    Route::get('/messages/{id}/{fromId}', 'MessageController@userMessages')->name('messages');
    // manage cms routes
    Route::get('/faq', 'CmsController@showFaq')->name('faq');
    Route::get('/load-faq-list', 'CmsController@getAllFaqs');
    Route::get('/add-faqs', 'CmsController@showAddFaqs')->name('faq');
    Route::post('/add-faqs', 'CmsController@addFaqs');
    Route::get('/remove-faq/{id}', 'CmsController@deleteFaqs');
    Route::get('/edit-faq/{id}', 'CmsController@showEditFaqs')->name('faq');
    Route::post('/edit-faqs', 'CmsController@editFaqs');
    Route::get('/cms', 'CmsController@showCms')->name('cms');
    Route::get('/load-cms-list', 'CmsController@getAllCms');
    Route::get('/add-cms', 'CmsController@showAddCms')->name('cms');
    Route::post('/add-cms', 'CmsController@addCms');
    Route::get('/edit-cms/{id}', 'CmsController@showEditCms')->name('cms');
    Route::post('/edit-cms', 'CmsController@editCms');

    /** manage contractor section route */
    Route::get('/manage-contractor', 'ContractorController@index')->name('manage-contractor');
    Route::post('/load-contractors-list', 'ContractorController@loadContractorsList');
    Route::get('/update-contractor-status', 'ContractorController@updateContractorStatus');
    Route::get('/remove-contractor/{id}', 'ContractorController@removeContractor');
    Route::get('/load-contractor-details/{id}', 'ContractorController@loadContractorDetails');
    Route::get('/load-check-availability/{id}', 'ContractorController@loadCheckAvailability');
    Route::get('/load-view-document/{id}', 'ContractorController@loadViewDocument');
    Route::get('/load-view-category/{id}', 'ContractorController@loadViewCategory');
    /** pending contractor section route */
    Route::get('/pending-contractor', 'ContractorController@pendingContractors')->name('pending-contractor');
    Route::post('/load-pending-contractors-list', 'ContractorController@loadPendingContractorsList');
    Route::get('/load-contractor-details/{id}', 'ContractorController@loadContractorDetails');
    // manage complaint routes
    Route::get('/manage-complaint', 'ComplaintController@index')->name('manage-complaint');
    Route::get('/load-complaints-list', 'ComplaintController@getAllComplaints');
    Route::get('/load-complaints-view/{id}', 'ComplaintController@getComplaintsView');
    // manage review and post routes
    Route::get('/manage-review-post', 'PostController@index')->name('manage-review-post');
    Route::post('/load-reviews-list', 'PostController@getAllReviews');
    Route::post('/load-posts-list', 'PostController@getAllPosts');
    Route::get('/load-postcomment-view/{id}/{type}', 'PostController@getPostCommentView');
    Route::get('/load-postimage-view/{id}', 'PostController@getPostImageView');
    Route::get('/remove-post-review/{id}/{type}', 'PostController@removePostReview');
    // manage booking routes
    Route::get('/manage-booking', 'BookingController@index')->name('manage-booking');
    Route::post('/load-booking-list', 'BookingController@getAllBookings');
    Route::get('/invoice/{id}', 'BookingController@getInvoice');
    // manage country state city routes
    Route::get('get-all-country', 'DashboardController@getAllCountry');
    Route::get('get-state-by-country-id', 'DashboardController@getStatesByCountryId');
    Route::get('get-city-by-state-id', 'DashboardController@getCitiesByStateId');
});
