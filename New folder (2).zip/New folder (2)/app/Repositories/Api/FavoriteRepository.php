<?php

namespace App\Repositories\Api;

/**
 * Description: this repository is used only for favourite unfavourite related for both mentor and user 
 * Author : Codiant- A Yash Technologies Company 
 * Date :15 march 2019
 * 
 */

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Favorite;

Class FavoriteRepository {

    public function __construct(Favorite $favorite) {
        $this->favorite = $favorite;
    }

    /**
     * Save favorite
     */
    
    /**
     * favourite and unfavourite user
     * @param type $request(obj)
     * @param type $user(obj)
     * @return type boolean
     */
    public function saveFavorite($request, $user) {
        $data = $this->favorite->where(['from_id' => $user->id, 'to_id' => $request->user_id])->first();
        if ($data) {
            return $data->delete();
        } else {
            $data['from_id'] = $user->id;
            $data['to_id'] = $request->user_id;
            return $this->favorite->create($data);
        }
    }

}
