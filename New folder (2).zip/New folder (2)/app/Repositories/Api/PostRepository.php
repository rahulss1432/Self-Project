<?php

namespace App\Repositories\Api;
/**
 * Description: this repository is used for post related operations 
 * Author : Codiant- A Yash Technologies Company 
 * Date :8 march 2019
 * 
 */

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Post;
use App\Models\PostImage;
use File;

Class PostRepository {

    public function __construct(Post $post, PostImage $postImage) {
        $this->post = $post;
		$this->postImage = $postImage;
    }

  
    /**
     * Save Post
     * @param type $request(obj)
     * @param type $user(obj)
     * @return type (obj)
     */
    
    public function savePost($request, $user) {
		$data['from_id'] = $user->id;
		$data['to_id'] = $request->to_id;
		$data['appointment_id'] = $request->appointment_id;
		$data['comment'] = $request->comment;
		// Save Post
		$post = $this->post->create($data);
		
		if($post){	
			$postID = $post->id;
			// Create folder if not exist
			$portfolioPath = public_path() . '/uploads/posts';
			if (!is_dir($portfolioPath)) {
				File::makeDirectory($portfolioPath, $mode = 0777, true, true);
			}
			if ($request->hasFile('images')) {
				// Upload file into folder
				foreach( $request->images as $images ){
					$file = $images;
					$fileName = $file->getClientOriginalName();
					$fileExtension = strtolower($file->getClientOriginalExtension());
					$imageExist = public_path() . '/uploads/posts/' . $fileName;
					$file->move('public/uploads/posts', time().$fileName);
					$postImage['post_id'] = $postID;
					$postImage['image_title'] = time().$fileName;
					$this->postImage->create($postImage);
				}
			}
		}
		return $post;
    }
	
	/**
         * get post list
         * @param type $request(obj)
         * @param type $user(obj)
         * @return type
         */
    
    public function getPost($request, $user) {
		return $this->post->where('to_id', $request->id)->get();
    }

}
