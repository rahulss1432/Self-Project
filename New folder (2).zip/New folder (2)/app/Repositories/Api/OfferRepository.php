<?php

namespace App\Repositories\Api;
/**
 * Description: this repository is used only for offer related operation for both mentor and user 
 * Author : Codiant- A Yash Technologies Company 
 * Date :15 march 2019
 * 
 */

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Offer;

Class OfferRepository {

    public function __construct(Offer $offer) {
        $this->offer = $offer;
    }

    /**
     * Save Offer
     * @param type $request(OBJ)
     * @param type $user (OBJ)
     * @return Boolean
     */
    
    public function saveOffer($request, $user) {
		$data = $request->all();
		$data['from_id'] = $user->id;
		return $this->offer->create($data);
    }

    /**
     * get Offer list
     * @param type $request(OBJ)
     * @param type $user (OBJ)
     * @return type Object
     */
    public function getOffer($request, $user) {
		return $this->offer->whereRaw("( from_id = $user->id OR to_id = $user->id )")->get();
    }

}
