<?php

namespace App\Repositories\Api;

/**
 * Description: this repository is used only for appointment related operations 
 * Author : Codiant- A Yash Technologies Company 
 * Date :5 march 2019
 * 
 */

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Appointment;

Class AppointmentRepository {

    public function __construct(Appointment $appointment) {
        $this->appointment = $appointment;
    }

    /**
     *  Save Appointment
     * @param type $request(OBJ)
     * @param type $user
     * @return type Boolean
     */
    
    public function saveAppointment($request, $user) {
        $data = $request->all();
        $data['reference_id'] = substr(rand() * 900000 + 100000, 0, 6);
        $data['from_id'] = $user->id;
        return $this->appointment->create($data);
    }

       
    /**
     * Get Appointment list
     * @param type $request(OBJ)
     * @param type $user (OBJ)
     * @return type json
     */
    
    public function getAppointment($request, $user) {
        $date = date('Y-m-d');
        if ($request->type == 'on_going') {
            return $this->appointment->where('date', $date)->whereRaw("( from_id = $user->id OR to_id = $user->id ) and status != 'cancelled'")->get();
        } elseif ($request->type == 'upcomming') {
            return $this->appointment->where('date', '>', $date)->whereRaw("( from_id = $user->id OR to_id = $user->id ) and status != 'cancelled' ")->get();
        } else {
            return $this->appointment->where('date', '<', $date)->whereRaw("( from_id = $user->id OR to_id = $user->id ) or status = 'cancelled' ")->get();
        }
    }

    /**
     * Get Appointment detail
     * @param type $request(OBJ)
     * @return type OBJ
     */
    
    public function getAppointmentDetail($request) {

        return $this->appointment->where('id', $request->id)->first();
    }

   
    /**
     * Update Appointment
     * @param type $request(OBJ)
     * @param type $user (OBJ)
     * @return type OBJ
     */
    
    public function updateAppointment($request, $user) {
        $this->appointment->where('id', $request->id)->update($request->all());
        return $this->appointment->find($request->id);
    }

    /**
     * cancel/complete Appointment
     * @param type $request(OBJ)
     * @return boolean
     */
    
    public function cancelCompleteAppointment($request) {
        $appointment = $this->appointment->where('id', $request->id)->first();
        if ($appointment) {
            $appointment['status'] = $request->status;
            $appointment->save();
            return true;
        }return false;
    }

}
