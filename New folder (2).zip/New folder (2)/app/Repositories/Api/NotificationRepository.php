<?php

namespace App\Repositories\Api;

/**
 * Description: this repository is used only for notification related operation for both mentor and user 
 * Author : Codiant- A Yash Technologies Company 
 * Date :15 march 2019
 * 
 */

use JWTAuth;
use StaticMessage;
use App\Models\Notification;

Class NotificationRepository {

    public function __construct(Notification $notification) {
        $this->notification = $notification;
    }

    
    /**
     * Save Notification
     * @param type $request
     * @return type boolean
     */
    
    public function saveNotification($request) {
        $data = $request->all();
        return $this->notification->create($data);
    }

    /**
     * get notification list.
     * @param type $request(OBJ)
     * @return Json
     */
    
    public function getNotification($request) {

        try {
            
            $user = JWTAuth::toUser($request->header('access_token'));// to get current user detail
            $notifications = $this->notification->where('to_id', $user->id)->paginate(10);
            if (count($notifications) > 0) {
                foreach ($notifications as $notification) {
                    $from_user = \App\User::where(['id' => $notification['from_id']])->first();
                    $notification->from_user_image = checkUserImage($from_user->profile_image);
                    $notification->from_user_first_name = $from_user['first_name'];
                    $notification->from_user_last_name = $from_user['last_name'];
                }
            }
            return response()->json(['success' => true, 'data' => $notifications, 'message' => '']);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * delete notification
     * @param type $request(OBJ)
     * @return type Json
     */
    public function deleteNotification($request) {

        try {
            $notification = $this->notification->where('id', $request->id)->delete();
            if ($notification) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Notification deleted successfully.']);
            }
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Notification not found']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * delete all notification of login user
     * @param type $request(OBJ)
     * @return type Json
     */
    
    public function deleteAllNotification($request) {

        try {
            $user = JWTAuth::toUser($request->header('access_token'));
            $notification = $this->notification->where('to_id', $user->id)->delete();
            if ($notification) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Notification deleted successfully.']);
            }
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Notification not found']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

}
