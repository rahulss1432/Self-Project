<?php

namespace App\Repositories\Api;
/**
 * Description: this repository is used for offer related operations 
 * Author : Codiant- A Yash Technologies Company 
 * Date :10 march 2019
 * 
 */

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Portfolio;
use File;

Class PortfolioRepository {

    public function __construct(Portfolio $portfolio) {
        $this->portfolio = $portfolio;
    }

    /**
     * Save Portfolio
     */
    /**
     * 
     * @param type $request(obj)
     * @param type $user(obj)
     * @return boolean
     */
    
    public function savePortfolio($request, $user) {

            $fileName = "";
            $data = $request->all();
            $data['user_id'] = $user->id;

            // Create folder if not exist
            $portfolioPath = public_path() . '/uploads/portfolio';
            if (!is_dir($portfolioPath)) {
                File::makeDirectory($portfolioPath, $mode = 0777, true, true);
            }

            if (!empty($request->ids)) {
                foreach ($request->ids as $id) {
                    $this->portfolio->where(['id' => $id])->delete();
                }
            }

        if ($request->hasFile('links')) {
            
                // Upload file into folder
                foreach ($request->links as $link) {
                    $file = $link;
                    $fileName = $file->getClientOriginalName();
                    $fileExtension = strtolower($file->getClientOriginalExtension());
                    $imageExist = public_path() . '/uploads/portfolio/' . $fileName;
                    $link->move('public/uploads/portfolio', $fileName);
                    $data['link'] = $fileName;
                    $port_model = new $this->portfolio();
                    $port_model->user_id = $data['user_id'];
                    $port_model->link = $data['link'];
                    $port_model->bio = $data['bio'];
                    $port_model->file_size = filesize($imageExist);
                    $port_model->save();
                }
            }return true;
            
      
    }

    /**
     * 
     * @param type $request(obj)
     * @param type $user(obj)
     * @return type array of obj
     */
    
    public function getPortfolio($request, $user) {
        $data = $this->portfolio->where('user_id', $user->id)->get();
        foreach ($data as $item) {
            $item->file_name = $item->link;
            $item['link'] = url('public/uploads/portfolio/' . $item->link);
            // create file extension
            $path_array = explode('/', $item['link']);
            $last_value = $path_array[count($path_array) - 1];
            $extension_array = explode('.', $last_value);
            $extension = $extension_array[count($extension_array) - 1];
            $item['extension'] = $extension;
        }
        return $data;
    }

}
