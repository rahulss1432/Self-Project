<?php

namespace App\Repositories\Api;

/**
 * Description: this repository is used  for account and other user related operations 
 * Author : Codiant- A Yash Technologies Company 
 * Date :10 march 2019
 * 
 */
use Illuminate\Support\Facades\DB;
use App\Models\Auth;
use App\UserDevice;
use App\Models\Rating;
use App\Models\Category;
use App\Models\Service;
use App\Models\Appointment;
use App\User;
use Stripe\Stripe;
use Stripe\Customer;
use StaticMessage;
use App\Models\Offer;
use JWTAuth;
use File;
use App\Models\Portfolio;
use App\Models\MentorCategory;

Class UserRepository {

    public function __construct(User $user, Rating $rating, Category $category, Service $service, Appointment $appointment, Offer $offer) {
        $this->user = $user;
        $this->category = $category;
        $this->service = $service;
        $this->rating = $rating;
        $this->appointment = $appointment;
        $this->offer = $offer;
    }

    /**
     * Send otp on mentee and  mentor mobile number.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function sendOTP($request) {

        try {
            $user = $this->user->where('email', $request->email)->first();
            if (!empty($user)) {
                $otp = mt_rand(100000, 999999);
                $user->verification_code = $otp;
                if ($user->save()) {
                    $data['request'] = 'send_otp';
                    $data['username'] = $user->first_name;
                    $data['email'] = $user->email;
                    $data['otp'] = $otp;
                    $data['subject'] = 'Send otp';
                    $mail = sendMail($data);
                }
                return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['resent_code']]);
            }
            return response()->json(['success' => FALSE, 'data' => [], 'error' => ['message' => 'User not found.']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * Send otp on mentee  and mentor  mobile number.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function forgotPassword($request) {

        try {
            $user = $this->user->where('email', $request->email)->first();
            if (!empty($user)) {
                $token = mt_rand(100000, 999999);
                $user->reset_token = $token;
                if ($user->save()) {
                    $data['request'] = 'reset_token';
                    $data['username'] = $user->first_name;
                    $data['email'] = $user->email;
                    $data['token'] = $token;
                    $data['subject'] = 'Reset token';
                    $mail = sendMail($data);
                }
                return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['resent_token']]);
            }
            return response()->json(['success' => FALSE, 'data' => [], 'error' => ['message' => \StaticMessage::$app['resent_email']]]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * code verification
     * @param type $request(OBJ)
     * @return type Json
     */
    public function OTPVerify($request) {
        try {
            $user = $this->user->where(['verification_code' => $request->code, 'email' => $request->email])->first();
            if (!empty($user)) {
                $user->verification_code = 0;
                if ($user->save()) {
                    $user->profile_image = checkUserImage($user->profile_image);
                    $token = JWTAuth::fromUser($user); // login after verification for first time
                    $post = $request->all();
                    $post['access_token'] = $token;
                    if (!empty($user)) {
                        $user['access_token'] = $token;
                        $result = UserDevice::addUserDevice($post); // save device details and type
                    }
                    return response()->json(['success' => true, 'data' => $user, 'message' => \StaticMessage::$app['verify_code']]);
                }
            }
            return response()->json(['success' => FALSE, 'data' => [], 'error' => ['message' => \StaticMessage::$app['verify_code_invalid']]]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * reset password 
     * @param type $request(OBJ)
     * @return type Json
     */
    public function resetPassword($request) {
        try {
            $user = $this->user->where('reset_token', $request->code)->first();
            if (!empty($user)) {
                $user->reset_token = 0;
                $user->password = bcrypt($request->password);
                if ($user->save())
                    return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['pass_reset']]);
            }
            return response()->json(['success' => FALSE, 'data' => [], 'error' => ['message' => \StaticMessage::$app['pass_reset_token_invalid']]]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * 
     * @param type $user
     * @param type $device
     * @return type
     */
    public function getToken($user, $device) {
        try {
            //return $user;
            if (!$userToken = JWTAuth::fromUser($user)) {
                return response()->json(['error' => 'invalid_credentials'], 401);
            }

            $get_token = $this->user_devices->where('user_id', $user->id)->first();
            if (isset($get_token['access_token']) && $get_token['access_token'] != '') {
                $this->user_devices->where('user_id', $user->id)->delete();
                JWTAuth::invalidate($get_token['access_token']);
            }
            $this->user_devices->where('user_id', $user->id)->delete();
            $device['user_id'] = $user->id;
            $device['access_token'] = $userToken;
            $user_device = $this->user_devices->create($device); //Save data in user devices table.
            if (isset($user_device) && $user_device != '') {
                $unread_notification_count = Utility::getUnreadNotificationCount($user->id);
                return response()->json(['success' => true, 'error' => [], 'data' => ['access_token' => $userToken, 'is_user_registered' => $user['is_user_registered'], 'country_code' => $user->country_code, 'mobile' => $user->mobile, 'customer_id' => $user['customer_id'], 'unread_notification_count' => $unread_notification_count, 'user_id' => $user['id']]]);
            } else {
                return response()->json(['success' => false, 'error' => ['message' => 'Please check your enter data']], 422);
            }
            //return $user;
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /**
     * Get user profile detail
     * @param type $request
     * @return type json
     */
    public function getUser($request) {

        try {
            $token = $request->header('access_token');
            $user = JWTAuth::toUser($request->header('access_token')); // to get login user detail
            $user = User::where(['id' => $request->id])->first();
            $user->profile_image = checkUserImage($user->profile_image, 'users'); // to get user profile image
            $user['access_token'] = $request->header('access_token');
            $rating = getAverageRating($user->id);
            $user['average_rating'] = $rating['average'];
            $user['rating_count'] = $rating['count'];
            if ($user['role'] == 'mentor') {
                $portfolio = Portfolio::where(['user_id' => $user['id']])->orderBy('id', 'desc')->first();
                $user['bio'] = ($portfolio) ? $portfolio['bio'] : '';
            }
            return response()->json(['success' => true, 'data' => $user, 'error' => []]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /**
     * update user profile.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function updateProfile($request) {
        try {

            $user = JWTAuth::toUser($request->header('access_token'));
            $usersPath = public_path() . '/uploads/users';
            if (!is_dir($usersPath)) {
                File::makeDirectory($usersPath, $mode = 0777, true, true);
            }

            if (isset($request['profile_image']) && $request['profile_image'] != '') {
                $filename = public_path() . '/uploads/' . $user->profile_image;
                $image = time() . '.' . $request['profile_image']->getClientOriginalExtension();
                $request['profile_image']->move($usersPath, $image);
            } else {
                $image = $user->profile_image;
            }

            $user = JWTAuth::toUser($request->header('access_token'));
            if (empty($request['phone_number'])) {
                $mobile_number = '';
            } else {
                $mobile_number = $request['phone_number'];
            }
            $update = $this->user->where('id', $user->id)->update(['first_name' => $request['first_name'], 'last_name' => $request['last_name'], 'profile_image' => $image, 'phone_number' => $mobile_number, 'address' => $request['address'], 'date_of_birth' => $request['date_of_birth'], 'address' => $request['address'], 'country_id' => $request['country'], 'state_id' => $request['state'], 'city' => $request['city'], 'bio' => $request['bio'], 'parent_name' => $request['parent_name'], 'parent_email' => $request['parent_email']]);
            if ($update) {
                $update_user = JWTAuth::toUser($request->header('access_token'));
                $update_user->profile_image = checkUserImage($update_user->profile_image, 'users');
                $update_user->profile_complete = checkMentorProfileStatus($update_user->id);
                return response()->json(['success' => true, 'data' => $update_user, 'message' => 'Profile updated successfully.']);
            } else {
                return response()->json(['success' => false, 'error' => ['message' => 'Profile could not be updated']], 422);
            }
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * save user detail and send mail for verification
     * @param type $request(obj)
     * @return json
     */
    public function saveUser($request) {
        try {
            $otp = mt_rand(100000, 999999);
            $user = new $this->user;
            $user->verification_code = $otp;
            $user->role = $request->role;
            $user->first_name = $request->first_name;
            $user->last_name = $request->last_name;
            $user->email = $request->email;
            $user->password = bcrypt($request->password);
            $user->status = ($request->role == 'mentor') ? 'disapprove' : 'active';
            if ($user->save()) {
                /*                 * ************ Create stripe User *********************** */
                Stripe::setApiKey(getSetting('stripe_test_secret_key'));
                $customer = Customer::create(['email' => $request->email]);
                if ($customer) {
                    $user->customer_id = $customer['id'];
                }
                /*                 * ******************************************************* */
                /*
                 * send verification mail to signup user
                 */
                $data['request'] = 'send_otp';
                $data['username'] = $user->first_name;
                $data['email'] = $user->email;
                $data['otp'] = $otp;
                $data['subject'] = 'Send otp';
                $mail = sendMail($data);
            }
            return response()->json(['success' => true, 'data' => $user, 'message' => \StaticMessage::$app['signup']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * function to logout user
     * @param type $request
     * @return json
     */
    public function logout($request) {
        try {
            $token = \Request::header('access_token');
            $user = JWTAuth::toUser($request->header('access_token'));
            try {
                $this->user->where('id', $user->id)->update(['is_available' => '0']);
                JWTAuth::invalidate($token);
                $this->user_devices->where('access_token', $token)->delete();
            } catch (\Exception $e) {
                $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
                return $json;
            }

            return response()->json(['success' => true, 'error' => [], 'data' => ['message' => 'You are Logged out.']]);
        } catch (\Exception $e) {

            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /**
     * function to get user detail
     * @param type $id
     * @return obj
     */
    public function getUserData($id) {

        $user = $this->user->where('id', $id)->first();
        if ($user) {
            return $user;
        } else {
            return false;
        }
    }

    /**
     * function to check user is verified or not
     * @param type $request(obj)
     * @return type json
     */
    public function checkVerification($request) {

        $data = [];
        $user = $this->user->where('email', $request->email)->first();
        if ($user) {
            if (empty($user->verification_code)) {
                $data['is_verified'] = true;
            } else {
                $data['is_verified'] = false;
            }
            return response()->json(['success' => true, 'data' => $data, 'message' => '']);
        }
        return response()->json(['success' => false, 'error' => ['message' => \StaticMessage::$app['email_not_exist']]]);
    }

    /**
     * save or update social user detail and login
     * @param type $post(array)
     * @return type json
     */
    public static function saveSocialUser($post) {

        $user = Auth::where(['source_id' => $post['source_id']])->first();

        $check_email = User::where(['email' => $post['email']])->first();
        if (empty($user)) {
            if (!empty($check_email) && $check_email['user_type'] != $post['type']) {
                return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'This email already used by user in another social media.']]);
            }
            $user = new User();
            $user->profile_image = $post['profile_image'];
            $user->user_type = $post['type'];
            $user->role = $post['role'];
            $user->email = $post['email'];
            $user->first_name = $post['first_name'];
            $user->last_name = $post['last_name'];
            $user->status = ($post['role'] == 'mentor') ? 'disapprove' : 'active';
            $user->verify_facebook = ($post['type'] == 'facebook') ? 'yes' : 'no';
            $user->verify_youtube = ($post['type'] == 'google') ? 'yes' : 'no';
            if ($user->save()) {
                $auth = new Auth();
                $auth->user_id = $user->id;
                $auth->source_id = $post['source_id'];
                $auth->save();
                $token = JWTAuth::fromUser($user);
                if ($token) {
                    $post['access_token'] = $token;
                    $post['user_id'] = $user->id;
                    $user = User::find($user->id);
                    UserDevice::addUserDevice($post);
                    $user->access_token = $token;
                    $user->profile_image = $user->profile_image;
                }
                return response()->json(['success' => true, 'data' => $user, 'message' => '']);
            }
        } else {

            $user = User::where(['id' => $user->user_id])->first();
            if ($post['role'] != $user['role']) {
                return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Your are not allowed to login  this type of user.']]);
            }

            if ($user['status'] == 'inactive') {
                return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Your account  is not active.']]);
            }

            $token = JWTAuth::fromUser($user);
            if ($token) {
                $post['access_token'] = $token;
                $post['user_id'] = $user->id;
                UserDevice::addUserDevice($post);
                $user['access_token'] = $token;
                $user['profile_image'] = $user->profile_image;
            }
            return response()->json(['success' => true, 'data' => $user, 'message' => '']);
        }
    }

    /**
     * save login user device detail and token
     * @param type $post(array)
     */
    public static function saveDeviceDetail($post) {
        $devicemodel = UserDevice::where(['user_id' => $post['user_id'], 'device_id' => $post['device_id']])
                ->first();
        if (empty($devicemodel)) {
            $devicemodel = new UserDevice();
        }
        $devicemodel->user_id = $post['user_id'];
        $devicemodel->device_id = $post['device_id'];
        $devicemodel->device_type = $post['device_type'];
        $devicemodel->access_token = $post['access_token'];
        $devicemodel->device_token = $post['device_token'];
        $devicemodel->save();
    }

    /**
     * provide Rating to opposite user
     * @param type $request(obj)
     * @return boolean
     */
    public function giveRating($request) {
        $rating = new $this->rating();
        $rating->from_id = $request->from_id;
        $rating->to_id = $request->to_id;
        $rating->appointment_id = $request->appointment_id;
        $rating->reviews = $request->reviews;
        $rating->rating = $request->rating;
        if ($rating->save()) {
            return true;
        }return false;
    }

    /**
     * get service list by category id
     * @param type $request(obj)
     * @return type obj
     */
    public function services($request) {
        $services = $this->service->where(['status' => 'active', 'category_id' => $request->catery_id])->get();
        return $services;
    }

    /**
     *  get category list
     * @param type $request(obj)
     * @return type obj
     */
    public function categoryList($request) {
        $categorys = $this->category->where(['status' => 'active'])->get();
        foreach ($categorys as $category) {
            $category->category_icon = checkCategoryIcon($category->category_icon, 'category_icons');
        }
        return $categorys;
    }

    /**
     * get mentor earning api
     * @param type $request(obj)
     * @return type obj
     */
    public function getEarning($request) {

        $earnings = DB::table('appointments')
                ->join('transactions as tn', 'tn.appointment_id', '=', 'appointments.id')
                ->select('tn.transaction_id as transaction_id', 'appointments.reference_id', 'appointments.status', 'appointments.status', 'tn.total_amount as amount', 'tn.total_amount as amount', 'appointments.created_at', 'appointments.from_id')
        ;
        // date wise filter
        if (!empty($request->date)) {
            $date = "'" . $request->date . "'";
            $earnings->whereRaw("DATE(tn.created_at) = $date");
        }
        // status wise filter
        if (!empty($request->status)) {
            $satatus = "'" . $request->status . "'";
            $earnings->whereRaw("tn.status = $satatus");
        }
        // transaction_id wise filter
        if (!empty($request->transaction_id)) {
            $tarnsaction_id = "'" . $request->transaction_id . "'";
            $earnings->whereRaw("tn.transaction_id = $tarnsaction_id");
        }

        $earnings = $earnings->paginate(10);
        foreach ($earnings as $earning) {
            $user = User::where(['id' => $earning->from_id])->first();
            $earning->from_user_first_name = $user['first_name'];
            $earning->from_user_last_name = $user['last_name'];
        }


        $custom = collect(['total_amount' => 9798]);
        $data = $custom->merge($earnings);
        return $data;
    }

    /**
     * get eplore user list
     * @param type $request(obj)
     * @return type obj
     */
    public function explorUsers($request) {

        $users = $this->user::take(20)->select('first_name', 'last_name', 'profile_image', 'address')->where(['role' => 'user'])->get();
//        $users->join('ratings', 'ratings.to_id', '=', 'users.id');
//            $users->havingRaw("AVG(ratings.rating) >= $from");
//            $users->groupBy("ratings.to_id");$users->get();

        if (count($users) > 0) {
            foreach ($users as $user) {
                $user->profile_image = checkUserImage($user->profile_image, 'users');
                $user->average_rating = getAverageRating($user->id)['average'];
            }
        }
        return $users;
    }

    /**
     * get mentor lists by mentee
     * @param type $request(obj)
     * @return type obj
     */
    public function getMentorList($request) {

        $user = JWTAuth::toUser($request->header('access_token'));
        $lat = $user->latitude;
        $long = $user->longitude;
        $distance = explode(',', $request->distance);
        $mentors = User::
                join('availability as avl', 'avl.user_id', '=', 'users.id')
                ->join('mentor_categories as mc', 'mc.user_id', '=', 'users.id')
                ->select('users.first_name', 'users.last_name', 'users.id', 'users.address', 'users.profile_image', 'avl.latitude', 'avl.longitude', 'avl.from_date_time', 'avl.to_date_time')
                ->whereRaw(DB::raw("(3959 * acos( cos( radians($lat) ) * cos( radians( avl.latitude ) )  * 
                          cos( radians( avl.longitude ) - radians($long) ) + sin( radians($lat) ) * sin( 
                          radians( avl.latitude ) ) ) ) between  $distance[0] and $distance[1]"));


        // experience filter
        if (!empty($request->experince)) {
            $experince = explode(',', $request->experince);
            $from = $experince[0];
            $to = $experince[1];
            $mentors->whereBetween('mc.exp_year', [$from, $to]);
        }
        // price filter
        if (!empty($request->price)) {
            $price = explode(',', $request->price);
            $from = $price[0];
            $to = $price[1];
            $mentors->whereBetween('mc.amount', [$from, $to]);
        }

        // date filter
        if (!empty($request->date)) {
            $date = "'" . $request->date . "'";
            $mentors->whereRaw("DATE(avl.from_date_time) <= $date and DATE(avl.to_date_time) >= $date");
        }

        // time filter
        if (!empty($request->time)) {
            $time = "'" . $request->time . "'";
            $mentors->whereRaw("TIME(avl.from_date_time) <= $time and TIME(avl.to_date_time) >= $time");
        }

        // rating filter
        if (!empty($request->rating)) {
            $rating = explode(',', $request->rating);
            $from = $rating[0];
            $to = $rating[1];
            $mentors->join('ratings', 'ratings.to_id', '=', 'users.id');
            $mentors->havingRaw("AVG(ratings.rating) >= $from");
            $mentors->havingRaw("AVG(ratings.rating) <=  $to");
            $mentors->groupBy("ratings.to_id");
        }
        // filter by category id 
        if (!empty($request->category_id)) {
            $mentors->where('mc.category_id', '=', $request->category_id);
        }
        // filter by service id 
        if (!empty($request->service_id)) {
            $mentors->where('mc.service_id', '=', $request->service_id);
        }
        //filter by mentor id 
        if (!empty($request->mentor_id)) {
            $mentors->where('avl.user_id', '=', $request->mentor_id);
        }
        // place wise filter
        if (!empty($request->meeting_place)) {
            $mentors->where('avl.meeting_place', '=', $request->meeting_place);
        }

        $mentors = $mentors->paginate(10);

        if (count($mentors) > 0) {
            foreach ($mentors as $mentor) {
                $mentor->profile_image = checkUserImage($mentor->profile_image, 'users');
            }
        }
        return $mentors;
    }

    /**
     * mentee home api's function
     * @param type $request(obj)
     * @return type obj
     */
    
    public function userHome($request) {

        $user = JWTAuth::toUser($request->header('access_token'));
        $lat = $user->latitude;
        $long = $user->longitude;
        $distance = explode(',', $request->distance);
        $mentors = User::
                join('availability as avl', 'avl.user_id', '=', 'users.id')
                ->select('users.first_name', 'users.last_name', 'users.role', 'users.id', 'users.address', 'users.profile_image', 'avl.latitude', 'avl.longitude', 'avl.from_date_time', 'avl.to_date_time')
//                ->whereRaw(DB::raw("(3959 * acos( cos( radians($lat) ) * cos( radians( avl.latitude ) )  * 
//                          cos( radians( avl.longitude ) - radians($long) ) + sin( radians($lat) ) * sin( 
//                          radians( avl.latitude ) ) ) )"))
                ->where('users.role', 'mentor');

        $mentors = $mentors->get();
        if (count($mentors) > 0) {
            foreach ($mentors as $mentor) {
                $mentor->profile_image = checkUserImage($mentor->profile_image, 'users');
            }
        }
        return $mentors;
    }

/**
 * get favourite mentor lists by user
 * @param type $request(obj)
 * @return type(obj)
 */
    public function myFavourite($request) {
        $user = JWTAuth::toUser($request->header('access_token'));
        $mentors = User::
                join('favorites as fav', 'fav.from_id', '=', 'users.id')
                ->select('users.first_name', 'users.last_name', 'users.id', 'users.address', 'users.profile_image')
                ->where('fav.from_id', $user->id)
                ->paginate(10);
        if (count($mentors) > 0) {
            foreach ($mentors as $mentor) {
                $mentor->profile_image = checkUserImage($mentor->profile_image, 'users');
            }
        }
        return $mentors;
    }

/**
 * update lat long of mentee
 * @param type $request(obj)
 * @return boolean
 */
    public function updateLatLong($request) {
        $user = JWTAuth::toUser($request->header('access_token'));
        $user->latitude = $request->latitude;
        $user->longitude = $request->longitude;
        if ($user->save()) {
            return true;
        } return false;
    }


/**
 * user offer detail
 * @param type $request(obj)
 * @return type obj
 */
    public function offerDetail($request) {
        $user = JWTAuth::toUser($request->header('access_token'));
        return $this->offer->where(['from_id' => $request->mentor_id, 'to_id' => $user->id])->first();
    }

  
/**
 * update offer status
 * @param type $request(obj)
 * @return boolean
 */
    public function offerAcceptDecline($request) {

        $offer = $this->offer->where(['id' => $request->offer_id])->first();
        if ($offer) {
            $offer['status'] = $request->status;
            $offer->save();
            return true;
        }return false;
    }

/**
 * check mentor availabilty by mentee
 * @param type $request(obj)
 * @return type(obj)
 */
    public function checkAvailability($request) {

        $availability = User::
                join('availability as avl', 'avl.user_id', '=', 'users.id')
                ->select('users.address', 'avl.latitude', 'avl.longitude', 'avl.from_date_time', 'avl.to_date_time', 'avl.user_id', 'avl.meeting_place')
                ->whereRaw("avl.user_id = $request->mentor_id");

        // date filter
        if (!empty($request->date)) {
            $date = "'" . $request->date . "'";
            $availability->whereRaw("DATE(avl.from_date_time) <= $date and DATE(avl.to_date_time) >= $date");
        }
        // get level of knowledge for perticular category
        $category = MentorCategory::where(['category_id' => $request->category_id, 'service_id' => $request->sub_category_id])->first();

        $availability = $availability->first();
        if (!empty($availability)) {
            $availability->level_of_knowledge = $category['level_of_knowledge'];
        }

        return $availability;
    }

}
