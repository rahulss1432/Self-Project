<?php

namespace App\Repositories\Api;

/**
 * Description: this repository is used only for complaints operation for both mentor and user 
 * Author : Codiant- A Yash Technologies Company 
 * Date :15 march 2019
 * 
 */

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Complaint;

Class ComplaintRepository {

    public function __construct(Complaint $complaint) {
        $this->complaint = $complaint;
    }

    /**
     * 
     * @param type $request(obj)
     * @param type $user(obj)
     * @return type boolean
     */
    
    public function saveComplaints($request, $user) {
		$data['from_id'] = $user->id;
		$data['to_id'] = $request->user_id;
		$data['comments'] = $request->comments;
		$data['block'] = $request->block;
		return $this->complaint->create($data);
    }

}
