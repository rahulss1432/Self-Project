<?php

namespace App\Repositories\Api;

/**
 * Description: this repository is used only for mentor related operations 
 * Author : Codiant- A Yash Technologies Company 
 * Date : march 2019
 * 
 */
use App\Models\Availability;
use JWTAuth;
use StaticMessage;
use App\Models\MentorCategory;

Class MentorRepository {

    public function __construct(Availability $Availability, MentorCategory $mentorCategory) {
        $this->availability = $Availability;
        $this->mentorCategory = $mentorCategory;
    }

    /**
     * add availability
     * @param type $request(OBJ)
     * @return type Json
     */
    public function addAvailability($request) {

        try {

            $user = JWTAuth::toUser($request->header('access_token')); // to get login user detail
            $from_date = "'" . $request->from_date . "'"; // convert into string
            $to_date = "'" . $request->to_date . "'"; // convert into string

            $from_time = "'" . $request->from_time . "'"; // convert into string
            $to_time = "'" . $request->to_time . "'"; // convert into string
            // to check for already exist slot on date and time
            $avl = Availability::where('user_id', $user->id)
                    ->where(function ($query) use ($from_date, $to_date, $user, $from_time, $to_time) {
                        // to check for already exist slot on same  date 
                        $query->whereRaw("DATE(from_date_time) = $from_date and DATE(to_date_time)=  $to_date and "
                                // to check for already exist slot for time only 
                                . "((TIME(from_date_time) = $from_time and TIME(to_date_time)=  $to_time) or "
                                . "(TIME(from_date_time) > $from_time and TIME(from_date_time) < $to_time)or"
                                . "(TIME(from_date_time) < $from_time and TIME(to_date_time)=  $to_time)or"
                                . "(TIME(to_date_time) > $from_time and TIME(to_date_time)<  $to_time)or "
                                . "(TIME(from_date_time) = $from_time and TIME(to_date_time)>  $to_time))");
                    })->orWhere(function($query)use ($from_date, $to_date, $user, $from_time, $to_time) {
                        $query->whereRaw("DATE(from_date_time) > $from_date and DATE(to_date_time)<  $to_date");
                    })->orWhere(function($query)use ($from_date, $to_date, $user, $from_time, $to_time) {
                        $query->whereRaw("DATE(from_date_time) < $from_date and DATE(to_date_time)>=  $to_date");
                    })->orWhere(function($query)use ($from_date, $to_date, $user, $from_time, $to_time) {
                        $query->whereRaw("DATE(to_date_time) > $from_date and DATE(to_date_time) <  $to_date");
                    })->orWhere(function($query)use ($from_date, $to_date, $user, $from_time, $to_time) {
                        $query->whereRaw("DATE(from_date_time) >= $from_date and DATE(to_date_time) >  $to_date");
                    })
                    ->first();

            // add vailabolity slot of mentor
            if (empty($avl)) {
                $model = new $this->availability();
                $model->user_id = $user->id;
                $model->from_date_time = $request->from_date . ' ' . $request->from_time;
                $model->to_date_time = $request->to_date . ' ' . $request->to_time;
                $model->state = $request->state;
                $model->city = $request->city;
                $model->address = $request->address;
                $model->latitude = $request->latitude;
                $model->longitude = $request->longitude;
                $model->meeting_place = $request->meeting_place;
                $model->save();
                return response()->json(['success' => true, 'data' => $model, 'message' => \StaticMessage::$app['availibilty_add']]);
            } return response()->json(['success' => false, 'data' => [], 'error' => ['message' => \StaticMessage::$app['availability_exist']]]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * edit availability
     * @param type $request(OBJ)
     * @return type Json
     */
    public function editAvailability($request) {
        try {
            $user = JWTAuth::toUser($request->header('access_token')); // to get login user detail
            $model = $this->availability->find($request->id);
            $model->user_id = $user->id;
            $model->from_date_time = $request->from_date . ' ' . $request->from_time;
            $model->to_date_time = $request->to_date . ' ' . $request->to_time;
            $model->state_id = $request->state;
            $model->city = $request->city;
            $model->save();
            return response()->json(['success' => true, 'data' => $model, 'message' => \StaticMessage::$app['update_availability']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * get availability
     * @param type $request
     *  @return type Json
     */
    public function getAvailability($request) {


        try {
            $user = JWTAuth::toUser($request->header('access_token')); // to get login user detail
            $model = $this->availability->where(['user_id' => $user->id])->get();
            return response()->json(['success' => true, 'data' => $model, 'message' => '']);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * delete availability
     * @return type Json
     */
    public function deleteAvailability($request) {


        try {
            $model = $this->availability->where(['id' => $request->id])->delete();
            if ($model) {
                return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['delete_availability']]);
            }
            return response()->json(['success' => false, 'data' => [], 'message' => 'Availabilty not found']);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * add Service
     * @param type $request(OBJ)
     * @return type Json
     */
    public function addService($request) {
        $response = [];
        $post = $request->all();
        $user = JWTAuth::toUser($request->header('access_token')); // to get login user detail
        $response['user_status'] = $user->status;
        try {
            foreach ($post['skills'] as $skill) {
                $model = new $this->mentorCategory();
                $model->user_id = $user->id;
                $model->category_id = $skill['category_id'];
                $model->service_id = $skill['service_id'];
                $model->exp_year = $skill['exp_year'];
                $model->exp_month = $skill['exp_month'];
                $model->amount = $skill['amount'];
                $model->level_of_knowledge = $skill['level_of_knowledge'];
                $model->save();
            }

            /**
             * to check mentor profile status as his portfolio ,skill and profile is complete or not
             * @param type userId
             * return type boolean
             */
            $response['profile_complete'] = checkMentorProfileStatus($user->id);
            return response()->json(['success' => true, 'data' => $response, 'message' => \StaticMessage::$app['skill_added']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * get mentor service list
     * @param type $request
     * @return Json
     */
    public function getService($request) {
        $post = $request->all();
        $user = JWTAuth::toUser($request->header('access_token')); // to get login user detail
        try {
            $services = $this->mentorCategory->where(['user_id' => $request->id])->get();
            foreach ($services as $service) {
                $service->category_name = $service->category->category_name;
                $service->service_name = $service->service->name;
            }
            return response()->json(['success' => true, 'data' => $services, 'message' => '']);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * delete mentor service
     * @param type $request (OBJ)
     * @return Json 
     */
    public function deleteService($request) {
        try {
            $services = $this->mentorCategory->where(['id' => $request->id])->delete();
            if ($services) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Service deleted successfully.']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Service not found.']);
            }
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * mentor home api 
     * @param type $request
     * @return type Json
     */
    public function mentorHome($request) {
        $data = [];
        $user = JWTAuth::toUser($request->header('access_token'));
        $today = "'" . date('Y-m-d') . "'";
        $data['today_appointment'] = \App\Models\Appointment::where(['date' => date('Y-m-d')])->count(); //to get today's appointment count
        $data['total_earning'] = 0.00;
        $today_availability = Availability::whereRaw("DATE(from_date_time) <= $today and DATE(to_date_time) >= $today and user_id =$user->id")->first(); // to get today's availabilty
        $data['today_from_availability'] = ($today_availability) ? $today_availability['from_date_time'] : '';
        $data['today_to_availability'] = ($today_availability) ? $today_availability['to_date_time'] : '';
        $data['address'] = ($today_availability) ? $today_availability['address'] : '';
        $data['latitude'] = ($today_availability) ? $today_availability->latitude : 0.0;
        $data['longitude'] = ($today_availability) ? $today_availability->longitude : 0.0;
        return $data;
    }

}
