<?php

/**
 * Description: this repository is used only for message related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Message;
use App\Models\Connection;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class MessageRepository {

    /**
     * Class Construct.
     * @param $message, $connection
     */
    public function __construct(Connection $connection, Message $message) {
        $this->message = $message;
        $this->connection = $connection;
    }

    /**
     * Get All Connections.
     * @param type $post
     * @return type array of object
     */
    public function getAllConnections($post) {
        try {
            $connectionList = $this->connection->orderBy('id', 'desc');
            /* Filter by from date and to date */
            if (!empty($post['from_date']) && !empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $to = date('Y-m-d', strtotime($post['to_date']));
                $connectionList->whereDate('created_at', '>=', $from)
                        ->whereDate('created_at', '<=', $to);
            }
            /* Filter by from date */
            if (!empty($post['from_date']) && empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $connectionList->whereDate('created_at', $from);
            }
            /* Filter by to date */
            if (!empty($post['to_date']) && empty($post['from_date'])) {
                $to = date('Y-m-d', strtotime($post['to_date']));
                $connectionList->whereDate('created_at', $to);
            }
            $rows = $connectionList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * change message's status
     * @param type $request
     * @return type json
     */
    public function changeConnectionStatus($request) {
        try {
            $post = $request->all();
            $connection_status = $this->connection->find($post['id']);
            if (empty($connection_status)) {
                return redirect()->back();
            }
            $connection_status->status = $post['status'];
            $connection_status->save();
            return response()->json(['success' => true, 'message' => \StaticMessage::$admin['change_status']]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Delete connections.
     * @param type $id
     * @return type json
     */
    public function deleteConnection($id) {
        try {
            $this->connection->where(['id' => $id])->delete();
            return response()->json(['success' => true, 'message' => \StaticMessage::$admin['connection_delete']]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * get user messages.
     * @param type $post
     * @return type array of object
     */
    public function getAllMessages($post) {
        try {
            $messageList = $this->message->select(['messages.*', 'from_user.profile_image', 'to_user.profile_image', 'from_user.role', 'to_user.role'])
                    ->join('users as from_user', 'from_user.id', '=', 'messages.from_id')
                    ->join('users as to_user', 'to_user.id', '=', 'messages.to_id')
                    ->where('connection_id', $post)
                    ->get();
            return $messageList;
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              