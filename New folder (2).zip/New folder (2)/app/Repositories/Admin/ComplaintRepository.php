<?php

/**
 * Description: this repository is used only for complaint related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Complaint;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class ComplaintRepository {

    /**
     * Class Construct.
     * @param $complaint
     */
    public function __construct(Complaint $complaint) {
        $this->complaint = $complaint;
    }

    /**
     * Get Complaint Data.
     * @param type $post
     * @return type array of object
     */
    public function getAllComplaints($post) {
        try {
            $complaintList = $this->complaint->orderBy('id', 'desc');
            $rows = $complaintList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * View complaint comments.
     * @param type $id
     * @return type json
     */
    public function getComplaintsView($id) {
        try {
            return $this->complaint->where(['id' => $id])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
