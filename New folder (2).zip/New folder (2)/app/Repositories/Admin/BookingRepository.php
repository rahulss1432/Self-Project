<?php

/**
 * Description: this repository is used only for booking related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : march 2019.
 */

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Appointment;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class BookingRepository {

    /**
     * Class Construct.
     * @param $appointment
     */
    public function __construct(Appointment $appointment) {
        $this->appointment = $appointment;
    }

    /**
     * Get Bookings Data.
     * @param type $post
     * @return type array of object
     */
    public function getAllBookings($post) {
        try {
            $bookingList = $this->appointment->orderBy('id', 'desc');
            /* Filter by from date and to date */
            if (!empty($post['from_date']) && !empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $to = date('Y-m-d', strtotime($post['to_date']));
                $bookingList->whereDate('created_at', '>=', $from)
                        ->whereDate('created_at', '<=', $to);
            }
            /* Filter by from date */
            if (!empty($post['from_date']) && empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $bookingList->whereDate('created_at', $from);
            }
            /* Filter by to date */
            if (!empty($post['to_date']) && empty($post['from_date'])) {
                $to = date('Y-m-d', strtotime($post['to_date']));
                $bookingList->whereDate('created_at', $to);
            }

            /* Filter By category */
            if (isset($post['category']) && !empty($post['category'])) {
                $bookingList->where('category_id', $post['category']);
            }

            /* Filter By Mentor Name */
            if (isset($post['mentor_name']) && !empty($post['mentor_name'])) {
                $searchData = $post['mentor_name'];
                $bookingList->whereHas('bookingToUser', function ($query) use ($searchData) {
                    $query->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $searchData . '%');
                });
            }

            /* Filter By User Name */
            if (isset($post['user_name']) && !empty($post['user_name'])) {
                $searchData = $post['user_name'];
                $bookingList->whereHas('bookingFromUser', function ($query) use ($searchData) {
                    $query->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $searchData . '%');
                });
            }
            /* Filter By Booking Id */
            if (isset($post['booking_id']) && !empty($post['booking_id'])) {
                $bookingList->where('reference_id', 'like', '%' . $post['booking_id'] . '%');
            }
            /* Filter by status on active inactive */
            if (isset($post['status']) && !empty($post['status'])) {
                $bookingList->where('status', $post['status']);
            }
            $rows = $bookingList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Manage Bookings Invoice.
     * @param type $id
     * @return type array of object
     */
    public function getInvoice($id) {
        try {
            return $this->appointment->where(['id' => $id])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
