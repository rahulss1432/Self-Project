<?php

/**
 * Description: this repository is used only for review and post related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Post;
use App\Models\Rating;
use App\Models\PostImage;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class PostRepository {

    /**
     * Class Construct.
     * @param $post,$rating,$postImage
     */
    public function __construct(Post $post, Rating $rating, PostImage $postImage) {
        $this->post = $post;
        $this->rating = $rating;
        $this->postImage = $postImage;
    }

    /**
     * Get Review Data.
     * @param type $post
     * @return type array of object
     */
    public function getAllReviews($post) {
        try {
            $reviewList = $this->rating->orderBy('id', 'desc');
            /* Filter by from date and to date */
            if (!empty($post['from_date']) && !empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $to = date('Y-m-d', strtotime($post['to_date']));
                $reviewList->whereDate('created_at', '>=', $from)
                        ->whereDate('created_at', '<=', $to);
            }
            /* Filter by from date */
            if (!empty($post['from_date']) && empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $reviewList->whereDate('created_at', $from);
            }
            /* Filter by to date */
            if (!empty($post['to_date']) && empty($post['from_date'])) {
                $to = date('Y-m-d', strtotime($post['to_date']));
                $reviewList->whereDate('created_at', $to);
            }
            $rows = $reviewList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Get Post Data.
     * @param type $post
     * @return type array of object
     */
    public function getAllPosts($post) {
        try {
            $postList = $this->post->orderBy('id', 'desc');
            /* Filter by from date and to date */
            if (!empty($post['from_date']) && !empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $to = date('Y-m-d', strtotime($post['to_date']));
                $postList->whereDate('created_at', '>=', $from)
                        ->whereDate('created_at', '<=', $to);
            }
            /* Filter by from date */
            if (!empty($post['from_date']) && empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $postList->whereDate('created_at', $from);
            }
            /* Filter by to date */
            if (!empty($post['to_date']) && empty($post['from_date'])) {
                $to = date('Y-m-d', strtotime($post['to_date']));
                $postList->whereDate('created_at', $to);
            }
            $rows = $postList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * View post and review comments.
     * @param type $id and $type
     * @return type json
     */
    public function getPostCommentView($id, $type) {
        try {
            if ($type == "post") {
                return $this->post->where(['id' => $id])->first();
            } else {
                return $this->rating->where(['id' => $id])->first();
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * View post images.
     * @param type $id
     * @return type json
     */
    public function getPostImageView($id) {
        try {
            return $this->postImage->where(['post_id' => $id])->get();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * function using for delete review and post
     * @param type $id and $type (post and review)
     * @return type json
     */
    public function removePostReview($id, $type) {
        try {
            if ($type == "post") {
                $this->post->where(['id' => $id])->delete();
                return response()->json(['success' => true, 'message' => \StaticMessage::$admin['post_delete']]);
            } else {
                $this->rating->where(['id' => $id])->delete();
                return response()->json(['success' => true, 'message' => \StaticMessage::$admin['review_delete']]);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
