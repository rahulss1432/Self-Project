<?php

/**
 * Description: this repository is used only for user(mentor and mentee) related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;
use App\Models\Availability;
use App\Models\Portfolio;
use App\Models\MentorCategory;

Class UserRepository {

    /**
     * Class Construct.
     * @param User $user
     */
    public function __construct(User $user) {
        $this->user = $user;
    }

    /**
     * Get User(mentee) Data.
     * @param type $post
     * @return type array of object
     */
    public function getAllUsers($post) {
        try {
            $userList = $this->user->where(['role' => 'user']);
            /* Filter By Name */
            if (isset($post['name']) && !empty($post['name'])) {
                $searchData = $post['name'];
                $userList->where(function($query) use($searchData) {
                    $query->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $searchData . '%');
                });
            }
            /* Filter By Email */
            if (isset($post['email']) && !empty($post['email'])) {
                $userList->where('email', 'like', '%' . $post['email'] . '%');
            }
            /* Filter by status on active inactive */
            if (isset($post['status']) && !empty($post['status'])) {
                $userList->where('status', $post['status']);
            }
            $rows = $userList->orderBy('id', 'desc')->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * change  users's status
     * @param type $request
     * @return type json
     */
    public function changeUserStatus($request) {
        try {
            $post = $request->all();
            $user_status = $this->user->find($post['id']);
            if (empty($user_status)) {
                return redirect()->back();
            }
            $user_status->status = $post['status'];
            $user_status->save();
            return response()->json(['success' => true, 'message' => \StaticMessage::$admin['change_status']]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * load user profile
     * @param type $request
     * @return type json
     */
    public function loadUserProfile($request) {
        try {
            return $this->user->where('id', $request['id'])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * admin change password.
     * @param  type $request
     * @return type json
     */
    public function updatePassword($request) {

        try {
            $post = $request->all();
            $user = $this->user->find($post['id']);
            if (!\Hash::check($post['current_password'], $user->password)) {
                return json_encode(array('success' => false, 'message' => \StaticMessage::$admin['confirm_password']));
            } else {
                $user->update(array('password' => bcrypt($request['new_password'])));
            }
            return json_encode(array('success' => true, 'message' => \StaticMessage::$admin['change_password']));
        } catch (\Exception $e) {
            return json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
    }

    /**
     * Get Contractor(mentor) Data
     * @param  type $post
     * @return type array of object
     */
    public function getContractorList($post) {
        try {
            $userList = $this->user->where(['role' => 'mentor'])->where('status', '<>', 'disapprove');
            /* Filter By Name */
            if (isset($post['name']) && !empty($post['name'])) {
                $searchData = $post['name'];
                $userList->where(function($query) use($searchData) {
                    $query->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $searchData . '%');
                });
            }
            /* Filter By Email */
            if (isset($post['email']) && !empty($post['email'])) {
                $userList->where('email', 'like', '%' . $post['email'] . '%');
            }
            /* Filter by status on active inactive */
            if (isset($post['status']) && !empty($post['status'])) {
                $userList->where('status', $post['status']);
            }

            $rows = $userList->orderBy('id', 'desc')->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * update contractor(mentor) status 
     * @param type $request
     * @return type json
     */
    public function updateContractorStatus($request) {
        try {
            $post = $request->all();
            $status = $this->user->find($post['id']);
            if (empty($status)) {
                return redirect()->back();
            }
            $status->status = $post['status'];
            $status->save();
            return response()->json(['success' => true, 'message' => \StaticMessage::$admin['change_status']]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * function using for delete contractor user
     * @param type $id
     * @return type json
     */
    public function removeContractor($id) {
        try {
            $this->user->where(['id' => $id])->delete();
            return response()->json(['success' => true, 'message' => \StaticMessage::$admin['mentor_delete']]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * get user details by id  
     * @param type $id
     * @return type json
     */
    public function getUserById($id) {
        try {
            return $this->user->find($id);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Get Pending Contractor(mentor) Data
     * @param type $post
     * @return type array of object
     */
    public function getPendingContractorList($post) {
        try {
            $userList = $this->user->where(['role' => 'mentor', 'status' => 'disapprove']);
            /* Filter By Name */
            if (isset($post['name']) && !empty($post['name'])) {
                $searchData = $post['name'];
                $userList->where(function($query) use($searchData) {
                    $query->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $searchData . '%');
                });
            }
            /* Filter By Email */
            if (isset($post['email']) && !empty($post['email'])) {
                $userList->where('email', 'like', '%' . $post['email'] . '%');
            }
            /* Filter by status on active inactive */
            if (isset($post['status']) && !empty($post['status'])) {
                $userList->where('status', $post['status']);
            }
            $rows = $userList->orderBy('id', 'desc')->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * function using for get availability by user id
     * @param type $userId
     * @return type array of object
     */
    public function getAvailability($userId) {
        try {
            $availability = Availability::where('user_id', $userId)->get();
            return $availability;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * function using for get document by user id
     * @param type $userId
     * @return type array of object
     */
    public function getDocument($userId) {
        try {
            $document = Portfolio::where('user_id', $userId)->get();
            return $document;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * function using for get category by user id
     * @param type $userId
     * @return type array of object
     */
    public function getCategory($userId) {
        try {
            $category = MentorCategory::where('user_id', $userId)->get();
            return $category;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * function using for delete mentee user
     * @param type $id
     * @return type json
     */
    public function removeUser($id) {
        try {
            $this->user->where(['id' => $id])->delete();
            return response()->json(['success' => true, 'message' => \StaticMessage::$admin['mentee_delete']]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
