<?php

/**
 * Description: this repository is used only for payment report related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Transaction;
use App\Models\Setting;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class PaymentRepository {

    /**
     * Class Construct.
     * @param $transaction, $setting
     */
    public function __construct(Transaction $transaction, Setting $setting) {
        $this->transaction = $transaction;
        $this->setting = $setting;
    }

    /**
     * get payment list data.
     * @param type $post
     * @return type array of object
     */
    public function getAllPayments($post) {
        try {
            $paymentList = $this->transaction->orderBy('id', 'desc');
            /* Filter by from date and to date */
            if (!empty($post['from_date']) && !empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $to = date('Y-m-d', strtotime($post['to_date']));
                $paymentList->whereDate('created_at', '>=', $from)
                        ->whereDate('created_at', '<=', $to);
            }
            /* Filter by from date */
            if (!empty($post['from_date']) && empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $paymentList->whereDate('created_at', $from);
            }
            /* Filter by to date */
            if (!empty($post['to_date']) && empty($post['from_date'])) {
                $to = date('Y-m-d', strtotime($post['to_date']));
                $paymentList->whereDate('created_at', $to);
            }
            /* Filter By Booking Id */
            if (isset($post['booking_id']) && !empty($post['booking_id'])) {
                $searchData = $post['booking_id'];
                $paymentList->whereHas('transactionBooking', function ($query) use ($searchData) {
                    $query->where('reference_id', 'like', '%' . $searchData . '%');
                });
            }
            /* Filter By Mentors name */
            if (isset($post['mentor_name']) && !empty($post['mentor_name'])) {
                $paymentList->where('mentor_id', $post['mentor_name']);
            }
            /* Filter By Users name */
            if (isset($post['user_name']) && !empty($post['user_name'])) {
                $paymentList->where('user_id', $post['user_name']);
            }
            $rows = $paymentList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * commission update method
     * @param type $post
     * @return type json
     */
    public function editCmmission($post) {
        try {
            $model = $this->setting->where('key', $post['commission_key'])->first();
            $model->value = $post['commission'];
            $model->save();
            return response()->json(['success' => true, 'message' => \StaticMessage::$admin['commission_update']]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
