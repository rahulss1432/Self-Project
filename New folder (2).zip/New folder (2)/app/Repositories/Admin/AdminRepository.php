<?php

/**
 * Description: this repository is used only for admin forget and reset password related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Notification;
use Auth;

Class AdminRepository {

    /**
     * Class Construct.
     * @param $notification
     */
    public function __construct(Notification $notification) {
        $this->notification = $notification;
    }

    /**
     * Get forget password page.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function forgotPassword() {
        try {
            return view('admin::forget-password.forgot-password');
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Get reset password page.
     * @param type user token
     * @return type array of object
     */
    public function resetPassword($token) {
        try {
            return view('admin::forget-password.password_reset', ['token' => $token]);
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Admin notification list on modal.
     * @param null
     * @return type array of object
     */
    public function getNotificationList() {
        $userId = Auth::guard('admin')->user()->id; // to get login user(admin) id
        $notificationList = $this->notification->where(['to_id' => $userId])->take(5)->orderBy('id', 'desc')->get();
        return $notificationList;
    }

    /**
     * Admin notification list on view.
     * @param null
     * @return type array of object
     */
    public function getAllNotificationList() {
        $userId = Auth::guard('admin')->user()->id; // to get login user(admin) id
        $notificationList = $this->notification->where(['to_id' => $userId])->orderBy('id', 'desc')->paginate(10);
        return $notificationList;
    }

}
