<?php

/**
 * Description: this repository is used only for cms related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Faq;
use App\Models\Cms;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class CmsRepository {

    /**
     * Class Construct.
     * @param $faq, $cms
     */
    public function __construct(Faq $faq, Cms $cms) {
        $this->faq = $faq;
        $this->cms = $cms;
    }

    /**
     * Get Faq Data.
     * @param type $post
     * @return type array of object
     */
    public function getAllFaqs($post) {
        try {
            $faqList = $this->faq->orderBy('id', 'desc');
            $rows = $faqList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * add and edit faq method.
     * @param type $post
     * @return type json
     */
    public function addFaqs($post) {
        try {
            if (isset($post['faq_id'])) {
                $model = $this->faq->find($post['faq_id']);
            } else {
                $model = new $this->faq;
            }
            $model->question = $post['question'];
            $model->answer = $post['answer'];
            $model->save();
            if (isset($post['faq_id'])) {
                return response()->json(['success' => true, 'message' => \StaticMessage::$admin['faq_update']]);
            } else {
                return response()->json(['success' => true, 'message' => \StaticMessage::$admin['faq_add']]);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Delete faqs.
     * @param type $id
     * @return type json
     */
    public function deleteFaqs($id) {
        try {
            $this->faq->where(['id' => $id])->delete();
            return response()->json(['success' => true, 'message' => \StaticMessage::$admin['faq_delete']]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Edit faqs data.
     * @param type $id
     * @return type json
     */
    public function showEditFaqs($id) {
        try {
            return $this->faq->where(['id' => $id])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Get Cms Data.
     * @param type $post
     * @return type array of object.
     */
    public function getAllCms($post) {
        try {
            $cmsList = $this->cms->orderBy('id', 'desc');
            $rows = $cmsList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Edit cms data.
     * @param type $id
     * @return type json.
     */
    public function showEditCms($id) {
        try {
            return $this->cms->where(['id' => $id])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * edit cms method
     * @param type $post
     * @return type json.
     */
    public function editCms($post) {
        try {
            if (isset($post['cms_id'])) {
                $model = $this->cms->find($post['cms_id']);
            } else {
                $model = new $this->cms;
            }
            $model->title = $post['title'];
            $model->description = $post['description'];
            $model->save();
            if (isset($post['cms_id'])) {
                return response()->json(['success' => true, 'message' => \StaticMessage::$admin['cms_update']]);
            } else {
                return response()->json(['success' => true, 'message' => \StaticMessage::$admin['cms_add']]);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
