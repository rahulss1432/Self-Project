<?php

/**
 * Description: this repository is used only for dashboard related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Models\Transaction;
use App\Models\Category;

Class DashboardRepository {

    public function __construct() {
        
    }

    /**
     * Get all dashboard data.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        try {
            return view('admin::dashboard.index');
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * function using for count all events on admin dashboard.
     * @param type $post(array) and $type of single parameter.
     * @return type array of object
     */
    public function getDetailBytype($post, $type) {
        if ($type == 'mentor') { // get data only mentor user
            $eventData = User::where('role', '<>', 'admin')->where('role', '<>', 'user')->where('status', '<>', 'disapprove');
            /* Filter By Country id */
            if (isset($post['country_id']) && !empty($post['country_id'])) {
                $eventData->where('country_id', $post['country_id']);
            }
            /* Filter By State id */
            if (isset($post['state_id']) && !empty($post['state_id'])) {
                $eventData->where('state_id', $post['state_id']);
            }
            /* Filter By City Id */
            if (isset($post['city_id']) && !empty($post['city_id'])) {
                $eventData->where('city', $post['city_id']);
            }
            $eventData = $eventData->count();
        }
        if ($type == 'user') { // get data only mentee user
            $eventData = User::where('role', '<>', 'admin')->where('role', '<>', 'mentor');
            /* Filter By Country id */
            if (isset($post['country_id']) && !empty($post['country_id'])) {
                $eventData->where('country_id', $post['country_id']);
            }
            /* Filter By State id */
            if (isset($post['state_id']) && !empty($post['state_id'])) {
                $eventData->where('state_id', $post['state_id']);
            }
            /* Filter By City Id */
            if (isset($post['city_id']) && !empty($post['city_id'])) {
                $eventData->where('city', $post['city_id']);
            }
            $eventData = $eventData->count();
        }
        if ($type == 'total_earned') { // get data only mentor total earning
            $eventData = Transaction::select('transactions.total_amount')
                    ->join('users', 'users.id', 'transactions.mentor_id');
            /* Filter By Country id */
            if (isset($post['country_id']) && !empty($post['country_id'])) {
                $eventData->where('users.country_id', $post['country_id']);
            }
            /* Filter By State id */
            if (isset($post['state_id']) && !empty($post['state_id'])) {
                $eventData->where('users.state_id', $post['state_id']);
            }
            /* Filter By City Id */
            if (isset($post['city_id']) && !empty($post['city_id'])) {
                $eventData->where('users.city', $post['city_id']);
            }
            $eventData = $eventData->where('users.role', 'mentor')->sum('transactions.total_amount');
        }
        if ($type == 'category') { // get data only mentor total categories
            $eventData = Category::select('categories.*');
            /* Filter By Country id */
            if (isset($post['country_id']) && !empty($post['country_id'])) {
                $eventData->leftjoin('mentor_categories', 'categories.id', 'mentor_categories.category_id')
                        ->leftjoin('users', 'users.id', 'mentor_categories.user_id')
                        ->where('users.role', 'mentor')
                        ->where('users.country_id', $post['country_id']);
            }
            /* Filter By State id */
            if (isset($post['state_id']) && !empty($post['state_id'])) {
                $eventData->leftjoin('mentor_categories', 'categories.id', 'mentor_categories.category_id')
                        ->leftjoin('users', 'users.id', 'mentor_categories.user_id')
                        ->where('users.role', 'mentor')
                        ->where('users.state_id', $post['state_id']);
            }
            /* Filter By City Id */
            if (isset($post['city_id']) && !empty($post['city_id'])) {
                $eventData->leftjoin('mentor_categories', 'categories.id', 'mentor_categories.category_id')
                        ->leftjoin('users', 'users.id', 'mentor_categories.user_id')
                        ->where('users.role', 'mentor')
                        ->where('users.city', $post['city_id']);
            }
            $eventData = $eventData->count();
        }
        return $eventData;
    }

    /**
     * function using for top 20 users on admin dashboard.
     * @param type $post
     * @return type array of object
     */
    public function getUsersOnDashboard($post) {
        $userData = User::where('role', '<>', 'admin')->where('role', '<>', 'user')->where('status', '<>', 'disapprove');
        /* Filter By Country id */
        if (isset($post['country_id']) && !empty($post['country_id'])) {
            $userData->where('country_id', $post['country_id']);
        }
        /* Filter By State id */
        if (isset($post['state_id']) && !empty($post['state_id'])) {
            $userData->where('state_id', $post['state_id']);
        }
        /* Filter By City Id */
        if (isset($post['city_id']) && !empty($post['city_id'])) {
            $userData->where('city', $post['city_id']);
        }
        return $userData->take(20)->orderBy('id', 'desc')->paginate(10);
    }

}
