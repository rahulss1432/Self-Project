<?php

/**
 * Description: this helper file is used only for common function related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */
use Carbon\Carbon;
use App\Models\Service;
use App\Models\Category;
use App\User;
use App\Models\Offer;
use App\Models\Setting;
use App\Models\Rating;
use App\Models\Transaction;
use App\Models\Message;
use App\Models\Country;
use App\Models\State;
use App\Models\City;
use App\Models\MentorCategory;
use App\Models\Portfolio;
use App\Models\Availability;

/**
 * function using for send email
 * @param type $data
 * @return boolean
 */
function sendMail($data) {
    try {
        switch ($data['request']) {
            case "admin_forgot_password":
                Mail::send('admin::emails.admin_forgot_password', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(env('FROM_EMAIL'), 'Mentor Locator')
                            ->subject($data['subject']);
                });
                break;
            case "send_otp":
                Mail::send('admin::emails.send_otp', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(env('FROM_EMAIL'), 'Mentor Locator')
                            ->subject($data['subject']);
                });
                break;
            case "reset_token":
                Mail::send('admin::emails.reset_token', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(env('FROM_EMAIL'), 'Mentor Locator')
                            ->subject($data['subject']);
                });
                break;
            case "contact_us":
                Mail::send('admin::emails.contact_us', ['data' => $data], function ($message) use ($data) {
                    $message->to('swapnilk@neuronsolutions.com')
                            ->from(env('FROM_EMAIL'), 'Mentor Locator')
                            ->subject($data['subject']);
                });
                break;
            default:
                break;
        }
        return true;
    } catch (Exception $e) {
        return $e->getMessage();
    }
}

/**
 * function using for get full name
 * @param type $firstName and $lastName(array of object)
 * @return string
 */
function getFullName($firstName, $lastName) {
    return ucfirst($firstName) . ' ' . ucfirst($lastName);
}

/**
 * show created date format from database like d-m-Y
 * @param type $date
 * @return string
 */
function showDateFormat($date) {
    $dateFormat = getSetting('date_format');
    return date($dateFormat, strtotime($date));
}

/**
 * for date time 25 Feb 2019 10:58 AM
 * @param type $string
 * @return string
 */
function timeFormat($string) {
    return Carbon::parse($string)->format('d M Y h:i A');
}

/**
 * for date format Thursday, Jan 03rd 2019
 * @param type $date
 * @return string
 */
function showDateTimeFormat($date) {
    return date('l M j<\s\up>S</\s\up> Y', strtotime($date));
}

/**
 * for date format 2019-03-01 10:41:16
 * @param type $string
 * @return string
 */
function dateTimeFormat($string) {
    $dateFormat = getSetting('date_time_format');
    return date($dateFormat, strtotime($string));
//    return Carbon::parse($string)->format('d<\s\up>S</\s\up> M Y, h.i A');
}

/**
 * for start and end date format
 * @param type $start and $end
 * @return string
 */
function startEndDateFormat($start, $end) {
    $startDate = date('M d, Y', strtotime($start));
    $endDate = date('M d, Y', strtotime($end));
    return $startDate . ' - ' . $endDate;
}

/**
 * for start and end time format
 * @param type $start and $end
 * @return string
 */
function startEndTimeFormat($start, $end) {
    $startTime = date('H.i A', strtotime($start));
    $endTime = date('H.i A', strtotime($end));
    return $startTime . ' - ' . $endTime;
}

/**
 * chat listing time conversion function
 * @param type $created_at
 * @return string
 */
function chatTimeShow($created_at) {
    $full = false;
    $now = new Carbon(date('Y-m-d H:i:s')); // for using date format
    $ago = new Carbon($created_at);
    $diff = $now->diff($ago);
    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;
    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }
    if (!$full)
        $string = array_slice($string, 0, 1);
    echo $string ? implode(', ', $string) . ' ago' : 'just now';
}

/**
 * Check image url and set image path
 * @param type $image and $folder
 * @return src path
 */
function checkUserImage($image, $folder = null) {
    $src = url('public/images/default-user.png');
    $fileName = public_path() . '/uploads/' . $folder . '/' . $image;
    if (!empty($image) && file_exists($fileName)) {
        $src = url('public/uploads/' . $folder . '/' . $image);
    }
    return $src;
}

/**
 * Check service counts by category
 * @param type $categoryId
 * @return array of object count
 */
function getServiceCount($categoryId) {
    $serviceCount = Service::where('category_id', $categoryId)->count();
    return $serviceCount;
}

/**
 * get all category 
 * @param null
 * @return array of object
 */
function getAllCategories() {
    $category = Category::get();
    return $category;
}

/**
 * function using for get notifications count
 * @param type $userId
 * @return array of object count
 */
function getNotificationCount($userId) {
    $notificationCount = \App\Models\Notification::where('to_id', $userId)->count();
    return $notificationCount;
}

/**
 * Get Unread Notification Count By Admin
 * @param type $userId
 * @return array of object
 */
function loadNotificationCount($userId) {
    $notification = App\Models\Notification::where('to_id', $userId)->where('is_read', 0)->count();
    return $notification;
}

/**
 * Update Unread Notification By Admin
 * @param type $userId
 * @return array of object
 */
function updateNotificationList($userId) {
    $notification = \App\Models\Notification::where('to_id', $userId)->where('is_read', 0)->update(['is_read' => 1]);
    return $notification;
}

/**
 * get users by role
 * @param type $role
 * @return array of object
 */
function getUserByRole($role) {
    $users = User::where('role', $role)->get();
    return $users;
}

/**
 * Check category icon url and set icon path
 * @param type $image and $folder
 * @return src path
 */
function checkCategoryIcon($image, $folder = null) {
    $src = url('public/images/blue-logo.png');
    $fileName = public_path() . '/uploads/' . $folder . '/' . $image;
    if (!empty($image) && file_exists($fileName)) {
        $src = url('public/uploads/' . $folder . '/' . $image);
    }
    return $src;
}

/**
 * Check post image
 * @param type $image and $folder
 * @return src path
 */
function checkPostImage($image, $folder = null) {
    $src = url('public/images/default-media.jpg');
    $fileName = public_path() . '/uploads/' . $folder . '/' . $image;
    if (!empty($image) && file_exists($fileName)) {
        $src = url('public/uploads/' . $folder . '/' . $image);
    }
    return $src;
}

/**
 * Function for text char limit.
 * @param type $limit(set number) and $text
 * @return string
 */
function getLimitText($limit, $text) {
    $string = substr($text, 0, $limit);
    if (strlen($text) >= $limit) {
        $string .= '...';
    };
    return $string;
}

/**
 * function using for get service by offer id from offer model
 * @param type $offerId
 * @return array of object
 */
function getServiceByOffer($offerId) {
    $offerServices = Offer::where('id', $offerId)->first();
    $serviceId = Service::where('id', $offerServices['service_id'])->first();
    return !empty($serviceId['name']) ? $serviceId['name'] : '-';
}

/**
 * Get Common Setting
 * @param type $key
 * @return array of object
 */
function getSetting($key) {
    $data = Setting::select('value')->where('key', $key)->first();
    return !empty($data->value) ? $data->value : '-';
}

/**
 * Get average rating
 * @param type $user_id
 * @return array of object
 */
function getAverageRating($user_id) {
    $data = [];
    $average_rating = Rating::where(['to_id' => $user_id])->groupBy('to_id')->avg('rating');
    $data['average'] = ($average_rating) ? $average_rating : 0;
    $data['count'] = Rating::where(['to_id' => $user_id])->groupBy('to_id')->count();
    return $data;
}

/**
 * get ratings by user id
 * @param type $userId
 * @return array of object
 */
function getRatingsByUserId($userId) {
    $getRatings = Rating::select(DB::raw('avg(rating) AS avgRating'))
                    ->join('users', 'users.id', 'ratings.to_id')
                    ->where('ratings.to_id', $userId)
                    ->groupBy('ratings.to_id')->get();
    return $getRatings;
}

/**
 * get user experience by user id in master category table
 * @param type $userId
 * @return string
 */
function getExperienceByUserId($userId) {
    $getExperience = MentorCategory::where('user_id', $userId)->orderBy('exp_year', 'desc')->orderBy('exp_month', 'desc')->first();
    $expYear = !empty($getExperience->exp_year) ? $getExperience->exp_year . ' year ' : '';
    $expMonth = !empty($getExperience->exp_month) ? $getExperience->exp_month . ' month' : '';
    return $getExperience = $expYear . $expMonth;
}

/**
 * get ratings by user id
 * @param type $userId
 * @return array of object
 */
function totalEarning($userId) {
    $getRatings = Transaction::where([''])->sum('');
    return $getRatings;
}

/**
 * get unread message count
 * @param type $user_id
 * @return array of object
 */
function getUnreadCount($user_id) {
    return Message::where(['to_id' => $user_id, 'is_read' => 0])->count();
}

/**
 * function for get all country name.
 * @param type $request
 * @return html
 */
function getAllCountry($request) {
    $countries = Country::all();
    foreach ($countries as $country) {
        echo "<option value='$country->id'>$country->name</option>";
    }
}

/**
 * function for get state name by country id.
 * @param type $request
 * @return html
 */
function getStatesByCountryId($request) {
    $states = State::where('country_id', $request['country_id'])->get();
    $html = '';
    foreach ($states as $state) {
        $html .= "<option value='$state->id'>$state->name</option>";
    }
    return $html;
}

/**
 * function for get city name by state id.
 * @param type $request
 * @return html
 */
function getCitiesByStateId($request) {
    $cities = City::where('state_id', $request['state_id'])->get();
    $html = '';
    foreach ($cities as $city) {
        $html .= "<option value='$city->id'>$city->name</option>";
    }
    return $html;
}

/**
 * Get user data
 * @param type $id and $column
 * @return array of object
 */
function getUserData($id, $column) {
    $data = User::where('id', $id)->first([$column]);
    if ($data) {
        return $data->$column;
    } else {
        return [];
    }
}

/**
 * get mentors availability by user id and date
 * @param type $userId
 * @param string $date 
 * @return type object
 */
function getMentorAvailability($userId, $date) {
    $date = "'" . $date . "'";
    $getData = Availability::where('user_id', $userId)
                    ->whereRaw("DATE(from_date_time) <= $date and DATE(to_date_time) >= $date")->first();
    return $getData;
}

/**
 * to check mentor profile status as his portfolio ,skill and profile is complete or not
 * @param type $mentor_id
 * @return boolean
 */
function checkMentorProfileStatus($mentor_id) {
    $user = User::where(['id' => $mentor_id])->first();
    $port_folio_count = Portfolio::where(['user_id' => $mentor_id])->count();
    $skill_count = MentorCategory::where(['user_id' => $mentor_id])->count();
    if ($port_folio_count != 0 && $skill_count != 0 && (!empty($user['phone_number']) || !empty($user['date_of_birth']) || !empty($user['address']) || !empty($user['country_id']) || !empty($user['state_id']) || !empty($user['city']))) {
        return true;
    }return false;
}
