<?php

/**
 * Description: this service provider file is used only for custom validation related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : february 2019.
 */

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;
use DB;
use Illuminate\Support\Facades\Hash;
use JWTAuth;
use Illuminate\Support\Facades\Input;

class AppServiceProvider extends ServiceProvider {

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot() {

        /**
         * this method using for custom check email format
         * @param type $attribute,$value,$parameters,$validator
         * @return boolean
         */
        Validator::extend('check_email_format', function ($attribute, $value, $parameters, $validator) {
            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                return false;
            } else {
                return true;
            }
        });

        /**
         * this method using for custom valid email format
         * @param type $attribute,$value,$parameters,$validator
         * @return boolean
         */
        Validator::extend('valid_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->get();
            if ($user->count() > 0) {
                return true;
            } else {
                return false;
            }
        });

        /**
         * this method using for custom valid number files
         * @param type $attribute,$value,$parameters,$validator
         * @return boolean
         */
        Validator::extend('valid_number_file', function ($attribute, $value, $parameters, $validator) {
            $post = Input::all();
            if (count($post['links']) > 9) {
                return false;
            } else {
                return true;
            }
        });

        /**
         * this method using for custom check email type
         * @param type $attribute,$value,$parameters,$validator
         * @return boolean
         */
        Validator::extend('admin_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->where('role', '=', 'admin')->get();
            if ($user->count() > 0) {
                return true;
            } else {
                return false;
            }
        });

        /**
         * this method using for custom check for current password is valid or not on web side
         * @param type $attribute,$value,$parameters,$validator
         * @return boolean
         */
        Validator::extend('current_password_match', function ($attribute, $value, $parameters, $validator) {
            return Hash::check($value, Auth::guard('admin')->user()->password);
        });

        /**
         * this method using for custom check for current password is valid or not on api side
         * @param type $attribute,$value,$parameters,$validator
         * @return boolean
         */
        Validator::extend('current_password_match_api', function ($attribute, $value, $parameters, $validator) {
            $user = JWTAuth::toUser(request()->header('access_token'));
            return Hash::check($value, $user['password']);
        });

        /**
         * this method using for custom check no spaces contain in field
         * @param type $attribute,$value,$parameters,$validator
         * @return boolean
         */
        Validator::extend('remove_spaces', function($attribute, $value, $parameters, $validator) {
            if (trim($value) == '') {
                return false;
            }
            return true;
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register() {
        //
    }

}
