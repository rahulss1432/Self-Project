<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use App\Http\Models\CallRequest;
use JWTAuth;

class Ticket extends Model {

    // N: get user for send missed notification
    public static function missedNotification($post) {
        if ($post) {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $ticketData = Ticket::select('id')->where(['ticket_number' => $post['ticket_id']])->first();
            if (!empty($ticketData)) {
                if($user->role == "customer"){
                    return $callRequestData = CallRequest::where('ticket_id', $ticketData->id)
                            ->where(function($q) {
                                $q->where('status', 'missed_request')
                                  ->orWhere('status', 'ringing');
                            })->groupBy('executive_id')->get();
                } else {
                    $request = $callRequestData = CallRequest::where(['ticket_id'=> $ticketData->id,'executive_id'=>$user->id])
                            ->where(function($q) {
                                $q->where('status', 'missed_request')
                                  ->orWhere('status', 'ringing');
                            })->orderBy('id','desc')->first();
                            //})->groupBy('customer_id')->get();
                            $arr[] = $request;
                            return $arr;
                }
            }
            return false;
        }
        return false;
    }

}
