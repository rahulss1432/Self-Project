<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ExecutiveManagerRelation extends Model {

    protected $table = 'executive_manager_relations';

    /*
     * get customers by executive id
     */

    public static function getCustomerByExecutiveId($executiveId) {
        return CustomerExecutiveRelation::where('executive_id', $executiveId)->get();
    }

    /*
     * get executives by executive id
     */

    public static function getExecutiveByCustomerId($executiveId) {
        return CustomerExecutiveRelation::where('customer_id', $executiveId)->get();
    }

    /*
     * get executives count under manager id
     */

    public static function getAllExectiveCountByManager($id) {
        return \App\Http\Models\ExecutiveManagerRelation::where('manager_id', $id)->count();
    }

    public static function getCustomerByExecutiveAdmin($executiveId) {
        $data = ExecutiveManagerRelation::where('executive_id', $executiveId)->first();
        return $data['manager_id'];
    }

    public static function getManagerByCustomer($customerId) {
        $data = CustomerExecutiveRelation::where('customer_id', $customerId)->first();
        return $data['manager_id'];
    }

    /* Rahul : get manager by executive */
    public static function getManagerByExecutiveId($execuitveId) {
        $data = ExecutiveManagerRelation::where('executive_id', $execuitveId)->first();
        return $data['manager_id'];
    }

}
