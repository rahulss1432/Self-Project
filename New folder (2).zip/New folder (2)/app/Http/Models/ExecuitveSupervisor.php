<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ExecuitveSupervisor extends Model {

    protected $table = 'execuitve_supervisors';

}
