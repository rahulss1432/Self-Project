<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use App\Common\Utility;
use App\Http\Models\Notification;

class AdminContact extends Model {

    public static function addAdminContact($request) {
        $contact = new AdminContact();
        $contact->name = $request->name;
        $contact->business_name = $request->business_name;
        $contact->phone_no = $request->phone_no;
        $contact->email = $request->email;
        $contact->message = $request->message;
        if ($contact->save()) {
            if($request->device_type == "" || $request->device_type == "string"){
                $message = "You have received an inquiry through the android app";
            } else {
                $message = "You have received an inquiry through the ".$request->device_type." app";
            }
            $data = [
                'notification_type' => 'contact_admin'
            ];
            Utility::saveNotification(1, $message, 'contact_admin', $data, 1);
            /* N:- send mail function for admin contact */
            $data = [];
            $data['name'] = $request->name;;
            $data['business_name'] = $request->business_name;
            $data['email'] = $request->email;
            $data['phone_no'] = $request->phone_no;
            $data['subject'] = 'Contact Request';
            $data['request'] = 'contact_mail';
            $data['message'] = $request->message;
            $mail = sendMail($data);
            return true;
        }
        
        return false;
    }

    public static function getContactAdminList($post) {
        $contactAdmin = AdminContact::select('admin_contacts.*');
        if (isset($post['name']) && !empty($post['name'])) {
            $contactAdmin->where('name', 'like', '%' . $post['name'] . '%');
        }
        return $contactAdmin->orderBy('id', 'desc')->paginate(10);
    }

}
