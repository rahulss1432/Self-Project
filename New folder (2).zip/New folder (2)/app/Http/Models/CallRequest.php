<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use App\Http\Models\User;
use App\Http\Models\ExecutiveCategory;
use JWTAuth;
use App\Common\Utility;
use App\Http\Models\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Pagination\LengthAwarePaginator;

class CallRequest extends Model {
    /*
     * relation with user table by customer_id
     */

    public function customerDetail() {
        return $this->belongsTo('App\Http\Models\User', 'customer_id');
    }

    /*
     * relation with user table by executive_id
     */

    public function executiveDetail() {
        return $this->belongsTo('App\Http\Models\User', 'executive_id');
    }

    /*
     * relation with category table by category_id
     */

    public function BankCategory() {
        return $this->belongsTo('App\Http\Models\BankingCategory', 'category_id');
    }

    /*
     * relation with user profile table by customer_id
     */

    public function UserProfile() {
        return $this->belongsTo('App\Http\Models\UserProfile', 'customer_id', 'user_id');
    }

    /*
     * relation with rating table by customer_id
     */

    public function customerRating() {
        return $this->belongsTo('App\Http\Models\Rating', 'customer_id', 'customer_id');
    }

    /*
     * get resolved call request by executive id
     */

    public static function getResolveCallRequestByExecutive($executive_id, $callFrom) {
        $lists = CallRequest::where('executive_id', '=', $executive_id)->where('status', '=', 'resolved');
        $lists->groupBy('ticket_id');
        $lists->groupBy('executive_id');
        if ($callFrom == 'count') {

            return $lists->get()->count();
        } else {
            return $lists->paginate(10);
        }
    }

    /*
     * get pending call request by executive id
     */

    public static function getPendingCallRequestByExecutive($executive_id, $callFrom) {
        $lists = CallRequest::where('executive_id', '=', $executive_id)
                ->where(function ($lists) {
            $lists->where('status', 'pending')
            ->orWhere('status', 'missed_request');
        });
        $lists->groupBy('ticket_id');
        $lists->groupBy('executive_id');
        if ($callFrom == 'count') {
            return $lists->get()->count();
        } else {
            return $lists = $lists->orderBy('id', 'DESC')->paginate(10);
        }
    }

    /*
     * Function for get count of all merchant request rised by manager id.
     */

    public static function getAllRequestByManager($id) {
        return CallRequest::where('executive_id', '=', $id)->where('status', '=', 'resolved')->count();
    }

    //linked history For Mobile Devices
    public static function getLinkerHistory($data) {
        $lastDate = \Carbon\Carbon::today()->subDays(30);
        $mainArray = [];
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if (!empty($user)) {
            if ($user->role == 'customer') {
                $lists = CallRequest::where('customer_id', $user->id)
                                ->where('call_time', '!=', "0")
                                ->where(function ($lists) {
                                    $lists->where('status', 'pending')
                                    ->orWhere('status', 'resolved');
                                })->where('created_at', '>=', date($lastDate))
                                        ->orderBy('id', 'DESC')->get();
            } else {
                $lists = CallRequest::where('executive_id', $user->id)
                                ->where('call_time', '!=', "0")
                                ->where(function ($lists) {
                                    $lists->where('status', 'pending')
                                    ->orWhere('status', 'resolved');
                                })->where('created_at', '>=', date($lastDate))
                                        ->orderBy('id', 'DESC')->get();
            }
            if (isset($data['page']) && $data['page'] != 0) {
                $page = $data['page'];
            } else {
                $page = 1;
            }
            $arr = [];
            $ticketArr = [];
            if (!empty($lists) && count($lists) > 0) {
                $collection = collect($lists);
                //$grouped = $collection->groupBy('ticket_id');
                $grouped = $collection->groupBy('id');
                $grouped = $grouped->toArray();
                //$lists = $grouped->last();
                foreach ($grouped as $group) {
                    $groupCollection = collect($group);
                    $groupLast = $groupCollection->last();
                    array_push($mainArray, $groupLast);
                }
                $perPage = 10;
                //$currentItems = array_slice($mainArray, $perPage * ($page - 1), $perPage);
                // $paginator = new LengthAwarePaginator($currentItems, count($mainArray), $perPage, $page);
                foreach ($mainArray as $list) {
                    $list = (object) $list;
                    $executive = User::where(['id' => $list->executive_id])->first();
                    $customer = User::where(['id' => $list->customer_id])->first();
                    $list->ticket_id = getTicketById($list->ticket_id);
                    //if(!in_array($list->ticket_id, $ticketArr)){
                    $ticketArr[] = $list->ticket_id;
                    if ($user->role == 'customer') {
                        $list->executive_name = $executive->contact_name;
                        $list->executive_profile = checkProfileImage($executive->profile_image);
                        $manager = ExecutiveManagerRelation::select(['users.first_name', 'users.last_name'])->join('users', 'executive_manager_relations.manager_id', '=', 'users.id')->where(['executive_manager_relations.executive_id' => $executive->id])->first();
                        $list->executive_bank = (!empty($manager)) ? $manager->first_name . ' ' . $manager->last_name : '';
                        $list->bank_category = ExecutiveCategory::getExecutiveCategoryName($list->category_id);
                        $list->notes = getNotesByTicketId($list->ticket_id);
                    } else {
                        $list->customer_name = $customer->contact_name;
                        $list->customer_profile = checkProfileImage($customer->profile_image);
                        $manager = CustomerExecutiveRelation::select(['users.first_name', 'users.last_name'])->join('users', 'customer_executive_relations.manager_id', '=', 'users.id')->where(['customer_executive_relations.customer_id' => $customer->id])->first();
                        $list->customer_bank = (!empty($manager)) ? $manager->first_name . ' ' . $manager->last_name : '';
                        $list->bank_category = ExecutiveCategory::getExecutiveCategoryName($list->category_id);
                        $list->notes = getNotesByTicketId($list->ticket_id);
                    }
                    $arr[] = $list;
                    //}
                }
                $currentItems = array_slice($arr, $perPage * ($page - 1), $perPage);

                $paginator = new LengthAwarePaginator($currentItems, count($arr), $perPage, $page);
                return $paginator;
            }return false;
        }
    }

// history detail
    public static function getHistoryDetail($get) {

        $callHistory = CallRequest::where(['id' => $get['request_id']])->first();
        $ticketId = $callHistory->ticket_id;
        //$callHistory = CallRequest::where(['ticket_id'=>$ticketId])->where('call_time','!=',"")->orderBy('id','desc')->first();
        $callHistory = CallRequest::where(['id' => $get['request_id'],'ticket_id'=>$ticketId])->orderBy('id','desc')->first();
        $ticket = getTicketById($ticketId);
        if (!empty($callHistory)) {
            $callHistory->ticket_id = getTicketById($callHistory->ticket_id);
            $executive = User::where(['id' => $callHistory->executive_id])->first();
            $customer = User::where(['id' => $callHistory->customer_id])->first();
            $callHistory->executive_name = $executive['contact_name'];
            $callHistory->customer_name = $customer['contact_name'];
            $callHistory->customer_profile = checkProfileImage($customer['profile_image']);
            $callHistory->customer_bank = getManagerNametByExecutiveId($callHistory->executive_id);
            $callHistory->bank_category = ExecutiveCategory::getExecutiveCategoryName($callHistory['category_id']);
            return $callHistory;
        }return false;
    }

    /*
     * get all merchant call request history
     */

    public static function getAllMerchantRequestHistory($post, $callFrom) {
        $merchantRequest = CallRequest::select('call_requests.*')
                ->join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                ->where('users.status', '!=', 'deleted')
                ->where('users.role', '=', 'customer')
                ->where('call_requests.status', '!=', 'missed_request')
                ->where('call_requests.call_time', '!=', '0');
        if ($callFrom == 'manager') {
            $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if ($callFrom == 'request_count_manager') {
            return $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id)->count();
        }
        if (isset($post['request_date']) && !empty($post['request_date'])) {
            $merchantRequest->whereDate('call_requests.created_at', getDBdateFormat($post['request_date']));
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $merchantRequest->where('call_requests.category_id', $post['category_id']);
        }
        if (isset($post['executive_id']) && !empty($post['executive_id'])) {
            $merchantRequest->where('call_requests.executive_id', $post['executive_id']);
        }
        if (isset($post['bussiness_name']) && !empty($post['bussiness_name'])) {
            $merchantRequest->where('user_profiles.bussiness_name', 'like', '%' . $post['bussiness_name'] . '%');
        }
        if (isset($post['phone']) && !empty($post['phone'])) {
            $merchantRequest->where('users.phone_number', 'like', '%' . $post['phone'] . '%');
        }
        
       // $merchantRequest->groupBy('ticket_id');
       // $merchantRequest->groupBy('call_requests.executive_id');
        $merchantRequest->orderBy('call_requests.id',"desc");
        return $merchantRequest->paginate(10);
    }
    
    // Csv List for get all merchant request list
    public static function getAllMerchantRequestHistoryForCSV($post, $callFrom) {
        $merchantRequest = CallRequest::select('call_requests.*')
                ->join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                ->where('users.status', '!=', 'deleted')
                ->where('users.role', '=', 'customer')
                ->where('call_requests.status', '!=', 'missed_request')
                ->where('call_requests.call_time', '!=', '0');
        if ($callFrom == 'manager') {
            $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if ($callFrom == 'request_count_manager') {
            return $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id)->count();
        }
        if (isset($post['request_date']) && !empty($post['request_date'])) {
            $merchantRequest->whereDate('call_requests.created_at', getDBdateFormat($post['request_date']));
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $merchantRequest->where('call_requests.category_id', $post['category_id']);
        }
        if (isset($post['executive_id']) && !empty($post['executive_id'])) {
            $merchantRequest->where('call_requests.executive_id', $post['executive_id']);
        }
        if (isset($post['bussiness_name']) && !empty($post['bussiness_name'])) {
            $merchantRequest->where('user_profiles.bussiness_name', 'like', '%' . $post['bussiness_name'] . '%');
        }
        if (isset($post['phone']) && !empty($post['phone'])) {
            $merchantRequest->where('users.phone_number', 'like', '%' . $post['phone'] . '%');
        }
        
       // $merchantRequest->groupBy('ticket_id');
       // $merchantRequest->groupBy('call_requests.executive_id');
        $merchantRequest->orderBy('call_requests.id',"desc");
        return $merchantRequest->get();
    }

    /*
     * get merchant call request history by id
     */

    public static function getCallRequestsById($id) {
        return CallRequest::where('id', $id)->first();
    }
    
    //Get Call Detail By Id
    public static function getCallRequestsByRequestId($id) {
        return CallRequest::where(['id'=>$id])->where('status','!=','missed_request')->where('call_time',"!=","")->first();
    }

    /*
     * update call request
     */

    public static function updateCallRequests($post) {
        try {
            $requestModel = CallRequest::where('id', $post['request_id'])->first();
            $requestModel->status = $post['status'];
            $requestModel->category_id = $post['category_id'];
            $requestModel->notes = $post['notes'];
            $requestModel->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.request_updated')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function getCallRequestList($post, $userType) {
        $callRequest = CallRequest::select('call_requests.*')
                ->join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                ->where('call_requests.status', '!=', 'missed_request')
                ->where('call_requests.call_time', '!=', '0');
        if ($userType == 'manager') {
            $callRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if (isset($post['merchant_number']) && !empty($post['merchant_number'])) {
            $callRequest->where('user_profiles.merchant_number', 'like', '%' . $post['merchant_number'] . '%');
        }
        if (isset($post['se_assigned']) && !empty($post['se_assigned'])) {
            $callRequest->where('call_requests.executive_id', $post['se_assigned']);
        }
        if (isset($post['business_name']) && !empty($post['business_name'])) {
            $callRequest->where('user_profiles.bussiness_name', 'like', '%' . $post['business_name'] . '%');
        }
        if (isset($post['date_of_call']) && !empty($post['date_of_call'])) {
            $callRequest->whereDate('call_requests.created_at', getDBdateFormat($post['date_of_call']));
        }
        //$callRequest->groupBy('ticket_id');
        //$callRequest->groupBy('call_requests.executive_id');
        $callRequest->orderBy('id', 'DESC');
        //return $callRequest->get();

        return $callRequest->paginate(10);
    }
    
    public static function getCallRequestListForCsv($post, $userType) {
        $callRequest = CallRequest::select('call_requests.*')
                ->join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                ->where('call_requests.status', '!=', 'missed_request')
                ->where('call_requests.call_time', '!=', '0');
        if ($userType == 'manager') {
            $callRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if (isset($post['merchant_number']) && !empty($post['merchant_number'])) {
            $callRequest->where('user_profiles.merchant_number', 'like', '%' . $post['merchant_number'] . '%');
        }
        if (isset($post['se_assigned']) && !empty($post['se_assigned'])) {
            $callRequest->where('call_requests.executive_id', $post['se_assigned']);
        }
        if (isset($post['business_name']) && !empty($post['business_name'])) {
            $callRequest->where('user_profiles.bussiness_name', 'like', '%' . $post['business_name'] . '%');
        }
        if (isset($post['date_of_call']) && !empty($post['date_of_call'])) {
            $callRequest->whereDate('call_requests.created_at', getDBdateFormat($post['date_of_call']));
        }
        //$callRequest->groupBy('ticket_id');
        //$callRequest->groupBy('call_requests.executive_id');
        $callRequest->orderBy('id', 'DESC');
        //return $callRequest->get();

        return $callRequest->get();
    }

    public static function getMerchantRequestList($post, $userType) {
        $merchantRequest = CallRequest::select('call_requests.*')
                ->join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                ->where('call_requests.customer_id', '=', $post['user_id'])
                ->where('call_requests.status', '!=', 'missed_request');
        if ($userType == 'manager') {
            $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if (isset($post['name']) && !empty($post['name'])) {
            $merchantRequest->where('users.contact_name', 'like', '%' . $post['name'] . '%');
        }
        if (isset($post['generate_date']) && !empty($post['generate_date'])) {
            $merchantRequest->whereDate('call_requests.created_at', getDBdateFormat($post['generate_date']));
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $merchantRequest->where('call_requests.category_id', $post['category_id']);
        }
        if (isset($post['executive_id']) && !empty($post['executive_id'])) {
            $merchantRequest->where('call_requests.executive_id', $post['executive_id']);
        }

        return $merchantRequest->orderBy('call_requests.id', 'desc')->paginate(10);
    }

    /*
     * get executives linked merchant notes history by executive and merchant id
     */

    public static function getMerchantLinkedNotesHistoryByExecutive($executiveId, $merchantId) {
        
       // $ticketData = getTicketDataByNumber($ticketNumber);
        //return CallRequest::where(['executive_id' => $executiveId, 'customer_id' => $merchantId,'ticket_id'=>$ticketData->id])->where('notes','!=','')->orderBy('id','desc')->paginate(10);
        return CallRequest::where(['customer_id' => $merchantId])->where('notes','!=','')->orderBy('id','desc')->groupBy(DB::raw('date(created_at)'))->paginate(10);
    }

    /* update call request by executve
     */

    public static function updateCallRequestsExecutive($post) {
        $executiveId = Auth::guard('web')->user()->id;
        try {
            $requestModel = CallRequest::where('id', $post['request_id'])->first();
            if(!empty($requestModel)){
            $notificationValue = 0;
            if ($requestModel->executive_id != $post['executive_id']) {
                $notificationValue = 1;
                //N:- Notification for assigned request for SE
                $category = BankingCategory::getCategoryById($post['category_id']);
                $categoryName = $category->name;
                $userName = \App\Http\Models\User::getUserDataByKey($requestModel->executive_id, 'contact_name');
                $receiverData = \App\Http\Models\UserDevice::where(['user_id' => $post['executive_id']])->first();
                $userData = \App\Http\Models\User::where(['id' => $post['executive_id']])->first();
                $message = "You have been assigned a " . $categoryName . " request from " . $userName;

                $image = User::getUserDataByKey($post['executive_id'], 'profile_image');
                $callerImage = checkProfileImage($image);

                $data = [
                    'notification_type' => "assigned_request",
                    'userJID' => $requestModel->executive_id,
                    'ticketId' => getTicketById($requestModel->ticket_id),
                    'receiverId' => $post['executive_id'],
                    'caller_name' => $userName,
                    'message' => $message,
                    'caller_image' => $callerImage
                ];

                $seCallRequest = CallRequest::where(['executive_id' => $requestModel->executive_id, 'ticket_id' => $requestModel->ticket_id])->get();
                if (!empty($seCallRequest)) {
                    foreach ($seCallRequest as $val) {
                        $val->executive_id = $post['executive_id'];
                        $val->save();
                    }
                }
                $ticektData = Ticket::where(['id' => $requestModel->ticket_id])->first();
                $ticektData->executive_id = $post['executive_id'];
                $ticektData->save();

                if (!empty($receiverData)) {
                    if ($receiverData->device_type == "ios") {
                        Utility::APNSPushDeviceNotification($receiverData->device_id, $message, $userData->role, $data, $requestModel->executive_id, $post['executive_id']);
                        //Utility::APNSPushDeviceNotification($receiverData->device_id, $message, $userData->role, $data, $requestModel->executive_id, $post['executive_id']);
                    } else {
                        Utility::FcmPushNotification([$receiverData->device_id], $message, $userData->role, $data, $requestModel->executive_id, $post['executive_id']);
                    }
                }
                //N:- Notification for SM
                $userName = \App\Http\Models\User::getUserDataByKey($requestModel->executive_id, 'contact_name');
                $managerData = ExecutiveManagerRelation::select('manager_id')->where('executive_id', $requestModel->executive_id)->first();
                $executiveName = \App\Http\Models\User::getUserDataByKey($post['executive_id'], 'contact_name');
                $userData = \App\Http\Models\User::where(['id' => $managerData->manager_id])->first();
                $message = $userName . " has assigned a customer request to " . $executiveName;
                $image = User::getUserDataByKey($post['executive_id'], 'profile_image');
                $callerImage = checkProfileImage($image);

                $data = [
                    'notification_type' => 'assigned_request',
                    'userJID' => $requestModel->executive_id,
                    'ticketId' => getTicketById($requestModel->ticket_id),
                    'receiverId' => $managerData->manager_id,
                    'caller_name' => $userName,
                    'message' => $message,
                    'caller_image' => $callerImage
                ];
                Utility::saveNotification($requestModel->executive_id, $message, 'assigned_request', $data, $managerData->manager_id);
            }
            $requestModel->status = $post['status'];
            $requestModel->call_log = $post['hdnCallDisconnectReason'];

            if ($post['status'] == "pending") {
                if (isset($post['notify_type'])) {
                    $requestModel->notify_type = $post['notify_type'];
                    if ($post['notify_type'] == "selected_date") {
                        $requestModel->notify_date = getDBdateFormat($post['notify_date']);
                        $requestModel->notify_date_time = getDBdateFormat($post['notify_date']) . ' ' . date('H:i', strtotime($post['notify_date_time']));
                        $requestModel->today_in_time = "";
                    } elseif ($post['notify_type'] == "today") {
                        getTimeZoneByUserId($executiveId);
                        $cDate = date('Y-m-d H:i');
                        $splitStr = explode("_", $post['today_in_time']);

                        if ($splitStr['1'] == 'hour') {
                            $todayInTime = gmdate('H:i', strtok($post['today_in_time'], '_') * 60 * 60);
                            $convertedTime = date('Y-m-d H:i', strtotime('+' . $splitStr['0'] . 'hour', strtotime($cDate)));
                        } else {
                            $todayInTime = gmdate('H:i', strtok($post['today_in_time'], '_') * 60);
                            $convertedTime = date('Y-m-d H:i', strtotime('+' . $splitStr['0'] . 'minutes', strtotime($cDate)));
                        }
                        $requestModel->today_in_time = $todayInTime;
                        $requestModel->notify_date = $cDate;
                        $requestModel->notify_date_time = $convertedTime;
                    } else {
                        $requestModel->today_in_time = "";
                        $requestModel->notify_date = null;
                        $requestModel->notify_date_time = "";
                    }
                }
            } else {
                $requestModel->notify_type = null;
                $requestModel->today_in_time = "";
                $requestModel->notify_date = null;
                $requestModel->notify_date_time = "";
            }
            if (isset($post['time']) && $post['time'] != "") {
                $requestModel->call_time = $post['time'];
            }
            $requestModel->call_current_status = 'free';
            $requestModel->category_id = $post['category_id'];
            $requestModel->executive_id = $post['executive_id'];
            $requestModel->notes = $post['notes'];
            $requestModel->save();

            $requestTicketId = $requestModel->ticket_id;

            $ticketCallData = CallRequest::where(['ticket_id' => $requestTicketId, 'executive_id' => $post['executive_id']])->get();
            if (!empty($ticketCallData)) {
                if ($post['status'] != "pending") {
                    foreach ($ticketCallData as $value) {
                        $value->call_current_status = 'free';
                        $value->status = 'resolved';
                        $value->save();
                    }
                } else {
                    foreach ($ticketCallData as $value) {
                        $value->call_current_status = 'free';
                        $value->save();
                    }
                }
            }

            //N:- Notification for customer request as pending at the end of a call
            if ($requestModel) {
                if ($notificationValue == 0) {
                    if ($post['status'] == "pending") {
                        $senderId = $requestModel->customer_id;
                        $receiverId = $requestModel->executive_id;
                        $notificationType = 'pending_request';
                        $notificationMessage = "You have a pending request";
                    }
                    if ($post['status'] == "resolved") {
                        $userName = \App\Http\Models\User::getUserDataByKey($requestModel->executive_id, 'contact_name');
                        $category = BankingCategory::getCategoryById($post['category_id']);
                        $categoryName = $category->name;
                        $senderId = $requestModel->executive_id;
                        $receiverId = $requestModel->customer_id;
                        $notificationType = 'completed_request';
                        $notificationMessage = $userName . " has marked the request for " . $categoryName . " as completed.";
                    }
                    $userName = \App\Http\Models\User::getUserDataByKey($senderId, 'contact_name');
                    $receiverData = \App\Http\Models\UserDevice::where(['user_id' => $receiverId])->first();
                    $userData = \App\Http\Models\User::where(['id' => $receiverId])->first();
                    $message = $notificationMessage;
                    $image = User::getUserDataByKey($receiverId, 'profile_image');
                    $callerImage = checkProfileImage($image);
                    $data = [
                        'notification_type' => $notificationType,
                        'userJID' => $senderId,
                        'ticketId' => getTicketById($requestModel->ticket_id),
                        'receiverId' => $receiverId,
                        'caller_name' => $userName,
                        'caller_image' => $callerImage,
                        'message' => $message
                    ];
                    if (!empty($receiverData) && $requestModel->status == "pending") {
                        if ($receiverData->device_type == "ios") {
                            // Utility::APNSPushDeviceNotification($receiverData->device_id, $message, $userData->role, $data, $senderId, $receiverId);
                             Utility::APNSPushDeviceNotification($receiverData->device_id, $message, $userData->role, $data, $senderId, $receiverId);
                        } else {
                            Utility::FcmPushNotification([$receiverData->device_id], $message, $userData->role, $data, $senderId, $receiverId);
                        }
                    } else {
                        $data = [
                            'notification_type' => 'pending_request',
                            'userJID' => $senderId,
                            'ticketId' => getTicketById($requestModel->ticket_id),
                            'receiverId' => $receiverId,
                            'caller_name' => $userName,
                            'caller_image' => $callerImage,
                            'message' => $message
                        ];
                    }
                }
            }
            return Response::json(['success' => true, 'message' => \Config::get('constants.request_updated')]);
            } else {
                return Response::json(['success' => false, 'message' => ""]);
            }
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    //Function Run when user finish current call and send notification to SE (if call status marked as pending) and Customer(if call status marked as resolved)
    public static function saveFinishCallDetail($post) {
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        $ticketData = Ticket::where(['ticket_number' => $post['ticket_id']])->first();
        $request = CallRequest::where(['ticket_id' => $ticketData->id, 'executive_id' => $user->id])->orderBy('id', 'desc')->first();
        if (!empty($request)) {
            //N
            $notificationValue = 0;
            if (isset($post['executive_id']) && $request->executive_id != @$post['executive_id']) {
                $notificationValue = 1;
                //N:- Notification for assigned request for SE
                $category = BankingCategory::getCategoryById($request->category_id);
                $categoryName = $category->name;
                $userName = \App\Http\Models\User::getUserDataByKey($request->executive_id, 'contact_name');
                $image = User::getUserDataByKey($request->executive_id, 'profile_image');
                $callerImage = checkProfileImage($image);
                $receiverData = \App\Http\Models\UserDevice::where(['user_id' => $post['executive_id']])->first();
                $userData = \App\Http\Models\User::where(['id' => @$post['executive_id']])->first();
                $message = "You have been assigned a " . $categoryName . " request from " . $userName;
                $data = [
                    'notification_type' => "assigned_request",
                    'userJID' => $request->executive_id,
                    'ticketId' => getTicketById($request->ticket_id),
                    'receiverId' => $post['executive_id'],
                    'caller_name' => $userName,
                    'message' => $message,
                    'caller_image' => $callerImage
                ];

                $seCallRequest = CallRequest::where(['executive_id' => $request->executive_id, 'ticket_id' => $ticketData->id])->get();
                if (!empty($seCallRequest)) {
                    foreach ($seCallRequest as $val) {
                        $val->executive_id = $post['executive_id'];
                        $val->save();
                    }
                }
                
                $ticektData = Ticket::where(['id' => $request->ticket_id])->first();
                $ticektData->category_id = $post['category_id'];
                $ticektData->executive_id = $post['executive_id'];
                $ticektData->save();


                if (!empty($receiverData)) {
                    if ($receiverData->device_type == "ios") {
                         Utility::APNSPushDeviceNotification($receiverData->device_id, $message, $userData->role, $data, @$post['executive_id'], @$post['executive_id']);
                        // Utility::APNSPushDeviceNotification($receiverData->device_id, $message, $userData->role, $data, @$post['executive_id'], @$post['executive_id']);
                    } else {
                        Utility::FcmPushNotification([$receiverData->device_id], $message, $userData->role, $data, @$post['executive_id'], @$post['executive_id']);
                    }
                }
                //N:- Notification for SM
                $userName = \App\Http\Models\User::getUserDataByKey($post['executive_id'], 'contact_name');
                $image = User::getUserDataByKey($post['executive_id'], 'profile_image');
                $callerImage = checkProfileImage($image);
                $managerData = ExecutiveManagerRelation::select('manager_id')->where('executive_id', @$post['executive_id'])->first();
                $executiveName = \App\Http\Models\User::getUserDataByKey(@$post['executive_id'], 'contact_name');
                $userData = \App\Http\Models\User::where(['id' => $managerData->manager_id])->first();
                $message = $userName . " has assigned a customer request to " . $executiveName;

                $data = [
                    'notification_type' => 'assigned_request',
                    'userJID' => @$post['executive_id'],
                    'ticketId' => getTicketById($request->ticket_id),
                    'receiverId' => $managerData->manager_id,
                    'caller_name' => $userName,
                    'message' => $message,
                    'caller_image' => $callerImage
                ];
                Utility::saveNotification($request->executive_id, $message, 'assigned_request', $data, $managerData->manager_id);
            }
            // N

            $request->status = $post['request_status'];
            $request->call_current_status = 'free';
            $request->notes = $post['notes'];
            if ($post['notify_type'] == 'selected_date') {
                $request->notify_date = $post['notify_date'];
//                $request->notify_date_time = $post['notify_date_time'];
                $request->notify_date_time = date('Y-m-d', strtotime($post['notify_date'])).' '.date('H:i', strtotime($post['notify_date_time']));
            }
            if ($post['notify_type'] == 'today') {
                getTimeZoneByUserId($request->executive_id);
                if($post['today_in_time'] == '00:30:00'){
                    $post['today_in_time'] = '30_minute';
                } else if($post['today_in_time'] == '01:00:00'){
                    $post['today_in_time'] = '1_hour';
                } else if($post['today_in_time'] == '02:00:00'){
                    $post['today_in_time'] = '2_hour';
                } else if($post['today_in_time'] == '03:00:00'){
                    $post['today_in_time'] = '3_hour';
                } else if($post['today_in_time'] == '04:00:00'){
                    $post['today_in_time'] = '4_hour';
                } else if($post['today_in_time'] == '05:00:00'){
                    $post['today_in_time'] = '5_hour';
                }
                $cDate = date('Y-m-d H:i');
                $splitStr = explode("_", $post['today_in_time']);
                $todayInTime = '';
                $convertedTime = '';
                if ($splitStr['1'] == 'hour') {
                    $todayInTime = gmdate('H:i', strtok($post['today_in_time'], '_') * 60 * 60);
                    $convertedTime = date('Y-m-d H:i', strtotime('+' . $splitStr['0'] . 'hour', strtotime($cDate)));
                } else {
                    $todayInTime = gmdate('H:i', strtok($post['today_in_time'], '_') * 60);
                    $convertedTime = date('Y-m-d H:i', strtotime('+' . $splitStr['0'] . 'minutes', strtotime($cDate)));
                }
                $request->today_in_time = $todayInTime;
                $request->notify_date = $cDate;
                $request->notify_date_time = $convertedTime;
                
                
//                $request->today_in_time = $post['today_in_time'];
            }
            if(isset($post['call_time']) && !empty($post['call_time'])){
                  $request->call_time = @$post['call_time']; 
            }
            $request->category_id = $post['category_id'];
            $request->call_current_status = "free";
            $request->notify_type = $post['notify_type'];
            $request->is_call_dropped = @$post['is_call_drop'];
            $request->updated_at = date('Y-m-d H:i:s');
            if ($request->save()) {

                $requestTicketId = $request->ticket_id;
                $executiveId = $user->id;

                $ticketCallData = CallRequest::where(['ticket_id' => $requestTicketId, 'executive_id' => $executiveId])->get();
                if (!empty($ticketCallData)) {
                    if ($post['request_status'] != "pending") {
                        foreach ($ticketCallData as $value) {
                            $value->call_current_status = 'free';
                            $value->status = 'resolved';
                            $value->updated_at = date('Y-m-d H:i:s');
                            $value->save();
                        }
                    } else {
                        foreach ($ticketCallData as $value) {
                            $value->call_current_status = 'free';
                            $value->updated_at = date('Y-m-d H:i:s');
                            $value->save();
                        }
                    }
                }

                if ($notificationValue == 0) {
                    if ($post['request_status'] == "pending") {
                        $senderId = $request->customer_id;
                        $receiverId = $request->executive_id;
                        $notificationType = 'pending_request';
                        $notificationMessage = "You have a pending request";
                    }
                    if ($post['request_status'] == "resolved") {
                        $userName = \App\Http\Models\User::getUserDataByKey($request->executive_id, 'contact_name');
                        $category = BankingCategory::getCategoryById($request->category_id);
                        $categoryName = $category->name;
                        $senderId = $request->executive_id;
                        $receiverId = $request->customer_id;
                        $notificationType = 'completed_request';
                        $notificationMessage = $userName . " has marked the request for " . $categoryName . " as completed.";
                    }

                    $userName = \App\Http\Models\User::getUserDataByKey($senderId, 'contact_name');
                    $receiverData = \App\Http\Models\UserDevice::where(['user_id' => $receiverId])->first();
                    $userData = \App\Http\Models\User::where(['id' => $receiverId])->first();
                    $message = $notificationMessage;
                    $image = User::getUserDataByKey($receiverId, 'profile_image');
                    $callerImage = checkProfileImage($image);
                    $data = [
                        'notification_type' => $notificationType,
                        'userJID' => $senderId,
                        'ticketId' => getTicketById($request->ticket_id),
                        'receiverId' => $receiverId,
                        'caller_name' => $userName,
                        'caller_image' => $callerImage,
                        'message' => $message
                    ];
                    if (!empty($receiverData) && $request->status != "resolved") {
                        if ($receiverData->device_type == "ios") {
                            //@Utility::APNSPushDeviceNotification($receiverData->device_id, $message, $userData->role, $data, $senderId, $receiverId);
                            @Utility::APNSPushDeviceNotification($receiverData->device_id, $message, $userData->role, $data, $senderId, $receiverId);
                        } else {
                            @Utility::FcmPushNotification([$receiverData->device_id], $message, $userData->role, $data, $senderId, $receiverId);
                        }
                    } else {
                        $data = [
                            'notification_type' => 'pending_request',
                            'userJID' => $senderId,
                            'ticketId' => getTicketById($request->ticket_id),
                            'receiverId' => $receiverId,
                            'caller_name' => $userName,
                            'caller_image' => $callerImage,
                            'message' => $message
                        ];
                    }
                }


                return true;
            }
        }
        return false;
    }

// api for home screen in executive side
    public static function getMissedRequest() {
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if (!empty($user)) {
            $lists = CallRequest::select('id', 'customer_id', 'ticket_id', 'executive_id', 'notes', 'created_at', 'status')
                    ->where(['executive_id' => $user->id])
                    ->where(function ($query) {
                            $query->where('status', '=', 'missed_request')
                            ->orWhere('status', '=', 'pending');
                        })
                   // ->where(['status' => 'missed_request', 'executive_id' => $user->id])
                    ->where('ticket_id', '!=', 0)
                    ->orderBy('id', 'desc')
                    //->groupBy('ticket_id')
                    ->paginate(10);
            if (count($lists) > 0) {
                foreach ($lists as $val) {
                    $customer = User::where(['id' => $val->customer_id])->first();
                    $val->customer_name = $customer['contact_name'];
                    $val->customer_profile = checkProfileImage($customer['profile_image']);
                    $val->customer_bank = Bank::getbankNameById($customer['bank_id']);
                    $val->online_status = User::getUserDataByKey($val->customer_id, 'online_status');
                    $val->last_login_time = User::getUserDataByKey($val->customer_id, 'last_login_time');
                    $val->ticket_number = getTicketById($val->ticket_id);
                }
                return $lists;
            }return false;
        }return false;
    }

    // send request to executive in api side
    public static function sendRequestNotification($post) {
        $defaultTimeZone = \Config::get('constants.default_time_zone');
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);

        $userDevice = \App\Http\Models\UserDevice::where(['user_id' => $user->id])->first();
        if (!empty($userDevice)) {
            if ($userDevice->timezone == "India Standard Time") {
                $userDevice->timezone = "$defaultTimeZone";
            }
            if ($userDevice->timezone == "" || $userDevice->timezone == "string") {
                $timeZone = "$defaultTimeZone";
            } else {
                $timeZone = $userDevice->timezone;
            }
            date_default_timezone_set("$timeZone");
        } else {
            date_default_timezone_set("$defaultTimeZone");
        }
        $date = date('Y-m-d H:i:s');


        $ticket = Ticket::where(['customer_id' => $user->id, 'category_id' => $post['category_id'], 'status' => 'pending'])->where('executive_id', 'IS NOT', NULL)->first();
        if (empty($ticket)) {
            $userManager = \App\Http\Models\CustomerExecutiveRelation::where(['customer_id' => $user->id])->first();
            $customerSe = \App\Http\Models\CustomerExecutiveRelation::where(['customer_id' => $user->id])->get();
            $SeArr = [];
            if(!empty($customerSe)){
                foreach($customerSe as $row){
                    $SeArr[] = $row->executive_id;
                }
            }
            $executive = User::select('users.*')
                            ->join('executive_categories', 'executive_categories.executive_id', 'users.id')
                            ->join('executive_manager_relations', 'executive_manager_relations.executive_id', 'users.id')
                            ->where(['executive_categories.category_id' => $post['category_id'], 'executive_manager_relations.manager_id' => $userManager->manager_id,'users.status'=>'active'])->get();
//                            ->where(['executive_categories.category_id' => $post['category_id'], 'online_status' => 'online','executive_manager_relations.manager_id'=>$userManager->manager_id])->get();
            if (!empty($executive)) {
                // save ticket
                $ticketNumber = Utility::generateTicket();
                $ticket = new Ticket();
                $ticket->ticket_number = $ticketNumber;
                $ticket->customer_id = $user->id;
                $ticket->category_id = $post['category_id'];
                $ticket->save();
                // save request 
                $newArr = [];
                $ringingArr = [];
                foreach ($executive as $val) {
                    $executiveCallData = CallRequest::where(['executive_id' => $val->id])->orderBy('id', 'desc')->first();
                    if (!empty($executiveCallData)) {
//                        if ($executiveCallData->call_current_status == 'busy') {
//                            
//                        } else if ($executiveCallData->status == "ringing") {
//                            $ringingArr[] = $val->id;
//                        } else {
                        if(in_array($val->id,$SeArr)){
                            $newArr[] = $val->id;
                            $requestModel = new CallRequest();
                            $requestModel->ticket_id = $ticket->id;
                            $requestModel->customer_id = $user->id;
                            $requestModel->category_id = $post['category_id'];
                            $requestModel->executive_id = $val->id;
                            $requestModel->notes = @$post['notes'];
                            //    $requestModel->status = 'ringing';
                            $requestModel->status = 'missed_request';
                            $requestModel->call_current_status = 'free';
                            $requestModel->created_at = $date;
                            $requestModel->updated_at = $date;
                            $requestModel->save();
                        }
                        // }
                    } else {
                        if(in_array($val->id,$SeArr)){
                            $newArr[] = $val->id;
                            $requestModel = new CallRequest();
                            $requestModel->ticket_id = $ticket->id;
                            $requestModel->customer_id = $user->id;
                            $requestModel->category_id = $post['category_id'];
                            $requestModel->notes = @$post['notes'];
                            $requestModel->executive_id = $val->id;
                            //$requestModel->status = 'ringing';
                            $requestModel->status = 'missed_request';
                            $requestModel->call_current_status = 'free';
                            $requestModel->created_at = $date;
                            $requestModel->updated_at = $date;
                            $requestModel->save();
                        }
                    }
                }
                return response()->json(['success' => TRUE, 'data' => $newArr, 'ringArr' => $ringingArr, 'ticketId' => $ticketNumber]);
                //$callRequest = self::saveCallRequuest($post, $ticket);
            } else {
                return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'No executive online']]);
            }
        } else {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'You already have SE for this category']]);
            //   $callRequest = self::saveCallRequuest($post, $ticket);
        }
//        if (!empty($callRequest)) {
//            $userIds[] = $callRequest->executive_id;
//            $message = 'You have a missed call from ' . $user->contact_name;
//            $type = 'customer_call_request';
//            $fromId = $user->id;
//            $toId = $callRequest->executive_id;
//            $data = [];
//            $data['type'] = $type;
//            $data['message'] = $message;
//            $customer_image = checkProfileImage($user->profile_image);
//            $data['profile_image'] = $customer_image;
//            $data['business_name'] = Bank::getbankNameById($user->bank_id);
//            $data['first_name'] = $user['first_name'];
//            $data['last_name'] = $user['last_name'];
//            $data['contact_name'] = $user->contact_name;
//            $data['request_status'] = 'pending';
//            $data['ticket_id'] = $ticket->ticket_number;
//            $data['request_id'] = $callRequest->id;
//            $data['customer_id'] = $callRequest->customer_id;
//            //Utility::saveNotification($from_id, $message, $type, $data, $to_id);
//            Utility::sendNotification($userIds, $message, $type, $data,$fromId,$toId);
//            return response()->json(['success' => true, 'data' => [], 'message' => 'Notification sent']);
//        }
        return response()->json(['success' => false]);
    }

    public static function saveCallRequuest($post, $ticket) {
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        $callRequest = CallRequest::where(['customer_id' => $user->id, 'executive_id' => $ticket->executive_id, 'status' => 'pending', 'status' => 'missed_request', 'category_id' => $post['category_id']])->first();
        if (empty($callRequest)) {
            $callRequest = new CallRequest();
            $callRequest->ticket_id = $ticket->id;
            $callRequest->customer_id = $user->id;
            $callRequest->executive_id = $ticket->executive_id;
            $callRequest->category_id = $post['category_id'];
            $callRequest->status = 'missed_request';
            $callRequest->notes = $post['notes'];
            $callRequest->save();
        }
        return $callRequest;
    }

    public static function saveCallRequuestFromWeb($post) {
        $userId = Auth::guard()->user()->id;
        getTimeZoneByUserId($userId);
        $ticketData = Ticket::where(['ticket_number' => $post['ticketId'], 'status' => 'resolved'])->first();
        if (empty($ticketData)) {
            $userName = \App\Http\Models\User::getUserDataByKey($userId, 'contact_name');
            $image = \App\Http\Models\User::getUserDataByKey($userId, 'profile_image');
            $callerImage = checkProfileImage($image);
            $ticketData = Ticket::where(['ticket_number' => $post['ticketId']])->orderBy('id', 'desc')->first();
            if ($post['requestType'] == 'pending') {
                $callRequest = CallRequest::where(['id' => $post['$requestId']])->first();
                $userDeviceData = UserDevice::where(['user_id' => $post['customerId']])->first();
                $managerData = getManagerByExecutiveId($userId);
                $managerName = \App\Http\Models\User::getUserDataByKey($managerData, 'contact_name');
                $waitingTime = \App\Http\Models\User::getManagerWaitingTimeById($userId);
                if (!empty($userDeviceData)) {
                    $executiveName = User::getUserDataByKey($userId, 'contact_name');
                    $message = "You have a missed call from $executiveName";
                    $userType = 'customer';
                    $data = [
                    'notification_type' => 'missed_call_request',
                    'userJID' =>$userId,
                    'ticketId' => $post['ticketId'],
                    'receiverId' => $post['customerId'],
                    'caller_name' => $userName,
                    'caller_image' => $callerImage,
                    'manager_name' => $managerName,
                    'message'=>$message,
                    'waiting_time' =>$waitingTime 
                ];
                    if ($userDeviceData->device_type == "ios") {
                        Utility::APNSPushDeviceNotification($userDeviceData->device_id, $message, 'customer', $data, $userId, $post['customerId']);
                    } else {
                        Utility::FcmPushNotification([$userDeviceData->device_id], $message, 'customer', $data, $userId,$post['customerId']);
                    }
                    
                }
            } else {
                $callRequest = new CallRequest();
//                $callData = CallRequest::where(['ticket_id'=>$ticketData->id,'status'=>'missed_request'])->delete();
            }
            $callRequest->ticket_id = $ticketData->id;
            $callRequest->customer_id = $post['customerId'];
            $callRequest->executive_id = $userId;
            $callRequest->category_id = $ticketData->category_id;
            $callRequest->status = 'missed_request';
            $callRequest->created_at = date('Y-m-d H:i:s');
            $callRequest->updated_at = date('Y-m-d H:i:s');
            
            $callRequest->save();
            return $callRequest->id;
        } else {
            return false;
        }
    }

// linking with customer by execurive in api side

    public static function linkWithCustomer1($post) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            if (!empty($user)) {
                $userIds[] = ($user->role == 'executive') ? $post['customer_id'] : $post['executive_id'];
                $message = 'You have a missed call from ' . $user->contact_name;
                $type = ($user->role == 'executive') ? 'executive_call_link' : 'customer_call_link';
                $from_id = $user->id;
                $to_id = ($user->role == 'executive') ? $post['customer_id'] : $post['executive_id'];
                $data = [];
                $data['type'] = $type;
                $data['message'] = $message;
                $executive_image = checkProfileImage($user->profile_image);
                $data['profile_image'] = $executive_image;
                $data['business_name'] = Bank::getbankNameById($user->bank_id);
                $data['first_name'] = $user['first_name'];
                $data['last_name'] = $user['last_name'];
                $data['contact_name'] = $user->contact_name;
                $data['request_status'] = 'pending';
                $data['ticket_id'] = $post['ticket_id'];
                $data['request_id'] = '';
                Utility::saveNotification($from_id, $message, $type, $data, $to_id);
                if (Utility::sendNotification($userIds, $message, $type, $data)) {
                    return response()->json(['success' => true, 'data' => [], 'message' => 'link notification sent']);
                }return response()->json(['success' => false, 'data' => [], 'message' => 'not sent']);
            }
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => $ex->getMessage()]]);
        }
    }

    //P : Api to create request from SE to generate call request
    public static function linkWithCustomer($post) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $defaultTimeZone = \Config::get('constants.default_time_zone');
            $userDevice = \App\Http\Models\UserDevice::where(['user_id' => $user->id])->first();
            if (!empty($userDevice)) {
                if ($userDevice->timezone == "India Standard Time" || $userDevice->timezone == "string") {
                    $userDevice->timezone = "$defaultTimeZone";
                }
                if ($userDevice->timezone == "") {
                    $timeZone = "$defaultTimeZone";
                } else {
                    $timeZone = $userDevice->timezone;
                }
                date_default_timezone_set("$timeZone");
            } else {
                date_default_timezone_set("$defaultTimeZone");
            }
            $date = date('Y-m-d H:i:s');

            if (!empty($user)) {
                $ticketData = getTicketDataByNumber($post['ticket_id']);
                $ticketId = $ticketData->id;
                $callData = CallRequest::where(['ticket_id'=>$ticketId,'status'=>'missed_request'])->delete();
                $model = new CallRequest();
                if (isset($post['customer_id'])) {
                    $postUserId = $post['customer_id'];
                    //$customerCallRequest = CallRequest::where(['customer_id' => $postUserId, 'call_current_status' => 'busy'])->first();
                    $customerCallRequest = CallRequest::where(['customer_id' => $postUserId])->first();
                    $model->customer_id = $post['customer_id'];
                    $model->executive_id = $user->id;
                } else {
                    $postUserId = $post['executive_id'];
                    //$customerCallRequest = CallRequest::where(['executive_id' => $postUserId, 'call_current_status' => 'busy'])->first();
                    $customerCallRequest = CallRequest::where(['executive_id' => $postUserId])->first();
                    $model->executive_id = $post['executive_id'];
                    $model->customer_id = $user->id;
                }
                $customerCallRequest = [];
                $customerId = $postUserId;
                if (empty($customerCallRequest)) {
                    $ticketData = Ticket::where(['ticket_number' => $post['ticket_id']])->first();

                    $model->ticket_id = $ticketData->id;


                    $model->category_id = $ticketData->category_id;
                    //$model->status = 'ringing';
                    $model->status = 'missed_request';
                    $model->call_current_status = 'free';
                    $model->created_at = $date;
                    $model->updated_at = $date;
                    $model->save();
                    $arr = [];

                    $arr['name'] = User::getUserDataByKey($postUserId, 'contact_name');
                    $image = User::getUserDataByKey($postUserId, 'profile_image');
                    $arr['image'] = checkProfileImage($image);
                    $arr['id'] = $postUserId;
                    return response()->json(['success' => true, 'data' => $arr, 'error' => ['message' => ""]]);
                } else {
                    return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'User is busy on another call']]);
                }
            } else {
                return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'User is busy on another call']]);
            }
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => $ex->getMessage()]]);
        }
    }

    //R : get all call request count by admin
    public static function allCallRequestCount($userType) {
        $merchantRequest = CallRequest::join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                ->where('call_requests.status', '!=', 'missed_request');
        if ($userType == 'manager') {
            $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        return $merchantRequest->count();
    }

    //R : get manager id by executive
    public static function getManagerIdByExecutive($executive_id) {
        return CallRequest::join('executive_manager_relations', 'executive_manager_relations.executive_id', 'call_requests.executive_id')
                        ->where('call_requests.status', '!=', 'missed_request')
                        ->where('call_requests.executive_id', $executive_id)->first();
    }

    //R : get request history in executive section
    public static function getLinkedHistoryRequest($id) {
        return CallRequest::select('call_requests.*')
                        ->join('users', 'users.id', 'call_requests.customer_id')
                        ->where('call_requests.status', '!=', 'missed_request')
                        ->where('call_requests.executive_id', '=', $id)
                        ->where('call_time', '!=', "")
                        ->where('users.role', '=', 'customer')
                        ->where('users.status', '!=', 'deleted')
                        ->groupBy('call_requests.executive_id')
                        //->groupBy('call_requests.ticket_id')
                        ->groupBy('call_requests.id')
                        ->orderBy('call_requests.id', 'desc')
                        ->paginate(10);
    }

    // Update Current Call Status
    public static function updateCallStatus($post) {
        $ticketData = Ticket::where(['ticket_number' => $post['ticketId']])->first();
        if (empty($ticketData)) {
            return false;
        }
        $userDevice = UserDevice::where(['user_id'=>$post['userId']])->first();
        date_default_timezone_set($userDevice->timezone);
        $userData = User::where(['id' => $post['userId']])->first();
        
        if ($userData->role == 'executive') {
            if($userDevice->device_type == 'ios' || $userDevice->device_type == 'android'){
                $model = CallRequest::where(['ticket_id' => $ticketData->id,'executive_id' => $post['userId']])->orderBy('id','desc')->first();
            } else {
                
                $model = CallRequest::where(['ticket_id' => $ticketData->id,'customer_id'=>$post['senderId'], 'executive_id' => $post['userId']])->orderBy('id','desc')->first();
            }
        } else {
            if($userDevice->device_type == 'ios' || $userDevice->device_type == 'android'){
                $model = CallRequest::where(['ticket_id' => $ticketData->id,'customer_id' => $post['userId'],'executive_id'=>$post['otherUserId']])->orderBy('id','desc')->first();
            } else {
                $model = CallRequest::where(['ticket_id' => $ticketData->id,'executive_id'=>$post['senderId'], 'customer_id' => $post['userId']])->orderBy('id','desc')->first();
            }
        }

        if (!empty($model)) {
                $model->status = $post['status'];

                if ($post['status'] == 'missed_request') {
                    $model->call_current_status = 'free';
                } else {
                    $model->call_socket_id = @$post['socketId'];
                    $model->call_accepted_time = date('Y-m-d H:i:s');
                    $model->call_current_status = 'busy';
                }
                $model->save();
                if (!empty($ticketData)) {
                    $ticketData->executive_id = $model->executive_id;
                    $ticketData->save();
                }
        }
        
        if ($userData->role == 'executive') {
            if($userDevice->device_type == 'ios' || $userDevice->device_type == 'android'){
                CallRequest::where(['ticket_id' => $ticketData->id])->where('executive_id',"!=", $post['userId'])->delete();
             //   Notification::where(['ticket_id' => $ticketData->id])->where('to_id',"!=", $post['userId'])->delete();
            } else {
                CallRequest::where(['ticket_id' => $ticketData->id,'customer_id'=>$post['senderId']])->where('executive_id',"!=", $post['userId'])->delete();
              //  Notification::where(['ticket_id' => $ticketData->id,'from_id'=>$post['senderId']])->where('to_id',"!=", $post['userId'])->delete();
            }
        } else {
            $callRequestData = CallRequest::where(['ticket_id' => $ticketData->id,'customer_id'=>$post['userId']])->where('status','!=','pending')->get();
            if(!empty($callRequestData)){
                for($i=0;$i<count($callRequestData)-1;$i++){
                    $data = CallRequest::where(['id'=>$callRequestData[$i]->id])->delete();
                 //   Notification::where(['ticket_id' => $callRequestData[$i]->tiket_id])->where('to_id',"!=", $post['userId'])->delete();
                }
            }
        }
        return true;
    }

    // Function to show request analytics on admin and manager dashboard
    public static function requestChartList($post, $userType) {
        $userPendingMonth = array();
        $userResolvedMonth = array();
        $months = array();

        if (isset($post['from_date']) && isset($post['to_date'])) {
            $j = date('m', strtotime($post['from_date']));
//            $k = date('m', strtotime($post['to_date']));
            $year1 = date('Y', strtotime($post['from_date']));
            $year2 = date('Y', strtotime($post['to_date']));

            $month1 = date('m', strtotime($post['from_date']));
            $month2 = date('m', strtotime($post['to_date']));
            $k = (($year2 - $year1) * 12) + ($month2 - $month1);
        } else {
            $year1 = date('Y');
            $j = 1;
            $k = 12;
        }
        $z = 0;
        for ($i = $j; $i <= $j + $k; $i++) {
            $r = $i;
            if ($i > 12) {
                $year1 = $year1 + 1;
                $r = $i - 12;
                $dateObj = \DateTime::createFromFormat('!m', $r);
            } else {
                $dateObj = \DateTime::createFromFormat('!m', $i);
            }
            $monthName = $dateObj->format('M');
            $months[$z] = $monthName;
            $z++;
            $month = 12 - $i;
            $q1 = CallRequest::join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                    ->join('users', 'users.id', 'call_requests.customer_id')
                    ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                    ->where('call_requests.status', '!=', 'missed_request');
            if ($userType == "manager") {
                $q1->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
            }
            if (isset($post['executive_id']) && !empty($post['executive_id'])) {
                $q1 = $q1->where('executive_manager_relations.executive_id', $post['executive_id']);
            }
//            if (isset($post['from_date']) && isset($post['to_date'])) {
//                $q1 = $q1->whereBetween(DB::raw('month(call_requests.created_at)'), array(date('m', strtotime($post['from_date'])), date('m', strtotime($post['to_date']))))
//                                ->where('call_requests.status', 'pending')->get();
//            } else {
            $q1 = $q1->whereMonth('call_requests.created_at', '=', $r)->whereYear('call_requests.created_at', '=', $year1)
                            ->where('call_requests.status', 'pending')->get();
//            }
            $userPendingMonth[$i] = count($q1);

            $q2 = CallRequest::join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                    ->join('users', 'users.id', 'call_requests.customer_id')
                    ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                    ->where('call_requests.status', '!=', 'missed_request');
            if ($userType == "manager") {
                $q2->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
            }
            if (isset($post['executive_id']) && !empty($post['executive_id'])) {
                $q2 = $q2->where('executive_manager_relations.executive_id', $post['executive_id']);
            }
//            if (isset($post['from_date']) && isset($post['to_date'])) {
//                $q2 = $q2->whereBetween(DB::raw('month(call_requests.created_at)'), array(date('m', strtotime($post['from_date'])), date('m', strtotime($post['to_date']))))
//                                ->where('call_requests.status', 'resolved')->get();
//            } else {
            $q2 = $q2->whereMonth('call_requests.created_at', '=', $r)->whereYear('call_requests.created_at', '=', $year1)
                            ->where('call_requests.status', 'resolved')->get();
//            }
            $userResolvedMonth[$i] = count($q2);
        }

        $result['resolved'] = $userResolvedMonth;
        $result['pending'] = $userPendingMonth;
        $result['months'] = $months;
        return $result;
    }

    // Function Run when user(customer/SE) is disconeected During running call
    public static function updateDisconnctUserCallRequest($post) {
        $userId = $post['userId'];
        $socketId = $post['socketId'];
        $userData = User::where(['id' => $userId])->first();
        $type = $userData->role;
        if ($type == 'customer') {
            $userDevice = UserDevice::where(['user_id'=>$userId])->first();
            date_default_timezone_set($userDevice->timezone);
            $date = date('Y-m-d H:i:s');
            $callRequest = CallRequest::where(['customer_id' => $userId,'call_current_status'=>'busy'])->first();
            if (!empty($callRequest)) {
                //foreach ($callRequest as $val) {
                    $callRequest->call_current_status = "free";
                    $callRequest->is_call_dropped = 1;
                    $callRequest->save();
                //}
            }
        } else {
            $userDevice = UserDevice::where(['user_id'=>$userId])->first();
            date_default_timezone_set($userDevice->timezone);
            $date = date('Y-m-d H:i:s');
            $callRequest = CallRequest::where(['executive_id' => $userId,'status'=>'pending','call_current_status'=>'busy','call_socket_id'=>$socketId,'call_time'=>0])->orderBy('id','DESC')->first();
            
            
            
            if (!empty($callRequest)) {
                $callDate = $callRequest->call_accepted_time;
                $datetime1 = new \DateTime($date);
                $datetime2 = new \DateTime($callDate);
                $diff = $datetime1->getTimestamp() - $datetime2->getTimestamp();

                    $callRequest->call_current_status = "free";
                    $callRequest->is_call_dropped = 1;
                    $callRequest->call_time = $diff;
                    $callRequest->save();
                
            }
            
            $callRequestData = $callRequest = CallRequest::where(['executive_id' => $userId,'call_current_status'=>'busy','call_socket_id'=>$socketId])->get();
            if($callRequestData->count() > 0){
                foreach($callRequestData as $val){
                    $val->call_current_status = "free";
                    $val->save();
                }
            }
        }
        if(!empty($callRequest)){
            $logModel = new CallLog();
            $logModel->user_id = $userId;
            $logModel->call_id = @$callRequest->id;
            $logModel->disconnect_reason = $post['reason'];
            $logModel->created_at = $date;
            $logModel->save();
        }
    }

    public static function endUserCall($post) {
        $userId = $post['userId'];
        $userDevice = UserDevice::where(['user_id' => $userId])->first();
        $userData = User::where(['id' => $userId])->first();
        if ($userData->role == "customer") {
            $userType = "executive";
        } else {
            $userType = "customer";
        }
        $data = [
            'notification_type' => 'end_call'
        ];
        $message = "Your current call has been ended";

        if ($userDevice->user_device == "ios") {
            Utility::APNSPushDeviceNotification($userDevice->device_id, $message, $userType, $data, 0, 0);
        } else {
            Utility::FcmPushNotification([$userDevice->device_id], $message, $userType, $data, 0, 0);
        }
    }

    public static function getCustomerRequestByTicketId($ticketId) {
        $executiveId = Auth::guard('web')->user()->id;
        $request = CallRequest::where(['ticket_id' => $ticketId, 'executive_id' => $executiveId])->first();
        return $request;
    }

    // Notify time notification send for executive  by cron 
    public static function cronNotification() {
        error_reporting(E_ALL);
        $defaultTimeZone = \Config::get('constants.default_time_zone');
        date_default_timezone_set("$defaultTimeZone");
        $cDate = date('Y-m-d H:i');
        $currentDate = strtotime($cDate);
        $futureDate = $currentDate+(60*10);
        $eDate = date("Y-m-d H:i", $futureDate);
        $callRequest = CallRequest::whereBetween('notify_date_time', array($cDate, $eDate))->where('notify_type', '!=', 'when_online')->get();
       if ($callRequest->count() > 0) {
            foreach ($callRequest as $val) {
                $userName = \App\Http\Models\User::getUserDataByKey($val->customer_id, 'contact_name');
                $receiverData = \App\Http\Models\UserDevice::where(['user_id' => $val->executive_id])->first();
                $userData = \App\Http\Models\User::where(['id' => $val->executive_id])->first();
                $image = User::getUserDataByKey($val->customer_id, 'profile_image');
                $callerImage = checkProfileImage($image);
                $date = date('d M Y H:i', strtotime($val->notify_date_time));
                $message = "You have to callback to $userName at $date";
                $data = [
                    'notification_type' => 'panding_request_notifier',
                    'userJID' => $val->customer_id,
                    'ticketId' => getTicketById($val->ticket_id),
                    'receiverId' => $val->executive_id,
                    'caller_name' => $userName,
                    'caller_image' => $callerImage,
                    'message' => $message
                ];
                if (!empty($receiverData)) {
                    if ($receiverData->device_type == "ios") {
                        @Utility::APNSPushDeviceNotification($receiverData->device_id, $message, $userData->role, $data, $val->customer_id, $val->executive_id);
                    } else {
                        @Utility::FcmPushNotification([$receiverData->device_id], $message, $userData->role, $data, $val->customer_id, $val->executive_id);
                    }
                }
            }
            return true;
        }
        return true;
    }

    // Update current call status as "DROPPED" when call is dropped 
    public static function updateDroppedCallRequest($userId){
        $callRequest = callRequest::where(['executive_id'=>$userId])->orderBy('id','desc')->first();
        if(!empty($callRequest)){
            $callRequest->is_call_dropped = 1;
            $callRequest->save();
        }
    }
    
    //Get Notes history by customer Id
    public static function getNotesHistoryByCustomerId($data) {
        $customerId = $data['customer_id'];
        $lastDate = \Carbon\Carbon::today()->subDays(30);
        $lists = CallRequest::where('customer_id', $customerId)
                        ->where('notes', '!=', "")
                        ->where('created_at', '>=', date($lastDate))
                        ->orderBy('id', 'DESC')->get();
        $arr = [];
        if (!empty($lists) && count($lists) > 0) {
            $dateArr = [];
            foreach ($lists as $list) {
                $date = date('Y-m-d', strtotime($list->created_at));
                if (!in_array($date, $dateArr)) {
                    array_push($dateArr, $date);

                    $callData = CallRequest::where('customer_id', $customerId)
                                    ->where('notes', '!=', "")
                                    ->where(\DB::raw("date(created_at)"), '=', "$date")
                                    ->orderBy('id', 'DESC')->get();

                                   
                    if (!empty($callData)) {
                        foreach ($callData as $row){
                            $row->executive_name = User::getUserDataByKey($row->executive_id, 'contact_name');
                        }
                        $myArr = [];
                        $myArr['date'] = $date;
                        $myArr['data'] = $callData;
                        $arr[] = $myArr;
                    }
                }
            }
            return $arr;
        } return false;
    }
    
    // Send Notification When user is busy
    public static function sendBusyNotification($post){
        $userId = Auth::guard('web')->user()->id;
        $userDeviceData = UserDevice::where(['user_id' => $post['customerId']])->first();
        $userName = \App\Http\Models\User::getUserDataByKey($userId, 'contact_name');
        $image = \App\Http\Models\User::getUserDataByKey($userId, 'profile_image');
        $callerImage = checkProfileImage($image);
        $managerData = getManagerByExecutiveId($userId);
        $managerName = \App\Http\Models\User::getUserDataByKey($managerData, 'contact_name');
        $waitingTime = \App\Http\Models\User::getManagerWaitingTimeById($userId);
        if (!empty($userDeviceData)) {
                    $executiveName = User::getUserDataByKey($userId, 'contact_name');
                    $message = "You have a missed call from $executiveName";
                    $userType = 'customer';
                    $data = [
                    'notification_type' => 'missed_call_request',
                    'userJID' =>$userId,
                    'ticketId' => $post['ticketId'],
                    'receiverId' => $post['customerId'],
                    'caller_name' => $userName,
                    'caller_image' => $callerImage,
                    'manager_name' => $managerName,
                    'message'=>$message,
                    'waiting_time' =>$waitingTime 
                ];
                    if ($userDeviceData->device_type == "ios") {
                        Utility::APNSPushDeviceNotification($userDeviceData->device_id, $message, 'customer', $data, $userId, $post['customerId']);
                    } else {
                        Utility::FcmPushNotification([$userDeviceData->device_id], $message, 'customer', $data, $userId,$post['customerId']);
                    }
                    
                }
    }

}
