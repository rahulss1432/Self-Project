<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use JWTAuth;

class ExecutiveCategory extends Model {
    /*
     * relation with bank category table by category_id
     */

    public function bankCategory() {
        return $this->belongsTo('App\Http\Models\BankingCategory', 'category_id');
    }

    public static function getCategoriesById($id) {
        return ExecutiveCategory::where('executive_id', $id)->get();
    }

    public static function getAllExecutiveCategories() {
        return ExecutiveCategory::get();
    }

    public static function getExecutiveCategoryName($category_id) {
        $category = BankingCategory::where(['id' => $category_id])->first();
        return ($category) ? $category['name'] : '';
    }

    public static function getCategoryExecutive($get) {
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        $userId = $user->id;
        if($user->user_type == 'customer'){
             $customerRelationData = CustomerExecutiveRelation:: select('manager_id')
                        ->where(['customer_id' => $userId])
                        ->groupBy('customer_id')->first();
        }else{
             $customerRelationData = ExecutiveManagerRelation:: select('manager_id')
                        ->where(['executive_id' => $userId])
                        ->first();
        }
       
        if (!empty($customerRelationData)) {
            $executives = ExecutiveCategory:: select('executive_categories.*', 'executive_manager_relations.executive_id')
                    ->join('executive_manager_relations', 'executive_manager_relations.executive_id', 'executive_categories.executive_id')
                    ->join('users', 'executive_manager_relations.executive_id', 'users.id')
                    ->where(['executive_manager_relations.manager_id' => $customerRelationData->manager_id])
                    ->where(['executive_categories.category_id' => $get['category_id']])
                    ->where(['status' => 'active'])
                    ->get();
            if (count($executives) > 0) {
                foreach ($executives as $val) {
                    $executive = User::getUserById($val->executive_id);
                    $val->first_name = $executive['first_name'];
                    $val->last_name = $executive['last_name'];
                    $val->contact_name = $executive['contact_name'];
                }
                return $executives;
            }
             return false;
        }
        return false;
    }

    //Rahul : get category by executive
    public static function getCategoriesByExecutiveId($id) {
        return ExecutiveCategory::select('banking_categories.name')
                        ->join('banking_categories', 'executive_categories.category_id', 'banking_categories.id')
                        ->where('executive_categories.executive_id', $id)->get();
    }

}
