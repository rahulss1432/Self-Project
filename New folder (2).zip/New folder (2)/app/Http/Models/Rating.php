<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use JWTAuth;
use App\Http\Models\Ticket;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Collection;

class Rating extends Model {

    //Rahul : get executive by executive id
    public function executiveDetail() {
        return $this->belongsTo('App\Http\Models\User', 'executive_id');
    }

    public static function rateToExecutive($post) {

        $rating = new Rating();
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if (!empty($user)) {
            $ticketData = Ticket::where(['ticket_number' => $post['ticket_id']])->first();
            $ticketId = 0;
            $requestId = 0;
            $executiveId = 0;
            if (!empty($ticketData)) {
                $userDevice = UserDevice::where(['user_id'=>$user->id])->first();
                if($userDevice->device_type == "ios"){
                    $request = CallRequest::where(['ticket_id' => $ticketData->id])->orderBy('id','DESC')->first();
                } else {
                    $request = CallRequest::where(['ticket_id' => $ticketData->id])->where('status','!=','missed_request')->first();
                }
                if (!empty($request)) {
                    $requestId = $request->id;
                    $executiveId = $request->executive_id;
                }
            }
            $rating->request_id = $requestId;
            $rating->customer_id = $user->id;
            $rating->executive_id = $executiveId;
            $rating->behaviour_rating = $post['executive_rating'];
            $rating->waiting_time_rating = $post['waiting_rating'];
            $rating->overall_rating = $post['overall_rating'];
            $rating->review = $post['review'];
            if ($rating->save()) {
                return true;
            }
        }
        return false;
    }

    //Rahul : get top five ratings on dashboard by executives
    public static function getTopFiveRatings($userType) {
        $getRatings = Rating::select(DB::raw("ratings.executive_id, round((SUM(behaviour_rating) + SUM(waiting_time_rating) + SUM(overall_rating))/3/COUNT(*)) as avgRating"))
                ->join('call_requests', 'call_requests.id', 'ratings.request_id')
                ->join('executive_manager_relations', 'ratings.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'ratings.executive_id')
                ->where('users.status', '!=', 'deleted')
                ->groupBy('ratings.executive_id')
                ->orderBy('avgRating', 'desc');
        if ($userType == "manager") {
            $getRatings->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        return $getRatings->take(5)->get();
    }

    //Rahul : get top five ratings on dashboard by executives
    public static function getAllRatings($post, $userType) {
        $getRatings = Rating::select(DB::raw("ratings.executive_id, round((SUM(behaviour_rating) + SUM(waiting_time_rating) + SUM(overall_rating))/3/COUNT(*)) as avgRating"))
                ->join('call_requests', 'call_requests.id', 'ratings.request_id')
                ->join('executive_manager_relations', 'ratings.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'ratings.executive_id')
                ->where('users.status', '!=', 'deleted')
                ->groupBy('ratings.executive_id')
                ->orderBy('avgRating', 'desc');
        if ($userType == "manager") {
            $getRatings->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if (isset($post['name']) && !empty($post['name'])) {
            $getRatings->where('users.contact_name', 'like', '%' . $post['name'] . '%');
        }
        if (isset($post['email']) && !empty($post['email'])) {
            $getRatings->where('users.email', 'like', '%' . $post['email'] . '%');
        }
        $getData = $getRatings->get();
        if (isset($post['rating']) && !empty($post['rating'])) {
            $getData = collect($getData);
            $getData = $getData->where('avgRating', '=', $post['rating']);
//            $getData = $getData->where(round('avgRating'), '<=', $post['rating'] + 1);
            $getData = $getData->all();
        }
        return $getData;
    }
    public static function getRequestRating($id){
        $model = Rating::where('request_id',$id)->first();
        if(!empty($model)){
            $i = 0;
            $number = 0;
            if($model->behaviour_rating != ''){
                $i++;
                $number += $model->behaviour_rating;
            }
            if($model->waiting_time_rating != ''){
                $i++;
                $number += $model->waiting_time_rating;
            }
            if($model->overall_rating != ''){
                $i++;
                $number += $model->overall_rating;
            }
            if($i > 0){
                $rating = round($number/$i);
            } else {
                $rating = 0;
            }
            return $rating;
        }
        return 0;
    }
    
    public static function getReviewRating($id){
        $model = Rating::where('request_id', $id)->first();
        return $model;
    }
    
    public static function getAverageRatingByExecutiveId($executiveId){
        $ratingData = Rating::where(['executive_id'=>$executiveId])->get();
        if($ratingData->count() > 0){
            $totalrating = 0;
            foreach ($ratingData as $val){
                $i=0;
                $rating = 0;
                if($val->behaviour_rating!="" && $val->behaviour_rating!="NULL"){
                    $rating+=$val->behaviour_rating;
                }
                if($val->waiting_time_rating!="" && $val->waiting_time_rating!="NULL"){
                    $rating+=$val->waiting_time_rating;
                }
                if($val->overall_rating!="" && $val->overall_rating!="NULL"){
                    $rating+=$val->overall_rating;
                }
                if($rating > 0){
                    $avgRating = $rating/3;
                    $totalrating+= $avgRating;
                } else {
                    $totalrating+= $rating;
                }
                
            }
            return $totalrating/$ratingData->count();
        }
        return 0;
    }
}
