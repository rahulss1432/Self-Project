<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;
use App\Http\Models\CustomerExecutiveRelation;
use App\Http\Models\ExecutiveManagerRelation;
use App\Http\Models\UserProfile;
use App\Http\Models\Bank;
use App\Http\Models\ExecutiveCategory;
use App\Http\Models\ExecuitveSupervisor;
use JWTAuth;
use App\Common\Utility;

class User extends Model {
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'username','role', 'password', 'email','contact_name'
    ];
    /*
     * relation with user profile table by user_id
     */

    public function userDetail() {
        return $this->hasOne('App\Http\Models\UserProfile', 'user_id');
    }

    /*
     * relation with bank category table by category_id
     */

    public function bankCategory() {
        return $this->belongsTo('App\Http\Models\BankingCategory', 'category_id');
    }

    /*
     * relation with bank table by bank_id
     */

    public function bank() {
        return $this->belongsTo('App\Http\Models\Bank', 'bank_id');
    }

    /*
     * relation with customer_executive_relations table by executive_id
     */

    public function customerExecutive() {
        return $this->hasMany('App\Http\Models\CustomerExecutiveRelation', 'executive_id');
    }

    /*
     * relation with executive_supervisor table by executive_id
     */

    public function executiveSupervisor() {
        return $this->hasOne('App\Http\Models\ExecuitveSupervisor', 'executive_id');
    }

    public function userDevices() {
        return $this->hasOne('App\http\Models\UserDevice', 'user_id');
    }

    /*
     * get all users's where type executive
     */

    //R : get all executive by admin
    public static function getAllExecutives($post) {
        $user = User::select('users.*', 'user_profiles.executive_number')
                        ->join('user_profiles', 'users.id', 'user_profiles.user_id')
                        ->where('role', '=', 'executive')->where('status', '!=', 'deleted');

        if (isset($post['name']) && !empty($post['name'])) {
            $user->where('users.contact_name', 'like', '%' . $post['name'] . '%');
        }
        if (isset($post['email']) && !empty($post['email'])) {
            $user->where('users.email', 'like', '%' . $post['email'] . '%');
        }
        if (isset($post['executive_number']) && !empty($post['executive_number'])) {
            $user->where('user_profiles.executive_number', 'like', '%' . $post['executive_number'] . '%');
        }
        if (isset($post['phone']) && !empty($post['phone'])) {
            $user->where('users.phone_number', 'like', '%' . $post['phone'] . '%');
        }
        if (isset($post['city_state']) && !empty($post['city_state'])) {
            $user->where(function ($query) use ($post) {
                $query->where('users.city', 'like', '%' . $post['city_state'] . '%')
                        ->orWhere('users.state', 'like', '%' . $post['city_state'] . '%');
            });
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $catId = implode(',', $post['category_id']);
            $user->Join('executive_categories', 'users.id', 'executive_categories.executive_id')->whereIn('executive_categories.category_id', [$catId]);
        }
        if (isset($post['status']) && !empty($post['status'])) {
            $user->where('users.status', $post['status']);
        }
        return $user->orderBy('users.id', 'desc')->paginate(10);
    }
    
    //R : get all executive by admin
    public static function getAllExecutivesForCsv($post) {
        $user = User::select('users.*', 'user_profiles.executive_number')
                        ->join('user_profiles', 'users.id', 'user_profiles.user_id')
                        ->where('role', '=', 'executive')->where('status', '!=', 'deleted');

        if (isset($post['name']) && !empty($post['name'])) {
            $user->where('users.contact_name', 'like', '%' . $post['name'] . '%');
        }
        if (isset($post['email']) && !empty($post['email'])) {
            $user->where('users.email', 'like', '%' . $post['email'] . '%');
        }
        if (isset($post['executive_number']) && !empty($post['executive_number'])) {
            $user->where('user_profiles.executive_number', 'like', '%' . $post['executive_number'] . '%');
        }
        if (isset($post['phone']) && !empty($post['phone'])) {
            $user->where('users.phone_number', 'like', '%' . $post['phone'] . '%');
        }
        if (isset($post['city_state']) && !empty($post['city_state'])) {
            $user->where(function ($query) use ($post) {
                $query->where('users.city', 'like', '%' . $post['city_state'] . '%')
                        ->orWhere('users.state', 'like', '%' . $post['city_state'] . '%');
            });
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $catId = implode(',', $post['category_id']);
            $user->Join('executive_categories', 'users.id', 'executive_categories.executive_id')->whereIn('executive_categories.category_id', [$catId]);
        }
        if (isset($post['status']) && !empty($post['status'])) {
            $user->where('users.status', $post['status']);
        }
        return $user->orderBy('users.id', 'desc')->get();
    }

    /*
     * get all users's where type executive by manager id
     */

    public static function getAllExecutivesByManager($post, $callFrom) {
        $user = User::select('users.*', 'user_profiles.executive_number')
                ->join('user_profiles', 'users.id', 'user_profiles.user_id')
                ->join('executive_manager_relations', 'users.id', 'executive_manager_relations.executive_id')
                ->where('status', '!=', 'deleted')
                ->where('executive_manager_relations.manager_id', Auth::guard(getAuthGuard())->user()->id);
        if ($callFrom == 'count') {
            return $user->get()->count();
        }
        if (isset($post['executive_number']) && !empty($post['executive_number'])) {
            $user->where('user_profiles.executive_number', 'like', '%' . $post['executive_number'] . '%');
        }
        if (isset($post['name']) && !empty($post['name'])) {
            $user->where('users.contact_name', 'like', '%' . $post['name'] . '%');
        }
        if (isset($post['email']) && !empty($post['email'])) {
            $user->where('users.email', 'like', '%' . $post['email'] . '%');
        }
        if (isset($post['phone']) && !empty($post['phone'])) {
            $user->where('users.phone_number', 'like', '%' . $post['phone'] . '%');
        }
        if (isset($post['city_state']) && !empty($post['city_state'])) {
            $user->where(function ($query) use ($post) {
                $query->where('users.city', 'like', '%' . $post['city_state'] . '%')
                        ->orWhere('users.state', 'like', '%' . $post['city_state'] . '%');
            });
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $catId = implode(',', $post['category_id']);
            $user->Join('executive_categories', 'users.id', 'executive_categories.executive_id')->whereIn('executive_categories.category_id', [$catId]);
        }
        if (isset($post['status']) && !empty($post['status'])) {
            $user->where('users.status', $post['status']);
        }
        return $user->orderBy('users.id', 'desc')->paginate(10);
    }
    
    public static function getAllExecutivesByManagerForCSV($post, $callFrom) {
        $user = User::select('users.*', 'user_profiles.executive_number')
                ->join('user_profiles', 'users.id', 'user_profiles.user_id')
                ->join('executive_manager_relations', 'users.id', 'executive_manager_relations.executive_id')
                ->where('status', '!=', 'deleted')
                ->where('executive_manager_relations.manager_id', Auth::guard(getAuthGuard())->user()->id);
        if ($callFrom == 'count') {
            return $user->get()->count();
        }
        if (isset($post['executive_number']) && !empty($post['executive_number'])) {
            $user->where('user_profiles.executive_number', 'like', '%' . $post['executive_number'] . '%');
        }
        if (isset($post['name']) && !empty($post['name'])) {
            $user->where('users.contact_name', 'like', '%' . $post['name'] . '%');
        }
        if (isset($post['email']) && !empty($post['email'])) {
            $user->where('users.email', 'like', '%' . $post['email'] . '%');
        }
        if (isset($post['phone']) && !empty($post['phone'])) {
            $user->where('users.phone_number', 'like', '%' . $post['phone'] . '%');
        }
        if (isset($post['city_state']) && !empty($post['city_state'])) {
            $user->where(function ($query) use ($post) {
                $query->where('users.city', 'like', '%' . $post['city_state'] . '%')
                        ->orWhere('users.state', 'like', '%' . $post['city_state'] . '%');
            });
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $catId = implode(',', $post['category_id']);
            $user->Join('executive_categories', 'users.id', 'executive_categories.executive_id')->whereIn('executive_categories.category_id', [$catId]);
        }
        if (isset($post['status']) && !empty($post['status'])) {
            $user->where('users.status', $post['status']);
        }
        return $user->orderBy('users.id', 'desc')->get();
    }

    /*
     * save new executive
     */

    public static function saveExecutive($post) {
        try {
            DB::beginTransaction();
            $model = new User();
            $model->contact_name = $post['contact_name'];
            $model->email = $post['email'];
            $model->username = $post['username'];
            $model->phone_number = $post['phone'];
            $model->role = 'executive';
            $model->city = $post['city'];
            $model->state = $post['state'];
            $model->profile_image = $post['hiddenFileName'];
            $model->created_by = Auth::guard(getAuthGuard())->user()->id;
            $model->status = 'active';
            $model->password = bcrypt($post['password']);
            $model->password_base64 = base64_encode($post['password']);
            $model->company_name = $post['company'];
            $model->save();
            /* save data to user profile table */
            $userProfile = new UserProfile();
            $userProfile->user_id = $model->id;
            $userProfile->executive_number = $post['executive_number'];
            $userProfile->bussiness_address = $post['bussiness_address'];
            $userProfile->save();
            /* save this exective to customer relation model */
             if(isset($post['supervisor_customer'])){
                foreach ($post['supervisor_customer'] as $customer) {
                        $relationModel = new CustomerExecutiveRelation();
                        $relationModel->customer_id = $customer;
                        $relationModel->executive_id = $model->id;
                        $relationModel->manager_id = $post['manager_id'];
                        $relationModel->linked_by = $model->created_by;
                        $relationModel->save();
                    }
             }
            $executiveManagerModel = new ExecutiveManagerRelation();
            $executiveManagerModel->executive_id = $model->id;
            $executiveManagerModel->manager_id = $post['manager_id'];
            $executiveManagerModel->save();
            foreach ($post['category'] as $category) {
                $categoryModel = new ExecutiveCategory();
                $categoryModel->executive_id = $model->id;
                $categoryModel->category_id = $category;
                $categoryModel->save();
            }
            /* save this exective's supervisor to executive supervisor model */
            $supervisorModel = new ExecuitveSupervisor();
            $supervisorModel->executive_id = $model->id;
            $supervisorModel->name = $post['supervisor_name'];
            $supervisorModel->email = $post['supervisor_email'];
            $supervisorModel->phone_number = $post['supervisor_phone'];
            if (isset($post['supervisor_customer']) && !empty($post['supervisor_customer'])) {
                $supervisorModel->customer_id = implode(',', $post['supervisor_customer']);
            } else {
                $supervisorModel->customer_id = NULL;
            }
            $supervisorModel->save();
            /* send mail function for user credentials */
            $data = [];
            $data['name'] = $model->first_name . ' ' . $model->last_name;
            $data['username'] = $model->username;
            $data['email'] = $model->email;
            $data['password'] = $post['password'];
            $data['subject'] = 'User Credentials';
            $data['request'] = 'user_mail';
            $data['user_role'] = $model->role;
            $data['created_by_role'] = Auth::guard(getAuthGuard())->user()->role;
            $mail = sendMail($data);
            DB::commit();
            return Response::json(['success' => true, 'message' => \Config::get('constants.executive_added')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * update executive
     */

    public static function updateExecutive($post) {
        try {
            DB::beginTransaction();
            $model = User::where('id', $post['user_id'])->first();
            $model->contact_name = $post['contact_name'];
            $model->email = $post['email'];
            $model->phone_number = $post['phone'];
            $model->role = 'executive';
            $model->city = $post['city'];
            $model->state = $post['state'];
            $model->profile_image = $post['hiddenFileName'];
            $model->updated_by = Auth::guard(getAuthGuard())->user()->id;
            $model->status = 'active';
            $model->company_name = $post['company'];
            $model->save();
            /* save data to user profile table */
            $userProfileModel = UserProfile::where('user_id', $model->id)->first();
            $userProfileModel->executive_number = $post['executive_number'];
            $userProfileModel->bussiness_address = $post['bussiness_address'];
            $userProfileModel->save();
            /* save this exective to customer relation model */
            CustomerExecutiveRelation::where(['executive_id' => $model->id])->delete();
            if(isset($post['supervisor_customer'])){
               
                 foreach ($post['supervisor_customer'] as $customer) {
                    $relationModel = new CustomerExecutiveRelation();
                    $relationModel->customer_id = $customer;
                    $relationModel->executive_id = $model->id;
                    $relationModel->manager_id = $post['manager_id'];
                    $relationModel->linked_by = $model->created_by;
                    $relationModel->save();
                }
            }
            // save this exective to executive relation model 
            $executiveManagerModel = ExecutiveManagerRelation::where('executive_id', $model->id)->first();
            $executiveManagerModel->executive_id = $model->id;
            $executiveManagerModel->manager_id = $post['manager_id'];
            $executiveManagerModel->save();
            /* update this exective's category to executive_category model */
            ExecutiveCategory::where([
                'executive_id' => $model->id
            ])->delete();
            foreach ($post['category'] as $category) {
                $categoryModel = new ExecutiveCategory();
                $categoryModel->executive_id = $model->id;
                $categoryModel->category_id = $category;
                $categoryModel->save();
            }
            /* save this exective's supervisor to executive supervisor model */
            $supervisorModel = ExecuitveSupervisor::where('executive_id', $model->id)->first();
            if (empty($supervisorModel)) {
                $supervisorModel = new ExecuitveSupervisor();
                $supervisorModel->executive_id = $model->id;
            }
            $supervisorModel->name = $post['supervisor_name'];
            $supervisorModel->email = $post['supervisor_email'];
            $supervisorModel->phone_number = $post['supervisor_phone'];
            if (isset($post['supervisor_customer']) && !empty($post['supervisor_customer'])) {
                $supervisorModel->customer_id = implode(',', $post['supervisor_customer']);
            } else {
                $supervisorModel->customer_id = NULL;
            }
            $supervisorModel->save();

            DB::commit();
            return Response::json(['success' => true, 'message' => \Config::get('constants.executive_updated')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getLine()]);
        }
    }

    public static function getCustomerLinkedById() {
        return User::where('role', 'customer')->where('status', '!=', 'deleted')->get();
    }

    public static function getCustomerLinkedByManagerId($id) {
//        return User::where('role', 'customer')->where('status', 'active')->where('created_by', $id)->get();
        return User::select('users.*')
                ->join('customer_executive_relations', 'users.id', '=', 'customer_executive_relations.customer_id')
                ->where('users.status', 'active')
                ->where('customer_executive_relations.manager_id', $id)
                ->groupBy('customer_id')->get();
//        return $customeres;
    }

    /*
     * change  users's status
     */

    public static function changeUserStatus($post) {
        try {
            if ($post['status'] == 'deleted') {
                $msg = \Config::get('constants.user_deleted');
            } else {
                $msg = \Config::get('constants.status_updated');
            }
            $model = User::where('id', $post['id'])->first();
            $model->status = $post['status'];
            $model->save();
            //N:- delete customer from customer Executive Relation 
            if($post['status'] == 'deleted' && !empty($model)){
                if($model->role == "manager"){
                    $customer = CustomerExecutiveRelation::where('manager_id',$post['id'])->delete();
                } else if($model->role == "executive"){
                    $customer = CustomerExecutiveRelation::where('executive_id',$post['id'])->get();
                    if(!empty($customer)){
                        foreach($customer as $val){
                            $data = CustomerExecutiveRelation::where('customer_id','=',$val->customer_id)->where('executive_id','!=',$post['id'])->get();
                            if(empty($data)){
                                $data = CustomerExecutiveRelation::where('customer_id','=',$val->customer_id)->where('executive_id','!=',$post['id'])->delete();
                            }
                        }
                    }
                }
            } 
            if($model->role == "manager"){
                    $customer = CustomerExecutiveRelation::where('manager_id',$post['id'])->get();
                    if(!empty($customer)){
                        foreach($customer as $val){
                            $userData = User::where(['id'=>$val->customer_id])->first();
                            if(!empty($userData)){
                                $userData->status = $post['status'];
                                $userData->save();
                            }
                            $userDetail = User::where(['id'=>$val->executive_id])->first();
                            if(!empty($userDetail)){
                                $userDetail->status = $post['status'];
                                $userDetail->save();
                            }
                        }
                    }
                } else if($model->role == "executive"){
                    $customer = CustomerExecutiveRelation::where('executive_id',$post['id'])->get();
                    
                }
            return Response::json(['success' => true, 'message' => $msg]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * get users details by id
     */

    public static function getUserById($userId) {
        return User::where('id', $userId)->where('status', '!=', 'deleted')->first();
    }
    /*
     * get cumtomer assign executive by id
     */

    public static function getAssignCustomer($executiveId) {
        return CustomerExecutiveRelation::where('executive_id', $executiveId)->get();
      
    }

    //R : get user details by id
    public static function getUsersByType($userId, $userType) {
        if (Auth::guard(getAuthGuard())->user()->role == "manager") {
            if ($userType == "customer") {
                return User::select('users.*')->join('user_profiles', 'users.id', 'user_profiles.user_id')
                                ->join('customer_executive_relations', 'customer_executive_relations.customer_id', 'users.id')
                                ->where('users.id', $userId)
                                ->where('users.role', '=', $userType)
                                ->where('users.status', '!=', 'deleted')
                                ->where('customer_executive_relations.manager_id', Auth::guard(getAuthGuard())->user()->id)->first();
            } else {
               
                return User::select(['users.*','user_profiles.bussiness_address','user_profiles.executive_number'])
                                ->join('user_profiles', 'users.id', 'user_profiles.user_id')
                                ->join('executive_manager_relations', 'users.id', 'executive_manager_relations.executive_id')
                                ->where('users.id', $userId)
                                ->where('users.role', '=', $userType)
                                ->where('users.status', '!=', 'deleted')
                                ->where('executive_manager_relations.manager_id', Auth::guard(getAuthGuard())->user()->id)->first();
            }
        } else {
            return User::where('id', $userId)->where('role', '=', $userType)->where('status', '!=', 'deleted')->first();
        }
    }

    /*
     * get all users's where type customer
     */

    public static function getAllMerchant($post) {
        $user = User::join('user_profiles', 'users.id', 'user_profiles.user_id')
                ->join('customer_executive_relations', 'customer_executive_relations.customer_id', 'users.id')
                ->where('users.role', '=', 'customer')
                ->where('users.status', '!=', 'deleted')
                ->where('customer_executive_relations.manager_id', Auth::guard(getAuthGuard())->user()->id);
        if (isset($post['name']) && !empty($post['name'])) {
            $searchData = $post['name'];
            $user->where(function($query) use($searchData) {
                $query->where(DB::raw('CONCAT(users.first_name," ",users.last_name)'), 'like', '%' . $searchData . '%');
            });
        }
        if (isset($post['merchant_number']) && !empty($post['merchant_number'])) {
            $user->where('user_profiles.merchant_number', 'like', '%' . $post['merchant_number'] . '%');
        }
        if (isset($post['bussiness_name']) && !empty($post['bussiness_name'])) {
            $user->where('user_profiles.bussiness_name', 'like', '%' . $post['bussiness_name'] . '%');
        }
        if (isset($post['phone_number']) && !empty($post['phone_number'])) {
            $user->where('users.phone_number', 'like', '%' . $post['phone_number'] . '%');
        }
        if (isset($post['bussiness_address']) && !empty($post['bussiness_address'])) {
            $user->where('user_profiles.bussiness_address', 'like', '%' . $post['bussiness_address'] . '%');
        }
        return $user->orderBy('users.id', 'desc')->groupBy('customer_executive_relations.customer_id')->paginate(10);
    }
    
    public static function getAllMerchantForCSV($post) {
        $user = User::join('user_profiles', 'users.id', 'user_profiles.user_id')
                ->join('customer_executive_relations', 'customer_executive_relations.customer_id', 'users.id')
                ->where('users.role', '=', 'customer')
                ->where('users.status', '!=', 'deleted')
                ->where('customer_executive_relations.manager_id', Auth::guard(getAuthGuard())->user()->id);
        if (isset($post['name']) && !empty($post['name'])) {
            $searchData = $post['name'];
            $user->where(function($query) use($searchData) {
                $query->where(DB::raw('CONCAT(users.first_name," ",users.last_name)'), 'like', '%' . $searchData . '%');
            });
        }
        if (isset($post['merchant_number']) && !empty($post['merchant_number'])) {
            $user->where('user_profiles.merchant_number', 'like', '%' . $post['merchant_number'] . '%');
        }
        if (isset($post['bussiness_name']) && !empty($post['bussiness_name'])) {
            $user->where('user_profiles.bussiness_name', 'like', '%' . $post['bussiness_name'] . '%');
        }
        if (isset($post['phone_number']) && !empty($post['phone_number'])) {
            $user->where('users.phone_number', 'like', '%' . $post['phone_number'] . '%');
        }
        if (isset($post['bussiness_address']) && !empty($post['bussiness_address'])) {
            $user->where('user_profiles.bussiness_address', 'like', '%' . $post['bussiness_address'] . '%');
        }
        return $user->orderBy('users.id', 'desc')->groupBy('customer_executive_relations.customer_id')->get();
    }

    /*
     * save new merchant
     */

    public static function saveMerchant($post) {
        $managerId = $post['manager_id'];
        $customer_limit = User::select('customer_limit')->where('id', $managerId)->first();
        $CsvLimit = $customer_limit->customer_limit;
        $totalCustomer = CustomerExecutiveRelation::where('manager_id', $managerId)->groupBy('customer_id')->get();
        $totalData = $totalCustomer->count();
        $dataLimit = $CsvLimit - $totalData;
        if($dataLimit > 0){
            try {
            DB::beginTransaction();
            $model = new User();
            $model->contact_name = $post['contact_name'];
            $model->email = $post['email'];
            $model->username = $post['username'];
            $model->role = 'customer';
            $model->phone_number = $post['phone'];
            $model->city = $post['city'];
            $model->state = $post['state'];
            $model->profile_image = $post['hiddenFileName'];
            $model->created_by = Auth::guard(getAuthGuard())->user()->id;
            $model->updated_by = Auth::guard(getAuthGuard())->user()->id;
            $model->status = 'active';
            $model->password = bcrypt($post['password']);
            $model->password_base64 = base64_encode($post['password']);
            if ($model->save()) {
                $userProfile = new UserProfile();
                $userProfile->user_id = $model->id;
                $userProfile->merchant_number = $post['merchant_number'];
//                $userProfile->product = $post['product'];
                $userProfile->bussiness_name = $post['bussiness_name'];
                $userProfile->bussiness_address = $post['bussiness_address'];
//                $userProfile->terminal_model = $post['terminal_model'];
                $userProfile->machine_model = $post['machine_model'];
                $userProfile->save();
                foreach ($post['executive'] as $executive) {
                    $relationModel = new CustomerExecutiveRelation();
                    $relationModel->customer_id = $model->id;
                    $relationModel->executive_id = $executive;
                    $relationModel->manager_id = $post['manager_id'];
                    $relationModel->linked_by = $model->created_by;
                    $relationModel->save();
                }
                // send mail function for user credentials 
                $data = [];
                $data['name'] = $model->first_name . ' ' . $model->last_name;
                $data['username'] = $model->username;
                $data['email'] = $model->email;
                $data['password'] = $post['password'];
                $data['subject'] = 'User Credentials';
                $data['request'] = 'user_mail';
                $data['user_role'] = $model->role;
                $data['created_by_role'] = Auth::guard(getAuthGuard())->user()->role;
                $mail = sendMail($data);
                DB::commit();
            } else {
                DB::rollBack();
            }
            return Response::json(['success' => true, 'message' => \Config::get('constants.merchant_added')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
        }else{
             return Response::json(['success' => false, 'message' =>'The manager`s customer limit is over.']); 
        }
        
    }

    /*
     * update merchant
     */

    public static function updateMerchant($post) {
        try {
            DB::beginTransaction();
            $model = User::where('id', $post['user_id'])->first();
            $model->contact_name = $post['contact_name'];
            $model->email = $post['email'];
            $model->role = 'customer';
            $model->phone_number = $post['phone'];
            $model->city = $post['city'];
            $model->state = $post['state'];
            $model->profile_image = $post['hiddenFileName'];
            $model->updated_by = Auth::guard(getAuthGuard())->user()->id;
            $model->status = 'active';
            if ($model->save()) {
                $userProfile = UserProfile::where('user_id', $post['user_id'])->first();
                $userProfile->user_id = $model->id;
//                $userProfile->product = $post['product'];
                $userProfile->bussiness_name = $post['bussiness_name'];
                $userProfile->bussiness_address = $post['bussiness_address'];
                $userProfile->machine_model = $post['machine_model'];
//                $userProfile->terminal_model = $post['terminal_model'];
                $userProfile->merchant_number = $post['merchant_number'];
                $userProfile->save();
                CustomerExecutiveRelation::where(['customer_id' => $model->id])->delete();
                foreach ($post['executive'] as $executive) {
                    $relationModel = new CustomerExecutiveRelation();
                    $relationModel->customer_id = $model->id;
                    $relationModel->executive_id = $executive;
                    $relationModel->manager_id = $post['manager_id'];
                    $relationModel->linked_by = $model->created_by;
                    $relationModel->save();
                }
                DB::commit();
            } else {
                DB::rollBack();
            }
            return Response::json(['success' => true, 'message' => $msg = \Config::get('constants.merchant_updated')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    //R : get all manager by admin
    public static function getManagerList($request) {
        $lists = User::where('role', 'manager')->where('status', '!=', 'deleted')->orderBy('id', 'desc');
        if (isset($request['name']) && !empty($request['name'])) {
            $lists->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $request['name'] . '%');
        }
        if (isset($request['company_name']) && !empty($request['company_name'])) {
            $lists->where('company_name', 'like', '%' . $request['company_name'] . '%');
        }
        $result = $lists->paginate(10);
        return $result;
    }
    
    //R : get all manager by admin
    public static function getManagerListForCsv($request) {
        $lists = User::where('role', 'manager')->where('status', '!=', 'deleted')->orderBy('id', 'desc');
        if (isset($request['name']) && !empty($request['name'])) {
            $lists->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $request['name'] . '%');
        }
        if (isset($request['company_name']) && !empty($request['company_name'])) {
            $lists->where('company_name', 'like', '%' . $request['company_name'] . '%');
        }
        $result = $lists->get();
        return $result;
    }

    //R : save manager by admin
    public static function saveManager($post) {
        try {
            DB::beginTransaction();
            $model = new User();
            $model->username = $post['username'];
            $model->password = bcrypt($post['password']);
            $model->password_base64 = base64_encode($post['password']);
            $model->first_name = $post['first_name'];
            $model->last_name = $post['last_name'];
            $model->contact_name = $post['first_name'] . ' ' . $post['last_name'];
            $model->email = $post['email'];
            $model->phone_number = $post['phone'];
            $model->role = 'manager';
            $model->profile_image = $post['hiddenFileName'];
            $model->status = 'active';
            $model->company_name = $post['company'];
            $model->waiting_time = $post['waiting_time'];
            $model->customer_limit = $post['customer_limit'];
            $model->created_by = Auth::guard(getAuthGuard())->user()->id;
            if ($model->save()) {
                $data = [];
                $data['name'] = $model->first_name . ' ' . $model->last_name;
                $data['username'] = $model->username;
                $data['email'] = $model->email;
                $data['password'] = $post['password'];
                $data['subject'] = 'User Credentials';
                $data['request'] = 'user_mail';
                $data['user_role'] = $model->role;
                $data['created_by_role'] = Auth::guard(getAuthGuard())->user()->role;
                $mail = sendMail($data);
                DB::commit();
            }
            return Response::json(['success' => true, 'message' => \Config::get('constants.manager_added')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    //R : update manager by admin
    public static function updateManager($post) {
        try {
            DB::beginTransaction();
            $model = User::where('id', $post['managerId'])->first();
            $generateNumber = str_random(8);
            $model->first_name = $post['first_name'];
            $model->last_name = $post['last_name'];
            $model->contact_name = $post['first_name'] . ' ' . $post['last_name'];
            $model->email = $post['email'];
            $model->phone_number = $post['phone'];
            $model->role = 'manager';
            $model->profile_image = $post['hiddenFileName'];
            $model->company_name = $post['company'];
            $model->waiting_time = $post['waiting_time'];
            $model->customer_limit = $post['customer_limit'];
            if ($model->save()) {
                DB::commit();
            } else {
                DB::rollBack();
            }
            return Response::json(['success' => true, 'message' => $msg = \Config::get('constants.manager_update')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    //R : get manager dropdown list by admin
    public static function getManagerLinkedById() {
        return User::where('role', 'manager')->where('status', 'active')->where('status', '!=', 'deleted')->where('created_by', Auth::guard(getAuthGuard())->user()->id)->get();
    }

    /*
     * get all executives where linked by admin or manager
     */

    public static function getExecutivesLinkedById() {
        if (Auth::guard(getAuthGuard())->user()->role == "manager") {
            return CustomerExecutiveRelation::select(['users.*'])->join('users', 'users.id', '=', 'customer_executive_relations.executive_id')->where(['customer_executive_relations.manager_id' => Auth::guard(getAuthGuard())->user()->id])->groupBy('customer_executive_relations.executive_id')->get();
//            return User::where('role', 'executive')->where('status', 'active')->where('created_by', Auth::guard(getAuthGuard())->user()->id)->get();
        } else {
            return User::where('role', 'executive')->where('status', 'active')->get();
        }
    }

    //R : get executive dropdown list by admin
    public static function getAllExecutivesByAdmin() {
        return User::where('role', 'executive')->where('status', '!=', 'deleted')->get();
    }

    /*
     * change password for user
     */

    public static function changePasswordById($id) {
        try {
            $model = User::where('id', $id)->first();
            /* send mail function for user credentials */
            $data = [];
            $data['name'] = $model->first_name . ' ' . $model->last_name;
            $data['username'] = $model->username;
            $data['email'] = $model->email;
            $data['password'] = base64_decode($model->password_base64);
            $data['subject'] = 'Change Password Credentials';
            $data['request'] = 'change_password_mail';
            $data['user_role'] = $model->role;
            $data['created_by_role'] = Auth::guard(getAuthGuard())->user()->role;
            $mail = sendMail($data);
            return Response::json(['success' => true, 'message' => \Config::get('constants.change_password_mail_sent')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    //R : get all customer by admin
    public static function getAllMerchantByAdmin($post) {
        $user = User::join('user_profiles', 'users.id', 'user_id')->where('role', '=', 'customer')->where('status', '!=', 'deleted');
        if (isset($post['name']) && !empty($post['name'])) {
            $searchData = $post['name'];
            $user->where(function($query) use($searchData) {
                $query->where(DB::raw('CONCAT(users.first_name," ",users.last_name)'), 'like', '%' . $searchData . '%');
            });
        }
        if (isset($post['merchant_number']) && !empty($post['merchant_number'])) {
            $user->where('user_profiles.merchant_number', 'like', '%' . $post['merchant_number'] . '%');
        }
        if (isset($post['bussiness_name']) && !empty($post['bussiness_name'])) {
            $user->where('user_profiles.bussiness_name', 'like', '%' . $post['bussiness_name'] . '%');
        }
        if (isset($post['phone_number']) && !empty($post['phone_number'])) {
            $user->where('users.phone_number', 'like', '%' . $post['phone_number'] . '%');
        }
        if (isset($post['bussiness_address']) && !empty($post['bussiness_address'])) {
            $user->where('user_profiles.bussiness_address', 'like', '%' . $post['bussiness_address'] . '%');
        }
        return $user->orderBy('users.id', 'desc')->paginate(10);
    }
    
    //R : get all customer by admin
    public static function getAllMerchantByAdminCSV($post) {
        $user = User::join('user_profiles', 'users.id', 'user_id')->where('role', '=', 'customer')->where('status', '!=', 'deleted');
        if (isset($post['name']) && !empty($post['name'])) {
            $searchData = $post['name'];
            $user->where(function($query) use($searchData) {
                $query->where(DB::raw('CONCAT(users.first_name," ",users.last_name)'), 'like', '%' . $searchData . '%');
            });
        }
        if (isset($post['merchant_number']) && !empty($post['merchant_number'])) {
            $user->where('user_profiles.merchant_number', 'like', '%' . $post['merchant_number'] . '%');
        }
        if (isset($post['bussiness_name']) && !empty($post['bussiness_name'])) {
            $user->where('user_profiles.bussiness_name', 'like', '%' . $post['bussiness_name'] . '%');
        }
        if (isset($post['phone_number']) && !empty($post['phone_number'])) {
            $user->where('users.phone_number', 'like', '%' . $post['phone_number'] . '%');
        }
        if (isset($post['bussiness_address']) && !empty($post['bussiness_address'])) {
            $user->where('user_profiles.bussiness_address', 'like', '%' . $post['bussiness_address'] . '%');
        }
        return $user->orderBy('users.id', 'desc')->get();
    }

    /*
     * get all merchant by managers 
     */

    public static function getAllMerchantByManager($id) {
        return User::join('user_profiles', 'users.id', 'user_profiles.user_id')
                        ->join('customer_executive_relations', 'customer_executive_relations.customer_id', 'users.id')
                        ->where('users.role', '=', 'customer')
                        ->where('users.status', '!=', 'deleted')
                        ->where('customer_executive_relations.manager_id', $id)
                        ->groupBy('customer_executive_relations.customer_id')->get();
    }

    public static function viewMerchantbyManager($id) {
        $viewMerchant = User::join('user_profiles', 'users.id', 'user_profiles.user_id')
                ->where('users.id', $id)
                ->where('users.status', '!=', 'deleted')
                ->first();
        return $viewMerchant;
    }

    /*
     * update user password by users id
     */

    public static function updateUserPassword($post) {
        try {
            $model = User::where('id', $post['user_id'])->first();
            $model->password = bcrypt($post['password']);
            $model->password_base64 = base64_encode($post['password']);
            $model->save();
            self::changePasswordById($post['user_id']);
            return Response::json(['success' => true, 'message' => \Config::get('constants.password_updated')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    //R : get all executive by request by admin
    public static function getAllExecutivesByRequest($post) {
        $user = User::select('users.*', 'executive_manager_relations.manager_id')
                ->Join('executive_manager_relations', 'executive_manager_relations.executive_id', 'users.id')
                ->where('role', '=', 'executive')
                ->where('status', '!=', 'deleted');
        if (isset($post['name']) && !empty($post['name'])) {
            $user->where('contact_name', 'like', '%' . $post['name'] . '%');
        }
        return $user->orderBy('users.id', 'desc')->paginate(10);
    }
    
    //R : get all executive by request by admin
    public static function getAllExecutivesByRequestForCSV($post) {
        $user = User::select('users.*', 'executive_manager_relations.manager_id')
                ->Join('executive_manager_relations', 'executive_manager_relations.executive_id', 'users.id')
                ->where('role', '=', 'executive')
                ->where('status', '!=', 'deleted');
        if (isset($post['name']) && !empty($post['name'])) {
            $user->where('contact_name', 'like', '%' . $post['name'] . '%');
        }
        return $user->orderBy('users.id', 'desc')->get();
    }

    public static function getAllExecutivesRequestByManager($post) {
        $user = User::select('users.*', 'executive_manager_relations.manager_id')
                ->Join('executive_manager_relations', 'executive_manager_relations.executive_id', 'users.id')
                ->where('role', '=', 'executive')
                ->where('status', '!=', 'deleted')
                ->where('executive_manager_relations.manager_id', Auth::guard('manager')->user()->id);
        if (isset($post['name']) && !empty($post['name'])) {
            $user->where('contact_name', 'like', '%' . $post['name'] . '%');
        }
        return $user->orderBy('users.id', 'desc')->paginate(10);
    }

    // api side for customer home screen detail
    public static function GetCustomerHomeDetail() {
        $token = \Request::header('access-token');
        $array = [];
        $user = JWTAuth::toUser($token);
        if (!empty($user)) {
            $bank = Bank::where(['id' => $user->bank_id])->first();
            $userName = CustomerExecutiveRelation::select('users.*')
                            ->join('users', 'customer_executive_relations.executive_id', 'users.id')
                            ->where(['customer_id' => $user->id])->get();
            
            $managerName = CustomerExecutiveRelation::select('users.*')
                            ->join('users', 'customer_executive_relations.manager_id', 'users.id')
                            ->where(['customer_id' => $user->id])->first();
            
            $executiveCount = count($userName);
            foreach ($userName as $val) {
                $executiveName = $val['contact_name'];
                $executiveImage = $val['profile_image'];
            }
//            if ($executiveCount > 1) {
                $array['company_name'] = $managerName['company_name'];
                $array['user_image'] = $managerName['profile_image'];
//            } else {
//                $array['company_name'] = $executiveName;
//                $array['user_image'] = $executiveImage;
//            }
            $count = CustomerExecutiveRelation::where(['customer_id' => $user->id])->count();
            $customerDetails = CustomerExecutiveRelation::where(['customer_id' => $user->id])->first();

            $manager_id = $customerDetails['manager_id'];
            $manager = User::where(['id' => $manager_id])->first();
            $image = checkProfileImage($manager['profile_image']);
            $array['waiting_time'] = (!empty($manager) && $manager->waiting_time != '') ? $manager->waiting_time : 0;
            $array['logo_image'] = $image;
            $bank_categorys = BankingCategory::where(['status' => 'active'])->orderBy('id', 'desc')->get();
            foreach ($bank_categorys as $category) {
                $category->category_logo = Utility::getCategoryLogo($category->category_logo);
            }
            $array['category'] = $bank_categorys;
            return $array;
        }
        return false;
    }

    //api side executive list
    public static function executiveList($get) {
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if (!empty($user)) {
            $lists = User::select('users.id', 'users.first_name', 'users.last_name')
                            ->Join('executive_categories', 'executive_categories.executive_id', 'users.id')
                            ->where('users.role', '=', 'executive')
                            ->where('executive_categories.category_id', $get['category_id'])->get();
            if (count($lists) > 0) {
                return $lists;
            }return false;
        }return false;
    }

    // get user count

    public static function getUserCountByType($userType) {
        return User::join('user_profiles', 'users.id', 'user_id')
                        ->where('role', '=', $userType)->where('status', '!=', 'deleted')->count();
    }

    //R : send user detail by admin and manager
    public static function sendDetail($id) {
        try {
            $model = User::where('id', $id)->first();
            $data = [];
            $data['name'] = $model->first_name . ' ' . $model->last_name;
            $data['username'] = $model->username;
            $data['email'] = $model->email;
            $data['password'] = base64_decode($model->password_base64);
            $data['subject'] = 'User Detail';
            $data['request'] = 'send_detail_mail';
            $data['user_role'] = $model->role;
            $data['created_by_role'] = Auth::guard(getAuthGuard())->user()->role;
            $mail = sendMail($data);
            return Response::json(['success' => true, 'message' => \Config::get('constants.user_detail_mail_sent')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    // P: Get User Detail By UserId and Key
    public static function getUserDataByKey($userId, $key) {
        $userData = User::where('id', $userId)->first();
        if (!empty($userData)) {
            return $userData->$key;
        } else {
            return "";
        }
    }
    // N: Get Manager Waiting time UserId 
    public static function getManagerWaitingTimeById($userId) {
        $userData = User::select('users.*')
                ->join('customer_executive_relations', 'users.id', '=', 'customer_executive_relations.manager_id')
                ->where('users.status', 'active')
                ->where(function ($query)use ($userId){
                    $query->where('customer_executive_relations.executive_id', $userId)
                          ->orWhere('customer_executive_relations.customer_id', $userId);
                })->first();
        if (!empty($userData)) {
            return $userData->waiting_time;
        } else {
            return "";
        }
    }

    // P: Get User Profile Detail By UserId and Key
    public static function getUserProfileDataByKey($userId, $key) {
        $userData = UserProfile::where('user_id', $userId)->first();
        if (!empty($userData)) {
            return $userData->$key;
        } else {
            return "";
        }
    }

    //R : get executive by manager in admin side
    public static function getExecutiveByManager($post) {
        $executives = User::select('users.*')
                ->join('executive_manager_relations', 'users.id', '=', 'executive_manager_relations.executive_id')
                ->where('users.status', 'active')
                ->where('executive_manager_relations.manager_id', $post['manager_id'])
                ->get();
        return $executives;
    }
    
    //N : get customer by manager in admin side
    public static function getCustomerByManager($post) {
        $customeres = User::select('users.*')
                ->join('customer_executive_relations', 'users.id', '=', 'customer_executive_relations.customer_id')
                ->where('users.status', 'active')
                ->where('customer_executive_relations.manager_id', $post['manager_id'])
                ->groupBy('customer_id')->get();
        return $customeres;
    }

    //R : get executive by customer in admin side
    public static function getExecutiveByCustomer($customerId) {
        return CustomerExecutiveRelation::where('customer_id', $customerId)->get();
    }
    
    //N : get customer by executive in admin side
    public static function getCustomerByExcutive($executiveId) {
        return CustomerExecutiveRelation::where('executive_id', $executiveId)->get();
    }

    //R : get customer count by executive in admin side
    public static function getMerhcantCountByExcutive($id) {
        return User::join('customer_executive_relations', 'customer_executive_relations.customer_id', 'users.id')
                        ->where('users.role', '=', 'customer')
                        ->where('users.status', '!=', 'deleted')
                        ->where('customer_executive_relations.executive_id', $id)->count();
    }

    //R : get manager by document
    public static function getManagerByDocument($id) {
        return User::where('role', 'manager')->where('status', '!=', 'deleted')->where('id', $id)->first();
    }

    public static function getWaitingTime($managerId) {
        $manager = User::where(['id' => $managerId])->first();
        if(!empty($manager)){
            return $manager->waiting_time;
        }
        return 0;
    }
    
    // Sent notification when user back to online
    public static function sendOnlineNotification($userId){
        $userDetail = User::where(['id'=>$userId])->first();
        $message = "$userDetail->contact_name is online now you can contact for your pending request";
        $image = User::getUserDataByKey($userId, 'profile_image');
        $callerImage = checkProfileImage($image);
       
        $customerRequest = CallRequest::where(['notify_type'=>'when_online','status'=>'pending','customer_id'=>$userId,'is_notification_send'=>0])->get();
        if(!empty($customerRequest)){
            foreach($customerRequest as $val){
                $userDeviceData = UserDevice::where(['user_id'=>$val->executive_id])->first();
                
                if(!empty($userDeviceData)){
                    
                    if($userDeviceData->device_type == "ios"){
                        $notificationType = "user_online";
                    } else {
                        $notificationType = "panding_request_notifier";
                    }

                    error_reporting(E_ALL);
                     $data = [
                        'notification_type' => $notificationType,
                        'userId' =>$userId,
                        'message'=>$message,
                        'caller_name'=>$userDetail->contact_name,
                        'caller_image'=>$callerImage
                    ];
                    if ($userDeviceData->device_type == "ios") {
                        //Utility::APNSPushDeviceNotification($userDeviceData->device_id, $message, 'executive', $data, $userId, $val->executive_id);
                        Utility::APNSPushDeviceNotification($userDeviceData->device_id, $message, 'executive', $data, $userId, $val->executive_id);
                    } else if ($userDeviceData->device_type == "android") {
                        Utility::FcmPushNotification([$userDeviceData->device_id], $message, 'executive', $data, $userId,$val->executive_id);
                    } else {
                        Utility::saveNotification($userId, $message, 'user_online', $data, $val->executive_id);
                    }      
                }
                $val->is_notification_send = 1;
                $val->save();
            }
        }
    }
}
