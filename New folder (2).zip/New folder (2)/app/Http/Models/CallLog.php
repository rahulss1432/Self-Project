<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use App\Http\Models\User;
use App\Http\Models\ExecutiveCategory;
use JWTAuth;
use App\Common\Utility;
use App\Http\Models\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Pagination\LengthAwarePaginator;

class CallLog extends Model {

}
