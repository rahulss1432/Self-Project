<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Models\CallRequest;

class CustomerRequestController extends Controller {

    public function index() {
        return view('executive.customer-request.customer_request');
        
    }

    // Get List of customer request list
    public function customerRequestList() {
        try {
            $requests = CallRequest::getPendingCallRequestByExecutive(Auth::guard('web')->user()->id, 'listing');
            $html = View::make('executive.customer-request._customer_request_list', ['requests' => $requests])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    // Function to create call request
    public function createCallRequest(Request $request){
        $post = $request->all();
        $userId = Auth::guard('web')->user()->id;
        $callData = CallRequest::where(['executive_id'=>$userId,'call_current_status'=>'busy'])->get();
        if($callData->count() == 0){
        $result = CallRequest::saveCallRequuestFromWeb($post);
        if($result){
            return Response::json(['success' => true, 'request_id' => $result]);
        } else {
            return Response::json(['success' => false,'message'=>'Please try again']);
        }
        } else {
            return Response::json(['success' => false,'message'=>'You already have a running call']);
        }
        
    }
    
    // Function to check current call status
    public function checkCurrentCallStatus(){
        $userId = Auth::guard('web')->user()->id;
        $callData = CallRequest::where(['executive_id'=>$userId,'call_current_status'=>'busy'])->get();
        if($callData->count() == 0){
            return Response::json(['success' => true]);
        } else {
            return Response::json(['success' => false,'message'=>'You already have a running call']);
        }
    }
    
    public function updateUserCallStatus(Request $request){
//        $post = $request->all();
//        $userId = Auth::guard('web')->user()->id;
//        $ticketData = getTicketDataByNumber($post['ticketId']);
//        $callRequest = CallRequest::where(['ticket_id'=>$ticketData->id,'executive_id'=>$userId])->first();
//        $callRequest->call_current_status = "busy";
//        $callRequest->is_call_dropped = 0;
//        $callRequest->save();
    }
    
    // Function to send busy notification to customer
    public function sendBusyNotification(Request $request){
        $post = $request->all();
        CallRequest::sendBusyNotification($post);
    }

}
