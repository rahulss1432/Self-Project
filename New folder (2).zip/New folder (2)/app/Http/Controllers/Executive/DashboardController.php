<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Models\User;
use View;

class DashboardController extends Controller {

    /**
     * view user profile
     * @return view
     * */
    public function viewUserProfile() {
        try {
            $user = \App\Http\Models\User::getUserById(Auth::guard()->user()->id);
            $userSuperVisor = \App\Http\Models\ExecuitveSupervisor::where(['executive_id'=>Auth::guard()->user()->id])->first();
            $html = View::make('executive._user_profile', ['user' => $user,'userSuperVisor'=>$userSuperVisor])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for get all executives by category.
     *
     * @return \Illuminate\Http\Response
     */
    public function getExecutiveByCategory(Request $request) {
        $executives = \App\Http\Models\BankingCategory::getAllActiveExecutiveByCategory($request->all());
        foreach ($executives as $executive) {
            if ($executive->id == $request['executive_id']) {
                $selected = 'selected="selected"';
            } else {
                $selected = '';
            }
            echo "<option value='$executive->id' $selected>$executive->contact_name</option>";
        }
    }
    
    public function checkLoginCode(Request $request){
        $userId = Auth::guard()->user()->id;
        $post = $request->all();
        $code = $post['hdnLoginCode'];
        $userDevice = \App\Http\Models\UserDevice::where(['user_id'=>$userId])->first();
        if(!empty($userDevice) && $userDevice->login_code!=""){
            if($userDevice->login_code == $code){
                return Response::json(['success' => true]);
            } else {
                return Response::json(['success' => false]);
            }
        } else {
            return Response::json(['success' => false]);
        }
    }

}
