<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NotificationController extends Controller {

    /**
     * executive dashboard
     * @return view
     * */
    public function index() {
        $userId = Auth::guard()->user()->id;
        $date =  date('Y-m-d', strtotime('today - 30 days'));
        $notificationList = \App\Http\Models\Notification::where(['to_id'=>$userId])->where('created_at' ,'>=',$date)->orderBy('id','desc')->get();
        if(!empty($notificationList)){
            foreach($notificationList as $val){
                $val->read_status = 1;
                $val->save();
            }
        }
        return view('executive.notifications.index');
    }

    public function notificationList() {
        $userId = Auth::guard()->user()->id;
        $date =  date('Y-m-d', strtotime('today - 30 days'));
        $notificationList = \App\Http\Models\Notification::where(['to_id'=>$userId])->where('created_at' ,'>=',$date)->orderBy('id','desc')->paginate(10);
        if(!empty($notificationList)){
            foreach($notificationList as $val){
                $val->read_status = 1;
                $val->save();
            }
        }
        $html = View::make('executive.notifications._notifications',['notificationList'=>$notificationList])->render();
        return Response::json(['success' => true, 'html' => $html]);
        
    }

}
