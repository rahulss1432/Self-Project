<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use App\Http\Models\CallRequest;
use App\Http\Models\Document;
use Illuminate\Support\Facades\Auth;
use File;
use App\Http\Models\CallImage;

class LinkedNotesController extends Controller {

    /**
     * executive dashboard
     * @return view
     * */
    public function index(Request $request) {
        $post = $request->all();
        //$id = $post['id'];
        $ticketId = $post['ticketId'];
//        

//        if($ticketId == ""){
//            $ticketData = \App\Http\Models\Ticket::where(['id'=>$request->ticket_id])->first();
//            $ticketId = $ticketData->ticket_number;
//        } else {
//            $ticketId = $ticketId;
//        }
        $ticketData = \App\Http\Models\Ticket::where(['ticket_number'=>$ticketId])->first();
        $customerRequest = CallRequest::getCustomerRequestByTicketId($ticketData->id);
        //$request = CallRequest::getCallRequestsById($id);
        //return view('executive.linked-notes.index', ['request' => $request]);
        $html = View::make('executive.linked-notes.index', ['request'=>$customerRequest,'ticketData'=>$ticketData])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * executive's bank document listing
     * @return \Illuminate\Http\Response
     * */
    public function executiveDocumentsList(Request $request) {
        try {
            $documents = Document::getDocListForWeb($request->all());
            $html = View::make('executive.linked-notes._document_list', ['documents' => $documents])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * executive's linked merhcant notes history listing
     * @return \Illuminate\Http\Response
     * */
    public function linkedMerchantNotesHistoryList($merchantId) {
        try {
            $executiveId = Auth::guard('web')->user()->id;
            $notesHistory = CallRequest::getMerchantLinkedNotesHistoryByExecutive($executiveId, $merchantId);
            $html = View::make('executive.linked-notes._linked_notes_history', ['notesHistory' => $notesHistory])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    public function getNotesDataByDate(Request $request){
        $post = $request->all();
        $date = $post['callDate'];
        $customerId = $post['customerId'];
        $date = date('Y-m-d',strtotime($date));
        $callData = CallRequest::where(['customer_id' => $customerId])->where('notes','!=','')->orderBy('id','desc')->where(\Illuminate\Support\Facades\DB::raw('date(created_at)'),'=',$date)->paginate(10);
        $html = View::make('executive.linked-notes._linked_notes_history_detail', ['callData' => $callData])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * executive's linked merhcant notes history modal
     * @return \Illuminate\Http\Response
     * */
    public function loadAddNoteModal($requestId,$time) {
        try {
            $seRequest = CallRequest::getCallRequestsById($requestId);
            $html = View::make('executive.linked-notes._add_note_modal', ['seRequest' => $seRequest,'time'=>$time])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
       
    
    public function uploadImage(Request $request){
        $file = $_FILES; 
        $type = explode("/", $file["add_image"]["type"]);
        
        if($type[0]=='image'){
            if ($file["add_image"]["size"] < (1000 * 1000 * 5)) {
                $size = getimagesize($file["add_image"]['tmp_name']);
                $filename = time() . "-" . $file['add_image']['name'];
                $imagePath = base_path() . '/public/uploads/linked-call-images/';
                if (!is_dir($imagePath)) {
                    File::makeDirectory($imagePath, $mode = 0777, true, true);
                }
                move_uploaded_file($file['add_image']['tmp_name'], $imagePath . $filename);
                
                $ticket = $request->ticket_id;
                $lastCall = CallRequest::where(['ticket_id' => $ticket])->orderBy('id', 'DESC')->first();
                $callId = 0;
                if(!empty($lastCall)){
                    $callId = $lastCall->id;
                }
                
                $callImage = new CallImage();
                $callImage->call_id = $callId;
                $callImage->ticket_id = $ticket;
                $callImage->image_name = $filename;
                $callImage->save();
                
                $image = url('/public/uploads/linked-call-images/'.$filename);
                return Response::json(['success' => 1, 'filename' => $image]);
                
            } else {
                return Response::json(['success' => 0, 'error' => 'Image has to be smaller than 5MB']);
            }
        }
    }

    public function updateExecutiveDroppedRequest(){
        $executiveId = Auth::guard('web')->user()->id;
        CallRequest::updateDroppedCallRequest($executiveId);
    }

}
