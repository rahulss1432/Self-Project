<?php
namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\ContactAdminRequest;
use Illuminate\Support\Facades\Response;
use App\Http\Models\AdminContact;

class ContactController extends Controller {

    public function contactAdmin(ContactAdminRequest $request) {
        try {
            $contact = AdminContact::addAdminContact($request);
            if($contact){
                $json = ['success' => true, 'message' => 'Form submitted successfully.',];
            } else {
                $json = ['success' => false, 'error' => ['message' => 'Something went wrong.']];
            }
            return $json;
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

}
