<?php

namespace App\Http\Controllers\Api;

/**
 * Description: this controller is used  for mentee related operation 
 * Author : Codiant- A Yash Technologies Company 
 * Date :25 feb 2019
 * 
 */
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\SaveAppointmentRequest;
use App\Http\Requests\Api\SaveFavoriteRequest;
use App\Repositories\Api\AppointmentRepository;
use App\Repositories\Api\FavoriteRepository;
use JWTAuth;
use App\Repositories\Api\UserRepository;

class MenteeController extends Controller {

    public function __construct(AppointmentRepository $appointment, FavoriteRepository $favorite, UserRepository $user) {
        $this->appointment = $appointment;
        $this->favorite = $favorite;
        $this->user = $user;
    }

    /**
     * Save Appointment
     * @param SaveAppointmentRequest $request(obj)
     * @return type json
     */
    public function saveAppointment(SaveAppointmentRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->appointment->saveAppointment($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => \StaticMessage::$app['saved_appoinment']]);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Save Favorite
     * @param SaveFavoriteRequest $request(obj)
     * @return type json
     */
    public function saveFavorite(SaveFavoriteRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->favorite->saveFavorite($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Favorite list updated successfully.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * categoryList
     * @param Request $request(obj)
     * @return type json
     */
    public function categoryList(Request $request) {

        try {

            $data = $this->user->categoryList($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * services list
     * @param Request $request(obj)
     * @return type json
     */
    public function serviceList(Request $request) {
        try {

            $data = $this->user->services($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * user favourite list
     * @param Request $request(obj)
     * @return type json
     */
    public function myFavourite(Request $request) {
        try {

            $data = $this->user->myFavourite($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * update lat long of mentee
     * @param Request $request(obj)
     * @return type json
     */
    public function updateLatLong(Request $request) {
        try {

            $data = $this->user->updateLatLong($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Updated successfully.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     *  user home api
     * @param Request $request(obj)
     * @return type json
     */
    public function userHome(Request $request) {
        try {

            $data = $this->user->userHome($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * ffer detail
     * @param Request $request(obj)
     * @return type json
     */
    public function offerDetail(Request $request) {
        try {

            $data = $this->user->offerDetail($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * update offer status
     * @param Request $request(obj)
     * @return type json
     */
    public function offerAcceptDecline(Request $request) {
        try {
            $data = $this->user->offerAcceptDecline($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Offer status updated successfully.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * check mentor checkAvailability
     * @param Request $request(obj)
     * @return type json
     */
    public function checkAvailability(Request $request) {

        try {
            $data = $this->user->checkAvailability($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Availability not found.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

}
