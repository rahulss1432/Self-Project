<?php

namespace App\Http\Controllers\Api;

/**
 * Description: this controller is used  for common operation for both user and mentor 
 * Author : Codiant- A Yash Technologies Company 
 * Date :10 march 2019
 * 
 */
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\SaveComplaintsRequest;
use App\Http\Requests\Api\SaveAppointmentRequest;
use App\Http\Requests\Api\SavePostRequest;
use App\Repositories\Api\CommonRepository;
use App\Repositories\Api\ComplaintRepository;
use App\Repositories\Api\AppointmentRepository;
use App\Repositories\Api\OfferRepository;
use App\Repositories\Api\UserRepository;
use App\Repositories\Api\PostRepository;
use App\Http\Requests\Api\RatingRequest;
use JWTAuth;

class CommonController extends Controller {

    public function __construct(CommonRepository $common, ComplaintRepository $complaint, AppointmentRepository $appointment, OfferRepository $offer, UserRepository $user, PostRepository $post) {
        $this->common = $common;
        $this->complaint = $complaint;
        $this->appointment = $appointment;
        $this->offer = $offer;
        $this->user = $user;
        $this->post = $post;
    }

    /**
     * Get user detail by token.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getCountry(Request $request) {
        return $this->common->getCountry($request);
    }

    /**
     * Get user detail by token.
     * @return type Json
     */
    public function getState(Request $request) {
        return $this->common->getState($request);
    }

    /**
     * Get city list.
     * @return type Json
     */
    public function getCity(Request $request) {
        return $this->common->getCityList($request);
    }

    /**
     * Save Complaints
     * @param SaveComplaintsRequest $request(obj)
     * @return type json
     */
    public function saveComplaints(SaveComplaintsRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->complaint->saveComplaints($request, $user);
            return response()->json(['success' => true, 'data' => $data, 'message' => \StaticMessage::$app['complaint_save']]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Get Appointment
     * @param Request $request(obj)
     * @return type json
     */
    public function getAppointment(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->appointment->getAppointment($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Update Appointment
     * @param SaveAppointmentRequest $request(obj)
     * @return type json
     */
    public function updateAppointment(SaveAppointmentRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->appointment->updateAppointment($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => \StaticMessage::$app['update_appoinment']]);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Delete Appointment
     * @param Request $request
     * @return type json
     */
    public function cancelCompleteAppointment(Request $request) {
        try {
            $data = $this->appointment->cancelCompleteAppointment($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['cancel_appoinment']]);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Invalid Appointment ID.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * get Appointment detail
     * @param Request $request(obj)
     * @return type json
     */
    public function getAppointmentDetail(Request $request) {
        try {
            $data = $this->appointment->getAppointmentDetail($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Invalid Appointment ID.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     *  Get Offer
     * @param Request $request(obj)
     * @return type json
     */
    public function getOffer(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->offer->getOffer($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * function to give rating
     * @param RatingRequest $request(obj)
     * @return type
     */
    public function giveRating(RatingRequest $request) {
        try {
            $data = $this->user->giveRating($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['give_rating']]);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Save Post
     * @param SavePostRequest $request(obj)
     * @return type json
     */
    
    public function savePost(SavePostRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->post->savePost($request, $user);
            return response()->json(['success' => true, 'data' => $data, 'message' => \StaticMessage::$app['give_post']]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Get Post
     * @param Request $request(obj)
     * @return type json
     */
    
    public function getPost(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->post->getPost($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Get rating and review
     * @param Request $request(obj)
     * @return type json
     */
    public function getRatingReview(Request $request) {

        try {
            $data = $this->common->getRatingReview($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Contact Us
     * @param Request $request(obj)
     * @return type json
     */
    public function contactUs(Request $request) {
        try {
            $data['request'] = 'contact_us';
            $data['name'] = $request->name;
            $data['subject'] = $request->type;
            $data['comments'] = $request->comments;
            $mail = sendMail($data);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], \StaticMessage::$app['contact_us']]);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

/**
 * verify with
 * @param Request $request(obj)
 * @return type json
 */
    public function verifyWith(Request $request) {
        try {
            $data = $this->common->verifyWith($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => \StaticMessage::$app['social_verification']]);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

/**
 * faqList list
 * @param Request $request(obj)
 * @return type json
 */
    public function faqList(Request $request) {
        try {
            $data = $this->common->faqList($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

}
