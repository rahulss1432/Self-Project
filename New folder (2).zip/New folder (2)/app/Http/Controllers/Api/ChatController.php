<?php

namespace App\Http\Controllers\Api;

/**
 * Description: this controller is used  for chat related operation for both user and mentor 
 * Author : Codiant- A Yash Technologies Company 
 * Date :25 feb 2019
 * 
 */
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Api\ChatRepository;
use App\Http\Requests\Api\MessageRequest;

class ChatController extends Controller {

    public function __construct(ChatRepository $chat) {
        $this->message = $chat;
    }

    /**
     * save message.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function postMessage(MessageRequest $request) {
        try {
            $data = $this->message->saveMessage($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['message_save']]);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * get inbox.
     * @param Request $request(obj)
     * @return type json
     */
    public function getInbox(Request $request) {
        try {
            $data = $this->message->getInbox($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * get chat list.
     * @param Request $request(obj)
     * @return type json
     */
    public function getChatList(Request $request) {
        try {
            $data = $this->message->getChatList($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * delete chat.
     * @param Request $request(obj)
     * @return type json
     */
    public function deleteChat(Request $request) {
        try {
            $data = $this->message->deleteChat($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['chat_delete']]);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'There is no conversation.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

}
