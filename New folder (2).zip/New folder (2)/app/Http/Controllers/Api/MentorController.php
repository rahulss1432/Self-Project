<?php

namespace App\Http\Controllers\Api;

/**
 * Description: this controller is used  for mentor related operation 
 * Author : Codiant- A Yash Technologies Company 
 * Date :27 feb 2019
 * 
 */
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\AddAvailabilty;
use App\Http\Requests\Api\SaveOfferRequest;
use App\Http\Requests\Api\SavePortfolioRequest;
use App\Repositories\Api\MentorRepository;
use App\Repositories\Api\OfferRepository;
use App\Repositories\Api\PortfolioRepository;
use App\Repositories\Api\UserRepository;
use JWTAuth;

class MentorController extends Controller {

    public function __construct(MentorRepository $mentor, OfferRepository $offer, PortfolioRepository $portfolio, UserRepository $user) {
        $this->mentor = $mentor;
        $this->offer = $offer;
        $this->portfolio = $portfolio;
        $this->user = $user;
    }

    /**
     * add mentor availability.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function addAvailability(AddAvailabilty $request) {
        return $this->mentor->addAvailability($request);
    }

    /**
     * edit mentor availability.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function editAvailability(Request $request) {
        return $this->mentor->editAvailability($request);
    }

    /**
     * get availability.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getAvailability(Request $request) {
        return $this->mentor->getAvailability($request);
    }

    /**
     * delete availability.
     * @return type Json
     */
    public function deleteAvailability(Request $request) {
        return $this->mentor->deleteAvailability($request);
    }

    /**
     * add service by mentor
     * @param Request $request(obj)
     * @return type json
     */
    public function addService(Request $request) {
        return $this->mentor->addService($request);
    }

    /**
     * get service list by mentor
     * @param Request $request(obj)
     * @return type json
     */
    public function getService(Request $request) {
        return $this->mentor->getService($request);
    }

    /**
     * delete service
     * @param Request $request
     * @return type
     */
    public function deleteService(Request $request) {
        return $this->mentor->deleteService($request);
    }

    /**
     * Save Offer by mentor
     * @param SaveOfferRequest $request(obj)
     * @return type json
     */
    public function saveOffer(SaveOfferRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->offer->saveOffer($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => \StaticMessage::$app['offer_saved']]);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Save Portfolio by mentor
     * @param SavePortfolioRequest $request(obj)
     * @return type json
     */
    public function savePortfolio(SavePortfolioRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->portfolio->savePortfolio($request, $user);
            if ($data) {
                $res = [];
                $res['user_status'] = $user->status;
                $res['profile_complete'] = checkMentorProfileStatus($user->id);
                return response()->json(['success' => true, 'data' => $res, 'message' => \StaticMessage::$app['portfolio_saved']]);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Get Portfolio by mentor
     * @param Request $request(obj)
     * @return type json
     */
    public function getPortfolio(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->portfolio->getPortfolio($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Get my earning by mentor
     * @param Request $request(obj)
     * @return type json
     */
    public function getEarning(Request $request) {
        try {
            $data = $this->user->getEarning($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Get explor user list by mentor
     * @param Request $request(obj)
     * @return type json
     */
    public function explorUsers(Request $request) {
        try {
            $data = $this->user->explorUsers($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Get mentor list by mentee
     * @param Request $request(obj)
     * @return type json
     */
    public function getMentorList(Request $request) {
        try {
            $data = $this->user->getMentorList($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * update lat long of mentee
     * @param Request $request(obj)
     * @return type json
     */
    public function mentorHome(Request $request) {

        try {
            $data = $this->mentor->mentorHome($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

}
