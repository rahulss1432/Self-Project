<?php

namespace App\Http\Controllers\Api;

/**
 * Description: this controller is used  for chat related operation for both user and mentor 
 * Author : Codiant- A Yash Technologies Company 
 * Date :15 march 2019
 * 
 */
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\AddStripeUserRequest;
use App\Http\Requests\Api\AddCardRequest;
use App\Http\Requests\Api\PaymentRequest;
use App\Repositories\Api\TransactionRepository;
use JWTAuth;

class TransactionController extends Controller {

    public function __construct(TransactionRepository $transaction) {
        $this->transaction = $transaction;
    }

    /**
     * Add Card
     * @param AddCardRequest $request(obj)
     * @return type json
     */
    public function addCard(AddCardRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->transaction->addCard($user, $request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => 'Saved successfully.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Something went wrong! Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Get Card
     * @param Request $request(obj)
     * @return type json
     */
    public function getCard(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->transaction->getCard($user, $request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Delete Card
     * @param Request $request(obj)
     * @return type json
     */
    public function deleteCard(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->transaction->deleteCard($user, $request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Card deleted.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Payment by user
     * @param PaymentRequest $request(obj)
     * @return type json
     */
    public function payment(PaymentRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            return $this->transaction->payment($user, $request);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Create Connect Account
     * @param Request $request(obj)
     * @return type json
     */
    public function createConnectAccount(Request $request) {
        try {
            $data = $this->transaction->createConnectAccount($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Connect account created.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Delete Connect Account
     * @param Request $request(obj)
     * @return type json
     */
    public function deleteConnectAccount(Request $request) {
        try {
            $data = $this->transaction->deleteConnectAccount($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Connect account deleted.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Refund Payment
     * @param Request $request(obj)
     * @return type json
     */
    public function refundPayment(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->transaction->refundPayment($user, $request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Amount refund.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Get All Transactions
     * @param Request $request(obj)
     * @return type json
     */
    public function getAllTransactions(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->transaction->getAllTransactions($user, $request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Capture Payment
     * @param Request $request(obj)
     * @return type json
     */
    public function capturePayment(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->transaction->capturePayment($user, $request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Payment completed.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

}
