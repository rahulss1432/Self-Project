<?php
/**
 * Description: this controller is used  for user related operation for both user and mentor 
 * Author : Codiant- A Yash Technologies Company 
 * Date :28 feb 2019
 * 
 */
namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Api\UserRepository;
use App\Http\Requests\Api\UserValidation;
use App\Http\Requests\Api\OtpValidation;
use App\Http\Requests\Api\AddBankAccountValidation;
use App\Http\Requests\Api\Verificationrequest;
use App\Http\Requests\Api\PasswordResetRequest;
use App\Http\Requests\Api\UpdateProfileRequest;
use App\Http\Requests\Api\CodeVerifyRequest;
use App\Http\Requests\Api\ForgotPasswordRequest;
use App\Http\Requests\Api\SocialUserRequest;

class UserController extends Controller
{
    
    public function __construct(UserRepository $user) {
        $this->user = $user;
    }

    /**
     * Send otp for user registration.
     * @param type $request(OBJ)
     * @return type Json
     */
    
    public function sendOTP(Verificationrequest $request){
        //return $request->all();
        return  $this->user->sendOTP($request);
    }

    /**
     * OTP and mobile verification .
     * @param type $request(OBJ)
     * @return type Json
     */
    public function OTPVerify(CodeVerifyRequest $request)
    {
        return $this->user->OTPVerify($request);
    }

    /**
     * Get user detail by token.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getUser(Request $request)
    {
        return $this->user->getUser($request);
    }

    /**
     * update user profile
     * @param type $request(OBJ)
     * @return type Json
     */
    public function updateProfile(UpdateProfileRequest $request)
    {   return $this->user->updateProfile($request);
    }
    
    /**
     * user add
     * @param type $request(OBJ)
     * @return type Json
     */
    public function signup(UserValidation $request)
    {
        return $this->user->saveUser($request);
    }

    /**
     * send forgot password mail.
     * @param ForgotPasswordRequest $request(obj)
     * @return type json
     */
    public function forgotPassword(ForgotPasswordRequest $request){
        
          return $this->user->forgotPassword($request);         
    }
    
    /**
     * reset password.
     * @param PasswordResetRequest $request(obj)
     * @return type json
     */
    public function resetPassword(PasswordResetRequest $request){
        
          return $this->user->resetPassword($request);         
    }
  
    /**
     * check user is verified by verification code or not. 
     * @param Verificationrequest $request(obj)
     * @return type json
     */
    public function checkVerification(Verificationrequest $request){
        
          return $this->user->checkVerification($request);         
    }
    
    /**
     * social signup.
     * @param SocialUserRequest $request(obj)
     * @return type json
     */
    public function saveSocialUser(SocialUserRequest $request){
        
          return $this->user->saveSocialUser($request);         
    }
    
}
