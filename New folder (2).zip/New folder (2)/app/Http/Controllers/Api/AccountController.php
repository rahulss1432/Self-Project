<?php

namespace App\Http\Controllers\Api;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\LoginFormRequest;
use JWTAuth;
use JWTAuthException;
use App\Http\Models\UserDevice;
use App\Http\Middleware\AddHeader;
use Illuminate\Support\Facades\Response;
use App\Http\Models\ExecutiveCategory;
use App\Http\Models\BankingCategory;
use App\Http\Models\UserProfile;

class AccountController extends Controller {

    public function login(LoginFormRequest $request) {
      
        $creendialData = [];
        $creendialData['username'] = $request->username;
        $creendialData['password'] = $request->password;
        $creendialData['role'] = $request->user_type;
        $creendialData['status'] = 'active';
        
//        $credentials = $request->only('username', 'password');
        $token = null;
        try {
            if (!$token = JWTAuth::attempt($creendialData)) {
                return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Invalid Username or Password entered, please try again']]);
            }
        } catch (JWTAuthException $e) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Failed to create token']]);
        }
        $user = JWTAuth::toUser($token);
        if ($user['role'] != 'customer' && $user['role'] != 'executive') {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Your account type is invalid']]);
        }
        $user = JWTAuth::toUser($token);
        if ($user['status'] == 'inactive') {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Your account  is not active']]);
        }
        $post = $request->all();
        // do online after login
        $user->online_status = 'online';
        $user->save();
        $post['access_token'] = $token;
        if (!empty($user)) {
            $result = UserDevice::addUserDevice($post);
        }
        $user['access_token'] = $token;
        if (!empty($user)) {
            if($post['user_type']=='executive'){
              $executives =  ExecutiveCategory::where(['executive_id'=>$user->id])->get();
              $array = [];
              $all = [];
              if(!empty($executives) && count($executives)){
                  foreach ($executives as $exe){
                      $category = BankingCategory::where(['id'=>$exe['category_id']])->first();
                      $array['id'] = $category['id'];
                      $array['category_name'] = $category['name'];
                      $all[] = $array;
                  }
              }
              $user->executive_categorys = $all;
            }else{
                \App\Http\Models\User::sendOnlineNotification($user->id);
                $profile = UserProfile::getProfileDetail($user->id);
                $user->bussiness_name = (!empty($profile))?$profile->bussiness_name:'';
            }
            $user->profile_image = checkProfileImage($user->profile_image);
            if($user->role == 'executive'){
                $managerId = getManagerByExecutiveId($user->id);
            } else {
                $managerId = getManagerByCustomerId($user->id);
            }
            $managerData = \App\Http\Models\User::where(['id'=>$managerId])->first();
            if(!empty($managerData)){
                 $user->waiting_time = $managerData->waiting_time;
            }else{
                 $user->waiting_time = '';
            }
           
            return response()->json(['success' => true, 'data' => $user]);
        }
    }
    
    public function logout(Request $request) {
        try {
            $defaultTimeZone = \Config::get('constants.default_time_zone');
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $userDevice = UserDevice::where('user_id',$user->id)->first();
            if(!empty($userDevice)){
            if($userDevice->timezone == "India Standard Time"){
                    $userDevice->timezone = "$defaultTimeZone";
                }
                 date_default_timezone_set("$userDevice->timezone");
            } else {
                date_default_timezone_set("$defaultTimeZone");
            }
            $DeviceId = UserDevice::where('user_id',$user->id)->delete();
            // do offline after logout
            $user->online_status = 'offline';
            $user->last_login_time = date('Y-m-d H:i:s');
            $user->save();
            try {
                JWTAuth::invalidate($token);
            } catch (\Exception $e) {
                $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
                return $json;
            }
            $json = ['success' => true, 'message' => 'You are Logged out.',];
            return $json;
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    public function doOnlineOffline(Request $request){
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if($user){
            $user->online_status = $request['status'];
            if($user->save()){
               return response()->json(['success' => true, 'data' => [], 'message' => 'status has been updated']);  
            }
        }
        return response()->json(['success' => false, 'data' => [], 'message' => 'status not updated']);  
    }
}
