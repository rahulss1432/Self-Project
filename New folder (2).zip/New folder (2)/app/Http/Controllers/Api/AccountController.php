<?php

namespace App\Http\Controllers\Api;

/**
 * Description: this controller is used  for account related operation for both user and mentor 
 * Author : Codiant- A Yash Technologies Company 
 * Date :25 feb 2019
 * 
 */
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\LoginRequest;
use JWTAuth;
use JWTAuthException;
use App\UserDevice;
use App\Http\Requests\Api\LogoutRequest;
use Illuminate\Support\Facades\Response;
use App\Http\Requests\Api\ChangePasswordRequest;

class AccountController extends Controller {

    /**
     * function to login for both user and mentor
     * @param LoginRequest $request(obj)
     * @return type json
     */
    public function login(LoginRequest $request) {
        $creendialData = [];
        $creendialData['email'] = $request->email;
        $creendialData['password'] = $request->password;
        $token = null;
        try {
            if (!$token = JWTAuth::attempt($creendialData)) {
                return response()->json(['success' => false, 'data' => [], 'error' => ['message' => \StaticMessage::$app['invalid_credential']]]);
            }
        } catch (JWTAuthException $e) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Failed to create token']]);
        }
        $user = JWTAuth::toUser($token);

        if ($request->role != $user->role) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => \StaticMessage::$app['not_allow_other']]]);
        }

        if (!empty($user['verification_code'])) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => \StaticMessage::$app['not_verified']]]);
        }

        if ($user['status'] == 'inactive') {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => \StaticMessage::$app['not_active']]]);
        }

        $post = $request->all();
        $post['access_token'] = $token;
        if (!empty($user)) {
            $result = UserDevice::addUserDevice($post);
        }
        $user['access_token'] = $token;
        if (!empty($user)) {
            $user->profile_image = checkUserImage($user->profile_image);
            return response()->json(['success' => true, 'data' => $user]);
        }
    }
/**
 * logout function
 * @param Request $request(obj)
 * @return string|array
 */
    public function logout(Request $request) {

        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $DeviceId = UserDevice::where('user_id', $user->id)->delete();
            $user->save();
            try {
                JWTAuth::invalidate($token);
            } catch (\Exception $e) {
                $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
                return $json;
            }
            $json = ['success' => true, 'message' => 'You are Logged out.',];
            return $json;
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

  
    /**
     * change password
     * @param ChangePasswordRequest $request
     * @return array
     */
    public function changePassword(ChangePasswordRequest $request) {

        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $user->password = bcrypt($request->new_password);
            $user->save();
            $json = ['success' => true, 'data' => [], 'message' => \StaticMessage::$app['change_pass']];
            return $json;
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

}
