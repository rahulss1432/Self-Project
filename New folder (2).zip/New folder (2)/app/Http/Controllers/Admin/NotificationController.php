<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Models\Notification;
use Illuminate\Support\Facades\Auth;

class NotificationController extends Controller {

    public function notifications(Request $request) {
        return view('admin.notifications.index');
    }

    // Load Notification List
    public function listNotificationList(Request $request) {
        try {
            $notifications = Notification::getNotificationByAdmin(Auth::guard('admin')->user()->id);
            $html = View::make('admin.notifications._notifications-list', ['notifications' => $notifications])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    // This is for testing please ignore
    public function loadNotificationList(Request $request) {
        try {
            $notifications = Notification::loadNotificationByAdmin(Auth::guard('admin')->user()->id);
            $html = View::make('admin.notifications._load_notification_list', ['notifications' => $notifications])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    
    public function updateNotificationList(Request $request) {
        $userId = Auth::guard('admin')->user()->id;
        return updateNotificationList($userId);
    }

    public function loadNotificationCount() {
        $userId = Auth::guard('admin')->user()->id;
        $notificationCount = loadNotificationCount($userId);
        return Response::json(['success' => true, 'data' => $notificationCount]);
    }
    
    // This is for testing Please ignore
    public function testNotification() {
        
       $notificationCount = \App\Http\Models\CallRequest::cronNotification();
       return Response::json(['success' => true, 'message' => $notificationCount]);
     
    }

}
