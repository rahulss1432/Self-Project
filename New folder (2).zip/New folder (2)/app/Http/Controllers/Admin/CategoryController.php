<?php

namespace App\Http\Controllers\Admin;

use App\Http\Models\BankingCategory;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Requests\Admin\AddCategoryRequest;

class CategoryController extends Controller {

    public function categoryList(Request $request) {
        return view('admin.category.index');
    }

    // List All Category
    public function listAllCategories(Request $request) {
        try {
            $category = BankingCategory::getCategoryList($request);
            $html = View::make('admin.category._list_category', ['category' => $category])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    // Load Form For Edit Category
    public function categoryEdit($id) {
        $editCategory = BankingCategory::where('id', $id)->first();
        if (!empty($editCategory)) {
            return view('admin.category.category-edit', ['editCategory' => $editCategory]);
        }
        abort(404);
    }

    // Update Category
    public function categoryUpdate(AddCategoryRequest $request) {
        return BankingCategory::updateCategory($request);
    }

}
