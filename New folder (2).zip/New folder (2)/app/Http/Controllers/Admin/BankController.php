<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Models\Bank;

class BankController extends Controller {

    // Bank List Index page
    public function bankList(Request $request) {
        return view('admin.bank.index');
    }

    // Load all bak list
    public function listAllBanks(Request $request) {
        try {
            $banks = Bank::getAllBankList($request);
            $html = View::make('admin.bank._list_bank', ['banks' => $banks])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    // Delete Bank By Id
    public function bankDelete($id) {
        return Bank::bankDelete($id);
    }

    // Load Edit Bank Form By Id
    public function bankEdit($id) {
        $editBank = Bank::where('id', $id)->first();
        if (!empty($editBank)) {
            return view('admin.bank.bank-edit', ['editBank' => $editBank]);
        }
        abort(404);
    }

    // Update Bank By Id
    public function bankUpdate(Request $request) {
        return Bank::updateBank($request);
    }

    //To Change the status of bank
    public static function activeInactiveBank($id) {
        $model = Bank::activeInactiveBank($id);
        if ($model) {
            return Response::json(['success' => true, 'message' => \Config::get('constants.category_status')]);
        } else {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
