<?php

namespace App\Http\Controllers\Admin;

use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\ChangePasswordRequest;
use App\Http\Requests\Admin\EditProfileRequest;
use Illuminate\Support\Facades\Response;

class ChangePasswordController extends Controller {

    // Change Password
    public function changePassword() {
        return view('admin.change-password.change-password');
    }

    // Update Password
    public function updatePassword(ChangePasswordRequest $request) {
        return User::updatePassword($request->all());
    }

    // View User Profile
    public function viewProfile() {
        $adminData = User::where('id', Auth()->guard('admin')->user()->id)->first();
        $excutiveCount = \App\Http\Models\User::getUserCountByType('executive');
        $merchantCount = \App\Http\Models\User::getUserCountByType('customer');
        return view('admin.change-password.view-profile', ['adminData' => $adminData, 'excutiveCount' => $excutiveCount, 'merchantCount' => $merchantCount]);
    }

    // Load Form For Edit Profile
    public function editProfile() {
        return view('admin.change-password.edit-profile');
    }

    // Update User Profile
    public function updateProfile(EditProfileRequest $request) {
        return User::updateProfile($request->all());
    }

}
