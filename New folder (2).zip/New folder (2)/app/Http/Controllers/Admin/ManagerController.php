<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Models\User;
use App\Http\Models\UserProfile;
use App\Http\Requests\Admin\AddManagerRequest;
use App\Http\Requests\Admin\EditManagerRequest;
use Excel;
use App\Http\Models\CustomerExecutiveRelation;
use Illuminate\Support\Facades\Auth;
use App\Http\Models\MailQueue;
use App\Http\Models\ExecutiveManagerRelation;

class ManagerController extends Controller {

    public function managerList(Request $request) {
        return view('admin.manager.index');
    }

    // To List All Manager 
    public function listAllManagers(Request $request) {
        try {
            $managers = User::getManagerList($request);
            $html = View::make('admin.manager._list_manager', ['managers' => $managers])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    // Load Form to add manager
    public function addManagerForm() {
        return view('admin.manager.manager-add');
    }

    // Save Manager Detail
    public function addManager(AddManagerRequest $request) {
        $manager = User::saveManager($request);
        return $manager;
    }

    // Load Form for edit manager
    public function managerEdit($id) {
        $editManager = User::where('id', $id)->where('role', 'manager')->where('status', '!=', 'deleted')->first();
        if (!empty($editManager)) {
            return view('admin.manager.manager-edit', ['editManager' => $editManager]);
        }
        abort(404);
    }

    // To Delete Manager
    public function managerDelete($id) {
        return User::deleteManager($id);
    }

    // To Update Manager
    public function managerUpdate(EditManagerRequest $request) {
        if (!empty($request->managerId)) {
            $totalData = 0;
            $totalCustomer = CustomerExecutiveRelation::where('manager_id', $request->managerId)->groupBy('customer_id')->get();
            if(!empty($totalCustomer)){
                foreach($totalCustomer as $val){
                    $userData = \App\Http\Models\User::where(['id'=>$val->customer_id,'status'=>'active'])->first();
                    if(!empty($userData)){
                        $totalData++;
                    }
                }
            }
            if ($request->customer_limit < $totalData) {
                session()->flash('error', 'error');
                session()->flash('error', 'Please enter customer limit more than ');
                return Response::json(['success' => false, 'message' => 'Please enter customer limit more than ' . $totalCustomer->count()]);
            }
        }
        $manager = User::updateManager($request);
        return $manager;
    }

    // Upload csv file of merchant
    public function csvImport(Request $request) {
        $managerId = $request->manager_id;
        $customer_limit = User::select('customer_limit')->where('id', $managerId)->first();
        $CsvLimit = $customer_limit->customer_limit;
        $totalCustomer = CustomerExecutiveRelation::where('manager_id', $managerId)->groupBy('customer_id')->get();
        
        $totalData = 0;
        if(!empty($totalCustomer)){
            foreach($totalCustomer as $val){
                $userData = \App\Http\Models\User::where(['id'=>$val->customer_id,'status'=>'active'])->first();
                if(!empty($userData)){
                    $totalData++;
                }
            }
        }
        $dataLimit = $CsvLimit - $totalData;
        $emailArray = [];
        if (isset($_FILES['csv_file']['name'])) {
            //validate whether uploaded file is a csv file
            $csvMimes = array('application/vnd.ms-excel', 'text/plain', 'text/csv', 'text/tsv');
            if (!empty($_FILES['csv_file']['name']) && in_array($_FILES['csv_file']['type'], $csvMimes)) {
                if($dataLimit > 0){
                if (is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
                    //open uploaded csv file with read only mode
                    $csvFile = fopen($_FILES['csv_file']['tmp_name'], 'r');
                    //skip first line
                    fgetcsv($csvFile);
                    //parse data from csv file line by line
                    $inserCount = 1;
                    $dataCount = 1;
                    $total = 0;
                    while (($line = fgetcsv($csvFile)) !== FALSE) {
                        $total++;
                        //check email formate 
                        $email = trim($line[2]);
                        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            array_push($emailArray, $email);
                        } else {
                            $executiveArray = explode(",", trim($line[6]));
                            $userData = User::select('id')->where('status', '!=', 'deleted')->where(function ($query) use ($line) {
                                        $query->where('username', '=', trim($line[0]))
                                                ->orWhere('email', '=', trim($line[2]));
                                    })->first();
                            if (empty($userData)) {
                                $i = 0;
                                $limitFlag = 0;
                                foreach ($executiveArray as $executives) {
                                    //check executive by username 
                                    $executiveData = User::select('id')->where(['role' => 'executive', 'username' => $executives])->first();
                                    
                                    if (!empty($executiveData)) {
                                        //check executive assign to manager 
                                        $executiveReletion = ExecutiveManagerRelation::where(['executive_id' => $executiveData->id, 'manager_id' => $managerId])->first();
                                        if (!empty($executiveReletion)) {
                                            if ($inserCount <= $dataLimit) {
                                                if($line[0]!="" && $line[1]!="" && $line[2]!="" && $line[3]!=""){
                                                if ($line[0] == trim($line[0]) && strpos($line[0], ' ') !== false) {
                                                    $inserCount --;
                                                } else {
                                                $executiveId = $executiveData->id;
                                                $csvData = [];
                                                $csvData['username'] = trim($line[0]);
                                                $csvData['password'] = trim($line[1]);
                                                $csvData['email'] = trim($line[2]);
                                                $csvData['contact_name'] = trim($line[3]);
                                                $csvData['machine_model'] = trim($line[4]);
                                                $csvData['bussiness_name'] = trim($line[5]);
                                                $model = User::where(['username' => $csvData['username'], 'email' => $csvData['email']])->where('status', '!=', 'deleted')->first();
                                                if (empty($model)) {
                                                    $model = new User();
                                                    $model->username = $csvData['username'];
                                                    $model->role = 'customer';
                                                    $model->password = bcrypt($csvData['password']);
                                                    $model->email = $csvData['email'];
                                                    $model->contact_name = $csvData['contact_name'];
//                                         save the customer to the database
                                                    $model->save();

                                                    // save the data mail queue to the database
                                                    $mailModel = new MailQueue();
                                                    $mailModel->username = $csvData['username'];
                                                    $mailModel->password = $csvData['password'];
                                                    $mailModel->email = $csvData['email'];
                                                    $mailModel->save();
                                                    $dataCount ++;
                                                    
                                                }

                                                if (!empty($model)) {
//                                        $userModel = new UserProfile();
                                                    $userModel = UserProfile::firstOrNew(['user_id' => $model->id]);
                                                    $userModel->user_id = $model->id;
                                                    $userModel->machine_model = $csvData['machine_model'];
                                                    $userModel->bussiness_name = $csvData['bussiness_name'];
                                                    // save the customer to the database
                                                    $userModel->save();
                                                    $customerModel = new CustomerExecutiveRelation();
                                                    $customerModel->customer_id = $model->id;
                                                    $customerModel->executive_id = $executiveId;
                                                    $customerModel->manager_id = $managerId;
                                                    $customerModel->linked_by = Auth::guard(getAuthGuard())->user()->id;
                                                    // save the customer to the database
                                                    $customerModel->save();
                                                }
                                                }
                                                } else {
                                                    $inserCount --;
                                                }
                                            }else {
                                                if($i == 0){
                                                    $limitFlag = 1;
                                                }
                                            }
                                        }
                                    }
                                }
                                 $inserCount ++;
                            }
                            
                        }
                       
                    } 
                } 
                if(!empty($emailArray)){
                    /* send mail function for user credentials */
                    $errorEmail = implode(',', $emailArray);
                    $userEmail = Auth::guard(getAuthGuard())->user()->email;
                    $userName = Auth::guard(getAuthGuard())->user()->username;
                    $data = [];
                    $data['name'] = $userName;
                    $data['error'] = $errorEmail;
                    $data['email'] = $userEmail;
                    $data['subject'] = 'Csv Errors';
                    $data['request'] = 'csv_error_mail';
                    $mail = sendMail($data);
                }
                $inserCount --;
                $dataCount --;
                $remainingRecord = $total - $dataCount;
                if(@$limitFlag > 0){
                    return Response::json(['success' => false, 'message' => 'Your uploading limit has been over. '.$dataCount . ' Record inserted successfully remaining ' . $remainingRecord . ' record']);
                }
                if($dataCount == 0){
                    return Response::json(['success' => false, 'message' => 'your csv file is incorrect may be it contain duplicate or incorrect data, please check and try again later']);
                }
                return Response::json(['success' => true, 'message' => $dataCount . ' Record inserted successfully remaining ' . $remainingRecord . ' record']);
            }  else {
                return Response::json(['success' => false, 'message' => 'Your uploading limit has been over']);    
                } 
            } else {
                return Response::json(['success' => false, 'message' => 'File must be .csv format']);
            }
        }
        return Response::json(['success' => false, 'message' => 'Please try again']);
    }

    // Manager Detail By Id
    public function managerView($id) {
        $viewManager = User::where('id', $id)->where('role', 'manager')->where('status', '!=', 'deleted')->first();
        if (!empty($viewManager)) {
            return view('admin.manager.manager-view', ['viewManager' => $viewManager]);
        }
        abort(404);
    }

    // Download Manager List in CSV format
    public function downloadManagerCsv() {
        $post = [];
        $managers = User::getManagerListForCsv($post);
        $excelDownload = Excel::create('merchant_processor_records', function($excel) use ($managers) {
                    $excel->sheet('Sheet1', function($sheet) use($managers) {
                        $arr = array();
                        foreach ($managers as $userData) {
                            $data = array(
                                getFullName($userData->first_name, $userData->last_name),
                                $userData->email,
                                $userData->company_name,
                                $userData->phone_number,
                                showFullDateFormat($userData->created_at),
                                $userData->status
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Name', 'Email', 'Company Name', 'Phone Number', 'Created Date', 'Status')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export merchant processor');
            return redirect()->back();
        }
    }

}
