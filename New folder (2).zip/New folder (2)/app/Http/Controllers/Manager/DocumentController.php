<?php

namespace App\Http\Controllers\Manager;

use App\Http\Models\Document;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Requests\Manager\AddDocumentRequest;
use App\Http\Requests\Manager\EditDocumentRequest;
use Illuminate\Support\Facades\Auth;

class DocumentController extends Controller {

    /**
     * manage document index
     * @return view
     * */
    public function index() {
        return view('manager.document.index');
    }

    /**
     * all document list
     * @return view
     * */
    public function allDocument(Request $request) {
        try {
            $documents = Document::getDocumentsCreatedById($request->all());
            $html = View::make('manager.document._document_list', ['documents' => $documents])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * add new document
     * @return view
     * */
    public function addDocument() {
        return view('manager.document.add_document');
    }

    /**
     *  add new document
     * @return \Illuminate\Http\Response
     * */
    public function saveDocument(AddDocumentRequest $request) {
        return Document::saveDocuments($request);
    }

    /**
     * edit document
     * @return view
     * */
    public function editDocument($id) {
        $document = Document::where('id', $id)->where('manager_id', Auth::guard(getAuthGuard())->user()->id)->first();
        if (!empty($document)) {
            return view('manager.document.edit_document', ['document' => $document]);
        }
        abort(404);
    }

    /**
     * update document
     * @return \Illuminate\Http\Response
     * */
    public function updateDocument(EditDocumentRequest $request) {
        return Document::updateDocuments($request);
    }

    /**
     * view document
     * @return \Illuminate\Http\Response
     * */
    public function viewDocument($id) {
        $document = Document::where('id', $id)->where('manager_id', Auth::guard(getAuthGuard())->user()->id)->first();
        if (!empty($document)) {
            return view('manager.document.view_document', ['document' => $document]);
        }
        abort(404);
    }

    /**
     * delete document
     * @return \Illuminate\Http\Response
     * */
    public function deleteDocument($id) {
        return Document::deleteDocument($id);
    }

}
