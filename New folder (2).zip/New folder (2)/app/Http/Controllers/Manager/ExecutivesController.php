<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Http\Models\User;
use App\Http\Models\CallRequest;
use View;
use Excel;
use App\Http\Requests\Manager\AddExecutiveRequest;
use App\Http\Requests\Manager\EditExecutiveRequest;
use \App\Http\Models\CustomerExecutiveRelation;
use App\Http\Models\ExecutiveCategory;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Auth;

class ExecutivesController extends Controller {

    /**
     * manage executives index
     * @return view
     * */
    public function index() {
        return view('manager.executives.index');
    }

    /**
     * all executives list
     * @return view
     * */
    public function allExecutives(Request $request) {
        try {
            $executives = User::getAllExecutivesByManager($request->all(), 'listing');
            $html = View::make('manager.executives._executives_list', ['executives' => $executives])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     *  add new executive
     * @return \Illuminate\Http\Response
     * */
    public function addExecutive() {
        return view('manager.executives.add_executive');
    }

    /**
     *  save executive
     * @return \Illuminate\Http\Response
     * */
    public function saveExecutive(AddExecutiveRequest $request) {
        return User::saveExecutive($request->all());
    }

    /**
     *  edit executive form
     * @return view
     * */
    public function editExecutive($id) {
        $user = User::getUsersByType($id, 'executive');
        if (!empty($user)) {
            return view('manager.executives.edit_executive', ['user' => $user]);
        }
        abort(404);
    }

    /**
     *  update executive
     * @return \Illuminate\Http\Response
     * */
    public function updateExecutive(EditExecutiveRequest $request) {
        return User::updateExecutive($request->all());
    }

    /**
     *  view executive
     * @return view
     * */
    public function viewExecutive($id) {
        $user = User::getUsersByType($id, 'executive');
        if (!empty($user)) {
            return view('manager.executives.view_executive', ['user' => $user]);
        }
        abort(404);
    }

    /**
     * all assigned merchants by executive id
     * @return view
     * */
    public function assignedMerchantList($id) {
        try {
            $seMerchant = CustomerExecutiveRelation::getCustomerByExecutiveId($id);
            $html = View::make('manager.executives._assigned_merchants', ['seMerchant' => $seMerchant])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * support executive requests view
     * @return view
     * */
    public function seRequest() {
        return view('manager.executives.support_executive_request');
    }

    /**
     * list of  all support executive requests
     * @return response json
     * */
    public function SeRequestList(Request $request) {
        try {
            $executives = User::getAllExecutivesRequestByManager($request->all());
            $html = View::make('manager.executives._support_executive_request_list', ['executives' => $executives])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * request details by id
     * @return view
     * */
    public function seRequestView($id) {
        $userId = Auth()->guard(getAuthGuard())->user()->id;
        $managerId = getManagerByExecutiveId($id);
        if($userId == $managerId){
            return view('manager.executives.support_executive_request_view', ['id' => $id]);
        }
        abort(404);
    }

    /**
     * se request view list
      @return response json
     * */
//    public function seRequestViewList(Request $request) {
//        try {
//            $id = $request['id'];
//            $executives = CallRequest::where('status', '!=', 'missed_request')->where('executive_id', '=', $id)->groupBy('ticket_id')->groupBy('executive_id')->paginate(10);
//            $html = View::make('manager.executives._executive_request_list_view', ['executives' => $executives])->render();
//            return Response::json(['success' => true, 'html' => $html]);
//        } catch (\Exception $e) {
//            return Response::json(['success' => false, 'message' => $e->getMessage()]);
//        }
//    }
    
    public function seRequestViewList(Request $request) {
        try {
            $data = $request->all();
            $id = $request['id'];
            
            $lists = CallRequest::where('executive_id', $id)
                            ->where('call_time', '!=', "0")
                            ->where(function ($lists) {
                                $lists->where('status', 'pending')
                                ->orWhere('status', 'resolved');
                            })
                                    ->orderBy('id', 'DESC')->get();
            if (isset($data['page']) && $data['page'] != 0) {
                $page = $data['page'];
            } else {
                $page = 1;
            }
            $arr = [];
            $ticketArr = [];
            $mainArray = [];
            if (!empty($lists) && count($lists) > 0) {
                $collection = collect($lists);
                $grouped = $collection->groupBy('id');
                $grouped = $grouped->toArray();
                //$lists = $grouped->last();
                foreach ($grouped as $group) {
                    $groupCollection = collect($group);
                    $groupLast = $groupCollection->last();
                    array_push($mainArray, $groupLast);
                }
                $perPage = 10;
                //$currentItems = array_slice($mainArray, $perPage * ($page - 1), $perPage);
                // $paginator = new LengthAwarePaginator($currentItems, count($mainArray), $perPage, $page);
                foreach ($mainArray as $list) {
                    $list = (object) $list;
                    $executive = User::where(['id' => $list->executive_id])->first();
                    $customer = User::where(['id' => $list->customer_id])->first();
                    $list->ticket_id = getTicketById($list->ticket_id);
                    //if(!in_array($list->ticket_id, $ticketArr)){
                    $ticketArr[] = $list->ticket_id;
                    $list->exe_contact_name = $executive->contact_name;
                    $list->contact_name = $customer->contact_name;
                    $list->customer_profile = checkProfileImage($customer->profile_image);
                    $manager = CustomerExecutiveRelation::select(['users.first_name', 'users.last_name'])->join('users', 'customer_executive_relations.manager_id', '=', 'users.id')->where(['customer_executive_relations.customer_id' => $customer->id])->first();
                    $list->customer_bank = (!empty($manager)) ? $manager->first_name . ' ' . $manager->last_name : '';
                    $list->bank_category = ExecutiveCategory::getExecutiveCategoryName($list->category_id);
                    $list->notes = getNotesByTicketId($list->ticket_id);
                    $arr[] = $list;
                  //  }
                }
                $currentItems = array_slice($arr, $perPage * ($page - 1), $perPage);

                $paginator = new LengthAwarePaginator($currentItems, count($arr), $perPage, $page, ['path' => $request->url()]);
                $html = View::make('manager.executives._executive_request_list_view', ['executives' => $paginator])->render();
            }
            
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * se request note
      @return view
     * */
    public function seRequestNoteView($id) {
        $userId = Auth()->guard(getAuthGuard())->user()->id;
        $requestNotes = CallRequest::where('id', '=', $id)->first();
        $managerId = getManagerByExecutiveId($requestNotes->executive_id);
        if($userId == $managerId){
            
            $rating = \App\Http\Models\Rating::where(['request_id'=>$id])->first();
            return view('manager.executives.support_executive_request_note', ['requestNotes' => $requestNotes,'rating'=>$rating]);
        } 
        abort(404);
    }

    /*
     *  download executives listing csv
     */

    public function executivesListCsvDownload() {
        $post = [];
        $executives = User::getAllExecutivesByManagerForCSV($post, 'listing');
        $excelDownload = Excel::create('executive_records', function($excel) use ($executives) {
                    $excel->sheet('Sheet1', function($sheet) use($executives) {
                        $arr = array();
                        foreach ($executives as $userData) {
                            $string = $userData->city . ',' . $userData->state;
                            $string = trim($string, ',');
                            $data = array(
                                !empty($userData->executive_number) ? $userData->executive_number : '-',
                                ucfirst($userData->contact_name),
                                !empty($userData->phone_number) ? $userData->phone_number : '-',
                                getMerhcantCountByExcutive($userData->id),
                                !empty($userData->city || $userData->state) ? $string : '-'
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'ID', 'Name', 'Phone', 'Merchant', 'City/State')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export  executives listing');
            return redirect()->back();
        }
    }

    /*
     *  executives request csv download
     */

    public function downloadExecutiveRequestCsv() {
        $post = [];
        $executives = User::getAllExecutivesRequestByManager($post);
        $excelDownload = Excel::create('executive_reqeust_records', function($excel) use ($executives) {
                    $excel->sheet('Sheet1', function($sheet) use($executives) {
                        $arr = array();
                        foreach ($executives as $userData) {
                            $pendingRequest = \App\Http\Models\CallRequest::getPendingCallRequestByExecutive($userData->id, 'count');
                            $resolvedRequest = \App\Http\Models\CallRequest::getResolveCallRequestByExecutive($userData->id, 'count');
                            $data = array(
                                ucfirst($userData->contact_name),
                                (!empty($userData->bank->waiting_time) ? $userData->bank->waiting_time : '0') . 'min',
                                $pendingRequest > 0 ? $pendingRequest : '0',
                                $resolvedRequest > 0 ? $resolvedRequest : '0'
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Name', 'Average Waiting time', 'Pending request', 'Completed Request')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export executive request');
            return redirect()->back();
        }
    }

}
