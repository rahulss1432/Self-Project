<?php

namespace App\Http\Controllers\Manager;

use DB;
use Session;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Http\Requests\ResetPasswordRequest;
use App\Http\Requests\Manager\ForgotPasswordRequest;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\User;
use App\Http\Models\UserProfile;
use App\Http\Models\CustomerExecutiveRelation;
use App\Http\Models\MailQueue;
use App\Http\Models\ExecutiveManagerRelation;

class ManagerController extends Controller {

    public function index(Request $request) {
        if (Auth()->guard('manager')->check() && (Auth::guard('manager')->user()->status == 'active')) {
            return redirect('manager/dashboard');
        }
        return view('manager.index');
    }

    public function forgotPassword() {
        return view('manager.forgot-password.forgot-password');
    }

    public function sendForgotEmail(ForgotPasswordRequest $request) {
        return User::forgotEmail($request->all(), 'manager');
    }

    public function resetPassword($token) {
        $user = User::where('reset_token', $token)->first();
        if (empty($user)) {
            session()->flash('error', \Config::get('constants.reset_token_not_found'));
            return redirect('/manager');
        }
        return view('manager.forgot-password.password_reset', ['token' => $token]);
    }

    public function Reset(ResetPasswordRequest $request) {
        return User::ResetPassword($request->all());
    }

    public static function activeInactive($id) {
        $model = User::where('id', $id)->first();

        if ($model->status == 'active') {
            $model->status = 'inactive';
        } else {
            $model->status = 'active';
        }
        if ($model->save()) {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => 'Status Changed  Successfully.'));
        } else {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => 'Status Not Changed .'));
        }
    }

    public function deleteUser($id) {
        $delete = User::where('id', $id)->first();

        if ($delete->delete()) {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => 'Delete Successfully'));
        } else {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => 'Deletion Failed'));
        }
    }

    //N:- Upload csv file 
    public function csvImport(Request $request) {
        $managerId = $request->manager_id;
        $customer_limit = User::select('customer_limit')->where('id', $managerId)->first();
        $CsvLimit = $customer_limit->customer_limit;
        $totalCustomer = CustomerExecutiveRelation::where('manager_id', $managerId)->groupBy('customer_id')->get();
        $totalData = 0;
        if(!empty($totalCustomer)){
            foreach($totalCustomer as $val){
                $userData = \App\Http\Models\User::where(['id'=>$val->customer_id,'status'=>'active'])->first();
                if(!empty($userData)){
                    $totalData++;
                }
            }
        }
       // $totalData = $totalCustomer->count();
        $dataLimit = $CsvLimit - $totalData;
        $emailArray = [];
        if (isset($_FILES['csv_file']['name'])) {
            //validate whether uploaded file is a csv file
            $csvMimes = array('application/vnd.ms-excel', 'text/plain', 'text/csv', 'text/tsv');
            if (!empty($_FILES['csv_file']['name']) && in_array($_FILES['csv_file']['type'], $csvMimes)) {
                if($dataLimit > 0){
                if (is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
                    //open uploaded csv file with read only mode
                    $csvFile = fopen($_FILES['csv_file']['tmp_name'], 'r');
                    //skip first line
                    fgetcsv($csvFile);
                    //parse data from csv file line by line
                    $inserCount = 1;
                    $dataCount = 1;
                    $total = 0;
                    while (($line = fgetcsv($csvFile)) !== FALSE) {
                        $total++;
                        //check email formate 
                        $email = trim($line[2]);
                        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            array_push($emailArray, $email);
                        } else {
                            $executiveArray = explode(",", trim($line[6]));
                            $userData = User::select('id')->where('status', '!=', 'deleted')->where(function ($query) use ($line) {
                                        $query->where('username', '=', trim($line[0]))
                                                ->orWhere('email', '=', trim($line[2]));
                                    })->first();
                            if (empty($userData)) {
                                $i = 0;
                                $limitFlag = 0;
                                foreach ($executiveArray as $executives) {
                                    //check executive by username 
                                    $executiveData = User::select('id')->where(['role' => 'executive', 'username' => $executives])->first();
                                    if (!empty($executiveData)) {
                                        //check executive assign to manager 
                                        $executiveReletion = ExecutiveManagerRelation::where(['executive_id' => $executiveData->id, 'manager_id' => $managerId])->first();
                                        if (!empty($executiveReletion)) {
                                            if ($inserCount <= $dataLimit) {
                                                if($line[0]!="" && trim($line[1])!="" && trim($line[2])!="" && trim($line[3])!=""){
                                                if ($line[0] == trim($line[0]) && strpos($line[0], ' ') !== false) {
                                                    $inserCount --;
                                                } else {
                                                $executiveId = $executiveData->id;
                                                $csvData = [];
                                                $csvData['username'] = trim($line[0]);
                                                $csvData['password'] = trim($line[1]);
                                                $csvData['email'] = trim($line[2]);
                                                $csvData['contact_name'] = trim($line[3]);
                                                $csvData['machine_model'] = trim($line[4]);
                                                $csvData['bussiness_name'] = trim($line[5]);
                                                $model = User::where(['username' => $csvData['username'], 'email' => $csvData['email']])->where('status', '!=', 'deleted')->first();
                                                if (empty($model)) {
                                                    $model = new User();
                                                    $model->username = $csvData['username'];
                                                    $model->role = 'customer';
                                                    $model->password = bcrypt($csvData['password']);
                                                    $model->email = $csvData['email'];
                                                    $model->contact_name = $csvData['contact_name'];
//                                         save the customer to the database
                                                    $model->save();

                                                    // save the data mail queue to the database
                                                    $mailModel = new MailQueue();
                                                    $mailModel->username = $csvData['username'];
                                                    $mailModel->password = $csvData['password'];
                                                    $mailModel->email = $csvData['email'];
                                                    $mailModel->save();
                                                    $dataCount ++;
                                                    
                                                }

                                                if (!empty($model)) {
//                                        $userModel = new UserProfile();
                                                    $userModel = UserProfile::firstOrNew(['user_id' => $model->id]);
                                                    $userModel->user_id = $model->id;
                                                    $userModel->machine_model = $csvData['machine_model'];
                                                    $userModel->bussiness_name = $csvData['bussiness_name'];
                                                    // save the customer to the database
                                                    $userModel->save();
                                                    $customerModel = new CustomerExecutiveRelation();
                                                    $customerModel->customer_id = $model->id;
                                                    $customerModel->executive_id = $executiveId;
                                                    $customerModel->manager_id = $managerId;
                                                    $customerModel->linked_by = Auth::guard(getAuthGuard())->user()->id;
                                                    // save the customer to the database
                                                    $customerModel->save();
                                                }
                                                }
                                            } else {
                                               $inserCount --; 
                                            }
                                            } else {
                                                if($i == 0){
                                                    $limitFlag = 1;
                                                }
                                            }
                                        }
                                    }
                                }
                                 $inserCount ++;
                            }
                            
                        }
                       
                    } 
                }
                if(!empty($emailArray)){
                    /* send mail function for user credentials */
                    $errorEmail = implode(',', $emailArray);
                    $userEmail = Auth::guard(getAuthGuard())->user()->email;
                    $userName = Auth::guard(getAuthGuard())->user()->username;
                    $data = [];
                    $data['name'] = $userName;
                    $data['error'] = $errorEmail;
                    $data['email'] = $userEmail;
                    $data['subject'] = 'Csv Errors';
                    $data['request'] = 'csv_error_mail';
                    $mail = sendMail($data);
                }
                $inserCount --;
                $dataCount --;
                $remainingRecord = $total - $dataCount;
                if(@$limitFlag > 0){
                    return Response::json(['success' => false, 'message' => 'Your uploading limit has been over. '.$dataCount . ' Record inserted successfully remaining ' . $remainingRecord . ' record']);
                }
                if($dataCount == 0){
                    return Response::json(['success' => false, 'message' => 'your csv file is incorrect may be it contain duplicate or incorrect data, please check and try again later']);
                }
                return Response::json(['success' => true, 'message' => $dataCount . ' Record inserted, remaining ' . $remainingRecord . ' record']);
                }  else {
                return Response::json(['success' => false, 'message' => 'Your uploading limit has been over']);    
                }
            } else {
                return Response::json(['success' => false, 'message' => 'File must be .csv format']);
            }
        }
        return Response::json(['success' => false, 'message' => 'Please try again']);
    }

}
