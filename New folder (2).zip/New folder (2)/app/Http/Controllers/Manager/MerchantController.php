<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Http\Models\User;
use Illuminate\Support\Facades\Auth;
use View;
use Excel;
use App\Http\Requests\Manager\AddMerchantRequest;
use App\Http\Requests\Manager\EditMerchantRequest;
use App\Http\Models\CallRequest;
use App\Http\Models\CustomerExecutiveRelation;
use App\Http\Requests\Manager\EditMerchantCallRequest;
use App\Http\Models\Rating;

class MerchantController extends Controller {

    /**
     * manage merchants index
     * @return view
     * */
    public function index() {
        return view('manager.merchants.index');
    }

    /**
     * all merchants list
     * @return view
     * */
    public function allMerchant(Request $request) {
        try {
            $users = User::getAllMerchant($request->all());
            $html = View::make('manager.merchants._merchant_list', ['users' => $users])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     *  add new merchant
     * @return \Illuminate\Http\Response
     * */
    public function addMerchant() {
        return view('manager.merchants.add_merchant');
    }

    /**
     *  save merchant
     * @return \Illuminate\Http\Response
     * */
    public function saveMerchant(AddMerchantRequest $request) {
        return User::saveMerchant($request->all());
    }

    /**
     *  edit merchant form
     * @return view
     * */
    public function editMerchant($id) {
        $user = User::getUsersByType($id, 'customer');
        if (!empty($user)) {
            return view('manager.merchants.edit_merchant', ['user' => $user]);
        }
        abort(404);
    }

    /**
     *  update merchant
     * @return \Illuminate\Http\Response
     * */
    public function updateMerchant(EditMerchantRequest $request) {
        return User::updateMerchant($request->all());
    }

    /**
     *  view merchant
     * @return view
     * */
    public function viewMerchant($id) {
        $user = User::getUsersByType($id, 'customer');
        if (!empty($user)) {
            return view('manager.merchants.view_merchant', ['user' => $user]);
        }
        abort(404);
    }

    /**
     * linked merchant support list for merchant id
     */
    public function linkedSupport($id) {
        $merchantCall = User::where('id', $id)->where('role', 'customer')->where('status', '!=', 'deleted')->first();
        if (!empty($merchantCall)) {
            return view('manager.merchants.linked_support', ['id' => $id]);
        }
        abort(404);
    }

    /**
     * render view merchant linked support list
     * @return \Illuminate\Http\Response view
     * */
    public function linkedSupportList(Request $request) {
        try {
            $merchantCall = CallRequest::getMerchantRequestList($request, 'manager');
            $html = View::make('manager.merchants._linked_support_list', ['merchantCall' => $merchantCall])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * render merchant request view
     * @return view
     * */
    public function merchantRequest(Request $request) {
        return view('manager.merchants.merchant-request');
    }

    /**
     *  return view for all merchant request list
     * @return \Illuminate\Http\Response view
     * */
    public function merchantRequestList(Request $request) {
        try {
            $callRequests = CallRequest::getAllMerchantRequestHistory($request->all(), 'manager');
            $html = View::make('manager.merchants._merchant_request_list', ['callRequests' => $callRequests])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     *  return view merchant request by merchant
     * @return view
     */

    public function merchantRequestView($id) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $callRequest = CallRequest::getCallRequestsByRequestId($id);
        $managerId = getManagerByCustomerId($callRequest->customer_id);
        if($userId == $managerId){
           $rating = Rating::getRequestRating($id);
           $review = Rating::getReviewRating($id);
        if (!empty($callRequest)) {
            return view('manager.merchants.merchant-request-view', ['callRequest' => $callRequest,'rating'=>$rating, 'review' => $review]);
        }
        }
        abort(404);
    }

    /*
     * edit merchant request modal
     * @return \Illuminate\Http\Response view
     */

    public function editMerchantRequestModal($id) {
        try {
            $callRequest = CallRequest::getCallRequestsById($id);
            $html = View::make('manager.merchants._edit_merchant_request', ['callRequest' => $callRequest])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * update merchant
     * @return \Illuminate\Http\Response
     */

    public function updateMerchantRequest(EditMerchantCallRequest $request) {
        return CallRequest::updateCallRequests($request->all());
    }

    /*
     *  return view merchant's unsigned request
     * @return view
     */

    public function merchantUnassignedRequest(Request $request) {
        return view('manager.merchants.request-unassigned');
    }

    /*
     *  return view unsigned request listing
     * @return \Illuminate\Http\Response
     */

    public function listUnassignedRequest(Request $request) {
        try {
            $html = View::make('manager.merchants._request-unassigned')->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     *  return view unsigned request view
     * @return view
     */

    public function unassignedRequestView(Request $request) {
        return view('manager.merchants.request-unassigned-view');
    }

    /*
     *  download merchants lsiting csv
     */

    public function downloadMerchantCsv() {
        $post = [];
        $merchants = User::getAllMerchantForCSV($post = NULL);
        $excelDownload = Excel::create('merchant_records', function($excel) use ($merchants) {
                    $excel->sheet('Sheet1', function($sheet) use($merchants) {
                        $arr = array();
                        foreach ($merchants as $userData) {
                            $string = $userData->city . ',' . $userData->state;
                            $string = trim($string, ',');
                            $data = array(
                                !empty($userData->merchant_number) ? $userData->merchant_number : '-',
                                $userData->bussiness_name,
                                !empty($userData->contact_name) ? ucfirst($userData->contact_name) : '-',
                                !empty($userData->phone_number) ? $userData->phone_number : '-',
                                $userData->machine_model,
                                !empty($userData->city || $userData->state) ? $string : '-'
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Merchant Number', 'Business Name', 'Contact Name', 'Phone Number', 'Machine Model', 'City/State')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export merchant');
            return redirect()->back();
        }
    }

    /*
     *  download merchants request lsiting csv
     */

    public function downloadMerchantRequestHistoryCsv() {
        $post = [];
        $callRequests = CallRequest::getAllMerchantRequestHistoryForCSV($post, 'manager');
        $excelDownload = Excel::create('merchant_records', function($excel) use ($callRequests) {
                    $excel->sheet('Sheet1', function($sheet) use($callRequests) {
                        $arr = array();
                        foreach ($callRequests as $userData) {
                            if($userData->status == "resolved"){
                                 $status = $userData->status;   
                                } else {
                                    if($userData->is_call_dropped == 1){
                                        $status = 'Call Dropped';   
                                    } else {
                                        $status = $userData->status;   
                                    }
                                }
                            $data = array(
                                ucfirst($userData->customerDetail->contact_name),
                                $userData->UserProfile->product,
                                showFullMonthDateFormat($userData->created_at),
                                ucfirst($status),
                                $userData->executiveDetail->contact_name,
                                $userData->BankCategory->name,
                                $userData->call_time . ' minutes',
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Name', 'Processor', 'Generate Date', 'Status', 'SE Assigned', 'Category', 'Time of call')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export merchant reqest history');
            return redirect()->back();
        }
    }

    /*
     *  merchant's linked executive view
     * @return view
     */

    public function merchantLinkedExcutives($id) {
        $merchantSE = User::where('id', $id)->where('role', 'customer')->where('status', '!=', 'deleted')->first();
        if (!empty($merchantSE)) {
            return view('manager.merchants.merchant_linked_executive', ['id' => $id]);
        }
        abort(404);
    }

    /*
     *  merchant's linked executive listing
     * @return \Illuminate\Http\Response
     */

    public function merchantLinkedExcutiveList(Request $request) {
        try {
            $merchantSE = CustomerExecutiveRelation::getExecutiveByCustomerManagerId($request->id);
            $html = View::make('manager.merchants._merchant_linked_executive_list', ['merchantSE' => $merchantSE])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     *  merchant's linked executive csv download
     */

    public function downloadMerchantLinkedExecutiveCsv($id) {
        $merchantSE = CustomerExecutiveRelation::getExecutiveByCustomerManagerId($id);
        $excelDownload = Excel::create('merchant_executive_records', function($excel) use ($merchantSE) {
                    $excel->sheet('Sheet1', function($sheet) use($merchantSE) {
                        $arr = array();
                        foreach ($merchantSE as $userData) {
                            $managerName = \App\Http\Models\User::getManagerByDocument($userData->manager_id);
                            $data = array(
                                !empty($userData->userProfile->executive_number) ? $userData->userProfile->executive_number : '',
                                $userData->userDetail->contact_name,
                                !empty($managerName) ? ucfirst($managerName->first_name . ' ' . $managerName->last_name) : '-',
                                $userData->userDetail->phone_number,
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'ID', 'Name', 'Manager Name', 'Phone Number')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export merchant executive');
            return redirect()->back();
        }
    }

}
