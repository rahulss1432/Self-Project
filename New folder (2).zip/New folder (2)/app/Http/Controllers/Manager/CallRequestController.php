<?php

namespace App\Http\Controllers\Manager;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Models\BankingCategory;
use App\Http\Models\CallRequest;
use App\Http\Models\Rating;
use Excel;

class CallRequestController extends Controller {

    /**
     *  manager call request view
     * @return view
     * */
    public function callRequestList(Request $request) {
        return view('manager.call-request.index');
    }

    /**
     *  all call request of manager listing
     * @return \Illuminate\Http\Response
     * */
    public function AllCallRequestlist(Request $request) {
        try {
            $callRequest = CallRequest::getCallRequestList($request, 'manager');
            $html = View::make('manager.call-request._call_request_list', ['callRequest' => $callRequest])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     *  view call request by id
     * @return view
     * */
    public function callRequestView($id) {
        $userId = Auth()->guard(getAuthGuard())->user()->id;
        $callRequest = CallRequest::getCallRequestsById($id);
        $managerId = getManagerByExecutiveId($callRequest->executive_id);
        if($managerId == $userId){
            $rating = Rating::getRequestRating($id);
            if (!empty($callRequest)) {
                return view('manager.call-request.call-request-view', ['callRequest' => $callRequest, 'rating' => $rating]);
            }
        }
        abort(404);
    }

    /**
     *  download call request csv
     * @return view
     * */
    public function downloadCallRequestCsv() {
        $post = [];
        $callRequest = CallRequest::getCallRequestListForCsv($post, 'manager');
        $excelDownload = Excel::create('call_request_records', function($excel) use ($callRequest) {
                    $excel->sheet('Sheet1', function($sheet) use($callRequest) {
                        $arr = array();
                        foreach ($callRequest as $callData) {
                            if($callData->status == "resolved"){
                                 $status = $callData->status;   
                                } else {
                                    if($callData->is_call_dropped == 1){
                                        $status = 'Call Dropped';   
                                    } else {
                                        $status = $callData->status;   
                                    }
                                }
                            $data = array(
                                !empty($callData->UserProfile->bussiness_name) ? $callData->UserProfile->bussiness_name : '-',
                                !empty($callData->UserProfile->merchant_number) ? $callData->UserProfile->merchant_number : '-',
                                date('d-m-Y', strtotime($callData->created_at)),
                                $status,
                                !empty($callData->executiveDetail->contact_name) ? $callData->executiveDetail->contact_name : '-',
                                !empty($callData->BankCategory->name) ? $callData->BankCategory->name : '-',
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Business Name', 'Merchant Number', 'Date of Call', 'Status of Call', 'SE Assigned', 'Category')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export call request');
            return redirect()->back();
        }
    }

}
