<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
//        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('executive.index');
    }
    
    public function site()
    {
        return view('site');
    }
    
    public function test(){
        error_reporting(E_ALL);
        
//        $data = [];
//            $data['name'] = "Praveen";
//            $data['username'] = "Praveen";
//            $data['email'] = "praveenj@neuronsolutions.com";
//            $data['password'] = "test123";
//            $data['subject'] = 'User Credentials';
//            $data['request'] = 'user_mail';
//            $data['user_role'] = 'executive';
//            $data['created_by_role'] = \Illuminate\Support\Facades\Auth::guard(getAuthGuard())->user()->role;
//            $mail = sendMail($data);
        
       // $waitingTime = getWaitingTimeByUserId(5);
       //         $waitingTime = $waitingTime*60;
       //         echo $waitingTime; exit;
//        echo $deviceId;
//        exit;
        $deviceId = "442ac5f31f2e76b410abf8c48ede2c17aa090f2efd95aeac1c6bf85f65894e32";
      //  $deviceId = "e021f38cdf17329defce76b9a13e5d65265f313a270103863aec5d0a633537a6";
        $message = "Hi Linked Assist test";
//        $type = "";
        $user_type = "customer";
         // $deviceId = "feYrRVBFgls:APA91bE8PgVqxmrN_J_SZiz3B69X6X6zU8k8bdDmleppEWzYIGIV9O8z0J70JdmP6A_GZu_M2fTF5bZMdVfLo3p-wRluX5l46hWgM3eRvBWh85V26XjQGAcoXPQHpt2q-crhph6xDkGo";
          
//        if($device == 'android'){
            //\App\Common\Utility::FcmPushNotification([$deviceId], $message, $user_type,[],1,1,'nosave');
//        } else {
            \App\Common\Utility::APNSPushDeviceNotification($deviceId,$message,$user_type,[],1,1,'');
        //}
    }
    
     public function updateDisconnctUserCallRequest(Request $request){
        $post = $request->all();
        \App\Http\Models\CallRequest::updateDisconnctUserCallRequest($post);
    }
    
    public function ringing(){
        //$data = [
          //  "userId"=> 46,
            //'socketId'=>"test",
            //'reason'=>'test'
        //];
        //\App\Http\Models\CallRequest::updateDisconnctUserCallRequest($data);
        $data = \App\Http\Models\CallRequest::where(['call_current_status'=>'busy'])->get();
        if(!empty($data)){
            foreach($data as $val){
                $val->call_current_status = "free";
                $val->save();
            }
        }
        
    }
    
    public function endcallnotification(Request $request){
        $post = $request->all();
        \App\Http\Models\CallRequest::endUserCall($post);
    }
    
    public function updateCallStatus(Request $request){
        $post = $request->all();
        $result = \App\Http\Models\CallRequest::updateCallStatus($post);
        if($result){
             return response()->json(['success' => true, 'data' => []]);
        }
         return response()->json(['success' => false, 'data' => [], 'message' => 'some thing went worng']);
    }
    
    public function freeUser($id){
        $callRequest = \App\Http\Models\CallRequest::where(['executive_id'=>$id,'call_current_status'=>'busy'])->get();
        if(!empty($callRequest)){
            foreach ($callRequest as $val){
                $val->call_current_status = 'free';
                $val->save();
            }
        }
    }
    
    public function MarkAsFree(){
        $userID = Auth::guard('web')->user()->id;
        $callRequest = \App\Http\Models\CallRequest::where(['executive_id'=>$userID,'call_current_status'=>'busy'])->get();
        if(!empty($callRequest)){
            foreach ($callRequest as $val){
                $val->call_current_status = 'free';
                $val->save();
            }
        }
    }
}
