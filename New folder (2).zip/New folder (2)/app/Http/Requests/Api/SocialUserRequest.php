<?php
/**
 * Description: this request is used to add social user validation related operations .
 * Author : Codiant- A Yash Technologies Company.
 * Date : march 2019.
 */
namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class SocialUserRequest extends ApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name'=> 'required|max:50',
            'last_name'=> 'required|max:50',
            'email' => 'required|string|email',
            'role'=> 'required',
            'type'=> 'required',
            'profile_image'=> 'required'
                 
        ];
    }

    public function messages()
    {
        return [
           
        ];
    }  
}
