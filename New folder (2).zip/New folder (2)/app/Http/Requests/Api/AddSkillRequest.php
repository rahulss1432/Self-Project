<?php
/**
 * Description: this request is  to add mentor category validation related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : march 2019.
 */
namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class AddSkillRequest extends ApiRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            '*.category_id' => 'required',
            '*.service_id' => 'required',
            '*.exp_year' => 'required',
            '*.exp_month' => 'required',
        ];
    }

    public function messages() {
        return [
             '*.exp_month.required' =>'Expire month is required.', 
             '*.exp_year.required' =>'Expire year is required.' ,
             '*.service_id.required' =>'Service is required.',
             '*.category_id.required' =>'Category is required.' 
        ];
    }

}
