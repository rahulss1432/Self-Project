<?php

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class RateExecutiveRequest extends ApiRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'ticket_id' => 'required',
//            'executive_rating' => 'required',
//            'waiting_rating' => 'required',
//            'overall_rating' => 'required',
        ];
    }

    public function messages() {
        return [
            'ticket_id.required' => 'Ticket Id is Required',
//            'executive_rating.required' => 'Support Executive Rating is required.',
//            'waiting_rating.required' => 'Waiting Time Rating is required.',
//            'overall_rating.required' => 'Over All Rating is required.',
        ];
    }

}
