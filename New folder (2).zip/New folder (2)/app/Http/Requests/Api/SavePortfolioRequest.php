<?php
/**
 * Description: this request is used to add portfolio by mentor validation related operations .
 * Author : Codiant- A Yash Technologies Company.
 * Date : march 2019.
 */
namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class SavePortfolioRequest extends ApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'links' => 'nullable',
           
        ];
    }

    public function messages()
    {
        return [
           'links.valid_number_file' =>'you Can not upload more than 9 files' 
        ];
    }  
}
