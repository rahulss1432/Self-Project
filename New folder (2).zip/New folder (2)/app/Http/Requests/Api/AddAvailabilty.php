<?php

/**
 * Description: this request is used  for availability fields validation related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : march 2019.
 */

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class AddAvailabilty extends ApiRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'from_date' => 'required|date_format:Y-m-d',
            'to_date' => 'required|date_format:Y-m-d',
            'from_time' => 'required|date_format:H:i:s',
            'to_time' => 'required|date_format:H:i:s',
            'state' => 'required',
            'city' => 'required',
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
        ];
    }

    public function messages() {
        return [
            'from_date.date_format' => 'Please fill proper from date format.',
            'to_date.date_format' => 'Please fill proper end date format.',
            'from_time.date_format' => 'Please fill proper from time format.',
            'to_time.date_format' => 'Please fill proper end time format.',
            'latitude.regex' => 'Latitude value appears is incorrect format.',
            'longitude.regex' => 'Longitude value appears is incorrect format.'
        ];
    }

}
