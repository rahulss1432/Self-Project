<?php

/**
 * Description: this request is used to changes password validation related operations.
 * Author : Codiant- A Yash Technologies Company.
 * Date : march 2019.
 */

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class ChangePasswordRequest extends ApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            
            'current_password'=> 'required|min:6|max:50|current_password_match_api',
            'new_password'  =>'required|min:6|max:50',
            'confirm_password'  =>'required|same:new_password|min:6|max:50',
            
                 
        ];
    }

    public function messages()
    {
        return [
          'current_password.current_password_match_api' =>'Current password does not match' 
        ];
    }  
}
