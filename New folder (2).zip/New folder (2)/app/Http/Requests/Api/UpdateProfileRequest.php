<?php
/**
 * Description: this request is used to update profile validation related operations .
 * Author : Codiant- A Yash Technologies Company.
 * Date : march 2019.
 */
namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;
use JWTAuth;

class UpdateProfileRequest extends ApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
      
        $user = JWTAuth::toUser(request()->header('access_token'));
        return [
            //'email' => 'required|string|email|unique:users,email,'.$user->id,
            'phone_number'=> 'nullable|numeric',
            'date_of_birth'=> 'nullable|date_format:Y-m-d',
       
                 
        ];
    }

    public function messages()
    {
        return [
           
        ];
    }  
}
