<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddExecutiveRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {

        return[
            'username' => 'required|max:30|remove_spaces|username_unique_not_deleted',
            'password' => 'required|min:6|max:20',
            'contact_name' => 'required|remove_spaces|max:30',
            'category' => 'required',
            'manager_id' => 'required',
            'phone' => 'nullable|numeric|digits_between:4,16',
            'email' => 'required|check_email_format|email_unique_not_deleted',
            'supervisor_email' => 'nullable|email|max:50|check_email_format',
            'supervisor_phone' => 'nullable|numeric|digits_between:4,16',
        ];
    }

    public function messages() {
        return[
            'contact_name.remove_spaces' => 'The contact name does not contain spaces.',
            'manager_id.required' => 'The merchant processor is required',
            'email.check_email_format' => 'The email format is not valid.',
            'category.required' => 'The category field is required.',
            'username.remove_spaces' => 'The username does not contain spaces.',
            'supervisor_email.check_email_format' => 'The supervisor email format is not valid.',
            'username.username_unique_not_deleted' => 'The username is already exists.',
            'email.email_unique_not_deleted' => 'The email is already exists.',
        ];
    }

}
