<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class EditExecutiveRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return[
            'contact_name' => 'required|remove_spaces|max:30',
            'category' => 'required',
            'manager_id' => 'required',
            'phone' => 'nullable|numeric|digits_between:4,16',
            'email' => 'required|check_email_format|email_matched_not_deleted',
            'supervisor_email' => 'nullable|email|max:50|check_email_format',
            'supervisor_phone' => 'nullable|numeric|digits_between:4,16',
        ];
    }

    public function messages() {
        return[
            'contact_name.remove_spaces' => 'The contact name does not contain spaces.',
            'manager_id.required' => 'The merchant processor is required',
            'email.check_email_format' => 'The email format is not valid.',
            'category.required' => 'The category field is required.',
            'supervisor_email.check_email_format' => 'The supervisor email format is not valid.',
            'email.email_matched_not_deleted' => 'The email is already using by other user.',
        ];
    }

}
