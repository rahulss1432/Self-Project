<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class EditManagerRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'first_name' => 'required|string|remove_spaces|max:50',
            'last_name' => 'required|string|remove_spaces|max:50',
            'email' => 'required|check_email_format|email_matched_not_deleted',
            'phone' => 'required|numeric|digits_between:4,16',
            'company' => 'required|remove_spaces',
            'waiting_time' => 'required',
             'customer_limit' => 'required|integer|min:1|max:9999',
//            'manager_type' => 'required',
//            'image_file' => 'nullable|mimes:jpeg,png,jpg,svg|max:2048',
//            'hiddenFileName' => 'required',
        ];
    }

    public function messages() {
        return [
            'first_name.remove_spaces' => 'The first name does not contain spaces.',
            'last_name.remove_spaces' => 'The last name does not contain spaces.',
            'company.remove_spaces' => 'The company does not contain spaces.',
//            'phone.phone_format' => 'The phone must be at least 10 characters.',
            'email.email_matched_not_deleted' => 'The email is already using by other user.',
            'email.check_email_format' => 'The email format is not valid.',
//            'hiddenFileName.required' => 'The image field is required',
        ];
    }

}
