<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddMerchantRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return
                    [
                    'manager_id' => 'required|check_customer_limit',
                    'contact_name' => 'required|remove_spaces|max:30',
                    'password' => 'required|min:6|max:20',
                    'username' => 'required|max:30|remove_spaces|username_unique_not_deleted',
//                    'merchant_number' => 'required|remove_spaces',
//                    'terminal_model' => 'required|remove_spaces',
                    'machine_model' => 'required|remove_spaces|max:100',
                    'bussiness_name' => 'required|remove_spaces|min:4|max:30',
//                    'bussiness_address' => 'required|remove_spaces|min:4|max:30',
//                    'product' => 'required|remove_spaces|min:4|max:30',
                    'phone' => 'nullable|numeric|digits_between:4,16',
                    'email' => 'required|check_email_format|email_unique_not_deleted',
//                    'city' => 'required|remove_spaces|max:100',
//                    'state' => 'required|remove_spaces|max:100',
                    'executive' => 'required',
//                    'image_file' => 'required|mimes:jpeg,png,jpg,svg|max:2048',
        ];
    }

    public function messages() {
        return[
            'manager_id.required' => 'The manager field is required.',
            'manager_id.check_customer_limit' => 'The manager`s customer limit is over.',
            'contact_name.remove_spaces' => 'The contact name does not contain spaces.',
            'username.remove_spaces' => 'The username does not contain spaces.',
//            'merchant_number.remove_spaces' => 'The merchant number does not contain spaces.',
//            'terminal_model.remove_spaces' => 'The terminal model does not contain spaces.',
            'bussiness_name.required' => 'The business name field is required.',
//            'bussiness_address.required' => 'The business address field is required.',
            'bussiness_name.remove_spaces' => 'The business name does not contain spaces.',
//            'bussiness_address.remove_spaces' => 'The business address does not contain spaces.',
//            'product.remove_spaces' => 'The product does not contain spaces.',
//            'city.remove_spaces' => 'The city does not contain spaces.',
//            'state.remove_spaces' => 'The state does not contain spaces.',
            'email.check_email_format' => 'The email format is not valid',
//            'phone.phone_format' => 'The mobile number is not valid',
            'username.username_unique_not_deleted' => 'The username is already exists.',
            'email.email_unique_not_deleted' => 'The email is already exists.',
            'machine_model.remove_spaces' => 'The machine model does not contain spaces.',
        ];
    }

}
