<?php

class StaticMessage
{

    public static $app = [
        'signup' => 'A verification has been sent your email ID.',
        'resent_code' => 'Code resent successfully.',
        'resent_token' => 'A code to reset password has been sent to registered email ID.',
        'resent_email' => 'Email address doesn’t match with our record.Please enter the registered email address.',
        'verify_code' => 'Verification successfull.',
        'verify_code_invalid' => 'Verification code is not valid.',
        'pass_reset' => 'Your password hes been changed successfully.',
        'pass_reset_token_invalid' => 'Reset code is not valid.',
        'availibilty_add' => 'Availability added successfully.',
        
    ];
    
   public static $admin = [
        'es' => 'www.domain.es',
        'en' => 'www.domain.us',
        
    ];
}