(function() {
    'use strict';
    var express = require('express');
    var app = express();
    var request = require('request');
    var http = require('http');
    var serverUrl = 'http://localhost/mentor-locator/api/';

    app.use(express.static(__dirname + '/public'));
    app.get('/', function(req, res) {
        res.sendFile(__dirname + '/index.html');
    });

    var server = app.listen(6021);
    var io = require('socket.io')(server);
    var connectedUsers = {};

    io.sockets.on('connection', function(socket) {
		
        socket.on('join_chat', function(data) {
            var userJID = data.userID;
            if (connectedUsers.hasOwnProperty(userJID)) {
                connectedUsers[userJID].removeAllListeners();
                connectedUsers[userJID].disconnect();
                delete connectedUsers[userJID];

            };
            if (!connectedUsers.hasOwnProperty(userJID)) {
                socket.userId = userJID;
                connectedUsers[userJID] = socket;
                console.log('connecting ', userJID);
            };
        });

        socket.on('new_msg_send', function(data) {
            saveChatMessage(data);
        });

        socket.on('is typing', function(data) {
            var toUser = data.to;
            if (connectedUsers.hasOwnProperty(toUser)) {
                connectedUsers[toUser].emit('typing', data);
            };
        });

        socket.on('leave-chat', function(data) {
            console.log(data);
            var userJID = data.userID;
            if (connectedUsers.hasOwnProperty(userJID)) {
                connectedUsers[userJID].removeAllListeners();
                connectedUsers[userJID].disconnect();
                delete connectedUsers[userJID];
            };
        });

        socket.on('disconnect', function() {
            console.log('user disconnected.');
            socket.disconnect();
        });

        function saveChatMessage(data) {
            var message = data.message;
            var fromUser = data.from_id;
            var toUser = data.to_id;

            request.post(
                serverUrl + 'message', {
                    json: {
                        "to_id": toUser,
                        "from_id": fromUser,
                        "message": message
                    }
                },
                function(error, response, body) {
                    if (!error && response.statusCode == 200) {
                        if (connectedUsers.hasOwnProperty(toUser)) {
                            connectedUsers[toUser].emit('new_msg_recieve', data);
                            console.log(response.body);
                        } else {
                            request.post(
                                serverUrl + 'notification', {
                                    json: {
                                        "to_id": toUser,
                                        "from_id": fromUser,
                                        "message": message,
                                        "notification_data": "{test:123}",
                                        "type": "test",
                                    }
                                },
                                function(error, response, body) {
                                    if (!error && response.statusCode == 200) {
                                    } else {
                                        console.log(response.body);
                                    }
                                }
                            );
                        };
                    } else {
                        console.log(response.body);
                    }
                }
            );
        }
    });
})();