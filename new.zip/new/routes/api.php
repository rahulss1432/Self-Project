<?php

use Illuminate\Http\Request;

/*
  |--------------------------------------------------------------------------
  | API Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register API routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | is assigned the "api" middleware group. Enjoy building your API!
  |
 */

Route::group(['namespace' => 'Api'], function() {

    Route::get('country-list', 'CommonController@getCountry');
    Route::get('state-list', 'CommonController@getState');
    Route::get('city-list', 'CommonController@getCity');
    
    Route::post('signup', 'UserController@signup');
    Route::post('login', 'AccountController@login');
    Route::post('resend-code', 'UserController@sendOTP');
    Route::post('verify-code', 'UserController@OTPVerify');
    Route::post('check-verification', 'UserController@checkVerification');
    Route::post('forgot-password', 'UserController@forgotPassword');
    Route::post('reset-password', 'UserController@resetPassword');
    Route::post('social-login', 'UserController@saveSocialUser');

	Route::post('/message', 'ChatController@postMessage');
	Route::post('/notification', 'NotificationController@saveNotification');
    
    Route::group(['middleware' => 'jwt.auth'], function () {

		// Auth
        Route::post('/logout', 'AccountController@logout');
        Route::post('/change-password', 'AccountController@chnagePassword');
        Route::post('/update-profile', 'UserController@updateProfile');
        Route::get('/user-detail', 'UserController@getUser');
        Route::post('/availability', 'MentorController@addAvailability');
        Route::put('/availability', 'MentorController@editAvailability');
        Route::get('/availability', 'MentorController@getAvailability');
        Route::delete('/availability/{id}', 'MentorController@deleteAvailability');
		
        // Notification
        Route::get('/notification', 'NotificationController@getNotification');
        Route::delete('/notification/{id}', 'NotificationController@deleteNotification');

        // User Appointment
        Route::post('/appointment', 'MenteeController@saveAppointment');

        Route::post('/complaints', 'CommonController@saveComplaints');
        Route::post('/toggle-favorite', 'MenteeController@saveFavorite');

		// Skill
        Route::post('/service', 'MentorController@addSkill');
        Route::get('/service', 'MentorController@getSkill');

        // Mentor Appointment
        Route::get('/appointment', 'CommonController@getAppointment');
        Route::put('/appointment/{id}', 'CommonController@updateAppointment');
        Route::delete('/appointment/{id}', 'CommonController@deleteAppointment');

        // chat routes
        Route::get('/inbox', 'ChatController@getInbox');
        Route::get('/chat-list', 'ChatController@getChatList');
        Route::delete('/chat/{to_id}', 'ChatController@deleteChat');

        // Offer
        Route::post('/offer', 'MentorController@saveOffer');
        Route::get('/offer', 'CommonController@getOffer');

        // Portfolio
        Route::post('/portfolio', 'MentorController@savePortfolio');
        Route::get('/portfolio', 'MentorController@getPortfolio');
        Route::get('/my-earning', 'MentorController@getEarning');
        
        // rating and services
        Route::post('/rating', 'CommonController@givRating');
        Route::get('/rating', 'CommonController@getRatingReiew');
        Route::get('/category', 'MenteeController@categoryList');
        Route::get('/services', 'MenteeController@serviceList');
		
		// Post
		Route::post('/post', 'CommonController@savePost');
        Route::get('/post', 'CommonController@getPost');
		
	Route::post('/contact-us', 'CommonController@contactUs');
	Route::post('/mentor-home', 'CommonController@contactUs');
	Route::get('/users', 'MentorController@explorUsers');

    });
});
