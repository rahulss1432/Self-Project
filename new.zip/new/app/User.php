<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Auth;

class User extends Authenticatable {

    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
    
    public function mentorServces() {
        return $this->hasMany('App\Models\MentorCategory','user_id','id');
    }

    public static function forgotEmail($post, $callFrom) {
        try {
            $user = User::where('email', $post['email'])->first();
            if (!empty($user)) {
                $reset_password_token = str_random(30);
                $data = [];
                if ($callFrom == 'admin') {
                    $data['request'] = 'admin_forgot_password';
                    $data['link'] = url('admin/reset-password/' . $reset_password_token);
                }
                $data['username'] = $user->first_name;
                $data['email'] = $user->email;
                $data['subject'] = 'Reset password link';
                $mail = sendMail($data);
                if (!empty($user)) {
                    $user->reset_token = $reset_password_token;
                    if ($user->save()) {
                        return Response::json(['success' => true, 'message' => 'send mail successfully']);
                    }
                } else {
                    return Response::json(['success' => false, 'message' => 'something went wrong']);
                }
                return redirect('/admin');
            }
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function ResetPassword($post) {
        try {
            $reset_token = $post['reset_token'];
            $password = $post['password'];
            $user = User::where('reset_token', $reset_token)->first();
            if (!empty($user)) {
                $user->reset_token = NULL;
                $user->password = bcrypt($password);
                $user->save();
                return Response::json(['success' => true, 'message' => 'Password reset successfully']);
            } else {
                return Response::json(['success' => false, 'message' => 'Reset token not found']);
            }
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
