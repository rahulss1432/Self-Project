<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MentorCategory extends Model {

    protected $table = 'mentor_categories';
    protected $fillable = [
        'user_id', 'category_id', 'service_id', 'exp_year', 'exp_month', 'amount', 'level_of_knowledge'
    ];

    public function mentorCategory() {
        return $this->belongsTo('App\Models\Category', 'category_id', 'id');
    }
    public function category() {
        return $this->belongsTo('App\Models\Category', 'category_id', 'id')->select('category_name');
    }

    public function mentorService() {
        return $this->belongsTo('App\Models\Service', 'service_id', 'id');
    }
    public function service() {
        return $this->belongsTo('App\Models\Service', 'service_id', 'id')->select('name');
    }

}
