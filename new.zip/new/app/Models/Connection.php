<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Connection extends Model {

    public function connectionFromUser() {
        return $this->belongsTo('App\User', 'from_id', 'id');
    }

    public function connectionToUser() {
        return $this->belongsTo('App\User', 'to_id', 'id');
    }

}
