<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Availability extends Model {

    protected $table = 'availability';
    protected $fillable = [
        'state_id', 'city', 'message', 'from_date', 'to_date', 'from_time', 'to_time'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    public function userState() {
        return $this->belongsTo('App\Models\State', 'state_id', 'id');
    }

}
