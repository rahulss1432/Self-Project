<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Portfolio extends Model {

    protected $table = 'portfolios';
    
    protected $fillable = [
        'user_id', 'link', 'bio'
    ];
	
    protected $hidden = [
        'created_at', 'updated_at'
    ];

}
