<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model {

    public function transactionMentor() {
        return $this->belongsTo('App\User', 'mentor_id', 'id');
    }

    public function transactionUser() {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }
    
    public function transactionBooking() {
        return $this->belongsTo('App\Models\Appointment', 'appointment_id', 'id');
    }

}
