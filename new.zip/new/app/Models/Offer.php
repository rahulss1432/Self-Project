<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Offer extends Model {

    protected $table = 'offers';
    
    protected $fillable = [
        'from_id', 'to_id', 'category_id', 'service_id', 'date_time', 'price'
    ];
	
    protected $hidden = [
        'created_at', 'updated_at'
    ];

}
