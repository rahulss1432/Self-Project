<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Rating extends Model {

    protected $table = 'ratings';
    protected $fillable = [
        'from_id', 'to_id', 'rating', 'reviews', 'appointment_id'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    protected $appends = ['rating_date'];

    public function getRatingDateAttribute() {
        $dateFormat = getSetting('date_time_format');
        return date($dateFormat, strtotime($this->created_at));
    }

    public function ratingFromUser() {
        return $this->belongsTo('App\User', 'from_id', 'id');
    }

    public function fromUser() {
        return $this->belongsTo('App\User', 'from_id', 'id')->select('first_name', 'last_name', 'profile_image');
    }

    public function ratingToUser() {
        return $this->belongsTo('App\User', 'to_id', 'id');
    }

    public function ratingAppointment() {
        return $this->belongsTo('App\Models\Appointment', 'appointment_id', 'id');
    }

}
