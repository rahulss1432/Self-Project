<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Complaint extends Model {

    protected $table = 'complaints';
    protected $fillable = [
        'from_id', 'to_id', 'comments'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    public function fromUser() {
        return $this->belongsTo('App\User', 'from_id', 'id');
    }

    public function toUser() {
        return $this->belongsTo('App\User', 'to_id', 'id');
    }

}
