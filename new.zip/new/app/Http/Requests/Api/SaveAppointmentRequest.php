<?php

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class SaveAppointmentRequest extends ApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'to_id' => 'required',
            'date' => 'required|date_format:Y-m-d',
            'meeting_place' => 'required',
            'meeting_address' => 'required',
            'level_of_knowledge' => 'required',
			'description' => 'required'
        ];
    }

    public function messages()
    {
        return [
           
        ];
    }  
}
