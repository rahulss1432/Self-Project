<?php

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class ChangePasswordRequest extends ApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            
            'current_password'=> 'required|min:6|max:50|current_password_match_api',
            'new_password'  =>'required',
            'confirm_password'  =>'required|same:new_password',
            
                 
        ];
    }

    public function messages()
    {
        return [
          'current_password.current_password_match_api' =>'Current password does not match' 
        ];
    }  
}
