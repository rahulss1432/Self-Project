<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\SaveAppointmentRequest;
use App\Http\Requests\Api\SaveFavoriteRequest;
use App\Repositories\Api\AppointmentRepository;
use App\Repositories\Api\FavoriteRepository;
use JWTAuth;
use App\Repositories\Api\UserRepository;


class MenteeController extends Controller {

    public function __construct(AppointmentRepository $appointment, FavoriteRepository $favorite,UserRepository $user) {
        $this->appointment = $appointment;
        $this->favorite = $favorite;
        $this->user = $user;
    }

    /*
     * Save Appointment
     */

    public function saveAppointment(SaveAppointmentRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->appointment->saveAppointment($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => 'Saved successfully.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Save Favorite
     */

    public function saveFavorite(SaveFavoriteRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->favorite->saveFavorite($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Favorite list updated successfully.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * categoryList
     */

    public function categoryList(Request $request) {
        
        try {

            $data = $this->user->categoryList($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * services
     */

    public function serviceList(Request $request) {
        try {

            $data = $this->user->services($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

}
