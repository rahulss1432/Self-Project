<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Api\NotificationRepository;

class NotificationController extends Controller {

    public function __construct(NotificationRepository $notification) {
        $this->notification = $notification;
    }
	
	/*
	 * Save Notification
	 */
	public function saveNotification(Request $request){
		try {
            $data = $this->notification->saveNotification($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Notification saved successfully.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
	}
    
    /**
     * Get notification.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getNotification(Request $request)
    {   return $this->notification->getNotification($request);
    }
    /**
     * delete notification.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function deleteNotification(Request $request)
    {
        return $this->notification->deleteNotification($request);
    }
  

}
