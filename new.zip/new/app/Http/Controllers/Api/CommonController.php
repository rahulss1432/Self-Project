<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\SaveComplaintsRequest;
use App\Http\Requests\Api\SaveAppointmentRequest;
use App\Http\Requests\Api\SavePostRequest;
use App\Repositories\Api\CommonRepository;
use App\Repositories\Api\ComplaintRepository;
use App\Repositories\Api\AppointmentRepository;
use App\Repositories\Api\OfferRepository;
use App\Repositories\Api\UserRepository;
use App\Repositories\Api\PostRepository;
use JWTAuth;

class CommonController extends Controller {

    public function __construct(CommonRepository $common, ComplaintRepository $complaint, AppointmentRepository $appointment, OfferRepository $offer, UserRepository $user, PostRepository $post) {
        $this->common = $common;
        $this->complaint = $complaint;
        $this->appointment = $appointment;
        $this->offer = $offer;
        $this->user = $user;
        $this->post = $post;
    }

    /**
     * Get user detail by token.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getCountry(Request $request) {
        return $this->common->getCountry($request);
    }

    /**
     * Get user detail by token.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getState(Request $request) {
        return $this->common->getState($request);
    }

    /**
     * Get user detail by token.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getCity(Request $request) {
        echo "city";
        die;
        return $this->user->getUser($request);
    }

    /*
     * Save Complaints
     */

    public function saveComplaints(SaveComplaintsRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->complaint->saveComplaints($request, $user);
            return response()->json(['success' => true, 'data' => $data, 'message' => 'Saved successfully']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Get Appointment
     */

    public function getAppointment(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->appointment->getAppointment($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Update Appointment
     */

    public function updateAppointment(SaveAppointmentRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->appointment->updateAppointment($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => 'Updated successfully.']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Delete Appointment
     */

    public function deleteAppointment(Request $request) {
        try {
            $data = $this->appointment->deleteAppointment($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Deleted successfully.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Invalid Appointment ID.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Get Offer
     */

    public function getOffer(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->offer->getOffer($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * giv rating
     */

    public function givRating(Request $request) {
        try {
            $data = $this->user->givRating($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Rating successfull']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Save Post
     */

    public function savePost(SavePostRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->post->savePost($request, $user);
            return response()->json(['success' => true, 'data' => $data, 'message' => 'Saved successfully']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Get Post
     */

    public function getPost(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->post->getPost($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Get rating and review
     */

    public function getRatingReiew(Request $request) {
        
        try {
            $data = $this->common->getRatingReiew($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }
	
	/*
     * Contact Us
     */

    public function contactUs(Request $request) {
        try {
			$data['request'] = 'contact_us';
			$data['name'] = $request->name;
			$data['subject'] = $request->type;
			$data['comments'] = $request->comments;
			$mail = sendMail($data);
            if ($data) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Your mail sent successfully.']);
            } else {
                return response()->json(['success' => true, 'data' => [], 'message' => '']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

}
