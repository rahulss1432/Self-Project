<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Api\UserRepository;
use App\Http\Requests\Api\UserValidation;
use App\Http\Requests\Api\OtpValidation;
use App\Http\Requests\Api\AddBankAccountValidation;
use App\Http\Requests\Api\Verificationrequest;
use App\Http\Requests\Api\PasswordResetRequest;
use App\Http\Requests\Api\UpdateProfileRequest;
use App\Http\Requests\Api\CodeVerifyRequest;
use App\Http\Requests\Api\ForgotPasswordRequest;
use App\Http\Requests\Api\SocialUserRequest;

class UserController extends Controller
{
    
    public function __construct(UserRepository $user) {
        $this->user = $user;
    }

    /**
     * Send otp for user registration.
     * @param type $request(OBJ)
     * @return type Json
     */
    
    public function sendOTP(Verificationrequest $request){
        //return $request->all();
        return  $this->user->sendOTP($request);
    }

    /**
     * OTP and mobile varification .
     * @param type $request(OBJ)
     * @return type Json
     */
    public function OTPVerify(CodeVerifyRequest $request)
    {
        return $this->user->OTPVerify($request);
    }

    /**
     * Get user detail by token.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getUser(Request $request)
    {
        return $this->user->getUser($request);
    }

    /**
     * update user profile
     * @param type $request(OBJ)
     * @return type Json
     */
    public function updateProfile(UpdateProfileRequest $request)
    {   return $this->user->updateProfile($request);
    }
    /**
     * user add
     * @param type $request(OBJ)
     * @return type Json
     */
    public function signup(UserValidation $request)
    {
        return $this->user->saveUser($request);
    }


    /**
     * user logout.
     * @param type $request(OBJ)
     * @return type Jsone
     */
    public function logout(Request $request){
        
        //return 'test';
        return $this->user->logout($request); 
    }

  
    /**
     *remove user from database. 
     */
    public function removeUser(Request $request,$mobile){
        
          return $this->user->removeUser($mobile);         
    }
    
    /**
     *send forgot mail. 
     */
    public function forgotPassword(ForgotPasswordRequest $request){
        
          return $this->user->forgotPassword($request);         
    }
    
    /**
     *reset password. 
     */
    public function resetPassword(PasswordResetRequest $request){
        
          return $this->user->resetPassword($request);         
    }
    
    public function checkVerification(Verificationrequest $request){
        
          return $this->user->checkVerification($request);         
    }
    
    public function saveSocialUser(SocialUserRequest $request){
        
          return $this->user->saveSocialUser($request);         
    }
    
}
