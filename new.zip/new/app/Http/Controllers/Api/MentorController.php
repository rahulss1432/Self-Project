<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\AddAvailabilty;
use App\Http\Requests\Api\SaveOfferRequest;
use App\Http\Requests\Api\SavePortfolioRequest;
use App\Repositories\Api\MentorRepository;
use App\Repositories\Api\OfferRepository;
use App\Repositories\Api\PortfolioRepository;
use App\Repositories\Api\UserRepository;
use JWTAuth;

class MentorController extends Controller {

    public function __construct(MentorRepository $mentor, OfferRepository $offer, PortfolioRepository $portfolio, UserRepository $user) {
        $this->mentor = $mentor;
        $this->offer = $offer;
        $this->portfolio = $portfolio;
        $this->user = $user;
    }

    /**
     * add availability.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function addAvailability(AddAvailabilty $request) {
        return $this->mentor->addAvailability($request);
    }

    /**
     * edit availability.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function editAvailability(Request $request) {
        return $this->mentor->editAvailability($request);
    }

    /**
     * edit availability.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getAvailability(Request $request) {
        return $this->mentor->getAvailability($request);
    }

    /**
     * edit availability.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function deleteAvailability(Request $request) {
        return $this->mentor->deleteAvailability($request);
    }

    public function addSkill(Request $request) {
        return $this->mentor->addSkill($request);
    }

    public function getSkill(Request $request) {
        return $this->mentor->getSkill($request);
    }

    /*
     * Save Offer
     */

    public function saveOffer(SaveOfferRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->offer->saveOffer($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => 'Saved successfully.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Save Portfolio
     */

    public function savePortfolio(SavePortfolioRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->portfolio->savePortfolio($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => 'Saved successfully.']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Get Portfolio
     */

    public function getPortfolio(Request $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $data = $this->portfolio->getPortfolio($request, $user);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Get my earning
     */

    public function getEarning(Request $request) {
        try {
            $data = $this->user->getEarning($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /*
     * Get my earning
     */

    public function explorUsers(Request $request) {
        try {
            $data = $this->user->explorUsers($request);
            if ($data) {
                return response()->json(['success' => true, 'data' => $data, 'message' => '']);
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Please try again.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

}
