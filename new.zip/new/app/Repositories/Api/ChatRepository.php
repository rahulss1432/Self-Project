<?php

namespace App\Repositories\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Message;
use JWTAuth;
use App\Models\Connection;

Class ChatRepository {

    public function __construct(Message $message, Connection $connection) {
        $this->message = $message;
        $this->connection = $connection;
    }

    /**
     * Save chat
     */
    public function saveMessage($request) {
       
        $connection = $this->connection->where(function ($query) use ($request) {
                    $query->where('from_id', '=', $request->from_id)
                            ->where('to_id', '=', $request->to_id);
                })->orWhere(function ($query) use ($request) {
                    $query->where('to_id', '=', $request->from_id)
                            ->where('from_id', '=', $request->to_id);
                })->first();
        if (!$connection) {
            $connection = new $this->connection();
            $connection->from_id = $request->from_id;
            $connection->to_id = $request->to_id;
            $connection->save();
        }
        $chat = new $this->message();
        $chat->from_id = $request->from_id;
        $chat->to_id = $request->to_id;
        $chat->message = $request->message;
        $chat->connection_id = $connection->id;
        if ($chat->save()) {
            return true;
        }return false;
    }

    /**
     * Get inbox
     */
    public function getInbox($request) {

        $user = JWTAuth::toUser($request->header('access_token'));
        $chat_inbox = $this->message->where('to_id', $user->id)
                ->orWhere('from_id', $user->id)
                ->join(DB::raw('(Select max(id) as id from messages where to_id =' . $user->id . ' or '.'from_id ='. $user->id . ' group by connection_id) LatestMessage'), function($join) {
                    $join->on('messages.id', '=', 'LatestMessage.id');
                })
                ->get();
        if (count($chat_inbox) > 0) {
            foreach ($chat_inbox as $chat) {
                $from_user = \App\User::where(['id' => $chat['from_id']])->first();
                $chat->from_user_image = checkUserImage($from_user->profile_image);
                $chat->from_user_first_name = $from_user['first_name'];
                $chat->from_user_last_name = $from_user['last_name'];
            }
        }
        return $chat_inbox;
    }

    /**
     * Get getChatList
     */
    public function getChatList($request) {

        $user = JWTAuth::toUser($request->header('access_token'));
        $from_id = $user->id;
        $to_id = $request->to_id;
        $chat_lists = $this->message->where(function ($query) use ($from_id, $to_id) {
                    $query->where('from_id', '=', $from_id)
                            ->where('to_id', '=', $to_id);
                })->orWhere(function ($query) use ($from_id, $to_id) {
                    $query->where('to_id', '=', $from_id)
                            ->where('from_id', '=', $to_id);
                })->get();
        if (count($chat_lists) > 0) {
            $affected = DB::table('messages')->where('to_id', '=', $user->id)->update(array('is_read' => 1));
            foreach ($chat_lists as $chat) {
                $from_user = \App\User::where(['id' => $chat['from_id']])->first();
                $chat->from_user_image = checkUserImage($from_user->profile_image);
                $chat->from_user_first_name = $from_user['first_name'];
                $chat->from_user_last_name = $from_user['last_name'];
                $to_user = \App\User::where(['id' => $chat['to_id']])->first();
                $chat->to_user_image = checkUserImage($to_user->profile_image);
                $chat->to_user_first_name = $to_user['first_name'];
                $chat->to_user_last_name = $to_user['last_name'];
            }
        }
        return $chat_lists;
    }

    /**
     * delete Chat
     */
    public function deleteChat($request) {

        $user = JWTAuth::toUser($request->header('access_token'));
        $from_id = $user->id;
        $to_id = $request->to_id;
        $chat_lists = $this->message->where(function ($query) use ($from_id, $to_id) {
                    $query->where('from_id', '=', $from_id)
                            ->where('to_id', '=', $to_id);
                })->orWhere(function ($query) use ($from_id, $to_id) {
                    $query->where('to_id', '=', $from_id)
                            ->where('from_id', '=', $to_id);
                })->delete();
        if ($chat_lists) {
            return true;
        }
        return false;
    }

    /**
     * Delete Appointment
     */
    public function deleteAppointment($request) {
        return $this->appointment->where('id', $request->id)->delete();
    }

}
