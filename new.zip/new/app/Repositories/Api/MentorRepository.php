<?php

namespace App\Repositories\Api;

use App\Models\Availability;
use JWTAuth;
use StaticMessage;
use App\Models\MentorCategory;

Class MentorRepository {

    public function __construct(Availability $Availability, MentorCategory $mentorCategory) {
        $this->availability = $Availability;
        $this->mentorCategory = $mentorCategory;
    }

    /**
     * add availability
     * @param type $request(OBJ)
     * @return type Json
     */
    public function addAvailability($request) {
        try {
            $user = JWTAuth::toUser($request->header('access_token'));
            $model = new $this->availability();
            $model->user_id = $user->id;
            $model->from_date_time = $request->from_date . ' ' . $request->from_time;
            $model->to_date_time = $request->to_date . ' ' . $request->to_time;
            $model->state_id = $request->state;
            $model->city = $request->city;
            $model->save();
            return response()->json(['success' => true, 'data' => $model, 'message' => \StaticMessage::$app['availibilty_add']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * edit availability
     * @param type $request(OBJ)
     * @return type Json
     */
    public function editAvailability($request) {
        try {
            $user = JWTAuth::toUser($request->header('access_token'));
            $model = $this->availability->find($request->id);
            $model->user_id = $user->id;
            $model->from_date_time = $request->from_date . ' ' . $request->from_time;
            $model->to_date_time = $request->to_date . ' ' . $request->to_time;
            $model->state_id = $request->state;
            $model->city = $request->city;
            $model->save();
            return response()->json(['success' => true, 'data' => $model, 'message' => 'Availabilty updated successfully']);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * get availability
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getAvailability($request) {


        try {
            $user = JWTAuth::toUser($request->header('access_token'));
            $model = $this->availability->where(['user_id' => $user->id])->get();
            return response()->json(['success' => true, 'data' => $model, 'message' => '']);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * delete availability
     * @param type $request(OBJ)
     * @return type Json
     */
    public function deleteAvailability($request) {


        try {
            $model = $this->availability->where(['id' => $request->id])->delete();
            if ($model) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Deleted successfully.']);
            }
            return response()->json(['success' => false, 'data' => [], 'message' => 'Availabilty not found']);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * add skill
     * @param type $request(OBJ)
     * @return type Json
     */
    public function addSkill($request) {
        $post = $request->all();
        $user = JWTAuth::toUser($request->header('access_token'));
        try {
            foreach ($post['skills'] as $skill) {
                $model = new $this->mentorCategory();
                $model->user_id = $user->id;
                $model->category_id = $skill['category_id'];
                $model->service_id = $skill['service_id'];
                $model->exp_year = $skill['exp_year'];
                $model->exp_month = $skill['exp_month'];
                $model->amount = $skill['amount'];
                $model->level_of_knowledge = $skill['level_of_knowledge'];
                $model->save();
            }
            return response()->json(['success' => true, 'data' => [], 'message' => 'Sakill Added successfully.']);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    public function getSkill($request) {
        $post = $request->all();
        $user = JWTAuth::toUser($request->header('access_token'));
        try {
            $services = $this->mentorCategory->where(['user_id' => $request->id])->get();
            foreach ($services as $service){
                $service->category_name = $service->category->category_name;
                $service->service_name = $service->service->name;
            }
            return response()->json(['success' => true, 'data' => $services, 'message' => '']);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

}
