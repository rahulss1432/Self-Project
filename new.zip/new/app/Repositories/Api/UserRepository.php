<?php

namespace App\Repositories\Api;

use App\User;
use JWTAuth;
use StaticMessage;
use App\Models\Auth;
use App\UserDevice;
use App\Models\Rating;
use App\Models\Category;
use App\Models\Service;
use App\Models\Appointment;
use File;

Class UserRepository {

    public function __construct(User $user, Rating $rating, Category $category, Service $service, Appointment $appointment) {
        $this->user = $user;
        $this->category = $category;
        $this->service = $service;
        $this->rating = $rating;
        $this->appointment = $appointment;
    }

    /**
     * Send otp on customer and photographer mobile number.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function sendOTP($request) {

        try {
            $user = $this->user->where('email', $request->email)->first();
            if (!empty($user)) {
                $otp = mt_rand(100000, 999999);
                $user->verification_code = $otp;
                if ($user->save()) {
                    $data['request'] = 'send_otp';
                    $data['username'] = $user->first_name;
                    $data['email'] = $user->email;
                    $data['otp'] = $otp;
                    $data['subject'] = 'Send otp';
                    $mail = sendMail($data);
                }
                return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['resent_code']]);
            }
            return response()->json(['success' => FALSE, 'data' => [], 'error' => ['message' => 'User not found.']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * Send otp on customer and photographer mobile number.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function forgotPassword($request) {

        try {
            $user = $this->user->where('email', $request->email)->first();
            if (!empty($user)) {
                $token = mt_rand(100000, 999999);
                $user->reset_token = $token;
                if ($user->save()) {
                    $data['request'] = 'reset_token';
                    $data['username'] = $user->first_name;
                    $data['email'] = $user->email;
                    $data['token'] = $token;
                    $data['subject'] = 'Reset token';
                    $mail = sendMail($data);
                }
                return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['resent_token']]);
            }
            return response()->json(['success' => FALSE, 'data' => [], 'error' => ['message' => \StaticMessage::$app['resent_email']]]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * Otp verify (mobile number and otp match)
     * @param type $request(OBJ)
     * @return type Json
     */
    public function OTPVerify($request) {
        try {
            $user = $this->user->where(['verification_code' => $request->code, 'email' => $request->email])->first();
            if (!empty($user)) {
                $user->verification_code = 0;
                if ($user->save()) {
                    $user->profile_image = checkUserImage($user->profile_image);
                    return response()->json(['success' => true, 'data' => $user, 'message' => \StaticMessage::$app['verify_code']]);
                }
            }
            return response()->json(['success' => FALSE, 'data' => [], 'error' => ['message' => \StaticMessage::$app['verify_code_invalid']]]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * Otp verify (mobile number and otp match)
     * @param type $request(OBJ)
     * @return type Json
     */
    public function resetPassword($request) {
        try {
            $user = $this->user->where('reset_token', $request->code)->first();
            if (!empty($user)) {
                $user->reset_token = 0;
                $user->password = bcrypt($request->password);
                if ($user->save())
                    return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['pass_reset']]);
            }
            return response()->json(['success' => FALSE, 'data' => [], 'error' => ['message' => \StaticMessage::$app['pass_reset_token_invalid']]]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * Use this function for get token for customer login
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getToken($user, $device) {
        try {
            //return $user;
            if (!$userToken = JWTAuth::fromUser($user)) {
                return response()->json(['error' => 'invalid_credentials'], 401);
            }

            $get_token = $this->user_devices->where('user_id', $user->id)->first();
            if (isset($get_token['access_token']) && $get_token['access_token'] != '') {
                $this->user_devices->where('user_id', $user->id)->delete();
                JWTAuth::invalidate($get_token['access_token']);
            }
            $this->user_devices->where('user_id', $user->id)->delete();
            $device['user_id'] = $user->id;
            $device['access_token'] = $userToken;
            $user_device = $this->user_devices->create($device); //Save data in user devices table.
            if (isset($user_device) && $user_device != '') {
                $unread_notification_count = Utility::getUnreadNotificationCount($user->id);
                return response()->json(['success' => true, 'error' => [], 'data' => ['access_token' => $userToken, 'is_user_registered' => $user['is_user_registered'], 'country_code' => $user->country_code, 'mobile' => $user->mobile, 'customer_id' => $user['customer_id'], 'unread_notification_count' => $unread_notification_count, 'user_id' => $user['id']]]);
            } else {
                return response()->json(['success' => false, 'error' => ['message' => 'Please check your enter data']], 422);
            }
            //return $user;
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /**
     * Get user data from database by token.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getUser($request) {

        try {
            $token = $request->header('access_token');
            $user = JWTAuth::toUser($request->header('access_token'));
            $user = User::where(['id' => $user->id])->first();
            $user->profile_image = checkUserImage($user->profile_image);
            $user['access_token'] = $request->header('access_token');
            $rating = getAverageRating($user->id);
            $user['average_rating'] = $rating['average'];
            $user['rating_count'] = $rating['count'];
            return response()->json(['success' => true, 'data' => $user, 'error' => []]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /**
     * update user profile.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function updateProfile($request) {
        try {

            $user = JWTAuth::toUser($request->header('access_token'));
            $usersPath = public_path() . '/uploads/users';
            if (!is_dir($usersPath)) {
                File::makeDirectory($usersPath, $mode = 0777, true, true);
            }

            if (isset($request['profile_image']) && $request['profile_image'] != '') {
                $filename = public_path() . '/uploads/' . $user->profile_image;
                $image = time() . '.' . $request['profile_image']->getClientOriginalExtension();
                $request['profile_image']->move($usersPath, $image);
            } else {
                $image = $user->profile_image;
            }
            $user = JWTAuth::toUser($request->header('access_token'));
            if (empty($request['phone_number'])) {
                $mobile_number = '';
            } else {
                $mobile_number = $request['phone_number'];
            }
            $update = $this->user->where('id', $user->id)->update(['first_name' => $request['first_name'], 'last_name' => $request['last_name'], 'profile_image' => $image, 'phone_number' => $mobile_number, 'address' => $request['address'], 'date_of_birth' => $request['date_of_birth'], 'address' => $request['address'], 'country_id' => $request['country'], 'state_id' => $request['state'], 'city' => $request['city'], 'bio' => $request['bio'], 'job_details' => $request['job_details']]);
            if ($update) {
                $update_user = JWTAuth::toUser($request->header('access_token'));
                $update_user->profile_image = checkUserImage($update_user->profile_image,'users');
                return response()->json(['success' => true, 'data' => $update_user, 'error' => []]);
            } else {
                return response()->json(['success' => false, 'error' => ['message' => 'Profile could not be updated']], 422);
            }
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * user signup.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function saveUser($request) {
        try {
            $otp = mt_rand(100000, 999999);
            $user = new $this->user;
            $user->verification_code = $otp;
            $user->role = $request->role;
            $user->first_name = $request->first_name;
            $user->last_name = $request->last_name;
            $user->email = $request->email;
            $user->password = bcrypt($request->password);
            if ($user->save()) {

                $data['request'] = 'send_otp';
                $data['username'] = $user->first_name;
                $data['email'] = $user->email;
                $data['otp'] = $otp;
                $data['subject'] = 'Send otp';
                $mail = sendMail($data);
            }
            return response()->json(['success' => true, 'data' => $user, 'message' => \StaticMessage::$app['signup']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * User logout
     * @param type $request(OBJ)
     * @return type Json
     */
    public function logout($request) {
        try {
            $token = \Request::header('access_token');
            $user = JWTAuth::toUser($request->header('access_token'));
            try {
                $this->user->where('id', $user->id)->update(['is_available' => '0']);
                JWTAuth::invalidate($token);
                $this->user_devices->where('access_token', $token)->delete();
            } catch (\Exception $e) {
                $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
                return $json;
            }

            return response()->json(['success' => true, 'error' => [], 'data' => ['message' => 'You are Logged out.']]);
        } catch (\Exception $e) {

            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /**
     * Get photographer 
     * @param type $id
     * @return boolean
     */
    public function getUserData($id) {

        $user = $this->user->where('id', $id)->first();
        if ($user) {
            return $user;
        } else {
            return false;
        }
    }

    public function checkVerification($request) {

        $data = [];
        $user = $this->user->where('email', $request->email)->first();
        if ($user) {
            if (empty($user->verification_code)) {
                $data['is_verified'] = true;
            } else {
                $data['is_verified'] = false;
            }
            return response()->json(['success' => true, 'data' => $data, 'message' => '']);
        }
        return response()->json(['success' => false, 'error' => ['message' => 'Email Not exist in my record.']]);
    }

    public static function saveSocialUser($post) {

        $user = Auth::where(['source_id' => $post['source_id']])->first();
        if (empty($user)) {
            $user = new User();
            $user->profile_image = $post['profile_image'];
            $user->user_type = $post['type'];
            $user->role = $post['role'];
            $user->email = $post['email'];
            $user->first_name = $post['first_name'];
            $user->last_name = $post['last_name'];
            if ($user->save()) {
                $auth = new Auth();
                $auth->user_id = $user->id;
                $auth->source_id = $post['source_id'];
                $auth->save();
                $token = JWTAuth::fromUser($user);
                if ($token) {
                    $post['access_token'] = $token;
                    $post['user_id'] = $user->id;
                    UserDevice::addUserDevice($post);
                    $user->access_token = $token;
                    $user->profile_image = $user->profile_image;
                }
                return response()->json(['success' => true, 'data' => $user, 'message' => '']);
            }
        } else {
            $user = User::where(['id' => $user->user_id])->first();
            $token = JWTAuth::fromUser($user);
            if ($token) {
                $post['access_token'] = $token;
                $post['user_id'] = $user->id;
                UserDevice::addUserDevice($post);
                $user['access_token'] = $token;
                $user['profile_image'] = $user->profile_image;
            }
            return response()->json(['success' => true, 'data' => $user, 'message' => '']);
        }
    }

    public static function saveDeviceDetail($post) {
        $devicemodel = UserDevice::where(['user_id' => $post['user_id'], 'device_id' => $post['device_id']])
                ->first();
        if (empty($devicemodel)) {
            $devicemodel = new UserDevice();
        }
        $devicemodel->user_id = $post['user_id'];
        $devicemodel->device_id = $post['device_id'];
        $devicemodel->device_type = $post['device_type'];
        $devicemodel->access_token = $post['access_token'];
        $devicemodel->device_token = $post['device_token'];
        $devicemodel->save();
    }

    /*
     * givRating
     */

    public function givRating($request) {
        $rating = new $this->rating();
        $rating->from_id = $request->from_id;
        $rating->to_id = $request->to_id;
        $rating->appointment_id = $request->appointment_id;
        $rating->reviews = $request->reviews;
        $rating->rating = $request->rating;
        if ($rating->save()) {
            return true;
        }return false;
    }

    /*
     * get service list
     */

    public function services($request) {
        $services = $this->service->where(['status' => 'active', 'category_id' => $request->catery_id])->get();
        return $services;
    }

    /*
     * get category list
     */

    public function categoryList($request) {
        $categorys = $this->category->where(['status' => 'active'])->get();
        foreach ($categorys as $category) {
            $category->category_icon = checkCategoryIcon($category->category_icon, 'category_icons');
        }
        return $categorys;
    }

    /*
     * get mentor earning
     */

    public function getEarning($request) {

        $earnings = \Illuminate\Support\Facades\DB::table('appointments')
                ->join('transactions as tn', 'tn.appointment_id', '=', 'appointments.id')
                ->select('tn.transaction_id as transaction_id', 'appointments.reference_id', 'appointments.status', 'appointments.status', 'tn.total_amount as amount', 'tn.total_amount as amount', 'appointments.created_at', 'appointments.from_id')
                ->paginate(10);
        foreach ($earnings as $earning) {
            $user = User::where(['id' => $earning->from_id])->first();
            $earning->from_user_first_name = $user['first_name'];
            $earning->from_user_last_name = $user['last_name'];
        }
        $custom = collect(['total_amount' => 9798]);
        $data = $custom->merge($earnings);
        return $data;
    }

    /*
     * get mentor earning
     */

    public function explorUsers($request) {

        $users = $this->user->select('first_name', 'last_name', 'profile_image', 'address')->where(['role' => 'user'])->paginate(10);
        if (count($users) > 0) {
            foreach ($users as $user) {
                $user->profile_image = checkUserImage($user->profile_image, 'users');
                $user->average_rating = getAverageRating($user->id)['average'];
            }
        }
        return $users;
    }

}
