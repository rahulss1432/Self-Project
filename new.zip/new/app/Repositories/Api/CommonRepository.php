<?php

namespace App\Repositories\Api;

use App\Models\Country;
use App\Models\State;
use JWTAuth;
use StaticMessage;
use App\Models\Rating;

Class CommonRepository {

    public function __construct(Country $country, State $state, Rating $rating) {
        $this->country = $country;
        $this->state = $state;
        $this->rating = $rating;
    }

    /**
     * get country list
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getCountry($request) {

        try {
            return $this->country->get();
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * get state list.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getState($request) {

        try {
            return $this->state->where(['country_id' => $request->country_id])->get();
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * get rating list.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getRatingReiew($request) {

        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        $ratings = $this->rating->where('to_id', $user->id)->get();
        if (count($ratings) > 0) {
            foreach ($ratings as $rating) {
                $rating->from_user_first_name = $rating->fromUser->first_name;
                $rating->from_user_last_name = $rating->fromUser->last_name;
                $rating->from_user_profile = checkUserImage($rating->fromUser->profile_image);
                $appoitment = \App\Models\Appointment::where(['id' => $rating->appointment_id])->first();
                $rating->appointment_reference_id = $appoitment['reference_id'];
                
            }
        }
        return $ratings;
    }

}
