<?php

namespace App\Repositories\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Offer;

Class OfferRepository {

    public function __construct(Offer $offer) {
        $this->offer = $offer;
    }

    /**
     * Save Offer
     */
    public function saveOffer($request, $user) {
		$data = $request->all();
		$data['from_id'] = $user->id;
		return $this->offer->create($data);
    }
	
	 /**
     * Save Offer
     */
    public function getOffer($request, $user) {
		return $this->offer->whereRaw("( from_id = $user->id OR to_id = $user->id )")->get();
    }

}
