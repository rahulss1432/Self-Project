<?php

namespace App\Repositories\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Appointment;

Class AppointmentRepository {

    public function __construct(Appointment $appointment) {
        $this->appointment = $appointment;
    }

    /**
     * Save Appointment
     */
    public function saveAppointment($request, $user) {
		$data = $request->all();
		$data['reference_id'] = substr( rand() * 900000 + 100000, 0, 6 );
		$data['from_id'] = $user->id;
		return $this->appointment->create($data);
    }
	
	/**
     * Get Appointment
     */
    public function getAppointment($request, $user) {
		$date = date('Y-m-d');
		if($request->type == 'on_going'){
			return $this->appointment->where('date', $date)->whereRaw("( from_id = $user->id OR to_id = $user->id )")->get();
		}elseif($request->type == 'upcomming'){
			return $this->appointment->where('date', '>', $date)->whereRaw("( from_id = $user->id OR to_id = $user->id )")->get();
		}else{
			return $this->appointment->where('date', '<',  $date)->whereRaw("( from_id = $user->id OR to_id = $user->id )")->get();
		}
    }
	
	/**
     * Update Appointment
     */
    public function updateAppointment($request, $user) {
		$this->appointment->where('id', $request->id)->update($request->all());
		return $this->appointment->find($request->id);
    }
	
	/**
     * Delete Appointment
     */
    public function deleteAppointment($request) {
		return $this->appointment->where('id', $request->id)->delete();
    }
	
}
