<?php

namespace App\Repositories\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Portfolio;
use File;

Class PortfolioRepository {

    public function __construct(Portfolio $portfolio) {
        $this->portfolio = $portfolio;
    }

    /**
     * Save Portfolio
     */
    public function savePortfolio($request, $user) {
		if ($request->hasFile('link')) {
			$fileName = "";
			$data = $request->all();
			$data['user_id'] = $user->id;
			
			// Create folder if not exist
			$portfolioPath = public_path() . '/uploads/portfolio';
			if (!is_dir($portfolioPath)) {
				File::makeDirectory($portfolioPath, $mode = 0777, true, true);
			}
			
			// Upload file into folder
			$file = $request->file('link');
			$fileName = $file->getClientOriginalName();
			$fileExtension = strtolower($file->getClientOriginalExtension());
			$imageExist = public_path() . '/uploads/portfolio/' . $fileName;
			$request->file('link')->move('public/uploads/portfolio', $fileName);
			$data['link'] = $fileName;
			
			// Save file
			return $this->portfolio->create($data);
		}
    }
	
	/**
     * Get Portfolio
     */
    public function getPortfolio($request, $user) {
		$data = $this->portfolio->where('user_id', $user->id)->get();
		foreach( $data as $item ){
			$item['link'] = url( 'public/uploads/portfolio/' . $item->link );
		}
		return $data;
    }

}
