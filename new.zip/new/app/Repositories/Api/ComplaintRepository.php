<?php

namespace App\Repositories\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Complaint;

Class ComplaintRepository {

    public function __construct(Complaint $complaint) {
        $this->complaint = $complaint;
    }

    /**
     * Save complaint
     */
    public function saveComplaints($request, $user) {
		$data['from_id'] = $user->id;
		$data['to_id'] = $request->user_id;
		$data['comments'] = $request->comments;
		return $this->complaint->create($data);
    }

}
