<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Category;
use App\Models\Service;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;
use File;

Class CategoryRepository {

    /**
     * Class Construct.
     * @param $category
     */
    public function __construct(Category $category, Service $service) {
        $this->category = $category;
        $this->service = $service;
    }

    /**
     * Manage User.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function getAllCategories($post) {
        try {
            $categoryList = $this->category->orderBy('id', 'desc');
            /* Filter By Name */
            if (isset($post['name']) && !empty($post['name'])) {
                $categoryList->where('category_name', 'like', '%' . $post['name'] . '%');
            }
            /* Filter active inactive */
            if (isset($post['status']) && !empty($post['status'])) {
                $categoryList->where('status', $post['status']);
            }
            $rows = $categoryList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /*
     * change  category's status
     */

    public function changeCategoryStatus($request) {
        try {
            $post = $request->all();
            $status = $this->category->find($post['id']);
            if (empty($status)) {
                return redirect()->back();
            }
            $status->status = $post['status'];
            $status->save();
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * get service by category id
     */

    public function getServiceById($post) {
        try {
            $serviceList = $this->service->where('category_id', $post['category_id']);
            /* Filter By Name */
            if (isset($post['name']) && !empty($post['name'])) {
                $serviceList->where('name', 'like', '%' . $post['name'] . '%');
            }
            /* Filter active inactive */
            if (isset($post['status']) && !empty($post['status'])) {
                $serviceList->where('status', $post['status']);
            }
            $rows = $serviceList->orderBy('id', 'desc')->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * change  service's status
     */

    public function changeServiceStatus($request) {
        try {
            $post = $request->all();
            $status = $this->service->find($post['id']);
            if (empty($status)) {
                return redirect()->back();
            }
            $status->status = $post['status'];
            $status->save();
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * add category method 
     */

    public function addCategory($post) {
        try {
            $fileName = "";
            $categoryIconPath = public_path() . '/uploads/category_icons';
            if (!is_dir($categoryIconPath)) {
                File::makeDirectory($categoryIconPath, $mode = 0777, true, true);
            }
            if ($post->hasFile('category_icon')) {
                $file = $post->file('category_icon');
                $fileName = $file->getClientOriginalName();
                $fileExtension = strtolower($file->getClientOriginalExtension());
                $imageExist = public_path() . '/uploads/category_icons/' . $fileName;
                $post->file('category_icon')->move('public/uploads/category_icons', $fileName);
            }
            $model = $this->category;
            $model->category_name = $post['category_name'];
            $model->category_icon = $fileName;
            $model->save();
            return response()->json(['success' => true, 'message' => 'Category added successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * add subcategory method 
     */

    public function addService($post) {
        try {
            $model = $this->service;
            $model->category_id = $post['category_id'];
            $model->name = $post['service_name'];
            $model->save();
            return response()->json(['success' => true, 'message' => 'Service added successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
