<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Complaint;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class ComplaintRepository {

    /**
     * Class Construct.
     * @param $complaint
     */
    public function __construct(Complaint $complaint) {
        $this->complaint = $complaint;
    }

    /**
     * Manage Complaint.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function getAllComplaints($post) {
        try {
            $complaintList = $this->complaint->orderBy('id', 'desc');
            $rows = $complaintList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /*
     * View complaint comments.
     */

    public function getComplaintsView($id) {
        try {
            return $this->complaint->where(['id' => $id])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
