<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Transaction;
use App\Models\Setting;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class PaymentRepository {

    /**
     * Class Construct.
     */
    public function __construct(Transaction $transaction, Setting $setting) {
        $this->transaction = $transaction;
        $this->setting = $setting;
    }

    /**
     * get payment list data.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function getAllPayments($post) {
        try {
            $paymentList = $this->transaction->orderBy('id', 'desc');
            /* Filter from date to date */
            if (!empty($post['from_date']) && !empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $to = date('Y-m-d', strtotime($post['to_date']));
                $paymentList->whereDate('created_at', '>=', $from)
                        ->whereDate('created_at', '<=', $to);
            }
            if (!empty($post['from_date']) && empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $paymentList->whereDate('created_at', $from);
            }
            if (!empty($post['to_date']) && empty($post['from_date'])) {
                $to = date('Y-m-d', strtotime($post['to_date']));
                $paymentList->whereDate('created_at', $to);
            }
            /* Filter By Booking Id */
            if (isset($post['booking_id']) && !empty($post['booking_id'])) {
                $searchData = $post['booking_id'];
                $paymentList->whereHas('transactionBooking', function ($query) use ($searchData) {
                    $query->where('reference_id', 'like', '%' . $searchData . '%');
                });
            }
            /* Filter By Mentors */
            if (isset($post['mentor_name']) && !empty($post['mentor_name'])) {
                $paymentList->where('mentor_id', $post['mentor_name']);
            }
            /* Filter By Users */
            if (isset($post['user_name']) && !empty($post['user_name'])) {
                $paymentList->where('user_id', $post['user_name']);
            }
            $rows = $paymentList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /*
     * commission update method 
     */

    public function editCmmission($post) {
        try {
            $model = $this->setting->where('key', 'commision_percent')->first();
            $model->value = $post['commission'];
            $model->save();
            return response()->json(['success' => true, 'message' => 'Commission updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
