<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Notification;
use Auth;

Class AdminRepository {

    public function __construct(Notification $notification) {
        $this->notification = $notification;
    }

    /**
     * Get forget password page.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function forgotPassword() {
        try {
            return view('admin::forget-password.forgot-password');
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Get forget password page.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function resetPassword($token) {
        try {
            return view('admin::forget-password.password_reset', ['token' => $token]);
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Admin notification list on modal.
     * @return type
     */
    public function getNotificationList() {
        $userId = Auth::guard('admin')->user()->id;
        $notificationList = $this->notification->where(['to_id' => $userId])->take(5)->orderBy('id', 'desc')->get();
        return $notificationList;
    }

    /**
     * Admin notification list on view.
     * @return type
     */
    public function getAllNotificationList() {
        $userId = Auth::guard('admin')->user()->id;
        $notificationList = $this->notification->where(['to_id' => $userId])->orderBy('id', 'desc')->paginate(10);
        return $notificationList;
    }

}
