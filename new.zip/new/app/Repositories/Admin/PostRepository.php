<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Post;
use App\Models\Rating;
use App\Models\PostImage;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class PostRepository {

    /**
     * Class Construct.
     * @param $post
     */
    public function __construct(Post $post, Rating $rating, PostImage $postImage) {
        $this->post = $post;
        $this->rating = $rating;
        $this->postImage = $postImage;
    }

    /**
     * Manage Review.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function getAllReviews($post) {
        try {
            $reviewList = $this->rating->orderBy('id', 'desc');
//            /* Filter from date to date */
            if (!empty($post['from_date']) && !empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $to = date('Y-m-d', strtotime($post['to_date']));
                $reviewList->whereDate('created_at', '>=', $from)
                        ->whereDate('created_at', '<=', $to);
            }
            if (!empty($post['from_date']) && empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $reviewList->whereDate('created_at', $from);
            }
            if (!empty($post['to_date']) && empty($post['from_date'])) {
                $to = date('Y-m-d', strtotime($post['to_date']));
                $reviewList->whereDate('created_at', $to);
            }
            $rows = $reviewList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Manage Post.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function getAllPosts($post) {
        try {
            $postList = $this->post->orderBy('id', 'desc');
            if (!empty($post['from_date']) && !empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $to = date('Y-m-d', strtotime($post['to_date']));
                $postList->whereDate('created_at', '>=', $from)
                        ->whereDate('created_at', '<=', $to);
            }
            if (!empty($post['from_date']) && empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $postList->whereDate('created_at', $from);
            }
            if (!empty($post['to_date']) && empty($post['from_date'])) {
                $to = date('Y-m-d', strtotime($post['to_date']));
                $postList->whereDate('created_at', $to);
            }
            $rows = $postList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /*
     * View post and review comments.
     */

    public function getPostCommentView($id, $type) {
        try {
            if ($type == "comment") {
                return $this->post->where(['id' => $id])->first();
            } else {
                return $this->rating->where(['id' => $id])->first();
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * View post images.
     */

    public function getPostImageView($id) {
        try {
            return $this->postImage->where(['post_id' => $id])->get();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
