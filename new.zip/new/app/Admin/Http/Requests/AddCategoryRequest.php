<?php

namespace App\Admin\Http\Requests;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddCategoryRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'category_name' => 'required|remove_spaces|max:150',
            'category_icon' => 'mimes:jpeg,jpg,png,gif|required|max:10000',
        ];
    }

    public function messages() {
        return [
            'category_name.required' => 'The category field is required.',
            'category_name.remove_spaces' => 'The category name does not contain spaces.',
        ];
    }

}
