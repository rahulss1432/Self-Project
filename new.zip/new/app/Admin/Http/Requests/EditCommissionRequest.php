<?php

namespace App\Admin\Http\Requests;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class EditCommissionRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'commission' => 'required|numeric',
        ];
    }

    public function messages() {
        return [
//            'commission.remove_spaces' => 'The commission does not contain spaces.',
        ];
    }

}
