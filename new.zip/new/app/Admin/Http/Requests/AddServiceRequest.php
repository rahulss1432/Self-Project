<?php

namespace App\Admin\Http\Requests;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddServiceRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'service_name' => 'required|remove_spaces|max:150',
        ];
    }

    public function messages() {
        return [
            'service_name.required' => 'The service field is required.',
            'service_name.remove_spaces' => 'The service does not contain spaces.',
        ];
    }

}
