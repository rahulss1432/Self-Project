<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\UserRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\ChangePasswordRequest;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller {

    public function __construct(UserRepository $user) {
        $this->user = $user;
    }

    /**
     * Display a listing of the users.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin::user.manage-user');
    }

    /**
     * Display a listing of the users.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllUsers(Request $request) {
        $users = $this->user->getAllUsers($request);
        $html = View::make('admin::ajax-content.user._load-user-list', ['users' => $users])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Change user status
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function changeUserStatus(Request $request) {
        return $this->user->changeUserStatus($request);
    }

    /* load user profile */

    public function loadUserProfile(Request $request) {
        $user = $this->user->loadUserProfile($request);
        $html = View::make('admin::ajax-content.user._load-user-profile', ['user' => $user])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display change password
     * @return \Illuminate\Http\Response
     */
    public function changePassword() {
        $userId = Auth::guard('admin')->user()->id;
        return View('admin::change-password', ['id' => $userId]);
    }

    /**
     * Update user password
     *
     * @return \Illuminate\Http\Response
     */
    public function updatePassword(ChangePasswordRequest $request) {
        return $this->user->updatePassword($request);
    }
    
    /** 04-march-2019
     * function using for delet mentee user
     * @param type $id
     */
    public function removeUser($id) {
        return $this->user->removeUser($id);
    }

}
