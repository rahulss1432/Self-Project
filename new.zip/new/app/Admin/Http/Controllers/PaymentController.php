<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\PaymentRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\EditCommissionRequest;

class PaymentController extends Controller {

    public function __construct(PaymentRepository $payment) {
        $this->payment = $payment;
    }

    /**
     * Display a listing of the payments.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin::payment-report.manage-payment-report');
    }

    /**
     * Display a listing of the payments.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllPayments(Request $request) {
        $payments = $this->payment->getAllPayments($request);
        $html = View::make('admin::ajax-content.payment-report._manage-payment-report-list', ['payments' => $payments])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display a listing of the commission.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function commission() {
        return view('admin::commission.manage-commission');
    }
    
    /**
     * edit commission.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function editCmmission(EditCommissionRequest $request) {
       return $this->payment->editCmmission($request);
    }

}
