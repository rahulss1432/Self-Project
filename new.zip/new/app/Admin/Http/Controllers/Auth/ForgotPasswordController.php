<?php

namespace App\Admin\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use App\Admin\Http\Requests\ForgotPasswordValidation;
use App\Repositories\Admin\UserRepository;
use App\Admin\Http\Requests\ResetPasswordValidation;
use App\Clinic;
use App\Caregiver;
use App\Patient;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

   
    
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(UserRepository $user)
    {
    //    $this->middleware('guest');
         $this->user = $user;
    }
    
    
        public function sendResetLinkEmail(ForgotPasswordValidation $request) {

        $this->validateEmail($request);
        if ($request->has('email')) {
            
            
            $checkEmail = $this->user->findEmail($request->email, 'admin');        
            
            if ($checkEmail) {
                $saveToken = $this->user->saveToken($request->email);
                $checkEmail['link'] = url('admin/password/reset/' . $saveToken);
                $checkEmail['email'] = $request->email;
                $checkEmail['name'] = $checkEmail['name'];
                $checkEmail['subject'] = 'Forgot Password';

                if (sendMail($checkEmail)) {

                    return redirect()->back()->with('success_msg', 'Please check your mail for reset your password.');
                } else {
                    return redirect()->back()->with('error_msg', 'Mail not sent, Please try again.');
                }
            }
            else{                
                   return redirect()->back()->with('error_msg', 'Email does not exist.');
                   
                   
            }
        }
    }
     /**
     * 
     * @param Request $request
     * @return type
     */
    public function reset(ResetPasswordValidation $request) {
      
        //return $request->all();
        $checkToke = $this->user->checkToken($request->token);
        if ($checkToke) {
            $changePassword = $this->user->updatePassword($request->all());
            if ($changePassword) {
                if($request->set_password){
                    
                  return redirect('institute/login')->with('success_msg', 'Password Updated Successfully. Please Login.');   
                }
                else{
                    
                   return redirect('admin/login')->with('success_msg', 'Password Updated Successfully Please Login.');   
             
                }
            } else {
                return redirect()->back()->with('error_msg', 'Error in reset password.');
            }
        } else {
            return redirect()->back()->with('error_msg', 'Your sesion has been expired.');
        }
    }

    /**
     * Set password view page
     * @param type $token
     * @return type
     */
    public function setPassword($token){
        
          $users = $this->user->checkToken($token);
        if ($users) {
             return view('admin::set-password', compact('users'));
            
         } else {
            return redirect('institute/login')->with('error_msg', 'Invalid token');
        }
    }
    /**
     * Validate the email for the given request.
     *
     * @param \Illuminate\Http\Request  $request
     * @return void
     */
    protected function validateEmail(Request $request) {
        $this->validate($request, ['email' => 'required|email']);
    }

    
}

