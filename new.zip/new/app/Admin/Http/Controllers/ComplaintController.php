<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\ComplaintRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\AddFaqRequest;

class ComplaintController extends Controller {

    public function __construct(ComplaintRepository $complaint) {
        $this->complaint = $complaint;
    }

    /**
     * Display a complaint page.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin::complaint.manage-complaint');
    }

    /**
     * Display a listing of the complaint.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllComplaints(Request $request) {
        $complaints = $this->complaint->getAllComplaints($request);
        $html = View::make('admin::ajax-content.complaint._load-complaint-list', ['complaints' => $complaints])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display a view of the complaint.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getComplaintsView($id) {
        $complaints = $this->complaint->getComplaintsView($id);
        $data = $complaints->comments;
        return Response::json(['success' => true, 'complaints' => $data]);
    }

}
