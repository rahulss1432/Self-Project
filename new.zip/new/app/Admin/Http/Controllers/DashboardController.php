<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\DashboardRepository;

class DashboardController extends Controller
{
    public function __construct(DashboardRepository $dashboard)
    {
        $this->dashboard = $dashboard;
    }
    /**
     * Display a listing of the resource.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return $this->dashboard->index();
    }
}
