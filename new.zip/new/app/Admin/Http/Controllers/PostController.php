<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\PostRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class PostController extends Controller {

    public function __construct(PostRepository $post) {
        $this->post = $post;
    }

    /**
     * Display a listing of the review and post.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin::review-post.reviews-and-posts');
    }

    /**
     * Display a listing of the reviews.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllReviews(Request $request) {
        $reviews = $this->post->getAllReviews($request);
        $html = View::make('admin::ajax-content.review-post._reviews-list', ['reviews' => $reviews])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display a listing of the posts.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllPosts(Request $request) {
        $posts = $this->post->getAllPosts($request);
        $html = View::make('admin::ajax-content.review-post._post-list', ['posts' => $posts])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display a view of the post and review comment.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getPostCommentView($id, $type) {
        $postComment = $this->post->getPostCommentView($id, $type);
        $data = "";
        if ($type == "comment") {
            $data = $postComment->comment;
        } else {
            $data = $postComment->reviews;
        }
        return Response::json(['success' => true, 'postComment' => $data]);
    }

    /**
     * Display a view of the post image.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getPostImageView($id) {
        $postImages = $this->post->getPostImageView($id);
        $html = View::make('admin::ajax-content.review-post._load_post-image', ['postImages' => $postImages])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

}
