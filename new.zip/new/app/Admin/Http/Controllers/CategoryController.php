<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\CategoryRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\AddCategoryRequest;
use App\Admin\Http\Requests\AddServiceRequest;

class CategoryController extends Controller {

    public function __construct(CategoryRepository $category) {
        $this->category = $category;
    }

    /**
     * Display a listing of the categories.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin::category.manage-category');
    }

    /**
     * Display a listing of the categories.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllCategories(Request $request) {
        $categories = $this->category->getAllCategories($request);
        $html = View::make('admin::ajax-content.category._load-category-list', ['categories' => $categories])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Change categories status
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function changeCategoryStatus(Request $request) {
        return $this->category->changeCategoryStatus($request);
    }

    /* get all service by category id */

    public function getServiceById($id) {
        $categoryId = base64_decode($id);
        return view('admin::category.manage-service', ['categoryId' => $categoryId]);
    }

    /**
     * Display a listing of the service.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllService(Request $request) {
        $services = $this->category->getServiceById($request);
        $html = View::make('admin::ajax-content.category._load-service', ['services' => $services])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Change service status
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function changeServiceStatus(Request $request) {
        return $this->category->changeServiceStatus($request);
    }

    /*
     * add category method
     */

    public function addCategory(AddCategoryRequest $request) {
        return $this->category->addCategory($request);
    }

    /*
     * add service method
     */

    public function addService(AddServiceRequest $request) {
        return $this->category->addService($request);
    }

}
