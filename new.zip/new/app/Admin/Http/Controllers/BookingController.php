<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\BookingRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class BookingController extends Controller {

    public function __construct(BookingRepository $booking) {
        $this->booking = $booking;
    }

    /**
     * Display a listing of the booking.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin::booking.manage-booking');
    }

    /**
     * Display a listing of the booking.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllBookings(Request $request) {
        $bookings = $this->booking->getAllBookings($request);
        $html = View::make('admin::ajax-content.booking._load-booking-list', ['bookings' => $bookings])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /*
     * get booking invoice
     */

    public function getInvoice($id) {
        $invoice = $this->booking->getInvoice(base64_decode($id));
        return view('admin::booking.invoice', ['invoice' => $invoice]);
    }

}
