<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\AdminRepository;
use DB;
use Session;
use App\User;
use Illuminate\Support\Facades\Auth;
use App\Admin\Http\Requests\ResetPasswordRequest;
use App\Admin\Http\Requests\ForgotPasswordRequest;

class AdminController extends Controller {

    public function __construct(AdminRepository $admin) {
        $this->adminRepository = $admin;
    }

    public function forgotPassword() {
        return $this->adminRepository->forgotPassword();
    }

    public function sendForgotEmail(ForgotPasswordRequest $request) {
        return User::forgotEmail($request->all(), 'admin');
    }

    public function resetPassword($token) {
        return $this->adminRepository->resetPassword($token);
    }

    public function Reset(ResetPasswordRequest $request) {
        return User::ResetPassword($request->all());
    }

}
