<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\CmsRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Admin\Http\Requests\EditCmsRequest;
use App\Admin\Http\Requests\AddFaqRequest;

class CmsController extends Controller {

    public function __construct(CmsRepository $cms) {
        $this->cms = $cms;
    }

    /**
     * Display a faq page.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function showFaq() {
        return view('admin::cms.faq');
    }

    /**
     * Display a listing of the faqs.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllFaqs(Request $request) {
        $faqs = $this->cms->getAllFaqs($request);
        $html = View::make('admin::ajax-content.cms._faq-list', ['faqs' => $faqs])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display a add faq page.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function showAddFaqs() {
        return view('admin::cms.add-faq');
    }

    /**
     * Display a add faqs.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function addFaqs(AddFaqRequest $request) {
        return $this->cms->addFaqs($request);
    }

    /*
     * Delete Faqs.
     */

    public function deleteFaqs($id) {
        return $this->cms->deleteFaqs($id);
    }

    /*
     * Show Edit Faqs.
     */

    public function showEditFaqs($id) {
        $editFaqs = $this->cms->showEditFaqs(base64_decode($id));
        return view('admin::cms.edit-faq', ['editFaqs' => $editFaqs]);
    }

    /**
     * Display a edit faqs.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function editFaqs(AddFaqRequest $request) {
        return $this->cms->addFaqs($request);
    }

    /**
     * Display a cms page.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function showCms() {
        return view('admin::cms.cms');
    }

    /**
     * Display a listing of the cms.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllCms(Request $request) {
        $cms = $this->cms->getAllCms($request);
        $html = View::make('admin::ajax-content.cms._cms-list', ['cms' => $cms])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /*
     * Show Add Cms.
     */

    public function showAddCms() {
        return view('admin::cms.add-cms');
    }
    
    /**
     * Display a add cms.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function addCms(EditCmsRequest $request) {
        return $this->cms->editCms($request);
    }

    /*
     * Show Edit Cms.
     */

    public function showEditCms($id) {
        $editCms = $this->cms->showEditCms(base64_decode($id));
        return view('admin::cms.edit-cms', ['editCms' => $editCms]);
    }

    /**
     * Display a edit cms.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function editCms(EditCmsRequest $request) {
        return $this->cms->editCms($request);
    }

}
