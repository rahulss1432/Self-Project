<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\MessageRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class MessageController extends Controller {

    public function __construct(MessageRepository $message) {
        $this->message = $message;
    }

    /**
     * Display a listing of the Connections.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin::message.all-chats');
    }

    /**
     * Display a listing of the Connections.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllConnections(Request $request) {
        $connections = $this->message->getAllConnections($request);
        $html = View::make('admin::ajax-content.message._chat-list', ['connections' => $connections])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Change message status
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function changeConnectionStatus(Request $request) {
        return $this->message->changeConnectionStatus($request);
    }

    /*
     * Delete Messages.
     */

    public function deleteConnection($id) {
        return $this->message->deleteConnection($id);
    }

    /**
     * Display a listing of the flagged terms.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllFlaggedTerms(Request $request) {
        $html = View::make('admin::ajax-content.message._flagged-terms')->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display a user messages.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function userMessages($id, $fromId) {
        $messages = $this->message->getAllMessages(base64_decode($id));
        return view('admin::message.messages', ['messages' => $messages, 'fromId' => base64_decode($fromId)]);
    }

}
