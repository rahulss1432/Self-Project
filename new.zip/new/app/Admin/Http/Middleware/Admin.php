<?php

namespace App\Admin\Http\Middleware;

use Illuminate\Support\Facades\Auth;
use Closure;

class Admin {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = 'admin') {
        if (!Auth::guard('admin')->check()) {
            return redirect('/admin');
        }
        $userId = Auth::guard('admin')->user()->id;
        $userData = \App\User::where(['id' => $userId])->first();
        if (!empty($userData)) {
            $response = $next($request);
            return $response->header('Cache-Control', 'nocache, no-store, max-age=0, must-revalidate')
                            ->header('Pragma', 'no-cache');
        } else {
            return redirect('/admin');
        }
    }

}
