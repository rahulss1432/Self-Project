@extends('admin::include.app')
@section('title', 'Dashboard')
@section('content')
<main class="main-content dashboard-page" id="mainContent">
    <div class="page-content">
        <div class="container-fluid">
            <section class="admin-fun-fact">
                <div class="row box-row">
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="{{url('admin/manage-payment')}}" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">2019 Earned Total</h2>
                                <p class="mb-0">
                                    @if(getDetailBytype('total_earned') <= 9)
                                    0{{getDetailBytype('total_earned')}}
                                    @else
                                    {{getDetailBytype('total_earned')}}
                                    @endif
                                </p>
                            </div>
                            <div class="icon bg-pink">
                                <i class="ti-money"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="{{url('admin/manage-contractor')}}" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Mentors</h2>
                                <p class="mb-0">
                                    @if(getDetailBytype('mentor') <= 9)
                                    0{{getDetailBytype('mentor')}}
                                    @else
                                    {{getDetailBytype('mentor')}}
                                    @endif
                                </p>
                            </div>
                            <div class="icon bg-yello">
                                <i class="ti-layers-alt"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="{{url('admin/manage-user')}}" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Mentees</h2>
                                <p class="mb-0">
                                    @if(getDetailBytype('user') <= 9)
                                    0{{getDetailBytype('user')}}
                                    @else
                                    {{getDetailBytype('user')}}
                                    @endif
                                </p>
                            </div>
                            <div class="icon bg-green">
                                <i class="ti-user"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="javascript:void(0);" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Impressions</h2>
                                <p class="mb-0">
                                    @php
                                    $totalImpression = getDetailBytype('user') + getDetailBytype('mentor');
                                    @endphp
                                    @if($totalImpression <= 9)
                                    0{{$totalImpression}}
                                    @else
                                    {{$totalImpression}}
                                    @endif
                                </p>
                            </div>
                            <div class="icon bg-green-light">
                                <i class="ti-gallery"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="{{url('admin/manage-category')}}" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Categories</h2>
                                <p class="mb-0">
                                    @if(getDetailBytype('category') <= 9)
                                    0{{getDetailBytype('category')}}
                                    @else
                                    {{getDetailBytype('category')}}
                                    @endif
                                </p>
                            </div>
                            <div class="icon bg-red-light">
                                <i class="ti-view-list-alt"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="javascript:void(0);" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Flagged</h2>
                                <p class="mb-0">200</p>
                            </div>
                            <div class="icon bg-blue">
                                <i class="ti-pencil-alt"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxx -->
                    <!-- xxxxxxx -->
                </div>
                <!-- xxxxx -->
            </section>
        </div>
    </div>
</main>
@endsection