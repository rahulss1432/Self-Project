@extends('admin::include.app')
@section('title', 'Message')
@section('content')
<main class="main-content messages-page" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Message List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Back" >
                        <a href="{{url('admin/manage-chat')}}" class="nav-link"><i class="ti-arrow-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body message-body">
                <div class="row">
                    <!-- right section start -->
                    <div class="right_section col">
                        <ul class="mCustomScrollbar list-unstyled chat_sec" data-mcs-theme="minimal-dark">
                            @if(count($messages)>0)
                            @foreach($messages as $message)
                            @if($message->from_id == $fromId)
                            <li class="left">
                                <div class="img_wrap">
                                    <img src="{{checkUserImage($message->profile_image, '') }}" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                                <div class="chat_box">
                                    <p>{!! $message->message !!}</p>
                                    <span class="time">{{chatTimeShow($message->created_at)}}</span>
                                </div>
                            </li>
                            @else
                            <li class="right">
                                <div class="chat_box">
                                    <p>{!! $message->message !!}</p>
                                    <span class="time">{{chatTimeShow($message->created_at)}}</span>
                                </div>
                                <div class="img_wrap">
                                    <img src="{{checkUserImage($message->profile_image, '') }}" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                            </li>
                            @endif
                            @endforeach
                            @else 
                            <div class="alert alert-danger text-center">No record found.</div>
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    $(document).ready(function () {
        $("#leftSection ul li a").click(function () {
            $("#leftSection ul li a").removeClass("active");
            $(this).addClass("active");
        });
    });
</script>
@endsection