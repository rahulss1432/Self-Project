@if(count($bookings) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th class="w250">Address</th>
            <th>Job Date and Time</th>
            <th>Status</th>
            <th>Service Type</th>
            <th>Mentor Name</th>
            <th>User Name</th>
            <th>Amount</th>
            <th class="w120 text-center">Invoice</th>
        </tr>
    </thead>
    <tbody>
        @foreach($bookings as $booking)
        <tr>
            <td>#{{$booking->reference_id}}</td>
            <td>{{$booking->meeting_address}}</td>
            <td>{{dateTimeFormat($booking->created_at)}}</td>
            <td>
                @php
                $status = "";
                $statusType = "";
                if($booking->status == "active"){
                $status = 'Completed';
                $statusType = 'success';
                }elseif($booking->status == "pending"){
                $status = 'Pending';
                $statusType = 'warning';
                }else{
                $status = 'Cancelled';
                $statusType = 'danger';
                }
                @endphp
                <span class="text-{{$statusType}}">{{$status}}</span>
            </td>
            <td>{{$booking->bookingService->name}}</td>
            <td>{{$booking->bookingToUser->first_name.' '.$booking->bookingToUser->last_name}}</td>
            <td>{{$booking->bookingFromUser->first_name.' '.$booking->bookingFromUser->last_name}}</td>
            <td>{{!empty($booking->bookingAmount->total_amount)? '$ '.$booking->bookingAmount->total_amount:'-'}}</td>
            <td class="text-center"><a href="{{url('admin/invoice/'.base64_encode($booking->id))}}" target="_blank" class="btn-blue ripple-effect">View Invoice</a></td>
        </tr>
        @endforeach
    </tbody>
</table>

@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $bookings->links() }}
<script>
    $(".pagination li a").on('click', function (e) {
        pageDivLoader('show', 'getBookingList');
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
                $('.pagination:first').remove();
                $('#getBookingList').html(response.html);
            }
        });
    });
</script>