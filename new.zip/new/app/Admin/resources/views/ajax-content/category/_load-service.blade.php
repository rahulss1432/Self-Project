@if(count($services) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Service Name</th>
            <th class="w150 text-center">Status</th>
        </tr>
    </thead>
    <tbody>
        @foreach($services as $service)
        <tr>
            <td>{{$service->name}}</td>
            <td>
                <div class="switch text-center">
                    <label>
                        @if($service->status == 'active')
                        <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this,'{{$service->id}}')">
                        @else
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'{{$service->id}}')">
                        @endif
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $services->links() }}
<script>
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getServiceList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getServiceList').html(response.html);
            }
    });
    });
</script>     