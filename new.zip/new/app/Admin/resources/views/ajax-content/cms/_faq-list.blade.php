@if(count($faqs) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Question</th>
            <th>Answer</th>
            <th class="w170 text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($faqs as $faq)
        <tr>
            <td>{{$faq->question}}</td>
            <td>{{$faq->answer}}</td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item">
                        <a href="{{url('admin/edit-faq/'.base64_encode($faq->id))}}"><i class="ti-pencil-alt"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onclick="removeFaq('{{$faq->id}}');"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $faqs->links() }}
<script>
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getFaqList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'GET',
            url: pageLink,
            async: false,
            success: function (response) {
            $('.pagination:first').remove();
            $('#getFaqList').html(response.html);
            }
    });
    });
</script>