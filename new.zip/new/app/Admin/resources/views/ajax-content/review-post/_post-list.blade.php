@if(count($posts) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th>Mentor Name</th>
            <th>User Name</th>
            <th>Date and time </th>
            <th>View Media File</th>
            <th class="w350">Comment</th>
        </tr>
    </thead>
    <tbody>
        @foreach($posts as $post)
        <tr>
            <td>#{{$post->postAppointment->reference_id}}</td>
            <td>{{$post->postFromUser->first_name.' '.$post->postFromUser->last_name}}</td>
            <td>{{$post->postToUser->first_name.' '.$post->postToUser->last_name}}</td>
            <td>{{dateTimeFormat($post->created_at)}}</td>
            <td><a href="javascript:void(0);" class="btn-blue" onclick="viewMedia('{{$post->id}}');">View Media</a></td>
            <td>
                {{getLimitText(30,$post->comment)}}
                @php
                $stringLength = strlen($post->comment);
                if($stringLength > 30){
                @endphp
                <a href="javascript:void(0);" onclick="commentsView('{{$post->id}}', 'comment')" class="theme-color">Read More</a>
                @php
                }
                @endphp
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $posts->links() }}
<script>
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getPostsList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getPostsList').html(response.html);
            }
    });
    });
</script>