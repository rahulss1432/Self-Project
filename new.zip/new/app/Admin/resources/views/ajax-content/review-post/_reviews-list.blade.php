@if(count($reviews) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th>Mentor Name</th>
            <th>User Name</th>
            <th>Rating counts</th>
            <th>Date and time </th>
            <th class="w350">Comment</th>
        </tr>
    </thead>
    <tbody>
        @foreach($reviews as $review)
        <tr>
            <td>#{{$review->ratingAppointment->reference_id}}</td>
            <td>{{$review->ratingFromUser->first_name.' '.$review->ratingFromUser->last_name}}</td>
            <td>{{$review->ratingToUser->first_name.' '.$review->ratingToUser->last_name}}</td>
            <td>
                <div class="rating d-inline-block">
                    @for($i=1; $i<=$review->rating; $i++)
                    <i class="fa fa-star" aria-hidden="true" data-rating="{{$review->rating}}"></i>
                    @endfor
                </div>
                <span>({{$review->rating}}.0)</span>
            </td>
            <td>{{dateTimeFormat($review->created_at)}}</td>
            <td>
                {{getLimitText(30,$review->reviews)}}
                @php
                $stringLength = strlen($review->reviews);
                if($stringLength > 30){
                @endphp
                <a href="javascript:void(0);" onclick="commentsView('{{$review->id}}', 'review')" class="theme-color">Read More</a>
                @php
                }
                @endphp
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $reviews->links() }}
<script>
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getReviewsList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getReviewsList').html(response.html);
            }
    });
    });
</script>