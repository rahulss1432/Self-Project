@if(count($getAvailability)>0)
@foreach($getAvailability as $data)
<li>
    <div class="location_row">
        <i class="fa fa-map-marker"></i>
        <h3>{{$data->userState->getCountryByState->name}} <span>{{$data->userState->state_name}}</span></h3>
    </div>
    <ul class="list-inline date_row mb-0">
        <li class="list-inline-item">
            <i class="fa fa-calendar"></i><span>{{startEndDateFormat($data->from_date_time,$data->to_date_time)}}</span>
        </li>
        <li class="list-inline-item">
            <i class="fa fa-clock-o"></i><span>{{startEndTimeFormat($data->from_date_time,$data->to_date_time)}}</span>
        </li>
    </ul>
    <div class="meeting_row">
        <label><i class="fa fa-home"></i> Meeting Place :</label> <span>{{$data->city}}</span>
    </div>
</li>
@endforeach
@else 
<div class="alert alert-danger"><center>No record found</center></div>
@endif