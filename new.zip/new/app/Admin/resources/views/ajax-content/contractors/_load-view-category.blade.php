@if(count($getCategory)>0)
@foreach($getCategory as $data)
<li>
    <div class="location_row">
        <i class="ti-layout-grid3"></i>{{$data->mentorCategory->category_name}}
    </div>
    <div class="location_row">
        <i class="ti-layout-grid3"></i>{{$data->mentorService->name}}
    </div>
</li>
@endforeach
@else 
<div class="alert alert-danger"><center>No record found</center></div>
@endif