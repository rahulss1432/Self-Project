@if(count($getDocument)>0)
@foreach($getDocument as $data)
<li>
    <div class="location_row">
        <i class="fa fa-file-text-o"></i>
        <a href="{{asset('public/uploads/portfolio/'.$data->link)}}" target="_blank" download>{{$data->link}}</a>
    </div>
</li>
@endforeach
@else 
<div class="alert alert-danger"><center>No record found</center></div>
@endif