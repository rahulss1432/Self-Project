@extends('admin::include.app')
@section('title', 'Manage Payment')
@section('content')
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Commission List</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive" id="getCommissionList">
                    <table class="table admin-table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>value</th>
                                <th class="w100 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Commission rate in Percentage %</td>
                                <td>{{getSetting('commision_percent')}}</td>
                                <td>
                                    <ul class="list-inline mb-0 text-center">
                                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                            <a href="javascript:void(0);" onclick="editCommissionModal();"><i class="ti-pencil-alt"></i></a>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- add flagged terms modal -->
<div class="modal fade" id="editCommissionModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Commission</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" id="editCommission" class="f-field" action="{{ url('admin/edit-commission') }}">
                    {{csrf_field()}}
                    <div class="form-group">
                        <input type="text" class="form-control form-control-lg" value="{{getSetting('commision_percent')}}" name="commission"/>
                        <label class="control-label">Commission rate</label>
                    </div>
                    <div class="form-group mb-0 text-right">
                        <button type="submit" id="btnCommission" onclick="editCommission()" class="btn btn-sm btn-primary ripple-effect">
                            Submit <i id="formLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none"></i>
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Admin\Http\Requests\EditCommissionRequest','#editCommission') !!}
            </div>
        </div>
    </div>
</div>
<script>

    function editCommissionModal() {
        $("#editCommissionModal").modal("show");
    }

    function editCommission() {
        var formData = $("#editCommission").serializeArray();
        if ($('#editCommission').valid()) {
            $('#btnCommission').prop('disabled', true);
            $('#formLoader').show();
            $.ajax({
                type: "POST",
                url: "{{ url('admin/edit-commission') }}",
                data: formData,
                success: function (response)
                {
                    if (response.success) {
                        $("#editCommissionModal").modal('hide');
                        toastrAlertMessage('success', response.message);
                        window.location.reload();
                        $('#formLoader').hide();
                        $('#btnCommission').prop('disabled', false);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnCommission').prop('disabled', false);
                        $('#formLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#formLoader').hide();
                    $('#btnCommission').prop('disabled', false);
                }
            });
        }
    }
</script>
@endsection