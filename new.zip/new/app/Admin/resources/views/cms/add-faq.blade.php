@extends('admin::include.app')
@section('title', 'Manage Cms')
@section('content')    
<main class="main-content cms-edit" id="mainContent">
    <div class="page-content" id="pageContent">
        <div class="card custom_card" id="card_height">
            <div class="card-header">
                <h4 class="page-title float-left">Add FAQ</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/faq')}}" class="nav-link" title="Back"><i class="ti-arrow-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-xl-8 offset-xl-2">
                        <form method="post" id="addFaqs" class="f-field" action="{{ url('admin/add-faqs') }}">
                            {{csrf_field()}}
                            <div class="form-group">
                                <input type="text" name="question" class="form-control form-control-lg" placeholder="">
                                <label class="control-label">Question</label>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control form-control-lg" name="answer"></textarea>
                                <label class="control-label">Answer</label>
                            </div>
                            <div class="from-group">
                                <button id="btnFaqs" type="submit" onclick="addFaqs();" class="btn btn-sm btn-primary ripple-effect">
                                    Submit <i id="faqFormLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none;"></i>
                                </button>
                            </div>
                        </form>
                        {!! JsValidator::formRequest('App\Admin\Http\Requests\AddFaqRequest','#addFaqs') !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    function addFaqs() {
        var formData = $("#addFaqs").serializeArray();
        formData.push('_token', '{{ csrf_token() }}');
        if ($('#addFaqs').valid()) {
            $('#btnFaqs').prop('disabled', true);
            $('#faqFormLoader').show();
            $.ajax({
                type: "POST",
                url: "{{ url('admin/add-faqs') }}",
                data: formData,
                success: function (response)
                {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        $('#faqFormLoader').hide();
                        $('#btnFaqs').prop('disabled', false);
                        window.location.href = "{{url('admin/faq')}}";
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnFaqs').prop('disabled', false);
                        $('#faqFormLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#faqFormLoader').hide();
                    $('#btnFaqs').prop('disabled', false);
                }
            });
        }
    }

    $("textarea").keydown(function () {
        var el = this;
        el.style.cssText = 'height:auto; padding:0';
        el.style.cssText = 'height:' + el.scrollHeight + 'px';
    });
</script>
@endsection