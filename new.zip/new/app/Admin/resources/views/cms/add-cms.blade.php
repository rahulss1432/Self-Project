@extends('admin::include.app')
@section('title', 'Manage Cms')
@section('content')
<main class="main-content cms-edit" id="mainContent">
    <div class="page-content" id="pageContent" >
        <div class="card custom_card" id="card_height">
            <div class="card-header">
                <h4 class="page-title float-left">Add Cms</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/cms')}}" class="nav-link" title="Back"><i class="ti-arrow-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-xl-8 offset-xl-2">
                        <form method="post" id="addCms" class="f-field" action="{{ url('admin/add-cms') }}">
                            {{csrf_field()}}
                            <div class="form-group">
                                <input type="text" name="title" class="form-control form-control-lg" placeholder="">
                                <label class="control-label">Title</label>
                            </div>
                            <div class="form-group">
                                <textarea rows="6" name="description" id="description" class="form-control contain-editor"></textarea>
                                <span id="validation-error-msg"></span>
                                <!--<label class="control-label">Description</label>-->
                            </div>
                            <div class="from-group">
                                <button type="submit" id="btnCms" onclick="addCms();" class="btn btn-sm btn-primary ripple-effect">
                                    Save <i id="cmsFormLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none;"></i>
                                </button>
                            </div>
                        </form>
                        {!! JsValidator::formRequest('App\Admin\Http\Requests\EditCmsRequest','#addCms') !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    $(document).ready(function () {
        tinymceInit();
    });

    function tinymceInit() {
        tinymce.init({
            theme: "modern",
            selector: "textarea",
            relative_urls: false,
            remove_script_host: true,
            convert_urls: false,
            plugins: 'preview code searchreplace autolink directionality table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern',
            toolbar: 'undo redo | formatselect | bold italic strikethrough forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat | code',
            height: 200,
            init_instance_callback: function (editor) {
                editor.on('keyup', function (e) {
                    var description = tinymce.get('description').getContent();
                    if (description === undefined || description.length == 0)
                    {
                        $('#validation-error-msg').css({"display": "inline-block", "margin-top": "5px"}).html("Description field is required.");
                    } else
                    {
                        $('#validation-error-msg').html('');
                    }
                });
            }
        });
    }

    function addCms() {
        var description = tinymce.get('description').getContent();
        if (description) {
            $('#validation-error-msg').html('');
            var formData = $("#addCms").serializeArray();
            formData.push({name: 'description', value: tinymce.get('description').getContent()});
            if ($('#addCms').valid()) {
                $('#btnCms').prop('disabled', true);
                $('#cmsFormLoader').show();
                $.ajax({
                    type: "POST",
                    url: "{{ url('admin/add-cms') }}",
                    data: formData,
                    success: function (response)
                    {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            $('#cmsFormLoader').hide();
                            $('#btnCms').prop('disabled', false);
                            window.location.href = "{{url('admin/cms')}}";
                        } else {
                            toastrAlertMessage('error', response.message);
                            $('#btnCms').prop('disabled', false);
                            $('#cmsFormLoader').hide();
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                        $('#cmsFormLoader').hide();
                        $('#btnCms').prop('disabled', false);
                    }
                });
            }
        } else {
            $('#validation-error-msg').css({"display": "inline-block", "margin-top": "5px"}).html("Description field is required.");
        }
    }
</script>
@endsection