@php
$currentRoute = Request::route()->getName();
@endphp
<header id="header">
    <nav class="navbar navbar-light justify-content-between bg-transparent">
        <h3 class="page-title">
            <a href="javascript:void(0);" onclick="openSideMenu();" class="toggle-icon">
                <i class="ti-menu-alt"></i>
            </a>
            @if($currentRoute == 'manage-dashboard')
            Dashboard
            @elseif($currentRoute == 'manage-user')
            Manage Mentee
            @elseif($currentRoute == 'manage-category')
            Manage Category List
            @elseif($currentRoute == 'manage-booking')
            Manage Booking
            @elseif($currentRoute == 'get-service')
            Manage Service
            @elseif($currentRoute == 'notifications')
            Notifications
            @elseif($currentRoute == 'change-password')
            Change Password
            @elseif($currentRoute == 'manage-payment')
            Manage Payment
            @elseif($currentRoute == 'manage-commission')
            Manage Commission
            @elseif($currentRoute == 'manage-review-post')
            Reviews & Posts
            @elseif($currentRoute == 'manage-chat')
            All Chats
            @elseif($currentRoute == 'messages')
            Message
            @elseif($currentRoute == 'faq' || $currentRoute == 'cms')
            Manage Cms
            @elseif($currentRoute == 'manage-contractor')
            Manage Mentors
            @elseif($currentRoute == 'pending-contractor')
            Pending Mentors
            @elseif($currentRoute == 'manage-complaint')
            Manage Complaints
            @endif
            @php $id = \Illuminate\Support\Facades\Auth::guard('admin')->user()->id; @endphp
        </h3>
        <ul class="nav">
            <li class="dropdown notification ">
                <a href="javascript:void(0);" class="dropdown-toggle" onclick="readNotification()" id="dropdownMenuButton01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="ti-bell"></i>
                    <span class="notificationCount"></span>
                </a>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton01">
                    <div class="head">
                        <h3 class="font-hy mb-0">Notifications</h3>
                    </div>
                    <div class="noti_body" id="notificationList">

                    </div>
                    @if(getNotificationCount($id)>0)
                    <div class="noti_footer text-center">
                        <a onclick="readNotification()" href="{{url('admin/notifications')}}" class="d-block">View All</a>
                    </div>
                    @endif
                </div>
            </li> 
            <li class="dropdown nav-item mr-0 user-dropdwon">
                <a class="bg-transparent dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="ti-user"></i>
                </a>
                <div class="dropdown-menu border-0" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="{{url('admin/change-password')}}"><i class="ti-key"></i> Change Password</a>
                    <a class="dropdown-item" href="{{url('admin/logout')}}" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                        <i class="ti-power-off"></i>Log Out
                    </a>
                    <form id="logout-form" action="{{url('admin/logout')}}" method="POST" style="display: none;">
                        {{ csrf_field() }}
                    </form>
                </div>
            </li>

        </ul>
    </nav>
</header>

<script>
    $(document).ready(function () {
        loadNotificationList();
        setInterval(countNotificationList, 5000);
    });

    function loadNotificationList() {
        pageDivLoader('notificationList', 'show');
        var url = "{{url('admin/load-notification-list')}}";
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.success) {
                    $("#notificationList").html(response.html);
                    $(".notifi-list").mCustomScrollbar();
                }
            }
        });
    }

    function countNotificationList() {
        var url = "{{url('admin/load-notification-count')}}";
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.data > 0) {
                    $('.notificationCount').addClass('count');
                    $('.notificationCount').html(response.data);
                } else {
                    $('.notificationCount').removeClass('count');
                    $('.notificationCount').html('');
                }
            },
            error: function (err) {
            }
        });
    }

    function readNotification() {
        var url = "{{url('admin/update-notification-list')}}";
        $.ajax({
            url: url,
            type: 'POST',
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
                loadNotificationList();
                countNotificationList();
            },
            error: function (err) {
            }
        });
    }
</script>