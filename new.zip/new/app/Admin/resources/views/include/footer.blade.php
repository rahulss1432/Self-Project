<div class="page-overlay" onclick="closeSidemenu();"></div>
<script type="text/javascript">
    /**selectpicker on selected value add class */
    $('.selectpicker').change(function () {
        if ($(this).val()) {
            $(this).closest('.bootstrap-select').addClass('selected');
        } else {
            $(this).closest('.bootstrap-select').removeClass('selected');
        }
    });

//    //Date Picker
//    $('#SelectDate02, #SelectDate01, #SelectDate04').datetimepicker({
//        focusOnShow: false,
//        format: 'L',
//        ignoreReadonly: true
//    });

    $("#fromDate").on("change.datetimepicker", function (e) {
        $('#toDate').datetimepicker('minDate', e.date);
    });
    $("#toDate").on("change.datetimepicker", function (e) {
        $('#fromDate').datetimepicker('maxDate', e.date);
    });
    //  dateFormate
    $('#fromDate, #toDate').datetimepicker({
        useCurrent: false,
        focusOnShow: false,
        format: 'L',
        ignoreReadonly: true,
        maxDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
        disabledDates: [
            new Date(Date.now() + 1 * 24 * 60 * 60 * 1000)],

    });
    
    $("#fromDate1").on("change.datetimepicker", function (e) {
        $('#toDate1').datetimepicker('minDate', e.date);
    });
    $("#toDate1").on("change.datetimepicker", function (e) {
        $('#fromDate1').datetimepicker('maxDate', e.date);
    });
    //  dateFormate
    $('#fromDate1, #toDate1').datetimepicker({
        useCurrent: false,
        focusOnShow: false,
        format: 'L',
        ignoreReadonly: true,
        maxDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
        disabledDates: [
            new Date(Date.now() + 1 * 24 * 60 * 60 * 1000)],

    });

    $('.form-control').on('focus blur', function (e) {
        $(this).parents('.form-group').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
    }).trigger('blur');

    // for side menu start
    function openSideMenu() {
        $("body").toggleClass("menu-toggle");
    }
    function closeSidemenu() {
        $("body").removeClass("menu-toggle");
    }
    // for side menu end

    // for ripple effect
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });

    var rotate = 1;

    function hide_preloader() {
        rotate = 0;
        $("#preloader").fadeOut('slow');
    }

    function deleteModal() {
        $("#deleteModal").modal('show');
    }

    function showStatusModal() {
        $("#statusModal").modal('show');
    }

    $("textarea").keydown(function () {
        var el = this;
        el.style.cssText = 'height:auto; padding:0';
        el.style.cssText = 'height:' + el.scrollHeight + 'px';
    });

    $('[data-toggle="tooltip"]').tooltip({trigger: "hover"});

// $(window).scroll(function() {    
//     var scroll = $(window).scrollTop();    
//     if (scroll <= 0) {
//         $("#header").addClass("static");
//     }
//     else{
//       $("#header").removeClass("static");  
//     }
// }

// toaster common function
    function toastrAlertMessage(type, msg) {
        if (type == 'success') {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.success(msg, {timeOut: 2000});
        } else {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.error(msg, {timeOut: 2000});
        }
    }
// page loader common function
    function pageDivLoader(type, id) {
        if (type === 'show') {
            $('#' + id).html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-2x"></i></div>');
        } else {
            $('#' + id).html('');
        }
    }
</script>


<!-- delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false"  aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered delete-modal" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <p class="text-center">Are you sure you want to delete this ?</p>
                <div class="form-group mb-0 text-center">
                    <button type="button" class="btn btn-sm btn-dark ripple-effect mr-2" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-sm btn-primary ripple-effect" data-dismiss="modal">Ok</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- change status Modal -->
<div class="modal fade" id="statusModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false"  aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered delete-modal" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <p class="text-center">Are you sure you want to change the status ?</p>
                <div class="form-group mb-0 text-center">
                    <button type="button" class="btn btn-sm btn-dark ripple-effect mr-2 cancle_btn"
                            data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-sm btn-primary ripple-effect success_btn"
                            data-dismiss="modal">Ok</button>
                </div>
            </div>
        </div>
    </div>
</div>