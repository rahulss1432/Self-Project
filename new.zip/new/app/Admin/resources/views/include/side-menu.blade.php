@php
$currentRoute = Request::route()->getName();
@endphp
<aside class="sidemenu" >
    <div class="sidebar-wrapper">
        <div class="logo">
            <img src="{{ asset('public/images/logo.png') }}" alt="logo" class="img-fluid">      
        </div>
        <ul  id="nav-aside" class="nav flex-column mCustomScrollbar sidenav" data-mcs-theme="minimal-dark">
            <li class="nav-item {{($currentRoute == 'manage-dashboard')?'active':''}}">
                <a class="nav-link" href="{{url('admin/dashboard')}}"><i class="ti-home"></i>Dashboard</a>
            </li>
            <li class="nav-item {{($currentRoute == 'manage-contractor')? 'active' :''}}">
                <a class="nav-link" href="{{ url('/admin/manage-contractor') }}"><i class="ti-layers-alt"></i>Manage Mentors</a>
            </li>
            <li class="nav-item {{($currentRoute == 'pending-contractor')? 'active' :''}}">
                <a class="nav-link" href="{{url('admin/pending-contractor')}}"><i class="ti-layers"></i>Pending Mentors</a>
            </li>
            <li class="nav-item {{($currentRoute == 'manage-user')?'active':''}}">
                <a class="nav-link" href="{{url('admin/manage-user')}}"><i class="ti-user"></i>Manage Mentee</a>
            </li>
            <li class="nav-item {{($currentRoute == 'manage-category' || $currentRoute == 'get-service')?'active':''}}">
                <a class="nav-link" href="{{url('admin/manage-category')}}"><i class="ti-layout-grid3"></i>Manage Category</a>
            </li>
            <li class="nav-item {{($currentRoute == 'manage-booking')?'active':''}}">
                <a class="nav-link" href="{{url('admin/manage-booking')}}"><i class="ti-bookmark-alt"></i>Manage Bookings</a>
            </li>
            <li class="nav-item {{($currentRoute == 'manage-payment')?'active':''}}">
                <a class="nav-link" href="{{url('admin/manage-payment')}}"><i class="fa fa-credit-card"></i>Payment Report</a>
            </li>
            <li class="nav-item {{($currentRoute == 'manage-commission')?'active':''}}">
                <a class="nav-link" href="{{url('admin/manage-commission')}}"><i class="ti-money"></i>Manage Commission</a>
            </li>
            <li class="nav-item {{($currentRoute == 'manage-chat')?'active':''}}">
                <a class="nav-link" href="{{url('admin/manage-chat')}}"><i class="ti-comment-alt"></i>All Chats</a>
            </li>
            <li class="nav-item {{($currentRoute == 'manage-review-post')?'active':''}}">
                <a class="nav-link" href="{{url('admin/manage-review-post')}}"><i class="ti-share-alt"></i>Reviews and Posts</a>
            </li>
            <li class="nav-item {{($currentRoute == 'manage-complaint')?'active':''}}">
                <a class="nav-link" href="{{url('admin/manage-complaint')}}"><i class="ti-book"></i>Manage Complaints</a>
            </li>
            <li class="nav-item {{($currentRoute == 'notifications')?'active':''}}">
                <a class="nav-link" href="{{url('admin/notifications')}}"><i class="ti-bell"></i>Notifications</a>
            </li>
            <li class="nav-item {{($currentRoute == 'faq' || $currentRoute == 'cms')?'active':''}}">
                <a class="nav-link" role="button" data-toggle="collapse" href="#manageCms" aria-expanded="false" aria-controls="order">
                    <i class="ti-pencil-alt icon"></i>Manage CMS <i class="ti-angle-down pt-1 mr-0 float-right"></i></a>
                <ul class="list-unstyled collapse {{($currentRoute == 'faq' || $currentRoute == 'cms')?'show':''}}" data-parent="#nav-aside" id="manageCms">
                    <li class="nav-item {{($currentRoute == 'faq')?'active':''}}">
                        <a class="nav-link" href="{{url('admin/faq')}}"><i class="ti-arrow-circle-right"></i>FAQ</a>   
                    </li>
                    <li class="nav-item {{($currentRoute == 'cms')?'active':''}}">
                        <a class="nav-link" href="{{url('admin/cms')}}"><i class="ti-arrow-circle-right"></i>CMS</a> 
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</aside>
