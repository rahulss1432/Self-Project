@extends('admin::include.app')
@section('title', 'Manage Payment')
@section('content')
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Payment Report List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="filter_section collapse" id="searchFilter">
                    <form method="post" action="javascript:load_payment_list()" id="search_form">
                        {{csrf_field()}}
                        <div class="row">
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="dateicon">
                                        <input type="text" readonly name="from_date" id="fromDate" class="form-control form-control-lg datetimepicker-input" data-target="#fromDate" data-toggle="datetimepicker">
                                        <label class="control-label">From Date</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <div class="dateicon">
                                        <input type="text" readonly name="to_date" id="toDate" class="form-control form-control-lg datetimepicker-input" data-target="#toDate" data-toggle="datetimepicker">
                                        <label class="control-label">To Date</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="booking_id" class="form-control form-control-lg">
                                    <label class="control-label">Booking ID</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    @php
                                    $mentors = getUserByRole('mentor');
                                    @endphp
                                    <select name="mentor_name" class="form-control form-control-lg selectpicker" data-size="5">
                                        <option value="">Select Mentor</option>
                                        @if(count($mentors) > 0)
                                        @foreach($mentors as $mentor)
                                        <option value="{{$mentor->id}}">{{getFullName($mentor->first_name,$mentor->last_name)}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                    <label class="control-label">Select Mentor</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group">
                                    @php
                                    $users = getUserByRole('user');
                                    @endphp
                                    <select name="user_name" class="form-control form-control-lg selectpicker" data-size="5">
                                        <option value="">Select Mentor</option>
                                        @if(count($users) > 0)
                                        @foreach($users as $user)
                                        <option value="{{$user->id}}">{{getFullName($user->first_name,$user->last_name)}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                    <label class="control-label">Select User</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group d-inline-block mr-2">
                                    <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                </div>
                                <div class="form-group d-inline-block">
                                    <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="reset">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="getPaymentList">
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    $(document).ready(function ()
    {
        $('#preloader').hide();
        load_payment_list();
    });

    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        load_payment_list();
    }
    ;

    function load_payment_list()
    {
        pageDivLoader('show', 'getPaymentList');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "POST",
            url: "{{ url('admin/load-payment-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getPaymentList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection