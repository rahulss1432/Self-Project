<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;
use DB;
use Illuminate\Support\Facades\Hash;
use JWTAuth;

class AppServiceProvider extends ServiceProvider {

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot() {

        Validator::extend('check_email_format', function ($attribute, $value, $parameters, $validator) {
            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('valid_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->get();
            if ($user->count() > 0) {
                return true;
            } else {
                return false;
            }
        });

        /* check email type if admin */
        Validator::extend('admin_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->where('role', '=', 'admin')->get();
            if ($user->count() > 0) {
                return true;
            } else {
                return false;
            }
        });

        /* check for current password is valida or not */
        Validator::extend('current_password_match', function ($attribute, $value, $parameters, $validator) {
            return Hash::check($value, Auth::guard('admin')->user()->password);
        });

        /* check for current password is valida or not */
        Validator::extend('current_password_match_api', function ($attribute, $value, $parameters, $validator) {
            $user = JWTAuth::toUser(request()->header('access_token'));
            return Hash::check($value, $user['password']);
        });

        /* validation for check no spaces contain in field */
        Validator::extend('remove_spaces', function($attribute, $value, $parameters, $validator) {
            if (trim($value) == '') {
                return false;
            }
            return true;
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register() {
        //
    }

}
