<?php

return [
    'paths' => [
        "/notification" => [
            "get" => [
                "tags" => [
                    "notification"
                ],
                "summary" => "notification list",
                "description" => "notification list",
                "operationId" => "notification list",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                   
                ],
                "responses" => [
                ]
            ],
            
        ],
        "/notification/{id}" => [
            "delete" => [
                "tags" => [
                    "notification"
                ],
                "summary" => "delete notification",
                "description" => "delete notification",
                "operationId" => "delete notification",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "path",
                        "name" => "id",
                        "description" => "",
                        "required" => true,
                        "type" => "integer",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                ]
            ],
            
        ],
        
    ],
    'definitions' => [
        'login' => [
            'type' => "object",
            'properties' => [
                'email' => [
                    'type' => 'string'
                ],
                'password' => [
                    'type' => 'string'
                ],
                'device_id' => [
                    'type' => 'string'
                ],
                'device_type' => [
                    'type' => 'string'
                ],
                'certification_type' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "Login"
            ]
        ],
    ]
];
