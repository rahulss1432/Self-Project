<?php

return [
    'paths' => [
        "/toggle-favorite" => [
            "post" => [
                "tags" => [
                    "user"
                ],
                "summary" => "Toggle favorite",
                "description" => "Toggle favorite",
                "operationId" => "post",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "query",
                        "name" => "user_id",
                        "description" => "",
                        "required" => true,
                        "type" => "integer",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                ]
            ],
        ],
        "/category" => [
            "get" => [
                "tags" => [
                    "user"
                ],
                "summary" => "category list",
                "description" => "category list",
                "operationId" => "category list",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                ]
            ],
        ],
        "/services" => [
            "get" => [
                "tags" => [
                    "user"
                ],
                "summary" => "service list",
                "description" => "service list",
                "operationId" => "service list",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "catery_id",
                        "in" => "query",
                        "description" => "catery_id",
                        "required" => true,
                        "type" => "integer",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                ]
            ],
        ],
    ],
    'definitions' => [
        'favorite-post' => [
            'type' => "object",
            'properties' => [
                'to_id' => [
                    'type' => 'integer'
                ],
            ],
            'xml' => [
                'name' => "appointment"
            ]
        ],
    ]
];
