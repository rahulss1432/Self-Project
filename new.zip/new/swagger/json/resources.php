<?php

$params = require_once('params.php');

$account = require_once('account.php');
$common = require_once('common.php');
$mentor = require_once('mentor.php');
$user = require_once('user.php');
$notification = require_once('notification.php');
$chat = require_once('chat.php');

$paths = array_merge($account['paths'],$common['paths'],$mentor['paths'],$user['paths'],$notification['paths'],$chat['paths']);

$definitions = array_merge($account['definitions'],$common['definitions'],$mentor['definitions'],$user['definitions'],$notification['definitions'],$chat['definitions']);

echo json_encode([
    'tags' => [
         [
            'name' => 'common',
            'description' => 'Common operation.',
        ],
        [
            'name' => 'account',
            'description' => 'guest user operations.',
        ]
       ,
       [
            'name' => 'mentor',
            'description' => 'Operation for mantor.',
        ],
        [
            'name' => 'user',
            'description' => 'Operation about user.',
        ],
        [
            'name' => 'notification',
            'description' => 'Operation about Executive.',
        ],
        [
            'name' => 'chat',
            'description' => 'Operation about chat.',
        ],
    ],
    "swagger" => "2.0",
    "info" => [
        "version" => "2.0.0",
        "title" => "Mentor Locator API"
    ],
    "host" => $params['host'],
    "basePath" => $params['basePath'],
    "schemes" => [
        "http",
        "https"
    ],
    'paths' => $paths,
    'definitions' => $definitions
]);
