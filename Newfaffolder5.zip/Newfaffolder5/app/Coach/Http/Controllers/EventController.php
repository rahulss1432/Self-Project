<?php

namespace App\Coach\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Repositories\Coach\EventRepository;

class EventController extends Controller {
    /*
     * Class Construct.
     *
     * @param  array  $data
     * @return App\Coach\Repositories\UserRepository;
     */

    public function __construct(EventRepository $event) {
        $this->event = $event;
    }

    /*
     * Function for add event.
     */

    public function index() {
        return view('coach::event.event-add');
    }

    /*
     * Function for save event.
     */

    public function saveEvent(Request $request) {
        return $this->event->saveEvent($request);
    }

    /*
     * function for edit event.
     */

    public function editEvent($slug) {
        $event = $this->event->getEvent(NULL, base64_decode($slug), NULL);
        return view('coach::event.event-edit', ['event' => $event]);
    }

    /*
     * Function for delete event.
     */

    public function deleteEvent(Request $request) {
        return $this->event->deleteEvent($request);
    }

}
