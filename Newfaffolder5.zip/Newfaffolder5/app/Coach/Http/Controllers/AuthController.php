<?php

namespace App\Coach\Http\Controllers;

use App\Coach\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;

class AuthController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest')->except('logout');
    }
   
    /**
     * Log the user out of the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function logout(Request $request) {
        $role = $request->session()->get('current-guard');
        $userId = Auth::guard($role)->user()->id;
        $user = User::where('id',$userId)->first();
        $user->availability = 'offline';
        $user->save();
        Auth::guard($role)->logout();
        $request->session()->invalidate();
        return redirect('/');
    }

}
