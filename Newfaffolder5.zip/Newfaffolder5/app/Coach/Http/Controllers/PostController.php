<?php

namespace App\Coach\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Repositories\Coach\PostRepository;
use App\Repositories\Player\UserRepository;

class PostController extends Controller
{
    /*
     * Class Construct.
     *
     * @param  array  $data
     * @return App\Coach\Repositories\UserRepository;
     */
    public function __construct(PostRepository $post, UserRepository $user, \App\Repositories\UserRepository $commanUser) {
        $this->post = $post;
        $this->commanUser = $commanUser;
        $this->user = $user;
    }
    
    /*
     * Function for get post.
     */
    public function index()
    {
        $posts = $this->post->getPost();
        $html = View::make('coach::ajax-content._post-view', ['posts' => $posts,'o_id' =>''])->render();
        return Response::json(['html' => $html, 'posts' => $posts]);
    }
    
    /*
     * Function for get post.
     */
    public function getTimelinePost(Request $request)
    {
        $id = '';
        if (!empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $posts = $this->post->getTimelinePost($user->id);
        $html = View::make('coach::ajax-content._post-view', ['posts' => $posts,'o_id' =>$id])->render();
        return Response::json(['html' => $html, 'posts' => $posts]);
    }
    
    /*
     * Function for save post.
     */
    public function savePost(Request $request) {
        return $this->commanUser->savePost($request);
    }
    
    /*
     * Function for edit post.
     */
    public function editPost(Request $request){
        $post = $this->commanUser->editPost($request);
        $html = View::make('coach::ajax-content._edit-post', ['post' => $post])->render();
        return Response::json(['html' => $html]);
    }
    
     /*
     * Function for add post.
     */
    public function addPost(){
        $html = View::make('coach::ajax-content._add-post')->render();
        return Response::json(['html' => $html]);
    }
    
    /*
    * Function using for upload multiple media file image/video 
    */
    
    public function uploadMultipleMediaPost(Request $request){
         return $this->commanUser->uploadPostFile($request);
    }
        
    /*
     * Function for save post.
     */
    public function deletePost(Request $request) {
        return $this->commanUser->deletePost($request);
    }
    
    /*
     * Function for get post likes.
     */
    public function getPostLike(Request $request){
        return $this->post->getPostLike($request);
    }
        
    /*
     * Function for add post likes.
     */
    public function addPostLike(Request $request){
        return $this->post->addPostLike($request);
    }
    
    /*
     * Function for add post likes.
     */
    public function checkPostLike(Request $request){
        return checkUserLike($request->pid,$request->id);
    }
    
    /*
     * Function for add post likes.
     */
    public function getLikeUser(Request $request){
        try{
            $likeUsers = $this->post->getLikeUser($request);
            $html = View::make('coach::ajax-content._like-list', ['likeUsers' => $likeUsers])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    /*
     * Function for add post comment.
     */
    public function addPostComment(Request $request){
        return $this->post->addPostComment($request);
    }
    
    /*
     * Function for get post comment.
     */
    public function getPostComments(Request $request) {
        try {
            $comments = $this->post->getPostComments($request);
            $count = $this->post->getPostCommentsCount($request);
            if ($request->action == 'first') {  // when page load get first three record desc and reverse
                $html = View::make('coach::ajax-content._comments-list', ['comments' => $comments, 'pid' => $request->pid, 'total_count' => $count])->render();
            } else {
                $html = View::make('coach::ajax-content._post_all_comments', ['comments' => $comments, 'pid' => $request->pid, 'total_count' => $count])->render();
            }
            return Response::json(['success' => true, 'html' => $html, 'total_count' => $count]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    /*
     * Function for add post comment.
     */
    public function addPostCommentReply(Request $request){
        return $this->post->addPostCommentReply($request);
    }
    
    /*
     * Function for get post comment.
     */
    public function getPostCommentsReply(Request $request){
        try{
            $comments = $this->post->getPostCommentsReply($request);
            $count = $this->post->getPostCommentsReplyCount($request);
            $html = View::make('coach::ajax-content._comments-reply-list', ['comments' => $comments])->render();
            return Response::json(['success' => true, 'html' => $html, 'count' => $count]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
      /*
    * Function using for get post view modal
    */
    
    public function getPostViewModal(Request $request){
        $getPost = $this->commanUser->getPlayerPost($request);
        $html = View::make('coach::ajax-content._post-view-modal',['getPost' => $getPost])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }
    
    /*
    * Function using for media comment list
    */
    
    public function mediaCommentList(Request $request){
        $getComment = $this->commanUser->getMediaEventsByType($request, 'comment');
        $html = View::make('coach::ajax-content._media-comment-list',['getComment' => $getComment])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }
    
    /*
    * Function using for save media comment
    */
    
    public function saveMediaComment(Request $request){
       return  $this->commanUser->saveMediaComment($request);
    }
    
    /*
    * Function using for save media like
    */
    
    public function saveMediaLike(Request $request){
       return  $this->commanUser->saveMediaLike($request);
    }
    
     /*
    * Function using for save media like
    */
    
    public function getMediaLikeUser(Request $request){
      try{
            $likeUsers = $this->commanUser->getMediaEventsByType($request,'like');
            $html = View::make('coach::ajax-content._like-list', ['likeUsers' => $likeUsers])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    /*
    * Function using for get my post media view
    */
    
    public function getMyMediaView(Request $request){
        $getMedia = $this->commanUser->getMyMediaView($request);
        $html = View::make('coach::ajax-content._my-post-media-view',['getMedia' => $getMedia])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }
    
    
    /**
     * sumit
     * @param Request $request
     * @return type
     * delete media comment
     */
    
    public function deleteMediaComment(Request $request){
        return $this->commanUser->deleteMediaComment($request->id);  
    } 
    
    /**
     * sumit
     * @param Request $request
     * @return type
     * delete post comment
     */
    
    public function deletePostComment(Request $request){
        return $this->commanUser->deletePostComment($request->id);
    }
    
}
