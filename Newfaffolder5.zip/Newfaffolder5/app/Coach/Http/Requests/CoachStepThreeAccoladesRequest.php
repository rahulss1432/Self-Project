<?php

namespace App\Coach\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CoachStepThreeAccoladesRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => "required|max:100|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/",
            'image' => 'nullable|mimes:jpeg,jpg,png|max:1048',
            'present_organization' => "required|max:100|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/",
            'present_year' => 'required',
        ];
    }
      public function messages() {
         return [
             'name.regex' =>'The only space not allowed.',
             'present_organization.regex' =>'The only space not allowed.',
            // 'to_year.required_if' =>'The to year field is required.',
            ];
     }
}
