<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */
Route::group(['prefix' => 'coach', 'middleware' => 'common'], function() {
    /**/
    Route::get('get-coach-procard', 'CoachController@coachProCard');
    Route::get('members-you-may-know/{slug?}', 'CoachController@membersYouMayKnow');
    Route::post('get-member-list', 'CoachController@getMemberList');
    Route::get('left-sidebar', 'CoachController@leftSidebar');
    Route::get('right-sidebar', 'CoachController@rightSidebar');
    Route::get('get-coach-counts', 'CoachController@getAllCount');

    Route::get('get-desired-benifites', 'CoachController@getDesiredBenifites');
    Route::get('load-more-benefites', 'CoachController@loadMoreBenefites');

    Route::post('get-attribute-list', 'CoachController@attributesList');

    Route::get('get-all-education', 'CoachController@getAllEducation');
    Route::get('get-all-accolades', 'CoachController@getAccoladesList');
    /* coach experience routes */
    Route::post('get-experience-list', 'CoachController@getExperienceList');
    Route::get('get-coaching-experience', 'CoachController@getCoachingExperienceList');
    Route::get('user-connections-list', 'CoachController@userConnectionsList');

    /* route for slider page on home and timeline page */
    Route::post('get-matched-mutual-joined-members', 'CoachController@getMatchedAndMutualJoinedMembers');
    Route::post('get-matched-mutual-joined-members-list', 'CoachController@getMatchedMutualJoinedMembersList');
    Route::get('get-profile-media-list', 'CoachController@getProfileMediaList');

    /* route for profile and time line */
    Route::get('coach-timeline/{slug?}', 'CoachController@coachTimeline');
    Route::get('get-timeline-post', 'PostController@getTimelinePost');

    Route::get('coach-media/{slug?}', 'CoachController@coachMedia');

    Route::get('get-post-view-modal', 'PostController@getPostViewModal');
    Route::get('media-comment-list', 'PostController@mediaCommentList');
    Route::post('save-media-comment', 'PostController@saveMediaComment');
    Route::get('save-media-like', 'PostController@saveMediaLike');
    Route::post('get-media-like-user', 'PostController@getMediaLikeUser');

    Route::post('update-select-media', 'CoachController@updateSelectedMedia');
    Route::get('get-my-media-view', 'PostController@getMyMediaView');
    Route::get('get-select-media', 'CoachController@getSelectMedia');

    Route::get('get-video-list', 'CoachController@getMediaVideoList');
    Route::get('get-image-list', 'CoachController@getMediaImageList');

    /* post routes */
    Route::get('get-post', 'PostController@index');

    Route::get('get-post-like', 'PostController@getPostLike');
    Route::post('check-post-like', 'PostController@checkPostLike');
    Route::post('get-like-user', 'PostController@getLikeUser');
    Route::post('get-post-comments', 'PostController@getPostComments');

    /* My Connections Routes */
    Route::post('connect-dismiss-member', 'CoachController@connectDismissMember');
    Route::post('get-recent-joined-members', 'CoachController@getRecentJoinedMembers');
    Route::post('accept-reject-connection', 'CoachController@acceptRejectConnection');


    Route::get('connections/{slug?}', 'CoachController@getConnections');
    Route::post('get-all-connections', 'CoachController@getAllConnections');
    Route::post('accept-reject-connection', 'CoachController@acceptRejectConnection');

    Route::post('add-post-like', 'PostController@addPostLike');
    Route::post('add-post-comment', 'PostController@addPostComment');

    Route::post('get-all-friend-request', 'CoachController@getAllFriendRequest');

    Route::post('logout', 'AuthController@logout');
});

Route::group(['prefix' => 'coach', 'middleware' => 'coach'], function() {
    // Remove post and media comments
    Route::post('remove-media-comment', 'PostController@deleteMediaComment');
    Route::post('remove-post-comment', 'PostController@deletePostComment');

    Route::post('upload-multiple-file', 'CoachController@uploadMultipleMedia');

    Route::get('post-view', 'CoachController@postView');
    Route::get('new-job-list', 'CoachController@newJobList');
    Route::get('applied-job-list', 'CoachController@appliedJobList');
    Route::get('dashboard', 'CoachController@index');
    Route::get('coach-profile', 'CoachController@coachProfile');

    Route::get('coach-media', 'CoachController@coachMedia');

    Route::get('coach-profile-form', 'CoachController@coachProfileForm');
    Route::get('load-add-skills-modal', 'CoachController@addSkillsModal');
    //Route::get('/search-user-skills', 'CoachController@autoSearchSkills');
    Route::post('/add-coach-skills', 'CoachController@addCoachSkills');

    Route::post('coach-step-one', 'CoachController@coachStepOne');
    Route::post('coach-step-two', 'CoachController@coachStepTwo');
    /* step 3 */
    Route::post('coach-step-three-general', 'CoachController@coachStepThreegeneral');
    Route::get('coach-step-three', 'CoachController@coachStepThree');
    Route::post('coach-add-update-experience', 'CoachController@coachAddUpdateExp');
    Route::get('coach-edit-delete-experience', 'CoachController@coachEditDeleteExp');
    /* End step 3 */
    Route::post('coach-step-four', 'CoachController@coachStepFour');
    Route::post('coach-step-five', 'CoachController@coachStepFive');

    /* Routes for events */
    Route::get('event-add', 'EventController@index');
    Route::post('save-event', 'EventController@saveEvent');
    Route::get('edit-event/{slug}', 'EventController@editEvent');
    Route::post('delete-event', 'EventController@deleteEvent');

    Route::post('delete-post', 'PostController@deletePost');



    Route::post('add-post-comment-reply', 'PostController@addPostCommentReply');
    Route::post('get-post-comments-reply', 'PostController@getPostCommentsReply');


    /* Messages routes */
    Route::get('messages', 'MessageController@index');
    Route::get('get-chat-users', 'MessageController@getChatUsers');
    Route::get('get-user-messages', 'MessageController@getUserMessages');
    Route::post('send-chat-message', 'MessageController@sendChatMessage');
    Route::get('check-unread-count', 'MessageController@checkUnreadCount');
    Route::get('update-read-count', 'MessageController@updateReadCount');
    Route::post('block-chat-user', 'MessageController@blockChatUser');


    /* Notifications Routes */
    Route::get('work-mode', 'CoachController@workMode');
    Route::get('get-notification', 'CoachController@getNotification');
    Route::get('notifications', 'CoachController@getAllNotifications');
    Route::get('notification-list', 'CoachController@notificationList');
    Route::get('remove-notification/{id}', 'CoachController@deleteNotifications');

    Route::get('delete-attribute', 'CoachController@deleteAttribute');

    Route::get('add-post-form', 'PostController@addPost');
    Route::get('edit-post', 'PostController@editPost');
    Route::post('upload-post-media', 'PostController@uploadMultipleMediaPost');
    Route::post('save-post', 'PostController@savePost');

    /* Friend requests */
    Route::get('my-friend-request', 'CoachController@myFriendRequest');

    /* friend requests Routes */
    Route::get('friend-request-unread-count', 'CoachController@getRequestUnreadCount');
});
