@if( $countries->count() > 0)
@foreach( $countries as $row )
<option value="{{ $row->country_id }}">{{ $row->name }}</option>
@endforeach
@endif