<div class="modal fade modal-center  users_like" id="users_like" data-backdrop="static" data-keyboard="false" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="users_like" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">  
                <h5 class="modal-title" id="exampleModalLabel">Users Like(7)</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body mt-0">
                <div class="btn_loader btn_ring" id="listLoader" style="display: none"></div>
                <ul class="list-unstyled mb-0 black-scroll mCustomScrollbar user_like_scroll" data-mcs-theme="dark"  id="LikeList" style="display: none; ">
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li> 
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<footer class="common_footer">
    <div class="row d-block d-lg-none d-xl-none">
        <div class="col-12">
            <div class="news">
                <div class="newsheading">
                    <p><span class="headingtag">FAF NEWS FEED</span></p>
                    <div class="newsline"><span>..st. Olaf new head football coach for the 2018</span></div>
                </div>
            </div>
        </div>
    </div>
    <div class="row common_row">
        <div class="col-12 col-sm-3 col-lg-2">
            <div class="foot_heading color-white">
                <h4>Explore</h4>
            </div> 
            <ul class="list-unstyled explore mb-0">
                <li><a href="javascript:void(0);" onclick="showAboutModal()">About FAF</a></li>
                <li><a href="javascript:void(0);" onclick="contactUsSupportForm('contact')">Contact Us</a></li>
                <!-- <li><a href="javascript:void(0);">Support</a></li> -->
                <li><a href="{{url('terms-and-service')}}">Terms of Service</a></li>
            </ul>   
        </div>
        <div class="col-12 col-sm-3 col-lg-2">
            <div class="foot_heading color-white">
                <h4>Follow</h4>
            </div>
            <ul class="follow list-inline mb-0">
                <li class="list-inline-item"> 
                    <a href="javascript:void(0);"> <i class="faf_icon"></i> </a> 
                </li>
                <li class="list-inline-item">
                    <a href="https://www.facebook.com/FreeAgentFootball/" target="_blank" class="icon facebook"> <i class=" flaticon-facebook-logo"></i></a>
                </li>
                <li class="list-inline-item">
                    <a href="https://twitter.com/FAFProDay" target="_blank" class="icon twitter"> <i class="flaticon-twitter-logo-silhouette"></i></a>
                </li>
                <li class="list-inline-item">
                    <a href="https://www.instagram.com/freeagentfootball.com.faf/" target="_blank"  class="icon instagram"> <i class="flaticon-instagram"></i></a>
                </li> 
            </ul>
        </div>
        <div class="col-12 col-lg-4 d-none d-md-none d-lg-block d-xl-block">
            <div class="news">
                <div class="newsheading">
                    <p><span class="headingtag">FAF NEWS FEED</span></p>
                    <div class="newsline" id="newsBulletin"></div>
                </div>
                <div class="foootball_img text-center">
                    <img class="img-fluid" src="{{ url('public/images/footer_news_img.png') }}" alt="football ">
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-3 col-lg-2">
            <div class="affiliate">
                <div class="foot_heading color-white">
                    <h4>Affiliate</h4>
                </div>
                <a href="https://prodip.pro/password" target="_blank">
                    <img class="img-fluid" src="{{ url('public/images/prodip_logo.jpg') }}" alt="logo ">
                </a>
            </div>
        </div>
        <div class="col-12 col-sm-3 col-lg-2">
            <div class="faf_app">
                <div class="foot_heading color-white ">
                    <h4>Get the App</h4>
                </div>
                <div class="app_link d-xl-flex justify-content-xl-between">
                    <div class="left d-none d-md-none d-lg-block d-xl-block">
                        <img src="{{ url('public/images/app_logo.png') }}" alt="logo ">
                    </div>
                    <div class="right">
                        <a href="javascript:void(0);">
                            <img src="{{ url('public/images/app_storebtn.png') }}" alt="logo ">
                        </a>
                        <a href="javascript:void(0);">
                            <img  src="{{ url('public/images/play_storebtn.png') }}" alt="logo ">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright text-center">
        <p class="mb-0">© {{date('Y')}} FreeAgentFootball.com (FAF) All Right Reserved</p>
    </div>
</footer>

<!-- post modal -->
<div class="modal fade modal-center share-article add_post" data-backdrop="static" data-keyboard="false" id="add_post" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="post_title">Compose Post</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="content">
                    <div class="form-group">
                        <textarea rows="5" class="form-control" placeholder="Type text here..."></textarea>
                    </div>
                    <div class="d-flex justify-content-center align-items-center">
                        <p>upload Photo/Video</p>
                        <!-- <ul class="list-inline icons">
                            <li class="list-inline-item">
                                <label for="photo">
                                    <input type="file" id="photo" hidden="">
                                    <span class="icon icon-image"></span>
                                </label>
                            </li>
                        </ul> -->
                    </div>
                    <div class="preview">
                        <div class="preview-box d-flex align-items-center justify-content-between">
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <img src="{{ url('public/images/video_thumb.jpg') }}" class="img-fluid" alt="video">
                                    <div class="icon">
                                        <a href="javascript:void(0);"><i class="fas fa-times"></i></a>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <img src="{{ url('public/images/video_thumb.jpg') }}" class="img-fluid" alt="video">
                                    <div class="icon">
                                        <a href="javascript:void(0);"><i class="fas fa-times"></i></a>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <img src="{{ url('public/images/video_thumb.jpg') }}" class="img-fluid" alt="video">
                                    <div class="icon">
                                        <a href="javascript:void(0);"><i class="fas fa-times"></i></a>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <img src="{{ url('public/images/video_thumb.jpg') }}" class="img-fluid" alt="video">
                                    <div class="icon">
                                        <a href="javascript:void(0);"><i class="fas fa-times"></i></a>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <img src="{{ url('public/images/video_thumb.jpg') }}" class="img-fluid" alt="video">
                                    <div class="icon">
                                        <a href="javascript:void(0);"><i class="fas fa-times"></i></a>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <img src="{{ url('public/images/video_thumb.jpg') }}" class="img-fluid" alt="video">
                                    <div class="icon">
                                        <a href="javascript:void(0);"><i class="fas fa-times"></i></a>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <img src="{{ url('public/images/video_thumb.jpg') }}" class="img-fluid" alt="video">
                                    <div class="icon">
                                        <a href="javascript:void(0);"><i class="fas fa-times"></i></a>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <img src="{{ url('public/images/video_thumb.jpg') }}" class="img-fluid" alt="video">
                                    <div class="icon">
                                        <a href="javascript:void(0);"><i class="fas fa-times"></i></a>
                                    </div>
                                </li>
                            </ul>
                            <div class="list-inline-item add-more">
                                <div class="wrap">
                                    <label for="add">
                                        <input type="file" id="add" hidden="">
                                        <img src="{{ url('public/images/plus_icon.svg') }}" alt="icon">
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer d-flex justify-content-between">
                <button type="button" class="btn btn-primary">Post</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal End -->

<!-- like modal -->
<div class="modal fade modal-center  users_like" id="users_like" data-backdrop="static" data-keyboard="false" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="users_like" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">  
                <h5 class="modal-title" id="exampleModalLabel">Users Like(7)</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body mt-0">
                <div class="btn_loader btn_ring" id="listLoader" style="display: none"></div>
                <ul class="list-unstyled mb-0 black-scroll mCustomScrollbar user_like_scroll" data-mcs-theme="dark"  id="LikeList" >
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li> 
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li><li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                    <li>
                        <div class="imgdiv">
                            <img src="{{ url('public/images/user_img07.png') }}" class="rounded-circle" alt="user">
                        </div>
                        <div class="caption">
                            <h4 class="text-capitalize">Boris Bell</h4>
                            <p>Player</p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- share social media -->
<div class="modal fade modal-center share_sociamedia" id="ShareSociaMedia" data-backdrop="static" data-keyboard="false"  data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content" id="media_page">

        </div>
    </div> 
</div>


<div class="modal fade alert_message" id="confirmJobApply" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Alert Message</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" >
                <div class="modal-body text-center">
                    <p>You are sure you want to apply job!</p>
                    <button type="button"  id="confirmStatus" class="btn btn-success border-2 p-8-20 font-14" onclick="changeAppliedStatus('yes')">Yes</button>
                    <button type="button"  id="confirmStatus" class="btn btn-success border-2 p-8-20 font-14" data-dismiss="modal" onclick="changeAppliedStatus('no')">No</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- contact form modal -->
<div class="modal fade contact_faf_modal form_modal backdrop-dark" id="contactUsModal" tabindex="-1" data-backdrop="static" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close login-modal-close" id="close-contactUsModal" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="flaticon-cross"></i></span></button>
            </div>
            <div class="modal-body" id="contactUsModalBody">
            </div>
        </div>
    </div>
</div>

<!--Success messaage modal for contact us form submission-->
<div class="modal form_modal fade success_message backdrop-dark" id="successFafModal" tabindex="-1" role="dialog"  data-backdrop="static" data-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered  " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span><i class="flaticon-cross"></i></span> 
                </button>
            </div>
            <div class="modal-body p-sm-0">
                <div class="success_message_box">
                    <div class="success_message_cnt ml-auto mr-auto">
                        <div class="sonar-emitter d-none d-md-block">
                            <div class="sonar-wave"></div>
                        </div>
                        <div class="top_heading">
                            <div class="text-center mb-3 color-green"><h3>Success!</h3></div>
                        </div>
                        <div class="inner text-center"> 
                            <p class="text-center color-white mb-0">
                                Your Message has been received and an FAF Team Member Will be Responding to you Shortly!
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--About FAF modal-->
<div class="modal form_modal fade about_faf backdrop-dark" id="aboutModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered about-modal" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span><i class="flaticon-cross"></i></span>
                </button>
            </div>
            <div class="about-body p-0">
                <div class="about-outer-box">
                    <div class="about-cnt ml-auto mr-auto">
                        <div class="sonar-emitter d-none d-md-block">
                            <div class="sonar-wave"></div>
                        </div>
                        <div class="about-inner ml-auto mr-auto position-relative">
                            <div class="modal-top">
                                <div class="text-center mb-3 color-white"><h3>About FAF</h3></div>
                            </div>
                            <div class="inner"> 
                                {!!getSettingBykey('about_us')!!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--js scripts-->

<script src="{{ url('public/js/popper.min.js') }}"></script>
<script src="{{ url('public/js/bootstrap.min.js') }}"></script>
<script src="{{ url('public/js/jquery.fileuploadmulti.min.js') }}"></script>
<script src="{{ url('public/js/jsvalidation.js') }}"></script>
<script src="{{ url('public/js/owl.carousel.min.js') }}"></script>
<script src="{{ url('public/js/jssocials.js') }}"></script>
<script src="{{ url('public/js/tempusdominus-bootstrap-4.min.js') }}"></script>
@if(Request::segment(2) != 'event-add' && Request::segment(2) != 'edit-event')
<script src="{{ url('public/js/bootstrap-select.min.js') }}"></script>
@endif
<script src="{{ url('public/js/jquery.mCustomScrollbar.concat.min.js') }}"></script>
<script src="{{ url('public/js/api.js') }}"></script>
<script src="{{ url('public/js/common.js') }}"></script>
<script src="{{ url('public/js/toastr.min.js') }}"></script>
<script src="{{ url('public/js/bootbox.js') }}"></script>

<script>
        function changeAddressBar() {
            try {
                <?php
                    if (isset($_GET['page'])) {
                        $url = $_SERVER['PHP_SELF'];
                    }
                ?>
                    history.pushState(null, null, '<?= (!empty($url)) ? $url : ""; ?>');
                        return false;
                    } catch (e) {
                    }
                 location.hash = '#';
        }

        changeAddressBar();    
        
        // Give modal backdrop an extra class to make it customizable
        $('.modal').on('show.bs.modal', function (e) {
            setTimeout(function () {
                $('.modal-backdrop').addClass('modal-backdrop-dark');
            });
        });        

        //  function for show contact us/support form
        function contactUsSupportForm(type){
            $.ajax({
                type: "GET",
                url: "{{ url('show-contact-support-form')}}/"+type,
                success: function (response) {
                   $('#contactUsModal').modal('show');                    
                   $("#contactUsModalBody").html(response.html);               
                },
                error:function(err){                
                },
                complete: function () {                        
                }
            });         
        }  
        
        //open about us modal
        function showAboutModal(){
            $('#aboutModal').modal('show');
        }             

// open modal
        function add_post() {
            $('#add_post').modal('show');
        }

        $(".preview-box  ul").mCustomScrollbar({
            theme: "dark",
            axis: "x",
        });

// share button
        var radioButtons = $("input[type='radio'][name='share']");
        var radioStates = {};
        $.each(radioButtons, function (index, rd) {
            radioStates[rd.value] = $(rd).is(':checked');
        });

        radioButtons.click(function () {
            var val = $(this).val();
            $(this).attr('checked', (radioStates[val] = !radioStates[val]));
            $.each(radioButtons, function (index, rd) {
                if (rd.value !== val) {
                    radioStates[rd.value] = false;
                }
            });
        });

        $('#LikeModal').click(function () {
            setTimeout(function () {
                $("#listLoader").hide();
                $("#LikeList").fadeIn('1000');
            }, 2000);
        });

        var urlSegment = "{{Request::segment(3)}}";
        var currentPage = "{{Request::segment(2)}}";
        var AuthUserSlug = "{{\Auth::guard(getAuthGuard())->user()->slug}}";
        var socialSharUrl = "{{ url('get-social-page')}}";
        var mutualFriednListUrl = "{{ url('mutual-friends-list')}}";
        var token = "{{csrf_token()}}";

        /*** End    **/
        $(document).ready(function () {
            getCoachNews();
            $('input[type="file"]').on('change', function () {
                var filename = $(this).val();
                console.log(filename);
                if (/^\s*$/.test(filename)) {
                    // $(".forupload").removeClass('active');
                    $(this).parent().children(".nofile_name").text("No file chosen...");
                } else {
                    // $(".forupload").addClass('active');
                    $(this).parent().children(".nofile_name").text(filename.replace(/C:\\fakepath\\/i, ''));
                }
            });
            if ((currentPage == 'coach-profile' || currentPage == 'coach-timeline' || currentPage == 'coach-media' || currentPage == 'team-profile' || currentPage == 'player-profile') && urlSegment != '') {
                getMutualFriendList();
            }
        });


        $(document).ready(function (e) {
            var checkStatus = '{{ checkApplyPendingStatus() }}';
            if (checkStatus > 0) {
                $('#confirmJobApply').modal('show');
            }
        });

        function changeAppliedStatus(status) {
            showButtonLoader('confirmStatus', 'SAVE', 'disable');
            $.post('{{ url("change-applied-status") }}', {_token: token, status: status}, function (data) {
                if (data.success && data.message != '') {
                    toastr.success(data.message);
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                } else if (data.success && data.message == '') {
                    location.reload();
                } else {
                    toastr.error(data.message);
                    location.reload();
                }
            });
        }

        /*** End    **/

        // get all coach news
        function getCoachNews() {
            var url = "{{ url('coach/get-coach-counts') }}";
            $.ajax({type: "GET",
                dataType: 'JSON',
                url: url,
                success: function (response) {
                    $('.newsheading #newsBulletin').html('<span>' + response.newsBulletin + '</span>');
                },
                error: function () {
                    getCoachNews();
                }
            });
        }

</script>
<script src="{{ url('public/js/common/social-share.js') }}"></script>
<script src="{{ url('public/js/common/mutual-friend-list.js') }}"></script>