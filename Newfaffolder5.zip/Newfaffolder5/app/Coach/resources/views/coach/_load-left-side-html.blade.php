<div class="lefttoggle_btn ">
    <a href="javascript:void(0);"></a>
</div>
<div class="inner_section">
    @if(($page == 'dashboard') || ($page == 'coach-timeline'))

    <div class="profile_section coach">
        <div class="profile_info text-center">
            <img src="{{ checkUserImage($user->profile_image, 'coach/thumb') }}" class="userprofile" alt="user profile">
            <h2 class="text-uppercase">{{$user->first_name}}  {{$user->last_name}}</h2>
            <h3 class="text-capitalize sign">{{!empty($user->signature)?$user->signature:'-'}}</h3>
            <span class="text-uppercase team">{{ $user->role }}</span>
            <span class="text-uppercase about">{{getLimitText(10,getPositionName($user->position_id))}}</span>
            <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'medium') }}" class="flag mt-3" alt="american flag">
            <span class="cityname">{{!empty($user->country->name) ? $user->country->name : '-'}} <br>{{!empty($user->state->state_name) ? $user->state->state_name : '-'}}, {{$user->city}}</span>
        </div>
        <div class="text-center">
            <div class="work-mode mt-md-4 mt-2 {{ (checkUserEventStatus($user->id) == 'available') ? 'active' : '' }}" id="work_mode">
                <h3>WORK MODE</h3>
                <h3 class="available">AVAILABLE MODE</h3>
                <div class="social-media">
                    <ul class="list-inline text-center">
                        <li class="list-inline-item power">
                            <a href="javascript:void(0);" id="workmode_btn">
                                @if(checkUserEventStatus($user->id) == 'available')
                                <img src="{{ url('public/images/power-btn-green.png') }}" alt="green btn" style="display: block"/>
                                @else
                                <img src="{{ url('public/images/power-btn.png') }}" alt="red btn" style="display: block"/>
                                @endif
                            </a>
                        </li>
                        @if(checkUserConnect($user->id) == 'pending')
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="disabled_icon">
                                <div class="hexa-box">
                                    <span class="flaticon-user-pending"></span>
                                </div>
                            </a>
                        </li>
                        @elseif(checkUserConnect($user->id) == 'accept')
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="disabled_icon">
                                <div class="hexa-box">
                                    <span class="flaticon-user-accpet"></span>
                                </div>
                            </a>
                        </li>
                        @elseif(checkUserEventStatus($user->id) == 'available' && $user->id != Auth::guard(getAuthGuard())->user()->id)
                        <li class="list-inline-item" id="add-user-connection-1">
                            <a href="javascript:void(0);" class="active" onclick='userConnection("{{$user->id}}", "connect", this)' title="Friend Request">
                                <div class="hexa-box">
                                    <span class="flaticon-user-add"></span>
                                </div>
                            </a>
                        </li>
                        @else
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="disabled_icon" title="Friend Request">
                                <div class="hexa-box">
                                    <span class="flaticon-user-add"></span>
                                </div>
                            </a>
                        </li>
                        @endif
                        @if(checkUserEventStatus($user->id) == 'available' && $user->id != Auth::guard(getAuthGuard())->user()->id)
                        <li class="list-inline-item center-item">
                            <a href="javascript:void(0);" onclick="followPlayer('{{ $user->id }}')" id="follow-profile-events" title="Subscribe" class="{{ (checkProfileEvents($user->id, 'follow') != 0) ? 'active' : 'inactive' }}">
                                <div class="hexa-box">
                                    <span class="icon-wi-fi-signal"></span>
                                </div>
                            </a>
                        </li>
                        @else 
                        <li class="list-inline-item center-item">
                            <a href="javascript:void(0);" class="disabled_icon" title="Subscribe">
                                <div class="hexa-box">
                                    <span class="icon-wi-fi-signal"></span>
                                </div>
                            </a>
                        </li>
                        @endif
                        @if(checkUserConnect($user->id) == 'accept' && checkUserEventStatus($user->id) == 'available' && $user->id != Auth::guard(getAuthGuard())->user()->id)
                        <li class="list-inline-item">
                            <a href="{{ url(getAuthGuard().'/messages') }}" class="active" title="Message">
                                <div class="hexa-box">
                                    <span class="icon-email_icon"></span>
                                </div>
                            </a>
                        </li>
                        @else
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="disabled_icon" title="Message">
                                <div class="hexa-box">
                                    <span class="icon-email_icon"></span>
                                </div>
                            </a>
                        </li>
                        @endif
                    </ul>
                </div>
            </div>
            <div class="globel_map">
                <div id="earth_div"></div>
            </div> 
        </div>

        <div class="yourmedia">
            <div class="inner_media">
                <h3 class="text-uppercase">your media </h3>
                <div class="video">
                    <div class="row custom_grid">
                        @if(!empty($mediaList) && count($mediaList) > 0)
                        @foreach($mediaList as $key => $userMedia)
                        @if($key == 0 || $key == 1)
                        @if(count($mediaList) <= 2 || count($mediaList) >= 2 && $key == 0)
                        <div class="col">
                            <a href="javascript:void(0);" class="first_img">
                                <img src="{{ checkMediaByType($userMedia->media, $user->role, $userMedia->media_type, 'left-media-thumb') }}" class="img-fluid"  alt="post img">
                            </a>
                        </div>
                        @endif
                        @endif
                        @if(count($mediaList) > 2 && $key > 0 && $key < 2)
                        <div class="w-100"></div>
                        @endif
                        @if($key == 1 && count($mediaList) > 2)
                        <div class="col-6">
                            <a href="javascript:void(0);" class="thumb_img">
                                <img src="{{ checkMediaByType($userMedia->media, $user->role, $userMedia->media_type, 'left-media-thumb') }}" class="img-fluid"  alt="post img">
                            </a>
                        </div>
                        @endif
                        @if($key == 2)
                        <div class="col-6">
                            @php
                            if($user->id == Auth::guard(getAuthGuard())->user()->id){
                            $url = url('coach/coach-media');  
                            }else{
                            $url = url($user->role.'/'.$user->role.'-media/'.$user->slug);  
                            }
                            @endphp
                            <a href="{{ $url }}" class="video_viewmore d-flex align-self-center justify-content-center"> <span> + {{ count($mediaList) - 2 }} </span></a>
                        </div>
                        @endif
                        @endforeach
                        @else 
                        <div class="col">
                            <a href="javascript:void(0);" class="first_img">
                                <img src="{{ url('public/images/default-media.jpg') }}" class="img-fluid"  alt="post img">
                            </a>
                        </div>
                        @endif   
                    </div>
                </div>
                <div class="user_video">
                    <ul class="list-inline text-center">
                        @if(!empty($mediaList)  && count($mediaList) > 2)
                        @foreach($mediaList as $key => $userMedia) 
                        @if($key < 6)
                        <li class="list-inline-item">
                            <a href="javascript:void(0);">
                                <img src="{{ checkMediaByType($userMedia->media, $user->role, $userMedia->media_type, 'left-media-thumb') }}" alt="">
                            </a>
                        </li>
                        @endif
                        @endforeach
                        @endif
                    </ul>
                    @if(count($mediaList) - 6 > 0 )
                    <div class="viewmore text-center">
                        @php
                        if($user->id == Auth::guard(getAuthGuard())->user()->id){
                        $url = url('coach/coach-media');  
                        }else{
                        $url = url($user->role.'/'.$user->role.'-media/'.$user->slug);  
                        }
                        @endphp
                        <a href="{{ $url }}">
                            <strong>+ {{ count($mediaList) - 6 }}</strong> <br><span> VIEW ALL</span>
                        </a>
                    </div>
                    @endif
                </div>
            </div>
        </div>

    </div>
    <div class="facebook_post">
        <!--<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FFreeAgentFootball&tabs=timeline&width=268&height=1646&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=1664434403824350" width="268" height="1646" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>-->

        <div class="fb-page" data-href="https://www.facebook.com/FreeAgentFootball" data-tabs="timeline" data-width="268" data-height="1646" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/FreeAgentFootball" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/FreeAgentFootball">FreeAgentFootball.com</a></blockquote></div>
    </div>
    @elseif(($page == 'coach-profile') || ($page == 'other-coach-profile') || ($page == 'coach-media'))
    <div class="profile_section short-bg">
        <div class="profile_info text-center">
            <img src="{{ checkUserImage($user->profile_image, 'coach/thumb') }}" class="userprofile" alt="user profile">
            @if($page == 'coach-profile')
            <div class="edit_icon">
                <a href="{{ url('coach/coach-profile-form') }}">
                    <i class="fas fa-edit"></i>
                </a>
            </div>
             @endif
            <h2 class="text-uppercase">{{$user->first_name}}  {{$user->last_name}}</h2>
            <h3 class="text-capitalize sign">{{ $user->signature }}</h3>
            <span class="text-uppercase team">{{ $user->role }}</span> 
            <span class="text-uppercase about">{{getLimitText(10,getPositionName($user->postion_id))}}</span>
            <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'medium') }}" class="flag mt-3" alt="american flag">
            <span class="cityname">{{!empty($user->country->name) ? $user->country->name : '-'}} <br> {{$user->city}}, {{!empty($user->state->state_name) ? $user->state->state_name : '-'}}</span>
        </div>
        <div class="globel_view text-center">
            <div class="work-mode {{ (checkUserEventStatus($user->id) == 'available') ? 'active' : '' }}" id="work_mode">
                <h3>WORK MODE</h3>
                <h3 class="available">AVAILABLE MODE</h3>
                <div class="social-media">
                    <ul class="list-inline text-center">
                        <li class="list-inline-item power">
                            <a href="javascript:void(0);" @php echo ($user->id == Auth::guard(getAuthGuard())->user()->id) ? 'id="workmode_btn"' : '' @endphp>
                               @if(checkUserEventStatus($user->id) == 'available')
                               <img src="{{ url('public/images/power-btn-green.png') }}" alt="green btn" style="display: block"/>
                                @else
                                <img src="{{ url('public/images/power-btn.png') }}" alt="red btn" style="display: block"/>
                                @endif
                            </a>
                        </li>
                        @if(checkUserConnect($user->id) == 'pending')
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="disabled_icon">
                                <div class="hexa-box">
                                    <span class="flaticon-user-pending"></span>
                                </div>
                            </a>
                        </li>
                        @elseif(checkUserConnect($user->id) == 'accept')
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="disabled_icon">
                                <div class="hexa-box">
                                    <span class="flaticon-user-accpet"></span>
                                </div>
                            </a>
                        </li>
                        @elseif(checkUserEventStatus($user->id) == 'available' && $user->id != Auth::guard(getAuthGuard())->user()->id)
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick='userConnection("{{$user->id}}", "connect", this)'>
                                <div class="hexa-box">
                                    <span class="flaticon-user-add"></span>
                                </div>
                            </a>
                        </li>
                        @else
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="disabled_icon">
                                <div class="hexa-box">
                                    <span class="flaticon-user-add"></span>
                                </div>
                            </a>
                        </li>
                        @endif
                        @if(checkUserEventStatus($user->id) == 'available' && $user->id != Auth::guard(getAuthGuard())->user()->id)
                        <li class="list-inline-item center-item">
                            <a href="javascript:void(0);" onclick="followPlayer('{{ $user->id }}')" id="follow-profile-events" class="{{ (checkProfileEvents($user->id, 'follow') != 0) ? 'active' : 'inactive' }}">
                                <div class="hexa-box">
                                    <span class="icon-wi-fi-signal"></span>
                                </div>
                            </a>
                        </li>
                        @else 
                        <li class="list-inline-item center-item">
                            <a href="javascript:void(0);" class="disabled_icon">
                                <div class="hexa-box">
                                    <span class="icon-wi-fi-signal"></span>
                                </div>
                            </a>
                        </li>
                        @endif
                        @if(checkUserConnect($user->id) == 'accept' && checkUserEventStatus($user->id) == 'available' && $user->id != Auth::guard(getAuthGuard())->user()->id)
                        <li class="list-inline-item">
                            <a href="{{ url('team/messages') }}">
                                <div class="hexa-box">
                                    <span class="icon-email_icon"></span>
                                </div>
                            </a>
                        </li>
                        @else
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="disabled_icon">
                                <div class="hexa-box">
                                    <span class="icon-email_icon"></span>
                                </div>
                            </a>
                        </li>
                        @endif
                    </ul>
                </div>
            </div>
        </div>
        <div class="globel_map">
            <div id="earth_div"></div>
        </div> 
    </div>
    @elseif($page == 'jobs') <!-- job list left side -->
    <div class="left-filter">
        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" onclick="clearForm('playerForm')" id="player-tab" data-toggle="pill" href="#player" role="tab" aria-controls="player-tab" aria-selected="true">PLAYER</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" onclick="clearForm('staffForm')" id="staff-tab" data-toggle="pill" href="#staff" role="tab" aria-controls="staff-tab" aria-selected="false">STAFF and PERSONNEL</a>
            </li>
        </ul>
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="player" role="tabpanel" aria-labelledby="player-tab">
                <form id="jobForm" method="post" action="javascript:void(0);">
                    <div class="filter-content">
                        <div class="filter-head">
                            <h2>FILTERS</h2>
                        </div>
                        <div class="content-in">
                            <div class="head-in">
                                <h4>PLAYERS POSITIONS</h4>
                            </div>
                            <div class="player-position">
                                @php
                                $positions = getUserByPositions('player');
                                @endphp
                                <ul class="list-unstyled">
                                    @if(count($positions)>0)
                                    <li>
                                        @foreach($positions as $key => $position)
                                        @if($key % 2 == 0)
                                        <label for="c{{$key}}">
                                            <input type="checkbox" name="position[]" id="c{{$key}}" hidden value="{{$position->id}}">
                                            <span>{{$position->name}}</span>
                                        </label>
                                        @else
                                        <label for="g{{$key}}">
                                            <input id="g{{$key}}" name="position[]" type="checkbox" hidden value="{{$position->id}}">
                                            <span>{{$position->name}}</span>
                                        </label>
                                        @endif
                                        @endforeach
                                    </li>
                                    @else
                                    <div class="alert alert-danger">record not found</div>
                                    @endif
                                </ul>
                            </div>
                            <div class="location common-field common-padding">
                                <div class="head-in">
                                    <h4>Select Country</h4>
                                </div>
                                <div class="form-group">
                                    <select class="selectpicker form-control" name="country" id="country" title="Select Country" data-size="4">
                                    </select>
                                </div>
                                <div class="head-in">
                                    <h4>Select State</h4>
                                </div>
                                <div class="form-group">
                                    <select class="selectpicker form-control" name="state" id="state" title="Select State" data-size="4">
                                    </select>
                                </div>
                                <div class="head-in">
                                    <h4>Select City</h4>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="job_city" placeholder="Search by City">
                                </div>
                                <div class="head-in">
                                    <h4>SALARY ($)</h4>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-xl-6 mb-3 mb-xl-0">
                                            <input type="text" name="salary_from" id="fromSalary" class="form-control" placeholder="From" maxlength="10">
                                        </div>
                                        <div class="col-xl-6">
                                            <input type="text" name="salary_to" class="form-control" id="toSalary" placeholder="To" maxlength="10">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="benefits">
                                <div class="head-in">
                                    <h4>BENEFITS</h4>
                                </div>
                                @php
                                $benefits = getBenefitsByJob();
                                @endphp
                                <ul class="list-unstyled" data-mcs-theme="dark">
                                    @if(count($benefits)>0)
                                    @foreach($benefits as $key => $benefit)
                                    <li>
                                        <input type="checkbox" name="benefits[]" value="{{$benefit->id}}" hidden id="{{$benefit->title}}{{$key}}">
                                        <label for="{{$benefit->title}}{{$key}}">
                                            <span class="d-block">{{$benefit->title}}</span>
                                        </label>
                                    </li>
                                    @endforeach
                                    @endif
                                </ul>
                            </div>
                            <div class="registered common-field common-padding">
                                <div class="head-in">
                                    <h4>DATE</h4>
                                </div>
                                <div class="form-group">
                                    <div class="input-field filter_date mb-3">
                                        <input type="text" name="startDate" class="form-control datetimepicker-input" id="startDate1" data-toggle="datetimepicker" data-target="#startDate1" placeholder="From Date" />
                                        <i class="flaticon-calendar"></i>
                                    </div>
                                    <div class="input-field filter_date">
                                        <input type="text" name="endDate" class="form-control datetimepicker-input" id="endDate1" data-toggle="datetimepicker" data-target="#endDate1" placeholder="To Date" />
                                        <i class="flaticon-calendar"></i>
                                    </div>
                                </div>
                                <div class="head-in">
                                    <h4>REGISTERED</h4>
                                </div>
                                <div class="form-group registered mb-0">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <input type="checkbox" name="register_time[]" id="24hrs01" hidden value="1">
                                            <label for="24hrs01" class="mb-3">
                                                24 Hours
                                            </label>
                                        </div>
                                        <div class="col-sm-6"> 
                                            <input type="checkbox" name="register_time[]" id="48hrs01" hidden value="2">
                                            <label for="48hrs01" class="mb-3">
                                                48 Hours
                                            </label>
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="checkbox" name="register_time[]" id="week01" hidden value="7">
                                            <label for="week01" class="mb-3">
                                                WEEK
                                            </label>
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="checkbox" name="register_time[]" id="month01" hidden value="30">
                                            <label for="month01" class="mb-3">
                                                MONTH
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="filter_bottom d-flex justify-content-between">
                            <a class="btn btn-secondary" href="javascript:void(0)" id="applyBtn" onclick="getJobList('', 'first', 'playerForm')">APPLY</a>
                            <a class="btn btn-secondary" href="javascript:void(0)" onclick="clearForm('playerForm')">CLEAR</a>
                        </div>
                    </div>
                </form>
            </div>
            <div class="tab-pane fade " id="staff" role="tabpanel" aria-labelledby="staff-tab">
                <form id="jobForm1" method="post" action="javascript:void(0);">
                    <div class="filter-content">
                        <div class="filter-head">
                            <h2>FILTERS</h2>
                        </div>
                        <div class="content-in">
                            <div class="head-in">
                                <h4>POSITIONS AREAS</h4>
                            </div>
                            <div class="position-area">
                                @php
                                $positions = getUserByPositions('coach');
                                @endphp
                                <ul class="list-unstyled">
                                    @if(count($positions)>0)
                                    @foreach($positions as $key => $position)
                                    <li>
                                        <input type="checkbox" name="position[]" id="area{{$key}}" hidden value="{{$position->id}}">
                                        <label for="area{{$key}}">{{$position->name}}</label>
                                    </li>  
                                    @endforeach
                                    @endif
                                </ul>
                            </div>
                            <div class="location common-field common-padding">
                                <div class="head-in">
                                    <h4>Select Country</h4>
                                </div>
                                <div class="form-group">
                                    <select class="selectpicker form-control" name="country" id="country1" title="Select Country" data-size="4">
                                    </select>
                                </div>
                                <div class="head-in">
                                    <h4>Select State</h4>
                                </div>
                                <div class="form-group">
                                    <select class="selectpicker form-control" name="state" id="state1" title="Select State" data-size="4">
                                    </select>
                                </div>
                                <div class="head-in">
                                    <h4>Select City</h4>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="job_city" placeholder="Search by City">
                                </div>
                                <div class="head-in">
                                    <h4>SALARY ($)</h4>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-xl-6 mb-3 mb-xl-0">
                                            <input type="text" name="salary_from" id="fromSalarystaff" class="form-control" placeholder="From" maxlength="10">
                                        </div>
                                        <div class="col-xl-6">
                                            <input type="text" name="salary_to" id="toSalarystaff" class="form-control" placeholder="To" maxlength="10">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="benefits">
                                <div class="head-in">
                                    <h4>BENEFITS</h4>
                                </div>
                                @php
                                $benefits = getBenefitsByJob();
                                @endphp
                                <ul class="list-unstyled">
                                    @if(count($benefits)>0)
                                    @foreach($benefits as $key => $benefit)
                                    <li>
                                        <input type="checkbox" name="benefits[]" value="{{$benefit->id}}" hidden id="{{$benefit->title}}{{$key + 1}}">
                                        <label for="{{$benefit->title}}{{$key + 1}}">
                                            <span class="d-block">{{$benefit->title}}</span>
                                        </label>
                                    </li>
                                    @endforeach
                                    @endif
                                </ul>
                            </div>
                            <div class="registered common-field common-padding">
                                <div class="head-in">
                                    <h4>DATE</h4>
                                </div>
                                <div class="form-group">
                                    <div class="form-group">
                                        <div class="input-field filter_date mb-3">
                                            <input type="text" name="startDate" class="form-control datetimepicker-input" id="startDate2" data-toggle="datetimepicker" data-target="#startDate2" placeholder="From Date" />
                                            <i class="flaticon-calendar"></i>
                                        </div>
                                        <div class="input-field filter_date">
                                            <input type="text" name="endDate" class="form-control datetimepicker-input" id="endDate2" data-toggle="datetimepicker" data-target="#endDate2" placeholder="To Date" />
                                            <i class="flaticon-calendar"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="head-in">
                                    <h4>REGISTERED</h4>
                                </div>
                                <div class="form-group registered mb-0">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <input type="checkbox" name="register_time[]" id="24hrs02" hidden value="1">
                                            <label for="24hrs02" class="mb-3">
                                                24 Hours
                                            </label>
                                        </div>
                                        <div class="col-sm-6"> 
                                            <input type="checkbox" name="register_time[]" id="48hrs02" hidden value="2">
                                            <label for="48hrs02" class="mb-3">
                                                48 Hours
                                            </label>
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="checkbox" name="register_time[]" id="week02" hidden value="7">
                                            <label for="week02" class="mb-3">
                                                WEEK
                                            </label>
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="checkbox" name="register_time[]" id="month02" hidden value="30">
                                            <label for="month02" class="mb-3">
                                                MONTH
                                            </label>
                                        </div>
                                    </div>
                                </div>                            
                            </div>
                        </div>
                        <div class="filter_bottom d-flex justify-content-between">
                            <a class="btn btn-secondary" href="javascript:void(0)" id="applyBtn1" onclick="getJobList('', 'first', 'staffForm')">APPLY</a>
                            <a class="btn btn-secondary" href="javascript:void(0)" onclick="clearForm('staffForm')">CLEAR</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>       
    @elseif($page == 'events')
    <div class="lefttoggle_btn ">
        <a href="javascript:void(0);"></a>
    </div>
    <div class="inner_section">
        <div class="left-filter">
            <div class="filter-content">
                <div class="filter-head">
                    <div class="text-center">
                        <h2 class="mb-0">FILTERS</h2>
                    </div>
                </div>
                <form id="eventFrorm" method="post" action="javascript:void(0);">
                    <div class="content-in">
                        <div class="filter">
                            <div class="filter-form">
                                <div class="form-group">
                                    <label>Search by Name</label>
                                    <input class="form-control" name="event_name" placeholder="Search by Name">
                                </div>

                                <div class="form-group">
                                    <label>Search by City</label>
                                    <input class="form-control" name="event_city" placeholder="Search by City">
                                </div>
                                <div class="form-group">
                                    <label>From Date</label>
                                    <div class="input-field filter_date">
                                        <input type="text" name="startDate" class="form-control datetimepicker-input" id="datetimepicker" data-toggle="datetimepicker" data-target="#datetimepicker" placeholder="From Date" />
                                        <i class="flaticon-calendar"></i>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>To Date</label>
                                    <div class="input-field filter_date">
                                        <input type="text" name="endDate" class="form-control datetimepicker-input" id="datetimepicker01" data-toggle="datetimepicker" data-target="#datetimepicker01" placeholder="To Date" />
                                        <i class="flaticon-calendar"></i>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Posted By </label>
                                    <select class="form-control selectpicker" name="posted_by" id="posted_by" title="Select" data-size="4">
                                        <option value="player">Player</option>
                                        <option value="coach">Coach</option>
                                        <option value="team">Team</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="filter_bottom d-flex justify-content-between">
                        <a class="btn btn-secondary" href="javascript:void(0)" id="applyBtn" onclick="getEvents()">APPLY</a>
                        <a class="btn btn-secondary" href="javascript:void(0)" onclick="clearForm()">CLEAR</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="btm-logo">
        <div class="logo-in">
            <img src="{{ url('public/images/frames-bg/jobdtl-left-logo.png') }}" class="img-fluid" alt="logo">
        </div>
    </div>
    @else
    <!--  for member you may know page   --> 
    <div class="left-filter">
        <div class="filter-content">
            <div class="filter-head">
                <div class=" text-center">
                    <h2 class="mb-0">FILTERS</h2>
                </div>
            </div>
            <form id="coachMemberForm">
                {{ csrf_field() }}
                @if(!empty($slug))
                <input type="hidden" name="id" value="{{ getUserIdBySlug($slug) }}">
                @else
                <input type="hidden" name="id" value="">
                @endif
                <div class="content-in">
                    <div class="filter">
                        <div class="filter-form">
                            <div class="form-group">
                                <label>Search by Name</label>
                                <input name="full_name" id="full_name" class="form-control" placeholder="Search by Name">
                            </div>

                            <div class="form-group">
                                <label>Select User Role</label>
                                <select name="member_type" id="member_type" class="form-control selectpicker" title="Select">
                                    <option value="team">Team</option>
                                    <option value="coach">Coach</option>
                                    <option value="player">Player</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Search by City</label>
                                <input name="city" id="city" class="form-control" placeholder="Search by City">
                            </div>

                        </div>
                    </div>
                </div>
                <div class="filter_bottom d-flex justify-content-between">
                    @if($page == 'connection_list')
                    <a class="btn btn-secondary" href="javascript:void(0)" id="applyBtn" onclick="getConnectionList();">APPLY</a><!--- getConnectionList() is defined in my-connection  blade  --->
                    @elseif ($page == 'friend_request_list')
                    <a class="btn btn-secondary" href="javascript:void(0)" id="applyBtn" onclick="friendRequestList();">APPLY</a><!--- friendRequestList() is defined in my-friend-request  blade  --->
                    @else
                    <a class="btn btn-secondary" href="javascript:void(0)" id="applyBtn" onclick="getMemberList();">APPLY</a>
                    @endif
                    <a class="btn btn-secondary" href="javascript:void(0)" onclick="clearForm()">CLEAR</a>
                </div>
            </form>
        </div>
    </div>
    <div class="btm-logo">
        <div class="logo-in">
            <img src="{{url('public/images/frames-bg/jobdtl-left-logo.png')}}" class="img-fluid" alt="logo">
        </div>
    </div>
    @endif
</div>
@php
$latlong = getLatLangByAddress(!empty($user->country->name) ? $user->country->name : 'USA');
$lat = $latlong['lat'];
$long = $latlong['long'];
@endPhp
<script>

    // get all country
    $(document).ready(function () {
    $('#datetimepicker, #datetimepicker01, #startDate1, #startDate2, #endDate1, #endDate2').datetimepicker({
    useCurrent: false,
            format: "L",
            minDate: new Date().setHours(0, 0, 0, 0),
            ignoreReadonly: true,
    });
    $("#datetimepicker").on("change.datetimepicker", function (e) {
    $('#datetimepicker01').datetimepicker('minDate', e.date);
    });
    $("#datetimepicker01").on("change.datetimepicker", function (e) {
    $('#datetimepicker').datetimepicker('maxDate', e.date);
    });
    $("#startDate1").on("change.datetimepicker", function (e) {
    $('#endDate1').datetimepicker('minDate', e.date);
    });
    $("#endDate1").on("change.datetimepicker", function (e) {
    $('#startDate1').datetimepicker('maxDate', e.date);
    });
    $("#startDate2").on("change.datetimepicker", function (e) {
    $('#endDate2').datetimepicker('minDate', e.date);
    });
    $("#endDate2").on("change.datetimepicker", function (e) {
    $('#startDate2').datetimepicker('maxDate', e.date);
    });
    $.post("{{ url('get-all-country') }}", {_token: "{{ csrf_token() }}", type: ""}, function (data) {
    $('#country').html(data);
    $('#country').selectpicker('refresh');
    });
// get state by country id
    $(document).on('change', '#country', function () {
    $.post("{{ url('get-state-by-country-id') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: ""}, function (data) {
    $('#state').html(data);
    $('#state').selectpicker('refresh');
    });
    });
    $.post("{{ url('get-all-country') }}", {_token: "{{ csrf_token() }}", type: ""}, function (data) {
    $('#country1').html(data);
    $('#country1').selectpicker('refresh');
    });
// get state by country id
    $(document).on('change', '#country1', function () {
    $.post("{{ url('get-state-by-country-id') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: ""}, function (data) {
    $('#state1').html(data);
    $('#state1').selectpicker('refresh');
    });
    });
    });
    // Change work mode.
    $(document).ready(function () {
    $("#workmode_btn").click(function () {
    $.get("{{ url('coach/work-mode') }}", function(data){
    if (data.success){
    if (data.workmode == 'available'){
    $("#workmode_btn").html("<img src={{ url('public/images/power-btn-green.png') }} alt='green btn' style='display:block'/>");
    $("#workmode_btn").parent().parent().parent().parent().addClass('active');
    $("#workmode_btn").parent().parent().parent().parent().removeClass('inactive');
    } else{
    $("#workmode_btn").html("<img src={{ url('public/images/power-btn.png') }} alt='red btn' style='display:block'/>");
    $("#workmode_btn").parent().parent().parent().parent().addClass('inactive');
    $("#workmode_btn").parent().parent().parent().parent().removeClass('active');
    }
    message('success', data.message);
    } else{
    message('error', data.message);
    }
    });
    });
    });
    // globe function
    function initialize() {
    earth = new WE.map('earth_div', {
    zoom: 0,
            scrollWheelZoom: false
    });
    var lat = '<?php echo $lat ?>';
    var long = '<?php echo $long ?>';
    earth.setView(['<?php echo $lat ?>', '<?php echo $long ?>'], custom_setview
            );
    WE.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    // attribution: '© OpenStreetMap contributors'
    }).addTo(earth);
//        var marker = WE.marker([51.5, -0.09]).addTo(earth);
//        marker.bindPopup("<b>Hello world!</b><br>I am a FAF.<br /><span style='font-size:10px;color:#999'>Tip: Another popup is hidden..</span>", {maxWidth: 150, closeButton: true});

    var marker2 = WE.marker([lat, long]).addTo(earth);
    marker2.bindPopup("<b class='text-center'><?php echo $user->address_line_1 ?></b>", {maxWidth: 120, closeButton: true});
    // Start a simple rotation animation
    var before = null;
    requestAnimationFrame(function animate(now) {
    var c = earth.getPosition();
    var elapsed = before? now - before: 0;
    before = now;
    earth.setCenter([c[0], c[1] + 0.1 * (elapsed / 30)]);
    requestAnimationFrame(animate);
    });
    }

    function followPlayer(toId){
    var url = "{{ url('/follow-user')}}";
    $.ajax({type: "GET", url: url, data:{to_id:  toId},
            success: function (response) {
            if (response.event == 'follow'){
            $('#follow-profile-events').attr('class', 'active');
            } else if (response.event == 'unfollow'){
            $('#follow-profile-events').attr('class', 'inactive');
            }
            },
    });
    }

    function userConnection(toId, type, obj){
    var url = "{{ url('/user-connection')}}";
    $.ajax({
    type: "POST",
            url: url,
            data:{_token: '{{ csrf_token() }}', id: toId, type: type},
            success: function (response) {
            if (response.success) {
            $(obj).parent().html('<a href="javascript:void(0);" class="disabled_icon" ><div class="hexa-box"><span class="flaticon-user-pending"></span></div></a>')
                    message('success', response.message);
            } else {
            message('error', response.message);
            }
            },
    });
    }



</script>