@extends('coach::layouts.app')
@section('content')
<link rel="stylesheet" href="{{ url('public/css/jquery.fancybox.min.css') }}" type="text/css">
<main class="main-content ">
    <div id="pro-card">
        <section class="top-section">
            <!--  left side -->
            <aside class="left_section " id="left-side-html">
                <!-- Left side html render -->
            </aside>

            <!-- xxxxxxxxx -->

            <div class="middle_section">
                <div class="container-fluid">
                    <div class="news_point">
                        <div class="inner">
                            <div class="newsheading">
                                <p><span class="headingtag">NEWS</span></p> <div class="newsline"><span id="newsBulletin"></span></div>
                                <a href="{{ url('/news-details') }}">(READ MORE)</a>
                            </div>
                            <div class="news_tag" id="divCoachCounts">

                            </div>
                        </div>
                    </div>
                    <!-- xxxxxx --> 
                    <div id="divVideoUserViews">
                    </div>
                </div>
            </div>

            <!-- right side -->
            <aside class="right_section" id="right-side-html">
                <!-- Right side html render -->
            </aside>
        </section>

        <!-- xxxxxxxxx -->

        <section class="compare-profile">
            <div class="container-fluid">
                <div class="compare-row d-flex align-items-end">
                    <div class="left-sec">
                        <img src="{{ url('public/images/frames-bg/compare-profile-left-corner.png') }}" alt="compare-profile-row-bg" class="img-fluid">
                    </div>
                    <div class="center-sec">
                        <div class="center">
                            <a href="{{url('view/compare')}}"><h2 class="heading-24 color-white text-uppercase">compare profile</h2></a>
                        </div>
                    </div>
                    <div class="right-sec">
                        <h2 class="text-center">
                            <span class="text-uppercase">Profile LAST UPDATED</span> <br>
                            {{sameDate($user->updated_at)}}
                        </h2>
                    </div>
                </div>
            </div>
        </section>

        <!-- xxxxxxxxx -->

        <section class="compare_profile">
            <div class="left">
                <div class="about_us">
                    <div class="heading text-center">
                        <div class="icon">
                            <img src="{{ url('public/images/about_icon.png') }}" alt="icon">
                        </div>
                        <h3 class="heading-24">ABOUT</h3>
                        <div class="edit_icon">
                            <a href="{{url('coach/coach-profile-form')}}" oncontextmenu="onRightClickMenu('step-form-about')" onclick='coachProfileForm("step-form-about");'>
                                <i class="fas fa-edit"></i>
                            </a>
                        </div>
                    </div>
                    <ul class="list-unstyled">
                        <li>
                            <label>STATE / PROVINCE</label>
                            <h4>{{!empty($user->state->state_name)? $user->state->state_name : '-' }}</h4>
                        </li>
                        <li>
                            <label>YEARS OF EXPERIENCE</label>
                            <h4>{{!empty($user->userGeneral->playing_exp) ? $user->userGeneral->playing_exp : '-'}}</h4>
                        </li>
                        <li>
                            <label>CURRENTLY UNDER CONTRACT</label>
                            <h4>{{ (!empty($user->userGeneral->under_contract) && $user->userGeneral->under_contract != '' && ucfirst($user->userGeneral->under_contract)=='Yes') ? 'Yes'  : 'No'}}</h4>
                        </li>
                        <li>
                            <label>LOOKING TO SIGN</label>
                            <h4>{{ (!empty($user->userGeneral->look_to_sign) && $user->userGeneral->look_to_sign != '' && ucfirst($user->userGeneral->look_to_sign)=='Yes') ?  'Yes' : 'No'}}</h4>
                        </li>
                        <li>
                            <label>CURRENT TEAM</label>
                            <h4>{{ !empty($user->userGeneral->current_team) ?  ucfirst($user->userGeneral->current_team) : '-'}}</h4>
                        </li>
                        <li>
                            <label>CURRENT LEAGUE or CONFERENCE</label>
                            <h4>{{!empty($user->userGeneral->current_league) ? ucfirst($user->userGeneral->current_league) : '-'}} </h4>
                        </li>
                        <li>
                            <label>FORMER TEAM</label>
                            <h4>{{!empty($user->userGeneral->former_team) ? ucfirst($user->userGeneral->former_team) : '-'}}</h4>
                        </li>
                        <li>
                            <label>FORMER LEAGUE or CONFERENCE</label>
                            <h4>{{!empty($user->userGeneral->former_league) ? ucfirst($user->userGeneral->former_league) : '-'}}</h4>
                        </li>
                        <li>
                            <label>PASSPORT READY</label>
                            <h4>{{!empty($user->userGeneral->passport) ? ucfirst($user->userGeneral->passport) : 'No'}}</h4>
                            <h4>{{!empty($user->userGeneral->country) ? $user->userGeneral->country->name : '-'}}</h4>
                        </li>
                        <li>
                            <label>NATIVE LANGUAGE</label>
                            <h4>{{!empty($user->userGeneral->nativeLanguage) ? ucfirst($user->userGeneral->nativeLanguage->language) : '-'}}</h4>
                        </li>
                        <li>
                            <label>SECONDARY LANGAGE</label>
                            <h4>{{!empty($user->userGeneral->secondaryLanguage) ? ucfirst($user->userGeneral->secondaryLanguage->language) : '-'}}</h4>
                        </li>
                        <li>
                            <label>PREP/COLLEGE EXPERIENCE</label>
                            <h4>@if(empty($user->userCollegeExperince[0])){{ 'No'}} @else {{ 'Yes'}} @endif </h4>
                            @if(!empty($user->userCollegeExperince[0]))
                            <h4>{{!empty($user->userCollegeExperince[0]) ? $user->userCollegeExperince[0]['experience_type'] : '-'}}</h4>
                            <h4>{{!empty($user->userCollegeExperince[0]) ? $user->userCollegeExperince[0]['from_year'] .'-'. $user->userCollegeExperince[0]['to_year'] : '-'}} </h4>   
                            @endif
                            @if(!empty($user->userCollegeExperince) && count($user->userCollegeExperince) > 1)
                            <div class="seeall_btn mt-1">
                                <a href="javascript:void(0);" class="btn btn-success btn-sm border-1" onclick="getExperienceList('college_experience')">SEE ALL</a>
                            </div>
                            @endif
                        </li>
                        <li>
                            <label>PRO EXPERIENCE</label>
                            <h4>@if(empty($user->userProExperince[0])){{ 'No'}} @else {{ 'Yes'}} @endif </h4>
                            @if(!empty($user->userProExperince[0]))
                            <h4>{{!empty($user->userProExperince) ? $user->userProExperince[0]['experience_type'] : '-'}}</h4>
                            <h4>{{ !empty($user->userProExperince) ? $user->userProExperince[0]['from_year'] .'-'. $user->userProExperince[0]['to_year'] : '-'}} </h4>   
                            @endif
                            @if(!empty($user->userProExperince) && count($user->userProExperince) > 1)
                            <div class="seeall_btn mt-1">
                                <a href="javascript:void(0);" class="btn btn-success btn-sm border-1" onclick="getExperienceList('user_pro')">SEE ALL</a>
                            </div>
                            @endif
                        </li>
                        <li>
                            <label>INTERNATIONAL EXPERIENCE</label>
                            <h4>@if(empty($user->userInternationalExperince[0])){{ 'No'}} @else {{ 'Yes'}} @endif </h4>
                            @if(!empty($user->userInternationalExperince[0]))
                            <h4>{{!empty($user->userInternationalExperince) ? getLevelName($user->userInternationalExperince[0]['experience_type']) : '-'}}</h4>
                            <h4> {{!empty($user->userInternationalExperince)  ?  $user->userInternationalExperince[0]['from_year'] .'-'. $user->userInternationalExperince[0]['to_year'] : '-'}} </h4>   
                            @endif
                            @if(!empty($user->userInternationalExperince) && count($user->userInternationalExperince) > 1)
                            <div class="seeall_btn mt-1">
                                <a href="javascript:void(0);" class="btn btn-success btn-sm border-1" onclick="getExperienceList('user_international')">SEE ALL</a>
                            </div>
                            @endif
                        </li>
                        <li>
                            <label>INDOOR EXPERIENCE</label>
                            <h4>@if(empty($user->userIndooreExperince[0])){{ 'No'}} @else {{ 'Yes'}} @endif </h4>
                            @if(!empty($user->userIndooreExperince[0]))
                            <h4>{{!empty($user->userIndooreExperince) ? getLevelName($user->userIndooreExperince[0]['experience_type']) : '-'}}</h4>
                            <h4>{{!empty($user->userIndooreExperince) ? $user->userIndooreExperince[0]['from_year'] .'-'.    $user->userIndooreExperince[0]['to_year'] : '-'}}</h4>
                            @endif
                            @if(!empty($user->userIndooreExperince) && count($user->userIndooreExperince) > 1)
                            <div class="seeall_btn mt-1">
                                <a href="javascript:void(0);" class="btn btn-success btn-sm border-1" onclick="getExperienceList('user_indoor')">SEE ALL</a>
                            </div>
                            @endif
                        </li>
                    </ul>
                </div>
            </div>
            <div class="middle_section02">
                <div class="container-fluid">
                    <div class="biography ml-auto mr-auto">
                        <div class="common_heading">
                            <h3 class="black black-lg">
                                BIOGRAPHY
                            </h3>
                        </div>
                        <p class="text-justify">{{!empty($user->bio) ? $user->bio : '-'}}</p>
                    </div>

                    <div class="experience-section">
                        <div class="common_heading">
                            <h3 class="black black-lg">
                                UPCOMING EVENTS
                            </h3>
                        </div>
                        <div class="row">
                            @if(count($upcoming_events)>0)
                            @foreach($upcoming_events as $event)
                            <div class="col-6 col-sm-4">
                                <a href="{{ url('/event/'.base64_encode($event->id)) }}">
                                    <div class="event_card">
                                        <p class="status">{{ date('m/d/Y', strtotime($event->start_date)) }}</p>
                                        <h6 class="title">{{getLimitText(10,$event->event_name)}}</h6>
                                        <div class="events_team d-flex justify-content-center text-center">
                                            <div class="team_box">
                                                <div class="img_box d-flex align-items-center">
                                                    @if (intval($event->team1))
                                                    <img src="{{ checkUserImage(getUserById($event->team1,'profile_image'), 'team') }}" alt="olaf-flag">
                                                    @else
                                                    <img src="{{ checkUserImage(getTeamLogo($event->team1), 'team') }}" alt="olaf-flag">
                                                    @endif
                                                </div>
                                                @if (intval($event->team1))
                                                <p class="mb-0">{{ getLimitText(5,getUserByEvents($event->team1)) }}</p>
                                                @else
                                                <p class="mb-0">{{ getLimitText(5,$event->team1) }}</p>
                                                @endif
                                            </div>
                                            <div class="vs">VS</div>
                                            <div class="team_box">
                                                <div class="img_box d-flex align-items-center">
                                                    @if (intval($event->team2))
                                                    <img src="{{ checkUserImage(getUserById($event->team2,'profile_image'), 'team') }}" alt="gac-flag">
                                                    @else
                                                    <img src="{{ checkUserImage(getTeamLogo($event->team2), 'team') }}" alt="gac-flag">
                                                    @endif
                                                </div>
                                                @if (intval($event->team2))
                                                <p class="mb-0">{{ getLimitText(5,getUserByEvents($event->team2)) }}</p>
                                                @else
                                                <p class="mb-0">{{ getLimitText(5,$event->team2) }}</p>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="info">
                                            <p class="label">Time</p>
                                            <p>{{ getTimeFormat($event->start_time) }} (EST)</p>
                                        </div>
                                        <div class="info">
                                            <p class="label">Location</p>
                                            <p>{{ getLimitText(20,$event->address1) }}</p>
                                        </div> 
                                        <div class="info">
                                            <p class="label">Website</p>
                                            <p class="url">{{ getLimitText(15,$event->ticket_url) }}</p>
                                        </div> 
                                        <div class="bottom_loader">
                                            <div class="border_loader">
                                                <div></div>
                                                <div></div>
                                                <div></div>
                                                <div></div>
                                                <div></div>
                                                <div></div>
                                                <div></div>
                                                <div></div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            @endforeach
                            @else
                            <div class="col-10 alert alert-danger text-center">No record found.</div>
                            @endif
                        </div>
                    </div>
                    <div class="validated_attributes pt-0">
                        <div class="common_heading">
                            <h3 class="black black-lg">
                                VALIDATED ATTRIBUTES
                            </h3>
                        </div>
                        <div class="frame-wrap">
                            <div class="inner-heading d-sm-flex justify-content-sm-between justi align-items-sm-center">
                                <h6 class="mb-sm-0">OFFENSIVE <br> COORDINATOR</h6>
                                <a href="javascript:void(0);" onclick="getAddSkillsPage()" class="mb-0">
                                    ADD A NEW SKILL</a>
                            </div>

                            <div class="left_loader">
                                <div class="border_loader">
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                </div>
                            </div>

                            <div class="right_loader">
                                <div class="border_loader">
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                </div>
                            </div>

                            <ul class="list-unstyled coordinator-list" id="coach_attribute_list">
                            </ul>
                            @if(count($user->coachAttributes)>0)
                            <p class="view-more text-center mb-0">
                                <a class="btn btn-success btn-sm border-1" href="javascript:void(0);" onclick="getAttributesList('view_more')">See ALL </a>
                            </p>
                            @endif
                        </div>
                    </div>
                </div>
            </div>

            <div class="right">
                <div class="social-connection">
                    <div class="social-block">
                        <div class="content">
                            <a class="twitter-timeline" data-width="341" data-height="300" href="https://twitter.com/fafproday?ref_src=twsrc%5Etfw">Tweets by fafproday</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                        </div>
                        <div class="right_loader">
                            <div class="border_loader">
                                <div></div>
                                <div></div>
                                <div></div>
                                <div></div>
                                <div></div>
                            </div>
                        </div>
                        <div class="left_loader">
                            <div class="border_loader">
                                <div></div>
                                <div></div>
                                <div></div>
                            </div>
                        </div>
                        <div class="social_caption">
                            <div class="social-icon">
                                <a href="javascript:void(0);"><img src="{{ url('public/images/twitter_icon.png') }}" alt="icon"></a>
                            </div>
                            <div class="social-name text-center">
                                <a href="javascript:void(0);" class="d-block">TWITTER</a>
                            </div>
                        </div>
                    </div>
                    <div class="social-block">
                        <div class="content">
                            <div class="fb-page" data-href="https://www.facebook.com/FreeAgentFootball" data-tabs="timeline" data-width="341" data-height="300" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/FreeAgentFootball" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/FreeAgentFootball">FreeAgentFootball.com</a></blockquote></div>
                            <!--<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FFreeAgentFootball&tabs=timeline&width=271&height=300&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=1664434403824350" width="271" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>-->

                        </div>
                        <div class="right_loader">
                            <div class="border_loader">
                                <div></div>
                                <div></div>
                                <div></div>
                                <div></div>
                                <div></div>
                            </div>
                        </div>
                        <div class="left_loader">
                            <div class="border_loader">
                                <div></div>
                                <div></div>
                                <div></div>
                            </div>
                        </div>
                        <div class="social_caption">
                            <div class="social-icon">
                                <a href="javascript:void(0);"><img src="{{ url('public/images/facebook_icon.png') }}" alt="icon"></a>
                            </div>
                            <div class="social-name text-center">
                                <a href="javascript:void(0);" class="d-block">FACEBOOK</a>
                            </div>
                        </div>
                    </div>
                    <div class="social-block">
                        <div class="content">
                            <div id="instgramPost" class="instgram_post mx-auto bg-white"></div>
                        </div>
                        <div class="social_caption">
                            <div class="social-icon">
                                <a href="javascript:void(0);"><img src="{{ url('public/images/instagram_icon.png') }}" alt="icon"></a>
                            </div>
                            <div class="social-name text-center">
                                <a href="javascript:void(0);" class="d-block">INSTAGRAM</a>
                            </div>
                        </div>


                    </div>
                    <!--                    <div class="social-block">
                                            <div class="content">
                                                                                                                        
                                            </div>
                                            <div class="right_loader">
                                                <div class="border_loader">
                                                    <div></div>
                                                    <div></div>
                                                    <div></div>
                                                    <div></div>
                                                    <div></div>
                                                </div>
                                            </div>
                                            <div class="left_loader">
                                                <div class="border_loader">
                                                    <div></div>
                                                    <div></div>
                                                    <div></div>
                                                </div>
                                            </div>
                                            <div class="social_caption">
                                                <div class="social-icon">
                                                    <a href="javascript:void(0);"><img src="{{ url('public/images/linkedin_icon.png') }}" alt="icon"></a>
                                                </div>
                                                <div class="social-name text-center">
                                                    <a href="javascript:void(0);" class="d-block">LINKEDIN</a>
                                                </div>
                                            </div>
                                        </div>-->
                </div>
            </div>
        </section>

        <!-- xxxxxxxxx -->

        <section class="thirdprofile_status secondprofile_status">
            <div class="container-fluid">
                <div class="compare-row d-flex align-items-end">
                    <div class="left-sec">
                        <div class="details">
                            <div class="imgdiv"> 
                                <img class="rounded-circle" src="{{ checkUserImage($user->profile_image, 'coach/thumb') }}" alt="player img">
                            </div> 
                            <div class="caption text-center">
                                <h4 class="color-white">{{ucfirst($user->full_name)}}</h4>
                                <h3 class="color-green">{{getPositionName($user->position_id)}}</h3>
                            </div>
                        </div>
                    </div>
                    <div class="center-sec">
                        <div class="center">
                            <h6 class="color-white ">
                                <span>{{ (!empty($latestNews->title)) ?  getLimitText(50,$latestNews->title) : '-'}}...</span>
                                <a href="{{ url('/news-details') }}">(READ MORE)</a> 
                            </h6>
                        </div>
                    </div>
                    <div class="right-sec">


                    </div>
                </div>
            </div>
        </section>

        <!-- xxxxxxxxx -->

        <section class="eduction-section">

            <ul class="list-unstyled bar-animation">
                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>

                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>

                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-left bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
            </ul>

            <!-- bars right -->
            <ul class="list-unstyled bar-animation bar-animation-right">
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
                <li>
                    <ul class="list-unstyled bars-right bar-wrap">
                        <li class="bar"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                        <li class="bar bar-short"></li>
                    </ul>
                </li>
            </ul>

            <div class="container-1800">
                <div class="inner-wrap">
                    <div class="common_heading  position-relative">
                        <h3 class="black black-lg h_black d-inline-block">
                            EDUCATION
                        </h3>

                        <h3 class="black gray-lg color-white h-white ">
                            EDUCATION
                        </h3>
                        <div class="edit_icon icon_center">
                            <a href="{{url('coach/coach-profile-form')}}" oncontextmenu="onRightClickMenu('step-form-about')" onclick='coachProfileForm("step-form-about");'>
                                <i class="fas fa-edit"></i>
                            </a>
                        </div>

                    </div>
                    <?php if (!empty($user->userEducationExperience)) {
                        ?>
                        <ul class="list-inline text-center card-wrap">
                            <?php for ($i = 0; $i < 3; $i++) {
                                ?>
                                <li class="list-inline-item list">
                                    <img src="{{(!empty($user->userEducationExperience[$i]->logo))?checkUserImage($user->userEducationExperience[$i]->logo, 'coach/thumb','community-experience'): checkUserImage('default.png', 'coach/thumb','community-experience')}}" alt="icon">
                                    <h3>{{(!empty($user->userEducationExperience[$i]->name)) ? getLimitText(20,$user->userEducationExperience[$i]->name) : 'add info'}}</h3>
                                    <h6>{{(!empty($user->userEducationExperience[$i]->degree_name)) ? getLimitText(20,$user->userEducationExperience[$i]->degree_name) : '-'}}</h6>
                                    <p>{{(!empty($user->userEducationExperience[$i]->from_year))?$user->userEducationExperience[$i]->from_year:'-'}}-{{(!empty($user->userEducationExperience[$i]->to_year))?$user->userEducationExperience[$i]->to_year:'-'}}</p>
                                </li>
                            <?php } ?>
                        </ul>
                        <?php
                    }
                    if (count($user->userEducationExperience) > 3) {
                        ?>
                        <div class="text-center seeall_btn mt-xl-4 mt-3">
                            <a id="education_see" href="javascript:void(0);" class="btn btn-success btn-sm border-1 p-6-15 font-14" onclick="allEducation()">SEE ALL</a>
                        </div>
                    <?php } ?>
                </div>

            </div>
        </section>

        <!-- xxxxxxxxx -->

        <section class="logo_present text-center">
            <img class="img-fluid" src="{{ url('public/images/logo_present.png') }}" alt=" logo present">
        </section>

        <section class="desired_benefits">
            <div class="container-1800">
                <div class="common_heading position-relative">
                    <h3 class="black gray-lg color-white">
                        DESIRED BENEFITS
                    </h3>
                    <div class="edit_icon icon_center color_white">
                        <a href="{{url('coach/coach-profile-form')}}" oncontextmenu="onRightClickMenu('step-form-desired-benefits')" onclick='coachProfileForm("step-form-desired-benefits");'>
                            <i class="fas fa-edit"></i>
                        </a>
                    </div>

                </div>
                <div id="divDesiredBenifites">

                </div>
            </div>
        </section>

        <!-- xxxxxxxxx -->

        <section class="secondprofile_status profile_status ">
            <div class="container-fluid">
                <div class="compare-row d-flex align-items-end">
                    <div class="left-sec">
                        <img src="{{ url('public/images/frames-bg/compare-profile-left-corner-gray.png') }}" alt="compare-profile-row-bg" class="img-fluid">
                    </div>
                    <div class="center-sec">
                        <div class="center ">
                            <h6 class="color-white "><span>... 
                                    {{$latest_news}}... </span><a href="{{ url('/news-details') }}">(READ MORE)</a>.</h6>
                        </div>
                    </div>
                    <div class="right-sec text-center">
                        <img class="img-fluid" src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'medium') }}" alt="flag">
                    </div>
                </div>
            </div>
        </section>

        <section class="accolades_section">
            <div class="container-1800">
                <div class="frame_bg">
                    <div class="left_loader">
                        <div class="border_loader">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                    <div class="common_heading position-relative">
                        <h3 class="black gray-lg color-white">
                            ACCOLADES
                        </h3>
                        <div class="edit_icon icon_center color_white">
                            <a href="{{url('coach/coach-profile-form')}}" oncontextmenu="onRightClickMenu('step-form-about')" onclick='coachProfileForm("step-form-about");'>
                                <i class="fas fa-edit"></i>
                            </a>
                        </div>

                        <!-- <div class="edit_icon icon_center color_white">
                            <a href="javascript:void(0);">
                                <i class="fas fa-edit"></i>
                            </a>
                        </div> -->
                    </div>
                    <?php if (!empty($user->userAccoladesExperince)) {
                        ?>
                        <ul class="list-inline text-center card-wrap">
                            <?php for ($i = 0; $i < 3; $i++) {
                                ?>
                                <li class="list-inline-item list">
                                    <img src="{{(!empty($user->userAccoladesExperince[$i]->logo))?checkUserImage($user->userAccoladesExperince[$i]->logo, 'coach/thumb','logo'): checkUserImage('cairo_icon.svg', 'coach/thumb','accolades-experience') }}" alt="icon">
                                    <h3 class="color-green">{{(!empty($user->userAccoladesExperince[$i]->name)) ? getLimitText(20,$user->userAccoladesExperince[$i]->name) : 'add info'}}</h3>
                                    <h6 class="color-white">{{(!empty($user->userAccoladesExperince[$i]->present_organization)) ? getLimitText(20,$user->userAccoladesExperince[$i]->present_organization) : '-'}}</h6>
                                    <p class="color-green">{{(!empty($user->userAccoladesExperince[$i]->present_year)) ? $user->userAccoladesExperince[$i]->present_year : '-'}}</p>
                                </li>
                            <?php } ?>
                        </ul>
                        <?php
                    }
                    if (count($user->userAccoladesExperince) > 3) {
                        ?>
                        <div class="text-center seeall_btn mt-xl-4 mt-3">
                            <a  href="javascript:void(0);" id="accolade_see"class="btn btn-success btn-sm border-1 p-6-15 font-14" onclick="allAccolades()">SEE ALL</a>
                        </div>
                    <?php } ?>
                </div>
            </div>    
        </section>

        <!-- xxxxxxxxx -->

<!--    <section class="career_achivements"> 
        <div class="container-1800">
            <div class="common_heading">
                <h3 class="black gray-lg">CAREER HIGHLIGHTS AND ACHIVEMENTS</h3>
            </div>
            <ul class="list-inline text-center">
                <li class="list-inline-item list">
                    <img src="{{ url('public/images/community_icon.svg') }}" alt="icon">
                    <h3>CAIRO WOLVES</h3>
                    <h6>RD/DB</h6>
                    <p>2017 TO PRESENT</p>
                    <div class="bottom_loader">
                        <div class="border_loader">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                </li>
                <li class="list-inline-item list">
                    <img src="{{ url('public/images/community_icon.svg') }}" alt="icon">
                    <h3>CAIRO WOLVES</h3>
                    <h6>RD/DB</h6>
                    <p>2017 TO PRESENT</p>
                    <div class="bottom_loader">
                        <div class="border_loader">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                </li>
                <li class="list-inline-item list">
                    <img src="{{ url('public/images/community_icon.svg') }}" alt="icon">
                    <h3>CAIRO WOLVES</h3>
                    <h6>RD/DB</h6>
                    <p>2017 TO PRESENT</p>
                    <div class="bottom_loader">
                        <div class="border_loader">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </section>-->
        <section class="career_achivements"> 
            <div class="container-1800">
                <div class="common_heading position-relative">
                    <h3 class="black gray-lg">COACHING EXPERIENCE</h3> 
                    <div class="edit_icon icon_center color_white">
                        <a href="{{url('coach/coach-profile-form')}}" oncontextmenu="onRightClickMenu('step-form-about')" onclick='coachProfileForm("step-form-about");'>
                            <i class="fas fa-edit"></i>
                        </a>
                    </div> 

                </div>
                <?php if (!empty($user->userCoachingExperince)) { ?>
                    <ul class="list-inline text-center mb-0">
                        <?php for ($i = 0; $i < 3; $i++) { ?>
                            <li class="list-inline-item list text-white">
                                <span class="year">{{(!empty($user->userCoachingExperince[$i]->from_year))?$user->userCoachingExperince[$i]->from_year:'-'}}-{{(!empty($user->userCoachingExperince[$i]->to_year))?$user->userCoachingExperince[$i]->to_year:'-'}}</span>
                                <div class="team_logo">
                                    <img src="{{(!empty($user->userCoachingExperince[$i]->logo))?checkUserImage($user->userCoachingExperince[$i]->logo, 'coach/thumb','logo'): checkUserImage('coachinglist_logo.png', 'coach/thumb','coaching-list')}}" class="img-fluid" alt="logo">
                                </div>
                                <h5 class="mt-3 mb-3">{{(!empty($user->userCoachingExperince[$i]->name))?$user->userCoachingExperince[$i]->name:'ADD INFO'}}</h5>
                                <div class="form-group">
                                    <label>Link to Team’s page/stats</label>
                                    <p>@if(!empty($user->userCoachingExperince[$i]->coaching_link)) <a href="{{$user->userCoachingExperince[$i]->coaching_link}}">{{$user->userCoachingExperince[$i]->coaching_link}}</a> @else {{'-'}} @endif</p>
                                </div>
                                <div class="form-group">
                                    <label>League/Conference</label>
                                    <p>{{(!empty($user->userCoachingExperince[$i]->coching_league))?$user->userCoachingExperince[$i]->coching_league:'-'}}</p>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label>Country</label>
                                            <p>{{(!empty($user->userCoachingExperince[$i]->experienceCountry->name))?$user->userCoachingExperince[$i]->experienceCountry->name:'-'}}</p>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label>State</label>
                                            <p>{{(!empty($user->userCoachingExperince[$i]->experienceState->state_name))?$user->userCoachingExperince[$i]->experienceState->state_name:'-'}}</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label>Level</label>
                                            <p>{{(!empty($user->userCoachingExperince[$i]->experienceLevel->level_name))?$user->userCoachingExperince[$i]->experienceLevel->level_name:'-'}}</p>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label>Position Held</label>
                                            <p>{{(!empty($user->userCoachingExperince[$i]->position_held)) ? getLimitText(10,$user->userCoachingExperince[$i]->position_held): '-'}}</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="bottom_loader">
                                    <div class="border_loader">
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                    </div>
                                </div>
                                <p class="pra mb-0 text-left mt-3">
                                    {{(!empty($user->userCoachingExperince[$i]->bio)) ? getLimitText(60,$user->userCoachingExperince[$i]->bio) : '-'}}
                                </p>
                            </li>
                        <?php } ?>
                    </ul>
                    <?php if (count($user->userCoachingExperince) > 3) { ?>
                        <div class="text-center seeall_btn mt-xl-4 mt-3">
                            <a href="javascript:void(0);" id="coaching_exp_see" class="btn btn-success btn-sm border-1 p-6-15 font-14" onclick="allCoachingexperience()">SEE ALL</a>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
        </section>



        <!-- xxxxxxxxx -->
    </div>
    <section class="resume">
        <div class="container-1800">
            <div class="common_heading ">
                <h3 class="black gray-lg color-white ">PROFESSIONAL RESUME</h3>
            </div>
            <div class="frame_bg">
                <div class="row">
                    <div class="col-sm-4">
                        <h3 class="text-uppercase text-center">{{strtoupper($user->first_name)}} <br> {{strtoupper($user->last_name)}}</h3>
                    </div>

                    <div class="col-sm-4">
                        <div class="profile_info text-center">
                            <img class="rounded-circle" src="{{ checkUserImage($user->profile_image, 'coach/thumb') }}" alt=" profile">
                            <h4>DOWNLOAD RESUME</h4>
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    @if(!empty($user->resume))
                                    <a href="{{url('public/uploads/coach/'.$user->resume)}}" download class="icon">
                                        <i class="icon-download_icon "></i>
                                    </a>
                                    @else
                                    <a href="javascript:void(0)" class="icon">
                                        <i class="icon-download_icon "></i>
                                    </a>

                                    @endif
                                </li>
                                <li class="list-inline-item">
                                    <a href="{{ url('coach/coach-profile-form') }}" class="icon">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                </li>

                            </ul>
                        </div> 
                    </div>
                    <div class="col-sm-4">
                        <div class="flag text-sm-right">
                            <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'medium') }}" alt=" flag">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  education model -->
    <div class="modal fade modal-center education accolades" id="Education" data-backdrop="static" data-keyboard="false"  data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content" id="education_list">

            </div>
        </div> 
    </div> 
    <!--  accolade model -->
    <div class="modal fade modal-center education accolades" id="Accolades" data-backdrop="static" data-keyboard="false"  data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content" id="accolades_list">

            </div>
        </div> 
    </div>
    <!--  coaching experience model -->
    <div class="modal fade modal-center coaching_experience" id="CoachingExperience" data-backdrop="static" data-keyboard="false"  data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content" id="coaching_experience_list">

            </div>
        </div> 
    </div>


    <!--  Coach pro card -->
    <div class="procard-coach" id="divCoachProCard"> </div>
    <!-- experience -->
    <div class="modal fade modal-center collage_experience" id="userExperienceList" data-backdrop="static" data-keyboard="false"  data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md " role="document">
            <div class="modal-content" id="experience_list">

            </div>
        </div> 
    </div>
    <!-- more attribute model -->
    <div class="modal fade modal-center collage_experience" id="attributeList" data-backdrop="static" data-keyboard="false"  data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md " role="document">
            <div class="modal-content" id="attribute_list">

            </div>
        </div> 
    </div>


    <!-- desired benefits -->
    <div class="modal fade modal-center desired_benefits" id="DesiredBenefits" data-backdrop="static" data-keyboard="false"  data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content" id="moreDesiredBenefitsList">

            </div>
        </div> 
    </div>
    <!-- Add skills -->
    <div class="modal fade modal-center add_skills" data-backdrop="static" data-keyboard="false" id="AddSkills" data-easein="flipBounceXIn" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content" id="addSkillsModalBody">
            </div>
        </div>        
    </div>
</main>

<!-- left & right side url routing-->
<input type="hidden" data-url="{{url('coach/left-sidebar')}}" id="coach_left_side">
<input type="hidden" data-url="{{url('coach/right-sidebar')}}" id="coach_right_side">
<input type="hidden" data-url="{{url('coach/delete-attribute')}}" id="delete_status">
<script src="{{ url('public/js/jquery.fancybox.min.js') }}"></script>
<script src="{{url('public/js/coach/coach-left-right-sidebar.js')}}"></script>
<script src="{{url('public/js/bootbox_common.js')}}"></script>

<script>
                                /* on click on link*/
                                function coachProfileForm(type) {
                                    localStorage.setItem('type', type);
                                }

                                /* on click on right button links*/
                                function onRightClickMenu(type) {
                                    localStorage.setItem('type', type);
                                }

//   get profile media
                                function getProfileMediaList() {
                                    var url = "{{ url('coach/get-profile-media-list') }}";
                                    $.ajax({
                                        type: "GET",
                                        url: url,
                                        data: {},
                                        success: function (response) {
                                            $('#divVideoUserViews').html(response.html);
                                        },
                                        error: function () {
                                            getProfileMediaList();
                                        },
                                        complete: function () {
                                            setTimeout(function () {
                                                setHeightMiddleSection();
                                            }, 3000);
                                        }
                                    });
                                }

                                function allEducation() {
                                    showButtonLoader('education_see', 'SEE ALL', 'disable');
                                    var url = "{{ url('coach/get-all-education') }}";
                                    $.ajax({
                                        type: "GET",
                                        url: url,
                                        success: function (response) {

                                            $('#education_list').html(response.html);
                                            $('#Education').modal('show');
                                        },
                                        error: function () {

                                        },
                                        complete: function () {
                                            showButtonLoader('education_see', 'SEE ALL', 'enable');
                                            $(".scroll_body").mCustomScrollbar({
                                                theme: "dark",
                                                axis: "y",
                                            });
                                        }
                                    });
                                }

                                function allAccolades() {
                                    showButtonLoader('accolade_see', 'SEE ALL', 'disable');
                                    var url = "{{ url('coach/get-all-accolades') }}";
                                    $.ajax({
                                        type: "GET",
                                        url: url,
                                        success: function (response) {
                                            $('#accolades_list').html(response.html);
                                            $('#Accolades').modal('show');
                                            showButtonLoader('accolade_see', 'SEE ALL', 'enable');
                                        },
                                        complete: function () {
                                            $(".scroll_body").mCustomScrollbar({
                                                theme: "dark",
                                                axis: "y",
                                            });
                                        }

                                    });
                                }

                                function allCoachingexperience() {
                                    showButtonLoader('coaching_exp_see', 'SEE ALL', 'disable');
                                    var url = "{{ url('coach/get-coaching-experience') }}";
                                    $.ajax({
                                        type: "GET",
                                        url: url,
                                        success: function (response) {
                                            $('#coaching_experience_list').html(response.html);
                                            $('#CoachingExperience').modal('show');
                                            showButtonLoader('coaching_exp_see', 'SEE ALL', 'enable');
                                        }
                                    });
                                }

                                var userConnectionList = "{{ url('coach/user-connections-list') }}";
//  profile pages benefits sections animation

                                var desired_sec = $('.desired_benefits').offset();
                                var $window = $(window);
                                $window.scroll(function () {
                                    if ($window.scrollTop() >= desired_sec.top) {
                                        $('.desired_benefits').addClass("active_sec");
                                    }
                                });
                                $(".hover").mouseleave(
                                        function () {
                                            $(this).removeClass("hover");
                                        });
// function for get default functions on page ready.
                                $(document).ready(function () {
                                    getLeftSidebar("coach-profile");
                                    getRightSidebar("coach-profile");
                                    getCoachProCard();
                                    getCoachAllCount();
                                    getDesiredBenifites();
                                    getAttributesList('attribute_list');
                                    getProfileMediaList();
                                    getInstagrampostList();
                                });
// show coach pro card
                                function getCoachProCard() {
                                    var url = "{{ url('coach/get-coach-procard') }}";
                                    $.ajax({
                                        type: "GET",
                                        url: url,
                                        success: function (response) {
                                            $('#divCoachProCard').html(response.html);
                                        },
                                        error: function () {
                                            getCoachProCard();
                                        },
                                        complete: function () {
                                            setHeightMiddleSection();
                                        }
                                    });
                                }
// get all coach counts
                                function getCoachAllCount() {
                                    pageLoader('divCoachCounts', 'show');
                                    var url = "{{ url('coach/get-coach-counts') }}";
                                    $.ajax({
                                        type: "GET",
                                        url: url,
                                        success: function (response) {
                                            $('#divCoachCounts').html('');
                                            $('#divCoachCounts').html(response.html);
                                            $('#newsBulletin').html(response.newsBulletin);
                                        },
                                        error: function () {
                                            getCoachAllCount();
                                        }
                                    });
                                }

                                /* Get coach  experience */
                                function getExperienceList(type) {
                                    var url = "{{ url('coach/get-experience-list') }}";
                                    var _token = '{{ csrf_token() }}';
                                    $.ajax({
                                        type: "POST",
                                        url: url,
                                        data: {
                                            _token: _token,
                                            experience_type: type
                                        },
                                        success: function (response) {
                                            $('#userExperienceList').modal('show');
                                            $('#experience_list').html(response.html);
                                        },
                                        error: function () {
                                            getExperienceList(type)
                                        },
                                        complete: function () {
                                            $(".scroll_body").mCustomScrollbar({
                                                theme: "dark",
                                                axis: "y",
                                            });
                                        }
                                    });
                                }
                                /* Get coach  attributes list */
                                function getAttributesList(type) {
                                    var url = "{{ url('coach/get-attribute-list') }}";
                                    var _token = '{{ csrf_token() }}';
                                    $.ajax({
                                        type: "POST",
                                        url: url,
                                        dataType: 'JSON',
                                        data: {
                                            _token: _token,
                                            type: type
                                        },
                                        success: function (response) {
                                            if (type == 'view_more') {
                                                $('#attributeList').modal('show');
                                                $('#attribute_list').html(response.html);
                                            } else {
                                                $('#coach_attribute_list').html(response.html);
                                            }
                                        },
                                        complete: function () {
                                            $(".scroll_body").mCustomScrollbar({
                                                theme: "dark",
                                                axis: "y",
                                            });
                                        }
                                    });
                                }

                                function getDesiredBenifites() {
                                    var url = "{{ url('coach/get-desired-benifites') }}";
                                    $.ajax({
                                        type: "GET",
                                        url: url,
                                        success: function (response) {
                                            $('#divDesiredBenifites').html(response.html);
                                        },
                                        error: function () {
                                            //getDesiredBenifites();
                                        },
                                        complete: function () {
                                            //setHeightMiddleSection(); 
                                        }
                                    });
                                }

                                function loadMoreBenefits() {
                                    showButtonLoader('loader_more_benefit', 'SEE ALL', 'disable');
                                    var url = "{{ url('coach/load-more-benefites') }}";
                                    $.ajax({
                                        type: "GET",
                                        url: url,
                                        success: function (response) {
                                            $('#DesiredBenefits').modal('show');
                                            $('#moreDesiredBenefitsList').html(response.html);
                                        },
                                        error: function () {
                                            loadMoreBenefits();
                                        },
                                        complete: function () {
                                            showButtonLoader('loader_more_benefit', 'SEE ALL', 'enable');
                                            $(".scroll_body").mCustomScrollbar({
                                                theme: "dark",
                                                axis: "y",
                                            });
                                            //setHeightMiddleSection(); 
                                        }
                                    });
                                }

// add skills modal
                                function getAddSkillsPage() {
                                    var url = "{{ url('coach/load-add-skills-modal') }}";
                                    $.ajax({
                                        type: "GET",
                                        url: url,
                                        success: function (response) {
                                            $('#AddSkills').modal('show');
                                            $('#addSkillsModalBody').html(response.html);
                                        },
                                        error: function () {
                                        },
                                        complete: function () {
                                        }
                                    });
                                }
// instagram feed listing
                                function getInstagrampostList() {
                                    pageLoader('instgramPost', 'show')
                                    var url = "{{ url('get-instagram-feed') }} ";
                                    $.ajax({
                                        type: "GET",
                                        url: url,
                                        success: function (response) {
                                            $("#instgramPost").html("");
                                            $("#instgramPost").html(response.html);
                                        }, error: function () {
                                            getInstagrampostList();
                                        }
                                    });
                                }

</script>

@endsection