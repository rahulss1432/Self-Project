@extends('coach::layouts.app')
@section('content')
<main class="main-content">
    <div class="mainframe_border">
        <div class="borderheight" id="borderheight"></div>
    </div>
    <div class="container-fluid">
        <div class="common_heading">
            <h3 class="black black-lg text-uppercase">
                members you may know
            </h3>
        </div>
    </div>
    <aside class="left_section " id="left-side-html">
        <!-- left side html render -->
    </aside>
    <section class="middle_section">


        <div class="container-fluid">
            <div class="members_list">
                <div class="heading text-center mr-auto ml-auto">
                    RECENT MEMBERS JOINED
                </div>
                <div class="list" id="sliderDiv">
                    <div class="customNavigation">
                        <a href="javascript:void(0);" class="prev"></a>
                    </div>
                    <div class="back_bg"></div>
                    <div class="owl-carousel owl-theme member" id="memberlist">
                    </div>
                    <div class="customNavigation">
                        <a href="javascript:void(0);" class="next"></a>
                    </div>
                </div>
            </div>

            <div class="ajax_list_load">
                <div class="connections-wrap" id="divAllMembersList">                    
                </div>
            </div>
        </div>
    </section>
    <aside class="right_section" id="right-side-html">
        <!-- right side html render -->
    </aside>
</main>
<!-- left & right side url routing-->
<input type="hidden" data-url="{{url('coach/left-sidebar')}}" id="coach_left_side">
<input type="hidden" data-url="{{url('coach/right-sidebar')}}" id="coach_right_side">
<script>
//     accepr reject urls
    var memberConnectDismissUrl = "{{ url('coach/connect-dismiss-member') }}";
    var recentJoinedMembersUrl = "{{ url('coach/get-recent-joined-members') }}";
    var currentPageUrl = '{{ Request::segment(2) }}';
    var csrfToken = "{{csrf_token()}}";
    var user_id='{{$id}}'; // for reinitilize slider when length 0.
    // ajax loading
    function getMemberList() {
        pageLoader('divAllMembersList', 'show');
        var url = "{{ url('coach/get-matched-mutual-joined-members-list') }}";
        var formData = $('#coachMemberForm').serialize();
        $('#applyBtn').prop('disabled', true);

        $.ajax({type: "POST",
            url: url,
            data: formData,
            success: function (response) {
                if (response.success) {
                    setTimeout(function () {
                        pageLoader('divAllMembersList', 'hide');
                        $("#divAllMembersList").html(response.html);
                        $('#left-side-html').removeClass('open');
                        $('body').removeClass("aside-open-left");
                    }, 2000);
                } else {
                    message('error', response.message);
                }
            },
            error: function (err) {
                //message('error', err);
                getMemberList();
            },
            complete: function () {
                setHeightMiddleSection();
            }
        });
    }

    $(document).ready(function () {
        getLeftSidebar("member-you-know");
        getRightSidebar("member-you-know");
        setTimeout(function () {
            getMemberList();
            getRecentJoinedMembers("member-you-know", csrfToken, '{{$id}}');
        }, 1500);
    });

    /* Clear search form */
    function clearForm() {
        $('#member_type').val('');
        $('#member_type').selectpicker('refresh');
        $('#coachMemberForm').trigger("reset");
        setTimeout(function () {
            getMemberList();
            getRecentJoinedMembers("member-you-know", csrfToken, '{{$id}}');
        }, 1000);
    }

</script>
<script src="{{url('public/js/coach/coach-connect-dissmiss.js')}}"></script>
<script src="{{url('public/js/coach/coach-left-right-sidebar.js')}}"></script>
<script src="{{url('public/js/coach/recent-joined-members.js')}}"></script>
@endsection