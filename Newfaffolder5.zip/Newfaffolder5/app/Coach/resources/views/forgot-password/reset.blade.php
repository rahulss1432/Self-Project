<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Material Design for Bootstrap fonts and icons -->
        <script src="{{ asset('public/js/jquery-3.2.1.min.js') }}"></script>    
           
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">

<!--        <link href='//fonts.googleapis.com/?family=Roboto:300,400,500,700,900'  rel='stylesheet' type='text/css'>-->

        <!-- Material Design for Bootstrap CSS -->
        <link rel="stylesheet" href="{{ asset('public/css/bootstrap-material-design.min.css')}}" crossorigin="anonymous">
        <link rel="stylesheet" href="{{ asset('public/css/custom.min.css')}}" crossorigin="anonymous">
         <link rel="stylesheet" href="{{ asset('public/css/toastr.min.css')}}">
     
         <style type="text/css">
              .error-help-block {
                color: red;
              }
        </style>

        <title>OPTT</title>
    </head>
    <body>


        <div class="main-content loginpage">
    <div class="page-content" id="pageContent">
        <div class="login-wrapper">
            <div class="login-box row no-gutters">
                    <div class="leftside col-md-6 col-sm-12 col-lg-6 col-xl-5">
    @include('message')

                            <div class="logo">
                                <h2>OPTT</h2>
                            </div>
                            <div class="para">
                                <h3>Reset Password</h3>
                               
                            </div>
                        <form class="login_form" id="reset_password" method="post" action="{{URL::To('reset-password')}}">
                               {{ csrf_field() }}
                                 <input type="hidden" name="token" value="{{request()->token}}">
                               
                                 <div class="form-group">
                                    <label>New Password</label>
                                    <input type="password" class="form-control" placeholder="Enter new password" name="password">
                                </div> 
                                <div class="form-group">
                                    <label>Confirm Password</label>
                                    <input type="password" class="form-control" placeholder="Enter confirm password" name="password_confirmation">
                                </div> 
                                 <div class="btn-row">
                                    <button type="submit" class="btn btn-raised btn-primary rounded-0">Reset Password</button>
                                    <a  href="{{URL('login')}}" class="forgot-link">Login</a>
                                </div>
                              </form>
                           {!! JsValidator::formRequest('App\Http\Requests\ResetPasswordValidation','#reset_password') !!}
                        </div>
                        <div class="rightside col-md-6 col-sm-12 col-lg-6 col-xl-7 d-none d-md-block">
                            
                            <img src="{{URL('public/images/login-bg.jpg')}}" alt="login-bg">
                        </div>
            </div>
        </div>
    </div>
</div>

        

<!--        <script src="{{ asset('public/js/jquery-3.2.1.slim.min.js') }}" integrity="sha384-fA23ZRQ3G/J53mElWqVJEGJzU0sTs+SvzG8fXVWP+kJQ1lwFAOkcUOysnlKJC33U" crossorigin="anonymous"></script>-->
        <script src="{{ asset('public/js/popper.js') }}" integrity="sha384-fA23ZRQ3G/J53mElWqVJEGJzU0sTs+SvzG8fXVWP+kJQ1lwFAOkcUOysnlKJC33U" crossorigin="anonymous"></script>
        <script src="{{ asset('public/js/bootstrap-material-design.js') }}" crossorigin="anonymous"></script>
        <script src="{{ asset('/public/js/jsvalidation.min.js') }}"></script>

         <script src="{{ asset('/public/js/toastr.min.js') }}"></script>
      
   
        <script>
              
    $(document).ready(function () { 

    $('body').bootstrapMaterialDesign();
});

    
        </script>
    </body>
</html>





