@extends('coach::layouts.app')
@section('content')

<link rel="stylesheet" href="{{ url('public/css/tempusdominus-bootstrap-4.min.css') }}" />
<link rel="stylesheet" href="{{ url('public/css/bootstrap-tagsinput.css') }}" />

<div class="main-content side_padding">
    <section class="eventadd_form">
        <div class="container">
            <div class="common_heading">
                <h3 class="black black-lg">EDIT EVENT</h3>
            </div>
            <form class="custom_form" id="add-event" method="post" action="{{ url('coach/save-event') }}">
                {{ csrf_field() }}
                <input type="hidden" name="id" value="{{ $event->id }}"/>
                <div class="form-group">                    
                    <label class="upload_img upload-btn" for="banner_image" onclick="$('#event_image_input').trigger('click')">
                        <span class="content text-center">
                            <div id="setCropImage">
                                @if(!empty($event->banner_image))
                                <div class="banner-holder" style="background-image:url('{{ checkUserImage($event->banner_image, 'event/thumb', 'event-banner') }}')"></div>
                                @else
                                <i class="flaticon-photo"></i>
                                @endif
                            </div>
                            <span class="title d-block">Upload Banner Image</span>
                        </span>
                    </label>
                </div>
                <div class="row common-row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label">Event Name<span class="text-danger">*</span></label>
                            <div class="input-field">
                                <input type="text" name="event_name" value="{{ $event->event_name }}" class="form-control" placeholder="event name">
                                <div class="invalid-tooltip">Please Enter Event Name</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 ">
                        <div class="form-group">
                            <label class="control-label">Keywords</label>
                            <div class="input-field">
                                <input type="text" name="keywords" value="{{ $event->keywords }}" id="keywords" class="form-control" placeholder="Keywords" data-role="tagsinput">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row common-row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label">Address 1</label>
                            <div class="input-field">
                                <input type="text" name="address1" value="{{ $event->address1 }}" class="form-control" placeholder="Address 1">
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label">Address 2</label>
                            <div class="input-field">
                                <input type="text" name="address2" value="{{ $event->address2 }}" class="form-control" placeholder="Address 2">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row common-row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label">Country</label>
                            <select name="country_id" id="country" class="selectpicker select-custom form-control" data-size="3" title="Select Country">
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label">State</label>
                            <select name="state_id" id="state" class="selectpicker select-custom form-control" data-size="3" title="Select State">
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row common-row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label">City</label>
                            <div class="input-field">
                                <input type="text" name="city" value="{{ $event->city }}" class="form-control" placeholder="City">
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label">Zip Code</label>
                            <div class="input-field">
                                <input type="text" name="zipcode" value="{{ $event->zipcode }}" class="form-control" placeholder="Zip Code">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row common-row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label">Team 1</label>
                            <select name="team1" id="team1" onchange="$(this).valid();" data-live-search="true"  class="selectpicker select-custom form-control" data-size="5" title="Select Team 1">
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="team_vs"></div>
                        <div class="form-group ">
                            <label class="control-label">Team 2</label>
                            <select name="team2" id="team2" onchange="$(this).valid();" data-live-search="true"  class="selectpicker select-custom form-control" data-size="5" title="Select Team 2">
                            </select> 
                        </div>
                    </div>
                </div>
                <div class="row common-row">
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Start Date<span class="text-danger">*</span></label>
                                    <div class="input-field date_picker z-index">
                                        <div class="input-group date">
                                            <input type="text" name="start_date" id="startDate" class="form-control date datetimepicker-input" data-target="#startDate" data-toggle="datetimepicker" readonly="true"/>                                                                                    
                                            <div class="invalid-tooltip">Please Select Start Date</div>
                                            <div class="input-group-append" data-target="#startDate" data-toggle="datetimepicker">
                                                <div class="input-group-text">
                                                    <i class="flaticon-calendar"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">End Date<span class="text-danger">*</span></label>
                                    <div class="input-field date_picker z-index">
                                        <div class="input-group date">
                                            <input type="text" name="end_date" id="endDate" class="form-control date datetimepicker-input" data-target="#endDate" data-toggle="datetimepicker" readonly="true"/>                                                                                                                            
                                            <div class="invalid-tooltip">Please Select End Date</div>
                                            <div class="input-group-append" data-target="#endDate" data-toggle="datetimepicker">
                                                <div class="input-group-text">
                                                    <i class="flaticon-calendar"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Start Time<span class="text-danger">*</span></label>
                                    <div class="input-field date_picker">
                                        <div class="input-group date">
                                            <input type="text" name="start_time" id="startTime" class="form-control time datetimepicker-input" data-target="#startTime" data-toggle="datetimepicker" readonly="true"/>                                                                                    
                                            <div class="invalid-tooltip">Please Select Start Time</div>
                                            <div class="input-group-append" data-target="#startTime" data-toggle="datetimepicker">
                                                <div class="input-group-text">
                                                    <i class="far fa-clock"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">End Time<span class="text-danger">*</span></label>
                                    <div class="input-field date_picker">
                                        <div class="input-group date">
                                            <input type="text" name="end_time" id="endTime" class="form-control time datetimepicker-input" data-target="#endTime" data-toggle="datetimepicker" readonly="true"/>                                        
                                            <div class="invalid-tooltip">Please Select End Time</div>
                                            <div class="input-group-append" data-target="#endTime" data-toggle="datetimepicker">
                                                <div class="input-group-text">
                                                    <i class="far fa-clock"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>                
                <div class="row common-row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="control-label">Event URL</label>
                            <div class="input-field">
                                <input type="text" name="ticket_url" value="{{ $event->ticket_url }}" placeholder="Enter url" required="">
                            </div>
                        </div>
                    </div>
                </div>	
                <div class="form-group">
                    <label class="control-label">Description</label>
                    <div class="input-field textarea">
                        <textarea rows="4" name="description" class="form-control" placeholder="Event Description" required="">{{ $event->description }}</textarea>
                    </div>
                </div>	

                <div class="form-group submit_btn text-right">
                    <a href="javascript:void(0);" class="btn btn-secondary btn-lg font-20 p-12-25 border-2">CANCEL</a>
                    <button  class="btn btn-success btn-lg font-20 p-12-25 border-2" type="submit" id="btnSubmit"> <span class="d-n">UPDATE</span>
                        <span class="btn_loader btn_ring" style="display: none;" id="btnSubmitLoader"></span>
                    </button>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Coach\Http\Requests\AddEventRequest','#add-event') !!}
        </div>
    </section>
</div>

<!-- team add -->
<div class="modal fade team_add" id="divTeamAddModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document" id="divAddTeamModalBody">
    </div>
</div>

<!-- Image cropper model -->
<div id="imagCropperModal" class="modal fade image_cropper" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel01" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog common-modal crop-modal modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title heading-modal text-center">Event Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="removeCropperFile()"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <div id="cropperDiv">
                    <div style="display:none;" id="processloader" class="imagmodelloader center-block">
                        <i class="fa fa fa-spinner fa-pulse fa-2x"></i></div> </div>
            </div>
        </div>
    </div>
</div>

<script src="{{ url('public/js/bootstrap-tagsinput.js') }}"></script>
<script type="text/javascript" src="{{ url('public/js/ajaxupload.3.5.js') }}"></script>
<script type="text/javascript" src="{{ url('public/js/cropper.min.js') }}"></script>
<script src="{{ url('public/js/event-bootstrap-select.min.js') }}"></script>
<script>
                    // date and time picker
                    if ($(window).width() < 767) {
                        $('#startDate, #endDate').datetimepicker({
                            format: 'L',
                            debug: true,
                            widgetPositioning: {
                                horizontal: 'right',
                                vertical: 'bottom'
                            },
                        });
                        $('#startTime, #endTime').datetimepicker({
                            format: 'LT',
                            debug: true,
                            widgetPositioning: {
                                horizontal: 'right',
                                vertical: 'bottom'
                            },
                        });
                    }

                    /*start time and end time picker*/
                    var dbStartTime = "{{$event->start_time}}";
                    var newStartTime = moment(dbStartTime, "HH:mm a").format("hh:mm a");
                    var dbEndTime = "{{$event->end_time}}";
                    var newEndTime = moment(dbEndTime, "HH:mm a").format("hh:mm a");
                    if (newStartTime && newEndTime) {
                        var newStartTimeHour = moment(newStartTime, "LTH").format("H");
                        var newStartTimeMinute = moment(newStartTime, "LTH").format("mm");
                        var newEndTimeHour = moment(newEndTime, "LTH").format("H");
                        var newEndTimeMinute = moment(newEndTime, "LTH").format("mm");
                    } else {
                        var newStartTimeHour = moment().format("H");
                        var newStartTimeMinute = moment().format("mm");
                        var newEndTimeHour = moment().format("H");
                        var newEndTimeMinute = moment().format("mm");
                    }
                    $(function () {
                        $('#startTime').datetimepicker({
                            defaultDate: moment({
                                hour: newStartTimeHour,
                                minute: newStartTimeMinute,
                            }),
                            format: 'LT',
                            ignoreReadonly: true,
                        });
                        $('#endTime').datetimepicker({
                            defaultDate: moment({
                                hour: newEndTimeHour,
                                minute: newEndTimeMinute,
                            }),
                            format: 'LT',
                            ignoreReadonly: true,
                        });
                    });

                    /**start of datetime picker functions*/
                    //      initialize timeickers
                    function initTimePicker() {
                        $('#startTime').datetimepicker({
                            format: 'LT',
                            ignoreReadonly: true
                        });
                        $('#endTime').datetimepicker({
                            format: 'LT',
                            ignoreReadonly: true
                        });
                    }
                    /*initialzie start date picker*/
                    function initStartDatePicker() {
                        $('#startDate').datetimepicker({// initialize datepicker
                            useCurrent: false,
                            format: "L",
                            minDate: new Date().setHours(0, 0, 0, 0),
                            ignoreReadonly: true,
                        });
                    }
                    ;

                    /*initialzie end date picker*/
                    function initEndDatePicker() {
                        $('#endDate').datetimepicker({// initialize datepicker
                            useCurrent: false,
                            format: "L",
                            minDate: new Date().setHours(0, 0, 0, 0),
                            ignoreReadonly: true,
                        });
                    }
                    ;

                    /* reset end date on ready function*/
                    function resetEndDateOnReady() {
                        $('#endDate').datetimepicker('clear'); // set minimum end date to startDate 
                        $('#endDate').datetimepicker("destroy");
                        var startDatePicker = moment($('#startDate').val(), "MM/DD/YYYY"); // get start date value        
                        $('#endDate').datetimepicker({// initialize datepicker
                            useCurrent: false,
                            format: "L",
                            minDate: startDatePicker,
                            ignoreReadonly: true,
                        });
                        $("#endDate").val("{{date('m/d/Y', strtotime($event->end_date))}}");
                    }

                    /* reset end time on ready function*/
                    function resetEndTimeOnReady() {
                        $('#endTime').datetimepicker('clear'); // set minimum end date to startDate 
                        $('#endTime').datetimepicker("destroy");
                        var startTimeHour = parseInt(moment($('#startTime').val(), "LTH").format("H")); // get start time hour
                        var startTimeMinute = parseInt(moment($('#startTime').val(), "LTH").format("mm")); // get start time minute
                        $('#endTime').datetimepicker({// set default time of database
                            defaultDate: moment({
                                hour: newEndTimeHour,
                                minute: newEndTimeMinute,
                            }),
                            format: 'LT',
                            ignoreReadonly: true,
                        });
                        $('#endTime').datetimepicker('minDate', moment({// set end time's minimum time
                            hour: startTimeHour,
                            minute: startTimeMinute,
                        }));
                    }

                    $(document).ready(function () {
                        $('#team1').selectpicker();
                        $('#team2').selectpicker();
                        setTimeout(function () {
                            getAllTeam("{{$event->team1}}", 'team1');
                            getAllTeam("{{$event->team2}}", 'team2');
                        }, 1500);
                        initTimePicker(); // initialize datetimepicker at first
                        initStartDatePicker();
                        initEndDatePicker();
                        setTimeout(function () {
                            resetEndDateOnReady()  // check end date is greater or not on ready 
                            resetEndTimeOnReady(); // reset end time picker on ready.                
                        }, 2000);
                        // date picker functions       
                        var currentDate = moment().format('DD/MM/YYYY');
                        $("#startDate").on("change.datetimepicker", function (e) { // on changes start date
                            $('#endDate').datetimepicker('clear'); // set minimum end date to startDate 
                            $('#endDate').datetimepicker("destroy");
                            initEndDatePicker();
                            $('#startTime').datetimepicker('clear'); // reset start time picker            
                            $('#endTime').datetimepicker('clear'); // reset endtime picker
                            $('#endDate').datetimepicker('minDate', e.date); // set minimum end date to startDate 
                            var startDate = moment($('#startDate').val(), "L").format('DD/MM/YYYY'); // get start date value
                            if (startDate == currentDate) { // if start date and today date is same        
                                $('#startTime').datetimepicker('minDate', moment({// start time minimum time set to current time
                                    hour: moment().format('H'),
                                    minute: moment().format('mm'),
                                }));
                            } else {
                                $('#startTime').datetimepicker('clear'); // else clear start time and no set any minimum time
                                $('#startTime').datetimepicker('minDate', moment({
                                    locale: moment.locale(),
                                }));
                            }
                        });

                        $("#endDate").on("change.datetimepicker", function (e) { // on changes of end date
                            $('#endTime').datetimepicker('clear'); // reset endtime picker            
                            $('#startDate').datetimepicker('maxDate', e.date); // start date's mamimux date set to end date
                            var endDate = moment($('#endDate').val(), "L").format('DD/MM/YYYY'); // get end date
                            if (endDate == currentDate) { // if end date  and current date are same
                                $('#endTime').datetimepicker('minDate', moment({// set current time to mimimum end time
                                    hour: moment().format('H'),
                                    minute: moment().format('mm'),
                                }));
                            } else {
                                $('#endTime').datetimepicker('clear'); // else reset end time  and don't set any minimum time
                                $('#endTime').datetimepicker('minDate', moment({
                                    locale: moment.locale(),
                                }));
                            }
                        });

                        $("#startTime").on("change.datetimepicker", function (e) { //on change of start time
                            var startDate = moment($('#startDate').val(), "L").format('DD/MM/YYYY'); // get start date
                            var endDate = moment($('#endDate').val(), "L").format('DD/MM/YYYY'); // get end date
                            if (endDate != 'Invalid date') {
                                if (startDate == endDate) {                                     // if start date and end date are same        
                                    var startTimeHour = parseInt(moment(e.date._i, "LTH").format("H"));             // get start time hour
                                    var startTimeMinute = parseInt(moment(e.date._i, "LTH").format("mm"));          // get start time minute
                                    var newStartHour = startTimeHour ? startTimeHour : parseInt(moment().format('H'));
                                    var newStartMinutes = startTimeMinute ? startTimeMinute : parseInt(moment().format('mm'));
                                    $('#endTime').datetimepicker('minDate', moment({// set to end time's minimum time
                                        hour: newStartHour,
                                        minute: newStartMinutes,
                                    }));
                                }
                            }
                        });

                        $("#endTime").on("click", function (e) {              //on change of start time
                            $('#endTime').datetimepicker("clear");
                            $('#endTime').datetimepicker("destroy");
                            initTimePicker();
                            var startDate = moment($('#startDate').val(), "L").format('DD/MM/YYYY');     // get start date
                            var endDate = moment($('#endDate').val(), "L").format('DD/MM/YYYY');         // get end date                
                            if (endDate != 'Invalid date') {
                                 if (startDate == endDate) {                                     // if start date and end date are same        
                                         var startTimeHour = parseInt(moment($('#startTime').val(), "LTH").format("H"));             // get start time hour
                                         var startTimeMinute = parseInt(moment($('#startTime').val(), "LTH").format("mm"));          // get start time minute
                                         $('#endTime').datetimepicker('minDate', moment({// set to end time's minimum time
                                             hour: startTimeHour,
                                             minute: startTimeMinute,
                                         }));                    
                                 }
                             }
                        });

                        setTimeout(function () {
                            $("#startDate").val("{{date('m/d/Y', strtotime($event->start_date))}}");
                            $("#endDate").val("{{date('m/d/Y', strtotime($event->end_date))}}");
                        }, 1000);
                    });
                    /**end of datetime picker*/

                    // open add team modal function   
                    function openAddTeamModal() {
                        $.get("{{ url('add-team-form') }}", function (response) {
                            $('#divTeamAddModal').modal('show');
                            $('#divAddTeamModalBody').html(response.html);
                            $("#eventTeamForm")[0].reset();
                        });
                    }
                    // reset add event team   
                    function resetAddTeamForm() {
                        $("#eventTeamForm")[0].reset();
                    }

                    $(document).ready(function () {
                        var eventImage = $('#bannerImage').val();
                        if (eventImage) {
                            $("input[name='eventImage']").attr('title', '');
                        } else {
                            $("input[name='eventImage']").attr('title', 'No file chosen');
                        }
                    });

                    $("#Keywords").tagsinput('add', 'some tag')

                    function myFunction() {
                        var option_value = document.getElementById("select54").value;
                        if (option_value == "3") {
                            $('#teamadd').modal('show')
                        }
                    }


                    $(document).ready(function () {
                        $('input').focusin(function () {
                            $(this).parent().addClass('focused');
                        });
                        $('input').focusout(function () {
                            $(this).parent().removeClass('focused');
                        });
                        $('.date_picker .input-group-append').click(function () {
                            $(this).parent().parent().toggleClass('zindex');
                        })
                    });

                    // get all country
                    $(document).ready(function () {
                        var country_id = "{{ $event->country_id }}";
                        $.post("{{ url('get-all-country') }}", {
                            _token: '{{ csrf_token() }}',
                            type: ''
                        }, function (data) {
                            $('#country').html(data);
                            $('#country').selectpicker('refresh');
                            if (country_id != '' && country_id != undefined) {
                                $('#country').selectpicker('val', country_id);
                                $('#country').selectpicker('render');
                            }
                        });
                        
                        // get state by country id
                        var state_id = "{{ $event->state_id }}";
                        $(document).on('change', '#country', function () {
                            $.post("{{ url('get-state-by-country-id') }}", {
                                _token: "{{ csrf_token() }}",
                                country_id: $(this).val(),
                                type: ''
                            }, function (data) {
                                $('#state').html(data);
                                $('#state').selectpicker('refresh');
                                if (state_id != '' && state_id != undefined) {
                                    $('#state').selectpicker('val', state_id);
                                    $('#state').selectpicker('render');
                                }
                            });
                        });                        
                    });

                    // function for save event.
                    $(document).on('submit', '#add-event', function (e) {
                        e.preventDefault();
                        var formData = new FormData($(this)[0]);
                        formData.append('old_image', "{{$event->banner_image}}");
                        if ($('#add-event').valid()) {
                            $('#btnSubmit').prop('disabled', true);
                            $('#btnSubmitLoader').show();
                            $.ajax({
                                url: $(this).attr('action'),
                                data: formData,
                                processData: false,
                                contentType: false,
                                type: 'POST',
                                dataType: 'JSON',
                                success: function (data) {
                                    if (data.success) {
                                        toastr.success(data.message);
                                        setTimeout(function () {
                                            window.location.href = "{{ url('view/events') }}"
                                            $('#btnSubmit').prop('disabled', false);
                                            $('#btnSubmitLoader').hide();
                                        }, 1000);
                                    } else {
                                        toastr.error(data.message);
                                        $('#btnSubmit').prop('disabled', false);
                                        $('#btnSubmitLoader').hide();
                                    }
                                }
                            });
                        }
                    });

                    // get all teams 1
                    function getAllTeam(teamId, teamType) {
                        $.post("{{ url('get-all-team') }}", {
                            _token: "{{ csrf_token() }}",
                            teamId: teamId
                        }, function (data) {
                            if (teamType == 'team1') {
                                $('#team1').html(data);
                                $('#team1').selectpicker('refresh');
                            }
                            if (teamType == 'team2') {
                                $('#team2').html(data);
                                $('#team2').selectpicker('refresh');
                            }

                            if (teamId != '' && teamId != undefined) {
                                if (teamType == 'team1') {
                                    $('#team1').selectpicker('val', teamId);
                                    $('#team1').selectpicker('render');
                                }
                                if (teamType == 'team2') {
                                    $('#team2').selectpicker('val', teamId);
                                    $('#team2').selectpicker('render');
                                }
                            }
                        });
                    }

                    /* image uload by cropper */
                    var profile_picture = $('.upload-btn');
                    pPicture = new AjaxUpload(profile_picture, {
                        action: "{{ url('upload-event-image') }}",
                        name: 'eventImage',
                        cache: false,
                        method: 'post',
                        data: {
                            _token: '{{ csrf_token() }}',
                            folder: 'event',
                            image_type: 'eventImage'
                        },
                        responseType: "JSON",
                        onChange: function (file, ext) {
                            //check the file size
                            if (pPicture._input.files[0].size > 2097152) { //2MB
                                //show alert message
                                message('error', 'Selected file is bigger than 2MB.');
                                return false;
                            }
                        },
                        onSubmit: function (file, ext) {
                            if (!(ext && /^(jpg|png|jpeg)$/.test(ext))) {
                                message('error', 'Only jpg, jpeg, png files are allowed.');
                                return false;
                            }
                        },
                        onComplete: function (file, response) {
                            if (file != "") {
                                if (response.success == 1) {
                                    $("input[name='eventImage']").attr('title', '');
                                    load_cropp_image(response.filename, 'eventImage');
                                } else {
                                    $("input[name='eventImage']").attr('title', 'No file chosen');
                                    message('error', response.error);
                                }
                            } else {
                                message('error', "Error occured! please try again.");
                            }
                        }
                    });

                    function load_cropp_image(filename, type) {
                        $("#imagCropperModal").modal('show');
                        var url = "{{ url('load-event-image-cropper') }}";
                        $.ajax({
                            type: "POST",
                            url: url,
                            data: {
                                _token: "{{ csrf_token() }}",
                                filename: filename,
                                folder: 'event',
                                thumb_folder: 'event/thumb',
                                image_type: type
                            },
                            success: function (response) {
                                $("#cropperDiv").html(response);
                                setTimeout(function () {
                                    $("#cropbutton").attr('disabled', false);
                                }, 5000);
                            }
                        });
                    }

</script>
@endsection