<!-- member you may know page list content  -->
@if(count($users)>0)
@foreach($users as $user)
@if($user->role == 'player')    
<div class="detail-wrap" id="divJoinedMember_{{$user->id}}">
    <a href="{{url('view/player-profile/'.$user->slug)}}">
        <div class="player details">
            <div class="top-heading d-flex">
                <img src="{{url('public/images/white_logo.png')}}" alt="logo">
                <h2>{{$user->full_name}}</h2>
            </div>
            <div class="info-sec">
                <div class="left">
                    <ul class="list-unstyled">
                        <li>
                            <p>HT</p><span>{{!empty($user->userMeasurables->height_ft) ? $user->userMeasurables->height_ft : 0}}'{{!empty($user->userMeasurables->height_in) ? $user->userMeasurables->height_in : 0 }}'' </span>
                        </li>
                        <li>
                            <p>WT</p><span>{{!empty($user->userMeasurables->weight) ? $user->userMeasurables->weight : '-'}}</span>
                        </li>
                        <li>
                            <p>40</p><span>{{ !empty($user->userMeasurables->fourty) ? $user->userMeasurables->fourty : '-'}}</span>
                        </li>
                        <li>
                            <p>VERT</p><span>{{ !empty($user->userMeasurables->vert) ? $user->userMeasurables->vert : '-'}}</span>
                        </li>
                    </ul>
                </div>
                <div class="right d-flex flex-wrap">
                    <div class="profile-box">
                        <div class="user_profile">
                            <img src="{{ checkUserImage($user->profile_image, 'player/thumb','') }}" alt="player">
                        </div>
                        <div class="profile-box-bottom d-flex align-items-center">
                            <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'medium') }}" alt="FLAG">
                            <h4>{{getLimitText(5,!empty($user->country->name) ? $user->country->name : '-')}}</h4>
                        </div>
                    </div>
                    <div class="user_details">
                        <div class="player-top d-flex">
                            <h4>{{$user->role}}</h4>
                            <span>{{getLimitText(5,getPositionName($user->position_id))}}</span>
                        </div>
                        <ul class="list-unstyled mb-0">
                            <li>
                                <h4>AGE: <span>{{$user->age}}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENTLY UNDER CONTRACT: <span>{{ !empty($user->userGeneral->under_contract) ?  strtoupper($user->userGeneral->under_contract) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENT TEAM: <span>{{ !empty($user->userGeneral->current_team) ?  ucfirst(getLimitText(8,$user->userGeneral->current_team)) : '-' }}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENT LEAGUE: <span>{{!empty($user->userGeneral->current_league) ? ucfirst(getLimitText(8,$user->userGeneral->current_league)) : '-'}}</span></h4>
                            </li>
                            <li>
                                <h4>LOOKING TO SIGN: <span>{{!empty($user->userGeneral->look_to_sign) ? strtoupper($user->userGeneral->look_to_sign) : 'NO'}}</span></h4>                                                                
                            </li>
                            <li>
                                <h4>PASSPORT READY: <span>{{!empty($user->userGeneral->passport) ?  strtoupper($user->userGeneral->passport) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4> PREP/COLLEGE EXPERIENCE: <span>{{!empty($user->userCollegeExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>PRO EXPERIENCE: <span>{{!empty($user->userProExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>INTERNATIONAL EXPERIENCE: <span>{{!empty($user->userInternationalExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>INDOOR  EXPERIENCE: <span>{{ !empty($user->userIndooreExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                        </ul>
                    </div>
                    <div class="bottom-sec">
                        <h6>freeagentfootball.com</h6>
                    </div>
                </div>
            </div>
            <div class="share-bottom">
                <span class="icon-share_icon"></span>
            </div>
        </div>
    </a>
     @if(empty($o_id))
    
    <div class="button-sec member_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-lg border-2"  onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>
            CONNECT
        </a>
        <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2"  onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>
            DISMISS
        </a>
    </div>
    @else
 
          <div class="button-sec member_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-lg border-2" onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>CONNECT</a>
       <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2" onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>DISMISS</a>
    </div>
 
    @endif
</div>
@elseif($user->role == 'team')
<div class="detail-wrap team" id="divJoinedMember_{{$user->id}}">
    <a href="{{url('view/team-profile/'.$user->slug)}}">
        <div class="details team">
            <div class="top-heading d-flex">
                <img src="{{url('public/images/black_logo.png')}}" alt="logo">
                <h2>{{$user->full_name}}</h2>
            </div>
            <div class="info-sec">
                <div class="right d-flex flex-wrap">
                    <div class="profile-box">
                        <div class="user_profile">
                            <img src="{{ checkUserImage($user->profile_image, 'team/thumb','') }}" alt="team">
                        </div>
                        <div class="profile-box-bottom">
                            <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'medium') }}" alt="FLAG">
                            <h4>{{getLimitText(8,!empty($user->country->name) ? $user->country->name : '-')}}</h4>
                        </div>
                    </div>
                    <div class="user_details">
                        <div class="player-top d-flex">
                            <h4>{{$user->role}}</h4>
                            <span><img src="{{url('public/images/miac_logo.jpg')}}" alt="logo"></span>
                        </div>
                        <ul class="list-unstyled mb-0">
                            <li>
                                <h4>STATE/PROVINCE: <span>{{!empty($user->state) ? getLimitText(8,$user->state->state_name) : '-' }}</span></h4>
                            </li>
                            <li>
                                <h4>YEARS IN EXISTENCE: <span>{{!empty($user->userGeneral->playing_exp) ? $user->userGeneral->playing_exp : '-'}}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENTLY RECRUITING: <span>{{!empty($user->userGeneral->recruiting) ? strtoupper($user->userGeneral->recruiting) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>LEAGUE: <span>{{!empty($user->userGeneral->current_league) ? ucfirst(getLimitText(8,$user->userGeneral->current_league)) : '-'}}</span></h4>
                            </li>
                        </ul>
                        <p class="mt-3 mb-0">www.stolaf.edu.com</p>
                    </div>
                    <div class="bottom-sec">
                        <h6>freeagentfootball.com</h6>
                    </div>
                </div>
            </div>
            <div class="share-bottom">
                <span class="icon-share_icon"></span>
            </div>
        </div>
    </a>
      @if(empty($o_id))
    
    <div class="button-sec member_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-lg border-2"  onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>
            CONNECT
        </a>
        <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2"  onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>
            DISMISS
        </a>
    </div>
    @else
          <div class="button-sec member_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-lg border-2" onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>CONNECT</a>
       <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2" onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>DISMISS</a>
    </div>
    @endif
</div>    
@elseif($user->role == 'coach')
<div class="detail-wrap coach" id="divJoinedMember_{{$user->id}}">
    <a href="{{url('view/coach-profile/'.$user->slug)}}">
        <div class="coach details">
            <div class="top-heading d-flex">
                <img src="{{url('public/images/black_logo.png')}}" alt="logo">
                <h2>{{$user->first_name}} {{$user->last_name}}</h2>
            </div>
            <div class="info-sec">
                <div class="right d-flex flex-wrap">
                    <div class="profile-box">
                        <div class="user_profile">
                            <!-- <div class="top-img d-none d-sm-block">
                                <h3 class="mb-0">George st. lawrence</h3>
                            </div>  -->
                            <img src="{{ checkUserImage($user->profile_image, 'coach/thumb','') }}" alt="player">
                        </div>
                        <div class="profile-box-bottom d-flex align-items-center">
                            <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'medium') }}" alt="FLAG">
                            <h4>{{getLimitText(8,!empty($user->country->name) ? $user->country->name : '-')}}</h4>
                        </div>
                    </div>
                    <div class="user_details">
                        <div class="player-top d-flex">
                            <h4>{{$user->role}}</h4>
                            <span>{{getLimitText(5,getPositionName($user->position_id))}}</span>
                        </div>
                        <ul class="list-unstyled mb-0">
                            <li>
                                <h4>AGE: <span>{{$user->age}}</span></h4>
                            </li> 
                            <li>
                                <h4>CURRENTLY UNDER CONTRACT: <span>{{ !empty($user->userGeneral->under_contract) ?  strtoupper($user->userGeneral->under_contract) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENT TEAM: <span>{{ !empty($user->userGeneral->current_team) ?  ucfirst($user->userGeneral->current_team) : '-'}}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENT LEAGUE: <span>{{!empty($user->userGeneral->current_league) ? ucfirst(getLimitText(8,$user->userGeneral->current_league)) : '-'}}</span></h4>
                            </li>
                            <li>
                                <h4>LOOKING TO SIGN: <span>{{!empty($user->userGeneral->look_to_sign) ? strtoupper($user->userGeneral->look_to_sign) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>PASSPORT READY: <span>{{!empty($user->userGeneral->passport) ?  strtoupper($user->userGeneral->passport) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4> PREP/COLLEGE EXPERIENCE: <span>{{!empty($user->userCollegeExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>PRO EXPERIENCE: <span>{{!empty($user->userProExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>INTERNATIONAL EXPERIENCE: <span>{{!empty($user->userInternationalExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>3-DOWN EXPERIENCE: <span>{{!empty($user->userGeneral->playing_exp) ? 'YES' : 'NO'}}</span></h4>                                
                            </li>  
                            <li>
                                <h4>INDOOR  EXPERIENCE: <span>{{ !empty($user->userIndooreExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                        </ul>
                    </div>
                    <div class="bottom-sec">
                        <h6>freeagentfootball.com</h6>
                    </div>
                </div>
            </div>
            <div class="share-bottom">
                <span class="icon-share_icon"></span>
            </div>
        </div>
    </a>
      @if(empty($o_id))
    
    <div class="button-sec member_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-lg border-2"  onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>
            CONNECT
        </a>
        <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2"  onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>
            DISMISS
        </a>
    </div>
    @else
          <div class="button-sec member_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-lg border-2" onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>CONNECT</a>
       <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2" onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>DISMISS</a>
    </div>
    @endif
</div>    
@endif
@endforeach
@else
<div class="alert alert-danger w-90" role="alert">
    No Members Found!
</div>
@endif
<script>
/*load more with pagination*/
$(document).ready(function() {

    $("#divAllMembersList").mCustomScrollbar({
        theme:"dark"
    });

    setTimeout(function() {
        $("ul.pagination li").first().remove();
    }, 500);
    $(".pagination li a").on('click', function(e) {
        $(".pagination li a").attr("disabled", true);
        $(".explore-btn-loader").html('<div class="text-center"> MORE <i class="fa fa-spin fa-spinner color-blue"></i></div>');
        e.preventDefault();
        var $this = $(this);
        var formData = $('#playerMemberForm').serialize();
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'POST',
            url: pageLink,
            data: formData,
            success: function(response) {
                $('.pagination:first').remove();
                $('#divAllMembersList').append(response.html);
            }
        });
    });
    $(".pagination li a").addClass('btn btn-success explore-btn-loader');
    $(".pagination li a").html('MORE');
});

</script>
