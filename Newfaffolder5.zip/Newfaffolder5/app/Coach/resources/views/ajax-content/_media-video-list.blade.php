<div class="container-fluid">
    <div class="common_heading d-flex justify-content-between align-items-center">
        <h3 class="black black-lg">
            videos
        </h3>
        <div class="text-right common_pagination  mt-3 mt-sm-0">
            <nav aria-label="Page navigation example" title="video">
                {{$getVideos->links('vendor.pagination.simple-bootstrap-4')}} 
            </nav>
        </div>
    </div>   
    <div class="row custom-gutters">  
        @if(count($getVideos) > 0)
        @foreach($getVideos as $video)
        <div class="col-md-4 col-sm-4 col-">
            <div class="video-box">
                <a href="javascript:void(0);" onclick="getMediaModal('{{ $video->id }}')">
                    <img src="{{ checkMediaImage($video->media, 'coach/thumb') }}" alt="video-thmb" class="img-fluid">
                    <img src="{{ url('public/images/play-button.png') }}" class="play-icon" alt="play">
                </a>
                @if($video->user_id == Auth::guard(getAuthGuard())->user()->id)
                <input type="radio" name="media" {{ ($video->order_by == 1) ? 'checked' : ''}} id="video{{$video->id}}" hidden="" onclick="updateSelectMedia('{{ $video->id }}')">
                <label for="video{{$video->id}}" class="select_list mb-0">
                    <i class="fas fa-check"></i>
                </label>
                @endif
            </div>
        </div>
        @endforeach
        @else 
        <div class="col-12">
            <div class="alert alert-danger text-center">No Record Found</div>
        </div>
        @endif
    </div>
</div>
<script>
    $(".pagination li a").on('click', function (e) {
        var type = $(this).parent().parent().parent().attr('title');
        if (type == 'video'){
            e.preventDefault();
            var $this = $(this);
            var pageLink = $this.attr('href');
            getMediaVideoList(pageLink);
        }
    });
</script>