<div class="job-block">
    <div class="jb_logo">
        <img src="images/havoc-lg.png" alt=" job logo">
    </div>
    <div class="jb_info d-flex justify-content-between">
        <ul class="list-unstyled">
            <li>
                <label>NAME</label>
                <p>Swarco Raiders</p>
            </li>
            <li>
                <label>INSTITUTION TYPE</label>
                <p>Team</p>
            </li>
            <li>
                <label>JOB TYPE</label>
                <p>Player</p>
            </li>
            <li>
                <label>POSITION TITLE</label>
                <p>QB (Quarterback)</p>
            </li>
            <li>
                <label>LEVEL</label>
                <p>Indoor/Arena</p>
            </li>
        </ul>
        <ul class="list-unstyled">
            <li>
                <label>LEAGUE or CONFERENCE</label>
                <p>AAL</p>
            </li>
            <li>
                <label>LOCATION</label>
                <p>United States</p>
            </li>
            <li>
                <img class="flag" src="images/american_flag.jpg" alt="flag">
            </li>
            <li>
                <label>DATE</label>
                <p>Apr 24, 2018</p>
            </li>
        </ul>
        <ul class="list-unstyled views">
            <li>
                <label>VIEWS</label>
                <p>33</p>
            </li>
            <li>
                <a href="job-detail.php?page=<?= $_GET['page']; ?>" class="btn btn-primary text-uppercase">VIEW</a>
            </li>
            <li>
                <a href="javascript:void(0);">
                <span class="icon icon-share_icon"></span>
            </a>
            </li>
        </ul>
    </div>
</div>
<div class="job-block">
    <div class="jb_logo">
        <img src="images/black_logo.png" alt=" job logo">
    </div>
    <div class="jb_info d-flex justify-content-between">
        <ul class="list-unstyled">
            <li>
                <label>NAME</label>
                <p>FreeAgentFootball.com</p>
            </li>
            <li>
                <label>INSTITUTION TYPE</label>
                <p>Organization</p>
            </li>
            <li>
                <label>JOB TYPE</label>
                <p>Staff and Personnel</p>
            </li>
            <li>
                <label>POSITION TITLE</label>
                <p>Sales</p>
            </li>
            <li>
                <label>LEVEL</label>
                <p>Director of Sales</p>
            </li>
        </ul>
        <ul class="list-unstyled">
            <li>
                <label>LEAGUE or CONFERENCE</label>
                <p>AAL</p>
            </li>
            <li>
                <label>LOCATION</label>
                <p>United States</p>
            </li>
            <li>
                <img class="flag" src="images/american_flag.jpg" alt="flag">
            </li>
            <li>
                <label>DATE</label>
                <p>Apr 24, 2018</p>
            </li>
        </ul>
        <ul class="list-unstyled views">
            <li>
                <label>VIEWS</label>
                <p>47</p>
            </li>
            <li>
                <a href="job-detail.php?page=<?= $_GET['page']; ?>" class="btn btn-primary text-uppercase">VIEW</a>
            </li>
            <li>
                <a href="javascript:void(0);">
                <span class="icon icon-share_icon"></span>
            </a>
            </li>
        </ul>
    </div>
</div>
<div class="job-block">
    <div class="jb_logo">
        <img src="images/empire.png" alt=" job logo">
    </div>
    <div class="jb_info d-flex justify-content-between">
        <ul class="list-unstyled">
            <li>
                <label>NAME</label>
                <p>Albany Empire</p>
            </li>
            <li>
                <label>INSTITUTION TYPE</label>
                <p>Team</p>
            </li>
            <li>
                <label>JOB TYPE</label>
                <p>Staff and Personnel</p>
            </li>
            
            <li>
                <label>POSITION AREA</label>
                <p>Marketing</p>
            </li>
            <li>
                <label>POSITION TITLE</label>
                <p>Director of Marketing</p>
            </li>
            
            
        </ul>
        <ul class="list-unstyled">
           <li>
                <label>LEVEL</label>
                <p>Indoor/Arena</p>
            </li>
            <li>
                <label>LEAGUE or CONFERENCE</label>
                <p>AAL</p>
            </li>
            <li>
                <label>LOCATION</label>
                <p>Brazil</p>
            </li>
            <li>
                <img class="flag" src="images/brazil_logo.png" alt="flag">
            </li>
            <li>
                <label>DATE</label>
                <p>Apr 25, 2018</p>
            </li>
        </ul>
        <ul class="list-unstyled views">
            <li>
                <label>VIEWS</label>
                <p>12</p>
            </li>
            <li>
                <a href="job-detail.php?page=<?= $_GET['page']; ?>" class="btn btn-primary text-uppercase">VIEW</a>
            </li>
            <li>
                <a href="javascript:void(0);">
                <span class="icon icon-share_icon"></span>
            </a>
            </li>
        </ul>
    </div>
</div>
<div class="job-block">
    <div class="jb_logo">
        <img src="images/havoc-lg.png" alt=" job logo">
    </div>
    <div class="jb_info d-flex justify-content-between">
        <ul class="list-unstyled">
            <li>
                <label>NAME</label>
                <p>Swarco Raiders</p>
            </li>
            <li>
                <label>INSTITUTION TYPE</label>
                <p>Team</p>
            </li>
            <li>
                <label>JOB TYPE</label>
                <p>Player</p>
            </li>
            <li>
                <label>POSITION TITLE</label>
                <p>QB (Quarterback)</p>
            </li>
            <li>
                <label>LEVEL</label>
                <p>Indoor/Arena</p>
            </li>
        </ul>
        <ul class="list-unstyled">
            <li>
                <label>LEAGUE or CONFERENCE</label>
                <p>AAL</p>
            </li>
            <li>
                <label>LOCATION</label>
                <p>United States</p>
            </li>
            <li>
                <img class="flag" src="images/american_flag.jpg" alt="flag">
            </li>
            <li>
                <label>DATE</label>
                <p>Apr 24, 2018</p>
            </li>
        </ul>
        <ul class="list-unstyled views">
            <li>
                <label>VIEWS</label>
                <p>33</p>
            </li>
            <li>
                <a href="job-detail.php?page=<?= $_GET['page']; ?>" class="btn btn-primary text-uppercase">VIEW</a>
            </li>
            <li>
                <a href="javascript:void(0);">
                <span class="icon icon-share_icon"></span>
            </a>
            </li>
        </ul>
    </div>
</div>
<div class="job-block">
    <div class="jb_logo">
        <img src="images/black_logo.png" alt=" job logo">
    </div>
    <div class="jb_info d-flex justify-content-between">
        <ul class="list-unstyled">
            <li>
                <label>NAME</label>
                <p>FreeAgentFootball.com</p>
            </li>
            <li>
                <label>INSTITUTION TYPE</label>
                <p>Organization</p>
            </li>
            <li>
                <label>JOB TYPE</label>
                <p>Staff and Personnel</p>
            </li>
            <li>
                <label>POSITION TITLE</label>
                <p>Sales</p>
            </li>
            <li>
                <label>LEVEL</label>
                <p>Director of Sales</p>
            </li>
        </ul>
        <ul class="list-unstyled">
            <li>
                <label>LEAGUE or CONFERENCE</label>
                <p>AAL</p>
            </li>
            <li>
                <label>LOCATION</label>
                <p>United States</p>
            </li>
            <li>
                <img class="flag" src="images/american_flag.jpg" alt="flag">
            </li>
            <li>
                <label>DATE</label>
                <p>Apr 24, 2018</p>
            </li>
        </ul>
        <ul class="list-unstyled views">
            <li>
                <label>VIEWS</label>
                <p>47</p>
            </li>
            <li>
                <a href="job-detail.php?page=<?= $_GET['page']; ?>" class="btn btn-primary text-uppercase">VIEW</a>
            </li>
            <li>
                <a href="javascript:void(0);">
                <span class="icon icon-share_icon"></span>
            </a>
            </li>
        </ul>
    </div>
</div>