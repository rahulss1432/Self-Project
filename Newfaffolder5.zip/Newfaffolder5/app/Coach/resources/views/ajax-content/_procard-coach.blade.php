<div class="pro-card">
    <h3 class="user_name">{{$user->signature}}</h3>
    <div class="members_list">
        <div class="common_heading">
            <h3 class="black black-lg">
                FAF PRO-CARD
            </h3>
        </div>
    </div>
    <div id="pro-card">
        <div class="player-detail">
            <div class="top-heading d-flex">
                <img src="{{ url('public/images/black_logo.png') }}" alt="logo">
                <h2>{{getLimitText(15,$user->full_name)}}</h2>
            </div>
            <div class="info-sec">
                <div class="right d-flex">
                    <div class="profile-box">
                        <div class="user_profile">
                            <!-- <div class="top-img d-none d-sm-block">
                                <h3>George st. lawrence</h3>
                            </div> -->
                            <img src="{{ checkUserImage($user->profile_image, 'coach/thumb','') }}" alt="coach">
                        </div>
                        <div class="profile-box-bottom d-flex align-items-center">
                            <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'medium') }}" alt="FLAG">
                            <h4 class="text-uppercase">{{getLimitText('8', !empty($user->country->name) ? $user->country->name : '-')}}</h4>
                            <!-- <h6 class="signature d-block d-sm-none mt-2">George st. lawrence</h6> -->
                        </div>
                    </div>
                    <div class="user_details">
                        <div class="player-top d-flex justify-content-between align-items-center">
                            <h4>{{$user->role}}</h4>
                            <span>{{getLimitText(5,getPositionName($user->position_id))}}</span>
                        </div>
                        <ul class="list-unstyled">
                            <li>
                                <h4>CURRENTLY UNDER CONTRACT: <span class="text-uppercase">{{ (!empty($user->userGeneral->under_contract)) ? $user->userGeneral->under_contract : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENT TEAM: <span>{{ (!empty($user->userGeneral->current_team)) ? ucfirst(getLimitText(15,$user->userGeneral->current_team)) : '-'}}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENTLY LEAGUE: <span>{{ (!empty($user->userGeneral->current_league)) ?  ucfirst(getLimitText(15,$user->userGeneral->current_league)) : '-'}}</span></h4>
                            </li>
                            <li>
                                <h4>LOOKING TO SIGN: <span class="text-uppercase">{{ (!empty($user->userGeneral->look_to_sign)) ? strtoupper($user->userGeneral->look_to_sign) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>PASSPORT READY: <span class="text-uppercase">{{ (!empty($user->userGeneral->passport)) ? $user->userGeneral->passport : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>PREP/COLLEGE EXPERIENCE: <span class="text-uppercase">{{ (!empty($user->userCollegeExperince) && count($user->userCollegeExperince) > 0) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>PRO EXPERIENCE: <span class="text-uppercase">{{ (!empty($user->userProExperince)&& count($user->userProExperince) > 0)  ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>INTERNATIONAL EXPERIENCE: <span class="text-uppercase">{{  (!empty($user->userInternationalExperince) && count($user->userInternationalExperince) > 0) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>3-DOWN EXPERIENCE: <span class="text-uppercase">{{  (!empty($user->userGeneral->playing_exp)) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>INDOOR  EXPERIENCE: <span class="text-uppercase">{{ (!empty($user->userIndooreExperince) && count($user->userIndooreExperince) > 0 ) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="bottom-sec">
                    @if(!empty($user->website))
                    <a href="{{$user->website}}" target="_blank">{{getLimitText(18,$user->website)}}</a>
                    @else
                    freeagentfootball.com
                    @endif
                </div>
            </div>

            <div class="share-bottom">
                <a  href="javascript:void(0);" onclick="ShareModal('procard-share', '')"><span class="icon-share_icon"></span></a>
            </div>
        </div>
    </div>
    <div class="share-section">
        <ul class="list-unstyled list-inline">
            <li class="list-inline-item">
                <p>DOWNLOAD FAF PRO-CARD</p>
                <a href="javascript:void(0);" onclick="download_pro_Card();">
                    <span class="icon-download_icon"></span>
                </a>
            </li>
            <li class="list-inline-item">
                <p>SHARE FAF PRO-CARD</p>
                <a href="javascript:void(0);" onclick="ShareModal('procard-share', '')">
                    <span class="icon-share_icon"></span>
                </a>
            </li>
        </ul>
    </div>
</div>
<script type="text/javascript" src="https://cdn.bootcss.com/dom-to-image/2.6.0/dom-to-image.min.js"></script>
<script type="text/javascript" src="https://cdn.bootcss.com/FileSaver.js/2014-11-29/FileSaver.min.js"></script>
<script>
                    function download_pro_Card() {
                        domtoimage.toBlob(document.getElementById('pro-card'))
                                .then(function (blob) {
                                    window.saveAs(blob, 'ProCard.png');
                                    var authId = "{{Auth::guard(getAuthGuard())->user()->id}}";
                                    var userId = "{{$user->id}}";
                                    if (authId != userId) {
                                        sendProcardNofication("{{$user->id}}");
                                    }
                                });
                    }

                    // send notification pro card download
                    function sendProcardNofication(id) {
                        var url = "{{ url('send-procard-notification') }}/" + id;
                        $.ajax({type: "GET", url: url,
                            success: function (response) {
                                console.log(response);
                            },
                            error: function () {
                            },
                            complete: function () {
                            }
                        });
                    }

</script>

