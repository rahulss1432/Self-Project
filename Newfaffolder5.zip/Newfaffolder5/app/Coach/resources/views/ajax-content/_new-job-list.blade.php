@if( $jobs->count() > 0 )
@foreach( $jobs as $job )

    <div class="job-block">
        <div class="jb_logo">
            <a href="{{url('jobs-detail',base64_encode($job->id))}}"><img src="{{ checkUserImage($job->user->profile_image, 'team/thumb','') }}" alt="job logo"></a>
        </div>
        <div class="jb_info d-flex justify-content-between">
            <ul class="list-unstyled">
                <li>
                    <label>NAME</label>
                    <p>{{!empty($job->institution_name) ? $job->institution_name : '-'}}</p>
                </li>
                <li>
                    <label>INSTITUTION TYPE</label>
                    <p>{{!empty($job->institution_type) ? $job->institution_type : '-'}}</p>
                </li>
                <li>
                    <label>JOB TYPE</label>
                    <p>{{!empty($job->job_type) ? $job->job_type : '-'}}</p>
                </li>
                @php
                $positionName = getJobPositionName($job->position_id);
                @endphp            
                @if($job->job_type == 'player')            
                <li>
                    <label>POSITION TITLE</label>
                    @if (!empty($positionName))                
                   <p>{{getLimitText(10,implode(',',$positionName))}}</p>
                    @else
                    <p>-</p>
                    @endif
                </li>
                <li>
                    <label>LEVEL</label>
                    <p>{{!empty($job->level->level_name) ? $job->level->level_name : '-'}}</p>
                </li>
                @else
                <li>
                    <label>POSITION AREA</label>
                    @if (!empty($positionName))                
                    @foreach($positionName as $val)                                                            
                    <p>{{$val}}</p>
                    @endforeach
                    @else
                    <p>-</p>
                    @endif
                </li> 
                <li>
                    <label>POSITION TITLE</label>
                    <p>{{getLimitText(8, !empty($job->position_title) ? $job->position_title : '-')}}</p>
                </li> 
                @endif
            </ul>
            <ul class="list-unstyled">
                <li>
                    <label>LEAGUE or CONFERENCE</label>
                    <p class="text-uppercase">{{!empty($job->conference) ? $job->conference : '-'}}</p>
                </li>
                <li>
                    <label>LOCATION</label>
                    <p>{{!empty($job->country->name) ? $job->country->name : '-'}}</p>
                </li>
                <li>
                   <img class="flag" src="{{ checkFlagImage(!empty($job->country->short_name) ? $job->country->short_name : '', 'small') }}" alt="flag">                    
                </li>
                <li>
                    <label>DATE</label>
                    <p>{{getMonthDateYearFormat($job->created_at)}}</p>
                </li>
            </ul>
            <ul class="list-unstyled views">
                <li>
                    <label>VIEWS</label>
                    <p>{{getViewCountByJob($job->id)}}</p>
                </li>
                <li>
                    <a href="{{url('jobs-detail',base64_encode($job->id))}}" class="btn btn-primary text-uppercase">VIEW</a>
                </li>
                <li>
                    <a href="javascript:void(0);" onclick="ShareModal('job-share', {{$job->id}})">
                        <span class="icon icon-share_icon"></span>
                    </a>
                </li>
            </ul>
        </div>
    </div>


@endforeach
@else
<div class="alert alert-danger w-70 mt-md-5 mt-3" role="alert">
    No Jobs Available!
</div>
@endif