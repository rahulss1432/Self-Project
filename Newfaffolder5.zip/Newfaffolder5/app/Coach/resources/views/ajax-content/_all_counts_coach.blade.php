<ul class="list-inline">
    <li class="list-inline-item">
        <h4>{{$getViewCount}}</h4>
        <p>PROFILE VIEW</p>
    </li>
    <li class="list-inline-item">
        <h4>{{$getConnectionsCount}}</h4>
        <p>CONNECTIONS</p>
    </li>
    <li class="list-inline-item">
        <h4>{{$getFollowCount}}</h4>
        <p>TRACKING</p>
    </li>
    <li class="list-inline-item">
        <h4>{{$getFollowersCount}}</h4>
        <p>TRACKERS</p>
    </li>
    <li class="list-inline-item">
        <h4>{{$getLikeCount}}</h4>
        <p>PROFILE LIKE</p>
    </li>
</ul>