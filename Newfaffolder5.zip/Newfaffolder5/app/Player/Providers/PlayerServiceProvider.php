<?php

namespace App\Player\Providers;

use Illuminate\Support\ServiceProvider;

class PlayerServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services. 
     *
     * @return void
     */
    /*
   
    */
    public function boot()
    {
        $this->loadViewsFrom(__DIR__.'/../Resources/Views','player');
        $this->loadTranslationsFrom(__DIR__.'/../Resources/Lang', 'player');
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register(RouteServiceProvider::class);
    }
    protected function loadViewsFrom($path, $namespace)
    {
        $this->app['view']->addNamespace('player', base_path().'/app/Player/resources/views');
    }

    protected function loadTranslationsFrom($path, $namespace)
    {
        $this->app['translator']->addNamespace($namespace, $path);
    }
}
