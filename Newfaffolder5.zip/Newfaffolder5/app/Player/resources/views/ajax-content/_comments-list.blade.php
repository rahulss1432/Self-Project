@if( count($comments) > 0 )
<div class="users_msg">
    <ul class="list-unstyled mb-0" >
        @foreach( $comments as $comment )
        <li class="msg d-flex">
            <div class="msg_left">
                <img src="{{ checkUserImage($comment->user->profile_image, $comment->user->role.'/thumb') }}" class="rounded-circle" alt="user">
            </div>
            <div class="msg_body">
                <h6 class="msg_heading">
                    @if($comment->from_id == Auth::guard(getAuthGuard())->user()->id)
                    <a href="{{ url('player/player-profile/')}}">{{ $comment->user->first_name . ' ' . $comment->user->last_name }}</a>
                    @elseif($comment->user->role == "player")
                    <a href="{{ url('view/player-profile/'.$comment->user->slug )}}">{{ $comment->user->first_name . ' ' . $comment->user->last_name }}</a>
                    @elseif($comment->user->role == "coach")
                    <a href="{{ url('view/coach-profile/'.$comment->user->slug )}}">{{ $comment->user->first_name . ' ' . $comment->user->last_name }}</a>
                    @elseif($comment->user->role == "team")
                    <a href="{{ url('view/team-profile/'.$comment->user->slug )}}">{{ $comment->user->first_name . ' ' . $comment->user->last_name }}</a>
                    @endif
                    <span class="time">{{ dateDayAgo($comment->created_at) }}</span>
                </h6>
                <p>{{ $comment->comment }}</p>
                @if($comment->from_id == Auth::guard(getAuthGuard())->user()->id)
                <a href="javascript:void(0);" class="delete" onclick="deletePostComment('{{ $comment->id }}', '{{ $comment->post_id }}')">Delete</a>
                @endif
            </div>
        </li>
        @endforeach
        @endif
        @if( $total_count > 3 )
        <li class="view_comment">
            <a href="javascript:void(0);" onclick="getPostComments('{{ $pid }}', 'all')" id="CommentModal">
                View All Comments
            </a>
        </li>
    </ul>
</div>
@endif            
<script>
//  Function for delete post comment
    function deletePostComment(id, postId){
    bootbox.confirm({
    message: "Are you sure want to delete comment?",
            buttons: {
            confirm: {
            label: 'Yes',
                    className: 'btn-success border-1 font-14'
            },
                    cancel: {
                    label: 'No',
                            className: 'btn btn btn-light rounded-0'
                    }
            },
            callback: function (result) {
            if (result){
            $.post("{{ url('player/remove-post-comment') }}", {_token: "{{ csrf_token() }}", id: id}, function(data){
            if (data.success){
            message('success', data.message);
            getPostComments(postId, 'first');
            } else{
            message('error', data.message);
            }
            });
            }
            }
    });
    }
</script>
