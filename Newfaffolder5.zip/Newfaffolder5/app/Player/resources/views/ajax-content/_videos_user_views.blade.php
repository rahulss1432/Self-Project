<div class="profile_videos">
    <div class="left_loader">
        <div class="border_loader">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
    <!-- <div class="row">
        <div class="col-sm-12">
            <div class="player">
                <img src="{{ url('public/images/videoplayer_img.jpg') }}" alt="video img">
            </div>
        </div>
    </div> -->
    <div class="row">
        @if(count($mediaList) > 0)
        @foreach($mediaList as $key => $media)
        @if($key == 0 || $key == 1)
        @if(count($mediaList) == 2)
        <div class="col-sm-6 mb-2 mb-sm-0">
            <div class="first_img">             
                <img src="{{  checkMediaByType($media->media, getUserById($media->user_id, 'role'), $media->media_type, 'profile-media-thumb') }}" alt="video img">
            </div>
        </div>
        @endif
        @endif
        @if(count($mediaList) == 1 && $key == 0)
        <div class="col-sm-12">
            <div class="first_img">
                <img src="{{  checkMediaByType($media->media, getUserById($media->user_id, 'role'), $media->media_type, 'profile-media-thumb') }}" alt="video img">
            </div>
        </div>
        @endif
        @if(count($mediaList) > 2 && $key == 0)
        <div class="col-sm-8">
            <div class="first_img profile_first_img">
                <img src="{{  checkMediaByType($media->media, getUserById($media->user_id, 'role'), $media->media_type, 'profile-media-thumb') }}" alt="video img">
            </div>
        </div>
        @endif
        @endforeach
        @else 
         <div class="col-sm-12">
            <div class="first_img">
                <img src="{{ url('public/images/defaul_profile_media.jpg') }}" alt="video img">
            </div>
        </div>
        @endif
        @if(count($mediaList) > 2)
        <div class="col-sm-4 pl-0">
            <div class="video_thumb">
                <ul class="list-unstyled mb-0 d-xs-flex">
                    @foreach($mediaList as $key => $media)
                    @if($key == 1)
                    <li>
                        <img src="{{  checkMediaByType($media->media, getUserById($media->user_id, 'role'), $media->media_type, 'profile-media-thumb') }}" alt="video thumb">
                        <div class="overlay">
                            <!-- <div class="action">
                                <a href="javascript:void(0);"> <i class="icon-play-button"></i></a>
                                <a href="javascript:void(0);"> <i class="icon-share_icon"></i></a>
                            </div> -->
                        </div>
                    </li>
                    @endif
                    @if(count($mediaList) >= 3 && $key == 2)
                    <li class="viewmore">
                        @php 
                        if($user->id == Auth::guard(getAuthGuard())->user()->id){
                            $url = url('player/player-media');  
                        }else{
                            $url = url($user->role.'/'.$user->role.'-media/'.$user->slug);  
                        }
                        @endphp
                        <a href="{{ $url }}">
                            <span> + {{ count($mediaList) - 2 }} </span>
                            <p>VIEW ALL</p>
                        </a>
                    </li>
                    @endif
                    @endforeach
                </ul>
            </div>
        </div> 
        @endif
    </div>
</div>
<div class="userprofile_view">
    <ul class="list-inline text-center">
        @if(count($mediaList) > 0)
        @foreach($mediaList as $key => $media)
         @if($key <= 5) 
         <li class="list-inline-item">
             @php 
                if($user->id == Auth::guard(getAuthGuard())->user()->id){
                $url = url('player/player-media');  
                }else{
                    $url = url($user->role.'/'.$user->role.'-media/'.$user->slug);  
                }
                @endphp  
                <a href="{{ $url }}">              
                 <img class="rounded-circle" src="{{   checkMediaByType($media->media, getUserById($media->user_id, 'role'), $media->media_type, 'profile-media-thumb') }}" alt="user img">
             </a>
         </li>
        @endif
        @endforeach
        @endif
    </ul>
    @if(count($mediaList) > 6)
    <div class="viewmore text-center">
        @php 
            if($user->id == Auth::guard(getAuthGuard())->user()->id){
                $url = url('player/player-media');  
            }else{
                $url = url($user->role.'/'.$user->role.'-media/'.$user->slug);  
            }
            @endphp
        <a href="{{ $url }}">
            <span>+ {{ count($mediaList) - 6 }}</span>
            <p>VIEW ALL</p>
        </a>
    </div>
    @endif
</div>