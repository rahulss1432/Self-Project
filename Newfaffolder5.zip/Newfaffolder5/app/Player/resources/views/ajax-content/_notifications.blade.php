<table class="table">
    <tr>
        <td>Notifications</td>
        <td>Time</td>
    </tr>
    @forelse ( $notifications as $notification )
    <tr>
        <td>{{ $notification->message }}</td>
        <td width="200">{{ dateDayAgo($notification->created_at) }}</td>
    </tr>
    @empty
    <tr>
        <td colspan="2"><div class="alert alert-danger mt-3"> No Notifications Found! </div></td>
    </tr>
    @endforelse
</table>
<div id="pagination">
{{ $notifications->links() }}
</div>