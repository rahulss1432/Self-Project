<?php include_once '../include/constant.php'; ?>

<div class="connections-wrap">
    <div class="detail-wrap">
        <a href="<?php echo BASE_URL ?>/player/player-profile.php">
            <div class="player details">
                <div class="top-heading d-flex">
                    <img src="<?php echo IMAGES_URL ?>/images/white_logo.png" alt="logo">
                    <h2>desean jackson</h2>
                </div>
                <div class="info-sec">
                    <div class="left">
                        <ul class="list-unstyled">
                            <li>
                                <p>HT</p><span>6'1"</span>
                            </li>
                            <li>
                                <p>WT</p><span>195</span>
                            </li>
                            <li>
                                <p>40</p><span>4.5</span>
                            </li>
                            <li>
                                <p>VERT</p><span>36</span>
                            </li>
                        </ul>
                    </div>
                    <div class="right d-flex flex-wrap">
                        <div class="profile-box">
                            <div class="user_profile">
                                <img src="<?php echo IMAGES_URL ?>/images/player1.jpg" alt="player">
                            </div>
                            <div class="profile-box-bottom d-flex align-items-center">
                                <img src="<?php echo IMAGES_URL ?>/images/american_flag.jpg" alt="FLAG">
                                <h4>Georgia</h4>
                            </div>
                        </div>
                        <div class="user_details">
                            <div class="player-top d-flex">
                                <h4>player </h4>
                                <span>rb/db</span>
                            </div>
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <h4>AGE: <span>24</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENTLY UNDER CONTRACT: <span>NO</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT TEAM: <span>Altianta Havoc</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT LEAGUE: <span>AAL</span></h4>
                                </li>
                                <li>
                                    <h4>LOOKING TO SIGN: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>PASSPORT READY: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4> PREP/COLLEGE EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>PRO EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>INTERNATIONAL EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>INDOOR  EXPERIENCE: <span>YES</span></h4>
                                </li>
                            </ul>
                        </div>
                        <div class="bottom-sec">
                            <h6>freeagentfootball.com</h6>
                        </div>
                    </div>
                </div>

                <div class="share-bottom">
                    <span class="icon-share_icon"></span>
                </div>
            </div>
        </a>
        <div class="button-sec">
            <a href="javascript:void(0);" class="btn btn-success btn-sm border-1">CONNECT</a>
            <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1">DISMISS</a>
        </div>
    </div>
    <div class="detail-wrap team">
        <a href="<?php echo BASE_URL ?>/team/team-profile.php">
            <div class="details team">
                <div class="top-heading d-flex">
                    <img src="<?php echo IMAGES_URL ?>/images/black_logo.png" alt="logo">
                    <h2>st. olaf college</h2>
                </div>
                <div class="info-sec">
                    <div class="right d-flex flex-wrap">
                        <div class="profile-box">
                            <div class="user_profile">
                                <img src="<?php echo IMAGES_URL ?>/images/olaf_flag.png" alt="team">
                            </div>
                            <div class="profile-box-bottom">
                                <img src="<?php echo IMAGES_URL ?>/images/flag-canada.jpg" alt="FLAG">
                                <h4>CANADA</h4>
                            </div>
                        </div>
                        <div class="user_details">
                            <div class="player-top d-flex">
                                <h4>team </h4>
                                <span><img src="<?php echo IMAGES_URL ?>/images/miac_logo.jpg" alt="logo"></span>
                            </div>
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <h4>STATE/PROVINCE: <span>ONTARIO</span></h4>
                                </li>
                                <li>
                                    <h4>YEARS IN EXISTENCE: <span>59</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENTLY RECRUITING: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>LEAGUE: <span>MIAC</span></h4>
                                </li>
                            </ul>
                            <p class="mt-3 mb-0">www.stolaf.edu.com</p>
                        </div>
                        <div class="bottom-sec">
                            <h6>freeagentfootball.com</h6>
                        </div>
                    </div>
                </div>
                <div class="share-bottom">
                    <span class="icon-share_icon"></span>
                </div>
            </div>
        </a>
        <div class="button-sec">
            <a href="javascript:void(0);" class="btn btn-success btn-sm border-1">CONNECT</a>
            <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1">DISMISS</a>
        </div>
    </div>
    <div class="detail-wrap coach">
        <a href="<?php echo BASE_URL ?>/coach/coach-profile.php">
            <div class="coach details">
                <div class="top-heading d-flex">
                    <img src="<?php echo IMAGES_URL ?>/images/black_logo.png" alt="logo">
                    <h2>george st. lawrence</h2>
                </div>
                <div class="info-sec">
                    <div class="right d-flex flex-wrap">
                        <div class="profile-box">
                            <div class="user_profile">
                                <!-- <div class="top-img d-none d-sm-block">
                                    <h3 class="mb-0">George st. lawrence</h3>
                                </div>  -->
                                <img src="<?php echo IMAGES_URL ?>/images/coach-avtar01.jpg" alt="player">
                            </div>
                            <div class="profile-box-bottom d-flex align-items-center">
                                <img src="<?php echo IMAGES_URL ?>/images/canada_flag.jpg" alt="FLAG">
                                <h4>CANADA</h4>
                            </div>
                        </div>
                        <div class="user_details">
                            <div class="player-top d-flex">
                                <h4>coach </h4>
                                <span>offensive <br>coordinator</span>
                            </div>
                            <ul class="list-unstyled mb-0">
                               <!--  <li>
                                    <h4>AGE: <span>24</span></h4>
                                </li> -->
                                <li>
                                    <h4>CURRENTLY UNDER CONTRACT: <span>NO</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT TEAM: <span>Altianta Havoc</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT LEAGUE: <span>AAL</span></h4>
                                </li>
                                <li>
                                    <h4>LOOKING TO SIGN: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>PASSPORT READY: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4> PREP/COLLEGE EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>PRO EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>INTERNATIONAL EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>3-DOWN EXPERIENCE: <span>YES</span></h4>
                                </li>  
                                <li>
                                    <h4>INDOOR  EXPERIENCE: <span>YES</span></h4>
                                </li>
                            </ul>
                        </div>
                        <div class="bottom-sec">
                            <h6>freeagentfootball.com</h6>
                        </div>
                    </div>
                </div>

                <div class="share-bottom">
                    <span class="icon-share_icon"></span>
                </div>
            </div>
        </a>
        <div class="button-sec">
            <a href="javascript:void(0);" class="btn btn-success btn-sm border-1">CONNECT</a>
            <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1">DISMISS</a>
        </div>
    </div>
    <div class="detail-wrap">
        <a href="<?php echo BASE_URL ?>/player/player-profile.php">
            <div class="player details">
                <div class="top-heading d-flex">
                    <img src="<?php echo IMAGES_URL ?>/images/white_logo.png" alt="logo">
                    <h2>desean jackson</h2>
                </div>
                <div class="info-sec">
                    <div class="left">
                        <ul class="list-unstyled">
                            <li>
                                <p>HT</p><span>6'1"</span>
                            </li>
                            <li>
                                <p>WT</p><span>195</span>
                            </li>
                            <li>
                                <p>40</p><span>4.5</span>
                            </li>
                            <li>
                                <p>VERT</p><span>36</span>
                            </li>
                        </ul>
                    </div>
                    <div class="right d-flex flex-wrap">
                        <div class="profile-box">
                            <div class="user_profile">
                                <img src="<?php echo IMAGES_URL ?>/images/player_01.png" alt="player">
                            </div>
                            <div class="profile-box-bottom d-flex align-items-center">
                                <img src="<?php echo IMAGES_URL ?>/images/american_flag.jpg" alt="FLAG">
                                <h4>Georgia</h4>
                            </div>
                        </div>
                        <div class="user_details">
                            <div class="player-top d-flex">
                                <h4>player </h4>
                                <span>rb/db</span>
                            </div>
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <h4>AGE: <span>24</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENTLY UNDER CONTRACT: <span>NO</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT TEAM: <span>Altianta Havoc</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT LEAGUE: <span>AAL</span></h4>
                                </li>
                                <li>
                                    <h4>LOOKING TO SIGN: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>PASSPORT READY: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4> PREP/COLLEGE EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>PRO EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>INTERNATIONAL EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>INDOOR  EXPERIENCE: <span>YES</span></h4>
                                </li>
                            </ul>
                        </div>
                        <div class="bottom-sec">
                            <h6>freeagentfootball.com</h6>
                        </div>
                    </div>
                </div>

                <div class="share-bottom">
                    <span class="icon-share_icon"></span>
                </div>
            </div>
        </a>
        <div class="button-sec">
            <a href="javascript:void(0);" class="btn btn-success btn-sm border-1">CONNECT</a>
            <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1">DISMISS</a>
        </div>
    </div>

    <div class="detail-wrap">
        <a href="<?php echo BASE_URL ?>/player/player-profile.php">
            <div class="player details">
                <div class="top-heading d-flex">
                    <img src="<?php echo IMAGES_URL ?>/images/white_logo.png" alt="logo">
                    <h2>desean jackson</h2>
                </div>
                <div class="info-sec">
                    <div class="left">
                        <ul class="list-unstyled">
                            <li>
                                <p>HT</p><span>6'1"</span>
                            </li>
                            <li>
                                <p>WT</p><span>195</span>
                            </li>
                            <li>
                                <p>40</p><span>4.5</span>
                            </li>
                            <li>
                                <p>VERT</p><span>36</span>
                            </li>
                        </ul>
                    </div>
                    <div class="right d-flex flex-wrap">
                        <div class="profile-box">
                            <div class="user_profile">
                                <img src="<?php echo IMAGES_URL ?>/images/player_02.png" alt="player">
                            </div>
                            <div class="profile-box-bottom d-flex align-items-center">
                                <img src="<?php echo IMAGES_URL ?>/images/american_flag.jpg" alt="FLAG">
                                <h4>Georgia</h4>
                            </div>
                        </div>
                        <div class="user_details">
                            <div class="player-top d-flex">
                                <h4>player </h4>
                                <span>rb/db</span>
                            </div>
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <h4>AGE: <span>24</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENTLY UNDER CONTRACT: <span>NO</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT TEAM: <span>Altianta Havoc</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT LEAGUE: <span>AAL</span></h4>
                                </li>
                                <li>
                                    <h4>LOOKING TO SIGN: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>PASSPORT READY: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4> PREP/COLLEGE EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>PRO EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>INTERNATIONAL EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>INDOOR  EXPERIENCE: <span>YES</span></h4>
                                </li>
                            </ul>
                        </div>
                        <div class="bottom-sec">
                            <h6>freeagentfootball.com</h6>
                        </div>
                    </div>
                </div>

                <div class="share-bottom">
                    <span class="icon-share_icon"></span>
                </div>
            </div>
        </a>
        <div class="button-sec">
            <a href="javascript:void(0);" class="btn btn-success btn-sm border-1">CONNECT</a>
            <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1">DISMISS</a>
        </div>
    </div>

    <div class="detail-wrap">
        <a href="<?php echo BASE_URL ?>/player/player-profile.php">
            <div class="player details">
                <div class="top-heading d-flex">
                    <img src="<?php echo IMAGES_URL ?>/images/white_logo.png" alt="logo">
                    <h2>desean jackson</h2>
                </div>
                <div class="info-sec">
                    <div class="left">
                        <ul class="list-unstyled">
                            <li>
                                <p>HT</p><span>6'1"</span>
                            </li>
                            <li>
                                <p>WT</p><span>195</span>
                            </li>
                            <li>
                                <p>40</p><span>4.5</span>
                            </li>
                            <li>
                                <p>VERT</p><span>36</span>
                            </li>
                        </ul>
                    </div>
                    <div class="right d-flex flex-wrap">
                        <div class="profile-box">
                            <div class="user_profile">
                                <img src="<?php echo IMAGES_URL ?>/images/player_03.png" alt="player">
                            </div>
                            <div class="profile-box-bottom d-flex align-items-center">
                                <img src="<?php echo IMAGES_URL ?>/images/american_flag.jpg" alt="FLAG">
                                <h4>Georgia</h4>
                            </div>
                        </div>
                        <div class="user_details">
                            <div class="player-top d-flex">
                                <h4>player </h4>
                                <span>rb/db</span>
                            </div>
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <h4>AGE: <span>24</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENTLY UNDER CONTRACT: <span>NO</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT TEAM: <span>Altianta Havoc</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT LEAGUE: <span>AAL</span></h4>
                                </li>
                                <li>
                                    <h4>LOOKING TO SIGN: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>PASSPORT READY: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4> PREP/COLLEGE EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>PRO EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>INTERNATIONAL EXPERIENCE: <span>YES</span></h4>
                                </li>
                                <li>
                                    <h4>INDOOR  EXPERIENCE: <span>YES</span></h4>
                                </li>
                            </ul>
                        </div>
                        <div class="bottom-sec">
                            <h6>freeagentfootball.com</h6>
                        </div>
                    </div>
                </div>

                <div class="share-bottom">
                    <span class="icon-share_icon"></span>
                </div>
            </div>
        </a>
        <div class="button-sec">
            <a href="javascript:void(0);" class="btn btn-success btn-sm border-1">CONNECT</a>
            <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1">DISMISS</a>
        </div>
    </div>
</div>