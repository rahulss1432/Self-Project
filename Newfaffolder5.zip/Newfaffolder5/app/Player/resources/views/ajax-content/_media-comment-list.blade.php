<div class="comment" id="CommentList">
    @if(!empty($getComment) && count($getComment) > 0)
    @foreach($getComment as $comment)
    <div class="comment_list">
        <div class="d-flex align-items-center">
            <div class="d-flex align-items-center">
                <div class="profile_img">
                    <img src="{{ checkUserImage($comment->fromUser->profile_image, $comment->fromUser->role) }}" class="img-fluid rounded-circle" alt="Profile">
                </div>
                @if($comment->from_id == Auth::guard(getAuthGuard())->user()->id)
                <a href="{{ url('player/player-profile/')}}"><h3 class="mb-0">{{ $comment->fromUser->full_name }}</h3></a>
                @elseif($comment->fromUser->role == "player")
                <a href="{{ url('view/player-profile/'.$comment->fromUser->slug )}}"><h3 class="mb-0">{{ $comment->fromUser->full_name }}</h3></a>
                @elseif($comment->fromUser->role == "coach")
                <a href="{{ url('view/coach-profile/'.$comment->fromUser->slug )}}"><h3 class="mb-0">{{ $comment->fromUser->full_name }}</h3></a>
                @elseif($comment->fromUser->role == "team")
                <a href="{{ url('view/team-profile/'.$comment->fromUser->slug )}}"><h3 class="mb-0">{{ $comment->fromUser->full_name }}</h3></a>
                @endif
            </div>
            <div class="ml-auto">
                <div class="date_time">
                    <span>{{ dateTimeFormat($comment->created_at) }}</span>
                </div>
            </div>
        </div>
        <div class="description">
            <p>{{ $comment->comment }}</p>
            @if($comment->from_id == Auth::guard(getAuthGuard())->user()->id)
            <a href="javascript:void(0);" class="delete" onclick="deleteMediaComment('{{ $comment->id }}','{{ $comment->media_id }}')"> Delete</a>
            @endif
        </div>  
    </div>
    @endforeach
    @endif
</div>
<script>
//  Function for delete post comment
    function deleteMediaComment(id, mediaId){
    bootbox.confirm({
    message: "Are you sure want to delete comment?",
            buttons: {
            confirm: {
            label: 'Yes',
                    className: 'btn-success border-1 font-14'
            },
                    cancel: {
                    label: 'No',
                            className: 'btn-success border-1 font-14'
                    }
            },
            callback: function (result) {
            if (result){
            $.post("{{ url('player/remove-media-comment') }}", {_token: "{{ csrf_token() }}", id: id}, function(data){
            if (data.success){
            message('success', data.message);
            getMediaCommentList(mediaId);
            var getCumments = $('#commentCount' + mediaId).text();
            var countComment = getCumments -= 1;
            $('#commentCount' + mediaId).html('<i class="icon icon-chat icon"></i>' + countComment);
            } else{
            message('error', data.message);
            }
            });
            }
            }
    });
    }
</script>