<div class="modal-header">
                    <h5 class="modal-title" id="post_title">Coaching Experience</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body p-0">
                    <div class="scroll_body black-scroll">
                        <div class="table-responsive">
                            <table class="table info_table mb-0">
                                <thead>
                                    <tr>
                                        <th>Logo</th>
                                        <th>Organization name</th>
                                        <th>Year</th>
                                        <th>Level</th>
                                        <th>Position held</th>
                                        <th>League/Conference</th>
                                        <th>Link to team’s page/stats</th>
                                        <th>Country</th>
                                        <th>State</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse( $experiences as $coachingExperience )
                                    <tr>
                                        <td>
                                            <div class="logo border rounded-circle">
                                                <img src="{{(!empty($coachingExperience->logo))?checkUserImage($coachingExperience->logo, 'player/thumb','logo'): url('public/images/coachinglist_logo.png') }}" alt="logo" width="20">
                                            </div>
                                        </td>
                                        <td>{{(!empty($coachingExperience->name))?$coachingExperience->name:'ADD INFO'}}</td>
                                        <td>{{(!empty($coachingExperience->from_year))?$coachingExperience->from_year:'-'}}-{{(!empty($coachingExperience->to_year))?$coachingExperience->to_year:'-'}}</td>
                                        <td>{{(!empty($coachingExperience->experienceLevel->level_name))?$coachingExperience->experienceLevel->level_name:'-'}}</td>
                                        <td>{{(!empty($coachingExperience->position_held))?$coachingExperience->position_held:'-'}}</td>
                                        <td>{{(!empty($coachingExperience->coching_league))?$coachingExperience->coching_league:'-'}}</td>
                                        <td>{{(!empty($coachingExperience->coaching_link))?$coachingExperience->coaching_link:'-'}}</td>
                                        <td>{{(!empty($coachingExperience->experienceCountry->name))?$coachingExperience->experienceCountry->name:'-'}}</td>
                                        <td>{{(!empty($coachingExperience->experienceState->state_name))?$coachingExperience->experienceState->state_name:'-'}}</td>
                                    </tr>
                                    @empty
                                    <h3>No Coaching experience Found!</h3>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
</div>