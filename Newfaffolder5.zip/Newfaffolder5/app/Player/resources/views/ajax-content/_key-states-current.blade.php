<div class="inner_section green-scroll key-states-current" data-mcs-theme="dark">
    <div class="offence">
        <h6 class="font_14 mb-3">Offence</h6>
        <div class="row common_row">
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total passing yards:</label>
                    <span>{{!empty($keyStatesCurrent->total_passing)?$keyStatesCurrent->total_passing:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average passing yards (Game):</label>
                    <span>{{!empty($keyStatesCurrent->passing_game)?$keyStatesCurrent->passing_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average passing yards (Season):</label>
                    <span>{{!empty($keyStatesCurrent->passing_season)?$keyStatesCurrent->passing_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Completions:</label>
                    <span>{{!empty($keyStatesCurrent->completion)?$keyStatesCurrent->completion:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Completions<span style="font-family:initial;">(%)</span>:</label>
                    <!--<span>{{!empty($keyStatesCurrent->completion_percent)?$keyStatesCurrent->completion_percent:0}}<span style="font-family:initial;">(%)</span></span>-->
                    <span>{{!empty($keyStatesCurrent->completion_percent)?$keyStatesCurrent->completion_percent:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">QB passer rating:</label>
                    <span>{{!empty($keyStatesCurrent->passer_rating)?$keyStatesCurrent->passer_rating:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total rushing yards:</label>
                    <span>{{!empty($keyStatesCurrent->total_rushing)?$keyStatesCurrent->total_rushing:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average rushing yards (Game):</label>
                    <span>{{!empty($keyStatesCurrent->rushing_game)?$keyStatesCurrent->rushing_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average rushing yards (Season):</label>
                    <span>{{!empty($keyStatesCurrent->rushing_season)?$keyStatesCurrent->rushing_season:0}}</span>
                </div>
            </div>

            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total receiving yards:</label>
                    <span>{{!empty($keyStatesCurrent->total_receiving)?$keyStatesCurrent->total_receiving:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average receiving yards (Game):</label>
                    <span>{{!empty($keyStatesCurrent->receiving_game)?$keyStatesCurrent->receiving_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average receiving yards (Season):</label>
                    <span>{{!empty($keyStatesCurrent->receiving_season)?$keyStatesCurrent->receiving_season:0}}</span>
                </div>
            </div>

            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total return yards:</label>
                    <span>{{!empty($keyStatesCurrent->total_return)?$keyStatesCurrent->total_return:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average return yards (Game):</label>
                    <span>{{!empty($keyStatesCurrent->return_game)?$keyStatesCurrent->return_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average return yards (Season):</label>
                    <span>{{!empty($keyStatesCurrent->return_season)?$keyStatesCurrent->return_season:0}}</span>
                </div>
            </div>

            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total all purpose yards:</label>
                    <span>{{!empty($keyStatesCurrent->total_all_purpose)?$keyStatesCurrent->total_all_purpose:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average all purpose yards (Game):</label>
                    <span>{{!empty($keyStatesCurrent->purpose_game)?$keyStatesCurrent->purpose_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average all purpose yards (Season):</label>
                    <span>{{!empty($keyStatesCurrent->purpose_season)?$keyStatesCurrent->purpose_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Touchdowns:</label>
                    <span>{{!empty($keyStatesCurrent->tuchdowns)?$keyStatesCurrent->tuchdowns:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Games played:</label>
                    <span>{{!empty($keyStatesCurrent->games_played)?$keyStatesCurrent->games_played:0}}</span>
                </div>
            </div>
        </div>
    </div>
    <div class="defence">
        <h6 class="font_14 mb-3">Defence</h6>
        <div class="row common_row">
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total tackles:</label>  
                    <span>{{!empty($keyStatesCurrent->tackles)?$keyStatesCurrent->tackles:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles (Game):</label> 
                    <span>{{!empty($keyStatesCurrent->tackles_game)?$keyStatesCurrent->tackles_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles (Season):</label>   
                    <span>{{!empty($keyStatesCurrent->tackles_season)?$keyStatesCurrent->tackles_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total tackles for loss:</label> 
                    <span>{{!empty($keyStatesCurrent->total_tackloss)?$keyStatesCurrent->total_tackloss:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles for loss (Game):</label>    
                    <span>{{!empty($keyStatesCurrent->tackloss_game)?$keyStatesCurrent->tackloss_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles for loss (Season):</label>  
                    <span>{{!empty($keyStatesCurrent->tackloss_season)?$keyStatesCurrent->tackloss_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total sacks:</label>    
                    <span>{{!empty($keyStatesCurrent->total_sacks)?$keyStatesCurrent->total_sacks:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average sacks (Game):</label>   
                    <span>{{!empty($keyStatesCurrent->sacks_game)?$keyStatesCurrent->sacks_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average sacks (Season):</label> 
                    <span>{{!empty($keyStatesCurrent->sacks_season)?$keyStatesCurrent->sacks_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total pass breakups:</label>    
                    <span>{{!empty($keyStatesCurrent->total_breaksups)?$keyStatesCurrent->total_breaksups:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average pass breakups (Game):</label>   
                    <span>{{!empty($keyStatesCurrent->breaksups_game)?$keyStatesCurrent->breaksups_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average pass breakups (Season):</label> 
                    <span>{{!empty($keyStatesCurrent->breaksups_season)?$keyStatesCurrent->breaksups_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total Interceptions:</label>    
                    <span>{{!empty($keyStatesCurrent->total_interception)?$keyStatesCurrent->total_interception:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Average Interceptions (Game):</label>   
                    <span>{{!empty($keyStatesCurrent->interception_game)?$keyStatesCurrent->interception_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Average Interceptions (Season):</label> 
                    <span>{{!empty($keyStatesCurrent->interception_season)?$keyStatesCurrent->interception_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Blocked punts:</label>  
                    <span>{{!empty($keyStatesCurrent->blocked_punts)?$keyStatesCurrent->blocked_punts:0}}</span>
                </div>
            </div>
        </div>
    </div>
    <div class="specials">
        <h6 class="font_14 mb-3">Specials</h6>
        <div class="row common_row">
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Total field goals:</label>  
                    <span>{{!empty($keyStatesCurrent->total_field_goal)?$keyStatesCurrent->total_field_goal:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Longest field goal:</label> 
                    <span>{{!empty($keyStatesCurrent->longest_field_goal)?$keyStatesCurrent->longest_field_goal:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Field goal percentage:</label>  
                    <!--<span>{{!empty($keyStatesCurrent->field_goal_percent)?$keyStatesCurrent->field_goal_percent:0}}<span style="font-family:initial;">%</span></span>-->
                    <span>{{!empty($keyStatesCurrent->field_goal_percent)?$keyStatesCurrent->field_goal_percent:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Longest punt:</label>   
                    <span>{{!empty($keyStatesCurrent->longest_punt)?$keyStatesCurrent->longest_punt:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Average punt distance:</label>  
                    <span class="text-capitalize">{{!empty($keyStatesCurrent->avg_punt_distance)?$keyStatesCurrent->avg_punt_distance:0}}</span>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    setTimeout(function () {
        $(".key-states-current").mCustomScrollbar({
            theme: "dark",
            axis: "y",
        });
    }, 2000);
</script>