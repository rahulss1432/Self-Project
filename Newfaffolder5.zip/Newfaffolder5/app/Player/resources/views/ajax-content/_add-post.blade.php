<form id="save-post" method="post" action="javascript:void()" enctype="multipart/form-data">
{{ csrf_field() }}
<div class="modal-header">
    <h5 class="modal-title" id="post_title">Compose Post</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="close-btn">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <div class="content">
        <div class="form-group">
            <textarea name="title" rows="5" class="form-control" id="title-field" placeholder="Type text here..."></textarea>
            <span id="title-validation-msg" class="error-msg "></span>
        </div>
        <div class="form-group mb-0">
            <div class="upload-file-input">
                <div id="mulitplefileuploader"  onclick="uploadMultipleFile()">
                    <label for="uploadFile" class="d-block mb-0" >
                        <div class="uploadIcon">
                            <input id="uploadFile" type="text" class="form-control" placeholder="upload Photo/Video" >
                        </div>
                    </label>
                </div>
            </div>
            <!--this hide section using for uploading time open--> 
            <div class="simple-file-input" style="display:none">
                <div>
                    <label for="uploadFile" class="d-block mb-0" >
                        <div class="uploadIcon">
                            <input id="simpleuploadFile" type="text" class="form-control" placeholder="upload Photo/Video" >
                        </div>
                    </label>
                </div>
            </div>
            <span id="file-validation-msg" class="error-msg "></span>
            <div class="preview">
                <div class="preview-box ">
                    <ul class="list-inline"  id="upload-image">
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal-footer d-flex justify-content-between">
    <button type="submit"  id="savePostBtn" class="btn btn-primary" onclick="savePost()">Post</button>
</div>
</form>
<script>
      function savePost(){
       var title = $('#title-field').val();
        if ($.trim(title) == '' && $('.imagecount').length == 0) {
            $('#title-validation-msg').html('Post cannot be blank');
            return false;
        } else {
            if ($.trim(title).length > 500) {
                $('#title-validation-msg').html('title can not be greater then 500 charactor.');
                return false;
            }
            $('#title-validation-msg').html('');
        }
        showButtonLoader('savePostBtn', 'Post', 'disable');
        var url = "{{ url('player/save-post') }}";
        var formData = new FormData($('#save-post')[0]);
        formData.append('_token', '{{ csrf_token() }}');
        $.ajax({
            url: url,
            data: formData,
            processData: false,
            contentType: false,
            type: 'POST',
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    message('success', data.message);
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                }else if(data.validation == 'yes'){
                      $('#file-validation-msg').html(data.message);
                      showButtonLoader('savePostBtn', 'Post', 'enable');
                } else {
                    message('error', data.message);
                    showButtonLoader('savePostBtn', 'Post', 'enable');
                }
            },error: function (err) {
                message('error', err);
                showButtonLoader('savePostBtn', 'Post', 'enable');
            }   
        });
    }
    
    function removeImage(obj) {
        $(obj).parent().parent().remove();
        $(".preview-box").mCustomScrollbar("destroy"); /* Post scrolling */
        $(".preview-box").mCustomScrollbar({
          theme: "dark",
           axis:"x",
        });
    }

    function uploadMultipleFile() {
        var uploadFileCount = '';
        var options = {
            url: "{{url('player/upload-post-media')}}",
            dragDrop: true,
            method: "POST",
            cache: false,
            allowedTypes: "jpg,png,gif,jpeg,mp4",
            fileName: "myPost",
            async: true,
            multiple: true,
            formData: {_token: '{{ csrf_token() }}'},
            onSelect: function (files, data, xhr)
            {
                var ImageCount = $('.imagecount').length;
                uploadFileCount = files.length;
                var totaleCount = ImageCount + uploadFileCount;
                if (totaleCount > 10) {
                    $('#file-validation-msg').html('Maximum 10 file upload');
                    return false;
                }
                
                var checkFile = 0;  
                $.each(files, function(index, value) {
                  if(value.type == 'image/jpeg' || value.type == 'image/png' || value.type == 'image/jpg' || value.type == 'video/mp4'){
                      $('#file-validation-msg').html('');
                      $('#close-btn').attr("disabled", "disabled"); 
                      $('#savePostBtn').attr("disabled", "disabled");
                      checkFile++;
                    }  
                 });
              
              if(checkFile > 0){
                 $('.upload-file-input').hide(); 
                 $('.simple-file-input').show();
                 $('#simpleuploadFile').attr("disabled", "disabled");
                 $('#upload-image').prepend('<li class="list-inline-item imagecount"><div class="text-center image-loader"><div class="ajax_list_load bg-white"><span class="ajax_loader btn_ring"></span></div></div></li>');
               }
               
            },
            onSuccess: function (files, data, xhr)
            {
                if (data.success == true) {
                    var imageName = data.image;
                    $('#upload-image').append('<li class="list-inline-item imagecount">\n\
                             <input type="hidden" name="duration[]" value="' + data.duration + '">\n\
                             <input type="hidden" name="size[]" value="' + data.size + '">\n\
                             <input type="hidden" name="mediaType[]" value="' + data.type + '">\n\
                             <input type="hidden" name="hdnImageName[]" id="hdnImageName" value="' + imageName + '">\n\
                             <img src="<?php echo url("public/uploads/temp/thumb") ?>/' + imageName + '" class="img-fluid " alt="video"><div class="icon">\n\
                             <a href="javascript:void(0);" onclick="removeImage(this)"><i class="fas fa-times"></i>\n\
                            </a></div>\n\
                            </li>');
                 }else{
                    message('error', data.message);
                }
            },
            afterUploadAll: function () {
                  $('.image-loader').parent().remove();
                  $(".preview-box").mCustomScrollbar("update");
                  $('#close-btn').removeAttr("disabled");
                  $('#savePostBtn').removeAttr("disabled");
                  $('.upload-file-input').show();
                  $('.simple-file-input').hide();
            },
        }
        $("#mulitplefileuploader").uploadFile(options);
    }
    
    $(document).ready(function () {
        uploadMultipleFile();
        $(".preview-box").mCustomScrollbar({
            theme: "dark",
            axis: "x",
        });
    });
</script>