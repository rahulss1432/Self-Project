<form id="edit-post" method="post" action="javascript:void(0)" enctype="multipart/form-data">
    {{ csrf_field() }}
    <input type="hidden" name="id" value="{{ $post->id }}"/>
    <div class="modal-header">
        <h5 class="modal-title" id="post_title">Edit Post</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="close-btn">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
        <div class="content">
            <div class="form-group">
                <textarea name="title" rows="5"  id="title-record" class="form-control" placeholder="Type text here...">{{ $post->post }}</textarea>
                <span id="title-validation" class="error-msg"></span>
            </div>
            <div class="form-group mb-0">
                <div class="upload-file-input">
                    <div id="updateMultipleFile"  onclick="uploadMultipleFile()">
                        <label for="uploadFile" class="d-block mb-0" >
                            <div class="uploadIcon">
                                <input id="uploadFile" type="text" class="form-control" placeholder="upload Photo/Video" >
                            </div>
                        </label>
                    </div>
                </div>
                <!--this hide section using for uploading time open--> 
                <div class="simple-file-input" style="display:none">
                    <div>
                        <label for="uploadFile" class="d-block mb-0" >
                            <div class="uploadIcon">
                                <input id="simpleuploadFile" type="text" class="form-control" placeholder="upload Photo/Video" >
                            </div>
                        </label>
                    </div>
                </div>
                <span id="file-validation-msg" class="error-msg"></span>
                <div class="preview">
                    <div class="preview-box ">
                        <ul class="list-inline"  id="get-upload-image">
                             @if(count($post->media) > 0)
                            @foreach($post->media as $file)
                            <li class="list-inline-item uploadImageCount">
                                <input type="hidden" name="duration[]" value="{{ $file->time_duration }}">
                                <input type="hidden" name="size[]" value="{{ $file->size }}">
                                <input type="hidden" name="mediaType[]" value="{{ $file->media_type }}">
                                <input type="hidden" name="hdnImageName[]" id="hdnImageName" value="{{ $file->media }}">
                                <img src="{{ url("public/uploads/player/thumb/". $file->media) }}" class="img-fluid " alt="video">
                                <div class="icon">
                                 <a href="javascript:void(0);" onclick="removeImage(this)"><i class="fas fa-times"></i>
                                </a>
                                </div>
                            </li>
                            @endforeach
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
          
            <div id="image-validation-message"></div>
       <!--<input type="file" name="post" id="edit-post-label" style="opacity:0; position:absolute;">-->
        </div>
    </div>
    <div class="modal-footer d-flex justify-content-between">
        <button type="submit" id="updatePostBtn" class="btn btn-primary" onclick="savePost()">Update</button>
    </div>
</form>
<script>
     $(document).ready(function () {
        updateMultipleFile();
        $(".preview-box").mCustomScrollbar({
        theme:"dark",
        axis:"x",
        });
     })
     
    function updateMultipleFile(){
        var uploadFileCount = '';
        var options = {
            url: "{{url('player/upload-post-media')}}",
            dragDrop: true,
            method: "POST",
            cache: false,
            allowedTypes: "jpg,png,gif,jpeg,mp4",
            fileName: "myPost",
            async: true,
            multiple: true,
            formData: {_token: '{{ csrf_token() }}'},
            onSelect: function (files, data, xhr)
            {
                       
               var ImageCount = $('.uploadImageCount').length;
                uploadFileCount = files.length;
                var totaleCount = ImageCount + uploadFileCount;
                if (totaleCount > 10) {
                    $('#file-validation-msg').html('Maximum 10 file upload');
                    return false;
                }
                
                var checkFile = 0;  
                $.each(files, function(index, value) {
                  if(value.type == 'image/jpeg' || value.type == 'image/png' || value.type == 'image/jpg' || value.type == 'video/mp4'){
                      $('#file-validation-msg').html('');
                      $('#close-btn').attr("disabled", "disabled"); 
                      $('#updatePostBtn').attr("disabled", "disabled");
                      checkFile++;
                    }  
                 });
              
              if(checkFile > 0){
                 $('.upload-file-input').hide(); 
                 $('.simple-file-input').show();
                 $('#simpleuploadFile').attr("disabled", "disabled");
                 $('#get-upload-image').prepend('<li class="list-inline-item uploadImageCount"><div class="text-center image-loader"><div class="ajax_list_load bg-white"><span class="ajax_loader btn_ring"></span></div></div></li>');
               }
          
          },
            onSuccess: function (files, data, xhr)
            {
                if (data.success == true) {
                    var imageName = data.image;
                    $('#get-upload-image').append('<li class="list-inline-item uploadImageCount">\n\
                             <input type="hidden" name="duration[]" value="' + data.duration + '"> \n\
                             <input type="hidden" name="size[]" value="' + data.size + '"> \n\
                             <input type="hidden" name="mediaType[]" value="' + data.type + '">\n\
                             <input type="hidden" name="hdnImageName[]" id="hdnImageName" value="' + imageName + '">\n\
                             <img src="<?php echo url("public/uploads/temp/thumb") ?>/' + imageName + '" class="img-fluid " alt="video"><div class="icon">\n\
                             <a href="javascript:void(0);" onclick="removeImage(this)"><i class="fas fa-times"></i>\n\
                            </a></div>\n\
                            </li>');
                }else{
                    message('error', data.message);
                }
             },
             afterUploadAll: function () {
                  $('.image-loader').parent().remove();
                  $(".preview-box").mCustomScrollbar("update");
                  $('#close-btn').removeAttr("disabled");
                  $('#updatePostBtn').removeAttr("disabled");
                  $('.upload-file-input').show();
                  $('.simple-file-input').hide();
            },
        }
        $("#updateMultipleFile").uploadFile(options);
    }

    function removeImage(obj) {
        $(obj).parent().parent().remove();
        $(".preview-box").mCustomScrollbar("destroy");
        $(".preview-box").mCustomScrollbar({
            theme: "dark",
            axis: "x",
        });
    }
    
    function savePost(){
        var title = $('#title-record').val();
        if ($.trim(title) == '' && $('.uploadImageCount').length == 0) {
            $('#title-validation').html('Post cannot be blank');
            return false;
         }else{
            if ($.trim(title).length > 500) {
               $('#title-validation').html('title can not be greater then 500 charactor.');
               return false;
            }
          }
          
        $('#title-validation').html('');
        showButtonLoader('updatePostBtn', 'Post', 'disable');
        var url = "{{ url('player/save-post') }}";
        var formData = new FormData($('#edit-post')[0]);
        formData.append('_token', '{{ csrf_token() }}');
        $.ajax({
            url: url,
            data: formData,
            processData: false,
            contentType: false,
            type: 'POST',
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    message('success', data.message);
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                }else if(data.validation == 'yes'){
                      $('#file-validation-msg').html(data.message);
                      showButtonLoader('updatePostBtn', 'Post', 'enable');
                } else {
                    message('error', data.message);
                    showButtonLoader('updatePostBtn', 'Post', 'enable');
                }
            },error: function (err) {
                message('error', err);
                showButtonLoader('updatePostBtn', 'Post', 'enable');
            }   
        });
    }
</script>    