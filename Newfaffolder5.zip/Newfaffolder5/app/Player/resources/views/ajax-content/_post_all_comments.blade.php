<div class="modal-header">  
    <h5 class="modal-title" id="exampleModalLabel">Users Comments({{ $total_count }})</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
@if( count($comments) > 0 )

<div class="modal-body mt-0">
    <ul class="list-unstyled mb-0 black-scroll mCustomScrollbar user_like_scroll" data-mcs-theme="dark">
        @foreach( $comments as $comment )
        <li>
            <div class="imgdiv">
                <img src="{{ checkUserImage($comment->user->profile_image, $comment->user->role.'/thumb') }}" class="rounded-circle" alt="user">
            </div>
            <div class="caption">
                <h4 class="text-capitalize">
                    @if($comment->from_id == Auth::guard(getAuthGuard())->user()->id)
                    <a href="{{ url('player/player-profile/')}}"><span class="name">{{ $comment->user->first_name . ' ' . $comment->user->last_name }}</span></a>
                    @elseif($comment->user->role == "player")
                    <a href="{{ url('view/player-profile/'.$comment->user->slug )}}"><span class="name">{{ $comment->user->first_name . ' ' . $comment->user->last_name }}</span></a>
                    @elseif($comment->user->role == "coach")
                    <a href="{{ url('view/coach-profile/'.$comment->user->slug )}}"><span class="name">{{ $comment->user->first_name . ' ' . $comment->user->last_name }}</span></a>
                    @elseif($comment->user->role == "team")
                    <a href="{{ url('view/team-profile/'.$comment->user->slug )}}"><span class="name">{{ $comment->user->first_name . ' ' . $comment->user->last_name }}</span></a>
                    @endif
                    <span class="time">{{ dateDayAgo($comment->created_at) }}</span>
                </h4>
                <p>{{ $comment->comment }}</p>
            </div>
        </li>
        @endforeach
    </ul>
</div>
@endif
<script>
    $(".user_like_scroll").mCustomScrollbar({
        theme: "dark",
        axis: "y",
    });
    $(window).resize(function () {
        var chk_account_height = $('.modal-header').outerHeight(true);
        var window_height = $(window).height();
        $(".user_like_scroll").css('max-height', window_height - chk_account_height - custom_margin);
    }).resize();
</script>