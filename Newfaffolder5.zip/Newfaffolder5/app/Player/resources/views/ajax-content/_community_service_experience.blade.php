@if($user->userCommunityExperince->count() > 0)
@php
$i=0;
@endphp
@foreach($user->userCommunityExperince as $userCommunity)
@php
if($i == 3){
break;
}
$i++;
@endphp
<li class="list-inline-item list">
    <img src="{{ checkUserImage($userCommunity->logo, 'player/thumb','community-experience') }}" alt="icon">
    <h3 >{{!empty($userCommunity->name) ? ucfirst($userCommunity->name) : '-'}}</h3>
    <h6>{{getPositionName($user->position_id)}}</h6>
    <p>{{$userCommunity->from_year .' TO '.  $userCommunity->to_year}}</p>
    <div class="bottom_loader">
        <div class="border_loader">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</li>
@endforeach
@if(count($user->userCommunityExperince) > 3)
   <div class="text-center seeall_btn mt-xl-4 mt-3">
                        <a href="javascript:void(0);" class="btn btn-success btn-sm border-1 p-6-15 font-14" onclick="getMoreResults('community','cm')" id="cm">SEE ALL</a>
    </div>
@endif
@else
<li class="list-inline-item list">
    <img src="{{ checkUserImage('', 'player/thumb','community-experience') }}" alt="icon">
    <h3 >Add Info</h3>
    <h6>-</h6>
    <p>-</p>
    <div class="bottom_loader">
        <div class="border_loader">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</li>
<li class="list-inline-item list">
    <img src="{{ checkUserImage('', 'player/thumb','community-experience') }}" alt="icon">
    <h3 >Add Info</h3>
    <h6>-</h6>
    <p>-</p>
    <div class="bottom_loader">
        <div class="border_loader">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</li>
<li class="list-inline-item list">
    <img src="{{ checkUserImage('', 'player/thumb','community-experience') }}" alt="icon">
    <h3 >Add Info</h3>
    <h6>-</h6>
    <p>-</p>
    <div class="bottom_loader">
        <div class="border_loader">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</li>
@endif