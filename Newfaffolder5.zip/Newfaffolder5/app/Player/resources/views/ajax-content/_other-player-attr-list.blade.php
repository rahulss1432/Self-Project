<div class="attributes_content">
    <div class="heading d-inline-block text-center">
        <h6>RELATIVE TO POSITION</h6>
        <h2>WR/DB</h2>
    </div>
    <div class="count_addlist">
        <div class="text-md-center">
            @if(count($getAttributes) > 0)
            @foreach($getAttributes as $key => $attribute)
            @if($key == 0) 
            <div class="c_tag top_center wow fadeInLeft {{ (checkAttributeById($attribute->id , $fromUser->id, $toUser) !=0) ? 'active' : '' }}" data-wow-delay="0s" data-wow-duration="0.2s">
                <span class="count d-flex align-items-center"> 
                    @if(checkAttributeById($attribute->id , $fromUser->id, $toUser) !=0) <a href="javascript:void(0);" class="d-none d-md-block review"> {{ checkAttributeById($attribute->id , $fromUser->id, $toUser) }}</a>
                    @else
                    <a href="javascript:void(0);" class="d-none d-md-block" onclick="addSelectAttribute('{{$attribute->id}}','{{$fromUser->id}}','{{$toUser}}')"><i class="flaticon-plus"></i></a>
                    @endif
                    {{ $attribute->title }}
                </span>
            </div>
            @endif
            @endforeach
            @endif
        </div>
        <div class="c_leftlist float-md-left">
            <ul class="list-unstyled text-md-right">
                @if(count($getAttributes) > 0)
                @foreach($getAttributes as $key => $attribute)
                @if($key == 31 || $key != 30 && $key != 0 && $key != 32 && $key % 2 == 0) 
                <li>
                    <div class="c_tag wow fadeInLeft {{ (checkAttributeById($attribute->id , $fromUser->id, $toUser) !=0) ? 'active' : '' }}" data-wow-delay="0s" data-wow-duration="0.4s">
                        <span class="count d-flex align-items-center"> 
                            @if(checkAttributeById($attribute->id , $fromUser->id, $toUser) !=0) <a href="javascript:void(0);" class="d-none d-md-block review">{{ checkAttributeById($attribute->id , $fromUser->id, $toUser) }}</a>
                            @else
                            <a href="javascript:void(0);" class="d-none d-md-block" onclick="addSelectAttribute('{{$attribute->id}}','{{$fromUser->id}}','{{$toUser}}')"><i class="flaticon-plus"></i></a>
                            @endif
                               {{ $attribute->title }}
                        </span>
                    </div>
                </li>
                @endif
                @endforeach
                @endif
            </ul>
        </div>
        <div class="c_rightlist float-md-right">
            <ul class="list-unstyled text-md-left">
                @if(count($getAttributes) > 0)
                @foreach($getAttributes as $key =>  $attribute)
                @if(($key % 2 == 1 && $key != 31) || $key == 30 || $key == 32)
                <li>
                    <div class="c_tag wow fadeInRight {{ (checkAttributeById($attribute->id , $fromUser->id, $toUser) !=0) ? 'active' : '' }} " data-wow-delay="0s" data-wow-duration="0.7s">
                        <span class="count d-flex align-items-center"> 
                            {{ $attribute->title }}
                            @if(checkAttributeById($attribute->id , $fromUser->id, $toUser) !=0)<a href="javascript:void(0);" class="review"> {{ checkAttributeById($attribute->id , $fromUser->id, $toUser) }}</a>
                             @else
                             <a href="javascript:void(0);" class="d-none d-md-block" onclick="addSelectAttribute('{{$attribute->id}}','{{$fromUser->id}}','{{$toUser}}')"><i class="flaticon-plus"></i></a>
                            @endif
                        </span>
                    </div>
                </li>
                @endif
                @endforeach
                @endif
            </ul>     
        </div> 
    </div>
</div>
<script>
    function addSelectAttribute(attrId, fromId,toId){
        var url = "{{ url('player/add-select-attribute') }}";
        $.ajax({type: "GET", url: url,data:{attribute_id:attrId, from_id:fromId, to_id:toId},
            success: function (response) {
                if(response.success == true){
                    getValidateAttributeList();
                }else{
                    message('error', response.message);
                }
            },
            error: function () {
               getValidateAttributeList();
            },
        });
    }

</script>
