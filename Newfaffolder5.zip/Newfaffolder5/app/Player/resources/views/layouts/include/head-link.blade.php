<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<!-- favicon -->
<link rel="apple-touch-icon" sizes="180x180" href="{{ url('public/images/favicon/apple-touch-icon.png')}}">
<link rel="icon" type="image/png" sizes="32x32" href="{{ url('public/images/favicon/favicon-32x32.png')}}">
<link rel="icon" type="image/png" sizes="16x16" href="{{ url('public/images/favicon/favicon-16x16.png')}}">
<link rel="manifest" href="{{ url('public/images/favicon/site.webmanifest')}}">
<link rel="mask-icon" href="{{ url('public/images/favicon/safari-pinned-tab.svg')}}" color="#5bbad5">
<meta name="msapplication-TileColor" content="#bee626">
<meta name="theme-color" content="#BEE626">
<meta name="mobile-web-app-capable" content="yes">
<!-- STYLE CSS -->
<link rel="stylesheet" href="{{ url('public/css/bootstrap.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{ url('public/css/bootstrap-select.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{ url('public/css/owl.carousel.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{ url('public/css/owl-dots.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{ url('public/css/jquery.mCustomScrollbar.min.css')}}">
<link rel="stylesheet" href="{{ url('public/css/iconmoon.css')}}" type="text/css">
<link rel="stylesheet" href="{{ url('public/css/flaticon.css')}}" type="text/css">
<link rel="stylesheet" href="{{ url('public/css/fontawesome-all.css')}}" type="text/css">
<link rel="stylesheet" href="{{ url('public/css/custom.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{ url('public/css/toastr.css')}}" type="text/css">
<link rel="stylesheet" href="{{ url('public/css/cropper.css')}}" type="text/css">
<!-- SCRIPT JS -->
<script src="{{ url('public/js/jquery.min.js') }}"></script>
<script src="{{ url('public/js/moment.js') }}"></script>

