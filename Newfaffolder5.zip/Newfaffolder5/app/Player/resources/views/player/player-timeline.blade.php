@extends('player::layouts.app')

@section('content')

<main class="main-content">
    <div class="mainframe_border">
        <div class="borderheight" id="borderheight"></div>
    </div>
    <!--  left side -->
    <aside class="left_section " id="left-side-html">
        <!-- left side html render -->
    </aside>
    <!--  middle section -->
    <section class="middle_section">
        <div class="container-fluid">
            <div class="news_point">
                <div class="inner">
                    <div class="newsheading">
                        <p><span class="headingtag">NEWS</span></p> <div class="newsline"><span id="newsBulletin"></span></div>
                        <a href="{{ url('/news-details') }}">(READ MORE)</a>
                    </div>
                    <div class="news_tag" id="all_player_counts">

                    </div>
                </div>
            </div>
            <div class="members_list">
                <div class="heading text-center mr-auto ml-auto">
                    MEMBERS YOU MAY KNOW
                </div>
                <div class="list" id="sliderDiv">
                    <div class="customNavigation">
                        <a href="javascript:void(0);" class="prev"></a>
                    </div>
                    <div class="back_bg"></div>
                    <div class="owl-carousel owl-theme member" id="memberlist">
                    </div>
                    <div class="customNavigation">
                        <a href="javascript:void(0);" class="next"></a>
                    </div>
                </div>
            </div>
            <div class="web_presentation text-center">
                <img src="{{ url('public/images/black_logo.png') }}" class="img-fluid" alt="logo">
            </div>
            @if($user->id == Auth::guard(getAuthGuard())->user()->id)
            <div class="post_videophoto">
                <form action="post">
                    <div class="profile_img common_side">
                        <!--<img src="{{ url('public/images/user_img.jpg') }}" class="rounded-circle" alt="profile">-->
                        <img src="{{ checkUserImage(\Auth::guard(getAuthGuard())->user()->profile_image, 'player') }}" class="rounded-circle" alt="profile">
                        <div class="circle_animation">
                        </div>
                    </div>
                    <div class="post_desc">
                        <a onclick="addPost()" href="javascript:void(0);">
                            Share an Article, Photo, Video...
                        </a>
                        <ul class="list-inline icons">
                            <li class="list-inline-item">
                                <label onclick="addPost()">
                                    <span class="icon icon-film"></span>
                                </label>
                            </li>
                            <li class="list-inline-item">
                                <label  onclick="addPost()">
                                    <span class="icon icon-image"></span>
                                </label>
                            </li>
                        </ul>
                    </div>
                    <div class="post_btn common_side">
                        <a href="javascript:void(0);" class="btn btn-dark rounded-circle" onclick="addPost()">
                            POST
                        </a>
                    </div>
                </form>
            </div>
            @endif

            <!----------------- view all post ------------------->
            <div class="post_view" >
                <div class="post ml-auto mr-auto green-scroll" id="postframe">

                </div>
            </div>
            <div class="text-center" id="loader-div" style="display:none;"><a href="javascript:void(0);" id="post-load-more" class="btn btn-success" onclick="loadMorePost()">More</a></div>
            <!----------------- view all post ------------------->

        </div>
    </section>
    <!-- right side -->
    <aside class="right_section" id="right-side-html">
        <!-- right side html render  -->
    </aside>

    <div class="procard-player" id="divPlayerProCard">
    </div>
</main> 

<!-- Add post modal -->
<div class="modal fade modal-center share-article" data-backdrop="static" data-keyboard="false" id="add_post" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="add-post-data">
            <div class="btn_loader btn_ring" id="listLoader"></div>
        </div>
    </div>
</div>

<!-- Modal End -->

<!-- Edit post modal -->
<div class="modal fade modal-center share-article edit_post" data-backdrop="static" data-keyboard="false" id="edit_post" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="edit-post-data">
            <div class="btn_loader btn_ring" id="listLoader"></div>
        </div>
    </div>
</div>
<!-- Modal End -->

<!-- like model -->
<div class="modal fade modal-center  users_like" id="users_like" data-backdrop="static" data-keyboard="false" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="users_like" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="LikeUserList">
            <div class="btn_loader btn_ring" id="listLoader"></div>
        </div>
    </div>
</div>

<!-- like model -->
<!-- comment model -->
<div class="modal fade modal-center  users_like users_comments" id="users_comments" data-backdrop="static" data-keyboard="false" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="users_comments" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="AllCommentList">
            <div class="btn_loader btn_ring" id="listLoader"></div>
        </div>
    </div>
</div>
<!-- comment model -->
<!-- left & right side url routing-->
<input type="hidden" data-url="{{url('player/left-sidebar')}}" id="player_left_side">
<input type="hidden" data-url="{{url('player/right-sidebar')}}" id="player_right_side">
<script>

    // This user id is used when one user see other user profile
    var user_id = '{{ $id }}'; // for reinitilize slider when length 0.

    // accepr reject url
    var memberConnectDismissUrl = "{{ url('player/connect-dismiss-member') }}";
    var recentJoinedMembersUrl = "{{ url('player/get-recent-joined-members') }}";
    var currentPageUrl = '{{ Request::segment(2) }}';
    var csrfToken = "{{csrf_token()}}";
    var userConnectionList = "{{ url('player/user-connections-list') }}";
    var recentMathcedJoinedMembersUrl = "{{ url('player/get-matched-mutual-joined-members') }}";

    // post view content list load
    function getpostView(obj = null, url, action) {

        if (url == '' || url == undefined) {
            var url = "{{ url('player/get-timeline-post') }}";
            pageLoader('postframe', 'show');
        }

        $.ajax({type: "GET", url: url, data: {id: '{{ $id }}'},
            success: function (response) {
                if (action == 'first') {
                    $("#postframe").html("");
                    $("#postframe").html(response.html);
                } else {
                    $('.pagination:first').remove();
                    $("#postframe").append(response.html);
                }
            },
            error: function () {
                getpostView('', url, action);
            },
            complete: function () {
                setHeightMiddleSection();
                if (action == 'pagination') {
                    showButtonLoader('explore-btn-loader', "MORE", "enable");
                    $("#postframe").mCustomScrollbar("destroy"); /* Post scrolling */
                    $("#postframe").mCustomScrollbar({
                        theme: "dark",
                        axis: "y"
                    });
                }
            }
        });
    }

    // Function for get post like.
    function getPostLike(id) {
        $.get("{{ url('player/get-post-like') }}", {id: id}, function (response) {
            if (response.success) {
                if (response.data == 0) {
                    $("#post-like-" + id).html('');
                    document.getElementById("prevent-" + id).style.pointerEvents = 'none';
                } else {
                    $("#post-like-" + id).html(response.data);
                    document.getElementById("prevent-" + id).style.pointerEvents = 'auto';
                }
            } else {
                message('error', response.message);
            }
        });
    }

    // Function for check post like.
    function checkPostLike(pid) {
        return $.post("{{ url('player/check-post-like') }}", {_token: '{{ csrf_token() }}', pid: pid, id: '{{$id}}'}, function (response) {
            if (response == 1) {
                $('#like-btn-' + pid).removeClass('like');
                $('#like-btn-' + pid).removeClass('unlike');
                $('#like-btn-' + pid).addClass('like');
            } else {
                $('#like-btn-' + pid).removeClass('like');
                $('#like-btn-' + pid).removeClass('unlike');
                $('#like-btn-' + pid).addClass('unlike');
            }
        });
    }

    // Function for add post like.
    function addPostLike(pid, uid) {
        $.post("{{ url('player/add-post-like') }}", {_token: '{{ csrf_token() }}', pid: pid, uid: uid, id: '{{$id}}'}, function (response) {
            if (response.success) {
                getPostLike(pid);
                checkPostLike(pid);
            } else {
                message('error', response.message);
            }
        });
    }

    // Function for get all user like.
    function getLikeUser(pid) {
        $('#users_like').modal('show');
        $.post("{{ url('player/get-like-user') }}", {_token: '{{ csrf_token() }}', pid: pid, id: '{{$id}}'}, function (response) {
            if (response.success) {
                $('#LikeUserList').html('');
                $('#LikeUserList').html(response.html);
                setTimeout(function () {
                    $(".user_like_scroll").mCustomScrollbar({
                        theme: "dark",
                        axis: "y",
                    });
                }, 500);
            } else {
                message('error', response.message);
            }
        });
    }

    // Function for get post and all  comments.
    function getPostComments(pid, action) {
        if (action == 'all') {
            $('#users_comments').modal('show');
        }
        $.ajax({type: "POST",
            url: "{{ url('player/get-post-comments') }}",
            data: {_token: '{{ csrf_token() }}', pid: pid, action: action},
            success: function (response) {
                if (response.success) {
                    if (action == 'first') {   // add and first time load                 
                        $('#post-comments-' + pid).html(response.html);
                    } else {
                        $('#AllCommentList').html('');
                        $('#AllCommentList').html(response.html);
                    }
                    if (response.total_count == 0) {
                        $('#post-comments-count-' + pid).html('');
                    } else {
                        $('#post-comments-count-' + pid).html(response.total_count);
                    }
                }
            },
            error: function () {
                getPostComments(pid, action);
            },
            complete: function () {
                $(".user_like_scroll").mCustomScrollbar({
                    theme: "dark",
                    axis: "y",
                });
            }
        });
    }

    // Function for save post comment.
    $(document).on('submit', '.comment-form', function (e) {
        e.preventDefault();
        var pid = $(this).find('[name="pid"]').val();
        var comment = $(this).find('[name="comment"]').val();
        if ($.trim(comment) == '') {
            $(this).find('[name="comment"]').focus();
        } else {
            $.post($(this).attr('action'), $(this).serialize(), function (data) {
                if (data.success) {
                    $('.comment-form').trigger('reset');
                    getPostComments(pid, 'first');
                } else {
                    message('error', data.message);
                }
            });
        }
    });

    // Function for edit post.
    function editPost(id) {
        $.get("{{ url('player/edit-post') }}", {id: id}, function (data) {
            $("#edit-post-data").html(data.html);
            $('#edit_post').modal('show');
        });
    }


    // Function for Add post.
    function addPost() {
        $.get("{{ url('player/add-post-form') }}", function (data) {
            $("#add-post-data").html(data.html);
            $('#add_post').modal('show');
        });
    }

// show player pro card
    function getPlayerProCard() {
        var url = "{{ url('player/get-player-procard') }}";
        $.ajax({type: "GET", url: url, data: {id: '{{ $id }}'},
            success: function (response) {
                $('#divPlayerProCard').html(response.html);
            },
            error: function (err) {
                getPlayerProCard();
            },
            complete: function () {
                //setHeightMiddleSection(); 
            }
        });
    }
// all counts of player
    function getPlayerAllCount() {
        pageLoader('all_player_counts', 'show');
        var url = "{{ url('player/get-player-counts') }}";
        $.ajax({type: "GET",
            url: url,
            data: {id: user_id},
            success: function (response) {
                $('#all_player_counts').html('');
                $('#all_player_counts').html(response.html);
                $('#newsBulletin').html(response.newsBulletin);
            },
            error: function () {
                getPlayerAllCount();
            }
        });
    }
    // Function for run default functions on page ready.
    $(document).ready(function () {
        var _token = '{{ csrf_token() }}';
        getpostView('', '', 'first');
        getLeftSidebar("player-timeline", '{{$id}}');
        getRightSidebar("player-timeline", '{{$id}}');
        getPlayerProCard();
//        getRecentJoinedMembers('player-timeline', _token, '{{ $id }}');
        getMathchedJoinedMembers('dashboard', _token, '{{ $id }}');

        getPlayerAllCount();
    });

</script>
<script src="{{url('public/js/player/player-connect-dissmiss.js')}}"></script>
<script src="{{url('public/js/player/player-left-right-sidebar.js')}}"></script>
<!--<script src="{{url('public/js/player/recent-joined-members.js')}}"></script>-->
<script src="{{url('public/js/player/matched-mutual-joined-members.js')}}"></script>
@endsection