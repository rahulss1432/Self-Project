@if($pastSeasons->count()>0)
@foreach($pastSeasons as $data)
<div class="card" id="seasonRow_{{$data->id}}">
    <div class="card-header action_question">
        <h5 class="mb-0">
            <button class="btn btn-link editable" type="button"  data-toggle="collapse" data-target="#collapseAdded_{{$data->id}}" aria-expanded="false">
                past Season <small>({{$data->from_year}} - {{$data->to_year}})</small>
                <!-- <a href="javascript:void(0);"> <i class="far fa-edit icon"></i></a> -->
               <!--  <ul class="list-inline float-right">
                    <li class="list-inline-item">
                        
                    </li>
                    <li class="list-inline-item">
                        
                    </li>
                </ul> -->
                    <!--for delete-->

            </button>
            <div class="action">
                <a href="javascript:void(0);" data-toggle="collapse" data-target="#collapseAdded_{{$data->id}}"> <i class="fas fa-edit"></i></a>
                <a href="javascript:void(0);" id="delete{{$data->id}}" onclick='deletePastSeason("{{$data->id}}")'>
                    <i class="fas fa-trash-alt"></i>
                </a>
            </div>
        </h5>
    </div>    
    <div id="collapseAdded_{{$data->id}}" class="collapse" data-parent="#accordionAdded">
        <form id="updatePastSeasonForm_{{$data->id}}" method="POST" action="{{url('player/save-season')}}">  
            {{ csrf_field() }}
            <input type="hidden" name="season_id" value="{{$data->id}}">
            <input type="hidden" name="season_type" value="past">            
            <div class="card-body">
                <div class="container">
                    <div class="row common-row">
                        <div class="col-lg-8 col-xl-6">
                            <div class="row">
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">From</label>
                                        <div class="input-field date_picker z-index">
                                            <div class="input-group date savedPastFromYear" id="datetimepickerTo_{{$data->id}}" data-target-input="nearest">
                                                <input type="text" class="form-control datetimepicker-input" id="savedPastFromYear_{{$data->id}}" name="from_year" value="{{$data->from_year}}" data-target="#datetimepickerTo_{{$data->id}}" placeholder="Date" />
                                                <div class="input-group-append" data-target="#datetimepickerTo_{{$data->id}}" data-toggle="datetimepicker">
                                                    <div class="input-group-text">
                                                        <i class="flaticon-calendar"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">To</label>
                                        <div class="input-field date_picker dashed">
                                            <div class="input-group date savedPastToYear" id="datetimepickerFrom_{{$data->id}}" data-target-input="nearest">
                                                <input type="text" class="form-control datetimepicker-input" id="savedPastToYear_{{$data->id}}" name="to_year" value="{{$data->to_year}}" data-target="#datetimepickerFrom_{{$data->id}}" placeholder="Date" />
                                                <div class="input-group-append" data-target="#datetimepickerFrom_{{$data->id}}" data-toggle="datetimepicker">
                                                    <div class="input-group-text">
                                                        <i class="flaticon-calendar"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                                             
                    </div>
                    <!-- xxxx -->
                    <div class="row">
                        <div class="col">
                            <h2 class="inner-heading text-uppercase">
                                Offense
                            </h2>
                        </div>
                    </div>
                    <!-- xxxx -->
                    <div class="row common-row">
                        <div class="w-100"></div>
                        <div class="col-md-12 col-lg-6">
                            <div class="form-group">
                                <label class="control-label">Total Passing Yards</label>
                                <div class="input-field">
                                    <input type="text" name="total_passing" value="{{$data->total_passing}}" placeholder="Total Passing Yards">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-6">
                            <label class="control-label">Average Passing Yards (Game/Session)</label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="passing_game" value="{{$data->passing_game}}" placeholder="For Game">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text"  name="passing_season" value="{{$data->passing_season}}" placeholder="For Season">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">Completions</label>
                                        <div class="input-field">
                                            <input type="text" name="completion" value="{{$data->completion}}" placeholder="Completions">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">Completions(<span class="font-arial">%</span>)</label>
                                        <div class="input-field">
                                            <input type="text" name="completion_percent" value="{{$data->completion_percent}}" placeholder="Completions">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">QB Passer Rating</label>
                                <div class="input-field">
                                    <input type="text" name="passer_rating" value="{{$data->passer_rating}}" placeholder="QB Passer Rating">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-6">
                            <div class="form-group">
                                <label class="control-label">Total Rushing Yards</label>
                                <div class="input-field">
                                    <input type="text" name="total_rushing" value="{{$data->total_rushing}}" placeholder="Total Rushing Yards">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-6">
                            <label class="control-label">Average Passing Yards (Game/Session) </label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="rushing_game" value="{{$data->rushing_game}}"  placeholder="For Game">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="rushing_season" value="{{$data->rushing_season}}" placeholder="For Season">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-6">
                            <div class="form-group">
                                <label class="control-label">Total Receiving Yards</label>
                                <div class="input-field">
                                    <input type="text" name="total_receiving" value="{{$data->total_receiving}}" placeholder="Total Receiving Yards">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-6">
                            <label class="control-label">Average Passing Yards (Game/Session) </label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="receiving_game" value="{{$data->receiving_game}}" placeholder="For Game">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text"  name="receiving_season" value="{{$data->receiving_season}}" placeholder="For Season">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-6">
                            <div class="form-group">
                                <label class="control-label">Total Return Yards</label>
                                <div class="input-field">
                                    <input type="text" name="total_return" value="{{$data->total_return}}" placeholder="Total Receiving Yards">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-6">
                            <label class="control-label">Average Passing Yards (Game/Session) </label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="return_game" value="{{$data->return_game}}" placeholder="For Game">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="return_season" value="{{$data->return_season}}" placeholder="For Season">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-6">
                            <div class="form-group">
                                <label class="control-label">Total All Purpose Yards</label>
                                <div class="input-field">
                                    <input type="text" name="total_all_purpose" value="{{$data->total_all_purpose}}" placeholder="Total Receiving Yards">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-6">
                            <label class="control-label">Average Passing Yards (Game/Session) </label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="purpose_game" value="{{$data->purpose_game}}" placeholder="For Game">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="purpose_season" value="{{$data->purpose_season}}" placeholder="For Season">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Touchdowns</label>
                                <div class="input-field">
                                    <input type="text" name="tuchdowns" value="{{$data->tuchdowns}}" placeholder="Touchdowns">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Games Played</label>
                                <div class="input-field">
                                    <input type="text" name="games_played" value="{{$data->games_played}}"  placeholder="Games Played">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- xxxx -->
                    <div class="row">
                        <div class="col">
                            <h2 class="inner-heading text-uppercase">
                                Defense
                            </h2>
                        </div>
                    </div>
                    <!-- xxxx -->
                    <div class="row common-row">

                        <div class="col-md-12 col-lg-6">
                            <div class="form-group">
                                <label class="control-label">Total Tackles</label>
                                <div class="input-field">
                                    <input type="text" name="tackles" value="{{$data->tackles}}" placeholder="Total Tackles">
                                </div>
                            </div>    
                        </div>

                        <div class="col-md-12 col-lg-6">
                            <label class="control-label">Average Passing Yards (Game/Session) </label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="tackles_game" value="{{$data->tackles_game}}" placeholder="For Game">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="tackles_season" value="{{$data->tackles_season}}" placeholder="For Season">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-12 col-lg-6">
                            <div class="form-group">
                                <label class="control-label">Total Tackles for Loss</label>
                                <div class="input-field">
                                    <input type="text"  name="total_tackloss" value="{{$data->total_tackloss}}" placeholder="Total Tackles for Loss">
                                </div>
                            </div>    

                        </div>

                        <div class="col-md-12 col-lg-6">
                            <label class="control-label">Average Passing Yards (Game/Session) </label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="tackloss_game" value="{{$data->tackloss_game}}" placeholder="For Game">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="tackloss_season" value="{{$data->tackloss_season}}" placeholder="For Season">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="col-md-12 col-lg-6">
                            <div class="form-group">
                                <label class="control-label">Total Sacks</label>
                                <div class="input-field">
                                    <input type="text" name="total_sacks" value="{{$data->total_sacks}}" placeholder="Total Sacks">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 col-lg-6">
                            <label class="control-label">Average Passing Yards (Game/Session) </label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="sacks_game" value="{{$data->sacks_game}}" placeholder="For Game">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="sacks_season" value="{{$data->sacks_season}}"  placeholder="For Season">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-12 col-lg-6">
                            <div class="form-group">
                                <label class="control-label">Total Pass Breakups</label>
                                <div class="input-field">
                                    <input type="text" name="total_breaksups" value="{{$data->total_breaksups}}" placeholder="Total Pass Breakups">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 col-lg-6">
                            <label class="control-label">Average Passing Yards (Game/Session) </label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="breaksups_game" value="{{$data->breaksups_game}}" placeholder="For Game">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="breaksups_season" value="{{$data->breaksups_season}}" placeholder="For Season">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 col-lg-6">
                            <div class="form-group">
                                <label class="control-label">Total Interceptions</label>
                                <div class="input-field">
                                    <input type="text" name="total_interception" value="{{$data->total_interception}}" placeholder="Total Interceptions">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 col-lg-6">
                            <label class="control-label">Average Passing Yards (Game/Session) </label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text"  name="interception_game" value="{{$data->interception_game}}" placeholder="For Game">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" name="interception_season" value="{{$data->interception_season}}" placeholder="For Season">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Blocked Punts</label>
                                <div class="input-field">
                                    <input type="text" name="blocked_punts" value="{{$data->blocked_punts}}" placeholder="Blocked Punts">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- xxxx -->
                    <div class="row">
                        <div class="col">
                            <h2 class="inner-heading text-uppercase">
                                Specials
                            </h2>
                        </div>
                    </div>
                    <!-- xxxx -->
                    <div class="row common-row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Total Field Goals</label>
                                <div class="input-field">
                                    <input type="text" name="total_field_goal" value="{{$data->total_field_goal}}" placeholder="Total Field Goals">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Longest Field Goal</label>
                                <div class="input-field">
                                    <input type="text" name="longest_field_goal" value="{{$data->longest_field_goal}}" placeholder="Longest Field Goal">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Field Goal Percentage</label>
                                <div class="input-field">
                                    <input type="text" name="field_goal_percent" value="{{$data->field_goal_percent}}" placeholder="Field Goal Percentage">
                                </div>
                            </div>    
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Longest Punt</label>
                                <div class="input-field">
                                    <input type="text" name="longest_punt" value="{{$data->longest_punt}}" placeholder="Longest Punt">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label">Average Punt Distance</label>
                                <div class="input-field">
                                    <input type="text"  name="avg_punt_distance" value="{{$data->avg_punt_distance}}"  placeholder="Average Punt Distance">
                                </div>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
            <div class="card-footer">
        <a href="javascript:void(0);" class="position-relative add-more" id="update{{$data->id}}" onclick="updatePastSeasonForm({{$data->id}})">UPDATE</a>
    </div>
        </form>                 
        {!! JsValidator::formRequest('App\Player\Http\Requests\PastSeasonRequest','#updatePastSeasonForm_'.$data->id) !!}                                                                                                           
    </div>
</div>
<script>
            /* for current season form datepickers start and end date*/
            $("#datetimepickerTo_{{$data->id}}").datetimepicker({
            format: 'DD/MM/YYYY',
            maxDate: new Date(),
            widgetPositioning: {
            horizontal: 'right',
            vertical: 'bottom'
            },
    });
            $("#datetimepickerFrom_{{$data->id}}").datetimepicker({
            useCurrent: false,
            maxDate: new Date(),
            format: 'DD/MM/YYYY',
            widgetPositioning: {
            horizontal: 'right',
            vertical: 'bottom'
            }
    });
            $("#datetimepickerTo_{{$data->id}}").on("change.datetimepicker", function(e) {
    $("#datetimepickerFrom_{{$data->id}}").datetimepicker('minDate', e.date);
    });
            $("#datetimepickerFrom_{{$data->id}}").on("change.datetimepicker", function(e) {
    $("#datetimepickerTo_{{$data->id}}").datetimepicker('maxDate', e.date);
    });
</script>
@endforeach
@endif