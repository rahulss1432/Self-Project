@extends('player::layouts.app')
@section('content')
<main class="main-content side_padding">
    <div class="mainframe_border">
        <div class="borderheight" id="borderheight"></div>
    </div> 
    <section class="notifications_list">
        <div class="container-fluid">
            <div class="inner">
                <div class="common_heading">
                    <h3 class="black black-lg text-uppercase">NOTIFICATIONS</h3>
                </div>
                <div class="left_right_border"></div>
                <div id="getNotificationList">

                </div>
            </div>
        </div>
    </section>
</main>

<script>

    $(document).ready(function () {
        notificationList('');
    });

    function notificationList(url) {
        if (url == '' || url == undefined)
        {
            url = "{{url('player/notification-list')}}";
        }
        pageLoader('getNotificationList', 'show');
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.success) {
                    $("#getNotificationList").html('<ul class="list-unstyled content mb-0 bg-white green-scroll" id="NotificationsList">' + response.html + '</ul>');
                }
            }
        });
    }

     function removeNotification(id) {
        bootbox.confirm({
            size: "small",
            message: "Are you sure? you want to delete this notification.",
            buttons: {
                confirm: {
                    label: 'Yes',
                    className: 'btn btn-success rounded-0'
                },
                cancel: {
                    label: 'No',
                    className: 'btn btn-light rounded-0'
                }
            },
            callback: function (result) {
                if (result) {
                    var url = "{{ url('player/remove-notification') }}/ " + id;
                    $.ajax({type: "GET", url: url,
                        success: function (response) {
                            if (response.success) {
                                message('success', response.message);
                                notificationList('');
                            } else {
                                message('error', response.message);
                            }
                        }
                    });
                }
            }
        });        
    }
</script>
@endsection