<?php

namespace App\Player\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PastSeasonRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'from_year' => 'required',
            'to_year' => 'required',
            'completion_percent' => 'nullable|numeric|between:0,100',    
            'total_passing' => 'nullable|numeric',
            'passing_game' => 'nullable|numeric',
            'passing_season' => 'nullable|numeric',
            'completion' => 'nullable|numeric',
            'passer_rating' => 'nullable|numeric',
            'total_rushing' => 'nullable|numeric',
            'rushing_game' => 'nullable|numeric',
            'rushing_season' => 'nullable|numeric',
            'total_receiving' => 'nullable|numeric',
            'receiving_game' => 'nullable|numeric',
            'receiving_season' => 'nullable|numeric',
            'total_return' => 'nullable|numeric',
            'return_game' => 'nullable|numeric',
            'return_season' => 'nullable|numeric',
            'total_all_purpose' => 'nullable|numeric',
            'purpose_game' => 'nullable|numeric',
            'purpose_season' => 'nullable|numeric',
            'tuchdowns' => 'nullable|numeric',
            'games_played' => 'nullable|numeric',
            
            
            'tackles' => 'nullable|numeric',
            'tackles_game' => 'nullable|numeric',
            'tackles_season' => 'nullable|numeric',
            'total_tackloss' => 'nullable|numeric',
            'tackloss_game' => 'nullable|numeric',
            'tackloss_season' => 'nullable|numeric',
            'total_sacks' => 'nullable|numeric',
            'sacks_game' => 'nullable|numeric',
            'sacks_season' => 'nullable|numeric',
            'total_breaksups' => 'nullable|numeric',
            'breaksups_game' => 'nullable|numeric',
            'breaksups_season' => 'nullable|numeric',
            'total_interception' => 'nullable|numeric',
            'interception_game' => 'nullable|numeric',
            'interception_season' => 'nullable|numeric',
            'blocked_punts' => 'nullable|numeric',
            
            'total_field_goal' => 'nullable|numeric',
            'longest_field_goal' => 'nullable|numeric',
            'field_goal_percent' => 'nullable|numeric',
            'longest_punt' => 'nullable|numeric',
            'avg_punt_distance' => 'nullable|numeric',
        ];
    }

    public function messages() {
        return [
            //'from_year.required' => 'The from field year is required',
            //'to_year.required' => 'The from field year is required',
            'completion_percent.numeric|between:0,100' => 'The completion field should be numeric|between:0,100',
            
//            'total_passing.regex' =>'The only space not allowed.',
//            'completion.regex' =>'The only space not allowed.',
//            'passer_rating.regex' =>'The only space not allowed.',
//            'rushing_game.regex' =>'The only space not allowed.',
//            'total_rushing.regex' =>'The only space not allowed.',
//            'rushing_season.regex' =>'The only space not allowed.',
//            'total_receiving.regex' =>'The only space not allowed.',
//            'receiving_game.regex' =>'The only space not allowed.',
//            'receiving_season.regex' =>'The only space not allowed.',
//            'total_return.regex' =>'The only space not allowed.',
//            'return_game.regex' =>'The only space not allowed.',
//            'return_season.regex' =>'The only space not allowed.',
//            'total_all_purpose.regex' =>'The only space not allowed.',
//            'purpose_game.regex' =>'The only space not allowed.',
//            'purpose_season.regex' =>'The only space not allowed.',
//            'tuchdowns.regex' =>'The only space not allowed.',
//            'games_played.regex' =>'The only space not allowed.',
//            
//            
//            'tackles.regex' =>'The only space not allowed.',
//            'tackles_game.regex' =>'The only space not allowed.',
//            'tackles_season.regex' =>'The only space not allowed.',
//            'total_tackloss.regex' =>'The only space not allowed.',
//            'tackloss_game.regex' =>'The only space not allowed.',
//            'tackloss_season.regex' =>'The only space not allowed.',
//            'total_sacks.regex' =>'The only space not allowed.',
//            'sacks_game.regex' =>'The only space not allowed.',
//            'sacks_season.regex' =>'The only space not allowed.',
//            'total_breaksups.regex' =>'The only space not allowed.',
//            'breaksups_game.regex' =>'The only space not allowed.',
//            'breaksups_season.regex' =>'The only space not allowed.',
//            'total_interception.regex' =>'The only space not allowed.',
//            'interception_game.regex' =>'The only space not allowed.',
//            'interception_season.regex' =>'The only space not allowed.',
//            'blocked_punts.regex' =>'The only space not allowed.',
//            
//            
//            'total_field_goal.regex' =>'The only space not allowed.',
//            'longest_field_goal.regex' =>'The only space not allowed.',
//            'field_goal_percent.regex' =>'The only space not allowed.',
//            'longest_punt.regex' =>'The only space not allowed.',
//            'avg_punt_distance.regex' =>'The only space not allowed.',
        ];
    }

}
