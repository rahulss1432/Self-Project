<?php

namespace App\Player\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PlayerStepThreeRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'playing_exp' => 'nullable',
            'current_team' => "nullable|max:100|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/",
            'current_league' => "nullable|max:100|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/",
            'former_team' => "nullable|max:100|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/",
            'former_league' => "nullable|max:100|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/",
            'current_team_link' => 'nullable|url',
            'current_league_link' => 'nullable|url',
            'former_team_link' => 'nullable|url',
            'former_league_link' => 'nullable|url',
        ];
    }

    public function messages() {
        return [           
            'current_team_link.regex' => 'Please provide valid url.',
            'current_league_link.regex' => 'Please provide valid url.',
            'former_team_link.regex' => 'Please provide valid url.',
            'former_league_link.regex' => 'Please provide valid url.',
        ];
    }

}
