<?php

namespace App\Player\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AddEventRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'banner_image' => 'nullable|mimes:jpeg,jpg,png|max:2048',
            'event_name' => 'required',
            'team1' => 'nullable|different:team2',
            'team2' => 'nullable|different:team1',
            'start_date' => 'required',
            'end_date' => 'required',
            'start_time' => 'required',
            'end_time' => 'required',
            'ticket_url' => 'nullable|url',
            'zipcode' => 'nullable|regex:/^[a-zA-Z0-9]+$/u|max:6',
        ];
    }

    /*
     * Function for show validation messages.
     */

    public function messages() {
        return [
            'banner_image.max' => 'The banner image may not be greater than 2MB.',
        ];
    }

}
