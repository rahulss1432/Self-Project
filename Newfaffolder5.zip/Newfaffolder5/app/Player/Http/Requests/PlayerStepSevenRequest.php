<?php

namespace App\Player\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PlayerStepSevenRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'salary_from' => 'nullable|numeric|min:1',
            'salary_to' => 'nullable|numeric||min:1|greater_salary',
        ];
    }
    
     public function messages() {
         return [
             'salary_to.greater_salary' =>'The from salary is not greater than to salary.',
            ];
     }
}
