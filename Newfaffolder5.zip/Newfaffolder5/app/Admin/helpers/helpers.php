<?php

use App\Models\Menus;
use App\User;
use App\Models\Job;
use App\Models\Event;
use App\Models\UserMedia;
use App\Models\Post;
use Carbon\Carbon;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* Function get user full name with refrence id */

function getUserFullNameById($id) {
    $data = User::find($id);
    if (!empty($data)) {
        $name = ($data->full_name) ? $data->full_name : '-';
        $reference_id = ($data->reference_id) ? $data->reference_id : '-';
        return ucfirst($name) . " (" . $reference_id . ")";
    } else {
        return '-';
    }
}

/* chat listing time conversion function */

function chatTimeShow($created_at) {

    $full = false;
    $now = new Carbon(date('Y-m-d H:i:s'));
    $ago = new Carbon($created_at);
    $diff = $now->diff($ago);
    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;
    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }
    if (!$full)
        $string = array_slice($string, 0, 1);
    echo $string ? implode(', ', $string) . ' ago' : 'just now';
}

/* Function convert Date & Time (MM/DD/YYYY, HH:MM AM/PM (12 Hour Format)) */

function dateTimeFormat($string) {
    return Carbon::parse($string)->format('m/d/Y h:i A');
}

/* Function search from server created at date */

function startDateFormatServer($string) {
    $dateTime = new Carbon(Carbon::parse($string)->format('Y-m-d'));
    return $dateTime->toDateString();
}

function endDateFormatServer($string) {
    $dateTime = new Carbon(Carbon::parse($string)->format('Y-m-d'));
    return $dateTime->addDays(1)->toDateString();
}

/* End */
/* Function for get admin sidebar menu */

function getAllMenus() {
    return Menus::all();
}

/* End */

