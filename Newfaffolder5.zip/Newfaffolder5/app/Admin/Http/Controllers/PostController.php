<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\PostRepository;

class PostController extends Controller {

    public function __construct(PostRepository $post, \App\Repositories\UserRepository $commanUser) {
        $this->postRepository = $post;
        $this->commanUser = $commanUser;
    }

    /*
     * list all post
     */

    public function index() {
        return View('admin::manage-post.manage-post');
    }

    /*
     * ajax manage post data
     */

    function ajaxManagePostList(Request $request) {
        $getPostList = $this->postRepository->getPostList($request);
        $html = View::make('admin::ajax-content.manage-post._post-list', ['getPostList' => $getPostList])->render();
        return Response::json(['html' => $html]);
    }

    /**
     * function using for update status
     * @param Request $request
     * @return type
     */
    function updateStatus(Request $request) {
        return $this->postRepository->updateStatus($request);
    }

    /**
     * function using for post view
     * @param type $id
     * @return type
     */
    function postView($id) {
        $getPost = $this->postRepository->getPostById(base64_decode($id));
        return View('admin::manage-post.post-view', ['getPost' => $getPost]);
    }

    /**
     * function using for get post media list
     * @param Request $request
     * @return type
     */
    function postMediaList(Request $request) {
        $getPost = $this->postRepository->getPostById($request->id);
        $html = View::make('admin::ajax-content.manage-post._post-media-list', ['getPost' => $getPost])->render();
        return Response::json(['html' => $html]);
    }

    /**
     * function using for get post comment list
     * @param Request $request
     * @return type
     */
    function postCommentList(Request $request) {
        $getPostComment = $this->postRepository->getPostEventList($request->id, 'comment');
        $html = View::make('admin::ajax-content.manage-post._comment-list', ['getPostComment' => $getPostComment])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Function using for get my post media view
     */

    public function getMediaModalView(Request $request) {
        $getMedia = $this->commanUser->getMyMediaView($request);
        $html = View::make('admin::ajax-content.manage-post._post-media-modal', ['getMedia' => $getMedia])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /*
     * Function using for media comment list
     */

    public function mediaCommentList(Request $request) {
        $getComment = $this->commanUser->getMediaEventsByType($request, 'comment');
        $html = View::make('admin::ajax-content.manage-post._media-comment-list', ['getComment' => $getComment])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

}
