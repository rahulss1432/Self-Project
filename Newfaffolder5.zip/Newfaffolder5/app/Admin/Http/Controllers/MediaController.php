<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\MediaRepository;

class MediaController extends Controller
{
    
    public function __construct(MediaRepository $media)
    {
       $this->userMedia = $media;   
    }

    /*
     * list all media
     */
    public function index()
    {
        return View('admin::manage-media.index');
    }

    /*
    * ajax manage media data
    */
   
    function ajaxManageMediaList(Request $request){
        $mediaList = $this->userMedia->getMediaList($request);
        $html = View::make('admin::ajax-content.manage-media._media-list',['mediaList' => $mediaList])->render();
        return Response::json(['html' => $html]);
    }
    
     /*
     * function using for view media
     */
    
    function mediaView($id){
        $getMedia = $this->userMedia->getMediaById(base64_decode($id));
        return View('admin::manage-media.media-view',['getMedia' => $getMedia]);
    }
    
    
     /*
     * function using for view media
     */
    
    function ajaxManageMediaComments(Request $request){
        $getMedia = $this->userMedia->getMediaCommentById($request->media_id, 'comment');
        $html = View::make('admin::ajax-content.manage-media._comments-list',['getMedia' => $getMedia])->render();
        return Response::json(['html' => $html]);
    }
    
     /*
     * update media status 
     */
    
    public function updateStatus(Request $request) {
        return $this->userMedia->updateStatus($request);
    }
    
}
