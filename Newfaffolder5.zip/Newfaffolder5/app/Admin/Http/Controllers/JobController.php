<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Team\JobRepository;

class JobController extends Controller {

    public function __construct(JobRepository $jobRepository) {
        $this->jobRepository = $jobRepository;
    }

    /*
     * list all job
     */

    public function index() {
        return View('admin::manage-jobs.manage-jobs');
    }

    /*
     * ajax manage job data
     */

    function ajaxManageJobsList(Request $request) {

        $jobLists = $this->jobRepository->getJobList($request);
        $html = View::make('admin::ajax-content.manage-jobs._jobs-list', ['jobList' => $jobLists])->render();
        return Response::json(['html' => $html]);
    }

    public function getLevelList(Request $request) {
        $levels = \App\Models\Job::groupBy('level_id')->get();
        foreach ($levels as $level) {
            $levelModel = \App\Models\Level::where(['id' => $level->level_id])->first();
            $id = $levelModel['id'];
            $name = $levelModel['level_name'];
            echo "<option value='$id'>$name</option>";
        }
    }

    /*

     * job detail
     */

    public function getView(Request $request) {
        $id = base64_decode($request->id);
        $jobDetail = $this->jobRepository->getJobDetail($id);
        return View('admin::manage-jobs.manage-view', ['jobDetail' => $jobDetail]);
    }

    /**
     *  job detail
     * @param Request $request
     * @return type
     */
    public function getJobDetail(Request $request) {
        return View('admin::ajax-content.manage-jobs._jobs-detail');
    }

    /*
     * Update user status
     */

    public function changeStatus(Request $request) {
        return $this->jobRepository->changeStatus($request);
    }

}
