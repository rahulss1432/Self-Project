<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\DashboardRepository;
use App\Roles;
use App\User;

class DashboardController extends Controller {

    public function __construct(DashboardRepository $dashboard) {
        $this->dashboard = $dashboard;
    }

    /**
     * Display a listing of the resource.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $this->dashboard->index();
        return view('admin::dashboard');
    }

    /**
     * check permission
     * @param Request $request
     * @return type
     */
    public function postAdminPermission(Request $request) {
        $user = User::find($request->user_id);
        $user->roles()->detach();
        if ($request['role_player']) {
            $user->roles()->attach(Roles::where('name', 'player')->first());
        }
        if ($request['role_team']) {
            $user->roles()->attach(Roles::where('name', 'team')->first());
        }
        if ($request['role_coach']) {
            $user->roles()->attach(Roles::where('name', 'coach')->first());
        }
        return redirect()->back();
    }

    /**
     * player page
     * @return type
     */
    public function playerPage() {
        try {
            return view('admin::dashboard.player');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /**
     * Team page
     * @return type
     */
    public function teamPage() {
        try {
            return view('admin::dashboard.team');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /**
     * Coach page
     * @return type
     */
    public function coachPage() {
        try {
            return view('admin::dashboard.coach');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /**
     * Dashboard chart
     * @param Request $request
     * @return type
     */
    public function chartDetail(Request $request) {

        try {
            $dashboardData = $this->dashboard->getdashboardData($request);
            return Response::json(['success' => true, 'userCount' => $dashboardData]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

}
