<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\AdminRepository;
use App\Admin\Http\Requests\AddAdminRequest;

class AdminController extends Controller
{
    
    public function __construct(AdminRepository $adminRepository)
    {
        $this->adminRepository = $adminRepository;
    }

    /*
     * list all admin
     */
    public function index()
    {
        return View('admin::manage-admin.index');
    }

    /*
     * manage admin data
     */
    function manageAdminList(Request $request){
        $admins = $this->adminRepository->getAllAdmins($request);
        $html = View::make('admin::ajax-content.manage-admin._admins-list', ['admins' => $admins])->render();
        return Response::json(['html' => $html]);
    }
    
    /*
     * Add Admins
     */
    public function add(){
        return View('admin::manage-admin.add');
    }
    
    /*
     * Save and update Admins
     */
    public function save(AddAdminRequest $request){              
        return $this->adminRepository->save($request);
    }
    /*
     * Update Status
     */
    public function status(Request $request){              
        return $this->adminRepository->updateStatus($request);
    }
    /*
     * Edit Admin
     */
    public function edit($id){              
        return $this->adminRepository->adminEdit(base64_decode($id));
    }
    /*
     * Assign Permission
     */
    public function assign($id){              
        return $this->adminRepository->adminAssign(base64_decode($id));
    }
    /*
     * Assign Permission
     */
    public function assignPermission(Request $request){              
        return $this->adminRepository->adminAssignPermission($request);
    }
    
}
