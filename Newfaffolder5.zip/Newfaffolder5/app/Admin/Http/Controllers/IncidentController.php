<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\ReportRepository;
use App\Admin\Http\Requests\ReportRequest;

class IncidentController extends Controller
{
    
    public function __construct(ReportRepository $reportRepository) {
        $this->reportRepository = $reportRepository;
    }

    /*
     * list all incidents
     */
    public function index()
    {
        return View('admin::manage-incident.manage-incidents');
    }

    /*
     * manage incidents data
     */
    function manageIncidentsList(Request $request){
        $incidentLists = $this->reportRepository->getIncidentLists($request);
        $html = View::make('admin::ajax-content.manage-incidents._incidents-list',['incidents'=>$incidentLists])->render();
        return Response::json(['html' => $html]);
    }
    
     /*
     * view incident status
     */

     public function view(Request $request) {
        $incident = $this->reportRepository->getIncidentById(base64_decode($request->id));
        return View('admin::manage-incident.manage-incident-view',['incident'=>$incident]);
    }
   
    /*
     * get reporter list
     */
    
    public function getReporterList(Request $request) {
            $incidents = \App\Models\Incident::groupBy('from_id')->get();
            foreach ($incidents as $incident) {
                $reporter = \App\User::find($incident->from_id);
                echo "<option value='$incident->from_id'>$reporter->full_name</option>";
            }  
    }
    
    /*
     * resolve resolveIncident
     */ 
    public function report(ReportRequest $request){
      return $this->reportRepository->resolveIncident($request); 
    }

}
