<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\MessageRepository;

class ChatController extends Controller
{
    
    public function __construct(MessageRepository $messageRepository)
    {
         $this->messageRepository = $messageRepository;
    }

    /*
     * list all chats
     */
    public function index()
    {
        return View('admin::chat.chats');
    }

    /*
     * ajax manage chats data
     */
    function ajaxManageChatsList(Request $request){
         try {
            $chatMessages = $this->messageRepository->getAllChatMessage($request);
            $html = View::make('admin::ajax-content.chats._chats-list',['chatMessages' => $chatMessages])->render();
            return Response::json(['html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }
  
     /*
     * get user chat view section 
     */
    
    function  viewChat($id,$fromId){
         $chatMessages = $this->messageRepository->getMessageBySelectUser(base64_decode($id));
         if(empty($chatMessages))
         {
                return redirect()->back();
         }
         return View('admin::chat.chat_view',['userChats' => $chatMessages, 'fromId' => base64_decode($fromId)]);
    }
    
}
