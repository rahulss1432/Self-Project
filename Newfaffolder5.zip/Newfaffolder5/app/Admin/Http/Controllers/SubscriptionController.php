<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\SubscriptionsRepository;
use App\Admin\Http\Requests\SubscriptionValidation;

class SubscriptionController extends Controller {

    public function __construct(SubscriptionsRepository $subscriptions) {
        $this->adminSubscriptions = $subscriptions;
    }

    /*
     * list all subscriptions
     */

    public function index() {
        return View('admin::subscription.index');
    }

    /*
     * ajax manage subscriptions data
     */

    function ajaxSubscriptionsList(Request $request) {
        $getSubscription = $this->adminSubscriptions->getAllSubscriptions($request);
        $html = View::make('admin::ajax-content.subscriptions._subscriptions-list', ['getSubscription' => $getSubscription])->render();
        return Response::json(['html' => $html]);
    }

    /**
     * render add subscription page
     * @return type
     */
    function addSubscription() {
        return View('admin::subscription.add');
    }

    /**
     * edit subscription page
     * @param type $id
     * @return type
     */
    function editSubscription($id) {
        $getSubscription = $this->adminSubscriptions->geSubscriptionsById(base64_decode($id));
        if (empty($getSubscription)) {
            return redirect()->back();
        }
        return View('admin::subscription.update', ['subscription' => $getSubscription]);
    }

    /**
     * save subscription.
     * @param SubscriptionValidation $request
     * @return type
     */
    function save(SubscriptionValidation $request) {
        return $this->adminSubscriptions->saveSubscriptions($request);
    }

    /**
     * update subscription
     * @param SubscriptionValidation $request
     * @return type
     */
    function update(SubscriptionValidation $request) {
        return $this->adminSubscriptions->updateSubscriptions($request);
    }

    /*
     * Update Status
     */

    public function status(Request $request) {
        return $this->adminSubscriptions->updateStatus($request);
    }

    /**
     * subscription view
     * @param type $id
     * @return type
     */
    function viewSubscription($id) {
        $getSubscription = $this->adminSubscriptions->geSubscriptionsById(base64_decode($id));
        if (empty($getSubscription)) {
            return redirect()->back();
        }
        return View('admin::subscription.view', ['subscription' => $getSubscription]);
    }

}
