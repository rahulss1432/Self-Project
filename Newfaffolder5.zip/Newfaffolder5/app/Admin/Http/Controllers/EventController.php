<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\EventRepository;
use App\Admin\Http\Requests\AddEventRequest;
class EventController extends Controller {

    public function __construct(EventRepository $eventRepository) {
        $this->eventRepository = $eventRepository;
    }

    /*
     * List all events
     */

    public function index() {
        return View('admin::events.events');
    }

    /*
     * Ajax manage events data
     */

    function eventsList(Request $request) {
        try {
            $events = $this->eventRepository->getAllEvents($request);
            $html = View::make('admin::ajax-content.events._events-list', ['events' => $events])->render();
            return Response::json(['html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /*
     * Add events
     */

    public function add() {
        return View('admin::events.add');
    }

    /*
     * Save events
     */

    public function save(AddEventRequest $request) {
        return $this->eventRepository->save($request);
    }

    /*
     * Update event status
     */

    public function changeStatus(Request $request) {
        return $this->eventRepository->changeStatus($request);
    }

    /*
     * Edit event
     */

    public function edit(Request $request) {
        $event = $this->eventRepository->getEventById(base64_decode($request->id));
        return View('admin::events.edit', ['event' => $event]);
    }

    /*
     * View event
     */

    public function view(Request $request) {
        $event = $this->eventRepository->getEventById(base64_decode($request->id));
        if (!empty($event)) {
            return View('admin::events.view', ['event' => $event]);
        }
        abort(404);
    }

    /*
     * open add event form modal
     */

    function addTeamForm() {
        $html = View::make('admin::ajax-content.events._add-team-modal-form')->render();
        return Response::json(['html' => $html]);
    }

}
