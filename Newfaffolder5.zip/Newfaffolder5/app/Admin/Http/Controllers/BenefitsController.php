<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\UserBenefitRepository;
use Illuminate\Support\Facades\Auth;

class BenefitsController extends Controller {

    public function __construct(UserBenefitRepository $userBenefitRepository) {
        $this->userBenefitRepository = $userBenefitRepository;
    }

    /*
     * list all user benefits
     */

    public function index() {
        return View('admin::manage-benefits.benefits');
    }

    /*
     * ajax manage users benefits data
     */

    function benefitsList(Request $request) {
        try {
            $userBenefits = $this->userBenefitRepository->getAllUserBenefits($request);
            $html = View::make('admin::ajax-content.manage-benefits._users-benefits-list', ['userBenefits' => $userBenefits])->render();
            return Response::json(['html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }
    
    /*
     * Update user benefit status
     */

    public function changeBenefitStatus(Request $request) {
        return $this->userBenefitRepository->changeStatus($request);
    }

}
