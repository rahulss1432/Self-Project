<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\UserRepository;
use App\Admin\Http\Requests\PlayerAddRequest;
use App\Admin\Http\Requests\CoachAddRequest;
use App\Admin\Http\Requests\TeamAddRequest;
use App\Admin\Http\Requests\UserUpdateRequest;
use App\Admin\Http\Requests\EditProfileRequest;
use App\Admin\Http\Requests\ChangePasswordRequest;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller {

    public function __construct(UserRepository $userRepository, \App\Repositories\UserRepository $commanUser) {
        $this->userRepository = $userRepository;
        $this->commanUser = $commanUser;
    }

    /*
     * list all user
     */

    public function index() {
        return View('admin::users.users');
    }

    /*
     * ajax manage users data
     */

    function usersList(Request $request) {
        try {
            $users = $this->userRepository->getAllusers($request);
            $html = View::make('admin::ajax-content.users._users-list', ['users' => $users])->render();
            return Response::json(['html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /*
     * Add users
     */

    public function add() {
        return View('admin::users.add');
    }

    /*
     * View users
     */

    public function view(Request $request) {
        $tab = '';
        if (!empty($request->tab)) {
            $tab = $request->tab;
        }
        $user = $this->userRepository->getUserById(base64_decode($request->id));
        return View('admin::users.view', ['user' => $user, 'tab' => $tab]);
    }

    /*
     * Edit users
     */

    public function edit(Request $request) {
        $user = $this->userRepository->getUserById(base64_decode($request->id));
        return View('admin::users.edit', ['user' => $user]);
    }

    /*
     * Player save
     */

    public function playerSave(PlayerAddRequest $request) {
        return $this->userRepository->userSave($request);
    }

    /*
     * Coach save
     */

    public function coachSave(CoachAddRequest $request) {
        return $this->userRepository->userSave($request);
    }

    /*
     * Team save
     */

    public function teamSave(TeamAddRequest $request) {
        return $this->userRepository->userSave($request);
    }

    /*
     * User update
     */

    public function userUpdate(UserUpdateRequest $request) {
        return $this->userRepository->userSave($request);
    }

    /*
     * Update user status
     */

    public function changeStatus(Request $request) {
        return $this->userRepository->changeStatus($request);
    }

    /*
     * Ajax Personal Info View
     */

    public function personalInfoView(Request $request) {
        $post = $request->all();
        $role = getUserById($post['id'], 'role');
        $user = $this->userRepository->getUserById($post['id']);
        if ($role == 'player') {
            $html = View::make('admin::ajax-content.users.player-view._personal-info-view', ['user' => $user])->render();
        } elseif ($role == 'coach') {
            $html = View::make('admin::ajax-content.users.coach-view._personal-info-view', ['user' => $user])->render();
        } else {
            $html = View::make('admin::ajax-content.users.team-view._basic-info-view', ['user' => $user])->render();
        }
        return Response::json(['html' => $html]);
    }

    /*
     * Ajax Personal Info View
     */

    public function contactInfoView(Request $request) {
        $post = $request->all();
        $role = getUserById($post['id'], 'role');
        $user = $this->userRepository->getUserById($post['id']);
        if ($role == 'player') {
            $html = View::make('admin::ajax-content.users.player-view._contact-info-view', ['user' => $user])->render();
        } elseif ($role == 'coach') {
            $html = View::make('admin::ajax-content.users.coach-view._contact-info-view', ['user' => $user])->render();
        } else {
            $html = View::make('admin::ajax-content.users.team-view._contact-info-view', ['user' => $user])->render();
        }
        return Response::json(['html' => $html]);
    }

    /*
     * Ajax About View
     */

    public function aboutView(Request $request) {
        $post = $request->all();
        $role = getUserById($post['id'], 'role');
        $user = $this->userRepository->getUserById($post['id']);
        if ($role == 'player') {
            $html = View::make('admin::ajax-content.users.player-view._about-view', ['user' => $user])->render();
        } elseif ($role == 'coach') {
            $html = View::make('admin::ajax-content.users.coach-view._about-view', ['user' => $user])->render();
        } else {
            $html = View::make('admin::ajax-content.users.team-view._about-view', ['user' => $user])->render();
        }
        return Response::json(['html' => $html]);
    }

    /*
     * Ajax Desired Benifits View
     */

    public function desiredBenifitsView(Request $request) {
        $post = $request->all();
        $role = getUserById($post['id'], 'role');
        $user = $this->userRepository->getUserById($post['id']);
        if ($role == 'player') {
            $html = View::make('admin::ajax-content.users.player-view._desired-benifits-view', ['user' => $user])->render();
        } elseif ($role == 'coach') {
            $html = View::make('admin::ajax-content.users.coach-view._desired-benifits-view', ['user' => $user])->render();
        } else {
            $html = View::make('admin::ajax-content.users.team-view._desired-benifits-view', ['user' => $user])->render();
        }
        return Response::json(['html' => $html]);
    }

    /*
     * Ajax Measurables View
     */

    public function measurablesView(Request $request) {
        $post = $request->all();
        $user = $this->userRepository->getUserById($post['id']);
        $html = View::make('admin::ajax-content.users.player-view._measurables-view', ['user' => $user])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Ajax Key Stats View
     */

    public function keyStatsView(Request $request) {
        $post = $request->all();
        $user = $this->userRepository->getUserById($post['id']);
        $html = View::make('admin::ajax-content.users.player-view._key-stats-view', ['user' => $user])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Ajax Media View
     */

    public function mediaView(Request $request) {
        $post = $request->all();
        $role = getUserById($post['id'], 'role');
        $user = $this->userRepository->getUserById($post['id']);
        $getVideo = $this->commanUser->getMediaListByIdAndType($user->id, 'video');
        $getImage = $this->commanUser->getMediaListByIdAndType($user->id, 'image');
        $html = View::make('admin::ajax-content.users._media-view', ['user' => $user, 'getImage' => $getImage, 'getVideo' => $getVideo])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Ajax Media View
     */

    public function planPurchaseView(Request $request) {
        $post = $request->all();
        $role = getUserById($post['id'], 'role');
        $subscription_id = getUserById($post['id'], 'subscription_id');
        $userTransactions = $this->userRepository->getUserTransactions($post);
        if ($role == 'player') {
            $html = View::make('admin::ajax-content.users.player-view._plan-view', ['transactions' => $userTransactions, 'id' => $post['id'], 'subscription_id' => $subscription_id])->render();
        } elseif ($role == 'coach') {
            $html = View::make('admin::ajax-content.users.coach-view._plan-view', ['transactions' => $userTransactions, 'id' => $post['id'], 'subscription_id' => $subscription_id])->render();
        } else {
            $html = View::make('admin::ajax-content.users.team-view._plan-view', ['transactions' => $userTransactions, 'id' => $post['id'], 'subscription_id' => $subscription_id])->render();
        }
        return Response::json(['html' => $html]);
    }

    /*
     * Purcahse view
     *  
     * */

    public function purchaseView(Request $request) {
        $post = $request->all();
        $role = getUserById($post['id'], 'role');
        $user = $this->userRepository->getUserById($post['id']);
        $transaction = $user->userTransaction->where('id', $post['transaction_id'])->first();
        if ($role == 'player') {
            $html = View::make('admin::ajax-content.users.player-view._purchased-view', ['transaction' => $transaction])->render();
        } elseif ($role == 'coach') {
            $html = View::make('admin::ajax-content.users.coach-view._purchased-view', ['transaction' => $transaction])->render();
        } else {
            $html = View::make('admin::ajax-content.users.team-view._purchased-view', ['transaction' => $transaction])->render();
        }
        return Response::json(['html' => $html]);
    }

    /*
     * team roster View
     */

    public function teamRosterView(Request $request) {
        $post = $request->all();
        $teamPlayer = $this->userRepository->getTeamPlayerById($post['id']);
        $teamStaff = $this->userRepository->getTeamStaffById($post['id']);
        $html = View::make('admin::ajax-content.users.team-view._team-roster-view', ['teamPlayer' => $teamPlayer, 'teamStaff' => $teamStaff])->render();
        return Response::json(['html' => $html]);
    }

    /**
     * Display user profile
     * @return \Illuminate\Http\Response
     */
    public function getProfile() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return View('admin::profile', ['id' => $userId]);
    }

    /**
     * Update user profile
     *
     * @return \Illuminate\Http\Response
     */
    public function updateProfile(EditProfileRequest $request) {
        return $this->userRepository->updateProfile($request);
    }

    /**
     * Display change password
     * @return \Illuminate\Http\Response
     */
    public function changePassword() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return View('admin::change-password', ['id' => $userId]);
    }

    /**
     * Update user password
     *
     * @return \Illuminate\Http\Response
     */
    public function updatePassword(ChangePasswordRequest $request) {
        return $this->userRepository->updatePassword($request);
    }

    /**
     * Method for get contry code.
     *
     */
    public function getCountryCode(Request $request) {
        return getCountryCode($request->all());
    }

    /*
     * Function using for get my post media view
     */

    public function getMediaModalView(Request $request) {
        $getMedia = $this->commanUser->getMyMediaView($request);
        $html = View::make('admin::ajax-content.users._post-media-modal', ['getMedia' => $getMedia])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /*
     * Function using for media comment list
     */

    public function mediaCommentList(Request $request) {
        $getComment = $this->commanUser->getMediaEventsByType($request, 'comment');
        $html = View::make('admin::ajax-content.users._media-comment-list', ['getComment' => $getComment])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * send transcation invoice to user
     * @param type $id
     * @return type
     */
    public function sendInvoiceData($id) {
        $result = $this->userRepository->sendInvoiceData($id);
        if (!empty($result)) {
            return response()->json(['success' => true, 'message' => 'Send Invoice.Please check your mail.']);
        } else {
            return response()->json(['success' => false, 'message' => 'Please try again.']);
        }
    }

}
