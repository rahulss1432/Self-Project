<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CoachAddRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        if (!empty($this->id)) {
            return [
                'first_name' => 'required|alpha_dash|min:2|max:30',
                'last_name' => 'required|alpha_dash|min:2|max:30',
                'email' => 'required|check_email_format|unique:users,email,',
                'phone_number' => 'required|phone_format',
                'country_id' => 'required',
                'state_id' => 'required',
                'city' => "required|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/|max:100",
//                'zip_code' => 'required|regex:/^[a-zA-Z0-9]+$/u|max:6|min:1',
                'zip_code' => 'required|get_latlong_byzip|max:10',
                'address_line_1' => "required|string|max:100"
            ];
        } else {
            return [
                'first_name' => 'required|alpha_dash|min:2|max:30',
                'last_name' => 'required|alpha_dash|min:2|max:30',
                'email' => 'required|check_email_format|unique:users,email,',
                'phone_number' => 'required|phone_format',
                'country_id' => 'required',
                'state_id' => 'required',
                'plan_id' => 'required',
                'signup_type' => 'required',
                'city' => "required|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/|max:100",
//                'zip_code' => 'required|regex:/^[a-zA-Z0-9]+$/u|max:6|min:1',
                'zip_code' => 'required|get_latlong_byzip|max:10',
                'address_line_1' => "required|string|max:100"
            ];
        }
    }

    public function messages() {
        if (!empty($this->id)) {
            return [
                'zip_code.get_latlong_byzip' => 'The zip code is invalid.',
                'phone_number.required' => 'The mobile number field is required.',
                'phone_number.phone_format' => 'The phone number field is invalid.',
                'email.check_email_format' => 'Please fill valid email.',
                'address_line_1.required' => 'The address field is required.',
            ];
        } else {
            return [
                'zip_code.get_latlong_byzip' => 'The zip code is invalid.',
                'plan_id.required' => 'The plan field is required.',
                'signup_type.required' => 'The payment method field is required.',
                'phone_number.required' => 'The mobile number field is required.',
                'phone_number.phone_format' => 'The phone number field is invalid.',
                'email.check_email_format' => 'Please fill valid email.',
                'address_line_1.required' => 'The address field is required.',
            ];
        }
    }

}
