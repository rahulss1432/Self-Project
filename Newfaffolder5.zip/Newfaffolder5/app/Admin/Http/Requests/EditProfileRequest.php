<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EditProfileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
     
            return [
                'full_name' => 'required|regex:/^[a-zA-Z0-9][\sa-zA-Z0-9]*$/|max:70',
                'email' => 'required|email|max:70|unique:users,email,'.$this->id,
                'phone_number' => 'required|phone_format',
                'country_id' => 'required',
                'state_id' => 'required',
                'city' => 'required|remove_spaces',
                'zip_code' => 'required|regex:/^[a-zA-Z0-9]+$/u|max:6',
                'address_line_1' => 'required|remove_spaces|max:150',
            ];

      
    }

    /*
     * Function for show validation messages.
     */
    public function messages(){
        return [
            'full_name.required' => 'The name field is required.',
            'phone_number.required' => 'The mobile number field is required.',
            'phone_number.phone_format' => 'The mobile number field is invalid.',
            'country_id.required' => 'The country field is required.',
            'state_id.required' => 'The state field is required.',
            'address_line_1.required' => 'The address field is required.',
            'full_name.remove_spaces' => 'Only space not allowed',
            'city.remove_spaces' => 'Only space not allowed',
            'zip_code.remove_spaces' => 'Only space not allowed',
            'address_line_1.remove_spaces' => 'Only space not allowed',
        ];
    }
}
