<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AddEventRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
//            'banner_image' => 'nullable',
            'event_name' => 'required|regex:/^[a-zA-Z0-9.@&][\sa-zA-Z0-9.@&]*$/|max:50',
            'team1' => 'nullable|different:team2',
            'team2' => 'nullable|different:team1',
            'start_date' => 'required',
            'end_date' => 'required',
            'start_time' => 'required',
            'end_time' => 'required',
            'ticket_url' => 'nullable|url',
            'description' => 'nullable|remove_spaces|max:500',
            'zipcode' => 'nullable|regex:/^[a-zA-Z0-9]+$/u|max:6',
            'city' => 'nullable|regex:/^[a-zA-Z0-9.@&][\sa-zA-Z0-9.@&]*$/|max:100',
            'address1' => 'nullable|max:100',
        ];
    }

    /*
     * Function for show validation messages.
     */

    public function messages() {
        return [
//            'banner_image.max' => 'The banner image may not be greater than 2MB.',
            'description.remove_spaces' => 'The only spaces are not allowed.',
            'address1.regex' => 'The address1 field is invalid.',
        ];
    }

}
