@php $pageTitle = 'Subscriptions | Admin'; @endphp
@php $activePage = 'subscriptions'; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.header')
@include('admin::layouts.include.side-menu')

<div class="main-content adduser_page subscriptionsadd_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Subscriptions Add</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{url('admin/subscriptions')}}">Subscriptions</a></li>
                        <li class="breadcrumb-item">Subscriptions Add</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <div class="add_form mx-auto">
                <div class="card">
                    <div class="card-header">Add Subscriptions</div>
                    <div class="card-body">
                        <form action="javascript:void(0)" method="post" id="addSubscriptionFrm">
                            {{ csrf_field() }}
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Subscription Name</label>
                                        <input type="text" class="form-control" name="name">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Renewal Cycle</label>
                                        <select class="selectpicker select-custom form-control" title="&nbsp;" data-size="4" name="renewal_cycle">
                                            <option value="30">Monthly</option>
                                            <option value="90">Quarterly</option>
                                            <option value="180">Half Yearly</option>
                                            <option value="360">Yearly</option>

                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Amount</label>
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">$</span>
                                            </div>
                                            <input type="text" class="form-control" maxlength="10" aria-label="Username" aria-describedby="basic-addon1" name="amount">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Plan Space (In GB)</label>
                                        <input type="text" class="form-control" maxlength="10" name="plan_space">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group ">
                                <label>Description </label>
                                <div class="discription position-relative">
                                    <input type="text" class="form-control required"  name="description[]">
                                    <a href="javascript:void(0)" onclick="addMoreDescription()" class="btn btn-dark">
                                        <i class="flaticon-cancel-music add_icon"></i>
                                    </a>
                                </div>
                                 <span class="error-tooltip"></span>
                                <div id="add-more-input" class="mt-3"></div>
                            </div>

                            <div class="form-group action  text-right mb-0">
                                <a href="{{ url('admin/subscriptions') }}" id="sub-cancel" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                    Cancel
                                </a>
                                <button type="submit" class="btn btn-dark rounded-0" id="submit-subscription" onclick="submitSubscription()" >Save</button>
                            </div>
                        </form>
                        {!! JsValidator::formRequest('App\Admin\Http\Requests\SubscriptionValidation','#addSubscriptionFrm') !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function submitSubscription() {
        var flag = 0;
        $(".required").each(function () {
            if ($(this).val() == "") {
                $(this).parent().next('span').css({"margin-top": "5px"}).html('The description  field is required');
                flag++;
            }
        });
        $('.required').keyup(function () {
            $(this).parent().next('span').css('color', 'green').html("");
        });
        if ($("#addSubscriptionFrm").valid() && flag == 0) {
            showButtonLoader('submit-subscription', 'Save', 'disable');
            document.getElementById('sub-cancel').style.pointerEvents = 'none';
            var url = "{{ url('admin/subscriptions/submit') }}";
            var formData = $("#addSubscriptionFrm").serializeArray();
            formData.push({name: '_token', value: '{{ csrf_token() }}'});
            $.ajax({
                url: url,
                data: formData,
                type: 'POST',
                success: function (data) {
                    if (data.success) {
                        message('success', data.message);
                        setTimeout(function () {
                            window.location.href = "{{ url('admin/subscriptions') }}"
                        }, 1000);
                    } else {
                        message('error', data.message);
                    }
                },
                error: function (err) {
                    message('error', err);
                },
                complete: function () {
                    showButtonLoader('submit-subscription', 'Save', 'enable');
                    document.getElementById('sub-cancel').style.pointerEvents = 'auto';
                }
            });
        }
    }

    function addMoreDescription() {
        $('#add-more-input').append('<div class="form-group mb-3"><div class="discription position-relative"><input type="text" class="form-control required" name="description[]"><a href="javascript:void(0)" onclick="removeInput($(this))" class="btn btn-success"> <i class="flaticon-cancel-music"></i> </a></div><span class="error-tooltip"></span></div>');
    }

    function removeInput(obj) {
        obj.parent().parent().remove();
    }

</script>
@endsection