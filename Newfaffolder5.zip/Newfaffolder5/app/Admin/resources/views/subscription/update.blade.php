 @php $pageTitle = 'Subscriptions | Admin'; @endphp
@php $activePage = 'subscriptions'; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.header')
@include('admin::layouts.include.side-menu')

<div class="main-content adduser_page subscriptionsadd_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Subscriptions Update</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{url('admin/subscriptions')}}">Subscriptions</a></li>
                        <li class="breadcrumb-item">Subscriptions Update</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <div class="add_form mx-auto">
                <div class="card">
                    <div class="card-header">Update Subscriptions</div>
                    <div class="card-body">
                        <form action="{{ url('admin/subscriptions/update') }}" method="post" id="updateSubscriptionFrm">
                            {{ csrf_field() }}
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Subscription Name</label>
                                        <input type="text" class="form-control" name="name" value="{{ $subscription->title }}">
                                    </div>
                                </div>
                                <input type="hidden" class="form-control" name="id" value="{{ $subscription->id }}">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Renewal Cycle</label>
                                        <select class="selectpicker select-custom form-control" title="&nbsp;" data-size="4" name="renewal_cycle">
                                            <option {{ ($subscription->renewal_cycle == '30') ? 'selected' : '' }}  value="30" >Monthly</option>
                                            <option {{ ($subscription->renewal_cycle == '90') ? 'selected' : '' }}  value="90"> Quarterly</option>
                                            <option {{ ($subscription->renewal_cycle == '180') ? 'selected' : '' }}  value="180"> Half Yearly</option>
                                            <option {{ ($subscription->renewal_cycle == '360') ? 'selected' : '' }}  value="360"> Yearly</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Amount</label>
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">$</span>
                                            </div>
                                            <input type="text" class="form-control" maxlength="10" aria-label="Username" aria-describedby="basic-addon1" name="amount" value="{{ $subscription->amount }}">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Plan Space (In GB)</label>
                                        <input type="text" class="form-control" maxlength="10" name="plan_space" value="{{ $subscription->plan_space }}">
                                    </div>
                                </div>
                            </div>
                            <!-- <a href="javascript:void(0)" onclick="addMoreDescription()" class="btn btn-primary btn-xs">Add more</a>
                            @if($subscription->subDescription)
                            @foreach($subscription->subDescription as $key => $description)
                            <div class="form-group">
                                <label>Description </label>
                                <input type="text" class="form-control required" value="{{ $description->description }}" name="description[]">
                                @if($key != 0)
                                <a href="javascript:void(0)" onclick="removeInput($(this))">remove</a>
                                @endif        
                                <a href="javascript:void(0)"></a>
                                <span></span>
                            </div>
                            @endforeach
                            @endif  -->        

                            <div class="form-group ">
                                <label>Description </label>
                                @if($subscription->subDescription)
                                @foreach($subscription->subDescription as $key => $description)
                                <div class="form-group mb-3">
                                    <div class="discription position-relative">
                                        <input type="text" class="form-control required"  name="description[]" value="{{ $description->description }}">
                                        @if($key != 0)
                                        <a href="javascript:void(0)" onclick="removeInput($(this))" class="btn btn-success"> <i class="flaticon-cancel-music"></i> </a>
                                        @else
                                        <a href="javascript:void(0)" onclick="addMoreDescription()" class="btn btn-dark">
                                            <i class="flaticon-cancel-music add_icon"></i>
                                        </a>
                                        @endif     
                                    </div>
                                    <span class="error-tooltip"></span>
                                </div>
                                @endforeach
                                @endif 
                                <div id="add-more-input" class="mt-3"></div>
                            </div>
                            <div class="form-group action  text-right mb-0">
                                <a href="{{ url('admin/subscriptions') }}" id="sub-cancel" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                    Cancel
                                </a>
                                <button type="submit" class="btn btn-dark rounded-0" id="update-subscription" onclick="updateSubscription()" >Save</button>
                            </div>
                        </form>
                        {!! JsValidator::formRequest('App\Admin\Http\Requests\SubscriptionValidation','#updateSubscriptionFrm') !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function updateSubscription() {
//      check valid description
        var flag = 0;
        $(".required").each(function () {
            if ($(this).val() == "") {
                var text = $(this).closest(".form-group").find("label").text();
                $(this).parent().next('span').css({"margin-top": "5px"}).html('The description field is required');
                flag++;
            }
        });
        $('.required').keyup(function () {
            $(this).parent().next('span').css('color', 'green').html("");
        });
//      submit form
        if ($("#updateSubscriptionFrm").valid() && flag == 0) {
            showButtonLoader('update-subscription', 'Save', 'disable');
            document.getElementById('sub-cancel').style.pointerEvents = 'none';
            var url = "{{ url('admin/subscriptions/update') }}";
            var formData = $("#updateSubscriptionFrm").serializeArray();
            formData.push({name: '_token', value: '{{ csrf_token() }}'});
            $.ajax({
                url: url,
                data: formData,
                type: 'POST',
                success: function (data) {
                    if (data.success) {
                        message('success', data.message);
                        setTimeout(function () {
                            window.location.href = "{{ url('admin/subscriptions') }}"
                        }, 1000);
                    } else {
                        message('error', data.message);
                    }
                },
                error: function (err) {
                    message('error', err);
                },
                complete: function () {
                    showButtonLoader('update-subscription', 'Save', 'enable');
                    document.getElementById('sub-cancel').style.pointerEvents = 'auto';
                }
            });
        }
    }

    function addMoreDescription() {
        $('#add-more-input').append('<div class="form-group mb-3"><div class="discription position-relative"><input type="text" class="form-control required" name="description[]"> <a href="javascript:void(0)" onclick="removeInput($(this))" class="btn btn-success"> <i class="flaticon-cancel-music"></i> </a></div><span class="error-tooltip"></span></div>');
    }

    function removeInput(obj) {
        obj.parent().parent().remove();
    }

</script>
@endsection