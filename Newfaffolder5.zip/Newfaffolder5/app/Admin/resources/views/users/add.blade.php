@php $pageTitle = 'Add | Admin'; @endphp
@php $activePage = 'users'; @endphp

@extends('admin::layouts.app')

@section('content')
@include('admin::layouts.include.side-menu')

<div class="main-content adduser_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">User Add</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/users') }}">Manage Users</a></li>
                        <li class="breadcrumb-item">User Add</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <div class="add_details mx-auto add_form">
                <div class="card">
                    <div class="card-header">  Add User Details	</div>
                    <div class="card-body">
                        <ul class="list-inline users_options">
                            <li class="list-inline-item">
                                <div class="radio">
                                    <input id="radio-1" name="radio" type="radio" checked onchange="checked_radio('player_field');">
                                    <label for="radio-1"><span class="radio-label"></span> Player</label>
                                </div>
                            </li>
                            <li class="list-inline-item">
                                <div class="radio">
                                    <input id="radio-2" name="radio" type="radio" onchange="checked_radio('staff_field');">
                                    <label for="radio-2"><span class="radio-label"></span> Staff & Personal</label>
                                </div>
                            </li>
                            <li class="list-inline-item">
                                <div class="radio">
                                    <input id="radio-3" name="radio" type="radio" onchange="checked_radio('team_field');">
                                    <label for="radio-3"><span class="radio-label"></span> Team & Organization</label>
                                </div>
                            </li>
                        </ul>
                        <div class="field_content" >
                            <div class="field_box " id="player_field">

                                <form id="player-save" class="user-save" method="post" action="{{ url('admin/users/player/save') }}">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="role" id="role" value="player"/>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>First Name</label>
                                                <input type="text" name="first_name" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Last Name</label>
                                                <input type="text" name="last_name" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control">
                                    </div>
                                    <div class="row">
                                        
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Country</label>

                                                <select name="country_id" id="country1" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select Country">


                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>State</label>

                                                <select name="state_id" id="state1" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select State">


                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input type="text" name="city"  class="form-control">
                                            </div>
                                        </div>
                                         <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Zip Code</label>
                                                <input type="text" name="zip_code" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                       
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <input type="text" name="address_line_1" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group mobile_no">
                                                <label>Mobile Number</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                         <select name="country_code" id="country_cod" class="selectpicker select-custom form-control" data-size="3">
                                                               <option value=''>+1</option>
                                                         </select>
                                                    </div>
                                                    <input type="text" name="phone_number" class="form-control" aria-label="Text input with dropdown button">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Select Payment</label>
                                                <select name="signup_type" id="signup_type" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select Payment">
                                                    <option value="">Select Payment</option>
                                                    <option value="ach">Join with ACH Debit</option>
                                                    <option value="card">Join with card</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Select Plan</label>
                                                @php  $all_plans=getAllActivePlans(); @endphp
                                                <select name="plan_id" id="plan_id" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select Plan">
                                                    <option value="">Select Plan</option>
                                                @if(!empty($all_plans) && count($all_plans)>0)
                                                    @foreach($all_plans as $plans)   
                                                    <option value="{{$plans['id']}}">{{$plans['title']}} (${{$plans['amount']}} , {{getPlanMonth($plans['renewal_cycle'])}})</option>
                                                    @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group action text-right mb-0">
                                        <a href="{{ url('admin/users') }}" id="user-cancel" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                            Cancel
                                        </a>
                                        <button type="submit" class="btn btn-dark rounded-0 ripple-effect" id="user-save">Save
                                        </button>
                                    </div>
                                </form>
                                {!! JsValidator::formRequest('App\Admin\Http\Requests\PlayerAddRequest','#player-save') !!}
                            </div>
                            <div class="field_box collapse" id="staff_field">
                                <form id="coach-save" class="user-save" method="post" action="{{ url('admin/users/coach/save') }}">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="role" id="role" value="coach"/>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>First Name</label>
                                                <input type="text" name="first_name" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Last Name</label>
                                                <input type="text" name="last_name" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control">
                                    </div>
                                    <div class="row">
                                        
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Country</label>
                                                <select name="country_id" id="country2" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select Country">

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>State</label>
                                                <select name="state_id" id="state2" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select State">

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input type="text" name="city"  class="form-control">
                                            </div>
                                        </div>
                                         <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Zip Code</label>
                                                <input type="text" name="zip_code" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <input type="text" name="address_line_1" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group mobile_no">
                                                <label>Mobile Number</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                       <div class="input-group-prepend">
                                                         <select name="country_code" id="country_cod_2" class="selectpicker select-custom form-control" data-size="3">
                                                               <option value=''>+1</option>
                                                         </select>
                                                       </div>
                                                    </div>
                                                    <input type="text" name="phone_number" class="form-control" aria-label="Text input with dropdown button">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Select Payment</label>
                                                <select name="signup_type" id="signup_type" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select Payment">
                                                    <option value="">Select Payment</option>
                                                    <option value="ach">Join with ACH Debit</option>
                                                    <option value="card">Join with card</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Select Plan</label>
                                                @php  $all_plans=getAllActivePlans(); @endphp
                                                <select name="plan_id" id="plan_id" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select Plan">
                                                    <option value="">Select Plan</option>
                                                @if(!empty($all_plans) && count($all_plans)>0)
                                                    @foreach($all_plans as $plans)   
                                                    <option value="{{$plans['id']}}">{{$plans['title']}} (${{$plans['amount']}} , {{getPlanMonth($plans['renewal_cycle'])}})</option>
                                                    @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group action text-right mb-0">
                                        <a href="{{ url('admin/users') }}" id="user-cancelc" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                            Cancel
                                        </a>
                                        <button type="submit" class="btn btn-dark rounded-0 ripple-effect" id="user-savec">Save
                                        </button>
                                    </div>
                                </form>
                                {!! JsValidator::formRequest('App\Admin\Http\Requests\CoachAddRequest','#coach-save') !!}
                            </div>
                            <div class="field_box collapse" id="team_field">
                                <form id="team-save" class="user-save" method="post" action="{{ url('admin/users/team/save') }}">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="role" id="role" value="team"/>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Institution type</label>
                                                <input type="text" name="institute_type" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Team & organization title</label>
                                                <input type="text" name="full_name" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control">
                                    </div>
                                    <div class="row">
                                     
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Country</label>
                                                <select name="country_id" id="country3" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select Country">

                                                </select>
                                            </div>
                                        </div>
                                         <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>State</label>
                                                <select name="state_id" id="state3" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select State">

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input type="text" name="city"  class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Zip Code</label>
                                                <input type="text" name="zip_code" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <input type="text" name="address_line_1" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                         <div class="form-group mobile_no">
                                             <label>Mobile Number</label>
                                             <div class="input-group">
                                                 <div class="input-group-prepend">
                                                     <div class="input-group-prepend">
                                                      <select name="country_code" id="country_cod_3" class="selectpicker select-custom form-control" data-size="3">
                                                            <option value=''>+1</option>
                                                      </select>
                                                     </div>
                                                 </div>
                                                 <input type="text" name="phone_number" class="form-control" aria-label="Text input with dropdown button">
                                             </div>
                                         </div>
                                     </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Select Payment</label>
                                                <select name="signup_type" id="signup_type" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select Payment">
                                                    <option value="">Select Payment</option>
                                                    <option value="ach">Join with ACH Debit</option>
                                                    <option value="card">Join with card</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Select Plan</label>
                                                @php  $all_plans=getAllActivePlans(); @endphp
                                                <select name="plan_id" id="plan_id" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="Select Plan">
                                                    <option value="">Select Plan</option>
                                                @if(!empty($all_plans) && count($all_plans)>0)
                                                    @foreach($all_plans as $plans)   
                                                    <option value="{{$plans['id']}}">{{$plans['title']}} (${{$plans['amount']}} , {{getPlanMonth($plans['renewal_cycle'])}})</option>
                                                    @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group action text-right mb-0">
                                        <a href="{{ url('admin/users') }}" id="user-cancelt" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                            Cancel
                                        </a>
                                        <button type="submit" class="btn btn-dark rounded-0 ripple-effect" id="user-savet">Save
                                        </button>
                                    </div>
                                </form>
                                {!! JsValidator::formRequest('App\Admin\Http\Requests\TeamAddRequest','#team-save') !!}
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function checked_radio(value) {
        $(".field_box").hide('slow');
        $("#" + value).show('slow');
        $("#" + value).find('form').trigger('reset');
        $("#" + value).find('.error-tooltip').hide();
        $("#" + value).find('.selectpicker').selectpicker('refresh');
    }
    function getSavebtn() {
        $(".btn_loader").css('display', 'inline-block');
        setTimeout(function () {
            $(".btn_loader").hide();
        }, 1000);
    }

    // get all country
    $(document).ready(function () {
        $.post("{{ url('get-all-country') }}", {_token: "{{ csrf_token() }}", type: ""}, function (data) {
            $('#country1').html(data);
            $('#country1').selectpicker('refresh');
            $('#country2').html(data);
            $('#country2').selectpicker('refresh');
            $('#country3').html(data);
            $('#country3').selectpicker('refresh');
        });
    });

    // get state by country id
    $(document).on('change', '#country1', function () {
        $.post("{{ url('get-state-by-country-id') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: ""}, function (data) {
            $('#state1').html(data);
            $('#state1').selectpicker('refresh');
        });
    });

    // get state by country id
    $(document).on('change', '#country2', function () {
        $.post("{{ url('get-state-by-country-id') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: ""}, function (data) {
            $('#state2').html(data);
            $('#state2').selectpicker('refresh');
        });
    });

    // get state by country id
    $(document).on('change', '#country3', function () {
        $.post("{{ url('get-state-by-country-id') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: ""}, function (data) {
            $('#state3').html(data);
            $('#state3').selectpicker('refresh');
        });
    });

    // function for save event.
    $(document).on('submit', '.user-save', function (e) {
        e.preventDefault();
        var role=$(this).parent().find("input[name=role]").val();
        if(role == 'player') { 
        var id = "user-save";
        var cancel="user-cancel";
        } else if(role == 'coach'){
        var id = "user-savec";
        var cancel="user-cancelc";
        } else { 
        var id = "user-savet";
        var cancel="user-cancelt";
        }
        showButtonLoader(id, 'Save', 'disable');
        document.getElementById(cancel).style.pointerEvents = 'none';
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: $(this).attr('action'),
            data: formData,
            processData: false,
            contentType: false,
            type: 'POST',
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    message('success', data.message);
                    setTimeout(function () {
                    window.location.href = "{{ url('admin/users') }}";
                    }, 1000);
                } else {
                    message('error', data.message);
                }
            },
            error: function (err) {
                message('error', err);
            },
            complete: function () {

                showButtonLoader('user-save', 'Save', 'enable');
        document.getElementById(cancel).style.pointerEvents = 'auto';

            }
        });
    });
    
 $(document).on('change', '#country1', function () {
    $.post("{{ url('get-country-code-byid') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val()}, function (data) {
        $('#country_cod').html(data);
        $('#country_cod').selectpicker('refresh');
    });
});
 $(document).on('change', '#country2', function () {
    $.post("{{ url('get-country-code-byid') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val()}, function (data) {
        $('#country_cod_2').html(data);
        $('#country_cod_2').selectpicker('refresh');
    });
});
 $(document).on('change', '#country3', function () {
    $.post("{{ url('get-country-code-byid') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val()}, function (data) {
        $('#country_cod_3').html(data);
        $('#country_cod_3').selectpicker('refresh');
    });
});
</script>

@endsection