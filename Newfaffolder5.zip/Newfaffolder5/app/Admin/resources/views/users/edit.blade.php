@php $pageTitle = 'Edit | Admin'; @endphp
@php $activePage = 'users'; @endphp

@extends('admin::layouts.app')

@section('content')
@include('admin::layouts.include.side-menu')

<div class="main-content adduser_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">User Edit</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/users') }}">Manage Users</a></li>
                        <li class="breadcrumb-item">User Edit</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <div class="add_details mx-auto add_form">
                <div class="card">
                    <div class="card-header"> Edit {{ ucfirst($user->role) }} Details</div>
                    <div class="card-body">
                        <div class="field_content" >
                            <div class="field_box " id="player_field">
                                <form id="user-save" method="post" action="{{ url('admin/users/update') }}">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="id" value="{{ $user->id }}"/>
                                    <input type="hidden" name="role" value="{{ $user->role }}"/>
                                    @if($user->role == 'team')
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Institution Type</label>
                                                <input type="text" name="institute_type" value="{{ $user->institute_type }}" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Team & Organization Title</label>
                                                <input type="text" name="full_name" value="{{ $user->full_name }}" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    @else
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>First Name</label>
                                                <input type="text" name="first_name" value="{{ $user->first_name }}" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Last Name</label>
                                                <input type="text" name="last_name" value="{{ $user->last_name }}" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" value="{{ $user->email }}" class="form-control" readonly="">
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group mobile_no">
                                                <label>Mobile Number</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <select name="country_code" id="country_cod_2" class="selectpicker select-custom form-control" data-size="3">
                                                            <option value=''>+1</option>
                                                        </select>
                                                    </div>
                                                    <input type="text" name="phone_number" value="{{ $user->phone_number }}" class="form-control" aria-label="Text input with dropdown button">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Country</label>
                                                <select name="country_id" id="country" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="&nbsp;">

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>State</label>
                                                <select name="state_id" id="state" class="selectpicker select-custom form-control" onchange="$(this).valid();" data-size="4" title="&nbsp;">

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input type="text" name="city" value="{{ $user->city }}" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Zip Code</label>
                                                <input type="text" name="zip_code" value="{{ $user->zip_code }}" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <input type="text" name="address_line_1" value="{{ $user->address_line_1 }}" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group action text-right mb-0">
                                        <a href="{{ url('admin/users') }}" id="userCancel" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                            Cancel
                                        </a>
                                        <button type="submit" class="btn btn-dark rounded-0 ripple-effect" id="userSave">Save
                                        </button>
                                    </div>
                                </form>
                                {!! JsValidator::formRequest('App\Admin\Http\Requests\UserUpdateRequest','#user-save') !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var countryId = "{{ $user->country_id }}";
    var stateId = "{{ $user->state_id }}";

    function checked_radio(value) {
        $(".field_box").hide('slow');
        $("#" + value).show('slow');
    }
    function getSavebtn() {
        $(".btn_loader").css('display', 'inline-block');
        setTimeout(function () {
            $(".btn_loader").hide();
        }, 1000);
    }

    // get user country
    $(document).ready(function () {

        $.post("{{ url('get-country-code-byid') }}", {_token: "{{ csrf_token() }}", country_id: countryId}, function (data) {
            console.log(data);
            $('#country_cod_2').html(data);
            $('#country_cod_2').selectpicker('refresh');
        });

        $.post("{{ url('get-all-country') }}", {_token: "{{ csrf_token() }}", type: 'user-profile-step-one'}, function (data) {
            $('#country').html(data);
            $('#country').selectpicker('refresh');
            $('#country').selectpicker('val', countryId);
            $('#country').selectpicker('render');
        });
    });

    // get state by country id
    $(document).on('change', '#country', function () {
        $.post("{{ url('get-state-by-country-id') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: 'user-profile-step-one'}, function (data) {
            $('#state').html(data);
            $('#state').selectpicker('refresh');
            $('#state').selectpicker('val', stateId);
            $('#state').selectpicker('render');
        });
    });

    // function for save event.
    $(document).on('submit', '#user-save', function (e) {
        e.preventDefault();
        showButtonLoader('userSave', 'Save', 'disable');
        document.getElementById('userCancel').style.pointerEvents = 'none';
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: $(this).attr('action'),
            data: formData,
            processData: false,
            contentType: false,
            type: 'POST',
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    message('success', data.message);
                    setTimeout(function () {
                        window.location.href = "{{ url('admin/users') }}";
                    }, 1000);
                } else {
                    message('error', data.message);
                }
            },
            error: function (err) {
                message('error', err);
            },
            complete: function () {
                showButtonLoader('userSave', 'Save', 'enable');
                document.getElementById('userCancel').style.pointerEvents = 'auto';
            }
        });
    });

    $(document).on('change', '#country', function () {
        $.post("{{ url('get-country-code-byid') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val()}, function (data) {
            console.log(data);
            $('#country_cod_2').html(data);
            $('#country_cod_2').selectpicker('refresh');
        });
    });
</script>

@endsection