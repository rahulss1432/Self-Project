<div class="view_body">
    <div class="row">
        <div class="col-sm-6">
            <div class="add_form">
                <div class="card">
                    <div class="card-header">Add CMS</div>
                    <div class="card-body">
                        <form action="{{ url('admin/cms/add-testimonial') }}" method="POST" id="addTestimonialFrm" enctype="multipart/form-data">
                            <div class="field_content">
                                <div class="field_box">
                                    <div class="form-group">
                                        <label class="d-block">User Image</label>
                                        <div class="upload-img-wrap">
                                            <label for="userImg" class="upload-img">
                                                <input class="do-not-ignore" hidden="" type="file"  id="userImg" name="image" onchange="setImage(this)">
                                                <img id="testimonial-pic" src="{{url('public/images/default-user.png')}}" alt="user">
                                            </label>
                                            <span id="image-validation-msg" class="error-msg "></span>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="d-block">User Name</label>
                                        <input type="text" name="name" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label class="d-block">Content</label>
                                        <textarea name="content" rows="4" class="form-control"></textarea>
                                    </div>
                                    <div class="form-group action mr-2  text-right mb-0">
                                        <a href="{{ url('admin/cms') }}" id="cms-cancel" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                            Cancel
                                        </a>
                                        <button type="submit" class="btn btn-dark rounded-0" id="testimonialBtn" onclick="submitTestimonial()">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        {!! JsValidator::formRequest('App\Admin\Http\Requests\TestimonialValidation','#addTestimonialFrm') !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $('.selectpicker').selectpicker();
    function submitTestimonial() {
        if ($("#addTestimonialFrm").valid()) {
            showButtonLoader('testimonialBtn', 'Save', 'disable');
            document.getElementById('cms-cancel').style.pointerEvents = 'none';
            var url = "{{ url('admin/cms/add-testimonial') }}";
            var formData = new FormData($('#addTestimonialFrm')[0]);
            formData.append('_token', '{{ csrf_token() }}');
            $.ajax({
                url: url,
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function (data) {
                    if (data.success) {
                        getUserTestimonials();
                        message('success', data.message);
                    } else {
                        if (data.image_validation) {
                            $('#image-validation-msg').css({"color": "#a94442", "display": "inline-block", "margin-top": "5px"}).html(data.message);
                            return false;
                        }
                        message('error', data.message);
                    }
                },
                error: function (err) {
                    message('error', err);
                },
                complete: function () {
                    showButtonLoader('testimonialBtn', 'Save', 'enable');
                    document.getElementById('cms-cancel').style.pointerEvents = 'auto';
                }
            });
        }
    }

    function setImage(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#testimonial-pic').attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>