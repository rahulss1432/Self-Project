<div class="content bg-white box-shadow">
    <!--  -->
    <div class="table-responsive common_table">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Event ID</th>
                    <th>Event name</th>
                    <th>Location</th>
                    <th>Opponent 1</th>
                    <th>Opponent 2</th>
                    <th>Start Date & Time</th>
                    <th>End Date & Time</th>
                    <th>Last Updated By</th>
                    <th>Last Updated On</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($events as $event)
                <tr>
                    <td>{{ $event->reference_id }}</td>
                    <td>{{ ucfirst($event->event_name) }}</td>
                    <td>{{ $event->city.' '. !empty($event->state_id) ? ucfirst($event->state->state_name) : '' .' '. !empty($event->country_id) ? ucfirst($event->country->name) : '' }}</td>
                    @if(intval($event->team1))
                    <td>{{ !empty($event->team1Data->full_name) ? $event->team1Data->full_name : '-' }}</td>                     
                    @else
                    <td>{{ !empty($event->team1) ? ucfirst($event->team1) : '-' }}</td>                     
                    @endif
                    @if(intval($event->team2))
                    <td>{{ !empty($event->team2Data->full_name) ? $event->team2Data->full_name : '-' }}</td>
                    @else
                    <td>{{ !empty($event->team2) ? ucfirst($event->team2) : '-' }}</td>                     
                    @endif
                    <td> {{dateTimeFormat($event->start_date.' '.$event->start_time)}}</td>
                    <td> {{dateTimeFormat($event->end_date.' '.$event->end_time)}}</td>
                    <td>{{ ucfirst($event->user->full_name)}}</td>
                    <td>{{dateTimeFormat($event->updated_at)}}</td>
                    <td>
                        <div class="switch">
                            <label> 
                                @if( $event->status == 'active' )
                                <input type="checkbox" name="activeInactive" checked onchange="getValue(this,'{{$event->id}}')">
                                @else
                                <input type="checkbox" name="activeInactive" onchange="getValue(this,'{{$event->id}}')">
                                @endif
                                <span class="lever"></span>
                            </label>
                        </div>
                    </td>
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="{{ url('admin/events/view/'.base64_encode($event->id)) }}">View</a>
                                    <a class="dropdown-item" href="{{ url('admin/events/edit/'.base64_encode($event->id)) }}">Edit</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                <tr><td colspan="11"><div class="alert alert-danger text-center">No Record Found.</div></td></tr>
                </tr>    
                @endforelse
            </tbody>
        </table>
    </div>
</div>
{{$events->links()}}  <!--Pagination render -->
<!-- Pagination on page click-->
<script>
    $(".pagination li a").on('click', function(e) {
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    getListing(pageLink);
    });
</script>