<div class="content bg-white box-shadow">
    <div class="table-responsive common_table">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>User Name</th>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Last Updated On</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($userBenefits as $benefits)
                <tr>
                    <td>{{ ucfirst($benefits->first_name).' '.ucfirst($benefits->last_name) }}</td>
                    <td>{{ ucfirst($benefits->title) }}</td>
                    @if($benefits->created_by == 1)
                    <td><i class="{{$benefits->image}} icons"></i></td>
                    @else
                    <td><i class="{{$benefits->image}} icons"></i></td>
                    @endif
                    <td>{{ dateTimeFormat($benefits->updated_at) }}</td>
                    <td>
                        <div class="switch">
                            <label>
                                @if($benefits->status == 'approved' && $benefits->created_by != 1)
                                <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this,'{{$benefits->id}}')">
                                @elseif($benefits->created_by == 1)
                                <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this, 'message')">
                                @else 
                                <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'{{$benefits->id}}')">
                                @endif
                                <span class="lever"></span>
                            </label>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="10"><div class="alert alert-danger text-center">No Record Found</div></td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
{{ $userBenefits->links() }}  <!--Pagination render -->
<!-- Pagination on page click-->
<script>
    $(".pagination li a").on('click', function (e) {
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    getListing(pageLink);
    });
</script>