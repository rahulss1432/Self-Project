<div class="view_body measurables_view">
    <div class="box_wrapper ">
        <div class="form-group info_row">
            <div class="row">
                <div class="col-sm-3 col-lg-2 col-4"> <label>Trans. ID:</label></div>
                <div class="col-sm-6 col-8"> <span>{{$transaction->transaction_id}}</span></div>
            </div>
        </div>
        <div class="form-group info_row">
            <div class="row">
                <div class="col-sm-3 col-lg-2 col-4"> <label>Payment mode:</label>	</div>
                <div class="col-sm-6 col-8"> <span>{{($transaction->transactionUser['signup_type'])?ucfirst($transaction->transactionUser['signup_type']):'-'}}</span></div>
            </div>
        </div>
        <div class="form-group info_row">
            <div class="row">
                <div class="col-sm-3 col-lg-2 col-4"> <label>Plan:</label>	</div>
                <div class="col-sm-6 col-8"> <span>{{getSubscriptionDetails($transaction->subscription_id,'title')}} </span></div>
            </div>
        </div>

        <div class="form-group info_row">
            <div class="row">
                <div class="col-sm-3 col-lg-2 col-4"> <label>Purchased on:</label>	</div>
                <div class="col-sm-6 col-8"> <span>{{sameDate($transaction->start_date)}}</span></div>
            </div>
        </div>
        <div class="form-group info_row">
            <div class="row">
                <div class="col-sm-3 col-lg-2 col-4"> <label>Expires on:</label>	</div>
                <div class="col-sm-6 col-8"> <span>{{sameDate($transaction->end_date)}}</span></div>
            </div>
        </div>
        <div class="form-group info_row ">
            <div class="row">
                <div class="col-sm-3 col-lg-2 col-4"> <label>Amount:</label>	</div>
                <div class="col-sm-6 col-8"> <span>{{($transaction->amount != '')?'$ '.$transaction->amount:'-'}}</span></div>
            </div>
        </div>
        <div class="form-group mb-0">
            <a href="javascript:void(0);" onclick="sendInvoiceData('{{$transaction->id}}')" id="sendInvoice" class="btn btn-dark rounded-0 ripple-effect">SEND INVOICE</a>
        </div>
    </div>
</div>
<script>
    function sendInvoiceData(transaction_id) {
    showButtonLoader('sendInvoice', 'SEND INVOICE', 'disable');
    document.getElementById('sendInvoice').style.pointerEvents = 'none';
    var url = "{{ url('admin/users/send-invoice-mail') }}/" + transaction_id;
    $.ajax({type: "GET", url: url,
        success: function (response) {
            if (response.success) {
                message('success', response.message);
                setTimeout(function () {
                  window.location.href = "{{ url('admin/users') }}";
                }, 1000);
            } else {
                message('error', response.message);
            }
        },
        complete: function () {
           showButtonLoader('sendInvoice', 'SEND INVOICE', 'enable');
           document.getElementById('sendInvoice').style.pointerEvents = 'auto';
        }
    });
    }
</script>
