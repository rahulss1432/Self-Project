<div class="view_body key_stats">
	<div class="row">

		<!---- CURRENT SEASION ---->

		<div class="col-xl-6 col-lg-12">
			<div class="box_wrapper current_season">
				<div class="offence">
					<div class="info_row mb-4">
						<h2 class="heading_22 ">Current Season</h2>
					<label>{{ !empty($user['userCurrentSeason']['from_year']) ? $user['userCurrentSeason']['from_year'] : '-' }} - {{ !empty($user['userCurrentSeason']['to_year']) ? $user['userCurrentSeason']['to_year'] : '-' }}</label>
					</div>
					<h2 class="heading_22 mb-3">Offense</h2>
					<div class="row">
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Passing Yards:</label>	
								<span>{{ !empty($user['userCurrentSeason']['total_passing']) ? $user['userCurrentSeason']['total_passing'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Passing Yards (Game):</label>	
								<span>{{ !empty($user['userCurrentSeason']['passing_game']) ? $user['userCurrentSeason']['passing_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Passing Yards (Season):</label>	
								<span>{{ !empty($user['userCurrentSeason']['passing_season']) ? $user['userCurrentSeason']['passing_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Completions:</label>	
								<span>{{ !empty($user['userCurrentSeason']['completion']) ? $user['userCurrentSeason']['completion'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Completions(%):</label>	
								<span>{{ !empty($user['userCurrentSeason']['completion_percent']) ? $user['userCurrentSeason']['completion_percent'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">QB Passer Rating:</label>	
								<span>{{ !empty($user['userCurrentSeason']['passer_rating']) ? $user['userCurrentSeason']['passer_rating'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Rushing Yards:</label>	
								<span>{{ !empty($user['userCurrentSeason']['total_rushing'])  ? $user['userCurrentSeason']['total_rushing'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Rushing Yards (Game):</label>	
								<span>{{ !empty($user['userCurrentSeason']['rushing_game']) ? $user['userCurrentSeason']['rushing_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Rushing Yards (Season):</label>	
								<span>{{ !empty($user['userCurrentSeason']['rushing_season']) ? $user['userCurrentSeason']['rushing_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Receiving Yards:</label>	
								<span>{{!empty($user['userCurrentSeason']['total_receiving']) ?  $user['userCurrentSeason']['total_receiving']: '-'  }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Receiving Yards (Game):</label>	
								<span>{{ !empty($user['userCurrentSeason']['receiving_game']) ? $user['userCurrentSeason']['receiving_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Receiving Yards (Season):</label>	
								<span>{{ !empty($user['userCurrentSeason']['receiving_season']) ? $user['userCurrentSeason']['receiving_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Return Yards:</label>	
								<span>{{ !empty($user['userCurrentSeason']['total_return']) ? $user['userCurrentSeason']['total_return'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Return Yards (Game):</label>	
								<span>{{ !empty($user['userCurrentSeason']['return_game']) ? $user['userCurrentSeason']['return_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Return Yards (Season):</label>	
								<span>{{ !empty($user['userCurrentSeason']['return_season']) ? $user['userCurrentSeason']['return_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total  All Purpose Yards:</label>	
								<span>{{ !empty($user['userCurrentSeason']['total_all_purpose']) ? $user['userCurrentSeason']['total_all_purpose'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average  All Purpose Yards (Game):</label>	
								<span>{{ !empty($user['userCurrentSeason']['purpose_game']) ? $user['userCurrentSeason']['purpose_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average  All Purpose Yards (Season):</label>	
								<span>{{ !empty($user['userCurrentSeason']['purpose_season']) ? $user['userCurrentSeason']['purpose_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Touchdowns:</label>	
								<span>{{ !empty($user['userCurrentSeason']['tuchdowns']) ? $user['userCurrentSeason']['tuchdowns']  :'-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Games Played:</label>	
								<span>{{ !empty($user['userCurrentSeason']['games_played']) ? $user['userCurrentSeason']['games_played'] : '-' }}</span>
							</div>
						</div>
					</div>
				</div>
				<div class="defence">
					<h2 class="heading_22 mb-3">Defense</h2>
					<div class="row">
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Tackles:</label>	
								<span>{{ !empty($user['userCurrentSeason']['tackles']) ? $user['userCurrentSeason']['tackles'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Tackles (Game):</label>	
								<span>{{ !empty($user['userCurrentSeason']['tackles_game']) ? $user['userCurrentSeason']['tackles_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Tackles (Season):</label>	
								<span>{{!empty( $user['userCurrentSeason']['tackles_season']) ?  $user['userCurrentSeason']['tackles_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Tackles For Loss:</label>	
								<span>{{ !empty($user['userCurrentSeason']['total_tackloss']) ? $user['userCurrentSeason']['total_tackloss'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Tackles For Loss (Game):</label>	
								<span>{{ !empty($user['userCurrentSeason']['tackloss_game']) ? $user['userCurrentSeason']['tackloss_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Tackles For Loss (Season):</label>	
								<span>{{ !empty($user['userCurrentSeason']['tackloss_season']) ? $user['userCurrentSeason']['tackloss_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Sacks:</label>	
								<span>{{ !empty($user['userCurrentSeason']['total_sacks']) ? $user['userCurrentSeason']['total_sacks'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Sacks (Game):</label>	
								<span>{{ !empty($user['userCurrentSeason']['sacks_game']) ? $user['userCurrentSeason']['sacks_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Sacks (Season):</label>	
								<span>{{ !empty($user['userCurrentSeason']['sacks_season']) ? $user['userCurrentSeason']['sacks_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Pass Breakups:</label>	
								<span>{{ !empty($user['userCurrentSeason']['total_breaksups']) ? $user['userCurrentSeason']['total_breaksups'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Pass Breakups (Game):</label>	
								<span>{{ !empty($user['userCurrentSeason']['breaksups_game']) ? $user['userCurrentSeason']['breaksups_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Pass Breakups (Season):</label>	
								<span>{{ !empty($user['userCurrentSeason']['breaksups_season']) ? $user['userCurrentSeason']['breaksups_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Interceptions:</label>	
								<span>{{ !empty($user['userCurrentSeason']['total_interception']) ? $user['userCurrentSeason']['total_interception'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Interceptions (Game):</label>	
								<span>{{ !empty( $user['userCurrentSeason']['interception_game']) ?  $user['userCurrentSeason']['interception_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Interceptions (Season):</label>	
								<span>{{ !empty($user['userCurrentSeason']['interception_season']) ? $user['userCurrentSeason']['interception_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Blocked Punts:</label>	
								<span>{{ !empty($user['userCurrentSeason']['blocked_punts']) ? $user['userCurrentSeason']['blocked_punts'] : '-' }}</span>
							</div>
						</div>
					</div>
				</div>
				<div class="defence">
					<h2 class="heading_22 mb-3">Specials</h2>
					<div class="row">
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Field Goals:</label>	
								<span>{{ !empty($user['userCurrentSeason']['total_field_goal']) ? $user['userCurrentSeason']['total_field_goal'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Longest Field Goal:</label>	
								<span>{{ !empty($user['userCurrentSeason']['longest_field_goal']) ? $user['userCurrentSeason']['longest_field_goal'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Field Goal Percentage:</label>	
								<span>{{ !empty($user['userCurrentSeason']['field_goal_percent']) ? $user['userCurrentSeason']['field_goal_percent'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Longest Punt:</label>	
								<span>{{ !empty($user['userCurrentSeason']['longest_punt']) ? $user['userCurrentSeason']['longest_punt'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Punt Distance:</label>	
								<span class="text-capitalize">{{ !empty($user['userCurrentSeason']['avg_punt_distance']) ? $user['userCurrentSeason']['avg_punt_distance'] : '-' }}</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- PAST SEASION --->

		<div class="col-xl-6 col-lg-12">
			<div class="box_wrapper current_season">
				<div class="offence">
					<div class="info_row mb-4">
						<h2 class="heading_22 ">Past Season</h2>
					<label>{{ !empty($user['userPastSeason']['from_year']) ? $user['userPastSeason']['from_year'] : '-' }} - {{ !empty($user['userPastSeason']['to_year']) ? $user['userPastSeason']['to_year'] : '-' }}</label>
					</div>
					<h2 class="heading_22 mb-3">Offense</h2>
					<div class="row">
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Passing Yards:</label>	
								<span>{{ !empty($user['userPastSeason']['total_passing']) ? $user['userPastSeason']['total_passing'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Passing Yards (Game):</label>	
								<span>{{ !empty($user['userPastSeason']['passing_game']) ? $user['userPastSeason']['passing_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Passing Yards (Season):</label>	
								<span>{{ !empty($user['userPastSeason']['passing_season']) ? $user['userPastSeason']['passing_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Completions:</label>	
								<span>{{ !empty($user['userPastSeason']['completion']) ? $user['userPastSeason']['completion'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Completions(%):</label>	
								<span>{{ !empty($user['userPastSeason']['completion_percent']) ? $user['userPastSeason']['completion_percent'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">QB Passer Rating:</label>	
								<span>{{ !empty($user['userPastSeason']['passer_rating']) ? $user['userPastSeason']['passer_rating'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Rushing Yards:</label>	
								<span>{{ !empty($user['userPastSeason']['total_rushing']) ? $user['userPastSeason']['total_rushing'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average rushing yards (Game):</label>	
								<span>{{ !empty($user['userPastSeason']['rushing_game']) ? $user['userPastSeason']['rushing_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Rushing Yards (Season):</label>	
								<span>{{ !empty($user['userPastSeason']['rushing_season']) ? $user['userPastSeason']['rushing_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Receiving Yards:</label>	
								<span>{{ !empty($user['userPastSeason']['total_receiving']) ? $user['userPastSeason']['total_receiving'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Receiving Yards (Game):</label>	
								<span>{{ !empty($user['userPastSeason']['receiving_game']) ? $user['userPastSeason']['receiving_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Receiving Yards (Season):</label>	
								<span>{{ !empty($user['userPastSeason']['receiving_season']) ? $user['userPastSeason']['receiving_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Return Yards:</label>	
								<span>{{ !empty($user['userPastSeason']['total_return']) ? $user['userPastSeason']['total_return'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Return Yards (Game):</label>	
								<span>{{ !empty($user['userPastSeason']['return_game']) ? $user['userPastSeason']['return_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Return Yards (Season):</label>	
								<span>{{ !empty($user['userPastSeason']['return_season']) ? $user['userPastSeason']['return_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total  All Purpose Yards:</label>	
								<span>{{ !empty($user['userPastSeason']['total_all_purpose']) ? $user['userPastSeason']['total_all_purpose'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average  All Purpose Yards (Game):</label>	
								<span>{{ !empty($user['userPastSeason']['purpose_game']) ? $user['userPastSeason']['purpose_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average  All Purpose Yards (Season):</label>	
								<span>{{ !empty($user['userPastSeason']['purpose_season']) ? $user['userPastSeason']['purpose_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Touchdowns:</label>	
								<span>{{ !empty($user['userPastSeason']['tuchdowns']) ? $user['userPastSeason']['tuchdowns'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Games Played:</label>	
								<span>{{ !empty($user['userPastSeason']['games_played']) ? $user['userPastSeason']['games_played'] : '-' }}</span>
							</div>
						</div>
					</div>
				</div>
				<div class="defence">
					<h2 class="heading_22 mb-3">Defense</h2>
					<div class="row">
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Tackles:</label>	
								<span>{{ !empty($user['userPastSeason']['tackles']) ? $user['userPastSeason']['tackles'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Tackles (Game):</label>	
								<span>{{ !empty($user['userPastSeason']['tackles_game']) ? $user['userPastSeason']['tackles_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Tackles (Season):</label>	
								<span>{{ !empty($user['userPastSeason']['tackles_season']) ? $user['userPastSeason']['tackles_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Tackles For Loss:</label>	
								<span>{{ !empty($user['userPastSeason']['total_tackloss']) ? $user['userPastSeason']['total_tackloss'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average tackles for loss (Game):</label>	
								<span>{{!empty( $user['userPastSeason']['tackloss_game']) ?  $user['userPastSeason']['tackloss_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Tackles For Loss (Season):</label>	
								<span>{{ !empty($user['userPastSeason']['tackloss_season']) ? $user['userPastSeason']['tackloss_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Sacks:</label>	
								<span>{{ !empty($user['userPastSeason']['total_sacks']) ? $user['userPastSeason']['total_sacks'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Sacks (Game):</label>	
								<span>{{ !empty($user['userPastSeason']['sacks_game']) ? $user['userPastSeason']['sacks_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Sacks (Season):</label>	
								<span>{{ !empty($user['userPastSeason']['sacks_season'])  ? $user['userPastSeason']['sacks_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Pass Breakups:</label>	
								<span>{{ !empty($user['userPastSeason']['total_breaksups']) ? $user['userPastSeason']['total_breaksups'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Pass Breakups (Game):</label>	
								<span>{{ !empty($user['userPastSeason']['breaksups_game']) ? $user['userPastSeason']['breaksups_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Pass Breakups (Season):</label>	
								<span>{{ !empty($user['userPastSeason']['breaksups_season']) ? $user['userPastSeason']['breaksups_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Interceptions:</label>	
								<span>{{!empty( $user['userPastSeason']['total_interception']) ?  $user['userPastSeason']['total_interception'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Interceptions (Game):</label>	
								<span>{{ !empty($user['userPastSeason']['interception_game']) ? $user['userPastSeason']['interception_game'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Interceptions (Season):</label>	
								<span>{{ !empty($user['userPastSeason']['interception_season']) ? $user['userPastSeason']['interception_season'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Blocked Punts:</label>	
								<span>{{ !empty($user['userPastSeason']['blocked_punts']) ? $user['userPastSeason']['blocked_punts'] : '-' }}</span>
							</div>
						</div>
					</div>
				</div>
				<div class="defence">
					<h2 class="heading_22 mb-3">Specials</h2>
					<div class="row">
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Total Field Goals:</label>	
								<span>{{ !empty($user['userPastSeason']['total_field_goal']) ? $user['userPastSeason']['total_field_goal'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Longest Field Goal:</label>	
								<span>{{ !empty($user['userPastSeason']['longest_field_goal']) ? $user['userPastSeason']['longest_field_goal'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Field Goal Percentage:</label>	
								<span>{{ !empty($user['userPastSeason']['field_goal_percent']) ? $user['userPastSeason']['field_goal_percent'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Longest Punt:</label>	
								<span>{{ !empty($user['userPastSeason']['longest_punt']) ? $user['userPastSeason']['longest_punt'] : '-' }}</span>
							</div>
						</div>
						<div class="col-sm-4 col-6">
							<div class="form-group info_row">
								<label class="d-block mb-2">Average Punt Distance:</label>	
								<span class="text-capitalize">{{ !empty($user['userPastSeason']['avg_punt_distance']) ? $user['userPastSeason']['avg_punt_distance'] : '-' }}</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>