<div class="view_body manage_incidents_view">
    <div class="box_wrapper mb-30">
        <h2 class="heading_22 ">Current Plan</h2>
        <ul class="list-inline details mt-3 mb-0">
            <li class="list-inline-item info_row">
                <label class="d-block">Plan ID:</label>
                <span>{{getSubscriptionDetails($subscription_id,'reference_id')}}</span>
            </li>
            <li class="list-inline-item info_row">
                <label class="d-block">Plan:</label>
                <span>{{getSubscriptionDetails($subscription_id,'title')}}</span>
            </li>
            <li class="list-inline-item info_row">
                <label class="d-block">Storage:</label>
                <span>{{getSubscriptionDetails($subscription_id,'plan_space')}} GB</span>
            </li>
        </ul>
    </div>
</div>
<div class="bg-white box-shadow common_table">
    <div class="table-responsive common_table">
        <table class="table mb-0">
            <thead>
                <tr>
                  <th>Trans. ID</th>
                  <th>Payment Mode</th>
                  <th>Plan</th>
                  <th>Purchased On</th>
                  <th>Expires On</th>
                  <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($transactions as $userPlan)
                <tr>
                    <td>{{($userPlan->transaction_id != '') ? $userPlan->transaction_id : '-'}}</td>
                    <td>{{($userPlan['transactionUser']['signup_type']) ? ucfirst($userPlan['transactionUser']['signup_type']) : '-'}}</td>
                    <td>{{ucfirst($userPlan['userSubscription']['title'])}}</td>
                    <td>{{!empty($userPlan->start_date) ? sameDate($userPlan->start_date) : '-'}}</td>
                    <td>{{!empty($userPlan->end_date) ? sameDate($userPlan->end_date) : '-'}}</td>
                    <td>{{!empty($userPlan->amount)? '$ '.$userPlan->amount : ''}}</td>
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="javascript:void(0);" onclick="getPurchasedView({{$userPlan->user_id}},{{$userPlan->id}})">View</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                @empty
                <!-- Not Record Found -->
                <tr><td colspan="8"><div class="alert alert-danger text-center">No Record Found.</div></td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
{{$transactions->links()}}
<script>
    function getPurchasedView(id,transaction_id) {
         pageLoader('content', 'show'); 
         var url = "{{ url('admin/users/purchase-view') }}"; 
         $.ajax({type: "POST", url: url, data: {id:id,transaction_id:transaction_id,_token:"{{csrf_token()}}"},
               success: function (response) {
                    $('.list-menu').hide();
                   setTimeout(function () {
                       $("#content").html("");
                       $("#content").hide().html(response.html).fadeIn('1000');

                   }, 2000);
               }
         });
     }
        
    $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        getPlanPurchased(pageLink,'{{$id}}')
    });    
        
</script>