<div class="view_body basic_info">
    <div class="row align-items-stretch mb-30">
        <div class="col-md-12 col-lg-3">
            <div class="box_wrapper text-center h-100">
                <div class="user_img_wrap rounded-circle mx-auto">
                    <img src="{{ checkUserImage($user->profile_image, $user->role, 'logo') }}" class="img-fluid"  alt="logo img">
                </div>
                <!-- xxxxxxx -->
                <div class="user_details ">
                    <h2 class="heading_22">{{ ucfirst($user->full_name) }}</h2>
                    <p>{{ !empty($user->reference_id) ? $user->reference_id : '-' }}</p>
                    <p>{{ ucfirst($user->role) }}</p>
                    <span class="divider mx-auto"></span>
                    <p class="mb-0">{{ !empty($user->level_id) ? $user->level_id : '-' }}</p>
                    <p class="mt-3"><b>Current Plan</b></p>
                    <p class="text-capitalize">{{ !empty($user['userSubscription']['title']) ? $user['userSubscription']['title'] : '-' }}</p>
                </div>
            </div>
        </div>
        <!-- xxxxxxxx -->
        <div class="col-md-12 col-lg-9">
            <div class="box_wrapper h-100 box_wrapper_last">
                <div class="bio">
                    <h2 class="heading_22">History</h2>
                    <p>{{ !empty($user->bio) ? $user->bio : '-' }}</p>
                </div>
                <h2 class="heading_22">Address</h2>
                <address>{{ !empty($user->address_line_1) ? $user->address_line_1 : '-' }}</address>
                <div id="map" class="map-holder map "></div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 col-lg-6">
            <div class="box_wrapper team_uniform">
                <h2 class="heading_22 mb-3">Team Uniform</h2>
                <div class="row team_row">
                    <div class="col-6 col-sm-6 col-md-3 col-lg-6 col-xl-3">
                        <div class="common_box">
                            <span class="title d-block">Front</span>
                            <div class="frame text-center"> 
                                <img src="{{ checkUserImage($user->uniform_front_upload, 'team/thumb','uniform') }}" class="img-fluid" alt="uniform">
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-6 col-md-3 col-lg-6 col-xl-3">
                        <div class="common_box mb-0">
                            <span class="title d-block">Back</span>
                            <div class="frame text-center">
                                <img src="{{ checkUserImage($user->uniform_back_upload, 'team/thumb','uniform') }}" class="img-fluid" alt="uniform">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6">
            <div class="box_wrapper team_uniform box_wrapper_last">
                <h2 class="heading_22 mb-3">Brochure</h2>
                @if(!empty($user->upload_brochure))
                <div class="row team_row">
                    <div class="col-6 col-sm-6 col-md-3 col-lg-6 col-xl-3">
                        <div class="common_box mb-0">
                            <span class="title d-block">Front</span>
                            <a href="{{ checkUserImage($user->upload_brochure, 'team') }}" target="_blank">
                                <div class="frame text-center d-flex align-items-center justify-content-center"> 
                                    <i class="flaticon-document"></i>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
             @else
             <div class='alert alert-danger w-70 mt-md-5 mt-3'>No Record Found.</div>
             @endif
            </div>
        </div>
    </div>
</div>
@php
$latlong = getLatLangByAddress(!empty($user->country->name) ? $user->country->name : 'USA');
$lat = $latlong['lat'];
$long = $latlong['long'];
@endPhp
<script>
    var lat = '{{$lat}}';
    var long = '{{$long}}';

    function initMap() {
        // Styles a map in night mode.
        var map = new google.maps.Map(document.getElementById('map'), {
            center: new google.maps.LatLng(lat, long, 5),
            zoom: 5,
            styles:
                    [
                        {
                            "elementType": "geometry",
                            "stylers": [
                                {
                                    "color": "#f5f5f5"
                                }
                            ]
                        },
                        {
                            "elementType": "labels.icon",
                            "stylers": [
                                {
                                    "visibility": "off"
                                }
                            ]
                        },
                        {
                            "elementType": "labels.text.fill",
                            "stylers": [
                                {
                                    "color": "#616161"
                                }
                            ]
                        },
                        {
                            "elementType": "labels.text.stroke",
                            "stylers": [
                                {
                                    "color": "#f5f5f5"
                                }
                            ]
                        },
                        {
                            "featureType": "administrative.country",
                            "elementType": "labels.icon",
                            "stylers": [
                                {
                                    "color": "#000000"
                                },
                                {
                                    "visibility": "on"
                                },
                                {
                                    "weight": 3
                                }
                            ]
                        },
                        {
                            "featureType": "administrative.land_parcel",
                            "elementType": "labels.text.fill",
                            "stylers": [
                                {
                                    "color": "#bdbdbd"
                                }
                            ]
                        },
                        {
                            "featureType": "poi",
                            "elementType": "geometry",
                            "stylers": [
                                {
                                    "color": "#eeeeee"
                                }
                            ]
                        },
                        {
                            "featureType": "poi",
                            "elementType": "labels.text.fill",
                            "stylers": [
                                {
                                    "color": "#757575"
                                }
                            ]
                        },
                        {
                            "featureType": "poi.park",
                            "elementType": "geometry",
                            "stylers": [
                                {
                                    "color": "#e5e5e5"
                                }
                            ]
                        },
                        {
                            "featureType": "poi.park",
                            "elementType": "labels.text.fill",
                            "stylers": [
                                {
                                    "color": "#9e9e9e"
                                }
                            ]
                        },
                        {
                            "featureType": "road",
                            "elementType": "geometry",
                            "stylers": [
                                {
                                    "color": "#ffffff"
                                }
                            ]
                        },
                        {
                            "featureType": "road.arterial",
                            "elementType": "labels.text.fill",
                            "stylers": [
                                {
                                    "color": "#757575"
                                }
                            ]
                        },
                        {
                            "featureType": "road.highway",
                            "elementType": "geometry",
                            "stylers": [
                                {
                                    "color": "#dadada"
                                }
                            ]
                        },
                        {
                            "featureType": "road.highway",
                            "elementType": "labels.text.fill",
                            "stylers": [
                                {
                                    "color": "#616161"
                                }
                            ]
                        },
                        {
                            "featureType": "road.local",
                            "elementType": "labels.text.fill",
                            "stylers": [
                                {
                                    "color": "#9e9e9e"
                                }
                            ]
                        },
                        {
                            "featureType": "transit.line",
                            "elementType": "geometry",
                            "stylers": [
                                {
                                    "color": "#e5e5e5"
                                }
                            ]
                        },
                        {
                            "featureType": "transit.station",
                            "elementType": "geometry",
                            "stylers": [
                                {
                                    "color": "#eeeeee"
                                }
                            ]
                        },
                        {
                            "featureType": "water",
                            "elementType": "geometry",
                            "stylers": [
                                {
                                    "color": "#c9c9c9"
                                }
                            ]
                        },
                        {
                            "featureType": "water",
                            "elementType": "labels.text.fill",
                            "stylers": [
                                {
                                    "color": "#9e9e9e"
                                }
                            ]
                        }
                    ]
        });
        marker = new google.maps.Marker({
            position: new google.maps.LatLng(lat, long),
            map: map
        });
    }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCYOF7L_v_ByPoDbIcZY5MwpAh_YcDoOXo&callback=initMap" async defer></script>        