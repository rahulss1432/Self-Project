<div class="content bg-white box-shadow">
    <div class="table-responsive common_table">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>User Name</th>
                    <th>Current Plan</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Account Type</th>
                    <th>Last Updated By</th>
                    <th>Last Updated On</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($users as $user)
                <tr>
                    <td>{{ ($user->reference_id)?$user->reference_id:'-' }}</td>
                    <td>{{ ucfirst($user->full_name) }}</td>
                    <td class="text-capitalize">{{ $user->role }}</td>
                    <td>{{ $user->email }}</td>    
                    <td>{{ ucfirst($user->address_line_1) }}</td>
                    <td>{{ ($user->role) ? ucfirst($user->role) : '-' }}</td>
                    <td>{{ getUserFullNameById($user->updated_by) }}</td>
                    <td>{{ dateTimeFormat($user->updated_at) }}</td>
                    <td>
                        <div class="switch">
                            <label>
                                @if( $user->status == 'active' )
                                <input type="checkbox" name="activeInactive" checked onchange="getValue(this,'{{$user->id}}')">
                                @else
                                <input type="checkbox" name="activeInactive" onchange="getValue(this,'{{$user->id}}')">
                                @endif
                                <span class="lever"></span>
                            </label>
                        </div>
                    </td>
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="{{ url('admin/users/view/'.base64_encode($user->id)) }}">View</a>
                                    <a class="dropdown-item" href="{{ url('admin/users/edit/'.base64_encode($user->id)) }}">Edit</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="10"><div class="alert alert-danger text-center">No Record Found</div></td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
{{ $users->links() }}  <!--Pagination render -->
<!-- Pagination on page click-->
<script>
    $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        getListing(pageLink);
    });
</script>