<div class="content bg-white box-shadow">
    <div class="table-responsive common_table">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Admin ID</th>
                    <th>Admin Name</th>
                    <th>Email ID</th>
                    <th>Phone Number</th>
                    <th>Address</th>
                    <th>Last Updated By</th>
                    <th>Last Updated On</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($admins as $subadmin)
                <tr>
                    <td>{{ $subadmin->reference_id }}</td>
                    <td>{{ ucfirst($subadmin->full_name) }}</td>
                    <td>{{ $subadmin->email }}</td>
                    <td>{{ $subadmin->phone_number }}</td>
                    <td>{{ ucfirst($subadmin->address_line_1) }}</td>
                    <td>{{ getUserFullNameById($subadmin->updated_by) }}</td>
                    <td>{{dateTimeFormat($subadmin->updated_at)}}</td>
                    <td>
                        <div class="switch">
                            <label>
                                @if( $subadmin->status == 'active' )
                                <input type="checkbox" name="activeInactive" checked onchange="getValue(this,'{{$subadmin->id}}')">
                                @else
                                <input type="checkbox" name="activeInactive" onchange="getValue(this,'{{$subadmin->id}}')">
                                @endif
                                <span class="lever"></span>
                            </label>
                        </div>
                    </td>
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="{{ url('admin/manage-admin/edit/'.base64_encode($subadmin->id)) }}">Edit</a>
                                    <a class="dropdown-item" href="{{ url('admin/manage-admin/assign/'.base64_encode($subadmin->id)) }}">Assign Modules</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="9"><div class="alert alert-danger text-center">No Record Found</div></td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
{{$admins->links()}}  <!--Pagination render -->
<!-- Pagination on page click-->
<script>
    $(".pagination li a").on('click', function(e) {
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    getListing(pageLink);
    });
</script>

