<div class="comment" id="CommentList">
    @if(!empty($getComment) && count($getComment) > 0)
    @foreach($getComment as $comment)
    <div class="comment_list">
        <div class="d-flex align-items-center">
            <div class="d-flex align-items-center">
                <div class="profile_img">
                    <img src="{{ checkUserImage($comment->fromUser->profile_image, $comment->fromUser->role) }}" class="img-fluid rounded-circle" alt="Profile">
                </div>
                <h3 class="mb-0">{{ ucfirst($comment->fromUser->full_name) }}</h3>
            </div>
            <div class="ml-auto">
                <div class="date_time">
                    <span>{{ dateTimeFormat($comment->created_at) }}</span>
                </div>
            </div>
        </div>
        <div class="description">
            <p>{{ ucfirst($comment->comment) }}</p>
        </div>  
    </div>
    @endforeach
    @else
    <div class="comment_list">
        <div class="alert alert-danger text-center">No Record Found.</div>
    </div>
    @endif
</div>