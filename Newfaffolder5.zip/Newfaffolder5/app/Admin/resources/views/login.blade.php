<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Login</title>
        <!-- Bootstrap -->
        @include('admin::layouts.include.head-link')
    </head>
    <body class="login-page ">
    @include('toastrMessage')
        <main >
            <div class="login-wrap mx-auto">
                <div class="login-header d-flex align-items-center justify-content-center">
                    <img src="{{ url('public/administrator/images/white_logo.png') }}" alt="logo">
                </div>
                <h3 class="title">Sign In</h3>
                <div class="login-field">
                    <form class="needs-validation" id="admin_login" method="post" action="{{ URL('admin/login') }}" autocomplete="off" novalidate>
                        {{ csrf_field() }}
                        <div class="form-group">
                            <input type="email" name="email" class="form-control form-control-lg" placeholder="Email"/>
                        </div>
                        <div class="form-group">
                            <input type="password" name="password" class="form-control form-control-lg" placeholder="Password"/>
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-success btn_radius btn-block ripple-effect">
                                LOGIN <span class="btn_loader" style="display: none;"></span>
                            </button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\UserValidation','#admin_login') !!}
                </div>
                <div class="login-footer text-right">
                    <a href="{{URL('admin/forgot')}}">FORGOT PASSWORD? <span class="fa fa-long-arrow-right"></span></a>
                </div>
            </div>
        </main>
        
        @include('admin::layouts.include.footer')

        <script>

            // toaster common function
            function message(action ,msg){
                if(action == 'success'){
                    toastr.remove();
                    toastr.options.closeButton = true;
                    toastr.success(msg, {timeOut: 1500});
                } else {
                    toastr.remove();
                    toastr.options.closeButton = true;
                    toastr.error(msg, {timeOut: 1500});
                }
            }

            // validation
            (function() {
              'use strict';
              window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                  form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                      event.preventDefault();
                      event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                    $('.btn_loader').css('display', 'inline-block');
                    setTimeout(function () {
                        $('.btn_loader').css('display', 'none');
                    }, 2000);

                    $('.d-n').css('opacity', '0.1');
                    setTimeout(function () {
                        $('.d-n').css('opacity', '1');
                    }, 2000);
                  }, false);
                });
              }, false);
            })();

            $(document).on('submit', '#admin_login', function(e){
                e.preventDefault();
                $.post($(this).attr('action'), $(this).serialize(), function(data){
                    if(data.success){
                        message('success', data.message);
                        $('#login').trigger("reset");
                        window.location.href = "{{ url('admin/dashboard') }}";
                    }else{
                        message('error', data.message);
                    }
                });
            });

        </script>

    </body>  
</html>