@php $pageTitle = 'Manage News | FAF'; @endphp
@php $activePage = 'manage-news'; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.side-menu')

<div class="main-content adduser_page add_news">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Manage News Edit </h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/manage-news') }}">Manage News</a>
                        </li>
                        <li class="breadcrumb-item">Manage News Edit</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <div class="add_form mx-auto">
                <div class="card">
                    <div class="card-header">Edit news</div>
                    <div class="card-body">
                        <form id="news-update" class="news-save" method="post" action="javascript:void(0)">
                            {{ csrf_field() }}
                            <input type="hidden" name="id" class="form-control required" value="{{ $getNews->id }}">
                            <div class="field_content">
                                <div class="field_box">
                                    <div class="form-group">
                                        <label>News Headline</label>
                                        <input type="text" name="title" id="title" maxlength="150" class="form-control required" value="{{ $getNews->title }}">
                                        <span class="error-tooltip"></span>
                                    </div>
                                    <!--<a href="javascript:void(0)" id="mulitplefileuploader" onclick="upload_media()">upload</a>-->
                                    <input type="hidden" name="hdnImage" id="hdnImage" >
                                    <span></span>
                                    <div class="row" id="imageSizeErrorDiv">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="d-block" for="uploadFile">Media File Upload
                                                    <div id="mulitplefileuploader" onclick="upload_media()">
                                                        <div class="uploadIcon">
                                                            <span class="form-control"></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <ul class="list-inline media_list mb-0" id="appendMedia">
                                        @if($getNews->newsImage)
                                        @foreach($getNews->newsImage as $image)
                                        <li class="list-inline-item">
                                            <input type="hidden" name="fileType[]" value="{{ $image->file_type}}">
                                            <input type="hidden" name="hdnImageName[]" id="hdnImageName" value="{{ $image->image }}">
                                            <input type="radio" name="mediafile" class="form-control" id="{{$image->image}}" value="{{ $image->image }}" {{ ($image->order_by_image == 1) ? 'checked' : '' }} hidden>
                                            <label class="mediafile image text-center" for="{{$image->image}}">
                                                <span class="overlay">
                                                    <img  height="100" width="100"  src="{{url("public/uploads/news/thumb/".$image->image)}}" class="img-fluid" alt="mediafile">
                                                </span>
                                                <a href="javascript:void(0);" title="{{ $image->image }}" onclick="removeImage(this)">
                                                    <i class="flaticon-cancel-music close_icon icon"></i>
                                                </a>
                                                <i class="flaticon-check check_icon icon"></i>
                                                <span class="rounded-circle play_icon"> 
                                                    <i class="flaticon-play-button"></i> 
                                                </span>
                                                <span class="title text-center">Thumbnail selected</span>
                                            </label>
                                        </li>
                                        @endforeach
                                        @endif
                                    </ul>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label>Description</label>
                                                <textarea name="news_description" maxlength="500" class="form-control required" rows="3">{{ $getNews->news_description }}</textarea>
                                                <span class="error-tooltip"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group action text-right mb-0">
                                        <a href="{{ url('admin/manage-news') }}" id="news-cancel" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                            Cancel
                                        </a>
                                        <button type="submit" class="btn btn-dark rounded-0" id="submitBtn">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $().ready(function () {
        upload_media();
        $("#submitBtn").click(function (e) {
            e.preventDefault();
            var flag = 0;
            $(".required").each(function () {
                if ($.trim($(this).val()) == "") {
                    var text = $(this).closest(".form-group").find("label").text();
                    $(this).next('span').css({"color": "#a94442", "display": "inline-block", "margin-top": "5px"}).html('The ' + text + ' field is required');
                    flag++;
                }
            });
            $('.required').keyup(function () {
                $(this).next('span').css('color', 'green').html("");
            });
            if (flag == 0) {
                submitForm();
            }
        })
    });
    $(function () {
        $('.time').datetimepicker({
            format: 'LT',
        });
    });

    $('input[type="file"]').change(function () {
        var file = this.files[ 0 ];
        $("#fileName").html(file.name);
    });

    function getSavebtn() {
        $(".btn_loader").css('display', 'inline-block');
        setTimeout(function () {
            $(".btn_loader").hide();
        }, 1000);
    }

    function upload_media() {
        var count = 0;
        var totalSelectedFiles = 0;
        if (navigator.appVersion.indexOf("Win") != -1 && navigator.userAgent.indexOf("Safari") > -1 && !(/chrom(e|ium)/.test(navigator.userAgent.toLowerCase())))
        {
            var options = {
                url: "{{url('admin/upload_news_media')}}",
                dragDrop: true,
                method: "POST",
                cache: false,
                allowedTypes: "jpg,png,gif,jpeg,mp4",
                fileName: "myfile",
                async: true,
                multiple: true,
                onSelect: function (files)
                {
                    failedImage = [];
                    totalSelectedFiles = files.length;
                    $('.file_errordiv').bind('DOMNodeInserted', function (event) {
                        $("#loader").html('');
                    });
                    setTimeout(function () {
                       $(".file_errordiv").html('');
                    }, 5000);
                },
                onSuccess: function (files, data, xhr)
                {
                    count++;
                    $(".file_errordiv").html('');
                    var imageName = JSON.parse(data);
                    set_image_preview(imageName);
                },
                afterUploadAll: function ()
                {
                     $(".file_errordiv").html('');
                    $("#status").html(" ");
                },
                onError: function (files, status, errMsg)
                {
                   $(".file_errordiv").html('');
                    $("#status").html("<font color='red'>Upload is Failed</font>");
                }
            }
            $("#mulitplefileuploader").uploadFile(options);
        } else
        {
            var options = {
                url: "{{url('admin/upload_news_media')}}",
                dragDrop: true,
                method: "POST",
                cache: false,
                allowedTypes: "jpg,png,gif,jpeg,mp4",
                fileName: "myfile",
                async: true,
                multiple: true,
                formData: {_token: '{{ csrf_token() }}'},
                onSelect: function (files, data, xhr)
                {
                    failedImage = [];
                    totalSelectedFiles = files.length;
                    $('.file_errordiv').bind('DOMNodeInserted', function (event) {

                    });
                    setTimeout(function () {
                       $(".file_errordiv").html('');
                    }, 5000);
                },
                onSuccess: function (files, data, xhr)
                {
                    count++;
                    $("#hdnSuccessImageCount").val(count);
                    $(".file_errordiv").html('');
                    var imageName = JSON.parse(data);
                    set_image_preview(imageName);
                },
                afterUploadAll: function () {
                    $(".file_errordiv").html('');
                    $("#status").html(" ");
                },
                onError: function (files, status, errMsg) {
                    $(".file_errordiv").html('');
                    $("#status").html("<font color='red'>Upload is Failed</font>");

                }
            }
            $("#mulitplefileuploader").uploadFile(options);
        }

    }

    function set_image_preview(image, groupId, id, appendValue) {
        $("#hdnImage").val(1);
        var exts = ['.jpg', '.gif', '.png', '.JPEG', '.jpeg', '.JPG'];
        $("#ptext-" + id).hide();
        $("#panel-body_" + id).show();
        image = image.toString();
        var res = image.split("===");
        if (image.indexOf("failedimage-") == 0) {
//            $("#imageSizeErrorDiv").show();
            var failedimageName = image.split('failedimage-');
            failedImage.push(failedimageName[1]);
             message('error', 'File has to be smaller than 10MB');
//            $('#imageSizeErrorDiv').html("<div  class='alert alert-info fade in'><a title='close' aria-label='close' data-dismiss='alert' class='close' href='#'>&times;</a>" + failedImage.join(' ,    ') + " Es können nur Panoramen mit einem 2:1 Größenverhältnis hochgeladen werden. Video-Uploads sind auf 100 MB begrenzt. Erlaubte Dateiformate sind: JPG, JPEG, GIF, PNG und MP4.</div>");
//            $('#imageSizeErrorDiv').html("<div  class='alert alert-info fade in'><a title='close' aria-label='close' data-dismiss='alert' class='close' href='#'>&times;</a>" + failedImage.join(' ,    ') + " Es können nur Panoramen mit einem 2:1 Größenverhältnis hochgeladen werden. Video-Uploads sind auf 100 MB begrenzt. Erlaubte Dateiformate sind: JPG, JPEG, GIF, PNG und MP4.</div>");
        }
        else {
            $("#panel-body").hide();
            var imageCount = 0;
            image = image.toString();
            image = image.split('===');
            if (res[0] == 'uploadphoto') {
                var imageName = image[1];
                var div = '<li class="list-inline-item"><input type="hidden" name="fileType[]" value="image"><input type="hidden" name="hdnImageName[]" id="hdnImageName" value="' + imageName + '"><input type="radio" class="form-control" name="mediafile" id="' + imageName + '" value="' + imageName + '" hidden><label class="mediafile image text-center" for="' + imageName + '"><span class="overlay"><img height="100" width="100" src="<?php echo url("public/uploads/temp/thumb") ?>/' + imageName + '"" class="img-fluid" alt="mediafile"></span><a href="javascript:void(0);" title="' + imageName + '" onclick="removeImage(this)"><i class="flaticon-cancel-music close_icon icon"></i></a><i class="flaticon-check check_icon icon"></i><span class="rounded-circle play_icon"> <i class="flaticon-play-button"></i> </span><span class="title text-center">Thumbnail selected</span></label> </li>';
            } else {
                var imageName = image[1];
                var div = '<li class="list-inline-item"><input type="hidden" name="fileType[]" value="video"><input type="hidden" name="hdnImageName[]" id="hdnImageName" value="' + imageName + '"><input type="radio" class="form-control" name="mediafile" id="' + imageName + '"  value="' + imageName + '" hidden><label class="mediafile image text-center" for="' + imageName + '"><span class="overlay"><img  height="100" width="100" src="<?php echo url("public/uploads/temp/thumb") ?>/' + imageName + '"" class="img-fluid" alt="mediafile"></span><a href="javascript:void(0);" title="' + imageName + '" onclick="removeImage(this)"><i class="flaticon-cancel-music close_icon icon"></i></a><i class="flaticon-check check_icon icon"></i><span class="rounded-circle play_icon"> <i class="flaticon-play-button"></i> </span><span class="title text-center">Thumbnail selected</span></label> </li>';
            }
            $("#appendMedia").append(div);
        }
    }


    function removeImage(obj) {
        $(obj).parent().parent('li').remove();
    }


    function submitForm() {
        showButtonLoader('submitBtn', 'Save', 'disable');
        document.getElementById('news-cancel').style.pointerEvents = 'none';
        var url = "{{ url('admin/manage-news/update') }}";
        var formData = $("#news-update").serializeArray();
        formData.push({name: '_token', value: '{{ csrf_token() }}'});
        $.ajax({
            url: url,
            data: formData,
            type: 'POST',
            success: function (data) {
                if (data.success) {
                    message('success', data.message);
                    setTimeout(function () {
                        window.location.href = "{{ url('admin/manage-news') }}"
                    }, 1000);
                } else {
                    message('error', data.message);
                }
            },
            error: function (err) {
                message('error', err);
            },
            complete: function () {
                showButtonLoader('submitBtn', 'Save', 'enable');
                document.getElementById('news-cancel').style.pointerEvents = 'auto';
            }
        });
    }
</script>
@endsection