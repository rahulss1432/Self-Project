@php $pageTitle = 'Manage News | Admin'; @endphp
@php $activePage = 'manage-news'; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.side-menu')
<div class="main-content manage_incidents_view">
    <div class="content_wrapper">
        <div class="content_header" id="content-header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Manage News View</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/manage-news') }}">Manage News</a></li>
                        <li class="breadcrumb-item">Manage News View</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="content bg-white box-shadow p-30" id="content-height">
            <div class="info_row">
                <label class="d-block">News ID:</label>
                <span>{{ $getNews->reference_id }}</span>
            </div>
            <ul class="list-inline details">
                <li class="list-inline-item info_row">
                    <label class="d-block">Posted By:</label>
                    <span>{{ getUserFullNameById($getNews->created_by) }}</span>
                </li>
                <li class="list-inline-item info_row">
                    <label class="d-block">Media:</label>
                    <span>{{ ucfirst($getNews->type) }}</span>
                </li>
                <li class="list-inline-item info_row">
                    <label class="d-block">Posted On:</label>
                    <span>{{ dateTimeFormat($getNews->created_at) }}</span>
                </li>
                <li class="list-inline-item info_row">
                    <label class="d-block">Last Updated:</label>
                    <span>{{ dateTimeFormat($getNews->updated_at) }}</span>
                </li>
            </ul>
            <div class="info_row">
                <label class="d-block">News</label>
                <h5>{{ ucfirst($getNews->title) }}</h5>
                <p class="mb-0">{{ ucfirst($getNews->news_description) }}</p>
            </div>
        </div>
    </div>
</div>
@endsection