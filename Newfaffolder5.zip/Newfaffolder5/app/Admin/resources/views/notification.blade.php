@php $pageTitle = 'Notification | FAF'; @endphp
@php $activePage = ''; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.side-menu')
<div class="main-content notification_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block">Notification</h2>
            </div>
        </div>
        <div id="getNotificationList">

        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        notificationList('');
        readNotification();
    });

    function notificationList(url) {
        if (url == '' || url == undefined)
        {
            url = "{{url('admin/notification-list')}}";
        }
        pageLoader('getNotificationList', 'show');
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.success) {
                    $("#getNotificationList").html(response.html);
                }
            }
        });
    }
</script>
@endsection