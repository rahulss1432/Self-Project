@php $pageTitle = 'View | Admin'; @endphp
@php $activePage = 'users'; @endphp

@extends('admin::layouts.app')

@section('content')
	@include('admin::layouts.include.side-menu')

    @php
    if($user->role == 'player'){
        $personal = true; $contact = true; $about = true; $key = true; $media = true; $measurables = true; $benifits = true; $roster = false;$plan = true;
    }
    if($user->role == 'coach'){
        $personal = true; $contact = true; $about = true; $key = false; $media = true; $measurables = false; $benifits = true; $roster = false;$plan = true;
    }
    if($user->role == 'team'){
        $personal = true; $contact = true; $about = true; $key = false; $media = true; $measurables = false; $benifits = true; $roster = true;$plan = true;
    }
    @endphp

	<div class="main-content view_page">
		<div class="content_wrapper">
            <div class="content_header">
                <div class="page_title">
                    <h2 class="d-inline-block pr-3 mr-3 border-right">{{ $user->role }} User View</h2>
                        <nav aria-label="breadcrumb" class="d-inline-block">
                        <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/users') }}">Manage Users</a></li>
                        <li class="breadcrumb-item">{{ $user->role }} User View</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="content">
                <ul class="common_tabs list-inline bg-white d-flex">
                    @if($personal)
                    <li class="list-inline-item active">
                        <a href="javascript:void(0);" class="active" onclick="getPersonalInfo('{{ $user->id }}')">{{($user->role == 'team')?'Basic info':'Personal info'}}</a>
                    </li>
                    @endif
                    @if($contact)
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onclick="getContactInfo('{{ $user->id }}')">Contact info</a>
                    </li>
                    @endif
                    @if($about)
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onclick="getAbout('{{ $user->id }}')">About</a>
                    </li>
                    @endif
                    @if($roster)
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onclick="getTeamRoster('{{ $user->id }}')">Team Roster</a>
                    </li>
                    @endif
                    @if($key)
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onclick="getKeyStats('{{ $user->id }}')">Key stats</a>
                    </li>
                    @endif
                    @if($media)
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onclick="getMedia('{{ $user->id }}')">Media</a>
                    </li>
                    @endif
                    @if($measurables)
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onclick="getMeasurables('{{ $user->id }}')">Measurables</a>
                    </li>
                    @endif
                    @if($benifits)
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onclick="getDesiredBenifits('{{ $user->id }}')">Desired benefits</a>
                    </li>
                    @endif
                    @if($benifits)
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onclick="getPlanPurchased('','{{ $user->id }}')">Plan Purchased</a>
                    </li>
                    @endif
                </ul>
                <!-- xxxxxxxxxx -->
                <div class="tabs_content">
                    <div class="ajax_list_load">
                        <div id="content"></div>
                    </div>
                </div>
            </div>
		</div>
	</div>

<script src="{{ url('public/administrator/js/jquery.fancybox.min.js') }}"></script>

<script type="text/javascript">
		
    $('.common_tabs li a').click(function() {
        $('.common_tabs li.active').removeClass('active');
        $(this).closest('li').addClass('active');
    });

    // ajax list load
    $(document).ready(function () {
        getPersonalInfo('{{ $user->id }}');
    });

    function getPersonalInfo(id) {
        pageLoader('content', 'show');
        var url = "{{ url('admin/users/_personal-info-view') }}"; 
        $.get(url, {id: id}, function (response) {
            setTimeout(function () {
                $("#content").html("");
                $("#content").hide().html(response.html).fadeIn('1000');
            }, 2000);
        });
    }
    function getContactInfo(id) {
        pageLoader('content', 'show');
        var url = "{{ url('admin/users/_contact-info-view') }}"; 
        $.get(url, {id: id}, function (response) {
            setTimeout(function () {
                $("#content").html("");
                $("#content").hide().html(response.html).fadeIn('1000');
            }, 2000);
        });
    }
    function getAbout(id) {
         pageLoader('content', 'show');
        var url = "{{ url('admin/users/_about-view') }}"; 
        $.get(url, {id: id}, function (response) {
            setTimeout(function () {
                $("#content").html("");
                $("#content").hide().html(response.html).fadeIn('1000');
            }, 2000);
        });
    }
    function getTeamRoster(id) {
         pageLoader('content', 'show');
        var url = "{{ url('admin/users/_team-roster-view') }}"; 
        $.get(url, {id: id}, function (response) {
            setTimeout(function () {
                $("#content").html("");
                $("#content").hide().html(response.html).fadeIn('1000');
            }, 2000);
        });
    }
    function getKeyStats(id) {
         pageLoader('content', 'show');
        var url = "{{ url('admin/users/_key-stats-view') }}"; 
        $.get(url, {id: id}, function (response) {
            setTimeout(function () {
                $("#content").html("");
                $("#content").hide().html(response.html).fadeIn('1000');
            }, 2000);
        });
    }
    function getMedia(id) {
        pageLoader('content', 'show');
        var url = "{{ url('admin/users/_media-view') }}"; 
        $.get(url, {id: id}, function (response) {
            setTimeout(function () {
                $("#content").html("");
                $("#content").hide().html(response.html).fadeIn('1000');
            }, 500);
        });
    }
    
    function getMeasurables(id) {
         pageLoader('content', 'show');
        var url = "{{ url('admin/users/_measurables-view') }}"; 
        $.get(url, {id: id}, function (response) {
            setTimeout(function () {
                $("#content").html("");
                $("#content").hide().html(response.html).fadeIn('1000');
            }, 2000);
        });
    }
    function getDesiredBenifits(id) {
         pageLoader('content', 'show');
        var url = "{{ url('admin/users/_desired-benifits-view') }}"; 
        $.get(url, {id: id}, function (response) {
            setTimeout(function () {
                $("#content").html("");
                $("#content").hide().html(response.html).fadeIn('1000');
            }, 2000);
        });
    }
    function getPlanPurchased(url,id) {
         pageLoader('content', 'show');
         if (url == '' || url == undefined)
        {
            url = "{{ url('admin/users/_plan-purchase-view') }}"; 
        }
        $.get(url, {id: id}, function (response) {
            setTimeout(function () {
                $("#content").html("");
                $("#content").hide().html(response.html).fadeIn('1000');
            }, 2000);
        });
    }
</script>

@endsection