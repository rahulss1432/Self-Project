@php $pageTitle = 'Change Password | FAF'; @endphp
@php $activePage = ''; @endphp

@extends('admin::layouts.app')

@section('content')

@include('admin::layouts.include.side-menu')
<div class="main-content adduser_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3">Change password</h2>
            </div>
        </div>
        <div class="content">
            <div class="add_details mx-auto add_form">
                <div class="card">
                    <div class="card-header">Change password</div>
                    <div class="card-body">
                        <form action="{{ url('admin/update-password') }}" id="changePassword" method="post" autocomplete="off">	
                             {{ csrf_field() }}
                             <input type="hidden" value="{{$id}}" name="id">
                            <div class="field_content" >
                                <div class="field_box">
                                    <div class="row">
                                        <div class="col-lg-6 offset-lg-3">
                                            <div class="form-group">
                                                <label>Current password</label>
                                                <input type="password" id="current_password" name="current_password" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 offset-lg-3">
                                            <div class="form-group">
                                                <label>New password</label>
                                                <input type="password" name="new_password" id="new_password" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 offset-lg-3">
                                            <div class="form-group">
                                                <label>Confirm new password</label>
                                                <input type="password" name="confirm_password" id="confirm_password" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 offset-lg-3">
                                            <div class="form-group action text-right mb-0">
                                                <a href="{{ url('admin/dashboard') }}" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                                    Cancel
                                                </a>
                                                <button type="button" class="btn btn-dark rounded-0 ripple-effect" id="updateButton" onclick="updatePassword('changePassword')">Save
                                                    
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                        {!! JsValidator::formRequest('App\Admin\Http\Requests\ChangePasswordRequest','#changePassword') !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    // function for save admins.
    function updatePassword(form_id) {
        if ($("#" + form_id).valid()) {
            showButtonLoader('updateButton', 'Save', 'disable');
            var formData = new FormData($("#" + form_id)[0]);
            $.ajax({
                url: $("#" + form_id).attr('action'),
                data: formData,
                processData: false,
                contentType: false,
                type: 'POST',
                dataType: 'JSON',
                success: function (data) {
                    if (data.success) {
                        message('success', data.message);
                        setTimeout(function () {
                            window.location.href = "{{ url('admin/dashboard') }}"
                        }, 1000);
                    } else {
                        message('error', data.message);
                    }
                },
                error: function (err) {
                    message('error', err);
                },
                complete: function () {

                    showButtonLoader('updateButton', 'Save', 'enable');

                }
            });
        }
    }
</script>

@endsection