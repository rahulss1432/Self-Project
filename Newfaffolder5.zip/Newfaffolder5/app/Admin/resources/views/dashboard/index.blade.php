@extends('admin::layouts.app')
@section('content')

<div id="page-wrapper" style="min-height: 700px;">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Admin Dashboard</h1>
                <table class="table">
                <thead>
                  <tr>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>Email</th>
                    <th>Roles Assign</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                    $users = \App\User::getAllUser();
                    foreach( $users as $user ){
                    ?>
                    <tr>
                        <td>{{ $user->first_name }}</td>
                        <td>{{ $user->last_name }}</td>
                        <td>{{ $user->email }}</td>
                        <td>
                            <form method="post" action="{{ url('admin/postAdminPermission') }}">
                            {{ csrf_field() }}
                            <input type="hidden" name="user_id" value="{{ $user->id }}"/>
                            <input type="checkbox" {{ $user->hasRole('player') ? 'checked' : '' }} name="role_player"/>
                            <input type="checkbox" {{ $user->hasRole('team') ? 'checked' : '' }} name="role_team"/>
                            <input type="checkbox" {{ $user->hasRole('coach') ? 'checked' : '' }} name="role_coach"/>
                            <input type="submit" value="Assign"/>
                            </form>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
              </table>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>

@endsection