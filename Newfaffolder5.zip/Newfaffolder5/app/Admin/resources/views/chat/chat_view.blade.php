@php $pageTitle = 'Chats View | Admin'; @endphp

@php $activePage = 'chats'; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.side-menu')
<div class="main-content view_page chats_view">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Chats View</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/chats') }}">Chats</a>
                        </li>
                        <li class="breadcrumb-item">Chats View</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <div class="view_body">
                <div class="box_wrapper">
                    <div class="conversation green-scroll"  id="ChatContentScroll"  >
                        <script>
                               ChatContentScrolloll();
                        </script>
                        @if(count($userChats)>0)
                        @foreach($userChats as $message)
                        @if($message->from_id != $fromId)
                        <div class="msg msg_recipient clearfix">
                            <div class="bubble ">
                                <div class="bubble_wrap d-flex align-items-start">
                                    <div class="user_img">
                                        <img src="{{checkUserImage($message->profile_image , $message->role. '/thumb') }}" class="rounded-circle" alt="user">
                                    </div>
                                    <div class="msg_content text-left">
                                        <p>{!! $message->message !!}</p>
                                        <small class="time">{{chatTimeShow($message->created_at)}}</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @else 
                        <div class="msg msg_sent clearfix">
                            <div class="bubble">
                                <div class="bubble_wrap d-flex align-items-start">
                                    <div class="msg_content text-left">
                                        <p>{!! $message->message !!}</p>
                                        <small class="time">{{chatTimeShow($message->created_at)}}</small>
                                    </div>
                                    <div class="user_img">
                                          <img src="{{checkUserImage($message->profile_image, $message->role. '/thumb') }}" class="rounded-circle" alt="user">
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                        @endforeach
                        @else 
                         <div class="alert alert-danger text-center">No record found.</div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

<script>
    custom_margin = 120;
     function ChatContentScrolloll() {
        if($(window).width() <= 1440){
            custom_margin = 100;
        }
        if($(window).width() <= 1024){
            custom_margin = 50;
        }
        var chk_header_height = $('header .navbar-collapse').outerHeight(true) + $('.content_wrapper .page_title').outerHeight(true)
        var window_height = $(window).height();
        $("#ChatContentScroll").css('max-height', window_height - chk_header_height - custom_margin );
        console.log(window_height, chk_header_height, custom_margin);
    } 

</script>