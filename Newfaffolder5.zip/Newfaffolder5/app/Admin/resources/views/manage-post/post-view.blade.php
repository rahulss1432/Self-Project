@php $pageTitle = 'Manage Post | Admin'; @endphp
@php $activePage = 'manage-post'; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.side-menu')
<div class="main-content manage_post_view">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Manage Post View</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/manage-post') }}">Manage Post</a></li>
                        <li class="breadcrumb-item">Manage Post View</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content bg-white box-shadow manage_post">
            <div class="post_comment">
                <div class="d-flex">
                    <div class="">
                        <h2>{{ $getPost->reference_id }}</h2>
                        <h3>{{ getUserFullNameById($getPost->user_id) }}</h3>
                    </div>
                    <div class="ml-auto">
                        <p class="date_time text-right mb-0">{{ dateTimeFormat($getPost->created_at) }}</p>
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item"><i class="flaticon-like"></i> {{ countPostEvent($getPost->id, 'like') }}</li>
                            <li class="list-inline-item"><i class="flaticon-comment"></i> {{ countPostEvent($getPost->id, 'comment') }} </li>
                        </ul>
                    </div>
                </div>
                <p class="description ">{{ ($getPost->post) ? $getPost->post : '-' }}</p>
            </div>
            <!--  -->
            <div class="ajax_list_load">
                <div id="Postlist"></div>
            </div>
            <!--  -->
            <div class="ajax_list_load">
                <div id="CommentList"></div>
            </div>
            <!--  -->
        </div>
    </div>
</div>

<script type="text/javascript">
   $(document).ready(function(){
       getPostMediaList();
       getPostCommentList();
   }) 
    
 function getPostMediaList() {
            $("#Postlist").html('<span class="ajax_loader btn_ring"></span>');
            var url = '{{ url("admin/manage-post/_get-post-media-list")}}';
            $.ajax({
                type: "GET", url: url, data: {id: '{{ $getPost->id }}'},
                success: function (response) {
                   $("#Postlist").html("");
                   $("#Postlist").html(response.html);
                }
            });
        }   
        
 function getPostCommentList() {
            $("#Postlist").html('<span class="ajax_loader btn_ring"></span>');
            var url = '{{ url("admin/manage-post/_get-post-comment-list")}}';
            $.ajax({
                type: "GET", url: url, data: {id: '{{ $getPost->id }}'},
                success: function (response) {
                   $("#CommentList").html("");
                   $("#CommentList").html(response.html);
                }
            });
        }   
</script>
@endsection