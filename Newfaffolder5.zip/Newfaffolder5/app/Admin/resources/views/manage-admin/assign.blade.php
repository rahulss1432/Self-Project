@php $pageTitle = 'Manage Admin Assign | FAF'; @endphp
@php $activePage = 'manage-admin'; @endphp

@extends('admin::layouts.app')

@section('content')

@include('admin::layouts.include.header')
@include('admin::layouts.include.side-menu')

<div class="main-content adduser_page assign_modules">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Assign Modules</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/manage-admin') }}">Manage Admin</a></li>
                        <li class="breadcrumb-item">Assign Modules</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <div class="add_details mx-auto add_form">
                <div class="card">
                    <div class="card-header">Assign Modules</div>
                    <div class="card-body">
                        <form action="{{ url('admin/manage-admin/assign-permission') }}" id="assign-admins" method="post" autocomplete="off">	
                            {{ csrf_field() }}
                            <input type="hidden" name="user_id" value="{{$adminAssign->id}}"/>
                            <ul class="list-unstyled">
                                <?php $sidebar_menus = getAllMenus();
                                foreach ($sidebar_menus as $s_menu) {
                                    ?>
                                    <li>
                                        <div class="custom-control custom-checkbox border-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="option01{{$s_menu['value']}}" {{ $adminAssign->hasMenu($s_menu['value']) ? 'checked' : '' }} value="{{$s_menu['value']}}" name="menu[]">
                                            <label class="custom-control-label" for="option01{{$s_menu['value']}}">{{$s_menu['name']}}</label>
                                        </div>
                                        <hr>
                                    </li>
                                <?php } ?>

                            </ul>
                            <div class="form-group action text-right mb-0">
                                <a href="{{ url('admin/manage-admin')}}" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                    Cancel
                                </a>
                                <button type="button" class="btn btn-dark rounded-0 ripple-effect" id="assignButton" onclick="assignPermission('assign-admins')">Assign
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    // function for save admins.
    function assignPermission(form_id) {
        if ($("#" + form_id).valid()) {
            showButtonLoader('assignButton', 'Save', 'disable');
            var formData = new FormData($("#" + form_id)[0]);
            $.ajax({
                url: $("#" + form_id).attr('action'),
                data: formData,
                processData: false,
                contentType: false,
                type: 'POST',
                dataType: 'JSON',
                success: function (data) {
                    if(data.success) {
                        message('success', data.message);
                        setTimeout(function () {
                            window.location.href = "{{ url('admin/manage-admin') }}"
                        }, 1000);
                    } else {
                        message('error', data.message);
                    }
                },
                error: function (err) {
                message('error', err);
                },
                complete: function () {
                    showButtonLoader('assignButton', 'Save', 'enable');
                }
            });
        }
    }
</script>

@endsection