<script>

    function uplaodResumeMessage() {
        message('error', 'Resume not uploaded by user.');
    }

    setTimeout(function () {
        $(window).resize(function () {
            var chk_height = $('header').outerHeight(true) + $('#content-header').outerHeight(true);
            var window_height = $(window).height();
            $("#content-height").css('min-height', window_height - chk_height - 170);
        }).resize();
    }, 100);

    setTimeout(function () {
        $("#ChatContentScroll").mCustomScrollbar({
            theme: "dark"
        });
    }, 500); 


    //nave toggle
    $(".navbar_toggle").click(function () {
        $("body").toggleClass("toggle_menu");
    });

    // Interactive Effects
    $(".switch, .radio").each(function () {
        var intElem = $(this);
        intElem.on('click', function () {
            intElem.addClass('interactive-effect');
            setTimeout(function () {
                intElem.removeClass('interactive-effect');
            }, 400);
        });
    });

    $("#startDate").on("change.datetimepicker", function (e) {
        $('#endDate').datetimepicker('minDate', e.date);
    });
    $("#endDate").on("change.datetimepicker", function (e) {
        $('#startDate').datetimepicker('maxDate', e.date);
    });
    //  dateFormate
    $( function () {
            $('#startDate, #endDate').datetimepicker({
                useCurrent: false,
                format: "MM/DD/YYYY",
                maxDate: new Date(Date.now() + 1*24*60*60*1000),
                disabledDates: [
                       new Date(Date.now() + 1*24*60*60*1000)],
             
               });
    });

    /* reset filter value */
    function resetFilter(id, tab) {
        $("#" + id)[0].reset();
        if (tab != 'chat')
        {
            $('#status').val('');
            $('#status').selectpicker('refresh');
        }
        if (tab == 'user')
        {
            $('#role').val('');
            $('#role').selectpicker('refresh');
        }
        if (tab == 'news' || tab == 'media')
        {
            $('#includes').val('');
            $('#includes').selectpicker('refresh');
        }
        if (tab == 'subscribe') {
            $('#renewal_cycle').val('');
            $('#renewal_cycle').selectpicker('refresh');
        }
        if (tab == 'event') {
            $('#filterStartDate, #filterEndDate').datetimepicker("destroy");
            initDatepicker();
        }

        getListing('');
    }

    //ripple effect button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });

    function getFilterOpen() {
        $(".filter_form").addClass("slide");
        setTimeout(function () {
            $('.selectpicker').selectpicker('render');
        }, 1000);

    }
    function getFilterClose() {
        $(".filter_form").removeClass("slide");
    }
    // (function () {
    //     // hold onto the drop down menu                                             
    //     var dropdownMenu;

    //     // and when you show it, move it to the body                                     
    //     $(window).on('show.bs.dropdown', function (e) {

    //         // grab the menu        
    //         dropdownMenu = $(e.target).find('.dropdown-menu.list-menu');

    //         // detach it and append it to the body
    //         $('body').append(dropdownMenu.detach());

    //         // grab the new offset position
    //         var eOffset = $(e.target).offset();

    //         // make sure to place it where it would normally go (this could be improved)
    //         dropdownMenu.css({
    //             'display': 'block',
    //             'top': eOffset.top + $(e.target).outerHeight(),
    //             'left': eOffset.left
    //         });
    //     });

    //     // and when you hide it, reattach the drop down, and hide it normally                                                   
    //     $(window).on('hide.bs.dropdown', function (e) {
    //         $(e.target).append(dropdownMenu.detach());
    //         dropdownMenu.hide();
    //     });
    // })();
</script>