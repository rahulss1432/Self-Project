<header class="main_header">
    <nav class="navbar navbar-expand fixed-top bg-white  bg-light" >
        <div class="navbar-brand-wrapper  d-flex align-items-center">
            <a class="navbar-brand mx-auto" href="{{ url('admin') }}">
                <img src="{{ url('public/administrator/images/black_logo.png') }}" alt="logo" class="mx-auto">
            </a>
        </div>
        @php $id = \Illuminate\Support\Facades\Auth::guard(getAuthGuard())->user()->id; @endphp
        <div class="collapse navbar-collapse" >
            <button type="button" class="navbar_toggle btn">
                <span class="icon"></span>
            </button>
            <ul class="navbar-right ml-auto list-unstyled mb-0 d-flex align-items-center">
                <li class="notification list-inline-item active">
                    <a href="javascript:void(0);" onclick="readNotification()" role="button" id="notificationMsg" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="icon-notifications-bell-button1"></i>
                        <span class="badge count admin-notifications"></span>
                    </a>
                    <div class="dropdown-menu right_swip pt-0 pb-0" aria-labelledby="notificationMsg">
                        <ul class="list-unstyled parent_ul">
                            <li class="list-group-item mb-0 border-top-0">Notification</li> 
                            <li id="notificationList" class="notificationList">

                            </li>
                            @if(getNotificationCount($id)>0)
                            <li class="list-group-item  border-bottom-0 view_all">
                                <a onclick="readNotification()" href="{{url('admin/notifications')}}">View all</a>
                            </li>
                            @endif
                        </ul>
                    </div>
                </li>
                <li>
                    <div class="dropdown profile">
                        <a class="btn dropdown-toggle" href="javascript:void(0);" role="button" id="profile_dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="getFilterClose()">
                            <div class=" d-flex align-items-center">
                                <img src="{{ checkUserImage(getUserById($id,'profile_image'), getUserById($id, 'role')) }}" class="rounded-circle" alt="user">
                                <div class="info">
                                    <h6 class="mb-0">{{ucfirst(getUserById($id, 'full_name'))}}</h6>
                                    <span>{{ (getUserById($id, 'role')=='admin')?'Super Admin':'Sub Admin'}}</span>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-menu right_swip" aria-labelledby="profile_dropdown">
                            <a class="dropdown-item ripple-effect" href="{{ url('admin/profile') }}"> <i class="icon-edit-user"></i> Edit Profile</a>
                            <a class="dropdown-item ripple-effect" href="{{ url('admin/change-password') }}"> <i class="icon-password"></i> Change Password</a>
                            <a class="dropdown-item ripple-effect" href="{{ url('admin/logout') }}"><i class="flaticon-on-off-power-button"></i> Logout</a>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</header>
<script>
    $(document).ready(function () {
        loadNotificationList();
        setInterval(countNotificationList, 5000);
    });

    function loadNotificationList() {
        pageLoader('notificationList', 'show');
        var url = "{{url('admin/load-notification-list')}}";
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.success) {
                    $(".notificationList").html(response.html);
                    $(".notifi-list").mCustomScrollbar();
                }
            }
        });
    }

    function countNotificationList() {
        var url = "{{url('admin/load-notification-count')}}";
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.data > 0) {
                    $('.admin-notifications').html(response.data);
                } else {
                    $('.admin-notifications').html('');
                }
            },
            error: function (err) {
            }
        });
    }

    function readNotification() {
        var url = "{{url('admin/update-notification-list')}}";
        $.ajax({
            url: url,
            type: 'POST',
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
                loadNotificationList();
                countNotificationList();
            },
            error: function (err) {
            }
        });
    }
</script>