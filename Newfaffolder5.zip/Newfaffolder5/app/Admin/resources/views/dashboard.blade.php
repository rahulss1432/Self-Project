@php $pageTitle = 'Dashboard | Admin'; @endphp
@php $activePage = 'dashboard'; @endphp

@extends('admin::layouts.app')

@section('content')

@include('admin::layouts.include.header')
@include('admin::layouts.include.side-menu')

<div class="main-content dashboard_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title"><h2>Dashboard</h2></div>
        </div>
        @php  
        $members = getDetailBytype('members'); 
        $countries = getDetailBytype('countries'); 
        $teams = getDetailBytype('teams'); 
        $staffs = getDetailBytype('staffs'); 
        $players = getDetailBytype('players'); 
        $jobs = getDetailBytype('jobs'); 
        $events = getDetailBytype('events'); 
        $videos = getDetailBytype('videos'); 
        $images = getDetailBytype('images'); 
        $posts = getDetailBytype('posts'); 
        @endphp
        <div class="content">
            <div class="row static_row">
                <div class="col">
                    <div class="static_box d-flex align-items-center bg-white box-shadow ">
                        <div class="icon">
                            <span class="icon-user-members">
                                <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span>
                            </span>
                        </div>
                        <div class="total">
                            <h3 data-count="{{$members}}">0</h3>
                            <span>Total members signed</span>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="static_box d-flex align-items-center bg-white box-shadow">
                        <div class="icon">
                            <span class="icon-flag">
                                <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span>
                            </span>
                        </div>
                        <div class="total">
                            <h3 data-count="{{$countries}}">0</h3>
                            <span>Total countries</span>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="static_box d-flex align-items-center bg-white box-shadow">
                        <div class="icon">
                            <span class="icon-team-work">
                                <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span>
                            </span>
                        </div>
                        <div class="total">
                            <h3 data-count="{{$teams}}">0</h3>
                            <span>Total teams & organizations</span>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="static_box d-flex align-items-center bg-white box-shadow">
                        <div class="icon">
                            <span class="icon-total-staff">
                                <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span>
                            </span>
                        </div>
                        <div class="total">
                            <h3 data-count="{{$staffs}}">0</h3>
                            <span>Total staff & personals</span>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="static_box d-flex align-items-center bg-white box-shadow">
                        <div class="icon">
                            <span class="icon-player">
                                <span class="path1"></span><span class="path2"></span><span class="path3"></span>
                            </span>
                        </div>
                        <div class="total">
                            <h3 data-count="{{$players}}">0</h3>
                            <span>Total players</span>
                        </div>
                    </div>
                </div>
                <div class="w-100 col_margin d-none  d-xl-block"></div>
                <div class="col">
                    <div class="static_box d-flex align-items-center bg-white box-shadow">
                        <div class="icon">
                            <span class="icon-d-helmet">
                                <span class="path1"></span><span class="path2"></span><span class="path3"></span>
                            </span>
                        </div>
                        <div class="total">
                            <h3 data-count="{{$jobs}}">0</h3>
                            <span>Total job posted</span>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="static_box d-flex align-items-center bg-white box-shadow">
                        <div class="icon">
                            <span class="icon-create-event">
                                <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span>
                            </span>
                        </div>
                        <div class="total">
                            <h3 data-count="{{$events}}">0</h3>
                            <span>Total events created</span>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="static_box d-flex align-items-center bg-white box-shadow">
                        <div class="icon">
                            <span class="icon-movie">
                                <span class="path1"></span><span class="path2"></span>
                            </span>
                        </div>
                        <div class="total">
                            <h3 data-count="{{$videos}}">0</h3>
                            <span>Total videos posted</span>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="static_box d-flex align-items-center bg-white box-shadow">
                        <div class="icon">
                            <span class="icon-photo">
                                <span class="path1"></span><span class="path2"></span><span class="path3"></span>
                            </span>
                        </div>
                        <div class="total">
                            <h3 data-count="{{$images}}">0</h3>
                            <span>Total images posted</span>
                        </div>
                    </div>
                </div>
                <div class="col-xl col-lg-4 col-md-4 col-sm-4">
                    <div class="static_box d-flex align-items-center bg-white box-shadow">
                        <div class="icon">
                            <span class="icon-blog-post">
                                <span class="path1"></span><span class="path2"></span>
                            </span>
                        </div>
                        <div class="total">
                            <h3 data-count="{{$posts}}">0</h3>
                            <span>Total posts</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="totalsigned_member">
                <div class="page_title d-flex align-items-center">
                    <h2>Total signed member </h2>
                    <div class="action ml-auto">
                        <form id="chart-detail" onchange="getChartBarData()" method="post" action="javascript:void(0);">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <select class="selectpicker select-custom box-shadow" name="type"  data-size="3">
                                        <option value="members">Signed Members/month</option>
                                        <option value="countries">New Countries/month</option>
                                        <option value="team">Teams/Organzations signed/month</option>
                                        <option value="staff">Staff & Personels signed/month</option>
                                        <option value="players">Players signed/month</option>
                                        <option value="jobs">Jobs Posted/month</option>
                                        <option value="events">Events Created/month</option>
                                        <option value="videos">Videos Posted/month</option>
                                        <option value="images">Images Posted/month</option>
                                        <option value="posts">Posts created/month</option>
                                    </select>
                                </li>
                                <li class="list-inline-item">
                                    @php
                                    $current_year = date('Y');
                                    $range = range($current_year, $current_year-5);
                                    $years = array_combine($range, $range);
                                    @endphp
                                    <select class="selectpicker select-custom box-shadow" name="year" data-size="3">
                                        @foreach($years as $val)
                                        <option value="{{$val}}">{{$val}}</option>
                                        @endforeach 
                                    </select>
                                </li>
                            </ul>
                        </form>
                    </div>
                </div>
                <div class="bar_chart">
                    <div id="barchart_material" style="width: 100%; height: 500px;"></div>
                </div>
                <!--<img src="{{ url('public/administrator/images/graph_img.png') }}" alt="graph image" class="img-fluid">-->
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script>
$('.static_box .total h3').each(function () {
    var $this = $(this),
            countTo = $this.attr('data-count');

    $({countNum: $this.text()}).animate({
        countNum: countTo
    },
    {
        duration: 2300,
        easing: 'linear',
        step: function () {
            $this.text(Math.floor(this.countNum));
        },
        complete: function () {
            $this.text(this.countNum);
        }
    });
});

$(document).ready(function(){
   getChartBarData(); 
});

// get detail for bar chat
function getChartBarData() {
    var url = "{{ url('admin/chartdetail') }}";
    var formData = $("#chart-detail").serializeArray();
    formData.push({name: '_token', value: '{{ csrf_token() }}'});
    $.ajax({
        url: url,
        data: formData,
        type: 'POST',
        success: function (response) {
            if (response.success) {
//                console.log( response.userCount);
                google.charts.load('current', {'packages': ['bar']});
                google.charts.setOnLoadCallback(drawChart);

                function drawChart() {
                    var data = google.visualization.arrayToDataTable([
                        ['', ''],
                        ['JAN', response.userCount[1]],
                        ['FEB', response.userCount[2]],
                        ['MAR', response.userCount[3]],
                        ['APR', response.userCount[4]],
                        ['MAY', response.userCount[5]],
                        ['JUN', response.userCount[6]],
                        ['JUL', response.userCount[7]],
                        ['AUG', response.userCount[8]],
                        ['SEP', response.userCount[9]],
                        ['OCT', response.userCount[10]],
                        ['NOV', response.userCount[11]],
                        ['DEC', response.userCount[12]]
                    ]);
                    var options = {
                        chart: {
                            title: '',
                            subtitle: '',
                        },

                        vAxis: {
                            textStyle: {
                                color: '#b9bdca'
                            },
                            titleTextStyle: {
                                color: '#b9bdca'
                            },
                            baselineColor: '#b9bdca4f',
                        },
                         hAxis: {
                            textStyle: {
                                color: '#b9bdca'
                            },
                            gridlines: {
                                color: '#b9bdca' 
                            },
                            titleTextStyle: {
                                color: '#b9bdca'
                            },
                            
                        },
                        
                        legend: { position: 'none' },
                        colors: ['#989898'],
                        bar: { groupWidth: '40%' },
                        bars: 'vertical', // Required for Material Bar Charts.
                        

                    };
                    var chart = new google.charts.Bar(document.getElementById('barchart_material'));
                    chart.draw(data, google.charts.Bar.convertOptions(options));
                }

            } else {
                message('error', data.message);
            }
        },
        error: function (err) {
            //message('error', err);
        },
        complete: function () {
            showButtonLoader('submit-subscription', 'Save', 'enable');
        }
    });
}
</script>

@endsection