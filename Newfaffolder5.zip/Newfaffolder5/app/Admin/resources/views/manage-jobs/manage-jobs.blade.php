@php $pageTitle = 'Manage Jobs | Admin'; @endphp
@php $activePage = 'manage-jobs'; @endphp

@extends('admin::layouts.app')

@section('content')

@include('admin::layouts.include.header')
@include('admin::layouts.include.side-menu')

<div class="main-content manage_jobs">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block">Manage Jobs</h2>
            </div>
            <!--  -->
            <div class="search_section justify-content-between">
                <div class="row">
                    <div class="col-12 col-sm-8">
                        <form autocomplete="off" id="job-search" method="post" action="javascript:void(0);">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <div class="filter_dropdown">
                                        <select class="selectpicker select-custom" onchange="getListing()" name="orderBy" id="orderBy">
                                            <option value="desc">Newest</option>
                                            <option value="asc">Oldest</option>
                                            <option value="">Recently Updated</option>
                                        </select>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <div class="input-group">
                                        <input type="text" name="columns" onkeyup="getListing('')" class="form-control" placeholder="Search By Keyword (Job Id/Position Type/Location)" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button type="submit" class="input-group-text btn btn-dark rounded-0 ripple-effect" id="basic-addon2" onclick="getListing()"> <i class="icon-search"></i> <span class="d-none d-md-block">Search</span></button>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </form>
                    </div>
                    <div class="col-12 col-sm-4">
                        <ul class="filter_right list-inline text-right mb-0">
                            <li class="list-inline-item">
                                <a href="javascript:void(0);" class="btn btn-white rounded-0 ripple-effect" onclick="getFilterOpen()"><i class="icon-filter-filled-tool-symbol"></i> Filter</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!--  -->
            <div class="filter_form bg-white">
                <div class="d-flex top_filter">
                    <div class="filter_heading">
                        <h2>Filters</h2>
                    </div>	
                    <div class="ml-auto">
                        <div class="close_btn" onclick="getFilterClose()">
                            <div class="x common rotate30 rotate45"></div>	
                            <div class="z common rotate150 rotate135"></div>
                        </div>
                    </div>
                </div>
                <form id="job-filter" autocomplete="off" method="post" action="javascript:void(0);">
                    <div class="comman_form">
                        <h4 class="form_heading">By Status</h4>
                        <div class="form-group">
                            <label>Job Status</label>
                            <select class="selectpicker select-custom form-control" name="status" title="Status"  title="Status">
                                <option value="">Select</option> 
                                <option value="active">Active</option> 
                                <option value="inactive">Inactive</option> 
                                <option value="all">All</option> 
                            </select>
                        </div>
                    </div>
                    <div class="comman_form">
                        <h4 class="form_heading">By Level</h4>
                        <div class="form-group">
                            <label>Team Level</label>
                            <select class="selectpicker select-custom form-control" name="levels" id="levels"  title="Status"  title="Status" size="3">

                            </select>
                        </div>
                    </div>
                    <div class="comman_form">
                        <h4 class="form_heading">By Type</h4>
                        <div class="form-group">
                            <label>Job Type</label>
                            <select class="selectpicker select-custom form-control" name="job_type" title="Status" size="3">
                                <option value="player">Player</option> 
                                <option value="staff">Staff & Personals</option> 
                            </select>
                        </div>
                    </div>
                    <div class="comman_form">
                        <h4 class="form_heading">By Date Range</h4>
                        <div class="form-group">
                            <label class="control-label">From Date</label>
                            <div class="dateIcon">
                                <input type="text" id="startDate" name="startDate" class="form-control rounded-0  datetimepicker-input" data-target="#startDate"  data-toggle="datetimepicker" placeholder="Date" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label">To Date</label>
                            <div class="dateIcon">
                                <input type="text" id="endDate"  name="endDate" class="form-control rounded-0  datetimepicker-input" data-target="#endDate"  data-toggle="datetimepicker" placeholder="Date"/>
                            </div>
                        </div>
                    </div>
                    <div class="form-group d-flex submit_btn mb-0">
                        <button type="submit" class="btn btn-light rounded-0 ripple-effect" onclick="resetFilter('job-filter', 'job');">Reset</button>
                        <div class="ml-auto">
                            <button type="submit" class="btn btn-dark rounded-0 ripple-effect" onclick="getListing('')"> Apply <i  style="display:none;" class="btn_loader"></i></button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
        <div id="listing"></div>
    </div>
</div>
<input type="hidden"  data-url="{{ url('admin/manage-jobs/status') }}" id="update_status">
<script type="text/javascript" src="{{ url('public/administrator/js/common.js') }}"></script>
<script type="text/javascript">

    //aAjax load content

    function getListing(url) {
        if (url == '' || url == undefined)
        {
            url = "{{ url('admin/manage-jobs/_jobs-list') }} ";
        }
        pageLoader('listing', 'show');
        var searching = $("#job-search,#job-filter").serializeArray();
        searching.push({name: '_token', value: '{{ csrf_token() }}'});
        $.ajax({
            type: "POST", url: url, data: searching,
            success: function (response) {
                $("#listing").html(response.html);
            },
            error: function (err) {

            },
            complete: function () {
                getFilterClose();
            }
        });
    }

    $(document).ready(function () {
        getListing('');
        $.post("{{ url('admin/get-level-list') }}", {_token: "{{ csrf_token() }}"}, function (data) {
            $('#levels').html(data);
            $('#levels').selectpicker('refresh');
        });
    });
    function searchJoblist() {
        getListing('');
    }

    function getFilterApply() {
        $(".btn_loader").css('display', 'inline-block');
        setTimeout(function () {
            $(".btn_loader").hide();
        }, 1000);
    }
</script>
@endsection