
@php $pageTitle = 'Manage Incidents | Admin'; @endphp
@php $activePage = 'manage-incidents'; @endphp

@extends('admin::layouts.app')

@section('content')

@include('admin::layouts.include.header')
@include('admin::layouts.include.side-menu')
<div class="main-content manage_incidents_view">
    <div class="content_wrapper">
        <div class="content_header" id="content-header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Manage Incidents View</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{url('admin/manage-incidents')}}">Manage Incidents</a></li>
                        <li class="breadcrumb-item">Manage Incidents View</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="content bg-white box-shadow p-30" id="content-height">
            <div class="heading">
                <h3 class="mb-0">#{{$incident->reference_id}}</h3>
                <p class="mb-0">{{fullTimeFormat($incident->created_at)}}</p>
            </div>
            <ul class="list-inline details">
                <li class="list-inline-item info_row">
                    <label class="d-block">Reported Entity:</label>
                    <span>{{ucfirst($incident->reported_entity)}}</span>
                </li>
                <li class="list-inline-item info_row">
                    <label class="d-block">Entity ID:</label>
                    <span>{{$incident->entity_id}}</span>
                </li>
                <li class="list-inline-item info_row">
                    <label class="d-block">Publisher:</label>
                    <span>{{getEntityPublisherDetail($incident->entity_id,$incident->reported_entity)['publisher']}}</span>
                </li>
                <li class="list-inline-item info_row">
                    <label class="d-block">Reported By:</label>
                    <span>{{$incident->reporter->full_name.'('.$incident->reporter->reference_id.')'}}</span>
                </li>
            </ul>
            <div class="info_row mb-3 mb-sm-4">
                <label class="d-block">Description:</label>
                <p class="mb-0">{{ucfirst($incident->title)}}</p>
            </div>
            <form id="report-form" class="report-save" method="post" action="{{ url('admin/manage-incidents/report-by-admin') }}">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Reported By</label>
                            <textarea name="reported_by"class="form-control" rows="6">{{!empty($incident->reported_by) ? $incident->reported_by : ''}}</textarea>	
                        </div>
                        <div class="form-group">
                            <label>Reported Against</label>
                            <textarea name="reported_to"class="form-control" rows="6">{{!empty($incident->reported_against) ? $incident->reported_against : ''}}</textarea>	
                        </div>
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <input type="hidden" name="id" value="{{ $incident->id }}">
                        <div class="form-group action text-right mb-0">
                            <a href="{{url('admin/manage-incidents')}}" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                Cancel
                            </a>
                            @if($incident->status=='open')
                            <button type="submit" class="btn btn-dark rounded-0 ripple-effect" id="report-save">Resolved
                                <i style="display:none;" class="btn_loader"></i>
                            </button>
                            @endif
                        </div>
                    </div>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Admin\Http\Requests\ReportRequest','#report-form') !!}
        </div>
    </div>
</div>

<script>

    $(document).on('submit', '.report-save', function (e) {
        e.preventDefault();
        showButtonLoader('report-save', 'Save', 'disable');
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: $(this).attr('action'),
            data: formData,
            processData: false,
            contentType: false,
            type: 'POST',
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    message('success', data.message);
                    setTimeout(function () {
                        window.location.href = "{{ url('admin/manage-incidents') }}"
                    }, 1000);
                } else {
                    message('error', data.message);
                }
            },
            error: function (err) {
                message('error', err);
            },
            complete: function () {
                showButtonLoader('report-save', 'Save', 'enable');

            }
        });
    });


</script>
@endsection