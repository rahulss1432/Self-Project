@php $pageTitle = 'Manage Incidents | Admin'; @endphp
@php $activePage = 'manage-incidents'; @endphp

@extends('admin::layouts.app')

@section('content')

@include('admin::layouts.include.header')
@include('admin::layouts.include.side-menu')

<div class="main-content manage_incidents">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2>Manage Incidents</h2>
            </div>
            <!--  -->
            <div class="search_section justify-content-between">
                <div class="row">
                    <div class="col-12 col-sm-8">
                        <form autocomplete="off" id="incident-search" method="post" action="javascript:void(0);">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <div class="filter_dropdown">
                                        <select class="selectpicker select-custom" onchange="getListing()" name="orderBy" id="orderBy">
                                            <option value="desc">Newest</option>
                                            <option value="asc">Oldest</option>
                                            <option value="">Recently Updated</option>
                                        </select>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <div class="input-group">
                                        <input type="text" name="columns" onkeyup="getListing('')" class="form-control" placeholder="Search By Keyword (Incident Number / Entity Id / Publisher / Reported By)" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button type="submit" class="input-group-text btn btn-dark rounded-0 ripple-effect" id="basic-addon2" onclick="getListing()"> <i class="icon-search"></i> <span class="d-none d-md-block">Search</span></button>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </form>
                    </div>
                    <div class="col-12 col-sm-4">
                        <ul class="filter_right list-inline text-right mb-0">
                            <li class="list-inline-item">
                                <a href="javascript:void(0);" class="btn btn-white rounded-0 ripple-effect" onclick="getFilterOpen()"><i class="icon-filter-filled-tool-symbol"></i> Filter</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!--  -->
            <div class="filter_form bg-white">
                <div class="d-flex top_filter">
                    <div class="filter_heading">
                        <h2>Filters</h2>
                    </div>	
                    <div class="ml-auto">
                        <div class="close_btn" onclick="getFilterClose()">
                            <div class="x common rotate30 rotate45"></div>	
                            <div class="z common rotate150 rotate135"></div>
                        </div>
                    </div>
                </div>
                <form id="incident-filter" autocomplete="off" method="post" action="javascript:void(0);">
                    <div class="comman_form">
                        <h4 class="form_heading">By Status</h4>
                        <div class="form-group">
                            <label>Incidents Status</label>
                            <select class="selectpicker select-custom form-control " name="status" title="Status" data-size="2">
                                <option value="">Select</option> 
                                <option value="open">Open</option> 
                                <option value="resolved">Resolved</option> 
                            </select>
                        </div>
                    </div>
                    <div class="comman_form">
                        <h4 class="form_heading">By Reported</h4>
                        <div class="form-group">
                            <label>Reported Entity</label>
                            <select class="selectpicker select-custom form-control " name="reporter" id="reporter" title="Reporter" data-size="2">

                            </select>
                        </div>
                    </div>
                    <div class="comman_form">
                        <h4 class="form_heading">By Date Range</h4>
                        <div class="form-group">
                            <label class="control-label">From Date</label>
                            <div class="dateIcon">
                                <input type="text" id="startDate" name="startDate" class="form-control rounded-0  datetimepicker-input" data-target="#startDate"  data-toggle="datetimepicker" placeholder="Date" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label">To Date</label>
                            <div class="dateIcon">
                                <input type="text" id="endDate" name="endDate" class="form-control rounded-0  datetimepicker-input" data-target="#endDate"  data-toggle="datetimepicker" placeholder="Date"/>
                            </div>
                        </div>
                    </div>
                    <div class="form-group d-flex submit_btn mb-0">
                        <button type="button" class="btn btn-light rounded-0 ripple-effect" onclick="resetFilter('incident-filter', 'incident');">Reset</button>
                        <div class="ml-auto">
                            <button type="button" class="btn btn-dark rounded-0 ripple-effect" onclick="getListing('')"> Apply <i  style="display:none;" class="btn_loader"></i></button>
                        </div>

                    </div>
                </form>
            </div>
        </div>

        <div id="listing">

        </div>
    </div>
</div>

<script type="text/javascript" src="{{ url('public/administrator/js/common.js') }}"></script>
<script type="text/javascript">

                                //left menu toggle
                                $('#filterbtn').click(function () {
                                    $(this).toggleClass('active');
                                    $('#filterform').toggleClass('slide');
                                })
                                $('#filterclose').click(function () {
                                    $('#filterform').removeClass('slide');
                                    $('#filterbtn').removeClass('active');
                                })

                                //aAjax load content
                                function getListing(url) {
                                    if (url == '' || url == undefined)
                                    {
                                        url = "{{ url('admin/incident-list') }} ";
                                    }
                                    pageLoader('listing', 'show');
                                    var searching = $("#incident-search,#incident-filter").serializeArray();
                                    searching.push({name: '_token', value: '{{ csrf_token() }}'});
                                    $.ajax({
                                        type: "POST", url: url, data: searching,
                                        success: function (response) {
                                            $("#listing").html("");
                                            $("#listing").hide().html(response.html).fadeIn('2000');
                                        },
                                        error: function (err) {

                                        },
                                        complete: function () {
                                            getFilterClose();
                                        }
                                    });
                                }

                                $(document).ready(function () {
                                    getListing();
                                    setTimeout(function () {
                                        $("#paginationList").fadeIn('2000');
                                    }, 2000);

                                    $.post("{{ url('admin/get-reporter-list') }}", {_token: "{{ csrf_token() }}"}, function (data) {
                                        $('#reporter').html(data);
                                        $('#reporter').selectpicker('refresh');
                                    });
                                });




                                function getFilterApply() {
                                    $(".btn_loader").css('display', 'inline-block');
                                    setTimeout(function () {
                                        $(".btn_loader").hide();
                                    }, 1000);
                                }
</script>

@endsection