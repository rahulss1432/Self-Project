@php $pageTitle = 'CMS | Admin'; @endphp
@php $activePage = 'cms'; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.header')
@include('admin::layouts.include.side-menu')

<link href="{{url('public/administrator/css/rich-text-editor.min.css')}}" rel="stylesheet" type="text/css">
<script src="{{url('public/administrator/js/rich-text-editor.min.js')}}"></script>
<div class="main-content view_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3">CMS</h2>
            </div>
        </div>
        <div class="content">
            <ul class="common_tabs list-inline bg-white d-flex">
                <li class="list-inline-item active">
                    <a href="javascript:void(0);" class="active" onclick="getUserTestimonials()">User Testimonials</a>
                </li>
                <li class="list-inline-item" id="about">
                    <a href="javascript:void(0);" onclick="getAbout()">About FAF</a>
                </li>
                <li class="list-inline-item" id="tos">
                    <a href="javascript:void(0);" onclick="getTerms()">Terms Of Service</a>
                </li>
                <li class="list-inline-item" id="contact_us">
                    <a href="javascript:void(0);" onclick="getContactInfo()">Contact Us</a>
                </li>
            </ul>
            <!-- xxxxxxxxxx -->
            <div class="tabs_content">
                <div class="ajax_list_load">
                    <div id="content"></div>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="{{ url('public/administrator/js/jquery.fancybox.min.js') }}"></script>

<script type="text/javascript">
                        $('.common_tabs li a').click(function () {
                            $('.common_tabs li.active').removeClass('active');
                            $(this).closest('li').addClass('active');
                        });

                        // ajax list load
                        $(document).ready(function () {
                            getUserTestimonials('');
                            var tabbb = "{{$tab}}";
                            if (tabbb != '' && tabbb != undefined) {
                                if (tabbb == 'about') {
                                    getAbout();
                                    $('.common_tabs li.active').removeClass('active');
                                    $('#about').addClass('active');
                                }
                                if (tabbb == 'tos') {
                                    getTerms();
                                    $('.common_tabs li.active').removeClass('active');
                                    $('#tos').addClass('active');
                                }
                                if (tabbb == 'contact_us') {
                                    getContactInfo();
                                    $('.common_tabs li.active').removeClass('active');
                                    $('#contact_us').addClass('active');
                                }
                            }

                        });

                        function getUserTestimonials(url) {
                            if (url == '' || url == undefined)
                            {
                                url = "{{ url('admin/cms/_user-testimonials-list') }}";
                            }
                            $("#content").html('<span class="ajax_loader btn_ring"></span>');
                            $.ajax({type: "GET", url: url, data: {},
                                success: function (response) {
//                                    alert(response);
                                    $("#content").html("");
                                    $("#content").html(response.html);
                                }
                            });
                        }


                        function getCmsAdd() {
                            $("#content").html('<span class="ajax_loader btn_ring"></span>');
                            var url = "{{ url('admin/cms/_cms-add') }}";
                            $.ajax({type: "GET", url: url, data: {},
                                success: function (response) {
                                    $("#content").html("");
                                    $("#content").html(response.html);
                                }
                            });
                        }

                        function getContactInfo() {
                            $("#content").html('<span class="ajax_loader btn_ring"></span>');
                            var url = "{{ url('admin/cms/_cms-contact') }}";
                            $.ajax({type: "GET", url: url, data: {},
                                success: function (response) {
                                    $("#content").html("");
                                    $("#content").html(response.html);
                                }
                            });
                        }

                        function getAbout() {
                            $("#content").html('<span class="ajax_loader btn_ring"></span>');
                            var url = "{{ url('admin/cms/_cms-about') }}";
                            $.ajax({type: "GET", url: url, data: {'title': 'about_us'},
                                beforeSend: function () {
                                    tinymce.remove('#content');
                                },
                                success: function (response) {
                                    $("#content").html("");
                                    $("#content").html(response.html);
                                }, error: function (err) {
                                   getAbout();
                                }, complete: function () {
                                    tinymceInit();
                                }
                            });
                        }

                        function getTerms() {
                            $("#content").html('<span class="ajax_loader btn_ring"></span>');
                            var url = "{{ url('admin/cms/_cms-about') }}";
                            $.ajax({type: "GET", url: url, data: {'title': 'terms_of_service'},
                                beforeSend: function () {
                                    tinymce.remove('#content');
                                },
                                success: function (response) {
                                    $("#content").html("");
                                    $("#content").html(response.html);
                                }, error: function (err) {
                                    getTerms();
                                }, complete: function () {
                                    tinymceInit();
                                }
                            });
                        }

</script>
@endsection