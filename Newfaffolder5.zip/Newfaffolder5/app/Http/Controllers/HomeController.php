<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Session;
use App\Repositories\PostRepository;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(UserRepository $user , PostRepository $post)
    {
        $this->user = $user;
        $this->post = $post;
//      $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('index');
    }
    
    public function homeIndex() {
        $getPlayerList = $this->user->getUserByRole('player');
        $getCoachList = $this->user->getUserByRole('coach');
        $getTeamList = $this->user->getUserByRole('team');
        $getTestimonialList = $this->user->getTestimonial();
        $getNewsList = $this->user->getLatestNewsList();
        $getJobList = $this->user->getLatestJob();
        $getEvents = $this->user->getLatestEvent();
        $featuredVideos = $this->post->getRecentPostByCategory('featured'); // get latest 15 days featured videos
        $newVideos =  $this->post->getRecentPostByCategory('new');           // get latest 15 days new videos        
        /* get and check previous url if available */
        $intended_url = Session::get('url.intended','');
        Session::forget('url.intended');
        /* End */
        return view('home', ['getPlayerList' => $getPlayerList, 'getCoachList' => $getCoachList,
            'getTeamList' => $getTeamList, 'getTestimonialList' => $getTestimonialList,
            'getNewsList' => $getNewsList, 'getJobList' => $getJobList, 'getEvents' => $getEvents,'resetToken' => '','next_url' => $intended_url,
            'featuredVideos'=> $featuredVideos  , 'newVideos' => $newVideos
        ]);
    }
    
    /* get all news list */
    public function allNewsList(){
          $getNews = $this->user->getLatestNews();
          return view('news.all-news-list',['getNews' => $getNews]);
    }
    
    /* get ajax load news list */
    public function loadNewsList(Request $request) {
        $post = $request->all();
        if ($post['type'] == 'faf') {
            $getNewsList = $this->user->getAllFafNewsList();
        } else if ($post['type'] == 'pro') {
            $getNewsList = '';
        } else if ($post['type'] == 'collegiate') {
            $getNewsList = '';
        } else if ($post['type'] == 'international') {
            $getNewsList = '';
        } else if ($post['type'] == 'indoor') {
            $getNewsList = '';
        } else if ($post['type'] == 'prep') {
            $getNewsList = '';
        }
        $html = View::make('ajax-content.news._news-list',['getNewsList' => $getNewsList])->render();
        return Response::json(['html' => $html]);
    }
    
    /* get all news list */
    public function getAllUserCountrys(){
       return $this->user->getAllUserCountrys();
    }
 
}
