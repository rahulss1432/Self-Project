<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use App\Http\Requests\ForgotRequest;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }
    
/**
 * function using for forgot password
 * @param ForgotRequest $request
 * @return type Json
 */ 
    
    public function forgot(ForgotRequest $request) {
        $data = array('');
        $user = \App\User::where(['email' => $request->email])->where('role','<>','subadmin')->first();
        if (!empty($user)) {
            $user->remember_token = generateRandomString(20);
            if ($user->save()) {
                $data['name'] = $user['full_name'];
                $data['request'] = 'forgot_password';
                $data['email'] = $request->email;
                $data['link'] = url('/reset-password/') . '/' . $user->remember_token;
                $data['subject'] = 'Forgot Password';
                $result = sendMail($data);
                if (!empty($result)) {
                    return response()->json(['success' => true, 'message' => 'Mail has been sent please check you mail.']);
                } else {
                    return response()->json(['success' => false, 'message' => 'Please try again.']);
                }
            } else {
                return response()->json(['error' => false, 'message' => 'Please try again.']);
            }
        }
        return response()->json(['error' => false, 'message' => 'This email id is not found in our records.']);
    }

}
