<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Auth;
use App\Models\ChatMessage;
use App\Models\Connection;
use App\Models\ProfileTracker;
use App\Models\Notification;
use App\Models\ChatMessageCron;
use App\Repositories\StripeRepository;
use App\Models\Job;
use Carbon\Carbon;

class CronController extends Controller {

    public function __construct(UserRepository $user, StripeRepository $stripeRepository) {
        $this->user = $user;
        $this->stripeRepository = $stripeRepository;
    }

    /* cron set for every 5 or 7 minute interval */

    public function userActivityCron() {
        try {
            $this->sendMailAfterMinutes();  //  after signup case 20 min, 1 days and 2 days.
            $this->sendUserActivityMail();   // weekly mail like facebook every saturday.
            $this->sendUserUnreadMsg();    // when user offline this unread msg send to mail or sms.
        } catch (\Exception $e) {
            //return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /* cron set for one in a day (time 00:01 AM ) */

    public function paymentRelatedCron() {
        try {
            $this->sendEmailByUserCardExpired();   // plan renew 
            $this->sendEmailByUserCardFailure();  // failure case 7 14 and weekly
        } catch (\Exception $e) {
            //return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * function using for send mails after minutes based on cron (after signup when user is not verify(not login))
     */

    public function sendMailAfterMinutes() {
//        try {
        $data = [];
        $getUserData = \App\User::where('customer_id', "")->where('role', '!=', 'admin')->where('role', '!=', 'subadmin')->get();
        if (!empty($getUserData)) {
            $intervalTime = 0;
            $afterMinute = '';
            $currentDate = '';
            $smsMessage = "";
            foreach ($getUserData as $val) {
                if ($val->after_minutes == 'first') {
                    $intervalTime = date('Y-m-d H:i', strtotime($val->created_at . '+20 minutes'));      /* 20 minutes interval on first time */
                    $currentDate = date('Y-m-d H:i');
                    $afterMinute = '20_minutes';
                    if ($val->signup_by == "website") {
                        $smsMessage = "Hello {" . $val->first_name . "}! Looks like you couldn’t start your FREE 14-Day FAF Membership. Please complete the payment details to start your journey with us.";
                    } else {
                        $smsMessage = "Hello {" . $val->first_name . "}! Looks like you couldn’t upload more videos. Please complete the payment details to start uploading more videos with us.";
                    }
                } elseif ($val->after_minutes == '20_minutes') {
                    $intervalTime = date('Y-m-d', strtotime($val->created_at . ' + 1 day'));       /* 24 hours interval after 20 minutes */
                    $currentDate = date('Y-m-d');
                    $afterMinute = '24_hours';
                    if ($val->signup_by == "website") {
                        $smsMessage = "Hello {" . $val->first_name . "}! We’d personally like to invite you to sign up with us. Please complete the payment details to start your journey with us.";
                    } else {
                        $smsMessage = "Hello {" . $val->first_name . "}! We’d personally like you to upload more videos. Please complete the payment details to start uploading more videos with us.";
                    }
                } elseif ($val->after_minutes == '24_hours') {
                    $intervalTime = date('Y-m-d', strtotime($val->created_at . ' + 2 days'));       /* 48 hours interval after 24 hours */
                    $currentDate = date('Y-m-d');
                    $afterMinute = '48_hours';
                    if ($val->signup_by == "website") {
                        $smsMessage = "Hello {" . $val->first_name . "}! From last 11 years we’ve helped people to grow in football. Please complete the payment details to start your journey with us.";
                    } else {
                        $smsMessage = "Hello {" . $val->first_name . "}! From last 11 years we’ve helped people to grow in football. Please complete the payment details to upload more videos.";
                    }
                } else {
                    break;
                }
                $phoneNumber = getCountryCodeForSms($val->country_id) . '' . $val->phone_number;
                if ($currentDate == $intervalTime) {
                    $data['name'] = $val->first_name;
                    $data['request'] = 'welcome_mail';
                    $data['email'] = $val->email;
                    $data['subject'] = 'Welcome mail';
                    $data['password'] = $val->password;
                    $data['user_login_type'] = $afterMinute;
                    if ($val->notification_flag == "email") { // for email by setting
                        $result = sendMail($data);
                    }
                    if ($val->notification_flag == "sms") { // for sms by setting
                        sendTextSMS($smsMessage, $phoneNumber);
                    }
                    if ($val->notification_flag == "both") { // for email and sms by setting
                        sendTextSMS($smsMessage, $phoneNumber);
                        $result = sendMail($data);
                    }
                    \App\User::where('id', $val->id)->update(['after_minutes' => $afterMinute]);
                } else {
                    break;
                }
            }
        }
//            if (!empty($result)) {
//                return response()->json(['success' => true, 'message' => 'Send Mail Successfully.Please check your mail and verify your account.']);
//            } else {
//                return response()->json(['success' => false, 'message' => 'Please try again.']);
//            }
//        } catch (\Exception $e) {
//           return response()->json(['success' => false, 'message' => $e->getMessage()]);
//        }
    }

    /*
     * function using for send mails after minutes based on cron (facebook weekly every saturday)
     */

    public function sendUserActivityMail() {
//        try {
        $data = [];
        $day = Carbon::setWeekStartsAt(Carbon::SUNDAY);
        $getUserData = \App\User::where(['availability' => 'offline', 'current_status' => 'available'])->get();
        if (!empty($getUserData)) {
            foreach ($getUserData as $val) {
                $messages = ChatMessage::where(['to_id' => $val->id, 'is_read' => 0])->count();
                $connections = Connection::where(['to_id' => $val->id, 'type' => 'pending'])->count();
                $followers = ProfileTracker::where(['to_id' => $val->id, 'type' => 'follow'])->count();
                $notifications = Notification::where(['to_id' => $val->id, 'is_read' => 0])->count();
                $jobs = Job::whereBetween('created_at', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()])->count();
                $currentDate = date('Y-m-d');
                $currentSaturday = date('Y-m-d', strtotime('next Saturday'));
                $phoneNumber = getCountryCodeForSms($val->country_id) . '' . $val->phone_number;
                $smsMessage = "Hello Text";
                if ($currentSaturday == $currentDate) {
                    $data['name'] = $val->full_name;
                    $data['user_image'] = checkUserImage(getUserById($val->id, 'profile_image'), $val->role);
                    $data['user_messages'] = $messages;
                    $data['user_connection'] = $connections;
                    $data['user_follower'] = $followers;
                    $data['user_notification'] = $notifications;
                    $data['user_jobs'] = $jobs;
                    $data['email'] = $val->email;
                    $data['faf_link'] = "";
                    $data['notification_link'] = $val->role . "/notifications";
                    $data['request'] = 'user_activity_mail';
                    $data['subject'] = 'User activity mail';
                    if ($val->notification_flag == "email") { // for email by setting
                        $result = sendMail($data);
                    }
                    if ($val->notification_flag == "sms") { // for sms by setting
                        sendTextSMS($smsMessage, $phoneNumber);
                    }
                    if ($val->notification_flag == "both") { // for email and sms by setting
                        sendTextSMS($smsMessage, $phoneNumber);
                        $result = sendMail($data);
                    }
                } else {
                    break;
                }
            }
        }
//            if (!empty($result)) {
//                return response()->json(['success' => true, 'message' => 'Send Mail Successfully.Please check your mail and verify your account.']);
//            } else {
//                return response()->json(['success' => false, 'message' => 'Please try again.']);
//            }
//        } catch (\Exception $e) {
//             return response()->json(['success' => false, 'message' => $e->getMessage()]);
//        }
    }

    /**
     * send user email by chat message after some time for cron (user is offline then send message or mail)
     */
    public function sendUserUnreadMsg() {
//        try {
        $data = [];
        $getUserData = \App\User::where(['availability' => 'offline', 'current_status' => 'available'])->get();
        if (!empty($getUserData)) {
            foreach ($getUserData as $val) {
                $getUnreadMsg = ChatMessageCron::where(['to_id' => $val->id, 'is_read' => 0])->get();
                if (!empty($getUnreadMsg)) {
                    foreach ($getUnreadMsg as $msg) {
                        $currentTime = time();
                        $userCreateTime = strtotime(date($msg->created_at));
                        $notificationFlag = getUserById($msg->to_id, 'notification_flag');
                        $phoneNumber = getCountryCodeForSms(getUserById($msg->to_id, 'country_id')) . '' . getUserById($msg->to_id, 'phone_number');
                        $smsMessage = "Hello Text";
                        if (($currentTime - $userCreateTime) > (5 * 60)) {
                            $data['name'] = getUserById($msg->to_id, 'full_name');
                            $data['user_image'] = checkUserImage(getUserById($msg->to_id, 'profile_image'), getUserById($msg->to_id, 'role'));
                            $data['user_notitcation'] = getUserById($msg->from_id, 'full_name') . ' says ' . $msg->message;
                            $data['email'] = getUserById($msg->to_id, 'email');
                            $data['request'] = 'user_notification_mail';
                            $data['subject'] = 'User notification mail';
                            if ($notificationFlag == "email") {  // for email by setting
                                $result = sendMail($data);
                                ChatMessageCron::where('to_id', $msg->to_id)->delete();
                            } elseif ($notificationFlag == "sms") { // for sms by setting
                                sendTextSMS($smsMessage, $phoneNumber);
                                ChatMessageCron::where('to_id', $msg->to_id)->delete();
                            } elseif ($notificationFlag == "both") { // for email and sms by setting
                                sendTextSMS($smsMessage, $phoneNumber);
                                $result = sendMail($data);
                                ChatMessageCron::where('to_id', $msg->to_id)->delete();
                            }
                        }
                    }
                }
            }
        }
//            if (!empty($result)) {
//                return response()->json(['success' => true, 'message' => 'Send Mail Successfully.Please check your mail and verify your account.']);
//            } else {
//                return response()->json(['success' => false, 'message' => 'Please try again.']);
//            }
//        } catch (\Exception $e) {
//            return response()->json(['success' => false, 'message' => $e->getMessage()]);
//        }
    }

    /**
     * send user email by renew expired account for cron (only 1 time 00:01 AM)
     */
    public function sendEmailByUserCardExpired() {
//        try {
        $data = [];
        $currentDate = date("Y-m-d");
        $getUserData = \App\User::whereDate('end_date', '<', $currentDate)->where('role', '!=', 'admin')->where('role', '!=', 'subadmin')->get();
        if (!empty($getUserData)) {
            foreach ($getUserData as $val) {
                if (empty($val->customer_id)) {
                    \App\User::where('id', $val->id)->update(['start_date' => '', 'end_date' => '', 'verification' => 'no', 'status' => 'inactive']);
                } else {
                    if ($val->signup_type == "ach") {
                        $this->user->payWithAch($val->id);
                        \App\User::where('id', $val->id)->orWhere('plan_flag', 'first')->orWhere('plan_flag', 'upgrade')->update(['plan_flag' => 'renew']);
                    } else {
                        $this->stripeRepository->paymentWithStripe($val->id);
                        \App\User::where('id', $val->id)->orWhere('plan_flag', 'first')->orWhere('plan_flag', 'upgrade')->update(['plan_flag' => 'renew']);
                    }
                }
            }
        }
//        } catch (\Exception $e) {
//             return response()->json(['success' => false, 'message' => $e->getMessage()]);
//        }
    }

    /**
     * send user email by renew failure account for cron  (failure case 7 14 and weekly mail)
     */
    public function sendEmailByUserCardFailure() {
//        try {
        $data = [];
        $getUserPayment = \App\Models\PaymentNotification::where(['is_process' => 0, 'status' => 'failure'])->get();
        if (!empty($getUserPayment)) {
            $afterDays = "";
            $currentDate = date('Y-m-d');
            $intervalTime = "";
            $smsMessage = "";
            foreach ($getUserPayment as $val) {
                if ($val->after_days == "first") {
                    $intervalTime = date('Y-m-d', strtotime($val->created_at . ' + 7 days'));      /* 7 days interval on first time */
                    $afterDays = '7_days';
                    if ($val->signup_by == "website") {
                        $smsMessage = "Hello {" . getUserById($val->user_id, 'full_name') . "}! Your payment method got declined but your profile info is intact. Just add another payment method to be live again!";
                    } else {
                        $smsMessage = "Hello {" . getUserById($val->user_id, 'full_name') . "}! Your payment method got declined but your profile info is intact. Just add another payment method to be add videos!";
                    }
                } elseif ($val->after_days == "7_days") {
                    $intervalTime = date('Y-m-d', strtotime($val->created_at . ' + 14 days'));       /* 14 days interval after 7 days */
                    $afterDays = '14_days';
                    if ($val->signup_by == "website") {
                        $smsMessage = "Hi {" . getUserById($val->user_id, 'full_name') . "}! Your payment method still got declined. To avoid account suspension in 7 days, please update payment method.";
                    } else {
                        $smsMessage = "Hi {" . getUserById($val->user_id, 'full_name') . "}! Your payment method still got declined. To add more videos, please update payment method.";
                    }
                } elseif ($val->after_days == "14_days") {
                    $intervalTime = date('Y-m-d', strtotime($val->created_at . ' + 7 days'));       /* weekly interval after 14 days */
                    $afterDays = 'weekly';
                    if ($val->signup_by == "website") {
                        $smsMessage = "Hi {" . getUserById($val->user_id, 'full_name') . "}! Hope all is well with you. Looks like your account fell into suspension. We’d hate to see you miss out new opportunities. Consider staying with us and we’ll do everything we can to assist you along your football journey!";
                    } else {
                        $smsMessage = "Hi {" . getUserById($val->user_id, 'full_name') . "}! Hope all is well with you. Looks like your video uploading access is restricted. To add more videos, please update payment method.";
                    }
                } else {
                    $intervalTime = date('Y-m-d', strtotime($val->created_at . ' + 7 days'));       /* weekly interval after 14 days */
                    $afterDays = 'weekly';
                    if ($val->signup_by == "website") {
                        $smsMessage = "Hello {" . getUserById($val->user_id, 'full_name') . "}! Hope all is well with you! Looks like there’s a great deal of activity on your FAF account like messages, connection requests, comments and other notifications requiring your attention. Click the link to reactivate your account!";
                    } else {
                        $smsMessage = "Hello {" . getUserById($val->user_id, 'full_name') . "}! Hope all is well with you! Looks like there’s a great deal of activity on your FAFTube account like comments and likeson your videos. Click the link to reactivate your account!";
                    }
                }
                $phoneNumber = getCountryCodeForSms(getUserById($val->user_id, 'country_id')) . '' . getUserById($val->user_id, 'phone_number');
                $notificationFlag = getUserById($val->user_id, 'notification_flag');
                if ($currentDate == $intervalTime) {
                    $data['name'] = getUserById($val->user_id, 'full_name');
                    $data['request'] = 'decline_mail';
                    $data['email'] = getUserById($val->user_id, 'email');
                    $data['subject'] = 'Decline mail';
                    $data['user_payment_type'] = $afterDays;
                    if ($val->signup_by == "website") {
                        $data['site_link'] = "";
                    } else {
                        $data['site_link'] = "";
                    }
                    if ($notificationFlag == "email") { // for email by setting
                        $result = sendMail($data);
                    }
                    if ($notificationFlag == "sms") { // for sms by setting
                        sendTextSMS($smsMessage, $phoneNumber);
                    }
                    if ($notificationFlag == "both") { // for email and sms by setting
                        sendTextSMS($smsMessage, $phoneNumber);
                        $result = sendMail($data);
                    }
                    \App\Models\PaymentNotification::where('user_id', $val->user_id)->update(['after_days' => $afterDays]);
                    if ($afterDays != "weekly") {
                        sendNotifacationByFrontUser($val->user_id, $val->user_id, 'payment_decline_' . $afterDays, "", "");
                    }
                }
            }
        }
//        } catch (\Exception $e) {
//             return response()->json(['success' => false, 'message' => $e->getMessage()]);
//        }
    }

}
