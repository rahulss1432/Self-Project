<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EventTeamRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'team_name' => 'required|max:50|unique:event_teams,name|check_first_letter|remove_spaces',
            'team_logo' => 'required|mimes:jpeg,jpg,png|max:2024',
        ];
    }

    public function messages() {
        return [
//            'team_name.required' => 'The team name field is required.',
            'team_name.check_first_letter' => 'The team name first character should be alphabet.',
            'team_name.remove_spaces' => 'The team name does not contain only spaces.',
        ];
    }

}
