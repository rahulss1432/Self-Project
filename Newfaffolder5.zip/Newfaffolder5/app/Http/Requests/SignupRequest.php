<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SignupRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'first_name' => 'required|alpha_dash',
            'last_name' => 'required|alpha_dash',
            'email' => 'required|string|check_email_format|unique:users',
            'password' => 'required|string|min:6|max:15',
            'confirm_password' => 'required|string|min:6|max:15|same:password',
            'phone_number' => 'required|phone_format',
            'country_id' => 'required',
            'state_id' => 'required',
            'city' => 'required|remove_spaces',
//            'zip_code' => 'required|remove_spaces|numeric|digits:6',
            'zip_code' => 'required|get_latlong_byzip|max:10',
            'address_line_1' => 'required|string|max:70|remove_spaces',
            'checktc' => 'required',
        ];
    }

    public function messages() {
        return [
            'zip_code.get_latlong_byzip' => 'The zip code is invalid.',
            'phone_number.required' => 'The mobile number field is required.',
            'phone_number.phone_format' => 'The phone number field is invalid.',
            'email.check_email_format' => 'Please provide valid email',
            'address_line_1.remove_spaces' => 'Only space not allowed',
            'city.remove_spaces' => 'Only space not allowed',
            'zip_code.remove_spaces' => 'Only space not allowed',
            'checktc.required' => 'Please agree terms and conditions.',
            'country_id.required' => 'The country field is required.',
            'state_id.required' => 'The state field is required.',
        ];
    }

}
