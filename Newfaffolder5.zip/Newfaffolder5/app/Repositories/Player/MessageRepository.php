<?php

namespace App\Repositories\Player;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;
use App\Models\Connection;
use App\Models\ChatMessage;
use App\Models\ChatMessageCron;
use Auth;

Class MessageRepository {

    /**
     * Class Construct.
     */
    public function __construct(Connection $connection, ChatMessage $chatMessage, ChatMessageCron $chatMessageCron) {
        $this->connection = $connection;
        $this->chatMessage = $chatMessage;
        $this->chatMessageCron = $chatMessageCron;
    }

    /**
     * Function for list all users.
     */
    public function getChatUsers() {
        $userId = Auth::guard('player')->user()->id;
        return $this->connection->where(function($query) use($userId) {
                    $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
                })->where(function($query) {
                    $query->orWhere('type', 'accept')->orWhere('type', 'unblock')->orWhere('type', 'block')
                            ->orWhere(function($query) {
                                $query->where(function($query) {
                                    $query->where('type', 'pending')->orWhere('type', 'reject');
                                })->where('chat_list', 'yes');
                            });
                })->orderBy('updated_at', 'DESC')->get();
    }

    /**
     * Function for list all users.
     */
    public function getUserMessages($request) {
        $userId = Auth::guard('player')->user()->id;
        return $this->chatMessage->where('chat_id', $request->chat_id)->get();
    }

    /*
     * Function for send chat message.
     */

    public function sendChatMessage($request) {
        $userId = Auth::guard('player')->user()->id;
        $current_time = \Carbon\Carbon::now()->toDateTimeString();
        $checkWorkMode = getUserById($request->to_id, 'current_status');
        if ($checkWorkMode == 'away') {
            return Response::json(['success' => false, 'data' => 'reload', 'message' => 'You can not chat.This User is not available.']);
        }
        $chatDetail = $this->connection->where('id', $request->chat_id)->first();
        if ($chatDetail->type == 'accept') {
            $connection = $this->connection->where('id', $request->chat_id)->update(['updated_at' => $current_time]);
            $model = $this->chatMessage;
            $model->chat_id = $request->chat_id;
            $model->from_id = $userId;
            $model->to_id = $request->to_id;
            if ($request->hasFile('attachment')) {
                $attachment = $request->file('attachment');
                $name = uploadFile($attachment, 'player');
                $attachment = checkUserImage($name, 'player');
                $message = "<i class='fa fa-download fa-2x downloadAttachment' data-url='$attachment' data-name='$name'></i>";
                $model->message = $message;
            } else {
                $model->message = $request->message;
            }
            $model->save();
            $model->time = timeFormat($model->created_at);
            $model->userImg = checkUserImage(getUserById($userId, 'profile_image'), getUserById($userId, 'role'));
            $connection = $this->connection->find($model->chat_id);
            if ($connection->from_id == $userId) {
                $model->otherUser = $connection->to_id;
            } elseif ($connection->to_id == $userId) {
                $model->otherUser = $connection->from_id;
            }
            // for cron messages
            $availability = getUserById($model->to_id, 'availability');
            $currentStatus = getUserById($model->to_id, 'current_status');
            if ($availability == "offline" && $currentStatus == "available") {
                $modelCron = $this->chatMessageCron;
                $modelCron->chat_id = $request->chat_id;
                $modelCron->from_id = $userId;
                $modelCron->to_id = $request->to_id;
                if ($request->hasFile('attachment')) {
                    $attachment = $request->file('attachment');
                    $name = uploadFile($attachment, 'player');
                    $attachment = checkUserImage($name, 'player');
                    $message = "<i class='fa fa-download fa-2x downloadAttachment' data-url='$attachment' data-name='$name'></i>";
                    $modelCron->message = $message;
                } else {
                    $modelCron->message = $request->message;
                }
                $modelCron->save();
                sendNotifacationByFrontUser($model->from_id, $model->to_id, 'user_messages', '', '');
            }
            return Response::json(['success' => true, 'data' => $model]);
            //return $model;
        } else {
            return Response::json(['success' => false, 'data' => '', 'message' => 'You can not chat with this user']);
        }
    }

    /*
     * Function for check unread messages.
     */

    public function checkUnreadCount() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return $this->chatMessage->where(['to_id' => $userId, 'is_read' => '0'])->count();
    }

    /*
     * Function for update read count.
     */

    public function updateReadCount($request) {
        $this->chatMessage->where(['chat_id' => $request->chat_id, 'is_read' => '0'])->update(['is_read' => '1']);
    }

    /**
     * Block/Unblock user for chat
     */
    public function blockChatUser($request) {
        $post = $request->all();
        $userId = Auth::guard('player')->user()->id;
        $users = array();
        $users['userId'] = $userId;
        $users['block_user_id'] = $post['user_id'];

        $connection = $this->connection->where(function($query) use($users) {
                    $query->where('from_id', $users['userId'])->where('to_id', $users['block_user_id']);
                })->orWhere(function($query) use($users) {
                    $query->where('from_id', $users['block_user_id'])->where('to_id', $users['userId']);
                })->where('type', 'accept')->first();

        if (!empty($connection)) {
            if ($post['type'] == 'block') {
                $connection->type = 'block';
                sendNotifacationByFrontUser($userId, $users['block_user_id'], 'block', '', '');
            } else {
                $connection->type = 'unblock';
            }
            $connection->save();
            return Response::json(['success' => true, 'message' => 'You have blocked this user successfully',]);
        } else {
            return Response::json(['success' => false, 'message' => 'Something went wrong']);
        }
    }

    /*
     * Get connection detail by id
     */

    public function getConnectionDetail($chatId) {
        return $this->connection->where('id', $chatId)->first();
    }

}
