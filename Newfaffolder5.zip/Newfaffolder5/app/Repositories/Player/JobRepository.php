<?php

namespace App\Repositories\Player;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Job;
use Auth;

Class JobRepository {

    /**
     * Class Construct.
     *
     * @param  array  $data
     * @return \App\User
     */

    public function __construct(Job $job) {
        $this->job = $job;
    }
    
   

}

