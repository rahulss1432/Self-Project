<?php

namespace App\Repositories\Player;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

Class DashboardRepository {
    
    public function __construct() {
        
    }
    
    /**
     * Get all dashboard data.
     * @param null
      * @return \Illuminate\Http\Response
     */
    public function index() {
        try {       
            return view('player::dashboard.index');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }
}
