<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Connection;
use App\Models\ChatMessage;
use Auth;

Class MessageRepository {

    /**
     * Class Construct.
     * @param Connection $connection
     * @param ChatMessage $chatMessage
     */
    public function __construct(Connection $connection, ChatMessage $chatMessage) {
        $this->connection = $connection;
        $this->chatMessage = $chatMessage;
    }

    /**
     * Function for get All user chat.
     * @param type $request
     * @return type
     */
    public function getAllChatMessage($request) {
        $query = DB::table('chat_messages AS t1')->select(DB::raw("t1.*, from_user.id as from_user_id,from_user.full_name as from_user_fullName,from_user.reference_id as from_user_reference_id, to_user.id as to_user_id,to_user.full_name as to_user_fullName,to_user.reference_id as to_user_reference_id"))
                ->join(DB::raw('(SELECT chat_id, MAX(created_at) created_at FROM chat_messages GROUP BY chat_id) t2'), ['t1.chat_id' => 't2.chat_id', 't1.created_at' => 't2.created_at'])
                ->join('users as from_user', 'from_user.id', '=', 't1.from_id')
                ->join('users as to_user', 'to_user.id', '=', 't1.to_id');
        /* check order of message by new ,old and recently updated */
        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $query->orderBy('id', $request['orderBy']);
            } else {
                $query->orderBy('updated_at', 'desc');
            }
        }
        /* text search by columns of message list */
        if (!empty($request['search_by_name']) && isset($request['search_by_name'])) {
            $query->where('from_user.full_name', 'like', '%' . $request['search_by_name'] . '%')
                    ->orWhere('t1.reference_id', 'like', '%' . $request['search_by_name'] . '%')
                    ->orWhere('to_user.full_name', 'like', '%' . $request['search_by_name'] . '%')
                    ->orWhere('from_user.reference_id', 'like', '%' . $request['search_by_name'] . '%')
                    ->orWhere('to_user.reference_id', 'like', '%' . $request['search_by_name'] . '%');
        }
        /* Filter from date to date */
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = startDateFormatServer($request['startDate']);
            $to = endDateFormatServer($request['endDate']);
            $query->whereBetween('t1.created_at', array($from, $to));
        }
        return $query->paginate(getPaginatePage());
    }

    /**
     * Function for get chat message by select user .
     * @param type $id
     * @return type
     */
    public function getMessageBySelectUser($id) {
        $query = $this->chatMessage->select(['chat_messages.*', 'from_user.profile_image', 'to_user.profile_image', 'from_user.role', 'to_user.role'])
                ->join('users as from_user', 'from_user.id', '=', 'chat_messages.from_id')
                ->join('users as to_user', 'to_user.id', '=', 'chat_messages.to_id')
                ->where('chat_id', $id)
                ->get();
        return $query;
    }

}
