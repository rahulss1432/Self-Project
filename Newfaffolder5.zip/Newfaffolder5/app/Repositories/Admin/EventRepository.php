<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Event;
use App\User;
use Auth;

Class EventRepository {

    /**
     * Class Construct.
     * @param Event $event
     * @param User $user
     */
    public function __construct(Event $event, User $user) {
        $this->event = $event;
        $this->user = $user;
    }

    /**
     * Get all dashboard data.
     * @param type $request
     * @return type
     */
    public function getAllEvents($request) {
        $eventList = $this->event->with('team1Data', 'team2Data', 'country', 'state')->select('events.*');
        /* check order of event by new ,old and recently updated */
        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $eventList->orderBy('id', $request['orderBy']);
            } else {
                $eventList->orderBy('updated_at', 'desc');
            }
        }
        /* text search by columns of admin list */
        if (!empty($request['columns'])) {
            $text = $request['columns'];
            $eventList->whereHas('team1Data', function ($q1) use ($text) {  // search data by user's table
                $q1->where('full_name', 'like', '%' . $text . '%');
            })->orWhereHas('team2Data', function ($q2) use ($text) {
                $q2->where('full_name', 'like', '%' . $text . '%');
            })->orWhereHas('country', function ($q3) use ($text) {
                $q3->where('name', 'like', '%' . $text . '%');
            })->orWhereHas('state', function ($q4) use ($text) {
                $q4->where('state_name', 'like', '%' . $text . '%');
            })->orWhere(function ($query) use ($text) {                     // search data by event table
                $query->orWhere('reference_id', 'like', '%' . $text . '%')
                        ->orWhere('event_name', 'like', '%' . $text . '%')
                        ->orWhere('address1', 'like', '%' . $text . '%')
                        ->orWhere('city', 'like', '%' . $text . '%')
                        ->orWhere('zipcode', 'like', '%' . $text . '%');
                if (!intval($text)) {
                    $query->orWhere('team1', 'like', '%' . $text . '%');
                    $query->orWhere('team2', 'like', '%' . $text . '%');
                }
            });
        }
        /* Filter active inactive */
        if (!empty($request['status'])) {
            $eventList->where('status', $request['status']);
        }
        /* Filter from date to date */
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = date('Y-m-d', strtotime($request['startDate']));
            $to = date('Y-m-d', strtotime($request['endDate']));
            $eventList->whereDate('start_date', '>=', $from)
                    ->whereDate('end_date', '<=', $to);
        }
        if (!empty($request['startDate']) && empty($request['endDate'])) {
            $from = date('Y-m-d', strtotime($request['startDate']));
            $eventList->whereDate('start_date', $from);
        }
        if (!empty($request['endDate']) && empty($request['startDate'])) {
            $to = date('Y-m-d', strtotime($request['endDate']));
            $eventList->whereDate('end_date', $to);
        }
        $rows = $eventList->Paginate(getPaginatePage());
        if (!empty($rows)) {
            return $rows;
        }
    }

    /**
     * Save event
     * @param type $request
     * @return type
     */
    public function save($request) {
        try {
            $post = $request->all();
            $city = $post['city'];
            $address = $post['address1'];
            $startDate = $post['start_date'];
            $startTime = $post['start_time'];
            $endDate = $post['end_date'];
            $endTime = $post['end_time'];
            if (!empty($city) && !empty($address) && !empty($endDate) && !empty($endTime)) { /* check for if event is aleardy on this date,time and city and address */
                $userStartDate = dbDateFormat($post['start_date']);
                $userEndDate = dbDateFormat($post['end_date']);
                $userStartTime = date('H:i:s', strtotime($post['start_time']));
                $userEndTime = date('H:i:s', strtotime($post['end_time']));

                $userStartDateTime = strtotime($userStartDate . ' ' . $userStartTime);
                $userEndDateTime = strtotime($userEndDate . ' ' . $userEndTime);
                $matchedEvents = $this->event->where('city', 'like', '%' . $city . '%')
                        ->where('address1', 'like', '%' . $address . '%');
                if (isset($post['id'])) {
                    $matchedEvents = $matchedEvents->where('id', '!=', $post['id']);
                }
                $matchedEvents = $matchedEvents->get();
                if ($matchedEvents->count() > 0) {
                    $eventExists = false;
                    foreach ($matchedEvents as $event) {
                        $serverStartTime = date('H:i:s', strtotime($event->start_time));
                        $serverEndTime = date('H:i:s', strtotime($event->end_time));
                        $serverStartDate = dbDateFormat($event->start_date);
                        $serverEndDate = dbDateFormat($event->end_date);

                        $serverStartDateTime = strtotime($serverStartDate . ' ' . $serverStartTime);
                        $serverEndDateTime = strtotime($serverEndDate . ' ' . $serverEndTime);
                        if (($serverStartDate <= $userStartDate && $serverEndDate >= $userEndDate) ||
                                ($serverStartDate > $userStartDate && $serverEndDate <= $userEndDate) ||
                                ($userStartDate > $serverStartDate && $serverEndDate > $userStartDate) ||
                                ($userEndDate >= $serverStartDate && $serverEndDate > $userEndDate) ||
                                ($userStartDate < $serverStartDate && $serverStartDate < $userEndDate) ||
                                ($userStartDate < $serverEndDate && $serverEndDate < $userEndDate)) {
                            if ($serverStartTime <= $userStartTime && $serverEndTime >= $userEndTime) {
                                $eventExists = true;
                            } elseif ($serverStartTime > $userStartTime && $serverEndTime <= $userEndTime) {
                                $eventExists = true;
                            } elseif ($userStartTime > $serverStartTime && $serverEndTime > $userStartTime) {
                                $eventExists = true;
                            } elseif ($userEndTime >= $serverStartTime && $serverEndTime > $userEndTime) {
                                $eventExists = true;
                            } elseif ($userStartTime < $serverStartTime && $serverStartTime < $userEndTime) {
                                $eventExists = true;
                            } elseif ($userStartTime < $serverEndTime && $serverEndTime < $userEndTime) {
                                $eventExists = true;
                            }

                            /* for datetime check */
                            if ($serverStartDateTime <= $userStartDateTime && $serverEndDateTime >= $userEndDateTime) {
                                $eventExists = true;
                            } elseif ($serverStartDateTime > $userStartDateTime && $serverEndDateTime <= $userEndDateTime) {
                                $eventExists = true;
                            } elseif ($userStartDateTime > $serverStartDateTime && $serverEndDateTime > $userStartDateTime) {
                                $eventExists = true;
                            } elseif ($userEndDateTime >= $serverStartDateTime && $serverEndDateTime > $userEndDateTime) {
                                $eventExists = true;
                            } elseif ($userStartDateTime < $serverStartDateTime && $serverStartDateTime < $userEndDateTime) {
                                $eventExists = true;
                            } elseif ($userStartDateTime < $serverEndDateTime && $serverEndDateTime < $userEndDateTime) {
                                $eventExists = true;
                            }
                        }
                        if ($eventExists) {
                            return response()->json(['success' => false, 'message' => 'The event is aleady exists,please try with another date,time or place.']);
                        }
                    }
                }
            }
            $userId = Auth::guard(getAuthGuard())->user()->id;
            if (isset($post['id'])) {
                $event = $this->event->find($post['id']);
                $event->updated_by = $userId;
            } else {
                $event = new $this->event;
                $event->status = "active";
                $event->user_id = $userId;
            }
            $event->banner_image = $post['banner_image'];
            $event->event_name = $post['event_name'];
            $event->keywords = $post['keywords'];
            $event->address1 = $post['address1'];
            $event->country_id = $post['country_id'];
            $event->state_id = $post['state_id'];
            $event->city = $post['city'];
            $event->zipcode = $post['zipcode'];
            $event->team1 = $post['team1'];
            $event->start_date = dbDateFormat($post['start_date']);
            $event->end_date = dbDateFormat($post['end_date']);
            $event->team2 = $post['team2'];
            $event->start_time = dbTimeFormat($post['start_time']);
            $event->end_time = dbTimeFormat($post['end_time']);
            $event->ticket_url = $post['ticket_url'];
            $event->description = $post['description'];
            $event->save();
            if (isset($post['old_image']) && ($event->banner_image != $post['old_image'] )) {
                unlinkImageFunction($post['old_image'], 'event');
                unlinkImageFunction($post['old_image'], 'event/thumb');
            }
            if (isset($post['id'])) {
                if (getAuthGuard() == "subadmin") {
                    $getUserType = $this->user->where('role', 'admin')->first();
                    sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'event_edit', $event->reference_id, $event->event_name, '', $event->id);
                } else {
                    sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'event_edit', $event->reference_id, $event->event_name, '', $event->id);
                }
                return response()->json(['success' => true, 'message' => 'Event updated successfully.']);
            } else {
                if (getAuthGuard() == "subadmin") {
                    $getUserType = $this->user->where('role', 'admin')->first();
                    sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'event_add', $event->reference_id, $event->event_name, '', $event->id);
                } else {
                    sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'event_add', $event->reference_id, $event->event_name, '', $event->id);
                }
                return response()->json(['success' => true, 'message' => 'Event created successfully.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Update event status
     * @param type $request
     * @return type
     */
    public function changeStatus($request) {
        try {
            $post = $request->all();
            $event_status = $this->event->find($post['id']);
            if (empty($event_status)) {
                return redirect()->back();
            }
            $event_status->status = $post['status'];
            $event_status->save();
            if (getAuthGuard() == "subadmin") {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'event_' . $post['status'], $event_status->reference_id, $event_status->event_name, '', $event_status->id);
            } else {
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'event_' . $post['status'], $event_status->reference_id, $event_status->event_name, '', $event_status->id);
            }
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Get event by id
     * @param type $id
     * @return type
     */
    public function getEventById($id) {
        return $this->event->find($id);
    }

}
