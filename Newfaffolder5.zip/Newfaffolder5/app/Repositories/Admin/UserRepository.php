<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use Auth;
use App\Models\Transactions;
use App\Models\TeamPlayer;
use App\Models\TeamStaff;
use Illuminate\Support\Facades\Session;

Class UserRepository {

    /**
     * Class Construct.
     * @param User $user
     * @param Transactions $transactions
     * @param TeamPlayer $teamPlayer
     * @param TeamStaff $teamStaff
     */
    public function __construct(User $user, Transactions $transactions, TeamPlayer $teamPlayer, TeamStaff $teamStaff) {
        $this->user = $user;
        $this->transactions = $transactions;
        $this->teamPlayer = $teamPlayer;
        $this->teamStaff = $teamStaff;
    }

    /**
     * Get All Users listing with search filter and pagination.
     * @param type $request
     * @return type
     */
    public function getAllUsers($request) {
        $userList = $this->user->where('role', '!=', 'admin')->where('role', '!=', 'subadmin');

        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $userList->orderBy('id', $request['orderBy']);
            } else {
                $userList->orderBy('updated_at', 'desc');
            }
        }
        /* text search by columns of admin list */
        if (!empty($request['columns'])) {
            $text = $request['columns'];
            $userList->where(function ($query) use ($text) {
                $query->orWhere('reference_id', 'like', '%' . $text . '%')
                        ->orWhere('full_name', 'like', '%' . $text . '%')
                        ->orWhere('email', 'like', '%' . $text . '%')
                        ->orWhere('phone_number', 'like', '%' . $text . '%')
                        ->orWhere('address_line_1', 'like', '%' . $text . '%');
            });
        }
        /* Filter active inactive */
        if (!empty($request['status'])) {
            $userList->where('status', $request['status']);
        }
        /* Filter by role */
        if (!empty($request['role'])) {
            $userList->where('role', $request['role']);
        }
        /* Filter from date to date */
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = startDateFormatServer($request['startDate']);
            $to = endDateFormatServer($request['endDate']);
            $userList->whereBetween('created_at', array($from, $to));
        }
        $rows = $userList->Paginate(getPaginatePage());
        if (!empty($rows)) {

            return $rows;
        }
    }

    /**
     * Get user by id
     * @param type $id
     * @return type
     */
    public function getUserById($id) {
        $user = $this->user->find($id);
        if (empty($user)) {
            return redirect()->back();
        }
        return $user;
    }

    /**
     * Save user
     * @param type $request
     * @return type
     */
    public function userSave($request) {
        try {
            $post = $request->all();
            $latLong = Session::get('latLong');
            Session::forget('latLong');
            $latLong = explode('&', $latLong);
            $post['latitude'] = !empty($latLong[0]) ? $latLong[0] : '37.0902';
            $post['longitude'] = !empty($latLong[1]) ? $latLong[1] : '-95.7129';
            $userId = Auth::guard(getAuthGuard())->user()->id;
            if (isset($post['id'])) {
                $user = $this->user->find($post['id']);
                $user->updated_by = $userId;
            } else {
                $user = new $this->user;
                $user->role = $post['role'];
                $user->email = $post['email'];
                $password = generateRandomString();
                $user->password = bcrypt($password);
                $user->signup_type = $post['signup_type'];
                $user->subscription_id = $post['plan_id'];
            }
            if ($post['role'] == 'player' || $post['role'] == 'coach') {
                $user->first_name = $post['first_name'];
                $user->last_name = $post['last_name'];
                $user->full_name = $post['first_name'] . ' ' . $post['last_name'];
            } else {
                $user->institute_type = $post['institute_type'];
                $user->full_name = $post['full_name'];
            }
            $user->phone_number = $post['phone_number'];
            $user->country_id = $post['country_id'];
            $user->state_id = $post['state_id'];
            $user->city = $post['city'];
            $user->zip_code = $post['zip_code'];
            $user->latitude = $post['latitude'];
            $user->longitude = $post['longitude'];
            $user->address_line_1 = $post['address_line_1'];
            $user->status = 'active';
            if ($user->save()) {
                $slug_name = make_slug($user->full_name, $user->id);
                $this->user->where('id', $user->id)->update(['slug' => $slug_name]);
                if (isset($post['id'])) {
                    if (getAuthGuard() == "subadmin") {
                        $getUserType = $this->user->where('role', 'admin')->first();
                        sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'users_edit', $user->reference_id, $user->full_name, '', $user->id);
                    } else {
                        sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'users_edit', $user->reference_id, $user->full_name, '', $user->id);
                    }
                    return response()->json(['success' => true, 'message' => 'User updated successfully.']);
                } else {
                    $data = array();
                    $data['request'] = 'user_signup_admin';
                    $data['email'] = $post['email'];
                    $data['password'] = $password;
                    $data['full_name'] = $user->full_name;
                    $data['subject'] = 'User Signup Information';
                    sendMail($data);
                    if (getAuthGuard() == "subadmin") {
                        $getUserType = $this->user->where('role', 'admin')->first();
                        sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'users_add', $user->reference_id, $user->full_name, '', $user->id);
                    } else {
                        sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'users_add', $user->reference_id, $user->full_name, '', $user->id);
                    }
                    return response()->json(['success' => true, 'message' => 'User created successfully.']);
                }
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Update user status.
     * @param type $request
     * @return type
     */
    public function changeStatus($request) {
        try {
            $post = $request->all();
            $user_status = $this->user->find($post['id']);
            if (empty($user_status)) {
                return redirect()->back();
            }
            $user_status->status = $post['status'];
            $user_status->save();
            if (getAuthGuard() == "subadmin") {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'users_' . $post['status'], $user_status->reference_id, $user_status->full_name, '', $user_status->id);
            } else {
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'users_' . $post['status'], $user_status->reference_id, $user_status->full_name, '', $user_status->id);
            }
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for profile update.
     * @param  array  $data
     * @return \App\User
     */
    public function updateProfile($request) {
        try {
            $post = $request->all();
            $latLong = Session::get('latLong');
            Session::forget('latLong');
            $latLong = explode('&', $latLong);
            $post['latitude'] = !empty($latLong[0]) ? $latLong[0] : '37.0902';
            $post['longitude'] = !empty($latLong[1]) ? $latLong[1] : '-95.7129';
            $user = $this->user->find($post['id']);
            $user->full_name = $post['full_name'];
            $user->email = $post['email'];
            $user->phone_number = $post['phone_number'];
            $user->country_id = $post['country_id'];
            $user->state_id = $post['state_id'];
            $user->city = $post['city'];
            $user->zip_code = $post['zip_code'];
            $user->latitude = $post['latitude'];
            $user->longitude = $post['longitude'];
            $user->address_line_1 = $post['address_line_1'];
            if ($user->save()) {
                return response()->json(['success' => true, 'message' => 'Profile updated successfully.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * change password.
     * @param  \Illuminate\Http\Request  $requeste
     * @return \Illuminate\Http\Response
     */
    public function updatePassword($request) {

        try {
            $post = $request->all();
            $user = $this->user->find($post['id']);
            if (!\Hash::check($post['current_password'], $user->password)) {
                return json_encode(array('success' => false, 'message' => 'Current password does not match.'));
            } else {
                $user->update(array('password' => bcrypt($request['new_password'])));
            }
            return json_encode(array('success' => true, 'message' => 'Password changed successfully.'));
        } catch (\Exception $e) {
            return json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
    }

    /**
     * Get user transactions
     * @param type $post
     * @return type
     */
    public function getUserTransactions($post) {
        $result = $this->transactions->with('userSubscription', 'transactionUser')
                        ->where('user_id', $post['id'])
                        ->orderBy('id', 'desc')->paginate(getPaginatePage());
        return $result;
    }

    /**
     * Get team player by user id
     * @param type $userId
     * @return type
     */
    public function getTeamPlayerById($userId) {
        return $this->teamPlayer->where('user_id', $userId)->get();
    }

    /**
     * Get team staff by user id.
     * @param type $userId
     * @return type
     */
    public function getTeamStaffById($userId) {
        return $this->teamStaff->where('user_id', $userId)->get();
    }

    /**
     * send invoice to mail of user.
     * @param type $transactionId
     * @return type
     */
    public function sendInvoiceData($transactionId) {
        $data = [];
        $transactionData = $this->transactions->where('id', $transactionId)->first();
        $data['name'] = getUserById($transactionData->user_id, 'full_name');
        $data['user_image'] = checkUserImage(getUserById($transactionData->user_id, 'profile_image'), getUserById($transactionData->user_id, 'role'));
        $data['email'] = getUserById($transactionData->user_id, 'email');
        $data['transaction_id'] = $transactionData->transaction_id;
        $data['signup_type'] = ($transactionData->transactionUser['signup_type']) ? ucfirst($transactionData->transactionUser['signup_type']) : '-';
        $data['title'] = getSubscriptionDetails($transactionData->subscription_id, 'title');
        $data['start_date'] = sameDate($transactionData->start_date);
        $data['end_date'] = sameDate($transactionData->end_date);
        $data['amount'] = ($transactionData->amount != '') ? '$ ' . $transactionData->amount : '-';
        $data['request'] = 'user_invoice_mail';
        $data['subject'] = 'User invoice mail';
        $result = sendMail($data);
        return $result;
    }

}
