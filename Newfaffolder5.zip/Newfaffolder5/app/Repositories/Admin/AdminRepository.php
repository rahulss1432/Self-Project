<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use Auth;
use App\Models\Menus;
use App\Models\Notification;
use Illuminate\Support\Facades\Session;

Class AdminRepository {

    /**
     * Class Construct.
     * @param User $user
     * @param Menus $menus
     * @param Notification $notification
     */
    public function __construct(User $user, Menus $menus, Notification $notification) {
        $this->user = $user;
        $this->menus = $menus;
        $this->notification = $notification;
    }

    /**
     * Get all subadmins listing include search filter and pagination.
     * @param type $request
     * @return type
     */
    public function getAllAdmins($request) {
        $adminList = $this->user->where('role', 'subadmin');
        /* check order of admin by new ,old and recently updated */
        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $adminList->orderBy('id', $request['orderBy']);
            } else {
                $adminList->orderBy('updated_at', 'desc');
            }
        }
        /* text search by columns of admin list */
        if (!empty($request['columns'])) {
            $text = $request['columns'];
            $adminList->where(function ($query) use ($text) {
                $query->orWhere('reference_id', 'like', '%' . $text . '%')
                        ->orWhere('full_name', 'like', '%' . $text . '%')
                        ->orWhere('email', 'like', '%' . $text . '%')
                        ->orWhere('phone_number', 'like', '%' . $text . '%')
                        ->orWhere('address_line_1', 'like', '%' . $text . '%');
            });
        }
        /* Filter active inactive */
        if (!empty($request['status'])) {
            $adminList->where('status', $request['status']);
        }
        /* Filter from date to date */
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = startDateFormatServer($request['startDate']);
            $to = endDateFormatServer($request['endDate']);
            $adminList->whereBetween('created_at', array($from, $to));
        }
        $rows = $adminList->Paginate(getPaginatePage());
        if (!empty($rows)) {
            return $rows;
        }
    }

    /**
     * Save Subadmins
     * @param type $request
     * @return type
     */
    public function save($request) {
        try {
            $post = $request->all();
            $latLong = Session::get('latLong');
            Session::forget('latLong');
            $latLong = explode('&', $latLong);
            $post['latitude'] = !empty($latLong[0]) ? $latLong[0] : '37.0902';
            $post['longitude'] = !empty($latLong[1]) ? $latLong[1] : '-95.7129';
            $userId = Auth::guard(getAuthGuard())->user()->id;
            if (isset($post['id'])) {
                $admin_user = $this->user->find($post['id']);
            } else {
                $admin_user = new $this->user;
            }
            $password = generateRandomString();
            $admin_user->role = 'subadmin';
            $admin_user->created_by = $userId;
            $admin_user->full_name = $post['full_name'];
            $admin_user->email = $post['email'];
            $admin_user->password = bcrypt($password);
            $admin_user->phone_number = $post['phone_number'];
            $admin_user->country_id = $post['country_id'];
            $admin_user->state_id = $post['state_id'];
            $admin_user->city = $post['city'];
            $admin_user->zip_code = $post['zip_code'];
            $admin_user->latitude = $post['latitude'];
            $admin_user->longitude = $post['longitude'];
            $admin_user->address_line_1 = $post['address_line_1'];
            $admin_user->status = 'active';
            $admin_user->save();
            $slug_name = make_slug($post['full_name'], $admin_user->id);
            User::where('id', $admin_user->id)->update(['slug' => $slug_name]);
            if (isset($post['id'])) {
                return response()->json(['success' => true, 'message' => 'Profile updated successfully.']);
            } else {
                $data = array();
                $data['request'] = 'user_signup_admin';
                $data['email'] = $post['email'];
                $data['password'] = $password;
                $data['full_name'] = $post['full_name'];
                $data['subject'] = 'Account Registration';
                sendMail($data);
                return response()->json(['success' => true, 'message' => 'Profile created successfully.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Admin view page.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function adminEdit($id) {
        try {
            $adminView = $this->user->where(['id' => $id, 'role' => 'subadmin'])->first();
            if (empty($adminView)) {
                return redirect()->back();
            }
            return view('admin::manage-admin.edit', compact('adminView'));
        } catch (\Exception $e) {
            return json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
    }

    /**
     * Admin update status.
     * @return \Illuminate\Http\Response
     */
    function updateStatus($request) {
        try {
            $post = $request->all();
            $user_status = $this->user->find($post['id']);
            if (empty($user_status)) {
                return redirect()->back();
            }
            $user_status->status = $post['status'];
            $user_status->save();
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Admin assign page.
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function adminAssign($id) {
        try {
            $adminAssign = $this->user->where(['id' => $id, 'role' => 'subadmin'])->first();
            if (empty($adminAssign)) {
                return redirect()->back();
            }
            return view('admin::manage-admin.assign', compact('adminAssign'));
        } catch (\Exception $e) {
            return json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
    }

    /**
     * Assign permission
     * @param type $request
     * @return type
     */
    public function adminAssignPermission($request) {
        try {
            $user = $this->user->find($request->user_id);
            $user->menus()->detach();
            if (empty($request['menu'])) {
                return json_encode(array('success' => false, 'message' => 'Please check any module first.'));
            }
            foreach ($request['menu'] as $menu) {
                $user->menus()->attach($this->menus->where('value', $menu)->first());
            }
            return response()->json(['success' => true, 'message' => 'Modules assigned successfully.']);
        } catch (\Exception $e) {
            return json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
    }

    /**
     * Admin notification list on modal.
     * @return type
     */
    public function getNotificationList() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        if (getAuthGuard() == "subadmin") {
            $getUserType = $this->user->where('role', 'admin')->first();
            $subAdminMenu = getSubAdminSideMenuId($userId);
            $notificationList = $this->notification->where(['to_id' => $getUserType->id])->where('type', 'faf')->whereIn('menu_id', $subAdminMenu)->take(5)->orderBy('id', 'desc')->get();
        } else {
            $notificationList = $this->notification->where(['to_id' => $userId, 'type' => 'faf'])->take(5)->orderBy('id', 'desc')->get();
        }
        return $notificationList;
    }

    /**
     * Admin notification list on view.
     * @return type
     */
    public function getAllNotificationList() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        if (getAuthGuard() == "subadmin") {
            $getUserType = $this->user->where('role', 'admin')->first();
            $subAdminMenu = getSubAdminSideMenuId($userId);
            $notificationList = $this->notification->where(['to_id' => $getUserType->id])->where('type', 'faf')->whereIn('menu_id', $subAdminMenu)->orderBy('id', 'desc')->paginate(10);
        } else {
            $notificationList = $this->notification->where(['to_id' => $userId, 'type' => 'faf'])->orderBy('id', 'desc')->paginate(10);
        }
        return $notificationList;
    }

}
