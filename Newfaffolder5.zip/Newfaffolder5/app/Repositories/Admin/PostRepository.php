<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Post;
use Auth;
use App\Models\UserMedia;
use App\Models\UserPostAction;
use App\User;

Class PostRepository {

    /**
     *  Class Construct.
     * @param Post $post
     * @param UserMedia $userMedia
     * @param UserPostAction $postAction
     * @param User $user
     */
    public function __construct(Post $post, UserMedia $userMedia, UserPostAction $postAction, User $user) {
        $this->post = $post;
        $this->userMedia = $userMedia;
        $this->postAction = $postAction;
        $this->user = $user;
    }

    /**
     *  function using for get all post list
     * @param type $request
     * @return type
     */
    public function getPostList($request) {
        $query = $this->post->select(['posts.*', 'users.full_name'])
                ->join('users', 'users.id', '=', 'posts.user_id');
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = startDateFormatServer($request['startDate']);
            $to = endDateFormatServer($request['endDate']);
            $query->whereBetween('posts.created_at', array($from, $to));
        }
        if (!empty($request['status']) && isset($request['status'])) {
            $query->where('posts.status', $request['status']);
        }
        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $query->orderBy('posts.id', $request['orderBy']);
            } else {
                $query->orderBy('posts.updated_at', 'desc');
            }
        }
        if (!empty($request['search_input']) && isset($request['search_input'])) {
            $query->where('posts.id', 'like', '%' . $request['search_input'] . '%')
                    ->orWhere('users.full_name', 'like', '%' . $request['search_input'] . '%');
        }
        return $query->paginate(getPaginatePage());
    }

    /**
     * function using for  update post status
     * @param type $request
     * @return type
     */
    public function updateStatus($request) {
        try {
            $post = $request->all();
            $media = $this->post->find($post['id']);
            if (empty($media)) {
                return redirect()->back();
            }
            $media->status = $post['status'];
            $media->save();
            if (getAuthGuard() == "subadmin") {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'post_' . $post['status'], $media->reference_id, '', '', $media->id);
            } else {
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'post_' . $post['status'], $media->reference_id, '', '', $media->id);
            }
            $this->userMedia->where(['post_id' => $media->id])->update(['status' => $media->status]);
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * function using for post list by id
     * @param type $id
     * @return type
     */
    public function getPostById($id) {
        $result = $this->post->where(['id' => $id])->first();
        return $result;
    }

    /**
     * function using for post comment list
     * @param type $id
     * @param type $type
     * @return type
     */
    public function getPostEventList($id, $type) {
        $result = $this->postAction->where(['post_id' => $id, 'type' => $type])->get();
        return $result;
    }

}
