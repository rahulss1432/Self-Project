<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Subscriptions;
use App\Models\SubscriptionDescription;
use Illuminate\Support\Facades\Auth;
use App\User;

Class SubscriptionsRepository {

    /**
     * Class Construct.
     * @param Subscriptions $subscriptions
     * @param SubscriptionDescription $subDescription
     * @param User $user
     */
    public function __construct(Subscriptions $subscriptions, SubscriptionDescription $subDescription, User $user) {
        $this->adminSubscriptions = $subscriptions;
        $this->subscriptionDescription = $subDescription;
        $this->user = $user;
    }

    /**
     * function using for Submit subscription.
     * @param type $request
     * @return type
     */
    public function saveSubscriptions($request) {
        try {
            $post = $request->all();
            $model = new $this->adminSubscriptions;
            $model->title = $post['name'];
            $model->renewal_cycle = $post['renewal_cycle'];
            $model->amount = $post['amount'];
            $model->plan_space = $post['plan_space'];
            $model->status = 'inactive';
            if ($model->save()) {
                if (!empty($post['description'])) {
                    foreach ($post['description'] as $description) {
                        $descriptionModel = new $this->subscriptionDescription;
                        $descriptionModel->subscription_id = $model->id;
                        $descriptionModel->description = $description;
                        $descriptionModel->save();
                    }
                }
            }
            if (getAuthGuard() == "subadmin") {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'subscription_add', $model->reference_id, $model->title, '', $model->id);
            } else {
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'subscription_add', $model->reference_id, $model->title, '', $model->id);
            }
            return response()->json(['success' => true, 'message' => 'Subscription submited successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * function using for Update subscription.
     * @param type $request
     * @return type
     */
    public function updateSubscriptions($request) {
        try {
            $post = $request->all();
            $model = $this->adminSubscriptions->where(['id' => $post['id']])->first();
            $planSubscriberCount = $this->user->where('subscription_id', $post['id'])->count();
            if (($planSubscriberCount > 0) && ($model->plan_space != $post['plan_space'])) {
                return response()->json(['success' => false, 'message' => 'You can not change the plan space because the plan has been subscribed by users.']);
            }
            if (!empty($model)) {
                $model->title = $post['name'];
                $model->renewal_cycle = $post['renewal_cycle'];
                $model->amount = $post['amount'];
                $model->plan_space = $post['plan_space'];
                $model->updated_by = Auth::guard(getAuthGuard())->user()->id;
                if ($model->save()) {
                    if (!empty($post['description'])) {
                        $this->subscriptionDescription->where(['subscription_id' => $post['id']])->delete();
                        foreach ($post['description'] as $description) {
                            $descriptionModel = new $this->subscriptionDescription;
                            $descriptionModel->subscription_id = $model->id;
                            $descriptionModel->description = $description;
                            $descriptionModel->save();
                        }
                    }
                }
                if (getAuthGuard() == "subadmin") {
                    $getUserType = $this->user->where('role', 'admin')->first();
                    sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'subscription_edit', $model->reference_id, $model->title, '', $model->id);
                } else {
                    sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'subscription_edit', $model->reference_id, $model->title, '', $model->id);
                }
                return response()->json(['success' => true, 'message' => 'Subscription updated successfully.']);
            } else {
                return response()->json(['success' => false, 'message' => 'Please try again']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * function using for get all subscription.
     * @param type $request
     * @return type
     */
    public function getAllSubscriptions($request) {
        $query = $this->adminSubscriptions->select('subscriptions.*');
        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $query->orderBy('id', $request['orderBy']);
            } else {
                $query->orderBy('updated_at', 'desc');
            }
        }
        if (!empty($request['search_input']) && isset($request['search_input'])) {
            $query->where('title', 'like', '%' . $request['search_input'] . '%')
                    ->orWhere('amount', 'like', '%' . $request['search_input'] . '%')
                    ->orWhere('renewal_cycle', 'like', '%' . $request['search_input'] . '%')
                    ->orWhere('reference_id', 'like', '%' . $request['search_input'] . '%');
        }
        if (!empty($request['status']) && isset($request['status'])) {
            $query->where('status', $request['status']);
        }
        if (!empty($request['renewal_cycle']) && isset($request['renewal_cycle'])) {
            $query->where('renewal_cycle', $request['renewal_cycle']);
        }
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = startDateFormatServer($request['startDate']);
            $to = endDateFormatServer($request['endDate']);
            $query->whereBetween('created_at', array($from, $to));
        }
        return $query->paginate(getPaginatePage());
    }

    /**
     * function using for get subscription by id.
     * @param type $id
     * @return type
     */
    public function geSubscriptionsById($id) {
        return $this->adminSubscriptions->find($id);
    }

    /**
     * Admin update status.
     * @return \Illuminate\Http\Response
     */
    function updateStatus($request) {
        try {
            $post = $request->all();
            $user_status = $this->adminSubscriptions->find($post['id']);
            if (empty($user_status)) {
                return redirect()->back();
            }
            $user_status->status = $post['status'];
            $user_status->save();
            if (getAuthGuard() == "subadmin") {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'subscription_' . $post['status'], $user_status->reference_id, $user_status->title, '', $user_status->id);
            } else {
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'subscription_' . $post['status'], $user_status->reference_id, $user_status->title, '', $user_status->id);
            }
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
