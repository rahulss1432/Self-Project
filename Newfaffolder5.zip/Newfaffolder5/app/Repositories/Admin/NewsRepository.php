<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\News;
use App\Models\NewsImages;
use Auth;
use Illuminate\Support\Facades\File;

Class NewsRepository {

    /**
     * class construct.
     * @param News $news
     * @param NewsImages $newsImages
     */
    public function __construct(News $news, NewsImages $newsImages) {
        $this->news = $news;
        $this->newsImages = $newsImages;
    }

    /**
     * Praveen: Get All News Data.
     * @param type $request
     * @return type
     */
    public function getAllNewsData($request) {
        $newsList = $this->news->select('news.*', 'users.full_name', 'users.reference_id as user_reference_id')->join('users', 'users.id', '=', 'news.created_by');
        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $newsList->orderBy('news.id', $request['orderBy']);
            } else {
                $newsList->orderBy('news.updated_at', 'desc');
            }
        }
        /* search with news reference id and title */
        if (!empty($request['search_input']) && isset($request['search_input'])) {
            $newsList->where('news.reference_id', 'like', '%' . $request['search_input'] . '%')
                    ->orWhere('news.title', 'like', '%' . $request['search_input'] . '%')
                    ->orWhere("users.full_name", 'LIKE', '%' . $request['search_input'] . '%')
                    ->orWhere("users.reference_id", 'LIKE', '%' . $request['search_input'] . '%');
        }
        if (!empty($request['status']) && isset($request['status'])) {
            $newsList->where('news.status', $request['status']);
        }
        /* media filter all media and no media */
        if (!empty($request['includes']) && isset($request['includes'])) {
            if ($request['includes'] != 'all') {
                $newsList->where('news.type', $request['includes']);
            }
        }
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = startDateFormatServer($request['startDate']);
            $to = endDateFormatServer($request['endDate']);
            $newsList->whereBetween('news.created_at', array($from, $to));
        }
        return $newsList->paginate(getPaginatePage());
    }

    /**
     * Save news
     * @param type $request
     * @return type
     */
    public function save($request) {
        try {
            DB::beginTransaction();
            $post = $request->all();
            $userId = Auth::guard(getAuthGuard())->user()->id;
            if (isset($post['id'])) {
                $newsData = $this->news->find($post['id']);
            } else {
                $newsData = new $this->news;
            }
            $newsData->created_by = $userId;
            $newsData->updated_by = $userId;
            $newsData->title = ($post['title']) ? $post['title'] : '';
            $newsData->news_description = $post['news_description'];
            $newsData->status = 'active';
            $newsData->type = (!empty($post['hdnImageName'])) ? 'yes' : 'no';
            $newsData->save();
            if (isset($post['id'])) {
                DB::commit();
                return response()->json(['success' => true, 'message' => 'News updated successfully.']);
            } else {
                if (!empty($post['hdnImageName'])) {
                    $imagePath = public_path() . '/uploads/news';
                    $imageThumbPath = public_path() . '/uploads/news/thumb';
                    $tempPath = public_path() . '/uploads/temp';
                    if (!is_dir($imagePath)) {
                        File::makeDirectory($imagePath, $mode = 0777, true, true);
                    }
                    if (!is_dir($imageThumbPath)) {
                        File::makeDirectory($imageThumbPath, $mode = 0777, true, true);
                    }
                    foreach ($post['hdnImageName'] as $key => $image) {
                        $imageModel = new $this->newsImages;
                        $imageModel->news_id = $newsData->id;
                        $imageModel->image = $image;
                        $imageModel->order_by_image = (!empty($post['mediafile']) && $post['mediafile'] == $image) ? 1 : 0;
                        $imageModel->file_type = $post['fileType'][$key];
                        $imageModel->save();

                        $changeImageName = explode('.', $image);
                        $oldVideo = $tempPath . '/' . $changeImageName[0] . '.mp4';
                        $newVideo = $imagePath . '/' . $changeImageName[0] . '.mp4';
                        $oldImage = $tempPath . '/' . $image;
                        $newImage = $imagePath . '/' . $image;
                        $thumboldImage = $tempPath . '/thumb/' . $image;
                        $thumbNewImage = $imagePath . '/thumb/' . $image;

                        if (!empty($oldVideo) && file_exists($oldVideo)) {
                            copy($oldVideo, $newVideo);
                            unlink($oldVideo);
                        }
                        if (!empty($oldImage) && file_exists($oldImage)) {
                            copy($oldImage, $newImage);
                            unlink($oldImage);
                        }
                        if (!empty($thumboldImage) && file_exists($thumboldImage)) {
                            copy($thumboldImage, $thumbNewImage);
                            unlink($thumboldImage);
                        }
                    }
                }
                DB::commit();
                if (getAuthGuard() == "subadmin") {
                    $getUserType = $this->user->where('role', 'admin')->first();
                    sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'news_add', $newsData->reference_id, '', '', $newsData->id);
                } else {
                    sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'news_add', $newsData->reference_id, '', '', $newsData->id);
                }
                return response()->json(['success' => true, 'message' => 'News created successfully.']);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * get selected news data by id
     * @param type $id
     * @return type
     */
    public function getNewsById($id) {
        return $this->news->find($id);
    }

    /**
     * update news
     * @param type $request
     * @return type
     */
    public function update($request) {
        try {
            DB::beginTransaction();
            $post = $request->all();
            $userId = Auth::guard(getAuthGuard())->user()->id;
            if (isset($post['id'])) {
                $newsData = $this->news->find($post['id']);
            }
            $newsData->created_by = $userId;
            $newsData->updated_by = $userId;
            $newsData->title = $post['title'];
            $newsData->news_description = $post['news_description'];
            $newsData->status = 'active';
            $newsData->type = (!empty($post['hdnImageName'])) ? 'yes' : 'no';
            $newsData->save();

//          remove upload image and old record in database
            $uploadedImage = $this->newsImages->where('news_id', $post['id'])->get();
            $uploadedImageArray = (isset($post['hdnImageName'])) ? $post['hdnImageName'] : [];
            if (!empty($uploadedImage)) {
                foreach ($uploadedImage as $getuploadImage) {
                    if (!in_array($getuploadImage->image, $uploadedImageArray)) {
                        removeDeletedImages($getuploadImage->image, 'news');
                    }
                    $getuploadImage->delete();
                }
            }
            if (!empty($post['hdnImageName'])) {
                $imagePath = public_path() . '/uploads/news';
                $tempPath = public_path() . '/uploads/temp';
                if (!is_dir($imagePath)) {
                    File::makeDirectory($imagePath, $mode = 0777, true, true);
                }
                foreach ($post['hdnImageName'] as $key => $image) {
                    $imageModel = new $this->newsImages;
                    $imageModel->news_id = $newsData->id;
                    $imageModel->image = $image;
                    $imageModel->order_by_image = (!empty($post['mediafile']) && $post['mediafile'] == $image) ? 1 : 0;
                    $imageModel->file_type = $post['fileType'][$key];
                    $imageModel->save();
                    copyImages($image, 'news');
                }
            }
            DB::commit();
            if (getAuthGuard() == "subadmin") {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'news_edit', $newsData->reference_id, '', '', $newsData->id);
            } else {
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'news_edit', $newsData->reference_id, '', '', $newsData->id);
            }
            return response()->json(['success' => true, 'message' => 'News updated successfully.']);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * using for change status
     * @param type $request
     * @return type
     */
    public function updateStatus($request) {
        try {
            $post = $request->all();
            $user_status = $this->news->find($post['id']);
            if (empty($user_status)) {
                return redirect()->back();
            }
            $user_status->status = $post['status'];
            $user_status->save();
            if (getAuthGuard() == "subadmin") {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'news_' . $post['status'], $user_status->reference_id, '', '', $user_status->id);
            } else {
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'news_' . $post['status'], $user_status->reference_id, '', '', $user_status->id);
            }
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
