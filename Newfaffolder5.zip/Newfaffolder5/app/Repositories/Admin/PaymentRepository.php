<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use Auth;
use App\Models\Transactions;
use App\Models\TeamPlayer;
use App\Models\TeamStaff;

Class PaymentRepository {

    /**
     * Class Construct.
     * @param User $user
     * @param Transactions $transactions
     */
    public function __construct(User $user, Transactions $transactions) {
        $this->user = $user;
        $this->transactions = $transactions;
    }

    /**
     * paymnet list and searching
     * @param type $request
     * @return type
     */
    public function getTransactionList($request) {
        $paymentList = $this->transactions->select(['transactions.*', 'users.full_name', 'subscriptions.renewal_cycle', 'users.signup_type'])
                ->join('users', 'users.id', '=', 'transactions.user_id')
                ->join('subscriptions', 'subscriptions.id', '=', 'transactions.subscription_id');
        /* search by order */
        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $paymentList->orderBy('id', $request['orderBy']);
            } else {
                $paymentList->orderBy('transactions.updated_at', 'desc');
            }
        }
        /* text search by columns of payment list */
        if (!empty($request['columns'])) {
            $text = $request['columns'];
            $paymentList->where(function ($query) use ($text) {
                $query->orWhere('transactions.reference_id', 'like', '%' . $text . '%')
                        ->orWhere('users.full_name', 'like', '%' . $text . '%');
            });
        }
        /* Filter plan wise */
        if (!empty($request['plan']) && $request['plan'] != 'all') {
            $paymentList->where('subscriptions.renewal_cycle', $request['plan']);
        }
        /* Filter payment mode wise */
        if (!empty($request['mode']) && $request['mode'] != 'all') {
            $paymentList->where('users.signup_type', $request['mode']);
        }

        /* Filter from date to date */
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = startDateFormatServer($request['startDate']);
            $to = endDateFormatServer($request['endDate']);
            $paymentList->whereBetween('transactions.created_at', array($from, $to));
        }
        return $paymentList->Paginate(getPaginatePage());
    }

}
