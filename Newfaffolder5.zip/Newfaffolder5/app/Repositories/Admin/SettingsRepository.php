<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Settings;
use App\Models\Testimonials;
use Auth;
use File;
use App\User;

Class SettingsRepository {

    /**
     * Class Construct.
     * @param Settings $settings
     * @param Testimonials $testimonial
     * @param User $user
     */
    public function __construct(Settings $settings, Testimonials $testimonial, User $user) {
        $this->adminSettings = $settings;
        $this->adminTestimonial = $testimonial;
        $this->user = $user;
    }

    /**
     * function using for get about and Terms value .
     * @param type $title
     * @return type
     */
    public function getSettingsValue($title) {
        $value = $this->adminSettings->where(['title' => $title])->first();
        return $value->value;
    }

    /**
     * function using for Update About us And terms service .
     * @param type $request
     * @return type
     */
    public function updateAboutAndTerms($request) {
        try {
            $post = $request->all();
            $model = $this->adminSettings->where(['title' => $post['title']])->first();
            $model->value = $post['content'];
            $model->save();
            if (getAuthGuard() == "subadmin") {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'cms_' . $post['title'], '', '', '', '');
            } else {
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'cms_' . $post['title'], '', '', '', '');
            }
            $message = ($post['title'] == 'about_us') ? 'About Us' : 'Terms of service';
            return response()->json(['success' => true, 'message' => $message . '  updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * function using for Update Contact us.
     * @param type $request
     * @return type
     */
    public function updateContacts($request) {
        try {
            $filedNameArray = array_keys($request->all());
            foreach ($filedNameArray as $filedName) {
                $model = $this->adminSettings->where(['title' => $filedName])->first();
                if (!empty($model)) {
                    $model->value = $request[$filedName];
                    $model->save();
                }
            }
            if (getAuthGuard() == "subadmin") {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'cms_contact', '', '', '', '');
            } else {
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'cms_contact', '', '', '', '');
            }
            return response()->json(['success' => true, 'message' => 'Contact us updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * function using for Save Testimonial.
     * @param type $request
     * @return type
     */
    public function saveTestimonial($request) {
        try {
            $post = $request->all();
            $model = new $this->adminTestimonial;
            $model->name = $post['name'];
            $model->content = $request['content'];
            if ($request->hasFile('image')) {
                $imagePath = public_path() . '/uploads/cms/';
                if (!is_dir($imagePath)) {
                    File::makeDirectory($imagePath, $mode = 0777, true, true);
                }
                $photo = $request->file('image');
                $imageName = time() . '.' . $photo->getClientOriginalExtension();
                $request->image->move($imagePath, $imageName);
                $model->image = $imageName;
            }
            $model->save();
            if (getAuthGuard() == "subadmin") {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'cms_testimonial', '', '', '', '');
            } else {
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'cms_testimonial', '', '', '', '');
            }
            return response()->json(['success' => true, 'message' => 'Contact us updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * function using for Get All Testimonial List.
     * @return type
     */
    public function getTestimonialList() {
        $list = $this->adminTestimonial->paginate(10);
        return $list;
    }

    /**
     * function using for remove testimonial.
     * @param type $id
     * @return type
     */
    public function removeTestimonial($id) {
        try {
            $query = $this->adminTestimonial->where(['id' => $id])->delete();
            return response()->json(['success' => true, 'message' => 'Remove testimonial successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * function using for get update testimonial data.
     * @param type $id
     * @return boolean
     */
    public function getUpdateTestimonial($id) {
        try {
            $result = $this->adminTestimonial->find($id);
            return $result;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * function using for update Testimponial.
     * @param type $request
     * @return type
     */
    public function updateTestimonial($request) {
        try {
            $post = $request->all();
            $model = $this->adminTestimonial->find($post['id']);
            $model->name = $post['name'];
            $model->content = $post['content'];
            if ($request->hasFile('image')) {
                $imagePath = public_path() . '/uploads/cms/';
                if (!is_dir($imagePath)) {
                    File::makeDirectory($imagePath, $mode = 0777, true, true);
                }
                $photo = $request->file('image');
                $imageName = time() . '.' . $photo->getClientOriginalExtension();
                $request->image->move($imagePath, $imageName);
                $model->image = $imageName;
            }
            $model->save();
            return response()->json(['success' => true, 'message' => 'Contact us updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
