<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Models\Job;
use App\Models\Event;
use App\Models\UserMedia;
use App\Models\Post;

Class DashboardRepository {

    /**
     * Class Construct.
     * @param User $user
     * @param Job $jobs
     * @param Event $event
     * @param UserMedia $usermedia
     * @param Post $post
     */
    public function __construct(User $user, Job $jobs, Event $event, UserMedia $usermedia, Post $post) {
        $this->user = $user;
        $this->job = $jobs;
        $this->event = $event;
        $this->usermedia = $usermedia;
        $this->post = $post;
    }

    /**
     * Get all dashboard data.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        try {
            return view('admin::dashboard.index');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /**
     * show dashboard data
     * @param type $request
     * @return type
     */
    public function getdashboardData($request) {
        $userMonth = array();
        $months = array();
        for ($i = 1; $i <= 12; $i++) {
            $month = $i;
            if ($request['type'] == 'members' && $request['year']) {
                $q1 = $this->user->where('role', '!=', 'admin')->where('role', '!=', 'subadmin')
                                ->whereYear('created_at', '=', $request['year'])
                                ->whereMonth('created_at', '=', $month)->get();
                $userMonth[$i] = count($q1);
            }
            if ($request['type'] == 'countries' && $request['year']) {
                $q1 = $this->user->where('role', '!=', 'admin')->where('role', '!=', 'subadmin')->groupBy('country_id')
                                ->whereYear('created_at', '=', $request['year'])
                                ->whereMonth('created_at', '=', $month)->get();
                $userMonth[$i] = count($q1);
            }
            if ($request['type'] == 'team' && $request['year']) {
                $q1 = $this->user->where('role', '=', 'team')
                                ->whereYear('created_at', '=', $request['year'])
                                ->whereMonth('created_at', '=', $month)->get();
                $userMonth[$i] = count($q1);
            }
            if ($request['type'] == 'staff' && $request['year']) {

                $q1 = $this->user->where('role', '=', 'coach')
                                ->whereYear('created_at', '=', $request['year'])
                                ->whereMonth('created_at', '=', $month)->get();
                $userMonth[$i] = count($q1);
            }
            if ($request['type'] == 'players' && $request['year']) {
                $q1 = $this->user->where('role', '=', 'player')
                                ->whereYear('created_at', '=', $request['year'])
                                ->whereMonth('created_at', '=', $month)->get();
                $userMonth[$i] = count($q1);
            }
            if ($request['type'] == 'jobs' && $request['year']) {
                $q1 = $this->job->where('status', '=', 'open')
                                ->whereYear('created_at', '=', $request['year'])
                                ->whereMonth('created_at', '=', $month)->get();
                $userMonth[$i] = count($q1);
            }
            if ($request['type'] == 'events' && $request['year']) {
                $q1 = $this->event->where('status', '=', 'active')
                                ->whereYear('created_at', '=', $request['year'])
                                ->whereMonth('created_at', '=', $month)->get();
                $userMonth[$i] = count($q1);
            }
            if ($request['type'] == 'videos' && $request['year']) {
                $q1 = $this->usermedia->where('media_type', '=', 'video')
                                ->whereYear('created_at', '=', $request['year'])
                                ->whereMonth('created_at', '=', $month)->get();
                $userMonth[$i] = count($q1);
            }
            if ($request['type'] == 'images' && $request['year']) {
                $q1 = $this->usermedia->where('media_type', '=', 'image')
                                ->whereYear('created_at', '=', $request['year'])
                                ->whereMonth('created_at', '=', $month)->get();
                $userMonth[$i] = count($q1);
            }
            if ($request['type'] == 'posts' && $request['year']) {
                $q1 = $this->post->where('status', '=', 'active')
                                ->whereYear('created_at', '=', $request['year'])
                                ->whereMonth('created_at', '=', $month)->get();
                $userMonth[$i] = count($q1);
            }
        }
        return $userMonth;
    }

}
