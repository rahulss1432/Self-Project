<?php

namespace App\Repositories;

use Illuminate\Http\Request;
use App\User;
use App\Models\Subscriptions;
use App\Models\Transactions;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Validator;
use Cartalyst\Stripe\Laravel\Facades\Stripe;
use Illuminate\Support\Facades\Input;
use Stripe\Error\Card;
use App\Repositories\UserRepository;
use App\Models\PaymentNotification;
use App\Models\PaymentSource;
Class StripeRepository {

    /**
     * Class Construct.
     *
     * @param  array  $data
     * @return \App\User
     */
    public function __construct(User $user, Transactions $transactions, UserRepository $userRepo, PaymentNotification $paymentNotification, PaymentSource $paymentSource) {
        $this->user = $user;
        $this->transaction = $transactions;
        $this->userRepo = $userRepo;
        $this->paymentNotification = $paymentNotification;
        $this->paymentSource = $paymentSource;        
    }

    /**
     * stripe authentication.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function stripeAuthentication($request) {
        $validator = Validator::make($request->all(), [
                    'card_no' => 'required',
                    'ccExpiryMonth' => 'required',
                    'ccExpiryYear' => 'required',
                    'cvvNumber' => 'required',
        ]);
        if ($validator->passes()) {
            try {
                $userId = Auth::guard(getAuthGuard())->user()->id;
                $email = Auth::guard(getAuthGuard())->user()->email;
                $role = getUserById($userId, 'role');
                $input = $request->all();
                $getStartDate = getUserById($userId, 'start_date');
                $getEndDate = getUserById($userId, 'end_date');
                // first time add 14 days trial period + subscription days
                if (empty($getStartDate) || empty($getEndDate)) {
                    $start_date = Carbon::today();
                    $end_date = Carbon::today()->addDay(getSetting(), 'day');
                } else {  // second time add only subscription days  (renew case)
                    $start_date = $getStartDate;
                    $end_date = $getEndDate;
                }
                $input = array_except($input, array('_token'));
                $stripe = Stripe::make(env("STRIPE_SECRET_KEY"));
//            $stripe = Stripe::setApiKey(env("STRIPE_SECRET_KEY"));            
                $token = $stripe->tokens()->create([
                    'card' => [
                        'number' => $request->get('card_no'),
                        'exp_month' => $request->get('ccExpiryMonth'),
                        'exp_year' => $request->get('ccExpiryYear'),
                        'cvc' => $request->get('cvvNumber'),
                    ],
                ]);
                if (!isset($token['id'])) {
                    return response()->json(['success' => false, 'message' => 'The Stripe Token was not generated correctly']);
                }
                $customer = $stripe->customers()->create([
                    'email' => $email,
                    'source' => $token['id'],
                ]);
                $customer_id = $customer['id'];
                if ($customer_id) {
                    $oldCustomerId = Auth::guard(getAuthGuard())->user()->customer_id;
                    if (!empty($oldCustomerId)) { /* if customer id is exists then delete the customer sources from database and stripe */
                        $customer = $customer = $stripe->customers()->find($oldCustomerId);
                        if(!empty($customer)){
                            $stripe->customers()->delete($oldCustomerId);                                                    
                            $this->user->where('id', $userId)->update(['customer_id' => NULL]);        // update customer id to null in database
                            $this->paymentSource->where('user_id', $userId)->delete();               // delete all customer source from payment source                                     
                        }
                    }
                    $this->userRepo->updateUserSubscriptionDetail($userId, $token['id'], $customer_id, $start_date, $end_date);
                    /* Ignore payment deduction process when user is on trial period */
                    if (!empty($getStartDate) && !empty($getEndDate)) {
                        $this->paymentWithStripe();
                    }
                    $this->userRepo->savePaymentSource($token['card']['id'], $token['card']['last4'], 'card', 'yes', $token['card']['brand'], $token['card']['funding']);
                    return response()->json(['success' => true, 'role' => $role, 'message' => 'Account verified successfully.']);
                } else {
                    return response()->json(['success' => false, 'message' => 'Customer not create.Please try again later. ']);
                }
            } catch (\Cartalyst\Stripe\Exception\CardErrorException $e) {
                return response()->json(['success' => false, 'message' => $e->getMessage()]);
            } catch (\Cartalyst\Stripe\Exception\MissingParameterException $e) {
                return response()->json(['success' => false, 'message' => $e->getMessage()]);
            } catch (\Exception $e) {
                return response()->json(['success' => false, 'message' => $e->getMessage()]);
            }
        }
        return response()->json(['success' => false, 'message' => 'All fields are required.']);
    }

    /**
     * Stripe payment process by card.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function paymentWithStripe($id = null) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        /* when function call by cron then id will use. default auth user id will work */
        if (!empty($id)) {
            $userId = $id;
        }
        $subscription_id = getUserById($userId, 'subscription_id');
        $days = getSubscriptionData($subscription_id, 'renewal_cycle');
        $ammount = getSubscriptionData($subscription_id, 'amount');
        $s_end_date = Carbon::today();
        $parse_date = Carbon::parse($s_end_date);
        $end_date = $parse_date->addDay($days, 'day');
        $custId = getUserById($userId, 'customer_id');
        $plan_flag = getUserById($userId, 'plan_flag');
//        $input = $request->all();
//        $input = array_except($input, array('_token'));
        $stripe = Stripe::make(env("STRIPE_SECRET_KEY"));
        try {
            $charge = $stripe->charges()->create([
                'customer' => $custId,
                'currency' => 'USD',
                'amount' => $ammount * 100,
                'description' => 'Add in wallet',
            ]);
            if (!empty($charge)) {
                $this->userRepo->updateUserSubscriptionDetail($userId, '', '', $s_end_date, $end_date, '');
                $this->userRepo->saveTransaction($userId, $subscription_id, $charge, $s_end_date, $end_date, $ammount, $plan_flag);
                $this->paymentNotification->where(['user_id' => $userId])->delete();
                $this->userRepo->savePaymentCronData($userId, $charge, 'success', 'Payment successfully');
                return response()->json(['success' => true, 'message' => 'Charge created successfully.']);
            }
        } catch (Exception $e) {
            $this->userRepo->savePaymentCronData($userId, $charge, 'failure', $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Cartalyst\Stripe\Exception\CardErrorException $e) {
            $this->userRepo->savePaymentCronData($userId, $charge, 'failure', $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Cartalyst\Stripe\Exception\MissingParameterException $e) {
            $this->userRepo->savePaymentCronData($userId, $charge, 'failure', $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
