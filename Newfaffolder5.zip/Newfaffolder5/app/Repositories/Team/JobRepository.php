<?php

namespace App\Repositories\Team;

use Illuminate\Http\Request;
//use Illuminate\Support\Facades\DB;
use App\Models\Job;
use App\Models\JobQuestionnaire;
use App\Models\JobQuestion;
use App\Models\Position;
use App\Models\JobQuestionAnswer;
use App\Models\MasterBenefits;
use App\Models\JobCategory;
use App\Models\ApplyJob;
use App\Models\AppliedJobAnswer;
use App\Models\AppliedJobQuestion;
use Auth;
use DB;
use App\User;

Class JobRepository {

    /**
     * Class Construct.
     *
     * @param  array  $data
     * @return \App\User
     */
    public function __construct(Job $job, JobQuestionnaire $jobQuestionnaire, JobQuestion $question, JobQuestionAnswer $jobAnswer, JobCategory $jobCategory, ApplyJob $appliedJob, AppliedJobQuestion $appliedJobQuestion, User $user) {
        $this->job = $job;
        $this->jobQuestionnaire = $jobQuestionnaire;
        $this->jobQuestion = $question;
        $this->jobAnswer = $jobAnswer;
        $this->jobCategory = $jobCategory;
        $this->appliedJob = $appliedJob;
        $this->appliedJobQuestion = $appliedJobQuestion;
        $this->user = $user;
    }

    /*

     *   job list  
     */

    public function getJobList($request) {

        $incidentList = $this->job->select(['jobs.*', 'positions.name'])
                ->join('positions', 'positions.id', '=', 'jobs.position_id');

        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $incidentList->orderBy('jobs.id', $request['orderBy']);
            } else {
                $incidentList->orderBy('jobs.updated_at', 'desc');
            }
        }
        //        /* text search by columns of payment list */
        if (!empty($request['columns'])) {
            $text = $request['columns'];
            $incidentList->where(function ($query) use ($text) {
                $query->orWhere('jobs.reference_id', 'like', '%' . $text . '%')
                        ->orWhere('positions.name', 'like', '%' . $text . '%')
                        ->orWhere('jobs.city', 'like', '%' . $text . '%');
            });
        }
        /* Filter status wise */
        if (!empty($request['status'])) {
            if ($request['status'] != 'all') {
                $incidentList->where('jobs.status', $request['status']);
            }
        }
        /* Filter by levels  wise */
        if (!empty($request['levels'])) {
            $incidentList->where('jobs.level_id', $request['levels']);
        }
        /* Filter by job type  wise */
        if (!empty($request['job_type'])) {
            $incidentList->where('jobs.job_type', $request['job_type']);
        }
        /* Filter from date to date */
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = startDateFormatServer($request['startDate']);
            $to = endDateFormatServer($request['endDate']);
            $incidentList->whereBetween('jobs.created_at', array($from, $to));
        }
        return $incidentList->Paginate(getPaginatePage());
    }

    /*
     * function for get all positions.
     */

    /* job detail */

    function getJobDetail($job_id) {
        $jobView = $this->job->where(['id' => $job_id])->first();
        if (empty($jobView)) {
            return redirect()->back();
        }
        return $jobView;
    }

    function getAllPositions($type) {
        $positions = Position::where(['type' => $type])->get();
        return $positions;
    }

    /*
     * function for get all benefits.
     */

    function getAllbenefits() {
        $benefits = MasterBenefits::where('status', 'approved')->get();
        return $benefits;
    }

    /**
     * Method for save profile step one
     */
    public function saveJob(Request $request) {
        DB::beginTransaction();
        try {
            $post = $request->all();
            $userId = Auth::guard('team')->user()->id;
            if (isset($post['id'])) {
                $job = $this->job->find($post['id']);
            } else {
                $job = new $this->job;
            }
            $job->user_id = $userId;
            $job->job_type = $post['job_type'];
            $job->questionnaire_id = ($post['accept_through'] == 'faf_account') ? $post['questionnaire_id'] : '';
            $job->institution_name = $post['institution_name'];
            $job->institution_type = $post['institution_type'];
            $job->level_id = $post['level_id'];
            $job->conference = $post['conference'];
            $job->country_id = $post['country_id'];
            $job->state_id = $post['state_id'];
            $job->city = $post['city'];
            $job->zip_code = $post['zip_code'];
            $job->job_description = $post['job_description'];
            $job->skills = $post['skills'];
            $job->experience = $post['relevant_experience'];
            $job->apply_date = date('Y/m/d', strtotime($post['last_date_apply']));
            $job->from_salary = $post['salary_from'];
            $job->to_salary = $post['salary_to'];
            $job->benefits = (!empty($post['benefit'])) ? implode(',', $post['benefit']) : '';
            $job->app_accept = $post['accept_through'];
            $job->media1 = $post['social_one'];
            $job->media2 = $post['social_two'];
            $job->media3 = $post['social_three'];
            $job->contact_person = $post['contact_person'];
            $job->email = $post['email'];
            $job->phone = $post['phone_no'];
            $job->website_url = ($post['accept_through'] == 'website') ? $post['website_name'] : '';
            if ($post['job_type'] == 'player') {
                $job->position_id = (!empty($post['job_type'])) ? implode(',', $post['player_position']) : '';
            } else {
                $job->position_id = ($post['job_type'] == 'staff') ? $post['position_id'] : '';
            }
            $job->position_title = ($post['job_type'] == 'staff') ? $post['position_title'] : '';
            $job->category_id = (($post['job_type'] == 'staff') && !empty($post['jab_category'])) ? implode(',', $post['jab_category']) : '';
            $job->status = 'active';
            if ($job->save()) {
                if (!empty($post['questionnaire_id'])) {
                    $tbl1 = $this->jobQuestionnaire->where(['id' => $post['questionnaire_id'], 'job_id' => 0])->first();
                    if (!empty($tbl1)) {
                        $tbl1->job_id = $job->id;
                        $tbl1->save();
                        $this->jobQuestion->where(['questionnaire_id' => $tbl1->id])->update(['job_id' => $job->id]);
                        $ques = $this->jobQuestionnaire->where(['job_id' => 0])->delete();
                        if (!empty($ques)) {
                            $questionList = $this->jobQuestion->where(['job_id' => 0])->get();
                            if (!empty($questionList)) {
                                foreach ($questionList as $question) {
                                    $this->jobAnswer->where(['question_id' => $question->id])->delete();
                                    $question->delete();
                                }
                            }
                        }
                    }
                }
            }
            DB::commit();
            if (isset($post['id'])) {
                $appliedUser = \App\Models\ApplyJob::where(['job_id' => $job->id, 'apply_status' => 'yes'])->get();
                if (!empty($appliedUser)) {
                    foreach ($appliedUser as $val) {
                        sendNotifacationByFrontUser($job->user_id, $val->user_id, 'team_apply_jobs', '', $job->id);
                    }
                }
                return response()->json(['success' => true, 'message' => 'Job Updated Successfully.']);
            } else {
                $followUser = \App\Models\ProfileTracker::where(['to_id' => $job->user_id, 'type' => 'follow'])->get();
                if (!empty($followUser)) {
                    foreach ($followUser as $val) {
                        sendNotifacationByFrontUser($job->user_id, $val->from_id, 'team_jobs', $job->job_type, $job->id);
                    }
                }
                return response()->json(['success' => true, 'message' => 'JOb Created Successfully.']);
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
        return true;
    }

    /**
     * get questionnaire list
     * @return type
     */
    public function getQueNameList() {
        return $this->jobQuestionnaire->where(['team_id' => Auth::guard('team')->user()->id])->Where('job_id', '<>', 0)->get();
    }

    /**
     * get all category
     * @return type
     */
    public function getCategory() {
        return $this->jobCategory->all();
    }

    /**
     * get question list
     * @return type 
     */
    public function jobQuestionList($quesId) {
        try {
            $result = $this->jobQuestion->where(['questionnaire_id' => $quesId])->get();
            return $result;
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

//    get questionnaire name
    public function getQuestionnaireName($name) {
        try {
            $result = $this->jobQuestionnaire->where(['name' => $name])->Where('job_id', '<>', 0)->count();
            return response()->json(['success' => true, 'count' => $result]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * save job Question  
     */
    public function saveQuestion($request) {
        $post = $request->all();
        DB::beginTransaction();
        try {
            $getQuestionnaire = $this->jobQuestionnaire->where(['name' => $post['quesName'], 'team_id' => Auth::guard('team')->user()->id])->first();
            if (!empty($getQuestionnaire) && $getQuestionnaire->job_id == 0) {
                $questionnaireId = $getQuestionnaire->id;
            } elseif (empty($getQuestionnaire)) {
                $tbl1 = $this->jobQuestionnaire->where(['job_id' => 0])->first();
                if (!empty($tbl1)) {
                    $questionList = $this->jobQuestion->where(['questionnaire_id' => $tbl1->id])->get();
                    if (!empty($questionList)) {
                        foreach ($questionList as $question) {
                            $this->jobAnswer->where(['question_id' => $question->id])->delete();
                            $question->delete();
                        }
                    }
                    $tbl1->delete();
                }
                $model = new $this->jobQuestionnaire;
                $model->name = $post['quesName'];
                $model->team_id = Auth::guard('team')->user()->id;
                $model->save();
                $questionnaireId = $model->id;
            } else {
                return false;
            }
            $questionModel = new $this->jobQuestion;
            $questionModel->questionnaire_id = $questionnaireId;
            $questionModel->question = $post['question'];
            $questionModel->type = $post['answerType'];
            $questionModel->mandatory = (isset($post['mandatory'])) ? 'yes' : 'no';
            $questionModel->save();
            if (!empty($post['answerName'])) {
                foreach ($post['answerName'] as $answer) {
                    $answerModel = new $this->jobAnswer;
                    $answerModel->question_id = $questionModel->id;
                    $answerModel->answer = $answer;
                    $answerModel->save();
                }
            }
            DB::commit();
            return response()->json(['success' => true, 'message' => 'Question added successfully!', 'questionnaire_id' => $questionnaireId]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
        return true;
    }

    /*
     * Update user status
     */

    public function changeStatus($request) {
        try {
            $post = $request->all();
            $user_status = $this->job->find($post['id']);
            if (empty($user_status)) {
                return redirect()->back();
            }
            $user_status->status = $post['status'];
            $user_status->save();
            if (getAuthGuard() == "subadmin") {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'job_' . $post['status'], $user_status->reference_id, $user_status->job_type, '', $user_status->id);
            } else {
                sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'job_' . $post['status'], $user_status->reference_id, $user_status->job_type, '', $user_status->id);
            }
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * 16-jan-2019
     * function using for get applied candidates by id
     * return array
     */

    public function getJobAppliedCandidatesById($id) {
        $query = $this->appliedJob->where(['job_id' => $id])->get();
        return $query;
    }

    public function getJobResponse($post) {
        $query = $this->appliedJobQuestion->where(['applied_id' => $post['appliedId']])->get();
        return $query;
    }

}
