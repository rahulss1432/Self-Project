<?php

namespace App\Repositories\Coach;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Event;
use Auth;

Class EventRepository {

    /**
     * Class Construct.
     *
     * @param  array  $data
     * @return \App\User
     */
    public function __construct(Event $event) {
        $this->event = $event;
    }

    /**
     * Function for list all events.
     */
    public function getEvent($type, $id, $request) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            if ($id) { //update time        
                return $this->event->where(['id' => $id, 'user_id' => $userId])->first();
            } else {
                return $this->event->where('user_id', $userId)->get();
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for save profile step one
     */
    public function saveEvent(Request $request) {
        try {
            $post = $request->all();
            $city = $post['city'];
            $address1 = $post['address1'];
            $startDate = $post['start_date'];
            $startTime = $post['start_time'];
            $endDate = $post['end_date'];
            $endTime = $post['end_time'];
            if (!empty($city) && !empty($address1) && !empty($endDate) && !empty($endTime)) { /* check for if event is aleardy on this date,time and city and address */
                $userStartDate = dbDateFormat($post['start_date']);
                $userEndDate = dbDateFormat($post['end_date']);
                $userStartTime = date('H:i:s', strtotime($post['start_time']));
                $userEndTime = date('H:i:s', strtotime($post['end_time']));
                $userStartDateTime = strtotime($userStartDate . ' ' . $userStartTime);
                $userEndDateTime = strtotime($userEndDate . ' ' . $userEndTime);
                $matchedEvents = $this->event->where('city', 'like', '%' . $city . '%')
                        ->where('address1', 'like', '%' . $address1 . '%');
                if (isset($post['id'])) {
                    $matchedEvents = $matchedEvents->where('id', '!=', $post['id']);
                }
                $matchedEvents = $matchedEvents->get();
                if ($matchedEvents->count() > 0) {
                    $eventExists = false;
                    foreach ($matchedEvents as $event) {
                        $serverStartTime = date('H:i:s', strtotime($event->start_time));
                        $serverEndTime = date('H:i:s', strtotime($event->end_time));
                        $serverStartDate = dbDateFormat($event->start_date);
                        $serverEndDate = dbDateFormat($event->end_date);

                        $serverStartDateTime = strtotime($serverStartDate . ' ' . $serverStartTime);
                        $serverEndDateTime = strtotime($serverEndDate . ' ' . $serverEndTime);
                        if (($serverStartDate <= $userStartDate && $serverEndDate >= $userEndDate) ||
                                ($serverStartDate > $userStartDate && $serverEndDate <= $userEndDate) ||
                                ($userStartDate > $serverStartDate && $serverEndDate > $userStartDate) ||
                                ($userEndDate >= $serverStartDate && $serverEndDate > $userEndDate) ||
                                ($userStartDate < $serverStartDate && $serverStartDate < $userEndDate) ||
                                ($userStartDate < $serverEndDate && $serverEndDate < $userEndDate)) {
                            if ($serverStartTime <= $userStartTime && $serverEndTime >= $userEndTime) {
                                $eventExists = true;
                            } elseif ($serverStartTime > $userStartTime && $serverEndTime <= $userEndTime) {
                                $eventExists = true;
                            } elseif ($userStartTime > $serverStartTime && $serverEndTime > $userStartTime) {
                                $eventExists = true;
                            } elseif ($userEndTime >= $serverStartTime && $serverEndTime > $userEndTime) {
                                $eventExists = true;
                            } elseif ($userStartTime < $serverStartTime && $serverStartTime < $userEndTime) {
                                $eventExists = true;
                            } elseif ($userStartTime < $serverEndTime && $serverEndTime < $userEndTime) {
                                $eventExists = true;
                            }

                            /* for datetime check */
                            if ($serverStartDateTime <= $userStartDateTime && $serverEndDateTime >= $userEndDateTime) {
                                $eventExists = true;
                            } elseif ($serverStartDateTime > $userStartDateTime && $serverEndDateTime <= $userEndDateTime) {
                                $eventExists = true;
                            } elseif ($userStartDateTime > $serverStartDateTime && $serverEndDateTime > $userStartDateTime) {
                                $eventExists = true;
                            } elseif ($userEndDateTime >= $serverStartDateTime && $serverEndDateTime > $userEndDateTime) {
                                $eventExists = true;
                            } elseif ($userStartDateTime < $serverStartDateTime && $serverStartDateTime < $userEndDateTime) {
                                $eventExists = true;
                            } elseif ($userStartDateTime < $serverEndDateTime && $serverEndDateTime < $userEndDateTime) {
                                $eventExists = true;
                            }
                        }
                        if ($eventExists) {
                            return response()->json(['success' => false, 'message' => 'The event is aleady exists,please try with another date,time or place.']);
                        }
                    }
                }
            }
            $userId = Auth::guard(getAuthGuard())->user()->id;
            if (isset($post['id'])) {
                $event = $this->event->find($post['id']);
                $event->updated_by = $userId;
            } else {
                $event = new $this->event;
                $event->status = 'active';
                $event->user_id = $userId;
            }
            if (isset($post['banner_image'])) {
                $event->banner_image = $post['banner_image'];
            }
            $event->event_name = $post['event_name'];
            $event->keywords = $post['keywords'];
            $event->address1 = $post['address1'];
            $event->address2 = $post['address2'];
            $event->country_id = $post['country_id'];
            $event->state_id = $post['state_id'];
            $event->city = $post['city'];
            $event->zipcode = $post['zipcode'];
            $event->team1 = $post['team1'];
            $event->start_date = dbDateFormat($post['start_date']);
            $event->end_date = dbDateFormat($post['end_date']);
            $event->team2 = $post['team2'];
            $event->start_time = dbTimeFormat($post['start_time']);
            $event->end_time = dbTimeFormat($post['end_time']);
            $event->ticket_url = $post['ticket_url'];
            $event->description = $post['description'];
            $event->save();
            if (isset($post['old_image']) && ($event->banner_image != $post['old_image'] )) {
                unlinkImageFunction($post['old_image'], 'event');
                unlinkImageFunction($post['old_image'], 'event/thumb');
            }
            $followUser = \App\Models\ProfileTracker::where(['to_id' => $event->user_id, 'type' => 'follow'])->get();
            if (isset($post['id'])) {
                if (!empty($followUser)) {
                    foreach ($followUser as $val) {
                        sendNotifacationByFrontUser($event->user_id, $val->from_id, 'user_edit_event', $event->event_name, $event->id);
                    }
                }
                return response()->json(['success' => true, 'message' => 'Event Updated successfully.']);
            } else {
                if (!empty($followUser)) {
                    foreach ($followUser as $val) {
                        sendNotifacationByFrontUser($event->user_id, $val->from_id, 'user_add_event', $event->event_name, $event->id);
                    }
                }
                return response()->json(['success' => true, 'message' => 'Event Created successfully.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Function for delete event.
     */
    public function deleteEvent($request) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $this->event->where(['id' => $request->id, 'user_id' => $userId])->delete();
            return response()->json(['success' => true, 'message' => 'Event Deleted successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
