<?php

namespace App\Repositories;

use Illuminate\Http\Request;
use App\Models\Incident;
use App\User;
use Illuminate\Support\Facades\Auth;

Class ReportRepository {

    public function __construct(Incident $incident, User $user) {
        $this->incident = $incident;
        $this->user = $user;
    }

    /*
     * save report section
     */

    public function saveReport($request) {
        try {
            $incident = new Incident;
            $incident->from_id = $request->from_id;
            $incident->to_id = null;
            $incident->entity_id = $request->to_id;
            $incident->title = $request->title;
            $incident->reported_entity = $request->reported_entity;
            $incident->reported_by = '';
            $incident->reported_against = '';
            if ($incident->save()) {
                $getUserType = $this->user->where('role', 'admin')->first();
                sendNotifacationByUser($request->from_id, $getUserType->id, 'report', getReferenceIdByReportType($incident->entity_id, $incident->reported_entity)['reference_id'], $request->reported_entity, $incident->reference_id, $incident->entity_id);
                return response()->json(['success' => true, 'message' => 'Report added successfully']);
            } else {
                return false;
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function getIncidentLists($request) {

        $incidentList = $this->incident->select(['incidents.*', 'users.full_name', 'pu.full_name', 'mu.full_name', 'su.full_name'])
                ->join('users', 'users.id', '=', 'incidents.from_id')
                ->leftjoin('posts', 'posts.id', '=', 'incidents.entity_id')
                ->leftjoin('users as pu', 'pu.id', '=', 'posts.user_id')
                ->leftjoin('user_medias', 'user_medias.id', '=', 'incidents.entity_id')
                ->leftjoin('users as mu', 'mu.id', '=', 'user_medias.user_id')
                ->leftjoin('users as su', 'su.id', '=', 'incidents.entity_id');


        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $incidentList->orderBy('incidents.id', $request['orderBy']);
            } else {
                $incidentList->orderBy('incidents.updated_at', 'desc');
            }
        }
//        /* text search by columns of payment list */
        if (!empty($request['columns'])) {
            $text = $request['columns'];
            $incidentList->where(function ($query) use ($text) {
                $query->orWhere('incidents.reference_id', 'like', '%' . $text . '%')
                        ->orWhere('incidents.entity_id', 'like', '%' . $text . '%')
                        ->orWhere('pu.full_name', 'like', '%' . $text . '%')
                        ->orWhere('mu.full_name', 'like', '%' . $text . '%')
                        ->orWhere('su.full_name', 'like', '%' . $text . '%')
                        ->orWhere('users.full_name', 'like', '%' . $text . '%');
            });
        }
        /* Filter status wise */
        if (!empty($request['status'])) {
            $incidentList->where('incidents.status', $request['status']);
        }
        /* Filter by reoprter wise */
        if (!empty($request['reporter'])) {
            $incidentList->where('incidents.from_id', $request['reporter']);
        }

        /* Filter from date to date */
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = date('Y-m-d', strtotime($request['startDate']));
            $to = date('Y-m-d', strtotime($request['endDate']));
            $incidentList->whereDate('incidents.created_at', '>=', $from)
                    ->whereDate('incidents.created_at', '<=', $to);
        }
        if (!empty($request['startDate']) && empty($request['endDate'])) {
            $from = date('Y-m-d', strtotime($request['startDate']));
            $incidentList->whereDate('incidents.created_at', $from);
        }
        if (!empty($request['endDate']) && empty($request['startDate'])) {
            $to = date('Y-m-d', strtotime($request['endDate']));
            $incidentList->whereDate('incidents.created_at', $to);
        }


        return $incidentList->Paginate(getPaginatePage());
    }

    public function getIncidentById($incident_id) {
        $incidentView = $this->incident->where(['id' => $incident_id])->first();
        if (empty($incidentView)) {
            return redirect()->back();
        }
        return $incidentView;
    }

    /* resolve incident */

    public function resolveIncident($request) {
        try {
            $incident = $this->incident->where(['id' => $request->id])->first();
            if (!empty($incident)) {
                $incident->reported_by = $request->reported_by;
                $incident->reported_against = $request->reported_to;
                $incident->status = 'resolved';
                $incident->updated_by = Auth::guard(getAuthGuard())->user()->id;
                if ($incident->save()) {
                    $reporterEmail = $incident->reporter->email;
                    $publisherEmail = getEntityPublisherDetail($incident->entity_id, $incident->reported_entity)['publisher_email'];
                    /* send mail to reporter */

                    $rdata['name'] = $incident->reporter->full_name;
                    $rdata['reported_entity'] = $incident->reported_entity;
                    $rdata['request'] = 'admin_incident_reporter';
                    $rdata['email'] = $reporterEmail;
                    $rdata['subject'] = 'Incident Reported ';
                    $rdata['reported_by'] = $request->reported_by;
                    $rResult = sendMail($rdata);

                    /* send mail to publisher */

                    $pdata['name'] = getEntityPublisherDetail($incident->entity_id, $incident->reported_entity)['publisher'];
                    $pdata['reported_entity'] = $incident->reported_entity;
                    $pdata['request'] = 'admin_incident_publisher';
                    $pdata['email'] = $publisherEmail;
                    $pdata['subject'] = 'Incident Reported ';
                    $pdata['reported_to'] = $request->reported_to;
                    $pResult = sendMail($pdata);

                    if ($rResult && $pResult) {
                        sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $incident->from_id, 'resolve_report', getReferenceIdByReportType($incident->entity_id, $incident->reported_entity)['reference_id'], $incident->reported_entity, $incident->reference_id, $incident->id);
                        sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, getReferenceIdByReportType($incident->entity_id, $incident->reported_entity)['publisher_id'], 'resolve_report', getReferenceIdByReportType($incident->entity_id, $incident->reported_entity)['reference_id'], $incident->reported_entity, $incident->reference_id, $incident->id);
                        if (getAuthGuard() == "subadmin") {
                            $getUserType = $this->user->where('role', 'admin')->first();
                            sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, $getUserType->id, 'resolve_report', getReferenceIdByReportType($incident->entity_id, $incident->reported_entity)['reference_id'], $incident->reported_entity, $incident->reference_id, $incident->id);
                        } else {
                            sendNotifacationByUser(Auth::guard(getAuthGuard())->user()->id, Auth::guard(getAuthGuard())->user()->id, 'resolve_report', getReferenceIdByReportType($incident->entity_id, $incident->reported_entity)['reference_id'], $incident->reported_entity, $incident->reference_id, $incident->id);
                        }
                        return response()->json(['success' => true, 'message' => 'Mail has been sent to reporter and publisher']);
                    }
                }
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
