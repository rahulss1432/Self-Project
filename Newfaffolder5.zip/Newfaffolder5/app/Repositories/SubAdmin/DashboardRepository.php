<?php

namespace App\Repositories\SubAdmin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

Class DashboardRepository {
    
    public function __construct() {
        
    }
    
    /**
     * Get all dashboard data.
     * @param null
      * @return \Illuminate\Http\Response
     */
    public function index() {
        try {               
            return view('subadmin::dashboard.index');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }
}
