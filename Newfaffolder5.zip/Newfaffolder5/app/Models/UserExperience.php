<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserExperience extends Model
{

    protected $table = 'user_experiences';
    
    protected $fillable = [
        'user_id', 'user_exp_type', 'country_id', 'state_id', 'level_id', 'experience_type', 'name', 'logo', 'from_year', 'to_year', 'present_organization', 'present_year', 'degree_name', 'position_held','coaching_link','coching_league'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at',
    ];

    /*
     * Get user exp level
     */
    public function experienceLevel() {
        return $this->belongsTo('App\Models\MasterLevel', 'level_id');
    }
    
    public function experienceCountry() {
        return $this->belongsTo('App\Models\Country', 'country_id', 'country_id');
    }

    public function experienceState() {
        return $this->belongsTo('App\Models\State', 'state_id', 'state_id');
    }
}