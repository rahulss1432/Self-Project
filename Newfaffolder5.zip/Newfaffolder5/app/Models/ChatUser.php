<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatUser extends Model
{
    
    protected $table = 'chat_users';
    
    protected $fillable = [
        'from_id','reference_id','to_id'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
    protected static function boot(){
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }
    
    public function fromUser(){
        return $this->belongsTo('App\User', 'from_id');
    }
    
    public function toUser(){
        return $this->belongsTo('App\User', 'to_id');
    }

}
