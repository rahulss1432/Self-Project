<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MasterLevel extends Model {

    protected $table = 'master_levels';

    protected $fillable = [
        'level_name'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at',
    ];

}
