<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Testimonials extends Model
{
    protected $table = 'testimonials';
    
    protected $fillable = [
        'image', 'name','content', 'created_at'
    ];
    
    protected $hidden = [
        'updated_at'
    ];
    
}
