<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppliedJobQuestion extends Model {

    protected $table = 'applied_job_question';
    protected $fillable = [
        'user_id', 'job_id','question'
    ];
    protected $hidden = [
        'updated_at', 'created_at'
    ];
    
    public function appliedJobAnswer(){
        return $this->hasMany('App\Models\AppliedJobAnswer', 'question_id', 'id');
    }

}
