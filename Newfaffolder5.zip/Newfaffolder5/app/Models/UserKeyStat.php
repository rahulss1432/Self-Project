<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserKeyStat extends Model {

    protected $table = 'user_key_stats';

   protected $fillable = ['user_id','season_type','from_year','to_year','total_passing','passing_game',
       'passing_season','completion','completion_percent','passer_rating','total_rushing','rushing_game',
       'rushing_season','total_receiving','receiving_game','receiving_season','total_return','return_game',
       'return_season','total_all_purpose','purpose_game','purpose_season','tuchdowns','games_played','tackles',
       'tackles_game','tackles_season','total_tackloss','tackloss_game','tackloss_season','total_sacks','sacks_game',
       'sacks_season','total_breaksups','breaksups_game','breaksups_season','total_interception','interception_game',
       'interception_season','blocked_punts','total_field_goal','longest_field_goal',
       'field_goal_percent','longest_punt','avg_punt_distance'];
   
   protected $hidden = [
        'created_at', 'updated_at',
    ];
}
