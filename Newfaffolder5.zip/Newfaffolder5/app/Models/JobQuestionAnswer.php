<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobQuestionAnswer extends Model
{
    protected $table = 'job_question_answers';
    
    protected $fillable = [
        
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
    /*
     * Relation for get job country.
     */
  
}
