<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentNotification extends Model {

    protected $table = 'payment_notifications';
    protected $fillable = [
        'id', 'user_id', 'charge_id', 'message', 'is_process', 'status', 'after_days', 'created_at'
    ];
    protected $hidden = [
        'updated_at'
    ];

    protected static function boot() {
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }

}
