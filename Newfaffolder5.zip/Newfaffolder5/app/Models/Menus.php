<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Menus extends Model
{
    
    protected $table = 'sidebar_menus';
    
    protected $fillable = [
        'name','value','icon'
    ];
    
    public function user(){
        return Menus::belongsToMany('App\User', 'user_sidebar_menus', 'menu_id', 'user_id');
    }
}
