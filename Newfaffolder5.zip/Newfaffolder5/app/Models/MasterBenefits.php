<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MasterBenefits extends Model {

    protected $table = 'master_benefits';

    protected $fillable = [
        'created_by', 'title', 'image', 'status'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at',
    ];

}
