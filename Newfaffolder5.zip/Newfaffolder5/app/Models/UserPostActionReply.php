<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserPostActionReply extends Model
{
    protected $table = 'user_post_action_replies';
    
    protected $fillable = [
        'post_action_id', 'from_id', 'comment'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
    public function comment(){
        return $this->belongsTo('App\Models\UserPostAction', 'post_action_id');
    }
    
    public function user(){
        return $this->belongsTo('App\User', 'from_id');
    }
}
