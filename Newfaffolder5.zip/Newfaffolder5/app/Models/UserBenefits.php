<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserBenefits extends Model {

    protected $table = 'user_benefits';

    protected $fillable = [
        'user_id', 'category_id', 'media', 'media_type'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at',
    ];

    /*
     * Function for get country name.
     */

    public function masterBenefits() {
        return $this->belongsTo('App\Models\MasterBenefits', 'benefit_id');
    }
    
}
