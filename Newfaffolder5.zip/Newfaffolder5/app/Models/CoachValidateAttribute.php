<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CoachValidateAttribute extends Model {

    protected $table = 'coach_validate_attributes';
    protected $fillable = [
        'attribute_id', 'user_id'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
    
    public function coachValidateAttribute(){
        return $this->belongsTo('App\Models\ValidateAttributes','attribute_id' ,'id');
    }
}
