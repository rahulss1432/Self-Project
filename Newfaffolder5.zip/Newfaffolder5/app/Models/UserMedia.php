<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserMedia extends Model {

    protected $table = 'user_medias';
    protected $fillable = [
        'user_id', 'category_id', 'media', 'post_id', 'media_type'
    ];
    protected $hidden = [
        'created_at', 'updated_at',
    ];

    protected static function boot() {
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }

    public function mediaComments() {
        return $this->hasMany('App\Models\MediaComments', 'media_id');
    }

    public function post() {
        return $this->belongsTo('App\Models\Post', 'post_id');
    }

    public function user() {
        return $this->belongsTo('App\User', 'user_id');
    }

}
