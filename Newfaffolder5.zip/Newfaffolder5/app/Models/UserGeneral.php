<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserGeneral extends Model {

    protected $table = 'user_generals';
    protected $fillable = [
        'user_id', 'playing_exp', 'under_contract', 'current_team', 'current_team_link', 'current_league', 'current_league_link', 'former_team', 'former_team_link', 'former_league', 'former_league_link', 'passport', 'native_lang_id', 'secondary_lang_id','look_to_sign','relocate'
    ];
    protected $hidden = [
        'created_at', 'updated_at',
    ];

    /*
     * Function for get native language info.
     */
    public function nativeLanguage() {
        return $this->belongsTo('App\Models\Language', 'native_lang_id');
    }

    /*
     * Function for get secondary language info.
     */
    public function secondaryLanguage() {
        return $this->belongsTo('App\Models\Language', 'secondary_lang_id');
    }

    /*
     * Get user exp level
     */
    public function level() {
        return $this->belongsTo('App\Models\MasterLevel', 'level_id');
    }

    /*
     * Function for get country name.
     */
    public function country() {
        return $this->belongsTo('App\Models\Country', 'country_id', 'country_id');
    }
    
    /*
     * Function for get country name by citizenship.
     */
    public function citizenshipCountry() {
        return $this->belongsTo('App\Models\Country', 'citizenship','country_id');
    }
    
    /*
     * Function for get country name by work in country.
     */
    public function workInCountry() {
        return $this->belongsTo('App\Models\Country', 'work_in_country_id','country_id');
    }

}
