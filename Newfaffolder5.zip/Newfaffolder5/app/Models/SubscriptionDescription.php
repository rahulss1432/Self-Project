<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubscriptionDescription extends Model {

    protected $table = 'subscription_description';
    protected $fillable = [
        'description','subscription_id','created_at'
    ];
    protected $hidden = [
        'updated_at'
    ];

     public function subscription_description()
    {
        return $this->belongsTo('App\Models\Subscriptions', 'subscription_id','id');
    }
}
