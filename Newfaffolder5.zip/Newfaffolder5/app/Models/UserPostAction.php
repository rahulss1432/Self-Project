<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserPostAction extends Model
{
    protected $table = 'user_post_actions';
    
    protected $fillable = [
        'post_id', 'from_id', 'to_id', 'comment', 'type'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
    public function post(){
        return $this->belongsTo('App\Models\Post', 'post_id');
    }
    
    public function user(){
        return $this->belongsTo('App\User', 'from_id');
    }
    
    /* this relation function used for media comment listing on admin*/
    public function fromUser(){ 
        return $this->belongsTo('App\User', 'from_id');
    }
}
