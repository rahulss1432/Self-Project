<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatMessage extends Model
{
    
    protected $table = 'chat_messages';
    
    protected $fillable = [
        'chat_id','reference_id','to_id', 'message', 'created_at'
    ];
    
    protected $hidden = [
        'updated_at'
    ];
    
    protected static function boot(){
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }
    public function user(){
        return $this->belongsTo('App\User', 'to_id');
    }
    
}
