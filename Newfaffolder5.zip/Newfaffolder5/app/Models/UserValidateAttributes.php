<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserValidateAttributes extends Model
{
    protected $table = 'user_validate_attributes';
    
    protected $fillable = [
        'from_id', 'to_id','attribute_id'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
    public function attribute(){
        return $this->belongsTo('App\Models\ValidateAttributes', 'attribute_id');
    }
    
}
