<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transactions extends Model {

    protected $table = 'transactions';
    protected $fillable = [
        'id', 'user_id', 'subscription_id','customer', 'charge_id', 'transaction_id','source_id','amount','status', 'start_date','end_date','created_at'
    ];
    protected $hidden = [
        'updated_at'
    ];
    
       protected static function boot() {
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }
    
   /*
    * Function for master level table relation .
    */
    public function userSubscription(){
      return $this->belongsTo('App\Models\Subscriptions', 'subscription_id','id');
    }
    
    public function transactionUser(){
        return $this->belongsTo('App\User', 'user_id','id');
    }

}
