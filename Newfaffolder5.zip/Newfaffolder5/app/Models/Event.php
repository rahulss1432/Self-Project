<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $table = 'events';
    
    protected $fillable = [
        'user_id', 'reference_id', 'banner_image', 'event_name', 'keywords', 'address1', 'address2', 'country', 'state', 'city', 'zipcode', 
        'team1', 'start_date', 'end_date', 'team2', 'start_time', 'end_time', 'ticket_url', 'description', 'status'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    protected static function boot(){
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }

    /*
     * Relation for get user.
     */
    public function user(){
        return $this->belongsTo('App\User', 'user_id');
    }
    
    /*
     * Relation for get state.
     */
    public function state(){
        return $this->belongsTo('App\Models\State', 'state_id', 'state_id');
    }

    /*
     * Relation for get country.
     */
    public function country(){
        return $this->belongsTo('App\Models\Country', 'country_id', 'country_id');
    }
    
    /*
     * Relation for get user by team1 id.
     */
    public function team1Data(){
        return $this->belongsTo('App\User', 'team1');
    }    
    
    /*
     * Relation for get user by team2 id.
     */
    public function team2Data(){
        return $this->belongsTo('App\User', 'team2');
    }    
    
}
