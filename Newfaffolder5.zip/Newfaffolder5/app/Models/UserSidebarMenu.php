<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class UserSidebarMenu extends Model {

    protected $table = 'user_sidebar_menus';
    protected $fillable = [
        'user_id', 'menu_id'
    ];

    public function menu() {
        return UserSidebarMenu::belongsTo('App\Models\Menus', 'menu_id', 'id');
    }

    public static function getUserSidebarMenu() {
        return UserSidebarMenu::where(['user_id' => Auth::guard('subadmin')->user()->id])->with('menu')->get();
    }

}
