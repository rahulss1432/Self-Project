<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EventTeam extends Model {

    protected $table = 'event_teams';
    protected $fillable = ['name', 'logo'];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

}
