<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobQuestion extends Model
{
    protected $table = 'job_questions';
    
    protected $fillable = [
        
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
    /*
     * Relation for get answer.
     */
 
    public function jobQuestionsAnswer(){
        return $this->hasMany('App\Models\JobQuestionAnswer', 'question_id', 'id');
    }
}
