<?php

use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;
use App\Models\Country;
use App\Models\State;
use App\User;
use App\Models\UserBenefits;
use App\Models\UserMeasurable;
use App\Models\TeamPlayer;
use App\Models\TeamStaff;
use App\Models\UserGeneral;
use App\Models\Job;
use App\Models\Event;
use App\Models\UserMedia;
use App\Models\Post;
use App\Models\Language;
use App\Models\Level;
use App\Models\Position;
use App\Models\JobBenefit;
use App\Models\UserKeyStat;
use App\Models\UserPostAction;
use App\Models\UserPostActionReply;
use App\Models\ChatMessage;
use App\Models\UserExperience;
use App\Models\ProfileTracker;
use App\Models\Connection;
use App\Models\Subscriptions;
use App\Models\UserValidateAttributes;
use Illuminate\Support\Facades\Auth;
use App\Models\MasterBenefits;
use App\Models\MediaComments;
use App\Models\EventTeam;
use App\Models\ApplyJob;
use App\Models\News;
use App\Repositories\StripeRepository;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Session;

/*
 * Function for change date format.
 */
ini_set('max_execution_time', '-1');
ini_set('memory_limit', '-1');

function dateTime($string) {
    return Carbon::parse($string)->format('d M Y');
}

function sameDate($string) {
    return Carbon::parse($string)->format('m/d/Y');
}

function dateDayAgo($string) {
    return Carbon::parse($string)->diffForHumans();
}

/**
 * 
 * @param type $string
 * @return type
 */
function timeFormat($string) {
    return Carbon::parse($string)->format('d M h:i');
}

function getTimeFormat($string) {
    return Carbon::parse($string)->format('h:i A');
}

function fullTimeFormat($string) {
    return Carbon::parse($string)->format('m/d/Y ,h:i A');
}

/* convert date to database date format */

function dbDateFormat($string) {
    return Carbon::parse($string)->format('Y-m-d');
}

/*
 *  for Apr 24, 2018
 */

function getMonthDateYearFormat($string) {
    return Carbon::parse($string)->format('M d ,Y');
}

/*
 *  for 12:00 (hours format)
 */

function dbTimeFormat($string) {
    return Carbon::parse($string)->format('H:i');
}

/**
 *  trial period days dyanmic from setting table
 * @param type $key
 * @return int
 */
function getSetting($key = null) {
    return 14;
}

/**
 * User slug
 */
function make_slug($name, $id) {
    $slug = preg_replace('/[^A-Za-z0-9\-]/', '', str_replace(' ', '-', $name));
    $data = User::where('slug', $slug)->first();
    if (empty($data)) {
        $slug = strtolower($slug);
    } else {
        $slug = strtolower($slug . '-' . $id);
    }
    if (empty(strpos($slug, '-'))) {
        $slug = strtolower($slug . '-' . $id);
    }
    return $slug;
}

/*
 * Function for get user id by slug name.
 */

function getUserIdBySlug($slug) {
    $data = User::where('slug', $slug)->first();
    if (!empty($data)) {
        return $data->id;
    } else {
        return 0;
    }
}

/*
 * function for get all country name.
 */

function getAuthGuard() {
    if (Auth::guard('player')->check()) {
        $guard = 'player';
    } elseif (Auth::guard('coach')->check()) {
        $guard = 'coach';
    } elseif (Auth::guard('team')->check()) {
        $guard = 'team';
    } elseif (Auth::guard('admin')->check()) {
        $guard = 'admin';
    } elseif (Auth::guard('subadmin')->check()) {
        $guard = 'subadmin';
    } else {
        $guard = 'web';
    }
    return $guard;
}

/* get all active plans */

function getAllActivePlans() {
    return Subscriptions::where('status', 'active')->with('subDescription')->orderBy('id', 'asc')->get();
}

/* get all active plans */

function getSubscriptionData($id, $key) {
    $data = Subscriptions::where('id', $id)->first();
    if (!empty($data)) {
        return $data->$key;
    } else {
        return '';
    }
}

/*
 * Function for get last message.
 */

function getPlanMonth($val) {

    if ($val == 30) {
        return 'Monthly';
    } elseif ($val == 90) {
        return 'Quarterly';
    } elseif ($val == 180) {
        return 'Half Yearly';
    } elseif ($val == 360) {
        return 'Yearly';
    }
}

/**
 * get user with all details.
 * @param type $id
 * @return string
 */
function getUserWithAllDetail($id) {
    $data = User::find($id);
    if (!empty($data)) {
        return $data;
    } else {
        return '';
    }
}

/*
 * Function for get user by id.
 */

function getUserById($id, $key) {
    $data = User::find($id);
    if (!empty($data)) {
        return $data->$key;
    } else {
        return '';
    }
}

/*
 * Send mail.
 */

function sendMail($data) {
    try {
        switch ($data['request']) {
            case "user_signup_admin":
                Mail::send('emails.user_signup_admin', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "contact-us":
                $admin_email = \App\Models\Setting::where(['setting_key' => 'admin-email'])->first();
                $data['admin_email'] = ($admin_email->key_value);
                Mail::send('emails.contact_us', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['admin_email'])
                            ->from(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "verification_email":
                Mail::send('emails.verification_email', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "rating_email":
                Mail::send('emails.rating_email', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->subject($data['subject'])
                            ->attach($data['ticket_image']);
                });
                break;

            case "verified_email":
                Mail::send('emails.verified_email', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->subject($data['subject']);
                });
                break;
            case "recent_otp":
                Mail::send('emails.recent-otp', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->subject($data['subject']);
                });
                break;
            case "forgot_password":
                Mail::send('emails.forgot_password', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->replyTo(fromMailCredential(), 'FAF')
                            ->from(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "admin_forgot_password":
                Mail::send('emails.admin_forgot_password', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "subadmin_mail":
                Mail::send('emails.subadmin_credentials', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->replyTo(fromMailCredential(), 'FAF')
                            ->from(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "admin_change_password":
                Mail::send('emails.subadmin_new_credential', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->replyTo(fromMailCredential(), 'FAF')
                            ->from(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
            case "welcome_mail":
                Mail::send('emails.welcome_mail', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(fromMailCredential(), 'FAF')
//                            ->replyTo(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "user_activity_mail":
                Mail::send('emails.user_activity_mail', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(fromMailCredential(), 'FAF')
//                            ->replyTo(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "user_invoice_mail":
                Mail::send('emails.user_invoice_mail', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(fromMailCredential(), 'FAF')
//                            ->replyTo(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "user_notification_mail":
                Mail::send('emails.user_notification_mail', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(fromMailCredential(), 'FAF')
//                            ->replyTo(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "decline_mail":
                Mail::send('emails.decline_mail', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(fromMailCredential(), 'FAF')
//                            ->replyTo(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "admin_incident_reporter":
                Mail::send('emails.incident_reporter', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(fromMailCredential(), 'FAF')
//                            ->replyTo(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "admin_incident_publisher":
                Mail::send('emails.incident_publisher', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(fromMailCredential(), 'FAF')
//                            ->replyTo(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;
            case "contact_and_support_mail":
                Mail::send('emails.contact_and_support_mail', ['data' => $data], function ($message) use ($data) {
                    $message->to(fromMailCredential(), 'FAF')
                            ->from($data['email'])
//                            ->replyTo(fromMailCredential(), 'FAF')
                            ->subject($data['subject']);
                });
                break;            
            default:
                break;
        }
        return true;
    } catch (Exception $e) {
        return $e->getMessage();
    }
}

/*
 * Function for check login user id.
 */

function checkLoginUser($id) {
    if (Auth::guard(getAuthGuard())->check()) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        if ($userId == $id) {
            return true;
        } else {
            return false;
        }
    }
    return false;
}

/*
 * get country name 
 */

function getCountryName($country_id) {
    $country_name = Country::where('country_id', $country_id)->first(['name']);
    if (!empty($country_name)) {
        return ucfirst($country_name->name);
    }
    return '';
}

/*
 * get country name 
 */

function getLevelName($level_id) {
    $level_name = Level::where('id', $level_id)->first(['level_name']);
    if (!empty($level_name)) {
        return ucfirst($level_name->level_name);
    }
    return '';
}

/*
 * get state name 
 */

function getStateName($state_id) {
    $state_name = State::where('state_id', $state_id)->first(['state_name']);
    if (!empty($state_name)) {
        return ucfirst($state_name->state_name);
    }
    return '';
}

/*
 *    Player step form 4 current season value
 */

function getUserKeyStatsValueByColumn($columnName) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    $data = UserKeyStat::where(['user_id' => $userId, 'season_type' => 'current'])->first();
    if (!empty($data)) {
        return $data->$columnName;
    }
    return '';
}

/*
 * function for get all country name.
 */

function getAllCountry($request) {
    if (isset($request['type']) && $request['type'] == 'user-profile-step-one') {
        $id = Auth::guard(getAuthGuard())->user()->country_id;
        $countries = Country::all();
        foreach ($countries as $country) {
            echo "<option value='$country->country_id'>$country->name</option>";
        }
    } else if (isset($request['type']) && $request['type'] == 'event-country') {
        $countries = Country::all();
        foreach ($countries as $country) {
            echo "<option value='$country->name'>$country->name</option>";
        }
    } else if (isset($request['type']) && ( $request['type'] == 'coaching' || $request['type'] == 'general')) {
        $countries = Country::all();
        if ($request['type'] == 'general') {
            $request['country_id'] = !empty(getUserGeneral('country_id')) ? getUserGeneral('country_id') : '';
        }
        foreach ($countries as $country) {
            if ($country->country_id == $request['country_id']) {
                $selected = 'selected="selected"';
            } else {
                $selected = '';
            }
            echo "<option value='$country->country_id' $selected>$country->name</option>";
        }
    } else {
        $countries = Country::all();
        foreach ($countries as $country) {
            echo "<option data-value='$country->short_name' value='$country->country_id'>$country->name</option>";
        }
    }
}

/*
 * function for get state name by country id.
 */

function getStatesByCountryId($request) {
    if (isset($request['type']) && $request['type'] == 'user-profile-step-one') {
        $id = Auth::guard(getAuthGuard())->user()->state_id;
        $states = State::where('country_id', $request['country_id'])->get();
        foreach ($states as $state) {
            echo "<option value='$state->state_id'>$state->state_name</option>";
        }
    } else if (isset($request['type']) && $request['type'] == 'event-state') {
        $country = Country::where('name', $request['country_id'])->first();
        $states = State::where('country_id', $country->country_id)->get();
        foreach ($states as $state) {
            echo "<option value='$state->state_name'>$state->state_name</option>";
        }
    } else if (isset($request['type']) && $request['type'] == 'coaching') {
        $states = State::where('country_id', $request['country_id'])->get();
        foreach ($states as $state) {
            if ($state->state_id == $request['state_id']) {
                $selected = 'selected="selected"';
            } else {
                $selected = '';
            }
            echo "<option value='$state->state_id' $selected>$state->state_name</option>";
        }
    } else {
        $states = State::where('country_id', $request['country_id'])->get();
        foreach ($states as $state) {
            echo "<option value='$state->state_id'>$state->state_name</option>";
        }
    }
}

/*
 * function for get all master languages.
 */

function getAllLanguages($post = null) {
    $languages = Language::all();
    foreach ($languages as $language) {
        echo "<option value='$language->id'>$language->language</option>";
    }
}

/*
 * function for get all teams.
 */

function getAllTeam($post) {
    $teams = User::where('role', 'team')->where('status', 'active')->get();
    $event_teams = EventTeam::all();
    $all_teams = array();
    foreach ($teams as $team) {
        if (!empty($post['teamId']) && $team->id == $post['teamId']) {
            $selected = 'selected="selected"';
        } else {
            $selected = '';
        }
        array_push($all_teams, "<option value='$team->id' $selected>$team->full_name</option>");
    }
    foreach ($event_teams as $team1) {
        if (!empty($post['teamId']) && $team1->id == $post['teamId']) {
            $selected = 'selected="selected"';
        } else {
            $selected = '';
        }
        array_push($all_teams, "<option value='$team1->name' $selected>$team1->name</option>");
    }
    return $all_teams;
}

/*
 * function for get all master levels.
 */

function getAllLevels() {

    $levels = Level::all();
    foreach ($levels as $level) {
        echo "<option value='$level->id'>$level->level_name</option>";
    }
}

/*
 * function for get all positions.
 */

function getAllPositions($request) {
    $positions = Position::where(['type' => $request->type])->get();
    foreach ($positions as $position) {
        echo "<option value='$position->id'>$position->name</option>";
    }
}

/*
 * function for get user data by column
 */

function getUserDataByColumn($key) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    $data = User::find($userId);
    if ($data->count() > 0) {
        if ($key == 'position_id') { // for position array
            $postion_array = json_decode($data->$key);
            if (!empty($postion_array)) {
                if (count($postion_array) <= 1) {
                    return $postion_array[0];
                }
                return $postion_array[0] . ',' . $postion_array[1];
            }
        }
        return $data->$key;
    } else {
        return '';
    }
}

/**
 * Team Add player with multi position select.
 * @param type $id
 * @param type $key
 * @return string
 */
function getTeamPlayerPosition($id, $key) {
    $data = TeamPlayer::find($id);
    if ($data->count() > 0) {
        if ($key == 'position_id') { // for position array
            $postion_array = json_decode($data->$key);
            if (!empty($postion_array)) {
                if (count($postion_array) <= 1) {
                    return $postion_array[0];
                }
                return $postion_array[0] . ',' . $postion_array[1];
            }
        }
        return $data->$key;
    } else {
        return '';
    }
}

/*
 * Check image url and set image path
 */

function checkUserImage($image, $folder = null, $logo = null) {
//  echo '<pre>';print_r($image,$folder);die;
    $src = url('public/images/default-user.png');
    if ($logo == 'logo') {
        $src = url('public/images/logo-img.jpg');
    }
    if ($logo == 'uniform') {
        $src = url('public/images/t-shirt-min.png');
    }
    if ($logo == 'event-banner') {
        $src = url('public/administrator/images/upload_img.jpg');
    }
    if ($logo == 'community-experience') {
        $src = url('public/images/community_icon.svg');
    }
    if ($logo == 'coaching-experience') {
        $src = url('public/images/cup_icon.svg');
    }
    if ($logo == 'accolades-experience') {
        $src = url('public/images/cairo_icon.svg');
    }
    if ($logo == 'accolades-experience') {
        $src = url('public/images/cairo_icon.svg');
    }
    if ($logo == 'coaching-list') {
        $src = url('public/images/coachinglist_logo.png');
    }
    if ($logo == 'frount-uniform') {
        $src = url('public/images/front_uniform.png');
    }
    if ($logo == 'backend-uniform') {
        $src = url('public/images/backend_uniform.png');
    }
    $fileName = public_path() . '/uploads/' . $folder . '/' . $image;
    $FafTubeFileName = env('FAFTUBE_LINK'). '/public/uploads/' . $folder . '/' . $image;        
    if (!empty($image) && file_exists($fileName)) {                              // check if file exists in FAF folder
        $src = url('public/uploads/' . $folder . '/' . $image);
    }
    if(@file_get_contents($FafTubeFileName) != false && !empty($image)){      // check if file exists in FAF TUBE folder
        $src = $FafTubeFileName;
    }    
    return $src;
}

/*
 * Unlink old image of user
 */

function unlinkImageFunction($image, $folder = null) {
    $fileName = public_path() . '/uploads/' . $folder . '/' . $image;
    if (!empty($image) && file_exists($fileName)) {
        unlink($fileName);
    }
}

/*
 * function for upload images.
 */

function uploadFile($image, $folder = null) {
    try {
        $destination = public_path() . '/uploads/' . $folder;
        if (!is_dir($destination)) {
            File::makeDirectory($destination, $mode = 0777, true, true);
        }
        $imageName = time() . rand(11111, 99999) . '.' . $image->getClientOriginalExtension();
        $fileName = str_replace(" ", "-", $imageName);
        if (uploadFileExist($destination, $fileName)) {
            if ($image->move($destination, $fileName)) {
                return $fileName;
            } else {
                return "Error in uploading file.";
            }
        }
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

/* 06-feb-2019
 * function using for check file ex already 
 * return filename
 */

function uploadFileExist($destination, $fileName) {
    if (!file_exists($destination . '/' . $fileName)) {
        return true;
    } else {
        return false;
    }
}

/*
 * function for upload images thumb.
 */

function uploadFileThumb($image, $folder = null, $main = null) {
    try {
        $thumbPath = public_path() . '/uploads/' . $folder;
        if (!\File::exists($thumbPath)) {
            \File::makeDirectory($thumbPath, 0777, true, true);
        }
        $img = Image::make(checkUserImage($image, $main));
        $thumb_img = $img->resize(280, 280);
        $thumb_img->save($thumbPath . '/' . $image, 100);
        return $folder = $image;
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

/*
 * function for check upload images.
 */

function checkFileExist($destination, $image) {
    $filename = time() . '.' . $image->getClientOriginalExtension();
    if (!\File::exists($destination)) {
        \File::makeDirectory($destination, 0777, true, true);
    }
    $i = 1;
    while (\File::exists($destination . '/' . $filename)) {
        $fileNameWithoutExtenssion = basename(time() . '.' . $image->getClientOriginalName(), '.' . $image->getClientOriginalExtension());
        $filename = $fileNameWithoutExtenssion . $i . '.' . $image->getClientOriginalExtension();
        $i++;
    }
    return $filename;
}

/*
 * function for upload profile images.
 */

function profileImage($request) {
    $file = $_FILES;
    $type = explode("/", $file[$request['image_type']]["type"]);
    if ($type[0] == 'image') {
        if ($file[$request['image_type']]["size"] < (1000 * 1000 * 2)) {
            $size = getimagesize($file[$request['image_type']]['tmp_name']);
            $filename1 = strtolower(trim(preg_replace("/[^a-zA-Z0-9.]/", "", $file[$request['image_type']]['name']), ''));
            $filename = time() . "-" . $filename1;
            $imagePath = public_path() . '/uploads/' . $request['folder'] . '/';
            if (!is_dir($imagePath)) {
                File::makeDirectory($imagePath, $mode = 0777, true, true);
            }
            move_uploaded_file($file[$request['image_type']]['tmp_name'], $imagePath . $filename);
            return json_encode(array('success' => 1, 'filename' => $filename, 'size' => $size, 'type' => 'image'));
        } else {
            return json_encode(array('success' => 0, 'error' => 'Image has to be smaller than 2MB'));
        }
    } else {
        return json_encode(array('success' => 0, 'error' => 'File type is not image.'));
    }
}

/*
 * function for cropped images save and return for show.
 */

function getSavingImage($image_name, $imgdata) {
    $cropImgPath = public_path() . '/uploads/' . $imgdata['thumb_folder'] . '/';
    if (!is_dir($cropImgPath)) {
        mkdir($cropImgPath, 0777, true);
    }
    $userId = Auth::guard(getAuthGuard())->user()->id;
    $userInfo = User::find($userId);
    // unlink profile old image of this user
    if ($imgdata['image_type'] == 'profileImage') {
        if (!empty($userInfo->profile_image)) {
            unlinkImageFunction($userInfo->profile_image, $imgdata['folder']);
            unlinkImageFunction($userInfo->profile_image, $imgdata['thumb_folder']);
        }
        $userInfo->profile_image = $image_name;
    }
    // team uniform front image check and unlink
    if ($imgdata['image_type'] == 'front_image') {
        if (!empty($userInfo->uniform_front_upload)) {
            unlinkImageFunction($userInfo->uniform_front_upload, $imgdata['folder']);
            unlinkImageFunction($userInfo->uniform_front_upload, $imgdata['thumb_folder']);
        }
        $userInfo->uniform_front_upload = $image_name;
    }
    // team uniform back image check and unlink
    if ($imgdata['image_type'] == 'back_image') {
        if (!empty($userInfo->uniform_back_upload)) {
            unlinkImageFunction($userInfo->uniform_back_upload, $imgdata['folder']);
            unlinkImageFunction($userInfo->uniform_back_upload, $imgdata['thumb_folder']);
        }
        $userInfo->uniform_back_upload = $image_name;
    }
    $userInfo->save();
    $origanlImage = public_path() . '/uploads/' . $imgdata['folder'] . '/' . $image_name;
    $destinationPath = $cropImgPath . $image_name;
    $img = Image::make($origanlImage);
    $img->rotate(-intval($imgdata['rotate']));
    $img->crop(intval($imgdata['croppedWidth']), intval($imgdata['croppedHeight']), intval($imgdata['croppedX']), intval($imgdata['croppedY']));
    $img->resize(300, 300);
    if ($imgdata['image_type'] == 'eventImage') {  // for event only
        $img->resize(850, 280);
    }
    $img->save($destinationPath);
    return $image_name;
}

/*
 * function for get user media data by column
 */

function getUserMediaByColumn($key, $type) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    $data = UserMedia::where(['user_id' => $userId, 'media_type' => $type])->first();
    if (!empty($data)) {
        return $data->$key;
    } else {
        return '';
    }
}

/*
 * function for get user benefits
 */

function getUserBenefits() {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    $data = UserBenefits::where('user_id', $userId)->select('benefit_id')->get();
    if ($data->count() > 0) {
        foreach ($data as $row) {
            $benefit[] = $row->benefit_id;
        }
        return $benefit;
    } else {
        return [];
    }
}

/*
 * function for get user media data by column
 */

function getUserMeasurables($key) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    $data = UserMeasurable::where('user_id', $userId)->first();
    if (!empty($data)) {
        return $data->$key;
    } else {
        return '';
    }
}

/*
 * Function for text char limit.
 */

function getLimitText($limit, $text) {
    $string = substr($text, 0, $limit);
    if (strlen($text) > $limit) {
        $string .= '..';
    };
    return $string;
}

/*
 * Function for get team player data.
 */

function getTeamPlayer($id, $key) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    $data = TeamPlayer::where(['id' => $id, 'user_id' => $userId])->first();
    if (!empty($data)) {
        return $data->$key;
    } else {
        return '';
    }
}

/*
 * Function for get team staff data.
 */

function getTeamStaff($id, $key) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    $data = TeamStaff::where(['id' => $id, 'user_id' => $userId])->first();
    if (!empty($data)) {
        return $data->$key;
    } else {
        return '';
    }
}

/*
 * Function for get step form 3 general data.
 */

function getUserGeneral($key) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    $data = UserGeneral::where(['user_id' => $userId])->first();
    if (!empty($data)) {
        return $data->$key;
    } else {
        return '';
    }
}

/**
 * 
 * @return string
 */
function getUserGeneralData() {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    $data = UserGeneral::where(['user_id' => $userId])->first();
    if (!empty($data)) {
        return $data;
    } else {
        return '';
    }
}

/*
 * Function for get job benefits.
 */

function getJobBenefits($jobId) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    $data = JobBenefit::where(['user_id' => $userId, 'job_id' => $jobId])->select('benefit_id')->get();
    if ($data->count() > 0) {
        foreach ($data as $row) {
            $benefit[] = $row->benefit_id;
        }
        return $benefit;
    } else {
        return [];
    }
}

/*
 * Functino for check user likes.
 */

function checkUserLike($pid, $oid = null) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    if (!empty($oid)) {
        $userId = $oid;
    }
    $data = UserPostAction::where(['post_id' => $pid, 'from_id' => $userId, 'type' => 'like'])->count();
    if ($data > 0) {
        return 1;
    } else {
        return 0;
    }
}

/*
 * Function for get last message.
 */

function lastMessage($chatId) {
    $data = ChatMessage::where('chat_id', $chatId)->orderBy('id', 'desc')->first();
    if (!empty($data)) {
        return $data;
    } else {
        return '';
    }
}

/*
 * check flag image according to size and set image path
 */

function checkFlagImage($imageName, $size) {
    $flagImage = strtolower($imageName) . '.png';
    if ($size == 'large') {
        $file = "/images/flags-large/" . $flagImage;
    }
    if ($size == 'medium') {
        $file = "/images/flags-medium/" . $flagImage;
    }
    if ($size == 'extralarge') {
        $file = "/images/flags-extralarge/" . $flagImage;
    }
    if ($size == 'small') {
        $file = "/images/flags/" . $flagImage;
    }
    $imagePath = public_path() . $file;
    if (!empty($imageName) && file_exists($imagePath)) {
        $src = url('public') . $file;
    } else {
        $src = url('public/images/american_flag.jpg');
    }
    return $src;
}

/*
 * get position name
 */

function getPositionName($position) {
    $positionNameArray = [];
    $postionList = json_decode($position);
    if (!empty($postionList)) {
        foreach ($postionList as $position) {
            $model = Position::where('id', $position)->first();
            $positionNameArray[] = ucfirst($model->name);
        }
    } else {
        $positionNameArray[] = '-';
    }
    return implode("/", $positionNameArray);
}

/*
 * Function for check unread messages.
 */

function checkUnreadCount($chatId) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    return ChatMessage::where(['chat_id' => $chatId, 'to_id' => $userId, 'is_read' => '0'])->count();
}

/*
 * Get user data from any table.
 */

function getUserData($id, $column, $model, $type) {
    if (!empty($type)) {
        $data = $model::where(['user_id' => $id, 'user_exp_type' => $type])->first();
    } else {
        if ($model == '\App\Models\UserGeneral') {
            if ($column == 'native_lang_id') {
                $data = UserGeneral::where('user_id', $id)->first();
                if (!empty($data->native_lang_id)) {
                    $lang = \App\Models\Language::where('id', $data->native_lang_id)->first();
                    return $lang->language;
                } else {
                    return '-';
                }
            } else {
                $data = $model::where('user_id', $id)->first();
            }
        } elseif ($model == '\App\Models\Level') {
            $data = $model::find($id)->first();
        } elseif ($model == '\App\Models\Country') {
            $data = $model::where('country_id', $id)->first();
        } else {
            $data = $model::where('user_id', $id)->first();
        }
    }
    if (!empty($data)) {
        return $data->$column;
    } else {
        return '';
    }
}

/*
 * Get profile tracker.
 */

function getProfileTrackers($id, $type, $trackType) {
    if ($trackType == 'tracking') {
        return ProfileTracker::where(['from_id' => $id, 'type' => $type])->count();
    } else {
        return ProfileTracker::where(['to_id' => $id, 'type' => $type])->count();
    }
}

/*
 * Get connection total count.
 */

function getConnectionCount($userId) {
    return Connection::where(function($query) use($userId) {
                $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
            })->where('type', 'accept')->count();
}

/**
 * check user connect with this user or not
 * @param type $userId
 */
function checkUserConnect($userId) {
    $myId = (!empty(Auth::guard(getAuthGuard())->user()->id)) ? Auth::guard(getAuthGuard())->user()->id : 0;
    $check_accept = Connection::where(function($query) use($userId, $myId) {
                $query->where(['from_id' => $userId, 'to_id' => $myId])->orWhere(function($query1) use($userId, $myId) {
                    $query1->where(['from_id' => $myId, 'to_id' => $userId]);
                });
            })->where('type', 'accept')->count();
    if ($check_accept > 0) {
        return 'accept';
    }
    $check_reject = Connection::where(function($query) use($userId, $myId) {
                $query->where(['from_id' => $userId, 'to_id' => $myId])->orWhere(function($query1) use($userId, $myId) {
                    $query1->where(['from_id' => $myId, 'to_id' => $userId]);
                });
            })->where(function($query2) {
                $query2->where('type', 'pending')->orWhere('type', 'reject');
            })->count();
    if ($check_reject > 0) {
        return 'pending';
    }
    return '';
}

/*
 * Get user event count.
 */

function getUserActionCount($id, $model) {
    return $model::where('user_id', $id)->count();
}

/*
 * Generate random string
 */

function generateRandomString($length = 8) {
    return substr(str_shuffle(str_repeat($x = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / strlen($x)))), 1, $length);
}

/*
 * Get testimonial  Image.
 */

function getTestimonialImage($image) {
    $imagePath = public_path() . '/uploads/cms/' . $image;
    if (!empty($image) && file_exists($imagePath)) {
        $src = url('public/uploads/cms/' . $image);
    } else {
        $src = url('public/images/default-user.png');
    }
    return $src;
}

/*
 * function using for player check select my attribute count in player section.
 */

function countAttributeById($attrId, $userId) {
    $result = UserValidateAttributes::where(['to_id' => $userId, 'attribute_id' => $attrId])->count();
    return $result;
}

/*
 * function using for player select other player check attribute by from and to id in player section.
 */

function checkAttributeById($attrId, $fromId, $toId) {
    $result = UserValidateAttributes::where(['to_id' => $toId, 'from_id' => $fromId, 'attribute_id' => $attrId])->count();
    return $result;
}

/*
 * function using for check profile events.
 */

function checkProfileEvents($toId, $type) {
    $fromId = Auth::guard(getAuthGuard())->user()->id;
    $result = ProfileTracker::where(['to_id' => $toId, 'from_id' => $fromId, 'type' => $type])->count();
    return $result;
}

/**
 * S.
 * @param string $video
 * @param type $folderName
 * @return boolean|string
 * function using for create video thumb.
 */
function videoThumb($video, $folderName) {
    try {
        $size = $video->getClientSize();
        $ext = $video->getClientOriginalExtension();
        if ($ext == 'mp4' || $ext == 'MP4') {
            if ($size < (getFileSize('video'))) {
                $public_path = str_replace("\\", "/", public_path());
                $videoPath = $public_path . '/uploads/' . $folderName;
                $videoThumbPath = $public_path . '/uploads/' . $folderName . '/thumb';
                $appendVideoPath = $public_path . '/uploads/' . $folderName . '/append-video';
                $filterVideoPath = $public_path . '/uploads/' . $folderName . '/filter-video';
                
                if (!is_dir($videoPath)) {
                    File::makeDirectory($videoPath, $mode = 0777, true, true);
                }

                if (!is_dir($videoThumbPath)) {
                    File::makeDirectory($videoThumbPath, $mode = 0777, true, true);
                }

                if (!is_dir($appendVideoPath)) {
                    File::makeDirectory($appendVideoPath, $mode = 0777, true, true);
                }
                
                if (!is_dir($filterVideoPath)) {
                    File::makeDirectory($filterVideoPath, $mode = 0777, true, true);
                }

                $videoName = time() . rand(0, 3000) . '.' . $video->getClientOriginalExtension();
                $destinationPath = $videoPath;
                $video->move($destinationPath, $videoName);
                $ffmpegPath = \Config::get('constants.ffmpeg_path');
                $ffprobePath = \Config::get('constants.ffprobe_path');

                $ffmpeg = FFMpeg\FFMpeg::create(array(
                            'ffmpeg.binaries' => $ffmpegPath,
                            'ffprobe.binaries' => $ffprobePath,
                            'timeout' => 3600,
                            'ffmpeg.threads' => 12,
                ));
                
//                it is very usefull for find error on ffmpeg
               // $ffmpeg->getFFMpegDriver()->listen(new \Alchemy\BinaryDriver\Listeners\DebugListener());
               // $ffmpeg->getFFMpegDriver()->on('debug', function ($message) {
               //     echo $message."\n";
               // });

                $uploadedVideoPath = $destinationPath . '/' . $videoName;
                $filename = pathinfo($videoName, PATHINFO_FILENAME);
                $videoThumbimage = $videoThumbPath . '/' . $filename . '.jpg';
                $appendVideoPath = $appendVideoPath . '/' . $filename . '.mp4';
                $filterVideoPath = $filterVideoPath . '/' . $filename . '.mp4';

                $introVideo =  $public_path.'/images/faf-video/faf-intro-start.mp4';
                $watermarkImagePath =  './public/images/watermark-image.png';

//              create concat video and thumb
                $video = $ffmpeg->open($uploadedVideoPath);
                
                $video->filters()->pad(new FFMpeg\Coordinate\Dimension(1280, 720));
                $video->save(new \FFMpeg\Format\Video\X264('libmp3lame', 'libx264'), $filterVideoPath);
                
                $video->frame(\FFMpeg\Coordinate\TimeCode::fromSeconds(1))
                        ->save($videoThumbimage);
                
                $video->concat(array($introVideo, $filterVideoPath, $introVideo))
                        ->saveFromSameCodecs($appendVideoPath, FALSE);

                unlink($filterVideoPath);        
                

//              create watermark
                $video = $ffmpeg->open($appendVideoPath);
                $video->filters()
                        ->watermark($watermarkImagePath, array(
                            'position' => 'relative',
                            'bottom' => 60,
                            'right' => 50,
                ));

                unlink($uploadedVideoPath);
                $format = new \FFMpeg\Format\Video\X264('libmp3lame', 'libx264');
                $video->save($format, './public/uploads/temp/' . $filename . '.mp4');
                unlink($appendVideoPath);

//             create duration time 
                $ffprobe = FFMpeg\FFProbe::create(array(
                            'ffmpeg.binaries' => $ffmpegPath,
                            'ffprobe.binaries' => $ffprobePath,
                            'timeout' => 3600,
                            'ffmpeg.threads' => 12,
                ));

                $videoDuration = $ffprobe->format($uploadedVideoPath)
                        ->get('duration');

                $videoTimeDuration = convertTimeToHrs($videoDuration);
                $img = Image::make($videoThumbimage);
                $thumb_img = $img->resize(670, 380);
                $thumb_img->save($videoThumbimage, 100);
                if (file_exists($videoThumbimage)) {
                    $resultArray = [];
                    $resultArray['fileName'] = $filename . '.jpg';
                    $resultArray['fileDuration'] = $videoTimeDuration;
                    return $resultArray;
                } else {
                    return 'Please try again';
                }
            } else {
                return 'File has to be smaller than 10MB';
            }
        } else {
            return 'Invalid Formate: Allow only jpg,png,gif,jpeg,mp4';
        }
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

function rand_string($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function getLatLangByAddress($address) {
    $data = [];
    $arrContextOptions = array(
        "ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
        ),
    );
    $encodedAddress = urlencode($address);
    $json = file_get_contents("https://maps.google.com/maps/api/geocode/json?key=AIzaSyC6UvgQK_Ua6wHk9J5Up0IcGJVPvko1lvI&address=" . $encodedAddress . "&sensor=false", false, stream_context_create($arrContextOptions));
    $json = json_decode($json);
    if ($json->{'status'} == 'OK') {
        $glat = $json->{'results'}[0]->geometry->location->lat;
        $glong = $json->{'results'}[0]->geometry->location->lng;
        $gaddress = $json->{'results'}[0]->formatted_address;
        if (!empty($glat) && !empty($glong)) {
            $data['lat'] = $glat;
            $data['long'] = $glong;
            $data['address'] = $gaddress;
            return $data;
        } else {   //lat long empty else
            $data['lat'] = $latitude = 37.0902;
            $data['long'] = $longitude = -95.7129;
            $data['address'] = "US";
            return $data;
        }
    } else {
        $data['lat'] = $latitude = 37.0902;
        $data['long'] = $longitude = -95.7129;
        $data['address'] = "US";
        return $data;
    }
}

/*
 * Get user benefits
 */

function getUserBenefit($masterBenefitId, $userId) {
    //   $userId = Auth::guard(getAuthGuard())->user()->id;
    $userBenefits = UserBenefits::where('user_id', $userId)->get();
    foreach ($userBenefits as $benefit) {
        if ($benefit->benefit_id == $masterBenefitId) {
            return 'true';
        }
    }
    return 'false';
}

/*
 *  funtion using for count media like 
 */

function mediaLikeCount($mediaId, $type) {
    $result = MediaComments::where(['media_id' => $mediaId, 'type' => $type])->count();
    return $result;
}

/*
 *  funtion usein for check user to like on media 
 */

function checkUserMediaLike($mediaId, $fromId, $type) {
    $result = MediaComments::where(['media_id' => $mediaId, 'from_id' => $fromId, 'type' => $type])->count();
    return $result;
}

/**
 * Follow unfollow check 
 */
function checkFollowUnfollow($to_id) {
    $myId = Auth::guard(getAuthGuard())->user()->id;
    return ProfileTracker::where(['from_id' => $myId, 'to_id' => $to_id, 'type' => 'follow'])->count();
}

/* function for get dynamic image and video size validation */

function getFileSize($type) {
    if ($type == 'video') {
        return 1000 * 1000 * 10;
    } elseif ($type == 'image') {
        return 1000 * 1000 * 5;
    }
}

/**
 * S.
 * @param type $image
 * @param type $folder
 * @return boolean
 * function for remove deleted images
 */
function removeDeletedImages($image, $folder) {
    $imagePath = public_path() . '/uploads/' . $folder . '/';
    $changeImageName = explode('.', $image);
    $video = $imagePath . '/' . $changeImageName[0] . '.mp4';
    if (!empty($video) && file_exists($video)) {
        unlink($video);
    }

    $originalImage = $imagePath . '/' . $image;
    if (!empty($image) && file_exists($originalImage)) {
        unlink($originalImage);
    }

    $thumbImage = $imagePath . '/thumb/' . $image;
    if (!empty($thumbImage) && file_exists($thumbImage)) {
        unlink($thumbImage);
    }

    $leftMediaImage = $imagePath . '/left-media-thumb/' . $image;
    if (!empty($leftMediaImage) && file_exists($leftMediaImage)) {
        unlink($leftMediaImage);
    }

    $profileMediaImage = $imagePath . '/profile-media-thumb/' . $image;
    if (!empty($profileMediaImage) && file_exists($profileMediaImage)) {
        unlink($profileMediaImage);
    }
    return true;
}

/**
 * S
 * @param type $filleName
 * @param type $folderName
 * function using for  copy images.   in temp folder to main folder
 */
function copyImages($filleName, $folderName) {
    $imagePath = public_path() . '/uploads/' . $folderName;
    $imageThumb = public_path() . '/uploads/' . $folderName . '/thumb';
    $leftMediaImageThumb = public_path() . '/uploads/' . $folderName . '/left-media-thumb';
    $profileMediaImageThumb = public_path() . '/uploads/' . $folderName . '/profile-media-thumb';

    $tempPath = public_path() . '/uploads/temp';

    if (!is_dir($imagePath)) {
        File::makeDirectory($imagePath, $mode = 0777, true, true);
    }

    if (!is_dir($imageThumb)) {
        File::makeDirectory($imageThumb, $mode = 0777, true, true);
    }

    if (!is_dir($leftMediaImageThumb)) {
        File::makeDirectory($leftMediaImageThumb, $mode = 0777, true, true);
    }

    if (!is_dir($profileMediaImageThumb)) {
        File::makeDirectory($profileMediaImageThumb, $mode = 0777, true, true);
    }

    $changeImageName = explode('.', $filleName);
    $oldVideo = $tempPath . '/' . $changeImageName[0] . '.mp4';
    $newVideo = $imagePath . '/' . $changeImageName[0] . '.mp4';
    $oldImage = $tempPath . '/' . $filleName;
    $newImage = $imagePath . '/' . $filleName;
    $thumboldImage = $tempPath . '/thumb/' . $filleName;
    $thumbNewImage = $imageThumb . '/' . $filleName;

    $oldLeftMediaImageThumb = $tempPath . '/left-media-thumb/' . $filleName;
    $newLeftMediaImageThumb = $leftMediaImageThumb . '/' . $filleName;

    $oldProfileMediaImageThumb = $tempPath . '/profile-media-thumb/' . $filleName;
    $newProfileMediaImageThumb = $profileMediaImageThumb . '/' . $filleName;

    if (!empty($oldVideo) && file_exists($oldVideo)) {
        copy($oldVideo, $newVideo);
        unlink($oldVideo);
    }
    if (!empty($oldImage) && file_exists($oldImage)) {
        copy($oldImage, $newImage);
        unlink($oldImage);
    }

    if (!empty($thumboldImage) && file_exists($thumboldImage)) {
        copy($thumboldImage, $thumbNewImage);
        unlink($thumboldImage);
    }

    if (!empty($oldLeftMediaImageThumb) && file_exists($oldLeftMediaImageThumb)) {
        copy($oldLeftMediaImageThumb, $newLeftMediaImageThumb);
        unlink($oldLeftMediaImageThumb);
    }

    if (!empty($oldProfileMediaImageThumb) && file_exists($oldProfileMediaImageThumb)) {
        copy($oldProfileMediaImageThumb, $newProfileMediaImageThumb);
        unlink($oldProfileMediaImageThumb);
    }
}

/**
 * check user connect with this user connect or not
 * @param type $userId
 */
function checkUserRequest($userId) {
    $myId = Auth::guard(getAuthGuard())->user()->id;
    $check_accept = Connection::where(['from_id' => $userId, 'to_id' => $myId])->where('type', '!=', 'reject')->count();
    if ($check_accept > 0) {
        return true;
    }
    return false;
}

/* function using for check user Available */

function checkUserEventStatus($toId) {
    $result = User::where(['id' => $toId])->first();
    return $result->current_status;
}

/**
 * S
 * @param type $image
 * @param type $folderName
 * @param type $type
 * @return boolean
 * function using for get uploaded file size
 */
function getUploadedFileSize($image, $folderName, $type) {
    $filePath = public_path() . '/uploads/' . $folderName;
    $changeImageName = explode('.', $image);
    $fileName = $filePath . '/' . $changeImageName[0] . '.mp4';
    if (!empty($image) && file_exists($fileName)) {
        return filesize($fileName) . ' (byte)';
    }

    $fileName = $filePath . '/' . $image;
    if (!empty($image) && file_exists($fileName)) {
        return filesize($fileName) . ' (byte)';
    }
    return false;
}

function getSubscriptionDetails($id, $key) {
    $data = Subscriptions::where(['id' => $id])->first();
    if (!empty($data)) {
        return $data->$key;
    } else {
        return '-';
    }
}

// country code by id
function getCountryCode($post) {
    if (!empty($post)) {
        $country = Country::where('country_id', $post['country_id'])->first();
        $countruCode = $country['phonecode'];
        echo "<option value=''>+$countruCode</option>";
    }
}

// count post like   
function countPostEvent($postId, $type) {
    $result = UserPostAction::where(['post_id' => $postId, 'type' => $type])->count();
    return $result;
}

/* function for pagination per page */

function getPaginatePage() {
    return 5;
}

/**
 * 
 * @param type $image
 * @param type $folder
 * @return type
 * function using for check media files
 */
function checkMediaImage($image, $folder) {
    $src = url('public/images/default-media.jpg');
    $fileName = public_path() . '/uploads/' . $folder . '/' . $image;
    if (!empty($image) && file_exists($fileName)) {
        $src = url('public/uploads/' . $folder . '/' . $image);
    }
    return $src;
}

/* 10-jan-2019
 * function using for check news
 * return type image
 */

function checkNewsImage($image) {
    $src = url('public/images/default-media.jpg');
    $fileName = public_path() . '/uploads/news/thumb/' . $image;
    if (!empty($image) && file_exists($fileName)) {
        $src = url('public/uploads/news/thumb/' . $image);
    }
    return $src;
}

/**
 * S
 * @param type $image
 * @param type $folder
 * @return type function using for get media file by media type image name folder name
 */
function checkMediaByType($imageName, $role, $type, $folderName) {
    $imagePath = url('public/images/' . $folderName . '.jpg');
    $publicPath = public_path() . '/uploads/';
    if ($type == 'video') {
        $checkFile = $publicPath . '/' . $role . '/thumb/' . $imageName;
        $src = url('public/uploads/' . $role . '/thumb/' . $imageName);
    } elseif ($type == 'image') {
        $checkFile = $publicPath . '/' . $role . '/' . $folderName . '/' . $imageName;
        $src = url('public/uploads/' . $role . '/' . $folderName . '/' . $imageName);
    }
    if (!empty($imageName) && file_exists($checkFile)) {
        $imagePath = $src;
    }
    return $imagePath;
}

/**
 * S
 * @param type $image
 * @param type $folder
 * function using for check media video
 */
function checkMediaVideo($image, $folder) {
    $changeFileName = explode('.', $image);
    $oldVideo = $changeFileName[0] . '.mp4';
    $src = url('public/images/default-media.jpg');
    $fileName = public_path() . '/uploads/' . $folder . '/' . $oldVideo;
    if (!empty($image) && file_exists($fileName)) {
        $src = url('public/uploads/' . $folder . '/' . $oldVideo);
    }
    return $src;
}

/** S
 * image resize function  
 * @param type $imageName
 */
function resizeMediaImage($imageName) {
    $thumbPath = public_path() . '/uploads/temp/thumb';
    $thumbLeftMediPath = public_path() . '/uploads/temp/left-media-thumb';
    $thumbProfileMediPath = public_path() . '/uploads/temp/profile-media-thumb';
    if (!is_dir($thumbPath)) {
        File::makeDirectory($thumbPath, $mode = 0777, true, true);
    }
    if (!is_dir($thumbLeftMediPath)) {
        File::makeDirectory($thumbLeftMediPath, $mode = 0777, true, true);
    }
    if (!is_dir($thumbProfileMediPath)) {
        File::makeDirectory($thumbProfileMediPath, $mode = 0777, true, true);
    }
    // front image thumb
    $img = Image::make(public_path() . '/uploads/temp/' . $imageName);
    $thumb_img = $img->resize(665, 325);
    $thumb_img->save($thumbPath . '/' . $imageName, 100);
    //  left  media display thumb
    $thumb_img2 = $img->resize(290, 160);
    $thumb_img2->save($thumbLeftMediPath . '/' . $imageName, 100);
    //   profile image display thumb
    $thumb_img3 = $img->resize(800, 380);
    $thumb_img3->save($thumbProfileMediPath . '/' . $imageName, 100);
}

/**
 * 
 * @return type
 */
function fromMailCredential() {
    return $str = 'testingemail@codiantdev.com';
}

function getEntityPublisherDetail($entity_id, $type) {

    $data = [];
    $data['publisher'] = "-";
    $data['updated_by'] = "-";
    $data['updated_at'] = "-";
    $data['publisher_email'] = 0;

    if ($type == 'event') {
        $event = \App\Models\Event::where(['id' => $entity_id])->first();
        if (!empty($event)) {
            $user = User::find($event['user_id']);
            if (!empty($user)) {
                $publisher = $user['full_name'];
                $data['publisher'] = $publisher . '(' . $user['reference_id'] . ')';
                $data['publisher_email'] = $user['email'];
                if (!empty($user['updated_by'])) {
                    $updateByUser = User::find($user['updated_by']);
                    if (!empty($updateByUser))
                        $data['updated_by'] = $updateByUser['full_name'] . '(' . $user['reference_id'] . ')';
                    $data['updated_at'] = fullTimeFormat($updateByUser['updated_at']);
                }
            }
        }
    } elseif ($type == 'post') {
        $post = \App\Models\Post::where(['id' => $entity_id])->first();
        if (!empty($post)) {
            $user = User::find($post['user_id']);
            if (!empty($user)) {
                $publisher = $user['full_name'];
                $data['publisher'] = $publisher . '(' . $user['reference_id'] . ')';
                $data['publisher_email'] = $user['email'];
                if (!empty($user['updated_by'])) {
                    $updateByUser = User::find($user['updated_by']);
                    if (!empty($updateByUser))
                        $data['updated_by'] = $updateByUser['full_name'] . '(' . $user['reference_id'] . ')';
                    $data['updated_at'] = fullTimeFormat($updateByUser['updated_at']);
                }
            }
        }
    } elseif ($type == 'image' || $type == 'video') {
        $media = \App\Models\UserMedia::where(['id' => $entity_id])->first();
        if (!empty($media)) {
            $user = User::find($media['user_id']);
            if (!empty($user)) {
                $publisher = $user['full_name'];
                $data['publisher'] = $publisher . '(' . $user['reference_id'] . ')';
                $data['publisher_email'] = $user['email'];
                if (!empty($user['updated_by'])) {
                    $updateByUser = User::find($user['updated_by']);
                    if (!empty($updateByUser))
                        $data['updated_by'] = $updateByUser['full_name'];
                    $data['updated_at'] = fullTimeFormat($updateByUser['updated_at']);
                }
            }
        }
    } elseif ($type == 'team') {
        return getUserEntityDetail($entity_id);
    } elseif ($type == 'coach') {
        return getUserEntityDetail($entity_id);
    } else {
        return getUserEntityDetail($entity_id);
    }
    return $data;
}

function getUserEntityDetail($user_id) {
    $data = [];
    $data['publisher'] = "-";
    $data['updated_by'] = "-";
    $data['updated_at'] = "-";
    $data['publisher_email'] = 0;

    $userEntity = User::find($user_id);
    if (!empty($userEntity)) {
        $user = User::find($userEntity['id']);
        if (!empty($user)) {
            $publisher = $user['full_name'];
            $data['publisher'] = $publisher . '(' . $user['reference_id'] . ')';
            $data['publisher_email'] = $user['email'];
            if (!empty($user['updated_by'])) {
                $updateByUser = User::find($user['updated_by']);
                if (!empty($updateByUser))
                    $data['updated_by'] = $updateByUser['full_name'] . '(' . $user['reference_id'] . ')';
                $data['updated_at'] = fullTimeFormat($updateByUser['updated_at']);
            }
        }
    }
    return $data;
}

/**
 * get incident data by status and from id
 * @param type $fromId
 * @param type $entityId
 * @param type $reportEntity
 * @return type
 */
function getIncidentDataByStatus($fromId, $entityId, $reportEntity) {
    $getPost = App\Models\Incident::where('from_id', $fromId)->where('entity_id', $entityId)
                    ->where('reported_entity', $reportEntity)->where('status', 'open')->first();
    return !empty($getPost) ? $getPost['status'] : '';
}

/**
 * get user by events
 * @return type
 */
function getUserByEvents($userId) {
    $getUser = User::where('role', 'team')->where('id', $userId)->first();
    return !empty($getUser) ? $getUser['first_name'] . ' ' . $getUser['last_name'] : '';
}

/**
 * get event country and state by id
 * @param type $countryId
 * @return type
 */
function getEventCountryId($type, $id) {
    if ($type == "country") {
        $getUserCountry = Country::where('country_id', $id)->first();
        $result = !empty($getUserCountry) ? $getUserCountry['name'] : '';
    }
    if ($type == "state") {
        $getUserCountry = State::where('state_id', $id)->first();
        $result = !empty($getUserCountry) ? $getUserCountry['state_name'] : '';
    }
    return $result;
}

// convert time according to location $time = 12:00:00, $toTz = Asia/Kolkala, $fromTz = UTC
function converToTz($time, $toTz, $fromTz) {
    // timezone by php friendly values
    if (empty($toTz)) {
        if (isset($_COOKIE['timezone']))
            $toTz = $_COOKIE['timezone'];
    }
    $date = new \DateTime($time, new \DateTimeZone($fromTz));
    $date->setTimezone(new \DateTimeZone($toTz));
    $data['time'] = $date->format('H:i');
    $data['tz'] = $date->format('P');
    return implode(' ', $data);
}

/*
 * get job position name
 */

function getJobPositionName($position) {
    $positionNameArray = [];
    if (!empty($position)) {
        $positionNameArray = [];
        $postionList = explode(',', $position);
        if (!empty($postionList)) {
            foreach ($postionList as $position) {
                $model = Position::where('id', $position)->first();
                $positionNameArray[] = $model->name;
            }
        } else {
            $positionNameArray[] = [];
        }
        return $positionNameArray;
    }
    return $position;
}

/**
 * Function for list team events.
 */
function getEventByTeam($id, $page) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    if (!empty($id)) {
        $userId = $id;
    }
    try {
        if ($page == "dashboard") {
            $getEvents = \App\Models\Event::where('status', 'active')->whereDate('start_date', '>=', date('Y-m-d'))
                            ->where('user_id', $userId)->take(1);
        } else {
            $getEvents = \App\Models\Event::where('status', 'active')->whereDate('start_date', '>=', date('Y-m-d'))
                            ->where('user_id', $userId)->take(2);
        }
        return $getEvents->orderBy('id', 'desc')->get();
    } catch (\Exception $e) {
        return response()->json(['success' => false, 'message' => $e->getMessage()]);
    }
}

/*
 * get job benefits name
 */

function getJobBenefitsName($benefites) {
    $benefitesNameArray = [];
    if (!empty($benefites)) {
        $benefitesNameArray = [];
        $benefitesList = explode(',', $benefites);
        if (!empty($benefitesList)) {
            foreach ($benefitesList as $benefites) {
                $model = MasterBenefits::where('id', $benefites)->first();
                $benefitesNameArray[] = $model;
            }
        } else {
            $benefitesNameArray[] = [];
        }
        return $benefitesNameArray;
    }
    return $benefites;
}

/**
 * Function for player position list.
 */
function getUserByPositions($type = "") {
    try {
        return \App\Models\Position::where('type', $type)->orderBy('id', 'asc')->get();
    } catch (\Exception $e) {
        return response()->json(['success' => false, 'message' => $e->getMessage()]);
    }
}

/**
 * Function for benefits list by job.
 */
function getBenefitsByJob() {
    try {
        return \App\Models\MasterBenefits::where('status', 'approved')->orderBy('id', 'asc')->get();
    } catch (\Exception $e) {
        return response()->json(['success' => false, 'message' => $e->getMessage()]);
    }
}

/**
 * Function for get job view count by job id
 */
function getViewCountByJob($jobId) {
    return \App\Models\JobView::where('job_id', $jobId)->count();
}

/**
 * Function for get job country
 */
function getJobCountry() {
    $country = [];
    $jobs = \App\Models\Job::get();
    if (count($jobs) > 0) {
        foreach ($jobs as $key => $job) {
            $country[$key] = !empty($job->country->name) ? getLatLangByAddress($job->country->name) : '-';
            $country[$key]['address1'] = (!empty($job->user->address_line_1)) ? $job->user->address_line_1 : '-';
        }
    }
    return $country;
}

/**
 * Function for get instagram feed form pixel union
 */
function getInstagramFeed() {
// use this instagram access token generator http://instagram.pixelunion.net/
    $access_token = env('INSTAGRAM_ACCESS_KEY');
    $json_link = "https://api.instagram.com/v1/users/self/media/recent/?";
    $json_link .= "access_token={$access_token}";
    $json = file_get_contents($json_link);
    $obj = json_decode($json, true, 512, JSON_BIGINT_AS_STRING);
    return $obj;
}

/*
 * get job position name by admin
 */

function getJobPositionByAdmin($id) {
    $position = Position::where('id', $id)->first();
    return !empty($position->name) ? $position->name : '-';
}

/*
 * get job benefits name by admin
 */

function getJobBenefitsByAdmin($id) {
    $benefits = MasterBenefits::where('id', $id)->first();
    return !empty($benefits->title) ? $benefits->title : '-';
}

/**
 * check user apply by id
 * @param type $id
 */
function checkApplyerById($jobId) {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    return ApplyJob::where(['job_id' => $jobId, 'user_id' => $userId])->count();
}

/**
 * check user applyer pending status 
 * @param type $id
 */
function checkApplyPendingStatus() {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    return ApplyJob::where(['user_id' => $userId, 'apply_status' => 'pending'])->count();
}

/*
 * get logo by event team
 */

function getTeamLogo($name) {
    $eventTeam = EventTeam::where('name', $name)->first();
    return !empty($eventTeam->logo) ? $eventTeam->logo : '';
}

/**
 * function using for check active/inactive subscriptions
 */
function checkActiveSubscriptions() {
    return Subscriptions::where(['status' => 'active'])->count();
}

/**
 * function using for get reference id by report types
 */
function getReferenceIdByReportType($entity_id, $type) {
    $data = [];
    $data['reference_id'] = "-";
    $data['publisher_id'] = "-";
    if ($type == 'event') {
        $event = \App\Models\Event::where(['id' => $entity_id])->first();
        if (!empty($event)) {
            $data['reference_id'] = $event->reference_id;
            $data['publisher_id'] = $event->user_id;
        }
    } elseif ($type == 'post') {
        $post = \App\Models\Post::where(['id' => $entity_id])->first();
        if (!empty($post)) {
            $data['reference_id'] = $post->reference_id;
            $data['publisher_id'] = $post->user_id;
        }
    } elseif ($type == 'image' || $type == 'video') {
        $media = \App\Models\UserMedia::where(['id' => $entity_id])->first();
        if (!empty($media)) {
            $data['reference_id'] = $media->reference_id;
            $data['publisher_id'] = $media->user_id;
        }
    } elseif ($type == 'team') {
        $team = \App\User::where(['id' => $entity_id])->first();
        if (!empty($team)) {
            $data['reference_id'] = $team->reference_id;
            $data['publisher_id'] = $team->id;
        }
    } elseif ($type == 'coach') {
        $coach = \App\User::where(['id' => $entity_id])->first();
        if (!empty($coach)) {
            $data['reference_id'] = $coach->reference_id;
            $data['publisher_id'] = $coach->id;
        }
    } else {
        $player = \App\User::where(['id' => $entity_id])->first();
        if (!empty($player)) {
            $data['reference_id'] = $player->reference_id;
            $data['publisher_id'] = $player->id;
        }
    }
    return $data;
}

/**
 * function using for send notifications for admin side
 */
function sendNotifacationByUser($fromId, $toId, $type, $entityId = "", $entityType = "", $referenceId = "", $viewId = "") {
    $notification = new \App\Models\Notification();
    $notification->from_id = $fromId;
    $notification->to_id = $toId;
    $menuName = '';
    $getUserType = \App\User::where('role', getAuthGuard())->first();
    // for user report send notification by user side
    if ($type == "report") {
        if ($entityType == "post") {
            $menuName = 'manage-post';
        } elseif ($entityType == "event") {
            $menuName = 'events';
        } elseif ($entityType == "chat") {
            $menuName = 'chats';
        } elseif ($entityType == "team" || $entityType == "coach" || $entityType == "player") {
            $menuName = 'users';
        } elseif ($entityType == "job") {
            $menuName = 'manage-jobs';
        } elseif ($entityType == "image" || $entityType == "video") {
            $menuName = 'manage-media';
        }
        $notification->message = "A new incident ($referenceId) has been generated for the ($entityType) [$entityId].";
    }
    // for user connect send notification by user side
    if ($type == "connect") {
        $notification->message = "you have new friend request.";
    }
    // for user accept send notification by user side
    if ($type == "accept") {
        $notification->message = "accept your friend request.";
    }
    // for user report resolve send notification by admin and subadmin side
    if ($type == "resolve_report") {
        $menuName = 'manage-incidents';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) resolved the incident ($referenceId)generated for the ($entityType) [$entityId].";
    }
    // for manage user section send notification by admin and subadmin side
    if ($type == "users_add") {
        $menuName = 'users';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) added user ($entityType) ($entityId).";
    }
    if ($type == "users_edit") {
        $menuName = 'users';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) updated ($entityType) ($entityId) info.";
    }
    if ($type == "users_active") {
        $menuName = 'users';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) activated user ($entityType) ($entityId).";
    }
    if ($type == "users_inactive") {
        $menuName = 'users';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) deactivated user ($entityType) ($entityId).";
    }
    // for manage event section send notification by admin and subadmin side
    if ($type == "event_add") {
        $menuName = 'events';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) added event ($entityType) ($entityId).";
    }
    if ($type == "event_edit") {
        $menuName = 'events';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) updated ($entityType) ($entityId)info.";
    }
    if ($type == "event_active") {
        $menuName = 'events';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) activated event ($entityType) ($entityId).";
    }
    if ($type == "event_inactive") {
        $menuName = 'events';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) deactivated event ($entityType) ($entityId).";
    }
    // for manage job section send notification by admin and subadmin side
    if ($type == "job_active") {
        $menuName = 'manage-jobs';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) activated ($entityType) ($entityId) job.";
    }
    if ($type == "job_inactive") {
        $menuName = 'manage-jobs';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) deactivated ($entityType) ($entityId) job.";
    }
    // for manage post section send notification by admin and subadmin side
    if ($type == "post_active") {
        $menuName = 'manage-post';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) activated Post ($entityId).";
    }
    if ($type == "post_inactive") {
        $menuName = 'manage-post';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) deactivated Post ($entityId).";
    }
    // for manage subscriptions section send notification by admin and subadmin side
    if ($type == "subscription_add") {
        $menuName = 'subscriptions';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) added a new plan ($entityType) [$entityId].";
    }
    if ($type == "subscription_edit") {
        $menuName = 'subscriptions';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) updated($entityType) [$entityId] plan.";
    }
    if ($type == "subscription_active") {
        $menuName = 'subscriptions';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) activated ($entityType) [$entityId] plan.";
    }
    if ($type == "subscription_inactive") {
        $menuName = 'subscriptions';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) deactivated ($entityType) [$entityId] plan.";
    }
    // for manage news section send notification by admin and subadmin side
    if ($type == "news_add") {
        $menuName = 'manage-news';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) added news ($entityId).";
    }
    if ($type == "news_edit") {
        $menuName = 'manage-news';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) updated news ($entityId).";
    }
    if ($type == "news_active") {
        $menuName = 'manage-news';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) activated news ($entityId).";
    }
    if ($type == "news_inactive") {
        $menuName = 'manage-news';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) deactivated news ($entityId).";
    }
    // for manage cms section send notification by admin and subadmin side
    if ($type == "cms_testimonial") {
        $menuName = 'cms';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) added a new testimonial.";
    }
    if ($type == "cms_about_us") {
        $menuName = 'cms';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) updated About FAF info.";
    }
    if ($type == "cms_terms_of_service") {
        $menuName = 'cms';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) updated Terms of Service info.";
    }
    if ($type == "cms_contact") {
        $menuName = 'cms';
        $notification->message = "$getUserType->full_name ($getUserType->reference_id) updated contact details.";
    }
    // for manage payment section send notification by users
    if ($type == "payment_renew") {
        $menuName = 'users';
        $notification->message = "Plan successfully renewed for ($entityType)[$entityId]";
    }
    if ($type == "payment_upgrade") {
        $menuName = 'users';
        $notification->message = "Plan successfully upgraded for ($entityType)[$entityId]";
    }
    if ($type == "payment_first") {
        $menuName = 'users';
        $notification->message = "Plan successfully purchased by ($entityType)[$entityId]";
    }
    // for manage save benefits by user send notification to admin
    if ($type == "save_benefits") {
        $menuName = 'manage-benefits';
        $notification->message = "$entityType($entityId) has requested for the Benefit ($referenceId)";
    }
    $notification->is_read = 0;
    if ($type == "cms_testimonial" || $type == "save_benefits") {
        $notification->url = $menuName;
    } elseif ($type == "cms_about_us") {
        $notification->url = $menuName . '?tab=about';
    } elseif ($type == "cms_terms_of_service") {
        $notification->url = $menuName . '?tab=tos';
    } elseif ($type == "cms_contact") {
        $notification->url = $menuName . '?tab=contact_us';
    } elseif ($type == "payment_renew" || $type == "payment_upgrade" || $type == "payment_first") {
        $notification->url = $menuName . '/view/' . base64_encode($viewId) . '?tab=plan';
    } else {
        $notification->url = $menuName . '/view/' . base64_encode($viewId);
    }
    $notification->menu_id = getSideMenu($menuName)->id;
    $notification->save();
    return $notification;
}

/**
 * function using for get side bar menus
 */
function getSideMenu($value) {
    $sideBarMenu = \App\Models\SidebarMenu::where('value', 'like', '%' . $value . '%')->first();
    return $sideBarMenu;
}

/**
 * function using for get notifications count
 */
function getNotificationCount($userId) {
    if (getAuthGuard() == "subadmin") {
        $getUserType = \App\User::where('role', 'admin')->first();
        $subAdminMenu = getSubAdminSideMenuId($userId);
        $notificationCount = \App\Models\Notification::where(['to_id' => $getUserType->id])->whereIn('menu_id', $subAdminMenu)->where('type', 'faf')->count();
    } else {
        $notificationCount = \App\Models\Notification::where('to_id', $userId)->where('type', 'faf')->count();
    }
    return $notificationCount;
}

/**
 * 
 * @param type $userId
 * Get Unread Notification Count By Admin
 */
function loadNotificationCount($userId) {
    if (getAuthGuard() == "subadmin") {
        $getUserType = \App\User::where('role', 'admin')->first();
        $subAdminMenu = getSubAdminSideMenuId($userId);
        $notification = \App\Models\Notification::where(['to_id' => $getUserType->id])->whereIn('menu_id', $subAdminMenu)->where('type', 'faf')->where('is_read', 0)->count();
    } else {
        $notification = App\Models\Notification::where('to_id', $userId)->where('type', 'faf')->where('is_read', 0)->count();
    }
    return $notification;
}

/**
 * 
 * @param type $userId
 * Update Unread Notification By Admin
 */
function updateNotificationList($userId) {
    if (getAuthGuard() == "subadmin") {
        $getUserType = \App\User::where('role', 'admin')->first();
        $subAdminMenu = getSubAdminSideMenuId($userId);
        $notification = \App\Models\Notification::where(['to_id' => $getUserType->id])->whereIn('menu_id', $subAdminMenu)->where('type', 'faf')->where('is_read', 0)->update(['is_read' => 1]);
    } else {
        $notification = \App\Models\Notification::where('to_id', $userId)->where('is_read', 0)->where('type', 'faf')->update(['is_read' => 1]);
    }
    return $notification;
}

/*
 * get job category name by category ids
 */

function getJobCategoryName($category) {
    if (!empty($category)) {
        $categoryNameArray = [];
        $categoryList = explode(',', $category);
        if (!empty($categoryList)) {
            foreach ($categoryList as $category) {
                $model = App\Models\JobCategory::where('id', $category)->first();
                $categoryNameArray[] = ucfirst($model->name);
            }
        } else {
            $categoryNameArray[] = '-';
        }
        return $categoryNameArray;
    }
    return $categoryNameArray = [];
}

/**
 * function using for get sub admin side bar menus id
 */
function getSubAdminSideMenuId($userId) {
    $subAdminMenu = [];
    $sideBarMenuId = \App\Models\UserSidebarMenu::where(['user_id' => $userId])->get();
    if (!empty($sideBarMenuId)) {
        foreach ($sideBarMenuId as $val) {
            $subAdminMenu[] = $val->menu_id;
        }
    }
    return $subAdminMenu;
}

/*
 * function using for count all events
 */

function getDetailBytype($type) {
    if ($type == 'members') {
        $userData = User::where('role', '<>', 'admin')->where('role', '<>', 'subadmin')->get();
    }
    if ($type == 'countries') {
        $userData = User::where('role', '<>', 'admin')->where('role', '<>', 'subadmin')->groupBy('country_id')->get();
    }
    if ($type == 'teams') {
        $userData = User::where('role', '=', 'team')->get();
    }
    if ($type == 'staffs') {
        $userData = User::where('role', '=', 'coach')->get();
    }
    if ($type == 'players') {
        $userData = User::where('role', '=', 'player')->get();
    }
    if ($type == 'jobs') {
        $userData = Job::where('status', '=', 'active')->get();
    }
    if ($type == 'events') {
        $userData = Event::where('status', '=', 'active')->get();
    }
    if ($type == 'videos') {
        $userData = UserMedia::where('media_type', '=', 'video')->get();
    }
    if ($type == 'images') {
        $userData = UserMedia::where('media_type', '=', 'image')->get();
    }
    if ($type == 'posts') {
        $userData = Post::where('status', '=', 'active')->get();
    }
    $usercount = $userData->count();
    return $usercount;
}

/**
 * function using for send notifications for front side
 */
function sendNotifacationByFrontUser($fromId, $toId, $type, $attributeName = "", $viewId = "") {
    $notification = new \App\Models\Notification();
    $notification->from_id = $fromId;
    $notification->to_id = $toId;
    $menuName = '';
    $data = [];
    // for user block send notification user side
    if ($type == "block") {
        $notification->message = "is blocked your profile";
    }
    // for user connect send notification user side
    if ($type == "connect") {
        $notification->message = "has sent you a new friend request.";
    }
    // for user accept request send notification user side
    if ($type == "accept") {
        $menuName = 'view/' . getUserById($fromId, 'role') . '-profile/' . getUserById($fromId, 'slug');
        $notification->message = "has accepted your friend request.";
    }
    // for user validated attribute send notification user side
    if ($type == "validate_attribute") {
        $menuName = 'player/player-profile';
        $notification->message = "has validated your attribute – [$attributeName])";
    }
    // for user post comments send notification user side
    if ($type == "post_comments") {
        $menuName = 'post-details/' . base64_encode($viewId);
        $notification->message = "has commented on your post.";
    }
    // for user post like send notification user side
    if ($type == "post_likes") {
        $menuName = 'post-details/' . base64_encode($viewId);
        $notification->message = "has liked your post.";
    }
    // for user post like update send notification user side
    if ($type == "post_update_like") {
        $menuName = 'post-details/' . base64_encode($viewId);
        $notification->message = "has edited the post you liked.";
    }
    // for user post comment update send notification user side
    if ($type == "post_update_comment") {
        $menuName = 'post-details/' . base64_encode($viewId);
        $notification->message = "has edited the post you commented on.";
    }
    // for user follow your profile send notification user side
    if ($type == "user_follow") {
        $menuName = 'view/' . getUserById($fromId, 'role') . '-profile/' . getUserById($fromId, 'slug');
        $notification->message = "has tracked you down.";
    }
    // for user like your profile send notification user side
    if ($type == "user_like") {
        $menuName = 'view/' . getUserById($fromId, 'role') . '-profile/' . getUserById($fromId, 'slug');
        $notification->message = "has liked your profile.";
    }
    // for user view your profile send notification user side
    if ($type == "user_view") {
        $menuName = 'view/' . getUserById($fromId, 'role') . '-profile/' . getUserById($fromId, 'slug');
        $notification->message = "viewed your profile.";
    }
    // for team job create send notification user side
    if ($type == "team_jobs") {
        $menuName = 'jobs-detail/' . base64_encode($viewId);
        $notification->message = "has created a new [$attributeName] job.";
    }
    // for team job edit send notification user side
    if ($type == "team_apply_jobs") {
        $menuName = 'jobs-detail/' . base64_encode($viewId);
        $notification->message = "The job you applied to has been edited.";
    }
    // for team job expired send notification user side
    if ($type == "team_expired_jobs") {
        $menuName = 'jobs-detail/' . base64_encode($viewId);
        $notification->message = "The [$attributeName] job you applied to has expired.";
    }
    // for user event create send notification user side
    if ($type == "user_add_event") {
        $menuName = 'event/' . base64_encode($viewId);
        $notification->message = "has created a new event ($attributeName).";
    }
    // for user event edit send notification user side
    if ($type == "user_edit_event") {
        $menuName = 'event/' . base64_encode($viewId);
        $notification->message = "has edited the event ($attributeName).";
    }
    // for user download procard send notification user side
    if ($type == "download_procard") {
        $menuName = 'view/' . getUserById($fromId, 'role') . '-profile/' . getUserById($fromId, 'slug');
        $notification->message = "downloaded your pro-card.";
    }
    // for manage benefits approved section send notification by admin
    if ($type == "benefit_approved") {
        $menuName = getUserById($toId, 'role') . '/' . getUserById($toId, 'role') . '-profile-form';
        $notification->message = "Your request for the benefit ($attributeName) has been approved by admin.";
    }
    // for chat messages section send notification user side
    if ($type == "user_messages") {
        $menuName = getUserById($toId, 'role') . '/messages';
        $notification->message = "has sent you a message.";
    }
    // for user update profile section send notification user side
    if ($type == "user_update_profile") {
        $menuName = 'view/' . getUserById($fromId, 'role') . '-profile/' . getUserById($fromId, 'slug');
        $notification->message = "has updated his profile.";
    }
    // for user payment decline first time send notification user side
    if ($type == "payment_decline_first") {
        $menuName = "settings";
        $notification->message = "Please update your payment information within (by today) to continue using your FAF account.";
    }
    // for user payment decline after 7 days send notification user side
    if ($type == "payment_decline_7_days") {
        $menuName = "settings";
        $notification->message = "Please update your payment information within (next 7 days) to continue using your FAF account.";
    }
    // for user payment decline after 14 days send notification user side
    if ($type == "payment_decline_14_days") {
        $menuName = "settings";
        $notification->message = "Please update your payment information within (next 14 days) to continue using your FAF account.";
    }
    $notification->is_read = 0;
    $notification->url = $menuName;
    $notification->save();
    $notificationFlag = getUserById($toId, 'notification_flag');
    $phoneNumber = getCountryCodeForSms(getUserById($toId, 'country_id')) . '' . getUserById($toId, 'phone_number');
    $smsMessage = "Hello Text";
    if ($type == "connect") {
        $data['name'] = getUserById($toId, 'full_name');
        $data['user_image'] = checkUserImage(getUserById($toId, 'profile_image'), getUserById($toId, 'role'));
        $data['user_notitcation'] = getUserById($fromId, 'full_name') . ' ' . $notification->message;
        $data['email'] = getUserById($toId, 'email');
        $data['request'] = 'user_notification_mail';
        $data['subject'] = 'User notification mail';
        if ($notificationFlag == "email") {  // for email by setting
            $result = sendMail($data);
        } elseif ($notificationFlag == "sms") { // for sms by setting
            sendTextSMS($smsMessage, $phoneNumber);
        } elseif ($notificationFlag == "both") { // for email and sms by setting
            sendTextSMS($smsMessage, $phoneNumber);
            $result = sendMail($data);
        }
    }
}

/*
 * Get latest news add by admin
 */

function getLastUpdateNews($attribute) {
    $quesry = News::where('status', 'active')->OrderBy('id', 'desc')->first();
    if (empty($quesry)) {
        return '';
    }
    return $quesry->$attribute;
}

/*
 * function using for send notifications for user expired jobs
 */

function expiredAppliedJobByUser($userId) {
    $getAppliedJobs = ApplyJob::where(['user_id' => $userId, 'apply_status' => 'yes'])->get();
    $currentDate = date("Y-m-d");
    if (!empty($getAppliedJobs)) {
        foreach ($getAppliedJobs as $val) {
            $getExpiredJobs = Job::where('id', $val->job_id)->whereDate('apply_date', '<', $currentDate)->get();
            if ($getExpiredJobs->count() > 0) {
                foreach ($getExpiredJobs as $job) {
                    sendNotifacationByFrontUser($job->user_id, $userId, 'team_expired_jobs', $job->job_type, $job->id);
                }
            } else {
                break;
            }
        }
    }
}

/**
 * check user connect with this user connect and follow
 * @param type $userId
 */
function checkUserConnectAndFollow($userId) {
    $followUser = ProfileTracker::where(['to_id' => $userId, 'type' => 'follow'])->get();
    if (!empty($followUser)) {
        foreach ($followUser as $val) {
            sendNotifacationByFrontUser($userId, $val->from_id, 'user_update_profile', '', '');
        }
    }
}

/*
 * check and get lat long by zip code
 */

function getLatLongByZip($value) {
    $arrContextOptions = array(
        "ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
        ),
    );
    $json = file_get_contents("https://maps.google.com/maps/api/geocode/json?key=AIzaSyC6UvgQK_Ua6wHk9J5Up0IcGJVPvko1lvI&address=" . urlencode($value) . "&sensor=false", false, stream_context_create($arrContextOptions));
    $json = json_decode($json);
    //echo '<pre>';print_r($json);die;
    $lat = '';
    $long = '';
    if ($json->{'status'} == 'OK') {
        $lat = $json->{'results'}[0]->geometry->location->lat;
        $long = $json->{'results'}[0]->geometry->location->lng;
    }
    if (empty($lat) || empty($long)) {
        return '';
    }
    Session::put('latLong', $lat . '&' . $long);
    return $lat . '&' . $long;
}

/**
 * sms code for send text message by AWS SNS Service
 * @param type $message
 * @param type $phone
 */
function sendTextSMS($message, $phone) {
//    $params = array(
//        'credentials' => array(
//            'key' => env("AWS_SNS_KEY"),
//            'secret' => env("AWS_SNS_SECRET_KEY"),
//        ),
//        'region' => env("AWS_SNS_REGION"), // < your aws from SNS Topic region
//        'version' => env("AWS_SNS_VERSION")
//    );
//    $sns = new \Aws\Sns\SnsClient($params);
//
//    $args = array(
//        "MessageAttributes" => [
//            'AWS.SNS.SMS.SenderID' => [
//                'DataType' => 'String',
//                'StringValue' => env("AWS_SNS_SENDER_ID")
//            ],
//            'AWS.SNS.SMS.SMSType' => [
//                'DataType' => 'String',
//                'StringValue' => 'Transactional'
//            ]
//        ],
//        "Message" => $message,
//        "PhoneNumber" => $phone  // mobile with country code
//    );
//    $result = $sns->publish($args);
//    return $result;
}

/*
 * get sum of total uploaded media size by user id
 */

function getUploadedMediaSizeByUser() {
    $userId = Auth::guard(getAuthGuard())->user()->id;
    return UserMedia::where('user_id', $userId)->sum('size');
}

/*
 * get count of total subscribed users by plan id
 */

function checkPlanSubscribedUser($id) {
    return User::where('subscription_id', $id)->count();
}

// get country code by id for send sms
function getCountryCodeForSms($countryId) {
    if (!empty($countryId)) {
        $country = Country::where('country_id', $countryId)->first();
        return $country['phonecode'];
    }
}

/**
 * 08-feb-2019
 * function using for conver size byte to GB
 */
function convertSize($size) {
    if ($size >= 1073741824) {
        return number_format($size / 1073741824, 2);
    } else {
        return false;
    }
}

/*
 * 08-feb-2019
 * function using for convert time second to h:i:s formate 
 */

function convertTimeToHrs($seconds) {
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds / 60) % 60);
    $seconds = $seconds % 60;
    return "$hours:$minutes:$seconds";
}

// get post media
function checkPostMedia($image, $folder) {
    $src = url('public/images/default-media.jpg');
    $fileName = public_path() . '/uploads/' . $folder . '/' . $image;
    if (!empty($image) && file_exists($fileName)) {
        $src = url('public/uploads/' . $folder . '/' . $image);
    }
    return $src;
}

// convert bytes to other readable unit

function readableBytesToUnit($size, $unit) {
    if ($unit == "KB") {
        return $fileSize = round($size / 1024, 2) . ' KB';
    }
    if ($unit == "MB") {
        return $fileSize = round($size / 1024 / 1024, 2) . ' MB';
    }
    if ($unit == "GB") {
        return $fileSize = round($size / 1024 / 1024 / 1024, 2) . ' GB';
    }
}

// consumed space to percent 
function consumedSpaceToPercent($consumedSpace, $totalPlanSpace) {
    $totalPlanSpaceInByte = $totalPlanSpace * (1024 * 1024 * 1024);    // convert total plan space (GB) to bytes
    return round((($consumedSpace / $totalPlanSpaceInByte) * 100), 2);
}

//function using for get post Action count
function countPostActionByType($postId, $type) {
    $result = UserPostAction::where(['post_id' => $postId, 'type' => $type])->count();
    return convertLikeFormat($result);
}

// convert 1000 to k format
function convertLikeFormat($action) {
    if ($action > 1000) {
        $count = $action * 1 / 1000;
        $number = round($count, PHP_ROUND_HALF_UP);
        return "$number  k";
    } else {
        return $action;
    }
}

// get post media images for faf-tube for home page 
function checkFafTubePostMedia($image, $folder) {
    $src = env('FAFTUBE_LINK') . '/public/images/default-media.jpg';
    $fileName = env('FAFTUBE_LINK') . '/public/uploads/' . $folder . '/' . $image;
    if (@file_get_contents($fileName) != false) {
        $src = $fileName;
    }
    return $src;
}

/**
 * get cms data (setting) by type.
 * @param type $title
 * @return type response
 */
function getSettingBykey($title) {
    $setting = \App\Models\Settings::where("title", $title)->first(['value']);
    return !empty($setting->value) ? $setting->value : '';
}