import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators'
import { Register } from './register';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({ providedIn: 'root' })
export class UserService {

  constructor(
    private http: HttpClient
  ) { }

  addUser(user): Observable<any> {
    let url: string = 'http://localhost/laravel_angular/laravel_angular/api/registration';
    let data = {
      name: user.name,
      email: user.email,
      password: user.password
    };
    return this.http.post<Register>(url, data, httpOptions).pipe(
      tap((data: Register) => this.log(`added user`)),
      catchError(this.handleError<Register>('addUser'))
    );
  }

  getUser(): Observable<Register[]> {
    let getUrl = "http://localhost/laravel_angular/laravel_angular/api/get-users";
    return this.http.get<Register[]>(getUrl)
      .pipe(
        tap(users => this.log(`fetched users`)),
        catchError(this.handleError('getUser', []))
      );
  }

  deleteUser(user: Register | any): Observable<Register> {
    let deleteUrl = "http://localhost/laravel_angular/laravel_angular/api/delete-user";
    const id = typeof user === 'number' ? user : user.id;
    const url = `${deleteUrl}/${id}`;
    return this.http.post<Register>(url, httpOptions).pipe(
      tap(user => this.log(`deleted user id=${id}`)),
      catchError(this.handleError<Register>('deleteUser'))
    );
  }

  getEditUser(id: number): Observable<Register> {
    let editUrl = "http://localhost/laravel_angular/laravel_angular/api/edit-user";
    const url = `${editUrl}/${id}`;
    return this.http.get<Register>(url).pipe(
      tap(_ => this.log(`edit user id=${id}`)),
      catchError(this.handleError<Register>(`getEditUser id=${id}`))
    );
  }

  editUserById(user): Observable<any> {
    let url: string = 'http://localhost/laravel_angular/laravel_angular/api/update-user';
    let data = {
      userId : user,
      name: user.name,
      email: user.email
    };
    console.log(data);
    return this.http.post<Register>(url, data, httpOptions).pipe(
      tap((data: Register) => this.log(`update user`)),
      catchError(this.handleError<Register>('editUserById'))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      this.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }

  private log(message: string) {
  }
}
