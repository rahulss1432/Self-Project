import { Component, OnInit, ElementRef, ViewChild } from "@angular/core";
import { Auth } from '../model/auth';
import { AuthLoginService } from '../auth_service/auth-login.service';
import { NgForm, FormsModule } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  errormessage = "red";
  model = [];
  constructor(
    private AuthServiceApi: AuthLoginService,
    private router: Router,
    private toasterApi: ToastrService
  ) { }

  ngOnInit() {

  }

  submitted = false;
  onSubmit(userData: NgForm) {
    this.submitted = true;
    if (userData.valid) {
      this.AuthServiceApi.userSignup(userData.value).subscribe(
        res => {
          if (res['success'] === true) {
            this.toasterApi.success(res['data']);
            this.router.navigate(['/login']);
          } else {
            this.toasterApi.error(res['data']);
          }
        },
        err => {
          if (err.error.error.length) {
            err.error.error.map((e, i) => {
              alert(err.error.error[i].message);
            });
          }
          else {
            alert('Something went wrong');
          }
        });
    }
  }

}
