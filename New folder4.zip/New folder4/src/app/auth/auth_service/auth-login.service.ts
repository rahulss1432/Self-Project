import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Response } from '@angular/http';

import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';

@Injectable({
  providedIn: 'root'
})

export class AuthLoginService {

  constructor(private http: HttpClient,
    private router: Router) { }


  userSignup(info): Observable<Response> {
    let url: string = 'http://localhost/new_angular_laravel/api/signup';
    let formData = new FormData();
    formData.append('email', info.email);
    formData.append('name', info.name);
    formData.append('password', info.password);
    return this.http.post<any>(url, formData).pipe(map(user => {
      if (user['success'] == true) {
        return user;
      } else {
        return user;
      }
    }))
  }

  socialLoginUser(info): Observable<Response> {
    let url: string = 'http://localhost/new_angular_laravel/api/social-login';
    let formData = new FormData();
    formData.append('email', info.email);
    formData.append('name', info.name);
    if (info.provider == "google") {
      formData.append('google_id', info.id);
    } else if (info.provider == "facebook") {
      formData.append('facebook_id', info.id);
    }
    formData.append('provider', info.provider);
    return this.http.post<any>(url, formData).pipe(map(user => {
      if (user['success'] == true) {
        return user;
      } else {
        return user;
      }
    }))
  }

  loginUser(info): Observable<Response> {
    let url: string = 'http://localhost/new_angular_laravel/api/login';
    let formData = new FormData();
    formData.append('email', info.email);
    formData.append('password', info.password);
    return this.http.post<any>(url, formData).pipe(map(user => {
      if (user['success'] == true) {
        localStorage.setItem('currentUser', JSON.stringify(user));
        return user;
      } else {
        return user;
      }
    }))
  }

  getLoginUser() {
    return JSON.parse(localStorage.getItem("currentUser"));
  }

  isLoggednIn() {
    return this.getLoginUser() !== null;
  }

  logout(): void {
    localStorage.removeItem('currentUser');
    this.router.navigate(["/login"]);
  }

  loginUserDetails(userId: number) {
    let url: string = 'http://localhost/new_angular_laravel/api/user-details';
    return this.http.get(url + '/' + userId).pipe(map(res => {
      return res;
    }))
  }

  changePassword(currentPassword: string, password: string) {
    let userId = this.getLoginUser().data.id;
    let url: string = 'http://localhost/new_angular_laravel/api/change-password';
    let formData = new FormData();
    formData.append('userId', userId);
    formData.append('oldPassword', currentPassword);
    formData.append('newPassword', password);
    return this.http.post<any>(url, formData).pipe(map(user => {
      if (user['success'] == true) {
        return user;
      } else {
        return user;
      }
    }))

  }

}
