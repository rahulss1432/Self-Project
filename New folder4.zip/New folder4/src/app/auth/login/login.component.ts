import { Component, OnInit } from "@angular/core";
import { Auth } from '../model/auth';
import { AuthLoginService } from '../auth_service/auth-login.service';
import { NgForm, FormsModule } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import {
  AuthService,
  FacebookLoginProvider,
  GoogleLoginProvider
} from 'angular-6-social-login';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  errormessage = "red";
  model = [];
  constructor(
    private AuthLoginServiceApi: AuthLoginService,
    private SocialAuthServiceApi: AuthService,
    private router: Router,
  ) { }


  ngOnInit() {
  }

  submitted = false;
  onLogin(loginData: NgForm) {
    this.submitted = true;
    if (loginData.valid) {
      this.AuthLoginServiceApi.loginUser(loginData.value).subscribe(
        res => {
          if (res['success'] === true) {
            this.router.navigate(['/dashboard']);
          } else {
            alert('Something went wrong');
          }
        },
        err => {
          if (err.error.error.length) {
            err.error.error.map((e, i) => {
              alert(err.error.error[i].message);
            });
          }
          else {
            alert('Something went wrong');
          }
        });
    }
  }

  public socialSignIn(socialPlatform: string) {
    let socialPlatformProvider;
    if (socialPlatform == "facebook") {
      socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
    } else if (socialPlatform == "google") {
      socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;
    }

    this.SocialAuthServiceApi.signIn(socialPlatformProvider).then(
      (userData) => {
        this.AuthLoginServiceApi.socialLoginUser(userData).subscribe(
          res => {
            if (res['success'] === true) {
              this.router.navigate(['/dashboard']);
            } else {
              alert('Something went wrong');
            }
          },
          err => {
            if (err.error.error.length) {
              err.error.error.map((e, i) => {
                alert(err.error.error[i].message);
              });
            }
            else {
              alert('Something went wrong');
            }
          });

      }
    );
  }

}
