import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, AbstractControl, ReactiveFormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AuthLoginService } from '../../auth/auth_service/auth-login.service';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  resetFormGroup: FormGroup;
  loading = false;

  constructor(
    private toastr: ToastrService,
    private authenticationService: AuthLoginService,
    fb: FormBuilder
  ) {
    this.resetFormGroup = fb.group({
      password: ['', Validators.required],
      currentPassword: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    }, {
        validator: this.MatchPassword
      })
  }

  ngOnInit() {
  }

  onSubmit() {
    this.loading = true;
    this.authenticationService.changePassword(
      this.resetFormGroup.controls['currentPassword'].value,
      this.resetFormGroup.controls['password'].value
    ).subscribe(result => {
      if (result['success'] === true) {
        this.toastr.success(result.message);
        this.resetFormGroup.reset();
        this.loading = false;
      } else {
        this.toastr.error(result.message);
        this.loading = false;
      }
    },
      (err) => {
        this.toastr.error(err.error.message);
        this.loading = false;
      })
  }

  MatchPassword(AC: AbstractControl) {
    const password = AC.get('password').value;
    const confirmPassword = AC.get('confirmPassword').value;
    if (password !== confirmPassword) {
      AC.get('confirmPassword').setErrors({ MatchPassword: true })
    } else {
      return null
    }
  }


}
