import { Component, OnInit, ViewChild } from '@angular/core';
import { CalendarComponent } from 'ng-fullcalendar';
import { Options } from 'fullcalendar';
import { EventsService } from './service/events.service';

@Component({
  selector: 'app-eventcalendar',
  templateUrl: './eventcalendar.component.html',
  styleUrls: ['./eventcalendar.component.css']
})
export class EventcalendarComponent implements OnInit {

  calendarOptions: Options;
  events: any;
  @ViewChild(CalendarComponent) ucCalendar: CalendarComponent;
  constructor(
    private eventsService: EventsService
  ) { }
  ngOnInit() {
    this.calendarOptions = {
      editable: true,
      eventLimit: false,
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay,listMonth'
      },
      events: [{
        title: 'All Day Event',
        start: '2018-09-01'
      },
      {
        title: 'Long Event',
        start: '2018-09-07',
        end: '2018-09-10'
      },
      {
        id: 997,
        title: 'Repeating Event',
        start: '2018-09-08'
      },
      {
        id: 998,
        title: 'Repeating Event',
        start: '2018-09-03'
      },
      {
        title: 'Conference',
        start: '2018-09-25',
        end: '2018-09-15'
      }]
    };
  }
  clickButton(model: any) {
    this.events = model;
  }
  eventClick(model: any) {
    model = {
      event: {
        id: model.event.id,
        start: model.event.start,
        end: model.event.end,
        title: model.event.title,
        allDay: model.event.allDay
      },
      duration: {}
    }
    this.events = model;
  }
  updateEvent(model: any) {
    model = {
      event: {
        id: model.event.id,
        start: model.event.start,
        end: model.event.end,
        title: model.event.title
      },
      duration: {
        _data: model.duration._data
      }
    }
    this.events = model;
  }
}
