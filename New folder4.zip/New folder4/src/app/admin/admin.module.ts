import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AdminComponent } from './admin.component';
import { adminRouting } from './admin-routing';
import { HeaderComponent } from './layout/header/header.component';
import { SidebarComponent } from './layout/sidebar/sidebar.component';
import { FooterComponent } from './layout/footer/footer.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ChartsComponent } from './charts/charts.component';
import { ImagecropperComponent } from './imagecropper/imagecropper.component';
import { NgxCropperModule } from 'ngx-cropper';
import { ImageuploadService } from './imagecropper/service/imageupload.service';
import { FullCalendarModule } from 'ng-fullcalendar';
import { EventcalendarComponent } from './eventcalendar/eventcalendar.component';
import { EventsService } from './eventcalendar/service/events.service';
import { AddressmapComponent } from './addressmap/addressmap.component';
import { AgmCoreModule, GoogleMapsAPIWrapper } from '@agm/core';
import { AccountComponent } from './account/account.component';
import { GooglePlaceModule } from "ngx-google-places-autocomplete";
import { SortablejsModule } from 'angular-sortablejs';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { UserlistComponent } from './userlist/userlist.component';
import { DataTableModule } from "angular-6-datatable";

@NgModule({
  declarations: [
    AdminComponent,
    HeaderComponent,
    SidebarComponent,
    FooterComponent,
    DashboardComponent,
    ChartsComponent,
    ImagecropperComponent,
    EventcalendarComponent,
    AddressmapComponent,
    AccountComponent,
    ChangepasswordComponent,
    UserlistComponent,
  ],
  imports: [
    CommonModule,
    adminRouting,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpModule,
    NgxCropperModule,
    FullCalendarModule,
    AgmCoreModule.forRoot({ apiKey: 'AIzaSyBkRtGTnWRVRxjr9H1OoaSfro-Dd7qKmAk' }),
    GooglePlaceModule,
    SortablejsModule.forRoot({ animation: 200 }),
    DataTableModule
  ],
  providers: [
    ImageuploadService,
    EventsService,
    GoogleMapsAPIWrapper
  ],
  bootstrap: [AdminComponent]
})
export class AdminModule { }
