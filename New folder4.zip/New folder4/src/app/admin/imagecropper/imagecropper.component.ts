import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from "@angular/router";
import { ImageuploadService } from './service/imageupload.service';
import { ItemImagemodel } from './model/ItemImagemodel';
import { SortablejsOptions } from 'angular-sortablejs';

@Component({
  selector: 'app-imagecropper',
  templateUrl: './imagecropper.component.html',
  styleUrls: ['./imagecropper.component.css']
})
export class ImagecropperComponent implements OnInit {
  itemImageList = [];
  id: number;
  selectedFile: Array<any>;
  public ngxCropperConfig: object;
  constructor(
    private toastr: ToastrService,
    private router: Router,
    private ImageuploadServiceApi: ImageuploadService,
  ) {
    this.ngxCropperConfig = {
      url: 'http://localhost/new_angular_laravel/api/upload-cropp-image',
      maxsize: 512000, // image max size, default 500k = 512000bit
      title: 'Apply your image size and position', // edit modal title, this is default
      uploadBtnName: 'Upload Image', // default Upload Image
      uploadBtnClass: null, // default bootstrap styles, btn btn-primary
      cancelBtnName: 'Cancel', // default Cancel
      cancelBtnClass: null, // default bootstrap styles, btn btn-default
      applyBtnName: 'Apply', // default Apply
      applyBtnClass: null, // default bootstrap styles, btn btn-primary
      fdName: 'file', // default 'file', this is  Content-Disposition: form-data; name="file"; filename="fire.jpg"
      aspectRatio: 1 / 1,// default 1 / 1, for example: 16 / 9, 4 / 3 ...
      viewMode: 1
    }
    this.router.navigate(['image-cropper']);
  }

  public onReturnData(data: any) {
    this.toastr.success('image uploaded successfully!');
    this.router.navigate(['image-section']);
  }

  ngOnInit() {
    this.getImageList();
  }

  options: SortablejsOptions = {
    onUpdate: () => {
      this.updateList(this.itemImageList);
    }

  };

  updateList(imageList): void {
    this.ImageuploadServiceApi.updateImageList(imageList).subscribe(res => {
      if (res['success'] == true) {
        this.toastr.success(res['data'], 'Image');
        this.router.navigate(['image-section']);
      }
    });
  }

  getImageList() {
    this.ImageuploadServiceApi.itemImageList().subscribe(
      res => {
        if (res['success'] === true) {
          this.itemImageList = res['data'];
        }
      })
  }

  deleteItemImage(id: any) {
    this.ImageuploadServiceApi.deleteItemImage(id).subscribe(
      res => {
        if (res['success'] === true) {
          this.toastr.success('item image Deleted successfully!');
          this.router.navigate(['image-section']);
        }
      })
  }

  onFileChanged(event) {
    this.selectedFile = event.target.files;
    if (this.selectedFile.length <= 10) {
      const uploadData = new FormData();
      for (let file of this.selectedFile) {
        uploadData.append('filename[]', file, file.name);
      }
      this.ImageuploadServiceApi.uploadMultiImage(uploadData).subscribe(res => {
        if (res['success'] == true) {
          this.toastr.success(res['message'], 'Image');
          location.reload();
        } else {
          this.toastr.error(res['message'], 'Image');
        }
      });
    } else {
    }
  }

}

