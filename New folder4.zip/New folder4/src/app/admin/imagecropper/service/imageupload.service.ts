import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Response } from '@angular/http';

import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ImageuploadService {

  constructor(
    private http: HttpClient,
    private router: Router
  ) { }

  itemImageList() {
    let url: string = 'http://localhost/new_angular_laravel/api/get-item-image-list';
    return this.http.get(url).pipe(map(res => {
      return res;
    }))
  }

  deleteItemImage(id) {
    let url: string = 'http://localhost/new_angular_laravel/api/delete-item-image';
    return this.http.get(url + '/' + id).pipe(map(res => {
      return res;
    }))
  }

  updateImageList(imageList: any) {
    let url: string = 'http://localhost/new_angular_laravel/api/update-image-list';
    const a = this.http.post(url, imageList);
    return a.pipe(map((res: any) => res));
  }

  uploadMultiImage(uploadData) {
    let url: string = 'http://localhost/new_angular_laravel/api/multi-image-upload';
    const a = this.http.post(url, uploadData);
    return a.pipe(map((res: any) => res));
  }

}
