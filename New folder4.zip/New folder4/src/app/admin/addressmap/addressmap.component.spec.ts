import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressmapComponent } from './addressmap.component';

describe('AddressmapComponent', () => {
  let component: AddressmapComponent;
  let fixture: ComponentFixture<AddressmapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddressmapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressmapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
