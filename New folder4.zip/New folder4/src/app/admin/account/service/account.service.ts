import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Response } from '@angular/http';

import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private http: HttpClient,
    private router: Router) { }

  accountFormSubmit(info, file: any, id: any): Observable<Response> {
    let url: string = 'http://localhost/new_angular_laravel/api/useraccount';
    let formData = new FormData();
    formData.append("profileImage", file ? file : "");
    formData.append("id", id);
    formData.append('name', info.name);
    formData.append('city', info.city);
    formData.append('state', info.state);
    formData.append('country', info.country);
    formData.append('latitude', info.latitude);
    formData.append('longitude', info.longitude);
    return this.http.post<any>(url, formData).pipe(map(user => {
      if (user['success'] == true) {
        return user;
      } else {
        return user;
      }
    }))
  }
}
