import { Component, OnInit, ElementRef, ViewChild, Input, NgZone } from "@angular/core";
import { FormGroup, NgForm, FormsModule, ReactiveFormsModule, Validators, FormControl } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { AccountService } from './service/account.service';
import { AuthLoginService } from '../../auth/auth_service/auth-login.service';
import { ToastrService } from 'ngx-toastr';
import { MapsAPILoader, AgmMap } from '@agm/core';
import { GoogleMapsAPIWrapper } from '@agm/core/services';

declare var google: any;

interface Marker {
  lat: number;
  lng: number;
  label?: string;
  draggable: boolean;
}

interface Location {
  lat?: number;
  lng?: number;
  viewport?: Object;
  zoom: number;
  city?: string;
  state?: string;
  country?: string;
  marker?: Marker;
}

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  @ViewChild("fileInput") inputEl: ElementRef;
  accountFrom = FormGroup;
  private fileList: any = [];
  photo: any;
  loginUser: any;
  userName: any = [];
  errormessage = "red";

  geocoder: any;
  public location: Location = {
    lat: 22.719568,
    lng: 75.857727,
    marker: {
      lat: 22.719568,
      lng: 75.857727,
      draggable: true
    },
    zoom: 10
  };

  @ViewChild(AgmMap)
  public agmMap: AgmMap
  constructor(
    private el: ElementRef,
    private router: Router,
    private accountApi: AccountService,
    private AuthServiceApi: AuthLoginService,
    private toastr: ToastrService,
    public mapsApiLoader: MapsAPILoader,
    private zone: NgZone,
    private wrapper: GoogleMapsAPIWrapper
  ) {
    this.mapsApiLoader = mapsApiLoader;
    this.zone = zone;
    this.wrapper = wrapper;
    this.mapsApiLoader.load().then(() => {
      this.geocoder = new google.maps.Geocoder();
    });
  }


  ngOnInit() {
    this.loginUser = this.AuthServiceApi.getLoginUser();
    this.AuthServiceApi.loginUserDetails(this.loginUser.data.id).subscribe(
      res => {
        if (res['success'] === true) {
          this.userName = res['data'];
          if (this.userName.latitude != '' && this.userName.longitude != '') {
            this.location.city = this.userName.city;
            this.location.state = this.userName.state;
            this.location.country = this.userName.country;
            this.location.lat = parseFloat(this.userName.latitude);
            this.location.lng = parseFloat(this.userName.longitude);
            this.location.marker.lat = parseFloat(this.userName.latitude);
            this.location.marker.lng = parseFloat(this.userName.longitude);
            this.agmMap.triggerResize();
          }
        }
      })
    this.location.marker.draggable = true;
  }

  updateOnMap() {
    let full_address: string = this.location.city || ""
    if (this.location.state) full_address = full_address + " " + this.location.state
    if (this.location.country) full_address = full_address + " " + this.location.country
    this.findLocation(full_address);
  }

  findLocation(address) {
    if (!this.geocoder) this.geocoder = new google.maps.Geocoder()
    this.geocoder.geocode({
      'address': address
    }, (results, status) => {
      if (status == google.maps.GeocoderStatus.OK) {
        for (var i = 0; i < results[0].address_components.length; i++) {
          let types = results[0].address_components[i].types
          if (types.indexOf('country') != -1) {
            this.location.country = results[0].address_components[i].long_name
          }
          if (types.indexOf('administrative_area_level_1') != -1) {
            this.location.state = results[0].address_components[i].long_name
          }
        }

        if (results[0].geometry.location) {
          this.location.lat = results[0].geometry.location.lat();
          this.location.lng = results[0].geometry.location.lng();
          this.location.marker.lat = results[0].geometry.location.lat();
          this.location.marker.lng = results[0].geometry.location.lng();
          this.location.marker.draggable = true;
          this.location.viewport = results[0].geometry.viewport;
        }
        this.agmMap.triggerResize()
      } else {
        alert("Sorry, this search produced no results.");
      }
    })
  }

  markerDragEnd(m: any, $event: any) {
    this.location.marker.lat = m.coords.lat;
    this.location.marker.lng = m.coords.lng;
    this.location.lat = this.location.marker.lat;
    this.location.lng = this.location.marker.lng;
    this.findAddressByCoordinates();
  }

  findAddressByCoordinates() {
    this.geocoder.geocode({
      'location': {
        lat: this.location.marker.lat,
        lng: this.location.marker.lng
      }
    }, (results, status) => {
      this.decomposeAddressComponents(results);
    })
  }

  decomposeAddressComponents(addressArray) {
    if (addressArray.length == 0) return false;
    let address = addressArray[0].address_components;

    for (let element of address) {
      if (element.length == 0 && !element['types']) continue

      if (element['types'].indexOf('street_number') > -1) {
        this.location.city = element['long_name'];
        continue;
      }
      if (element['types'].indexOf('route') > -1) {
        this.location.city += ', ' + element['long_name'];
        continue;
      }
      if (element['types'].indexOf('locality') > -1) {
        this.location.city = element['long_name'];
        continue;
      }
      if (element['types'].indexOf('administrative_area_level_1') > -1) {
        this.location.state = element['long_name'];
        continue;
      }
      if (element['types'].indexOf('country') > -1) {
        this.location.country = element['long_name'];
        continue;
      }
    }
  }

  submitted = false;
  onSubmit(postData: NgForm) {
    this.submitted = true;
    if (postData.valid) {
      this.loginUser = this.AuthServiceApi.getLoginUser();
      this.accountApi.accountFormSubmit(postData.value, this.fileList, this.loginUser.data.id).subscribe(
        res => {
          if (res['success'] === true) {
            this.toastr.success(res['data']);
            this.router.navigate(['/account']);
          } else {
            alert('Something went wrong');
          }
        },
        err => {
          if (err.error.error.length) {
            err.error.error.map((e, i) => {
              alert(err.error.error[i].message);
            });
          }
          else {
            alert('Something went wrong');
          }
        });
    }
  }

  upload(e) {
    const inputEl: HTMLInputElement = this.inputEl.nativeElement;
    const fileCount: number = inputEl.files.length;
    if (fileCount > 0) {
      for (let i = 0; i < fileCount; i++) {
        this.fileList = inputEl.files.item(i);
        const reader = new FileReader();
        reader.readAsDataURL(inputEl.files.item(i));
        reader.onload = this.setFileUrl;
      }
    }
  }

  setFileUrl(file: any) {
    this.photo = file.target.result;
    document
      .getElementById("managerImg")
      .setAttribute("src", file.target.result);
  }

}
