import { Component, OnInit } from '@angular/core';

import { AuthLoginService } from '../../../auth/auth_service/auth-login.service';
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  LoginUserDetails: any;
  userName = [] = [];
  constructor(
    private AuthServiceApi: AuthLoginService,
    private router: Router
  ) { }

  ngOnInit() {
    this.getUserList();
  }

  getUserList() {
    this.LoginUserDetails = this.AuthServiceApi.getLoginUser();
    this.AuthServiceApi.loginUserDetails(this.LoginUserDetails.data.id).subscribe(
      res => {
        if (res['success'] === true) {
          this.userName = res['data'];
        }
      })
  }

  userLogout() {
    this.AuthServiceApi.logout();
  }

}
