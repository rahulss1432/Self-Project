import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin.component';
import { AuthGuard } from '../auth/_guard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ChartsComponent } from './charts/charts.component';
import { ImagecropperComponent } from './imagecropper/imagecropper.component';
import { EventcalendarComponent } from './eventcalendar/eventcalendar.component';
import { AddressmapComponent } from './addressmap/addressmap.component';
import { AccountComponent } from './account/account.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { UserlistComponent } from './userlist/userlist.component';

const ADMIN_ROUTE: Routes = [
  {
    path: '', component: AdminComponent, children: [
      { path: 'dashboard', component: DashboardComponent },
      { path: 'charts', component: ChartsComponent },
      { path: 'image-cropper', component: ImagecropperComponent },
      { path: 'image-section', component: ImagecropperComponent },
      { path: 'calendar', component: EventcalendarComponent },
      { path: 'map', component: AddressmapComponent },
      { path: 'account', component: AccountComponent },
      { path: 'change-password', component: ChangepasswordComponent },
      { path: 'user-list', component: UserlistComponent }
    ]
  }
]

export const adminRouting = RouterModule.forChild(ADMIN_ROUTE);
