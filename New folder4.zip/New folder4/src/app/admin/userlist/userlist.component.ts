import { Component, OnInit, Pipe } from '@angular/core';
import { UserService } from './service/user.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent {
  public userList : any = [];
  p = 1;
  total: number;
  loading: boolean;
  query: string = '';
  pointer: "pointer";
  programInfo: any = [];
  constructor(private userService: UserService, private toastr: ToastrService) { }

  ngOnInit() {
    // this.getUserList();
    this.loading = true;
    this.userService.getUserList()
      .subscribe(
      (data: any) => {
        this.userList = data;
        console.log(this.userList);
      });
  }

  getUserList() {

  }

}

