﻿import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Response } from '@angular/http';

import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(
    private http: HttpClient,
    private router: Router
  ) { }

  getUserList() {
    let url: string = 'http://localhost/new_angular_laravel/api/get-user-list';
    return this.http.get(url).pipe(map(res => {
      return res;
    }))
  }

  deleteItemImage(id) {
    let url: string = 'http://localhost/new_angular_laravel/api/delete-item-image';
    return this.http.get(url + '/' + id).pipe(map(res => {
      return res;
    }))
  }

  updateImageList(imageList: any) {
    let url: string = 'http://localhost/new_angular_laravel/api/update-image-list';
    const a = this.http.post(url, imageList);
    return a.pipe(map((res: any) => res));
  }

}
