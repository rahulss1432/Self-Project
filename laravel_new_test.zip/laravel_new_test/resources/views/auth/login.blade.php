@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Login</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="javascript:void(0);" id="loginForm">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>
                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password" class="col-md-4 control-label">Password</label>
                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password">
                            </div>
                        </div>
						<span id="spanLoginError"></span>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> Remember Me
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="button" onclick="login()" class="btn btn-primary">
                                    Login
                                </button>
                                <a class="btn btn-link" href="{{url('/forgot-password')}}">
                                    Forgot Your Password?
                                </a>
                            </div>
                        </div>
                    </form>
					{!! JsValidator::formRequest('App\Http\Requests\LoginRequest','#loginForm') !!}
                </div>
            </div>
        </div>
    </div>
</div>
<script>
	function login(){
		$('#spanLoginError').text('');
        if ($('#loginForm').valid()) {
            $.ajax({
                url: "{{ url('/login') }}",
                data: $('#loginForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = response.redirectUrl;
                        }, 500);
                    } else {
                        toastrAlertMessage('error', response.message);
                    }
                },
                error: function (err) {
                    var obj = $.parseJSON(err.responseText);
                    for (var x in obj) {
                        if (obj[x].email) {
                            $('#spanLoginError').html('<span class="help-block error-help-block">' + obj[x].email + '</span>');
                        } else {
                            $('#spanLoginError').html('<span class="help-block error-help-block">' + obj[x] + '</span>');
                        }
                    }
                }
            });
        }
    }
	
	// toaster common function
    function toastrAlertMessage(type, msg) {
        if (type == 'success') {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.success(msg, {timeOut: 2000});
        } else {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.error(msg, {timeOut: 2000});
        }
    }

    function remove_error() {
        $('#spanLoginError').html('');
    }
</script>
@endsection