<?php

use Carbon\Carbon;
use App\Models\User;

function sendMail($data) {
    try {
        switch ($data['request']) {
            case "admin_forgot_password":
                Mail::send('emails.admin_forgot_password', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from('solankirahul993@gmail.com', 'Laravel New Test')
                            ->subject($data['subject']);
                });
                break;
            default:
                break;
        }
        return true;
    } catch (Exception $e) {
        return $e->getMessage();
    }
}