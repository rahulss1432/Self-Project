<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\RegisterRequest;
use App\Http\Requests\ForgotPasswordRequest;
use App\Http\Requests\ResetPasswordRequest;

class RegisterController extends Controller
{
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }
	
	public function registerShow(){
		return view('auth.register');
	}
	
	public function register(RegisterRequest $request){
		return User::saveUser($request);
	}
	
	public function forgotPassword() {
        try {
            return view('auth.forgot-password');
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
	
	public function sendForgotEmail(ForgotPasswordRequest $request) {
        return User::forgotEmail($request->all());
    }
	
	public function resetPassword($token) {
        try {
            return view('auth.password_reset', ['token' => $token]);
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
	
	public function Reset(ResetPasswordRequest $request) {
        return User::ResetPassword($request->all());
    }
}
