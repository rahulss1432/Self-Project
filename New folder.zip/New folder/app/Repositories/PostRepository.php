<?php

namespace App\Repositories;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\UserPostAction;
use App\Models\FafTubeCategory;
use Carbon\Carbon;
Class PostRepository {

    public function __construct(Post $post, UserPostAction $postAction, FafTubeCategory $fafTubeCategory) {
        $this->post = $post;
        $this->postAction = $postAction;
        $this->fafTubeCategory = $fafTubeCategory;
    }

    public function getAllPost() {
        try {

            return $this->post->with('user')->get();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function savePost($request) {
        try {
            $book = new Post;
            $userId = auth()->user()->id;
            $book->user_id = $userId;
            $book->title = $request->title;
            $book->description = $request->description;
            $book->save();
            return response()->json(['success' => true, 'message' => 'Post added successfully']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function updatePost($request) {
        try {
            $post = $this->post->find($request->id);
            $post->title = $request->title;
            $post->description = $request->description;
            $post->save();
            return response()->json(['success' => true, 'message' => 'Post updated successfully ']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function getSinglePost($id) {
        try {
            return $this->post->find($id);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function deletePost($request) {
        try {
            $this->post->destroy($request->id);
            return response()->json(['success' => true, 'message' => 'Post deleted successfully']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * sumit
     * create function for get post details
     * 21-12-2018
     */
    public function getPostById($id){
       return $this->post->where(['id' => $id, 'post_type' => 'faf'])->first();
    }

    /**
     * sumit
     * get post events by type and Id
     * 12-22-2018
     */
    public function getPostEvents($postId, $type) {
        $result = $this->postAction->where(['post_id' => $postId, 'type' => $type])->get();
        return $result;
    }

    /**
     * function for get recently 15 days Posts
     * return type array
     */
    public function getRecentPostByCategory($type) {
        return $this->post->select('posts.*', 'user_medias.media','user_medias.time_duration')
                        ->join('user_medias', 'user_medias.post_id', 'posts.id')
                        ->join('faf_tube_categories', 'faf_tube_categories.id', 'posts.category_id')                
                        ->where('faf_tube_categories.category_name',$type)
                        ->where('posts.post_type', 'faf-tube')                
                        ->where('posts.status', 'active')                
                        ->whereDate('posts.created_at', '>=', Carbon::now()->subDays(15))
                        ->orderBy('posts.id', 'desc')
                        ->take(15)->get();        
    }

}
