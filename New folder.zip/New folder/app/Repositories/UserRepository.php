<?php

namespace App\Repositories;

use Illuminate\Http\Request;
use App\User;
use App\Models\Subscriptions;
use App\Models\Transactions;
use App\Models\ProfileTracker;
use Stripe\Stripe;
use Stripe\Customer;
use Stripe\Charge;
use Stripe\Token;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Validator;
use Illuminate\Support\Facades\Input;
use App\Models\UserMedia;
use App\Models\MediaComments;
use Image;
use File;
use App\Models\Post;
use App\Models\News;
use App\Models\Connection;
use App\Models\TeamPlayer;
use App\Models\TeamStaff;
use App\Models\UserPostAction;
use App\Models\Job;
use App\Models\ApplyJob;
use App\Models\Event;
use App\Models\JobView;
use App\Models\JobQuestionnaire;
use App\Models\AppliedJobAnswer;
use App\Models\AppliedJobQuestion;
use App\Models\EventTeam;
use App\Models\Testimonials;
use DB;
use App\Models\Position;
use Illuminate\Support\Facades\Response;
use App\Models\Notification;
use App\Models\PaymentNotification;
use App\Models\PaymentSource;
use Illuminate\Support\Facades\Session;
use App\Models\Contact;
Class UserRepository {

    /**
     * Class Construct.
     *
     * @param  array  $data
     * @return \App\User
     */
    public function __construct(User $user, AppliedJobAnswer $appliedJobAnswer, AppliedJobQuestion $appliedJobQuestion, Transactions $transactions, ApplyJob $applyJob, UserPostAction $postAction, ProfileTracker $profileTracker, Connection $connections, UserMedia $userMedia, MediaComments $mediaComments, Post $post, News $news, TeamPlayer $teamPlayer, TeamStaff $teamStaff, Event $event, Job $job, JobView $jobView, JobQuestionnaire $jobQuestionnaire, EventTeam $eventTeam, Position $position, Testimonials $testimonial, Notification $notification, PaymentSource $paymentSource, PaymentNotification $paymentNotification, Subscriptions $subscriptions, Contact $contact) {
        $this->user = $user;
        $this->transaction = $transactions;
        $this->profileTracker = $profileTracker;
        $this->userMedia = $userMedia;
        $this->mediaComments = $mediaComments;
        $this->post = $post;
        $this->news = $news;
        $this->connections = $connections;
        $this->teamPlayer = $teamPlayer;
        $this->teamStaff = $teamStaff;
        $this->postAction = $postAction;
        $this->job = $job;
        $this->event = $event;
        $this->jobView = $jobView;
        $this->applyJob = $applyJob;
        $this->jobQuestionnaire = $jobQuestionnaire;
        $this->appliedJobAnswer = $appliedJobAnswer;
        $this->appliedJobQuestion = $appliedJobQuestion;
        $this->eventTeam = $eventTeam;
        $this->position = $position;
        $this->testimonial = $testimonial;
        $this->notification = $notification;
        $this->paymentNotification = $paymentNotification;
        $this->paymentSource = $paymentSource;
        $this->subscriptions = $subscriptions;
        $this->contact = $contact;        
        ini_set('max_execution_time', '-1');
        ini_set('memory_limit', '-1');
    }

    /**
     * Method for create signup With Ach.
     *
     * @param  array  $data
     * @return \App\User
     */
    public function signup($request) {
        try {
            $data = $request->all();
            $latLong = Session::get('latLong');
            Session::forget('latLong');
            $latLong = explode('&', $latLong);
            $post['latitude'] = !empty($latLong[0]) ? $latLong[0] : '37.0902';
            $post['longitude'] = !empty($latLong[1]) ? $latLong[1] : '-95.7129';
            $data['password'] = bcrypt($data['password']);
            $user = $this->user->create($data);
            $id = $user['id'];
            $slug_name = make_slug($data['full_name'], $id);
            $reponse = User::where('id', $id)->update(['slug' => $slug_name]);
            if ($reponse) {
                $smsMessage = "Hello {" . $data['first_name'] . "}! CONGRATS on joining Free Agent Football with your 14-day FREE Trial membership. We are honored to have you onboard.";
                $phoneNumber = getCountryCodeForSms($data['country_id']) . '' . $data['phone_number'];
                $data['name'] = $data['first_name'] . ' ' . $data['last_name'];
                $data['request'] = 'welcome_mail';
                $data['email'] = $request->email;
                $data['subject'] = 'Welcome mail';
                $data['password'] = $request->password;
                $data['user_login_type'] = 'first';
                $result = sendMail($data);
                sendTextSMS($smsMessage, $phoneNumber);
                if (!empty($result)) {
                    return response()->json(['success' => true, 'message' => 'Signup Successfully.Please check your mail and verify your account.']);
                } else {
                    return response()->json(['success' => false, 'message' => 'Please try again.']);
                }
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /** ach payment gatways using stripe  */
    public function confrimAchPayment($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $account_holder_name = $account_holder_type = $routing_number = $account_number = '';
            $account_holder_name = $post['account_holder_name'];
            $account_holder_type = $post['account_holder_type'];
            $routing_number = $post['routing_number'];
            $account_number = $post['account_number'];
            $subscription_id = getUserById($userId, 'subscription_id');
            $amount = getSubscriptionData($subscription_id, 'amount');
            Stripe::setApiKey(env("STRIPE_SECRET_KEY"));
            /* then create new customer and it's bank source */
            $bank_token = Token::create(array(
                        "bank_account" => array(
                            "country" => "US",
                            "currency" => "USD",
                            "account_holder_name" => $account_holder_name,
                            "account_holder_type" => $account_holder_type,
                            "routing_number" => $routing_number,
                            "account_number" => $account_number
                        )
            ));
            $b_token = $bank_token->__toJSON();
            $obj_token = json_decode($b_token, TRUE);
            $b_tok = $obj_token['id'];
            $bank_account_id = $obj_token['bank_account']['id'];
            $newCustomerEmail = Auth::guard(getAuthGuard())->user()->email;
            $newCustomerFullName = Auth::guard(getAuthGuard())->user()->full_name;
            $sp = Customer::create(array(
                        "source" => $b_tok,
                        "description" => "Accuount for Customer $newCustomerFullName",
                        "email" => $newCustomerEmail
            ));
            $cust_id = $sp['id'];
            //User::where('id', $userId)->update(['token' => $b_tok, 'customer_id' => $cust_id, 'ach_verification' => 'no']);
            request()->session()->put('bank_account_id', $bank_account_id); /* set bank account id in session */
            request()->session()->put('token', $b_tok); /* set bank token in session */
            request()->session()->put('customer_id', $cust_id);  /* set bank customer id in session */
            if ($sp) {
                return response()->json(['success' => true, 'amount' => $amount, 'message' => 'We have deposited two Microamount into your Bank Account.']);
            }
        } catch (\Stripe\Error\Card $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\RateLimit $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\InvalidRequest $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\Authentication $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\ApiConnection $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /* verify ach amount */

    public function verifyAmount($request) {
        $post = $request->all();
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $ammount1 = $post['ammount1'];
        $ammount2 = $post['ammount2'];
        $subscription_id = getUserById($userId, 'subscription_id');
        $role = getUserById($userId, 'role');
        $bankAccountId = request()->session()->get('bank_account_id');
        $token = request()->session()->get('token');
        $custId = request()->session()->get('customer_id');
        $getStartDate = getUserById($userId, 'start_date');
        $getEndDate = getUserById($userId, 'end_date');
        // first time add 14 days trial period + subscription days
        if (empty($getStartDate) || empty($getEndDate)) {
            $start_date = Carbon::today();
            $end_date = Carbon::today()->addDay(getSetting(), 'day');
        } else {  // second time add only subscription days (renew case)
            $start_date = $getStartDate;
            $end_date = $getEndDate;
        }
        try {
            Stripe::setApiKey(env("STRIPE_SECRET_KEY"));
            $customer = Customer::retrieve($custId);
            $bank_account = $customer->sources->retrieve($bankAccountId);
            $bank_account->verify(array('amounts' => array($ammount1, $ammount2)));
            $oldCustomerId = Auth::guard(getAuthGuard())->user()->customer_id;
            if (!empty($oldCustomerId)) { /* if customer id is exists then delete the customer sources from database and stripe */
                $customer = \Stripe\Customer::retrieve($oldCustomerId);
                if (!empty($customer)) {
                    $customer->delete();                                                     // delete customer from stripe
                    $this->user->where('id', $userId)->update(['customer_id' => NULL]);        // update customer id to null in database
                    $this->paymentSource->where('user_id', $userId)->delete();               // delete all customer source from payment source        
                }
            }
            if ($bank_account) {
                $this->updateUserSubscriptionDetail($userId, $token, $custId, $start_date, $end_date, json_encode($bank_account));
                $request->session()->forget('customer_id');
                $request->session()->forget('token');
                /* Ignore payment deduction process when user is on trial period */
                if (!empty($getStartDate) && !empty($getEndDate)) {
                    $this->payWithAch();
                }
                $this->savePaymentSource($bank_account['id'], $bank_account['last4'], 'bank', 'yes', $bank_account['bank_name'], $bank_account['account_holder_type']);
                return response()->json(['success' => true, 'role' => $role, 'message' => 'Your Bank Account has been verified successfully.']);
            }
        } catch (\Stripe\Error\Card $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\RateLimit $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\InvalidRequest $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\Authentication $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\ApiConnection $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     *  Ach payment procees by stripe
     * @param type $request
     * @return type
     */
    public function payWithAch($id = null) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        /* when function call by cron then id will use. default auth user id will work */
        if (!empty($id)) {
            $userId = $id;
        }
        $subscription_id = getUserById($userId, 'subscription_id');
        $custId = getUserById($userId, 'customer_id');
        $bank_account = json_decode(getUserById($userId, 'ach_bank_account'));
        $days = getSubscriptionData($subscription_id, 'renewal_cycle');
        $ammount = getSubscriptionData($subscription_id, 'amount');
//        $s_end_date = getUserById($userId, 'end_date');
        $s_end_date = Carbon::today();
        $start_date = Carbon::parse($s_end_date);
        $end_date = $start_date->addDay($days, 'day');
        $plan_flag = getUserById($userId, 'plan_flag');
        try {
            Stripe::setApiKey(env("STRIPE_SECRET_KEY"));
            $charge = \Stripe\Charge::create(array(
                        "amount" => 100 * $ammount,
                        "currency" => "usd",
                        "customer" => $custId,
                            // "source" => $bank_account,
            ));
            if (!empty($charge)) {
                $this->updateUserSubscriptionDetail($userId, '', '', $s_end_date, $end_date, '');
                $this->saveTransaction($userId, $subscription_id, $charge, $s_end_date, $end_date, $ammount, $plan_flag);
                $this->paymentNotification->where(['user_id' => $userId])->delete();
                $this->savePaymentCronData($userId, $charge, 'success', 'Payment successfully');
                return response()->json(['success' => true, 'message' => 'Charge created successfully.']);
            }
        } catch (\Stripe\Error\Card $e) {
            $this->savePaymentCronData($userId, $charge, 'failure', $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\RateLimit $e) {
            $this->savePaymentCronData($userId, $charge, 'failure', $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\InvalidRequest $e) {
            $this->savePaymentCronData($userId, $charge, 'failure', $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\Authentication $e) {
            $this->savePaymentCronData($userId, $charge, 'failure', $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\ApiConnection $e) {
            $this->savePaymentCronData($userId, $charge, 'failure', $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            $this->savePaymentCronData($userId, $charge, 'failure', $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function updateUserSubscriptionDetail($user_id, $token = null, $customer_id = null, $start_date, $end_date, $bank_account = null) {
        if (empty($customer_id) && empty($token)) {
            User::where('id', $user_id)->update(['ach_bank_account' => '', 'start_date' => $start_date, 'end_date' => $end_date, 'verification' => 'yes', 'fafTube_subscription_flag' => 'no']);
        } else {
            $bank_account = ($bank_account) ? $bank_account : '';
            User::where('id', $user_id)->update(['ach_bank_account' => $bank_account, 'token' => $token, 'customer_id' => $customer_id, 'start_date' => $start_date, 'end_date' => $end_date, 'verification' => 'yes', 'fafTube_subscription_flag' => 'no']);
        }
    }

    public function saveTransaction($user_id, $subscription_id, $charge, $start_date, $end_date, $ammount, $plan_flag) {
        $transaction = new $this->transaction;
        $transaction->user_id = $user_id;
        $transaction->subscription_id = $subscription_id;
        $transaction->charge_id = $charge['id'];
        $transaction->transaction_id = $charge['balance_transaction'];
        $transaction->source_id = $charge['source']['id'];
        $transaction->customer = $charge['customer'];
        $transaction->amount = $ammount;
        $transaction->start_date = $start_date;
        $transaction->end_date = $end_date;
        $transaction->status = ($charge['status'] == 'pending') ? 'pending' : 'complete';
        $transaction->save();
        $userData = $this->user->where('id', $transaction->user_id)->first();
        $getUserType = $this->user->where('role', 'admin')->first();
        sendNotifacationByUser($user_id, $getUserType->id, 'payment_' . $plan_flag, $userData->reference_id, $userData->full_name, '', $user_id);
    }

    /* for renew account on cron based */

    public function savePaymentCronData($user_id, $charge, $status, $message) {
        $result = $this->paymentNotification->where(['user_id' => $user_id, 'status' => 'failure'])->first();
        if (empty($result)) {
            $paymentRenew = new $this->paymentNotification;
            $paymentRenew->user_id = $user_id;
            $paymentRenew->charge_id = $charge['id'];
            $paymentRenew->message = $message;
            $paymentRenew->status = $status;
            if ($status == "success") {
                $paymentRenew->is_process = 1;
            } else {
                $paymentRenew->is_process = 0;
            }
            $paymentRenew->save();
            $subject = "";
            $userPaymentType = "";
            if ($paymentRenew->status == "failure") {
                $subject = 'Decline mail';
                $userPaymentType = $paymentRenew->after_days;
                sendNotifacationByFrontUser($user_id, $user_id, 'payment_decline_first', "", "");
            } else {
                $subject = 'Success mail';
                $userPaymentType = "success_payment";
            }
            $data['name'] = getUserById($user_id, 'full_name');
            $data['request'] = 'decline_mail';
            $data['email'] = getUserById($user_id, 'email');
            $data['subject'] = $subject;
            $data['user_payment_type'] = $userPaymentType;
            $result = sendMail($data);
            return true;
        }
    }

    /* using for save user profile viewer */

    public function saveProfileViewer($id) {
        $fromId = Auth::guard(getAuthGuard())->user()->id;
        $toId = $id;
        $result = $this->profileTracker->where(['from_id' => $fromId, 'to_id' => $toId, 'type' => 'view'])->first();
        if (empty($result)) {
            $model = new $this->profileTracker;
            $model->from_id = $fromId;
            $model->to_id = $toId;
            $model->type = 'view';
            $model->save();
            sendNotifacationByFrontUser($model->from_id, $model->to_id, 'user_' . $model->type, '', '');
            return true;
        }
        return true;
    }

    /* using for save user profile events like and follow */

    public function profileEvents($fromId, $toId, $type) {
        $model = $this->profileTracker->where(['from_id' => $fromId, 'to_id' => $toId, 'type' => $type])->first();
        if (empty($model)) {
            $model = new $this->profileTracker;
            $model->from_id = $fromId;
            $model->to_id = $toId;
            $model->type = $type;
            $model->save();
            sendNotifacationByFrontUser($model->from_id, $model->to_id, 'user_' . $model->type, '', '');
            return response()->json(['success' => true, 'event' => $type]);
        } else {
            $model->delete();
            return response()->json(['success' => true, 'event' => 'un' . $type]);
        }
    }

    /*
     * Function using for get user profile by id.
     */

    public function getUserProfileById($id) {
        $result = $this->user->where(['id' => $id])->first();
        return $result;
    }

   /**
    * change payment method in user table column ach or card
    * @param type $request
    * @return type response
    */
    public function changeMethodOfPayment($request) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return  $this->user->where('id', $userId)->update(['signup_type' => $request->signup_type]);
    }

    public function getUseDetails($request) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        if (!empty($request->id)) {
            $userId = $request->id;
        }
        return $this->user->where('id', $userId)->first();
    }
    /*
     * Function using for get media video and images list 
     */

    public function getMediaListByType($type, $userId, $size) {
        $result = $this->userMedia->select('user_medias.*')
                ->join('posts', 'user_medias.post_id', 'posts.id')
                ->where(['media_type' => $type, 'posts.user_id' => $userId, 'posts.type' => 'media', 'posts.status' => 'active', 'posts.post_type' => 'faf'])
                ->orderBy('id', 'desc')
                ->paginate($size);
        return $result;
    }

    /*
     * Function using for get select media
     */

    public function getSelectMedia($userId) {
        $result = $this->userMedia->select('user_medias.*')
                ->join('posts', 'user_medias.post_id', 'posts.id')
                ->where(['order_by' => '1', 'posts.user_id' => $userId, 'posts.type' => 'media', 'posts.status' => 'active', 'posts.post_type' => 'faf'])
                ->first();
        if (empty($result)) {
            $result = $this->userMedia->select('user_medias.*')
                            ->join('posts', 'user_medias.post_id', 'posts.id')
                            ->where(['posts.user_id' => $userId, 'posts.type' => 'media', 'posts.status' => 'active', 'posts.post_type' => 'faf'])
                            ->orderBy('user_medias.id', 'desc')->first();
        }
        return $result;
    }

    /*
     * Function using for get all media list
     */

    public function getMediaListById($userId) {
        if (empty(Auth::guard(getAuthGuard())->check())) {
            $userId = 0;
        }
        $result = $this->userMedia->select('user_medias.*')
                        ->join('posts', 'user_medias.post_id', 'posts.id')
                        ->where(['posts.user_id' => $userId, 'posts.type' => 'media', 'posts.status' => 'active', 'posts.post_type' => 'faf'])
                        ->orderBy('user_medias.id', 'desc')->get();
        return $result;
    }

    /*
     * Function using for get all media list by Id And type
     */

    public function getMediaListByIdAndType($userId, $type) {
        $result = $this->userMedia->where(['user_id' => $userId, 'media_type' => $type])->orderBy('id', 'desc')->get();
        return $result;
    }

    /*
     * Function using for update selected media order
     */

    public function updateSelectMedia($userId, $mediaId) {
        try {
            $this->userMedia->where('user_id', $userId)->update(['order_by' => '0']);
            $this->userMedia->where('id', $mediaId)->update(['order_by' => '1']);
            return response()->json(['success' => true, 'message' => 'Updated successfully!']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function using for upload multiple post media file (video/image) 
     */

    public function uploadPostFile($request) {
        try {
            $fileName = $request->file('myPost');
            $size = $fileName->getClientSize();
            $exte = $fileName->getClientOriginalExtension();
            $fileDuration = '';
            if ($exte == 'mp4' || $exte == 'MP4') {
                $uploadFileName = videoThumb($fileName, 'temp');
                if (!empty($uploadFileName) && is_array($uploadFileName)) {
                    $fileName = (!empty($uploadFileName['fileName'])) ? $uploadFileName['fileName'] : 0;
                    $fileDuration = (!empty($uploadFileName['fileDuration'])) ? $uploadFileName['fileDuration'] : 0;
                    $type = 'video';
                } else {
                    return response()->json(['success' => false, 'message' => $uploadFileName]);
                }
            } else if ($exte == 'png' || $exte == 'jpg' || $exte == 'jpeg' || $exte == 'PNG' || $exte == 'JPG' || $exte == 'JPEG') {
                $type = 'image';
                $fileName = uploadFile($fileName, 'temp');
                resizeMediaImage($fileName);
            } else {
                return response()->json(['success' => false, 'message' => 'Invalid Formate: Allow only jpg,png,gif,jpeg,mp4']);
            }
            return response()->json(['success' => true, 'image' => $fileName, 'duration' => $fileDuration, 'type' => $type, 'size' => $size]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function using for save media comments 
     */

    public function saveMediaComment($request) {
        try {
            $post = $request->all();
            $formId = Auth::guard(getAuthGuard())->user()->id;
            $model = new $this->mediaComments;
            $model->comment = (!empty($post['comment'])) ? $post['comment'] : '';
            $model->media_id = $post['media_id'];
            $model->to_id = $post['to_id'];
            $model->from_id = $formId;
            $model->type = 'comment';
            $model->save();
            $count = $this->mediaComments->where(['media_id' => $model->media_id, 'type' => 'comment'])->count();
            return response()->json(['success' => true, 'count' => $count]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function using for save media comments 
     */

    public function saveMediaLike($request) {
        $post = $request->all();
        $formId = Auth::guard(getAuthGuard())->user()->id;
        $event = $this->mediaComments->where(['media_id' => $post['media_id'], 'from_id' => $formId, 'type' => 'like'])->first();
        if (!empty($event)) {
            $event->delete();
            $count = $this->mediaComments->where(['media_id' => $post['media_id'], 'type' => 'like'])->count();
            return response()->json(['success' => true, 'count' => $count, 'event' => 'unlike']);
        } else {
            try {
                $model = new $this->mediaComments;
                $model->comment = (!empty($post['comment'])) ? $post['comment'] : '';
                $model->media_id = $post['media_id'];
                $model->to_id = $post['to_id'];
                $model->from_id = $formId;
                $model->type = 'like';
                $model->save();
                $count = $this->mediaComments->where(['media_id' => $model->media_id, 'type' => 'like'])->count();
                return response()->json(['success' => true, 'count' => $count, 'event' => 'like']);
            } catch (\Exception $e) {
                return response()->json(['success' => false, 'message' => $e->getMessage()]);
            }
        }
    }

    /*
     * Function using for get all media events (like/comment/shere)
     */

    public function getMediaEventsByType($request, $type) {
        $result = $this->mediaComments->where(['media_id' => $request->media_id, 'type' => $type])->get();
        return $result;
    }

    /*
     * Function using for get my media list 
     */

    public function getMyMediaView($request) {
        $result = $this->userMedia->where(['id' => $request->media_id])->first();
        return $result;
    }

    /**
     * Function for get post .
     */
    public function getPlayerPost($request) {
        $result = $this->userMedia->where(['post_id' => $request->postId])->get();
        return $result;
    }

    /**
     * last update :- 09-feb-2019
     * function using for save post 
     */
    public function savePost($request) {
        try {
            $post = $request->all();
            $user = Auth::guard(getAuthGuard())->user();
            if (!empty($post['size']) && count($post['size']) > 0) {
                $userPlan = $this->userMedia->where(['user_id' => $user->id])->sum('size');
                $postSize = 0;
                foreach ($post['size'] as $size) {
                    $postSize = $postSize + $size;
                }
                $currantplan = $userPlan + $postSize;
                $convertToGb = convertSize($currantplan);
                $userPlanSpace = getSubscriptionData($user->subscription_id, 'plan_space');
                if ($convertToGb > $userPlanSpace) {
                    return response()->json(['success' => false, 'validation' => 'yes', 'message' => 'Your plan limit expire.']);
                }
            }
            if (isset($post['id'])) {
                $model = $this->post->find($post['id']);
                $userPost = UserPostAction::where(['post_id' => $post['id']])->get();
                if (!empty($userPost)) {
                    foreach ($userPost as $val) {
                        if ($val->from_id != $user->id && $val->type == "like") {
                            sendNotifacationByFrontUser($user->id, $val->from_id, 'post_update_like', '', $post['id']);
                        }
                        if ($val->from_id != $user->id && $val->type == "comment") {
                            sendNotifacationByFrontUser($user->id, $val->from_id, 'post_update_comment', '', $post['id']);
                        }
                    }
                }
            } else {
                $model = new $this->post;
            }
            $model->user_id = $user->id;
            $model->status = 'active';
            $model->post = (!empty($post['title'])) ? $post['title'] : '';
            $model->type = (!empty($post['hdnImageName'])) ? 'media' : 'text';
            $model->save();
            $storImagesArray = [];
            if (isset($post['id'])) {
                $uploadedImage = $this->userMedia->where(['post_id' => $post['id']])->get();
                $uploadedImageArray = (isset($post['hdnImageName'])) ? $post['hdnImageName'] : [];
                if (!empty($uploadedImage)) {
                    foreach ($uploadedImage as $getuploadImage) {
                        if (!in_array($getuploadImage->media, $uploadedImageArray)) {
                            removeDeletedImages($getuploadImage->media, $user->role);
                            $getuploadImage->delete();
                        } else {
                            $storImagesArray[] = $getuploadImage->media;
                        }
                    }
                }
            }
            if (!empty($post['hdnImageName'])) {
                foreach ($post['hdnImageName'] as $key => $filleName) {
                    if (!in_array($filleName, $storImagesArray)) {
                        $mediaModel = new $this->userMedia;
                        $mediaModel->user_id = $user->id;
                        $mediaModel->post_id = $model->id;
                        $mediaModel->category_id = 1;
                        $mediaModel->media = $filleName;
                        $mediaModel->media_type = (!empty($post['mediaType'][$key])) ? $post['mediaType'][$key] : 'image';
                        $mediaModel->size = (!empty($post['size'][$key])) ? $post['size'][$key] : '';
                        $mediaModel->time_duration = (!empty($post['duration'][$key])) ? $post['duration'][$key] : '';
                        $mediaModel->save();
                        copyImages($filleName, $user->role);
                    }
                }
            }
            if (isset($post['id'])) {
                return response()->json(['success' => true, 'message' => 'Post Updated Successfully.']);
            } else {
                return response()->json(['success' => true, 'message' => 'Post Created Successfully.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'validation-mg' => 'no', 'message' => $e->getMessage()]);
        }
    }

    /**
     * Function for list all events.
     */
    public function editPost($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard(getAuthGuard())->user()->id;
            return $this->post->where(['id' => $post['id'], 'user_id' => $userId])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Function for delete event.
     */
    public function deletePost($request) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $this->post->where(['id' => $request->id, 'user_id' => $userId])->delete();
            $userMedia = $this->userMedia->where(['post_id' => $request->id, 'user_id' => $userId])->get();
            $this->postAction->where(['post_id' => $request->id])->delete();
            foreach ($userMedia as $media) {
                $medaiEvents = $this->mediaComments->where(['media_id' => $media->id])->delete();
                $media->delete();
            }
            return response()->json(['success' => true, 'message' => 'Post Deleted.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Get latest news add by admin
     */

    public function getLatestNews() {
        return $this->news->where('status', 'active')->OrderBy('id', 'desc')->first();
    }

    /**
     * connect dismiss member.
     */
    public function connectDismissMember($post) {
        try {
            $fromId = Auth::guard(getAuthGuard())->user()->id;
            $model = $this->connections;
            $model->from_id = $fromId;
            $model->to_id = $post['id'];
            $model->type = $post['type'] == 'connect' ? 'pending' : 'reject';
            $model->save();
            return response()->json(['success' => true, 'message' => "Member " . $post['type'] . " successfully"]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * team player list
     */

    public function getTeamPlayerList($userId, $size) {
        $result = $this->teamPlayer->where(['user_id' => $userId])
                ->orderBy('id', 'desc')
                ->paginate($size);
        return $result;
    }

    /*
     * team staff list 
     */

    public function getTeamStaffList($userId, $size) {
        $result = $this->teamStaff->where(['user_id' => $userId])
                ->orderBy('id', 'desc')
                ->paginate($size);
        return $result;
    }

//    save my profile media
    public function saveMyProfileMedia(Request $request) {
        try {
            $post = $request->all();
            if (!empty($post['hdnImageName'])) {
                $user = Auth::guard(getAuthGuard())->user();
                $model = new $this->post;
                $model->user_id = $user->id;
                $model->status = 'active';
                $model->post = '';
                $model->type = (!empty($post['hdnImageName'])) ? 'media' : 'text';
                $model->save();
                checkUserConnectAndFollow($user->id);
                if (!empty($post['hdnImageName'])) {
                    foreach ($post['hdnImageName'] as $key => $filleName) {
                        $mediaModel = new $this->userMedia;
                        $mediaModel->user_id = $user->id;
                        $mediaModel->post_id = $model->id;
                        $mediaModel->category_id = 1;
                        $mediaModel->media = $filleName;
                        $mediaModel->media_type = $post['mediaType'][$key];
                        $mediaModel->save();
                        copyImages($filleName, $user->role);
                    }
                }
            }
            return response()->json(['success' => true, 'message' => 'Media saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * sumit
     * @param type $id
     * @return type
     * Delete meida comment
     */
    function deleteMediaComment($id) {
        try {
            $this->mediaComments->where(['id' => $id])->delete();
            return response()->json(['success' => true, 'message' => 'Comment deleted successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * sumit
     * @param type $id
     * @return type
     * delete post comment
     */
    function deletePostComment($id) {
        try {
            $this->postAction->where(['id' => $id])->delete();
            return response()->json(['success' => true, 'message' => 'Comment deleted successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get all posted job.
     */

    public function getPostJob($request) {
        $getAllJobs = $this->job->select('jobs.*')->where('status', 'active');
        if (!empty($request['position'])) {
            $filter = $request['position'];
            $getAllJobs->where(function ($query) use($filter) {
                for ($i = 0; $i < count($filter); $i++) {
                    $query->orwhere('position_id', 'like', '%' . $filter[$i] . '%');
                }
            });
        }
        if (!empty($request['country'])) {
            $getAllJobs->where('country_id', $request['country']);
        }
        if (!empty($request['state'])) {
            $getAllJobs->where('state_id', $request['state']);
        }
        if (!empty($request['job_city'])) {
            $getAllJobs->where('city', 'like', '%' . $request['job_city'] . '%');
        }
        if (!empty($request['salary_from']) && !empty($request['salary_to'])) {
            $salaryFrom = $request['salary_from'];
            $salaryTo = $request['salary_to'];
            $getAllJobs->whereRaw("`from_salary` >= '$salaryFrom' and `to_salary` <= '$salaryTo'");
        }
        if (!empty($request['benefits'])) {
            $filter = $request['benefits'];
            $getAllJobs->where(function ($query) use($filter) {
                for ($i = 0; $i < count($filter); $i++) {
                    $query->orwhere('benefits', 'like', '%' . $filter[$i] . '%');
                }
            });
        }
        /* Filter from date to date */
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = date('Y-m-d', strtotime($request['startDate']));
            $to = date('Y-m-d', strtotime($request['endDate']));
            $getAllJobs->whereDate('created_at', '>=', $from)
                    ->whereDate('apply_date', '<=', $to);
        }
        if (!empty($request['startDate']) && empty($request['endDate'])) {
            $from = date('Y-m-d', strtotime($request['startDate']));
            $getAllJobs->whereDate('created_at', $from);
        }
        if (!empty($request['endDate']) && empty($request['startDate'])) {
            $to = date('Y-m-d', strtotime($request['endDate']));
            $getAllJobs->whereDate('apply_date', $to);
        }
        if (!empty($request['register_time'])) {
            $filter = $request['register_time'];
            $maxDay = max($filter);
            $getAllJobs->where(function($query) use($maxDay) {
                $query->where('created_at', '>', Carbon::now()->subDays($maxDay));
            });
        }
        return $getAllJobs->orderBy('id', 'desc')->simplePaginate(3);
    }

    /*
     * Function for get all posted job.
     */

    public function getJobById($id) {
        return $this->job->where('id', $id)->first();
    }

//    get Questionnaire
    public function getJobQuestionnaire($id) {
        try {
            return $this->jobQuestionnaire->find($id);
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Function for list all events.
     */
    public function getEvent($type, $id, $request) {
        $currentDate = date("Y-m-d H:i", time());
        if ($type == 'latest') {
            return $this->event->whereRaw("TIMESTAMP(end_date, end_time) <= '$currentDate'")
                            ->where('status', 'active')
                            ->whereDate('end_date', '>=', Carbon::now()->subDays(15))
                            ->orderBy('start_date', 'asc')->get();
        } elseif ($type == 'upcomming') {
            $upcomingEvents = $this->event->select('events.*')
                    ->join('users', 'users.id', 'events.user_id')
                    ->whereRaw("TIMESTAMP(events.end_date, events.end_time) >= '$currentDate'")
                    ->where('events.status', 'active');
            if (!empty($request['event_name'])) {
                $upcomingEvents->where('events.event_name', 'like', '%' . $request['event_name'] . '%');
            }
            if (!empty($request['event_city'])) {
                $upcomingEvents->where('events.city', 'like', '%' . $request['event_city'] . '%');
            }
            /* Filter from date to date */
            if (!empty($request['startDate']) && !empty($request['endDate'])) {
                $from = date('Y-m-d', strtotime($request['startDate']));
                $to = date('Y-m-d', strtotime($request['endDate']));
                $upcomingEvents->whereDate('events.start_date', '>=', $from)
                        ->whereDate('events.end_date', '<=', $to);
            }
            if (!empty($request['startDate']) && empty($request['endDate'])) {
                $from = date('Y-m-d', strtotime($request['startDate']));
                $upcomingEvents->whereDate('events.start_date', $from);
            }
            if (!empty($request['endDate']) && empty($request['startDate'])) {
                $to = date('Y-m-d', strtotime($request['endDate']));
                $upcomingEvents->whereDate('events.end_date', $to);
            }
            if (!empty($request['posted_by'])) {
                $upcomingEvents->where('users.role', '=', $request['posted_by']);
            }
            return $upcomingEvents->orderBy('events.start_date', 'asc')->simplePaginate(12);
        } elseif ($id) {
            return $this->event->where(['id' => $id])->first();
        } else {
            return $this->event->where('id', $id)->get();
        }
    }

    /*
     * Function for get all posted job.
     */

    public function getLatestJobsList($jobId) {
        return $this->job->where('id', '!=', $jobId)->where('status', 'active')->orderBy('id', 'desc')->take(3)->get();
    }

    /*
     * Function for save job view count by user.
     */

    public function saveJobView($jobId) {
        if (!empty(Auth::guard(getAuthGuard())->user()->id)) {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $model = $this->jobView->firstOrNew(['user_id' => $userId, 'job_id' => $jobId, 'type' => 'view']);
            $model->user_id = $userId;
            $model->job_id = $jobId;
            $model->type = 'view';
            $model->save();
        }
    }

    /*
     * Function for get connected mutual friend list for other user profile.
     */

    public function getMutualFriendsList($otherUserId) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $model = $this->connections->where(function($query1) use($userId, $otherUserId) {  // check for my and other user connection is accepted or not
                    $query1->where('from_id', $userId)
                            ->where('to_id', $otherUserId)
                            ->where('type', 'accept');
                })->orWhere(function($query2) use($userId, $otherUserId) {
                    $query2->where('from_id', $otherUserId)
                            ->where('to_id', $userId)
                            ->where('type', 'accept');
                })->first();
        if (!empty($model)) {
            $otherUserConnections = $this->connections->where(function($query4) use($userId, $otherUserId) {    // get other user's connection accepted connections excepting my id
                        $query4->where('from_id', $otherUserId)->where('to_id', '!=', $userId);
                    })->orWhere(function($query5) use($userId, $otherUserId) {
                        $query5->where('to_id', $otherUserId)->where('from_id', '!=', $userId);
                    })->where('type', 'accept')->where('type', 'accept')->orderBy('id', 'desc')->get();
            return $otherUserConnections;
        }
        return $model;
    }

    /**
     * function using for applay job
     */
    public function saveAppliedJob($request) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        try {
            $post = $request->all();
            if (!empty($post) && $post['form_type'] == 'website') {
                $model = new $this->applyJob;
                $model->apply_status = 'pending';
                $model->user_id = $userId;
                $model->job_id = $post['job_id'];
                $model->save();
                return response()->json(['success' => true]);
            } elseif (!empty($post) && $post['form_type'] == 'faf_account') {
                $model = new $this->applyJob;
                $model->apply_status = 'yes';
                $model->user_id = $userId;
                $model->job_id = $post['job_id'];
                $model->save();
                if (!empty($post['question'])) {
                    foreach ($post['question'] as $key => $question) {
                        $questionModel = new $this->appliedJobQuestion;
                        $questionModel->question = $question;
                        $questionModel->applied_id = $model->id;
                        $questionModel->user_id = $userId;
                        $questionModel->job_id = $post['job_id'];
                        if ($questionModel->save() && !empty($post['answer'][$key]) && count($post['answer'][$key]) > 0) {
                            if ($post['type'][$key] == 'Check Box') {
                                foreach ($post['answer'][$key] as $answer) {
                                    $answerModel = new $this->appliedJobAnswer;
                                    $answerModel->question_id = $questionModel->id;
                                    $answerModel->job_id = $post['job_id'];
                                    $answerModel->user_id = $userId;
                                    $answerModel->answer = $answer;
                                    $answerModel->save();
                                }
                            } else {
                                $answerModel = new $this->appliedJobAnswer;
                                $answerModel->question_id = $questionModel->id;
                                $answerModel->job_id = $post['job_id'];
                                $answerModel->user_id = $userId;
                                $answerModel->answer = $post['answer'][$key];
                                $answerModel->save();
                            }
                        }
                    }
                }
                return response()->json(['success' => true, 'message' => 'Job applied successfully.']);
            } else {
                return response()->json(['success' => true, 'message' => 'Please try again']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function saveEventTeam($request) {
        try {
            $model = $this->eventTeam;
            $model->name = $request->team_name;
            if ($request->hasFile('team_logo')) {
                if ($request->hasFile('team_logo')) {
                    $image_file = $request->file('team_logo');
                    $image = uploadFile($image_file, 'team');
                    $imageThumb = uploadFileThumb($image, 'team/thumb', 'team');
                    uploadFileThumb($image, 'team/thumb', 'team');
                }
                $model->logo = $image;
            }
            $model->save();
            return response()->json(['success' => true, 'message' => 'Team saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Function for delete job.
     */
    public function deleteJob($request) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $this->job->where(['id' => $request->id, 'user_id' => $userId])->delete();
            return response()->json(['success' => true, 'message' => 'Job Deleted.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * function change applied  status
     */

    public function changeAppliedStatus($request) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $model = $this->applyJob->where(['user_id' => $userId, 'apply_status' => 'pending'])->first();
        if (!empty($model)) {
            if ($request->status == 'yes') {
                $model->apply_status = 'yes';
                $model->save();
                return response()->json(['success' => true, 'message' => 'Job applied successfully!']);
            } else {
                $model->delete();
                return response()->json(['success' => true, 'message' => '']);
            }
        } else {
            return response()->json(['success' => false, 'message' => 'please try again']);
        }
    }

    /*
     * Function using for get most liked users for team profile.
     */

    public function getThreeProfileLike() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $result = $this->profileTracker
                        ->select('to_id', DB::raw('COUNT(to_id) as totalLikes'))
                        ->where(function($q) use($userId) {
                            $q->where('from_id', '!=', $userId)
                            ->where('to_id', '!=', $userId);
                        })
                        ->where(function($q1) use($userId) {
                            $q1->whereNOTIn('to_id', function($q2) use($userId) {
                                 $q2->select('to_id')->from('profile_trackers')
                                 ->where('from_id', $userId)
                                 ->where('type', 'like');                                                                 
                             });
                        })                        
                        ->where(function($q3) use($userId) {
                            $q3->whereNOTIn('to_id', function($q4) use($userId) {
                                 $q4->select('from_id')->from('profile_trackers')
                                 ->where('to_id', $userId)
                                 ->where('type', 'like');                                                                                                          
                             });
                        })
                        ->where('type', 'like')
                        ->groupBy('to_id')
                        ->orderBy('totalLikes', 'desc')->take(3)->get();                                                        
        $user_profile = [];
        if (!empty($result)) {
            foreach ($result as $data) {
                $userDetail = $this->user->where('id', $data->to_id)->where('role', 'team')->first();
                array_push($user_profile, $userDetail);
            }
        }
        return $user_profile;
    }

    /** 03-jan-2019
     * function using for gloable searching player lists
     * @param type $request
     */
    public function globalSearchPlayer($request) {
        $userId = (!empty(Auth::guard(getAuthGuard())->user()->id)) ? Auth::guard(getAuthGuard())->user()->id : 0;
        $query = $this->user->select(['users.*', 'states.state_name', 'countries.name as country_name',
                    'countries.short_name', 'user_generals.current_team', 'user_generals.current_league',
                    'user_generals.former_team', 'user_generals.former_league', 'user_generals.under_contract',
                    'user_generals.look_to_sign', 'user_generals.passport'])
                ->join('states', 'states.state_id', '=', 'users.state_id')
                ->join('countries', 'countries.country_id', '=', 'users.country_id')
                ->leftJoin('user_generals', 'user_generals.user_id', '=', 'users.id')
                ->where(['users.role' => 'player'])
                ->where('users.id', '!=', $userId)
                ->whereDoesntHave('userFromConnection', function ($query) use($userId) {
                    $query->where('to_id', $userId)->where('type', '!=', 'unblock')
                    ->where('type', '!=', 'accept')->where('type', '!=', 'pending');
                })
                ->whereDoesntHave('userToConnection', function ($query) use($userId) {
            $query->where('from_id', $userId)->where('type', '!=', 'unblock')
            ->where('type', '!=', 'accept')->where('type', '!=', 'pending');
        });

        if (!empty($request['search'])) {
            $search = $request['search'];
            $positions = $this->position->where('name', 'like', '%' . $search . '%')->pluck('id');
            $query = $query->where(function($q) use($search, $positions) {
                $q->where('users.full_name', 'like', '%' . $search . '%')
                        ->orWhere('users.first_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.last_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('countries.name', 'LIKE', '%' . $search . '%')
                        ->orWhere('states.state_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.city', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.website', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.skype', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.facebook', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.instagram', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.twitter', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.linkedin', 'LIKE', '%' . $search . '%')
                        ->orWhere('user_generals.current_team', 'LIKE', '%' . $search . '%')
                        ->orWhere('user_generals.current_league', 'LIKE', '%' . $search . '%')
                        ->orWhere('user_generals.former_team', 'LIKE', '%' . $search . '%')
                        ->orWhere('user_generals.former_league', 'LIKE', '%' . $search . '%');
                if (count($positions) > 0) {                                                // search by positions
                    $q->orWhere(function ($posQuery) use($positions) {
                        for ($i = 0; $i < count($positions); $i++) {
                            $posQuery->orWhere('position_id', 'like', '%' . $positions[$i] . '%');
                        }
                    });
                }
            });
            return $query->simplePaginate(10);
        } else {
            return false;
        }
    }

    /** 03-jan-2019
     * function using for gloable searching coach list
     * @param type $request
     */
    public function globalSearchCoach($request) {
        $userId = (!empty(Auth::guard(getAuthGuard())->user()->id)) ? Auth::guard(getAuthGuard())->user()->id : 0;
        $query = $this->user->select(['users.*', 'states.state_name', 'countries.name as country_name',
                    'countries.short_name', 'user_generals.current_team',
                    'user_generals.current_league', 'user_generals.former_team', 'user_generals.former_league',
                    'user_generals.under_contract', 'user_generals.look_to_sign', 'user_generals.passport'])
                ->join('states', 'states.state_id', '=', 'users.state_id')
                ->join('countries', 'countries.country_id', '=', 'users.country_id')
                ->leftJoin('user_generals', 'user_generals.user_id', '=', 'users.id')
                ->where(['users.role' => 'coach'])
                ->where('users.id', '!=', $userId)
                ->whereDoesntHave('userFromConnection', function ($query) use($userId) {
                    $query->where('to_id', $userId)->where('type', '!=', 'unblock')
                    ->where('type', '!=', 'accept')->where('type', '!=', 'pending');
                })
                ->whereDoesntHave('userToConnection', function ($query) use($userId) {
            $query->where('from_id', $userId)->where('type', '!=', 'unblock')
            ->where('type', '!=', 'accept')->where('type', '!=', 'pending');
        });

        if (!empty($request['search'])) {
            $search = $request['search'];
            $positions = $this->position->where('name', 'like', '%' . $search . '%')->pluck('id');
            $query = $query->where(function($q) use($search, $positions) {
                $q->where('users.full_name', 'like', '%' . $search . '%')
                        ->orWhere('users.first_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.last_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('countries.name', 'LIKE', '%' . $search . '%')
                        ->orWhere('states.state_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.city', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.website', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.skype', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.facebook', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.instagram', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.twitter', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.linkedin', 'LIKE', '%' . $search . '%')
                        ->orWhere('user_generals.current_team', 'LIKE', '%' . $search . '%')
                        ->orWhere('user_generals.current_league', 'LIKE', '%' . $search . '%')
                        ->orWhere('user_generals.former_team', 'LIKE', '%' . $search . '%')
                        ->orWhere('user_generals.former_league', 'LIKE', '%' . $search . '%');
                if (count($positions) > 0) {                                                    // search by positions
                    $q->orWhere(function ($posQuery) use($positions) {
                        for ($i = 0; $i < count($positions); $i++) {
                            $posQuery->orWhere('position_id', 'like', '%' . $positions[$i] . '%');
                        }
                    });
                }
            });
            return $query->simplePaginate(10);
        } else {
            return false;
        }
    }

    /** 03-jan-2019
     * function using for gloable searching team lists
     * @param type $request
     */
    public function globalSearchTeam($request) {
        $userId = (!empty(Auth::guard(getAuthGuard())->user()->id)) ? Auth::guard(getAuthGuard())->user()->id : 0;
        $query = $this->user->select(['users.*', 'states.state_name', 'countries.name as country_name',
                    'countries.short_name', 'user_generals.current_league', 'user_generals.former_league',
                    'user_generals.under_contract', 'user_generals.look_to_sign', 'user_generals.passport',
                    'user_generals.recruiting', 'user_generals.playing_exp'])
                ->join('states', 'states.state_id', '=', 'users.state_id')
                ->join('countries', 'countries.country_id', '=', 'users.country_id')
                ->leftJoin('user_generals', 'user_generals.user_id', '=', 'users.id')
                ->where(['users.role' => 'team'])
                ->where('users.id', '!=', $userId)
                ->whereDoesntHave('userFromConnection', function ($query) use($userId) {
                    $query->where('to_id', $userId)->where('type', '!=', 'unblock')
                    ->where('type', '!=', 'accept')->where('type', '!=', 'pending');
                })
                ->whereDoesntHave('userToConnection', function ($query) use($userId) {
            $query->where('from_id', $userId)->where('type', '!=', 'unblock')
            ->where('type', '!=', 'accept')->where('type', '!=', 'pending');
        });
        if (!empty($request['search'])) {
            $search = $request['search'];
            $query = $query->where(function($q) use($search) {
                $q->where('users.full_name', 'like', '%' . $search . '%')
                        ->orWhere('states.state_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.city', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.website', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.skype', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.facebook', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.instagram', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.twitter', 'LIKE', '%' . $search . '%')
                        ->orWhere('users.linkedin', 'LIKE', '%' . $search . '%')
                        ->orWhere('user_generals.current_league', 'LIKE', '%' . $search . '%')
                        ->orWhere('user_generals.former_league', 'LIKE', '%' . $search . '%');
            });
            return $query->simplePaginate(10);
        } else {
            return false;
        }
    }

    /*
     * function using for gloable seraching job 
     */

    public function globalSearchJob($request) {
        $query = $this->job->select(['jobs.*', 'states.state_name', 'countries.name as country_name', 'countries.short_name'])
                ->join('states', 'states.state_id', '=', 'jobs.state_id')
                ->join('countries', 'countries.country_id', '=', 'jobs.country_id');

        if (!empty($request['search'])) {
            $search = $request['search'];
            $positions = $this->position->where('name', 'like', '%' . $search . '%')->pluck('id');
            $query = $query->where(function($q) use($search, $positions) {
                $q->where('jobs.institution_name', 'like', '%' . $search . '%')
                        ->orWhere('states.state_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('countries.name', 'LIKE', '%' . $search . '%')
                        ->orWhere('jobs.city', 'LIKE', '%' . $search . '%')
                        ->orWhere('jobs.institution_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('jobs.position_title', 'LIKE', '%' . $search . '%')
                        ->orWhere('jobs.conference', 'LIKE', '%' . $search . '%');
                if (count($positions) > 0) {
                    $q->orWhere(function ($posQuery) use($positions) {
                        for ($i = 0; $i < count($positions); $i++) {
                            $posQuery->orWhere('position_id', 'like', '%' . $positions[$i] . '%');
                        }
                    });
                }
            });
            return $query->simplePaginate(10);
        } else {
            return false;
        }
    }

    /*
     * function using for gloable seraching Event
     */

    public function globalSearchEvent($request) {
        $query = $this->event->with('country', 'state', 'team1Data', 'team2Data')->select(['events.*']);
        if (!empty($request['search'])) {
            $search = $request['search'];
            $query = $query->whereHas('country', function($q1) use($search) {       //search by country name
                        $q1->where('name', 'LIKE', '%' . $search . '%');
                    })->orWhereHas('state', function($q2) use($search) {            //search by state name
                        $q2->where('state_name', 'LIKE', '%' . $search . '%');
                    })->orWhereHas('team1Data', function($q3) use($search) {        //search by team1 name
                        $q3->where('full_name', 'LIKE', '%' . $search . '%');
                    })->orWhereHas('team2Data', function($q4) use($search) {        //search by team2 name
                        $q4->where('full_name', 'LIKE', '%' . $search . '%');
                    })->orWhere('events.event_name', 'like', '%' . $search . '%')   //search by event name    
                    ->orWhere('events.keywords', 'LIKE', '%' . $search . '%')      //search by keywords name
                    ->orWhere('events.city', 'LIKE', '%' . $search . '%')        //search by city name
                    ->orWhere('events.team1', 'LIKE', '%' . $search . '%')        //search by team1 name
                    ->orWhere('events.team2', 'LIKE', '%' . $search . '%');        //search by team2 name
            return $query->simplePaginate(10);
        } else {
            return false;
        }
    }

    /*
     * function using for gloable seraching Post
     */

    public function globalSearchPost($request) {
        $query = $this->post->with('user')->where(['status' => 'active']);
        if (!empty($request['search'])) {
            $search = $request['search'];
            $query = $query->where(function($q) use($search) {
                $q->where('post', 'like', '%' . $search . '%')
                        ->orWhereHas('user', function ($q2) use ($search) {
                            $q2->where('full_name', 'like', '%' . $search . '%');
                        });
            });
            return $query->simplePaginate(10);
        } else {
            return false;
        }
    }

    public function advancedSearch($request) {
        $userType = $request['user_type'];
        $userId = (!empty(Auth::guard(getAuthGuard())->user()->id)) ? Auth::guard(getAuthGuard())->user()->id : 0;
        $query = $this->user->select(['users.*', 'states.state_name', 'countries.name as country_name',
                    'countries.short_name', 'user_generals.current_team', 'user_generals.current_league', 'user_generals.citizenship',
                    'user_generals.former_team', 'user_generals.former_league', 'user_generals.under_contract',
                    'user_generals.look_to_sign', 'user_generals.playing_exp', 'user_generals.recruiting', 'user_generals.passport', 'user_measurables.height_ft', 'user_measurables.height_in',
                    'user_measurables.weight', 'user_experiences.id AS exp_id'])
                ->join('states', 'states.state_id', '=', 'users.state_id')
                ->join('countries', 'countries.country_id', '=', 'users.country_id')
                ->leftJoin('user_generals', 'user_generals.user_id', '=', 'users.id')
                ->leftJoin('user_measurables', 'user_measurables.user_id', '=', 'users.id')
                ->leftJoin('user_experiences', 'user_experiences.user_id', '=', 'users.id');
        if (isset($request['jobs_listed']) && $userType == 'team') {
            $query = $query->Join('jobs', 'jobs.user_id', '=', 'users.id');
        }
        if (isset($request['any_event_listed'])) {
            $query = $query->Join('events', 'events.user_id', '=', 'users.id');
        }
        $query = $query->where(['users.role' => $request['user_type']])
                        ->where('users.id', '!=', $userId)
                        ->whereDoesntHave('userFromConnection', function ($q) use($userId) {
                            $q->where('to_id', $userId)->where('type', '!=', 'unblock')
                            ->where('type', '!=', 'accept')->where('type', '!=', 'pending');
                        })->whereDoesntHave('userToConnection', function ($q) use($userId) {
            $q->where('from_id', $userId)->where('type', '!=', 'unblock')
                    ->where('type', '!=', 'accept')->where('type', '!=', 'pending');
        });

        /*
         * Search by name
         */
        if (!empty($request['name'])) {
            $query = $query->where('full_name', 'LIKE', '%' . $request['name'] . '%');
        }

        /*
         * New user 
         */

        if (!empty($request['new_profile'])) {
            if ($request['new_profile'] == 'last_week') {
                $previous_week = strtotime("-1 week +1 day");
                $start_week = strtotime("last sunday midnight", $previous_week);
                $end_week = strtotime("next saturday", $start_week);
                $start_week = date("Y-m-d", $start_week);
                $end_week = date("Y-m-d", $end_week);
                $query = $query->whereBetween('users.created_at', [$start_week, $end_week]);
            } else {
                $firstDate = date('Y-m-d', strtotime('first day of last month'));
                $lastDate = date('Y-m-d', strtotime('last day of last month'));
                $query = $query->whereBetween('users.created_at', [$firstDate, $lastDate]);
            }
        }

        /*
         * Profile updated since
         */
        if (!empty($request['profile_updated_since'])) {
            if ($request['profile_updated_since'] == 'last_week') {
                $previous_week = strtotime("-1 week +1 day");
                $start_week = strtotime("last sunday midnight", $previous_week);
                $end_week = strtotime("next saturday", $start_week);
                $start_week = date("Y-m-d", $start_week);
                $end_week = date("Y-m-d", $end_week);
                $query = $query->whereBetween('users.updated_at', [$start_week, $end_week]);
            } elseif ($request['profile_updated_since'] == 'last_month') {
                $lastDate = date('Y-m-d', strtotime('last day of last month'));
                $query = $query->where('users.updated_at', '<=', $lastDate);
            } elseif ($request['profile_updated_since'] == 'older') {
                $lastDate = date('Y-m-d', strtotime('last day of last month'));
                $query = $query->where('users.updated_at', '>', $lastDate);
            } else {
                $query = $query->where('users.updated_at', '=', Carbon::yesterday());
            }
        }

        /*
         * Citizenship
         */
        if (!empty($request['citizenship']) && $userType != 'team') {
            $query = $query->where('user_generals.citizenship', $request['citizenship']);
        }
        /*
         * Country
         */
        if (!empty($request['country'])) {
            $query = $query->where('users.country_id', $request['country']);
        }
        /*
         * State
         */
        if (!empty($request['state'])) {
            $query = $query->where('users.state_id', $request['state']);
        }
        /*
         * Check height range
         */
        if (!empty($request['feet_from']) && !empty($request['feet_to']) && $userType == 'player') {
            $inchesFrom = (!empty($request['inches_from'])) ? $request['inches_from'] : 0;
            $inchesTo = (!empty($request['inches_to'])) ? $request['inches_to'] : 0;
            $heightFrom = $request['feet_from'] . '.' . $inchesFrom;
            $heightTo = $request['feet_to'] . '.' . $inchesTo;
            $query = $query->where(function($q) use($heightFrom, $heightTo) {
                $q->where(DB::raw("CONCAT(`user_measurables`.`height_ft`, '.', `user_measurables`.`height_in`)"), '>=', $heightFrom)
                        ->where(DB::raw("CONCAT(`user_measurables`.`height_ft`, '.', `user_measurables`.`height_in`)"), '<=', $heightTo);
            });
        }
        if (!empty($request['feet_from']) && empty($request['feet_to']) && $userType == 'player') {
            $inchesFrom = (!empty($request['inches_from'])) ? $request['inches_from'] : 0;
            $heightFrom = $request['feet_from'] . '.' . $inchesFrom;
            $query = $query->where(function($q) use($heightFrom) {
                $q->where(DB::raw("CONCAT(`user_measurables`.`height_ft`, '.', `user_measurables`.`height_in`)"), '>=', $heightFrom);
            });
        }

        /*
         * Age check
         */
        if (!empty($request['age_from']) && !empty($request['age_to']) && $userType != 'team') {
            $ageFrom = $request['age_from'];
            $ageTo = $request['age_to'];
            $query = $query->where(function($q) use($ageFrom, $ageTo) {
                $q->where('age', '>=', $ageFrom)
                        ->where('age', '<=', $ageTo);
            });
        }
        if (!empty($request['age_from']) && empty($request['age_to']) && $userType != 'team') {
            $ageFrom = $request['age_from'];
            $query = $query->where(function($q) use($ageFrom) {
                $q->where('age', '>=', $ageFrom);
            });
        }

        /*
         * Weight check
         */
        if (!empty($request['weight_from']) && !empty($request['weight_to']) && $userType == 'player') {
            $weightFrom = $request['weight_from'];
            $weightTo = $request['weight_to'];
            $query = $query->where(function($q) use($weightFrom, $weightTo) {
                $q->where('user_measurables.weight', '>=', $weightFrom)
                        ->where('user_measurables.weight', '<=', $weightTo);
            });
        }

        if (!empty($request['weight_from']) && empty($request['weight_to']) && $userType == 'player') {
            $weightFrom = $request['weight_from'];
            $query = $query->where(function($q) use($weightFrom) {
                $q->where('user_measurables.weight', '>=', $weightFrom);
            });
        }
        if (empty($request['weight_from']) && !empty($request['weight_to']) && $userType == 'player') {
            $weightTo = $request['weight_to'];
            $query = $query->where(function($q) use($weightTo) {
                $q->where('user_measurables.weight', '<=', $weightTo);
            });
        }

        /*
         * Native language
         */
        if (isset($request['native_language']) && $userType != 'team') {
            $query = $query->where('user_generals.native_lang_id', $request['native_language']);
        }

        /* search experience */
        if (!empty($request['experience']) && $userType != 'team') {
            $query = $query->where(['user_generals.playing_exp' => $request['experience']]);
        }

        /*
         * passport
         */
        if (isset($request['passport']) && $request['passport'] == 'on' && $userType != 'team') {
            $query = $query->where('user_generals.passport', 'yes');
        }
        /*
         * Under contract
         */
        if (isset($request['under_contrat']) && $request['under_contrat'] == 'on' && $userType != 'team') {
            $query = $query->where('user_generals.under_contract', 'yes');
        }
        /*
         * looking to sign
         */
        if (isset($request['looking_to_sign']) && $request['looking_to_sign'] == 'on' && $userType != 'team') {
            $query = $query->where('user_generals.look_to_sign', 'yes');
        }

        /*
         * searching relocate
         */
        if (isset($request['relocate']) && $userType == 'coach') {
            $query = $query->where('user_generals.relocate', 'yes');
        }

        /*
         * searching  recruiting
         */

        if (isset($request['current_recruitment']) && $userType == 'team') {
            $query = $query->where(['user_generals.recruiting' => 'yes']);
        }

        /*
         * College experience
         */
        if (isset($request['college_exp']) && $request['college_exp'] == 'on' && $userType != 'team') {
            $query = $query->where(['user_exp_type' => 'college'])->whereNotNull('user_experiences.id');
        }
        /*
         * Pro experience
         */
        if (isset($request['pro_exp']) && $request['pro_exp'] == 'on' && $userType != 'team') {
            $query = $query->where(['user_exp_type' => 'pro'])->whereNotNull('user_experiences.id');
        }
        /*
         * International experience
         */
        if (isset($request['international_exp']) && $request['international_exp'] == 'on' && $userType != 'team') {
            $query = $query->where(['user_exp_type' => 'international'])->whereNotNull('user_experiences.id');
        }

        /*
         * Indoor experience
         */
        if (isset($request['indoor_exp']) && $request['indoor_exp'] == 'on' && $userType != 'team') {
            $query = $query->where(['user_exp_type' => 'indoor'])->whereNotNull('user_experiences.id');
        }

        /* search position */
        if (!empty($request['position']) && $userType == 'player') {
            $searchVal = $request['position'];
            $query = $query->Where('users.position_id', 'like', '%' . $searchVal . '%');
        }

        /* search level */
        if (!empty($request['current_level']) && $userType == 'team') {
            $query = $query->where(['users.level_id' => $request['current_level']]);
        }

        if (!empty($request['current_level']) && $userType == 'coach') {
            $query = $query->where(['user_generals.level_id' => $request['current_level']]);
        }

        return $query->groupBy('users.id')->simplePaginate(10);
    }

    /*
     * Get compare users.
     */

    public function getCompareUsers($post) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        if (!empty($post['id'])) {
            $userId = $post['id'];
        }
        $allUsers = $this->connections->where(function($query) use($userId) {
                    $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
                })->where('type', 'accept')->orderBy('id', 'desc')->get();
        $coachUsers = [];

        foreach ($allUsers as $allUser) {
            if ($allUser->from_id == $userId) {
                $otherUser = $allUser->to_id;
            } else {
                $otherUser = $allUser->from_id;
            }
            $allUser['user_id'] = $otherUser;
            array_push($coachUsers, $allUser);
        }
        return $coachUsers;
    }

    /*
     * Add compare users.
     */

    public function addCompareUser($request) {
        if (isset($request->compareId) && count($request->compareId) > 0) {
            return $this->user->whereIn('id', $request->compareId)->get();
        } else {
            return [];
        }
    }

    /*
     * Get compare users data.
     */

    public function getCompareUsersData($request) {
        if (isset($request->userArr) && count($request->userArr) > 0) {
            return $this->user->whereIn('id', $request->userArr)->get();
        } else {
            return [];
        }
    }

    /*
     * Get news by id.
     */

    public function getNewsById($id) {
        return $this->news->where('id', $id)->first();
    }

    /**
     * change password.
     * @param  \Illuminate\Http\Request  $requeste
     * @return \Illuminate\Http\Response
     */
    public function updatePassword($request) {
        try {
            $post = $request->all();
            $user = $this->user->find($post['id']);
            $user->password = bcrypt($post['new_password']);
            $user->save();
            return Response::json(['success' => true, 'message' => 'Password changed successfully.']);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /** 22-jan-2019
     *  function using for get user list by role  
     *  @param type $type
     */
    public function getUserByRole($type) {
        return $this->user->where(['role' => $type, 'status' => 'active'])
                        ->whereDate('created_at', '>=', Carbon::now()->subDays(15))
                        ->get();
    }

    /*     * 23-jan-2019
     * get latest 15 testimonial
     * @return type
     */

    public function getTestimonial() {
        return $this->testimonial->orderBy('id', 'desc')->take(15)->get();
    }

    /* 23-jan-2019
     * function using for get latest 3 news 
     */

    public function getLatestNewsList() {
        return $this->news->where(['status' => 'active'])->orderBy('id', 'desc')->take(9)->get();
    }

    /*
     * 23-jan-2019
     * function using for get latest 15 job
     * @return type  
     */

    public function getLatestJob() {
        return $this->job->where(['status' => 'active'])
                        ->orderBy('id', 'desc')
                        ->take(15)
                        ->get();
    }

    /*
     *  23-jan-2019
     * function using for latest event list
     * return type
     */

    public function getLatestEvent() {
        $currentDate = date("Y-m-d H:i", time());
        return $this->event->select('events.*')->join('users', 'users.id', 'events.user_id')
                        ->whereRaw("TIMESTAMP(events.start_date, events.start_time) > '$currentDate'")
                        ->where('events.status', 'active')->get();
    }

    /*
     * 23-jan-2019
     * get all active news list
     * return type
     */

    public function getAllFafNewsList() {
        return $this->news->where(['status' => 'active'])->orderBy('id', 'desc')->get();
    }

    /**
     * change subscription.
     * @param  \Illuminate\Http\Request  $requeste
     * @return \Illuminate\Http\Response
     */
    public function updateUserSubscription($post) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $customerId = getUserById($userId, 'customer_id');
            $subscriptionId = $post['plan_id'];
            $renewalCycleDays = getSubscriptionData($subscriptionId, 'renewal_cycle');
            $ammount = getSubscriptionData($subscriptionId, 'amount');
            $planSpace = getSubscriptionData($subscriptionId, 'plan_space');
            $startDate = Carbon::today();
            $endDate = Carbon::parse($startDate)->addDay($renewalCycleDays, 'day');
            $planFlag = 'upgrade';
            $uploadedUserMediaSize = getUploadedMediaSizeByUser();
            if (($planSpace*1024*1024*1024) > $uploadedUserMediaSize) { // convert space GB to Bytes
                Stripe::setApiKey(env("STRIPE_SECRET_KEY"));
                $charge = \Stripe\Charge::create(array(
                            "amount" => 100 * $ammount,
                            "currency" => "usd",
                            "customer" => $customerId,
                ));
                if (!empty($charge)) {
                    $user = $this->user->find($userId);
                    $user->subscription_id = $subscriptionId;
                    $user->start_date = $startDate;
                    $user->end_date = $endDate;
                    $user->plan_flag = $planFlag;
                    $user->save();
                    $this->saveTransaction($userId, $subscriptionId, $charge, $startDate, $endDate, $ammount, $planFlag);
                    $this->savePaymentCronData($userId, $charge, 'success', 'Payment successfully');
                    return response()->json(['success' => true, 'message' => 'Plan upgraded successfully.']);
                }
            } else {
                return response()->json(['success' => false, 'message' => 'The plan you selected has not enough space to upload new media,please choose another plan with more space.']);
            }
        } catch (\Stripe\Error\Card $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\RateLimit $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\InvalidRequest $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\Authentication $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\ApiConnection $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * change notification flag.
     * @param  \Illuminate\Http\Request  $requeste
     * @return \Illuminate\Http\Response
     */
    public function updateNotificationFlag($post) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $user = $this->user->find($userId);
            if (isset($post['notification_flag']) && !empty($post['notification_flag'])) {
                if (count($post['notification_flag']) > 1) {
                    $user->notification_flag = 'both';
                } else {
                    $user->notification_flag = $post['notification_flag'][0];
                }
            } else {
                $user->notification_flag = '';
            }
            $user->save();
            return Response::json(['success' => true, 'message' => 'Notification updated successfully.']);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Front notification list on modal.
     */
    public function getNotificationList() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $notificationList = $this->notification->where(['to_id' => $userId, 'type' => 'faf'])->take(5)->orderBy('id', 'desc')->get();
        return $notificationList;
    }

    /*
     * get All User Countrys 
     */

    public function getAllUserCountrys() {
        $userData = $this->user->where(['status' => 'active'])->where('role', '<>', 'subadmin')->where('role', '<>', 'admin')->get();
        $latLongArray = [];
        if (!empty($userData)) {
            foreach ($userData as $key => $address) {
                if (!empty($address->country->name)) {
                    $latLongArray[] = getLatLangByAddress($address->country->name);
                    $latLongArray[$key]['role'] = $address->role;
                }
            }
        }
        return $latLongArray;
    }

    /* function for saving bank source */

    public function savePaymentSource($sourceId, $bankLastFour, $sourceType, $isDefault, $brand, $accountHolderType) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $model = new $this->paymentSource;
        $model->user_id = $userId;
        $model->source_id = $sourceId;
        $model->bank_last_four = $bankLastFour;
        $model->source_type = $sourceType;
        $model->is_default = $isDefault;
        $model->brand = $brand;
        $model->account_holder_type = $accountHolderType;
        $model->save();
    }

    /* function for getting payment sources by logged in user id */

    public function getPaymentSourceById($sourceType) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $query = $this->paymentSource->where('user_id', $userId)->where('source_type', $sourceType);
        if ($sourceType == 'bank') {
            $query = $query->first();
        } else {
            $query = $query->orderBy('id', 'DESC')->get();
        }
        return $query;
    }

    /* function for update default payment method */

    public function updatePaymentMethod($post) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $customerId = Auth::guard(getAuthGuard())->user()->customer_id;
            if ($post['payment_type'] == 'card') {
                $sourceId = $post['user_card'];
                $signupType = 'card';                
            } else {
                $sourceId = $post['payment_type'];
                $signupType = 'ach';                                
            }
            $sourceModel = $this->paymentSource->find($sourceId);
            /* update selected default source to stripe customer account */
            \Stripe\Stripe::setApiKey(env('STRIPE_SECRET_KEY'));
            $customer = \Stripe\Customer::retrieve($customerId);
            $customer->default_source = $sourceModel->source_id;
            if ($customer->save()) {
                /* update selected default source to yes */
                $sourceModel->is_default = 'yes';
                $sourceModel->save();
                $this->paymentSource->where('user_id', $userId)->where('id', '!=', $sourceModel->id)->update(['is_default' => 'no']);
                $this->user->where('id', $userId)->update(['signup_type' => $signupType]);                                	                
                return Response::json(['success' => true, 'message' => 'Default payment method updated successfully.']);
            } else {
                return Response::json(['success' => true, 'message' => 'Failed to updated default Payment method.']);
            }
        } catch (\Stripe\Error\Card $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\RateLimit $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\InvalidRequest $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\Authentication $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\ApiConnection $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /* function for save payment card */

    public function savePaymentCard($post) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $customerId = Auth::guard(getAuthGuard())->user()->customer_id;
            /* get customer detail from stripe by customer id */
            \Stripe\Stripe::setApiKey(env('STRIPE_SECRET_KEY'));
            $customer = \Stripe\Customer::retrieve($customerId);
            /* create new source token for a customer */
            $newSourceToken = \Stripe\Token::create([
                        "card" => [
                            "number" => $post['card_no'],
                            "name" => $post['name_on_card'],
                            "exp_month" => $post['ccExpiryMonth'],
                            "exp_year" => $post['ccExpiryYear'],
                            "cvc" => $post['cvvNumber']
                        ]
            ]);
            /* create a new source for customer */
            $newCardSource = $customer->sources->create(["source" => $newSourceToken['id']]);
            if (!empty($newCardSource)) {
                $this->savePaymentSource($newCardSource['id'], $newCardSource['last4'], 'card', 'no', $newCardSource['brand'], $newCardSource['funding']);
                return Response::json(['success' => true, 'message' => 'Payment card saved successfully.']);
            } else {
                return Response::json(['success' => false, 'message' => 'Failed to create Payment card.']);
            }
        } catch (\Stripe\Error\Card $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\RateLimit $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\InvalidRequest $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\Authentication $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\ApiConnection $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /* function for delete payment card */

    public function deletePaymentCard($id) {
        try {
            /* delete payment source by cardId */
            $cardModel = $this->paymentSource->find($id);
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $customerId = Auth::guard(getAuthGuard())->user()->customer_id;
            \Stripe\Stripe::setApiKey(env('STRIPE_SECRET_KEY'));
            $customer = \Stripe\Customer::retrieve($customerId);
            $paymentCard = $customer->sources->retrieve($cardModel->source_id)->delete();
            $this->paymentSource->where('id', $id)->delete();

            /* set default card recently added if no payment source is default */
            $defaultPaymentSource = $this->paymentSource->where('user_id', $userId)->where('is_default', 'yes')->first();
            if (empty($defaultPaymentSource)) {
                $latestAddedPaymentSource = $this->paymentSource->where('user_id', $userId)->orderBy('id', 'DESC')->first();    // get latest added payment source
                $customer = \Stripe\Customer::retrieve($customerId);                    // retrieve customer by customer_id 
                $customer->default_source = $latestAddedPaymentSource->source_id;       // update customer's default source
                $customer->save();                                                      //save the customer updation
                $latestAddedPaymentSource->is_default = 'yes';                          // update the latest payment source record to default
                $latestAddedPaymentSource->save();                                      // save the changes in model
            }
            return Response::json(['success' => true, 'message' => 'Payment card deleted successfully.']);
        } catch (\Stripe\Error\Card $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\RateLimit $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\InvalidRequest $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\Authentication $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\ApiConnection $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /** add ach payment bank  to existing customer */
    public function addAchPaymentBank($post) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $customerId = Auth::guard(getAuthGuard())->user()->customer_id;
            \Stripe\Stripe::setApiKey(env('STRIPE_SECRET_KEY'));
            $customer = \Stripe\Customer::retrieve($customerId);
            $bank_token = Token::create(array(
                        "bank_account" => array(
                            "country" => "US",
                            "currency" => "USD",
                            "account_holder_name" => $post['account_holder_name'],
                            "account_holder_type" => $post['account_holder_type'],
                            "routing_number" => $post['routing_number'],
                            "account_number" => $post['account_number']
                        )
            ));
            $newBankSource = $customer->sources->create(["source" => $bank_token['id']]);
            //User::where('id', $userId)->update(['token' => $b_tok, 'customer_id' => $customerId, 'ach_verification' => 'no']);
            request()->session()->put('bank_account_id', $newBankSource['id']); /* set bank account id in session */
            request()->session()->put('token', $bank_token['id']); /* set bank token in session */
            request()->session()->put('customer_id', $customerId);             
            return response()->json(['success' => true, 'message' => 'We have deposited two Microamount into your Bank Account.']);
        } catch (\Stripe\Error\Card $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\RateLimit $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\InvalidRequest $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\Authentication $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\ApiConnection $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /* verify newly created ach payment bank amount */

    public function verifyAchPaymentBankAmount($post) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $customerId = request()->session()->get('customer_id');            
            $ammount1 = $post['ammount1'];
            $ammount2 = $post['ammount2'];
            $bankAccountId = request()->session()->get('bank_account_id');
            $bankToken = request()->session()->get('token');
            /* get customer bank source and verify by two deposites micro amounts */
            Stripe::setApiKey(env("STRIPE_SECRET_KEY"));
            $customer = \Stripe\Customer::retrieve($customerId);
            $newBankAccount = $customer->sources->retrieve($bankAccountId);
            $verified = $newBankAccount->verify(array('amounts' => array($ammount1, $ammount2)));
            if (!empty($verified)) {
                $existingUserBank = $this->paymentSource->where('user_id', $userId)->where('source_type', 'bank')->first();    /* retrive existing bank  payment source */
                if (!empty($existingUserBank)) { /* if bank source is exists for this customer */
                    $existingUserBankId = $existingUserBank->source_id;
                    $existingBankIsDefault = $existingUserBank->is_default;
                    $customer = \Stripe\Customer::retrieve($customerId);
                    $customer->sources->retrieve($existingUserBankId)->delete();   /* delete the existing bank source from stripe */
                    $this->paymentSource->where('id', $existingUserBank->id)->delete();     /* also delete from database */
                    if ($existingBankIsDefault == 'yes') { /* if existing bank source is default */
                        $isDefault = 'yes';
                        $customer = \Stripe\Customer::retrieve($customerId);
                        $customer->default_source = $newBankAccount['id'];                    /* set new bank source to default source  */
                        $customer->save();
                    } else {
                        $isDefault = 'no';
                    }
                    $this->savePaymentSource($newBankAccount['id'], $newBankAccount['last4'], 'bank', $isDefault, $newBankAccount['bank_name'], $newBankAccount['account_holder_type']);
                } else {
                    $this->savePaymentSource($newBankAccount['id'], $newBankAccount['last4'], 'bank', 'no', $newBankAccount['bank_name'], $newBankAccount['account_holder_type']);
                }
                request()->session()->forget('bank_account_id');
                request()->session()->forget('token');
                return response()->json(['success' => true, 'message' => 'Your Bank Account has been verified successfully.']);
            }
        } catch (\Stripe\Error\Card $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\RateLimit $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\InvalidRequest $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\Authentication $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\ApiConnection $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /* cancel ACH verification form and remove existing customer's recentlty added bank and set into session */

    public function cancelAchVefiicationForm() {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $customerId = request()->session()->get('customer_id');            
            $bankAccountId = request()->session()->get('bank_account_id');      // recently added bank from setting's add bank page
            Stripe::setApiKey(env("STRIPE_SECRET_KEY"));
            $customer = \Stripe\Customer::retrieve($customerId);
            $customer->sources->retrieve($bankAccountId)->delete();   /* delete the existing bank source from stripe */
            request()->session()->forget('bank_account_id');
            request()->session()->forget('token');
            return response()->json(['success' => true, 'message' => 'Your Bank Account has been verified successfully.']);
        } catch (\Stripe\Error\Card $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\RateLimit $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\InvalidRequest $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\Authentication $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Stripe\Error\ApiConnection $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
        
    /**
     * get payment sources by userId 
     * @param type $userId
     * @return type Object
     */
    
    public function getOtherPaymentSource($id) {
        $userId = Auth::guard(getAuthGuard())->user()->id;        
        return $this->paymentSource->where('user_id', $userId)->where('id','!=',$id)->orderBy('id', 'DESC')->get();    // get latest added payment sources       
    }    
    
    /**
     * save contact us form
     * @param type array $request
     * @return type JSON Response
     */
    public function saveContactUs($post) {
        try {
            $contact = new $this->contact;
            $contact->first_name = $post['first_name'];
            $contact->last_name = $post['last_name'];
            $contact->email = $post['email'];
            $contact->phone_number = $post['phone_number'];
            $contact->message = $post['message'];
            $contact->type = 'faf';
            $contact->request_type = $post['form_type'];            
            $contact->save();
            $data['request'] = 'contact_and_support_mail';
            $data['request_type'] = $post['form_type'];                        
            $data['subject'] = ucfirst($post['form_type'])." mail";            
            $data['name'] = $post['first_name'].' '.$post['last_name'];            
            $data['email'] = $post['email'];
            $data['phone_number'] = $post['phone_number'];            
            $data['message'] = $post['message'];          
            sendMail($data);                                        
            return Response::Json(['success' => true, 'message' => 'Contact us saved successfully.']);            
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
}
