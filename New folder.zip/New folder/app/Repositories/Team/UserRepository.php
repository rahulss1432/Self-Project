<?php

namespace App\Repositories\Team;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Models\UserGeneral;
use App\Models\UserExperience;
use App\Models\UserMedia;
use App\Models\UserMeasurable;
use App\Models\UserBenefits;
use App\Models\MasterBenefits;
use App\Models\TeamPlayer;
use App\Models\TeamStaff;
use App\Models\Job;
use App\Models\JobBenefit;
use Auth;
use Carbon\Carbon;
use App\Models\Connection;
use App\Models\Notification;
use App\Models\ProfileTracker;
use App\Models\News;
use App\Models\Post;
use Illuminate\Support\Facades\Session;

Class UserRepository {

    /**
     * Class Construct.
     *
     * @param  array  $data
     * @return \App\User
     */
    public function __construct(Post $post, User $user, UserGeneral $userGeneral, UserExperience $userExperience, UserMedia $userMedia, UserMeasurable $userMeasurable, UserBenefits $userBenefits, MasterBenefits $masterBenefits, TeamPlayer $teamPlayer, TeamStaff $teamStaff, Job $job, JobBenefit $jobBenefit, Connection $connections, Notification $notification, ProfileTracker $profileTracker, News $news) {
        $this->user = $user;
        $this->userGeneral = $userGeneral;
        $this->userExperience = $userExperience;
        $this->userMedia = $userMedia;
        $this->userMeasurable = $userMeasurable;
        $this->userBenefits = $userBenefits;
        $this->masterBenefits = $masterBenefits;
        $this->teamPlayer = $teamPlayer;
        $this->teamStaff = $teamStaff;
        $this->job = $job;
        $this->jobBenefit = $jobBenefit;
        $this->connections = $connections;
        $this->notification = $notification;
        $this->profileTracker = $profileTracker;
        $this->news = $news;
        $this->post = $post;
    }

    /*
     * Function for get all master benefits.
     */

    public function getAllBenefits() {
        return $this->masterBenefits->where('status', 'approved')->get();
    }

    /**
     * Method for save profile step one
     *
     * @param  array  $data
     * @return \App\User
     */
    public function teamStepOne($request) {
        try {
            $post = $request->all();
            $latLong = Session::get('latLong');
            Session::forget('latLong');
            $latLong = explode('&', $latLong);
            $post['latitude'] = !empty($latLong[0]) ? $latLong[0] : '37.0902';
            $post['longitude'] = !empty($latLong[1]) ? $latLong[1] : '-95.7129';
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $user = $this->user->find($userId);
            $user->institute_type = isset($post['institute_type']) ? $post['institute_type'] : 'no';
            $user->full_name = $post['full_name'];
            $user->level_id = $post['level_id'];
            $user->country_id = $post['country_id'];
            $user->state_id = $post['state_id'];
            $user->city = $post['city'];
            $user->zip_code = $post['zip_code'];
            $user->latitude = $post['latitude'];
            $user->longitude = $post['longitude'];
            if ($request->hasFile('upload_brochure')) {
                $image = $request->file('upload_brochure');
                $name = uploadFile($image, 'team');
//              uploadFileThumb($name, 'team/thumb', 'team');
                $user->upload_brochure = ($name) ? $name : '';
            }
            $user->front_title = $post['front_title'];
            $user->back_title = $post['back_title'];
            $user->bio = $post['bio'];
            $user->updated_by = $userId;
            $user->save();
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'Profile saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for save profile step two
     *
     * @param  array  $data
     * @return \App\User
     */
    public function teamStepTwo($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $user = $this->user->find($userId);
            $user->skype = $post['skype'];
            $user->website = $post['website'];
            $user->facebook = $post['facebook'];
            $user->twitter = $post['twitter'];
            $user->instagram = $post['instagram'];
            $user->linkedin = $post['linkedin'];
            $user->save();
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'Contact information saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function using for get most liked users for team profile.
     */

    public function getThreeProfileLike() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $result = $this->profileTracker
                        ->select('to_id', DB::raw('COUNT(to_id) as totalLikes'))
                        ->where(function($q) use($userId) {
                            $q->where('from_id', '!=', $userId)
                            ->where('to_id', '!=', $userId);
                        })
                        ->where(function($q1) use($userId) {
                            $q1->whereNOTIn('to_id', function($q2) use($userId) {
                                 $q2->select('to_id')->from('profile_trackers')
                                 ->where('from_id', $userId)
                                 ->where('type', 'like');                                                                 
                             });
                        })                        
                        ->where(function($q3) use($userId) {
                            $q3->whereNOTIn('to_id', function($q4) use($userId) {
                                 $q4->select('from_id')->from('profile_trackers')
                                 ->where('to_id', $userId)
                                 ->where('type', 'like');                                                                                                          
                             });
                        })
                        ->where('type', 'like')                        
                        ->groupBy('to_id')
                        ->orderBy('totalLikes', 'desc')->take(3)->get();                        
        $user_profile = [];
        if (!empty($result)) {
            foreach ($result as $data) {
                $userDetail = $this->user->where('id', $data->to_id)->where('role', 'team')->first();
                array_push($user_profile, $userDetail);
            }
        }
        return $user_profile;
    }

    /*
     * Function for save team Step Three General.
     */

    public function teamStepThreeGeneral($request) {
        try {
            $post = $request->all();
            if (!isset($post['recruiting'])) {
                $post['recruiting'] = 'no';
            }
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $user = $this->userGeneral->firstOrNew(['user_id' => $userId]);
            $user->playing_exp = $post['playing_exp'];
            $user->recruiting = isset($post['recruiting']) ? $post['recruiting'] : 'no';
            $user->current_league = $post['current_league'];
            $user->current_league_link = $post['current_league_link'];
            $user->former_league = $post['former_league'];
            $user->former_league_link = $post['former_league_link'];
            $user->save();
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'About saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for profile step 3 about 
     *
     * * @param  $type
     * @return \App\User
     */
    public function teamStepThreeAbout($type) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $query = $this->userExperience->where(['user_exp_type' => $type, 'user_id' => $userId]);
        return $query->orderBy('id', 'DESC')->get();
    }

    /**
     * Method for save profile step 3 
     *
     * @param  array  $data
     * @return \App\User
     */
    public function teamAboutAddUpdate($request) {
        try {
            $image = '';
            $post = $request->all();

            $userId = Auth::guard(getAuthGuard())->user()->id;
            if (!empty($post['id'])) {
                $user = $this->userExperience->find($post['id']);
                $image = $user['logo'];
            } else {
                $user = $this->userExperience;
                $user->user_id = ($userId) ? $userId : '';
            }
            if ($request->hasFile('image')) {
                $image_file = $request->file('image');
                $image = uploadFile($image_file, 'team');
                $imageThumb = uploadFileThumb($image, 'team/thumb', 'team');
            }
            $user->user_exp_type = ($post['user_exp_type']) ? $post['user_exp_type'] : '';
            $user->name = ($post['name']) ? $post['name'] : '';
            $user->logo = ($image) ? $image : '';
            $user->present_organization = ($post['present_organization']) ? $post['present_organization'] : '';
            $user->present_year = ($post['present_year']) ? $post['present_year'] : '';
            $user->save();
            return response()->json(['success' => true, 'tab' => $request['tab_type'], 'message' => 'About saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for save profile step 3 Edit and delete 
     *
     * @param  array  $data
     * @return \App\User
     */
    public function teamAboutEditDelete($request) {
        try {
            $post = $request->all();
            $user = $this->userExperience->find($post['id']);
            if ($post['action'] == 'delete') {
                $user->delete();
            }
            if (!empty($user)) {
                return response()->json(['success' => true, 'user' => $user, 'message' => 'Experience removed successfully.']);
            } else {
                return response()->json(['success' => false, 'message' => 'Something went wrong.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get all team teams.
     */

    public function getTeamPlayer() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return $this->teamPlayer->where('user_id', $userId)->get();
    }

    /*
     * Function for get team players by id.
     */

    public function editTeamPlayer($request) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            return $this->teamPlayer->where(['id' => $request->id, 'user_id' => $userId])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get all team players.
     */

    public function deleteTeamPlayer($request) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $this->teamPlayer->where(['id' => $request->id, 'user_id' => $userId])->delete();
            return response()->json(['success' => true, 'message' => 'Player deleted successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * functin for team Step Four Add Player.
     */

    public function teamStepFourAddPlayer($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard(getAuthGuard())->user()->id;
            if (isset($post['id'])) {
                $model = $this->teamPlayer->find($post['id']);
            } else {
                $model = new $this->teamPlayer;
            }
            $model->user_id = $userId;
            $model->jersey_no = $post['jersey_no'];
            $model->player_name = $post['player_name'];
            $model->position_id = !empty($post['position_id']) ? json_encode($post['position_id']) : '';
            $model->height_ft = $post['height_ft'];
            $model->height_in = $post['height_in'];
            $model->weight = $post['weight'];
            $model->school = $post['school'];
            $model->save();
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'Player saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get all team staff.
     */

    public function getTeamStaff() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return $this->teamStaff->where('user_id', $userId)->get();
    }

    /*
     * Function for get team players by id.
     */

    public function editTeamStaff($request) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            return $this->teamStaff->where(['id' => $request->id, 'user_id' => $userId])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get all team staffs.
     */

    public function deleteTeamStaff($request) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $this->teamStaff->where(['id' => $request->id, 'user_id' => $userId])->delete();
            return response()->json(['success' => true, 'message' => 'Staff deleted successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * functin for team Step Four Add Staff.
     */

    public function teamStepFourAddStaff($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard(getAuthGuard())->user()->id;
            if (isset($post['id'])) {
                $model = $this->teamStaff->find($post['id']);
            } else {
                $model = new $this->teamStaff;
            }
            $model->user_id = $userId;
            $model->name = $post['name'];
            $model->title = $post['title'];
            if ($request->hasFile('profile_picture')) {
                $image = $request->file('profile_picture');
                $name = uploadFile($image, 'team');
                $imageThumb = uploadFileThumb($name, 'team/thumb', 'team');
                $model->profile_picture = $name;
            }
            $model->bio = $post['bio'];
            $model->save();
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'Staff saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * function for save user benefits.
     */

    public function teamStepSix($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $salaryFrom = $post['salary_from'];
            $salaryTo = $post['salary_to'];
            if (!empty($salaryFrom) && !empty($salaryTo)) {
                if ($salaryTo < $salaryFrom) {
                    return response()->json(['success' => false, 'message' => 'The from salary is not greater than To salary.']);
                }
            }
            /* conditon check for one field fill or one field null */
            if ((empty($salaryFrom) && !empty($salaryTo)) || (!empty($salaryFrom) && empty($salaryTo))) {
                    return response()->json(['success' => false, 'message' => 'The from salary and to salary required.']);
            }
            /* update salary range in user table */
            $this->user->where('id', $userId)->update(['from_salary' => $salaryFrom, 'to_salary' => $salaryTo]);
            if (!empty($post['title'])) {
                foreach ($post['title'] as $key => $value) {
                    $model = new $this->masterBenefits;
                    $model->created_by = $userId;
                    $model->title = $post['title'][$key];
                    $model->image = 'icon-benefit';
                    $model->status = 'pending';
                    if ($model->save()) {
                        $userBenefits = new $this->userBenefits;
                        $userBenefits->user_id = $userId;
                        $userBenefits->benefit_id = $model->id;
                        $userBenefits->save();
                    }
                    $getUserType = $this->user->where('role', 'admin')->first();
                    sendNotifacationByUser($userId, $getUserType->id, 'save_benefits', getUserById($userId, 'reference_id'), getUserById($userId, 'full_name'), $model->title, '');
                }
            }
            $this->userBenefits->where('user_id', $userId)->delete();
            if (!empty($post['benefits'])) {
                foreach ($post['benefits'] as $key => $value) {
                    $model = new $this->userBenefits;
                    $model->user_id = $userId;
                    $model->benefit_id = $post['benefits'][$key];
                    $model->save();
                }
            }
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'Profile updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * 
     */

    public function newJobSave($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard(getAuthGuard())->user()->id;
            if (isset($post['id'])) {
                $model = $this->job->find($post['id']);
            } else {
                $model = new $this->job;
            }
            $model->user_id = $userId;
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $name = uploadFile($image, 'team');
                $model->image = $name;
            }
            $model->title = $post['title'];
            $model->city = $post['city'];
            $model->country_id = $post['country_id'];
            $model->level_id = $post['level_id'];
            $model->position_id = $post['position_id'];
            $model->date = date('Y/m/d', strtotime($post['date']));
            $model->salary = $post['salary'];
            $model->expected_start_date = date('Y/m/d', strtotime($post['expected_start_date']));
            $model->season_length = $post['season_length'];
            $model->location = $post['location'];
            $model->description = $post['description'];
            $model->requirements = $post['requirements'];
            $model->status = 'open';
            if ($model->save()) {
                if (isset($post['benefits'])) {
                    if (isset($post['id'])) {
                        $this->jobBenefit->where('job_id', $model->id)->delete();
                    }
                    foreach ($post['benefits'] as $benefit) {
                        $jobBenefit = new $this->jobBenefit;
                        $jobBenefit->user_id = $userId;
                        $jobBenefit->job_id = $model->id;
                        $jobBenefit->benefit_id = $benefit;
                        $jobBenefit->save();
                    }
                }
            }
            return response()->json(['success' => true, 'message' => 'Job saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get all posted job.
     */

    public function getPostJob() {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            return $this->job->where('user_id', $userId)->where('status', 'active')->take(4)->get();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get post jobs.
     */

    public function teamProfileJobList($id = null) {

        $jobs = $this->user->getPostProfileJob($id);
        $html = View::make('team::ajax-content._teamprofile-joblist', ['jobs' => $jobs])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Function for get all posted job for profile.
     */

    public function getPostProfileJob($id = null) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        if (!empty($id)) {
            $userId = $id;
        }
        return $this->job->where('user_id', $userId)->take(10)->get();
    }

    /*
     * Function for get all posted job.
     */

    public function newPlayerList() {
        try {
            return $this->user->where('role', 'player')
                            ->whereDate('created_at', '>=', Carbon::now()->subDays(15))
                            ->where('status', 'active')
                            ->orderBy('id', 'desc')->take(4)->get();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get job details.
     */

    public function getJobDetails($id) {
        try {
            return $this->job->where(['id' => $id])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get job details.
     */

    public function deleteTeamJob($request) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            $this->job->where(['id' => $request->id, 'user_id' => $userId])->delete();
            return response()->json(['success' => true, 'message' => 'Job deleted successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get job details.
     */

    public function editJob($id) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
            return $this->job->where(['id' => $id, 'user_id' => $userId])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * get user details.
     *
     * @return \App\User
     */
    public function getUseDetails($id) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        if (!empty($id)) {
            $userId = $id;
        }
        return $this->user->where('id', $userId)->first();
    }

    /**
     * get recent joined members.
     *
     * @return \App\User
     */
    public function getRecentJoinedMembers($request) {
        $post = $request->all();
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $query = $this->user->whereDoesntHave('userFromConnection', function ($query) use($userId) {
                    $query->where('to_id', $userId)->where('type', '!=', 'unblock');
                })
                ->whereDoesntHave('userToConnection', function ($query) use($userId) {
                    $query->where('from_id', $userId)->where('type', '!=', 'unblock');
                })->where('role', '!=', 'admin')
                ->where('role', '!=', 'subadmin')
                ->where('status', 'active');
        if (!empty($request) && !empty($request->id)) {  // when member get other profile member
            $query->where('id', '!=', $request->id)
                    ->where('id', '!=', $userId);
        } else {
            $query->where('id', '!=', $userId);
        }
        $data = $query->whereDate('created_at', '>=', Carbon::now()->subDays(15))
                        ->orderBy('id', 'desc')->take(15)->get();
        return $data;
    }

    /**
     * connect dismiss member.
     */
    public function connectDismissMember($post) {
        try {
            $fromId = Auth::guard(getAuthGuard())->user()->id;
            $toId = $post['id'];
            $getToUserRole = getUserById($toId, 'role');
            /* check user available or not first */
            if ($getToUserRole != 'player') {
                $user_availability = $this->user->where(['id' => $toId, 'current_status' => 'away'])->count();
                if ($user_availability > 0) {
                    return response()->json(['success' => false, 'message' => 'User is not accepting connection requests at the moment. Please try again later.']);
                }
            }
            /* check for if user block and then block after that send request then check in connection and update request */
            $typee = $post['type'] == 'connect' ? 'pending' : 'reject';
            $chat_status = $post['type'] == 'connect' ? 'yes' : 'yes';
            $connection1_check = $this->connections->where(['from_id' => $fromId, 'to_id' => $toId, 'type' => 'unblock'])->first();
            $connection2_check = $this->connections->where(['from_id' => $toId, 'to_id' => $fromId, 'type' => 'unblock'])->first();
            if (!empty($connection1_check)) {
                $c1 = $this->connections->where(['id' => $connection1_check->id])->update(['from_id' => $fromId, 'to_id' => $toId, 'chat_list' => $chat_status, 'type' => $typee]);
                if (!empty($c1)) {
                    return response()->json(['success' => true, 'message' => "Request" . $post['type'] . " successfully"]);
                }
            }
            if (!empty($connection2_check)) {
                $c2 = $this->connections->where(['id' => $connection2_check->id])->update(['from_id' => $fromId, 'to_id' => $toId, 'chat_list' => $chat_status, 'type' => $typee]);
                if (!empty($c2)) {
                    return response()->json(['success' => true, 'message' => "Request" . $post['type'] . " successfully"]);
                }
            }
            /* end check */
            $connection1 = $this->connections->where(['from_id' => $fromId, 'to_id' => $toId])->first();
            $connection2 = $this->connections->where(['from_id' => $toId, 'to_id' => $fromId])->first();
            if (!empty($connection1) || !empty($connection2)) {
                return response()->json(['success' => false, 'message' => "User already exists in your request list."]);
            } else {
                $model = $this->connections;
                $model->from_id = $fromId;
                $model->to_id = $post['id'];
                $model->type = $post['type'] == 'connect' ? 'pending' : 'reject';
                $model->save();
                $currentStatus = getUserById($post['id'], 'current_status');
                if ($post['type'] == 'connect' && $currentStatus == "available") {
                    sendNotifacationByFrontUser($fromId, $post['id'], 'connect', '', '');
                }
                return response()->json(['success' => true, 'message' => "Request " . $post['type'] . " successfully"]);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Change user work mode.
     */

    public function workMode() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $check = $this->user->where(['id' => $userId, 'current_status' => 'available'])->count();
        if ($check > 0) {
            $this->user->where('id', $userId)->update(['current_status' => 'away']);
            return 'away';
        } else {
            $this->user->where('id', $userId)->update(['current_status' => 'available']);
            return 'available';
        }
    }

    /*
     * Get user notifications.
     */

    public function getNotification() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return $this->notification->where(['to_id' => $userId, 'is_read' => '0', 'type' => 'faf'])->count();
    }

    /*
     * Get all notifications.
     */

    public function getAllNotifications() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $this->notification->where(['to_id' => $userId, 'type' => 'faf'])->update(['is_read' => '1']);
        return $this->notification->where(['to_id' => $userId, 'type' => 'faf'])->orderBy('id', 'desc')->simplePaginate(10);
    }

    /*
     * Delete notifications.
     */

    public function deleteNotifications($id) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $this->notification->where(['to_id' => $userId, 'id' => $id, 'type' => 'faf'])->delete();
    }

    /*
     * Get Connections List.
     */

    public function userConnectionsList($request = null) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        if (!empty($request) && !empty($request->id)) {
            $userId = $request->id;
        }
        $connections = $this->connections->where(function($query) use($userId) {
                    $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
                })->where('type', 'accept')->orderBy('id', 'desc')->get();
        if (count($connections) > 0) {
            foreach ($connections as $connection) {
                if ($connection->from_id == $userId) {
                    $otherUser = $connection->to_id;
                } else {
                    $otherUser = $connection->from_id;
                }
                $userData = $this->user->find($otherUser);
                $userImg = checkUserImage($userData->profile_image, $userData->role . '/thumb');
                if ($userData->role == 'player') {
                    $url = url('view/player-profile/' . $userData->slug);
                } else if ($userData->role == 'coach') {
                    $url = url('view/coach-profile/' . $userData->slug);
                } else {
                    $url = url('view/team-profile/' . $userData->slug);
                }
                if ($userData->status == 'active') {
                    if ($userData->id == Auth::guard(getAuthGuard())->user()->id) {
                        echo "<li class='list-inline-item'>
                            <a href='javascript:void(0);' title='You'>
                                <img src='$userImg' alt='user'>
                            </a>
                        </li>";
                    } else {
                        echo "<li class='list-inline-item'>
                            <a href='$url' title='$userData->first_name ( $userData->role )'>
                                <img src='$userImg' alt='user'>
                            </a>
                        </li>";
                    }
                }
            }
        } else {
            echo "<script>$('#connection_view').hide(); $('#divNoConnection').show();</script>";
        }
    }

    /*
     * Get All Connections.
     */

    public function getAllConnections($post) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        if (!empty($post['id'])) {
            $userId = $post['id'];
        }
        $request = $post;
        $request['userId'] = $userId;
        $data = $this->connections->with(['fromUser', 'toUser']);
        $data = $data->where(function($query) use($request) {
            $query->whereHas('toUser', function($q1) use($request) {
                        $q1->where('id', '!=', $request['userId']);
                        $q1->where('status', '=', 'active');
                        if (!empty($request['id'])) {
                            $q1->where('id', '!=', Auth::guard(getAuthGuard())->user()->id);
                        }
                        if (!empty($request['full_name'])) {
                            $q1->where('full_name', 'LIKE', '%' . $request['full_name'] . '%');
                        }
                        if (!empty($request['member_type'])) {
                            $q1->where('role', '=', $request['member_type']);
                        }
                        if (!empty($request['city'])) {
                            $q1->where('city', 'LIKE', '%' . $request['city'] . '%');
                        }
                    })
                    ->orWhereHas('fromUser', function($q2) use($request) {
                        $q2->where('id', '!=', $request['userId']);
                        $q2->where('status', '=', 'active');
                        if (!empty($request['id'])) {
                            $q2->where('id', '!=', Auth::guard(getAuthGuard())->user()->id);
                        }
                        if (!empty($request['full_name'])) {
                            $q2->where('full_name', 'LIKE', '%' . $request['full_name'] . '%');
                        }
                        if (!empty($request['member_type'])) {
                            $q2->where('role', '=', $request['member_type']);
                        }
                        if (!empty($request['city'])) {
                            $q2->where('city', 'LIKE', '%' . $request['city'] . '%');
                        }
                    });
        });
        $data = $data->where(function($query) use($userId) {
                    $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
                })->where('type', 'accept')->orderBy('id', 'desc')->simplePaginate(5);
        $reuslt = $data;
        return $reuslt;
    }

    /*
     * Accept Reject Connections.
     */

    public function acceptRejectConnection($request) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $pendingRequest = $this->connections->where(['to_id' => $userId, 'type' => 'pending'])->first();
        $this->connections->where(function($query) use($userId) {
            $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
        })->where('id', $request->id)->update(['type' => $request->type]);
        $currentStatus = getUserById($pendingRequest->from_id, 'current_status');
        if ($request->type == 'accept' && $currentStatus == "available") {
            sendNotifacationByFrontUser($userId, $pendingRequest->from_id, 'accept', '', '');
        }
    }

    /*
     * Function using for get user profile by id.
     */

    public function getUserProfileById($id) {
        $result = $this->user->where(['id' => $id])->first();
        return $result;
    }

    public function getConnectionsCount($id) {
        $userId = $id;
        $connections = $this->connections->where(function($query) use($userId) {
                    $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
                })->where('type', 'accept')->count();
        return $connections;
    }

    public function getFollowCount($id) {
        $userId = $id;
        $followCount = $this->profileTracker->where('type', 'follow')
                        ->where('from_id', $userId)->count();
        return $followCount;
    }

    public function getFollowersCount($id) {
        $userId = $id;
        $followersCount = $this->profileTracker->where('type', 'follow')
                        ->where('to_id', $userId)->count();
        return $followersCount;
    }

    public function getViewCount($id) {
        $userId = $id;
        $viewCount = $this->profileTracker->where('type', 'view')
                        ->where('to_id', $userId)->count();
        return $viewCount;
    }

    public function getLikeCount($id) {
        $userId = $id;
        $likeCount = $this->profileTracker->where('type', 'like')
                        ->where('to_id', $userId)->count();
        return $likeCount;
    }

    /*
     * Get latest new add by admin
     */

    public function getLatestNews() {
        return $this->news->OrderBy('id', 'desc')->get();
    }

    /**
     * get joined member based on matched country,state,city and non mutual friends.
     *
     * @return \App\User
     */
    public function getMatchedAndMutualJoinedMembers($request) {
        $post = $request->all();
        $auth = Auth::guard(getAuthGuard())->user();
        $userId = $auth->id;
        $city = $auth->city;
        $country = $auth->country_id;
        $state = $auth->state_id;
        if (!empty($post) && !empty($post['id'])) {
            $otherUserId = $post['id'];
            $city = getUserById($otherUserId, 'city');
            $country = getUserById($otherUserId, 'country_id');
            $state = getUserById($otherUserId, 'state_id');
        }
        // query for get not mutual or connected member with connection table with auth user id      
        $query = $this->user->with('userFromConnection', 'userToConnection')->whereDoesntHave('userFromConnection', function ($query) use($userId) {
                    $query->where('to_id', $userId)->where('type', '!=', 'unblock');
                })
                ->whereDoesntHave('userToConnection', function ($query) use($userId) {
                    $query->where('from_id', $userId)->where('type', '!=', 'unblock');
                })->where('role', '!=', 'admin')
                ->where('role', '!=', 'subadmin')
                ->where('status', 'active');
        if (!empty($post) && !empty($post['id'])) { // when member get other profile member
            $query->where('id', '!=', $post['id'])
                    ->where('id', '!=', Auth::guard(getAuthGuard())->user()->id);
        } else {
            $query->where('id', '!=', $userId);
        }
        if (isset($post['full_name']) && !empty($post['full_name'])) {
            $query->where('full_name', 'like', '%' . $post['full_name'] . '%');
        }
        if (isset($post['member_type']) && !empty($post['member_type'])) {
            $query->where('role', '=', $post['member_type']);
        }
        if (isset($post['city']) && !empty($post['city'])) {
            $query->where('city', 'like', '%' . $post['city'] . '%');
        }
        $data = $query->take(250)->get();

        if ($data->count() > 0) {
            $newArr = [];
            $cityArr = [];
            $stateArr = [];
            $countryArr = [];
            if (!empty($post) && !empty($post['id'])) {         // when member get other profile member
                foreach ($data as $key => $value) {
                    if (!empty($value['userFromConnection'][0])) {        // check user connection by from id with user's id
                        $fromId = $value['userFromConnection'][0]['from_id'];
                        $toId = $value['userFromConnection'][0]['to_id'];
                    } elseif (!empty($value['userToConnection'][0])) {    // check user connection by to id with user's id
                        $fromId = $value['userToConnection'][0]['from_id'];
                        $toId = $value['userToConnection'][0]['to_id'];
                    } else {
                        $fromId = '';
                        $toId = '';
                    }
                    if ($post['id'] == $fromId || $post['id'] == $toId) {
                        $cityArr[] = $value;      // for matched user record for mutual friend of other user and place it in empty array
                    } else {
                        $stateArr[] = $value;
                    }
                }
            } else {
                foreach ($data as $key => $value) {     // when member get profile members by city,state and country
                    $valCity = $value['city'];
                    $valState = $value['state_id'];
                    $valCountry = $value['country_id'];
                    if ($city == $valCity) {
                        $cityArr[] = $value;
                    } elseif ($state == $valState) {
                        $stateArr[] = $value;
                    } elseif ($country == $valCountry) {
                        $countryArr[] = $value;
                    } else {
                        $newArr[] = $value;
                    }
                }
            }
            $data = array_merge($cityArr, $stateArr, $countryArr, $newArr);
        }
        return $data;
    }

    /*
     * Get All Friend requests.
     */

    public function getAllFriendRequests($post) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $request = $post;
        $request['userId'] = $userId;

        $data = $this->connections->with(['fromUser', 'toUser']);
        //  if (!empty($request['full_name']) || !empty($request['member_type']) || !empty($request['city'])) {
        $data = $data->where(function($query) use($request) {
            $query->whereHas('toUser', function($q1) use($request) {
                        $q1->where('id', '!=', $request['userId']);
                        $q1->where('status', '=', 'active');

                        if (!empty($request['full_name'])) {
                            $q1->where('full_name', 'LIKE', '%' . $request['full_name'] . '%');
                        }
                        if (!empty($request['member_type'])) {
                            $q1->where('role', '=', $request['member_type']);
                        }
                        if (!empty($request['city'])) {
                            $q1->where('city', 'LIKE', '%' . $request['city'] . '%');
                        }
                    })
                    ->orWhereHas('fromUser', function($q2) use($request) {
                        $q2->where('id', '!=', $request['userId']);
                        $q2->where('status', '=', 'active');

                        if (!empty($request['full_name'])) {
                            $q2->where('full_name', 'LIKE', '%' . $request['full_name'] . '%');
                        }
                        if (!empty($request['member_type'])) {
                            $q2->where('role', '=', $request['member_type']);
                        }
                        if (!empty($request['city'])) {
                            $q2->where('city', 'LIKE', '%' . $request['city'] . '%');
                        }
                    });
        });
        //  }
        $data = $data->where(function($query) use($userId) {
                    $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
                })->where('type', 'pending')->orderBy('id', 'desc')->simplePaginate(5);
        $reuslt = $data;
        return $reuslt;
    }

    /*
     * Function for get unread request count.
     */

    public function getRequestUnreadCount() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return $this->connections->where(['to_id' => $userId, 'status' => 'unread'])->count();
    }

    /*
     * Function for change connection status to read.
     */

    public function changeConnectionStatus() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return $this->connections->where(['to_id' => $userId, 'status' => 'unread'])->update(['status' => 'read']);
    }

}
