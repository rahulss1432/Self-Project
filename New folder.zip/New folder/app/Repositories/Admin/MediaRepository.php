<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\UserMedia;
use Auth;
use App\Models\Post;
use App\Models\MediaComments;
use App\Models\UserPostAction;
Class MediaRepository {

    /**
     * Class Construct.
     * @param UserMedia $userMedia
     * @param Post $post
     * @param MediaComments $mediaComments
     */
    public function __construct(UserMedia $userMedia, Post $post, MediaComments $mediaComments , UserPostAction $userPostAction) {
        $this->userMedia = $userMedia;
        $this->post = $post;
        $this->mediaComments = $mediaComments;
        $this->userPostAction = $userPostAction;
    }

    /**
     * function using get all media list
     * @param type $request
     * @return type
     */
    public function getMediaList($request) {
        $query = $this->userMedia->select(['user_medias.*', 'posts.type', 'posts.reference_id as post_reference_id', 'posts.post', 'users.full_name', 'posts.status as post_status'])
                ->join('users', 'users.id', '=', 'user_medias.user_id')
                ->join('posts', 'posts.id', '=', 'user_medias.post_id');
        /* check order of media by new ,old and recently updated */
        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $query->orderBy('user_medias.id', $request['orderBy']);
            } else {
                $query->orderBy('user_medias.updated_at', 'desc');
            }
        }
        /* text search by columns of media list */
        if (!empty($request['search_input']) && isset($request['search_input'])) {
            $searchText = $request['search_input'];
            $query->where(function($q) use($searchText) {
                $q->where('user_medias.reference_id', 'like', '%' . $searchText . '%')
                        ->orWhere('users.full_name', 'like', '%' . $searchText . '%')
                        ->orWhere("posts.reference_id", 'LIKE', '%' . $searchText . '%');
            });
        }
        /* Filter active inactive */
        if (!empty($request['status']) && isset($request['status'])) {
            $query->where('user_medias.status', $request['status']);
        }
        /* Filter by type */
        if (!empty($request['media_type']) && isset($request['media_type'])) {
            $query->where('user_medias.media_type', $request['media_type']);
        }
        /* Filter from date to date */
        if (!empty($request['startDate']) && !empty($request['endDate'])) {
            $from = startDateFormatServer($request['startDate']);
            $to = endDateFormatServer($request['endDate']);
            $query->whereBetween('user_medias.created_at', array($from, $to));
        }

        return $query->where('posts.status', 'active')->where('posts.type', 'media')->paginate(getPaginatePage());
    }

    /**
     * function using for get media list by id
     * @param type $id
     * @return type
     */
    public function getMediaById($id) {
        $result = $this->userMedia->where(['id' => $id])->first();
        return $result;
    }

    /**
     * function using for get media comment list
     * @param type $id
     * @param type $type
     * @return type
     */
    public function getMediaCommentById($id, $type) {
        $result = $this->mediaComments->where(['media_id' => $id, 'type' => $type])->get();        
        return $result;
    }

    /**
     * function using for update status
     * @param type $request
     * @return type
     */
    public function updateStatus($request) {
        try {
            $post = $request->all();
            $media = $this->userMedia->find($post['id']);
            if (empty($media)) {
                return redirect()->back();
            }
            $media->status = $post['status'];
            $media->save();
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
