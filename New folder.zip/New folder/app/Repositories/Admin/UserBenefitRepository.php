<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Auth;
use App\Models\MasterBenefits;

Class UserBenefitRepository {

    /**
     * Class Construct.
     * @param MasterBenefits $MasterBenefits
     */
    public function __construct(MasterBenefits $MasterBenefits) {
        $this->userBenefits = $MasterBenefits;
    }

    /**
     * function using get all user benefit list.
     * @param type $request
     * @return type
     */
    public function getAllUserBenefits($request) {
        $userBenefitList = $this->userBenefits->select('master_benefits.*', 'users.first_name', 'users.last_name')
                ->join('users', 'master_benefits.created_by', 'users.id');
        if (!empty($request['orderBy'])) {
            if ($request['orderBy'] == 'asc' || $request['orderBy'] == 'desc') {
                $userBenefitList->orderBy('id', $request['orderBy']);
            } else {
                $userBenefitList->orderBy('updated_at', 'desc');
            }
        }
        /* text search by columns of admin list */
        if (!empty($request['columns'])) {
            $text = $request['columns'];
            $userBenefitList->where(function ($query) use ($text) {
                $query->where('title', 'like', '%' . $text . '%')
                        ->orWhere('first_name', 'like', '%' . $text . '%')
                        ->orWhere('last_name', 'like', '%' . $text . '%');
            });
        }
        $rows = $userBenefitList->Paginate(getPaginatePage());
        if (!empty($rows)) {
            return $rows;
        }
    }

    /**
     * Update user benefit status.
     * @param type $request
     * @return type
     */
    public function changeStatus($request) {
        try {
            $post = $request->all();
            $user_status = $this->userBenefits->find($post['id']);
            if (empty($user_status)) {
                return redirect()->back();
            }
            $user_status->status = $post['status'];
            $user_status->save();
            if ($user_status->status == "approved") {
                sendNotifacationByFrontUser(Auth::guard(getAuthGuard())->user()->id, $user_status->created_by, 'benefit_approved', $user_status->title, '');
            }
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
