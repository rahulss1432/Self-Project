<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Transaction;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class PaymentRepository {

    /**
     * Class Construct.
     * @param $category
     */
    public function __construct(Transaction $transaction) {
        $this->transaction = $transaction;
    }

    /**
     * Manage Payment.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function getAllPayments($post) {
        try {
            $paymentList = $this->transaction->orderBy('id', 'desc');
            /* Filter from date to date */
            if (!empty($post['from_date']) && !empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $to = date('Y-m-d', strtotime($post['to_date']));
                $paymentList->whereDate('created_at', '>=', $from)
                        ->whereDate('created_at', '<=', $to);
            }
            if (!empty($post['from_date']) && empty($post['to_date'])) {
                $from = date('Y-m-d', strtotime($post['from_date']));
                $paymentList->whereDate('created_at', $from);
            }
            if (!empty($post['to_date']) && empty($post['from_date'])) {
                $to = date('Y-m-d', strtotime($post['to_date']));
                $paymentList->whereDate('created_at', $to);
            }
            /* Filter By Booking Id */
            if (isset($post['booking_id']) && !empty($post['booking_id'])) {
                $paymentList->where('booking_id', $post['booking_id']);
            }
            /* Filter By Mentors */
            if (isset($post['mentor_name']) && !empty($post['mentor_name'])) {
                $paymentList->where('mentor_id', $post['mentor_name']);
            }
            /* Filter By Users */
            if (isset($post['user_name']) && !empty($post['user_name'])) {
                $paymentList->where('user_id', $post['user_name']);
            }
            $rows = $paymentList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
    
    /**
     * Manage Commission.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function getAllCommissions($post) {
        try {
            $commissionList = $this->transaction->orderBy('id', 'desc');
            $rows = $commissionList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

}
