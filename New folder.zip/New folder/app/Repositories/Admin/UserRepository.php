<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class UserRepository {

    /**
     * Class Construct.
     * @param User $user
     */
    public function __construct(User $user) {
        $this->user = $user;
    }

    /**
     * Manage User.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function getAllUsers($post) {
        try {
            $userList = $this->user->where(['role' => 'user']);
            /* Filter By Name */
            if (isset($post['name']) && !empty($post['name'])) {
                $searchData = $post['name'];
                $userList->where(function($query) use($searchData) {
                    $query->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $searchData . '%');
                });
            }
            /* Filter By Email */
            if (isset($post['email']) && !empty($post['email'])) {
                $userList->where('email', 'like', '%' . $post['email'] . '%');
            }
            /* Filter active inactive */
            if (isset($post['status']) && !empty($post['status'])) {
                $userList->where('status', $post['status']);
            }
            $rows = $userList->orderBy('id', 'desc')->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /*
     * change  users's status
     */

    public function changeUserStatus($request) {
        try {
            $post = $request->all();
            $user_status = $this->user->find($post['id']);
            if (empty($user_status)) {
                return redirect()->back();
            }
            $user_status->status = $post['status'];
            $user_status->save();
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * load user profile
     */

    public function loadUserProfile($request) {
        try {
            return $this->user->where('id', $request['id'])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * change password.
     * @param  \Illuminate\Http\Request  $requeste
     * @return \Illuminate\Http\Response
     */
    public function updatePassword($request) {

        try {
            $post = $request->all();
            $user = $this->user->find($post['id']);
            if (!\Hash::check($post['current_password'], $user->password)) {
                return json_encode(array('success' => false, 'message' => 'Current password does not match.'));
            } else {
                $user->update(array('password' => bcrypt($request['new_password'])));
            }
            return json_encode(array('success' => true, 'message' => 'Password changed successfully.'));
        } catch (\Exception $e) {
            return json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
    }
    
    /**
     * 26-feb-2019
     * @param  \Illuminate\Http\Request  $requeste
     * @return \Illuminate\Http\Response
     */
    
    public function getContractorList($post){
         try {
            $userList = $this->user->where(['role' => 'mentor', 'status' => 'active']);
            /* Filter By Name */
            if (isset($post['name']) && !empty($post['name'])) {
                $searchData = $post['name'];
                $userList->where(function($query) use($searchData) {
                    $query->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $searchData . '%');
                });
            }
            /* Filter By Email */
            if (isset($post['email']) && !empty($post['email'])) {
                $userList->where('email', 'like', '%' . $post['email'] . '%');
            }
            /* Filter active inactive */
            if (isset($post['status']) && !empty($post['status'])) {
                $userList->where('status', $post['status']);
            }
            
            $rows = $userList->orderBy('id', 'desc')->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
    
  /**
   * 26-feb-2019
   * function using for update contractor  status 
   * @param type $request
   */
    public function updateCategoryStatus($request){
         try {
            $post = $request->all();
            $status = $this->user->find($post['id']);
            if (empty($status)) {
                return redirect()->back();
            }
            $status->status = $post['status'];
            $status->save();
            return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    /*
     * 26-feb-2019
     * function using for delete contractor user
     */
    public function removeContractor($id) {
       try {
            $this->user->where(['id' => $id])->delete();
            return response()->json(['success' => true, 'message' => 'Contractor deleted successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    /**
     * 26-feb-2019
     * get user details by id  
     * @param type $id
     */
    public function getUserById($id){
       try {
           return  $this->user->find($id);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    /**
     * 26-feb-2019
     * @param  \Illuminate\Http\Request  $requeste
     * @return \Illuminate\Http\Response
     */
    
    public function getPendingContractorList($post){
         try {
            $userList = $this->user->where(['role' => 'mentor', 'status' => 'inactive']);
            /* Filter By Name */
            if (isset($post['name']) && !empty($post['name'])) {
                $searchData = $post['name'];
                $userList->where(function($query) use($searchData) {
                    $query->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $searchData . '%');
                });
            }
            /* Filter By Email */
            if (isset($post['email']) && !empty($post['email'])) {
                $userList->where('email', 'like', '%' . $post['email'] . '%');
            }
            /* Filter active inactive */
            if (isset($post['status']) && !empty($post['status'])) {
                $userList->where('status', $post['status']);
            }
            
            $rows = $userList->orderBy('id', 'desc')->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

}
