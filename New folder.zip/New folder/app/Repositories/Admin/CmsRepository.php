<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Faq;
use App\Models\Cms;
use Illuminate\Support\Facades\Session;
use Auth;
use Illuminate\Support\Facades\Response;

Class CmsRepository {

    /**
     * Class Construct.
     * @param $faq
     */
    public function __construct(Faq $faq, Cms $cms) {
        $this->faq = $faq;
        $this->cms = $cms;
    }

    /**
     * Manage Faq.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function getAllFaqs($post) {
        try {
            $faqList = $this->faq->orderBy('id', 'desc');
            $rows = $faqList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /*
     * add and edit faq method
     */

    public function addFaqs($post) {
        try {
            if (isset($post['faq_id'])) {
                $model = $this->faq->find($post['faq_id']);
            } else {
                $model = new $this->faq;
            }
            $model->question = $post['question'];
            $model->answer = $post['answer'];
            $model->save();
            if (isset($post['faq_id'])) {
                return response()->json(['success' => true, 'message' => 'Faq updated successfully.']);
            } else {
                return response()->json(['success' => true, 'message' => 'Faq added successfully.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Delete faqs.
     */

    public function deleteFaqs($id) {
        try {
            $this->faq->where(['id' => $id])->delete();
            return response()->json(['success' => true, 'message' => 'Faq deleted successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Edit faqs.
     */

    public function showEditFaqs($id) {
        try {
            return $this->faq->where(['id' => $id])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Manage Cms.
     * @param null
     * @return \Illuminate\Http\Response
     */
    public function getAllCms($post) {
        try {
            $cmsList = $this->cms->orderBy('id', 'desc');
            $rows = $cmsList->paginate(10);
            if (!empty($rows)) {
                return $rows;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
    
    /*
     * Edit cms.
     */

    public function showEditCms($id) {
        try {
            return $this->cms->where(['id' => $id])->first();
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
