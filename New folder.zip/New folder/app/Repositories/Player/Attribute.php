<?php

namespace App\Repositories\Player;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\ValidateAttributes;
use App\Models\UserValidateAttributes;

Class Attribute {

    /**
     * Class Construct.
     *
     * @param  array  $data
     * @return \App\User
     */
    public function __construct(ValidateAttributes $attributes, UserValidateAttributes $userAttributes) {
        $this->attributes = $attributes;
        $this->userAttributes = $userAttributes;
    }

    public function getAttributes() {
        $result = $this->attributes->where('type', 'player')->get();
        return $result;
    }

    public function addAttribute($request) {
        $post = $request->all();
        $getAttribute = $this->userAttributes->where(['from_id' => $post['from_id'], 'to_id' => $post['to_id'], 'attribute_id' => $post['attribute_id']])->first();
        if (empty($getAttribute)) {
            try {
                $model = new $this->userAttributes;
                $model->from_id = $post['from_id'];
                $model->to_id = $post['to_id'];
                $model->attribute_id = $post['attribute_id'];
                $model->save();
                sendNotifacationByFrontUser($model->from_id, $model->to_id, 'validate_attribute', $model->attribute->title, '');
                return response()->json(['success' => true]);
            } catch (\Exception $e) {
                return response()->json(['success' => false, 'message' => $e->getMessage()]);
            }
        } else {
            return response()->json(['success' => false, 'message' => '']);
        }
    }

}
