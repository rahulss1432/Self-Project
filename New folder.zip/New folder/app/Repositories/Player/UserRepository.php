<?php

namespace App\Repositories\Player;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Models\UserGeneral;
use App\Models\UserExperience;
use App\Models\UserKeyStat;
use App\Models\UserMedia;
use App\Models\UserBenefits;
use App\Models\UserMeasurable;
use App\Models\MasterBenefits;
use Auth;
use File;
use Image;
use Carbon\Carbon;
use App\Models\Connection;
use App\Models\Notification;
use App\Models\ProfileTracker;
use App\Models\News;
use App\Models\Post;
use App\Models\Job;
use App\Models\ApplyJob;
use Illuminate\Support\Facades\Session;

Class UserRepository {

    /**
     * Class Construct.
     *
     * @param  array  $data
     * @return \App\User
     */
    public function __construct(Job $job, Post $post, User $user, UserExperience $userExperience, UserKeyStat $UserKeyStat, UserGeneral $userGeneral, UserMedia $userMedia, UserMeasurable $userMeasurable, UserBenefits $userBenefits, MasterBenefits $masterBenefits, Connection $connections, Notification $notification, ProfileTracker $profileTracker, News $news, ApplyJob $appliedJob) {

        $this->user = $user;
        $this->userGeneral = $userGeneral;
        $this->userExperience = $userExperience;
        $this->userKeyStat = $UserKeyStat;
        $this->userMedia = $userMedia;
        $this->userMeasurable = $userMeasurable;
        $this->userBenefits = $userBenefits;
        $this->masterBenefits = $masterBenefits;
        $this->connections = $connections;
        $this->notification = $notification;
        $this->profileTracker = $profileTracker;
        $this->news = $news;
        $this->post = $post;
        $this->post = $post;
        $this->job = $job;
        $this->appliedJob = $appliedJob;
    }

    /*
     * Function for get all master benefits.
     */

    public function getAllBenefits() {
        return $this->masterBenefits->where('status', 'approved')->get();
    }

    /**
     * Method for save profile step one
     *
     * @param  array  $data
     * @return \App\User
     */
    public function playerStepOne($request) {
        try {
            $post = $request->all();
            $latLong = Session::get('latLong');
            Session::forget('latLong');
            $latLong = explode('&', $latLong);
            $post['latitude'] = !empty($latLong[0]) ? $latLong[0] : '37.0902';
            $post['longitude'] = !empty($latLong[1]) ? $latLong[1] : '-95.7129';
            $userId = Auth::guard('player')->user()->id;
            $user = $this->user->find($userId);
            $user->first_name = $post['first_name'];
            $user->last_name = $post['last_name'];
            $user->full_name = $post['first_name'].' '.$post['last_name'];
            $user->age = $post['age'];
            $user->country_id = $post['country'];
            $user->state_id = $post['state'];
            $user->city = $post['city'];
            $user->zip_code = $post['zip'];
            $user->latitude = $post['latitude'];
            $user->longitude = $post['longitude'];
            $user->position_id = json_encode($post['position']);
            $user->signature = $post['signature'];
            $user->updated_by = $userId;
            if ($request->hasFile('resume')) {
                $image = $request->file('resume');
                $name = uploadFile($image, 'player');
                $user->resume = $name;
            }
            $user->bio = $post['bio'];
            $user->save();
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'Personal information saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for save profile step two
     *
     * @param  array  $data
     * @return \App\User
     */
    public function playerStepTwo($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard('player')->user()->id;
            $user = $this->user->find($userId);
            $user->skype = $post['skype'];
            $user->website = $post['website'];
            $user->facebook = $post['facebook'];
            $user->twitter = $post['twitter'];
            $user->instagram = $post['instagram'];
            $user->linkedin = $post['linkedin'];
            $user->save();
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'Contact information saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for save profile step three
     *
     * @param  array  $data
     * @return \App\User
     */
    public function playerStepThree($request) {
        try {
            $post = $request->all();
            if (!isset($post['under_contract'])) {
                $post['under_contract'] = 'no';
            }
            if (!isset($post['relocate'])) {
                $post['relocate'] = 'no';
            }
            if (!isset($post['look_to_sign'])) {
                $post['look_to_sign'] = 'no';
            }
            if (!isset($post['passport'])) {
                $post['passport'] = 'no';
            }
            $userId = Auth::guard('player')->user()->id;
            $user = $this->userGeneral->firstOrNew(['user_id' => $userId]);
            $user->playing_exp = $post['playing_exp'];
            $user->under_contract = $post['under_contract'];
            $user->current_team = $post['current_team'];
            $user->current_team_link = $post['current_team_link'];
            $user->current_league = $post['current_league'];
            $user->current_league_link = $post['current_league_link'];
            $user->former_team = $post['former_team'];
            $user->former_team_link = $post['former_team_link'];
            $user->former_league = $post['former_league'];
            $user->former_league_link = $post['former_league_link'];
            $user->passport = $post['passport'];
            $user->country_id = $post['country_id'];
            $user->native_lang_id = $post['native_lang_id'];
            $user->secondary_lang_id = $post['secondary_lang_id'];
            $user->look_to_sign = $post['look_to_sign'];
            $user->relocate = $post['relocate'];
            $user->save();
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'About saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for save profile step 3 
     *
     * @param  array  $data
     * @return \App\User
     */
    public function playerExpAddUpdate($request) {
        try {
            $image = '';
            $post = $request->all();
            $userId = Auth::guard('player')->user()->id;
            if (!empty($post['id'])) {
                $user = $this->userExperience->find($post['id']);
                $image = $user['logo'];
            } else {
                $user = $this->userExperience;
                $user->user_id = ($userId) ? $userId : '';
            }
            if ($request->hasFile('image')) {
                $image_file = $request->file('image');
                $image = uploadFile($image_file, 'player');
                $imageThumb = uploadFileThumb($image, 'player/thumb', 'player');
                uploadFileThumb($image, 'player/thumb', 'player');
            }
            $user->user_exp_type = ($post['user_exp_type']) ? $post['user_exp_type'] : '';
            if ($post['user_exp_type'] == 'coaching') {
                $user->country_id = ($post['country_id']) ? $post['country_id'] : '';
                $user->state_id = ($post['state_id']) ? $post['state_id'] : '';
                $user->coaching_link = ($post['coaching_link']) ? $post['coaching_link'] : '';
                $user->coching_league = ($post['coching_league']) ? $post['coching_league'] : '';
                $user->level_id = ($post['level_id']) ? $post['level_id'] : '';
            }
            if ($post['user_exp_type'] != 'accolades') {
                $user->from_year = ($post['from_year']) ? $post['from_year'] : '';
                $user->to_year = ($post['to_year']) ? $post['to_year'] : '';
            }
            if ($post['user_exp_type'] == 'college' || $post['user_exp_type'] == 'pro' || $post['user_exp_type'] == 'international' || $post['user_exp_type'] == 'indoor') {
                $user->experience_type = ($post['experience_type']) ? $post['experience_type'] : '';
            } else {
                $user->name = ($post['name']) ? $post['name'] : '';
                $user->logo = ($image) ? $image : '';
            }
            if ($post['user_exp_type'] == 'accolades') {
                $user->present_organization = ($post['present_organization']) ? $post['present_organization'] : '';
                $user->present_year = ($post['present_year']) ? $post['present_year'] : '';
            }
            if ($post['user_exp_type'] == 'education') {
                $user->level_id = ($post['level_id']) ? $post['level_id'] : '';
                $user->degree_name = ($post['degree_name']) ? $post['degree_name'] : '';
            }
            if ($post['user_exp_type'] == 'coaching' || $post['user_exp_type'] == 'community') {
                $user->position_held = ($post['position_held']) ? $post['position_held'] : '';
            }
            $user->save();
            return response()->json(['success' => true, 'tab' => $request['tab_type'], 'message' => 'Experience saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for save profile step 3 Edit and delete 
     *
     * @param  array  $data
     * @return \App\User
     */
    public function playerExpEditDelete($request) {
        try {
            $post = $request->all();
            $user = $this->userExperience->find($post['id']);
            if ($post['action'] == 'delete') {
                $user->delete();
            }
            if (!empty($user)) {
                return response()->json(['success' => true, 'user' => $user, 'message' => 'Experience removed successfully.']);
            } else {
                return response()->json(['success' => false, 'message' => 'Something went wrong.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for profile step 3 expereiences 
     *
     * * @param  $type
     * @return \App\User
     */
    public function playerStepThreeAbout($type) {
        $userId = Auth::guard('player')->user()->id;
        $query = $this->userExperience->where(['user_exp_type' => $type, 'user_id' => $userId]);
        return $query->orderBy('id', 'DESC')->get();
    }

    /**
     * Create a new season step 4 .
     *
     * @return Response json
     */
    public function saveSeason($post) {
        try {
            $userId = Auth::guard('player')->user()->id;
            if ($post['season_type'] == 'current') {
                $check_season = $this->userKeyStat->where(['user_id' => $userId, 'season_type' => 'current'])->first();
            }
            if (!empty($check_season)) {
                $post['season_id'] = $check_season->id;
            }
            if (isset($post['season_id'])) {
                $season = $this->userKeyStat->find($post['season_id']);
            } else {
                $season = $this->userKeyStat;
            }
            $season->user_id = $userId;
            $season->season_type = $post['season_type'];
            $season->from_year = $post['from_year'];
            $season->to_year = $post['to_year'];
            $season->total_passing = $post['total_passing'];
            $season->passing_game = $post['passing_game'];
            $season->passing_season = $post['passing_season'];
            $season->completion = $post['completion'];
            $season->completion_percent = $post['completion_percent'];
            $season->passer_rating = $post['passer_rating'];
            $season->total_rushing = $post['total_rushing'];
            $season->rushing_game = $post['rushing_game'];
            $season->rushing_season = $post['rushing_season'];
            $season->total_receiving = $post['total_receiving'];
            $season->receiving_game = $post['receiving_game'];
            $season->receiving_season = $post['receiving_season'];
            $season->total_return = $post['total_return'];
            $season->return_game = $post['return_game'];
            $season->return_season = $post['return_season'];
            $season->total_all_purpose = $post['total_all_purpose'];
            $season->purpose_game = $post['purpose_game'];
            $season->purpose_season = $post['purpose_season'];
            $season->tuchdowns = $post['tuchdowns'];
            $season->games_played = $post['games_played'];
            $season->tackles = $post['tackles'];
            $season->tackles_game = $post['tackles_game'];
            $season->tackles_season = $post['tackles_season'];
            $season->total_tackloss = $post['total_tackloss'];
            $season->tackloss_game = $post['tackloss_game'];
            $season->tackloss_season = $post['tackloss_season'];
            $season->total_sacks = $post['total_sacks'];
            $season->sacks_game = $post['sacks_game'];
            $season->sacks_season = $post['sacks_season'];
            $season->total_breaksups = $post['total_breaksups'];
            $season->breaksups_game = $post['breaksups_game'];
            $season->breaksups_season = $post['breaksups_season'];
            $season->total_interception = $post['total_interception'];
            $season->interception_game = $post['interception_game'];
            $season->interception_season = $post['interception_season'];
            $season->blocked_punts = $post['blocked_punts'];
            $season->total_field_goal = $post['total_field_goal'];
            $season->longest_field_goal = $post['longest_field_goal'];
            $season->field_goal_percent = $post['field_goal_percent'];
            $season->longest_punt = $post['longest_punt'];
            $season->avg_punt_distance = $post['avg_punt_distance'];
            $season->save();
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'Key Stat saved successfully']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * get step4 saved past seasons season.
     *
     * @return Response json
     */
    public function getPastSeasons() {
        $userId = Auth::guard('player')->user()->id;
        return $this->userKeyStat->where(['user_id' => $userId, 'season_type' => 'past'])->orderBy('created_at', 'DESC')->get();
    }

    /**
     * delete season by id.
     *
     * @return Response json
     */
    public function deleteSeason($id) {
        try {
            $this->userKeyStat->where('id', $id)->delete();
            return response()->json(['success' => true, 'message' => 'Season Deleted successfully']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for save profile step six
     *
     * @param  array  $data
     * @return \App\User
     */
    public function playerStepSix($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard('player')->user()->id;
            $user = $this->userMeasurable->firstOrNew(['user_id' => $userId]);
            $user->certifier = $post['certifier'];
            $user->email_link = $post['email_link'];
            $user->height_ft = $post['height_ft'];
            $user->height_in = $post['height_in'];
            $user->weight = $post['weight'];
            $user->pro_shuttle = $post['pro_shuttle'];
            $user->collegiate_shuttle = $post['collegiate_shuttle'];
            $user->bench = $post['bench'];
            $user->vert = $post['vert'];
            $user->hand_size = $post['hand_size'];
            $user->broad_jump_from = $post['broad_jump_from'];
            $user->broad_jump_to = $post['broad_jump_to'];
            $user->fourty = $post['fourty'];
            $user->save();
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'Measurable saved succesfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for save profile step seven
     *
     * @param  array  $data
     * @return \App\User
     */
    public function playerStepSeven($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard('player')->user()->id;
            $salaryFrom = $post['salary_from'];
            $salaryTo = $post['salary_to'];
            if (!empty($salaryFrom) && !empty($salaryTo)) {
                if ($salaryTo < $salaryFrom) {
                    return response()->json(['success' => false, 'message' => 'The from salary is not greater than To salary.']);
                }
            }
            /* conditon check for one field fill or one field null */
            if ((empty($salaryFrom) && !empty($salaryTo)) || (!empty($salaryFrom) && empty($salaryTo))) {
                    return response()->json(['success' => false, 'message' => 'The from salary and to salary required.']);
            }
            /* update salary range in user table */
            $this->user->where('id', $userId)->update(['from_salary' => $salaryFrom, 'to_salary' => $salaryTo]);
            if (!empty($post['title'])) {
                foreach ($post['title'] as $key => $value) {
                    $model = new $this->masterBenefits;
                    $model->created_by = $userId;
                    $model->title = $post['title'][$key];
                    $model->image = 'icon-benefit';
                    $model->status = 'pending';
                    if ($model->save()) {
                        $userBenefits = new $this->userBenefits;
                        $userBenefits->user_id = $userId;
                        $userBenefits->benefit_id = $model->id;
                        $userBenefits->save();
                    }
                    $getUserType = $this->user->where('role', 'admin')->first();
                    sendNotifacationByUser($userId, $getUserType->id, 'save_benefits', getUserById($userId, 'reference_id'), getUserById($userId, 'full_name'), $model->title, '');
                }
            }
            $this->userBenefits->where('user_id', $userId)->delete();
            if (!empty($post['benefits'])) {
                foreach ($post['benefits'] as $key => $value) {
                    $model = new $this->userBenefits;
                    $model->user_id = $userId;
                    $model->benefit_id = $post['benefits'][$key];
                    $model->save();
                }
            }
            checkUserConnectAndFollow($userId);
            return response()->json(['success' => true, 'message' => 'Profile saved successfully.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * get user details.
     *
     * @return \App\User
     */
    public function getUseDetails($id) {
        if (empty(Auth::guard(getAuthGuard())->check())) {
            $userId = 0;
        } else {
            $userId = Auth::guard(getAuthGuard())->user()->id;
        }
        if (!empty($id)) {
            $userId = $id;
        }
        return $this->user->where('id', $userId)->first();
    }

    /**
     * get recent joined members.
     *
     * @return \App\User
     */
    public function getRecentJoinedMembers($request) {
        $post = $request->all();
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $query = $this->user->whereDoesntHave('userFromConnection', function ($query) use($userId) {
                    $query->where('to_id', $userId)->where('type', '!=', 'unblock');
                })
                ->whereDoesntHave('userToConnection', function ($query) use($userId) {
                    $query->where('from_id', $userId)->where('type', '!=', 'unblock');
                })->where('role', '!=', 'admin')
                ->where('role', '!=', 'subadmin')
                ->where('status', '!=', 'active');
        if (!empty($request) && !empty($request->id)) {  // when member get other profile member
            $query->where('id', '!=', $request->id)
                    ->where('id', '!=', $userId);
        } else {
            $query->where('id', '!=', $userId);
        }
        $data = $query->whereDate('created_at', '>=', Carbon::now()->subDays(15))
                        ->orderBy('id', 'desc')->take(15)->get();
        return $data;
    }

    /**
     * connect dismiss member.
     */
    public function connectDismissMember($post) {
        try {
            $fromId = Auth::guard(getAuthGuard())->user()->id;
            $toId = $post['id'];
            $getToUserRole = getUserById($toId, 'role');
            /* check user available or not first */
            if ($getToUserRole != 'player') {
                $user_availability = $this->user->where(['id' => $toId, 'current_status' => 'away'])->count();
                if ($user_availability > 0) {
                    return response()->json(['success' => false, 'message' => 'User is not accepting connection requests at the moment. Please try again later.']);
                }
            }
            /* check for if user block and then block after that send request then check in connection and update request */
            $typee = $post['type'] == 'connect' ? 'pending' : 'reject';
            $chat_status = $post['type'] == 'connect' ? 'yes' : 'yes';
            $connection1_check = $this->connections->where(['from_id' => $fromId, 'to_id' => $toId, 'type' => 'unblock'])->first();
            $connection2_check = $this->connections->where(['from_id' => $toId, 'to_id' => $fromId, 'type' => 'unblock'])->first();
            if (!empty($connection1_check)) {
                $c1 = $this->connections->where(['id' => $connection1_check->id])->update(['from_id' => $fromId, 'to_id' => $toId, 'chat_list' => $chat_status, 'type' => $typee]);
                if (!empty($c1)) {
                    return response()->json(['success' => true, 'message' => "Request" . $post['type'] . " successfully"]);
                }
            }
            if (!empty($connection2_check)) {
                $c2 = $this->connections->where(['id' => $connection2_check->id])->update(['from_id' => $fromId, 'to_id' => $toId, 'chat_list' => $chat_status, 'type' => $typee]);
                if (!empty($c2)) {
                    return response()->json(['success' => true, 'message' => "Request" . $post['type'] . " successfully"]);
                }
            }
            /* end check */
            $connection1 = $this->connections->where(['from_id' => $fromId, 'to_id' => $toId])->first();
            $connection2 = $this->connections->where(['from_id' => $toId, 'to_id' => $fromId])->first();
            if (!empty($connection1) || !empty($connection2)) {
                return response()->json(['success' => false, 'message' => "User already exists in your request list."]);
            } else {
                $model = $this->connections;
                $model->from_id = $fromId;
                $model->to_id = $post['id'];
                $model->type = $post['type'] == 'connect' ? 'pending' : 'reject';
                $model->save();
                $currentStatus = getUserById($post['id'], 'current_status');
                if ($post['type'] == 'connect' && $currentStatus == "available") {
                    sendNotifacationByFrontUser($fromId, $post['id'], 'connect', '', '');
                    return response()->json(['success' => true, 'message' => "Request sent successfully"]);
                } else {
                    return response()->json(['success' => true, 'message' => "Request" . $post['type'] . " successfully"]);
                }
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Get user notifications.
     */

    public function getNotification() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return $this->notification->where(['to_id' => $userId, 'is_read' => '0', 'type' => 'faf'])->count();
    }

    /*
     * Get all notifications.
     */

    public function getAllNotifications() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $this->notification->where(['to_id' => $userId, 'type' => 'faf'])->update(['is_read' => '1']);
        return $this->notification->where(['to_id' => $userId, 'type' => 'faf'])->orderBy('id', 'desc')->simplePaginate(10);
    }

    /*
     * Delete notifications.
     */

    public function deleteNotifications($id) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $this->notification->where(['to_id' => $userId, 'id' => $id, 'type' => 'faf'])->delete();
    }

    /*
     * Get Connections List.
     */

    public function userConnectionsList($request = null) {
        $userId = Auth::guard(getAuthGuard())->user()->id;

        if (!empty($request) && !empty($request->id)) {
            $userId = $request->id;
        }
        $connections = $this->connections->where(function($query) use($userId) {
                    $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
                })->where('type', 'accept')->orderBy('id', 'desc')->get();
        if (count($connections) > 0) {
            foreach ($connections as $connection) {
                if ($connection->from_id == $userId) {
                    $otherUser = $connection->to_id;
                } else {
                    $otherUser = $connection->from_id;
                }
                $userData = $this->user->find($otherUser);
                $userImg = checkUserImage($userData->profile_image, $userData->role . '/thumb');
                if ($userData->role == 'player') {
                    $url = url('view/player-profile/' . $userData->slug);
                } else if ($userData->role == 'coach') {
                    $url = url('view/coach-profile/' . $userData->slug);
                } else {
                    $url = url('view/team-profile/' . $userData->slug);
                }
                if ($userData->status == 'active') {
                    if ($userData->id == Auth::guard(getAuthGuard())->user()->id) {
                        echo "<li class='list-inline-item'>
                            <a href='javascript:void(0);' title='You'>
                                <img src='$userImg' alt='user'>
                            </a>
                        </li>";
                    } else {

                        echo "<li class='list-inline-item'>
                            <a href='$url' title='$userData->first_name ( $userData->role )'>
                                <img src='$userImg' alt='user'>
                            </a>
                        </li>";
                    }
                }
            }
        } else {
            echo "<script>$('#connection_view').hide(); $('#divNoConnection').show();</script>";
        }
    }

    /*
     * Get All Connections.
     */

    public function getAllConnections($post) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        if (!empty($post['id'])) {
            $userId = $post['id'];
        }
        $request = $post;
        $request['userId'] = $userId;
        $data = $this->connections->with(['fromUser', 'toUser']);
        $data = $data->where(function($query) use($request) {
            $query->whereHas('toUser', function($q1) use($request) {
                        $q1->where('id', '!=', $request['userId']);
                        $q1->where('status', '=', 'active');
                        if (!empty($request['id'])) {
                            $q1->where('id', '!=', Auth::guard(getAuthGuard())->user()->id);
                        }
                        if (!empty($request['full_name'])) {
                            $q1->where('full_name', 'LIKE', '%' . $request['full_name'] . '%');
                        }
                        if (!empty($request['member_type'])) {
                            $q1->where('role', '=', $request['member_type']);
                        }
                        if (!empty($request['city'])) {
                            $q1->where('city', 'LIKE', '%' . $request['city'] . '%');
                        }
                    })
                    ->orWhereHas('fromUser', function($q2) use($request) {
                        $q2->where('id', '!=', $request['userId']);
                        $q2->where('status', '=', 'active');
                        if (!empty($request['id'])) {
                            $q2->where('id', '!=', Auth::guard(getAuthGuard())->user()->id);
                        }
                        if (!empty($request['full_name'])) {
                            $q2->where('full_name', 'LIKE', '%' . $request['full_name'] . '%');
                        }
                        if (!empty($request['member_type'])) {
                            $q2->where('role', '=', $request['member_type']);
                        }
                        if (!empty($request['city'])) {
                            $q2->where('city', 'LIKE', '%' . $request['city'] . '%');
                        }
                    });
        });
        $data = $data->where(function($query) use($userId) {
                    $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
                })->where('type', 'accept')->orderBy('id', 'desc')->simplePaginate(5);
        $reuslt = $data;
        return $reuslt;
    }

    /*
     * Get all frinds request.
     */

    public function getAllFriendRequests($post) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
//        if (!empty($request['id'])) {
//            $userId = $request['id'];
//        }
        $request = $post;
        $request['userId'] = $userId;

        $data = $this->connections->with(['fromUser', 'toUser']);
        //  if (!empty($request['full_name']) || !empty($request['member_type']) || !empty($request['city'])) {
        $data = $data->where(function($query) use($request) {
            $query->whereHas('toUser', function($q1) use($request) {
                        $q1->where('id', '!=', $request['userId']);
                        $q1->where('status', '=', 'active');

                        if (!empty($request['full_name'])) {
                            $q1->where('full_name', 'LIKE', '%' . $request['full_name'] . '%');
                        }
                        if (!empty($request['member_type'])) {
                            $q1->where('role', '=', $request['member_type']);
                        }
                        if (!empty($request['city'])) {
                            $q1->where('city', 'LIKE', '%' . $request['city'] . '%');
                        }
                    })
                    ->orWhereHas('fromUser', function($q2) use($request) {
                        $q2->where('id', '!=', $request['userId']);
                        $q2->where('status', '=', 'active');

                        if (!empty($request['full_name'])) {
                            $q2->where('full_name', 'LIKE', '%' . $request['full_name'] . '%');
                        }
                        if (!empty($request['member_type'])) {
                            $q2->where('role', '=', $request['member_type']);
                        }
                        if (!empty($request['city'])) {
                            $q2->where('city', 'LIKE', '%' . $request['city'] . '%');
                        }
                    });
        });
        // }
        $data = $data->where(function($query) use($userId) {
                    $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
                })->where('type', 'pending')->orderBy('id', 'desc')->simplePaginate(5);
        $reuslt = $data;
        return $reuslt;
    }

    /*
     * Accept Reject Connections.
     */

    public function acceptRejectConnection($request) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $pendingRequest = $this->connections->where(['to_id' => $userId, 'type' => 'pending'])->first();
        $this->connections->where(function($query) use($userId) {
            $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
        })->where('id', $request->id)->update(['type' => $request->type]);
        $currentStatus = getUserById($pendingRequest->from_id, 'current_status');
        if ($request->type == 'accept' && $currentStatus == "available") {
            sendNotifacationByFrontUser($userId, $pendingRequest->from_id, 'accept', '', '');
        }
    }

    /*
     * Function using for get user profile by id.
     */

    public function getUserProfileById($id) {
        $result = $this->user->where(['id' => $id])->first();
        return $result;
    }

    /*
     * Get user all connection with other users
     */

    public function getConnectionsCount($userId) {
        $connections = $this->connections->where(function($query) use($userId) {
                    $query->orWhere('from_id', $userId)->orWhere('to_id', $userId);
                })->where('type', 'accept')->count();
        return $connections;
    }

    /*
     * Get count of all users who he is following
     */

    public function getFollowCount($userId) {
        $followCount = $this->profileTracker->where('type', 'follow')
                        ->where('from_id', $userId)->count();
        return $followCount;
    }

    /*
     * Get users count by whom he is being followed
     */

    public function getFollowersCount($userId) {
        $followersCount = $this->profileTracker->where('type', 'follow')
                        ->where('to_id', $userId)->count();
        return $followersCount;
    }

    /*
     * Get profile view count
     */

    public function getViewCount($userId) {
        $viewCount = $this->profileTracker->where('type', 'view')
                        ->where('to_id', $userId)->count();
        return $viewCount;
    }

    /*
     * Get user like count
     */

    public function getLikeCount($userId) {
        $likeCount = $this->profileTracker->where('type', 'like')
                        ->where('to_id', $userId)->count();
        return $likeCount;
    }

    /**
     * get joined member based on matched country,state,city and non mutual friends.
     *
     * @return \App\User
     */
    public function getMatchedAndMutualJoinedMembers($request) {
        $post = $request->all();
        $auth = Auth::guard(getAuthGuard())->user();
        $userId = $auth->id;
        $city = $auth->city;
        $country = $auth->country_id;
        $state = $auth->state_id;
        if (!empty($post) && !empty($post['id'])) {
            $otherUserId = $post['id'];
            $city = getUserById($otherUserId, 'city');
            $country = getUserById($otherUserId, 'country_id');
            $state = getUserById($otherUserId, 'state_id');
        }
        // query for get not mutual or connected member with connection table with auth user id      
        $query = $this->user->with('userFromConnection', 'userToConnection')->whereDoesntHave('userFromConnection', function ($query) use($userId) {
                    $query->where('to_id', $userId)->where('type', '!=', 'unblock');
                })
                ->whereDoesntHave('userToConnection', function ($query) use($userId) {
                    $query->where('from_id', $userId)->where('type', '!=', 'unblock');
                })->where('role', '!=', 'admin')
                ->where('role', '!=', 'subadmin')
                ->where('status', '=', 'active');
        if (!empty($post) && !empty($post['id'])) { // when member get other profile member
            $query->where('id', '!=', $post['id'])
                    ->where('id', '!=', Auth::guard(getAuthGuard())->user()->id);
        } else {
            $query->where('id', '!=', $userId);
        }
        if (isset($post['full_name']) && !empty($post['full_name'])) {
            $query->where('full_name', 'like', '%' . $post['full_name'] . '%');
        }
        if (isset($post['member_type']) && !empty($post['member_type'])) {
            $query->where('role', '=', $post['member_type']);
        }
        if (isset($post['city']) && !empty($post['city'])) {
            $query->where('city', 'like', '%' . $post['city'] . '%');
        }
        $data = $query->take(250)->get();

        if ($data->count() > 0) {
            $newArr = [];
            $cityArr = [];
            $stateArr = [];
            $countryArr = [];
            if (!empty($post) && !empty($post['id'])) {         // when member get other profile member
                foreach ($data as $key => $value) {
                    if (!empty($value['userFromConnection'][0])) {        // check user connection by from id with user's id
                        $fromId = $value['userFromConnection'][0]['from_id'];
                        $toId = $value['userFromConnection'][0]['to_id'];
                    } elseif (!empty($value['userToConnection'][0])) {    // check user connection by to id with user's id
                        $fromId = $value['userToConnection'][0]['from_id'];
                        $toId = $value['userToConnection'][0]['to_id'];
                    } else {
                        $fromId = '';
                        $toId = '';
                    }
                    if ($post['id'] == $fromId || $post['id'] == $toId) {
                        $cityArr[] = $value;      // for matched user record for mutual friend of other user and place it in empty array
                    } else {
                        $stateArr[] = $value;
                    }
                }
            } else {
                foreach ($data as $key => $value) {     // when member get profile members by city,state and country
                    $valCity = $value['city'];
                    $valState = $value['state_id'];
                    $valCountry = $value['country_id'];
                    if ($city == $valCity) {
                        $cityArr[] = $value;
                    } elseif ($state == $valState) {
                        $stateArr[] = $value;
                    } elseif ($country == $valCountry) {
                        $countryArr[] = $value;
                    } else {
                        $newArr[] = $value;
                    }
                }
            }
            $data = array_merge($cityArr, $stateArr, $countryArr, $newArr);
        }
        return $data;
    }

    /*
     * Get latest new add by admin
     */

    public function getLatestNews() {
        return $this->news->OrderBy('id', 'desc')->get();
    }

    /*
     * Function for get unread request count.
     */

    public function getRequestUnreadCount() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $count = $this->connections->where(['to_id' => $userId, 'status' => 'unread'])->count();
        if ($count > 0) {
            return $count;
        } else {
            return 0;
        }
    }

    /*
     * Function for change connection status to read.
     */

    public function changeConnectionStatus() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return $this->connections->where(['to_id' => $userId, 'status' => 'unread'])->update(['status' => 'read']);
    }

    /*
     * get key current states.
     */

    public function getKeyStatesCurrent($request) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $keyStatesCurrent = $this->userKeyStat->where('season_type', 'current')
                        ->where('user_id', $userId)->first();
        return $keyStatesCurrent;
    }

    /*
     * get key past states.
     */

    public function getKeyStatesPast($request) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $keyStatesCurrent = $this->userKeyStat->where('season_type', 'past')
                        ->where('user_id', $userId)->orderBy('id', 'desc')->first();
        return $keyStatesCurrent;
    }

    /*
     * get player measurable 
     */

    public function playerMeasurable() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $userMeasurable = $this->userMeasurable->where('user_id', $userId)->first();
        return $userMeasurable;
    }

    /*
     * Function for get all Applied job.
     */

    public function getPostAppliedJob() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        return $this->appliedJob->where(['user_id' => $userId])->orderBy('id', 'desc')->take(4)->get();
    }

    /*
     * Function for get all posted job.
     */

    public function getPostJob() {
        return $this->job->where('status', 'active')->orderBy('id', 'desc')->take(4)->get();
    }

}
