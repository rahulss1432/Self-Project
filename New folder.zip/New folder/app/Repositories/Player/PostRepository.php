<?php

namespace App\Repositories\Player;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Post;
use App\Models\UserPostAction;
use App\Models\UserPostActionReply;
use Auth;
use File;
use App\Models\UserMedia;

Class PostRepository {

    /**
     * Class Construct.
     *
     * @param  array  $data
     * @return \App\User
     */
    public function __construct(Post $post, UserPostAction $userPostAction, UserPostActionReply $userPostActionReply, UserMedia $userMedia) {
        $this->post = $post;
        $this->userPostAction = $userPostAction;
        $this->userPostActionReply = $userPostActionReply;
        $this->userMedia = $userMedia;
    }

    /**
     * Function for list all events.
     */
    public function getPost() {
        try {
            return $this->post->where(['status' => 'active', 'post_type' => 'faf'])->orderBy('id', 'desc')->simplePaginate(3);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Function for list all events.
     */
    public function getTimelinePost($userId) {
        try {
            return $this->post->where(['user_id' => $userId, 'post_type' => 'faf'])->orderBy('id', 'desc')->simplePaginate(3);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Function for get post likes.
     */
    public function getPostLike($request) {
        try {
            $count = $this->userPostAction->where(['post_id' => $request->id, 'type' => 'like'])->get()->count();
            return response()->json(['success' => true, 'data' => $count]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Function for add post likes.
     */
    public function addPostLike($request) {
        try {
            $userId = Auth::guard(getAuthGuard())->user()->id;
//            if (!empty($request->id)) {
//            $userId = $request->id;
//        }
            $count = $this->userPostAction->where(['post_id' => $request->pid, 'from_id' => $userId, 'to_id' => $request->uid, 'type' => 'like'])->get()->count();
            if ($count > 0) {
                $this->userPostAction->where(['post_id' => $request->pid, 'from_id' => $userId, 'to_id' => $request->uid, 'type' => 'like'])->delete();
                $result = 'unlike';
            } else {
                $this->userPostAction->create(['post_id' => $request->pid, 'from_id' => $userId, 'to_id' => $request->uid, 'type' => 'like']);
                $result = 'like';
            }
            $countLike = $this->userPostAction->where(['post_id' => $request->pid, 'type' => 'like'])->count();
            if ($userId != $request->uid && $result == "like") {
                sendNotifacationByFrontUser($userId, $request->uid, 'post_likes', '', $request->pid);
            }
            return response()->json(['success' => true, 'type' => $result, 'count' => $countLike]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Function for get post likes.
     */
    public function getLikeUser($request) {
        return $this->userPostAction->where(['post_id' => $request->pid, 'type' => 'like'])->get();
    }

    /*
     * Function for add post comment.
     */

    public function addPostComment($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard(getAuthGuard())->user()->id;
//            if (!empty($request->id)) {
//            $userId = $request->id;
//            }
            $model = new $this->userPostAction;
            $model->post_id = $post['pid'];
            $model->from_id = $userId;
            $model->to_id = $post['uid'];
            $model->comment = $post['comment'];
            $model->type = 'comment';
            $model->save();
            if ($model->from_id != $model->to_id) {
                sendNotifacationByFrontUser($model->from_id, $model->to_id, 'post_comments', '', $model->post_id);
            }
            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Function for get post comments.
     */
    public function getPostComments($request) {
        if ($request->action == 'first') {  // when page load get first three record desc and reverse
            return $this->userPostAction->where(['post_id' => $request->pid, 'type' => 'comment'])->orderBy('id', 'desc')->take(3)->get()->reverse();
        }
        return $this->userPostAction->where(['post_id' => $request->pid, 'type' => 'comment'])->orderBy('id', 'asc')->get();
    }

    /**
     * Function for get post comments count.
     */
    public function getPostCommentsCount($request) {
        return $this->userPostAction->where(['post_id' => $request->pid, 'type' => 'comment'])->count();
    }

    /*
     * Function for add post comment.
     */

    public function addPostCommentReply($request) {
        try {
            $post = $request->all();
            $userId = Auth::guard('player')->user()->id;
            $model = new $this->userPostActionReply;
            $model->post_action_id = $post['comment_id'];
            $model->from_id = $userId;
            $model->comment = $post['comment'];
            $model->save();
            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Function for get post comments.
     */
    public function getPostCommentsReply($request) {
        return $this->userPostActionReply->where(['post_action_id' => $request->comment_id])->orderBy('id', 'desc')->paginate(1);
    }

    /**
     * Function for get post comments count.
     */
    public function getPostCommentsReplyCount($request) {
        return $this->userPostActionReply->where(['post_action_id' => $request->comment_id])->count();
    }

}
