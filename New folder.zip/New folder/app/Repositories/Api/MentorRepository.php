<?php

namespace App\Repositories\Api;

use App\Models\Availability;
use JWTAuth;
use StaticMessage;

Class MentorRepository {

    public function __construct(Availability $Availability) {
        $this->availability = $Availability;
    }

    /**
     * add availability
     * @param type $request(OBJ)
     * @return type Json
     */
    public function addAvailability($request) {


        try {
            $model = new $this->availability();
            $model->from_date = $request->from_date;
            $model->to_date = $request->to_date;
            $model->from_time = $request->from_time;
            $model->to_time = $request->to_time;
            $model->state = $request->state;
            $model->city = $request->city;
            $model->save();
            return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['availibilty_add']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * edit availability
     * @param type $request(OBJ)
     * @return type Json
     */
    public function editAvailability($request) {


        try {
            $model = $this->availability->where(['id' => $request->id])->first();
            $model['from_date'] = $request->from_date;
            $model['to_date'] = $request->to_date;
            $model['from_time'] = $request->from_time;
            $model['to_time'] = $request->to_time;
            $model['state'] = $request->state;
            $model['city'] = $request->city;
            $model->save();
            return response()->json(['success' => true, 'data' => [], 'message' => \StaticMessage::$app['availibilty_add']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * get availability
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getAvailability($request) {


        try {
            $model = $this->availability->where(['id' => $request->id])->first();
           
            return response()->json(['success' => true, 'data' => $model, 'message' => '']);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

    /**
     * delete availability
     * @param type $request(OBJ)
     * @return type Json
     */
    public function deleteAvailability($request) {


        try {
            $model = $this->availability->where(['id' => $request->id])->delete();
            if ($model) {
                return response()->json(['success' => true, 'data' => [], 'message' => 'Deleted successfully.']);
            }
            return response()->json(['success' => false, 'data' => [], 'message' => 'Availabilty not found']);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

}
