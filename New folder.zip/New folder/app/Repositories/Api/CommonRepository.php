<?php

namespace App\Repositories\Api;

use App\Models\Country;
use App\Models\State;
use JWTAuth;
use StaticMessage;

Class CommonRepository {

    public function __construct(Country $country,State $state) {
        $this->country = $country;
        $this->state = $state;
    }

    /**
     * get country list
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getCountry($request) {

        try {
          return  $this->country->get();
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }
    /**
     * get state list.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getState($request) {

        try {
          return  $this->state->where(['country_id'=>$request->country_id])->get();
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

   

}
