import { Component, Input, ElementRef, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from "@angular/router";
import { NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";
import { Staff } from "../model/staff.model";
import { ApiCountryStateService } from './../../../shared/service/api-country-state.service';
import { Countries } from '../../../shared/model/countries';
import { States } from '../../../shared/model/states';
import * as $ from "jquery";
import { ToastrService } from 'ngx-toastr';
import { CommonService } from "../../../shared/service/common.service";
import { StaffService } from "../service/staff.service";



@Component({
  selector: "hb-staffadd",
  templateUrl: "./staffadd.component.html"
})

export class StaffaddComponent implements OnInit {
  @ViewChild("fileInput") inputEl: ElementRef;
  @ViewChild('join_date1') joinDate;
  loading = false;
  today = new Date();
  private fileList: any = [];
  photo: any;
  countryData: any = [];
  stateData: any = [];
  futureDate: NgbDateStruct = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };
  newjoin_date: {};

  staff = new Staff();
  submitted = false;
  disabled = false;
  errorData = "";
  id: any;
  dateObj: any;
  dateStr: string;
  centerStates: any = [];

  fileCount: number;
  fileName: string;
  showSizeError: boolean = false;
  showTypeError: boolean = false;
  globalVariable: number;
  buttonTitle: string;

  constructor(private activatedRoute: ActivatedRoute, private formBuilder: FormBuilder, private route: ActivatedRoute, private commonService: CommonService,
    private router: Router, private _fetchCountry: ApiCountryStateService, private staffService: StaffService, private toastr: ToastrService,private el: ElementRef,
  ) {
    this.init();
    this.id = this.activatedRoute.snapshot.params["id"];
    if (this.id) {
      this.getStaffDetail(this.id);
      this.buttonTitle = 'Update';
    }else{
      this.buttonTitle = 'Save';
    }
  }

  init() {
    this.staff = new Staff();
    this.getCounties();
  }



  ngOnInit() {
    this.init();
  }

  getCounties(): void {
    this._fetchCountry.getCounties()
      .subscribe(
        countryData => {
          this.countryData = countryData['data'].rows;
        });
  }


  getStates(id: any): void {
    this._fetchCountry.getStates()
      .subscribe(
        stateData => {
          this.stateData = stateData['data'].rows.filter(element => {
            return element.country_id == id;
          });
        });
  }

  closeDatepicker(e) {
    if (!this.joinDate.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
      || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
      || !(e.target.parentElement && e.target.parentElement.parentElement &&
        !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
      return;
    }
    if (this.joinDate.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
      this.joinDate.close();
    }
  }

  clearError(imagetag) {
      this.showSizeError = false;
      this.showTypeError = false;

  }

  upload(e, imageFor) {

    const inputEl: HTMLInputElement = this.inputEl.nativeElement;
    this.fileCount = inputEl.files.length;
    if (this.fileCount > 0) { // a file was selected
    this.fileName = inputEl.files[0].name;
    
    //check file is valid
    if (!this.validateFile(inputEl.files[0].name)) {
      this.inputEl.nativeElement.value = "";
      this.showTypeError = true;
      return false;
    }
    this.showTypeError = false;
    //check file size is valid 10 MB
    if (inputEl.files[0].size > 10000000) {
        this.inputEl.nativeElement.value = "";
        document.getElementById('staffImg').setAttribute('src','assets/images/default-user.jpg');
        this.fileList='';
      this.showSizeError = true;
       return false;
    }
    this.showSizeError = false;

    
      for (let i = 0; i < this.fileCount; i++) {
        this.fileList = inputEl.files.item(i);
        const reader = new FileReader();
        reader.readAsDataURL(inputEl.files.item(i));
        reader.onload = this.setFileUrl;
      }
    }

  }

  validateFile(name: String) {
    var ext = name.substring(name.lastIndexOf('.') + 1);
    if (ext.toLowerCase() == 'png' || ext.toLowerCase() == 'jpeg' || ext.toLowerCase() == 'jpg') {
      return true;
    }
    else {
      return false;
    }
  }

  setFileUrl(file: any) {
    this.photo = file.target.result;
    document.getElementById("staffImg").setAttribute("src", file.target.result);
  }

numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

  addStaff(frm: NgForm) {
    if (frm.valid) {
      this.clearError('photo');
      this.disabled = true;
      this.errorData = "";
      this.loading = true;
      if (frm.value.join_date) {
        frm.value.join_date = frm.value.join_date.year + "-" + frm.value.join_date.month + "-" + frm.value.join_date.day;
      }
      this.staffService.AddStaffandUpdate(frm.value, this.fileList, this.id)
        .subscribe(result => {

          if (result.success === true) {
            this.toastr.success(result.message);
            if(this.id){
              this.router.navigate(["/teacher/detail/" + this.id]);
            }else{
              this.router.navigate(["/teacher/list"]);
            }
          } else {
            this.errorData = this.commonService.GetHandleMultilineErrorString(result.error);
            this.toastr.error(this.errorData);
          }
          this.loading = false;
          this.disabled = false;
        },
        err => {
          if (err.error.error.length) {
            err.error.error.map((e, i) => {
              this.toastr.error(err.error.error[i].message);
            });
            this.loading = false;
            this.disabled = false;
          }
          else
          {
            this.toastr.error('Something went wrong');
          }
        });
    }else {
      let target;
      target = this.el.nativeElement.querySelector('.errormessage');
      if (target) {
        $('html,body').animate({ scrollTop: $(target).offset().top - 150 }, 'slow', () => {
          target.focus();
        });
      }
    }
  }
  getFormattedDate(dt: any) {
    this.dateObj = new Date(dt);
    const year = this.dateObj.getFullYear();
    let month = this.dateObj.getMonth() + 1;
    if (month < 10) {
      month = "0" + month;
    }
    let date = this.dateObj.getDate();
    if (date < 10) {
      date = "0" + date;
    }
    this.dateStr = year + "-" + month + "-" + date;
    return this.dateStr;
  }
  getFormattedDateNew(dt: any) {
    this.dateObj = new Date(dt);
    const year = this.dateObj.getFullYear();
    let month = this.dateObj.getMonth() + 1;
    if (month < 10) {
      month = month;
    }
    let date = this.dateObj.getDate();
    if (date < 10) {
      date = date;
    }
    return { year: year, month: month, day: date };

  }

  getStaffDetail(id: number) {
    this.loading = true;
    this.staffService.getStaffDetail(id)
      .subscribe(
        (staff: any) => {
          console.log(staff.data);
          this.staff = staff.data.user;
          this.staff.first_name = staff.data.user.first_name;
          this.staff.last_name = staff.data.user.last_name;
          this.staff.join_date = this.getFormattedDate(staff.data.join_date);
          this.newjoin_date = this.getFormattedDateNew(staff.data.join_date);
          this.staff.email = staff.data.user.email;
          this.staff.phone_number = staff.data.user.phone_number;
          this.staff.mobile_number = staff.data.user.mobile_number;
          this.staff.address_line1 = staff.data.user.address_line1;
          this.staff.address_line2 = staff.data.user.address_line2;
          this.staff.city = staff.data.user.city;
          this.staff.zip_code = staff.data.user.zip_code;
          this.staff.photo = staff.data.user.photo;
          document.getElementById("staffImg").setAttribute("src", staff.data.user.photo);
          this.staff.country = staff.data.user.country;
          this.stateData = this.getStates(staff.data.user.country);
          //alert(staff.data.user.state);
          this.staff.state = staff.data.user.state;
          //this.staff.state = staff.data.user.state;
          this.staff.gender = staff.data.user.gender;
          this.staff.designation = staff.data.designation;
          this.loading = false;
        });
  }

  resetStaff() {
    this.staff = new Staff();
    this.init()
  }
}


