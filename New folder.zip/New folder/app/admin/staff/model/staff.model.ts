export class Staff {
  id: number;
  center_id: number;
  designation: string = '';
  join_date: string;
  leave_date: string;
  status: string;
  user_id: number;
  address_line1: string;
  address_line2: string;
  city: string;
  country: string = '';
  email: string;
  first_name: string;
  gender: string = '';
  last_name: string;
  mobile_number: string;
  phone_number: string;
  photo: string = '';
  state: string = '';
  user_type: string;
  zip_code: string;
  assign_child: any = '';
  created_at: Date;
  updated_at: Date;
  dob: Date;
}
