import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hb-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
