import { Routes, RouterModule } from '@angular/router';
import { StaffComponent } from './staff.component';
import { StafflistComponent } from './stafflist/stafflist.component';
import { StaffaddComponent } from './staffadd/staffadd.component';
import { StaffdetailComponent } from './staffdetail/staffdetail.component';

const STAFF_ROUTE: Routes = [
{
    path: '', component: StaffComponent, children: [
      { path: '', component: StafflistComponent },
      { path: 'list', component: StafflistComponent },
      { path: 'add', component: StaffaddComponent },
      { path: 'edit/:id', component: StaffaddComponent },
      { path: 'detail/:id', component: StaffdetailComponent }
  ]
  }
  ,
]

export const staffRouting = RouterModule.forChild(STAFF_ROUTE);
