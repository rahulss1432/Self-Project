import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { StaffService } from '../service/staff.service';
import { ApiCountryStateService } from '../../../shared/service/api-country-state.service';
import { Countries } from '../../../shared/model/countries';
import { States } from '../../../shared/model/states';

@Component({
  selector: 'hb-staffdetail',
  templateUrl: './staffdetail.component.html'
})
export class StaffdetailComponent implements OnInit {
  id: number;
  loading: boolean;
  staff: any = {};
  user: any = {};
  assigned_childs = [];
  dateObj: any;
  dateStr: string;
  countryData: Countries[];
  stateData: States[];
  selectedCountry: any;
  userCountry: any;
  userState: any;
  selectedState: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private staffService: StaffService,
    private _fetchCountry: ApiCountryStateService
  ) {
    this.id = this.activatedRoute.snapshot.params['id'];
  }

  ngOnInit() {
    this.getStaffDetail(this.id);
  }
  getFormattedDate(dt: any) {
    this.dateObj = new Date(dt);
    const year = this.dateObj.getFullYear();
    let month = this.dateObj.getMonth() + 1;
    if (month < 10) {
      month = '0' + month;
    }
    let date = this.dateObj.getDate();
    if (date < 10) {
      date = '0' + date;
    }
    this.dateStr = year + '-' + month + '-' + date;
    return this.dateStr;
  }

  getStaffDetail(id: number) {
    this.loading = true;
    this.staffService.getStaffDetail(id)
      .subscribe(
      (staff: any) => {
        this.staff = staff.data;
        this._fetchCountry.getCounties()
        .subscribe(
        countryData => {
          this.countryData = countryData['data'].rows;
          this.userCountry = this.countryData.filter(element => {
            return element.id == staff.data.country;
          });
          this.selectedCountry = this.userCountry[0].name;
        });
        this._fetchCountry.getStates()
        .subscribe(
        stateData => {
          this.stateData = stateData['data'].rows;
          this.userState = this.stateData.filter(element => {
            return element.id ==  staff.data.state;
          });
          
          this.selectedState= this.userState[0].state_name;
        });
        this.staff.first_name = staff.data.user.first_name;
        this.staff.last_name = staff.data.user.last_name;
        this.staff.join_date = this.getFormattedDate(staff.data.join_date);
        this.staff.email = staff.data.user.email;
        this.staff.phone_number = staff.data.user.phone_number;
        this.staff.mobile_number = staff.data.user.mobile_number;
        this.staff.address_line1 = staff.data.user.address_line1;
        this.staff.address_line2 = staff.data.user.address_line2;
        this.staff.city = staff.data.user.city;
        this.staff.zip_code = staff.data.user.zip_code;
        this.staff.photo = staff.data.user.photo;
        this.staff.country = staff.data.user.country;
        this.staff.state = staff.data.user.state;
        this.staff.gender = staff.data.user.gender;
        this.staff.designation = staff.data.designation;
        this.assigned_childs = staff.data.assigned_childs;
        this.loading = false;
      },
      (err) => {
        this.loading = false;
      });
  }
}
