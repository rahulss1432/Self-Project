﻿import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { StaffComponent } from './staff.component';
import { StafflistComponent } from './stafflist/stafflist.component';
import { StaffaddComponent } from './staffadd/staffadd.component';
import { StaffdetailComponent } from './staffdetail/staffdetail.component';
import { staffRouting } from './staff.routes';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { StaffService } from './service/staff.service';
import { NgxPaginationModule } from 'ngx-pagination';
import { SharedModule } from '../../shared/module/shared.module';
import { ChildService } from '../child/service/child.service';
// import { NumberOnlyDirective } from '../../shared/directive/number-only.directive';

@NgModule({
  declarations: [
    StaffComponent,
    StafflistComponent,
    StaffdetailComponent,
    StaffaddComponent,
    // NumberOnlyDirective
  ],
  imports: [CommonModule, FormsModule,NgbModule.forRoot(), ReactiveFormsModule, RouterModule,SharedModule, staffRouting, NgxPaginationModule],
  providers: [StaffService,ChildService]
})

export class StaffModule { }
