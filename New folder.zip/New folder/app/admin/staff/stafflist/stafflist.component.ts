﻿import { Component, OnInit, OnDestroy } from "@angular/core";
import { Staff } from "../model/staff.model";
import {
  FormGroup,
  NgForm,
  FormsModule,
  ReactiveFormsModule
} from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription } from "rxjs";
import { StaffService } from "../service/staff.service";
import { ToastrService } from "ngx-toastr";
import { ChildService } from "../../child/service/child.service";
import { CommonService } from "../../../shared/service/common.service";

declare var $: any;
@Component({
  selector: "hb-stafflist",
  templateUrl: "./stafflist.component.html",
  styles: [
    `
      .imgList img {
        height: 50px;
      }
    `
  ]
})
export class StafflistComponent implements OnInit, OnDestroy {
  private staffSubscription: Subscription;
  private childSubscription: Subscription;
  query = "";
  staffList: any[] = [];
  p = 1;
  total: number;
  loading: boolean;
  id: number;
  childList = [];
  staff = new Staff();
  errorData = "";
  staff_id: number;
  disabled = false;

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private staffService: StaffService,
    private toastr: ToastrService,
    private commonService: CommonService,
    private childService: ChildService
  ) { }

  ngOnInit() {
    this.getStaffList(1);
    this.getChildList(1);
  }

  ngOnDestroy() {
    this.childSubscription.unsubscribe();
    this.staffSubscription.unsubscribe();
  }

  updateStatus(staff) {
    this.staffService.updateStatus(staff.id, staff.status === "active" ? "inactive" : "active")
      .subscribe(
      result => {
        if (result.success === true) {
          staff.status = result.data.status;
          this.toastr.success(result.message);
        }
        this.loading = false;
      },
      err => {
        this.toastr.success(err.error.message);
        this.loading = false;
      }
      );
  }

  getStaffList(page: number) {
    this.loading = true;
    this.staffSubscription = this.staffService
      .getStaffList(page, this.query)
      .subscribe(
      (data: any) => {
        this.staffList = data.data.rows;
        this.total = data.data.total;
        this.p = page;
        this.loading = false;
      },
      err => {
        this.toastr.error(err.error.message);
        this.loading = false;
      }
      );
  }

  showPopUp(staff_id: number) {
    this.staff_id = staff_id;
    this.getChildList(1);
  }

  resetClose(frm: NgForm) {
    $('#assignChild').on('hide.bs.modal', function (e) {
      frm.resetForm();
      frm.form.controls['assign_child'].setValue('');
    });
    $("#assignChild").modal('hide');
  }

  getChildList(page: number) {
    this.childList = [];
    this.childSubscription = this.childService
      .getChildList(page, this.query, "active")
      .subscribe(
      (result: any) => {
        this.childList = result.data.rows;
        this.loading = false;
      },
      err => {
        this.loading = false;
        this.toastr.error(err.error.message);
      }
      );
  }

  assignChild(frm: NgForm) {
    if (frm.valid) {
      this.loading = true;
      this.disabled = true;
      this.staffService
        .assignChild(frm.value.assign_child, this.staff_id)
        .subscribe(
        (result: any) => {
          if (result.success) {
            this.toastr.success(result.message);
            this.router.navigate(["/teacher/list"]);
          } else {
            this.toastr.error(result.error.errormessage);
          }
          this.loading = false;
          this.disabled = false;
          $('#assignChild').on('hide.bs.modal', function (e) {
            frm.resetForm();
            frm.form.controls['assign_child'].setValue('');
          });
          $("#assignChild").modal('hide');
        },
        err => {
          if (err.error.error.length) {
            err.error.error.map((e, i) => {
              this.toastr.error(err.error.error[i].message);
            });
            this.loading = false;
            this.disabled = false;
            $('#assignChild').on('hide.bs.modal', function (e) {
              frm.resetForm();
              frm.form.controls['assign_child'].setValue('');
            });
            $("#assignChild").modal('hide');
          }
          else
          {
            this.toastr.error('Something went wrong');
          }
        });
    }
  }

}
