import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { NgbDateStruct, NgbDatepickerConfig } from "@ng-bootstrap/ng-bootstrap";
import { Appointment, Updateappointment } from "../model/appointment.model";
import { NgForm } from '@angular/forms';
import { CalendarComponent } from 'ng-fullcalendar';
import { Options } from 'fullcalendar';
import { AppointmentService } from '../service/appointment.service';
import { ToastrService } from 'ngx-toastr';
import { AuthenticationService } from '../../../auth/_services';
import { CommonService } from '../../../shared/service/common.service';
import { DatePipe } from '@angular/common';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import * as $ from "jquery";
import { ActivatedRoute, Router } from "@angular/router";
@Component({
  selector: 'hb-appointment-list',
  templateUrl: './appointment-list.component.html',
})
export class AppointmentListComponent implements OnInit {
  today = new Date();
  futureDate: NgbDateStruct = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };
  submitted = false;
  disabled = false;
  loading = false;
  errorData = "";
  newappointment_date: {};
  newappointment_time: {};
  editappointment_date: {};
  editappointment_time: {};
  dateObj: any;
  id: any;
  appointment = new Appointment();
  updateappointment = new Updateappointment();
  dateStr: string;
  events: any = {};
  center_id: number;
  calendarOptions: Options;
  dateTime: any;
  appointmentInfo: any;
  eventData: any;
  appointment_id: number;
  date_time: any;
  edit_date: any;
  edit_time: any;
  frmData: any = [];
  @ViewChild(CalendarComponent) ucCalendar: CalendarComponent;
  @ViewChild('newappointment_date') addAppointmentDate;
  @ViewChild('editappointment_date1') editAppointmentDate;

  constructor(private config: NgbDatepickerConfig, private appointmentService: AppointmentService, private commonService: CommonService, private authenticationService: AuthenticationService, private router: Router, private toastr: ToastrService, private datePipe: DatePipe) {
    this.center_id = this.authenticationService.getUserDetail().center_id;

    const currentDate = new Date();

    config.minDate = { year: currentDate.getFullYear(), month: currentDate.getMonth() + 1, day: currentDate.getDate() };
    config.maxDate = { year: 2099, month: 12, day: 31 };

    //config.outsideDays = 'hidden';
  }

  ngOnInit() {
    this.getAppointment();
  }
  closeDatepickerAddEdit(e, text) {
    if (text == 'add') {
      if (!this.addAppointmentDate.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.addAppointmentDate.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.addAppointmentDate.close();
      }
    }
    else {
      if (!this.editAppointmentDate.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.editAppointmentDate.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.editAppointmentDate.close();
      }
    }
  }
  addAppointment(frm: NgForm) {
    if (frm.valid) {
      this.disabled = true;
      this.errorData = "";
      this.loading = true;

      if (frm.value.appointment_date) {
        frm.value.appointment_date = frm.value.appointment_date.year + "-" + frm.value.appointment_date.month + "-" + frm.value.appointment_date.day;
      }
      if (frm.value.appointment_time) {
        frm.value.appointment_time = this.datePipe.transform(frm.value.appointment_time, 'shortTime');
      }
      this.appointmentService.AddAppointmentandUpdate(frm.value, this.center_id, this.id)
        .subscribe(result => {
          if (result.success === true) {
            this.toastr.success(result.message);
            setTimeout( function(){ location.reload(); }, 1000 );
          } else {
            //this.errorData = this.commonService.GetHandleMultilineErrorString(result.error);
            this.toastr.error(result.message);
          }
          this.loading = false;
          this.disabled = false;
          //setTimeout( function(){ location.reload(); }, 1000 );
        },
          (err) => {
            this.errorData = this.commonService.GetHandleMultilineErrorString(err.error);
            this.toastr.error(this.errorData);
            this.loading = false;
            this.disabled = false;
            setTimeout( function(){ location.reload(); }, 1000 );
          });
    }
  }

  getAppointment() {
    this.appointmentService.getAppointmentDetail().subscribe(
      (appointment: any) => {
        this.events = appointment.data['rows'];
        var appointmentData = [];
        for (let i = 0; i < this.events.length; i++) {
          var oldDate = this.datePipe.transform(this.events[i].appointment_date, 'dd');
          // var newDate = parseInt(oldDate) + 1;
          var newMonth = this.datePipe.transform(this.events[i].appointment_date, 'MM');
          var newYear = this.datePipe.transform(this.events[i].appointment_date, 'yyyy');
          appointmentData.push(
            {
              id: this.events[i].id,
              title: this.events[i].doctor_name,
              start: newYear + "-" + newMonth + "-" + oldDate + " " + this.events[i].appointment_time,
              category: this.events[i].doctor_category
            },

          );
        }

        this.calendarOptions = {
          editable: false,
          header: {
            left: '',
            center: 'prev title next',
            right: '',

          },
          events: appointmentData,
          timeFormat: 'hh:mm a',
          eventLimit: true
        };
      }
    );
  }

  eventRender(eventData) {
    eventData.element.find('.fc-title').append("<br/><span class='category'>"+eventData.event.category+"</span>");
    this.date_time = eventData.event.start._i.split(" ");
    this.edit_date = this.date_time[0];
    this.edit_time = this.datePipe.transform(this.date_time[0] + "," + this.date_time[1], 'shortTime');
    eventData.element.find('.fc-content').append(`<div class="action_btn"> <a title="Edit" onclick="$('#singleEditId').val(` + eventData.event.id + `),$('#singleEditCategory').val('` + eventData.event.category + `'),$('#singleEditDate').val('` + this.edit_date + `'),$('#singleEditTime').val('` + this.edit_time + `'),$('#singleEditTitle').val('` + eventData.event.title + `')" data-toggle="modal" data-target="#updateAppointment" class="btn btn_edit"><img src="assets/images/edit_icon_sm.png" /></a> <a onclick="$('#singleId').val(` + eventData.event.id + `)" class="btn btn_delete" title="Delete" data-target="#endDeleteModal" data-toggle="modal" class="eventDelete"><img src="assets/images/delete_icon_sm.png" /></a></div>`);
  }

  deleteAppointment(testfrm: any) {
    this.loading = true;
    this.appointmentService.deleteAppointment(testfrm)
      .subscribe(
        (data: any) => {
          this.toastr.success('Deleted Appointment successfully');
          this.loading = false;
          location.reload();
        },
        (err) => {
          this.loading = false;
        });
  }

  updateAppointment(updatefrm: NgForm) {
    this.id = $('#singleEditId').val();
    this.frmData.doctor_name = $('#singleEditTitle').val();
    this.frmData.doctor_category = $('#singleEditCategory').val();
    this.frmData.appointment_date = $('#singleEditDate').val();
    this.frmData.appointment_time = $('#singleEditTime').val();
    if (this.frmData) {
      this.disabled = true;
      this.errorData = "";
      this.loading = true;
      this.appointmentService.AddAppointmentandUpdate(this.frmData, this.center_id, this.id)
        .subscribe(result => {
          if (result.success === true) {
            this.toastr.success(result.message);
            location.reload();
          } else {
            this.errorData = this.commonService.GetHandleMultilineErrorString(result.error);
            this.toastr.error(this.errorData);
          }
          this.loading = false;
          this.disabled = false;
        },
          (err) => {
            this.errorData = this.commonService.GetHandleMultilineErrorString(err.error);
            this.toastr.error(this.errorData);
            this.loading = false;
            this.disabled = false;
          });
    }
  }


}
