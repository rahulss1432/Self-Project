import { AppointmentListComponent } from './appointment-list/appointment-list.component';
import { AppointmentComponent } from './appointment.component';
import { Routes, RouterModule } from '@angular/router';

const APPOINTMENT_ROUTE: Routes = [
{
    path: '', component: AppointmentComponent , children: [
      { path: '', component: AppointmentListComponent  },
      { path: 'list', component: AppointmentListComponent },
    ]
  }
  ,
]

export const appointmentRouting = RouterModule.forChild(APPOINTMENT_ROUTE);
