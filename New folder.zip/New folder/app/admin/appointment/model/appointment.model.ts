export class Appointment {
  appointment_date: string;
  appointment_time: string;
  doctor_name: string;
  doctor_category: string;
  created_at: Date;
  updated_at: Date;
  singleId: string;
}

export class Updateappointment {
  id: string;
  appointment_date: string;
  appointment_time: string;
  doctor_name: string;
  doctor_category: string;
}
