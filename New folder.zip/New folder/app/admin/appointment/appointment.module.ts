﻿import { AppointmentService } from './service/appointment.service';
import { appointmentRouting } from './appointment.routes';
import { AppointmentListComponent } from './appointment-list/appointment-list.component';
import { AppointmentComponent } from './appointment.component';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';
import { TabsModule } from 'ngx-bootstrap';
import { SharedModule } from '../../shared/module/shared.module';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { FullCalendarModule } from 'ng-fullcalendar';
import { DatePipe } from '@angular/common';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';

@NgModule({
  declarations: [
    AppointmentComponent,
    AppointmentListComponent
  ],
  imports: [CommonModule, FormsModule, RouterModule, appointmentRouting , NgxPaginationModule, TabsModule, SharedModule,NgbModule.forRoot(),FullCalendarModule, OwlDateTimeModule, OwlNativeDateTimeModule],
  providers: [AppointmentService]
})

export class AppointmentModule { }
