﻿import { environment } from '../../../../environments/environment';
import { Injectable } from '@angular/core';
import { Http, Response, Headers, } from '@angular/http';
import { Appointment } from './../model/appointment.model';
import "rxjs/Rx";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonService } from '../../../shared/service/common.service';
import { AuthenticationService } from '../../../auth/_services';
import { RequestOptions } from "../../../shared/service/common.service";
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable()
export class AppointmentService {
   baseUrl = environment.baseUrl;
  constructor(
    private http: HttpClient,
    private authenticationService: AuthenticationService,
    private commonService: CommonService,
   
  ) { }
  AddAppointmentandUpdate(appointment: Appointment, center_id: number, Id: number) {
    const urlSearchParams = this.commonService.getURLSearchParamsObject(appointment);
    const body = urlSearchParams.toString();
    const headers = this.commonService.getFormDataHeader();
    const options = new RequestOptions({ headers: headers });
    let formData = {
      "center_id": this.authenticationService.getUserDetail().center_id,
      "doctor_name": appointment.doctor_name,
      "doctor_category": appointment.doctor_category,
      "appointment_date": appointment.appointment_date,
      "appointment_time": appointment.appointment_time
    }
    if (Id) {
      return this.http
        .put(this.baseUrl + "center/" + center_id + "/appointment/" + Id, formData, options)
        .pipe(map((response: any) => {
          const data = response && response.data;
          return response;
        }));
    } else {

      return this.http
        .post(this.baseUrl + "center/" + center_id + "/appointment", formData, options)
        .pipe(map((response: any) => {
          const data = response && response.data;
          return response;
        }));
    }
  }

  getAppointmentDetail() {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });
    const center_id = this.authenticationService.getUserDetail().center_id;
    return this.http
      .get(this.baseUrl + "center/" + center_id + "/appointment", options)
      .map((response: any) => response)
      .catch(this.commonService.GetHandleErrorString);
  }

  deleteAppointment(id: number) {
    const headers = this.commonService.getHeadersObject(null, true, true);
    const options = new RequestOptions({ headers: headers });
    const center_id = this.authenticationService.getUserDetail().center_id;
    return this.http
      .delete(this.baseUrl + "center/" + center_id + "/appointment/" + id, options)
      .map((response: any) => {
        return response;
      })
      .catch(this.commonService.GetHandleErrorString);
  }
}
