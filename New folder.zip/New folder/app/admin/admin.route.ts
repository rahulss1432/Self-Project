﻿import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin.component';
import { AuthGuard } from '../auth/_guards';
import { AdminModule } from './admin.module';

const ADMIN_ROUTE: Routes = [
  {
    path: '', component: AdminComponent, children: [
      { path: 'center', loadChildren: 'app/admin/center/center.module#CenterModule', canActivate: [AuthGuard] },
      { path: 'program', loadChildren: 'app/admin/program/program.module#ProgramModule', canActivate: [AuthGuard] },
      { path: 'child', loadChildren: 'app/admin/child/child.module#ChildModule' },
      { path: 'teacher', loadChildren: 'app/admin/staff/staff.module#StaffModule' },
      { path: 'attendance', loadChildren: 'app/admin/attendance/attendance.module#AttendanceModule' },
      { path: 'my-account', loadChildren: 'app/admin/myaccount/myaccount.module#MyaccountModule' },
      { path: 'change-password', loadChildren: 'app/admin/password/password.module#PasswordModule' },
      // { path: 'video', loadChildren: 'app/admin/video/video.module#VideoModule' },
      { path: '', loadChildren: 'app/admin/dashboard/dashboard.module#DashboardModule' },
      { path: 'dashboard', loadChildren: 'app/admin/dashboard/dashboard.module#DashboardModule' },
      { path: 'messages', loadChildren: 'app/admin/messages/messages.module#MessagesModule' },
      { path: 'daily-schedule', loadChildren: 'app/admin/daily-schedule/daily-schedule.module#DailyScheduleModule' },
      { path: 'event', loadChildren: 'app/admin/event/event.module#EventModule' },
      { path: 'feedback', loadChildren: 'app/admin/feedback/feedback.module#FeedbackModule' },
      { path: 'appointment', loadChildren: 'app/admin/appointment/appointment.module#AppointmentModule' },
      { path: 'registration', loadChildren: 'app/admin/registration/registration.module#RegistrationModule' },
      // { path: 'enquiry', loadChildren: 'app/admin/enquiry/enquiry.module#EnquiryModule' },

    ]
  }
];

export const adminRouting = RouterModule.forChild(ADMIN_ROUTE);
