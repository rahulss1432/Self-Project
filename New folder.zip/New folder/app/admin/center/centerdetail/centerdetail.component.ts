﻿import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CenterService } from '../service/center.service';
import { Center } from '../model/center';
import { ApiCountryStateService } from '../../../shared/service/api-country-state.service';
import { Countries } from '../../../shared/model/countries';
import { States } from '../../../shared/model/states';

@Component({
  selector: 'hb-centerdetail',
  templateUrl: './centerdetail.component.html'
})
export class CenterdetailComponent implements OnInit {
  id: number;
  loading: boolean;
  center: any = {};
  userdetail: any = {};
  countryData: Countries[];
  stateData: States[];
  constructor(private activatedRoute: ActivatedRoute, private centerService: CenterService, private _fetchCountry: ApiCountryStateService) {
    this.id = this.activatedRoute.snapshot.params['id'];
  }

  ngOnInit() {
    this.getCenterDetail(this.id);
  }
  userCountry: any;
  userOwnerCountry: any;
  selectedCountry: any;
  selectedOwnerCountry: any;
  userManagerCountry: any;
  selectedManagerCountry: any;

  userState: any;
  userOwnerState: any;
  selectedState: any;
  selectedOwnerState: any;
  userManagerState: any;
  selectedManagerState: any;
  getCenterDetail(id: number) {
    this.loading = true;
    this.centerService.getCenterDetail(id).subscribe(
      (center: any) => {
        this.center = center.data;
        this._fetchCountry.getCounties()
          .subscribe(
          countryData => {
            this.countryData = countryData['data'].rows;
            this.userCountry = this.countryData.filter(element => {
              return element.id == this.center.country;
            });
            this.selectedCountry = this.userCountry[0].name;
            this.userOwnerCountry = this.countryData.filter(element => {
              return element.id == this.center.owner_country;
            });
            this.selectedOwnerCountry = this.userOwnerCountry[0].name;
            this.userManagerCountry = this.countryData.filter(element => {
              return element.id == this.center.center_managers[0].user.country;
            });
            this.selectedManagerCountry = this.userManagerCountry[0].name;
          });

          this._fetchCountry.getStates()
          .subscribe(
          stateData => {
            this.stateData = stateData['data'].rows;
            this.userState = this.stateData.filter(element => {
              return element.id == this.center.state;
            });
            this.selectedState = this.userState[0].state_name;
            this.userOwnerState = this.stateData.filter(element => {
              return element.id == this.center.owner_state;
            });
            this.selectedOwnerState = this.userOwnerState[0].state_name;
            this.userManagerState = this.stateData.filter(element => {
              return element.id == this.center.center_managers[0].user.state;
            });
            this.selectedManagerState= this.userManagerState[0].state_name;
          });
        this.loading = false;
      }
    );
  }



}
