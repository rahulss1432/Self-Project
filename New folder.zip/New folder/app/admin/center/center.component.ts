import { Component } from '@angular/core';

@Component({
  selector: 'hb-center',
  templateUrl: './center.component.html',
  styleUrls: ['./center.component.css']
})
export class CenterComponent {


}
