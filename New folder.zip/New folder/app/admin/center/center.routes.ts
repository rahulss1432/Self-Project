
import { Routes, RouterModule } from '@angular/router';
import { CenterlistComponent } from './centerlist/centerlist.component';
import { CenterComponent } from './center.component';
import { CenteraddComponent } from './centeradd/centeradd.component';
import { CenterdetailComponent } from './centerdetail/centerdetail.component';
const CENTER_ROUTE: Routes = [
  {
    path: '', component: CenterComponent, children: [
      { path: '', component: CenterlistComponent },
      { path: 'list', component: CenterlistComponent },
      { path: 'add', component: CenteraddComponent },
      { path: 'detail/:id', component: CenterdetailComponent },
      { path: 'edit/:id', component: CenteraddComponent },
    ]
  },

]

export const centerRouting = RouterModule.forChild(CENTER_ROUTE);

