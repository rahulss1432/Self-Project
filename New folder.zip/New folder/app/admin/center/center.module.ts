import { NgModule } from "@angular/core";
import { CenterComponent } from "./center.component";
import { CenterlistComponent } from "./centerlist/centerlist.component";
import { CenteraddComponent } from "./centeradd/centeradd.component";
import { CenterdetailComponent } from "./centerdetail/centerdetail.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { centerRouting } from "./center.routes";
import { SharedModule } from "../../shared/module/shared.module";
import { CenterService } from "./service/center.service";
import { NgxPaginationModule } from "ngx-pagination";
import { ApiConstantService } from "./../../shared/service/api-constant.service";
import { ApiParameterService } from "./../../shared/service/api-parameter.service";
import { ApiMiddleWareService } from "./../../shared/service/api-middle-ware.service";
import { ApiActionService } from "./../../shared/service/api-action.service";
import { ApiRepositoryService } from "./../../shared/service/api-repository.service";
import { GlobalConstantService } from "./../../shared/service/global-constant.service";

@NgModule({
  declarations: [
    CenterComponent,
    CenteraddComponent,
    CenterlistComponent,
    CenterdetailComponent,
    
    
  ],
  imports: [
    FormsModule,
    centerRouting,
    SharedModule,
    ReactiveFormsModule,
    NgxPaginationModule
  ],
  providers: [
    CenterService,
    ApiRepositoryService,
    ApiActionService,
    ApiMiddleWareService,
    ApiParameterService,
    ApiConstantService,
    GlobalConstantService
  ]
})
export class CenterModule { }
