﻿export class Center {

  // Center :start
  id: number;
  user_id: number;
  center_name: string;
  center_id: string;
  center_email: string;
  center_phone_no: string;
  address_line1: string;
  address_line2: string;
  country: string = '';
  state: string = '';
  city: string;
  zip_code: string;
  // Center : end

  staff_capacity: string;
  child_capacity: string;

  // Owner :start
  owner_first_name: string;
  owner_last_name: string;
  owner_address_line1: string;
  owner_address_line2: string;
  owner_email: string;
  owner_phone_number: string;
  owner_mobile_number: string;
  owner_country: string = '';
  owner_state: string = '';
  owner_city: string;
  owner_zip_code: string;

  // Owner : end


  // manager :start
  manager_first_name: string;
  manager_last_name: string;
  manager_address_line1: string;
  manager_address_line2: string;
  manager_email: string;
  manager_phone_number: string;
  manager_mobile_number: string;
  manager_country: string = '';
  manager_state: string = '';
  manager_city: string;
  manager_zip_code: string;
  manager_gender: string = '';
  photo: any;
  // manager : end

  status: string;
  addrescreated_ats: string;
  updated_at: string
}

