﻿import { Component, OnInit } from "@angular/core";
import { Center } from "../model/center";
import { CenterService } from "../service/center.service";
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: "hb-centerlist",
  templateUrl: "./centerlist.component.html"
})
export class CenterlistComponent implements OnInit {
  centerList: any[] = [];
  p = 1;
  total: number;
  loading: boolean;
  query = "";
  centerInfo: any = [];
  constructor(
    private centerapi: CenterService,
    private route: ActivatedRoute,
    private router: Router,
    private toastr: ToastrService,
  ) { }

  ngOnInit() {
    this.getCenterList(1);
  }

  onEditCenter(id: number) {
    // alert(id);
  }

  getCenterList(page: number) {
    this.loading = true;
    this.centerapi
      .getCenterList(page, this.query)
      .subscribe((data: any) => {
        this.centerList = data.data.rows;
        this.total = data.data.total;
        this.p = page;
        this.loading = false;
      });
  }


  deleteCenter(centerInfo: any, index: any) {
    this.loading = true;
    this.centerapi.deleteCenter(centerInfo.id)
      .subscribe(
      (data: any) => {

        this.centerList.splice(index, 1);
        this.toastr.success('Deleted successfully');

        this.getCenterList(1);

        this.loading = false;
      },
      (err) => {
        this.loading = false;

      });
  }

  centerinfo(data){
  this.centerInfo = data;
  }
}
