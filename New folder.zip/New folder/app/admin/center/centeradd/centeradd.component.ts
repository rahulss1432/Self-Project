﻿import { element } from "protractor";
import { Component, OnInit, ElementRef, ViewChild } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription } from "rxjs/Rx";
import {
  FormGroup,
  NgForm,
  FormsModule,
  ReactiveFormsModule
} from "@angular/forms";
import * as $ from "jquery";
import { CommonModule } from "@angular/common";
import { Center } from "../model/center";
import { CenterService } from "../service/center.service";
import { ApiCountryStateService } from './../../../shared/service/api-country-state.service';
import { Countries } from '../../../shared/model/countries';
import { States } from '../../../shared/model/states';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: "hb-centeradd",
  templateUrl: "./centeradd.component.html"
})
export class CenteraddComponent implements OnInit {
  @ViewChild("fileInput") inputEl: ElementRef;

  private fileList: any = [];
  private subscription: Subscription;
  countryData: Countries[];
  stateData: States[];
  id: number;
  title: string;
  center: any = new Center();
  center_managers: any = new Center();
  loading = false;
  errorData = "";
  photo: any;
  disabled: boolean = false;
  genders = ["male", "female"];

  fileCount: number;
  fileName: string;
  showSizeError: boolean = false;
  showTypeError: boolean = false;
  globalVariable: number;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private _fetchCountry: ApiCountryStateService,
    private centerapi: CenterService,
    private toastr: ToastrService,
    private el: ElementRef,
  ) {
    this.subscription = activatedRoute.params.subscribe((param: any) => {
      this.id = param["id"];
    });
    if (this.id) {
      this.title = "Edit Center For: " + this.id;
      // for getting center details
      this.getCenterDetail(this.id);
    } else {
      this.title = "Add Center";
      // this.init();
    }
  }

  ngOnInit() {
    this.getCounties();
    this.getStates();
  }

  getCounties(): void {
    this._fetchCountry.getCounties()
      .subscribe(
        countryData => {
          this.countryData = countryData['data'].rows;
        });
  }

  getStates(): void {
    this._fetchCountry.getStates()
      .subscribe(
        stateData => {
          this.stateData = stateData;
        });
  }
  centerCountry: number;
  centerStates: any = [];
  onCenterCountry(centerCountry): void {
    this._fetchCountry.getStates()
      .subscribe(
        stateData => {
          this.centerStates = this.stateData['data'].rows.filter(element => {
            return element.country_id == centerCountry;
          });

        });
  }

  ownerCountry: number;
  ownerStates: any = [];
  onOwnerCountry(ownerCountry): void {
    this._fetchCountry.getStates()
      .subscribe(
        stateData => {
          this.ownerStates = stateData['data'].rows.filter(element => {
            return element.country_id == ownerCountry;
          });
        });
  }

  managerCountry: number;
  managerStates: any = [];
  onManagerCountry(managerCountry): void {
    this._fetchCountry.getStates()
      .subscribe(
        stateData => {
          this.managerStates = stateData['data'].rows.filter(element => {
            return element.country_id == managerCountry;
          });
        });
  }

  addCenter(frm: NgForm) {
    if (frm.valid) {
      this.clearError('photo');
      this.loading = true;
      this.centerapi.addUpdateCenter(frm.value, this.fileList, this.id).subscribe(
        res => {
          if (res['success'] === true) {
            this.router.navigate(['/center/list']);
            this.toastr.success(res.message);
            this.loading = false;
          } else {
            this.loading = false;
            this.toastr.error('Something went wrong ');
          }
        },
        err => {
          if (err.error.error.length) {
            err.error.error.map((e, i) => {
              this.toastr.error(err.error.error[i].message);
            });
            this.loading = false;
            this.disabled = false;
          }
          else {
            this.toastr.error('Something went wrong');
          }
        });
    } else {
      let target;
      target = this.el.nativeElement.querySelector('.errormessage');
      if (target) {
        $('html,body').animate({ scrollTop: $(target).offset().top - 150 }, 'slow', () => {
          target.focus();
        });
      }
    }
  }

  clearError(imagetag) {
    this.showSizeError = false;
    this.showTypeError = false;
  }

  upload(e, imageFor) {

    const inputEl: HTMLInputElement = this.inputEl.nativeElement;
    this.fileCount = inputEl.files.length;
    if (this.fileCount > 0) {
    this.fileName = inputEl.files[0].name;
    
    //check file is valid
    if (!this.validateFile(inputEl.files[0].name)) {
      this.inputEl.nativeElement.value = "";
      this.showTypeError = true;
      return false;
    }
    this.showTypeError = false;
    //check file size is valid 10 MB
    if (inputEl.files[0].size > 10000000) {
      this.inputEl.nativeElement.value = "";
      document.getElementById('managerImg').setAttribute('src','assets/images/default-user.jpg');
      this.fileList='';
      this.showSizeError = true;
      return false;
    }
    this.showSizeError = false;
    
      // a file was selected
      for (let i = 0; i < this.fileCount; i++) {
        this.fileList = inputEl.files.item(i);
        const reader = new FileReader();
        reader.readAsDataURL(inputEl.files.item(i));
        reader.onload = this.setFileUrl;
      }
    }

  }

  validateFile(name: String) {
    var ext = name.substring(name.lastIndexOf('.') + 1);
    if (ext.toLowerCase() == 'png' || ext.toLowerCase() == 'jpeg' || ext.toLowerCase() == 'jpg') {
      return true;
    }
    else {
      return false;
    }
  }

  setFileUrl(file: any) {
    this.photo = file.target.result;
    document
      .getElementById("managerImg")
      .setAttribute("src", file.target.result);
  }
  resetCenter() {
    this.center = new Center();
    this.center_managers = new Center();
    this.ngOnInit();
  }

  getCenterDetail(id: number) {
    this.loading = true;
    this.centerapi.getCenterDetail(id).subscribe(
      (center: any) => {
        this.center = center.data;
        this.center_managers = center.data.center_managers[0].user;
        this.loading = false;
        this.centerCountry = center.data.country;
        this.ownerCountry = center.data.owner_country;
        this.managerCountry = center.data.center_managers[0].user.country;
        this.centerStates = this.onCenterCountry(center.data.country);
        this.center.state = center.data.state;
        this.ownerStates = this.onOwnerCountry(center.data.owner_country);
        this.center.owner_state = center.data.owner_state;
        this.managerStates = this.onManagerCountry(center.data.center_managers[0].user.country);
        this.center_managers.state = center.data.center_managers[0].user.state;;
      }
    );
  }
   numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

}
