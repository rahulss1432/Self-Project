﻿import { Injectable } from "@angular/core";
import { Http, Response, Headers } from "@angular/http";
import { AuthenticationService } from '../../../auth/_services';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Center } from "./../model/center";
import { Observable, of } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators'
import { environment } from '../../../../environments/environment';
import { ApiMiddleWareService } from "../../../shared/service/api-middle-ware.service";
import { ApiActionService } from "../../../shared/service/api-action.service";
import "rxjs/Rx";
import {
  RequestOptions,
  CommonService
} from "../../../shared/service/common.service";
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable()
export class CenterService {
    baseUrl = environment.baseUrl;
  constructor(
    private http: HttpClient,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    private apiMiddleWareService: ApiMiddleWareService,
    private apiActionService: ApiActionService,
  ) { }
  /** Add Center: add the center on the server */

  addUpdateCenter(center: Center, file: any, Id: number) {
    const urlSearchParams = this.commonService.getURLSearchParamsObject(center);
    const body = urlSearchParams.toString();
    const headers = this.commonService.getFormDataHeader();
    const options = new RequestOptions({ headers: headers });

    const formData = new FormData();
    formData.append("center_id", center.center_id);
    formData.append("center_name", center.center_name);
    formData.append("address_line1", center.address_line1);
    formData.append("address_line2", center.address_line2 ? center.address_line2 : "");
    formData.append("country", center.country);
    formData.append("state", center.state);
    formData.append("city", center.city);
    formData.append("zip_code", center.zip_code);

    formData.append("staff_capacity", center.staff_capacity);
    formData.append("child_capacity", center.child_capacity);

    formData.append("owner_first_name", center.owner_first_name);
    formData.append("owner_last_name", center.owner_last_name);
    formData.append("owner_address_line1", center.owner_address_line1);
    formData.append("owner_address_line2", center.owner_address_line2 ? center.owner_address_line2 : "");
    formData.append("owner_email", center.owner_email);
    formData.append("owner_phone_number", center.owner_phone_number ? center.owner_phone_number : "");
    formData.append("owner_mobile_number", center.owner_mobile_number);
    formData.append("owner_country", center.owner_country);
    formData.append("owner_state", center.owner_state);
    formData.append("owner_city", center.owner_city);
    formData.append("owner_zip_code", center.owner_zip_code);

    formData.append("manager_first_name", center.manager_first_name);
    formData.append("manager_last_name", center.manager_last_name);
    formData.append("manager_address_line1", center.manager_address_line1);
    formData.append(
      "manager_address_line2",
      center.manager_address_line2 ? center.manager_address_line2 : ""
    );
    formData.append("manager_email", center.manager_email);
    formData.append(
      "manager_phone_number",
      center.manager_phone_number ? center.manager_phone_number : ""
    );
    formData.append("manager_mobile_number", center.manager_mobile_number);
    formData.append("manager_country", center.manager_country);
    formData.append("manager_state", center.manager_state);
    formData.append("manager_city", center.manager_city);
    formData.append("manager_zip_code", center.manager_zip_code);
    formData.append("manager_gender", center.manager_gender);
    formData.append("photo", file ? file : "");
    if (Id) {
      const a = this.http.post(this.baseUrl + "center/" + Id,
        formData,
        options);
      return a.pipe(map((response: any) => {
        const data = response && response.data;
        return response;
      }));
    } else {

      const a = this.http.post(this.baseUrl + "center", formData, options);
      return a.pipe(map((response: any) => {
        const data = response && response.data;
        return response;
      }));

    }
  }
  /**centers  from the server */
  getCenterList(page: number, query: string) {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });

    return this.http
      .get(
      this.baseUrl +
      "center?limit=10&offset=" +
      (page - 1) * 10 +
      "&q=" +
      query,
      options
      ).pipe(map((response: any) => response));
  }

  /** center manager details from the server */
  getCenterDetail(id: number) {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });

    return this.http
      .get(this.baseUrl + "center/" + id, options)
      .map((response: any) => response)
      .catch(this.commonService.GetHandleErrorString);
  }
  /** delete  center manager details from the server */
     deleteCenter(id: number) {
    const headers = this.commonService.getHeadersObject(null, true, true);
    const options = new RequestOptions({ headers: headers });

    return this.http
      .delete(this.baseUrl + "center/" + id, options)
      .map((response: any) => {
        return response;
      })
      .catch(this.commonService.GetHandleErrorString);
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      this.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }

  private log(message: string) {
  }

}
