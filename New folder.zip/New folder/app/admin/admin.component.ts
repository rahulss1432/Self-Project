﻿import { Component, ViewChild, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'hb-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  header_title = 'Dashboard';
  @ViewChild('content') content;
  constructor(private router: Router) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        // console.log(event.urlAfterRedirects);
        this.setHeading(event.urlAfterRedirects);
      }
    });

  }

  setInnerPageHeight() {
    const contentCmp = this.content.nativeElement;
    const window_height = window.innerHeight;
    contentCmp.style.minHeight = window_height - 103 + 'px';
  }


  ngOnInit() {

    this.setInnerPageHeight();


  }

  setHeading(url: string) {
    switch (url) {
      case '/dashboard':
        this.header_title = 'Dashboard';
        break;
      case '/center':
        this.header_title = 'Manage Center';
        break;
      case '/center/add':
        this.header_title = 'Add Center';
        break;
      case '/attendance':
        this.header_title = 'Attendance';
        break;
      case '/child':
        this.header_title = 'MANAGE CHILD';
        break;
      case '/program':
        this.header_title = 'Manage Program';
        break;
      case '/program/add':
        this.header_title = 'Add Program';
        break;
      case '/messages':
        this.header_title = 'Messages';
        break;
      case '/my-account':
        this.header_title = 'My Account';
        break;
      case '/teacher':
        this.header_title = 'MANAGE Staff';
        break;
      case '/video':
        this.header_title = 'Video Library';
        break;
      case '/change-password':
        this.header_title = 'Setting';
        break;
      case '/daily-schedule':
        this.header_title = 'Daily Schedule';
        break;
      case '/event':
        this.header_title = 'Events';
        break;
      case '/feedback':
        this.header_title = 'Feedback';
        break;
      case '/appointment':
        this.header_title = 'Appointment';
        break;
      case '/registration':
        this.header_title = 'Registration';
        break;
      case '/enquiry':
        this.header_title = 'Enquiry';
        break;
      default:
        if (url.includes('/center/edit/')) {
          this.header_title = 'UPDATE CENTER';
        } else if (url.includes('/center/detail/')) {
          this.header_title = 'VIEW CENTER DETAILS';
        } else if (url.includes('/center/add/')) {
          this.header_title = 'ADD CENTER DETAILS';
        } else if (url.includes('/program/detail/')) {
          this.header_title = 'VIEW PROGRAM';
        } else if (url.includes('/program/edit/')) {
          this.header_title = 'UPDATE PROGRAM';
        } else if (url.includes('/daily-schedule/add')) {
          this.header_title = 'ADD SCHEDULE';
        } else if (url.includes('/daily-schedule/edit')) {
          this.header_title = 'EDIT SCHEDULE';
        } else if (url.includes('/teacher/add')) {
          this.header_title = 'ADD STAFF';
        } else if (url.includes('/teacher/edit')) {
          this.header_title = 'EDIT STAFF';
        } else if (url.includes('/teacher/detail')) {
          this.header_title = 'VIEW STAFF DETAILS';
        } else if (url.includes('/event/add')) {
          this.header_title = 'ADD EVENT';
        } else if (url.includes('/event/edit')) {
          this.header_title = 'EDIT EVENT';
        } else if (url.includes('/event/detail')) {
          this.header_title = 'VIEW EVENT DETAILS';
        } else if (url.includes('/feedback/detail')) {
          this.header_title = 'VIEW FEEDBACK DETAILS';
        }
        break;
    }
  }
}
