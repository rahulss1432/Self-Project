export class Program {
  id: number;
  program_name: string;
  description: string;
  from_age: number;
  to_age: number;
  skills: string;
  status: string;
  created_at: Date;
  updated_at: Date;
}
