import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hb-program',
  templateUrl: './program.component.html',
  styleUrls: ['./program.component.css']
})
export class ProgramComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
