import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProgramComponent } from './program.component';
import { ProgramlistComponent } from './programlist/programlist.component';
import { ProgramaddComponent } from './programadd/programadd.component';
import { ProgramdetailComponent } from './programdetail/programdetail.component';
import { programRouting } from './program.route';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProgramService } from "./service/program.service";
import { SharedModule } from '../../shared/module/shared.module';
import { NgxPaginationModule } from 'ngx-pagination';
@NgModule({
  imports: [
    CommonModule,
    programRouting,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    NgxPaginationModule
  ],
  declarations: [ProgramComponent, ProgramlistComponent, ProgramaddComponent, ProgramdetailComponent],
  providers: [ProgramService]
})
export class ProgramModule { }
