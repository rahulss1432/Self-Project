
import { Routes, RouterModule } from '@angular/router';
import { ProgramComponent } from './program.component';
import { ProgramlistComponent } from './programlist/programlist.component';
import { ProgramaddComponent } from './programadd/programadd.component';
import { ProgramdetailComponent } from './programdetail/programdetail.component';
const PROGRAM_ROUTE: Routes = [
  {
    path: '', component: ProgramComponent, children: [
      { path: '', component: ProgramlistComponent },
      { path: 'list', component: ProgramlistComponent },
      { path: 'add', component: ProgramaddComponent },
      { path: 'edit/:id', component: ProgramaddComponent },
      { path: 'detail/:id', component: ProgramdetailComponent },
    ]
  },

]

export const programRouting = RouterModule.forChild(PROGRAM_ROUTE);

