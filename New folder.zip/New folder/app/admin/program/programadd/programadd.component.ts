﻿import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Program } from "../model/program";
import { NgForm } from "@angular/forms";
import { ProgramService } from "../service/program.service";
import { ToastrService } from 'ngx-toastr';
import { CommonService } from "../../../shared/service/common.service";
@Component({
  selector: "hb-programadd",
  templateUrl: "./programadd.component.html"
})
export class ProgramaddComponent implements OnInit {
  id: number;
  title: string;
  program = new Program();
  loading = false;
  errorData = "";
  ageList = new Array(36);
  disabled: boolean = false;

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private programApi: ProgramService,
    private toastr: ToastrService,
    private commonService: CommonService
  ) {
    this.id = this.activatedRoute.snapshot.params["id"];
    if (this.id) {
      this.getProgramDetail(this.id);
    }
  }

  ngOnInit() {
    this.program.to_age = 1;
    this.program.from_age = 1;
  }

  getProgramDetail(id: number) {
    this.loading = true;
    this.programApi.getProgramDetail(id).subscribe((program: any) => {
      this.program = program.data;
      this.loading = false;
    });
  }

  addUpdateProgram(frm: NgForm) {
    if (frm.valid) {
      this.loading = true;
      this.programApi.addUpdateProgram(frm.value).subscribe(
        res => {
          if (res['success'] === true) {
            this.router.navigate(['/program/list']);
            this.toastr.success(res.message);
            this.loading = false;
          } else {
            this.errorData = this.commonService.GetHandleMultilineErrorString(
              res.error
            );
            this.toastr.error(this.errorData);
          }
          this.loading = false;
          this.disabled = false;
        },
        err => {
          if (err.error.error.length) {
            err.error.error.map((e, i) => {
              this.toastr.error(err.error.error[i].message);
            });
            this.loading = false;
            this.disabled = false;
          }
          else
          {
            this.toastr.error('Something went wrong');
          }
        }
      );
    }
  }

  resetProgram() {
    this.program = new Program();
    this.ngOnInit();
  }

}




