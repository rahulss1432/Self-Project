import { Component, OnInit, Pipe } from '@angular/core';
import { ProgramService } from '../service/program.service';
import { Program } from '../model/program';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'hb-programlist',
  templateUrl: './programlist.component.html'
})
export class ProgramlistComponent {
  programList: any[] = [];
  p = 1;
  total: number;
  loading: boolean;
  query: string = '';
  pointer: "pointer";
  programInfo: any = [];
  constructor(private programService: ProgramService, private toastr: ToastrService) { }

  ngOnInit() {
    this.getProgramList(1);
  }

  getProgramList(page: number) {
    this.loading = true;
    this.programService.getProgramList(page, this.query)
      .subscribe(
      (data: any) => {
        this.programList = data.data.rows;
        this.total = data.data.total;
        this.p = page;
        this.loading = false;
      }
      );
  }

  deleteProgram(programInfo: any, index: number) {
    this.loading = true;
    this.programService.deleteProgram(programInfo.id)
      .subscribe(
      (data: any) => {
        if (programInfo.status === "active") {
          this.programList.splice(index, 1);
          this.toastr.success("Delete successfully");
          this.getProgramList(1);
        }
        this.loading = false;
      },
      (err) => {
        this.loading = false;
      });
  }
  programinfo(data) {
    this.programInfo = data;


  }

}
