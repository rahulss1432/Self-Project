import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProgramService } from '../service/program.service';

@Component({
  selector: 'hb-programdetail',
  templateUrl: './programdetail.component.html'
})
export class ProgramdetailComponent implements OnInit {
  id: number;
  loading: boolean;
  program: any = {};

  constructor(
    private activatedRoute: ActivatedRoute,
    private programService: ProgramService
  ) {
    this.id = this.activatedRoute.snapshot.params['id'];
  }

  ngOnInit() {
    this.getProgramDetail(this.id);
  }

  getProgramDetail(id: number) {
    this.loading = true;
    this.programService.getProgramDetail(id)
      .subscribe(
      (program: any) => {
        this.program = program.data;
        this.loading = false;
      }
      );
  }

}
