﻿import { FeedbackDetailComponent } from './feedback-detail/feedback-detail.component';
import { FeedbackListComponent } from './feedback-list/feedback-list.component';
import { FeedbackComponent } from './feedback.component';
import { Routes, RouterModule } from '@angular/router';

const FEEDBACK_ROUTE: Routes = [
  {
    path: '', component: FeedbackComponent, children: [
      { path: '', component: FeedbackListComponent },
      { path: 'list', component: FeedbackListComponent },
      { path: 'detail/:id', component: FeedbackDetailComponent }
    ]
  }
];

export const FeedbackRouting = RouterModule.forChild(FEEDBACK_ROUTE);
