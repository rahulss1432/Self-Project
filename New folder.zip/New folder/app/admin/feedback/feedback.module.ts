import { FeedbackRouting } from './feedback.route';
import { FeedbackListComponent } from './feedback-list/feedback-list.component';
import { FeedbackDetailComponent } from './feedback-detail/feedback-detail.component';
import { FeedbackComponent } from './feedback.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/module/shared.module';
import { FeedbackService } from './service/feedback.service';

@NgModule({
  declarations: [
    FeedbackComponent,
    FeedbackDetailComponent,
    FeedbackListComponent
  ],
  providers: [
    FeedbackService
  ],
  imports: [
    CommonModule,
    HttpModule,
    FormsModule,
    NgxPaginationModule,
    FeedbackRouting,
    SharedModule
  ]
})

export class FeedbackModule { }
