import { Component, OnInit } from '@angular/core';
import { FeedbackService } from '../service/feedback.service';
import { AuthenticationService, AlertService } from '../../../auth/_services';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'hb-feedback-list',
  templateUrl: './feedback-list.component.html',
})
export class FeedbackListComponent implements OnInit {
  query = '';
  feedbackList: any[] = [];
  p = 1;
  total: number;
  loading: boolean;
  center_id: number;
  constructor(
    private feedbackService: FeedbackService,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private toastr: ToastrService,
  ) {
    this.center_id = this.authenticationService.getUserDetail().center_id;
  }

  ngOnInit() {
    this.getFeedbackList(1);
  }

  getFeedbackList(page: number) {
    this.loading = true;
    this.feedbackService.getFeedbackList(page, this.query, this.center_id)
      .subscribe(
      (data: any) => {
        this.feedbackList = data.data.rows;
        this.total = data.data.total;
        this.p = page;
        this.loading = false;
      },
      (err) => {
        this.toastr.error(err.error.message);
        this.loading = false;
      });
  }
}
