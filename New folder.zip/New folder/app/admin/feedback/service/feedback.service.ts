﻿import { Injectable } from '@angular/core';
import { RequestOptions } from '../../../shared/service/request-option';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { CommonService } from '../../../shared/service/common.service';
import 'rxjs/Rx';

@Injectable()
export class FeedbackService {
   baseUrl = environment.baseUrl;
  constructor(
    private http: HttpClient,
    private commonService: CommonService,
    ) { }

  getFeedbackList(
    page: number,
    query: string,
    center_id: number,
    pagination: boolean = true
  ) {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });
    return this.http
      .get(
      this.baseUrl +
      'center/' +
      center_id +
      '/feedback' +
      '?limit=10&offset=' +
      (page - 1) * 10 +
      '&q=' +
      query +
      '&pagination=' +
      pagination,
      options
      ).map((response: any) => response);
  }

  getFeedbackDetail(id: number, center_id: number) {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });
    return this.http
      .get(
      this.baseUrl +
      'center/' +
      center_id +
      '/feedback/' +
      id,
      options
      )
      .map((response: any) => response)
      .catch(this.commonService.GetHandleErrorString);
  }

  deleteFeedback(id: number, center_id: number) {
    const headers = this.commonService.getHeadersObject(null, true, true);
    const options = new RequestOptions({ headers: headers });
    return this.http
      .delete(
      this.baseUrl +
      'center/' +
      center_id +
      '/feedback/' +
      id,
      options
      )
      .map((response: any) => response)
      .catch(this.commonService.GetHandleErrorString);
  }

}
