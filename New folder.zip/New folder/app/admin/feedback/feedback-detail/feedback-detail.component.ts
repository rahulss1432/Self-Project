import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FeedbackService } from '../service/feedback.service';
import { AuthenticationService, AlertService } from '../../../auth/_services';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'hb-feedback-detail',
  templateUrl: './feedback-detail.component.html',
})
export class FeedbackDetailComponent implements OnInit {
  id: number;
  loading: boolean;
  feedback: any = {};
  center_id: number;

  constructor(
    private activatedRoute: ActivatedRoute,
    private feedbackService: FeedbackService,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private toastr: ToastrService,
  ) {
    this.id = this.activatedRoute.snapshot.params['id'];
    this.center_id = this.center_id = this.authenticationService.getUserDetail().center_id;
  }

  ngOnInit() {
    this.getFeedbackDetail(this.id);
  }

  getFeedbackDetail(id: number) {
    this.loading = true;
    this.feedbackService.getFeedbackDetail(id, this.center_id)
      .subscribe(
      (result: any) => {
        this.feedback = result.data;
        this.loading = false;
      },
      (err) => {
        this.toastr.error(err.error.message);
        this.loading = false;
      });
  }
}
