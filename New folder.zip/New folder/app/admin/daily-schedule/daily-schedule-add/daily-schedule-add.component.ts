import { DailySchedule } from "./../model/daily-schedule.model";
import { Component, OnInit } from "@angular/core";
import { FormGroup, NgForm, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { DailyScheduleService } from "./../service/daily-schedule.service";
import { CommonService } from "../../../shared/service/common.service";
import { NgbDateStruct, NgbTimepicker } from "@ng-bootstrap/ng-bootstrap";
import { AlertService, AuthenticationService } from "../../../auth/_services";
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: "hb-daily-schedule-add",
  templateUrl: "./daily-schedule-add.component.html"
})
export class DailyScheduleAddComponent implements OnInit {
  errorData = "";
  loading: boolean;
  formValue = [];
  startTime = "";
  endTime = "";
  start_time: any;
  end_time: any;
  activity_schedule = "";
  dailySchedule = new DailySchedule();
  program_id: number;
  center_id: number;
  scheduleList = [
    {
      program_id: 0,
      start_time: "",
      end_time: "",
      activity_schedule: ""
    }
  ];
  currentIndex: number;
  program_name: string;
  disabled = false;
  today = new Date();
  id: any;
  futureDate: NgbDateStruct = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };

  time: any;
  event_start_time1: any;
  event_end_time2: any;
  meridian = true;
  constructor(
    private dailyScheduleService: DailyScheduleService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private commonService: CommonService,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private toastrService: ToastrService
  ) {
    this.dailySchedule = new DailySchedule();
    this.program_id = this.activatedRoute.snapshot.params["id"];
    this.center_id = this.authenticationService.getUserDetail().center_id;
    this.time = { hour: 11, minute: 30 };
    this.event_start_time1 = this.time;
    this.event_end_time2 = this.time;
  }

  ngOnInit() {
    this.setProgramName();
  }

  setProgramName() {
    this.program_name = this.dailyScheduleService.setProgramName();
  }

  onSubmit(frm: NgForm) {
    if (frm.valid) {
      this.disabled = true;
      this.errorData = "";
      this.loading = true;
      this.formValue = [];
      this.scheduleList.forEach((obj, index) => {
        if (obj.start_time) {
          this.startTime =
            obj.start_time["hour"] + ":" + obj.start_time["minute"];
        }
        if (obj.end_time) {
          this.endTime = obj.end_time["hour"] + ":" + obj.end_time["minute"];
        }
        this.formValue.push({
          start_time: this.startTime,
          id: this.id,
          end_time: this.endTime,
          activity_schedule: obj.activity_schedule
        });
      });
      this.dailyScheduleService
        .addUpdateSchedule(this.formValue, this.center_id, this.program_id, this.id)
        .subscribe(
        result => {
          if (result.success === true) {
            this.toastrService.success(result.message);
            this.router.navigate(["/daily-schedule"]);
          } else if (result.error !== "") {
            this.errorData = this.commonService.GetHandleMultilineErrorString(
              result.error
            );
            this.toastrService.error(this.errorData);
          } else {
            this.toastrService.error(result.message);
          }
          this.loading = false;
          this.disabled = false;
        },
        err => {
          if (err.error.error.length) {
            err.error.error.map((e, i) => {
              this.toastrService.error(err.error.error[i].message);
            });
            this.loading = false;
            this.disabled = false;
          }
          else
          {
            this.toastrService.error('Something went wrong');
          }
        });
    }
  }

  addMoreSchedule() {
    this.currentIndex = this.scheduleList.length - 1;
    if (
      this.scheduleList[this.currentIndex].start_time !== "" &&
      this.scheduleList[this.currentIndex].end_time !== "" &&
      this.scheduleList[this.currentIndex].activity_schedule
    ) {
      this.scheduleList.push({
        program_id: this.program_id,
        start_time: "",
        end_time: "",
        activity_schedule: ""
      });
    } else {
      this.toastrService.error("Please fill current schedule first.");
    }
  }

  removeSchedule(index) {
    this.scheduleList.splice(index, 1);
  }

}
