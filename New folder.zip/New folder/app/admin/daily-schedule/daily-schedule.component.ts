import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'hb-daily-schedule',
  templateUrl: './daily-schedule.component.html',
})
export class DailyScheduleComponent implements OnInit , OnDestroy{

  constructor() { }

  ngOnInit() {
  }
  ngOnDestroy() {
    localStorage.setItem("program_id", '0'); 
  }

}
