import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/module/shared.module';

import { DailyScheduleRouting } from './daily-schedule.routes';
import { DailyScheduleComponent } from './daily-schedule.component';
import { DailyScheduleListComponent } from './daily-schedule-list/daily-schedule-list.component';
import { DailyScheduleAddComponent } from './daily-schedule-add/daily-schedule-add.component';
import { DailyScheduleService } from './service/daily-schedule.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProgramService } from '../program/service/program.service';
import { EditScheduleComponent } from './edit-schedule/edit-schedule.component';

@NgModule({
  imports: [
    CommonModule,
    DailyScheduleRouting,
    FormsModule,
    NgbModule.forRoot(),
    SharedModule
  ],
  declarations: [
    DailyScheduleComponent,
    DailyScheduleListComponent,
    DailyScheduleAddComponent,
    EditScheduleComponent,
  ],
  providers: [DailyScheduleService,ProgramService]
})
export class DailyScheduleModule { }
