import { ProgramService } from "./../../program/service/program.service";
import { DailyScheduleService } from "./../service/daily-schedule.service";
import { Component } from "@angular/core";
import { FormGroup, NgForm, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { AuthenticationService } from "../../../auth/_services";
import { CommonService } from "../../../shared/service/common.service";

@Component({
  selector: "hb-daily-schedule-list",
  templateUrl: "./daily-schedule-list.component.html"
})
export class DailyScheduleListComponent {
  scheduleList: any[] = [];
  loading: boolean;
  center_id: number;
  programList: any[] = [];
  p = 1;
  total: number;
  query = "";
  activeTabId = 0;
  activeTabName: string;
  programId = 0;
  program_name: string;
  TabId: any;
  previuosTabActive: any;
  constructor(
    private dailyScheduleService: DailyScheduleService,
    private programService: ProgramService,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.getprogramList(1);
    /** get previous tab active  */
    const getId :any=parseInt(localStorage.getItem("program_id"));
    setTimeout(function () {
      if(getId > 0)
      {
        let activeTab = $('a#tab_' + getId);
        activeTab[0].click();
      }
    }, 700);
  }

  getprogramList(page: number) {
    this.loading = true;
    this.programService.getProgramList(page, this.query).subscribe(
      (data: any) => {
        this.programList = data.data.rows;
        this.activeTabId = this.programList[0].id;
        this.activeTabName = this.programList[0].program_name;
        this.getScheduleList(this.activeTabId, this.activeTabName);
        this.total = data.data.total;
        this.p = page;
        this.loading = false;
      },
      err => {
        this.loading = false;
      }
    );
    /** Default first tab active */
    setTimeout(function () {
      this.TabId = $('ul#program_list li:first').attr('id');
      if (parseInt(this.TabId) > 0) {
        let activeTab = $('a#tab_' + this.TabId);
        activeTab[0].click();
      }
    }, 300);

  }

  getProgramName(program_name: string) {
    this.dailyScheduleService.getProgramName(program_name);
  }

  getScheduleList(program_id: number, program_name: string) {
    this.previuosTabActive=program_id;
    localStorage.setItem("program_id", this.previuosTabActive); // for previous tab active after new one submit or edit
    this.loading = true;
    this.programId = program_id;
    this.program_name = program_name;
    this.getProgramName(this.program_name);
    this.center_id = this.authenticationService.getUserDetail().center_id;
    this.dailyScheduleService
      .getScheduleList(this.center_id, program_id)
      .subscribe(
        (data: any) => {
          this.scheduleList = data.data.rows;
          this.loading = false;
        },
        err => {
          this.loading = false;
        });
  }
}
