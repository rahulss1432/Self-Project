import { Component, OnInit } from '@angular/core';
import { DailySchedule } from '../model/daily-schedule.model';
import { DailyScheduleService } from '../service/daily-schedule.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Route } from '@angular/compiler/src/core';
import { CommonService } from '../../../shared/service/common.service';
import { AlertService, AuthenticationService } from '../../../auth/_services';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-edit-schedule',
  templateUrl: './edit-schedule.component.html',
})
export class EditScheduleComponent implements OnInit {
  program_name: any;
  loading: boolean;
  startTime = "";
  endTime = "";
  activity_schedule = "";
  start_time1: any;
  end_time1: any;
  program_id: number;
  center_id: number;
  id: number;
  dailyschedule = new DailySchedule();
  disabled = false;
  meridian = true;
  formValue = [];

  constructor(
    private dailyScheduleService: DailyScheduleService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private toastrService: ToastrService
  ) {
    this.dailyschedule = new DailySchedule();
    this.program_id = this.activatedRoute.snapshot.params["id"];
    this.id = this.activatedRoute.snapshot.params["scheduleId"];
    this.center_id = this.authenticationService.getUserDetail().center_id;
    if (this.id) {
      this.getscheduleDetail(this.id);
    }
  }

  getscheduleDetail(id: number) {
    this.dailyScheduleService.getscheduleDetail(this.center_id, this.program_id, this.id).subscribe((schedule: any) => {
      const s1 = this.get24hTime(schedule.data.rows.start_time).split(":");
      this.start_time1 = { hour: Number(s1[0]), minute: Number(s1[1]) };
      const e1 = this.get24hTime(schedule.data.rows.end_time).split(":");
      this.end_time1 = { hour: Number(e1[0]), minute: Number(e1[1]) };
      this.dailyschedule = schedule.data.rows;
    });
  }

  ngOnInit() {
  }

  get24hTime(str) {
    str = String(str).toLowerCase().replace(/\s/g, '');
    var has_am = str.indexOf('am') >= 0;
    var has_pm = str.indexOf('pm') >= 0;
    str = str.replace('am', '').replace('pm', '');
    if (str.indexOf(':') < 0) str = str + ':00';
    if (has_am) str += ' am';
    if (has_pm) str += ' pm';
    var d = new Date("1/1/2011 " + str);
    var doubleDigits = function (n) {
      return (parseInt(n) < 10) ? "0" + n : String(n);
    };
    return doubleDigits(d.getHours()) + ':' + doubleDigits(d.getMinutes());
  }

  onSubmit(frm: NgForm) {
    if (frm.valid) {
      this.disabled = true;
      this.loading = true;
      if (frm.value.start_time1) {
        frm.value.start_time =
          frm.value.start_time1["hour"] + ":" + frm.value.start_time1["minute"];
      }
      if (frm.value.end_time1) {
        frm.value.end_time = frm.value.end_time1["hour"] + ":" + frm.value.end_time1["minute"];
      }
      frm.value.id = this.id;
      this.formValue = [frm.value];
      this.dailyScheduleService
        .addUpdateSchedule(this.formValue, this.center_id, this.program_id, this.id)
        .subscribe(
        result => {
          if (result.success === true) {
            this.toastrService.success('Schedule has been updated successfully');
            this.router.navigate(["/daily-schedule"]);
          }
          this.loading = false;
          this.disabled = false;
        },
        err => {
          if (err.error.error.length) {
            err.error.error.map((e, i) => {
              this.toastrService.error(err.error.error[i].message);
            });
            this.loading = false;
            this.disabled = false;
          }
          else
          {
            this.toastrService.error('Something went wrong');
          }
        });
    }
  }

}
