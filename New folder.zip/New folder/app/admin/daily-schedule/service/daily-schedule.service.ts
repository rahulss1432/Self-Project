﻿
import { DailySchedule } from "./../model/daily-schedule.model";
import { Injectable } from "@angular/core";
import { Http, Response, Headers } from "@angular/http";
import "rxjs/Rx";
import { Observable } from "rxjs/Observable";
import { HttpClient } from "@angular/common/http";
import { AuthenticationService } from "../../../auth/_services";
import { CommonService, RequestOptions } from "../../../shared/service/common.service";
import { environment } from '../../../../environments/environment';

@Injectable()
export class DailyScheduleService {
  program_name: string;
  baseUrl = environment.baseUrl;
  constructor(
    private http: HttpClient,
    private authenticationService: AuthenticationService,
    private commonService: CommonService,
 
  ) { }

  getScheduleList(center_id: number, program_id: number) {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });
    return this.http
      .get(
      this.baseUrl +
      "center/" +
      center_id +
      "/program/" +
      program_id +
      "/daily-schedule",
      options
      ).map((response: any) => response);
  }

  addUpdateSchedule(schedule: any, center_id: number, program_id: number, id: number) {
    const body = schedule;
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });
    return this.http
      .post(
      this.baseUrl +
      "center/" +
      center_id +
      "/program/" +
      program_id +
      "/daily-schedule",
      body,
      options
      )
      .map((response: any) => {
        const data = response && response.data;
        return response;
      })
      .catch(this.commonService.GetHandleErrorString);
  }
  getscheduleDetail(center_id: number, program_id: number, id: number) {
    const headers = this.commonService.getHeadersObject(null, true, true);
    const options = new RequestOptions({ headers: headers });
    return this.http
      .get(
      this.baseUrl +
      "center/" +
      center_id +
      "/program/" +
      program_id +
      "/daily-schedule/" + id,
      options
      ).map((response: any) => response);
  }

  getProgramName(program_name: string) {
    this.program_name = program_name;
  }

  setProgramName() {
    return this.program_name;
  }
}
