export class DailySchedule {
  program_id: number;
  center_id: number;
  start_time: any;
  end_time: any;
  id: any;
  activity_schedule: string;
}
