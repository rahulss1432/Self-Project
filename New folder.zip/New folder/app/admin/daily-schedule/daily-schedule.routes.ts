import { DailyScheduleAddComponent } from './daily-schedule-add/daily-schedule-add.component';
import { Routes, RouterModule } from '@angular/router';
import { DailyScheduleComponent } from './daily-schedule.component';
import { DailyScheduleListComponent } from './daily-schedule-list/daily-schedule-list.component';
import { EditScheduleComponent } from './edit-schedule/edit-schedule.component';

const DAILY_SCHEDULE_ROUTE: Routes = [
  {
    path: '', component: DailyScheduleComponent, children: [
    { path: '', component: DailyScheduleListComponent },
    { path: 'list', component: DailyScheduleListComponent },
    { path: 'add/:id', component: DailyScheduleAddComponent },
    { path: 'edit/:id/:scheduleId', component: EditScheduleComponent }
    ]
  },

]

export const DailyScheduleRouting = RouterModule.forChild(DAILY_SCHEDULE_ROUTE);
