﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PasswordComponent } from './password.component';
import { passwordRouting } from './password.route';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
    imports: [
        CommonModule,
        passwordRouting,
        FormsModule,
        ReactiveFormsModule
    ],
    declarations: [PasswordComponent],
 
})
export class PasswordModule { }
