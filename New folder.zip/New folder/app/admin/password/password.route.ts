import { Routes, RouterModule } from '@angular/router';
import { PasswordComponent } from './password.component';

const PASSWORD_ROUTE: Routes = [
  {
    path: '', component: PasswordComponent, children: [
      { path: '', component: PasswordComponent }
    ]
  }
]

export const passwordRouting = RouterModule.forChild(PASSWORD_ROUTE);
