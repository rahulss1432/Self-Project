﻿import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, AbstractControl, ReactiveFormsModule } from '@angular/forms';
import { AuthenticationService } from '../../auth/_services';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'hb-password',
  templateUrl: './password.component.html'
})
export class PasswordComponent implements OnInit {
  resetFormGroup: FormGroup;
  loading = false;

  constructor(
    private toastr: ToastrService,
    private authenticationService: AuthenticationService,
    fb: FormBuilder
  ) {
    this.resetFormGroup = fb.group({
      password: ['', Validators.required],
      currentPassword: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    }, {
        validator: this.MatchPassword
      })
  }

  ngOnInit() {
  }

  onSubmit() {
    this.loading = true;
    this.authenticationService.changePassword(
      this.resetFormGroup.controls['currentPassword'].value,
      this.resetFormGroup.controls['password'].value
    ).subscribe(result => {
      this.toastr.success(result.message);
      this.resetFormGroup.reset();
      this.loading = false;
    },
      (err) => {
        this.toastr.error(err.error.message);
        this.loading = false;
      })
  }

  MatchPassword(AC: AbstractControl) {
    const password = AC.get('password').value;
    const confirmPassword = AC.get('confirmPassword').value;
    if (password !== confirmPassword) {
      AC.get('confirmPassword').setErrors({ MatchPassword: true })
    } else {
      return null
    }
  }

}
