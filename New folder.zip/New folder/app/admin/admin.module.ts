﻿import { CommonService } from './../shared/service/common.service';
import { NgModule, Pipe } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin.component';
import { adminRouting } from './admin.route';
import { HeaderComponent } from '../shared/component/header/header.component';
import { FormsModule } from '@angular/forms';
import { SidebarComponent } from '../shared/component/sidebar/sidebar.component';
import { FooterbarComponent } from '../shared/component/footerbar/footerbar.component';
import { AuthenticationService } from '../auth/_services';
import { AuthGuard } from '../auth/_guards';
import { GlobalConstantService } from '../shared/service/global-constant.service';
import { environment } from '../../environments/environment';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    adminRouting,
  ],
  declarations: [
    AdminComponent,
    HeaderComponent,
    SidebarComponent,
    FooterbarComponent,
  ],
  providers: [AuthenticationService, AuthGuard, CommonService, GlobalConstantService]
})
export class AdminModule { }
