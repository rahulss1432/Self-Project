import { Routes, RouterModule } from '@angular/router';
import { AttendanceComponent } from './attendance.component';

const ATTENDANCE_ROUTE: Routes = [
  {
    path: '', component: AttendanceComponent, children: [
      { path: '', component: AttendanceComponent }
    ]
  }
]

export const attendanceRouting = RouterModule.forChild(ATTENDANCE_ROUTE);
