﻿import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from '../../../../environments/environment';
import { CommonService, RequestOptions } from "../../../shared/service/common.service";
import { AuthenticationService } from "../../../auth/_services";
import 'rxjs/Rx';
import{ map } from "rxjs/operators";
@Injectable()
export class AttendanceService {
  baseUrl = environment.baseUrl;
  constructor(
    private http: HttpClient,
    private authenticationService: AuthenticationService,
    private commonService: CommonService,
    ) {}

  getChildAttendanceDetails(
    page: number,
    child_id: number,
    from_date: string,
    to_date: string,
    pagination: boolean = true
  ) {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });
    // tslint:disable-next-line:max-line-length
    return this.http
      .get(
        this.baseUrl +
          "attendance/child/" +
          child_id +
          "?limit=10&offset=" +
          (page - 1) * 10 +
          "from_date=" +
          from_date +
          "&to_date=" +
          to_date +
        '&pagination=' +
        pagination,
        options
      )
      .pipe(map((response: any) => response))
      .catch(this.commonService.GetHandleErrorString);
  }

  getStaffAttendanceDetails(
    page: number,
    staff_id: number,
    from_date: string,
    to_date: string,
    pagination: boolean = true
  ) {

    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });
    // tslint:disable-next-line:max-line-length
    return this.http
      .get(
        this.baseUrl +
          "attendance/staff/" +
          staff_id +
          "?limit=10&offset=" +
          (page - 1) * 10 +
          "from_date=" +
          from_date +
          "&to_date=" +
          to_date +
          '&pagination=' +
          pagination,
          options
         )
      .pipe(map((response: any) => response))
      .catch(this.commonService.GetHandleErrorString);
  }
}
