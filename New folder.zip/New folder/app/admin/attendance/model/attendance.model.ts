export class Attendance {
  from_date: string;
  to_date: string;
  maxDate: {year: number; month: number; day: number;};
  minDate: {year: number; month: number; day: number;
  };
}
