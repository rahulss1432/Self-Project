import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'hb-attendance',
  templateUrl: './attendance.component.html'
})
export class AttendanceComponent implements OnInit {
@ViewChild('attendancechild') attendanceChild;
@ViewChild('attendancestaff') attendanceStaff;
selectedTab = 1;

  constructor() { }

  ngOnInit() {
  }

  public loadList(tab: any): void {
    if (tab.currentTarget.textContent === 'CHILD') {
        this.selectedTab = 1;
    } else if (tab.currentTarget.textContent === 'STAFF') {
         this.selectedTab = 0;
    }
  }

}
