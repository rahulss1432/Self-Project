import { SharedModule } from "./../../shared/module/shared.module";
import { NgxPaginationModule } from "ngx-pagination";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { AttendanceComponent } from "./attendance.component";
import { attendanceRouting } from "./attendance.route";
import { AttendancechildComponent } from "./attendancechild/attendancechild.component";
import { AttendancestaffComponent } from "./attendancestaff/attendancestaff.component";
import { AttendanceService } from "./service/attendance.service";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpModule } from "@angular/http";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { ChildService } from "../child/service/child.service";
import { StaffService } from "../staff/service/staff.service";

@NgModule({
  imports: [
    CommonModule,
    HttpModule,
    FormsModule,
    NgbModule.forRoot(),
    attendanceRouting,
    NgxPaginationModule,
    SharedModule
  ],
  declarations: [
    AttendanceComponent,
    AttendancechildComponent,
    AttendancestaffComponent
  ],
  providers: [ChildService, StaffService, AttendanceService]
})
export class AttendanceModule {}
