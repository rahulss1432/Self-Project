import { Attendance } from "./../model/attendance.model";
import { Component, OnInit, ViewChild } from "@angular/core";
import { ChildService } from "../../child/service/child.service";
import { AttendanceService } from "../service/attendance.service";
import { NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";
import { AlertService } from "../../../auth/_services";
import {
  FormGroup,
  NgForm,
  FormsModule,
  ReactiveFormsModule
} from "@angular/forms";

@Component({
  selector: "hb-attendancechild",
  templateUrl: './attendancechild.component.html'
})
export class AttendancechildComponent implements OnInit {
  childList: any[] = [];
  attendance = new Attendance();
  p = 1;
  total: number;
  loading: boolean;
  query = "";
  showAttendance = false;
  child_id: number;
  attendanceList: any[] = [];
  selected_child_name = "";
  selected_child_photo = "";
  child: {};
  duration = 0;
  totalHours = 0;
  checkIn: any;
  checkOut: any;
  hrs: number;
  mins: number;
  dur: any;
  totalHrs: any;
  disabled = false;

  today = new Date();
  futureDate: NgbDateStruct = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };
  from_date = {
    year: this.today.getFullYear(),
    month: this.today.getMonth() + 1,
    day: this.today.getDate()
  };
  to_date = {
    year: this.today.getFullYear(),
    month: this.today.getMonth() + 1,
    day: this.today.getDate()
  };
  @ViewChild('from_serch_date') fromDate;
  @ViewChild('to_serch_date') toDate;
  show_hide: boolean;
  constructor(
    private childService: ChildService,
    private alertService: AlertService,
    private attendanceService: AttendanceService
  ) {
    this.attendance = new Attendance();
    this.attendance.from_date = this.from_date.year + "-" + this.from_date.month + "-" + this.from_date.day;
    this.attendance.to_date = this.to_date.year + "-" + this.to_date.month + "-" + this.to_date.day;
  }

  ngOnInit() {
  this.getChildList(1);
    const currentDate = new Date();
    this.attendance.maxDate = { year: currentDate.getFullYear(), month: currentDate.getMonth() + 1, day: currentDate.getDate() };
    this.attendance.minDate = { year: 1950, month: 1, day: 1 };
  }
 
  closeDatepickerFromTo(e, text) {
    if (text == 'from') {
      if (!this.fromDate.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.fromDate.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.fromDate.close();
      }
    }
    else {
      if (!this.toDate.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.toDate.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.toDate.close();
      }
    }
  }

  getChildList(page: number) {
    this.loading = true;
    this.childService.getChildList(page, this.query, "active", false).subscribe(
      (data: any) => {
        this.childList = data.data.rows;
        if (this.childList.length > 0) {
         this.getChildAttendanceDetails(this.childList[0], 1);
         this.show_hide=true;
          //console.log(this.childList[0]);
         return false;
        }
        else
        {
          this.show_hide=false;
          this.getChildAttendanceDetails(0, 1);
        }
        this.total = data.data.total;
        this.p = page;
        this.loading = false;
      },
      err => {
        this.loading = false;
        // this.alertService.ErrorTimeOut(err.error.message);
      }
    );
  }

  setSearchDate(event: any, type) {
    const currentDate = new Date();
    const new_date = new Date(event.year + "-" + event.month + "-" + event.day);
    if (type === 1) {
      /** attendance to date */
    this.attendance.to_date = null;
    this.attendance.minDate = { year: new_date.getFullYear(), month: new_date.getMonth() + 1, day: new_date.getDate() };
    this.from_date = event;
    } else {
      this.to_date = event;
    }
    // console.log(this.from_date);
    // console.log(this.to_date);
  }

  getChildAttendanceDetails(child: any, page: number) {
    this.disabled = true;
    this.loading = true;
    this.showAttendance = true;
    this.child = child;
    this.child_id = child.id;
    this.attendanceList = [];
    const from_date1 = this.from_date.year + "-" + this.from_date.month + "-" + this.from_date.day;
    const to_date1 = this.to_date.year + "-" + this.to_date.month + "-" + this.to_date.day;
    this.attendanceService
      .getChildAttendanceDetails(
        page,
        child.id,
        from_date1 ? from_date1 : "",
        to_date1 ? to_date1 : ""
      )
      .subscribe((data: any) => {
        console.log(data);
        this.duration = 0;
        this.totalHours = 0;
        this.total = 0;
        this.p = 0;
        this.attendance.from_date = "";
        this.attendance.to_date = "";
        this.selected_child_name = child.first_name + " " + child.last_name;
        this.selected_child_photo = child.photo;
        this.attendanceList = data.data.rows;
        this.total = data.data.total;
        this.p = page;
        this.loading = false;
        this.disabled = false;
       // console.log(this.attendanceList);
        return false;
      });
  }

  getHours(checkIn: any, checkOut: any) {
    if (checkIn === null || checkOut === null) {
      this.duration = 0;
      console.log("Check In or Check Out time missing");
    } else {
      this.checkIn = new Date(checkIn);
      this.checkOut = new Date(checkOut);
      this.hrs = Math.abs(this.checkOut.getHours() - this.checkIn.getHours());
      this.mins = Math.abs(
        this.checkOut.getMinutes() - this.checkIn.getMinutes()
      );
      this.duration = (this.hrs * 60 + this.mins) / 60;
    }
    return this.duration;
  }
}