import { NgModule, Pipe } from '@angular/core';
import { ChildComponent } from './child.component';
import { ChildlistComponent } from './childlist/childlist.component';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { childRouting } from './child.routes';
import { ChildlistarchiveComponent } from './childlistarchive/childlistarchive.component';
import { FormsModule } from '@angular/forms';
import { ChildmainComponent } from './childmain/childmain.component';
import { AgePipe } from '../../shared/pipe/age.pipe';
import { SharedModule } from '../../shared/module/shared.module';
import { ChildService } from './service/child.service';
import { ChilddetailComponent } from './childdetail/childdetail.component';
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [
    ChildComponent,
    ChildlistComponent,
    ChilddetailComponent,
    ChildlistarchiveComponent,
    ChildmainComponent,
    AgePipe
  ],
  providers: [
    ChildService
  ],
  imports: [
    CommonModule,
    HttpModule,
    FormsModule,
    NgxPaginationModule,
    childRouting,
    SharedModule,
    ]
})

export class ChildModule { }
