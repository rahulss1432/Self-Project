import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy,
  Pipe
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { ChildService } from '../service/child.service';
import {
  Registration, Doctor, Dentist,
  ParentFather, ParentFatherWorkplace,
  ParentMother, ParentMotherWorkplace,
  ParentGuardian, ParentGuardianWorkplace,
  PrimaryContact, SecondaryContact, AdditionalInfo, Immunization
} from '../../registration/model/registration.model';
import { ApiCountryStateService } from '../../../shared/service/api-country-state.service';
import { Countries } from '../../../shared/model/countries';
import { States } from '../../../shared/model/states';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'hb-childdetail',
  templateUrl: './childdetail.component.html'
})
export class ChilddetailComponent implements OnInit, OnDestroy {
  @Output() clickedToList = new EventEmitter<void>();
  disabled = false;
  childId: number;
  id: string;
  loading: boolean;
  child: any = {};
  private subscription: Subscription;
  childParent: any = {};
  childDetail = new Registration();
  doctor = new Doctor();
  dentist = new Dentist();
  father = new ParentFather();
  fatherWorkplace = new ParentFatherWorkplace();
  mother = new ParentMother();
  motherWorkplace = new ParentMotherWorkplace();
  guardian = new ParentGuardian();
  guardianWorkplace = new ParentGuardianWorkplace();
  primaryContact = new PrimaryContact();
  secondaryContact = new SecondaryContact();
  additionalInfo = new AdditionalInfo();
  fatherWorkplaceExits: any = false;
  motherWorkplaceExits: any = false;
  guardianWorkplaceExits: any = false;
  fatherPrimary: boolean = false;
  motherPrimary: boolean = false;
  guardianPrimary: boolean = false;

  countryData: Countries[];
  stateData: States[];

  doctorCountry: any;
  dentistCountry: any;
  fatherCountry: any;
  fatherWorkplaceCountry: any;
  motherCountry: any;
  motherWorkplaceCountry: any;
  guardianCountry: any;
  guardianWorkplaceCountry: any;
  primaryContactCountry: any;
  secondaryContactCountry: any;
  selectedDoctorCountry: any;
  selectedDentistCountry: any;
  selectedFatherCountry: any;
  selectedFatherWorkplaceCountry: any;
  selectedMotherCountry: any;
  selectedMotherWorkplaceCountry: any;
  selectedGuardianCountry: any;
  selectedGuardianWorkplaceCountry: any;
  selectedPrimaryContactCountry: any;
  selectedSecondaryContactCountry: any;


  doctorState: any;
  dentistState: any;
  fatherState: any;
  fatherWorkplaceState: any;
  motherState: any;
  motherWorkplaceState: any;
  guardianState: any;
  guardianWorkplaceState: any;
  primaryContactState: any;
  secondaryContactState: any;
  selectedDoctorState: any;
  selectedDentistStates: any;
  selectedFatherState: any;
  selectedFatherWorkplaceState: any;
  selectedMotherState: any;
  selectedMotherWorkplaceState: any;
  selectedGuardianState: any;
  selectedGuardianWorkplaceState: any;
  selectedPrimaryContactState: any;
  selectedSecondaryContactState: any;
  checkIn: any;
  checkOut: any;
  program: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private childService: ChildService,
    private _fetchCountry: ApiCountryStateService,
    private toastr: ToastrService
  ) {
    this.subscription = activatedRoute.params.subscribe(
      (param: any) => (this.childId = param['id'])
    );
  }

  ngOnInit() {
    this.getChildDetail(this.childId);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getChildDetail(id: number) {
    this.loading = true;
    this.childService.getChildDetail(id).subscribe((child: any) => {
      this.childDetail = child.data;
      this.doctor = child.data.doctor;
      this.dentist = child.data.dentist;
      this.primaryContact = child.data.primary_contact;
      this.secondaryContact = child.data.secondary_contact;
      this.secondaryContact = child.data.secondary_contact;
      this.father = child.data.child_parents[0].parent.user;
      this.fatherWorkplace = child.data.child_parents[0].parent.work_place;
      this.mother = child.data.child_parents[1].parent.user;
      this.motherWorkplace = child.data.child_parents[1].parent.work_place;
      this.guardian = child.data.child_parents[2].parent.user;
      this.guardianWorkplace = child.data.child_parents[2].parent.work_place;
      this.fatherPrimary = child.data.child_parents[0].parent.is_primary;
      this.motherPrimary = child.data.child_parents[1].parent.is_primary;
      this.guardianPrimary = child.data.child_parents[2].parent.is_primary;

      if( child.data.child_attendances.length>0){
        this.checkIn = child.data.child_attendances[0].check_in;
      }else{
        this.checkIn = '';
      }
      if(child.data.child_attendances.length>0){
        this.checkOut = child.data.child_attendances[0].check_out;
      }else{
        this.checkOut = '';
      }
      if(child.data.program){
        this.program = child.data.program.program_name;
      }else{
        this.program = '';
      }

      // tslint:disable-next-line:max-line-length
      if (this.fatherWorkplace.email || this.fatherWorkplace.phone_number || this.fatherWorkplace.mobile_number || this.fatherWorkplace.address_line1 || this.fatherWorkplace.address_line2 || this.fatherWorkplace.country || this.fatherWorkplace.state || this.fatherWorkplace.city || this.fatherWorkplace.zip_code) {
        this.fatherWorkplaceExits = true;
      }

      // tslint:disable-next-line:max-line-length
      if (this.motherWorkplace.email || this.motherWorkplace.phone_number || this.motherWorkplace.mobile_number || this.motherWorkplace.address_line1 || this.motherWorkplace.address_line2 || this.motherWorkplace.country || this.motherWorkplace.state || this.motherWorkplace.city || this.motherWorkplace.zip_code) {
        this.motherWorkplaceExits = true;
      }

      // tslint:disable-next-line:max-line-length
      if (this.guardianWorkplace.email || this.guardianWorkplace.phone_number || this.guardianWorkplace.mobile_number || this.guardianWorkplace.address_line1 || this.guardianWorkplace.address_line2 || this.guardianWorkplace.country || this.guardianWorkplace.state || this.guardianWorkplace.city || this.guardianWorkplace.zip_code) {
        this.guardianWorkplaceExits = true;
      }

      this._fetchCountry.getCounties()
        .subscribe(
          countryData => {
            this.countryData = countryData['data'].rows;
            if (this.doctor.country) {
              this.doctorCountry = this.countryData.filter(element => {
                return element.id == child.data.doctor.country;
              });
              this.selectedDoctorCountry = this.doctorCountry[0].name;
            }

            if (this.dentist.country) {
              this.dentistCountry = this.countryData.filter(element => {
                return element.id == child.data.dentist.country;
              });
              this.selectedDentistCountry = this.dentistCountry[0].name;
            }

            this.fatherCountry = this.countryData.filter(element => {
              return element.id == child.data.child_parents[0].parent.user.country;
            });
            this.selectedFatherCountry = this.fatherCountry[0].name;

            if (this.fatherWorkplace.country) {
              this.fatherWorkplaceCountry = this.countryData.filter(element => {
                return element.id == child.data.child_parents[0].parent.work_place.country;
              });
              this.selectedFatherWorkplaceCountry = this.fatherWorkplaceCountry[0].name;
            }

            this.motherCountry = this.countryData.filter(element => {
              return element.id == child.data.child_parents[1].parent.user.country;
            });
            this.selectedMotherCountry = this.motherCountry[0].name;

            if (this.motherWorkplace.country) {
              this.motherWorkplaceCountry = this.countryData.filter(element => {
                return element.id == child.data.child_parents[1].parent.work_place.country;
              });
              this.selectedMotherWorkplaceCountry = this.motherWorkplaceCountry[0].name;
            }

            this.guardianCountry = this.countryData.filter(element => {
              return element.id == child.data.child_parents[2].parent.user.country;
            });
            this.selectedGuardianCountry = this.guardianCountry[0].name;

            if (this.guardianWorkplace.country) {
              this.guardianWorkplaceCountry = this.countryData.filter(element => {
                return element.id == child.data.child_parents[2].parent.work_place.country;
              });
              this.selectedGuardianWorkplaceCountry = this.guardianWorkplaceCountry[0].name;
            }

            if (this.primaryContact.country) {
              this.primaryContactCountry = this.countryData.filter(element => {
                return element.id == child.data.primary_contact.country;
              });
              this.selectedPrimaryContactCountry = this.primaryContactCountry[0].name;
            }

            if (this.secondaryContact.country) {
              this.secondaryContactCountry = this.countryData.filter(element => {
                return element.id == child.data.secondary_contact.country;
              });
              this.selectedSecondaryContactCountry = this.secondaryContactCountry[0].name;
            }
          });

      this._fetchCountry.getStates()
        .subscribe(
          stateData => {
            this.stateData = stateData['data'].rows;
            if (this.doctor.state) {
              this.doctorState = this.stateData.filter(element => {
                return element.id == child.data.doctor.state;
              });
              if(this.doctorState.length > 0 ){
                this.selectedDoctorState = this.doctorState[0].state_name;
              }
            }

            if (this.dentist.state) {
              this.dentistState = this.stateData.filter(element => {
                return element.id == child.data.dentist.state;
              });
              this.selectedDentistStates = this.dentistState[0].state_name;
            }

            this.fatherState = this.stateData.filter(element => {
              return element.id == child.data.child_parents[0].parent.user.state;
            });

            this.selectedFatherState = this.fatherState[0].state_name;

            if (this.fatherWorkplace.state) {
              this.fatherWorkplaceState = this.stateData.filter(element => {
                return element.id == child.data.child_parents[0].parent.work_place.state;
              });
              this.selectedFatherWorkplaceState = this.fatherWorkplaceState[0].state_name;
            }

            this.motherState = this.stateData.filter(element => {
              return element.id == child.data.child_parents[1].parent.user.state;
            });
            this.selectedMotherState = this.motherState[0].state_name;

            if (this.motherWorkplace.state) {
              this.motherWorkplaceState = this.stateData.filter(element => {
                return element.id == child.data.child_parents[1].parent.work_place.state;
              });
              this.selectedMotherWorkplaceState = this.motherWorkplaceState[0].state_name;
            }

            this.guardianState = this.stateData.filter(element => {
              return element.id == child.data.child_parents[2].parent.user.state;
            });
            this.selectedGuardianState = this.guardianState[0].state_name;

            if (this.guardianWorkplace.state) {
              this.guardianWorkplaceState = this.stateData.filter(element => {
                return element.id == child.data.child_parents[2].parent.work_place.state;
              });
              this.selectedGuardianWorkplaceState = this.guardianWorkplaceState[0].state_name;
            }

            if (this.primaryContact.state) {
              this.primaryContactState = this.stateData.filter(element => {
                return element.id == child.data.primary_contact.state;
              });
              this.selectedPrimaryContactState = this.primaryContactState[0].state_name;
            }

            if (this.secondaryContact.state) {
              this.secondaryContactState = this.stateData.filter(element => {
                return element.id == child.data.secondary_contact.state;
              });
              this.selectedSecondaryContactState = this.secondaryContactState[0].state_name;
            }

          });
      this.loading = false;
    },
      err => {
        if (err.error.error.length) {
          err.error.error.map((e, i) => {
            this.toastr.error(err.error.error[i].message);
          });
          this.loading = false;
          this.disabled = false;
        }
        else {
          this.toastr.error('Something went wrong');
        }
      });
  }
}
