import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'hb-childmain',
  templateUrl: './childmain.component.html'
})
export class ChildmainComponent implements OnInit {
@ViewChild('archiveList') archiveList;
@ViewChild('childlist') childlist;
selectedTab = 1;
  constructor() { }

  ngOnInit() {
  }

  public loadList(tab: any): void {
    if (tab.currentTarget.textContent === 'ACTIVE') {
        this.childlist.getChildList(1);
        this.selectedTab = 1;
    } else if (tab.currentTarget.textContent === 'ARCHIVED') {
        this.archiveList.getChildList(1);
         this.selectedTab = 0;
    }
  }

}
