﻿import { Component, OnInit } from '@angular/core';
import { AlertService } from '../../../auth/_services';
import { ChildService } from '../service/child.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'hb-childlistarchive',
  templateUrl: './childlistarchive.component.html'
})
export class ChildlistarchiveComponent implements OnInit {
  childList: any[] = [];
  p = 1;
  total: number;
  loading: boolean;
  query = '';
  disabled = false;

  constructor(
    private childService: ChildService,
    private alertService: AlertService,
    private toastr: ToastrService,
  ) {}

  ngOnInit() {}

  getChildList(page: number) {
    this.loading = true;
    this.childService.getChildList(page, this.query, 'inactive').subscribe(
      (data: any) => {
        this.childList = data.data.rows;
        this.total = data.data.total;
        this.p = page;
        this.loading = false;
      },
      err => {
        if (err.error.error.length) {
          err.error.error.map((e, i) => {
            this.toastr.error(err.error.error[i].message);
          });
          this.loading = false;
          this.disabled = false;
        }
        
      });
  }

  unarchivedChild(id: number, index: number) {
    this.childService.updateStatus(id, 'active').subscribe(
      result => {
        if (result.success === true) {
          this.childList.splice(index, 1);
          this.toastr.success(result.message);
        }
        this.loading = false;
      },
      err => {
        if (err.error.error.length) {
          err.error.error.map((e, i) => {
            this.toastr.error(err.error.error[i].message);
          });
          this.loading = false;
          this.disabled = false;
        }
                
      });
  }
}
