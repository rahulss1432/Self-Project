﻿
import { Routes, RouterModule } from '@angular/router';
import { ChildComponent } from './child.component';
import { ChildmainComponent } from './childmain/childmain.component';
import { ChilddetailComponent } from './childdetail/childdetail.component';

const CHILD_ROUTE: Routes = [
  {
    path: '', component: ChildComponent, children: [
      { path: '', component: ChildmainComponent },
      { path: 'list', component: ChildmainComponent },
      { path: 'detail/:id', component: ChilddetailComponent },
      { path: 'edit/:id', loadChildren: '../registration/registration.module#RegistrationModule'}
    ]
  }
];

export const childRouting = RouterModule.forChild(CHILD_ROUTE);
