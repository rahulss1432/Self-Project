import { Component } from '@angular/core';
// import { TabsetComponent } from 'ngx-bootstrap';
import { Router } from '@angular/router';

@Component({
  selector: 'hb-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css'],
})
export class ChildComponent {

  constructor(private router: Router) { }
}
