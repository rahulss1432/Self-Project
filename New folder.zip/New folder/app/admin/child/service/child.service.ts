﻿import { environment } from '../../../../environments/environment';
import { Registration, Doctor } from '../../registration/model/registration.model';
import { Injectable } from '@angular/core';
import 'rxjs/Rx';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../../../auth/_services/authentication.service';
import { RequestOptions } from '../../../shared/service/request-option';
import { CommonService } from '../../../shared/service/common.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({ providedIn: 'root' })

export class ChildService {
  baseUrl = environment.baseUrl;
  constructor(
    private http: HttpClient,
    private authenticationService: AuthenticationService,
    private commonService: CommonService,
  ) { }
  photoArray = [];
  docArray = [];
  doc1Array = [];
  getChildList(
    page: number,
    query: string,
    status: string,
    pagination: boolean = true
  ) {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });

    return this.http
      .get(
        this.baseUrl +
        'child/' +
        status +
        '?limit=10&offset=' +
        (page - 1) * 10 +
        '&q=' +
        query +
        '&pagination=' +
        pagination,
        options
      )
      .map((response: any) => response);
  }

  updateStatus(id: number, status: string) {
    const arrayStatus = [{ status: status }];
    // const urlSearchParams = this.commonService.getURLSearchParamsObject(
    //   arrayStatus
    // );
    // const body = urlSearchParams.toString();
    const body = arrayStatus[0];
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });
    return this.http
      .post(
        this.baseUrl + 'child/' + id + '/status',
        body,
        options
      )
      .map((response: any) => {
        const data = response && response.data;
        return response;
      })
      .catch(this.commonService.GetHandleErrorString);
  }

  getChildDetail(id: number) {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });

    return this.http
      .get(this.baseUrl + 'child/' + id, options)
      .map((response: any) => response);
  }


  addChildRegistration(
    registration1,
    registration2,
    registration3,
    registration4,
    registration5,
    registration6,
    file: any,
    fileDoc: any,
    fileDoc1: any,


  ) {
    const headers = this.commonService.getFormDataHeader();
    const options = new RequestOptions({ headers: headers });
    const formData = new FormData();
    formData.append("photo", file);   
    formData.append("document_file", fileDoc);   
    formData.append("document_file1", fileDoc1);   
    formData.append(
      "center_id",
      this.authenticationService.getUserDetail().center_id
    );
    formData.append("program_id", registration1.program_id);
    formData.append("first_name", registration1.first_name);
    formData.append("last_name", registration1.last_name);
    formData.append("date_of_birth", registration1.date_of_birth);
    formData.append("gender", registration1.gender);
    formData.append("sibling_name", registration1.sibling_name);


    formData.append(
      "medical_problem",
      registration2.medical_problem ? registration2.medical_problem : ""
    );
    formData.append(
      "special_requirement",
      registration2.special_requirement ? registration2.special_requirement : ""
    );
    formData.append(
      "doctor_first_name",
      registration2.doctor_first_name ? registration2.doctor_first_name : ""
    );
    formData.append(
      "doctor_last_name",
      registration2.doctor_last_name ? registration2.doctor_last_name : ""
    );
    formData.append(
      "doctor_email",
      registration2.doctor_email ? registration2.doctor_email : ""
    );
    formData.append(
      "doctor_phone_number",
      registration2.doctor_phone_number ? registration2.doctor_phone_number : ""
    );
    formData.append(
      "doctor_mobile_number",
      registration2.doctor_mobile_number
        ? registration2.doctor_mobile_number
        : ""
    );
    formData.append(
      "doctor_address_line1",
      registration2.doctor_address_line1
        ? registration2.doctor_address_line1
        : ""
    );
    formData.append(
      "doctor_address_line2",
      registration2.doctor_address_line2
        ? registration2.doctor_address_line2
        : ""
    );
    formData.append(
      "doctor_country",
      registration2.doctor_country ? registration2.doctor_country : ""
    );
    formData.append(
      "doctor_state",
      registration2.doctor_state ? registration2.doctor_state : ""
    );
    formData.append(
      "doctor_city",
      registration2.doctor_city ? registration2.doctor_city : ""
    );
    formData.append(
      "doctor_zip_code",
      registration2.doctor_zip_code ? registration2.doctor_zip_code : ""
    );
    formData.append(
      "dentist_first_name",
      registration2.dentist_first_name ? registration2.dentist_first_name : ""
    );
    formData.append(
      "dentist_last_name",
      registration2.dentist_last_name ? registration2.dentist_last_name : ""
    );
    formData.append(
      "dentist_email",
      registration2.dentist_email ? registration2.dentist_email : ""
    );
    formData.append(
      "dentist_phone_number",
      registration2.dentist_phone_number
        ? registration2.dentist_phone_number
        : ""
    );
    formData.append(
      "dentist_mobile_number",
      registration2.dentist_mobile_number
        ? registration2.dentist_mobile_number
        : ""
    );
    formData.append(
      "dentist_address_line1",
      registration2.dentist_address_line1
        ? registration2.dentist_address_line1
        : ""
    );
    formData.append(
      "dentist_address_line2",
      registration2.dentist_address_line2
        ? registration2.dentist_address_line2
        : ""
    );
    formData.append(
      "dentist_country",
      registration2.dentist_country ? registration2.dentist_country : ""
    );
    formData.append(
      "dentist_state",
      registration2.dentist_state ? registration2.dentist_state : ""
    );
    formData.append(
      "dentist_city",
      registration2.dentist_city ? registration2.dentist_city : ""
    );
    formData.append(
      "dentist_zip_code",
      registration2.dentist_zip_code ? registration2.dentist_zip_code : ""
    );

    formData.append("vaccination[]", "BCG");
    formData.append("vaccination[]", "HepB");
    formData.append("vaccination[]", "Poliovirus");
    formData.append("vaccination[]", "DTP");
    formData.append("vaccination[]", "Hib");
    formData.append("vaccination[]", "PCV");
    formData.append("vaccination[]", "RV");
    formData.append("vaccination[]", "Typhoid");
    formData.append("vaccination[]", "MMR");
    formData.append("vaccination[]", "Varicella");
    formData.append("vaccination[]", "HepA");
    formData.append("vaccination[]", "Tdap");
    formData.append("vaccination[]", "HPV");
    formData.append("prevents[]", "TB & bladder cancer");
    formData.append("prevents[]", "Hepatitis B");
    formData.append("prevents[]", "Polio");
    formData.append("prevents[]", "Diphtheria,Tetanus & Pertussis");
    formData.append("prevents[]", "Infections caused by Bacteria");
    formData.append("prevents[]", "Pneumonia");
    formData.append("prevents[]", "Severe Diarrheal Disease");
    formData.append("prevents[]", "Typhoid Fever, Diarrhea");
    formData.append("prevents[]", "Measles, Mumps & Rubella");
    formData.append("prevents[]", "Chickenpox");
    formData.append("prevents[]", "Liver disease");
    formData.append("prevents[]", "Diphtheria, Tetanus & Pertussis");
    formData.append("prevents[]", "Some Cancers & Warts");
    formData.append("no_of_dose[]", "1");
    formData.append("no_of_dose[]", "3");
    formData.append("no_of_dose[]", "3");
    formData.append("no_of_dose[]", "5");
    formData.append("no_of_dose[]", "4");
    formData.append("no_of_dose[]", "4");
    formData.append("no_of_dose[]", "3");
    formData.append("no_of_dose[]", "2");
    formData.append("no_of_dose[]", "2");
    formData.append("no_of_dose[]", "2");
    formData.append("no_of_dose[]", "2");
    formData.append("no_of_dose[]", "1");
    formData.append("no_of_dose[]", "3");
    formData.append(
      "BCG[]",
      registration3.bcg_dose1 ? registration3.bcg_dose1 : ""
    );
    formData.append(
      "HepB[]",
      registration3.hepB_dose1 ? registration3.hepB_dose1 : ""
    );
    formData.append(
      "HepB[]",
      registration3.hepB_dose2 ? registration3.hepB_dose2 : ""
    );
    formData.append(
      "HepB[]",
      registration3.hepB_dose3 ? registration3.hepB_dose3 : ""
    );
    formData.append(
      "Poliovirus[]",
      registration3.poliovirus_dose1 ? registration3.poliovirus_dose1 : ""
    );
    formData.append(
      "Poliovirus[]",
      registration3.poliovirus_dose2 ? registration3.poliovirus_dose2 : ""
    );
    formData.append(
      "Poliovirus[]",
      registration3.poliovirus_dose3 ? registration3.poliovirus_dose3 : ""
    );
    formData.append(
      "DTP[]",
      registration3.dtp_dose1 ? registration3.dtp_dose1 : ""
    );
    formData.append(
      "DTP[]",
      registration3.dtp_dose2 ? registration3.dtp_dose2 : ""
    );
    formData.append(
      "DTP[]",
      registration3.dtp_dose3 ? registration3.dtp_dose3 : ""
    );
    formData.append(
      "DTP[]",
      registration3.dtp_dose4 ? registration3.dtp_dose4 : ""
    );
    formData.append(
      "DTP[]",
      registration3.dtp_dose5 ? registration3.dtp_dose5 : ""
    );
    formData.append(
      "Hib[]",
      registration3.hib_dose1 ? registration3.hib_dose1 : ""
    );
    formData.append(
      "Hib[]",
      registration3.hib_dose2 ? registration3.hib_dose2 : ""
    );
    formData.append(
      "Hib[]",
      registration3.hib_dose3 ? registration3.hib_dose3 : ""
    );
    formData.append(
      "Hib[]",
      registration3.hib_dose4 ? registration3.hib_dose4 : ""
    );
    formData.append(
      "PCV[]",
      registration3.pcv_dose1 ? registration3.pcv_dose1 : ""
    );
    formData.append(
      "PCV[]",
      registration3.pcv_dose2 ? registration3.pcv_dose2 : ""
    );
    formData.append(
      "PCV[]",
      registration3.pcv_dose3 ? registration3.pcv_dose3 : ""
    );
    formData.append(
      "PCV[]",
      registration3.pcv_dose4 ? registration3.pcv_dose4 : ""
    );
    formData.append(
      "RV[]",
      registration3.rv_dose1 ? registration3.rv_dose1 : ""
    );
    formData.append(
      "RV[]",
      registration3.rv_dose2 ? registration3.rv_dose2 : ""
    );
    formData.append(
      "RV[]",
      registration3.rv_dose3 ? registration3.rv_dose3 : ""
    );
    formData.append(
      "Typhoid[]",
      registration3.typhoid_dose1 ? registration3.typhoid_dose1 : ""
    );
    formData.append(
      "Typhoid[]",
      registration3.typhoid_dose2 ? registration3.typhoid_dose2 : ""
    );
    formData.append(
      "MMR[]",
      registration3.mmr_dose1 ? registration3.mmr_dose1 : ""
    );
    formData.append(
      "MMR[]",
      registration3.mmr_dose2 ? registration3.mmr_dose2 : ""
    );
    formData.append(
      "Varicella[]",
      registration3.varicella_dose1 ? registration3.varicella_dose1 : ""
    );
    formData.append(
      "Varicella[]",
      registration3.varicella_dose2 ? registration3.varicella_dose2 : ""
    );
    formData.append(
      "HepA[]",
      registration3.hepA_dose1 ? registration3.hepA_dose1 : ""
    );
    formData.append(
      "HepA[]",
      registration3.hepA_dose2 ? registration3.hepA_dose2 : ""
    );
    formData.append(
      "Tdap[]",
      registration3.tdap_dose1 ? registration3.tdap_dose1 : ""
    );
    formData.append(
      "HPV[]",
      registration3.hpv_dose1 ? registration3.hpv_dose1 : ""
    );
    formData.append(
      "HPV[]",
      registration3.hpv_dose2 ? registration3.hpv_dose2 : ""
    );
    formData.append(
      "HPV[]",
      registration3.hpv_dose3 ? registration3.hpv_dose3 : ""
    );

    formData.append("is_primary", registration4.isPrimary);
    formData.append("father_first_name", registration4.father_first_name);
    formData.append("father_last_name", registration4.father_last_name);
    formData.append("father_email", registration4.father_email);
    formData.append(
      "father_phone_number",
      registration4.father_phone_number ? registration4.father_phone_number : ""
    );
    formData.append("father_mobile_number", registration4.father_mobile_number);
    formData.append("father_address_line1", registration4.father_address_line1);
    formData.append(
      "father_address_line2",
      registration4.father_address_line2
        ? registration4.father_address_line2
        : ""
    );
    formData.append(
      "father_country",
      registration4.father_country ? registration4.father_country : ""
    );
    formData.append(
      "father_state",
      registration4.father_state ? registration4.father_state : ""
    );
    formData.append(
      "father_city",
      registration4.father_city ? registration4.father_city : ""
    );
    formData.append("father_zip_code", registration4.father_zip_code);
    formData.append(
      "father_workplace_email",
      registration4.father_workplace_email
        ? registration4.father_workplace_email
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "father_workplace_phone_number",
      registration4.father_workplace_phone_number
        ? registration4.father_workplace_phone_number
        : ""
    );
    formData.append(
      "father_workplace_mobile_number",
      registration4.father_workplace_mobile_number
        ? registration4.father_workplace_mobile_number
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "father_workplace_address_line1",
      registration4.father_workplace_address_line1
        ? registration4.father_workplace_address_line1
        : ""
    );
    formData.append(
      "father_workplace_address_line2",
      registration4.father_workplace_address_line2
        ? registration4.father_workplace_address_line2
        : ""
    );
    formData.append(
      "father_workplace_country",
      registration4.father_workplace_country
        ? registration4.father_workplace_country
        : ""
    );
    formData.append(
      "father_workplace_state",
      registration4.father_workplace_state
        ? registration4.father_workplace_state
        : ""
    );
    formData.append(
      "father_workplace_city",
      registration4.father_workplace_city
        ? registration4.father_workplace_city
        : ""
    );
    formData.append(
      "father_workplace_zip_code",
      registration4.father_workplace_zip_code
        ? registration4.father_workplace_zip_code
        : ""
    );
    formData.append("mother_first_name", registration4.mother_first_name);
    formData.append("mother_last_name", registration4.mother_last_name);
    formData.append("mother_email", registration4.mother_email);
    formData.append(
      "mother_phone_number",
      registration4.mother_phone_number ? registration4.mother_phone_number : ""
    );
    formData.append("mother_mobile_number", registration4.mother_mobile_number);
    formData.append("mother_address_line1", registration4.mother_address_line1);
    formData.append(
      "mother_address_line2",
      registration4.mother_address_line2
        ? registration4.mother_address_line2
        : ""
    );
    formData.append(
      "mother_country",
      registration4.mother_country ? registration4.mother_country : ""
    );
    formData.append(
      "mother_state",
      registration4.mother_state ? registration4.mother_state : ""
    );
    formData.append(
      "mother_city",
      registration4.mother_city ? registration4.mother_city : ""
    );
    formData.append("mother_zip_code", registration4.mother_zip_code);
    formData.append(
      "mother_workplace_email",
      registration4.mother_workplace_email
        ? registration4.mother_workplace_email
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "mother_workplace_phone_number",
      registration4.mother_workplace_phone_number
        ? registration4.mother_workplace_phone_number
        : ""
    );
    formData.append(
      "mother_workplace_mobile_number",
      registration4.mother_workplace_mobile_number
        ? registration4.mother_workplace_mobile_number
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "mother_workplace_address_line1",
      registration4.mother_workplace_address_line1
        ? registration4.mother_workplace_address_line1
        : ""
    );
    formData.append(
      "mother_workplace_address_line2",
      registration4.mother_workplace_address_line2
        ? registration4.mother_workplace_address_line2
        : ""
    );
    formData.append(
      "mother_workplace_country",
      registration4.mother_workplace_country
        ? registration4.mother_workplace_country
        : ""
    );
    formData.append(
      "mother_workplace_state",
      registration4.mother_workplace_state
        ? registration4.mother_workplace_state
        : ""
    );
    formData.append(
      "mother_workplace_city",
      registration4.mother_workplace_city
        ? registration4.mother_workplace_city
        : ""
    );
    formData.append(
      "mother_workplace_zip_code",
      registration4.mother_workplace_zip_code
        ? registration4.mother_workplace_zip_code
        : ""
    );
    formData.append("guardian_first_name", registration4.guardian_first_name);
    formData.append("guardian_last_name", registration4.guardian_last_name);
    formData.append("guardian_email", registration4.guardian_email);
    formData.append(
      "guardian_phone_number",
      registration4.guardian_phone_number
        ? registration4.guardian_phone_number
        : ""
    );
    formData.append(
      "guardian_mobile_number",
      registration4.guardian_mobile_number
    );
    formData.append(
      "guardian_address_line1",
      registration4.guardian_address_line1
    );
    formData.append(
      "guardian_address_line2",
      registration4.guardian_address_line2
        ? registration4.guardian_address_line2
        : ""
    );
    formData.append(
      "guardian_country",
      registration4.guardian_country ? registration4.guardian_country : ""
    );
    formData.append(
      "guardian_state",
      registration4.guardian_state ? registration4.guardian_state : ""
    );
    formData.append(
      "guardian_city",
      registration4.guardian_city ? registration4.guardian_city : ""
    );
    formData.append("guardian_zip_code", registration4.guardian_zip_code);
    formData.append(
      "guardian_workplace_email",
      registration4.guardian_workplace_email
        ? registration4.guardian_workplace_email
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "guardian_workplace_phone_number",
      registration4.guardian_workplace_phone_number
        ? registration4.guardian_workplace_phone_number
        : ""
    );
    formData.append(
      "guardian_workplace_mobile_number",
      registration4.guardian_workplace_mobile_number
        ? registration4.guardian_workplace_mobile_number
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "guardian_workplace_address_line1",
      registration4.guardian_workplace_address_line1
        ? registration4.guardian_workplace_address_line1
        : ""
    );
    formData.append(
      "guardian_workplace_address_line2",
      registration4.guardian_workplace_address_line2
        ? registration4.guardian_workplace_address_line2
        : ""
    );
    formData.append(
      "guardian_workplace_country",
      registration4.guardian_workplace_country
        ? registration4.guardian_workplace_country
        : ""
    );
    formData.append(
      "guardian_workplace_state",
      registration4.guardian_workplace_state
        ? registration4.guardian_workplace_state
        : ""
    );
    formData.append(
      "guardian_workplace_city",
      registration4.guardian_workplace_city
        ? registration4.guardian_workplace_city
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "guardian_workplace_zip_code",
      registration4.guardian_workplace_zip_code
        ? registration4.guardian_workplace_zip_code
        : ""
    );

    formData.append(
      "primary_contact_first_name",
      registration5.primary_contact_first_name
        ? registration5.primary_contact_first_name
        : ""
    );
    formData.append(
      "primary_contact_last_name",
      registration5.primary_contact_last_name
        ? registration5.primary_contact_last_name
        : ""
    );
    formData.append(
      "primary_contact_relation",
      registration5.primary_contact_relation
        ? registration5.primary_contact_relation
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "primary_contact_is_release_child",
      registration5.primary_contact_is_release_child
        ? registration5.primary_contact_is_release_child
        : ""
    );
    formData.append(
      "primary_contact_email",
      registration5.primary_contact_email
        ? registration5.primary_contact_email
        : ""
    );
    formData.append(
      "primary_contact_phone_number",
      registration5.primary_contact_phone_number
        ? registration5.primary_contact_phone_number
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "primary_contact_mobile_number",
      registration5.primary_contact_mobile_number
        ? registration5.primary_contact_mobile_number
        : ""
    );
    formData.append(
      "primary_contact_address_line1",
      registration5.primary_contact_address_line1
        ? registration5.primary_contact_address_line1
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "primary_contact_address_line2",
      registration5.primary_contact_address_line2
        ? registration5.primary_contact_address_line2
        : ""
    );
    formData.append(
      "primary_contact_country",
      registration5.primary_contact_country
        ? registration5.primary_contact_country
        : ""
    );
    formData.append(
      "primary_contact_state",
      registration5.primary_contact_state
        ? registration5.primary_contact_state
        : ""
    );
    formData.append(
      "primary_contact_city",
      registration5.primary_contact_city
        ? registration5.primary_contact_city
        : ""
    );
    formData.append(
      "primary_contact_zip_code",
      registration5.primary_contact_zip_code
        ? registration5.primary_contact_zip_code
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "secondary_contact_first_name",
      registration5.secondary_contact_first_name
        ? registration5.secondary_contact_first_name
        : ""
    );
    formData.append(
      "secondary_contact_last_name",
      registration5.secondary_contact_last_name
        ? registration5.secondary_contact_last_name
        : ""
    );
    formData.append(
      "secondary_contact_relation",
      registration5.secondary_contact_relation
        ? registration5.secondary_contact_relation
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "secondary_contact_is_release_child",
      registration5.secondary_contact_is_release_child
        ? registration5.secondary_contact_is_release_child
        : ""
    );
    formData.append(
      "secondary_contact_email",
      registration5.secondary_contact_email
        ? registration5.secondary_contact_email
        : ""
    );
    formData.append(
      "secondary_contact_phone_number",
      registration5.secondary_contact_phone_number
        ? registration5.secondary_contact_phone_number
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "secondary_contact_mobile_number",
      registration5.secondary_contact_mobile_number
        ? registration5.secondary_contact_mobile_number
        : ""
    );
    formData.append(
      "secondary_contact_address_line1",
      registration5.secondary_contact_address_line1
        ? registration5.secondary_contact_address_line1
        : ""
    );
    // tslint:disable-next-line:max-line-length
    formData.append(
      "secondary_contact_address_line2",
      registration5.secondary_contact_address_line2
        ? registration5.secondary_contact_address_line2
        : ""
    );
    formData.append(
      "secondary_contact_country",
      registration5.secondary_contact_country
        ? registration5.secondary_contact_country
        : ""
    );
    formData.append(
      "secondary_contact_state",
      registration5.secondary_contact_state
        ? registration5.secondary_contact_state
        : ""
    );
    formData.append(
      "secondary_contact_city",
      registration5.secondary_contact_city
        ? registration5.secondary_contact_city
        : ""
    );
    formData.append(
      "secondary_contact_zip_code",
      registration5.secondary_contact_zip_code
        ? registration5.secondary_contact_zip_code
        : ""
    );

    formData.append(
      "language",
      registration6.language ? registration6.language : ""
    );
    formData.append(
      "custody",
      registration6.custody ? registration6.custody : ""
    );
    formData.append("notes", registration6.notes ? registration6.notes : "");
    formData.append('document_title', registration6.document_title ? registration6.document_title : '')
    formData.append('document_title1', registration6.document_title1 ? registration6.document_title1 : '');
    formData.append('document_old_file', registration6.document_old_file ? registration6.document_old_file : '')
    formData.append('document_old_file1', registration6.document_old_file1 ? registration6.document_old_file1 : '');

    if (registration1.childId) {
      const a = this.http.post(this.baseUrl + "child/" + registration1.childId,
        formData,
        options);
      return a.map((response: any) => {
        const data = response && response.data;
        return response;
      }).catch(this.commonService.GetHandleErrorString);
    } else {
      return this.http
        .post(this.baseUrl + "child", formData, options)
        .map((response: any) => {
          const data = response && response.data;
          return response;
        }).catch(this.commonService.GetHandleErrorString);
    }



  }

  getSiblingByName(name: string) {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });
    return this.http
      .get(this.baseUrl + 'child/sibling/' + name, options)
      .map((response: any) => response);
  }

  private handleError(error: any) {
    return Observable.throw(error.json());
  }
}
