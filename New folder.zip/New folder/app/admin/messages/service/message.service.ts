﻿
import { Injectable } from "@angular/core";
import { Message } from "./../model/message.model";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from '../../../../environments/environment';
import { AuthenticationService } from "../../../auth/_services";
import { CommonService } from "../../../shared/service/common.service";
import { pipe } from "rxjs";
import { map, catchError } from "rxjs/operators";

@Injectable()
export class MessageService {
     baseUrl = environment.baseUrl;
  constructor(
    private http: HttpClient,
    private authenticationService: AuthenticationService,
    private commonService: CommonService,
      ) { }

  getUserList(query: string) {
    return this.http
      .get(
      this.baseUrl + "/user/message_group?q=" + query,
      {
        headers: this.commonService.getHeadersObject(null, true, true)
      }
      ).pipe(
      map((response: any) => response),
      catchError(this.commonService.GetHandleErrorString));
  }

  getMessages(message_group_id: string) {
    return this.http
      .get(
      this.baseUrl +
      "/user/message_group/" +
      message_group_id +
      "/message",
      { headers: this.commonService.getHeadersObject(null, true, true) }
      ).pipe(
      map((response: any) => response),
      catchError(this.commonService.GetHandleErrorString));
  }

  sendMessage(message: Message, message_group_id: string) {
    const urlSearchParams = this.commonService.getURLSearchParamsObject(
      message
    );
    const body = urlSearchParams.toString();
    return this.http
      .post(
      this.baseUrl +
      "/user/message_group/" +
      message_group_id +
      "/message",
      body,
      { headers: this.commonService.getHeadersObject(null, true, true) }
      ).pipe
      (map((response: any) => {
        const data = response && response.data;
        return response;
      }),
      catchError(this.commonService.GetHandleErrorString));
  }
}
