﻿
import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { FormGroup, NgForm, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MessageService } from "./service/message.service";
import { Message } from "./model/message.model";
import { AlertService, AuthenticationService } from "../../auth/_services";
import { CommonService } from "../../shared/service/common.service";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "hb-messages",
  templateUrl: "./messages.component.html"
})
export class MessagesComponent implements OnInit {
  @ViewChild('scrollMe') private myScrollContainer: ElementRef;
  userList: any[] = [];
  showMessage = false;
  message = new Message();
  loading = false;
  errorData = "";
  message_group_id: string;
  id: number;
  messageList: any[] = [];
  query = "";
 
  constructor(
    private messageService: MessageService,
    private alertService: AlertService,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    private toaster: ToastrService
  ) {
    this.message = new Message();
  }

  ngOnInit() {
    this.getUserList(1);
    this.id = this.authenticationService.getUserDetail().id;
    this.scrollToBottom();
  }
  ngAfterViewChecked() {
    this.scrollToBottom();
}
scrollToBottom(): void {
  try {
      this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
  } catch(err) { }                 
}
  getUserList(page: number) {
    this.loading = true;
    this.messageService.getUserList(this.query).subscribe(
      (data: any) => {
        this.userList = data.data;
     
        if (this.userList.length > 0) {
          this.getMessages(this.userList[0].id);
          this.loading = false;
        }
        else
        {
          this.messageList =[];
          this.loading = false;
        }
      },
      err => {
        this.alertService.error(err.message);
        this.loading = false;
      });
  }

  getMessages(message_group_id: string) {
    this.showMessage = true;
    this.message_group_id = message_group_id;
    this.messageList = [];
    this.messageService.getMessages(message_group_id).subscribe((data: any) => {
      this.messageList = data.data.rows;
      this.scrollToBottom();
    });
  }

  sendMessage(messageForm: NgForm) {
    this.errorData = "";
    if(messageForm.value.message == '' || messageForm.value.message == undefined || messageForm.value.message == null)
    {
     
    }
    else {
    this.loading = true;
    this.messageService
      .sendMessage(messageForm.value, this.message_group_id)
      .subscribe(
      result => {
        if (result.success === true) {
          this.toaster.success('Message sent successfully');
          this.messageList.push({
            message: messageForm.value.message,
            user_id: this.id,
            created_at: new Date()
          });
          this.message = new Message();
          this.getUserList(1);
        } else {
          this.errorData = this.commonService.GetHandleMultilineErrorString(
            result.error
          );
          this.alertService.error(this.errorData);
        }
        this.loading = false;
      },
      err => {
        this.errorData = this.commonService.GetHandleMultilineErrorString(
          err.error
        );
        this.alertService.error(this.errorData);
        this.loading = false;
      });
    }
  }

  chop_string(str :any) {
 
    if(str.length > 30) 
    {
      str = str.substring(0,30);

      return str+'...';
    }
  
        return str;
    }  

  // changeData(data) {
  // }
}
