import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { MessagesComponent } from "./messages.component";
import { messagesRouting } from "./messages.route";
import { MessageService } from "./service/message.service";
import { HttpModule } from "@angular/http";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { SharedModule } from "../../shared/module/shared.module";

@NgModule({
  imports: [CommonModule, messagesRouting, FormsModule, SharedModule],
  declarations: [MessagesComponent],
  providers: [MessageService]
})
export class MessagesModule {}
