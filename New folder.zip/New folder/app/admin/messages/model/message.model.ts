export class Message {
  message_group_id: string;
  message: string;
}
