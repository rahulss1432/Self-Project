import { Routes, RouterModule } from '@angular/router';
import { MessagesComponent } from './messages.component';

const MESSAGES_ROUTE: Routes = [
  {
    path: '', component: MessagesComponent, children: [
      { path: '', component: MessagesComponent }
    ]
  }
]

export const messagesRouting = RouterModule.forChild(MESSAGES_ROUTE);
