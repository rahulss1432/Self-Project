import { EventService } from './service/event.service';
import { EventUpcomingListComponent } from './event-upcoming-list/event-upcoming-list.component';
import { EventComponent } from './event.component';
import { EventAddComponent } from './event-add/event-add.component';
import { EventRouting } from './event.routes';

import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/module/shared.module';
import { HttpModule } from '@angular/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxPaginationModule } from 'ngx-pagination';
import { EventDetailComponent } from './event-detail/event-detail.component';
import localeEnGb from '@angular/common/locales/en-GB'

@NgModule({
  imports: [
    FormsModule,
    SharedModule,
    EventRouting,
    HttpModule,
    SharedModule,
    NgbModule.forRoot(),
    NgxPaginationModule
  ],
  declarations: [
    EventComponent,
    EventUpcomingListComponent,
    EventAddComponent,
    EventDetailComponent
  ],
  providers: [EventService]
})
export class EventModule { }
