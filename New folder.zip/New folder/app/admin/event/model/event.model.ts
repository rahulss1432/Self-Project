export class Event {
  category: string = '';
  center_id: number;
  description: string;
  event_date: string;
  event_end_time: string;
  event_start_time: string;
  id: number;
  name: string;
  venue: string;
  venue_image: string;
  from_date: string;
  to_date: string;
  created_at: Date;
  updated_at: Date;
}
