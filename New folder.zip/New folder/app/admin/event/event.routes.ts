import { EventUpcomingListComponent } from './event-upcoming-list/event-upcoming-list.component';
import { EventComponent } from './event.component';
import { EventAddComponent } from './event-add/event-add.component';
import { Routes, RouterModule } from '@angular/router';
import { EventDetailComponent } from './event-detail/event-detail.component';

const EVENT_ROUTE: Routes = [
  {
    path: '', component: EventComponent, children: [
      { path: '', component: EventUpcomingListComponent },
      { path: 'list', component: EventUpcomingListComponent },
      { path: 'add', component: EventAddComponent },
      { path: 'edit/:id', component: EventAddComponent },
      { path: 'detail/:id', component: EventDetailComponent }
    ]
  },

];

export const EventRouting = RouterModule.forChild(EVENT_ROUTE);
