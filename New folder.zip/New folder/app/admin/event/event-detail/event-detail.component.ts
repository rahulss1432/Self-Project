import { EventService } from './../service/event.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AlertService } from '../../../auth/_services/alert.service';
import { AuthenticationService } from '../../../auth/_services';

@Component({
  selector: 'hb-event-detail',
  templateUrl: './event-detail.component.html',
})
export class EventDetailComponent implements OnInit {
  id: number;
  loading: boolean;
  event: any = {};
  center_id: number;
  constructor(
    private activatedRoute: ActivatedRoute,
    private eventService: EventService,
    private alertService: AlertService,
    private authenticationService: AuthenticationService) {
    this.id = this.activatedRoute.snapshot.params['id'];
    this.center_id = this.center_id = this.authenticationService.getUserDetail().center_id;
  }

  ngOnInit() {
    this.getEventDetail(this.id);
  }

  getEventDetail(id: number) {
    this.loading = true;
    this.eventService.getEventDetail(id, this.center_id)
      .subscribe(
      (event: any) => {
        this.event = event.data;
        if (!this.event.venue_image) {
          this.event.venue_image = 'assets/images/default-event.png';
        }
        this.loading = false;
      },
      (err) => {
        this.alertService.error(err.error.message);
        this.loading = false;
      });
  }
}
