
import { Event } from '../model/event.model';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, NgForm, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbDateStruct, NgbTimepicker, NgbDatepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import { EventService } from '../service/event.service';
import { AuthenticationService } from '../../../auth/_services/authentication.service';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../../shared/service/common.service';
import { AlertService } from '../../../auth/_services/alert.service';
@Component({
  selector: 'hb-event-add',
  templateUrl: './event-add.component.html'
})
export class EventAddComponent {
  @ViewChild('fileInput') inputEl: ElementRef;
  @ViewChild('event_date') eventDate;

  id: number;
  event = new Event();
  private fileList: any = [];
  loading = false;
  errorData = '';
  venue_image: any;
  center_id: number;
  dateObj: any;
  dateStr: string;
  start_time_ampm: string;
  start_time: any = [];
  end_time_ampm: string;
  end_time: any = [];
  event_start_time1: any;
  event_end_time2: any;
  disabled = false;
  start_hr: number;
  end_hr: number;
  validateTime = true;
  newEeventDate = {};
  today = new Date();
  futureDate: NgbDateStruct = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };
  time: any;
  meridian: any;
  showTypeError: boolean=false;
  showSizeError: boolean=false;
  buttonTitle: string;

  constructor(
    config: NgbDatepickerConfig,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private eventService: EventService,
    private toastr: ToastrService,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    private alertService: AlertService,
    private el: ElementRef
  ) {
    this.id = this.activatedRoute.snapshot.params['id'];
    this.center_id = this.authenticationService.getUserDetail().center_id;
    if (this.id) {
      this.getEventDetail(this.id);
      this.meridian = true;
      this.buttonTitle = 'Update';
    } else {
      this.time = { hour: 1, minute: 0 };
      this.meridian = true;
      this.event_start_time1 = this.time;
      this.event_end_time2 = this.time;
      this.init();
      this.buttonTitle = 'Save';
    }
    const currentDate = new Date();

    config.minDate = {year:currentDate.getFullYear(), month:currentDate.getMonth()+1, day: currentDate.getDate()};
    config.maxDate = {year: 2099, month: 12, day: 31};

    //config.outsideDays = 'hidden';
  }

  init() {
    this.event = new Event();
   
  }

  changeStartTimeOld(event) {
    if (event.hour < 12) {
      const startDate = event.hour + ':' + event.minute + ' AM';
      this.event.event_start_time = startDate.toString();
    } else {
      const startDate = event.hour + ':' + event.minute + ' PM';
      this.event.event_start_time = startDate.toString();
    }
  }

  closeDatepicker(e) {
    if (!this.eventDate.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
      || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
      || !(e.target.parentElement && e.target.parentElement.parentElement &&
        !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
      return;
    }
    if (this.eventDate.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
      this.eventDate.close();
    }
  }

  changeStartTime(event) {
    let hour = 0;
    let minute = 0;
    let meridian = ' AM';
    hour = event.hour < 10 ? `0${event.hour}` : event.hour;
    minute = event.minute < 10 ? `0${event.minute}` : event.minute;
    if (event.hour > 12) {
      meridian = ' PM';
    }
    const endDate = hour + ':' + minute + meridian;
    this.event.event_start_time = endDate.toString();
  }
  changeStartTime2(event) {
    let hour = 0;
    let minute = 0;
    let meridian = ' AM';
    hour = event.hour < 10 ? `0${event.hour}` : event.hour;
    minute = event.minute < 10 ? `0${event.minute}` : event.minute;
    if (event.hour > 12) {
      meridian = ' PM';
    }
    const endDate = hour + ':' + minute + meridian;
    this.event.event_end_time = endDate.toString();
  }
  onSubmit(frm: NgForm) {
      if (frm.valid) {
      this.clearError('photo');
      this.disabled = true;
      this.errorData = '';
      this.loading = true;
      frm.value.event_date =
        frm.value.event_date.year +
        '-' +
        frm.value.event_date.month +
        '-' +
        frm.value.event_date.day;
      this.eventService
        .addUpdateEvent(frm.value, this.fileList, this.id, this.center_id)
        .subscribe(
        result => {
          if (result.success === true) {
            this.toastr.success(result.message);
            this.router.navigate(['/event/list']);
          } else {
            this.errorData = this.commonService.GetHandleMultilineErrorString(
              result.error
            );
            this.toastr.error(this.errorData);
          }
          this.loading = false;
          this.disabled = false;
        },
        err => {
          this.errorData = this.commonService.GetHandleMultilineErrorString(
            err.error
          );
          this.alertService.error(this.errorData);
          this.loading = false;
          this.disabled = false;
        }
        );
    } else {
      let target;
      target = this.el.nativeElement.querySelector('.errormessage');
      if (target) {
        $('html,body').animate({ scrollTop: $(target).offset().top - 150 }, 'slow', () => {
          target.focus();
        });
      }
    }
  }

  getFormattedDate(dt: any) {
    this.dateObj = new Date(dt);
    const year = this.dateObj.getFullYear();
    let month = this.dateObj.getMonth() + 1;
    if (month < 10) {
      month = '0' + month;
    }
    let date = this.dateObj.getDate();
    if (date < 10) {
      date = '0' + date;
    }
    this.dateStr = year + '-' + month + '-' + date;
    return this.dateStr;
  }

  getFormattedDateNew(dt: any) {
    this.dateObj = new Date(dt);
    const year = this.dateObj.getFullYear();
    let month = this.dateObj.getMonth() + 1;
    if (month < 10) {
      month = 0 + month;
    }
    let date = this.dateObj.getDate();
    if (date < 10) {
      date = 0 + date;
    }
    return { year: year, month: month, day: date };
  }

  getEventDetail(id: number) {
    this.loading = true;
    this.eventService.getEventDetail(id, this.center_id).subscribe(
      (result: any) => {
        this.newEeventDate = this.getFormattedDateNew(result.data.event_date);
        this.event.name = result.data.name;
        this.event.event_date = this.getFormattedDate(result.data.event_date);
        this.event.venue = result.data.venue;
        this.event.description = result.data.description;
        this.event.category = result.data.category;
        this.event.event_start_time = result.data.event_start_time;
        this.event.event_end_time = result.data.event_end_time;
        const s1 = this.get24hTime(result.data.event_start_time).split(":");
        this.event_start_time1 = { hour: Number(s1[0]), minute: Number(s1[1]) };
        const e1 = this.get24hTime(result.data.event_end_time).split(":");
        this.event_end_time2 = { hour: Number(e1[0]), minute: Number(e1[1]) };
        document
          .getElementById('venueImg')
          .setAttribute('src', result.data.venue_image);
        this.loading = false;
      },
      err => {
        this.alertService.error(err.error.message);
        this.loading = false;
      }
    );
  }

  get24hTime(str) {
    str = String(str).toLowerCase().replace(/\s/g, '');
    var has_am = str.indexOf('am') >= 0;
    var has_pm = str.indexOf('pm') >= 0;
    str = str.replace('am', '').replace('pm', '');
    if (str.indexOf(':') < 0) str = str + ':00';
    if (has_am) str += ' am';
    if (has_pm) str += ' pm';
    var d = new Date("1/1/2011 " + str);
    var doubleDigits = function (n) {
      return (parseInt(n) < 10) ? "0" + n : String(n);
    };
    return doubleDigits(d.getHours()) + ':' + doubleDigits(d.getMinutes());
  }  

  upload(e) {
    const inputEl: HTMLInputElement = this.inputEl.nativeElement;
    const fileCount: number = inputEl.files.length;
    if (fileCount > 0) { // a file was selected
    //check file is valid
    if (!this.validateFile(inputEl.files[0].name)) {
      this.inputEl.nativeElement.value = "";
      this.showTypeError = true;
      return false;
    }
    this.showTypeError = false;
    //check file size is valid 10 MB
    if (inputEl.files[0].size > 10000000) {
      console.log(inputEl.files[0].size);
      this.inputEl.nativeElement.value = "";
      document.getElementById('venueImg').setAttribute('src','assets/images/default-event.png');
      this.fileList='';
      this.showSizeError = true;
      return false;
    }
    this.showSizeError = false;
  
      for (let i = 0; i < fileCount; i++) {
        this.fileList = inputEl.files.item(i);
        const reader = new FileReader();
        reader.readAsDataURL(inputEl.files.item(i));
        reader.onload = this.setFileUrl;
      }
    }
  }

  setFileUrl(file: any) {
    this.venue_image = file.target.result;
    document.getElementById('venueImg').setAttribute('src', file.target.result);
  }

  validateFile(name: String) {
    var ext = name.substring(name.lastIndexOf('.') + 1);
    if (ext.toLowerCase() == 'png' || ext.toLowerCase() == 'jpeg' || ext.toLowerCase() == 'jpg') {
      return true;
    }
    else {
      return false;
    }
  }
  clearError(imagetag) {
         this.showSizeError = false;
         this.showTypeError = false;
  }

}
