﻿import { environment } from '../../../../environments/environment';
import { Injectable } from '@angular/core';
import { AuthenticationService } from '../../../auth/_services/authentication.service';
import 'rxjs/Rx';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Event } from '../model/event.model';
import { RequestOptions, CommonService } from '../../../shared/service/common.service';
@Injectable()
export class EventService {
   baseUrl = environment.baseUrl;
  constructor(
    private http: HttpClient,
    private authenticationService: AuthenticationService,
    private commonService: CommonService,
   ) { }

  getEventList(
    page: number,
    query_by_name: string,
    from_date: any,
    to_date: any,
    center_id: number,
    pagination: boolean = true) {
    const urlSearchParams = this.commonService.getURLSearchParamsObject(query_by_name);
    const body = urlSearchParams.toString();
    const headers = this.commonService.getHeadersObject(null, true, true);
    const options = new RequestOptions({ headers: headers });
    from_date = from_date.year + '-' + from_date.month + '-' + from_date.day;

    return this.http.get(
      this.baseUrl +
      'center/' + center_id +
      '/event?limit=10&offset=' +
      (page - 1) * 10 + '&q=' + query_by_name + '&from_date=' + from_date + '&to_date=' + to_date + '&pagination=' +
      pagination, options)
      .pipe(map((response: any) => response));
  }


  addUpdateEvent(event: Event, file: any, Id: number, center_id: number) {
    const urlSearchParams = this
      .commonService
      .getURLSearchParamsObject(event);
    const body = urlSearchParams.toString();
    const headers = this.commonService.getFormDataHeader();
    const options = new RequestOptions({ headers: headers });
    const formData = new FormData();
    formData.append('name', event.name);
    formData.append('category', event.category);
    formData.append('event_date', event.event_date);
    formData.append('event_start_time', event.event_start_time);
    formData.append('event_end_time', event.event_end_time);
    formData.append('venue', event.venue);
    formData.append('venue_image', file);
    formData.append('description', event.description);
    if (Id) {
      return this
        .http
        .post(this.baseUrl + 'center/' + center_id + '/event/' + Id, formData, options)
        .pipe(map((response: any) => {
          const data = response && response.data;
          return response;
        }));
    } else {
      return this
        .http
        .post(this.baseUrl + 'center/' + center_id + '/event', formData, options)
        .pipe(map((response: any) => {
          const data = response && response.data;
          return response;
        }));
    }
  }

  deleteEvent(id: number, center_id: number) {
    const headers = this.commonService.getHeadersObject(null, true, true);
    const options = new RequestOptions({ headers: headers });
    return this.http
      .delete(
      this.baseUrl +
      'center/' +
      center_id +
      '/event/' +
      id,
      options
      )
      .pipe(map((response: any) => {
        return response;
      }))
      .catch(this.commonService.GetHandleErrorString);
  }

  getEventDetail(id: number, center_id: number) {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });
    return this.http.get(
      this.baseUrl +
      'center/' + center_id +
      '/event/' + id, options).map((response: any) => response)
      .catch(this.commonService.GetHandleErrorString);
  }
}
