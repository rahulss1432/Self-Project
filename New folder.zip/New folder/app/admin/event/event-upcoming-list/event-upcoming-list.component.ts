import { AuthenticationService } from './../../../auth/_services/authentication.service';
import { Component, OnInit, Output, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EventService } from '../service/event.service';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { AlertService } from '../../../auth/_services/alert.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'hb-event-upcoming-list',
  templateUrl: './event-upcoming-list.component.html',
})
export class EventUpcomingListComponent implements OnInit {
  upcomingEventList: any[] = [];
  p = 1;
  total: number;
  loading: boolean;
  query_by_name = '';
  center_id: number;
  disabled = false;
  eventinfo: any = [];
  today = new Date();
  futureDate: NgbDateStruct = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };
  from_date = { year: this.today.getFullYear(), month: this.today.getMonth() + 1, day: this.today.getDate() };
  to_date = { year: this.today.getFullYear(), month: this.today.getMonth() + 1, day: this.today.getDate() };
  
  @ViewChild('from_serch_date') fromDate;
  @ViewChild('to_serch_date') toDate;
  constructor(
    private eventService: EventService,
    private router: Router,
    private authenticationService: AuthenticationService,
    private alertService: AlertService,
    private toastr: ToastrService,
  ) {
    this.center_id = this.authenticationService.getUserDetail().center_id;
  }

  ngOnInit() {
    this.getEventList(1);
  }

  closeDatepickerFromTo(e, text) {
    if (text == 'from') {
      if (!this.fromDate.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.fromDate.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.fromDate.close();
      }
    }
    else {
      if (!this.toDate.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.toDate.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.toDate.close();
      }
    }
  }

  getEventList(page: number) {
    // console.log('onchange');
    this.disabled = true;
    this.loading = true;
    const from_date1 = this.from_date.year + '-' + this.from_date.month + '-' + this.from_date.day;
    const to_date1 = this.to_date.year + '-' + this.to_date.month + '-' + this.to_date.day;
    this.eventService.getEventList(page, this.query_by_name, from_date1, to_date1, this.center_id)
      .subscribe(
      (data: any) => {
        this.upcomingEventList = data.data.rows;
        this.total = data.data.total;
        this.p = page;
        this.loading = false;
        this.disabled = false;
      },
      (err) => {
        this.loading = false;
        this.disabled = false;
        this.alertService.ErrorTimeOut(err.error.message);
      });
  }

  deleteEvent(eventinfo: any, index: number) {
    this.loading = true;
    this.eventService.deleteEvent(eventinfo.id, this.center_id)
      .subscribe(
      (data: any) => {
        if (data.success === true) {
          this.toastr.success(data.message);
          this.getEventList(1);
        }
        this.loading = false;
      },
      (err) => {
        this.loading = false;
        this.alertService.ErrorTimeOut(err.error.message);
      });
  }

  eventInfo(data) {
    this.eventinfo = data;
  }

}
