import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyaccountComponent } from './myaccount.component';
import { myaccountRouting } from './myaccount.route';

@NgModule({
  imports: [
    CommonModule,
    myaccountRouting
  ],
  declarations: [MyaccountComponent]
})
export class MyaccountModule { }
