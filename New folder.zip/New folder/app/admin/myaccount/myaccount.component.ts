import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../auth/_services';
import { ApiCountryStateService } from '../../shared/service/api-country-state.service';
import { Countries } from '../../shared/model/countries';
import { States } from '../../shared/model/states';
@Component({
  selector: 'hb-myaccount',
  templateUrl: './myaccount.component.html'
})
export class MyaccountComponent implements OnInit {
  userdetail: any = {};
  countryData: Countries[];
  stateData: States[];
  constructor(
    private authenticationService: AuthenticationService,
    private _fetchCountry: ApiCountryStateService,
  ) { }

  ngOnInit() {
    this.userdetail = this.authenticationService.getUserDetail();
    this.getCounties();
    this.getStates();
    
  }
  userCountry: any;
  selectedCountry:any;
  getCounties(): void {
    this._fetchCountry.getCounties()
      .subscribe(
      countryData => {
        this.countryData = countryData['data'].rows;
        this.userCountry = this.countryData.filter(element => {
          return element.id == this.userdetail.country;
        });
        this.selectedCountry = this.userCountry[0].name; 
        });
  }
  userState: any;
  selectedState:any;
  getStates(): void {
    this._fetchCountry.getStates()
      .subscribe(
      stateData => {
        this.stateData = stateData['data'].rows;
          this.userState = this.stateData.filter(element => {
          return element.id == this.userdetail.state;
        });
        this.selectedState = this.stateData[0].state_name; 
      });
  }
}
