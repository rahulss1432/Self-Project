import { Routes, RouterModule } from '@angular/router';
import { MyaccountComponent } from './myaccount.component';

const MYACCOUNT_ROUTE: Routes = [
  {
    path: '', component: MyaccountComponent, children: [
      { path: '', component: MyaccountComponent }
    ]
  }
]

export const myaccountRouting = RouterModule.forChild(MYACCOUNT_ROUTE);
