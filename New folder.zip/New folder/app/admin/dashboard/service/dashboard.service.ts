import { environment } from '../../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../../shared/service/common.service';
import { RequestOptions } from '../../../shared/service/request-option';
import 'rxjs/Rx';

@Injectable()
export class DashboardService {
   baseUrl = environment.baseUrl;
  constructor(
    private http: HttpClient,
    private commonService: CommonService,
  ) {}

  getDashboardData() {
    const headers = this.commonService.getHeadersObject(null, true, false);
    const options = new RequestOptions({ headers: headers });

    return this.http
      .get(this.baseUrl + 'user/dashboard', options)
      .map((response: any) => response);
  }
}
