import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';

const DASHBOARD_ROUTE: Routes = [
  {
    path: '', component: DashboardComponent, children: [
      { path: '', component: DashboardComponent }
    ]
  }
];

export const dashboardRouting = RouterModule.forChild(DASHBOARD_ROUTE);
