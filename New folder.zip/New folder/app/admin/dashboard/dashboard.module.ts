import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { dashboardRouting } from './dashboard.route';
import { SharedModule } from '../../shared/module/shared.module';

@NgModule({
  declarations: [
    DashboardComponent,
  ],
  imports: [  CommonModule,  RouterModule, dashboardRouting, SharedModule ]
})

export class DashboardModule { }
