import { Component, OnInit } from '@angular/core';
import { DashboardService } from './service/dashboard.service';
import { AuthenticationService } from '../../auth/_services';
import { ToastrService } from 'ngx-toastr';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'hb-dashboard',
  templateUrl: './dashboard.component.html',
  providers: [DashboardService]
})
export class DashboardComponent implements OnInit {
  user_type: any;
  userType: any;
  dashboardData: any = {};
  dashboardList: any = [];
  totalChild = 0;
  totalStaff = 0;
  loading: boolean;

  constructor(
    private dashboardService: DashboardService,
    private authenticationService: AuthenticationService,
    private toastr: ToastrService,
    private router: Router
  ) {
    this.userType = '';
  }

  ngOnInit() {
    this.getDashboardData();
    this.userType = this.authenticationService.getUserDetail().user_type;
    }

  getDashboardData() {
    this.loading = true;
    this.dashboardService.getDashboardData().subscribe(
      (data: any) => {
        this.dashboardData = data.data;
        this.dashboardList = data.data.centers;
        this.dashboardList.forEach(
          s => (this.totalChild += parseFloat(s.children.length))
        );
        this.dashboardList.forEach(
          s => (this.totalStaff += parseFloat(s.staffs.length))
        );
        this.loading = false;
      },
      err => {
        this.loading = false;
        if(err.error.message == 'Invalid access token')
        {
          this.toastr.error(err.error.message);
          this.authenticationService.clearData();
          this.router.navigate(['/login']);
          return false;
        }
        this.toastr.error(err.error.message);
      }
    );
  }
}
