// import { AlertService } from '../../shared/service/alert.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, NgForm, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  Registration, Doctor, Dentist,
  ParentFather, ParentFatherWorkplace,
  ParentMother, ParentMotherWorkplace,
  ParentGuardian, ParentGuardianWorkplace,
  PrimaryContact, SecondaryContact, AdditionalInfo, Immunization
} from './model/registration.model';
// import { Registration} from './model/registration.model';
import { Component, OnInit, ElementRef, ViewChild, HostListener, SimpleChange } from '@angular/core';
import { ChildService } from '../child/service/child.service';
import { CommonService } from '../../shared/service/common.service';
// import { Subscription } from "rxjs/Rx";
import { NgbDateStruct, NgbDatepickerConfig, NgbDatepicker } from '@ng-bootstrap/ng-bootstrap';
import { ApiCountryStateService } from './../../shared/service/api-country-state.service';
import { Countries } from '../../shared/model/countries';
import { States } from '../../shared/model/states';
import { ToastrService } from 'ngx-toastr';
import { ProgramService } from './../program/service/program.service';
import { now } from '../../../../node_modules/moment';
import * as $ from "jquery";

@Component({
  selector: "hb-registration",
  templateUrl: "./registration.component.html"
})
export class RegistrationComponent implements OnInit {
  @ViewChild(NgbDatepicker) private picker: NgbDatepicker;
  activeTab = 1;
  activeForm = 1;
  loading: boolean = false;
  registration = new Registration();
  doctor = new Doctor();
  dentist = new Dentist();
  father = new ParentFather();
  fatherWorkplace = new ParentFatherWorkplace();
  mother = new ParentMother();
  motherWorkplace = new ParentMotherWorkplace();
  guardian = new ParentGuardian();
  guardianWorkplace = new ParentGuardianWorkplace();
  primaryContact = new PrimaryContact();
  secondaryContact = new SecondaryContact();
  additionalInfo = new AdditionalInfo();
  immunization = new Immunization();
  currentDatePicker: any;

  showDocs = false;
  errorData = "";
  @ViewChild("fileInput") inputEl: ElementRef;
  @ViewChild("fileInput1") inputEl1: ElementRef;
  @ViewChild("fileInput2") inputEl2: ElementRef;
  @ViewChild("frm4") frm4;
  @ViewChild('date_of_birth') DateOfBirth;
  @ViewChild('date_of_birth3') DatePicker3;
  @ViewChild('date_of_birth4') DatePicker4;
  @ViewChild('date_of_birth6') DatePicker6;
  @ViewChild('date_of_birth7') DatePicker7;
  @ViewChild('date_of_birth8') DatePicker8;
  @ViewChild('date_of_birth9') DatePicker9;
  @ViewChild('date_of_birth10') DatePicker10;
  @ViewChild('date_of_birth11') DatePicker11;
  @ViewChild('date_of_birth12') DatePicker12;
  @ViewChild('date_of_birth13') DatePicker13;
  @ViewChild('date_of_birth14') DatePicker14;
  @ViewChild('date_of_birth15') DatePicker15;
  @ViewChild('date_of_birth16') DatePicker16;
  @ViewChild('date_of_birth17') DatePicker17;
  @ViewChild('date_of_birth18') DatePicker18;
  @ViewChild('date_of_birth19') DatePicker19;
  @ViewChild('date_of_birth20') DatePicker20;
  @ViewChild('date_of_birth21') DatePicker21;
  @ViewChild('date_of_birth22') DatePicker22;
  @ViewChild('date_of_birth23') DatePicker23;
  @ViewChild('date_of_birth24') DatePicker24;
  @ViewChild('date_of_birth25') DatePicker25;
  @ViewChild('date_of_birth26') DatePicker26;
  @ViewChild('date_of_birth27') DatePicker27;
  @ViewChild('date_of_birth29') DatePicker28;
  @ViewChild('date_of_birth29') DatePicker29;
  @ViewChild('date_of_birth30') DatePicker30;
  @ViewChild('date_of_birth31') DatePicker31;
  @ViewChild('date_of_birth32') DatePicker32;
  @ViewChild('date_of_birth33') DatePicker33;
  @ViewChild('date_of_birth34') DatePicker34;
  @ViewChild('date_of_birth35') DatePicker35;

  fileCount: number;
  fileName: string;
  private fileList: any = [];
  private fileListDoc: any = [];
  private fileListDoc1: any = [];

  doses: any = [];
  disabled = false;
  countryData: Countries[];
  stateData: States[];
  country = "";
  doctorStates: any = [];
  selectedStates = [];
  dentistStates: any = [];
  fatherStates: any = [];
  fatherWorkplaceStates: any = [];
  motherStates: any = [];
  motherWorkplaceStates: any = [];
  guardianStates: any = [];
  guardianWorkplaceStates: any = [];
  primaryContactStates: any = [];
  secondaryContactStates: any = [];
  fatherData: any;
  motherData: any;
  guardianData: any;
  fatherWorkplaceData: any;
  motherWorkplaceData: any;
  guardianWorkplaceData: any;
  programData = [];
  id: number = 0;
  doctorExits: boolean = false;
  dentistExits: boolean = false;
  fatherWorkplaceExits: boolean = false;
  motherWorkplaceExits: boolean = false;
  guardianWorkplaceExits: boolean = false;
  secondaryContactExist: boolean = false;

  isFatherPrimary: any = true;
  isMotherPrimary: any = false;
  isGuardianPrimary: any = false;
  dateOfBirth = {};
  dateObj: any;
  dateStr: string;
  emailDisabled: boolean = false;

  today = new Date();
  futureDate: NgbDateStruct = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };
  maxDate: { year: number; month: number; day: number; };
  minDate: {
    year: number; month: number; day: number;
  };

  showSizeError: boolean = false;
  showTypeError: boolean = false;
  docTypeError: boolean = false;
  docSizeError: boolean = false;
  doc1TypeError: boolean = false;
  doc1SizeError: boolean = false;
  globalVariable: number;
  nextTabId: any;
  constructor(
    private config: NgbDatepickerConfig,
    private _fetchCountry: ApiCountryStateService,
    private toastr: ToastrService,
    private commonService: CommonService,
    private childService: ChildService,
    private programService: ProgramService,
    private activatedRoute: ActivatedRoute,
    private router: Router,

  ) {
    this.init();
    const currentDate = new Date();
    this.registration.maxDate = { year: currentDate.getFullYear(), month: currentDate.getMonth() + 1, day: currentDate.getDate() };
    this.registration.minDate = { year: 1950, month: 1, day: 1 };

  }

  init() {
    this.id = this.activatedRoute.snapshot.params['id'];
    if (this.id) {
      this.getChildDetail(this.id);
    }
  }

  globalDate: any = '';
  dp: any;
  setDateObject(evt, dp) {
    let a;
    a = document.querySelectorAll('.dropdown-menu')
    a.forEach(b => {
      b.remove();
    });
    this.globalDate = dp;
  }

  ngOnInit() {
    this.registration.id = '';
    this.getCounties();
    this.getStates();
    this.getPrograms();
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  closeDatepicker(e) {
    if (!this.DateOfBirth.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
      || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
      || !(e.target.parentElement && e.target.parentElement.parentElement &&
        !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
      return;
    }
    if (this.DateOfBirth.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
      this.DateOfBirth.close();
    }
  }
  closeDatepickerImunization(e, id: any) {
    // console.log(id);
    if (id == 'DatePicker3') {
      if (!this.DatePicker3.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker3.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker3.close();
      }
    }
    else if (id == 'DatePicker4') {
      if (!this.DatePicker4.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker4.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker4.close();
      }
    }
    else if (id == 'DatePicker6') {
      if (!this.DatePicker6.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker6.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker6.close();
      }
    }
    else if (id == 'DatePicker7') {
      if (!this.DatePicker7.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker7.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker7.close();
      }
    }
    else if (id == 'DatePicker8') {
      if (!this.DatePicker8.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker8.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker8.close();
      }
    }
    else if (id == 'DatePicker9') {
      if (!this.DatePicker9.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker9.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker9.close();
      }
    }
    else if (id == 'DatePicker10') {
      if (!this.DatePicker10.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker10.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker10.close();
      }
    }
    else if (id == 'DatePicker11') {
      if (!this.DatePicker11.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker11.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker11.close();
      }
    }
    else if (id == 'DatePicker12') {
      if (!this.DatePicker12.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker12.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker12.close();
      }
    }
    else if (id == 'DatePicker13') {
      if (!this.DatePicker13.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker13.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker13.close();
      }
    }
    else if (id == 'DatePicker14') {
      if (!this.DatePicker14.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker14.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker14.close();
      }
    }
    else if (id == 'DatePicker15') {
      if (!this.DatePicker15.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker15.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker15.close();
      }
    }
    else if (id == 'DatePicker16') {
      if (!this.DatePicker16.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker16.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker16.close();
      }
    }
    else if (id == 'DatePicker17') {
      if (!this.DatePicker17.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker17.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker17.close();
      }
    }
    else if (id == 'DatePicker18') {
      if (!this.DatePicker18.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker18.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker18.close();
      }
    }
    else if (id == 'DatePicker19') {
      if (!this.DatePicker19.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker19.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker19.close();
      }
    }
    else if (id == 'DatePicker20') {
      if (!this.DatePicker20.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker20.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker20.close();
      }
    }
    else if (id == 'DatePicker21') {
      if (!this.DatePicker21.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker21.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker21.close();
      }
    }
    else if (id == 'DatePicker22') {
      if (!this.DatePicker22.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker22.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker22.close();
      }
    }
    else if (id == 'DatePicker23') {
      if (!this.DatePicker23.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker23.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker23.close();
      }
    }
    else if (id == 'DatePicker24') {
      if (!this.DatePicker24.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker24.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker24.close();
      }
    }
    else if (id == 'DatePicker25') {
      if (!this.DatePicker25.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker25.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker25.close();
      }
    }
    else if (id == 'DatePicker26') {
      if (!this.DatePicker26.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker26.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker26.close();
      }
    }
    else if (id == 'DatePicker27') {
      if (!this.DatePicker27.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker27.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker27.close();
      }
    }
    else if (id == 'DatePicker28') {
      if (!this.DatePicker28.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker28.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker28.close();
      }
    }
    else if (id == 'DatePicker29') {
      if (!this.DatePicker29.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker29.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker29.close();
      }
    }
    else if (id == 'DatePicker30') {
      if (!this.DatePicker30.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker30.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker30.close();
      }
    }
    else if (id == 'DatePicker31') {
      if (!this.DatePicker31.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker31.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker31.close();
      }
    }
    else if (id == 'DatePicker32') {
      if (!this.DatePicker32.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker32.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker32.close();
      }
    }
    else if (id == 'DatePicker33') {
      if (!this.DatePicker33.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker33.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker33.close();
      }
    }
    else if (id == 'DatePicker34') {
      if (!this.DatePicker34.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker34.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker34.close();
      }
    }
    else if (id == 'DatePicker35') {
      if (!this.DatePicker35.isOpen() || (e.target.id === 'd' && e.target.id === 'dropdown-icon')
        || (e.target.offsetParent && e.target.offsetParent.localName.includes('ngb-datepicker'))
        || !(e.target.parentElement && e.target.parentElement.parentElement &&
          !e.target.parentElement.parentElement.localName.includes('ngb-datepicker'))) {
        return;
      }
      if (this.DatePicker35.isOpen() && e.target.id !== 'd' && e.target.id !== 'dropdown-icon') {
        this.DatePicker35.close();
      }
    }


  }


  onChange(changes: any) {
    const currentDate = new Date();
    const new_date = new Date(changes.year + "-" + changes.month + "-" + changes.day);
    this.immunization.bcg_dose0 = changes;
    this.immunization.hepB_dose0 = changes;
    this.immunization.poliovirus_dose0 = changes;

    /** immunization 4 & 8 week blank first and min date is DOB date */
    this.immunization.hepB_dose1 = null;
    this.immunization.hepB_dose2 = null;
    this.immunization.poliovirus_dose1 = null;
    this.immunization.poliovirus_dose2 = null;
    this.immunization.dtp_dose0 = null;
    this.immunization.dtp_dose1 = null;
    this.immunization.dtp_dose2 = null;
    this.immunization.dtp_dose3 = null;
    this.immunization.dtp_dose4 = null;
    this.immunization.hib_dose0 = null;
    this.immunization.hib_dose1 = null;
    this.immunization.hib_dose2 = null;
    this.immunization.hib_dose3 = null;
    this.immunization.pcv_dose0 = null;
    this.immunization.pcv_dose1 = null;
    this.immunization.pcv_dose2 = null;
    this.immunization.pcv_dose3 = null;
    this.immunization.rv_dose0 = null;
    this.immunization.rv_dose1 = null;
    this.immunization.rv_dose2 = null;
    this.immunization.typhoid_dose0 = null;
    this.immunization.typhoid_dose1 = null;
    this.immunization.mmr_dose0 = null;
    this.immunization.mmr_dose1 = null;
    this.immunization.varicella_dose0 = null;
    this.immunization.varicella_dose1 = null;
    this.immunization.hepA_dose0 = null;
    this.immunization.hepA_dose1 = null;
    this.immunization.tdap_dose0 = null;
    this.immunization.hpv_dose0 = null;
    this.immunization.hpv_dose1 = null;
    this.immunization.hpv_dose2 = null;

    this.immunization.minDate4 = { year: new_date.getFullYear(), month: new_date.getMonth() + 1, day: new_date.getDate() };
  }

  getChildDetail(id: number) {
    // this.loading = true;
    this.childService.getChildDetail(id).subscribe((result: any) => {
      this.registration = result.data;
      this.emailDisabled = true;
      this.doctor = result['data'].doctor;
      // tslint:disable-next-line:max-line-length
      if (this.doctor.first_name || this.doctor.last_name || this.doctor.email || this.doctor.phone_number || this.doctor.mobile_number || this.doctor.address_line1 || this.doctor.address_line2 || this.doctor.country || this.doctor.state || this.doctor.city || this.dentist.zip_code) {
        this.doctorExits = true;
        if (this.doctor.country) {
          this.onCountry(this.doctor.country, 'doctor_country');
        }
      }

      this.dentist = result['data'].dentist;
      // tslint:disable-next-line:max-line-length
      if (this.dentist.first_name || this.dentist.last_name || this.dentist.email || this.dentist.phone_number || this.dentist.mobile_number || this.dentist.address_line1 || this.dentist.address_line2 || this.dentist.country || this.dentist.state || this.dentist.city || this.dentist.zip_code) {
        this.dentistExits = true;
        if (this.dentist.country) {
          this.onCountry(this.dentist.country, 'dentist_country');
        }
      }
      this.isFatherPrimary = result['data'].child_parents[0].parent.is_primary;
      this.isMotherPrimary = result['data'].child_parents[1].parent.is_primary;
      this.isGuardianPrimary = result['data'].child_parents[2].parent.is_primary;

      this.father = result['data'].child_parents[0].parent.user;
      this.onCountry(this.father.country, 'father_country');

      this.fatherWorkplace = result['data'].child_parents[0].parent.work_place;
      // tslint:disable-next-line:max-line-length
      if (this.fatherWorkplace.email || this.fatherWorkplace.phone_number || this.fatherWorkplace.mobile_number || this.fatherWorkplace.address_line1 || this.fatherWorkplace.address_line2 || this.fatherWorkplace.country || this.fatherWorkplace.state || this.fatherWorkplace.city || this.fatherWorkplace.zip_code) {
        this.fatherWorkplaceExits = true;
        if (this.fatherWorkplace.country) {
          this.onCountry(this.fatherWorkplace.country, 'father_workplace_country');
        }
      }

      this.mother = result['data'].child_parents[1].parent.user;
      this.onCountry(this.mother.country, 'mother_country');

      this.motherWorkplace = result['data'].child_parents[1].parent.work_place;
      // tslint:disable-next-line:max-line-length
      if (this.motherWorkplace.email || this.motherWorkplace.phone_number || this.motherWorkplace.mobile_number || this.motherWorkplace.address_line1 || this.motherWorkplace.address_line2 || this.motherWorkplace.country || this.motherWorkplace.state || this.motherWorkplace.city || this.motherWorkplace.zip_code) {
        this.motherWorkplaceExits = true;
        if (this.motherWorkplace.country) {
          this.onCountry(this.motherWorkplace.country, 'mother_workplace_country');
        }
      }

      this.guardian = result['data'].child_parents[2].parent.user;
      this.onCountry(this.guardian.country, 'guardian_country');

      this.guardianWorkplace = result['data'].child_parents[2].parent.work_place;
      // tslint:disable-next-line:max-line-length
      if (this.guardianWorkplace.email || this.guardianWorkplace.phone_number || this.guardianWorkplace.mobile_number || this.guardianWorkplace.address_line1 || this.guardianWorkplace.address_line2 || this.guardianWorkplace.country || this.guardianWorkplace.state || this.guardianWorkplace.city || this.guardianWorkplace.zip_code) {
        this.guardianWorkplaceExits = true;
        if (this.motherWorkplace.country) {
          this.onCountry(this.guardianWorkplace.country, 'gaurdian_workplace_country');
        }
      }

      this.primaryContact = result['data'].primary_contact;
      if (this.primaryContact.country) {
        this.onCountry(this.primaryContact.country, 'primary_contact_country');
      }

      this.secondaryContact = result['data'].secondary_contact;
      // tslint:disable-next-line:max-line-length
      if (this.secondaryContact.first_name || this.secondaryContact.last_name || this.secondaryContact.relation || this.secondaryContact.is_release_child || this.secondaryContact.email || this.secondaryContact.phone_number || this.secondaryContact.mobile_number || this.secondaryContact.address_line1 || this.secondaryContact.address_line2 || this.secondaryContact.country || this.secondaryContact.state || this.secondaryContact.city || this.secondaryContact.zip_code) {
        this.secondaryContactExist = true;
        if (this.secondaryContact.country) {
          this.onCountry(this.secondaryContact.country, 'secondary_contact_country');
        }
      }

      this.registration.date_of_birth = this.getFormattedDateNew(result.data.date_of_birth);
      this.immunization.bcg_dose0 = this.getFormattedDateNew(result['data'].child_immunizations[0].doses);

      const hepB_dose = this.filterArrayFuntion(result['data'].child_immunizations[1].doses);
      this.immunization.hepB_dose0 = this.getFormattedDateNew(hepB_dose[0]);
      this.immunization.hepB_dose1 = this.getFormattedDateNew(hepB_dose[1]);
      this.immunization.hepB_dose2 = this.getFormattedDateNew(hepB_dose[2]);

      const poliovirus_dose = this.filterArrayFuntion(result['data'].child_immunizations[2].doses);
      this.immunization.poliovirus_dose0 = this.getFormattedDateNew(poliovirus_dose[0]);
      this.immunization.poliovirus_dose1 = this.getFormattedDateNew(poliovirus_dose[1]);
      this.immunization.poliovirus_dose2 = this.getFormattedDateNew(poliovirus_dose[2]);

      const dtp_dose = this.filterArrayFuntion(result['data'].child_immunizations[3].doses);
      this.immunization.dtp_dose0 = this.getFormattedDateNew(dtp_dose[0]);
      this.immunization.dtp_dose1 = this.getFormattedDateNew(dtp_dose[1]);
      this.immunization.dtp_dose2 = this.getFormattedDateNew(dtp_dose[2]);
      this.immunization.dtp_dose3 = this.getFormattedDateNew(dtp_dose[3]);
      this.immunization.dtp_dose4 = this.getFormattedDateNew(dtp_dose[4]);

      const hib_dose = this.filterArrayFuntion(result['data'].child_immunizations[4].doses);
      this.immunization.hib_dose0 = this.getFormattedDateNew(hib_dose[0]);
      this.immunization.hib_dose1 = this.getFormattedDateNew(hib_dose[1]);
      this.immunization.hib_dose2 = this.getFormattedDateNew(hib_dose[2]);
      this.immunization.hib_dose3 = this.getFormattedDateNew(hib_dose[3]);

      const pcv_dose = this.filterArrayFuntion(result['data'].child_immunizations[5].doses);
      this.immunization.pcv_dose0 = this.getFormattedDateNew(pcv_dose[0]);
      this.immunization.pcv_dose1 = this.getFormattedDateNew(pcv_dose[1]);
      this.immunization.pcv_dose2 = this.getFormattedDateNew(pcv_dose[2]);
      this.immunization.pcv_dose3 = this.getFormattedDateNew(pcv_dose[3]);

      const rv_dose = this.filterArrayFuntion(result['data'].child_immunizations[6].doses);
      this.immunization.rv_dose0 = this.getFormattedDateNew(rv_dose[0]);
      this.immunization.rv_dose1 = this.getFormattedDateNew(rv_dose[1]);
      this.immunization.rv_dose2 = this.getFormattedDateNew(rv_dose[2]);

      const typhoid_dose = this.filterArrayFuntion(result['data'].child_immunizations[7].doses);
      this.immunization.typhoid_dose0 = this.getFormattedDateNew(typhoid_dose[0]);
      this.immunization.typhoid_dose1 = this.getFormattedDateNew(typhoid_dose[1]);

      const mmr_dose = this.filterArrayFuntion(result['data'].child_immunizations[8].doses);
      this.immunization.mmr_dose0 = this.getFormattedDateNew(mmr_dose[0]);
      this.immunization.mmr_dose1 = this.getFormattedDateNew(mmr_dose[1]);

      const varicella_dose = this.filterArrayFuntion(result['data'].child_immunizations[9].doses);
      this.immunization.varicella_dose0 = this.getFormattedDateNew(varicella_dose[0]);
      this.immunization.varicella_dose1 = this.getFormattedDateNew(varicella_dose[1]);

      const hepA_dose = this.filterArrayFuntion(result['data'].child_immunizations[10].doses);
      this.immunization.hepA_dose0 = this.getFormattedDateNew(hepA_dose[0]);
      this.immunization.hepA_dose1 = this.getFormattedDateNew(hepA_dose[1]);

      this.immunization.tdap_dose0 = this.getFormattedDateNew(result['data'].child_immunizations[11].doses);

      const hpv_dose = this.filterArrayFuntion(result['data'].child_immunizations[12].doses);
      this.immunization.hpv_dose0 = this.getFormattedDateNew(hpv_dose[0]);
      this.immunization.hpv_dose1 = this.getFormattedDateNew(hpv_dose[1]);
      this.immunization.hpv_dose2 = this.getFormattedDateNew(hpv_dose[2]);

      this.additionalInfo.document_title = result['data'].child_documents[0].title;
      this.additionalInfo.document_file = result['data'].child_documents[0].document_url;
      this.additionalInfo.document_title1 = result['data'].child_documents[1].title;
      this.additionalInfo.document_file1 = result['data'].child_documents[1].document_url;
    },
      err => {
        if (err.error.error.length) {
          err.error.error.map((e, i) => {
            this.toastr.error(err.error.error[i].message);
          });
          this.loading = false;
          this.disabled = false;
        }
        else {
          this.toastr.error('Something went wrong');
        }
      });
  }

  filterArrayFuntion(DoseString: any) {
    return DoseString.split(',');
  }

  changePrimaryParent(val: any, type: string): void {
    if (type == 'father') {
      this.isFatherPrimary = 'father';
      this.isMotherPrimary = false;
      this.isGuardianPrimary = false;

    }
    if (type == 'mother') {
      this.isFatherPrimary = false;
      this.isMotherPrimary = 'mother';
      this.isGuardianPrimary = false;

    }

    if (type == 'guardian') {
      this.isFatherPrimary = false;
      this.isMotherPrimary = false;
      this.isGuardianPrimary = 'guardian';

    }
  }

  getFormattedDate(dt: any) {
    this.dateObj = new Date(dt);
    const year = this.dateObj.getFullYear();
    let month = this.dateObj.getMonth() + 1;
    if (month < 10) {
      month = '0' + month;
    }
    let date = this.dateObj.getDate();
    if (date < 10) {
      date = '0' + date;
    }
    this.dateStr = year + '-' + month + '-' + date;
    return this.dateStr;
  }

  getFormattedDateNew(dt: any) {
    this.dateObj = new Date(dt);
    const year = this.dateObj.getFullYear();
    let month = this.dateObj.getMonth() + 1;
    if (month < 10) {
      month = month;
    }
    let date = this.dateObj.getDate();
    if (date < 10) {
      date = date;
    }
    return { year: year, month: month, day: date };

  }

  getCounties(): void {
    this._fetchCountry.getCounties()
      .subscribe(
        countryData => {
          this.countryData = countryData['data'].rows;
        });
  }

  getStates(): void {
    this._fetchCountry.getStates()
      .subscribe(
        stateData => {
          this.stateData = stateData;
        });
  }

  onCountry(country, type) {
    if (type == 'doctor_country') {
      this.doctorStates = this.onSelectCountry(country, 'doctorCountry');
    }
    if (type == 'dentist_country') {
      this.dentistStates = this.onSelectCountry(country, 'dentistCountry');
    }
    if (type == 'father_country') {
      this.fatherStates = this.onSelectCountry(country, 'fatherCountry');
    }
    if (type == 'father_workplace_country') {
      this.fatherWorkplaceStates = this.onSelectCountry(country, 'fatherWorkplaceCountry');
    }
    if (type == 'mother_country') {
      this.motherStates = this.onSelectCountry(country, 'motherCountry');
    }
    if (type == 'mother_workplace_country') {
      this.motherWorkplaceStates = this.onSelectCountry(country, 'motherWorkplaceCountry');
    }
    if (type == 'guardian_country') {
      this.guardianStates = this.onSelectCountry(country, 'guardianCountry');
    }
    if (type == 'gaurdian_workplace_country') {
      this.guardianWorkplaceStates = this.onSelectCountry(country, 'guardianWorkplaceCountry');
    }
    if (type == 'primary_contact_country') {
      this.primaryContactStates = this.onSelectCountry(country, 'primaryContactCountry');
    }
    if (type == 'secondary_contact_country') {
      this.secondaryContactStates = this.onSelectCountry(country, 'secondaryContactCountry');
    }

  }

  onSelectCountry(country, type) {
    this._fetchCountry.getStates()
      .subscribe(
        stateData => {
          if (type == 'doctorCountry') {
            this.doctorStates = this.stateData['data'].rows.filter(element => { return element.country_id == country; });
          } else if (type == 'dentistCountry') {
            this.dentistStates = this.stateData['data'].rows.filter(element => { return element.country_id == country; });
          } else if (type == 'fatherCountry') {
            this.fatherStates = this.stateData['data'].rows.filter(element => { return element.country_id == country; });
          } else if (type == 'fatherWorkplaceCountry') {
            this.fatherWorkplaceStates = this.stateData['data'].rows.filter(element => { return element.country_id == country; });
          } else if (type == 'motherCountry') {
            this.motherStates = this.stateData['data'].rows.filter(element => { return element.country_id == country; });
          } else if (type == 'motherWorkplaceCountry') {
            this.motherWorkplaceStates = this.stateData['data'].rows.filter(element => { return element.country_id == country; });
          } else if (type == 'guardianCountry') {
            this.guardianStates = this.stateData['data'].rows.filter(element => { return element.country_id == country; });
          } else if (type == 'guardianWorkplaceCountry') {
            this.guardianWorkplaceStates = this.stateData['data'].rows.filter(element => { return element.country_id == country; });
          } else if (type == 'primaryContactCountry') {
            this.primaryContactStates = this.stateData['data'].rows.filter(element => { return element.country_id == country; });
          } else if (type == 'secondaryContactCountry') {
            this.secondaryContactStates = this.stateData['data'].rows.filter(element => { return element.country_id == country; });
          }
        });
  }

  clearError(imagetag) {
    if (imagetag == 'document_file') {

      this.docTypeError = false;
      this.docSizeError = false;

    }
    else if (imagetag == 'document_file1') {
      this.doc1TypeError = false;
      this.doc1SizeError = false;
    }
    else if (imagetag == 'photo') {
      this.showSizeError = false;
      this.showTypeError = false;
    }
  }
  upload(e, imageFor) {
    switch (imageFor.name) {
      case "photo":
        const inputEl: HTMLInputElement = this.inputEl.nativeElement;
        this.fileCount = inputEl.files.length;
        if (this.fileCount > 0) {
        this.fileName = inputEl.files[0].name;
        //check file is valid
        if (!this.validateFile(inputEl.files[0].name)) {
          this.inputEl.nativeElement.value = "";
          this.fileList='';
          this.registration.photo = "";
          this.showTypeError = true;
          this.globalVariable=1;
          return false;
        }
        this.showTypeError = false;
        //check file size is valid 10 MB
        if (inputEl.files[0].size > 10000000) {
          //console.log(inputEl.files[0].size);
          this.inputEl.nativeElement.value = "";
          this.fileList='';
          this.registration.photo = "";
          this.showSizeError = true;
          this.globalVariable=2;
          return false;
        }
        this.showSizeError = false;
        this.registration.photo = this.fileName;
        
          // a file was selected
          for (let i = 0; i < this.fileCount; i++) {
            this.fileList=inputEl.files.item(i);
            const reader = new FileReader();
            reader.readAsDataURL(inputEl.files.item(i));
          }
         // console.log('showSizeError :'+this.showSizeError+" showTypeError :"+this.showTypeError);
        }
        break;
      case "document_file":
        const inputEl1: HTMLInputElement = this.inputEl1.nativeElement;
        this.fileCount = inputEl1.files.length;
        if (this.fileCount > 0) {
        this.fileName = inputEl1.files[0].name;
        //check file is valid
        if (!this.validateDoc(inputEl1.files[0].name)) {
          this.inputEl1.nativeElement.value = "";
          this.fileListDoc = ''
          this.additionalInfo.document_file='';
          this.docTypeError = true;
          return false;
        }
        this.docTypeError = false;
        //check file size is valid 10 MB
        if (inputEl1.files[0].size > 10000000) {
          //console.log(inputEl1.files[0].size);
          this.inputEl1.nativeElement.value = "";
          this.fileListDoc = '';
          this.additionalInfo.document_file='';
          this.docSizeError = true;
          return false;
        }
        this.docSizeError = false;
        this.additionalInfo.document_file = this.fileName;
        
          // a file was selected
          for (let i = 0; i < this.fileCount; i++) {
            this.fileListDoc= inputEl1.files.item(i);
            const reader = new FileReader();
            reader.readAsDataURL(inputEl1.files.item(i));
          }
        }
        break;

      case "document_file1":
        const inputEl2: HTMLInputElement = this.inputEl2.nativeElement;
        this.fileCount = inputEl2.files.length;
        if (this.fileCount > 0) {
        this.fileName = inputEl2.files[0].name;
        //check file is valid
        if (!this.validateDoc(inputEl2.files[0].name)) {
          this.inputEl2.nativeElement.value = "";
          this.fileListDoc1='';
          this.additionalInfo.document_file1='';
          this.doc1TypeError = true;
          return false;
        }
        this.doc1TypeError = false;
        //check file size is valid 10 MB
        if (inputEl2.files[0].size > 10000000) {
           this.inputEl2.nativeElement.value = "";
          this.fileListDoc1='';
          this.additionalInfo.document_file1='';
          this.doc1SizeError = true;
          return false;
        }
        this.doc1SizeError = false;
        this.additionalInfo.document_file1 = this.fileName;
        
          // a file was selected
          for (let i = 0; i < this.fileCount; i++) {
            this.fileListDoc1=inputEl2.files.item(i);
            const reader = new FileReader();
            reader.readAsDataURL(inputEl2.files.item(i));
          }
        }
        break;
    }
    // this.showSizeError = false;
    // this.showTypeError = false;
    // this.docTypeError = false;
    // this.docSizeError = false;
    // this.doc1TypeError = false;
    // this.doc1SizeError = false;
  }

  validateFile(name: String) {
    var ext = name.substring(name.lastIndexOf('.') + 1);
    if (ext.toLowerCase() == 'png' || ext.toLowerCase() == 'jpeg' || ext.toLowerCase() == 'jpg') {
      return true;
    }
    else {
      return false;
    }
  }
  validateDoc(name: String) {
    var ext = name.substring(name.lastIndexOf('.') + 1);
    if (ext.toLowerCase() == 'png' || ext.toLowerCase() == 'jpeg' || ext.toLowerCase() == 'jpg' || ext.toLowerCase() == 'doc' || ext.toLowerCase() == 'docx' || ext.toLowerCase() == 'rtf' || ext.toLowerCase() == 'odt' || ext.toLowerCase() == 'pdf' || ext.toLowerCase() == 'xlsx' || ext.toLowerCase() == 'xls' || ext.toLowerCase() == 'csv') {
      return true;
    }
    else {
      return false;
    }
  }
  onSubmit(frm: NgForm, tab_id: number, form_id: number) {
    this.nextTabId=tab_id;
    if(form_id != 6)
    {
    this.nextTabId=$('#myTab > .active').next('li').find('a').attr('id').match(/\d+/)[0];
    }
    if (frm.valid) {
      this.activeTab = this.nextTabId;
      this.activeForm = this.nextTabId;
      let activeTab = $('a#tab_'+this.nextTabId);
          activeTab[0].click();
    }
     // only for form 3
     if (tab_id == 3 && form_id == 3) {
      this.activeTab = this.nextTabId;
      this.activeForm = this.nextTabId;
      let activeTab = $('a#tab_'+this.nextTabId);
        activeTab[0].click();
    }
  }


  // tslint:disable-next-line:max-line-length
  onSubmitRegistrationForm(frm1: NgForm, frm2: NgForm, frm3: NgForm, frm4: NgForm, frm5: NgForm, frm6: NgForm, tab_id: number, form_id: number) {
    if (this.showSizeError == true || this.showTypeError == true) {  // check photo image size and type validation
      let activeTab1 = $('a#tab_1');
      activeTab1[0].click();
      // check other form1 value null or not. 
      if (frm1.value.program_id == '' || frm1.value.date_of_birth == '' || frm1.value.first_name == '' || frm1.value.last_name == '' || frm1.value.gender == '') {
        let tab1 = document.getElementById('step01');
        tab1.click();
      }
      if(this.globalVariable ==1)
      {
        this.showTypeError = true;
      } else if(this.globalVariable ==2) {
        this.showSizeError = true;
      }
      return false;
    }
    
    this.clearError('document_file');
    this.clearError('document_file1')

    if (frm1.valid && frm2.valid && frm4.valid && frm5.valid && frm6.valid) {
      this.disabled = true;
      this.activeTab = tab_id;
      this.activeForm = form_id;
      this.errorData = "";
      this.loading = true;

      // tslint:disable-next-line:max-line-lengtfrmh
      frm1.value.date_of_birth =
        frm1.value.date_of_birth.year +
        "-" + frm1.value.date_of_birth.month +
        "-" + frm1.value.date_of_birth.day;
      // tslint:disable-next-line:no-debugger
      if (frm3.value.bcg_dose1) {
        frm3.value.bcg_dose1 =
          frm3.value.bcg_dose1.year +
          "-" +
          frm3.value.bcg_dose1.month +
          "-" +
          frm3.value.bcg_dose1.day;
      }
      if (frm3.value.hepB_dose1) {
        frm3.value.hepB_dose1 =
          frm3.value.hepB_dose1.year +
          "-" +
          frm3.value.hepB_dose1.month +
          "-" +
          frm3.value.hepB_dose1.day;
      }
      if (frm3.value.hepB_dose2) {
        frm3.value.hepB_dose2 =
          frm3.value.hepB_dose2.year +
          "-" +
          frm3.value.hepB_dose2.month +
          "-" +
          frm3.value.hepB_dose2.day;
      }
      if (frm3.value.hepB_dose3) {
        frm3.value.hepB_dose3 =
          frm3.value.hepB_dose3.year +
          "-" +
          frm3.value.hepB_dose3.month +
          "-" +
          frm3.value.hepB_dose3.day;
      }
      // tslint:disable-next-line:max-line-length
      if (frm3.value.poliovirus_dose1) {
        frm3.value.poliovirus_dose1 =
          frm3.value.poliovirus_dose1.year +
          "-" +
          frm3.value.poliovirus_dose1.month +
          "-" +
          frm3.value.poliovirus_dose1.day;
      }
      if (frm3.value.poliovirus_dose2) {
        frm3.value.poliovirus_dose2 =
          frm3.value.poliovirus_dose2.year +
          "-" +
          frm3.value.poliovirus_dose2.month +
          "-" +
          frm3.value.poliovirus_dose2.day;
      }
      if (frm3.value.poliovirus_dose3) {
        // tslint:disable-next-line:max-line-length
        frm3.value.poliovirus_dose3 =
          frm3.value.poliovirus_dose3.year +
          "-" +
          frm3.value.poliovirus_dose3.month +
          "-" +
          frm3.value.poliovirus_dose3.day;
      }
      // tslint:disable-next-line:max-line-length
      if (frm3.value.dtp_dose1) {
        frm3.value.dtp_dose1 =
          frm3.value.dtp_dose1.year +
          "-" +
          frm3.value.dtp_dose1.month +
          "-" +
          frm3.value.dtp_dose1.day;
      }
      if (frm3.value.dtp_dose2) {
        frm3.value.dtp_dose2 =
          frm3.value.dtp_dose2.year +
          "-" +
          frm3.value.dtp_dose2.month +
          "-" +
          frm3.value.dtp_dose2.day;
      }
      if (frm3.value.dtp_dose3) {
        frm3.value.dtp_dose3 =
          frm3.value.dtp_dose3.year +
          "-" +
          frm3.value.dtp_dose3.month +
          "-" +
          frm3.value.dtp_dose3.day;
      }
      if (frm3.value.dtp_dose4) {
        frm3.value.dtp_dose4 =
          frm3.value.dtp_dose4.year +
          "-" +
          frm3.value.dtp_dose4.month +
          "-" +
          frm3.value.dtp_dose4.day;
      }
      if (frm3.value.dtp_dose5) {
        frm3.value.dtp_dose5 =
          frm3.value.dtp_dose5.year +
          "-" +
          frm3.value.dtp_dose5.month +
          "-" +
          frm3.value.dtp_dose5.day;
      }
      if (frm3.value.hib_dose1) {
        // tslint:disable-next-line:max-line-length
        frm3.value.hib_dose1 =
          frm3.value.hib_dose1.year +
          "-" +
          frm3.value.hib_dose1.month +
          "-" +
          frm3.value.hib_dose1.day;
      }
      if (frm3.value.hib_dose2) {
        frm3.value.hib_dose2 =
          frm3.value.hib_dose2.year +
          "-" +
          frm3.value.hib_dose2.month +
          "-" +
          frm3.value.hib_dose2.day;
      }
      if (frm3.value.hib_dose3) {
        frm3.value.hib_dose3 =
          frm3.value.hib_dose3.year +
          "-" +
          frm3.value.hib_dose3.month +
          "-" +
          frm3.value.hib_dose3.day;
      }
      if (frm3.value.hib_dose4) {
        frm3.value.hib_dose4 =
          frm3.value.hib_dose4.year +
          "-" +
          frm3.value.hib_dose4.month +
          "-" +
          frm3.value.hib_dose4.day;
      }
      if (frm3.value.pcv_dose1) {
        // tslint:disable-next-line:max-line-length
        frm3.value.pcv_dose1 =
          frm3.value.pcv_dose1.year +
          "-" +
          frm3.value.pcv_dose1.month +
          "-" +
          frm3.value.pcv_dose1.day;
      }
      if (frm3.value.pcv_dose2) {
        frm3.value.pcv_dose2 =
          frm3.value.pcv_dose2.year +
          "-" +
          frm3.value.pcv_dose2.month +
          "-" +
          frm3.value.pcv_dose2.day;
      }
      if (frm3.value.pcv_dose3) {
        frm3.value.pcv_dose3 =
          frm3.value.pcv_dose3.year +
          "-" +
          frm3.value.pcv_dose3.month +
          "-" +
          frm3.value.pcv_dose3.day;
      }
      if (frm3.value.pcv_dose4) {
        frm3.value.pcv_dose4 =
          frm3.value.pcv_dose4.year +
          "-" +
          frm3.value.pcv_dose4.month +
          "-" +
          frm3.value.pcv_dose4.day;
      }
      if (frm3.value.rv_dose1) {
        // tslint:disable-next-line:max-line-length
        frm3.value.rv_dose1 =
          frm3.value.rv_dose1.year +
          "-" +
          frm3.value.rv_dose1.month +
          "-" +
          frm3.value.rv_dose1.day;
      }
      if (frm3.value.rv_dose1) {
        frm3.value.rv_dose2 =
          frm3.value.rv_dose2.year +
          "-" +
          frm3.value.rv_dose2.month +
          "-" +
          frm3.value.rv_dose2.day;
      }
      if (frm3.value.rv_dose3) {
        frm3.value.rv_dose3 =
          frm3.value.rv_dose3.year +
          "-" +
          frm3.value.rv_dose3.month +
          "-" +
          frm3.value.rv_dose3.day;
      }
      if (frm3.value.typhoid_dose1) {
        // tslint:disable-next-line:max-line-length
        frm3.value.typhoid_dose1 =
          frm3.value.typhoid_dose1.year +
          "-" +
          frm3.value.typhoid_dose1.month +
          "-" +
          frm3.value.typhoid_dose1.day;
      }
      if (frm3.value.typhoid_dose2) {
        // tslint:disable-next-line:max-line-length
        frm3.value.typhoid_dose2 =
          frm3.value.typhoid_dose2.year +
          "-" +
          frm3.value.typhoid_dose2.month +
          "-" +
          frm3.value.typhoid_dose2.day;
      }
      if (frm3.value.mmr_dose1) {
        // tslint:disable-next-line:max-line-length
        frm3.value.mmr_dose1 =
          frm3.value.mmr_dose1.year +
          "-" +
          frm3.value.mmr_dose1.month +
          "-" +
          frm3.value.mmr_dose1.day;
      }
      if (frm3.value.mmr_dose2) {
        frm3.value.mmr_dose2 =
          frm3.value.mmr_dose2.year +
          "-" +
          frm3.value.mmr_dose2.month +
          "-" +
          frm3.value.mmr_dose2.day;
      }
      if (frm3.value.varicella_dose1) {
        // tslint:disable-next-line:max-line-length
        frm3.value.varicella_dose1 =
          frm3.value.varicella_dose1.year +
          "-" +
          frm3.value.varicella_dose1.month +
          "-" +
          frm3.value.varicella_dose1.day;
      }
      if (frm3.value.varicella_dose2) {
        // tslint:disable-next-line:max-line-length
        frm3.value.varicella_dose2 =
          frm3.value.varicella_dose2.year +
          "-" +
          frm3.value.varicella_dose2.month +
          "-" +
          frm3.value.varicella_dose2.day;
      }

      if (frm3.value.hepA_dose1) {
        // tslint:disable-next-line:max-line-length
        frm3.value.hepA_dose1 =
          frm3.value.hepA_dose1.year +
          "-" +
          frm3.value.hepA_dose1.month +
          "-" +
          frm3.value.hepA_dose1.day;
      }
      if (frm3.value.hepA_dose2) {
        frm3.value.hepA_dose2 =
          frm3.value.hepA_dose2.year +
          "-" +
          frm3.value.hepA_dose2.month +
          "-" +
          frm3.value.hepA_dose2.day;
      }
      if (frm3.value.tdap_dose1) {
        // tslint:disable-next-line:max-line-length
        frm3.value.tdap_dose1 =
          frm3.value.tdap_dose1.year +
          "-" +
          frm3.value.tdap_dose1.month +
          "-" +
          frm3.value.tdap_dose1.day;
      }
      if (frm3.value.hpv_dose1) {
        frm3.value.hpv_dose1 =
          frm3.value.hpv_dose1.year +
          "-" +
          frm3.value.hpv_dose1.month +
          "-" +
          frm3.value.hpv_dose1.day;
      }
      if (frm3.value.hpv_dose2) {
        // tslint:disable-next-line:max-line-length
        frm3.value.hpv_dose2 =
          frm3.value.hpv_dose2.year +
          "-" +
          frm3.value.hpv_dose2.month +
          "-" +
          frm3.value.hpv_dose2.day;
      }
      if (frm3.value.hpv_dose2) {
        frm3.value.hpv_dose3 =
          frm3.value.hpv_dose3.year +
          "-" +
          frm3.value.hpv_dose3.month +
          "-" +
          frm3.value.hpv_dose3.day;
      }
     
      /** for primary parent on  edit child*/
      if(this.id){
      if(frm4.value.isPrimary)
      {
        if(this.isFatherPrimary)
        {
          frm4.value.isPrimary='father';
        }
        else if(this.isMotherPrimary)
        {
          frm4.value.isPrimary='mother';
        }
        else if(this.isGuardianPrimary)
        {
          frm4.value.isPrimary= 'guardian';
        }
      }
      else
      {
        if(this.isFatherPrimary)
        {
          frm4.value.isPrimary='father';
        }
        else if(this.isMotherPrimary)
        {
          frm4.value.isPrimary='mother';
        }
        else if(this.isGuardianPrimary)
        {
          frm4.value.isPrimary= 'guardian';
        }
      }
    }
      this.childService
        .addChildRegistration(
          frm1.value,
          frm2.value,
          frm3.value,
          frm4.value,
          frm5.value,
          frm6.value,
          this.fileList,
          this.fileListDoc,
          this.fileListDoc1
        ).subscribe(
          result => {
            if (result.success === true) {
              this.toastr.success(result.message);
              this.router.navigate(["/child/list"]);
            } else {
              this.errorData = this.commonService.GetHandleMultilineErrorString(result.error);
              this.toastr.error(this.errorData);
            }
            this.loading = false;
            this.disabled = false;
          },
          err => {
            this.loading = false;
            this.disabled = false;
            if (err.error.error.errors == undefined || err.error.error.errors == '') {
              this.errorData = this.commonService.GetHandleMultilineErrorString(
                err.error
              );
            }
            else {
              this.errorData = err.error.error.errors[0].message;
              let activeTab4 = $('a#tab_4');
              activeTab4[0].click();
              let activeTab4_1tab = $('a#fatherInfo');
              activeTab4_1tab[0].click();
            }
            this.toastr.error(this.errorData);
          });
    } else {
      if (frm1.valid == false)      // if error return to tab1
      {
        let tab1 = document.getElementById('step01');
        tab1.click();
        let activeTab1 = $('a#tab_1');
        activeTab1[0].click();
      }
      else if (frm4.valid == false)   // if error return to tab4
      {
        let tab4 = document.getElementById('step04');
        tab4.click();
        let activeTab4 = $('a#tab_4');
        activeTab4[0].click();
        if (frm4.value.father_first_name == '' || frm4.value.father_last_name == '' || frm4.value.father_mobile_number == '' ||
          frm4.value.father_email == '' || frm4.value.father_country == '' || frm4.value.father_city == '' ||
          frm4.value.father_state == '' || frm4.value.father_zip_code == '' || frm4.value.father_address_line1 == '') {
          let activeTab4_1tab = $('a#fatherInfo');
          activeTab4_1tab[0].click();
        }
        else if (frm4.value.mother_first_name == '' || frm4.value.mother_last_name == '' || frm4.value.mother_mobile_number == '' ||
          frm4.value.mother_email == '' || frm4.value.mother_country == '' || frm4.value.mother_city == '' ||
          frm4.value.mother_state == '' || frm4.value.mother_zip_code == '' || frm4.value.mother_address_line1 == '') {
          let activeTab4_2tab = $('a#motherInfo');
          activeTab4_2tab[0].click();
        }
        else if (frm4.value.guardian_first_name == '' || frm4.value.guardian_last_name == '' || frm4.value.guardian_mobile_number == '' ||
          frm4.value.guardian_email == '' || frm4.value.guardian_country == '' || frm4.value.guardian_city == '' ||
          frm4.value.guardian_state == '' || frm4.value.guardian_zip_code == '' || frm4.value.guardian_address_line1 == '') {
          let activeTab4_3tab = $('a#guardianInfo');
          activeTab4_3tab[0].click();
        }
      }
      else if (frm2.valid == false)    // if error return to tab2
      {
        let activeTab2 = $('a#tab_2');
        activeTab2[0].click();
      }
      else if (frm5.valid == false)   // if error return to tab5
      {
        let activeTab5 = $('a#tab_5');
        activeTab5[0].click();
      }
    }
  }

  getSiblingByName(name: string) {
    if(this.id == 0)
    {
      this.frm4.reset();
    }
    
    if (name.length > 0) {
      this.childService.getSiblingByName(name).subscribe(result => {
        this.fatherData = result['data'].child_parents[0].parent.user;
        this.motherData = result['data'].child_parents[1].parent.user;
        this.guardianData = result['data'].child_parents[2].parent.user;
        this.fatherWorkplaceData = result['data'].child_parents[0].parent.work_place;
        this.motherWorkplaceData = result['data'].child_parents[1].parent.work_place;
        this.guardianWorkplaceData = result['data'].child_parents[2].parent.work_place;

        this.isFatherPrimary = result['data'].child_parents[0].parent.is_primary;
        this.isMotherPrimary = result['data'].child_parents[1].parent.is_primary;
        this.isGuardianPrimary = result['data'].child_parents[2].parent.is_primary;

        this.father = this.fatherData;
        this.fatherStates = this.onSelectCountry(this.father.country, 'fatherCountry');
        this.fatherWorkplace = this.fatherWorkplaceData;
        // father information

        // tslint:disable-next-line:max-line-length
        if (this.fatherWorkplaceData.email || this.fatherWorkplaceData.phone_number || this.fatherWorkplaceData.mobile_number || this.fatherWorkplaceData.address_line1 || this.fatherWorkplaceData.address_line2 || this.fatherWorkplaceData.country || this.fatherWorkplaceData.state || this.fatherWorkplaceData.city || this.fatherWorkplaceData.zip_code) {
          this.fatherWorkplaceExits = true;
          this.fatherWorkplace = this.fatherWorkplaceData;
          this.onSelectCountry(this.fatherWorkplace.country, 'fatherWorkplaceCountry');
        }

        // mother information
        this.mother = this.motherData;
        this.motherStates = this.onSelectCountry(this.mother.country, 'motherCountry');
        this.motherWorkplace = this.motherWorkplaceData;

        // tslint:disable-next-line:max-line-length
        if (this.motherWorkplaceData.email || this.motherWorkplaceData.phone_number || this.motherWorkplaceData.mobile_number || this.motherWorkplaceData.address_line1 || this.motherWorkplaceData.address_line2 || this.motherWorkplaceData.country || this.motherWorkplaceData.state || this.motherWorkplaceData.city || this.motherWorkplaceData.zip_code) {
          this.motherWorkplaceExits = true;
          this.motherWorkplace = this.motherWorkplaceData;
          this.onSelectCountry(this.motherWorkplace.country, 'motherWorkplaceCountry');
        }
        // guardian information
        this.guardian = this.guardianData;
        this.onSelectCountry(this.guardian.country, 'guardianCountry');
        this.guardianWorkplace = this.guardianWorkplaceData;

        // tslint:disable-next-line:max-line-length
        if (this.guardianWorkplaceData.email || this.guardianWorkplaceData.phone_number || this.guardianWorkplaceData.mobile_number || this.guardianWorkplaceData.address_line1 || this.guardianWorkplaceData.address_line2 || this.guardianWorkplaceData.country || this.guardianWorkplaceData.state || this.guardianWorkplaceData.city || this.guardianWorkplaceData.zip_code) {
          this.guardianWorkplaceExits = true;
          this.guardianWorkplace = this.guardianWorkplaceData;
          this.onSelectCountry(this.guardianWorkplace.country, 'guardianWorkplaceCountry');
        }

      },
        err => {
          if (err.error.error.length) {
            err.error.error.map((e, i) => {
              this.toastr.error(err.error.error[i].message);
            });
            this.loading = false;
            this.disabled = false;
          }
          else {
            this.toastr.error('Something went wrong');
          }
        });
    }
  }

  getPrograms() {
    this.programService.getAllPrograms().subscribe(results => {
      this.programData = results['data'].rows;
    },
      err => {
        if (err.error.error.length) {
          err.error.error.map((e, i) => {
            this.toastr.error(err.error.error[i].message);
          });
          this.loading = false;
          this.disabled = false;
        }
        else {
          this.toastr.error('Something went wrong');
        }
      });
  }
}
