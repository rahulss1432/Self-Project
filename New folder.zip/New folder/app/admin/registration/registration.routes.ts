import { RegistrationComponent } from './registration.component';
import { Routes, RouterModule } from '@angular/router';

const REGISTRATION_ROUTE: Routes = [
{
    path: '', component: RegistrationComponent, children: [
      { path: '', component: RegistrationComponent },
    ]
  }
  ,
]

export const registrationRouting = RouterModule.forChild(REGISTRATION_ROUTE);
