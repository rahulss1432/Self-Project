﻿import { RegistrationComponent } from './registration.component';
import { ChildService } from '.././child/service/child.service';
import { registrationRouting } from './registration.routes';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
// import { NgxPaginationModule } from 'ngx-pagination';
// import { TabsModule } from 'ngx-bootstrap';
import { SharedModule } from '../../shared/module/shared.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProgramService } from './../program/service/program.service';
// import { NumberOnlyDirective } from '../../shared/directive/number-only.directive';

@NgModule({
  declarations: [
    RegistrationComponent,
    // NumberOnlyDirective
  ],
  imports: [CommonModule, FormsModule,
    NgbModule.forRoot(),
    RouterModule, registrationRouting,
    //  NgxPaginationModule,
    //   TabsModule, SharedModule
  ],
  providers: [
    ChildService,
    ProgramService
  ]
})

export class RegistrationModule { }
