<?php
if (!defined('BASE_URL')) {
   define('BASE_URL', 'http://localhost/faf-html');
    //define('BASE_URL','http://caption.neuroninc.com/neuron/freeagentfootball/www/');	
}
if (!defined('IMAGES_URL')) {
   define('IMAGES_URL', 'http://localhost/faf-html');
    //define('IMAGES_URL','http://caption.neuroninc.com/neuron/freeagentfootball/www/');		
}


?>