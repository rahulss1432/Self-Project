@php
$faftubeLink = env('FAFTUBE_LINK');
@endphp
<!-- preloader -->
<div class="preloader" > 
    <div class="preloader_img">
        <img class="loader" src="{{ url('public/images/loader_img.svg') }}"  alt="logo" >
        <img class="logo" src="{{ url('public/images/green_logo.png') }}"  alt="logo" >
    </div>
</div>
<header class="theme_menu">
    <div class="top_header">
        <nav class="navbar navbar-expand-xl  d-flex align-items-start navbar-dark bg-dark">
            <a class="navbar-brand text-center" href="{{url('coach/dashboard')}}">
                <img src="{{ url('public/images/white_logo.png') }}" alt="logo">
            </a>
            <div class="navbar-collapse nav-wrap d-none d-xl-block" id="navbarNavDropdown">
                <div class="topnav">
                    <div class="left_side_nav">
                        <ul class="navbar-nav ">
                            <li class="nav-item " id="job-board">
                                <a class="nav-link" href="{{ url('view/jobs') }}">FAF JOB BOARD</a>
                            </li>
                            <li class="nav-item" id="news-detail">
                                <a class="nav-link" href="{{ url('/all-news-list') }}">FAF NEWS</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">FAF INTERNATIONAL SCOUTING SHOWCASE (FAFISS.com)</a>
                            </li>
                            <li class="nav-item row-sec">
                                <a class="nav-link" href="https://prodip.pro/password" target="_blank">FAF PRO-DAY</a>                                
                            </li>
                            <li class="nav-item" id="view-events">
                                <a class="nav-link" href="{{ url('view/events') }}">FAF EVENTS</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="{{$faftubeLink}}" target="_blank">FAFtube.com</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">FAF ALL-AMERICANS & WATCHLISTS</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="bottom_header text-center">
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item" id="home-item">
                            <a href="{{ url(getAuthGuard().'/dashboard') }}"><span>HOME</span></a>
                        </li>
                        @php $page= Request::segment(3);
                        @endphp
                        @if(!empty($page))
                        @php $getRole= Request::segment(2);@endphp
                        @if($getRole == 'player-profile')
                        <li class="list-inline-item" id="profile-item">
                            <a href="{{ url('view/player-profile/'.$page) }}"><span>PROFILE</span></a>
                        </li>
                        <li class="list-inline-item" id="timeline-item">
                            <a href="{{ url('player/player-timeline/'.$page) }}"><span>TIMELINE</span></a>
                        </li>
                        <li class="list-inline-item" id="media-item">
                            <a href="{{ url('player/player-media/'.$page) }}"><span>MEDIA</span></a>
                        </li>
                        @elseif($getRole == 'team-profile')
                        <li class="list-inline-item" id="profile-item">
                            <a href="{{ url('view/team-profile/'.$page) }}"><span>PROFILE</span></a>
                        </li>
                        <li class="list-inline-item" id="timeline-item">
                            <a href="{{ url('team/team-timeline/'.$page) }}"><span>TIMELINE</span></a>
                        </li>
                        <li class="list-inline-item" id="media-item">
                            <a href="{{ url('team/team-media/'.$page) }}"><span>MEDIA</span></a>
                        </li>
                        @else
                        <li class="list-inline-item" id="profile-item">
                            <a href="{{ url('view/coach-profile/'.$page) }}"><span>PROFILE</span></a>
                        </li>
                        <li class="list-inline-item" id="timeline-item">
                            <a href="{{ url('coach/coach-timeline/'.$page) }}"><span>TIMELINE</span></a>
                        </li>
                        <li class="list-inline-item" id="media-item">
                            <a href="{{ url('coach/coach-media/'.$page) }}"><span>MEDIA</span></a>
                        </li>
                        @endif
                        @else
                        <li class="list-inline-item" id="profile-item">
                            <a href="{{ url('coach/coach-profile') }}"><span>PROFILE</span></a>
                        </li>
                        <li class="list-inline-item" id="timeline-item">
                            <a href="{{ url('coach/coach-timeline') }}"><span>TIMELINE</span></a>
                        </li>
                        <li class="list-inline-item" id="media-item">
                            <a href="{{ url('coach/coach-media') }}"><span>MEDIA</span></a>
                        </li>
                        @endif
                    </ul>
                </div>
            </div>
            <div class="right_side_nav">
                <ul class="list-inline login_option">
                    <li class="list-inline-item icon">
                        <a href="{{ url(getAuthGuard().'/messages') }}">
                            <span class="ico"><i class="icon-envelope"></i></span>
                            <div class="badge count" id="message-notification" style="display: none"></div>
                        </a>
                    </li>
                    <li class="list-inline-item icon notification">
                        <a href="javascript:void(0);" onclick="readNotification()" role="button" id="notification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle">
                            <span class="ico"><i class="icon-notification_icon"></i></span>
                            <div class="badge count" id="user-notification"></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="notification">
                            <ul class="notification_dropdown green-scroll" id="notificationList" data-mcs-theme="my-theme">

                            </ul>
                            @if(getNotificationCount(Auth::guard(getAuthGuard())->user()->id)>0)
                            <div class="notification_bottom">
                                <a href="{{ url(getAuthGuard().'/notifications') }}" class="btn btn-dark text-uppercase border-2"> 
                                    SEE ALL
                                </a> 
                            </div>
                            @endif
                        </div>
                    </li>
                    <li class="list-inline-item icon">
                        <a href="{{ url(getAuthGuard().'/my-friend-request') }}">
                            <span class="ico"><i class="icon-user_icon"></i></span>
                            <div class="badge count" id="friend-request-count" style="display: none"></div>
                        </a>
                    </li>
                    <li class="list-inline-item userprofile">
                        <a href="javascript:void(0);" role="button" id="UserProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle">
                            <img src="{{ checkUserImage(Auth::guard(getAuthGuard())->user()->profile_image, getAuthGuard().'/thumb') }}" alt="user">
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="UserProfile">
                            <a href="{{ url(getAuthGuard().'/'.getAuthGuard().'-profile-form') }}" class="dropdown-item" ><i class="fas fa-user"></i> My Profile</a>
                            <a href="{{url('settings')}}" class="dropdown-item" ><i class="fas fa-cog"></i> Settings</a>
                            <a href="javascript:void(0);" class="dropdown-item" id="coachLogout" onclick="leaveChat({{  Auth::guard(getAuthGuard())->user()->id }})"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                        <form id="logout-form" action="{{ url(getAuthGuard().'/logout') }}" method="post" style="display:none;">
                            {{ csrf_field() }}
                        </form>
                    </li>
                </ul>
            </div>
            <div class="responsive_nav">
                <div class="d-xl-none toggle_btn">
                    <div class="x"></div>
                    <div class="y"></div>
                    <div class="z"></div>
                </div>
                <div class="circle"></div>
                <div class="menu">
                    <ul class="list-unstyled">
                        <li id="home-item1"><a href="{{ url(getAuthGuard().'/dashboard') }}">HOME</a></li>
                         @if(!empty($page))
                        @php $getRole= Request::segment(2);@endphp
                        @if($getRole == 'player-profile')
                        <li id="profile-item1"><a href="{{ url('view/player-profile/'.$page) }}">PROFILE</a></li>
                        <li id="timeline-item1"><a href="{{ url('player/player-timeline/'.$page) }}">TIMELINE</a></li>
                        <li id="media-item1"><a href="{{ url('player/player-media/'.$page) }}">MEDIA</a></li>
                        @elseif($getRole == 'team-profile')
                        <li id="profile-item1"><a href="{{ url('view/team-profile/'.$page) }}">PROFILE</a></li>
                        <li id="timeline-item1"><a href="{{ url('team/team-timeline/'.$page) }}">TIMELINE</a></li>
                        <li id="media-item1"><a href="{{ url('team/team-media/'.$page) }}">MEDIA</a></li>
                        @else
                        <li id="profile-item1"><a href="{{ url('view/coach-profile/'.$page) }}">PROFILE</a></li>
                        <li id="timeline-item1"><a href="{{ url('coach/coach-timeline/'.$page) }}">TIMELINE</a></li>
                        <li id="media-item1"><a href="{{ url('coach/coach-media/'.$page) }}">MEDIA</a></li>
                        @endif
                        @else
                        <li id="profile-item1"><a href="{{ url('coach/coach-profile') }}">PROFILE</a></li>
                        <li id="timeline-item1"><a href="{{ url('coach/coach-timeline') }}">TIMELINE</a></li>
                        <li id="media-item1"><a href="{{ url('coach/coach-media') }}">MEDIA</a></li>
                        @endif
                        <li id="job-board1"><a href="{{ url('/view/jobs') }}">FAF JOB BOARD</a></li>
                        <li id="news-detail1"><a href="{{ url('/all-news-list') }}">FAF NEWS</a></li>
                        <li><a href="javascript:void(0);">FAF INTERNATIONAL SCOUTING SHOWCASE (FAFISS.com)</a></li>
                        <li><a href="javascript:void(0);">FAF PRO-DAY</a></li>
                        <li id="view-events1"><a href="{{ url('/view/events') }}">FAF Events</a></li>
                        <li><a href="{{$faftubeLink}}" target="_blank">FAFtube.com</a></li>
                        <li><a href="javascript:void(0);">FAF ALL-AMERICANS & WATCHLISTS</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</header>
<script src='{{env("SOCKET_JS_URL")}}'></script>

<script>

                                        var user;
                                socket = io.connect('{{env("SOCKET_DOMAIN_URL")}}');
                                var userId = parseInt('{{ \Auth::guard(getAuthGuard())->user()->id }}');
                                socket.emit('setUsername', userId);
                                socket.on('userSet', function (data) {
                                user = data.username;
                                });
                                var user_role = '{{\Auth::guard(getAuthGuard())->user()->role}}';
                                var noti_read_unread_url = '';
                                var noti_get_url = '';
                                if (user_role == 'player')
                                {
                                noti_url = "{{ url('player/check-unread-count') }}";
                                noti_get_url = "{{ url('player/get-notification') }}";
                                request_unread_count_url = "{{ url('player/friend-request-unread-count') }}";
                                }
                                else if (user_role == 'team')
                                {
                                noti_url = "{{ url('team/check-unread-count') }}";
                                noti_get_url = "{{ url('team/get-notification') }}";
                                request_unread_count_url = "{{ url('team/friend-request-unread-count') }}";
                                }
                                else {
                                noti_url = "{{ url('coach/check-unread-count') }}";
                                noti_get_url = "{{ url('coach/get-notification') }}";
                                request_unread_count_url = "{{ url('coach/friend-request-unread-count') }}";
                                }

// Function for get unread count of friend request.
                                setInterval(function () {
                                $.get(request_unread_count_url, function (data) {
                                if (data > 0) {
                                $('#friend-request-count').show();
                                $('#friend-request-count').html(data);
                                } else {
                                $('#friend-request-count').hide();
                                }
                                });
                                }, 5000);
// Function for check notifications.
                                setInterval(function () {
                                $.get(noti_url, function (data) {
                                if (data > 0) {
                                $('#message-notification').show();
                                $('#message-notification').html(data);
                                } else {
                                $('#message-notification').hide();
                                }
                                });
                                }, 5000);
                                function leaveChat(userID) {
                                socket.emit('leave-chat', {userID: userID});
                                document.getElementById('logout-form').submit();
                                }

                                var id = '{{ Request::segment(2) }}';
                                if (id == 'dashboard') {
                                id = 'coach_home';
                                $('#home-item').addClass('active');
                                $('#home-item1').addClass('active');
                                } else if (id == 'coach-profile') {
                                id = 'coach-profile-page';
                                $('#profile-item').addClass('active');
                                $('#profile-item1').addClass('active');
                                } else if (id == 'other-coach-profile') {
                                id = 'coach-profile-page';
                                $('#profile-item').addClass('active');
                                $('#profile-item1').addClass('active');
                                } else if (id == 'coach-timeline') {
                                id = 'coach_timeline_page';
                                $('#timeline-item').addClass('active');
                                $('#timeline-item1').addClass('active');
                                } else if (id == 'coach-media') {
                                id = 'coach-media-page';
                                $('#media-item').addClass('active');
                                $('#media-item1').addClass('active');
                                } else if (id == 'coach-profile-form') {
                                id = 'step-form-page coach-step-page';
                                } else if (id == 'events') {
                                id = 'event_list';
                                $('#view-events').addClass('active');
                                $('#view-events1').addClass('active');
                                } else if (id == 'members-you-may-know') {
                                id = 'my-connections';
                                } else if (id == 'messages') {
                                id = 'messages_page';
                                } else if (id == 'notifications') {
                                id = 'notifications_page';
                                } else if (id == 'connections') {
                                id = 'my-connections';
                                } else if (id == 'my-friend-request') {
                                id = 'my-connections';
                                } else if (id == 'compare') {
                                id = 'coachcompare_page';
                                } else if (id == 'player-profile') {
                                id = 'profile_page';
                                $('#profile-item').addClass('active');
                                } else if (id == 'team-profile') {
                                id = 'team-profile-page';
                                $('#profile-item').addClass('active');
                                } else if (id == 'jobs'){
                                id = 'joblist-page';
                                $('#job-board').addClass('active');
                                $('#job-board1').addClass('active');
                                } else if (id == 'event-add' || id == 'edit-event'){ 
                                    id = 'event_add_page'; 
                                }
                                var id1 = '{{ Request::segment(1) }}';
                                if (id1 == 'search'){ id = 'search_result'; }
                                else if (id1 == 'post-details'){ id = 'post_details'; }
                                else if (id1 == 'news-details'){ id = 'news-details-page'; }
                                else if (id1 == 'jobs-detail') { id = 'jobdetail-page'; }
                                else if (id1 == 'event') { id = 'event_detail'; }
                                else if (id1 == 'advance-filter') { id = 'advance-search_page'; }
                                else if (id1 == 'settings') { id = 'settings'; }
                                else if (id1 == 'terms-and-service') { id = 'terms_and_conditions_page'; }                                                                
                                else if (id1 == 'all-news-list') { id = 'news_result'; $('#news-detail').addClass('active');
                                $('#news-detail1').addClass('active'); }
                                $('#wrapper-div').addClass(id);
                               
    $(document).ready(function () {
        loadNotificationList();
        setInterval(countNotificationList, 5000);
    });

    function loadNotificationList() {
        // pageLoader('notificationList', 'show');
        var url = "{{url('load-notification-list')}}";
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.success) {
                    $("#notificationList").html('');
                    $("#notificationList").html(response.html);
                }
            }
        });
    }

    function countNotificationList() {
        var url = "{{url('load-notification-count')}}";
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.data > 0) {
                    $('#user-notification').html(response.data);
                } else {
                    $('#user-notification').html('');
                }
            },
            error: function (err) {
            }
        });
    }

    function readNotification() {
        var url = "{{url('update-notification-list')}}";
        $.ajax({
            url: url,
            type: 'POST',
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
                loadNotificationList();
                countNotificationList();
            },
            error: function (err) {
            }
        });
    }

</script>