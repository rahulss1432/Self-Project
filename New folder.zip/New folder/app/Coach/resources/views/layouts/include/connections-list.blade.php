<div class="connections">
    <div class="block-head">
        <div class="heading text-center">
            <span class="ico icon-connection"></span>
            <span>CONNECTIONS</span>
            <!-- <h2>712</h2> -->
        </div>
    </div>
    <div class="conection-list">
        <ul class="list-inline">
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img01.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img02.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img03.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img04.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img05.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img06.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img07.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img08.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img09.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img10.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img11.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img12.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img13.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img14.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img15.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img04.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img05.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img06.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img07.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img08.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img09.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img11.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img13.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img10.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img11.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img12.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img13.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img14.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img08.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img01.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img10.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img03.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img04.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img09.png') }}" alt="user">
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img13.png') }}" alt="user">
                     <span class="badge badge-pill badge-success"></span>
                 </a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);">
                     <img src="{{ url('public/images/user_img03.png') }}" alt="user">
                 </a>
            </li>
        </ul>
        <div class="text-center view_btn">
            <a href="/my-connections.php?page=team">View All</a>
        </div>
    </div>
</div>

