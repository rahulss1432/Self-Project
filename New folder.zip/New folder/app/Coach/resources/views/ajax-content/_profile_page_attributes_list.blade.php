@if(count($user->coachAttributes)>0)
@php
$i=0;
@endphp
@foreach($user->coachAttributes as $attribute)
@php
if($i == 8){
break;
}
$i++;
@endphp
<li id="liattribute_{{$attribute['coachValidateAttribute']['title']}}">
    <div class="left-side">
        <p>{{$attribute['coachValidateAttribute']['title']}}</p>
    </div>
</li>
@endforeach 
@else 
<div class="alert alert-danger mt-md-5 mt-3" role="alert">
    No Attributes Found!
</div>                                
@endif