<div class="modal-header">
    <h5 class="modal-title" id="post_title">Attributes</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body p-0">
    <div class="scroll_body black-scroll">
        <div class="table-responsive">
            <table class="table info_table mb-0 text-center">
                <thead>
                    <tr>
                        <th>Title</th>
                         @if($viewByOtherUser == '') 
                           <th>Action</th>
                        @endif
                    </tr>
                </thead>
            
                <tbody>
                        @if(count($attributes->coachAttributes)>0)               
                @foreach($attributes->coachAttributes as $attribute)
                   
                        <tr id="attribute_{{$attribute['coachValidateAttribute']['id']}}">
                            <td>{{$attribute['coachValidateAttribute']['title']}}</td>
                            <td><div class="action">
                    @if($viewByOtherUser == '')                
                    <a href="javascript:void(0);" id="deletecollege1" onclick="callBootBox({{$attribute['coachValidateAttribute']['id']}}, 'attribute')" class="remove">
                        <i class="fas fa-trash"></i>
                    </a>
                    @endif
                </div></td>
                        </tr>
                       
                        @endforeach 
                @else 
                <div class="alert alert-danger" role="alert">
                    No Suggested Attributes.
                </div>                                
                @endif  
                </tbody>
            </table>
        </div>
    </div>
</div>