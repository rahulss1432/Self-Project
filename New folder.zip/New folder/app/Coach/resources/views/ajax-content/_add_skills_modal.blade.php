
<div class="modal-header ">
    <h4 class="modal-title" >ADD SKILLS</h4>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <!--<form action="">-->
    <div class="form-group search">
        <!--<input type="text" class="form-control" placeholder="Skill (ex: Data Analysis)" id="keywords" data-role="tagsinput">-->
        <select name="user_attribute" id="attributes" data-placeholder="Choose a attribute" multiple class="chzn-select select_list" onchange="hideValdationError()">
            <option value=""></option>
            @if(count($validatedAttributes) >0)
            @foreach($validatedAttributes as $attribute)
            <option value="{{$attribute->title}}" data-id="{{$attribute->id}}">{{$attribute->title}}</option>
            @endforeach                             
            @endif 
        </select>
        <small  class="form-text">You can add 43 more skills</small>
    </div>
    <div class="suggested_skills">
        <h6 >Suggested skills based on your profile:</h6>	
        <ul class="list-inline mt-3 mt-sm-4">
            @if($suggestedAttributes->count()>0)               
            @foreach($suggestedAttributes as $attribute)
            <li class="list-inline-item" id="liAttr_{{$attribute->id}}">
                <input type="checkbox" id="{{$attribute->id}}" name="suggestedAttribute" class="suggestedAttribute" value="{{$attribute->id}}" data-attr="{{$attribute->title}}" onchange="hideValdationError()" hidden="">
                <label for="{{$attribute->id}}">
                    <i class="flaticon-plus"></i> {{$attribute->title}}
                </label>
                <!-- <a href="javascript:void(0);">
                    <i class="flaticon-plus"></i>
                    {{$attribute->title}}
                </a> -->
            </li>
            @endforeach 
            @else 
            <div class="alert alert-danger" role="alert">
                No Suggested Attributes!
            </div>                                
            @endif                
        </ul>
    </div>
    <p id="error" style="display: none;color:red">Please select attribute</p>
    <!--</form>-->
</div>
<div class="modal-footer text-center">
    <a href="javascript:void(0);" class="add-more" id="add_skills"  onclick="addAttribute()">Add</a>
</div>
<script src="{{ url('public/js/chosen.jquery.js')}}"></script>
<script>
        $(document).ready(function () {
            $(".chzn-select").chosen({
                width: "100%"
            });

            $(".chosen-search-input").keydown(function (e) {
                if (e.which == 13) {
                    var checkPoint = $("#attributes_chosen").find("li").hasClass("no-results");
                    if (checkPoint == true) {
                        $("#attributes").append('<option value="' + $(this).val().toUpperCase() + '" selected="selected" id="' + $(this).val().toUpperCase() + '">' + $(this).val().toUpperCase() + '</option>');
                        $("#attributes").trigger("chosen:updated");
                        $(".chosen-results").find("li").removeClass("highlighted");
                        $(".chosen-results").find("li").removeClass("result-selected");
                    }
                }
            });

            /* Remove from dropdown if cancled from selected  */
            $('.chzn-select').on('change', function (evt, params) {
                if (params.deselected) {
                    $('#attributes > option').each(function () {
                        if ($(this).val() == params.deselected) {
                            if (this.id != '') {
                                $(this).remove();
                                $("#attributes").trigger("chosen:updated");
                            }
                        }
                    });
                }
                /* Remove from suggested attributes  */
                if (params.selected) {
                    $('.suggestedAttribute').each(function () {
                        if ($(this).data('attr') == params.selected) {
                            $('#liAttr_' + $(this).attr('id')).hide();
                        }
                    });
                }
            });

        });


        function addAttribute() {
            var checkedAttributes = [];
            document.getElementById('add_skills').style.pointerEvents = 'none';
            var selectedAttributes = $('#attributes').val();
            var _token = '{{ csrf_token() }}';
            $('.suggestedAttribute').each(function () {
                if ($(this).is(":checked")) {
                    checkedAttributes.push($(this).val());
                }

            });

            if (selectedAttributes.length == 0 && checkedAttributes.length == 0) {
                $('#error').show();
            } else {
                $('#error').hide();
                showButtonLoader('add_skills', 'ADD', 'disable');
                var url = "{{ url('coach/add-coach-skills') }}";
                $.ajax({type: "POST",
                    url: url,
                    dataType: 'JSON',
                    data: {_token: _token, selectedAttributes: selectedAttributes, checkedAttributes: checkedAttributes},
                    success: function (response) {
                        $('#AddSkills').modal('hide');
                        showButtonLoader('add_skills', 'ADD', 'enable');
                        if (response.success) {
                            message('success', response.message);
                            getAttributesList('attribute_list');
                        } else {
                            message('error', response.message);
                        }
                    },
                    error: function () {
                    },
                    complete: function () {
                        document.getElementById('add_skills').style.pointerEvents = 'auto';
                    }
                });
            }
        }

        function hideValdationError() {
            $('#error').hide();
        }

</script>
</script>