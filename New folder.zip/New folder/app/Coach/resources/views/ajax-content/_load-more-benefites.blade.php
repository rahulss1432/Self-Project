<div class="modal-header">
    <h5 class="modal-title" id="post_title">Desired Benefits</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <div class="scroll_body black-scroll">
        <div class="inner_section ">
            <div class="row benifits_list common_row">
                @if(count($user->userBenefits) > 0)
                @foreach($user->userBenefits as $benefites)
                    @if($benefites->masterBenefits->status == 'approved')
                        <div class="col-6 col-sm-3">
                            <div class="box_wrap d-flex align-items-center justify-content-center">
                                <div class="caption text-center">
                                    <i class="{{$benefites->masterBenefits->image}}"></i>
                                    <p class="mb-0 d-block">{{$benefites->masterBenefits->title}}</p>
                                </div>
                            </div>
                        </div>
                   @endif     
                @endforeach
               @else 
               <div class="col-6 col-sm-3">
                    <div class="box_wrap d-flex align-items-center justify-content-center">
                        <div class="caption text-center">
                            <i class="icon-benefit"></i>
                            <p class="mb-0 d-block">No benefit found</p>
                        </div>
                    </div>
                </div>
              @endif
            </div>
        </div>
    </div>
</div>