@if(count($notifications)>0)
@foreach($notifications as $notify)
@php
$role = getUserById($notify->from_id, 'role');
$slug = getUserById($notify->from_id, 'slug');
@endphp
<li class="d-flex align-items-center">
    <div class="user_img">
        @if($role == "admin" || $role == "subadmin")
        <img src="{{ checkUserImage(getUserById($notify->from_id, 'profile_image'), $role.'/thumb') }}" class="rounded-circle" alt="user">
        @else
        <a href="{{url($notify->url)}}">
            <img src="{{ checkUserImage(getUserById($notify->from_id, 'profile_image'), $role.'/thumb') }}" class="rounded-circle" alt="user">
        </a>
        @endif
    </div>
    <div class="caption">
        @if($role == "admin" || $role == "subadmin")
        <h6><span>{{$notify->message}}</span></h6>
        <p class="mb-0">{{fullTimeFormat($notify->created_at)}}</p>
        @else
        <a href="{{url($notify->url)}}">
            <h6>{{getUserById($notify->from_id, 'full_name')}} <span>{{$notify->message}}</span></h6>
            <p class="mb-0">{{fullTimeFormat($notify->created_at)}}</p>
        </a>
        @endif
    </div>
    <a href="javascript:void(0);" onclick="removeNotification('{{$notify->id}}')" class="delete"><i class="fas fa-trash-alt"></i></a>
</li>
@endforeach
@else
<div class="alert alert-danger text-center">No record found.</div>
@endif
{{$notifications->links()}}
<script>
    /*load more with pagination*/
    $(document).ready(function () {
        $("#NotificationsList").mCustomScrollbar("destroy"); /* Post scrolling */
            $("#NotificationsList").mCustomScrollbar({
            theme: "dark"
        });
    setTimeout(function () {
        $("ul.pagination li").first().remove();
    }, 500);
    $(".pagination li a").on('click', function (e) {
    e.preventDefault();
    $(".pagination li a").attr("disabled", true);
    showButtonLoader('explore-btn-loader', "MORE", "disable");
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'GET',
            url: pageLink,
            success: function (response) {
            $('.pagination:first').remove();
            $('#getNotificationList ul').append(response.html);
            },
            complete: function () {
            showButtonLoader('explore-btn-loader', "MORE", "enable");
            $("#NotificationsList").mCustomScrollbar("destroy"); /* Post scrolling */
            $("#NotificationsList").mCustomScrollbar({
            theme: "dark"
            });
            }
    });
    });
    $(".pagination li").addClass('load_more');
    $(".pagination li a").attr('id', 'explore-btn-loader');
    $(".pagination li a").html('Load More');
    });

</script>