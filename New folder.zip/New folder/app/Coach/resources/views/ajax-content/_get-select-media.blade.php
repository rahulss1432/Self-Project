@if(!empty($getSelectMedia) && count($getSelectMedia) > 0)
<div class="video-wrap">
    @if($getSelectMedia->media_type == 'image')
    <div class="photo d-flex align-items-center justify-content-center">
        <img  src="{{ checkMediaImage($getSelectMedia->media, getUserById($getSelectMedia->user_id, 'role')) }}"  alt="player-media-video">
    </div>
    @else 
     <div class="video d-flex align-items-center justify-content-center">
	    <video autoplay="true" muted="">
	        <source src="{{ checkMediaVideo($getSelectMedia->media, getUserById($getSelectMedia->user_id, 'role')) }}" type="video/mp4">
	    </video>
    </div>
    @endif
</div>
@else 
<div class="video-wrap">
<div class="photo d-flex align-items-center justify-content-center">
    <img  src="{{ url('public/images/default-media.jpg') }}" alt="player-media-video">
</div>
</div>
@endif