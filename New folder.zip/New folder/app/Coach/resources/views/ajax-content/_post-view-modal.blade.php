<div class="owl-carousel owl-theme" id="PostList_Slider">
    @if(!empty($getPost))
    @foreach($getPost as $key => $postMedia)
    <div class="item">
        @if($postMedia->media_type == 'image')
        <div class="leftside float-lg-left d-flex align-items-center justify-content-center" >
            <img src="{{ checkMediaImage($postMedia->media, getUserById($postMedia->user_id, 'role')) }}" class="img-fluid" alt="post img">
            <div class="overlay"></div>
            <div class="owlcarousel_nav d-flex align-items-center">
                <div class="owlcarousel_arrow ml-auto">
                    @if($key > 0 ) <a href="javascript:void(0);" onclick="getMediaCommentList('{{ $getPost[$key - 1]->id }}')" class="prearrow"> </a>@endif
                    @if($key < count($getPost) - 1 )<a href="javascript:void(0);" onclick="getMediaCommentList('{{ $getPost[$key + 1]->id }}')" class="nextarrow"></a>@endif
                </div>
            </div>
        </div>
        @else
        <div class="leftside float-lg-left d-flex align-items-center justify-content-center">
            <video controls >
                <source src="{{ checkMediaVideo($postMedia->media, getUserById($postMedia->user_id, 'role')) }}" type="video/mp4">
            </video>
            <!-- <div class="overlay"></div> -->
            <div class="owlcarousel_nav d-flex align-items-center">
                <div class="owlcarousel_arrow ml-auto">
                    @if($key > 0 ) <a href="javascript:void(0);" onclick="getMediaCommentList('{{ $getPost[$key - 1]->id }}')" class="prearrow"> </a>@endif
                    @if($key < count($getPost) - 1 )<a href="javascript:void(0);" onclick="getMediaCommentList('{{ $getPost[$key + 1]->id }}')" class="nextarrow"></a>@endif
                </div>
            </div>
        </div>
        @endif   
        <div class="rightside pr-0 float-lg-left">
            <div class="manage_post">
                <div class="post_comment">
                    <div class="inner pb-0">
                        <h2>{{ (getUserById($postMedia->user_id, 'reference_id')) ? getUserById($postMedia->user_id, 'reference_id') : '' }}</h2>
                        <h3>{{ (!empty(getUserFullNameById($postMedia->user_id))) ? getUserFullNameById($postMedia->user_id) : '-' }}</h3>
                        <div class="d-flex align-items-center  mt-2 mt-sm-4">
                            <p class="date_time mb-0">{{ dateTimeFormat($postMedia->created_at) }}</p>
                            <ul class="list-inline mb-0 ml-auto">
                                @php
                                $getImage = getIncidentDataByStatus(Auth::guard(getAuthGuard())->user()->id,$postMedia->id, 'image');
                                $getVideo = getIncidentDataByStatus(Auth::guard(getAuthGuard())->user()->id,$postMedia->id, 'video');
                                @endphp
                                @if(!checkLoginUser($postMedia->user_id))
                                @if($postMedia->media_type == 'image')
                                @if($getImage != 'open')
                                <li class="list-inline-item">
                                    <a href="javascript:void(0);" onclick="addReport('{{Auth::guard(getAuthGuard())->user()->id}}','{{$postMedia->id}}', 'image')">
                                        <i class="flaticon-flag"></i>
                                    </a>
                                </li>
                                @endif
                                @else
                                @if($getVideo != 'open')
                                <li class="list-inline-item">
                                    <a href="javascript:void(0);" onclick="addReport('{{Auth::guard(getAuthGuard())->user()->id}}','{{$postMedia->id}}', 'video')">
                                        <i class="flaticon-flag"></i>
                                    </a>
                                </li>
                                @endif
                                @endif
                                @endif
                                <li class="list-inline-item">
                                    <a href="javascript:void(0);" id="likeCount{{ $postMedia->id }}" onclick="getMediaLikeUserList('{{ $postMedia->id }}')"><i class="icon icon-thumb-up-sign icon"></i>{{ mediaLikeCount($postMedia->id,'like') }}</a></li>
                                <li class="list-inline-item" id="commentCount{{ $postMedia->id }}"><i class="icon icon-chat icon"></i>{{ mediaLikeCount($postMedia->id, 'comment')}}</li>
                            </ul>
                        </div>
                    </div>
                    <div class="post_info mt-3 pt-0">
                        <h3 class="text-truncate">{{ ($postMedia->post->post) ? $postMedia->post->post : '' }}</h3>
                        <p class="mb-0 mCustomScrollbar" data-mcs-theme="dark"></p>
                    </div>
                </div>
                <div class="post_comment_listing">
                    <h2 class="heading pb-0">Comments</h2>
                    <div class="ajax_list_load" id="get-media-comment-list{{ $postMedia->id }}"></div>
                </div>
                <div class="user_comment collapse show pt-0" id="comment01" style="">
                    <div class="like_icon" id="like-icone{{ $postMedia->id }}">
                        @php $loginUser = Auth::guard(getAuthGuard())->user()->id; @endphp
                        <a href="javascript:void(0);"  id="like-btn{{ $postMedia->id }}" class="{{ (checkUserMediaLike($postMedia->id, $loginUser, 'like') != 0) ? 'active' : '' }}" onclick="likeMedia('{{ $postMedia->id }}','{{ $postMedia->user_id }}')"><i class="icon icon-thumb-up-sign icon"></i></a>
                    </div>
                    <div class="comment_box">
                        <form action="javascript:void(0)" id="commentForm{{ $postMedia->id }}">
                            <input   type="hidden" name="media_id" value="{{ $postMedia->id }}">
                            <input   type="hidden" name="to_id" value="{{ $postMedia->user_id }}">
                            <input class="form-control" name="comment" id="commentdata_{{$postMedia->id}}" type="text" placeholder="Write a Comment...">
                            <div class="uploadicon">
                                <button class="icon-sent-mail" id="saveCommentbtn" onclick="saveMediaComment('{{ $postMedia->id }}','{{ $postMedia->user_id }}')"></button>
                            </div>
                        </form>
                    </div>
                </div>
                <!--  -->
            </div>
        </div>
    </div>
    @endforeach
    @else
    <div class="alert alert-danger text-center">No Record Found</div>
    @endif
</div>
<script>
    $(document).ready(function() {
    var mediaId = '{{ (!empty($getPost[0]->id)) ? $getPost[0]->id : '' }}';
    getMediaCommentList(mediaId);
    var owl = $('#PostList_Slider');
    $('.nextarrow').click(function() {
    owl.trigger('next.owl.carousel');
    })
            // Go to the previous item
            $('.prearrow').click(function() {
    owl.trigger('prev.owl.carousel');
    })

            $('#PostList_Slider').owlCarousel({
    items: 1,
            dots: true,
            nav: false,
            loop: false,
            mouseDrag:false,
            animateOut: 'fadeOut'
    })

            $('.owlcarousel_dots').on('click', 'li', function(e) {
    owl.trigger('to.owl.carousel', [$(this).index(), 300]);
    });
    // setTimeout(function () {
    //     $(window).resize(function () {
    //         var chk_height = $('#myPhotosVideos .leftside').outerHeight(true) ;
    //         var window_height = $(window).height();
    //         $("#myPhotosVideos .rightside").css('min-height', window_height - chk_height - 170);
    //     }).resize();
    //   }, 100);       
    });
    $(document).ready(function() {
    if ($(window).width() >= 1024){
    var divHeight = $('#myPhotosVideos .leftside').height();
    $('#myPhotosVideos .rightside').css('height', divHeight + 'px');
    }

    });
    // iphone scroll remove
    $('#myPhotosVideos').on('touchmove', function(e) {
    e.preventDefault();
    e.stopPropagation();
    return false;
    });
    function getMediaCommentList(mediaId){
    $("#get-media-comment-list" + mediaId).html('<span class="ajax_loader btn_ring"></span>');
    var url = '{{ url("coach/media-comment-list") }}';
    $.ajax({
    type: "GET", url: url, data: {media_id : mediaId},
            success: function (response) {
            setTimeout(function(){
            console.log(mediaId);
            $("#get-media-comment-list" + mediaId).html(response.html);
            $(".comment").mCustomScrollbar({
            theme:"dark",
                    axis:"y",
            });
            }, 500);
            }
    });
    }

//    like media
    function likeMedia(mediaId, toId){
    var url = "{{  url('coach/save-media-like') }}";
    $.ajax({
    url: url,
            data: {media_id:mediaId, to_id:toId},
            type: 'GET',
            success: function (data) {
            if (data.success) {
            $('#likeCount' + mediaId).html('');
            $('#likeCount' + mediaId).html('<i class="icon icon-thumb-up-sign icon"></i>' + data.count);
            if (data.event == 'unlike'){
            $('#like-btn' + mediaId).attr('class', 'inactive');
            } else{
            $('#like-btn' + mediaId).attr('class', 'active');
            }
            } else {
            message('error', data.message);
            }
            },
    });
    }

    //    save media comment 
    function saveMediaComment(mediaId, toId) {
    console.log(mediaId);
    var comment = document.getElementById('commentdata_' + mediaId).value;
    if (comment == ''){
    return false;
    }
    $('#saveCommentbtn').prop('disabled', true);
    var url = "{{  url('coach/save-media-comment') }}";
    var formData = $("#commentForm" + mediaId).serializeArray();
    console.log(formData);
    formData.push({name: '_token', value: '{{ csrf_token() }}'});
    $.ajax({
    url: url,
            data: formData,
            type: 'POST',
            success: function (data) {
            $('#saveCommentbtn').prop('disabled', false);
            if (data.success) {
            $('#commentCount' + mediaId).html('');
            $('#commentCount' + mediaId).html('<i class="icon icon-chat icon"></i>' + data.count);
            $('#commentdata_' + mediaId).val('');
            getMediaCommentList(mediaId);
            } else {
            message('error', data.message);
            }
            },
            error: function (err) {
            message('error', err);
            },
    });
    }

//    get like media user list
    function getMediaLikeUserList(mediaId) {
    var countLike = $('#likeCount' + mediaId).text();
    if (countLike != 0){
    $('#likeCount' + mediaId).attr('data-dismiss', 'modal');
    $('#users_like').modal('show');
    $.post("{{ url('coach/get-media-like-user') }}", {media_id: mediaId, _token: '{{ csrf_token() }}'}, function (response) {
    if (response.success) {
    $('#LikeUserList').html(response.html);
    } else {
    message('error', response.message);
    }
    });
    }
    }

</script>
