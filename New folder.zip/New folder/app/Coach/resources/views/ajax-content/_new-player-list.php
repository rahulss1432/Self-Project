<div class="new-player">
    <div class="player-details">
        <div class="top-heading d-flex">
            <img src="../images/white_logo.png" alt="logo">
            <h2>desean jackson</h2>
        </div>
        <div class="info-sec">
            <div class="left">
                <ul class="list-unstyled">
                    <li>
                        <p>HT</p><span>6'1"</span></li>
                    <li>
                        <p>WT</p><span>195</span></li>
                    <li>
                        <p>40</p><span>4.5</span></li>
                    <li>
                        <p>VERT</p><span>36</span></li>
                </ul>
            </div>
            <div class="right d-flex flex-wrap">
                <div class="profile-box">
                    <div class="user_profile">
                        <img src="../images/player1.jpg" alt="player">
                    </div>
                    <div class="profile-box-bottom d-flex align-items-center">
                        <img src="../images/american_flag.jpg" alt="FLAG">
                        <h4>Georgia</h4>
                    </div>
                </div>
                <div class="user_details">
                    <div class="player-top d-flex">
                        <h4>player </h4>
                        <span>rb/db</span>
                    </div>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <h4>AGE: <span>24</span></h4>
                        </li>
                        <li>
                            <h4>CURRENTLY UNDER CONTRACT: <span>NO</span></h4>
                        </li>
                        <li>
                            <h4>CURRENT TEAM: <span>Altianta Havoc</span></h4>
                        </li>
                        <li>
                            <h4>CURRENT LEAGUE: <span>AAL</span></h4>
                        </li>
                        <li>
                            <h4>LOOKING TO SIGN: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>PASSPORT READY: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4> PREP/COLLEGE EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>PRO EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>INTERNATIONAL EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>INDOOR  EXPERIENCE: <span>YES</span></h4>
                        </li>
                    </ul>
                </div>
                <div class="bottom-sec">
                    <h6>freeagentfootball.com</h6>
                </div>
            </div>
        </div>
        <div class="share-bottom">
            <a href="javascript:void(0);"><span class="icon-share_icon"></span> </a>
        </div>
    </div>
</div>
<div class="new-player">
    <div class="player-details">
        <div class="top-heading d-flex">
            <img src="../images/white_logo.png" alt="logo">
            <h2>desean jackson</h2>
        </div>
        <div class="info-sec">
            <div class="left">
                <ul class="list-unstyled">
                    <li>
                        <p>HT</p><span>6'1"</span></li>
                    <li>
                        <p>WT</p><span>195</span></li>
                    <li>
                        <p>40</p><span>4.5</span></li>
                    <li>
                        <p>VERT</p><span>36</span></li>
                </ul>
            </div>
            <div class="right d-flex flex-wrap">
                <div class="profile-box">
                    <div class="user_profile">
                        <img src="../images/player1.jpg" alt="player">
                    </div>
                    <div class="profile-box-bottom d-flex align-items-center">
                        <img src="../images/american_flag.jpg" alt="FLAG">
                        <h4>Georgia</h4>
                    </div>
                </div>
                <div class="user_details">
                    <div class="player-top d-flex">
                        <h4>player </h4>
                        <span>rb/db</span>
                    </div>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <h4>AGE: <span>24</span></h4>
                        </li>
                        <li>
                            <h4>CURRENTLY UNDER CONTRACT: <span>NO</span></h4>
                        </li>
                        <li>
                            <h4>CURRENT TEAM: <span>Altianta Havoc</span></h4>
                        </li>
                        <li>
                            <h4>CURRENT LEAGUE: <span>AAL</span></h4>
                        </li>
                        <li>
                            <h4>LOOKING TO SIGN: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>PASSPORT READY: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4> PREP/COLLEGE EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>PRO EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>INTERNATIONAL EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>INDOOR  EXPERIENCE: <span>YES</span></h4>
                        </li>
                    </ul>
                </div>
                <div class="bottom-sec">
                    <h6>freeagentfootball.com</h6>
                </div>
            </div>
        </div>
        <div class="share-bottom">
            <a href="javascript:void(0);"><span class="icon-share_icon"></span> </a>
        </div>
    </div>
</div>
<div class="new-player">
    <div class="player-details">
        <div class="top-heading d-flex">
            <img src="../images/white_logo.png" alt="logo">
            <h2>desean jackson</h2>
        </div>
        <div class="info-sec">
            <div class="left">
                <ul class="list-unstyled">
                    <li>
                        <p>HT</p><span>6'1"</span></li>
                    <li>
                        <p>WT</p><span>195</span></li>
                    <li>
                        <p>40</p><span>4.5</span></li>
                    <li>
                        <p>VERT</p><span>36</span></li>
                </ul>
            </div>
            <div class="right d-flex flex-wrap">
                <div class="profile-box">
                    <div class="user_profile">
                        <img src="../images/player1.jpg" alt="player">
                    </div>
                    <div class="profile-box-bottom d-flex align-items-center">
                        <img src="../images/american_flag.jpg" alt="FLAG">
                        <h4>Georgia</h4>
                    </div>
                </div>
                <div class="user_details">
                    <div class="player-top d-flex">
                        <h4>player </h4>
                        <span>rb/db</span>
                    </div>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <h4>AGE: <span>24</span></h4>
                        </li>
                        <li>
                            <h4>CURRENTLY UNDER CONTRACT: <span>NO</span></h4>
                        </li>
                        <li>
                            <h4>CURRENT TEAM: <span>Altianta Havoc</span></h4>
                        </li>
                        <li>
                            <h4>CURRENT LEAGUE: <span>AAL</span></h4>
                        </li>
                        <li>
                            <h4>LOOKING TO SIGN: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>PASSPORT READY: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4> PREP/COLLEGE EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>PRO EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>INTERNATIONAL EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>INDOOR  EXPERIENCE: <span>YES</span></h4>
                        </li>
                    </ul>
                </div>
                <div class="bottom-sec">
                    <h6>freeagentfootball.com</h6>
                </div>
            </div>
        </div>
        <div class="share-bottom">
            <a href="javascript:void(0);"><span class="icon-share_icon"></span> </a>
        </div>
    </div>
</div>
<div class="new-player">
    <div class="player-details">
        <div class="top-heading d-flex">
            <img src="../images/white_logo.png" alt="logo">
            <h2>desean jackson</h2>
        </div>
        <div class="info-sec">
            <div class="left">
                <ul class="list-unstyled">
                    <li>
                        <p>HT</p><span>6'1"</span></li>
                    <li>
                        <p>WT</p><span>195</span></li>
                    <li>
                        <p>40</p><span>4.5</span></li>
                    <li>
                        <p>VERT</p><span>36</span></li>
                </ul>
            </div>
            <div class="right d-flex flex-wrap">
                <div class="profile-box">
                    <div class="user_profile">
                        <img src="../images/player1.jpg" alt="player">
                    </div>
                    <div class="profile-box-bottom d-flex align-items-center">
                        <img src="../images/american_flag.jpg" alt="FLAG">
                        <h4>Georgia</h4>
                    </div>
                </div>
                <div class="user_details">
                    <div class="player-top d-flex">
                        <h4>player </h4>
                        <span>rb/db</span>
                    </div>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <h4>AGE: <span>24</span></h4>
                        </li>
                        <li>
                            <h4>CURRENTLY UNDER CONTRACT: <span>NO</span></h4>
                        </li>
                        <li>
                            <h4>CURRENT TEAM: <span>Altianta Havoc</span></h4>
                        </li>
                        <li>
                            <h4>CURRENT LEAGUE: <span>AAL</span></h4>
                        </li>
                        <li>
                            <h4>LOOKING TO SIGN: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>PASSPORT READY: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4> PREP/COLLEGE EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>PRO EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>INTERNATIONAL EXPERIENCE: <span>YES</span></h4>
                        </li>
                        <li>
                            <h4>INDOOR  EXPERIENCE: <span>YES</span></h4>
                        </li>
                    </ul>
                </div>
                <div class="bottom-sec">
                    <h6>freeagentfootball.com</h6>
                </div>
            </div>
        </div>
        <div class="share-bottom">
            <a href="javascript:void(0);"><span class="icon-share_icon"></span> </a>
        </div>
    </div>
</div>