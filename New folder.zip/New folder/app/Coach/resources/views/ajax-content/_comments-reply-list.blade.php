@if( count($comments) > 0 )
@foreach( $comments as $comment )
<li class="msg d-flex">
    <div class="msg_left">
        <img src="{{ checkUserImage($comment->user->profile_image, $comment->user->role.'/thumb') }}" class="rounded-circle" alt="user">
    </div>
    <div class="msg_body">
        <h6 class="msg_heading">
            {{ $comment->user->first_name . ' ' . $comment->user->last_name }}
            <span class="time">| &nbsp; {{ dateDayAgo($comment->created_at) }}</span>
        </h6>
        <p>{{ $comment->comment }}</p>
    </div>
</li>
@endforeach
<a href="javascript:void(0);" class="load-more-btn-reply-{{ $comment->post_action_id }}" onclick="loadMoreCommentReply('{{ $comment->post_action_id }}')">View all reply</a>
@endif