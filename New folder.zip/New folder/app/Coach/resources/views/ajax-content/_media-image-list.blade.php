<div class="container-fluid">
    <div class="common_heading d-sm-flex justify-content-sm-between align-items-sm-center">
        <h3 class="black black-lg">
            PHOTOS
        </h3>
        <div class="text-right common_pagination  mt-3 mt-sm-0">
            <nav aria-label="Page navigation example" title="image">
                {{ $getimages->links('vendor.pagination.simple-bootstrap-4')}} 
            </nav>
        </div>
    </div>
    <div class="row custom-gutters">
        @if(count($getimages) > 0)
        @php $i = 1 @endphp
        @foreach($getimages as $image)
        <div class="col-sm col-6">
            <div class="photo-box">
                <a href="javascript:void(0);" onclick="getMediaModal('{{ $image->id }}')">
                    <img src="{{ checkMediaImage($image->media, 'coach/thumb') }}" alt="photo" class="img-fluid">
                </a>
                @if($image->user_id == Auth::guard(getAuthGuard())->user()->id)
                <input type="radio" name="media" {{ ($image->order_by == '1') ? 'checked' : ''}} id="photo{{$image->id}}" hidden="" onclick="updateSelectMedia('{{ $image->id }}')">
                <label for="photo{{$image->id}}" class="select_list mb-0">
                    <i class="fas fa-check"></i>
                </label>
                @endif
            </div>
        </div>
        @if($i == 5)
        @php $i = 0; @endphp
        <div class="w-100 d-none d-sm-block"></div>
        @endif
        @php $i++ @endphp
        @endforeach
        @else 
        <div class="col-12">
            <div class="alert alert-danger text-center">No Record Found</div>
        </div>
        @endif
    </div>
    <div class="left_loader">
        <div class="border_loader">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>
<script>
    $(".pagination li a").on('click', function (e) {
        var type = $(this).parent().parent().parent().attr('title');
        if (type == 'image') {
            e.preventDefault();
            var $this = $(this);
            var pageLink = $this.attr('href');
            getMediaImageList(pageLink);
        }
    });
</script>