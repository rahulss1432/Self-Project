<div class="modal-header">
    <h5 class="modal-title" id="post_title">{{$experienceType}} Experience</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body p-0">
    <div class="scroll_body black-scroll">
        <div class="table-responsive">
            <table class="table info_table mb-0 text-center">
                <thead>
                    <tr>
                        <th>Experience type</th>
                        <th>Duration (year)</th>
                    </tr>
                </thead>
                <tbody>
                    @if($userExperience->count()>0)
                        @foreach($userExperience as $experience)
                        <tr>
                            @if($experience['user_exp_type'] == 'international' || $experience['user_exp_type'] == 'indoor')
                            
                            <td>{{!empty($experience) ? getLevelName($experience['experience_type']) : '-'}}</td>
                            @else
                             <td>{{!empty($experience) ? $experience['experience_type'] : '-'}}</td>
                            @endif
                            <td>{{!empty($experience) ? $experience['from_year'] .'-'. $experience['to_year'] : '-'}}</td>
                        </tr>
                        @endforeach
                     @endif
                </tbody>
            </table>
        </div>
    </div>
</div>
