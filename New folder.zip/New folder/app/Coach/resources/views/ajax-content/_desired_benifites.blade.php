<div class="user_benefits">
    <div class="profile d-block d-md-none">
        <img class="rounded-circle" src="{{ url('public/images/user_img.jpg') }}" alt="user">
    </div>
    @foreach($masterBenefits as $benefits)
    <div class="polygon {{$benefits->class}} {{(getUserBenefit($benefits->id,$user->id) == 'true')?'active':''}}">
        <div class="icon">
            @php 
            $imageName = (getUserBenefit($benefits->id,$user->id) == 'true')?$benefits->image:$benefits->image.'-gray';
            @endphp
            <img class="iconimg" src="{{ url('public/images/benifits_icons/'.$imageName.'.png') }}" alt="icon">
            <div class="caption">
                <h4 class="<?php echo (trim($benefits->title) == 'Salary') ? 'salary text-center' : ''; ?>">{{trim($benefits->title)}}
                    @if(trim($benefits->title) == 'Salary')
                    <br> <span>{{!empty(getUserById($user->id,'from_salary'))?'$'.getUserById($user->id,'from_salary'):''}} - {{!empty(getUserById($user->id,'to_salary'))?'$'.getUserById($user->id,'to_salary'):''}}</span>
                    @endif
                </h4>
                <span class="point"></span>
            </div>
            {!!$benefits->svg_path!!}
        </div>
        <div class="caption d-inline-block d-md-none">
            <h4 class="color-green <?php echo (trim($benefits->title) == 'Salary') ? 'salary' : ''; ?>">{{$benefits->title}}
                @if(trim($benefits->title) == 'Salary')
                <br><span>{{!empty(getUserById($user->id,'from_salary'))?'$'.getUserById($user->id,'from_salary'):''}} - {{!empty(getUserById($user->id,'to_salary'))?'$'.getUserById($user->id,'to_salary'):''}}</span>
                @endif
            </h4>
        </div>
    </div>
    @endforeach
    <div class="profile d-none d-md-block">
        <img class="rounded-circle" src="{{ checkUserImage($user->profile_image, $user->role) }}" alt="user">
    </div>
</div>
@if(count($user->userBenefits) > 0)
<div class="text-center seeall_btn mt-xl-4 mt-3">
    <a href="javascript:void(0);" class="btn btn-success btn-sm border-1 p-6-15 font-14" id="loader_more_benefit" onclick="loadMoreBenefits()">SEE ALL</a>
</div>
@endif