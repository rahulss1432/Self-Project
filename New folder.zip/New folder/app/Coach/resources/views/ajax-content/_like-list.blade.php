<div class="modal-header">  
    <h5 class="modal-title" id="exampleModalLabel">Users Like({{ count($likeUsers) }})</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
@if( count($likeUsers) > 0 )
<div class="modal-body mt-0">
    <ul class="list-unstyled mb-0 black-scroll mCustomScrollbar user_like_scroll" data-mcs-theme="dark">
        @foreach( $likeUsers as $likeUser )
        <li>
            <div class="imgdiv">
                <img src="{{ checkUserImage((!empty($likeUser->user)) ? $likeUser->user->profile_image : $likeUser->fromUser->profile_image, (!empty($likeUser->user->role)) ? $likeUser->user->role : $likeUser->fromUser->role) }}" class="rounded-circle" alt="user">
            </div>
            <div class="caption">
                <h4 class="text-capitalize">{{ (!empty($likeUser->user)) ? $likeUser->user->full_name : $likeUser->fromUser->full_name }}</h4>
                <p>{{ (!empty($likeUser->user->role)) ? $likeUser->user->role : $likeUser->fromUser->role }}</p>
            </div>
        </li>
        @endforeach
    </ul>
</div>
@endif
<script>
$(".user_like_scroll").mCustomScrollbar({
    theme: "dark",
    axis: "y",
});
$(window).resize(function () {
    var chk_account_height = $('.modal-header').outerHeight(true);
    var window_height = $(window).height();
    $(".user_like_scroll").css('max-height', window_height - chk_account_height - custom_margin);
}).resize();
</script>