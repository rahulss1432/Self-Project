<!-- connection list in detail view -->
<div class="connections-wrap">

    @forelse( $connections as $connection )

    @php
    $userId = Auth::guard(getAuthGuard())->user()->id;
    if($connection->from_id == $userId ){
    $id = $connection->to_id;
    }else{
    $id = $connection->from_id;
    }

    $user = getUserWithAllDetail($id);

    @endphp

    @if($user->role == 'player')
    <div class="detail-wrap" id="divJoinedMember_{{$user->id}}">
        <div class="player details">
            <a href="{{ url('view/player-profile/'.$user->slug )}}" >
                <div class="top-heading d-flex">
                    <img src="{{ url('public/images/black_logo.png')}}" alt="logo">
                    <h2>{{$user->full_name}}</h2>
                </div>
                <div class="info-sec">
                    <div class="left">
                        <ul class="list-unstyled">
                            <li><p>HT</p><span>{{!empty($user->userMeasurables->height_ft) ? $user->userMeasurables->height_ft : 0 }}'{{!empty($user->userMeasurables->height_in) ? $user->userMeasurables->height_in : 0}}''</span></li>
                            <li><p>WT</p><span>{{!empty($user->userMeasurables->weight) ? $user->userMeasurables->weight : '-' }}</span></li>
                            <li><p>40</p><span>{{!empty($user->userMeasurables->fourty) ? $user->userMeasurables->fourty : '-' }}</span></li>
                            <li><p>VERT</p><span>{{!empty($user->userMeasurables->vert) ? $user->userMeasurables->vert : '-' }}</span></li>
                        </ul>
                    </div>
                    <div class="right d-flex flex-wrap">
                        <div class="profile-box">
                            <div class="user_profile">
                                <img src="{{ checkUserImage($user->profile_image, 'player/thumb','') }}" alt="player">
                            </div>
                            <div class="profile-box-bottom d-flex align-items-center">
                                <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'small') }}" alt="FLAG">
                                <h4>{{getLimitText('8', !empty($user->country->name) ? $user->country->name : '-')}}</h4>
                            </div>
                        </div>
                        <div class="user_details">
                            <div class="player-top d-flex">
                                <h4>{{$user->role}} </h4>
                                <span >{{getLimitText(5,getPositionName($user->position_id))}}</span>
                            </div>
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <h4>AGE: <span>{{$user->age}}</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENTLY UNDER CONTRACT: <span>{{ !empty($user->userGeneral->under_contract) ?  strtoupper($user->userGeneral->under_contract) : 'NO'}}</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT TEAM: <span>{{ !empty($user->userGeneral->current_team) ?  ucfirst(getLimitText(8,$user->userGeneral->current_team)) : '-' }}</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT LEAGUE: <span>{{!empty($user->userGeneral->current_league) ? ucfirst(getLimitText(8,$user->userGeneral->current_league)) : '-'}}</span></h4>
                                </li>
                                <li>
                                    <h4>LOOKING TO SIGN: <span>{{!empty($user->userGeneral->look_to_sign) ? strtoupper($user->userGeneral->look_to_sign) : 'NO'}}</span></h4>                                                                    
                                </li>
                                <li>
                                    <h4>PASSPORT READY: <span>{{!empty($user->userGeneral->passport) ?  strtoupper($user->userGeneral->passport) : 'NO'}}</span></h4>
                                </li>
                                <li>
                                    <h4> PREP/COLLEGE EXPERIENCE: <span>{{!empty($user->userCollegeExperince) ? 'YES' : 'NO'}}</span></h4>
                                </li>
                                <li>
                                    <h4>PRO EXPERIENCE: <span>{{!empty($user->userProExperince) ? 'YES' : 'NO'}}</span></h4>
                                </li>
                                <li>
                                    <h4>INTERNATIONAL EXPERIENCE: <span>{{!empty($user->userInternationalExperince) ? 'YES' : 'NO'}}</span></h4>
                                </li>
                                <li>
                                    <h4>INDOOR  EXPERIENCE: <span>{{ !empty($user->userIndooreExperince) ? 'YES' : 'NO'}}</span></h4>
                                </li>
                            </ul>
                        </div>
                        <div class="bottom-sec">
                            <h6>freeagentfootball.com</h6>
                        </div>
                    </div>
                </div>

                <div class="share-bottom">
                    <span class="icon-share_icon"></span>
                </div>
            </a>
        </div>
        @if(checkUserRequest($id))
        <div class="button-sec member_btn">
            <a href="javascript:void(0);"  id="accept_{{ $connection->id }}" class="btn btn-success btn-lg border-2" onclick="acceptRejectConnection('{{ $connection->id }}', 'accept')">ACCEPT</a>
            <a href="javascript:void(0);" id="reject_{{ $connection->id }}" class="btn btn-secondary btn-lg border-2" onclick="acceptRejectConnection('{{ $connection->id }}', 'reject')">REJECT</a>
        </div>
        @else
 <div class="button-sec connect_btn">
            <a href="javascript:void(0);" class="btn btn-success btn-lg border-2">PENDING</a>
        </div>
        @endif
    </div>
    @elseif($user->role == 'team')
    <div class="detail-wrap team" id="divJoinedMember_{{$user->id}}">
        <div class="details team">
            <a href="{{ url('view/team-profile/'. $user->slug )}}">
                <div class="top-heading d-flex">
                    <img src="{{ url('public/images/black_logo.png')}}" alt="logo">
                    <h2>{{$user->full_name}}</h2>
                </div>
                <div class="info-sec">
                    <div class="right d-flex flex-wrap">
                        <div class="profile-box">
                            <div class="user_profile">
                                <img src="{{ checkUserImage($user->profile_image, 'team/thumb','') }}" alt="team">
                            </div>
                            <div class="profile-box-bottom">
                                <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name :'', 'small') }}" alt="FLAG">
                                <h4>{{getLimitText('8', !empty($user->country->name) ? $user->country->name : '-')}}</h4>
                            </div>
                        </div>
                        <div class="user_details">
                            <div class="player-top d-flex">
                                <h4>{{$user->role}} </h4>
                                <span><img src="{{url('public/images/miac_logo.jpg')}}" alt="logo"></span>
                            </div>
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <h4>STATE/PROVINCE: <span>{{!empty($user->state)? getLimitText(8,$user->state->state_name) : '-' }}</span></h4>                                    
                                </li>
                                <li>
                                    <h4>YEARS IN EXISTENCE: <span>{{!empty($user->userGeneral->playing_exp) ? $user->userGeneral->playing_exp : '-' }}</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENTLY RECRUITING: <span>{{!empty($user->userGeneral->recruiting) ? strtoupper($user->userGeneral->recruiting) : 'NO' }}</span></h4>
                                </li>
                                <li>
                                    <h4>LEAGUE: <span>{{!empty($user->userGeneral->current_league) ? ucfirst($user->userGeneral->current_league) : '-'}}</span></h4>
                                </li>
                            </ul>
                            <p class="mt-3 mb-0">{{!empty($user->website) ? $user->website : ''}}</p>
                        </div>
                        <div class="bottom-sec">
                            <h6>freeagentfootball.com</h6>
                        </div>
                    </div>
                </div>
                <div class="share-bottom">
                    <span class="icon-share_icon"></span>
                </div>
            </a>
        </div>
 @if(checkUserRequest($id))
        <div class="button-sec member_btn">
            <a href="javascript:void(0);"  id="accept_{{ $connection->id }}" class="btn btn-success btn-lg border-2" onclick="acceptRejectConnection('{{ $connection->id }}', 'accept')">ACCEPT</a>
            <a href="javascript:void(0);" id="reject_{{ $connection->id }}" class="btn btn-secondary btn-lg border-2" onclick="acceptRejectConnection('{{ $connection->id }}', 'reject')">REJECT</a>
        </div>
 @else
 <div class="button-sec connect_btn">
            <a href="javascript:void(0);" class="btn btn-success btn-lg border-2">PENDING</a>
        </div>
 @endif
        </div>
    @elseif($user->role == 'coach')
    <div class="detail-wrap coach" id="divJoinedMember_{{$user->id}}">
        <div class="coach details">
            <a href="{{ url('view/coach-profile/'. $user->slug )}}">
                <div class="top-heading d-flex">
                    <img src="{{ url('public/images/black_logo.png')}}" alt="logo">
                    <h2>{{$user->full_name}}</h2>
                </div>
                <div class="info-sec">
                    <div class="right d-flex flex-wrap">
                        <div class="profile-box">
                            <div class="user_profile">
                                <!-- <div class="top-img d-none d-sm-block">
                                    <h3 class="mb-0">George st. lawrence</h3>
                                </div>  -->
                                <img src="{{ checkUserImage($user->profile_image, 'coach/thumb','') }}" alt="player">
                            </div>
                            <div class="profile-box-bottom d-flex align-items-center">
                                <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'small') }}" alt="FLAG">
                                <h4>{{getLimitText('8', !empty($user->country->name) ? $user->country->name : '-')}}</h4>
                            </div>
                        </div>
                        <div class="user_details">
                            <div class="player-top d-flex">
                                <h4>{{ucfirst($user->role)}} </h4>
                                <span>{{getLimitText(5,getPositionName($user->position_id))}}</span>
                            </div>
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <h4>AGE: <span>{{$user->age}}</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENTLY UNDER CONTRACT: <span>{{ !empty($user->userGeneral->under_contract) ?  strtoupper($user->userGeneral->under_contract) : 'NO'}}</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT TEAM: <span>{{ !empty($user->userGeneral->current_team) ?  ucfirst(getLimitText(8,$user->userGeneral->current_team)) : '-' }}</span></h4>
                                </li>
                                <li>
                                    <h4>CURRENT LEAGUE: <span>{{!empty($user->userGeneral->current_league) ? ucfirst(getLimitText(8,$user->userGeneral->current_league)) : '-'}}</span></h4>
                                </li>
                                <li>
                                    <h4>LOOKING TO SIGN: <span>{{!empty($user->userGeneral->look_to_sign) ? strtoupper($user->userGeneral->look_to_sign) : 'NO'}}</span></h4>
                                </li>
                                <li>
                                    <h4>PASSPORT READY: <span>{{!empty($user->userGeneral->passport) ?  strtoupper($user->userGeneral->passport) : 'NO'}}</span></h4>
                                </li>
                                <li>
                                    <h4> PREP/COLLEGE EXPERIENCE: <span>{{!empty($user->userCollegeExperince) ? 'YES' : 'NO'}}</span></h4>
                                </li>
                                <li>
                                    <h4>PRO EXPERIENCE: <span>{{!empty($user->userProExperince) ? 'YES' : 'NO'}}</span></h4>
                                </li>
                                <li>
                                    <h4>INTERNATIONAL EXPERIENCE: <span>{{!empty($user->userInternationalExperince) ? 'YES' : 'NO'}}</span></h4>
                                </li>
                                <li>
                                    <h4>3-DOWN EXPERIENCE: <span>{{!empty($user->userGeneral->playing_exp) ? 'YES' : 'NO'}}</span></h4>
                                </li> 
                                <li>
                                    <h4>INDOOR  EXPERIENCE: <span>{{ !empty($user->userIndooreExperince) ? 'YES' : 'NO'}}</span></h4>
                                </li>
                            </ul>
                        </div>
                        <div class="bottom-sec">
                            <h6>freeagentfootball.com</h6>
                        </div>
                    </div>
                </div>

                <div class="share-bottom">
                    <span class="icon-share_icon"></span>
                </div>
            </a>
        </div>
         @if(checkUserRequest($id))
        <div class="button-sec member_btn">
            <a href="javascript:void(0);"  id="accept_{{ $connection->id }}" class="btn btn-success btn-lg border-2" onclick="acceptRejectConnection('{{ $connection->id }}', 'accept')">ACCEPT</a>
            <a href="javascript:void(0);" id="reject_{{ $connection->id }}" class="btn btn-secondary btn-lg border-2" onclick="acceptRejectConnection('{{ $connection->id }}', 'reject')">REJECT</a>
        </div>
         @else
 <div class="button-sec connect_btn">
            <a href="javascript:void(0);" class="btn btn-success btn-lg border-2">PENDING</a>
        </div>
         @endif
    </div>

    @endif
    @empty
    <h3 class="alert alert-danger text-center w-90 mt-md-5 mt-3">No Request Available!</h3>
    @endforelse
    {{$connections->links()}}
</div>
<script>
    /* Connection scrolling */
    $("#membersList").mCustomScrollbar({
        theme: "dark",
        axis: "y"
    });
    /*load more with pagination*/
    $(document).ready(function() {
        setTimeout(function() {
            $("ul.pagination li").first().remove();
        }, 500);
        $(".pagination li a").on('click', function(e) {
            e.preventDefault();
            $(".pagination li a").attr("disabled", true);
            showButtonLoader('explore-btn-loader', "MORE", "disable");
            var $this = $(this);
            var pageLink = $this.attr('href');
            var formData = $('#playerMemberForm').serialize();
            $.ajax({
                type: 'POST',
                url: pageLink,
                data: formData,
                success: function(response) {
                    $('.pagination:first').remove();
                    $('#membersList').append(response.html);
                },
                error: function(err) {},
                complete: function() {
                    showButtonLoader('explore-btn-loader', "MORE", "enable");
                    $("#membersList").mCustomScrollbar("destroy"); /* Post scrolling */
                    $("#membersList").mCustomScrollbar({
                        theme: "dark",
                        axis: "y"
                    });
                }
            });
        });
        $(".pagination li a").addClass('btn btn-success');
        $(".pagination li a").attr('id', 'explore-btn-loader');
        $(".pagination li a").html('MORE');
    });
</script>