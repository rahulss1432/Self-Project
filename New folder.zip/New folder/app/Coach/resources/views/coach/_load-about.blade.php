<!-- experience type college -->
@if($type == 'college')
<form autocomplete="off" id="college" method="post" action="{{ url('coach/coach-add-update-experience') }}">
    {{ csrf_field() }}
    <input type="hidden" value="college" name="user_exp_type">
    <input type="text"  style="display:none;" value="" id="id" name="id">
    <div class="card-body panel-body">
        <div class="container">
            @if(!empty($data) && count($data) > 0)
            @foreach($data as $about_exp)
            <div class="card-top" id="remove{{$about_exp['id']}}">
                <ul class="list-unstyled experience_year mb-0">
                    <li>
                        <h4>{{$about_exp['experience_type']}}</h4>
                        <p>{{$about_exp['from_year']}} - {{$about_exp['to_year']}}</p>
                    </li>

                </ul>
                <div class="action">
                    <a href="javascript:void(0);"  id="editcollege{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'college', 'collapseSix', 'edit');" class="remove">
                        <i class="far fa-edit icon"></i>
                    </a>
                    <a href="javascript:void(0);"  id="deletecollege{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'college', 'collapseSix', 'delete');" class="remove">
                        <i class="flaticon-cross"></i>
                    </a>

                </div>

            </div>
            @endforeach
            @endif
        </div>
        <div class="container">
            <div class="row common-row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Type</label>
                        <div class="input-field">
                            <input type="text" placeholder="Type" name="experience_type" id="experience_type">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="control-label">Year</label>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker z-index">
                                    <div class="input-group date" id="year01" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#year01" placeholder="Select Year" name="from_year" id="from_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year01" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker z-index dashed">
                                    <div class="input-group date" id="year02" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input"  data-target="#year02" placeholder="Select Year" name="to_year" id="to_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year02" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <a href="javascript:void(0);" class="position-relative add-more" id="collegecollapseSix" onclick="add_update_experience('college', 'collapseSix');">ADD MORE</a>
    </div>
</form>
{!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepThreeCollegeRequest','#college') !!}
@endif

<!-- end college exp-->

<!-- experience type pro -->
@if($type == 'pro')
<form autocomplete="off" id="pro" method="post" action="{{ url('coach/coach-add-update-experience') }}">
    {{ csrf_field() }}
    <input type="hidden" value="pro" name="user_exp_type">
    <input type="text" style="display:none;" value="" id="pid" name="id">
    <div class="card-body panel-body">
        <div class="container">
            @if(!empty($data) && count($data) > 0)
            @foreach($data as $about_exp)
            <div class="card-top" id="remove{{$about_exp['id']}}">
                <ul class="list-unstyled experience_year mb-0">
                    <li>
                        <h4>{{$about_exp['experience_type']}}</h4>
                        <p>{{$about_exp['from_year']}} - {{$about_exp['to_year']}}</p>
                    </li>
                </ul>
                <div class="action">
                    <a href="javascript:void(0);"  id="editpro{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'pro', 'collapseSeven', 'edit');" class="remove">
                        <i class="far fa-edit icon"></i>
                    </a>
                    <a href="javascript:void(0);"  id="deletepro{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'pro', 'collapseSeven', 'delete');" class="remove">
                        <i class="flaticon-cross"></i>
                    </a>

                </div>

            </div>
            @endforeach  
            @endif
        </div>
        <div class="container">
            <div class="row common-row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Type</label>
                        <div class="input-field">
                            <input type="text" placeholder="Type" name="experience_type" id="pexperience_type">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="control-label">Year</label>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker z-index">
                                    <div class="input-group date" id="year03" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#year03" placeholder="Select Year" name="from_year" id="pfrom_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year03" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker z-index dashed">
                                    <div class="input-group date" id="year04" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#year04" placeholder="Select Year" name="to_year" id="pto_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year04" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <a href="javascript:void(0);" class="position-relative add-more" id="procollapseSeven" onclick="add_update_experience('pro', 'collapseSeven');">ADD MORE</a>

    </div>
</form>
{!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepThreeProRequest','#pro') !!}
@endif
<!-- end pro exp-->


<!-- experience type international -->
@if($type == 'international')
<form autocomplete="off" id="international" method="post" action="{{ url('coach/coach-add-update-experience') }}">
    {{ csrf_field() }}
    <input type="hidden" value="international" name="user_exp_type">
    <input type="text" style="display:none;" value="" id="intid" name="id">
    <div class="card-body panel-body">
        <div class="container">
            @if(!empty($data) && count($data) > 0)
            @foreach($data as $about_exp)
            <div class="card-top" id="remove{{$about_exp['id']}}">
                <ul class="list-unstyled experience_year mb-0">
                    <li>
                        <h4>{{getLevelName($about_exp['experience_type'])}}</h4>
                        <p>{{$about_exp['from_year']}} - {{$about_exp['to_year']}}</p>
                    </li>
                </ul>
                <div class="action">
                    <a href="javascript:void(0);"  id="editpro{{$about_exp['id']}}"  id="editinternational{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'international', 'collapseEight', 'edit');" class="remove">
                        <i class="far fa-edit icon"></i>
                    </a>
                    <a href="javascript:void(0);"  id="deletepro{{$about_exp['id']}}" id="deleteinternational{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'international', 'collapseEight', 'delete');" class="remove">
                        <i class="flaticon-cross"></i>
                    </a>

                </div>
            </div>
            @endforeach  
            @endif
        </div>
        <div class="container">
            <div class="row common-row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Level</label>
                        <select class="selectpicker form-control select-custom" title="Select Level" name="experience_type" id="interlevel_id"  data-size="4">
                        </select>
                        <!--                        <div class="input-field">
                                                    <input type="text" placeholder="Type" name="experience_type" id="intexperience_type">
                                                </div>-->
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="control-label">Year</label>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker z-index">
                                    <div class="input-group date" id="year05" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#year05" placeholder="Select Year" name="from_year" id="intfrom_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year05" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker z-index dashed">
                                    <div class="input-group date" id="year06" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#year06" placeholder="Select Year" name="to_year" id="intto_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year06" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <a href="javascript:void(0);" class="position-relative add-more" id="internationalcollapseEight" onclick="add_update_experience('international', 'collapseEight');">ADD MORE</a>
    </div>
</form>
{!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepThreeIntRequest','#international') !!}
@endif
<!-- end international exp-->

<!-- experience indoor pro -->
@if($type == 'indoor')
<form autocomplete="off" method="post" id="indoor" action="{{ url('coach/coach-add-update-experience') }}">
    {{ csrf_field() }}
    <input type="hidden" value="indoor" name="user_exp_type">
    <input type="text" style="display:none;" value="" id="inid" name="id">
    <div class="card-body panel-body">
        <div class="container">
            @if(!empty($data) && count($data) > 0)
            @foreach($data as $about_exp)
            <div class="card-top" id="remove{{$about_exp['id']}}">
                <ul class="list-unstyled experience_year mb-0">
                    <li>
                        <h4>{{getLevelName($about_exp['experience_type'])}}</h4>
                        <p>{{$about_exp['from_year']}} - {{$about_exp['to_year']}}</p>
                    </li>
                </ul>
                <div class="action">
                    <a href="javascript:void(0);"  id="editpro{{$about_exp['id']}}"  id="editindoor{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'indoor', 'collapseNine', 'edit');" class="remove">
                        <i class="far fa-edit icon"></i>
                    </a>
                    <a href="javascript:void(0);"  id="deletepro{{$about_exp['id']}}"  id="deleteindoor{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'indoor', 'collapseNine', 'delete');" class="remove">
                        <i class="flaticon-cross"></i>
                    </a>

                </div>
            </div>
            @endforeach  
            @endif
        </div>
        <div class="container">
            <div class="row common-row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Level</label>
                        <select class="selectpicker form-control select-custom" title="Select Level" name="experience_type" id="indoorlevel_id"  data-size="4">
                        </select>
                        <!--                        <div class="input-field">
                                                    <input type="text" placeholder="Type" name="experience_type" id="inexperience_type">
                                                </div>-->
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="control-label">Year</label>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker z-index">
                                    <div class="input-group date" id="year07" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#year07" placeholder="Select Year" name="from_year" id="infrom_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year07" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker z-index dashed">
                                    <div class="input-group date" id="year08" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#year08" placeholder="Select Year" name="to_year" id="into_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year08" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <a href="javascript:void(0);" class="position-relative add-more" id="indoorcollapseNine" onclick="add_update_experience('indoor', 'collapseNine');">ADD MORE</a>
    </div>
</form> 
{!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepThreeIndoorRequest','#indoor') !!}
@endif
<!-- end indoor exp-->


<!-- experience type accolades -->
@if($type == 'accolades')
<form autocomplete="off" method="post" id="accolades">
    {{ csrf_field() }}
    <input type="hidden" value="accolades" name="user_exp_type">
    <input type="text" style="display:none;" value="" id="aid" name="id">
    <div class="card-body panel-body">
        <div class="container">
            @if(!empty($data) && count($data) > 0)
            @foreach($data as $about_exp)
            <div class="card-top" id="remove{{$about_exp['id']}}">
                <ul class="list-unstyled mb-0">
                    <li class="media">
                        <div class="action">
                            <a href="javascript:void(0);" id="editaccolades{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'accolades', 'collapseTwo', 'edit');" class="remove">
                                <i class="far fa-edit icon"></i>
                            </a>
                            <a href="javascript:void(0);" id="deleteaccolades{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'accolades', 'collapseTwo', 'delete');" class="remove">
                                <i class="flaticon-cross"></i>
                            </a>
                        </div>
                        <div class="img-wrap mr-3 d-flex align-items-center justify-content-center">
                            <img class="img-fluid" src="{{ checkUserImage($about_exp['logo'], 'coach','logo') }}" alt="logo">
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 mb-1">{{$about_exp['name']}}</h5>
                            <div class="other-info">
                                <p class="mb-0">{{$about_exp['present_organization']}}</p>
                                <p>{{$about_exp['present_year']}}</p>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
            @endforeach
            @endif
        </div>

        <!-- xxxxx -->

        <div class="container">
            <div class="row common-row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Name of Accolade</label>
                        <div class="input-field">
                            <input type="text" placeholder="Name of Accolade" name="name" id="name">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group upload">
                        <label class="control-label">Add Logo</label>
                        <div class="input-field">
                            <div class="file-upload forupload">  
                                <div class="file-select ">
                                    <!-- <div class="file-select-button" id="fileName">Choose File</div> -->
                                    <div class="file-select-name nofile_name accolades_title" id="noFile">No file chosen...</div> 
                                    <input type="file" class="upload_file" name="image" id="uploadVideo">
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Presenting Organization</label>
                        <div class="input-field">
                            <input type="text" placeholder="Presenting Organization" name="present_organization" id="present_organization">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Year of Presentation</label>
                        <div class="input-field date_picker z-index">
                            <div class="input-group date" id="present_year" data-target-input="nearest">
                                <input type="text" class="form-control datetimepicker-input" data-target="#present_year" placeholder="Select Year" name="present_year" id="apresent_year" onkeydown="return false;">
                                <div class="input-group-append" data-target="#present_year" data-toggle="datetimepicker">
                                    <div class="input-group-text">
                                        <i class="flaticon-calendar"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <a href="javascript:void(0);" class="position-relative add-more" id="accoladescollapseTwo" onclick="add_update_experience('accolades', 'collapseTwo');">ADD MORE</a>
    </div>
</form>
{!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepThreeAccoladesRequest','#accolades') !!}
@endif
<!-- end accolades exp-->

<!-- experience type education -->
@if($type == 'education')
<form autocomplete="off" method="post" id="education">
    {{ csrf_field() }}
    <input type="hidden" value="education" name="user_exp_type">
    <input type="text" style="display:none;" value="" id="eid" name="id">
    <div class="card-body panel-body">

        <div class="container">
            @if(!empty($data) && count($data) > 0)
            @foreach($data as $about_exp)
            <div class="card-top" id="remove{{$about_exp['id']}}">
                <ul class="list-unstyled mb-0">
                    <li class="media">
                        <div class="action">
                            <a href="javascript:void(0);"  id="editeducation{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'education', 'collapseThree', 'edit');" class="remove">
                                <i class="far fa-edit icon"></i>
                            </a>
                            <a href="javascript:void(0);"  id="deleteeducation{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'education', 'collapseThree', 'delete');" class="remove">
                                <i class="flaticon-cross"></i>
                            </a>
                        </div>
                        <div class="img-wrap mr-3 d-flex align-items-center justify-content-center">
                            <img class="img-fluid" src="{{ checkUserImage($about_exp['logo'], 'coach','logo') }}" alt="logo">
                        </div>

                        <div class="media-body">
                            <h5 class="mt-0 mb-1">{{$about_exp['name']}}</h5>
                            <div class="other-info">
                                <p class="mb-0">{{$about_exp['from_year']}} - {{$about_exp['to_year']}}</p>
                                <p class="mb-0">{{getLevelName($about_exp['level_id'])}}</p>
                                <p>{{$about_exp['degree_name']}}</p>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
            @endforeach
            @endif
        </div>

        <!-- xxxxx -->

        <div class="container">
            <div class="row common-row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">School Name</label>
                        <div class="input-field">
                            <input type="text" placeholder="School Name" name="name" id="ename">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group upload">
                        <label class="control-label">Add School Logo</label>
                        <div class="input-field">
                            <div class="file-upload forupload">
                                <div class="file-select ">
                                    <!-- <div class="file-select-button" id="fileName">Choose File</div> -->
                                    <div class="file-select-name nofile_name education_title" id="noFile">No file chosen...</div> 
                                    <input type="file" class="upload_file" name="image" id="uploadVideo">
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="control-label">Year</label>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker z-index">
                                    <div class="input-group date" id="year09" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#year09" placeholder="Select Year" name="from_year" id="efrom_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year09" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker z-index dashed">
                                    <div class="input-group date" id="year10" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#year10" placeholder="Select Year" name="to_year" id="eto_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year10" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Level Completed</label>
                        <select class="selectpicker form-control select-custom" title="Select Level" name="level_id" id="elevel_id"  data-size="4">
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Degree Name</label>
                        <div class="input-field">
                            <input type="text" placeholder="Degree Name" name="degree_name" id="degree_name">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <a href="javascript:void(0);" class="position-relative add-more" id="educationcollapseThree" onclick="add_update_experience('education', 'collapseThree');">ADD MORE</a>
    </div>
</form>
{!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepThreeEduRequest','#education') !!}
@endif
<!-- end education exp-->
<!-- experience type coaching -->
@if($type == 'coaching')
<form autocomplete="off" method="post" id="coaching">
    {{ csrf_field() }}
    <input type="hidden" value="coaching" name="user_exp_type">
    <input type="text" style="display:none;" value="" id="coid" name="id">
    <div class="card-body">
        <div class="container">
            @if(!empty($data) && count($data) > 0)
            @foreach($data as $about_exp)
            <div class="card-top" id="remove{{$about_exp['id']}}">
                <ul class="list-unstyled mb-0">
                    <li class="media">
                        <div class="action">
                            <a href="javascript:void(0);" id="editcoaching{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'coaching', 'collapseFour', 'edit');" class="remove">
                                <i class="far fa-edit icon"></i>
                            </a>
                            <a href="javascript:void(0);" id="deletecoaching{{$about_exp['id']}}" onclick="editDelete_experience({{$about_exp['id']}}, 'coaching', 'collapseFour', 'delete');" class="remove">
                                <i class="flaticon-cross"></i>
                            </a>
                        </div>
                        <div class="img-wrap mr-3 d-flex align-items-center justify-content-center">
                            <img class="img-fluid" src="{{ checkUserImage($about_exp['logo'], 'coach','logo') }}" alt="logo">
                        </div>

                        <div class="media-body">
                            <h5 class="mt-0 mb-1">{{ $about_exp['name'] }}</h5>
                            <div class="other-info">
                                <p class="mb-0">{{ $about_exp['coaching_link'] }}</p>
                                <p class="mb-0">{{ $about_exp['coching_league'] }}</p>
                                <p class="mb-0">{{ getCountryName($about_exp['country_id']) }}</p>
                                <p class="mb-0">{{ getStateName($about_exp['state_id']) }}</p>
                                <p class="mb-0">{{ $about_exp['position_held'] }}</p>
                                <p class="mb-0">{{ $about_exp['from_year'] }} - {{ $about_exp['to_year'] }}</p>
                                <p class="mb-0">{{ getLevelName($about_exp['level_id']) }}</p>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
            @endforeach
            @endif
        </div>

        <!-- xxxxx -->

        <div class="container">
            <div class="row common-row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label class="control-label">Team / Program / Organization Name</label>
                        <div class="input-field">
                            <input type="text" placeholder="Team/Program/Organization Name" name="name" id="coname">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group upload">
                        <label class="control-label">Add Team Logo/Picture</label>
                        <div class="input-field">
                            <div class="file-upload forupload">
                                <div class="file-select ">
                                    <!-- <div class="file-select-button" id="fileName">Choose File</div> -->
                                    <div class="file-select-name nofile_name coaching_title" id="noFile">No file chosen...</div>
                                    <input type="file" class="upload_file" name="image" id="uploadVideo">
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Link to Team’s Page/Stats</label>
                        <div class="input-field">
                            <input type="text" placeholder="Link to Team’s Page/Stats" name="coaching_link" id="coaching_link">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">League/Conference </label>
                        <div class="input-field">
                            <input type="text" placeholder="League" name="coching_league" id="coching_league">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Country</label>
                        <select class="selectpicker form-control select-custom" title="Select Country" name="country_id" id="country_id" data-size="4">
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">State</label>
                        <select class="selectpicker form-control select-custom" title="Select State" name="state_id" id="state_id" data-size="4">
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Position Held</label>
                        <div class="input-field">
                            <input type="text" placeholder="Position Held" name="position_held" id="coposition_held">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="control-label">Year</label>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker">
                                    <div class="input-group date" id="year11" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#year11" placeholder="Select Year" name="from_year" id="cofrom_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year11" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="input-field date_picker dashed">
                                    <div class="input-group date" id="year12" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#year12" placeholder="Select Year" name="to_year" id="coto_year" onkeydown="return false;">
                                        <div class="input-group-append" data-target="#year12" data-toggle="datetimepicker">
                                            <div class="input-group-text">
                                                <i class="flaticon-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label">Level</label>
                        <select class="selectpicker form-control select-custom" title="Select Level" name="level_id" id="colevel_id"  data-size="4">
                        </select>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label class="control-label">Brief Description of Responsibilities</label>
                        <div class="input-field">
                            <textarea rows="3" name="bio" id="bio" placeholder="Type more about you"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <a href="javascript:void(0);" class="position-relative add-more" id="coachingcollapseFour" onclick="add_update_experience('coaching', 'collapseFour');">ADD MORE</a>
    </div>
</form>
{!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepThreeCoachRequest','#coaching') !!}
@endif
<!-- end coaching exp-->
<script>
            $(function() {
            var d = new Date();
                    month = d.getMonth();
                    day = d.getDate();
                    year = d.getFullYear();
                    future_yearr = new Date(year, 01, 01);
                    $('#year01, #year02, #year03, #year04,#present_year, #year05, #year06, #year07, #year08, #year09, #year10, #year11, #year12').datetimepicker({
            viewMode: 'years',
                    format: 'YYYY',
                    useCurrent: false,
                    maxDate: new Date(year + 1, month, day),
                    disabledDates: [
                            new Date(year + 1, month, day)]
            });
                    $(".selectpicker").selectpicker('refresh');
                    $('#present_year').datetimepicker({defaultDate: new Date()});
            });
            $("#year01").on("change.datetimepicker", function (e) {
    $('#year02').datetimepicker('minDate', e.date);
            var y1 = $("#year01").data("datetimepicker").date();
            if (y1 != "" && y1 != undefined) {
    if (!checkYear){
    $('#year01').datetimepicker('maxDate', future_yearr);
            var y2 = $("#year02").data("datetimepicker").date();
            if (y2 != "" && y2 != undefined) {
    if (new Date(y2) < new Date(y1)) {
    $('#year02').datetimepicker('date', future_yearr);
    }
    }
    }
    }
    });
            $("#year02").on("change.datetimepicker", function (e) {
    $('#year01').datetimepicker('maxDate', e.date);
            var y2 = $("#year02").data("datetimepicker").date();
            if (y2 != "" && y2 != undefined) {
    if (!checkYear){
    $('#year02').datetimepicker('maxDate', future_yearr);
    }
    $('#year01').datetimepicker('show');
            $('#year01').datetimepicker('hide');
    }
    });
            $("#year03").on("change.datetimepicker", function (e) {
    $('#year04').datetimepicker('minDate', e.date);
            var y3 = $("#year03").data("datetimepicker").date();
            if (y3 != "" && y3 != undefined) {
    if (!checkYear){
    $('#year03').datetimepicker('maxDate', future_yearr);
            var y4 = $("#year04").data("datetimepicker").date();
            if (y4 != "" && y4 != undefined) {
    if (new Date(y4) < new Date(y3)) {
    $('#year04').datetimepicker('date', future_yearr);
    }
    }
    }
    }
    });
            $("#year04").on("change.datetimepicker", function (e) {
    $('#year03').datetimepicker('maxDate', e.date);
            var y4 = $("#year04").data("datetimepicker").date();
            if (y4 != "" && y4 != undefined) {
    if (!checkYear){
    $('#year04').datetimepicker('maxDate', future_yearr);
    }
    $('#year03').datetimepicker('show');
    $('#year03').datetimepicker('hide');
    }
    });
            $("#year05").on("change.datetimepicker", function (e) {
    $('#year06').datetimepicker('minDate', e.date);
            var y5 = $("#year05").data("datetimepicker").date();
            if (y5 != "" && y5 != undefined) {
    if (!checkYear){
    $('#year05').datetimepicker('maxDate', future_yearr);
    var y6 = $("#year06").data("datetimepicker").date();
            if (y6 != "" && y6 != undefined) {
    if (new Date(y6) < new Date(y5)) {
    $('#year06').datetimepicker('date', future_yearr);
    }
    }
    }
    }
    });
            $("#year06").on("change.datetimepicker", function (e) {
    $('#year05').datetimepicker('maxDate', e.date);
            var y6 = $("#year06").data("datetimepicker").date();
            if (y6 != "" && y6 != undefined) {
    if (!checkYear){
    $('#year06').datetimepicker('maxDate', future_yearr);
    }
    $('#year05').datetimepicker('show');
    $('#year05').datetimepicker('hide');
    }
    });
            $("#year07").on("change.datetimepicker", function (e) {
    $('#year08').datetimepicker('minDate', e.date);
            var y7 = $("#year07").data("datetimepicker").date();
            if (y7 != "" && y7 != undefined) {
    if (!checkYear){
    $('#year07').datetimepicker('maxDate', future_yearr);
    var y8 = $("#year08").data("datetimepicker").date();
            if (y8 != "" && y8 != undefined) {
    if (new Date(y8) < new Date(y7)) {
    $('#year08').datetimepicker('date', future_yearr);
    }
    }
    }
    }
    });
            $("#year08").on("change.datetimepicker", function (e) {
    $('#year07').datetimepicker('maxDate', e.date);
            var y8 = $("#year08").data("datetimepicker").date();
            if (y8 != "" && y8 != undefined) {
    if (!checkYear){
    $('#year08').datetimepicker('maxDate', future_yearr);
    }
    $('#year07').datetimepicker('show');
    $('#year07').datetimepicker('hide');
    }
    });
            $("#year09").on("change.datetimepicker", function (e) {
    $('#year10').datetimepicker('minDate', e.date);
            var y9 = $("#year09").data("datetimepicker").date();
            if (y9 != "" && y9 != undefined) {
    if (!checkYear){
    $('#year09').datetimepicker('maxDate', future_yearr);
    var y10 = $("#year10").data("datetimepicker").date();
            if (y10 != "" && y10 != undefined) {
    if (new Date(y10) < new Date(y9)) {
    $('#year10').datetimepicker('date', future_yearr);
    }
    }
    }
    }
    });
            $("#year10").on("change.datetimepicker", function (e) {
    $('#year09').datetimepicker('maxDate', e.date);
            var y10 = $("#year10").data("datetimepicker").date();
            if (y10 != "" && y10 != undefined) {
    if (!checkYear){
    $('#year10').datetimepicker('maxDate', future_yearr);
    }
    $('#year09').datetimepicker('show');
    $('#year09').datetimepicker('hide');
    }
    });
            $("#year11").on("change.datetimepicker", function (e) {
    $('#year12').datetimepicker('minDate', e.date);
            var y11 = $("#year11").data("datetimepicker").date();
            if (y11 != "" && y11 != undefined) {
    if (!checkYear){
    $('#year11').datetimepicker('maxDate', future_yearr);
    var y12 = $("#year12").data("datetimepicker").date();
            if (y12 != "" && y12 != undefined) {
    if (new Date(y12) < new Date(y11)) {
    $('#year12').datetimepicker('date', future_yearr);
    }
    }
    }
    }
    });
            $("#year12").on("change.datetimepicker", function (e) {
    $('#year11').datetimepicker('maxDate', e.date);
            var y12 = $("#year12").data("datetimepicker").date();
            if (y12 != "" && y12 != undefined) {
    if (!checkYear){
    $('#year12').datetimepicker('maxDate', future_yearr);
    }
    $('#year11').datetimepicker('show');
    $('#year11').datetimepicker('hide');
    }
    });
            /*** End    **/
            $(document).ready(function(){
    $('input[type="file"]').on('change', function () {
    var filename = $(this).val();
            console.log(filename);
            if (/^\s*$/.test(filename)) {
    // $(".forupload").removeClass('active');
    $(this).parent().children(".nofile_name").text("No file chosen...");
    }
    else {
    // $(".forupload").addClass('active');
    $(this).parent().children(".nofile_name").text(filename.replace(/C:\\fakepath\\/i, ''));
    }
    });
    });

</script>