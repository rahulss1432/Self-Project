@extends('coach::layouts.app')
@section('content')
<main class="main-content">
    <div class="mainframe_border">
        <div class="borderheight" id="borderheight"></div>
    </div>
    <!--  left side -->
    <aside class="left_section " id="left-side-html">
        <!-- Left side html render  -->
    </aside>
    <!--  middle section -->
    <section class="middle_section">
        <div class="container-fluid">
            <div class="news_point">
                <div class="inner">
                    <div class="newsheading">
                        <p><span class="headingtag">NEWS</span></p>
                        <div class="newsline"><span id="newsBulletin"></span></div>
                        <a href="{{ url('/news-details') }}">(READ MORE)</a>
                    </div>
                    <div class="news_tag" id="divCoachCounts">

                    </div>
                </div>
            </div>
            <div class="members_list">
                <div class="heading text-center mr-auto ml-auto">
                    MEMBERS YOU MAY KNOW
                </div>
                <div class="list" id="sliderDiv">
                    <div class="customNavigation">
                        <a href="javascript:void(0);" class="prev"></a>
                    </div>
                    <div class="back_bg"></div>
                    <div class="owl-carousel owl-theme member" id="memberlist">
                        <!-- member you may know list render-->
                    </div>
                    <div class="customNavigation">
                        <a href="javascript:void(0);" class="next"></a>
                    </div>
                </div>
            </div>
            <div class="web_presentation text-center">
                <img src="{{ url('public/images/black_logo.png') }}" class="img-fluid" alt="logo">
            </div>
            <div class="post_videophoto">
                <form action="post">
                    <div class="profile_img common_side">
                        <img src="{{ checkUserImage(\Auth::guard(getAuthGuard())->user()->profile_image, 'coach') }}" class="rounded-circle" alt="profile">
                        <!--<img src="{{ url('public/images/user_img.jpg') }}" class="rounded-circle" alt="profile">-->
                        <div class="circle_animation">
                        </div>
                    </div>
                    <div class="post_desc">
                        <a href="javascript:void(0);" onclick="addPost()">
                            Share an Article, Photo, Video...
                        </a>
                        <ul class="list-inline icons">
                            <li class="list-inline-item">
                                <label onclick="addPost()">
                                    <span class="icon icon-film"></span>
                                </label>
                            </li>
                            <li class="list-inline-item">
                                <label onclick="addPost()">
                                    <span class="icon icon-image"></span>
                                </label>
                            </li>
                        </ul>
                    </div>
                    <div class="post_btn common_side">
                        <a href="javascript:void(0);" onclick="addPost()" class="btn btn-dark rounded-circle">
                            POST
                        </a>
                    </div>
                </form>
            </div>

            <!----------------- view all post ------------------->
            <div class="post_view" >
                <div class="post ml-auto mr-auto green-scroll" id="postframe">

                </div>
            </div>
            <!--<div class="text-center"  id="loader-div" style="display:none;"><a href="javascript:void(0);" id="post-load-more" class="btn btn-success" onclick="loadMorePost()">More</a></div>-->
            <!----------------- view all post ------------------->

        </div>
    </section>
    <!-- right side -->
    <aside class="right_section" id="right-side-html">
        <!--- Right side html render -->
    </aside>
    <!--  Coach pro card -->
    <div class="procard-coach" id="divCoachProCard"> </div>

</main>

<!-- post modal -->
<!-- Add post modal -->
<div class="modal fade modal-center share-article" data-backdrop="static" data-keyboard="false" id="add_post" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="add-post-data">
            <div class="btn_loader btn_ring" id="listLoader"></div>
        </div>
    </div>
</div>

<!-- Edit post modal -->
<div class="modal fade modal-center share-article edit_post" data-backdrop="static" data-keyboard="false" id="edit_post" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="edit-post-data">
            <div class="btn_loader btn_ring" id="listLoader"></div>
        </div>
    </div>
</div>
<!-- Modal End -->

<!-- like model -->
<div class="modal fade modal-center  users_like" id="users_like" data-backdrop="static" data-keyboard="false" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="users_like" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="LikeUserList">
            <div class="btn_loader btn_ring" id="listLoader"></div>
        </div>
    </div>
</div>
<!-- comment model -->
<div class="modal fade modal-center  users_like users_comments" id="users_comments" data-backdrop="static" data-keyboard="false" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="users_comments" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="AllCommentList">
            <div class="btn_loader btn_ring" id="listLoader"></div>
        </div>
    </div>
</div>
<!-- like model -->

<!-- left & right side url routing-->
<input type="hidden" data-url="{{url('coach/left-sidebar')}}" id="coach_left_side">
<input type="hidden" data-url="{{url('coach/right-sidebar')}}" id="coach_right_side">
<script>
    var memberConnectDismissUrl = "{{ url('coach/connect-dismiss-member') }}";
    var coach_new_job_list = "{{ url('coach/new-job-list') }}";
    var coach_applied_job_list = "{{ url('coach/applied-job-list') }}";
    var currentPageUrl = '{{ Request::segment(2) }}';
    var csrfToken = "{{csrf_token()}}";
    var userConnectionList = "{{ url('coach/user-connections-list') }}";
    var recentMathcedJoinedMembersUrl = "{{ url('coach/get-matched-mutual-joined-members') }}";
    // post view content list load
    var user_id = ''; // for reinitilize slider when length 0.    
    function getpostView(obj = null, url, action) {
        if (url == '' || url == undefined) {
            var url = "{{ url('coach/get-post') }}";
            pageLoader('postframe', 'show');
        }
        $.ajax({type: "GET", url: url, data: {},
            success: function (response) {
                if (action == 'first') {
                    $("#postframe").html("");
                    $("#postframe").html(response.html);
                } else {
                    $('.pagination:first').remove();
                    $("#postframe").append(response.html);
                }
            },
            error: function (err) {
                getpostView('', url, action);
            },
            complete: function () {
                setHeightMiddleSection();
                //pageLoader('postframe', 'hide');
                if (action == 'pagination') {
                    showButtonLoader('explore-btn-loader', "MORE", "enable");
                    $("#postframe").mCustomScrollbar("destroy"); /* Post scrolling */
                    $("#postframe").mCustomScrollbar({
                        theme: "dark",
                        axis: "y"
                    });
                }
            }
        });
    }

    // Function for get post like.
    function getPostLike(id) {
        $.get("{{ url('coach/get-post-like') }}", {id: id}, function (response) {
            if (response.success) {
                if (response.data == 0) {
                    $("#post-like-" + id).html('');
                    document.getElementById("prevent-" + id).style.pointerEvents = 'none';
                } else {
                    $("#post-like-" + id).html(response.data);
                    document.getElementById("prevent-" + id).style.pointerEvents = 'auto';
                }
            } else {
                message('error', response.message);
            }
        });
    }

    // Function for check post like.
    function checkPostLike(pid) {
        return $.post("{{ url('coach/check-post-like') }}", {_token: '{{ csrf_token() }}', pid: pid}, function (response) {
            if (response == 1) {
                $('#like-btn-' + pid).removeClass('like');
                $('#like-btn-' + pid).removeClass('unlike');
                $('#like-btn-' + pid).addClass('like');
            } else {
                $('#like-btn-' + pid).removeClass('like');
                $('#like-btn-' + pid).removeClass('unlike');
                $('#like-btn-' + pid).addClass('unlike');
            }
        });
    }

    // Function for add post like.
    function addPostLike(pid, uid) {
        $.post("{{ url('coach/add-post-like') }}", {_token: '{{ csrf_token() }}', pid: pid, uid: uid}, function (response) {
            if (response.success) {
                getPostLike(pid);
                checkPostLike(pid);
            } else {
                message('error', response.message);
            }
        });
    }

    // Function for get like user.
    function getLikeUser(pid) {
        $('#users_like').modal('show');
        $.post("{{ url('coach/get-like-user') }}", {_token: '{{ csrf_token() }}', pid: pid}, function (response) {
            if (response.success) {
                $('#LikeUserList').html('');
                $('#LikeUserList').html(response.html);
                setTimeout(function () {
                    $(".user_like_scroll").mCustomScrollbar({
                        theme: "dark",
                        axis: "y",
                    });
                }, 500);
            } else {
                message('error', response.message);
            }
        });
    }

    function getPostComments(pid, action) {
        if (action == 'all') {
            $('#users_comments').modal('show');
        }
        $.ajax({type: "POST",
            url: "{{ url('coach/get-post-comments') }}",
            data: {_token: '{{ csrf_token() }}', pid: pid, action: action},
            success: function (response) {
                if (response.success) {
                    if (action == 'first') {   // add and first time load                 
                        $('#post-comments-' + pid).html(response.html);
                    } else {
                        $('#AllCommentList').html('');
                        $('#AllCommentList').html(response.html);
                    }
                    if (response.total_count == 0) {
                        $('#post-comments-count-' + pid).html('');
                    } else {
                        $('#post-comments-count-' + pid).html(response.total_count);
                    }
                }
            },
            error: function () {
                getPostComments(pid, action);
            },
            complete: function () {
                $(".user_like_scroll").mCustomScrollbar({
                    theme: "dark",
                    axis: "y",
                });
            }
        });
    }

    // Function for save post comment.
    $(document).on('submit', '.comment-form', function (e) {
        e.preventDefault();
        var pid = $(this).find('[name="pid"]').val();
        var comment = $(this).find('[name="comment"]').val();
        if ($.trim(comment) == '') {
            $(this).find('[name="comment"]').focus();
        } else {
            $.post($(this).attr('action'), $(this).serialize(), function (data) {
                if (data.success) {
                    $('.comment-form').trigger('reset');
                    getPostComments(pid, 'first');
                } else {
                    message('error', data.message);
                }
            });
        }
    });

    // Function for edit post.
    function editPost(id) {
        $.get("{{ url('coach/edit-post') }}", {id: id}, function (data) {
            $("#edit-post-data").html(data.html);
            $('#edit_post').modal('show');
        });
    }



    // show coach pro card
    function getCoachProCard() {
        var url = "{{ url('coach/get-coach-procard') }}";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                $('#divCoachProCard').html(response.html);
            },
            error: function (err) {
                getCoachProCard();
            }
        });
    }
    // get all coach counts
    function getCoachAllCount() {
        pageLoader('divCoachCounts', 'show');
        var url = "{{ url('coach/get-coach-counts') }}";
        $.ajax({type: "GET",
            dataType: 'JSON',
            url: url,
            success: function (response) {
                $('#divCoachCounts').html('');
                $('#divCoachCounts').html(response.html);
                $('#newsBulletin').html(response.newsBulletin);
            },
            error: function () {
                getCoachAllCount();
            }
        });
    }

    // Function for edit post.
    function editPost(id) {
        $.get("{{ url('coach/edit-post') }}", {id: id}, function (data) {
            $("#edit-post-data").html(data.html);
            $('#edit_post').modal('show');
        });
    }

    // Function for Add post.
    function addPost() {
        $.get("{{ url('coach/add-post-form') }}", function (data) {
            $("#add-post-data").html(data.html);
            $('#add_post').modal('show');
        });
    }


    // function for get default functions on page ready.
    $(document).ready(function () {
        var _token = '{{ csrf_token() }}';
        getLeftSidebar("dashboard");
        getRightSidebar("dashboard");
//        getRecentJoinedMembers('dashboard',_token);
        getMathchedJoinedMembers('dashboard', _token, '');
        getpostView("", "", "first");
        getCoachProCard();
        getCoachAllCount();
    });

</script>
<script src="{{url('public/js/coach/coach-connect-dissmiss.js')}}"></script>
<script src="{{url('public/js/coach/coach-left-right-sidebar.js')}}"></script>
<script src="{{url('public/js/coach/matched-mutual-joined-members.js')}}"></script>
@endsection