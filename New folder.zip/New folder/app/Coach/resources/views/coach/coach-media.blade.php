@extends('coach::layouts.app')

@section('content')

<link rel="stylesheet" href="{{ url('public/css/jquery.fancybox.min.css') }}" type="text/css">

<main class="main-content ">
    <div class="mainframe_border">
        <div class="borderheight" id="borderheight"></div>
    </div>

    <section class="top-section">
        <!--  left side -->
        <aside class="left_section " id="left-side-html">
            <!-- Left side html render -->
        </aside>

        <!-- xxxxxxxxx -->

        <div class="middle_section">

            <div class="container-fluid">
                <div class="news_point">
                    <div class="inner">
                        <div class="newsheading">
                            <p><span class="headingtag">NEWS</span></p> <div class="newsline"><span id="newsBulletin"></span></div>
                            <a href="{{ url('/news-details') }}">(READ MORE)</a>
                        </div>	                  
                       <div class="news_tag" id="divCoachCounts">
                            
                       </div>
                    </div>
                </div>

                 <!--get select media-->
                <div id="get-select-media">
                 
                </div>
            </div>
        </div>

        <!-- right side -->
        <aside class="right_section" id="right-side-html">
            <!-- right side html render -->
        </aside>
    </section>

    <!-- xxxxxxx -->

    <section class="compare-profile">
        <div class="container-fluid">
            <div class="compare-row d-flex align-items-end">
                <div class="left-sec">
                    <img src="{{ url('public/images/frames-bg/compare-profile-left-corner.png') }}" alt="compare-profile-row-bg" class="img-fluid">
                </div>
                <div class="center-sec">
                    <div class="center">
                        <a href="{{url('/coach/compare')}}"> <h2 class="heading-24 color-white text-uppercase">compare profile</h2></a>
                    </div>
                </div>
                <div class="right-sec">
                    <h2 class="text-center">
                        <span class="text-uppercase">Media LAST UPDATED</span> <br>
                        {{sameDate($user->updated_at)}}
                    </h2>
                </div>
            </div>
        </div>
    </section>

    <!-- xxxxxxx -->

    <section class="video-section">
        <div id="get-media-video-list"></div>
    </section>

    <!-- xxxxxxx -->

    <section class="web_presentation_wrap">
        <div class="web_presentation text-center">
            <img src="{{ url('public/images/black_logo.png') }}" class="img-fluid" alt="logo">
        </div>
    </section>

    <!-- xxxxxxx -->

    <section class="photos-section">
        <div id="get-media-image-list"></div>
    </section>
    <!--  Coach pro card -->
    <div class="procard-coach" id="divCoachProCard"> </div>
</main>

<!-- get my post media modal -->
<div class="modal photos modal-effect" id="myPhotosVideos" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body" id="get-my-post-media">
                
            </div>
        </div>
    </div>
</div>

<!-- like model -->
<div class="modal fade modal-center  users_like" id="users_like" data-backdrop="static" data-keyboard="false" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="users_like" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="LikeUserList">
            <div class="btn_loader btn_ring" id="listLoader"></div>
        </div>
    </div>
</div>
<!-- left & right side url routing-->
<input type="hidden" data-url="{{url('coach/left-sidebar')}}" id="coach_left_side">
<input type="hidden" data-url="{{url('coach/right-sidebar')}}" id="coach_right_side">
<script src="{{ url('public/js/jquery.fancybox.min.js') }}"></script>
<script src="{{url('public/js/coach/coach-left-right-sidebar.js')}}"></script>
<script>
    var user_id = '{{$id}}';
    
    
var userConnectionList = "{{ url('coach/user-connections-list') }}";
$(".hover").mouseleave(function () {
    $(this).removeClass("hover");
});

// function for get default functions on page ready.
$(document).ready(function () {
    getLeftSidebar("coach-media",user_id);
    getRightSidebar("coach-media",user_id);
    getCoachProCard();
    getMediaVideoList();
    getMediaImageList();
    getSelectMedia();
    getCoachAllCount();
});

// show coach pro card
function getCoachProCard() {
    var url = "{{ url('coach/get-coach-procard') }}";
    $.ajax({type: "GET", url: url,
        data:{id:user_id},
        success: function (response) {
            $('#divCoachProCard').html(response.html);
        },
        error: function () {
            getCoachProCard();
        },
        complete: function () {
            setHeightMiddleSection();
        }
    });
}

// get all coach counts
function getCoachAllCount() {
     pageLoader('divCoachCounts', 'show');
    var url = "{{ url('coach/get-coach-counts') }}";
    $.ajax({type: "GET", url: url,
        data:{id:user_id},
        success: function (response) {
            $('#divCoachCounts').html('');
            $('#divCoachCounts').html(response.html);
            $('#newsBulletin').html(response.newsBulletin);
        },
        error: function(){
            getCoachAllCount();
        }
    });
}


function getMediaVideoList(url) {
    if (url == '' || url == undefined){
       var url = "{{ url('coach/get-video-list') }}";
      }
    pageLoader('get-media-video-list', 'show');
    $.ajax({type: "GET", url: url, data: {id:'{{ $id }}'},
        success: function (response) {
            $('#get-media-video-list').html(response.html);
        },
        error: function () {
            getMediaVideoList();
        },
    });
}

function getMediaImageList(url) {
    if (url == '' || url == undefined){
       var url = "{{ url('coach/get-image-list') }}";
    }
    pageLoader('get-media-image-list', 'show');
    $.ajax({type: "GET", url: url, data: {id:'{{ $id }}'},
        success: function (response) {
            $('#get-media-image-list').html(response.html);
        },
        error: function () {
            getMediaImageList(url);
        },
    });
}

//get select media file
 function getSelectMedia(){
         pageLoader('get-select-media', 'show');
        $.get("{{ url('coach/get-select-media')}}", {id: '{{ $id }}'}, function (data) {
            $("#get-select-media").html(data.html);
        });
    }

//updated select media 
function updateSelectMedia(mediaId){
     $.post("{{ url('coach/update-select-media') }}", {_token: '{{ csrf_token() }}', media_id: mediaId}, function (response) {
        if (response.success) {
            getSelectMedia();
            message('success', response.message);
        } else {
            message('error', response.message);
        }
    });
}

//get media post/comment  modal
function getMediaModal(mediaId){
   $("#get-my-post-media").html('<span class="ajax_loader btn_ring"></span>');
   var url = '{{ url("coach/get-my-media-view") }}';
   $.ajax({
       type: "GET", url: url, data: {media_id: mediaId},
       success: function (response) {
            $("#get-my-post-media").html("");
            $("#get-my-post-media").html(response.html);
            $('#myPhotosVideos').modal('show');
       }
   });
}

</script>

@endsection