@extends('coach::layouts.app')
@section('content')

<main class="main-content">
    <div class="mainframe_border">
        <div class="borderheight" id="borderheight"></div>
    </div>
    <div class="container-fluid">
        <div class="common_heading">
            <h3 class="black black-lg">
                MY CONNECTIONS
            </h3>
        </div>
    </div>
    <aside class="left_section " id="left-side-html">
    <!-- Left side html render -->
    </aside>
    <section class="middle_section">
        <div class="container-fluid">
            <div class="ajax_list_load">
                <div id="membersList"></div>
            </div>
        </div>
    </section>
    <aside class="right_section" id="right-side-html">
    <!-- right side html render -->
    </aside>            
</main>
<!-- left & right side url routing-->
<input type="hidden" data-url="{{url('coach/left-sidebar')}}" id="coach_left_side">
<input type="hidden" data-url="{{url('coach/right-sidebar')}}" id="coach_right_side">
<script>
    var user_id = '{{$id}}';
    var csrfToken = "{{csrf_token()}}";
    var currentPageUrl = '{{ Request::segment(2) }}';
    var memberConnectDismissUrl = "{{ url('coach/connect-dismiss-member') }}";    
    /* Get connection list */
    function getConnectionList() {
        //$("#membersList").html('<span class="ajax_loader btn_ring"></span>');
        pageLoader('membersList', 'show');
        var url = "{{ url('coach/get-all-connections') }}";
        var formData = $('#coachMemberForm').serialize();
        $('#applyBtn').prop('disabled', true);
        $.ajax({type: "POST", 
            url: url, 
            data:formData,
            success: function (response) {
                if (response.success) {
                    setTimeout(function () {
                        pageLoader('membersList', 'hide');
                        $('#applyBtn').prop('disabled', false);
                        $("#membersList").html("");
                        $("#membersList").html(response.html);
                        $('#left-side-html').removeClass('open');
                        $('body').removeClass("aside-open-left");
                    }, 1000);
                } else {
                    message('error', response.message);
                }
            },error: function (err) {
                message('error', err);
            },complete: function () {
              setHeightMiddleSection();
            }
        });
    }
    
//    function getAcceptRejectConnection() {
//        $.post("{{ url('coach/get-all-connections') }}", function (response) {
//            $("#membersList").html(response.html);
//        });
//    }
    
    /* Accept connection request */
    function acceptRejectConnection(id, type){
        $.post("{{ url('coach/accept-reject-connection') }}", {_token: "{{ csrf_token() }}", id: id, type: type}, function(response){
            if(response.success){
                getConnectionList();
                message('success', response.message);
            }else{
                message('error', response.message);
            }
        });
    }

    $(document).ready(function() {
       
        getLeftSidebar("connection_list",user_id);
        getRightSidebar("connection_list",user_id);
        setTimeout(function () {
           getConnectionList();
        }, 5000);
    });
    
    /* Clear search form */
    function clearForm() {
        $('#member_type').val('');
        $('#member_type').selectpicker('refresh');
        $('#playerMemberForm').trigger("reset");
    }
</script>
<script src="{{url('public/js/coach/coach-left-right-sidebar.js')}}"></script>
<script src="{{url('public/js/coach/coach-connect-dissmiss.js')}}"></script>
@endsection