@extends('coach::layouts.app')

@section('content')

@php
$countryId = Auth::guard('coach')->user()->country_id;
$stateId = Auth::guard('coach')->user()->state_id;
@endphp

<link rel="stylesheet" href="{{ url('public/css/tempusdominus-bootstrap-4.min.css') }}" />

<main class="main-content">
    <div class="container custom-container">
        <h1 class="inner-heading text-uppercase main-head pt-xl-2">Profile Completion</h1>
        <div class="step-form-wrap coach-step-form-wrap text-center">
            <!-- <div class="d-sm-flex justify-content-sm-start"> -->
            <div class="d-sm-flex justify-content-md-center">
                <div class="step step01 active" id="step01">
                    <div class="inner-step text-center">
                        <h2>1</h2>
                        <p>Personal
                            <br> Info</p>
                    </div>
                </div>
                <div class="step step02" id="step02">
                    <div class="inner-step text-center">
                        <h2>2</h2>
                        <p>Contact
                            <br> Info</p>
                    </div>
                </div>
                <div class="step step03" id="step03">
                    <div class="inner-step text-center">
                        <h2>3</h2>
                        <p>About</p>
                    </div>
                </div>
                <div class="step step04" id="step04">
                    <div class="inner-step text-center">
                        <h2>4</h2>
                        <p>Media</p>
                    </div>
                </div>
                <div class="step step07" id="step05">
                    <div class="inner-step text-center">
                        <h2>5</h2>
                        <p>Desired
                            <br> Benefits</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- xxxxxxx -->
    <div class="step-form01" id="Form01">
        <div class="container">
            <form autocomplete="off" id="coach-step-one" class="custom_form" method="post" action="{{ url('coach/coach-step-one') }}">
                {{ csrf_field() }}
                <div class="row common-row">
                    <div class="col-12 text-center">
                        <div class="add-profile rounded-circle">
                            <div class="img-holder rounded-circle">
                                @php $img = getUserDataByColumn('profile_image'); @endphp
                                <img id="profile_image" src="{{ checkUserImage($img, 'coach/thumb') }}" alt="default-user" class="img-fluid">
                            </div>
                            <label class="upload-btn rounded-circle mb-0" onclick="$('#profile_image_input').trigger('click')">
                                <i class="fas fa-plus"></i>
                            </label>
                            <label class="control-label mt-3 m-0">Add Profile Picture</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="file" name="profile_image" id="profile_image_input" class="profile_error" style="opacity: 0;position: absolute;padding: 0;width: initial;height: initial;margin: 0;left: 0;display::none;">
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">First Name</label>
                            <div class="input-field">
                                <input type="text" name="first_name" value="{{ getUserDataByColumn('first_name') }}" placeholder="First Name">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Last Name</label>
                            <div class="input-field">
                                <input type="text" name="last_name" value="{{ getUserDataByColumn('last_name') }}" placeholder="Last Name">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Select Age</label>
                            <select name="age"  id="age" onchange="$(this).valid()" class="selectpicker form-control select-custom" data-size="4" title="Select ">
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Select Country</label>
                            <select id="country" name="country" onchange="$(this).valid()" class="selectpicker form-control select-custom" data-size="4" title="Select "></select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Select State</label>
                            <select id="state" name="state" onchange="$(this).valid()" class="selectpicker form-control select-custom" data-size="4" title="Select "></select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">City</label>
                            <div class="input-field">
                                <input type="text" name="city" value="{{ getUserDataByColumn('city') }}" placeholder="City">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Zip Code</label>
                            <div class="input-field">
                                <input type="text" name="zip" value="{{ getUserDataByColumn('zip_code') }}" placeholder="Zip Code">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Select Position</label>
                            <select name="position[]" id="position" multiple data-max-options="1" onchange="$(this).valid()" class="selectpicker form-control select-custom" data-size="4" title="Select">
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Signature</label>
                            <div class="input-field">
                                <input type="text" name="signature" value="{{ getUserDataByColumn('signature') }}" placeholder="Signature">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group upload">
                            <label class="control-label">Upload Resume</label>
                            <div class="input-field">
                                <div class="file-upload forupload">
                                    <div class="file-select ">
                                        <!-- <div class="file-select-button" id="fileName">Choose File</div> -->
                                        <div class="file-select-name nofile_name" id="noFile"> {{ !empty(getUserDataByColumn('resume')) ? getUserDataByColumn('resume') :  'No file chosen...' }} </div>                                         
                                        <input type="file" class="upload_file" name="resume" id="uploadVideo">
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label class="control-label">Bio</label>
                            <div class="input-field">
                                <textarea rows="3" name="bio" placeholder="Type more about you">{{ getUserDataByColumn('bio') }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 pl-0">
                        <div class="btn-row w-100 text-right">
                            <button type="button" class="btn btn-success btn-lg border-2 font-22" onclick="firstStepForm('coach-step-one', 'next')" id="nextStep01">NEXT</button>
                            <a href="javascript:void(0);" class="btn btn-success btn-lg border-2 font-22" onclick="firstStepForm('coach-step-one', 'exit')" id="nextStep011">SAVE & EXIT</a>
                        </div>
                    </div>

                </div>
            </form>
            {!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepOneRequest','#coach-step-one') !!}
        </div>
    </div>
    <!-- xxxxxxx -->
    <div class="step-form02" id="Form02" style="display: none;">
        <div class="container">
            <form autocomplete="off" id="coach-step-two" class="custom_form" method="post" action="{{ url('coach/coach-step-two') }}">
                {{ csrf_field() }}
                <div class="row common-row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Skype ID</label>
                            <div class="input-field">
                                <input type="text" name="skype" value="{{ getUserDataByColumn('skype') }}" placeholder="Skype ID">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Website</label>
                            <div class="input-field">
                                <input type="text" name="website" value="{{ getUserDataByColumn('website') }}" placeholder="Website">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Facebook</label>
                            <div class="input-field">
                                <input type="text" name="facebook" value="{{ getUserDataByColumn('facebook') }}" placeholder="Facebook">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Twitter</label>
                            <div class="input-field">
                                <input type="text" name="twitter" value="{{ getUserDataByColumn('twitter') }}" placeholder="Twitter">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Instagram</label>
                            <div class="input-field">
                                <input type="text" name="instagram" value="{{ getUserDataByColumn('instagram') }}" placeholder="Instagram">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Linkedin</label>
                            <div class="input-field">
                                <input type="text" name="linkedin" value="{{ getUserDataByColumn('linkedin') }}" placeholder="Linkedin">
                            </div>
                        </div>
                    </div>
                    <div class="col-12 pl-0">
                        <div class="btn-row w-100 text-right">
                            <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2 font-22" id="preStep01">PREVIOUS</a>
                            <button type="button" class="btn btn-success btn-lg border-2 font-22" onclick="secondStepForm('coach-step-two', 'next')" id="nextStep02">NEXT</button>
                            <a href="javascript:void(0);" class="btn btn-success btn-lg border-2 font-22" onclick="secondStepForm('coach-step-two', 'exit')" id="nextStep02">SAVE & EXIT</a>

                        </div>
                    </div>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepTwoRequest','#coach-step-two') !!}
        </div>
    </div>
    <!-- xxxxxxx -->
    <div class="step-form03" id="Form03" style="display: none;">
        <div class="container">
            <div  class="custom_form">
                <div class="accordion" id="accordionStep3">
                    <div class="card">
                        <div class="card-header" id="headingOne">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" onclick="get_language_country('collapseOne');">
                                    general

                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseOne" class="collapse" data-parent="#accordionStep3">
                            <form autocomplete="off" id="coach-step-three" method="post" action="{{ url('coach/coach-step-three-general') }}" >
                                {{ csrf_field() }}
                                <div class="card-body">
                                    <div class="container">
                                        <div class="row common-row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Years of Experience</label>
                                                    <select id="playing_exp" class="selectpicker form-control select-custom" name="playing_exp" data-size="4"  title="Select Experience">
                                                        <option value="0-2" {{ getUserGeneral('playing_exp') == '0-2' ? 'selected':''}} > 0-2 </option>
                                                        <option value="2-5"{{ getUserGeneral('playing_exp') == '2-5' ? 'selected':''}}>2-5</option>
                                                        <option value="6-10" {{ getUserGeneral('playing_exp') == '6-10' ? 'selected':''}}>6-10</option>
                                                        <option value="11-15"{{ getUserGeneral('playing_exp') == '11-15' ? 'selected':''}}>11-15</option>
                                                        <option value="16-20"{{ getUserGeneral('playing_exp') == '16-20' ? 'selected':''}}>16-20</option>
                                                        <option value="21-25"{{ getUserGeneral('playing_exp') == '21-25' ? 'selected':''}}>21-25</option>
                                                        <option value="26-30"{{ getUserGeneral('playing_exp') == '26-30' ? 'selected':''}}>26-30</option>
                                                        <option value="30+"{{ getUserGeneral('playing_exp') == '30+' ? 'selected':''}}>30+</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group ml-2">
                                                    <label class="control-label ml-0">Currently Under Contract</label>
                                                    <ul class="list-inline common_list mb-0">
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="contract01" name="under_contract" value="yes" {{ (!empty(getUserGeneral('under_contract'))) && (getUserGeneral('under_contract') == 'yes') ? 'checked' : '' }}>
                                                                <label for="contract01">
                                                                    <i></i> Yes
                                                                </label>
                                                            </div>
                                                        </li>
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="contract02" name="under_contract" value="no" {{ (empty(getUserGeneral('under_contract'))) || (getUserGeneral('under_contract') == 'no') ? 'checked' : '' }}>
                                                                <label for="contract02">
                                                                    <i></i> No
                                                                </label>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Current Team</label>
                                                    <div class="input-field">
                                                        <input type="text" name="current_team" placeholder="Current Team" value="{{ getUserGeneral('current_team') }}">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Current Team Link</label>
                                                    <div class="input-field">
                                                        <input type="text" name="current_team_link" placeholder="Team Link" value="{{ getUserGeneral('current_team_link') }}">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Current League or Conference</label>
                                                    <div class="input-field">
                                                        <input type="text" name="current_league" value="{{ getUserGeneral('current_league') }}" placeholder="Current League or Conference">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Current League or Conference Link</label>
                                                    <div class="input-field">
                                                        <input type="text" name="current_league_link" value="{{ getUserGeneral('current_league_link') }}" placeholder="Current League or Conference Link">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Former Team</label>
                                                    <div class="input-field">
                                                        <input type="text" name="former_team" value="{{ getUserGeneral('former_team') }}" placeholder="Former Team">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Former Team Link</label>
                                                    <div class="input-field">
                                                        <input type="text" name="former_team_link" value="{{ getUserGeneral('former_team_link') }}" placeholder="Former Team Link">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Former League or Conference</label>
                                                    <div class="input-field">
                                                        <input type="text" name="former_league" value="{{ getUserGeneral('former_league') }}" placeholder="Former League or Conference">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Former League or Conference Link</label>
                                                    <div class="input-field">
                                                        <input type="text" name="former_league_link" value="{{ getUserGeneral('former_league_link') }}" placeholder="Former League or Conference Link">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group ml-2">
                                                    <label class="control-label ml-0">Passport Ready</label>
                                                    <ul class="list-inline common_list mb-0">
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="passport01" name="passport" value="yes" {{ (!empty(getUserGeneral('passport'))) && (getUserGeneral('passport') == 'yes') ? 'checked' : '' }}>
                                                                <label for="passport01">
                                                                    <i></i> Yes
                                                                </label>
                                                            </div>
                                                        </li>
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="passport02" name="passport" value="no" {{ (empty(getUserGeneral('passport'))) || (getUserGeneral('passport') == 'no') ? 'checked' : '' }}>
                                                                <label for="passport02">
                                                                    <i></i> No
                                                                </label>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Country of Issuance</label>
                                                    <select id="general_country" name="country_id" class="selectpicker form-control select-custom" title="Select Country" data-size="4">
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Native Language</label>
                                                    <select id="native_lang_id" name="native_lang_id" class="selectpicker form-control select-custom" title="Select Language" data-size="4">
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Secondary Language</label>
                                                    <select id="secondary_lang_id" name="secondary_lang_id" class="selectpicker form-control select-custom" title="Select Language" data-size="4">
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group ml-2">
                                                    <label class="control-label ml-0">Looking to Sign</label>
                                                    <ul class="list-inline common_list mb-0">
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="sign01" name="look_to_sign" value="yes" {{ (!empty(getUserGeneral('look_to_sign'))) && (getUserGeneral('look_to_sign') == 'yes') ? 'checked' : '' }}>
                                                                <label for="sign01">
                                                                    <i></i> Yes
                                                                </label>
                                                            </div>
                                                        </li>
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="sign02" name="look_to_sign" value="no" {{ (empty(getUserGeneral('look_to_sign'))) || (getUserGeneral('look_to_sign') == 'no') ? 'checked' : '' }}>
                                                                <label for="sign02">
                                                                    <i></i> No
                                                                </label>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>


                                            <div class="col-md-6">
                                                <div class="form-group ml-2">
                                                    <label class="control-label ml-0">Select Ability to Relocate</label>
                                                    <ul class="list-inline common_list mb-0">
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="relocate01" name="relocate" value="yes" {{ (!empty(getUserGeneral('relocate'))) && (getUserGeneral('relocate') == 'yes') ? 'checked' : '' }}>
                                                                <label for="relocate01">
                                                                    <i></i> Yes
                                                                </label>
                                                            </div>
                                                        </li>
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="relocate02" name="relocate" value="no" {{ (empty(getUserGeneral('relocate'))) || (getUserGeneral('relocate') == 'no') ? 'checked' : '' }}>
                                                                <label for="relocate02">
                                                                    <i></i> No
                                                                </label>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Current Level</label>
                                                    <select class="selectpicker form-control select-custom" name="level_id" id="glevel_id" title="Select Level"  data-size="4">
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Select Citizenship</label>
                                                    <select id="citizenship" name="citizenship" class="selectpicker form-control select-custom" title="Select Citizenship"  data-size="4">
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">I Would Like to Work in</label>
                                                    <select id="work_in_country_id" name="work_in_country_id" class="selectpicker form-control select-custom" title="Select Country"  data-size="4">
                                                    </select>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </form>
                            {!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepThreeRequest','#coach-step-three') !!}
                        </div>
                    </div>
                    <!-- xxxxxxx -->

                    <!--common route for all below tab -->
                    <!-- for page render -->
                    <input type="hidden" data-addurl="{{ url('coach/coach-step-three') }}" id="render_html">
                    <!-- for add  -->
                    <input type="hidden" data-url="{{ url('coach/coach-add-update-experience') }}" id="common_route">
                    <!-- for add  -->
                    <input type="hidden" data-url="{{ url('coach/coach-edit-delete-experience') }}" id="edit_delete_route">
                    <!--End-->

                    <div class="card">
                        <div class="card-header" id="headingSix">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" onclick="get_toggle('collapseSix', 'college', '');">
                                    PREP/COLLEGE EXPERIENCE
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseSix" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->



                            <!-- render html end -->
                        </div>
                    </div>

                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header" id="headingSeven">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" onclick="get_toggle('collapseSeven', 'pro', '');">
                                    PRO EXPERIENCE
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseSeven" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->



                            <!-- render html end -->
                        </div>
                    </div>

                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header" id="headingEight">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" onclick="get_toggle('collapseEight', 'international', '');">
                                    INTERNATIONAL EXPERIENCE
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseEight" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->



                            <!-- render html end -->
                        </div>
                    </div>

                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header" id="headingNine">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" onclick="get_toggle('collapseNine', 'indoor', '');">
                                    INDOOR EXPERIENCE
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseNine" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->



                            <!-- render html end -->
                        </div>
                    </div>







                    <!-- xxxxxxx -->

                    <div class="card">
                        <div class="card-header" id="headingTwo">
                            <h5 class="mb-0">
                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" onclick="get_toggle('collapseTwo', 'accolades', '');">
                                    ACCOLADES / Awards / Captainships / championship

                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseTwo" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->



                            <!-- render html end -->
                        </div>
                    </div>
                    <!-- xxxxxxx -->
                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header" id="headingThree">
                            <h5 class="mb-0">
                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" onclick="get_toggle('collapseThree', 'education', '');">
                                    Education

                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseThree" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->



                            <!-- render html end -->
                        </div>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" onclick="get_toggle('collapseFour', 'coaching', '');">
                                    Coaching experience

                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseFour" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->



                            <!-- render html end -->
                        </div>
                    </div>

                    <!-- xxxxxxx -->
                    <div class="btn-row w-100  text-right">
                        <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2 font-22" id="preStep02">PREVIOUS</a>
                        <button type="button" class="btn btn-success btn-lg border-2 font-22" id="nextStep03" onclick="thirdStepForm('coach-step-three', 'next')">NEXT</button>
                        <a href="javascript:void(0);" class="btn btn-success btn-lg border-2 font-22" id="nextStep033" onclick="thirdStepForm('coach-step-three', 'exit')" >SAVE & EXIT</a>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- xxxxxxx -->
    <div class="step-form04" id="Form04" style="display: none;">
        <div class="container">
            <form autocomplete="off" id="coach-step-four" class="custom_form" method="post" action="javascript:void(0)">
                {{ csrf_field() }}
                <div class="row common-row">
                    <div class="col-md-6">
                        <div class="form-group upload">
                            <label class="control-label">Add Files</label>
                            <div class="input-field">
                                <div id="uploadFiles">
                                    <div class="file-upload forupload">
                                        <div class="file-select ">
                                            <div class="file-select-name nofile_name" id="noFile">No file chosen...</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="image-upload-loader"></div>
                            </div>
                        </div>
                    </div>
                </div>   
                <ul class="list-inline multipal_images d-flex black-scroll" id="MultipalImages">
                     <!--get media image thumb append-->
                 </ul>
                <div id="media-validation-message">
                </div>
                <div class="row common-row">
                    <div class="col-12 pl-0">
                        <div class="btn-row w-100  text-right">
                            <button class="btn btn-secondary btn-lg border-2 font-22" id="preStep03">PREVIOUS</button>
                            <button type="button" class="btn btn-success btn-lg border-2 font-22" id="nextStep04" onclick="fourthStepForm('coach-step-four', 'next')">NEXT</button>
                            <button class="btn btn-success btn-lg border-2 font-22" id="nextStep044" onclick="fourthStepForm('coach-step-four', 'exit')">SAVE & EXIT</button>
                        </div>
                    </div>
                </div>
            </form>  
            {!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepFourRequest','#coach-step-four') !!}

        </div>
    </div>
    <!-- xxxxxxx -->
    <div class="step-form05 last-form" id="Form05" style="display: none;">
        <div class="container">
            <form autocomplete="off" id="coach-step-five" class="custom_form" method="post" action="{{ url('coach/coach-step-five') }}">
                {{ csrf_field() }}
                <label class="control-label">Salary Range (USD)</label>
                <div class="row common-row">
                    <div class="col">
                        <div class="form-group">
                            <div class="input-field">
                                <input type="text" name="salary_from" value="{{!empty($userDetail->from_salary) ? $userDetail->from_salary : ''}}" placeholder="From" id="fromSalary" maxlength="10">
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <div class="input-field dashed">
                                <input type="text" name="salary_to" value="{{!empty($userDetail->to_salary) ? $userDetail->to_salary : ''}}" placeholder="To" id="toSalary" maxlength="10">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- xxxxxxx -->
                <div class="row common-row" id="userBenefitMain">
                    @if(!empty($masterBenefits))
                    @php $userBenefits = getUserBenefits(); @endphp
                    @foreach($masterBenefits as $benefits)
                    <div class="col-md-3 col-sm-6">
                        <label class="d-block for-check">
                            <input type="checkbox" name="benefits[]" value="{{ $benefits->id }}" id="one{{ $benefits->id }}" class="d-none" @php if( in_array($benefits->id, $userBenefits) ){ echo 'checked'; } @endphp>
                                   <span class="box-wrap d-flex align-items-center justify-content-center text-center">
                                <span class="benefit-box text-center mb-0">
                                    <i class="{{$benefits->image}}"></i>
                                    <span class="mb-0 d-block">{{$benefits->title}}</span>
                                </span>
                            </span>
                        </label>
                    </div>
                    @endforeach
                    @endif 
                    <div class="col-md-3 col-sm-6">
                        <a href="javascript:void(0);" class="box-wrap add-box d-flex align-items-center justify-content-center text-center" id="addBenefit">
                            <div class="benefit-box text-center">
                                <p class="mb-0">Add Other Benefits</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="row common-row" id="userBenefitMain">

                    <!-- xxxxxxx -->
                    <div class="col-12 pl-0">
                        <div class="btn-row w-100  text-right">
                            <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2 font-22" id="preStep04">PREVIOUS</a>
                            <button type="button" class="btn btn-success btn-lg border-2 font-22" id="nextStep05" onclick="fifthStepForm('coach-step-five', 'next')">SAVE</button>
                        </div>
                    </div>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Coach\Http\Requests\CoachStepFiveRequest','#coach-step-five') !!}
        </div>
    </div>
</main>
<!-- Image cropper model -->
<div id="imagCropperModal" class="modal fade image_cropper" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel01" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog common-modal crop-modal modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title heading-modal text-center">Profile Image</h4>
            </div>
            <div class="modal-body">
                <div id="cropperDiv"><div style="display:none;" id="processloader" class="imagmodelloader center-block"><i class="fa fa fa-spinner fa-pulse fa-2x"></i></div> </div>
            </div>
        </div>
    </div>
</div>

<!-- After save step form redirect url -->
<input type="hidden"  data-url="{{ url('coach/coach-profile') }}" id="step_form_redirect" >
<!--      Country/State, Language, Level and position  URL 
-->     <input type="hidden"  data-url="{{ url('get-all-country') }}" id="all_country" >
<input type="hidden"  data-url="{{ url('get-all-language') }}" id="all_language" >
<input type="hidden"  data-url="{{ url('get-all-level') }}" id="all_level" >
<input type="hidden"  data-url="{{ url('get-all-position') }}" id="all_positon" >
<input type="hidden"  data-url="{{ url('get-state-by-country-id') }}" id="get_state_by_country" >
<!-- Image upload url -->
<input type="hidden"  data-url="{{ url('upload-profile-image') }}" id="upload_profile_image" >
<input type="hidden"  data-url="{{ url('load-profile-image-cropper') }}" id="loading_profile_image" >
<input type="hidden"  data-url="{{ url('save-profile-image') }}" id="save_profile_image" >
<input type="hidden"  data-url="{{ url('coach/coach-step-four') }}" id="step-forth-form-url">
<!-- end -->   

<script type="text/javascript" src="{{ url('public/js/coach/coach-step-forms.js') }}"></script>
<script type="text/javascript" src="{{ url('public/js/ajaxupload.3.5.js') }}"></script>
<script type="text/javascript" src="{{ url('public/js/cropper.min.js') }}"></script>
<script>

        $('#fromSalary').on('keyup', function () {
            if (($('#toSalary').val()) && ($(this).val() <= $('#toSalary').val())) {
                $('#one1').prop('checked', true);
            } else {
                $('#one1').prop('checked', false);
            }
        });
        $('#toSalary').on('keyup', function () {
            if (($('#fromSalary').val()) && ($(this).val() >= $('#fromSalary').val())) {
                $('#one1').prop('checked', true);
            } else {
                $('#one1').prop('checked', false);
            }
        });

        checkYear = false;

        // accordion
        $('.collapse').on('shown.bs.collapse', function (e) {
            var $card = $(this).closest('.card');
            $('html,body').animate({
                scrollTop: $card.offset().top - 70
            }, 500);
        });

        //datepicker
        $(function () {
            $('#datetimepicker01,#datetimepicker02,#datetimepicker03,#datetimepicker04, #datetimepicker05, #datetimepicker06, #datetimepicker07, #datetimepicker08 ').datetimepicker({
                format: 'L',
                widgetPositioning: {
                    horizontal: 'right',
                    vertical: 'bottom'
                },
            });
        });

        $('#preStep01').click(function () {
            $('#step01').removeClass('pre-active');
            $('#step01').addClass('active');
            $('#step02').removeClass('active');
            $('#Form02').hide();
            $('#Form01').show();
            $('html, body').animate({
                scrollTop: 0
            }, "slow");
        });

        $('#preStep02').click(function () {
            $('#step02').removeClass('pre-active');
            $('#step02').addClass('active');
            $('#step03').removeClass('active');
            $('#Form03,#Form01').hide();
            $('#Form02').show();
            $('html, body').animate({
                scrollTop: 0
            }, "slow");
        });

        $('#preStep03').click(function () {
            $('.file_errordiv').find('div').html('');
            $('#nextStep04').attr("disabled", false);
            $('#nextStep044').attr("disabled", false);
            $('#step03').removeClass('pre-active');
            $('#step03').addClass('active');
            $('#step04').removeClass('active');
            $('#Form04,#Form03,#Form01').hide();
            $('#Form03').show();
            $('html, body').animate({
                scrollTop: 0
            }, "slow");
        });

        // screen 05
        $('#preStep04').click(function () {
            $('#step04').removeClass('pre-active');
            $('#step04').addClass('active');
            $('#step05').removeClass('active');
            $('#Form05').hide();
            $('#Form04').show();
            $('#MultipalImages').html('');
            $('html, body').animate({
                scrollTop: 0
            }, "slow");
        });

    // add benefit
    $('#addBenefit').click(function () {
          $('#userBenefitMain .col-md-3.col-sm-6:last-child').before('\
            <div class="col-md-3 col-sm-6">\
                <div class="box-wrap-outer-for-input">\
                <i class="flaticon-cross"  onclick="$(this).parent().parent().remove()"></i>\
                <label class="d-block for-check">\
                    <input type="checkbox" class="d-none">\
                    <span class="box-wrap with_input d-flex align-items-center justify-content-center text-center">\
                        <span class="benefit-box text-center mb-0">\
                            <i class="icon-benefit"></i>\
                        </span>\
                    </span>\
                </label>\
                <span class="form-group mb-0 d-block check_input">\
                    <input type="text" name="title[]" class="form-control" autofocus="" required>\
                </span>\
                </div>\
            </div>\
        ');
    });

    // show user image onchange.
    $("[name=profile_image]").change(function () {
        if (this.files && this.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#profile_image').attr('src', e.target.result);
            }
            reader.readAsDataURL(this.files[0]);
        }
    });
    $(document).ready(function () {
        // get all country

            $.post("{{ url('get-all-country') }}", {_token: '{{ csrf_token() }}', type: 'user-profile-step-one'}, function (data) {
                $('#country').html(data);
                $('#country').selectpicker('refresh');
                $('#country').selectpicker('val', '{{ $countryId }}');
                $('#country').selectpicker('render');
            });
        getAge("{{getUserDataByColumn('age')}}");
        // for gettting team player add form
        $.post("{{ url('get-all-position') }}", {_token: '{{ csrf_token() }}', type: 'coach'}, function (data) {
            $('#position').html(data);
            var position_id = '{{ getUserDataByColumn("position_id") }}';
            //console.log(position_id);
            $('#position').selectpicker('refresh');
            if (position_id != '') {
                $('#position').selectpicker('val', [position_id.split(',')[0], position_id.split(',')[1]]);
                $('#position').selectpicker('render');
            }
        });

        var type = localStorage.getItem('type');
        if (type == 'step-form-about') {
            $('#step01,#step02,#step03').addClass('active');
            $('#step01,#step02').addClass('pre-active');
            $('#Form01').hide();
            $('#Form02').hide();
            $('#Form03').show();
            $('html, body').animate({
                scrollTop: 0
            }, "slow");
        }
        if(type == 'step-form-desired-benefits'){
            $('#step01,#step02,#step03,#step04,#step05').addClass('active');
            $('#step01,#step02,#step03,#step04').addClass('pre-active');
            $('#Form01').hide();
            $('#Form02').hide();
            $('#Form03').hide();
            $('#Form04').hide();
            $('#Form05').show();
            $('html, body').animate({
                scrollTop: 0
            }, "slow");}
        localStorage.removeItem('type');
    })

    /* for step 3 form education */
    // get all country
    function getCountry(type, country_id) {
        $.post($("#all_country").data('url'), {_token: '{{ csrf_token() }}', type: type, country_id: country_id}, function (data) {
            $('#country_id').html(data);
            $('#country_id').selectpicker('refresh');
            $('#country_id').selectpicker('val', country_id);
            $('#country_id').selectpicker('render');
        });
    }
    ;

    // get player state
    function getStateByCountry(type, country_id, state_id) {
        $.post($("#get_state_by_country").data('url'), {_token: '{{ csrf_token() }}', country_id: country_id, state_id: state_id, type: type}, function (data) {
            setTimeout(function () {
                $('#state_id').html(data);
                $('#state_id').selectpicker('refresh');
                $('#state_id').selectpicker('val', state_id);
                $('#state_id').selectpicker('render');
            }, 1500);
        });
    }
    ;

    // get state by country id
    $(document).on('change', '#country', function () {
        $.post("{{ url('get-state-by-country-id') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: 'user-profile-step-one'}, function (data) {
            $('#state').html(data);
            $('#state').selectpicker('refresh');
            $('#state').selectpicker('val', '{{ $stateId }}');
            $('#state').selectpicker('render');
        });
    });

    $(document).on('change', '#country_id', function () {
        $.post($("#get_state_by_country").data('url'), {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: ''}, function (data) {
            $('#state_id').html(data);
            $('#state_id').selectpicker('refresh');
        });
    });

    $(document).on('change', '#playing_exp', function () {
        $('#playing_exp').selectpicker('refresh');
    });
//    /* Genearl staep 3 country and language */
    function get_language_country(type)
    {
        setTimeout(function () {
            $("#playing_exp").selectpicker('refresh');
        }, 2000);
        if ($("#" + type).hasClass('show')) { // if tab already open then return
            return false;
        }
         var url = "{{ url('get-user-general-info') }}"; 
        $.get(url, {id: ''}, function (response) {
            var country_id = response.country_id;
            var native_language = response.native_lang_id;
            var second_language = response.secondary_lang_id;
            var level_id = response.level_id;
            var citizenship = response.citizenship;
            var work_in_country_id = response.work_in_country_id;
        /* for general country */
        $.post($("#all_country").data('url'), {_token: '{{ csrf_token() }}', type: 'general', country_id: country_id}, function (data) {
            $('#general_country').html(data);
            $('#general_country').selectpicker('refresh');
            $('#citizenship').html(data);
            $('#citizenship').selectpicker('refresh');
            $('#work_in_country_id').html(data);
            $('#work_in_country_id').selectpicker('refresh');
            if (country_id != '')
            {
                $('#general_country').selectpicker('val', country_id);
                $('#general_country').selectpicker('render');
            }
            if (citizenship != '')
            {
                $('#citizenship').selectpicker('val', citizenship);
                $('#citizenship').selectpicker('render');
            }
            if (work_in_country_id != '')
            {
                $('#work_in_country_id').selectpicker('val', work_in_country_id);
                $('#work_in_country_id').selectpicker('render');
            }

        });

//       /* for general languages */
        $.post($("#all_language").data('url'), {_token: '{{ csrf_token() }}'}, function (data) {
            $('#native_lang_id').html(data);
            $('#native_lang_id').selectpicker('refresh');
            $('#secondary_lang_id').html(data);
            $('#secondary_lang_id').selectpicker('refresh');
            if (native_language != '') {
                $('#native_lang_id').selectpicker('val', native_language);
                $('#native_lang_id').selectpicker('render');
            }
            if (second_language != '') {
                $('#secondary_lang_id').selectpicker('val', second_language);
                $('#secondary_lang_id').selectpicker('render');
            }
        });
        getLevel(level_id, 'general');
        });
    }
    /* Genearl step 3 coaching and education */
    function getLevel(id, type)
    {
        /* for coaching step 3  */
        $.post($("#all_level").data('url'), {_token: '{{ csrf_token() }}'}, function (data) {
            $('#colevel_id').html(data);
            $('#colevel_id').selectpicker('refresh');
            $('#elevel_id').html(data);
            $('#elevel_id').selectpicker('refresh');
            $('#glevel_id').html(data);
            $('#glevel_id').selectpicker('refresh');
            $('#interlevel_id').html(data);
            $('#interlevel_id').selectpicker('refresh');
            $('#indoorlevel_id').html(data);
            $('#indoorlevel_id').selectpicker('refresh');
            if (id != '' && type == 'coaching')
            {
                $('#colevel_id').selectpicker('val', id);
                $('#colevel_id').selectpicker('render');
            }
            if (id != '' && type == 'education')
            {
                $('#elevel_id').selectpicker('val', id);
                $('#elevel_id').selectpicker('render');
            }
            if (id != '' && type == 'general')
            {
                $('#glevel_id').selectpicker('val', id);
                $('#glevel_id').selectpicker('render');
            }
            if (id != '' && type == 'international')
            {
                $('#interlevel_id').selectpicker('val', id);
                $('#interlevel_id').selectpicker('render');
            }
            if (id != '' && type == 'indoor')
            {
                $('#indoorlevel_id').selectpicker('val', id);
                $('#indoorlevel_id').selectpicker('render');
            }

        });
    }

    /* image uload by cropper */
    var profile_picture = $('.upload-btn');
    pPicture = new AjaxUpload(profile_picture, {
        action: $("#upload_profile_image").data('url'),
        name: 'profileImage',
        cache: false,
        method: 'post',
        data: {_token: '{{ csrf_token() }}', folder: 'coach', image_type: 'profileImage'},
        responseType: "JSON",
        onChange: function (file, ext) {
            //check the file size
            if (pPicture._input.files[0].size > 2097152) { //2MB
                //show alert message
                message('error', 'Selected file is bigger than 2MB.');
                return false;
            }
        },
        onSubmit: function (file, ext) {
            if (!(ext && /^(jpg|png|jpeg)$/.test(ext))) {
                message('error', 'Only jpg, jpeg, png files are allowed.');
                return false;
            }
        },
        onComplete: function (file, response) {
            console.log(file, response);
            if (file != "") {
                if (response.success == 1) {
                    load_cropp_image(response.filename, 'profileImage');
                } else {
                    message('error', response.error);
                }
            } else {
                message('error', "Error occured! please try again.");
            }
        }
    });
    function  load_cropp_image(filename, type) {
        $("#imagCropperModal").modal('show');
        var url = $("#loading_profile_image").data('url');
        $.ajax({
            type: "POST",
            url: url,
            data: {_token: "{{ csrf_token() }}", filename: filename, folder: 'coach', thumb_folder: 'coach/thumb', image_type: type},
            success: function (response) {
                $("#cropperDiv").html(response);

                setTimeout(function () {
                    $("#cropbutton").attr('disabled', false);
                }, 3000);
            }
        });
    }

//  onload exicute function on upload multiple files
    $(document).ready(function () {
        $('#playing_exp').selectpicker('refresh');
        uploadMultipleFile();
    });

    // multiple imageupload
    function uploadMultipleFile() {
        var options = {
            url: "{{url('coach/upload-multiple-file')}}",
            dragDrop: true,
            method: "POST",
            cache: false,
            allowedTypes: "jpg,png,gif,jpeg,mp4",
            fileName: "myPost",
            async: true,
            multiple: true,
            formData: {_token: '{{ csrf_token() }}'},
            onSelect: function (files, data, xhr)
            {
                var ImageCount = $('.imagecount').length;
                uploadFileCount = files.length;
                var totaleCount = ImageCount + uploadFileCount;
                if (totaleCount > 10) {
                    $('#media-validation-message').html('Maximum 10 file upload');
                    return false;
                }else{
                    $('#media-validation-message').html('');
                } 
                
                $('#nextStep04').attr("disabled", "disabled");
                $('#nextStep044').attr("disabled", "disabled");

                $.each(files, function (index, value) {
                    if (value.type == 'image/jpeg' || value.type == 'image/png' || value.type == 'image/jpg' || value.type == 'video/mp4') {
                        $('#preStep03').attr("disabled", "disabled");
                        $('.image-upload-loader').html('<div class="img_loader"><div class="btn_ring"></div></div>');
                        $('.success-message').html('');
                    }
                });
            },
            onSuccess: function (files, data, xhr)
            {
                $('.image-upload-loader').html('');
                if (data.success == true) {
                   $('#MultipalImages').append('<li class="list-inline-item imagecount">\n\
                                       <input type="hidden" name="mediaType[]" value="' + data.type + '">\n\
                                       <input type="hidden" class="imageCount" name="hdnImageName[]" id="hdnImageName" value="' + data.image + '">\n\
                                       <img src="<?php echo url("public/uploads/temp/thumb") ?>/' + data.image + '" class="img-fluid" alt=""> \n\
                                       <div class="icon"> \n\
                                             <a href="javascript:void(0);" onclick="removeImage(this)"><i class="fas fa-times"></i></a>\n\
                                       </div>\n\
                                      </li>');
                    $("#MultipalImages").mCustomScrollbar("destroy");
                    $("#MultipalImages").mCustomScrollbar({
                        theme: "dark",
                         axis:"x",
                     });
                } else {
                    message('error', data.message);
                }
                $('#preStep03').removeAttr("disabled");
                $('#nextStep04').removeAttr("disabled");
                $('#nextStep044').removeAttr("disabled");
            },
        }
        $("#uploadFiles").uploadFile(options);
    }
    
      function removeImage(obj) {
            $('#media-validation-message').html('');
            $(obj).parent().parent().remove();
            $("#MultipalImages").mCustomScrollbar("destroy"); /* Post scrolling */
            $("#MultipalImages").mCustomScrollbar({
              theme: "dark",
               axis:"x",
            });
      }
    
</script>

@endsection