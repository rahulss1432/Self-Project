<!doctype html>
<html lang="en">

<head>
    <title>404 page</title>
    <?php include "include/head-link.php" ?>
</head>

<body class="error-page">
    <div class="middle-content text-center">
        <h1>404<span>Error</span></h1>
        <h4>Ooops! Something went wrong</h4>
        <a href="login.php" class="btn btn-error">back to home</a>
    </div>
</body>

</html>