@if( $states->count() > 0)
@foreach( $states as $row )
<option value="{{ $row->state_id }}">{{ $row->state_name }}</option>
@endforeach
@endif