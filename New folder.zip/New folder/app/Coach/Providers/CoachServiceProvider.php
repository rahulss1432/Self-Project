<?php

namespace App\Coach\Providers;

use Illuminate\Support\ServiceProvider;

class CoachServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services. 
     *
     * @return void
     */
    /*
   
    */
    public function boot()
    {
        $this->loadViewsFrom(__DIR__.'/../Resources/Views','coach');
        $this->loadTranslationsFrom(__DIR__.'/../Resources/Lang', 'coach');
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register(RouteServiceProvider::class);
    }
    protected function loadViewsFrom($path, $namespace)
    {
        $this->app['view']->addNamespace('coach', base_path().'/app/Coach/resources/views');
    }

    protected function loadTranslationsFrom($path, $namespace)
    {
        $this->app['translator']->addNamespace($namespace, $path);
    }
}
