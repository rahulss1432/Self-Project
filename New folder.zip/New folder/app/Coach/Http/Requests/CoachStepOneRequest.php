<?php

namespace App\Coach\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CoachStepOneRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [

            'profile_image' => 'nullable|mimes:jpeg,jpg,png|max:2048',
            'resume' => 'nullable|mimes:doc,pdf,docx,zip|max:1048',
            'first_name' => 'required|alpha_dash|min:2|max:30',
            'last_name' => 'required|alpha_dash|min:2|max:30',
            'age' => 'required|digits_between:1,3',
            'country' => 'required',
            'state' => 'required',
            'city' => "required|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/|max:100",
//            'zip' => 'required|regex:/^[a-zA-Z0-9]+$/u|max:6|min:1',
            'zip' => 'required|get_latlong_byzip|max:10',
            'position' => 'required',
            'signature' => 'nullable|regex:/^[a-zA-Z0-9.@&][\sa-zA-Z0-9.@&]*$/|max:20',
            'bio' => 'nullable|remove_spaces|max:250',
        ];
    }

    public function messages() {
        return [
            'zip.get_latlong_byzip' => 'The zip code is invalid.',
            'bio.remove_spaces' => 'The only space not allowed.',
            'first_name.regex' => 'The first name field only alphabets allowed.',
            'last_name.regex' => 'The last name field only alphabets allowed.',
            'profile_image.max' => 'The banner image may not be greater than 2MB.'
        ];
    }

}
