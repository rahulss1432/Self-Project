<?php

namespace App\Coach\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SendChatMessageRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'message' => 'required_if:attachment,!=,',
            'attachment' => 'nullable|mimes:jpeg,jpg,png,doc,pdf,docx,zip,mp4,mov',
        ]; 
    }
    
    /*
     * Function for show validation messages.
     */
    public function messages(){
        return [
            'message.required_if' => 'Message field is required.'
        ];
    }
}
