<?php

namespace App\Coach\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CoachStepThreeIntRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'experience_type' => 'required',
            'from_year' => 'required',
            'to_year' => 'required',
        ];
    }
      public function messages() {
         return [
             'experience_type.required' =>'The level field is required.',
            // 'from_year.required_if' =>'The from year field is required.',
            // 'to_year.required_if' =>'The to year field is required.',
            ];
     }
}
