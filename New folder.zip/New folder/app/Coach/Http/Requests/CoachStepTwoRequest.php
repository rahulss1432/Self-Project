<?php

namespace App\Coach\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CoachStepTwoRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'facebook' => 'nullable|url',
            'skype' => 'nullable|url',
            'website' => 'nullable|url',
            'twitter' => 'nullable|url',
            'instagram' => 'nullable|url',
            'linkedin' => 'nullable|url'
        ];
    }

    public function messages() {
        return [
            'facebook.regex' => 'Please provide valid url.',
            'skype.regex' => 'Please provide valid url.',
            'website.regex' => 'Please provide valid url.',
            'twitter.regex' => 'Please provide valid url.',
            'instagram.regex' => 'Please provide valid url.',
            'linkedin.regex' => 'Please provide valid url.',
        ];
    }

}
