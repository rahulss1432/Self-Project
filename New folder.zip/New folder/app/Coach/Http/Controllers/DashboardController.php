<?php

namespace App\Coach\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;

class DashboardController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('coach::coach.index');
    }

    public function postView(){
       $html = View::make('coach::ajax-content._post-view')->render();
       return Response::json(['html' => $html]);
    }

    public function newJobList(){
        $html = View::make('coach::ajax-content._new-job-list')->render();
        return Response::json(['html' => $html]);
    }

    public function appliedJobList(){
        $html = View::make('coach::ajax-content._applied-job-list')->render();
        return Response::json(['html' => $html]);
    }
    
    public function coachProfile(){
        return view('coach::coach.coach-profile');
    }
    
    public function coachTimeline(){
        return view('coach::coach.coach-timeline');
    }
    
    public function coachMedia(){
        return view('coach::coach.coach-media');
    }

}
