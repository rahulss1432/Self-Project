<?php

namespace App\Coach\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Repositories\Coach\UserRepository;
use Auth;
use App\Coach\Http\Requests\CoachStepFiveRequest;
use App\Coach\Http\Requests\CoachStepOneRequest;
use App\Repositories\Player\EventRepository;

class CoachController extends Controller {
    /*
     * Class Construct.
     *
     * @param  array  $data
     * @return App\Player\Repositories\UserRepository;
     */

    public function __construct(UserRepository $user, EventRepository $event, \App\Repositories\UserRepository $commanUser) {
        $this->user = $user;
        $this->event = $event;
        $this->commanUser = $commanUser;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        expiredAppliedJobByUser(Auth::guard(getAuthGuard())->user()->id);
        return view('coach::coach.index');
    }

    /*
     * function for get all post.
     */

    public function postView() {
        $html = View::make('coach::ajax-content._post-view')->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get new jobs.
     */

    public function newJobList() {
        $jobs = $this->user->getPostJob();
        $html = View::make('coach::ajax-content._new-job-list', ['jobs' => $jobs])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get applied job list.
     */

    public function appliedJobList() {
        $appliedJobs = $this->user->getPostAppliedJob();
        $html = View::make('coach::ajax-content._applied-job-list', ['appliedJobs' => $appliedJobs])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for view profile.
     */

    public function coachProfile(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $upcoming_events = $this->event->getLatestThreeEvents();
        $user_repository = \App\Models\News::getNewsBulletin('limited');
        $attributes = $this->user->getAllCoachAttributes();
        return view('coach::coach.coach-profile', ['user' => $user, 'latest_news' => $user_repository, 'attributes' => $attributes, 'upcoming_events' => $upcoming_events]);
    }

    /*
     * function for get videos and users views.
     */

    public function getProfileMediaList(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $getUserMedia = $this->commanUser->getMediaListById($user->id);
        $html = View::make('coach::ajax-content._profile-media-list', ['mediaList' => $getUserMedia, 'user' => $user])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for view coach timeline.
     */

    public function coachTimeline($slug = null) {
        $id = '';
        if (!empty($slug)) {
            $id = getUserIdBySlug($slug);
        }
        $user = $this->user->getUseDetails($id);
        return view('coach::coach.coach-timeline', ['user' => $user, 'id' => $id]);
    }

    /*
     * function for view media.
     */

    public function coachMedia($slug = null) {
        $id = '';
        if (!empty($slug)) {
            $id = getUserIdBySlug($slug);
        }
        $user = $this->user->getUseDetails($id);
        return view('coach::coach.coach-media', ['user' => $user, 'id' => $id]);
    }

    /*
     * function for get listing media videos 
     */

    public function getMediaVideoList(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $getVideos = $this->commanUser->getMediaListByType('video', $user->id, 6);
        $html = View::make('coach::ajax-content._media-video-list', ['getVideos' => $getVideos])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get listing media images 
     */

    public function getMediaImageList(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $getimages = $this->commanUser->getMediaListByType('image', $user->id, 15);
        $html = View::make('coach::ajax-content._media-image-list', ['getimages' => $getimages])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for view coach profile edit form.
     */

    public function coachProfileForm() {
        $masterBenefits = $this->user->getAllBenefits();
        $userDetail = $this->user->getUseDetails(\Auth::guard(getAuthGuard())->user()->id);
        return view('coach::coach.coach-step-form', ['masterBenefits' => $masterBenefits, 'userDetail' => $userDetail]);
    }

    /*
     * function for coach profile step one.
     */

    public function coachStepOne(CoachStepOneRequest $request) {
        return $this->user->coachStepOne($request);
    }

    /*
     * function for coach profile step two.
     */

    public function coachStepTwo(Request $request) {
        return $this->user->coachStepTwo($request);
    }

    /*
     * function for coach profile step three general.
     */

    public function coachStepThreegeneral(Request $request) {

        return $this->user->coachStepThree($request);
    }

    /*
     * function for coach profile step three.
     */

    public function coachAddUpdateExp(Request $request) {

        return $this->user->coachExpAddUpdate($request);
    }

    public function coachEditDeleteExp(Request $request) {
        return $this->user->coachExpEditDelete($request);
    }

    public function coachStepThree(Request $request) {
        $type = $request['type'];
        $data = $this->user->coachStepThreeAbout($type);
        $html = View::make('coach::coach._load-about', ['data' => $data, 'type' => $type])->render();
        return Response::Json(['html' => $html]);
    }

    /*
     * function for coach profile step four.
     */

    public function coachStepFour(Request $request) {
        return $this->commanUser->saveMyProfileMedia($request);
    }

    /*
     * function for save Benefits.
     */

    public function coachStepFive(CoachStepFiveRequest $request) {
        return $this->user->coachStepFive($request);
    }

    /*
     * Render left side bar.
     */

    public function leftSidebar(Request $request) {
        try {
            $id = '';
            $slug = '';
            if (!empty($request) && !empty($request->id)) {
                $id = $request->id;
                $slug = getUserById($id, 'slug');
            }
            $user = $this->user->getUseDetails($id);
            $mediaList = $this->commanUser->getMediaListById($user->id);
            $html = View::make('coach::coach._load-left-side-html', ['user' => $user, 'page' => $request->page, 'slug' => $slug, 'mediaList' => $mediaList])->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Render right side bar.
     */

    public function rightSidebar(Request $request) {
        try {
            $id = '';
            $slug = '';
            if (!empty($request) && !empty($request->id)) {
                $id = $request->id;
                $slug = getUserById($id, 'slug');
            }
            $user = $this->user->getUseDetails($id);
            $html = View::make('coach::coach._load-right-side-html', ['user' => $user, 'page' => $request->page, 'slug' => $slug])->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * render the recent joined memeber page 
     */

    public function getRecentJoinedMembers(Request $request) {
        try {
            $o_id = '';
            if (!empty($request) && !empty($request->id)) {
                $o_id = $request->id;
            }
            $users = $this->user->getRecentJoinedMembers($request);
            $html = View::make('coach::ajax-content._members_recent_joined', ['users' => $users, 'o_id' => $o_id])->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Connect or dismiss recent joined member.
     */

    public function connectDismissMember(Request $request) {
        return $this->user->connectDismissMember($request);
    }

    /*
     * Show the members you may know page.
     */

    public function membersYouMayKnow($slug = null) {
        $id = '';
        if (!empty($slug)) {
            $id = getUserIdBySlug($slug);
        }
        return view('coach::coach.member-you-may-know', ['id' => $id]);
    }

    /*
     * Show all recent joined member list.
     */

    public function getMemberList(Request $request) {
        try {
            $users = $this->user->getRecentJoinedMembers($request);
            $html = View::make('coach::ajax-content._all_recent_member_list', ['users' => $users])->render();
            return Response::Json(['success' => true, 'html' => $html, 'users' => $users]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * function for get pro card coach.
     */

    public function coachProCard(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $html = View::make('coach::ajax-content._procard-coach', ['user' => $user])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get all education.
     */

    public function getAllEducation(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $educations = $this->user->getUseDetails($id);
        $html = View::make('coach::ajax-content._all_education_list-coach', ['educations' => $educations])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get all accolades.
     */

    public function getAccoladesList(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $accolades = $this->user->getUseDetails($id);
        $html = View::make('coach::ajax-content._accolades-list', ['accolades' => $accolades])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get all coaching experience.
     */

    public function getCoachingExperienceList(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $coaching_experience = $this->user->getUseDetails($id);
        $html = View::make('coach::ajax-content._coaching-experience-coach', ['experiences' => $coaching_experience])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Change user work mode.
     */

    public function workMode() {
        try {
            $workmode = $this->user->workMode();
            return Response::Json(['success' => true, 'workmode' => $workmode, 'message' => 'Work Mode Updated.']);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Get user notification.
     */

    public function getNotification() {
        if (getUserDataByColumn('current_status') == 'available') {
            return $this->user->getNotification();
        }
    }

    /**
     * get notification in front
     */
    public function getAllNotifications() {
        return view('coach::coach.notifications');
    }

    /**
     * get notification list in front
     */
    function notificationList() {
        $notifications = $this->user->getAllNotifications();
        $html = View::make('coach::ajax-content._notifications-list', ['notifications' => $notifications])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /*
     * Delete notifications.
     */

    public function deleteNotifications($id) {
        try {
            $this->user->deleteNotifications($id);
            return Response::Json(['success' => true, 'message' => 'notification delete successfully.']);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Get Connections List.
     */

    public function userConnectionsList(Request $request) {
        return $this->user->userConnectionsList($request);
    }

    /*
     * Get Connections.
     */

    public function getConnections($slug = null) {
        $id = '';
        if (!empty($slug)) {
            $id = getUserIdBySlug($slug);
        }
        return view('coach::coach.my-connections', ['slug' => $slug, 'id' => $id]);
    }

    /*
     * Get All Connections.
     */

    public function getAllConnections(Request $request) {
        try {
            $post = $request->all();
            $id = '';
            if (!empty($request) && $post['id'] != '') {
                $id = $post['id'];
            }
            $connections = $this->user->getAllConnections($post);
            $html = View::make('coach::ajax-content._members-list', ['connections' => $connections, 'o_id' => $id])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Accept Connection request.
     */

    public function acceptRejectConnection(Request $request) {
        try {
            $this->user->acceptRejectConnection($request);
            return Response::json(['success' => true, 'message' => 'Connection Updated.']);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for getting experience list.
     */

    public function getExperienceList(Request $request) {
        $post = $request->all();
        $id = '';
        if (isset($post['id'])) {
            $id = $post['id'];
        }
        $user = $this->user->getUseDetails($id);
        $post = $request->all();
        if ($post['experience_type'] == 'college_experience') {
            $userExperience = $user->userCollegeExperince;
            $experienceType = 'College';
        } elseif ($post['experience_type'] == 'user_pro') {
            $userExperience = $user->userProExperince;
            $experienceType = 'Pro';
        } elseif ($post['experience_type'] == 'user_international') {
            $userExperience = $user->userInternationalExperince;
            $experienceType = 'International';
        } else {
            $userExperience = $user->userIndooreExperince;
            $experienceType = 'Indoor';
        }
        $html = View::make('coach::ajax-content._user-experience-list', ['userExperience' => $userExperience, 'experienceType' => $experienceType])->render();
        return Response::json(['html' => $html]);
    }

    /*

     * Function for getting counts.
     */

    public function getAllCount(Request $request) {
        //$user_repository = $this->user;
        $id = Auth::guard(getAuthGuard())->user()->id;
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $getViewCount = $this->user->getViewCount($id);
        $getFollowCount = $this->user->getFollowCount($id);
        $getFollowersCount = $this->user->getFollowersCount($id);
        $getLikeCount = $this->user->getLikeCount($id);
        $getConnectionsCount = $this->user->getConnectionsCount($id);
        $newsBulletin = \App\Models\News::getNewsBulletin();
        $html = view('coach::ajax-content._all_counts_coach', ['getViewCount' => $getViewCount,
            'getFollowCount' => $getFollowCount,
            'getFollowersCount' => $getFollowersCount,
            'getLikeCount' => $getLikeCount,
            'getConnectionsCount' => $getConnectionsCount])->render();
        // $newsBulletin = \App\Models\News::getNewsBulletin();
        // $html = view('coach::ajax-content._all_counts_coach', ['user_repo' => $user_repository])->render();
        return Response::json(['html' => $html, 'newsBulletin' => $newsBulletin]);
    }

    /*
     * function for get Desired Benifites.
     */

    public function getDesiredBenifites(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $masterBenefits = \App\Models\MasterBenefits::where('created_by', 1)->where('title', '<>', 'Scholarship')->get();
        $html = View::make('coach::ajax-content._desired_benifites', ['user' => $user, 'masterBenefits' => $masterBenefits])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for load all Desired Benifites.
     */

    public function loadMoreBenefites(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $html = View::make('coach::ajax-content._load-more-benefites', ['user' => $user])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for load all Desired Benifites.
     */

    public function attributesList(Request $request) {
        $id = '';
        $post = $request->all();
        if (isset($post['id'])) {
            $id = $post['id'];
        }
        $user = $this->user->getUseDetails($id);
        if ($post['type'] == 'view_more') {
            $viewByOtherUser = isset($post['ViewByOtherUser']) ? $post['ViewByOtherUser'] : '';
            $html = View::make('coach::ajax-content._attributes_list', ['attributes' => $user, 'viewByOtherUser' => $viewByOtherUser])->render();
        } else {
            $html = View::make('coach::ajax-content._profile_page_attributes_list', ['user' => $user])->render();
        }
        return Response::json(['html' => $html]);
    }

    /*
     * function for render add skill modal.
     */

    public function addSkillsModal() {
        $userId = Auth::guard('coach')->user()->id;
        $suggestedAttributes = $this->user->getValidateAttributes('random');
        $validatedAttributes = $this->user->getValidateAttributes('all');
        $html = View::make('coach::ajax-content._add_skills_modal', ['suggestedAttributes' => $suggestedAttributes, 'validatedAttributes' => $validatedAttributes])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get other users skills.
     */

    public function getOtherUserSkills() {
        try {
            $user = getAllOtherUserSkills();
            $html = View::make('coach::ajax-content._add-compare-user', ['users' => $users])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Add coach skills
     */

    public function addCoachSkills(Request $request) {
        $coachAttributes = $this->user->addCoachSkills($request);
        return $coachAttributes;
    }

    /**
     *  Delete coach attribute
     * @param Request $request
     * @return type
     */
    public function deleteAttribute(Request $request) {
        return $this->user->deleteAttributes($request);
    }

    /*
     * function for update selected media file order 
     */

    public function updateSelectedMedia(Request $request) {
        $user = $this->user->getUseDetails($id = null);
        return $this->commanUser->updateSelectMedia($user->id, $request->media_id);
    }

    /*
     * function for get select image 
     */

    public function getSelectMedia(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $getSelectMedia = $this->commanUser->getSelectMedia($user->id);
        $html = View::make('coach::ajax-content._get-select-media', ['getSelectMedia' => $getSelectMedia])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * render the joined member based on country state city and non mutual friends.
     */

    public function getMatchedAndMutualJoinedMembers(Request $request) {
        try {
            $o_id = '';
            if (!empty($request) && !empty($request->id)) {
                $o_id = $request->id;
            }
            $users = $this->user->getMatchedAndMutualJoinedMembers($request);
            $html = View::make('coach::ajax-content._members_mutual_joined', ['users' => $users, 'o_id' => $o_id])->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * show all list of joined member based on country state city and non mutual friends.
     */

    public function getMatchedMutualJoinedMembersList(Request $request) {
        try {
            $o_id = '';
            if (!empty($request) && !empty($request->id)) {
                $o_id = $request->id;
            }
            $users = $this->user->getMatchedAndMutualJoinedMembers($request);
            $html = View::make('coach::ajax-content._all_matched_mutual_joined_member_list', ['users' => $users, 'o_id' => $o_id])->render();
            return Response::Json(['success' => true, 'html' => $html, 'users' => $users]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Show the friend request page.
     */

    public function myFriendRequest() {
        $changeConnectionStatus = $this->user->changeConnectionStatus();  // change connection status to read        
        return view('coach::coach.my-friend-request');
    }

    /*
     * my friend request
     */

    public function getAllFriendRequest(Request $request) {
        try {
            $post = $request->all();
            $id = '';
            if (!empty($request) && $post['id'] != '') {
                $id = $post['id'];
            }
            $connections = $this->user->getAllFriendRequests($post);
            $html = View::make('coach::ajax-content._friend-request-list', ['connections' => $connections, 'o_id' => $id])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get unread request count.
     */

    public function getRequestUnreadCount() {
        return $this->user->getRequestUnreadCount();
    }

//    upload mutiple files
    public function uploadMultipleMedia(Request $request) {
        return $this->commanUser->uploadPostFile($request);
    }

}
