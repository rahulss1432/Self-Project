<?php

namespace App\Common;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\models\ContestListings;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Exception;
use App\Models\User;


class Utility {

    public static function sendMail($data) {
        try {
            switch ($data['request']) {
                case "contact-us":
                    $admin_email = \App\Models\Setting::where(['setting_key' => 'admin-email'])->first();
                    $data['admin_email'] = ($admin_email->key_value);
                    Mail::send('emails.contact_us', ['data' => $data], function ($message) use ($data) {
                        $message->to($data['admin_email'])
                                ->subject($data['subject']);
                    });
                    break;
                case "verification_email":
                    Mail::send('emails.verification_email', ['data' => $data], function ($message) use ($data) {
                        $message->to($data['email'])
                                ->subject($data['subject']);
                    });
                    break;
                case "rating_email":
                    Mail::send('emails.rating_email', ['data' => $data], function ($message) use ($data) {
                        $message->to($data['email'])
                                ->subject($data['subject'])
                                ->attach($data['ticket_image']);
                    });
                    break;

                case "verified_email":
                    Mail::send('emails.verified_email', ['data' => $data], function ($message) use ($data) {
                        $message->to($data['email'])
                                ->subject($data['subject']);
                    });
                    break;
                case "recent_otp":
                    Mail::send('emails.recent-otp', ['data' => $data], function ($message) use ($data) {
                        $message->to($data['email'])
                                ->subject($data['subject']);
                    });
                    break;
                case "forgot_password":
                    Mail::send('emails.forgot_password', ['data' => $data], function ($message) use ($data) {
                        $message->to($data['email'])
                                ->replyTo('testing@codiant.com', 'copmerit')
                                ->subject($data['subject']);
                    });
                    break;
                case "admin_forgot_password":
                    Mail::send('emails.admin_forgot_password', ['data' => $data], function ($message) use ($data) {
                        $message->to($data['email'])
                                ->subject($data['subject']);
                    });
                    break;
                case "subadmin_mail":
                    Mail::send('emails.subadmin_credentials', ['data' => $data], function ($message) use ($data) {
                        $message->to($data['email'])
                                ->replyTo('testing@codiant.com', 'copmerit')
                                ->subject($data['subject']);
                    });
                    break;
                case "admin_change_password":
                    Mail::send('emails.subadmin_new_credential', ['data' => $data], function ($message) use ($data) {
                        $message->to($data['email'])
                                ->replyTo('testing@codiant.com', 'copmerit')
                                ->subject($data['subject']);
                    });
                    break;
                case "user_mail":
                    Mail::send('emails.user_credentials', ['data' => $data], function ($message) use ($data) {
                        $message->to($data['email'])
                                ->replyTo('testing@codiant.com', 'copmerit')
                                ->subject($data['subject']);
                    });
                    break;
                default:
                    break;
            }
            return true;
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    public static function checkProfileImage($image) {
        $src = url('public/assets/images/default-user.jpg');
        $fileName = public_path() . '/uploads/users/' . $image;
        if (filter_var($image, FILTER_VALIDATE_URL) != FALSE) {
            $src = $image;
        } elseif (!empty($image) && file_exists($fileName)) {
            $src = url('public/uploads/users/' . $image);
        }
        return $src;
    }
    
    public static function checkExecutiveImage($image) {
        $src = url('public/assets/images/default-user.jpg');
        $fileName = public_path() . '/uploads/executive/' . $image;
        if (filter_var($image, FILTER_VALIDATE_URL) != FALSE) {
            $src = $image;
        } elseif (!empty($image) && file_exists($fileName)) {
            $src = url('public/uploads/executive/' . $image);
        }
        return $src;
    }

    public static function getDocUrl($doc) {
        $src = url('public/uploads/document/default.pdf');
        $fileName = public_path() . '/uploads/documents/' . $doc;
        if (filter_var($doc, FILTER_VALIDATE_URL) != FALSE) {
            $src = $doc;
        } elseif (!empty($image) && file_exists($fileName)) {
            $src = url('public/uploads/documents/' . $doc);
        }
        return $src;
    }

    

    //notification code 

    public static function FcmPushNotification($registatoinIds, $message, $type, $user_type, $data = array()) {
        //if($user_type == 'citizen'){
        $API_ACCESS_KEY = 'AIzaSyBh5xVxUDx6VX4aP_lEbOYtgjWv2T0x2I4';
        //}
//        if($user_type == 'lawyer'){
//             $API_ACCESS_KEY = 'AIzaSyBh5xVxUDx6VX4aP_lEbOYtgjWv2T0x2I4';
//        }
//
//        if(!isset( $API_ACCESS_KEY)){
//            return false;
//        }

        $url = 'https://fcm.googleapis.com/fcm/send';
        $fields = array(
            'registration_ids' => $registatoinIds,
            'data' => $data,
        );
        $headers = array
            (
            'Authorization: key=' . $API_ACCESS_KEY,
            'Content-Type: application/json'
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
//         print_r($headers); die;
        $data = json_decode($result);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }
        if ($data->success == 1) {
            curl_close($ch);
            return true;
        } else {
            curl_close($ch);
            return false;
        }
    }

    /**
     * [APNSPushDeviceNotification <Send push notifications to IOS device>]
     * @param [type] $deviceId  [description]
     * @param [type] $certType  [description]
     * @param [type] $message   [description]
     * @param [type] $type      [description]
     * @param [type] $user_type [description]
     * @param array  $data      [description]
     */
    public static function APNSPushDeviceNotification($deviceId, $message, $type, $user_type, $data = array()) {
        $certType = 'distribution';
        try {
            $notificationCount = 0;
            $deviceToken = $deviceId;
            $passphrase = "";

            $FILE_NAME = '/copmerit.pem';


            $ctx = stream_context_create();
            if ($certType == 'development') {

                stream_context_set_option($ctx, 'ssl', 'local_cert', app_path() . $FILE_NAME);
                $fp = stream_socket_client(
                        'ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
            } elseif ($certType == 'distribution') {
                stream_context_set_option($ctx, 'ssl', 'local_cert', app_path() . $FILE_NAME);
                $fp = stream_socket_client(
                        'ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
            }

            if (!isset($FILE_NAME) || !isset($fp)) {

                return false;
            }
            if (!$fp)
                return false;

            $body = $data;
            $body['aps'] = array(
                'alert' => $message,
                'sound' => 'default',
                'badge' => (int) $notificationCount,
            );

            $payload = json_encode($body);

//                $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
            @$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
            $result = fwrite($fp, $msg, strlen($msg));

            if ($result) {
                fclose($fp);
            } else {
                fclose($fp);
                return false;
            }
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * [sendNotification < single function send and save push notifications to IOS and android device >]
     * @param  [type] $user_ids [description]
     * @param  [type] $message  [description]
     * @param  [type] $type     [description]
     * @param  array  $data     [description]
     * @return [type]           [description]
     */
    public static function sendNotification($user_ids, $custome_message, $type, $data = array()) {
        try {
            $users = User::whereIn('id', $user_ids)->with('UserDevices')->get();
            foreach ($users as $user) {
                $message = $custome_message;

                if ($custome_message == "") {
                    # Set user default language.
                    App::setLocale($user->language);
                    $message = __('messages.notification.' . $type);
                }
                if ($user->userDevices && $user->userDevices->device_type == 'ios') {
                    self::APNSPushDeviceNotification(
                            $user->userDevices->device_id, $message, $type, $user->user_type, $data
                    );
                }

                if ($user->userDevices && $user->userDevices->device_type == 'android') {
                    self::FcmPushNotification(
                            array($user->userDevices->device_id), $message, $type, $user->user_type, $data
                    );
                }

                #Save Notification..
//                    $to_id = isset($data['to_id'])?$data['to_id']:null;
                $token = \Request::header('access_token');
                $authUser = JWTAuth::toUser($token);
                $form_id = $authUser->id;
                $to_id = $user->userDevices->user_id;
//                    if($type == 'broadcast_request'){
                self::saveNotification($form_id, $message, $type, $data, $to_id);
//                    }
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * [saveNotification <TO save notification>]
     * @param  [type] $user              [description]
     * @param  [type] $message           [description]
     * @param  [type] $notification_type [description]
     * @param  array  $data              [description]
     * @return [type]                    [description]
     */
    public static function saveNotification($userId, $message, $notification_type, $data = array(), $to_id = null) {


        try {
            $in_data = array(
                'form_id' => $userId,
                'to_id' => $to_id,
                'message' => $message,
                'type' => $notification_type,
                'notification_data' => json_encode($data),
                'read_status' => 'unread',
                'status' => 'active'
            );

            Notification::create($in_data);
        } catch (Exception $e) {
            return false;
        }
    }

    public static function dateFormat($date) {
        if ($date) {
            return date('d-m-Y', strtotime($date));
        } else {
            return "";
        }
    }

    public static function converToTz($dateTime, $toTz = "", $fromTz = "UTC") {
        $toTz = (isset($_COOKIE['timezone'])) ? $_COOKIE['timezone'] : "UTC";
        $date = new \DateTime($dateTime, new \DateTimeZone($fromTz));
        $date->setTimezone(new \DateTimeZone($toTz));
        return $date;
    }

   

}
