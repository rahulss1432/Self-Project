import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "age"
})
export class AgePipe implements PipeTransform {
  age: any;
  currnetAge: number;

  transform(value: any, args?: any): any {
    let result = "";
    if (value) {
      const mdate = value.toString();
      const yearThen = parseInt(mdate.substring(0, 4), 10);
      const monthThen = parseInt(mdate.substring(5, 7), 10);
      const dayThen = parseInt(mdate.substring(8, 10), 10);
      const today = new Date();
      const birthday = new Date(yearThen, monthThen - 1, dayThen);

      const differenceInMilisecond = today.valueOf() - birthday.valueOf();

      const year_age = Math.floor(differenceInMilisecond / 31536000000);
      let day_age = Math.floor(
        (differenceInMilisecond % 31536000000) / 86400000
      );
      const month_age = Math.floor(day_age / 30);

      day_age = day_age % 30;

      result =
        year_age + " years " + month_age + " months " + day_age + " days ";
    }
    return result;
  }
}
