import { Component, OnInit, Input } from '@angular/core';
import { AuthenticationService } from '../../../auth/_services';
import { ActivatedRoute, Router } from "@angular/router";
import { ToastrService } from 'ngx-toastr';
import * as $ from "jquery";
@Component({
  selector: 'hb-header',
  templateUrl: './header.component.html',
  providers: [AuthenticationService]
})
export class HeaderComponent implements OnInit {
  @Input() header_title = 'Dashboard';
  user: any = {};

  constructor(private authenticationService: AuthenticationService, private router: Router, private toastr: ToastrService) { }

  ngOnInit() {
    this.user = this.authenticationService.getUserDetail();
    $('#navbar').click(function(){
    $('#nav-aside').toggleClass('menu-open');
    });
 
  }

  logout() {
    this.authenticationService.logout()
      .subscribe(
      (data: any) => {
        this.toastr.success(data.message);
        this.router.navigate(['/login']);
      },
      err => {
        if (err.error.error) {
          err.error.error.map((e, i) => {
            this.toastr.error(err.error.error[i].message);
          });
        }
      });
  }


}
