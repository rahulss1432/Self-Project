﻿import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../auth/_services';
import { User } from '../../../auth/_models';
import { UserService } from '../../../auth/_services';
@Component({
  selector: 'hb-sidebar',
  templateUrl: './sidebar.component.html'
})
export class SidebarComponent implements OnInit {
  userType: any = {};
  constructor(private authenticationService: AuthenticationService) {
    this.userType = '';
  }

  ngOnInit() {
    this.userType = this.authenticationService.getUserDetail();
  }

 
}
