﻿import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hb-footerbar',
  templateUrl: './footerbar.component.html'
})
export class FooterbarComponent implements OnInit {
    currentYear: number;
  constructor() { }

  ngOnInit() {
      this.currentYear = new Date().getFullYear();
  }

}
