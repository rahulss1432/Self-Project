import { CommonService } from "./common.service";
import { ApiConstantService } from "./api-constant.service";
import { AlertService, AuthenticationService, UserService } from '../../auth/_services';
import { GlobalConstantService } from "./global-constant.service";
import { Observable } from "rxjs";
import { Injectable } from "@angular/core";
import { Response, RequestMethod, ResponseContentType } from "@angular/http";

import { ApiParameterService } from "./api-parameter.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { HttpRequest } from "selenium-webdriver/http";
import { RequestOptions } from "../../shared/service/request-option";
import { SwitchView } from "@angular/common/src/directives/ng_switch";

@Injectable()
export class ApiRepositoryService {
  body: any;

  constructor(
    private http: HttpClient,
    private globalConstantService: GlobalConstantService,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private apiConstantService: ApiConstantService,
    private commonService: CommonService
  ) {}

  get(apiParameterService: ApiParameterService) {
    return this.execute(
      apiParameterService.path,
      "get",
      null,
      null,
      this.getHeaderContent(
        apiParameterService.header,
        apiParameterService.access_token,
        // apiParameterService.content_type
        false
      ),
      null,
      null
    );
  }

  post(apiParameterService: ApiParameterService) {
    return this.execute(
      apiParameterService.path,
      RequestMethod.Post,
      null,
      null,
      this.getHeaderContent(
        apiParameterService.header,
        apiParameterService.access_token,
        apiParameterService.content_type
      ),
      this.getBodyContent(
        apiParameterService.body,
        apiParameterService.isMultipartUpload
      ),
      null
    );
  }

  put(apiParameterService: ApiParameterService) {
    return this.execute(
      apiParameterService.path,
      RequestMethod.Post,
      null,
      null,
      this.getHeaderContent(
        apiParameterService.header,
        apiParameterService.access_token,
        apiParameterService.content_type
      ),
      this.getBodyContent(
        apiParameterService.body,
        apiParameterService.isMultipartUpload
      ),
      null
    );
  }

  delete(apiParameterService: ApiParameterService) {
    return this.execute(
      apiParameterService.path,
      RequestMethod.Delete,
      null,
      null,
      this.getHeaderContent(
        apiParameterService.header,
        apiParameterService.access_token,
        apiParameterService.content_type
      ),
      null,
      null
    );
  }

  /* for execution all http request with respnse */
  private execute(
    url?: string | null,
    method?: string | RequestMethod | null,
    search?:
      | string
      | URLSearchParams
      | {
          [key: string]: any | any[];
        }
      | null,
    params?:
      | string
      | URLSearchParams
      | {
          [key: string]: any | any[];
        }
      | null,
    headers?: HttpHeaders | null,
    body?: any,
    withCredentials?: boolean | null,
    responseType?: ResponseContentType | null
  ) {
    // return this.http
    //   .request(
    //     method.toString(),
    //     `${this.globalConstantService.baseUrl}${url}`.toString(),
    //     {
    //       body,
    //       headers
    //     }
    //   )
    //   .map((response: any) => {
    //     return this.getResponseContent(response);
    //   })
    //   .catch((err: Response) => {
    //     return this.getResponseContent(err);
    //   });
  }

  private getHeaderContent(
    value?: any,
    access_token?: boolean,
    content_type?: boolean
  ): any {
    let headers = this.getHeadersObject(value);
    if (access_token) {
      headers = headers.append(
        "access_token",
        this.globalConstantService.access_token
      );
    }
    if (content_type) {
      headers = headers.append(
        "Content-Type",
        this.globalConstantService.Content_Type
      );
    } else {
      headers = headers.append(
        "Content-Type",
        this.globalConstantService.Content_Type_JSON
      );
    }
    return headers;
  }

  private getResponseContent(response: any): any {
    return response;
    // if (response.status === 200) {
    //   if (response.text()) {
    //     return response;
    //   } else {
    //     return response;
    //   }
    // } else if (response.status === 400) {
    //   const errorData = this.commonService.GetHandleMultilineErrorString(
    //     response.error
    //   );
    //   this.alertService.Error(errorData);
    // } else if (response.status !== 200) {
    //   this.alertService.Error(this.apiConstantService.INVALID_REQUEST);
    //   this.authenticationService.onLogout();
    // }
  }

  private getBodyContent(value: any, isMultipartUpload?: boolean) {
    if (!isMultipartUpload) {
      const body = this.getURLSearchParamsObject(value);
      if (value) {
        return body.toString();
      }
    } else if (isMultipartUpload) {
      if (value) {
        return this.getFormDataObject(value);
      }
    }
    return null;
  }

  private getRequestOptionsContent(
    value?: any,
    access_token?: boolean,
    content_type?: boolean
  ): any {
    let headers = this.getHeadersObject(value);
    if (access_token) {
      headers = headers.append(
        "access_token",
        this.globalConstantService.access_token
      );
    }
    if (content_type) {
      headers = headers.append(
        "Content-Type",
        this.globalConstantService.Content_Type
      );
    }
    if (value) {
      return new RequestOptions({
        headers: headers
      });
    }
    return null;
  }

  private getURLSearchParamsObject(value: any): URLSearchParams {
    const urlSearchParams = new URLSearchParams();
    if (value) {
      for (const key in value) {
        if (value.hasOwnProperty(key)) {
          const element = value[key];
          urlSearchParams.set(key, value[key]);
        }
      }
    }
    return urlSearchParams;
  }

  private getHeadersObject(value?: any): HttpHeaders {
    let headers = new HttpHeaders();
    if (value) {
      for (const key in value) {
        if (value.hasOwnProperty(key)) {
          const element = value[key];
          headers = headers.set(key, value[key]);
        }
      }
    }
    return headers;
  }

  private getFormDataObject(value?: any): FormData {
    const formData = new FormData();
    if (value) {
      for (const key in value) {
        if (value.hasOwnProperty(key)) {
          const element = value[key];
          formData.set(key, value[key]);
        }
      }
    }
    return formData;
  }
}
