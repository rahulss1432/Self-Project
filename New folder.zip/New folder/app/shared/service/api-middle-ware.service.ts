import { ApiConstantService } from "./api-constant.service";
import { ApiParameterService } from "./api-parameter.service";
import { ApiRepositoryService } from "./api-repository.service";
import { Injectable, OnDestroy } from "@angular/core";
import { AuthenticationService, AlertService } from '../../auth/_services';

@Injectable()
export class ApiMiddleWareService {
  constructor(
    private apiRepository: ApiRepositoryService,
    private apiParameter: ApiParameterService,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private apiConstantService: ApiConstantService
  ) { }

  public consumeAPI(content: any): any {
    this.apiParameter.type = content.type;
    this.apiParameter.method = content.method;
    this.apiParameter.path = content.path;
    this.apiParameter.header = content.header;
    this.apiParameter.body = content.body;
    this.apiParameter.access_token = content.access_token;
    this.apiParameter.content_type = content.content_type;
    this.apiParameter.isMultipartUpload = content.isMultipartUpload;

    if (content.method === "GET") {
      return this.apiRepository.get(this.apiParameter);
    } else if (content.method === "POST") {
      return this.apiRepository.post(this.apiParameter);
    } else if (content.method === "PUT") {
      return this.apiRepository.put(this.apiParameter);
    } else if (content.method === "DELETE") {
      return this.apiRepository.delete(this.apiParameter);
    }
  }
}
