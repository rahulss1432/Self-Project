import { ApiConstantService } from "./api-constant.service";
import { Injectable } from "@angular/core";

@Injectable()
export class ApiActionService {
  constructor(private apiConstant: ApiConstantService) {}

  // Start: service for Center Details
  getCenterDetail = body => ({
    type: this.apiConstant.GET_CENTER_DETAILS,
    method: "GET",
    path: `${"center/"}${body.Id}`, // 'center/'+id
    header: null,
    body: null,
    access_token: true,
    content_type: true,
    isMultipartUpload: false
  })

  getCenterList = body => ({
    type: this.apiConstant.GET_CENTER_LIST,
    method: "GET",
    path: "center?limit=10&offset=" + (body.page - 1) * 10 + "&q=" + body.query,
    header: null,
    body: null,
    access_token: true,
    content_type: true,
    isMultipartUpload: false
  })

  updateCenterDetail = body => ({
    type: this.apiConstant.UPDATE_CENTER_DETAILS,
    method: "PUT",
    path: `${"center/"}${body.Id}`,
    header: null,
    body: body.center,
    access_token: true,
    content_type: true,
    isMultipartUpload: false
  })

  addCenterDetail = body => ({
    type: this.apiConstant.ADD_CENTER_DETAILS,
    method: "POST",
    path: `${"center"}`,
    header: null,
    body: body.center,
    access_token: true,
    content_type: true,
    isMultipartUpload: false
  })

  deleteCenterDetail = body => ({
    type: this.apiConstant.DELETE_CENTER_DETAILS,
    method: "DELETE",
    path: `${"center/"}${body.Id}`,
    header: null,
    body: null,
    access_token: true,
    content_type: true,
    isMultipartUpload: false
  })

  // End: service for Center Details
}
