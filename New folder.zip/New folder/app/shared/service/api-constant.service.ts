import { Injectable } from "@angular/core";

@Injectable()
export class ApiConstantService {
  GET_CENTER_DETAILS = "GET_CENTER_DETAILS";
  GET_CENTER_LIST = "GET_CENTER_LIST";
  ADD_CENTER_DETAILS = "ADD_CENTER_DETAILS";
  UPDATE_CENTER_DETAILS = "UPDATE_CENTER_DETAILS";
  DELETE_CENTER_DETAILS = "DELETE_CENTER_DETAILS";
  INVALID_REQUEST = "Invalid Request.Please try again after some time";

  constructor() {}
}
