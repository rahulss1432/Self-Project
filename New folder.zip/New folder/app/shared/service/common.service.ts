import { Observable } from 'rxjs';
import { AuthenticationService } from '../../auth/_services';
import { Injectable } from '@angular/core';
import { HttpHeaders, HttpParams } from '@angular/common/http';
import { Router } from '../../../../node_modules/@angular/router';

@Injectable()
export class CommonService {
  errorData = '';
  constructor(private authenticationService: AuthenticationService, private router: Router) { }

  getURLSearchParamsObject(arry: any, access_token?: boolean): URLSearchParams {
    const urlSearchParams = new URLSearchParams();
    if (access_token) {
      urlSearchParams.append(
        'access_token',
        this.authenticationService.getToken()
      );

    }
    for (const key in arry) {
      if (arry.hasOwnProperty(key)) {
        const element = arry[key];
        urlSearchParams.set(key, arry[key]);
      }
    }
    return urlSearchParams;
  }

  getHeadersObject(
    arry?: any,
    access_token?: boolean,
    content_type?: boolean
  ): HttpHeaders {
    let headers = new HttpHeaders();

    if (access_token) {
      headers = headers.append(
        'access_token',
        this.authenticationService.getToken()
      );
    }
    if (content_type) {
      headers = headers.append(
        'Content-Type',
        'application/x-www-form-urlencoded'
      );
      headers.append('Content-Type', 'application/json');
    } else {
      headers = headers.append('Content-Type', 'application/json');
    }

    for (const key in arry) {
      if (arry.hasOwnProperty(key)) {
        const element = arry[key];
        headers = headers.set(key, arry[key]);
      }
    }
    return headers;
  }

  GetHandleErrorString(error: any) {
    if (error.status === 401) {
      // window.location.href = `/login`;
      this.router.navigate(['/login']);
    }
    return Observable.throw(error);
  }

  GetHandleMultilineErrorString(error: any): string {
    this.errorData = "";
    for (const key in error.error) {
      if (error.error.hasOwnProperty(key)) {
        this.errorData = this.errorData + error.error[key].message + "";
      }

    }
    return this.errorData;
  }

  getFormDataHeader(): HttpHeaders {
    let headers = new HttpHeaders();
    headers = headers.append(
      'access_token',
      this.authenticationService.getToken()
    );
    return headers;
  }
}



export class RequestOptions {
  headers?: HttpHeaders;
  observe?: 'body';
  params?: HttpParams;
  reportProgress?: boolean;
  responseType?: 'json';
  withCredentials?: boolean;

  constructor(data: any) {
    this.headers = data.headers;
    this.params = data.params;
  }
}
