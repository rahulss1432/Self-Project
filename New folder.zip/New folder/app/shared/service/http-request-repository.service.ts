import { GlobalConstantService } from "./global-constant.service";
import { AuthenticationService, } from '../../auth/_services';
import { Observable } from "rxjs";
import { Injectable } from "@angular/core";
import {
  Http,
  Response,
  Headers,
  BaseRequestOptions,
  Request,
  RequestMethod,
  ResponseContentType
} from "@angular/http";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { RequestOptions } from "../../shared/service/request-option";

@Injectable()
export class HttpRequestRepositoryService {
  constructor(
    private http: HttpClient,
    private globalConstantService: GlobalConstantService
  ) {}

  get(
    url: string,
    header: any,
    access_token?: boolean,
    content_type?: boolean
  ) {
    return this.execute(
      url,
      RequestMethod.Get,
      null,
      null,
      this.getHeaderContent(header, access_token, content_type),
      null,
      null
    );
  }

  post(
    url: string,
    header: any,
    body: any,
    access_token?: boolean,
    content_type?: boolean
  ) {
    return this.execute(
      url,
      RequestMethod.Post,
      null,
      null,
      this.getHeaderContent(header, access_token, content_type),
      body,
      null
    );
  }

  put(
    url: string,
    header: any,
    body: any,
    access_token?: boolean,
    content_type?: boolean
  ) {
    return this.execute(
      url,
      RequestMethod.Post,
      null,
      null,
      this.getHeaderContent(header, access_token, content_type),
      body,
      null
    );
  }

  delete(
    url: string,
    header: any,
    access_token?: boolean,
    content_type?: boolean
  ) {
    return this.execute(
      url,
      RequestMethod.Delete,
      null,
      null,
      this.getHeaderContent(header, access_token, content_type),
      null,
      null
    );
  }

  private execute(
    url?: string | null,
    method?: string | RequestMethod | null,
    search?:
      | string
      | URLSearchParams
      | {
          [key: string]: any | any[];
        }
      | null,
    params?:
      | string
      | URLSearchParams
      | {
          [key: string]: any | any[];
        }
      | null,
    headers?: Headers | null,
    body?: any,
    withCredentials?: boolean | null,
    responseType?: ResponseContentType | null
  ) {
    const options = new BaseRequestOptions();
    const req = new Request(
      options.merge({
        url: `${this.globalConstantService.baseUrl}${url}`,
        method,
        search,
        params,
        headers,
        body,
        withCredentials,
        responseType: responseType ? ResponseContentType.Json : responseType
      })
    );

    // return this.http
    //   .request(
    //     method.toString(),
    //     `${this.globalConstantService.baseUrl}${url}`.toString(),
    //     {
    //       body
    //     }
    //   )
    //   .map((response: any) => this.getResponseContent(response));
  }

  private getHeaderContent(
    value?: any,
    access_token?: boolean,
    content_type?: boolean
  ): any {
    let headers = this.getHeadersObject(value);
    if (access_token) {
      headers = headers.append(
        "access_token",
        this.globalConstantService.access_token
      );
    }
    if (content_type) {
      headers = headers.append(
        "Content-Type",
        this.globalConstantService.Content_Type
      );
    }
    return headers;
  }

  private getResponseContent(response: any): any {
    const data = response; // && response.data;
    console.log(data);
    return response;
  }

  private getBodyContent(value: any) {
    const body = this.getURLSearchParamsObject(value);
    if (value) {
      return body.toString();
    }
    return null;
  }

  private getRequestOptionsContent(
    value?: any,
    access_token?: boolean,
    content_type?: boolean
  ): any {
    let headers = this.getHeadersObject(value);
    if (access_token) {
      headers = headers.append(
        "access_token",
        this.globalConstantService.access_token
      );
    }
    if (content_type) {
      headers = headers.append(
        "Content-Type",
        this.globalConstantService.Content_Type
      );
    }
    if (value) {
      return new RequestOptions({
        headers: headers
      });
    }
    return null;
  }

  private getURLSearchParamsObject(value: any): URLSearchParams {
    const urlSearchParams = new URLSearchParams();
    if (value) {
      for (const key in value) {
        if (value.hasOwnProperty(key)) {
          const element = value[key];
          urlSearchParams.set(key, value[key]);
        }
      }
    }
    return urlSearchParams;
  }

  private getHeadersObject(value?: any): HttpHeaders {
    let headers = new HttpHeaders();
    if (value) {
      for (const key in value) {
        if (value.hasOwnProperty(key)) {
          const element = value[key];
          headers = headers.set(key, value[key]);
        }
      }
    }
    return headers;
  }

  private getFormDataObject(value?: any): FormData {
    const formData = new FormData();
    if (value) {
      for (const key in value) {
        if (value.hasOwnProperty(key)) {
          const element = value[key];
          formData.set(key, value[key]);
        }
      }
    }
    return formData;
  }
}
