import { Injectable } from "@angular/core";

@Injectable()
export class ApiParameterService {
  type: any;
  method: any;
  path: string;
  header?: any;
  body?: any;
  access_token?: boolean;
  content_type?: boolean;
  isMultipartUpload: boolean;
}
