import { Injectable } from "@angular/core";

@Injectable()
export class TokenManager {
  constructor() {}

  fetchToken() {
    const userData = localStorage.getItem("currentUser");
    let token = "";
    if (userData) {
      token = JSON.parse(userData).token;
    }
    return token;
  }

  deleteToken() {
    localStorage.removeItem("currentUser");
  }

  fetchData() {
    const userData = localStorage.getItem("currentUser");
    let name: any;
    if (userData) {
      name = JSON.parse(userData).name;
      // data['photo'] = JSON.parse(userData).photo;
    }
    return name;
  }
}
