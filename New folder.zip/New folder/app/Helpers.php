<?php

use Carbon\Carbon;
use App\Models\SubCategory;
use App\Models\Category;

function sendMail($data) {
    try {
        switch ($data['request']) {
            case "admin_forgot_password":
                Mail::send('admin::emails.admin_forgot_password', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(env('FROM_EMAIL'), 'Mentor Locator')
                            ->subject($data['subject']);
                });
                break;
            case "send_otp":
                Mail::send('admin::emails.send_otp', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(env('FROM_EMAIL'), 'Mentor Locator')
                            ->subject($data['subject']);
                });
                break;
            case "reset_token":
                Mail::send('admin::emails.reset_token', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(env('FROM_EMAIL'), 'Mentor Locator')
                            ->subject($data['subject']);
                });
                break;
            default:
                break;
        }
        return true;
    } catch (Exception $e) {
        return $e->getMessage();
    }
}

/*
 * get full name
 */

function getFullName($firstName, $lastName) {
    return ucfirst($firstName) . ' ' . ucfirst($lastName);
}

/*
 * show created date format from database
  like 10/11/2017
 */

function showDateFormat($date) {
    return date('d/m/Y', strtotime($date));
}

/*
 *  for 25 Feb 2019 10:58 AM
 */

function timeFormat($string) {
    return Carbon::parse($string)->format('d M Y h:i A');
}

/*
 * for Thursday, Jan 03rd 2019
 */

function showDateTimeFormat($date) {
    return date('l M j<\s\up>S</\s\up> Y', strtotime($date));
}

/*
 * Check image url and set image path
 */

function checkUserImage($image, $folder = null) {
    $src = url('public/images/default-user.png');
    $fileName = public_path() . '/uploads/' . $folder . '/' . $image;
    if (!empty($image) && file_exists($fileName)) {
        $src = url('public/uploads/' . $folder . '/' . $image);
    }
    return $src;
}

/*
 * Check sub category counts by category 
 */

function getSubCategoryCount($categoryId) {
    $subCategoryCount = SubCategory::where('category_id', $categoryId)->count();
    return $subCategoryCount;
}

/*
 * get all category 
 */

function getAllCategories() {
    $category = Category::get();
    return $category;
}

/**
 * function using for get notifications count
 */
function getNotificationCount($userId) {
    $notificationCount = \App\Models\Notification::where('to_id', $userId)->count();
    return $notificationCount;
}

/**
 * 
 * @param type $userId
 * Get Unread Notification Count By Admin
 */
function loadNotificationCount($userId) {
    $notification = App\Models\Notification::where('to_id', $userId)->where('is_read', 0)->count();
    return $notification;
}

/**
 * 
 * @param type $userId
 * Update Unread Notification By Admin
 */
function updateNotificationList($userId) {
    $notification = \App\Models\Notification::where('to_id', $userId)->where('is_read', 0)->update(['is_read' => 1]);
    return $notification;
}

/**
 * get users by role
 */
function getUserByRole($role) {
    $users = \App\User::where('role', $role)->get();
    return $users;
}

/*
 * Check category icon url and set icon path
 */

function checkCategoryIcon($image, $folder = null) {
    $src = url('public/images/blue-logo.png');
    $fileName = public_path() . '/uploads/' . $folder . '/' . $image;
    if (!empty($image) && file_exists($fileName)) {
        $src = url('public/uploads/' . $folder . '/' . $image);
    }
    return $src;
}
