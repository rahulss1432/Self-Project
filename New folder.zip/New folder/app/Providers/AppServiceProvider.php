<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;
use DB;

class AppServiceProvider extends ServiceProvider {

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot() {
        Schema::defaultStringLength(191);

        /* validations */
        Validator::extend('valid_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->get();
            if ($user->count() > 0) {
                return true;
            } else {
                return false;
            }
        });

        Validator::extend('check_matched_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('id', '!=', Auth::user()->id)->where('email', '=', $value)->get();
            if ($user->count() > 0) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('check_email_format', function ($attribute, $value, $parameters, $validator) {
            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('check_matched_username', function ($attribute, $value, $parameters, $validator) {
            $userId = Auth::user()->id;
            $user = \DB::table('users')->where('id', '!=', $userId)->where('username', '=', $value)->get();
            if ($user->count() > 0) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('current_password', function ($attribute, $value, $parameters, $validator) {
            if (!empty(\Auth::guard(getAuthGuard())->user()->id)) {
                $password = \Auth::guard(getAuthGuard())->user()->password;
            }
            return \Illuminate\Support\Facades\Hash::check($value, $password);
        });

        /* check email type if admin */
        Validator::extend('admin_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->where('role', '=', 'admin')->get();
            if ($user->count() > 0) {
                return true;
            } else {
                return false;
            }
        });

        Validator::extend('manager_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->where('role', '=', 'manager')->get();
            if ($user->count() > 0) {
                return true;
            } else {
                return false;
            }
        });

        Validator::extend('check_email_format', function ($attribute, $value, $parameters, $validator) {
            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('phone_format', function ($attribute, $value, $parameters, $validator) {
            if ($value != "") {
                return preg_match("/^(\+\d{1,3}[- ]?)?\d{10}$/", $value);
            } else {
                return true;
            }
        });

        Validator::extend('email_status_active', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->where('status', '=', 'active')->first();
            if (!empty($user)) {
                return true;
            } else {
                return false;
            }
        });

        Validator::extend('current_user_password', function ($attribute, $value, $parameters, $validator) {
            $post = Request::all();
            $user = \DB::table('users')->where('id', $post['user_id'])->first();
            if (!empty($user)) {
                $password = $user->password;
            }
            return \Illuminate\Support\Facades\Hash::check($value, $password);
        });

        Validator::extend('without_spaces', function ($attribute, $value, $parameters, $validator) {
            return preg_match('/^\S*$/u', $value);
        });
    }

}
