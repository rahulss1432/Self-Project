<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema; //Import Schema
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class AppServiceProvider extends ServiceProvider {

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot() {
        Schema::defaultStringLength(191); //Solved by increasing StringLength

        Validator::extend('phone_format', function ($attribute, $value, $parameters, $validator) {
            return preg_match("/^(\+\d{1,3}[- ]?)?\d{10}$/", $value);
        });

        Validator::extend('check_email_format', function ($attribute, $value, $parameters, $validator) {
            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('without_spaces', function($attr, $value) {
            return preg_match('/^\S*$/u', $value);
        });

        Validator::extend('remove_spaces', function($attribute, $value, $parameters, $validator) {
            if (trim($value) == '') {
                return false;
            }
            return true;
        });
        Validator::extend('get_latlong_byzip', function($attribute, $value, $parameters, $validator) {
            $post = Request::all();
            $latLong = getLatLongByZip($value);
            if (empty($latLong)) {
                return false;
            }
            return true;
        });

        Validator::extend('greater_salary', function($attribute, $value, $parameters, $validator) {
            $post = Request::all();
            $salaryFrom = $post['salary_from'];
            $salaryTo = $post['salary_to'];
            if (!empty($salaryFrom) && !empty($salaryTo)) {
                if ($salaryTo < $salaryFrom) {
                    return false;
                }
            }
            return true;
        });

        /* check first letter doest not contain numbers only */
        Validator::extend('check_first_letter', function($attribute, $value, $parameters, $validator) {
            if (is_numeric(substr($value, 0, 1))) {
                return false;
            }
            return true;
        });

        /* check for current password is valida or not */
        Validator::extend('current_password_match', function ($attribute, $value, $parameters, $validator) {

            return Hash::check($value, Auth::guard(getAuthGuard())->user()->password);
        });
        
        /* check plan is subscribe by other users */
        Validator::extend('is_subscribed', function ($attribute, $value, $parameters, $validator) {
            $post = Request::all();
            $planSpace = getSubscriptionData($post['id'], 'plan_space');
            $planSubscribed = checkPlanSubscribedUser($post['id']);
            if (($planSubscribed > 0) && ($planSpace != $post['plan_space'])) {
                return false;
            } else {
                return true;
            }
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register() {
        //
    }

}
