<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TeamPlayer extends Model {

    protected $table = 'team_players';

    protected $fillable = [
        'user_id', 'jersey_no', 'player_name', 'position_id', 'height_ft', 'height_in', 'weight', 'school'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
   
}
