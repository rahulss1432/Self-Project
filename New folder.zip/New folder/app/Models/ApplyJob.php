<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApplyJob extends Model {

    protected $table = 'applied_jobs';
    protected $fillable = [
        'user_id', 'job_id', 'created_at'
    ];
    protected $hidden = [
        'updated_at'
    ];
    
    /*relation with job table by job id*/
    public function job() {
        return $this->belongsTo('App\Models\Job', 'job_id','id');
    }
    
    
    /*relation with job table by user id*/
    public function user() {
        return $this->belongsTo('App\User', 'user_id');
    }
}
