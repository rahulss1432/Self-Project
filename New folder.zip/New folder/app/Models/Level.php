<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Level extends Model
{
    protected $table = 'master_levels';
    
    protected $fillable = [
        'level_name'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
}
