<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class News extends Model {

    protected $table = 'news';
    protected $fillable = [
        'reference_id', 'title', 'type', 'news_description'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    protected static function boot() {
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }

    public function newsImage() {
        return $this->hasMany('App\Models\NewsImages', 'news_id');
    }

    public function user() {
        return $this->belongsTo('App\User', 'created_by');
    }

    public static function getNewsBulletin($type = NULL) {
        $latestNews = \App\Models\News::where('status', 'active')->orderBy('id', 'DESC')->first();

        if (!empty($latestNews)) {
            if (!empty($type) && $type == 'limited') {
                $newsBulletin = substr($latestNews->title, 0, 100);
            } else {
                $newsBulletin = $latestNews->title;
            }
        } else {
            $newsBulletin = 'There is no latest news';
        }
        return $newsBulletin;
    }

}
