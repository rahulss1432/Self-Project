<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Subscriptions extends Model {

    protected $table = 'subscriptions';
    protected $fillable = [
        'title', 'discription', 'amount', 'reference_id', 'status', 'created_at'
    ];
    protected $hidden = [
        'updated_at'
    ];
    
    public function subDescription(){
        return $this->hasMany('App\Models\SubscriptionDescription', 'subscription_id','id');
    }

    protected static function boot() {
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }

}
