<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $table = 'posts';
    
    protected $fillable = [
       'reference_id', 'user_id', 'title', 'post', 'type','category_id','position_id','latitude', 'status','post_type'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
     protected static function boot() {
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }
    
    
    public function user(){
        return $this->belongsTo('App\User', 'user_id');
    }
    
    public function media(){
      return $this->hasMany('App\Models\UserMedia', 'post_id');
    }
    
    public function postComments() {
        return $this->hasMany('App\Models\UserPostAction', 'post_id');
    }
    
}
