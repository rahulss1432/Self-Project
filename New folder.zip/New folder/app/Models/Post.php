<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Post extends Model {

    protected $table = 'post';
    
    protected $fillable = [
        'from_id', 'to_id', 'comment', 'appointment_id'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

}
