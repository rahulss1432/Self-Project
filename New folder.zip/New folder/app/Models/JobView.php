<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobView extends Model {

    protected $table = 'job_views';
    protected $fillable = [
        'user_id', 'job_id', 'type',
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    /*
     * Relation for user table.
     */

    public function user() {
        return $this->belongsTo('App\User', 'user_id');
    }

    /*
     * Relation for user table.
     */

    public function job() {
        return $this->belongsTo('App\Models\Job', 'job_id');
    }

}
