<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TeamStaff extends Model {

    protected $table = 'team_staffs';

    protected $fillable = [
        'user_id', 'name', 'title', 'profile_picture', 'bio'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
}
