<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Message extends Model {

    public function messageMentor() {
        return $this->belongsTo('App\User', 'from_id', 'id');
    }

    public function messageUser() {
        return $this->belongsTo('App\User', 'to_id', 'id');
    }

}
