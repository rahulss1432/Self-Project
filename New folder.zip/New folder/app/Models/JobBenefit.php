<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobBenefit extends Model {

    protected $table = 'job_benefits';

    protected $fillable = [
        'user_id', 'job_id', 'benefit_id'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at',
    ];
    
    /*
     * Relation for get job benefits.
     */
    public function benefit(){
        return $this->belongsTo('App\Models\MasterBenefits', 'benefit_id', 'id');
    }
    
}
