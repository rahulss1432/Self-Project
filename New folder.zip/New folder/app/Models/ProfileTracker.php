<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProfileTracker extends Model
{
    
    protected $table = 'profile_trackers';
    
    protected $fillable = [
        'from_id', 'to_id', 'type'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
}
