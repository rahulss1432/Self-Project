<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatMessageCron extends Model {

    protected $table = 'chat_messages_cron';
    protected $fillable = [
        'chat_id', 'reference_id', 'to_id', 'message', 'created_at'
    ];
    protected $hidden = [
        'updated_at'
    ];

    protected static function boot() {
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }

}
