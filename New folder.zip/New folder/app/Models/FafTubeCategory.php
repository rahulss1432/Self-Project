<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FafTubeCategory extends Model
{
    protected $table = 'faf_tube_categories';
    
    protected $fillable = [
        'id', 'category_name'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];   
}
