<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Incident extends Model {

    protected $table = 'incidents';
    protected $fillable = [
        'reference_id', 'from_id', 'to_id', 'entity_id', 'reported_entity', 'reported_by', 'reported_against'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    public function reporter(){
        return $this->belongsTo('App\User', 'from_id','id');
    }
    
    protected static function boot() {
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }

}
