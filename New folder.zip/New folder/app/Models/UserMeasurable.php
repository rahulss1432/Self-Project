<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserMeasurable extends Model
{

    protected $table = 'user_measurables';
    
    protected $fillable = [
        'user_id', 'certifier', 'email_link', 'height_ft', 'height_in', 'weight', 'pro_shuttle', 'collegiate_shuttle', 'bench', 'vert', 'hand_size', 'broad_jump_from', 'broad_jump_to', 'fourty'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at',
    ];

}