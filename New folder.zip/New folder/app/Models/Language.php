<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Language extends Model
{
    protected $table = 'master_languages';
    
    protected $fillable = [
     'language'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];
}
