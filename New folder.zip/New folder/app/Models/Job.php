<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Job extends Model {

    protected $table = 'jobs';
    protected $fillable = [
        'user_id', 'image', 'title', 'city', 'country', 'level_id', 'position_id', 'date', 'salary', 'expected_start_date', 'season_length', 'benefits', 'location_id', 'description', 'requirements', 'status'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    protected static function boot() {
        parent::boot();
        static::creating(function ($query) {
            $query->reference_id = rand(5, 999999);
        });
    }

    /*
     * Relation for get job country.
     */

    public function country() {
        return $this->belongsTo('App\Models\Country', 'country_id', 'country_id');
    }

    public function state() {
        return $this->belongsTo('App\Models\State', 'state_id', 'state_id');
    }
    
    public function jobQuestionnaire() {
        return $this->belongsTo('App\Models\jobQuestionnaire', 'questionnaire_id', 'id');
    }

    /*
     * Relation for get job benefits.
     */

    public function jobBenefits() {
        return $this->hasMany('App\Models\JobBenefit', 'job_id', 'id');
    }

    /*
     * Relation for level table.
     */

    public function level() {
        return $this->belongsTo('App\Models\MasterLevel', 'level_id');
    }

    public function jobQuestions() {
        return $this->hasMany('App\Models\JobQuestion', 'job_id', 'id');
    }

    /*
     * Relation for user table.
     */

    public function user() {
        return $this->belongsTo('App\User', 'user_id');
    }

}
