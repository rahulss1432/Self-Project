<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model {

    protected $table = 'notifications';
    protected $fillable = [
        'from_id', 'to_id', 'message', 'is_read', 'menu_id', 'url'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    public function user() {
        return $this->belongsTo('App\User', 'to_id');
    }

}
