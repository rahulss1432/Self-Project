<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Rating extends Model {

    protected $table = 'rating';
    
    protected $fillable = [
        'from_id', 'to_id', 'rating', 'reviews','appointment_id'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

}
