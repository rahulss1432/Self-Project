<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PostImage extends Model {

    protected $table = 'post_image';
    
    protected $fillable = [
        'from_id', 'to_id', 'comment', 'appointment_id'
    ];
    protected $hidden = [
        'created_at', 'updated_at'
    ];

}
