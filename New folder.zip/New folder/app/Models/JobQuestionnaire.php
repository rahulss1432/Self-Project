<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobQuestionnaire extends Model
{
    protected $table = 'job_questionnaire';
    
    protected $fillable = [
        
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
    /*
     * Relation for get answer.
     */
  
     public function jobQuestion() {
        return $this->hasMany('App\Models\JobQuestion', 'questionnaire_id', 'id');
    }

}
