<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MediaComments extends Model
{
    protected $table = 'media_comments';
    protected $fillable = [
        'media_id', 'from_id', 'to_id', 'comment', 'type'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
    public function media(){
        return $this->belongsTo('App\Models\UserMedia', 'post_id');
    }
    
    public function fromUser(){
        return $this->belongsTo('App\User', 'from_id');
    }
    
    public function toUser(){
        return $this->belongsTo('App\User', 'to_id');
    }
}
