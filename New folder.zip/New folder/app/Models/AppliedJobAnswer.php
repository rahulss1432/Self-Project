<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppliedJobAnswer extends Model {

    protected $table = 'applied_job_answer';
    protected $fillable = [
        'user_id', 'job_id','answer','question_id'
    ];
    protected $hidden = [
        'updated_at', 'created_at'
    ];

}
