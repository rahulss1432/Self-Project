<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ValidateAttributes extends Model
{
    protected $table = 'validate_attributes';
    
    protected $fillable = [
        'title', 'image'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
    
    public function validateAttribute(){
        return $this->hasmany('App\Models\UserValidateAttributes', 'attribute_id');
    }
    
    public function coachValidateAttribute(){
        return $this->hasmany('App\Models\CoachValidateAttribute', 'attribute_id');
    }
}
