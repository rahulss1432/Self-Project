<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    protected $table = 'countries';
    
    protected $fillable = [
        'short_name', 'name', 'phonecode'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at'
    ];
}
