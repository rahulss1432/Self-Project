<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Connection extends Model {

    protected $table = 'connections';
    
    protected $fillable = [
        'from_id', 'to_id', 'type'
    ];
    
    protected $hidden = [
        'created_at', 'updated_at',
    ];
    
    public function fromUser(){
        return $this->belongsTo('App\User', 'from_id');
    }
    
    public function toUser(){
        return $this->belongsTo('App\User', 'to_id');
    }

}
