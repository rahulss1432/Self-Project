export class User {
    id: number;
    username: string;
    email:string;
    password: string;
    user_type:string;
    confirmpassword:string;
    
}