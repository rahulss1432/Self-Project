import { AuthenticationService } from '../_services';
import { ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResetComponent } from './reset.component';
import { resetRouting } from './reset.route';
import { SharedModule } from '../../shared/module/shared.module';

@NgModule({
  imports: [
    CommonModule,
    resetRouting,
    ReactiveFormsModule,
    SharedModule
  ],
  declarations: [ResetComponent]
})
export class ResetModule { }
