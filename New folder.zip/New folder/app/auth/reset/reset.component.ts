﻿import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { AuthenticationService } from '../_services';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs/Rx';

@Component({
  selector: 'hb-reset',
  templateUrl: './reset.component.html',
  providers: [AuthenticationService]
})
export class ResetComponent implements OnInit, OnDestroy {
  @ViewChild('main') mainContent;
  @ViewChild('loginSection') loginSection;
  token: string;
  bodyClass = 'login-page';
  body = document.getElementsByTagName('body')[0];
  resetFormGroup: FormGroup;
  loading = false;
  private subscription: Subscription;

  constructor(private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    private toastr: ToastrService,
    fb: FormBuilder) {

    this.token = this.activatedRoute.snapshot.params['token'];
    if (!this.token) {
      this.subscription = activatedRoute.queryParams.subscribe(
        (param: any) => this.token = param['token']
      );
    }
    this.resetFormGroup = fb.group({
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    }, {
        validator: this.MatchPassword
      })
  }

  ngOnInit() {
    this.body.classList.add(this.bodyClass);
    this.setAuthPageHeight();
  }

  ngOnDestroy() {
    this.body.classList.remove(this.bodyClass);
    this.subscription.unsubscribe();
  }

  onSubmit() {

    this.loading = true;
    this.authenticationService.resetPassword(this.token, this.resetFormGroup.controls['password'].value)
      .subscribe(result => {
        if (result.success === true) {
          this.toastr.success(result.message);
        } else {
          this.toastr.error(result.message);
        }
        this.loading = false;
      },
      (err) => {
        this.toastr.error(err);
        this.loading = false;
      })
  }


  MatchPassword(AC: AbstractControl) {
    let password = AC.get('password').value; // to get value in input tag
    let confirmPassword = AC.get('confirmPassword').value; // to get value in input tag
    if (password != confirmPassword) {
      console.log('false');
      AC.get('confirmPassword').setErrors({ MatchPassword: true })
    } else {
      console.log('true');
      return null
    }
  }

  setAuthPageHeight() {
    let window_height = window.innerHeight;
    const loginCmp = this.loginSection.nativeElement;
    const mainCmp = this.mainContent.nativeElement;
    mainCmp.style.minHeight = window_height + 'px';
    if (screen.width > 1200) {
      loginCmp.style.minHeight = window_height - 80 + 'px';
      loginCmp.style.marginTop = '40px';
    } else if (screen.width > 992) {
      loginCmp.style.minHeight = window_height - 80 + 'px';
      loginCmp.style.marginTop = '40px';
    } else if (screen.width > 767) {
      loginCmp.style.minHeight = window_height - 260 + 'px';
      loginCmp.style.marginTop = '130px';
    } else {
      setTimeout(function () {
        var sectionHeight = loginCmp.height();
        loginCmp.style.marginTop = Math.max(0, (window_height - sectionHeight) / 2) + 'px';
      }, 500);
    }
  }
  // compare validator
}
