<?php

namespace App\Http\Middleware;

use Illuminate\Support\Facades\Auth;
use Closure;
use Illuminate\Support\Facades\Session;

class Common {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null) {
//        $guard=$request->session()->get('current-guard');
        $guard = getAuthGuard();

        if (Auth::guard($guard)->check()) {
            if (Auth::guard($guard)->user()->status == 'inactive') {
                    Auth::guard($guard)->logout();
                    $request->session()->invalidate();
                    return redirect('/');
             }

            if ($guard != 'admin' && $guard != 'subadmin' && $guard != 'web') {
                $response = $next($request);
                return $response->header('Cache-Control', 'nocache, no-store, max-age=0, must-revalidate')
                            ->header('Pragma', 'no-cache')
                            ->header('Expires', '0');
            }
        }
      Session::put('url.intended', url()->current());
      return redirect('/');
    }

}
