<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Api\MentorRepository;
use App\Http\Requests\Api\AddAvailabilty;


class MentorController extends Controller {

      public function __construct(MentorRepository $mentor) {
        $this->mentor = $mentor;
    }
    
    /**
     * add availability.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function addAvailability(AddAvailabilty $request)
    { 
        return $this->mentor->addAvailability($request);
    }
    /**
     * edit availability.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function editAvailability(Request $request)
    {
        return $this->mentor->editAvailability($request);
    }
    /**
     * edit availability.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getAvailability(Request $request)
    {
        return $this->mentor->getAvailability($request);
    }
    /**
     * edit availability.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function deleteAvailability(Request $request)
    {
        return $this->mentor->deleteAvailability($request);
    }
 

}
