<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\LoginRequest;
use JWTAuth;
use JWTAuthException;
use App\UserDevice;
use App\Http\Requests\Api\LogoutRequest;
use Illuminate\Support\Facades\Response;

class AccountController extends Controller {

    public function login(LoginRequest $request) {
        $creendialData = [];
        $creendialData['email'] = $request->email;
        $creendialData['password'] = $request->password;

        $token = null;
        try {
            if (!$token = JWTAuth::attempt($creendialData)) {
                return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Invalid Username or Password entered, please try again']]);
            }
        } catch (JWTAuthException $e) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Failed to create token']]);
        }
        $user = JWTAuth::toUser($token);

        if (!empty($user['verification_code'])) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Your account  is not verified']]);
        }
        
//        if ($user['status'] == 'inactive') {
//            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'Your account  is not active']]);
//        }
        
        $post = $request->all();
        $post['access_token'] = $token;
        if (!empty($user)) {
            $result = UserDevice::addUserDevice($post);
        }
        $user['access_token'] = $token;
        if (!empty($user)) {
            $user->profile_image = checkUserImage($user->profile_image);
            return response()->json(['success' => true, 'data' => $user]);
        }
    }

    public function logout(Request $request) {
       
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            $DeviceId = UserDevice::where('user_id', $user->id)->delete();
            $user->save();
            try {
                JWTAuth::invalidate($token);
            } catch (\Exception $e) {
                $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
                return $json;
            }
            $json = ['success' => true, 'message' => 'You are Logged out.',];
            return $json;
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

}
