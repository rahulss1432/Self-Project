<?php
namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use App\Http\Requests\Api\RequestCallRequest;
use JWTAuth;
use App\Http\Models\Ticket;

class RequestCallController extends Controller {

    public function requestCallByCategory(RequestCallRequest $request) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            if (!empty($user)) {
                $ticket = new Ticket();
                $ticket->ticket_number = generateRandomString(8);
                $ticket->category_id = $request->category_id;
                $ticket->customer_id = $user->id;
                $ticket->note = $request->note;
                $ticket->status = 'pending';
                $ticket->created_at = date('Y-m-d H:i:s');
                $ticket->updated_at = date('Y-m-d H:i:s');
                $ticket->save();
                return response()->json(['success' => true, 'message' => 'Your Request hasbeen submitted to admin.']);
            }
            return response()->json(['success' => false,'error' => ['message' => 'user not Found ']]);
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

}
