<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Api\CommonRepository;

class CommonController extends Controller {

    public function __construct(CommonRepository $common) {
        $this->common = $common;
    }
    
    /**
     * Get user detail by token.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getCountry(Request $request)
    {   return $this->common->getCountry($request);
    }
    /**
     * Get user detail by token.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getState(Request $request)
    {
        return $this->common->getState($request);
    }
    /**
     * Get user detail by token.
     * @param type $request(OBJ)
     * @return type Json
     */
    public function getCity(Request $request)
    {
        echo "city";die;
        return $this->user->getUser($request);
    }

}
