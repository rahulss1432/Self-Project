<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Lcobucci\JWT\Parser;
use JWTAuth;
use JWTAuthException;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\Auth\Guard;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller {

    public function login(Request $request) {
        $credentials = $request->only('email', 'password');
        $token = null;
        try {
            if (!$token = JWTAuth::attempt($credentials)) {
                return response()->json(['success' => false, 'error' => ['message' => 'invalid email or password']]);
            }
        } catch (JWTAuthException $e) {
            return response()->json(['success' => false, 'error' => ['message' => 'failed_to_create_token']]);
        }
        $user = JWTAuth::toUser($token);
        $user->access_token = $token;
        return response()->json(['success' => true, 'message' => 'Logged in Successfully','userData' => $user]);
    }

    public function logout(Request $request) {
        try {
            $token = \Request::header('access-token');
            try {
                JWTAuth::invalidate($token);
            } catch (\Exception $e) {
                $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
                return $json;
            }
            $json = ['success' => true, 'message' => 'You are Logged out.',];
            return $json;
        } catch (\Exception $e) {
            $json = ['success' => false, 'error' => ['message' => $e->getMessage()]];
            return $json;
        }
    }

}
