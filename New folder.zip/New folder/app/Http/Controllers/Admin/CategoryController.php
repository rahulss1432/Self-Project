<?php

namespace App\Http\Controllers\Admin;

use App\Http\Models\BankingCategory;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Requests\Admin\AddCategoryRequest;

class CategoryController extends Controller {

    public function categoryList(Request $request) {
        return view('admin.category.index');
    }

    public function listAllCategories(Request $request) {
        try {
            $category = BankingCategory::getCategoryList($request);
            $html = View::make('admin.category._list_category', ['category' => $category])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function addCategoryForm() {
        return view('admin.category.category-add');
    }

    public function addCategory(AddCategoryRequest $request) {
        return BankingCategory::saveCategory($request);
    }

    public function categoryEdit($id) {
        $editCategory = BankingCategory::where('id', $id)->first();
        if (!empty($editCategory)) {
            return view('admin.category.category-edit', ['editCategory' => $editCategory]);
        }
        abort(404);
    }

    public function categoryUpdate(AddCategoryRequest $request) {
        return BankingCategory::updateCategory($request);
    }

    public function categoryDelete($id) {
        return BankingCategory::deleteCategory($id);
    }

    public static function activeInactiveCategory($id) {
        $model = BankingCategory::activeInactiveCategory($id);
        if ($model) {
            return Response::json(['success' => true, 'message' => \Config::get('constants.category_status')]);
        } else {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
