<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class NotificationController extends Controller {

    public function notifications(Request $request) {
        return view('admin.notifications.index');
    }

    public function listNotificationList(Request $request) {
        try {
            $html = View::make('admin.notifications._notifications-list')->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
