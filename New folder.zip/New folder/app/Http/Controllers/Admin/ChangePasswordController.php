<?php

namespace App\Http\Controllers\Admin;

use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\ChangePasswordRequest;
use App\Http\Requests\Admin\EditProfileRequest;
use Illuminate\Support\Facades\Response;

class ChangePasswordController extends Controller {

    public function changePassword() {
        return view('admin.change-password.change-password');
    }

    public function updatePassword(ChangePasswordRequest $request) {
        return User::updatePassword($request->all());
    }

    public function viewProfile() {
        $adminData = User::where('id', Auth()->guard('admin')->user()->id)->first();
        return view('admin.change-password.view-profile', ['adminData' => $adminData]);
    }

    public function editProfile() {
        return view('admin.change-password.edit-profile');
    }

    public function updateProfile(EditProfileRequest $request) {
        return User::updateProfile($request->all());
    }

}
