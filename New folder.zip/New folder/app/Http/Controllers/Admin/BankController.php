<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Models\Bank;

class BankController extends Controller {

    public function bankList(Request $request) {
        return view('admin.bank.index');
    }

    public function listAllBanks(Request $request) {
        try {
            $banks = Bank::getAllBankList($request);
            $html = View::make('admin.bank._list_bank', ['banks' => $banks])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function bankDelete($id) {
        return Bank::bankDelete($id);
    }

    public function bankEdit($id) {
        $editBank = Bank::where('id', $id)->first();
        if (!empty($editBank)) {
            return view('admin.bank.bank-edit', ['editBank' => $editBank]);
        }
        abort(404);
    }

    public function bankUpdate(Request $request) {
        return Bank::updateBank($request);
    }

    public static function activeInactiveBank($id) {
        $model = Bank::activeInactiveBank($id);
        if ($model) {
            return Response::json(['success' => true, 'message' => \Config::get('constants.category_status')]);
        } else {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
