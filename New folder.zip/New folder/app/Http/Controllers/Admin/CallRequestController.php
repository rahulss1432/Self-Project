<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Models\CallRequest;
use Excel;

class CallRequestController extends Controller {

    public function callRequestList(Request $request) {
        return view('admin.call-request.index');
    }

    public function listAllCallRequest(Request $request) {
        try {
            $callRequest = CallRequest::getCallRequestList($request, 'admin');
            $html = View::make('admin.call-request._call_request_list', ['callRequest' => $callRequest])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function callRequestView($id) {
        $callRequest = CallRequest::getCallRequestsById($id);
        return view('admin.call-request.call-request-view', ['callRequest' => $callRequest]);
    }

    public function downloadCallRequestCsv() {
        $post = [];
        $callRequest = CallRequest::getCallRequestList($post, 'admin');
        $excelDownload = Excel::create('call_request_records', function($excel) use ($callRequest) {
                    $excel->sheet('Sheet1', function($sheet) use($callRequest) {
                        $arr = array();
                        foreach ($callRequest as $callData) {
                            $data = array(
                                $callData->UserProfile->product,
                                $callData->UserProfile->merchant_number,
                                date('d-m-Y', strtotime($callData->created_at)),
                                $callData->status,
                                $callData->executiveDetail->contact_name,
                                $callData->BankCategory->name,
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Business Name', 'Merchant Number', 'Date of Call', 'Status of Call', 'SE Assigned', 'Category')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export call request');
            return redirect()->back();
        }
    }

}
