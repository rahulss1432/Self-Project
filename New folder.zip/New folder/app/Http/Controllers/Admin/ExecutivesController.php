<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Http\Models\User;
use View;
use App\Http\Requests\Admin\AddExecutiveRequest;
use App\Http\Requests\Admin\EditExecutiveRequest;
use Excel;
use App\Http\Models\CallRequest;
use \App\Http\Models\CustomerExecutiveRelation;

class ExecutivesController extends Controller {

    /**
     * manage executives index
     * @return view
     * */
    public function index() {
        return view('admin.executives.index');
    }

    /**
     * all executives list
     * @return view
     * */
    public function allExecutives(Request $request) {
        try {
            $executives = User::getAllExecutives($request->all());
            $html = View::make('admin.executives._executives_list', ['executives' => $executives])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     *  add new executive
     * @return \Illuminate\Http\Response
     * */
    public function addExecutive() {
        return view('admin.executives.add_executive');
    }

    /**
     *  save executive
     * @return \Illuminate\Http\Response
     * */
    public function saveExecutive(AddExecutiveRequest $request) {
        return User::saveExecutive($request->all());
    }

    /**
     *  edit executive form
     * @return view
     * */
    public function editExecutive($id) {
        $user = User::getUserById($id);
        if (!empty($user)) {
            return view('admin.executives.edit_executive', ['user' => $user]);
        }
        abort(404);
    }

    /**
     *  update executive
     * @return \Illuminate\Http\Response
     * */
    public function updateExecutive(EditExecutiveRequest $request) {
        return User::updateExecutive($request->all());
    }

    /**
     *  view executive
     * @return view
     * */
    public function viewExecutive($id) {
        $user = User::getUserById($id);
        if (!empty($user)) {
            return view('admin.executives.view_executive', ['user' => $user]);
        }
        abort(404);
    }

    /**
     * all assigned merchants by executive id
     * @return view
     * */
    public function assignedMerchantList($id) {
        try {
            $seMerchant = CustomerExecutiveRelation::getCustomerByExecutiveId($id);
            $html = View::make('admin.executives._assigned_merchants', ['seMerchant' => $seMerchant])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function seRequest() {
        return view('admin.executives.support-executive-request');
    }

    public function listSeRequest(Request $request) {
        try {
            $executives = User::getAllExecutivesByRequest($request->all());
            $html = View::make('admin.executives._support-executive-request-list', ['executives' => $executives])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function seRequestView($id) {
        return view('admin.executives.support-executive-request-view', ['id' => $id]);
    }

    public function seRequestViewList(Request $request) {
        try {
            $id = $request['id'];
            $executives = CallRequest::where('executive_id', '=', $id)->get();
            $html = View::make('admin.executives._executive-request-list-view', ['executives' => $executives])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function seRequestNoteView($id) {
        $requestNotes = CallRequest::where('id', '=', $id)->first();
        return view('admin.executives.support-executive-request-note-view', ['requestNotes' => $requestNotes]);
    }

    public function downloadExecutiveCsv() {
        $post = [];
        $executives = User::getAllExecutives($post);
        $excelDownload = Excel::create('executive_records', function($excel) use ($executives) {
                    $excel->sheet('Sheet1', function($sheet) use($executives) {
                        $arr = array();
                        foreach ($executives as $userData) {
                            $data = array(
                                $userData->executive_number,
                                ucfirst($userData->contact_name),
                                !empty($userData->bankCategory->name) ? $userData->bankCategory->name : '-',
                                $userData->phone_number,
                                !empty($userData->bank->name) ? $userData->bank->name : '-',
                                "10",
                                $userData->city . ',' . $userData->state
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'ID', 'Name', 'Category', 'Phone Number', 'Company', 'Merchant', 'City/State')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export executive');
            return redirect()->back();
        }
    }

    public function downloadExecutiveRequestCsv() {
        $post = [];
        $executives = User::getAllExecutivesByRequest($post);
        $excelDownload = Excel::create('executive_reqeust_records', function($excel) use ($executives) {
                    $excel->sheet('Sheet1', function($sheet) use($executives) {
                        $arr = array();
                        foreach ($executives as $userData) {
                            $managerName = \App\Http\Models\User::getUserById($userData->manager_id);
                            $waitingTime = \App\Http\Models\Bank::getBankByDucument($userData->bank_id);
                            $data = array(
                                ucfirst($userData->contact_name),
                                $managerName->first_name . ' ' . $managerName->last_name,
                                !empty($waitingTime->waiting_time) ? $waitingTime->waiting_time . ' min' : '0' . ' min',
                                \App\Http\Models\CallRequest::getCallRequestByPending($userData->id),
                                \App\Http\Models\CallRequest::getCallRequestByResolve($userData->id)
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Name', 'Manager Name', 'Average Waiting time', 'Pending request', 'Completed Request')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export executive request');
            return redirect()->back();
        }
    }

}
