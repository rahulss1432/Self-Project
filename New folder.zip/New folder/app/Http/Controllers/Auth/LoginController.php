<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\LoginRequest;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Login Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles authenticating users for the application and
      | redirecting them to your home screen. The controller uses a trait
      | to conveniently provide its functionality to your applications.
      |
     */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/player';
    protected $guard = 'player';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest')->except('logout');
    }

    public function login(LoginRequest $request) {
        $data = array();
        $intended_url = ($request->intended_url)?$request->intended_url:'';
        $data['status'] = 'active';
        $data['email'] = $request->email;
        $data['password'] = $request->password;
        $user = \App\User::where(['email' => $data['email']])->where('role', '!=', 'admin')->where('role', '!=', 'subadmin')->first();
        if (!empty($user)) {
            if ($user->status == 'active') {
                if (Auth::guard($user->role)->attempt($data, $request->remember)) {
                    $user->availability = 'online';
                    $user->save();
                    $request->session()->regenerate();
                    $request->session()->put('current-guard', $user->role);
                    $this->clearLoginAttempts($request);
                    $subscription_amount=(getSubscriptionData($user->subscription_id,'amount'))?getSubscriptionData($user->subscription_id,'amount'):0;
                    return response()->json(['success' => true, 'message' => ucfirst($user->role).' login successfully.','today'=>Carbon::today(), 'userData' => $user,'amount'=>$subscription_amount,'next_url'=>$intended_url]);
                }
            } else {
            return response()->json(['success' => false, 'message' => 'Your account has been deacivated by administrator.']);
            }
        }
        return response()->json(['success' => false, 'message' => 'These credentials do not match our records.']);
    }

    /**
     * Send the response after the user was authenticated.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    protected function sendLoginResponse(Request $request, $role) {
        $request->session()->regenerate();
        $request->session()->put('current-guard', $role);
        $this->clearLoginAttempts($request);
        return $this->authenticated($request)
                ? : redirect()->intended($this->redirectPath());
    }

    protected function authenticated(Request $request) {
        $role = $request->session()->get('current-guard');
        if ($role == 'player') {
            return redirect('player');
        }
         if ($role == 'coach') {
            return redirect('coach');
        }
         if ($role == 'team') {
            return redirect('team');
        }
    }

    /**
     * Get the failed login response instance.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    protected function sendFailedLoginResponse(Request $request) {
        $errors = [$this->username() => trans('auth.failed')];
        if ($request->expectsJson()) {
            return response()->json($errors, 422);
        }
        return redirect()->back()->with('error_msg', 'These credentials do not match our records.');
    }

    /**
     * Get the login username to be used by the controller.
     *
     * @return string
     */
    public function username() {
        return 'email';
    }

    /**
     * Log the user out of the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function logout(Request $request) {
        $role = $request->session()->get('current-guard');
        Auth::guard($role)->logout();
        $request->session()->invalidate();
        return redirect('/');
    }

    protected function guard1() {
        return \Auth::guard('player');
    }

}