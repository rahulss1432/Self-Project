<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ResetsPasswords;
use App\Http\Requests\ResetPasswordValidation;

class ResetPasswordController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Password Reset Controller
      |--------------------------------------------------------------------------
      |
      | This controller is responsible for handling password reset requests
      | and uses a simple trait to include this behavior. You're free to
      | explore this trait and override any methods you wish to tweak.
      |
     */

use ResetsPasswords;

    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest');
    }

    public function ResetPassword($token) {
        if (!empty($token)) {
            $user = \App\User::where(['remember_token' => $token])->where(function ($query) {
                        $query->where('role', 'player')
                                ->orWhere('role', 'coach')
                                ->orWhere('role', 'team');
                    })->first();
            if (!empty($user)) {
                return view('home', ['resetToken' => $user->remember_token, 'next_url' => '']);
            } else {
                if (!empty($token)) {
                    return redirect('/')->with('error_msg', 'Token has been expired.');
                }
                return redirect('/');
            }
        } else {
            return redirect('/');
        }
    }

    public function updatePassword(ResetPasswordValidation $request) {
        $post = $request->all();
        $model = \App\User::where(['remember_token' => $post['reset-token']])->where(function ($query) {
                    $query->where('role', 'player')
                            ->orWhere('role', 'coach')
                            ->orWhere('role', 'team');
                })->first();
        if (!empty($model)) {
            $model->password = bcrypt($post['password']);
            $model->remember_token = '';
            $model->save();
            \App\User::where(['remember_token' => $post['reset-token']])->update(['remember_token' => '']);
            return response()->json(['success' => true, 'message' => 'Password updated successfully!']);
        } else {
            return response()->json(['success' => false, 'message' => 'Please try again']);
        }
    }

}
