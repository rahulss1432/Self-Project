<?php

namespace App\Http\Controllers\Auth;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Http\Requests\SignupRequest;
use App\Repositories\UserRepository;

class SignupController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(UserRepository $user)
    {
        $this->user = $user;
    }

    /**
     * Method for create signup With Ach.
     *
     * @param  array  $data
     * @return \App\User
     */
    public function signUp(SignupRequest $request)
    {
        $request['full_name'] = $request['first_name'].' '.$request['last_name'];
        $request['trial_days'] = getSetting('days');
        return $this->user->signup($request);
    }
    
  
}
