<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;

class NotificationController extends Controller {

    /**
     * executive dashboard
     * @return view
     * */
    public function index() {
        return view('executive.notifications.index');
    }

    public function notificationList() {
        try {
            $html = View::make('executive.notifications._notifications')->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
