<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use App\Http\Models\CallRequest;
use App\Http\Models\Document;
use Illuminate\Support\Facades\Auth;

class LinkedNotesController extends Controller {

    /**
     * executive dashboard
     * @return view
     * */
    public function index($id) {
        $request = CallRequest::getCallRequestsById($id);
        return view('executive.linked-notes.index', ['request' => $request]);
    }

    /**
     * executive's bank document listing
     * @return \Illuminate\Http\Response
     * */
    public function executiveDocumentsList(Request $request) {
        try {
            $documents = Document::getDocList($request->all());
            $html = View::make('executive.linked-notes._document_list', ['documents' => $documents])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * executive's linked merhcant notes history listing
     * @return \Illuminate\Http\Response
     * */
    public function linkedMerchantNotesHistoryList($merchantId) {
        try {
            $executiveId = Auth::guard('web')->user()->id;
            $notesHistory = CallRequest::getMerchantLinkedNotesHistoryByExecutive($executiveId, $merchantId);
            $html = View::make('executive.linked-notes._linked_notes_history', ['notesHistory' => $notesHistory])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * executive's linked merhcant notes history modal
     * @return \Illuminate\Http\Response
     * */
    public function loadAddNoteModal($requestId) {
        try {
            $seRequest = CallRequest::getCallRequestsById($requestId);
            $html = View::make('executive.linked-notes._add_note_modal', ['seRequest' => $seRequest])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
