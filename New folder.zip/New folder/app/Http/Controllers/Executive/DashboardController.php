<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Models\User;
use View;
class DashboardController extends Controller {
    /**
     * view user profile
     * @return view
     * */
    public function viewUserProfile() {
        try {
            $user = \App\Http\Models\User::getUserById(Auth::guard()->user()->id);
            $html = View::make('executive._user_profile', ['user' => $user])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
