<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use App\Repositories\PostRepository;
use App\Http\Requests\PostRequest;
use App\Models\Posts;
use Illuminate\Support\Facades\Response;

class PostController extends Controller
{
    public function __construct(PostRepository $post){
        $this->post = $post;
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
        $posts = $this->post->getAllPost();
        return View::make('post.index')->with('posts', $posts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create(){
        return View::make('post.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store(PostRequest $request){
        return $this->post->savePost($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id){
        $post = $this->post->getSinglePost($id);
        return View::make('post.show')->with('post', $post);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id){
        $post = $this->post->getSinglePost($id);
        return View::make('post.edit')->with('post', $post);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(PostRequest $request){
        return $this->post->updatePost($request);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy(Request $request){
        return $this->post->deletePost($request);
    }
    
    
    /**
     * @param type $id
     * @return type
     * get post details
     */
    
    function postDetails($id){
       $getPost = $this->post->getPostById(base64_decode($id)); 
       return view('post-detail',['getPost' => $getPost]); 
    }

    
     /*
     * Function for get post comment.
     */
    public function getPostComments(Request $request) {
        try {
            $comments =  $this->post->getPostEvents($request->post_id, 'comment');
            $html = View::make('ajax-content._comments-list', ['comments' => $comments])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
}
