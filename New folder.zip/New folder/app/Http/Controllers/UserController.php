<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use App\Repositories\UserRepository;
use App\User;
use App\Http\Requests\AchRequest;
use App\Http\Requests\AchAmountVerifyRequest;
use App\Http\Requests\CardRequest;
use App\Repositories\StripeRepository;
use App\Repositories\ReportRepository;
use Illuminate\Support\Facades\Response;
use App\Repositories\Player\EventRepository;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller {

    public function __construct(UserRepository $user, EventRepository $event, StripeRepository $stripe, ReportRepository $report) {
        $this->user = $user;
        $this->event = $event;
        $this->stripe = $stripe;
        $this->report = $report;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $users = $this->user->getAllUser();
        return View::make('user.index')->with('users', $users);
    }

    /**
     * Payment Process page
     */
    public function paymentProcess($text) {
        return View::make('_payment_process')->with('text', $text);
    }

    /* Ach payment by stripe */

    public function AchPayment(AchRequest $request) {
        return $this->user->confrimAchPayment($request);
    }

    /* Ach verify amount by stripe */

    public function AchVerifyAmount(AchAmountVerifyRequest $request) {
        return $this->user->verifyAmount($request);
    }

    /* Ach payment  by stripe */

    public function payWithAch(Request $request) {
        return $this->user->payWithAch($request);
    }

    public function stripeAuthentication(CardRequest $request) {
        return $this->stripe->stripeAuthentication($request);
    }

    public function stripePayment(Request $request) {
        return $this->stripe->paymentWithStripe($request);
    }

    /**
     * function using for other player view
     * @param type $id
     * @return type
     */
    public function ProfileView($slug, $share = null) {
        $procardShare = '';
        $id = getUserIdBySlug($slug);
        if ($id == 0 && $id == '') {
            $id = base64_decode($slug);
        }
         $userId = (Auth::guard(getAuthGuard())->check())?Auth::guard(getAuthGuard())->user()->id:0;
        if($userId == $id){
            return redirect(getAuthGuard().'/'.getAuthGuard().'-profile');
        }
        $this->user->saveProfileViewer($id);
        $user = $this->user->getUserProfileById($id);
        $user_repository = $this->user;
        $upcoming_events = $this->event->getLatestThreeEvents();
        if (!empty($share)) {
            $procardShare = 'yes';
        }
        $latestNews = $this->user->getLatestNews();
        if ($user->role == 'player') {
            return view('player-profile', ['user' => $user, 'procardShare' => $procardShare, 'user_repo' => $user_repository, 'upcoming_events' => $upcoming_events, 'latestNews' => $latestNews]);
        } else if ($user->role == 'coach') {
            return view('coach-profile', ['user' => $user, 'procardShare' => $procardShare, 'user_repo' => $user_repository, 'upcoming_events' => $upcoming_events, 'latestNews' => $latestNews]);
        } else if ($user->role == 'team') {
            $profile_likes = $this->user->getThreeProfileLike();
            return view('team-profile', ['user' => $user, 'procardShare' => $procardShare, 'user_repo' => $user_repository, 'upcoming_events' => $upcoming_events, 'profile_likes' => $profile_likes, 'latestNews' => $latestNews]);
        }
    }

    /**
     * function using for like profile
     * @param Request $request
     * @return type
     */
    public function likeProfile(Request $request) {
        $fromId = $this->user->getUseDetails($id = null);
        $toId = $request->to_id;
        return $this->user->profileEvents($fromId->id, $toId, 'like');
    }

    /**
     * function using for like profile
     * @param Request $request
     * @return type
     */
    public function followUser(Request $request) {
        $fromId = $this->user->getUseDetails($id = null);
        $toId = $request->to_id;
        return $this->user->profileEvents($fromId->id, $toId, 'follow');
    }

    public function userConnection(Request $request) {
        $post = $request->all();
        return $this->user->connectDismissMember($post);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id) {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id) {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request) {
        return $this->user->deleteUser($request);
    }

    /*
     * Function for add report.
     */

    public function addReport() {
        $html = View::make('_add-report')->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Function for save report.
     */

    public function saveReport(Request $request) {
        return $this->report->saveReport($request);
    }

    /**
     * Method for job view page.
     *
     */
    public function jobs() {
        return view('jobs.jobs-list');
    }

    public function getJobQuestions(Request $request) {
        try {
            $getQuestionnaire = '';
            $jobDetail = $this->user->getJobById($request->id);
            if (!empty($jobDetail) && !empty($jobDetail->questionnaire_id)) {
                $getQuestionnaire = $this->user->getJobQuestionnaire($jobDetail->questionnaire_id);
            }
            $html = View::make('ajax-content.jobs._job-question', ['jobDetail' => $jobDetail, 'getQuestionnaire' => $getQuestionnaire, 'acceptType' => $request->acceptType])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for get post jobs.
     */

    public function getAlljobsList(Request $request) {
        try {
            $jobs = $this->user->getPostJob($request);
            $html = View::make('ajax-content.jobs._all_jobs-list', ['jobs' => $jobs, 'type' => $request->type])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for job detail page.
     *
     */
    public function jobDetail($id) {
        $jobView = $this->user->saveJobView(base64_decode($id));
        $job = $this->user->getJobById(base64_decode($id));
        return view('jobs.job-detail', ['job' => $job]);
    }

    /**
     * Method for get all new jobs list.
     *
     */
    public function newJobsList(Request $request) {
        try {
            $jobs = $this->user->getLatestJobsList($request->id);
            $html = View::make('ajax-content.jobs._new-jobs-list', ['jobs' => $jobs])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Method for get all jobs country for map.
     *
     */
    public function getJobCountry() {
        try {
            $jobCountry = getJobCountry();
            return Response::json(['jobCountry' => $jobCountry]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * function for mutuak friend list of other users
     * @param type $id
     * @return type
     */
    public function mutualFriendsList(Request $request) {
        try {
            $post = $request->all();
            $id = getUserIdBySlug($post['slug']);
            $users = $this->user->getMutualFriendsList($id);
            $html = View::make('ajax-content._mutual_friends_list', ['users' => $users, 'otherId' => $id])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * save job applay
     * @param Request $request
     */
    public function saveAppliedJob(Request $request) {
        return $this->user->saveAppliedJob($request);
    }

    public function changeAppliedStatus(Request $request) {
        return $this->user->changeAppliedStatus($request);
    }

    /*
     * Function for delete job.
     */

    public function deleteJob(Request $request) {
        return $this->user->deleteJob($request);
    }

    
    /*
     * Function for delete job.
     */

    public function sendTextSms() {
        $message="Test SMS";
        $phone='919039872629';
       // $response=sendTextSMS($message, $phone);
        print_r($response->get('@metadata')['statusCode']);
    }
    
    
}
