<?php

namespace App\Http\Controllers\Manager;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Models\BankingCategory;
use App\Http\Models\CallRequest;
use Excel;

class CallRequestController extends Controller {

    /**
     *  manager call request view
     * @return view
     * */
    public function callRequestList(Request $request) {
        return view('manager.call-request.index');
    }

    /**
     *  all call request of manager listing
     * @return \Illuminate\Http\Response
     * */
    public function AllCallRequestlist(Request $request) {
        try {
            $callRequest = CallRequest::getCallRequestList($request, 'manager');
            $html = View::make('manager.call-request._call_request_list', ['callRequest' => $callRequest])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     *  view call request by id
     * @return view
     * */
    public function callRequestView($id) {
        $callRequest = CallRequest::getCallRequestsById($id);
        return view('manager.call-request.call-request-view', ['callRequest' => $callRequest]);
    }

    /**
     *  download call request csv
     * @return view
     * */
    public function downloadCallRequestCsv() {
        $post = [];
        $callRequest = CallRequest::getCallRequestList($post, 'manager');
        $excelDownload = Excel::create('call_request_records', function($excel) use ($callRequest) {
                    $excel->sheet('Sheet1', function($sheet) use($callRequest) {
                        $arr = array();
                        foreach ($callRequest as $callData) {
                            $data = array(
                                $callData->UserProfile->product,
                                $callData->UserProfile->merchant_number,
                                date('d-m-Y', strtotime($callData->created_at)),
                                $callData->status,
                                $callData->executiveDetail->contact_name,
                                $callData->BankCategory->name,
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Business Name', 'Merchant Number', 'Date of Call', 'Status of Call', 'SE Assigned', 'Category')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export call request');
            return redirect()->back();
        }
    }

}
