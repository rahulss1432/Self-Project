<?php

namespace App\Http\Controllers\Manager;

use DB;
use Session;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Http\Requests\ResetPasswordRequest;
use App\Http\Requests\Manager\ForgotPasswordRequest;
use App\User;

class ManagerController extends Controller {

    public function index(Request $request) {
        if (Auth()->guard('manager')->check()) {
            return redirect('manager/dashboard');
        }
        return view('manager.index');
    }

    public function forgotPassword() {
        return view('manager.forgot-password.forgot-password');
    }

    public function sendForgotEmail(ForgotPasswordRequest $request) {
        return User::forgotEmail($request->all(), 'manager');
    }

    public function resetPassword($token) {
        return view('manager.forgot-password.password_reset', ['token' => $token]);
    }

    public function Reset(ResetPasswordRequest $request) {
        return User::ResetPassword($request->all());
    }

    public static function activeInactive($id) {
        $model = User::where('id', $id)->first();

        if ($model->status == 'active') {
            $model->status = 'inactive';
        } else {
            $model->status = 'active';
        }
        if ($model->save()) {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => 'Status Changed  Successfully.'));
        } else {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => 'Status Not Changed .'));
        }
    }

    public function deleteUser($id) {
        $delete = User::where('id', $id)->first();

        if ($delete->delete()) {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => 'Delete Successfully'));
        } else {
            return Response()->json(array('status' => false, 'success.content' => 'Status', 'message' => 'Deletion Failed'));
        }
    }

}
