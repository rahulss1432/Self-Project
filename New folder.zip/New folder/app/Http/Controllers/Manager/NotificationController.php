<?php

namespace App\Http\Controllers\Manager;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class NotificationController extends Controller {

    public function notifications(Request $request) {
        return view('manager.notifications.index');
    }

    public function listNotificationList(Request $request) {
        try {
            $html = View::make('manager.notifications._notifications-list')->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
