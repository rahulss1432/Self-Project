<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Http\Models\User;
use App\Http\Models\CallRequest;
use View;
use Excel;
use App\Http\Requests\Manager\AddExecutiveRequest;
use App\Http\Requests\Manager\EditExecutiveRequest;
use \App\Http\Models\CustomerExecutiveRelation;

class ExecutivesController extends Controller {

    /**
     * manage executives index
     * @return view
     * */
    public function index() {
        return view('manager.executives.index');
    }

    /**
     * all executives list
     * @return view
     * */
    public function allExecutives(Request $request) {
        try {
            $executives = User::getAllExecutivesByManager($request->all(), 'listing');
            $html = View::make('manager.executives._executives_list', ['executives' => $executives])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     *  add new executive
     * @return \Illuminate\Http\Response
     * */
    public function addExecutive() {
        return view('manager.executives.add_executive');
    }

    /**
     *  save executive
     * @return \Illuminate\Http\Response
     * */
    public function saveExecutive(AddExecutiveRequest $request) {
        return User::saveExecutive($request->all());
    }

    /**
     *  edit executive form
     * @return view
     * */
    public function editExecutive($id) {
        $user = User::getUserById($id);
        if (!empty($user)) {
            return view('manager.executives.edit_executive', ['user' => $user]);
        }
        abort(404);
    }

    /**
     *  update executive
     * @return \Illuminate\Http\Response
     * */
    public function updateExecutive(EditExecutiveRequest $request) {
        return User::updateExecutive($request->all());
    }

    /**
     *  view executive
     * @return view
     * */
    public function viewExecutive($id) {
        $user = User::getUserById($id);
        if (!empty($user)) {
            return view('manager.executives.view_executive', ['user' => $user]);
        }
        abort(404);
    }

    /**
     * all assigned merchants by executive id
     * @return view
     * */
    public function assignedMerchantList($id) {
        try {
            $seMerchant = CustomerExecutiveRelation::getCustomerByExecutiveId($id);
            $html = View::make('manager.executives._assigned_merchants', ['seMerchant' => $seMerchant])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * support executive requests view
     * @return view
     * */
    public function seRequest() {
        return view('manager.executives.support_executive_request');
    }

    /**
     * list of  all support executive requests
     * @return response json
     * */
    public function SeRequestList(Request $request) {
        try {
            $executives = User::getAllExecutivesRequestByManager($request->all());
            $html = View::make('manager.executives._support_executive_request_list', ['executives' => $executives])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * request details by id
     * @return view
     * */
    public function seRequestView($id) {
        return view('manager.executives.support_executive_request_view', ['id' => $id]);
    }

    /**
     * se request view list
      @return response json
     * */
    public function seRequestViewList(Request $request) {
        try {
            $id = $request['id'];
            $executives = CallRequest::where('executive_id', '=', $id)->get();
            $html = View::make('manager.executives._executive_request_list_view', ['executives' => $executives])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * se request note
      @return view
     * */
    public function seRequestNoteView($id) {
        $requestNotes = CallRequest::where('id', '=', $id)->first();
        return view('manager.executives.support_executive_request_note', ['requestNotes' => $requestNotes]);
    }

    /*
     *  download executives listing csv
     */

    public function executivesListCsvDownload() {
        $post = [];
        $executives = User::getAllExecutivesByManager($post, 'listing');
        $excelDownload = Excel::create('executive_records', function($excel) use ($executives) {
                    $excel->sheet('Sheet1', function($sheet) use($executives) {
                        $arr = array();
                        foreach ($executives as $userData) {
                            $data = array(
                                $userData->executive_number,
                                ucfirst($userData->contact_name),
                                $userData->bankCategory->name,
                                $userData->phone_number,
                                !empty($userData->bank->name) ? $userData->bank->name : '-',
                                !empty($userData->customerExecutive) && $userData->customerExecutive->count() > 0 ? $userData->customerExecutive->count() : '0',
                                $userData->city . ',' . $userData->state,
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'ID', 'Name', 'Category', 'Phone', 'Company', 'Merchant', 'City/State')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export  executives listing');
            return redirect()->back();
        }
    }

    /*
     *  executives request csv download
     */

    public function downloadExecutiveRequestCsv() {
        $post = [];
        $executives = User::getAllExecutivesRequestByManager($post);
        $excelDownload = Excel::create('executive_reqeust_records', function($excel) use ($executives) {
                    $excel->sheet('Sheet1', function($sheet) use($executives) {
                        $arr = array();
                        foreach ($executives as $userData) {
                            $pendingRequest = \App\Http\Models\CallRequest::getCallRequestByPending($userData->id);
                            $resolvedRequest = \App\Http\Models\CallRequest::getCallRequestByResolve($userData->id);
                            $data = array(
                                ucfirst($userData->contact_name),
                                (!empty($userData->bank->waiting_time) ? $userData->bank->waiting_time : '0') . 'min',
                                $pendingRequest > 0 ? $pendingRequest : '0',
                                $resolvedRequest > 0 ? $resolvedRequest : '0'
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Name', 'Average Waiting time', 'Pending request', 'Completed Request')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export executive request');
            return redirect()->back();
        }
    }

}
