<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use File;
use View;
use Image;
use App\Http\Models\User;
use App\Http\Requests\ChangePasswordRequest;
use App\Http\Requests\ChangeUserPasswordRequest;
class DashboardController extends Controller {

    /**
     * manager dashboard
     * @return view
     * */
    public function index() {
        return view('manager.dashboard.index');
    }

    /**
     *  change password
     * @return view
     * */
    public function changePassword() {
        return view('manager.change-password.change-password');
    }

    /**
     *  update password
     * @return \Illuminate\Http\Response
     * */
    public function updatePassword(ChangePasswordRequest $request) {
        return \App\User::updatePassword($request->all());
    }

    /**
     * upload media for image and videos
     * @return \Illuminate\Http\Response
     *  */
    public function uploadMedia(Request $request) {
        $file = $request->file('image_file');
        $uploadImageTempPath = public_path() . '/uploads/temp-image';
        if (!is_dir($uploadImageTempPath)) {
            File::makeDirectory($uploadImageTempPath, $mode = 0777, true, true);
        }
        $fileName = $file->getClientOriginalName();
        $fileExtendedName = time() . $fileName;
        $file->move($uploadImageTempPath, $fileExtendedName);
        return Response::Json(['filename' => $fileExtendedName]);
    }

    /**
     *  open image cropper model with file name parameter
     * @return \Illuminate\Http\Response
     * */
    public function loadImageCropper(Request $request) {
        $post = $request->all();
        $html = View::make('manager.executives._load_image_cropper', ['imageName' => $post['imageName'], 'type' => $post['type']])->render();
        return Response::json(['html' => $html]);
    }

    /**
     *  upload cropped picture to original path 
     * @return string
     * * */
    public function uploadCroppedPicture(Request $request) {
        $post = $request->all();
        if ($post['type'] == 'profile_image') {
            $cropImgPath = base_path() . '/public/uploads/users/';
        }
        if (!is_dir($cropImgPath)) {
            mkdir($cropImgPath, 0777, true);
        }
        $origanlImage = base_path() . '/public/uploads/temp-image/' . $post['imageName'];
        $destinationPath = $cropImgPath . $post['imageName'];
        $img = Image::make($origanlImage);
        $croppedImage = $img->crop(intval($post['croppedWidth']), intval($post['croppedHeight']), intval($post['croppedX']), intval($post['croppedY']));
        $croppedImage->save($destinationPath);
        unlink($origanlImage);
        return $post['imageName'];
    }

    /**
     * change users status.
     *
     * @return \Illuminate\Http\Response
     */
    public function changeUserStatus(Request $request) {
        return User::changeUserStatus($request->all());
    }

    /**
     * change password by user id.
     *
     * @return \Illuminate\Http\Response
     */
    public function changePasswordById($id) {
        return User::changePasswordById($id);
    }

    /**
     * manager profile view.
     *
     * @return view
     */
    public function viewManagerProfile() {
        $user = User::getUserById(Auth::guard(getAuthGuard())->user()->id);
        if (!empty($user)) {
            return view('manager.dashboard.view_profile', ['user' => $user]);
        }
        abort(404);
    }

    /**
     * .content text box image upload
     *
     * @return view
     */
    public function contentImageUpload(Request $request) {
        reset($_FILES);
        $temp = current($_FILES);
        $type = explode("/", $temp['type']);
        if ($type[0] == 'image') {
            if ($temp['size'] < (1000 * 1000 * 5)) {
                $size = getimagesize($temp['tmp_name']);
                $filename = time() . "-" . $temp['name'];
                $path = str_replace('/admin', '', base_path());
                $imagePath = $path . '/public/uploads/tinymce/';
                if (!is_dir($imagePath)) {
                    File::makeDirectory($imagePath, $mode = 0777, true, true);
                }
                move_uploaded_file($temp['tmp_name'], $imagePath . $filename);
                $url = url('/public/uploads/tinymce/' . $filename);
                echo json_encode(array('location' => $url));
                die();
            } else {
                echo json_encode(array('success' => 0, 'error' => 'Image has to be smaller than 5MB'));
                die();
            }
        }
    }

    /**
     *  open change password model content
     * @return \Illuminate\Http\Response
     * */
    public function loadChangePasswordModel($id) {
        try {
            $user = User::getUserById($id);
            $html = View::make('manager.change-password._change_user_password', ['user' => $user])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     *  update password
     * @return \Illuminate\Http\Response
     * */
    public function updateUserPassword(ChangeUserPasswordRequest $request) {
        return User::updateUserPassword($request->all());
    }

}
