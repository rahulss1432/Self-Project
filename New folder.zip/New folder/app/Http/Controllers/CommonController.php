<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Repositories\UserRepository;
use App\Http\Requests\EventTeamRequest;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\ChangePasswordRequest;
use App\Models\PaymentSource;
use App\Http\Requests\CardRequest;
use App\Http\Requests\AchRequest;
use App\Http\Requests\AchAmountVerifyRequest;
use App\Http\Requests\ContactUsRequest;
class CommonController extends Controller {
    /*
     * Class Construct.
     *
     * @param  array  $data
     * @return App\Player\Repositories\UserRepository;
     */

    public function __construct(UserRepository $user, PaymentSource $paymentSource) {
        $this->user = $user;
        $this->paymentSource = $paymentSource;
    }

    /**
     * Method for get all countries.
     *
     * @return \Illuminate\Http\Response
     */
    public function getAllCountry(Request $request) {
        return getAllCountry($request->all());
    }

    /**
     * Method for get all states.
     *
     * @return \Illuminate\Http\Response
     */
    public function getStatesByCountryId(Request $request) {
        return getStatesByCountryId($request->all());
    }

    /**
     * Method for get all master languages.
     *
     * @return \Illuminate\Http\Response
     */
    public function getLanguages(Request $request) {
        return getAllLanguages($request->all());
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function getUserGeneralInfo(Request $request) {
        return getUserGeneralData();
    }

    /**
     * Method for get all master levels.
     *
     * @return \Illuminate\Http\Response
     */
    public function getLevels(Request $request) {
        return getAllLevels($request->all());
    }

    /**
     * Method for get all positions.
     *
     * @return \Illuminate\Http\Response
     */
    public function getPositions(Request $request) {
        return getAllPositions($request);
    }

    /**
     * Method for Image upload.
     *
     * @return \Illuminate\Http\Response
     */
    public function uploadProfileImage(Request $request) {
        return profileImage($request->all());
    }

    public function loadProfileImageCropper(Request $request) {
        return View::make('_load-cropper-modal', ['filename' => $request['filename'], 'folder' => $request['folder'], 'thumb_folder' => $request['thumb_folder'], 'image_type' => $request['image_type']])->render();
    }

    public function saveProfileImage(Request $request) {
        return getSavingImage($request['filename'], $request);
    }

    /**
     * Method for get all teams.
     *
     * @return \Illuminate\Http\Response
     */
    public function getAllTeam(Request $request) {
        return getAllTeam($request->all());
    }

    /**
     * Method for Event Image upload.
     *
     * @return \Illuminate\Http\Response
     */
    public function uploadEventImage(Request $request) {
        return profileImage($request->all());
    }

    public function loadEventImageCropper(Request $request) {
        return View::make('_load_event_cropper_modal', ['filename' => $request['filename'], 'folder' => $request['folder'], 'thumb_folder' => $request['thumb_folder'], 'image_type' => $request['image_type']])->render();
    }

    /**
     * Method for get contry code.
     *
     */
    public function getCountryCode(Request $request) {
        return getCountryCode($request->all());
    }

    /**
     * Method for get Advance Filter.
     *
     */
    public function getAdvanceFilter() {
        return view('advance-filter');
    }

    /*
     * function for get event list.
     */

    public function getEvent() {
        $latest = $this->user->getEvent('latest', NULL, NULL);
        return view('event-list', ['latest' => $latest]);
    }

    /*
     * function for get upcoming event list.
     */

    public function getUpComingEvent(Request $request) {
        try {
            $upcomming = $this->user->getEvent('upcomming', NULL, $request);
            $html = View::make('_upcoming-events', ['upcomming' => $upcomming])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

    /*
     * function for view event.
     */

    public function viewEvent($slug) {
        $event = $this->user->getEvent(NULL, base64_decode($slug), NULL);
        if ($event) {
            return view('event-detail', ['event' => $event]);
        } else {
            return redirect(getAuthGuard() . '/dashboard');
        }
    }

    /**
     * Method for job view page.
     *
     */
    public function jobs() {
        return view('jobs.jobs');
    }

    /*
     * Function for get post jobs.
     */

    public function getAlljobList() {
        $jobs = $this->user->getPostJob();
        $html = View::make('ajax-content.jobs._get-team-job', ['jobs' => $jobs])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Function for getting social share page.
     */

    public function getSocialPage(Request $request) {
        $post = $request->all();
        if ((isset($post['id']) && !empty($post['id'])) || (isset($post['slug']) && !empty($post['slug']))) {
            $userId = getUserIdBySlug($post['slug']);
            $userRole = getUserById($userId, "role");
            if ($request['share_type'] == 'profile-share') {
                $url = url('view/' . $userRole . '-profile/' . $post['slug']);
            }
            if ($request['share_type'] == 'procard-share') {
                if (Auth::guard(getAuthGuard())->user()->id == $userId) {
                    $url = url($userRole . '/' . $userRole . '-profile/');
                } else {
                    $url = url('view/' . $userRole . '-profile/' . $post['slug'] . '/share');
                }
            }
            if ($request['share_type'] == 'post-share') {
                $url = url('post-details', base64_encode($post['id']));
            }
            if ($request['share_type'] == 'job-share') {
                $url = url('jobs-detail', base64_encode($post['id']));
            }
            if ($request['share_type'] == 'map-share') {
                $url = url('view/jobs');
            }
            if ($request['share_type'] == 'event-share') {
                $url = url('event', base64_encode($post['id']));
            }
            if ($request['share_type'] == 'news-share') {
                $url = url('news-details', base64_encode($post['id']));
            }
        } else {
            if ($request['share_type'] == 'home-share') {
                $url = url('/index');
            }
        }
        $html = view('_social_share_model', ['shareUrl' => $url])->render();
        return Response::json(['html' => $html]);
    }

    public function search($value = null) {
        if ($value == 'faf') {
            $value = '';
        }
        $searchData = $value;
        return view('search-result', ["searchData" => $searchData]);
    }

    /*
     * Function for get instagram feed
     */

    public function getInstagramFeed() {
        $html = View::make('_instagram-feeds')->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Function for save event team
     */

    public function saveEventTeam(EventTeamRequest $request) {
        return $this->user->saveEventTeam($request);
    }

    /*
     * open add event form modal
     */

    function addTeamForm() {
        $html = View::make('_add-team-modal-form')->render();
        return Response::json(['html' => $html]);
    }

    /**
     * get search playr result list
     */
    public function searchPlayerList(Request $request) {
        $getPlayer = $this->user->globalSearchPlayer($request->all());
        $html = View::make('ajax-content.search._player-search-list', ['getPlayer' => $getPlayer])->render();
        return Response::json(['html' => $html]);
    }

    /**
     * get search coach result list
     */
    public function searchCoachList(Request $request) {
        $getCoach = $this->user->globalSearchCoach($request->all());
        $html = View::make('ajax-content.search._coach-search-list', ['getCoach' => $getCoach])->render();
        return Response::json(['html' => $html]);
    }

    /**
     * get search team result list
     */
    public function searchTeamList(Request $request) {
        $getTeam = $this->user->globalSearchTeam($request->all());
        $html = View::make('ajax-content.search._team-search-list', ['getTeam' => $getTeam])->render();
        return Response::json(['html' => $html]);
    }

    /**
     * get search job result list
     */
    public function searchJobList(Request $request) {
        $getJob = $this->user->globalSearchJob($request->all());
        $html = View::make('ajax-content.search._search-job-list', ['getJob' => $getJob])->render();
        return Response::json(['html' => $html]);
    }

    /**
     * get search event result list
     */
    public function searchEventList(Request $request) {
        $events = $this->user->globalSearchEvent($request->all());
        $html = View::make('ajax-content.search._search-event-list', ['events' => $events])->render();
        return Response::json(['html' => $html]);
    }

    /**
     * get search post result list
     */
    public function searchPostList(Request $request) {
        $role = Auth::guard(getAuthGuard())->user()->role;
        $getPost = $this->user->globalSearchPost($request->all());
        $html = View::make($role . '::ajax-content._post-view', ['posts' => $getPost, 'o_id' => ''])->render();
        return Response::json(['html' => $html]);
    }

    public function advancedSearch(Request $request) {
        $post = $request->all();
        return view('advenced-search-result', ['post' => $post]);
    }

    /*
     * Advanaced search results
     */

    public function loadSearchResults(Request $request) {
        $post = $request->all();
        $data = '';
        if (!empty($post['data'])) {
            $data = (array) json_decode($post['data']);
            $result = $this->user->advancedSearch($data);
            if ($data['user_type'] == 'player') {
                $html = View::make('ajax-content.search._player-search-list', ['getPlayer' => $result])->render();
            } elseif ($data['user_type'] == 'team') {
                $html = View::make('ajax-content.search._team-search-list', ['getTeam' => $result])->render();
            } else {
                $html = View::make('ajax-content.search._coach-search-list', ['getCoach' => $result])->render();
            }
            return Response::json(['html' => $html]);
        }
    }

    /*
     * function using for get news Details  
     */

    public function newsDetails($newsId = null) {
        if (!empty($newsId)) {
            $getNewsList = $this->user->getNewsById(base64_decode($newsId));
        } else {
            $getNewsList = $this->user->getLatestNews();
        }
        if (!empty($getNewsList)) {
            return view('news.news-details', ['getNewsList' => $getNewsList]);
        } else {
            abort(404);
        }
    }

    /*
     * Compare player profiles.
     */

    public function compare($slug = null) {
        $id = '';
        if (!empty($slug)) {
            $id = getUserIdBySlug($slug);
        }
        return view('users-compare', ['id' => $id]);
    }

    /*
     * Get compare users.
     */

    public function getCompareUsers(Request $request) {
        try {
            $post = $request->all();
            $connections = $this->user->getCompareUsers($request);
            $html = View::make('ajax-content.compare._get-compare-users', ['connections' => $connections, 'compareUserRole' => $post['user_role'], 'addedUser' => $post['once_added_user_id']])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Add compare user.
     */

    public function addCompareUser(Request $request) {
        try {
            $users = $this->user->addCompareUser($request);
            if ($request->role == "player") {
                $html = View::make('ajax-content.compare._add-compare-player', ['users' => $users])->render();
            } elseif ($request->role == "coach") {
                $html = View::make('ajax-content.compare._add-compare-coach', ['users' => $users])->render();
            } elseif ($request->role == "team") {
                $html = View::make('ajax-content.compare._add-compare-team', ['users' => $users])->render();
            }
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Get Compare Users Data.
     */

    public function getCompareUsersData(Request $request) {
        try {
            $users = $this->user->getCompareUsersData($request);
            $role = $request->role;
            if ($role == "player") {
                $html = View::make('ajax-content.compare._get-compare-player-data', ['users' => $users])->render();
            } elseif ($role == "coach") {
                $html = View::make('ajax-content.compare._get-compare-coach-data', ['users' => $users])->render();
            } elseif ($role == "team") {
                $html = View::make('ajax-content.compare._get-compare-team-data', ['users' => $users])->render();
            }
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /* show settings page */

    public function settings() {
        return view('settings.settings');
    }

    /**
     * Display change password
     *
     * @return \Illuminate\Http\Response
     */
    public function showChangePassword() {
        $html = View::make('ajax-content.settings._change_password')->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Update user password
     *
     * @return \Illuminate\Http\Response
     */
    public function updatePassword(ChangePasswordRequest $request) {
        return $this->user->updatePassword($request);
    }

    /**
     * Display notifications form
     *
     * @return \Illuminate\Http\Response
     */
    public function showNotification() {
        $html = View::make('ajax-content.settings._notifications')->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Display payment method
     *
     * @return \Illuminate\Http\Response
     */
    public function showPaymentMethod() {
        try {
            $bankSource = $this->user->getPaymentSourceById('bank');
            $cardSources = $this->user->getPaymentSourceById('card');
            $html = View::make('ajax-content.settings._payment_method', ['bankSource' => $bankSource, 'cardSources' => $cardSources])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Get all plans list.
     */

    public function showPlanList() {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $subscriptionId = getUserById($userId, 'subscription_id');
        $consumedSpace = getUploadedMediaSizeByUser();
        $totalPlanSpace = getSubscriptionDetails($subscriptionId, 'plan_space');
        $consumedSizePercent = consumedSpaceToPercent($consumedSpace, $totalPlanSpace);
        if (($consumedSpace < (1024)) && ($consumedSpace > 0)) {  // if size is less than 1 KB and greater than 0 bytes
            $readableConsumedSpace = $consumedSpace . ' Bytes';
        } elseif (($consumedSpace < (1024 * 1024)) && ($consumedSpace >= (1024))) {   // if size is less than 1 MB and greater than or equal to 1 KB
            $readableConsumedSpace = readableBytesToUnit($consumedSpace, 'KB');
        } elseif (($consumedSpace < (1024 * 1024 * 1024)) && ($consumedSpace >= (1024 * 1024))) {     // if size is less than 1 GB and greater than or equal to 1 MB
            $readableConsumedSpace = readableBytesToUnit($consumedSpace, 'MB');
        } elseif (($consumedSpace >= (1024 * 1024 * 1024))) {                // if size is greater than 1GB
            $readableConsumedSpace = readableBytesToUnit($consumedSpace, 'GB');
        } else {
            $readableConsumedSpace = '0 Byte';
        }
        $html = View::make('ajax-content.settings._all_plan_list', compact('totalPlanSpace', 'consumedSizePercent', 'readableConsumedSpace'))->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /*
     * Update user plan.
     */

    public function updateUserSubscription(Request $request) {
        return $this->user->updateUserSubscription($request->all());
    }

    /*
     * Update user notification flag for sms or email.
     */

    public function updateNotificationFlag(Request $request) {
        return $this->user->updateNotificationFlag($request->all());
    }

    /**
     * get load notification list in front
     */
    function manageNotificationList() {
        $notification = $this->user->getNotificationList();
        $html = View::make('ajax-content.notification._load_notifications-list', ['notification' => $notification])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * update load notification list in front
     */
    function updateReadNotification() {
        $userId = \Illuminate\Support\Facades\Auth::guard(getAuthGuard())->user()->id;
        return updateNotificationList($userId);
    }

    /**
     * get load notification list count in front
     */
    public function loadNotificationCount() {
        $userId = \Illuminate\Support\Facades\Auth::guard(getAuthGuard())->user()->id;
        $notificationCount = loadNotificationCount($userId);
        return Response::json(['success' => true, 'data' => $notificationCount]);
    }

    /**
     * Update default payment method
     *
     * @return \Illuminate\Http\Response
     */
    public function updatePaymentMethod(Request $request) {
        return $this->user->updatePaymentMethod($request->all());
    }

    /**
     * show payment card form
     */
    function showPaymentCardForm() {
        $html = View::make('ajax-content.settings._add_payment_card_form')->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Save new payment card
     *
     * @return \Illuminate\Http\Response
     */
    public function savePaymentCard(CardRequest $request) {
        return $this->user->savePaymentCard($request->all());
    }

    /**
     * Delete payment card
     *
     * @return \Illuminate\Http\Response
     */
    public function deletePaymentCard($id) {
        $paymentResources = $this->setting->getOtherPaymentSource($id);
        if ($paymentResources->count() > 0) {
            return $this->user->deletePaymentCard($id);
        }
        return Response::json(['success' => false, 'message' => 'Please add new payment method before deleting this card.']);
    }

    /**
     * show payment bank form
     */
    function showPaymentBankForm() {
        $html = View::make('ajax-content.settings._add_payment_bank_form')->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * send pro card notification by user
     */
    function sendProcardNotification($userId) {
        return sendNotifacationByFrontUser(Auth::guard(getAuthGuard())->user()->id, $userId, 'download_procard', '', '');
    }

    /* Add new ACH payment bank to existing customer */

    public function addAchPaymentBank(AchRequest $request) {
        return $this->user->addAchPaymentBank($request->all());
    }

    /**
     * show payment bank form
     */
    function showBankVerificationAmountForm() {
        $html = View::make('ajax-content.settings._verify_ach_bank_form')->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /* verify newly created ach payment bank amount */

    public function verifyAchPaymentBankAmount(AchAmountVerifyRequest $request) {
        return $this->user->verifyAchPaymentBankAmount($request->all());
    }

    /* cancel ACH verifiction form */

    public function cancelAchVefiicationForm() {
        return $this->user->cancelAchVefiicationForm();
    }

    /**
     * change payment on payment model radio button change
     * @param Request $request
     * @return type json
     */
    public function changePaymentMethod(Request $request) {
        try {
            $this->user->changeMethodOfPayment($request);
            return Response::json(['success' => true]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    /**
     * Method for view Terms And Services page.
     * @return view
     */        
    public function termsAndService(Request $request) {
        return view('terms-and-service');
    }
    
    /**
     * Method for contact us/support form.
     * @return View
     */    
    public function loadContactSopportForm($type) {
        $html = View::make('ajax-content._contact_us_support_form', ['type' => $type])->render();
        return Response::Json(['html' => $html]);        
    }    
    
    /**
     * Method for save contact us form.
     * @return Response
     */    
    public function saveContactUs(ContactUsRequest $request) {
        return $this->user->saveContactUs($request->all());        
    }    
}
