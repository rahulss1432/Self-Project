<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class BankingCategory extends Model {

    public static function getCategoryList($request) {
        $category = BankingCategory::Select('banking_categories.*');
        if (isset($request['name']) && !empty($request['name'])) {
            $category->where('name', 'like', '%' . $request['name'] . '%');
        }
        $result = $category->orderBy('id', 'desc')->get();
        return $result;
    }

    public static function saveCategory($request) {
        try {
            $model = new BankingCategory();
            $model->name = $request['name'];
            $model->description = $request['description'];
            $model->category_logo = "logo1.png";
            $model->status = "active";
            $model->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.category_add')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function updateCategory($request) {
        try {
            $id = $request->categoryId;
            $model = BankingCategory::where('id', $id)->first();
            $model->name = $request['name'];
            $model->description = $request['description'];
            $model->category_logo = "logo1.png";
            $model->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.category_update')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function deleteCategory($id) {
        try {
            BankingCategory::where('id', $id)->delete();
            return Response::json(['success' => true, 'message' => \Config::get('constants.category_deleted')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function activeInactiveCategory($id) {
        $model = BankingCategory::where('id', $id)->first();
        if ($model->status == 'active') {
            $model->status = 'inactive';
        } else {
            $model->status = 'active';
        }
        if ($model->save()) {
            return $model->status;
        }
    }

    /*
     * get all active categories 
     */

    public static function getActiveCategories() {
        return BankingCategory::where('status', 'active')->get();
    }

    /*
     * get all categories 
     */

    public static function getAllCategories() {
        return BankingCategory::get();
    }

    /*
     * get category by id 
     */

    public static function getCategoryById($id) {
        return BankingCategory::where('id', $id)->first();
    }

}
