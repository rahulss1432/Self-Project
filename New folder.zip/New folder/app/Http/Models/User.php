<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;
use App\Http\Models\CustomerExecutiveRelation;
use App\Http\Models\ExecutiveManagerRelation;
use App\Http\Models\UserProfile;
use App\Http\Models\Bank;
use App\Http\Models\ExecutiveCategory;
use App\Http\Models\ExecuitveSupervisor;

class User extends Model {
    /*
     * relation with user profile table by user_id
     */

    public function userDetail() {
        return $this->hasOne('App\Http\Models\UserProfile', 'user_id');
    }

    /*
     * relation with bank category table by category_id
     */

    public function bankCategory() {
        return $this->belongsTo('App\Http\Models\BankingCategory', 'category_id');
    }

    /*
     * relation with bank table by bank_id
     */

    public function bank() {
        return $this->belongsTo('App\Http\Models\Bank', 'bank_id');
    }

    /*
     * relation with customer_executive_relations table by executive_id
     */

    public function customerExecutive() {
        return $this->hasMany('App\Http\Models\CustomerExecutiveRelation', 'executive_id');
    }

    /*
     * relation with executive_supervisor table by executive_id
     */

    public function executiveSupervisor() {
        return $this->hasOne('App\Http\Models\ExecuitveSupervisor', 'executive_id');
    }

    /*
     * get all users's where type executive
     */

    public static function getAllExecutives($post) {
        $user = User::select('users.*', 'user_profiles.executive_number')
                        ->join('user_profiles', 'users.id', 'user_id')
                        ->where('role', '=', 'executive')->where('status', '!=', 'deleted')->where('created_by', Auth::guard(getAuthGuard())->user()->id);
        if (isset($post['name']) && !empty($post['name'])) {
            $user->where('contact_name', 'like', '%' . $post['name'] . '%');
        }
        if (isset($post['email']) && !empty($post['email'])) {
            $user->where('email', 'like', '%' . $post['email'] . '%');
        }
        if (isset($post['executive_number']) && !empty($post['executive_number'])) {
            $user->where('user_profiles.executive_number', 'like', '%' . $post['executive_number'] . '%');
        }
        if (isset($post['phone']) && !empty($post['phone'])) {
            $user->where('phone_number', 'like', '%' . $post['phone'] . '%');
        }
        if (isset($post['city_state']) && !empty($post['city_state'])) {
            $user->where('city', 'like', '%' . $post['city_state'] . '%')
                    ->orWhere('state', 'like', '%' . $post['city_state'] . '%');
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $user->where('users.category_id', $post['category_id']);
        }
        if (isset($post['status']) && !empty($post['status'])) {
            $user->where('status', $post['status']);
        }
        return $user->orderBy('users.id', 'desc')->get();
    }

    /*
     * get all users's where type executive by manager id
     */

    public static function getAllExecutivesByManager($post, $callFrom) {
        $user = User::select('users.*', 'user_profiles.executive_number')
                ->join('user_profiles', 'users.id', 'user_id')
                ->leftjoin('executive_manager_relations', 'users.id', 'executive_manager_relations.executive_id')
                ->where('status', '!=', 'deleted')
                ->where('executive_manager_relations.manager_id', Auth::guard(getAuthGuard())->user()->id);
        if ($callFrom == 'count') {
            return $user->get()->count();
        }
        if (isset($post['executive_id']) && !empty($post['executive_id'])) {
            $user->where('user_profiles.executive_number', 'like', '%' . $post['executive_id'] . '%');
        }
        if (isset($post['name']) && !empty($post['name'])) {
            $user->where('contact_name', 'like', '%' . $post['name'] . '%');
        }
        if (isset($post['email']) && !empty($post['email'])) {
            $user->where('email', 'like', '%' . $post['email'] . '%');
        }
        if (isset($post['phone']) && !empty($post['phone'])) {
            $user->where('phone_number', 'like', '%' . $post['phone'] . '%');
        }
        if (isset($post['city_state']) && !empty($post['city_state'])) {
            $user->where('city', 'like', '%' . $post['city_state'] . '%')
                    ->orWhere('state', 'like', '%' . $post['city_state'] . '%');
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $user->where('users.category_id', $post['category_id']);
        }
        if (isset($post['status']) && !empty($post['status'])) {
            $user->where('status', $post['status']);
        }
        return $user->orderBy('users.id', 'desc')->get();
    }

    /*
     * save new executive
     */

    public static function saveExecutive($post) {
        try {
            DB::beginTransaction();
            $model = new User();
            $model->contact_name = $post['contact_name'];
            $model->email = $post['email'];
            $model->username = $post['username'];
            $model->phone_number = $post['phone'];
            $model->role = 'executive';
            $model->city = $post['city'];
            $model->state = $post['state'];
            $model->created_by = Auth::guard(getAuthGuard())->user()->id;
            $model->status = 'active';
            $model->password = bcrypt($post['password']);
            $model->password_base64 = base64_encode($post['password']);
            $model->category_id = $post['category'];

            $allBanks = Bank::where('name', $post['company'])->first();
            if (empty($allBanks)) {
                $bankModel = new Bank();
                $bankModel->name = $post['company'];
                if ($bankModel->save()) {
                    $model->bank_id = $bankModel->id;
                }
            } else {
                $model->bank_id = $allBanks->id;
            }
            $model->save();
            /* save data to user profile table */
            $userProfile = new UserProfile();
            $userProfile->user_id = $model->id;
            $userProfile->executive_number = $post['executive_number'];
            $userProfile->save();

            /* save this exective to executive relation model */
            $executiveManagerModel = new ExecutiveManagerRelation();
            $executiveManagerModel->executive_id = $model->id;
            $executiveManagerModel->manager_id = $post['manager_id'];
            $executiveManagerModel->save();

            /* save this exective's supervisor to executive supervisor model */
            $supervisorModel = new ExecuitveSupervisor();
            $supervisorModel->executive_id = $model->id;
            $supervisorModel->name = $post['supervisor_name'];
            $supervisorModel->email = $post['supervisor_email'];
            $supervisorModel->phone_number = $post['supervisor_phone'];
            if (isset($post['supervisor_customer']) && !empty($post['supervisor_customer'])) {
                $supervisorModel->customer_id = implode(',', $post['supervisor_customer']);
            } else {
                $supervisorModel->customer_id = NULL;
            }
            $supervisorModel->save();

            /* send mail function for user credentials */
            $data = [];
            $data['name'] = $model->first_name . ' ' . $model->last_name;
            $data['username'] = $model->username;
            $data['email'] = $model->email;
            $data['password'] = $post['password'];
            $data['subject'] = 'User Credentials';
            $data['request'] = 'user_mail';
            $data['user_role'] = $model->role;
            $data['created_by_role'] = Auth::guard(getAuthGuard())->user()->role;
            $mail = sendMail($data);
            DB::commit();
            return Response::json(['success' => true, 'message' => \Config::get('constants.executive_added')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * update executive
     */

    public static function updateExecutive($post) {
        try {
            DB::beginTransaction();
            $model = User::where('id', $post['user_id'])->first();
            $model->contact_name = $post['contact_name'];
            $model->email = $post['email'];
            $model->phone_number = $post['phone'];
            $model->role = 'executive';
            $model->city = $post['city'];
            $model->state = $post['state'];
            $model->updated_by = Auth::guard(getAuthGuard())->user()->id;
            $model->status = 'active';
            $model->category_id = $post['category'];
            $allBanks = Bank::where('name', $post['company'])->first();
            if (empty($allBanks)) {
                $bankModel = new Bank();
                $bankModel->name = $post['company'];
                if ($bankModel->save()) {
                    $model->bank_id = $bankModel->id;
                }
            } else {
                $model->bank_id = $allBanks->id;
            }
            $model->save();
            /* save data to user profile table */
            $userProfileModel = UserProfile::where('user_id', $model->id)->first();
            $userProfileModel->bussiness_address = $post['bussiness_address'];
            $userProfileModel->save();

            CustomerExecutiveRelation::where([
                'executive_id' => $model->id,
                'linked_by' => $model->created_by,
            ])->delete();

            if (isset($post['customer']) && !empty($post['customer'])) {
                foreach ($post['customer'] as $customer) {
                    $relationModel = new CustomerExecutiveRelation();
                    $relationModel->customer_id = $customer;
                    $relationModel->executive_id = $model->id;
                    $relationModel->manager_id = $post['manager_id'];
                    $relationModel->linked_by = $model->created_by;
                    $relationModel->save();
                }
            }
            // save this exective to executive relation model 
            $executiveManagerModel = ExecutiveManagerRelation::where('executive_id', $model->id)->first();
            $executiveManagerModel->executive_id = $model->id;
            $executiveManagerModel->manager_id = $post['manager_id'];
            $executiveManagerModel->save();

            /* save this exective's supervisor to executive supervisor model */
            $supervisorModel = ExecuitveSupervisor::where('executive_id', $model->id)->first();
            if (empty($supervisorModel)) {
                $supervisorModel = new ExecuitveSupervisor();
                $supervisorModel->executive_id = $model->id;
            }
            $supervisorModel->name = $post['supervisor_name'];
            $supervisorModel->email = $post['supervisor_email'];
            $supervisorModel->phone_number = $post['supervisor_phone'];
            if (isset($post['supervisor_customer']) && !empty($post['supervisor_customer'])) {
                $supervisorModel->customer_id = implode(',', $post['supervisor_customer']);
            } else {
                $supervisorModel->customer_id = NULL;
            }
            $supervisorModel->save();

            DB::commit();
            return Response::json(['success' => true, 'message' => \Config::get('constants.executive_updated')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getLine()]);
        }
    }

    public static function getCustomerLinkedById() {
        return User::where('role', 'customer')->where('status', '!=', 'deleted')->get();
    }

    public static function getCustomerLinkedByManagerId($id) {
        return User::where('role', 'customer')->where('status', '!=', 'deleted')->where('created_by', $id)->get();
    }

    /*
     * change  users's status
     */

    public static function changeUserStatus($post) {
        try {
            if ($post['status'] == 'deleted') {
                $msg = \Config::get('constants.user_deleted');
            } else {
                $msg = \Config::get('constants.status_updated');
            }
            $model = User::where('id', $post['id'])->first();
            $model->status = $post['status'];
            $model->save();
            return Response::json(['success' => true, 'message' => $msg]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * get users details by id
     */

    public static function getUserById($userId) {
        return User::where('id', $userId)->where('status', '!=', 'deleted')->first();
    }

    /*
     * get all users's where type customer
     */

    public static function getAllMerchant($post) {
        $user = User::join('user_profiles', 'users.id', 'user_id')->where('role', '=', 'customer')->where('status', '!=', 'deleted')->where('created_by', Auth::guard(getAuthGuard())->user()->id);
        if (isset($post['name']) && !empty($post['name'])) {
            $searchData = $post['name'];
            $user->where(function($query) use($searchData) {
                $query->where(DB::raw('CONCAT(users.first_name," ",users.last_name)'), 'like', '%' . $searchData . '%');
            });
        }
        if (isset($post['merchant_number']) && !empty($post['merchant_number'])) {
            $user->where('user_profiles.merchant_number', $post['merchant_number']);
        }
        if (isset($post['bussiness_name']) && !empty($post['bussiness_name'])) {
            $user->where('user_profiles.bussiness_name', 'like', '%' . $post['bussiness_name'] . '%');
        }
        if (isset($post['phone_number']) && !empty($post['phone_number'])) {
            $user->where('users.phone_number', $post['phone_number']);
        }
        if (isset($post['bussiness_address']) && !empty($post['bussiness_address'])) {
            $user->where('user_profiles.bussiness_address', 'like', '%' . $post['bussiness_address'] . '%');
        }
        return $user->orderBy('users.id', 'desc')->get();
    }

    /*
     * save new merchant
     */

    public static function saveMerchant($post) {
        try {
            DB::beginTransaction();
            $model = new User();
            $model->contact_name = $post['contact_name'];
            $model->email = $post['email'];
            $model->username = $post['username'];
            $model->role = 'customer';
            $model->phone_number = $post['phone'];
            $model->city = $post['city'];
            $model->state = $post['state'];
            $model->created_by = Auth::guard(getAuthGuard())->user()->id;
            $model->updated_by = Auth::guard(getAuthGuard())->user()->id;
            $model->status = 'active';
            $model->password = bcrypt($post['password']);
            $model->password_base64 = base64_encode($post['password']);
            if ($model->save()) {
                $userProfile = new UserProfile();
                $userProfile->user_id = $model->id;
                $userProfile->merchant_number = $post['merchant_number'];
                $userProfile->product = $post['product'];
                $userProfile->bussiness_name = $post['bussiness_name'];
                $userProfile->bussiness_address = $post['bussiness_address'];
                $userProfile->terminal_model = $post['terminal_model'];
                $userProfile->save();
                if (isset($post['executive']) && !empty($post['executive'])) {
                    foreach ($post['executive'] as $executive) {
                        $relationModel = new CustomerExecutiveRelation();
                        $relationModel->customer_id = $model->id;
                        $relationModel->executive_id = $executive;
                        $relationModel->manager_id = $model->created_by;
                        $relationModel->linked_by = $model->created_by;
                        $relationModel->save();
                    }
                }
                // send mail function for user credentials 
                $data = [];
                $data['name'] = $model->first_name . ' ' . $model->last_name;
                $data['username'] = $model->username;
                $data['email'] = $model->email;
                $data['password'] = $post['password'];
                $data['subject'] = 'User Credentials';
                $data['request'] = 'user_mail';
                $data['user_role'] = $model->role;
                $data['created_by_role'] = Auth::guard(getAuthGuard())->user()->role;
                $mail = sendMail($data);
                DB::commit();
            } else {
                DB::rollBack();
            }
            return Response::json(['success' => true, 'message' => \Config::get('constants.merchant_added')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * update merchant
     */

    public static function updateMerchant($post) {
        try {
            DB::beginTransaction();
            $model = User::where('id', $post['user_id'])->first();
            $model->contact_name = $post['contact_name'];
            $model->email = $post['email'];
            $model->role = 'customer';
            $model->phone_number = $post['phone'];
            $model->city = $post['city'];
            $model->state = $post['state'];
            $model->updated_by = Auth::guard(getAuthGuard())->user()->id;
            $model->status = 'active';
            if ($model->save()) {
                $userProfile = UserProfile::where('user_id', $post['user_id'])->first();
                $userProfile->user_id = $model->id;
                $userProfile->product = $post['product'];
                $userProfile->bussiness_name = $post['bussiness_name'];
                $userProfile->bussiness_address = $post['bussiness_address'];
                $userProfile->machine_model = $post['machine_model'];
                $userProfile->terminal_model = $post['terminal_model'];
                $userProfile->save();
                CustomerExecutiveRelation::where([
                    'customer_id' => $model->id,
                    'manager_id' => $model->created_by,
                ])->delete();
                if (isset($post['executive']) && !empty($post['executive'])) {
                    foreach ($post['executive'] as $executive) {
                        $relationModel = new CustomerExecutiveRelation();
                        $relationModel->customer_id = $model->id;
                        $relationModel->executive_id = $executive;
                        $relationModel->manager_id = $model->created_by;
                        $relationModel->linked_by = $model->created_by;
                        $relationModel->save();
                    }
                }
                DB::commit();
            } else {
                DB::rollBack();
            }
            return Response::json(['success' => true, 'message' => $msg = \Config::get('constants.merchant_updated')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * get all managers with filter
     */

    public static function getManagerList($request) {
        $lists = User::where('role', 'manager')->where('status', '!=', 'deleted')->orderBy('id', 'desc');
        if (isset($request['name']) && !empty($request['name'])) {
            $lists->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $request['name'] . '%');
        }
        if (isset($request['bank_id']) && !empty($request['bank_id'])) {
            $lists->where('bank_id', $request['bank_id']);
        }
        $result = $lists->get();
        return $result;
    }

    /*
     * save manager
     */

    public static function saveManager($post) {
        try {
            DB::beginTransaction();
            $model = new User();
            $generateNumber = str_random(8);
            $model->first_name = $post['first_name'];
            $model->last_name = $post['last_name'];
            $model->email = $post['email'];
            $model->phone_number = $post['phone'];
            $model->role = 'manager';
            $model->profile_image = $post['hiddenFileName'];
            $model->status = 'active';
            $allBanks = Bank::where('name', $post['company'])->first();
            if ($allBanks == null) {
                $bankModel = new Bank();
                $bankModel->name = $post['company'];
                if ($bankModel->save()) {
                    $model->bank_id = $bankModel->id;
                }
            } else {
                $model->bank_id = $allBanks->id;
            }
            $company = explode(' ', $post['company']);
            $data1 = strtolower($company[0]);
            $model->password = bcrypt($generateNumber);
            $model->password_base64 = base64_encode($generateNumber);
            $model->manager_type = $post['manager_type'];
            $model->created_by = Auth::guard(getAuthGuard())->user()->id;
            if ($model->save()) {
                $model->username = getUserName($post['first_name'], $data1, $model->id);
                $model->save();
                $data = [];
                $data['name'] = $model->first_name . ' ' . $model->last_name;
                $data['username'] = $model->username;
                $data['email'] = $model->email;
                $data['password'] = $generateNumber;
                $data['subject'] = 'User Credentials';
                $data['request'] = 'user_mail';
                $data['user_role'] = $model->role;
                $data['created_by_role'] = Auth::guard(getAuthGuard())->user()->role;
                $mail = sendMail($data);
                DB::commit();
            }
            return Response::json(['success' => true, 'message' => \Config::get('constants.manager_added')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * update manager
     */

    public static function updateManager($post) {
        try {
            DB::beginTransaction();
            $model = User::where('id', $post['managerId'])->first();
            $generateNumber = str_random(8);
            $model->first_name = $post['first_name'];
            $model->last_name = $post['last_name'];
            $model->email = $post['email'];
            $model->phone_number = $post['phone'];
            $model->role = 'manager';
            $model->profile_image = $post['hiddenFileName'];
            $allBanks = Bank::where('name', $post['company'])->first();
            if ($allBanks == null) {
                $bankModel = new Bank();
                $bankModel->name = $post['company'];
                if ($bankModel->save()) {
                    $model->bank_id = $bankModel->id;
                }
            } else {
                $model->bank_id = $allBanks->id;
            }
            $model->manager_type = $post['manager_type'];
            if ($model->save()) {
                DB::commit();
            } else {
                DB::rollBack();
            }
            return Response::json(['success' => true, 'message' => $msg = \Config::get('constants.manager_update')]);
        } catch (\Exception $e) {
            DB::rollBack();
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * get all manager where linked by admin
     */

    public static function getManagerLinkedById() {
        return User::where('role', 'manager')->where('status', '!=', 'deleted')->where('created_by', Auth::guard(getAuthGuard())->user()->id)->get();
    }

    /*
     * get all executives where linked by admin or manager
     */

    public static function getExecutivesLinkedById() {
        if (Auth::guard(getAuthGuard())->user()->role == "manager") {
            return User::where('role', 'executive')->where('status', '!=', 'deleted')->where('created_by', Auth::guard(getAuthGuard())->user()->id)->get();
        } else {
            return User::where('role', 'executive')->where('status', '!=', 'deleted')->get();
        }
    }

    /*
     * get all executives
     */

    public static function getAllExecutivesByAdmin() {
        return User::where('role', 'executive')->where('status', '!=', 'deleted')->get();
    }

    /*
     * change password for user
     */

    public static function changePasswordById($id) {
        try {
            $model = User::where('id', $id)->first();
            /* send mail function for user credentials */
            $data = [];
            $data['name'] = $model->first_name . ' ' . $model->last_name;
            $data['username'] = $model->username;
            $data['email'] = $model->email;
            $data['password'] = base64_decode($model->password_base64);
            $data['subject'] = 'Change Password Credentials';
            $data['request'] = 'change_password_mail';
            $data['user_role'] = $model->role;
            $data['created_by_role'] = Auth::guard(getAuthGuard())->user()->role;
            $mail = sendMail($data);
            return Response::json(['success' => true, 'message' => \Config::get('constants.change_password_mail_sent')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function getAllMerchantByAdmin($post) {
        $user = User::join('user_profiles', 'users.id', 'user_id')->where('role', '=', 'customer')->where('status', '!=', 'deleted');
        if (isset($post['name']) && !empty($post['name'])) {
            $searchData = $post['name'];
            $user->where(function($query) use($searchData) {
                $query->where(DB::raw('CONCAT(users.first_name," ",users.last_name)'), 'like', '%' . $searchData . '%');
            });
        }
        if (isset($post['merchant_number']) && !empty($post['merchant_number'])) {
            $user->where('user_profiles.merchant_number', $post['merchant_number']);
        }
        if (isset($post['bussiness_name']) && !empty($post['bussiness_name'])) {
            $user->where('user_profiles.bussiness_name', 'like', '%' . $post['bussiness_name'] . '%');
        }
        if (isset($post['phone_number']) && !empty($post['phone_number'])) {
            $user->where('users.phone_number', $post['phone_number']);
        }
        if (isset($post['bussiness_address']) && !empty($post['bussiness_address'])) {
            $user->where('user_profiles.bussiness_address', 'like', '%' . $post['bussiness_address'] . '%');
        }
        return $user->orderBy('users.id', 'desc')->get();
    }

    /*
     * get all merchant by managers 
     */

    public static function getAllMerchantByManager($id) {
        return User::where('role', '=', 'customer')->where('status', '!=', 'deleted')->where('created_by', $id)->get();
    }

    public static function viewMerchantbyManager($id) {
        $viewMerchant = User::join('user_profiles', 'users.id', 'user_profiles.user_id')
//                ->leftjoin('tickets', 'users.id', 'tickets.customer_id')
//                ->leftjoin('call_requests', 'call_requests.ticket_id', 'tickets.id')
//                ->leftjoin('ratings', 'ratings.request_id', 'call_requests.id')
                ->where('users.id', $id)
                ->where('users.status', '!=', 'deleted')
                ->first();
        return $viewMerchant;
    }

    /*
     * update user password by users id
     */

    public static function updateUserPassword($post) {
        try {
            $model = User::where('id', $post['user_id'])->first();
            $model->password = bcrypt($post['password']);
            $model->password_base64 = base64_encode($post['password']);
            $model->save();
            self::changePasswordById($post['user_id']);
            return Response::json(['success' => true, 'message' => \Config::get('constants.password_updated')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function getAllExecutivesByRequest($post) {
        $user = User::select('users.*', 'executive_manager_relations.manager_id')->Join('executive_manager_relations', 'executive_manager_relations.executive_id', 'users.id')->where('role', '=', 'executive')->where('status', '!=', 'deleted');
        if (isset($post['name']) && !empty($post['name'])) {
            $user->where('contact_name', 'like', '%' . $post['name'] . '%');
        }
        return $user->orderBy('users.id', 'desc')->get();
    }

    public static function getAllExecutivesRequestByManager($post) {
        $user = User::select('users.*', 'executive_manager_relations.manager_id')
                ->Join('executive_manager_relations', 'executive_manager_relations.executive_id', 'users.id')
                ->where('role', '=', 'executive')
                ->where('status', '!=', 'deleted')
                ->where('executive_manager_relations.manager_id', Auth::guard('manager')->user()->id);
        if (isset($post['name']) && !empty($post['name'])) {
            $user->where('contact_name', 'like', '%' . $post['name'] . '%');
        }
        return $user->orderBy('users.id', 'desc')->get();
    }

}
