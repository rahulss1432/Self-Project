<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;

class UserProfile extends Model {
    /*
     * relation with user table by user_id
     */

    public function user() {
        return $this->belongsTo('App\Http\Models\User', 'user_id');
    }

    // api side
    public static function getProfileDetail($user_id) {
        $profile = UserProfile::where(['user_id' => $user_id])->first();
        if (!empty($profile)) {
            return $profile;
        }return false;
    }

}
