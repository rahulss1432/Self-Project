<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class AdminContact extends Model {

    public static function addAdminContact($request){
        $contact = new AdminContact();
        $contact->name = $request->name;
        $contact->business_name = $request->business_name;
        $contact->phone_no = $request->phone_no;
        $contact->email = $request->email;
        $contact->message = $request->message;
        if($contact->save()){
            return true;
        }
        return false;
    }
}
