<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class Bank extends Model {

    public static function getBankList() {
        $lists = Bank::all();
        return $lists;
    }

    public static function getBankByDucument($id) {
        $lists = Bank::where('id', $id)->first();
        return $lists;
    }

    public static function getAllBankList($request) {
        $lists = Bank::orderBy('id', 'desc');
        if (isset($request['name']) && !empty($request['name'])) {
            $lists->where('name', 'like', '%' . $request['name'] . '%');
        }
        $result = $lists->get();
        return $result;
    }

    public static function bankDelete($id) {
        try {
            Bank::where('id', $id)->delete();
            return Response::json(['success' => true, 'message' => \Config::get('constants.bank_deleted')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function updateBank($request) {
        try {
            $id = $request->bankId;
            $model = Bank::where('id', $id)->first();
            $model->waiting_time = $request['waiting_time'];
            $model->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.bank_update')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function activeInactiveBank($id) {
        $model = Bank::where('id', $id)->first();
        if ($model->status == 'active') {
            $model->status = 'inactive';
        } else {
            $model->status = 'active';
        }
        if ($model->save()) {
            return $model->status;
        }
    }

    public static function getbankNameById($bank_id){
        $bank = Bank::where(['id'=>$bank_id])->first();
        return (!empty($bank))?$bank['name']:'';     
    }
}
