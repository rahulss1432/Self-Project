<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use App\Http\Models\User;
use App\Http\Models\ExecutiveCategory;
use JWTAuth;

class CallRequest extends Model {
    /*
     * relation with user table by customer_id
     */

    public function customerDetail() {
        return $this->belongsTo('App\Http\Models\User', 'customer_id');
    }

    /*
     * relation with user table by executive_id
     */

    public function executiveDetail() {
        return $this->belongsTo('App\Http\Models\User', 'executive_id');
    }

    /*
     * relation with category table by category_id
     */

    public function BankCategory() {
        return $this->belongsTo('App\Http\Models\BankingCategory', 'category_id');
    }

    /*
     * relation with user profile table by customer_id
     */

    public function UserProfile() {
        return $this->belongsTo('App\Http\Models\UserProfile', 'customer_id', 'user_id');
    }

    /*
     * relation with rating table by customer_id
     */

    public function customerRating() {
        return $this->belongsTo('App\Http\Models\Rating', 'customer_id', 'customer_id');
    }

    /*
     * get resolved call request by executive id
     */

    public static function getResolveCallRequestByExecutive($executive_id, $callFrom) {
        $lists = CallRequest::where('executive_id', '=', $executive_id)->where('status', '=', 'resolved');
        if ($callFrom == 'count') {
            return $lists->get()->count();
        } else {
            return $lists->paginate(10);
        }
    }

    /*
     * get pending call request by executive id
     */

    public static function getPendingCallRequestByExecutive($executive_id, $callFrom) {
        $lists = CallRequest::where('executive_id', '=', $executive_id)->where('status', '=', 'pending');
        if ($callFrom == 'count') {
            return $lists->get()->count();
        } else {
            return $lists->paginate(10);
        }
    }

    /*
     * Function for get count of all merchant request rised by manager id.
     */

    public static function getAllRequestByManager($id) {
        return CallRequest::where('executive_id', '=', $id)->where('status', '=', 'resolved')->count();
    }

//api side for linked history
    public static function getLinkerHistory() {
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if (!empty($user)) {
            if ($user->role == 'customer') {
                $lists = CallRequest::where(['customer_id' => $user->id])->paginate(10);
            } else {
                $lists = CallRequest::where(['executive_id' => $user->id])->paginate(10);
            }
            if (!empty($lists) && count($lists) > 0) {
                foreach ($lists as $list) {
                    $executive = User::where(['id' => $list->executive_id])->first();
                    $customer = User::where(['id' => $list->customer_id])->first();
                    if ($user->role == 'customer') {
                        $list->executive_name = $executive['first_name'] . ' ' . $executive['last_name'];
                        $list->executive_profile = \App\Common\Utility::checkExecutiveImage($executive['profile_image']);
                        $list->executive_bank = Bank::getbankNameById($executive['bank_id']);
                        $list->bank_category = ExecutiveCategory::getExecutiveCategoryName($list['category_id']);
                    } else {
                        $list->customer_name = $customer['first_name'] . ' ' . $customer['last_name'];
                        $list->customer_profile = \App\Common\Utility::checkProfileImage($customer['profile_image']);
                        $list->customer_bank = Bank::getbankNameById($customer['bank_id']);
                        $list->bank_category = ExecutiveCategory::getExecutiveCategoryName($list['category_id']);
                    }
                }
                return $lists;
            }return false;
        }
    }

// history detail
    public static function getHistoryDetail($get) {

        $call_history = CallRequest::where(['id' => $get['request_id']])->first();
        if (!empty($call_history)) {
            $executive = User::where(['id' => $call_history->executive_id])->first();
            $customer = User::where(['id' => $call_history->customer_id])->first();
            $call_history->customer_name = $customer['first_name'] . ' ' . $customer['last_name'];
            $call_history->customer_profile = \App\Common\Utility::checkProfileImage($customer['profile_image']);
            $call_history->customer_bank = Bank::getbankNameById($customer['bank_id']);
            $call_history->bank_category = ExecutiveCategory::getExecutiveCategoryName($call_history['category_id']);
            return $call_history;
        }return false;
    }

    /*
     * get all merchant call request history
     */

    public static function getAllMerchantRequestHistory($post, $callFrom) {
        $merchantRequest = CallRequest::select('call_requests.*')
                ->join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id');
        if ($callFrom == 'manager') {
            $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if ($callFrom == 'request_count_manager') {
            return $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id)->count();
        }
        if (isset($post['request_date']) && !empty($post['request_date'])) {
            $merchantRequest->whereDate('call_requests.created_at', getDBdateFormat($post['request_date']));
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $merchantRequest->where('call_requests.category_id', $post['category_id']);
        }
        if (isset($post['executive_id']) && !empty($post['executive_id'])) {
            $merchantRequest->where('call_requests.executive_id', $post['executive_id']);
        }
        if (isset($post['bussiness_name']) && !empty($post['bussiness_name'])) {
            $merchantRequest->where('user_profiles.bussiness_name', 'like', '%' . $post['bussiness_name'] . '%');
        }
        if (isset($post['phone']) && !empty($post['phone'])) {
            $merchantRequest->where('users.phone_number', 'like', '%' . $post['phone'] . '%');
        }

        return $merchantRequest->get();
    }

    /*
     * get merchant call request history by id
     */

    public static function getCallRequestsById($id) {
        return CallRequest::where('id', $id)->first();
    }

    /*
     * update call request
     */

    public static function updateCallRequests($post) {
        try {
            $requestModel = CallRequest::where('id', $post['request_id'])->first();
            $requestModel->status = $post['status'];
            $requestModel->category_id = $post['category_id'];
            $requestModel->notes = $post['notes'];
            $requestModel->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.request_updated')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function getCallRequestList($post, $userType) {
        $callRequest = CallRequest::select('call_requests.*')
                ->join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id');
        if ($userType == 'manager') {
            $callRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if (isset($post['merchant_number']) && !empty($post['merchant_number'])) {
            $callRequest->where('user_profiles.merchant_number', 'like', '%' . $post['merchant_number'] . '%');
        }
        if (isset($post['se_assigned']) && !empty($post['se_assigned'])) {
            $callRequest->where('call_requests.executive_id', $post['se_assigned']);
        }
        if (isset($post['business_name']) && !empty($post['business_name'])) {
            $callRequest->where('user_profiles.bussiness_name', 'like', '%' . $post['business_name'] . '%');
        }
        if (isset($post['date_of_call']) && !empty($post['date_of_call'])) {
            $callRequest->whereDate('call_requests.created_at', getDBdateFormat($post['date_of_call']));
        }
        return $callRequest->get();
    }

    public static function getMerchantRequestList($post) {
        $merchantRequest = CallRequest::select('call_requests.*')
                ->join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                ->where('call_requests.customer_id', '=', $post['user_id']);
//        if ($userType == 'manager') {
//            $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
//        }
        if (isset($post['name']) && !empty($post['name'])) {
            $merchantRequest->where('users.contact_name', 'like', '%' . $post['name'] . '%');
        }
        if (isset($post['generate_date']) && !empty($post['generate_date'])) {
            $merchantRequest->whereDate('call_requests.created_at', getDBdateFormat($post['generate_date']));
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $merchantRequest->where('call_requests.category_id', $post['category_id']);
        }
        if (isset($post['executive_id']) && !empty($post['executive_id'])) {
            $merchantRequest->where('call_requests.executive_id', $post['executive_id']);
        }

        return $merchantRequest->get();
    }

    /*
     * get executives linked merchant notes history by executive and merchant id
     */

    public static function getMerchantLinkedNotesHistoryByExecutive($executiveId, $merchantId) {
        return CallRequest::where(['executive_id' => $executiveId, 'customer_id' => $merchantId])->paginate(10);
    }

    /* update call request by executve
     */

    public static function updateCallRequestsExecutive($post) {
        try {
            $requestModel = CallRequest::where('id', $post['request_id'])->first();
            $requestModel->status = $post['status'];
            if ($post['status'] == "pending") {
                $requestModel->notify_type = $post['notify_type'];
                if ($post['notify_type'] == "selected_date") {
                    $requestModel->notify_date = getDBdateFormat($post['notify_date']);
                    $requestModel->notify_date_time = date('H:i:s', strtotime($post['notify_date_time']));
                    $requestModel->today_in_time = "";
                } elseif ($post['notify_type'] == "today") {
                    $requestModel->today_in_time = $post['today_in_time'];
                    $requestModel->notify_date = null;
                    $requestModel->notify_date_time = "";
                } else {
                    $requestModel->today_in_time = "";
                    $requestModel->notify_date = null;
                    $requestModel->notify_date_time = "";
                }
            } else {
                $requestModel->notify_type = "";
                $requestModel->today_in_time = "";
                $requestModel->notify_date = null;
                $requestModel->notify_date_time = "";
            }
            $requestModel->category_id = $post['category_id'];
            $requestModel->executive_id = $post['executive_id'];
            $requestModel->notes = $post['notes'];
            $requestModel->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.request_updated')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
