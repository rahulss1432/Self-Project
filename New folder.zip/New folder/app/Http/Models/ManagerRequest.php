<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\Http\Models\User;
use App\Http\Models\Bank;

class ManagerRequest extends Model {

    public static function getManagerList($request) {
        $lists = ManagerRequest::orderBy('id', 'desc');
        if (isset($request['name']) && !empty($request['name'])) {
            $lists->where(DB::raw('CONCAT(first_name," ",last_name)'), 'like', '%' . $request['name'] . '%')
                    ->orWhere('email', 'like', '%' . $request['name'] . '%')
                    ->orWhere('company', 'like', '%' . $request['name'] . '%');
        }
        $result = $lists->get();
        return $result;
    }

    public static function addManagerByAdmin($request) {
        $model = new User();
        $generateNumber = str_random(8);
        $model->first_name = $request['first_name'];
        $model->last_name = $request['last_name'];
        $model->email = $request['email'];
        $model->phone_number = $request['phone'];
        $allBanks = Bank::where('name', $request['company'])->first();
        if ($allBanks == null) {
            $bankModel = new Bank();
            $bankModel->name = $request['company'];
            if ($bankModel->save()) {
                $model->bank_id = $bankModel->id;
            }
        } else {
            $model->bank_id = $allBanks->id;
        }
        $company = explode(' ', $request['company']);
        $data1 = strtolower($company[0]);
        $model->password = bcrypt($generateNumber);
        $model->password_base64 = base64_encode($generateNumber);
        $model->manager_type = $request['manager_type'];
        $model->role = 'manager';
        $model->created_by = Auth()->guard('admin')->user()->id;
        $model->status = "active";
        if ($model->save()) {
            $model->username = strtolower($request['first_name']) . $data1 . $model->id;
            $model->save();
            ManagerRequest::where('id', $request['managerId'])->delete();
            $data = [];
            $data['name'] = $model->first_name . ' ' . $model->last_name;
            $data['username'] = $model->username;
            $data['email'] = $model->email;
            $data['password'] = $generateNumber;
            $data['subject'] = 'User Credentials';
            $data['request'] = 'user_mail';
            $mail = sendMail($data);
            return true;
        } else {
            return false;
        }
    }

}
