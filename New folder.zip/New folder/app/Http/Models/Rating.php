<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use JWTAuth;

class Rating extends Model {
    
    public static function rateToExecutive($post){
        
        $rating = new Rating();
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if (!empty($user)) {
            $rating->request_id = $post['request_id'];
            $rating->customer_id = $user->id;
            $rating->executive_id = $post['executive_id'];
            $rating->behaviour_rating = $post['executive_rating'];
            $rating->waiting_time_rating = $post['waiting_rating'];
            $rating->overall_rating = $post['overall_rating'];
            $rating->review = $post['review'];
            if ($rating->save()) {
                return true;
            }
        }
        return false;
    }
}
