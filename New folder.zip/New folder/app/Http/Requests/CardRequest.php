<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CardRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'card_no' => 'required|digits_between:16,16|numeric',
            'ccExpiryMonth' => 'required|digits_between:2,2|numeric',
            'ccExpiryYear' => 'required|digits_between:4,4|numeric',         
            'cvvNumber' => 'required|digits_between:3,3|numeric'
            
        ];
    }
    public function messages()
    {
        return [
            'card_no.digits_between' => 'Accept only 16 digit number.',
            'ccExpiryMonth.digits_between' => 'Accept only 2 digit number.', 
            'ccExpiryYear.digits_between' => 'Accept only 4 digit number.', 
            'cvvNumber.digits_between' => 'Accept only 3 digit number.', 
        ];
    }
}
