<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ContactUsRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'first_name' => 'required|alpha_dash|max:20',
            'last_name' => 'required|alpha_dash|max:20',
            'email' => 'required|string|check_email_format',
            'phone_number' => 'required|phone_format',
            'message' => 'required|string|remove_spaces|max:500',
        ];
    }

    public function messages() {
        return [
            'email.check_email_format' => 'Please provide valid email',
            'message.remove_spaces' => 'Only space not allowed',
            'phone_number.phone_format' => 'The phone number field is invalid.',
        ];
    }

}
