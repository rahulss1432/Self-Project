<?php

namespace App\Http\Requests\Manager;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddDocumentRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return
                [
                    'title' => 'required|string|max:150',
                    'pdf_upload' => 'required_if:document_type,upload_pdf|mimes:pdf',
                    'category_id' => 'required',                    
        ];
    }

    public function messages() {
        return
                [
                    'category_id.required' => 'The category field is required.',
                    'pdf_upload.required_if' => 'The pdf is required.'
        ];
    }

}
