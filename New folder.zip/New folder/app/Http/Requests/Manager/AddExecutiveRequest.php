<?php

namespace App\Http\Requests\Manager;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddExecutiveRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {

        return[
            'username' => 'required|max:30|without_spaces|unique:users,username',
            'password' => 'required|min:6|max:20',
            'contact_name' => 'required|max:30',
            'executive_number' => 'required',
            'category' => 'required',
            'company' => 'required|max:30',
            'phone' => 'required|min:10|phone_format',
            'city' => 'required|max:100',
            'state' => 'required|max:100',
            'email' => 'required|email|max:50|check_email_format|unique:users,email,',
            'supervisor_email' => 'nullable|email|max:50|check_email_format',
            'supervisor_phone' => 'nullable|phone_format|min:10',
        ];
    }

    public function messages() {
        return[
            'email.check_email_format' => 'The email format is not valid.',
            'phone.phone_format' => 'The mobile number is not valid.',
            'category.required' => 'The category field is required.',
            'username.without_spaces' => 'The username does contain spaces.',
            'supervisor_email.check_email_format' => 'The supervisor email format is not valid.',
            'supervisor_phone.phone_format' => 'The supervisor phone format is not valid.',
        ];
    }

}
