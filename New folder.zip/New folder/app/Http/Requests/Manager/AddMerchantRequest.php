<?php

namespace App\Http\Requests\Manager;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddMerchantRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return
                [
                    'contact_name' => 'required|max:30',
                    'password' => 'required|min:6|max:20',
                    'username' => 'required|max:30|without_spaces|unique:users,username',
                    'merchant_number' => 'required',
                    'terminal_model' => 'required',
                    'bussiness_name' => 'required|min:4|max:30',
                    'bussiness_address' => 'required|min:4|max:30',
                    'product' => 'required|min:4|max:30',
                    'phone' => 'required|min:10|phone_format',
                    'email' => 'required|email|max:50|check_email_format|unique:users,email,',
                    'city' => 'required|max:100',
                    'state' => 'required|max:100',
        ];
    }

    public function messages() {
        return[
            'email.check_email_format' => 'The email format is not valid',
            'phone.phone_format' => 'The mobile number is not valid',
            'username.without_spaces' => 'The username does contain spaces.',
        ];
    }

}
