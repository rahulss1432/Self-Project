<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddManagerRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return
                [
                    'first_name' => 'required|string|max:50',
                    'last_name' => 'required|string|max:50',
                    'email' => 'required|email|unique:users,email',
                    'phone' => 'required|min:10|phone_format',
                    'company' => 'required',
                    'manager_type' => 'required',
                    'image_file' => 'required|mimes:jpeg,png,jpg,svg|max:2048',
        ];
    }

    public function messages() {
        return
                [
                    'phone.phone_format' => 'The phone is not valid.',
        ];
    }

}
