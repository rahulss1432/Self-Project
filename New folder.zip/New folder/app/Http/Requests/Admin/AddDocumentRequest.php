<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddDocumentRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return
                [
                    'title' => 'required|string|max:150',
                    'bank_id' => 'required',
                    'category_id' => 'required',
                    'pdf_upload' => 'required_if:document_type,upload_pdf|mimes:pdf',
        ];
    }

    public function messages() {
        return
                [
                    'bank_id.required' => 'The bank field is required.',
                    'category_id.required' => 'The category field is required.',
                    'pdf_upload.required_if' => 'The pdf is required.'
        ];
    }

}
