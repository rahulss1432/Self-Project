<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class EditProfileRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'email' => 'required|email|max:50|check_email_format|unique:users,email,' . $this->id,
        ];
    }

    public function messages() {
        return [
            'email.check_email_format' => 'The email format is not valid.',
            'email.check_matched_email' => 'The email already taken by other user.',
        ];
    }

}
