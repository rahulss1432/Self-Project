<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class EditExecutiveRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return[
            'contact_name' => 'required|max:30',
            'company' => 'required|max:30',
            'category' => 'required',
            'manager_id' => 'required',
            'phone' => 'required|min:10|phone_format',
            'email' => 'required|email|max:50|check_email_format|unique:users,email,' . $this->user_id,
            'city' => 'required|max:100',
            'state' => 'required|max:100',
            'bussiness_address' => 'required|max:100',
            'supervisor_email' => 'nullable|email|max:50|check_email_format',
            'supervisor_phone' => 'nullable|phone_format|min:10',
        ];
    }

    public function messages() {
        return[
            'email.check_email_format' => 'The email format is not valid.',
            'phone.phone_format' => 'The mobile number is not valid.',
            'category.required' => 'The category field is required.',
            'manager_id.required' => 'The manager field is required.',
            'supervisor_email.check_email_format' => 'The supervisor email format is not valid.',
            'supervisor_phone.phone_format' => 'The supervisor phone format is not valid.',
        ];
    }

}
