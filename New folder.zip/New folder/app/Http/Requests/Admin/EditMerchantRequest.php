<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class EditMerchantRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return
                [
                    'contact_name' => 'required|max:30',
                    'bussiness_name' => 'required|min:4|max:30',
                    'phone' => 'required|min:10|phone_format',
                    'email' => 'required|email|max:50|check_email_format|unique:users,email,' . $this->user_id,
                    'product' => 'required|min:4|max:30',
                    'machine_model' => 'required|max:100',
                    'terminal_model' => 'required|max:100',
                    'bussiness_address' => 'required|min:4|max:30',
                    'city' => 'required|max:100',
                    'state' => 'required|max:100',
        ];
    }

    public function messages() {
        return[
            'email.check_email_format' => 'The email format is not valid',
            'phone.phone_format' => 'The mobile number is not valid',
        ];
    }

}
