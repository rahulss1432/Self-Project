<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SubscriptionValidation extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        if (!empty($this->id)) {
            return [
                'name' => 'required|regex:/^[a-zA-Z0-9.@&][\sa-zA-Z0-9.@&]*$/|max:50',
                'renewal_cycle' => 'required',
                'amount' => 'required|numeric|min:1',
                'plan_space' => 'required|integer|min:1|is_subscribed',
                    //            'description[]' => 'nullable|remove_spaces',
            ];
        } else {
            return [
                'name' => 'required|regex:/^[a-zA-Z0-9.@&][\sa-zA-Z0-9.@&]*$/|max:50',
                'renewal_cycle' => 'required',
                'amount' => 'required|numeric|min:1',
                'plan_space' => 'required|integer|min:1',
                    //            'description[]' => 'nullable|remove_spaces',
            ];
        }
    }

    public function messages() {
        if (!empty($this->id)) {
            return [
                //'name.required' =>'Space not allowed for first letter.',
//            'description.required' => 'The only Spaces are not allowed.',
                'plan_space.is_subscribed' => 'You can not change the plan space because the plan has been subscribed by users.',
            ];
        } else {
            return [
                    //'name.required' =>'Space not allowed for first letter.',
//            'description.required' => 'The only Spaces are not allowed.',
            ];
        }
    }

}
