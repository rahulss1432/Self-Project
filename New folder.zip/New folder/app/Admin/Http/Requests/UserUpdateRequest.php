<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserUpdateRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'first_name' => 'required_if:role,coach|alpha_dash|min:2|max:30',
            'last_name' => 'required_if:role,coach|alpha_dash|min:2|max:30',
            'first_name' => 'required_if:role,player|alpha_dash|min:2|max:30',
            'last_name' => 'required_if:role,player|alpha_dash|min:2|max:30',
            'phone_number' => 'required|phone_format',
            'country_id' => 'required',
            'state_id' => 'required',
            'city' => "required|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/|max:100",
//            'zip_code' => 'required|regex:/^[a-zA-Z0-9]+$/u|max:6|min:1',
            'zip_code' => 'required|get_latlong_byzip|max:10',
            'address_line_1' => "required|string|max:100",
            'institute_type' => "required_if:role,team|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/|max:100",
            'full_name' => 'required_if:role,team|remove_spaces|max:50',
        ];
    }

    public function messages() {
        return [
            'zip_code.get_latlong_byzip' => 'The zip code is invalid.',
            'phone_number.required' => 'The mobile number field is required.',
            'phone_number.phone_format' => 'The phone number field is invalid.',
            'full_name.remove_spaces' => 'Only space not allowed.',
            'full_name.required_if' => 'The team and organization title field is required.',
            'address_line_1.required' => 'The address field is required.',
        ];
    }

}
