<?php

namespace App\Admin\Http\Requests;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddSubCategoryRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'subcategory_name' => 'required',
        ];
    }

    public function messages() {
        return [
            'subcategory_name.required' => 'The sub category field is required.',
        ];
    }

}
