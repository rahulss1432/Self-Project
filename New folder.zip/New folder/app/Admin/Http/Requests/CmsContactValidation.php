<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CmsContactValidation extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'mobile_number' => 'nullable|numeric',
            'email' => 'nullable|email',
            'facebook_url' => 'nullable|url',
            'twitter_url' => 'nullable|url',
            'instagram_url' => 'nullable|url',
            'address' => 'nullable|max:100',
            'copyright' => 'nullable|max:100|regex:/^[a-zA-Z0-9.@&][\sa-zA-Z0-9.@&]*$/',
        ];
    }

//    public function messages() {
//        return [
//            'address.remove_spaces' => 'Only space not allowed.',
//            'copyright.remove_spaces' => 'Only space not allowed.',
//        ];
//    }

}
