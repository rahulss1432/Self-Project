<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TeamAddRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        if (!empty($this->id)) {
            return [
                'email' => 'required|check_email_format|unique:users',
                'phone_number' => 'required|phone_format',
                'country_id' => 'required',
                'state_id' => 'required',
                'city' => "required|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/|max:100",                
//                'zip_code' => 'required|regex:/^[a-zA-Z0-9]+$/u|max:6|min:1',  
                'zip_code' => 'required|get_latlong_byzip|max:10',
                'address_line_1' => "required|string|max:100",
                'institute_type' => "required|string|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/|max:100",
                'full_name' => "required|remove_spaces|max:50",
            ];
        } else {
            return [
                'email' => 'required|check_email_format|unique:users',
                'phone_number' => 'required|phone_format',
                'country_id' => 'required',
                'state_id' => 'required',
                'plan_id' => 'required',
                'signup_type' => 'required',
                'city' => "required|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/|max:100",                
//                'zip_code' => 'required|regex:/^[a-zA-Z0-9]+$/u|max:6|min:1',   
                'zip_code' => 'required|get_latlong_byzip|max:10',
                'address_line_1' => "required|string|max:100",
                'institute_type' => "required|string|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/|max:100",
                'full_name' => "required|remove_spaces|max:50",
            ];
        }
    }

    public function messages() {
        if (!empty($this->id)) {
            return [
                'phone_number.required' => 'The mobile number field is required.',
                'phone_number.phone_format' => 'The phone number field is invalid.',
                'email.check_email_format' => 'Please fill valid email.',
                'zip_code.get_latlong_byzip' => 'The zip code is invalid.',
                'full_name.remove_spaces' => 'Only space not allowed.',
                'address_line_1.required' => 'The address field is required.',
            ];
        } else {
            return [
                'plan_id.required' => 'The plan field is required.',
                'signup_type.required' => 'The payment method field is required.',
                'phone_number.required' => 'The mobile number field is required.',
                'phone_number.phone_format' => 'The phone number field is invalid.',
                'email.check_email_format' => 'Please fill valid email.',
                'zip_code.get_latlong_byzip' => 'The zip code is invalid.',
                'institute_type.remove_spaces' => 'Only space not allowed.',
                'full_name.remove_spaces' => 'Only space not allowed.',
                'address_line_1.required' => 'The address field is required.',
            ];
        }
    }

}
