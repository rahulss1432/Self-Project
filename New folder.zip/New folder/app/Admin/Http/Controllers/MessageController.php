<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\MessageRepository;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class MessageController extends Controller {

    public function __construct(MessageRepository $message) {
        $this->message = $message;
    }

    /**
     * Display a listing of the messages.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin::message.all-chats');
    }

    /**
     * Display a listing of the messages.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllMessages(Request $request) {
        $messages = $this->message->getAllMessages($request);
        $html = View::make('admin::ajax-content.message._chat-list', ['messages' => $messages])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * Change message status
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function changeMessageStatus(Request $request) {
        return $this->message->changeMessageStatus($request);
    }

    /*
     * Delete Messages.
     */

    public function deleteMessages($id) {
        return $this->message->deleteMessages($id);
    }

    /**
     * Display a listing of the flagged terms.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function getAllFlaggedTerms(Request $request) {
        $html = View::make('admin::ajax-content.message._flagged-terms')->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

}
