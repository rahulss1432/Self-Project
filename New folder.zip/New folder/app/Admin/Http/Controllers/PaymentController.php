<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\PaymentRepository;

class PaymentController extends Controller
{
    
     public function __construct(PaymentRepository $payementRepository) {
        $this->paymentRepository = $payementRepository;
     }

    /*
     * list all payments
     */
    public function index()
    {
        return View('admin::manage-payment.payments');
    }

    /*
     * ajax manage payments data
     */
    function ajaxPaymentsList(Request $request) {
        try {
            $paymentList = $this->paymentRepository->getTransactionList($request);
            $html = View::make('admin::ajax-content.manage-payments._payments-list', ['paymentList' => $paymentList])->render();
            return Response::json(['html' => $html]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }

}
