<?php

namespace App\Admin\Http\Controllers;

use App\Admin\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Admin\Http\Requests\UserValidation;
use App\Admin\Http\Requests\ForgotRequest;
use App\Admin\Http\Requests\ResetPasswordValidation;

class AuthController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Login Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles authenticating users for the application and
      | redirecting them to your home screen. The controller uses a trait
      | to conveniently provide its functionality to your applications.
      |
     */

use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = 'admin/dashboard';
    protected $guard = 'admin';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Handle a login request to the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response
     */
    public function login(UserValidation $request) {
        $data = array();
        $data['status'] = 'active';
        $data['email'] = $request->email;
        $data['password'] = $request->password;
        $user = \App\User::where(['email' => $data['email']])->where(function($query) {
                    $query->where('role', 'admin')->orWhere('role', 'subadmin');
                })->first();
        if (!empty($user)) {
            if ($user->status == 'active') {
                if (Auth::guard($user->role)->attempt($data, $request->remember)) {
                    $request->session()->regenerate();
                    $request->session()->put('current-guard', $user->role);
                    $this->clearLoginAttempts($request);
                    return response()->json(['success' => true, 'message' => $user->role . ' login Successfully.', 'role' => $user->role]);
                }
            } else {
                return response()->json(['success' => false, 'message' => 'Your account has been deacivated by administrator.']);
            }
        }
        return response()->json(['success' => false, 'message' => 'These credentials do not match our records.']);
    }

    public function forgotPassword(ForgotRequest $request) {
        $data = array();
        $user = \App\User::where(['email' => $request->email])->where('role', '<>', 'player')->where('role', '<>', 'coach')->where('role', '<>', 'team')->first();
        if (!empty($user)) {
            $user->remember_token = generateRandomString(20);
            if ($user->save()) {
                $data['name'] = $user['full_name'];
                $data['request'] = 'admin_forgot_password';
                $data['email'] = $request->email;
                $data['link'] = url('/admin/reset-password/') . '/' . $user->remember_token;
                $data['subject'] = 'Forgot Password';
                $result = sendMail($data);
                if ($result) {
                    return response()->json(['success' => true, 'message' => 'Mail has been sent please check your mail.']);
                } else {
                    return response()->json(['success' => false, 'message' => 'Please try again.']);
                }
            } else {
                return response()->json(['error' => false, 'message' => 'Please try again.']);
            }
        } else {
            return response()->json(['error' => false, 'message' => 'This email id is not found in our records']);
        }
    }

    public function ResetPassword($token) {
        if (!empty($token)) {
            $user = \App\User::where(['remember_token' => $token])->where(function ($query) {
                        $query->where('role', 'admin')
                                ->orWhere('role', 'subadmin');
                    })->first();
            if (!empty($user)) {
                return view('admin::reset-password', ['resetToken' => $user->remember_token]);
            } else {
                if (!empty($token)) {
                    return redirect('/admin/login')->with('error_msg', 'Token has been expired.');
                }
                return redirect('/admin/login');
            }
        } else {
            return redirect('/admin/login');
        }
    }

    public function adminUpdatePassword(Request $request) {
        $post = $request->all();
        $model = \App\User::where(['remember_token' => $post['reset-token']])->first();
        if (!empty($model)) {
            $model->password = bcrypt($post['password']);
            $model->remember_token = '';
            $model->save();
            \App\User::where(['remember_token' => $post['reset-token']])->update(['remember_token' => '']);
            return response()->json(['success' => true, 'message' => 'Password updated successfully!']);
        }
        return response()->json(['success' => false, 'message' => 'Please try again']);
    }


    /**
     * Get the failed login response instance.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    protected function sendFailedLoginResponse(Request $request) {
        $errors = [$this->username() => trans('auth.failed')];
        if ($request->expectsJson()) {
            return response()->json($errors, 422);
        }
        return redirect()->back()->with('error_msg', 'These credentials do not match our records.');
    }

    /**
     * Get the login username to be used by the controller.
     *
     * @return string
     */
    public function username() {
        return 'email';
    }

    /**
     * Log the user out of the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function logout(Request $request) {
        $this->guard()->logout();
        $request->session()->invalidate();
        return redirect('admin/login');
    }

    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard() {
        return \Auth::guard(getAuthGuard());
    }

}
