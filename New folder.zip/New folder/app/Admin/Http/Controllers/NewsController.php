<?php

namespace App\Admin\Http\Controllers;

use File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\NewsRepository;
use Intervention\Image\ImageManagerStatic as Image;
use App\Admin\Http\Requests\AddNewsRequest;

class NewsController extends Controller {

    public function __construct(NewsRepository $newsRepository) {
        $this->newsRepository = $newsRepository;
    }

    /*
     * list all news
     */

    public function index() {
        return View('admin::news.manage-news');
    }

    /*
     * ajax manage news data
     */

    public function LoadNewsList(Request $request) {
        $post = $request->all();
        $newsData = $this->newsRepository->getAllNewsData($post);
        $html = View::make('admin::ajax-content.manage-news._news-list', ['newsData' => $newsData])->render();
        return Response::json(['html' => $html]);
    }

    /**
     * render add news page
     * @param Request $request
     * @return type
     */
    public function addnews(Request $request) {
        return View('admin::news.add-news');
    }

    /**
     * save news
     * @param Request $request
     * @return type
     */
    public function save(Request $request) {
        return $this->newsRepository->save($request);
    }

    /**
     * upload news media.
     * @param Request $request
     */
    public function uploadNewsMedia(Request $request) {
        $imagePath = public_path() . '/uploads/temp';
        $imageThumbPath = public_path() . '/uploads/temp/thumb';
        $ffmpeg = \Config::get('constants.ffmpeg_path');
        $ret = array();
        if (!is_dir($imagePath)) {
            File::makeDirectory($imagePath, $mode = 0777, true, true);
        }
        if (!is_dir($imageThumbPath)) {
            File::makeDirectory($imageThumbPath, $mode = 0777, true, true);
        }
        $image = '';
        if ($request->hasFile('myfile')) {
            $photo = $request->file('myfile');
            $newsImage = time() . $photo->getClientOriginalName();
            $destinationPath = $imagePath;
            $photo->move($destinationPath, $newsImage);
            $image = $newsImage;
            $size = $request->file('myfile')->getClientSize();
            $photo = $request->file('myfile');
            $ext = pathinfo($image, PATHINFO_EXTENSION);
            if ($ext == 'mp4') {
                if ($size < (getFileSize('video'))) {
                    $video = public_path() . '/uploads/temp/' . $newsImage;
                    $filename = pathinfo($newsImage, PATHINFO_FILENAME);
                    $image = public_path() . '/uploads/temp/thumb/' . $filename . '.jpg';
                    $cmd = "$ffmpeg -i $video  -ss 00:00:03 -vframes 1  $image 2>&1";
                    exec($cmd, $output);
                    $image_resize = Image::make($image);
                    $image_resize->resize(420, 331);
                    $image_resize->save($image);
                    array_push($ret, 'uploadvideo===' . $filename . '.jpg');
                } else {
                    array_push($ret, 'failedimage-' . $newsImage);
                }
            } else {
                if ($size < (getFileSize('image'))) {
                    copy($imagePath . '/' . $image, public_path() . '/uploads/temp/thumb/' . $newsImage);
                    $image = public_path() . '/uploads/temp/thumb/' . $newsImage;
                    $image_resize = Image::make($image);
                    $image_resize->resize(420, 331);
                    $image_resize->save($image);
                    array_push($ret, 'uploadphoto===' . $newsImage);
                } else {
                    array_push($ret, 'failedimage-' . $newsImage);
                }
            }
            echo json_encode($ret);
        }
    }

    /*
     * get edit news form
     */

    public function editNews($id) {
        $getNews = $this->newsRepository->getNewsById(base64_decode($id));
        return View('admin::news.edit-news', ['getNews' => $getNews]);
    }

    /*
     * update news 
     */

    public function update(Request $request) {
        return $this->newsRepository->update($request);
    }

    /*
     * update news 
     */

    public function updateStatus(Request $request) {
        return $this->newsRepository->updateStatus($request);
    }

    /*
     * View news 
     */

    public function view($id) {
        $getNews = $this->newsRepository->getNewsById(base64_decode($id));
        return View('admin::news.view-news', ['getNews' => $getNews]);
    }

}
