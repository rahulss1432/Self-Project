<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Repositories\Admin\UserRepository;

class ContractorController extends Controller {

    public function __construct(UserRepository $user) {
        $this->user = $user;
    }

    /**
     * Display a listing of the manage contractors.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index() {
        return view('admin::manage-contractor.index');
    }

    /*
     * created 26-feb-2019
     * load contractor user listing 
     * @param type $request
     */

    public function loadContractorsList(Request $request) {
        $getContractors = $this->user->getContractorList($request->all());
        $html = View::make('admin::ajax-content.contractors._contractors-list', ['getContractors' => $getContractors])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /*
     * created 26-feb-2019
     * load contractor user listing 
     * @param type $request
     */

    public function loadContractorDetails($id) {
        $getContractors = $this->user->getUserById($id);
        $html = View::make('admin::ajax-content.contractors._load-details', ['getContractors' => $getContractors])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /*
     * created 26-feb-2019
     * update contractor status
     * @param type $request
     */

    public function updateContractorStatus(Request $request) {
        return $this->user->updateCategoryStatus($request);
    }

    /** 26-feb-2019
     * function using for delet contractor user
     * @param type $id
     */
    public function removeContractor($id) {
        return $this->user->removeContractor($id);
    }

    /**
     * Display a listing of the pending contractors.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function pendingContractors() {
        return view('admin::manage-contractor.pending-contractors');
    }

    /*
     * created 26-feb-2019
     * load pending contractor listing 
     * @param type $request
     */

    public function loadPendingContractorsList(Request $request) {
        $getContractors = $this->user->getPendingContractorList($request->all());
        $html = View::make('admin::ajax-content.contractors._pending-contractors', ['getContractors' => $getContractors])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

}
