<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\AdminRepository;

class NotificationController extends Controller {

    public function __construct(AdminRepository $adminRepository) {
        $this->adminRepository = $adminRepository;
    }

    /**
     * get load notification list in admin
     */
    function manageNotificationList() {
        $notification = $this->adminRepository->getNotificationList();
        $html = View::make('admin::ajax-content.manage-notification._load_notifications-list', ['notification' => $notification])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * update load notification list in admin
     */
    function updateReadNotification() {
        $userId = \Illuminate\Support\Facades\Auth::guard(getAuthGuard())->user()->id;
        return updateNotificationList($userId);
    }

    /**
     * get load notification list count in admin
     */
    public function loadNotificationCount() {
        $userId = \Illuminate\Support\Facades\Auth::guard(getAuthGuard())->user()->id;
        $notificationCount = loadNotificationCount($userId);
        return Response::json(['success' => true, 'data' => $notificationCount]);
    }

    /**
     * get notification in admin
     */
    public function notifications() {
        return view('admin::notification');
    }

    /**
     * get notification list in admin
     */
    function notificationList() {
        $notification = $this->adminRepository->getAllNotificationList();
        $html = View::make('admin::ajax-content.manage-notification._notifications-list', ['notification' => $notification])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

}
