<?php

namespace App\Admin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Controller;
use App\Repositories\Admin\SettingsRepository;
use App\Admin\Http\Requests\TestimonialValidation;
use Illuminate\Support\Facades\Validator;
use App\Admin\Http\Requests\CmsContactValidation;

class CmsController extends Controller {

    public function __construct(SettingsRepository $setting) {
        $this->adminSettings = $setting;
    }

    /*
     * list all cms
     */

    public function index(Request $request) {
        $tab = '';
        if (!empty($request->tab)) {
            $tab = $request->tab;
        }
        return View('admin::cms.cms', ['tab' => $tab]);
    }

    /*
     * ajax manage user-testimonials-list data
     */

    function ajaxUserTestimonialsList(Request $request) {
        $testimonialList = $this->adminSettings->getTestimonialList();
        $html = View::make('admin::ajax-content/cms/_user-testimonials-list', ['testimonialList' => $testimonialList])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * ajax manage user-testimonials-list data
     */

    function ajaxCmsAdd(Request $request) {
        $html = View::make('admin::ajax-content/cms/_cms-add')->render();
        return Response::json(['html' => $html]);
    }

    /*
     * ajax manage user-testimonials-list data
     */

    function ajaxCmsContact(Request $request) {
        $html = View::make('admin::ajax-content/cms/_cms-contact', ['settingValue' => $this->adminSettings])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * ajax manage user-testimonials-list data
     */

    function ajaxCmsAbout(Request $request) {
        $getvalue = $this->adminSettings->getSettingsValue($request->title);
        $html = View::make('admin::ajax-content/cms/_cms-about', ['title' => $request->title, 'value' => $getvalue])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function using for About and terms update
     */

    function updateAboutAndTerms(Request $request) {
        return $this->adminSettings->updateAboutAndTerms($request);
    }

    /*
     * function using for update contacts 
     */

    function updateContacts(CmsContactValidation $request) {
        return $this->adminSettings->updateContacts($request);
    }

    /*
     * function using for save Testimonial
     */

    function addTestimonial(TestimonialValidation $request) {
        $rules = array(
            'image' => 'nullable|max:2048|mimetypes:image/jpeg,image/png,image/jpg',
        );
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(['image_validation' => true, 'message' => 'The file must be an image']);
        }
        return $this->adminSettings->saveTestimonial($request);
    }

    /*
     * function using for update Testimonial
     */

    function updateTestimonial(Request $request) {
        return $this->adminSettings->updateTestimonial($request);
    }

    /*
     * function using for Remove Testimonial
     */

    function removeTestimonial($id) {
        return $this->adminSettings->removeTestimonial($id);
    }

    /*
     * function using for testimonial update form
     */

    function ajaxCmsUpdate($id) {
        $testimonial = $this->adminSettings->getUpdateTestimonial($id);
        $html = View::make('admin::ajax-content/cms/_cms-update', ['testimonial' => $testimonial])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function using for testimonial view
     */

    function ajaxCmsView($id) {
        $testimonial = $this->adminSettings->getUpdateTestimonial($id);
        $html = View::make('admin::ajax-content/cms/_cms-view', ['testimonial' => $testimonial])->render();
        return Response::json(['html' => $html]);
    }

}
