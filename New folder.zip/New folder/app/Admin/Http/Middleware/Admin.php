<?php

namespace App\Admin\Http\Middleware;

use Illuminate\Support\Facades\Auth;
use Closure;

class Admin {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = 'admin') {
        if (getAuthGuard() == 'admin' || getAuthGuard() == 'subadmin') {
            if (Auth::guard(getAuthGuard())->user()->status == 'inactive') {
                return redirect('admin/logout');
            }
            // check current role by guard
            $user = \App\User::find(Auth::guard(getAuthGuard())->user()->id);  // get current user object
            $side_tab = \Illuminate\Support\Facades\Request::segment(2);   // get url route by segment
            $permitted_routes = ['logout', 'dashboard', 'chartdetail', 'profile', 'profile-update', 'change-password', 'update-password', 'load-notification-list', 'load-notification-count', 'update-notification-list', 'notifications', 'notification-list', 'incident-list'];  // allow routes
            // check subadmin authorised routes 
            if (getAuthGuard() == 'subadmin' && !($user->hasMenu($side_tab)) && !in_array($side_tab, $permitted_routes)) {
                abort(401, 'You are not Authorised.');
            }
            $response = $next($request);
            return $response->header('Cache-Control', 'nocache, no-store, max-age=0, must-revalidate')
                            ->header('Pragma', 'no-cache')
                            ->header('Expires', '0');
        }
        return redirect('admin/login');
    }

}
