<?php

namespace App\Admin\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Request;
class AdminServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services. 
     *
     * @return void
     */
    /*
   
    */
    public function boot()
    {
        $this->loadViewsFrom(__DIR__.'/../Resources/Views','admin');
        $this->loadTranslationsFrom(__DIR__.'/../Resources/Lang', 'admin');
        
         Validator::extend('current_password_match', function ($attribute, $value, $parameters, $validator) {
            
            return Hash::check($value, Auth::guard(getAuthGuard())->user()->password);
        });
       
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register(RouteServiceProvider::class);
    }
    
    protected function loadViewsFrom($path, $namespace)
    {
        $this->app['view']->addNamespace('admin', base_path().'/app/Admin/resources/views');
    }

    protected function loadTranslationsFrom($path, $namespace)
    {
        $this->app['translator']->addNamespace($namespace, $path);
    }
}
