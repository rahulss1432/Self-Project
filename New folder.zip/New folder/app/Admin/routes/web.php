<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */
Route::group(['prefix' => 'admin', 'middleware' => 'guest'], function() {

    Route::get('/', function () {
        if (\Auth::guard('admin')->check()) {
            return redirect('admin/dashboard');
        }
        return view('admin::index');
    });

    Route::post('login', 'Auth\LoginController@login');
    Route::get('forgot-password', 'AdminController@forgotPassword');
    Route::post('send-forgot-email', 'AdminController@sendForgotEmail');
    Route::get('reset-password/{token}', 'AdminController@resetPassword');
    Route::post('reset-password', 'AdminController@reset');
});

Route::group(['prefix' => 'admin', 'middleware' => 'admin'], function() {
    Route::post('logout', 'Auth\LoginController@logout');
    // dashboard routes
    Route::get('/dashboard', 'DashboardController@index')->name('manage-dashboard');
    // manage user routes
    Route::get('/manage-user', 'UserController@index')->name('manage-user');
    Route::post('/load-user-list', 'UserController@getAllUsers');
    Route::get('/change-user-status', 'UserController@changeUserStatus');
    Route::get('/load-user-profile', 'UserController@loadUserProfile');
    // manage category routes
    Route::get('/manage-category', 'CategoryController@index')->name('manage-category');
    Route::post('/load-category-list', 'CategoryController@getAllCategories');
    Route::get('/change-category-status', 'CategoryController@changeCategoryStatus');
    Route::post('/add-category', 'CategoryController@addCategory');
    // manage sub category routes
    Route::get('/get-sub-category/{id}', 'CategoryController@getSubCategoryById')->name('manage-category');
    Route::post('/load-subcategory-list', 'CategoryController@getAllSubCategory');
    Route::get('/change-subcategory-status', 'CategoryController@changeSubCategoryStatus');
    Route::post('/add-subcategory', 'CategoryController@addSubCategory');
    // manage Notifications routes
    Route::get('/notifications', 'NotificationController@notifications')->name('notifications');
    Route::get('/notification-list', 'NotificationController@notificationList');
    Route::get('/load-notification-list', 'NotificationController@manageNotificationList');
    Route::get('/load-notification-count', 'NotificationController@loadNotificationCount');
    Route::post('/update-notification-list', 'NotificationController@updateReadNotification');
    // change password routes
    Route::get('/change-password', 'UserController@changePassword')->name('change-password');
    Route::post('/update-password', 'UserController@updatePassword');
    // manage payment transaction routes
    Route::get('/manage-payment', 'PaymentController@index')->name('manage-payment');
    Route::post('/load-payment-list', 'PaymentController@getAllPayments');
    // manage payment commission routes
    Route::get('/manage-commission', 'PaymentController@commission')->name('manage-commission');
    Route::get('/load-commission-list', 'PaymentController@getAllCommissions');
    // manage message and flagged terms routes
    Route::get('/manage-chat', 'MessageController@index')->name('manage-chat');
    Route::post('/load-chat-list', 'MessageController@getAllMessages');
    Route::get('/change-message-status', 'MessageController@changeMessageStatus');
    Route::get('/remove-message/{id}', 'MessageController@deleteMessages');
    Route::get('/load-flagged-terms-list', 'MessageController@getAllFlaggedTerms');
    // manage cms routes
    Route::get('/faq', 'CmsController@showFaq')->name('faq');
    Route::get('/load-faq-list', 'CmsController@getAllFaqs');
    Route::get('/add-faqs', 'CmsController@showAddFaqs')->name('faq');
    Route::post('/add-faqs', 'CmsController@addFaqs');
    Route::get('/remove-faq/{id}', 'CmsController@deleteFaqs');
    Route::get('/edit-faq/{id}', 'CmsController@showEditFaqs')->name('faq');
    Route::post('/edit-faqs', 'CmsController@editFaqs');
    Route::get('/cms', 'CmsController@showCms')->name('cms');
    Route::get('/load-cms-list', 'CmsController@getAllCms');
    Route::get('/edit-cms/{id}', 'CmsController@showEditCms')->name('cms');
    Route::post('/edit-cms', 'CmsController@editCms');

    /** manage contractor section route */
    Route::get('/manage-contractor', 'ContractorController@index')->name('manage-contractor');
    Route::post('/load-contractors-list', 'ContractorController@loadContractorsList');
    Route::get('/update-contractor-status', 'ContractorController@updateContractorStatus');
    Route::get('/remove-contractor/{id}', 'ContractorController@removeContractor');
    Route::get('/load-contractor-details/{id}', 'ContractorController@loadContractorDetails');
    /** pending contractor section route */
    Route::get('/pending-contractor', 'ContractorController@pendingContractors')->name('pending-contractor');
    Route::post('/load-pending-contractors-list', 'ContractorController@loadPendingContractorsList');
    Route::get('/load-contractor-details/{id}', 'ContractorController@loadContractorDetails');
});
