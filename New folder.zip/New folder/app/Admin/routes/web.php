<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */
Route::group(['prefix' => 'admin', 'middleware' => 'guest'], function() {
    Route::get('/', function () {
        return redirect('admin/login');
    });
    Route::get('login', function () {
        return view('admin::login');
    });
    Route::get('forgot', function () {
        return view('admin::forgot');
    });
    Route::post('login', 'AuthController@login');
    Route::get('reset-password/{token}', 'AuthController@ResetPassword');
    Route::post('forgot-password', 'AuthController@forgotPassword');
    Route::post('admin-update-password', 'AuthController@adminUpdatePassword');
});

Route::group(['prefix' => 'admin', 'middleware' => 'admin'], function() {
    Route::get('logout', 'AuthController@logout');
    Route::get('dashboard', 'DashboardController@index');
    Route::post('chartdetail', 'DashboardController@chartDetail');


    // Users
    Route::get('profile', 'UserController@getProfile');
    Route::post('profile-update', 'UserController@updateProfile');
    Route::get('change-password', 'UserController@changePassword');
    Route::post('update-password', 'UserController@updatePassword');
    Route::get('users', 'UserController@index');
    Route::post('users/_users-list', 'UserController@usersList');
    Route::get('users/add', 'UserController@add');
    Route::get('users/view/{id}', 'UserController@view');
    Route::get('users/edit/{id}', 'UserController@edit');
    Route::post('users/player/save', 'UserController@playerSave');
    Route::post('users/coach/save', 'UserController@coachSave');
    Route::post('users/team/save', 'UserController@teamSave');
    Route::post('users/update', 'UserController@userUpdate');
    Route::get('users/status', 'UserController@changeStatus');
    Route::get('users/_personal-info-view', 'UserController@personalInfoView');
    Route::get('users/_contact-info-view', 'UserController@contactInfoView');
    Route::get('users/_about-view', 'UserController@aboutView');
    Route::get('users/_team-roster-view', 'UserController@teamRosterView');
    Route::get('users/_key-stats-view', 'UserController@keyStatsView');
    Route::get('users/_media-view', 'UserController@mediaView');
    Route::get('users/media-detail-modal', 'UserController@getMediaModalView');
    Route::get('users/media-comment-list', 'UserController@mediaCommentList');
    Route::get('users/_measurables-view', 'UserController@measurablesView');
    Route::get('users/_desired-benifits-view', 'UserController@desiredBenifitsView');
    Route::get('users/_plan-purchase-view', 'UserController@planPurchaseView');
    Route::post('users/purchase-view', 'UserController@purchaseView');
    Route::post('get-country-code-byid', 'UserController@getCountryCode');
    Route::get('users/send-invoice-mail/{id}', 'UserController@sendInvoiceData');

    // Events
    Route::get('events', 'EventController@index');
    Route::post('events/_events-list', 'EventController@eventsList');
    Route::get('events/add', 'EventController@add');
    Route::post('events/save', 'EventController@save');
    Route::get('events/status', 'EventController@changeStatus');
    Route::get('events/edit/{id}', 'EventController@edit');
    Route::get('events/view/{id}', 'EventController@view');
    Route::get('events/add-team-form', 'EventController@addTeamForm');

    // Jobs
    Route::get('manage-jobs', 'JobController@index');
    Route::post('manage-jobs/_jobs-list', 'JobController@ajaxManageJobsList');
    Route::post('get-level-list', 'JobController@getLevelList');
    Route::get('manage-jobs/view/{id}', 'JobController@getView');
    Route::get('manage-jobs/status', 'JobController@changeStatus');

    // Post
    Route::get('manage-post', 'PostController@index');
    Route::get('manage-post/update-status', 'PostController@updateStatus');
    Route::get('manage-post/view/{id}', 'PostController@postView');
    Route::post('manage-post/_post-list', 'PostController@ajaxManagePostList');
    Route::get('manage-post/_get-post-media-list', 'PostController@postMediaList');
    Route::get('manage-post/_get-post-comment-list', 'PostController@postCommentList');

    Route::get('menage-post/get-media-modal', 'PostController@getMediaModalView');
    Route::get('manage-post/media-comment-list', 'PostController@mediaCommentList');

    // Chat
    Route::get('chats', 'ChatController@index');
    Route::get('chats/view-chat/{id}/{from_id}', 'ChatController@viewChat');
    Route::post('chats/_chats-list', 'ChatController@ajaxManageChatsList');


    // Subscriptions
    Route::get('subscriptions', 'SubscriptionController@index');
    Route::post('subscriptions/_subscriptions-list', 'SubscriptionController@ajaxSubscriptionsList');
    Route::get('subscriptions/add', 'SubscriptionController@addSubscription');
    Route::post('subscriptions/submit', 'SubscriptionController@save');
    Route::get('subscriptions/view/{id}', 'SubscriptionController@viewSubscription');
    Route::get('subscriptions/edit/{id}', 'SubscriptionController@editSubscription');
    Route::post('subscriptions/update', 'SubscriptionController@update');
    Route::get('subscriptions/status', 'SubscriptionController@status');

    //  get Media section 
    Route::get('manage-media', 'MediaController@index');
    Route::get('menage-media/view/{id}', 'MediaController@mediaView');
    Route::post('manage-media/_media-list', 'MediaController@ajaxManageMediaList');
    Route::get('manage-media/_comments-list', 'MediaController@ajaxManageMediaComments');
    Route::get('manage-media/update-status', 'MediaController@updateStatus');

    // Incidents
    Route::get('manage-incidents', 'IncidentController@index');
    Route::post('incident-list', 'IncidentController@manageIncidentsList');
    Route::get('manage-incidents/view/{id}', 'IncidentController@view');
    Route::post('get-reporter-list', 'IncidentController@getReporterList');
    Route::post('manage-incidents/report-by-admin', 'IncidentController@report');


    // News
    Route::get('manage-news', 'NewsController@index');
    Route::post('manage-news/_load_user_list', 'NewsController@LoadNewsList');
    Route::get('manage-news/add-news', 'NewsController@addnews');
    Route::post('manage-news/save', 'NewsController@save');
    Route::get('manage-news/edit-news/{id}', 'NewsController@editNews');
    Route::post('manage-news/update', 'NewsController@update');
    Route::get('manage-news/update-status', 'NewsController@updateStatus');
    Route::post('upload_news_media', 'NewsController@uploadNewsMedia');
    Route::get('manage-news/view/{id}', 'NewsController@view');
    // Payment
    Route::get('payments', 'PaymentController@index');
    Route::post('payments/_payments-list', 'PaymentController@ajaxPaymentsList');

    // Admin
    Route::get('manage-admin', 'AdminController@index');
    Route::post('manage-admin/list', 'AdminController@manageAdminList');
    Route::get('manage-admin/add', 'AdminController@add');
    Route::post('manage-admin/save', 'AdminController@save');
    Route::get('manage-admin/status', 'AdminController@status');
    Route::get('manage-admin/edit/{id}', 'AdminController@edit');
    Route::get('manage-admin/assign/{id}', 'AdminController@assign');
    Route::post('manage-admin/assign-permission', 'AdminController@assignPermission');

    // CMS
    Route::get('cms', 'CmsController@index');
    Route::get('cms/_user-testimonials-list', 'CmsController@ajaxUserTestimonialsList');
    Route::get('cms/_cms-add', 'CmsController@ajaxCmsAdd');
    Route::get('cms/_cms-update/{id}', 'CmsController@ajaxCmsUpdate');
    Route::get('cms/view/{id}', 'CmsController@ajaxCmsView');
    Route::get('cms/_cms-contact', 'CmsController@ajaxCmsContact');
    Route::get('cms/_cms-about', 'CmsController@ajaxCmsAbout');
    Route::post('cms/update-about-and-terms', 'CmsController@updateAboutAndTerms');
    Route::post('cms/update-contacts', 'CmsController@updateContacts');
    Route::post('cms/add-testimonial', 'CmsController@addTestimonial');
    Route::post('cms/update-testimonial', 'CmsController@updateTestimonial');
    Route::get('cms/remove-testimonial/{id}', 'CmsController@removeTestimonial');

    // Manage Benefits
    Route::get('manage-benefits', 'BenefitsController@index');
    Route::post('manage-benefits/_benefits-list', 'BenefitsController@benefitsList');
    Route::get('manage-benefits/status', 'BenefitsController@changeBenefitStatus');

    // Manage Notifications
    Route::get('load-notification-list', 'NotificationController@manageNotificationList');
    Route::get('load-notification-count', 'NotificationController@loadNotificationCount');
    Route::post('update-notification-list', 'NotificationController@updateReadNotification');
    Route::get('notifications', 'NotificationController@notifications');
    Route::get('notification-list', 'NotificationController@notificationList');


    Route::get('player', [
        'uses' => 'DashboardController@playerPage',
        'as' => 'player',
        'middleware' => 'roles',
        'roles' => ['player']
    ]);
    Route::get('team', [
        'uses' => 'DashboardController@teamPage',
        'as' => 'team',
        'middleware' => 'roles',
        'roles' => ['team']
    ]);
    Route::get('coach', [
        'uses' => 'DashboardController@coachPage',
        'as' => 'coach',
        'middleware' => 'roles',
        'roles' => ['coach']
    ]);
    Route::post('postAdminPermission', 'DashboardController@postAdminPermission');
});
