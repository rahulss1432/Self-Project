<html lang="en">
    <head>
        <title>Login</title>
        @include('admin::layouts.include.head-link')
    </head>
    <body class="login-page ">
        <main >
            <div class="login-wrap mx-auto">
                <div class="login-header d-flex align-items-center justify-content-center">
                    <img src="{{ url('public/administrator/images/white_logo.png') }}" alt="logo">
                </div>
                <h3 class="title">Reset Password</h3>
                <div class="login-field">
                    <form id="admin-reset-password" method="post" action="{{url('/admin/admin-update-password')}}">
                        {{ csrf_field() }}
                        <input type="hidden" name="reset-token" value="{{ $resetToken }}">
                        <div class="form-group">
                            <input type="password" name="password" class="form-control form-control-lg" placeholder="Password"/>
                        </div>
                        <div class="form-group">
                            <input type="password" name="password_confirmation" class="form-control form-control-lg" placeholder="Confirm Password">
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" id="reset-password-btn" class="btn btn-success btn_radius btn-block ripple-effect">
                                Reset Password <span class="btn_loader" style="display: none;"></span>
                            </button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Http\Requests\ResetPasswordValidation','#admin-reset-password') !!}
                </div>
                <div class="login-footer text-right">
                    <a href="{{URL('admin/login')}}">Sign In?<span class="fa fa-long-arrow-right"></span></a>
                </div>
            </div>
        </main>
        @include('admin::layouts.include.footer')
    </body>  
</html>
<script>
    $(document).on('submit', '#admin-reset-password', function (e) {
        e.preventDefault();
        $('#reset-password-btn').html('<i class="fa fa-spinner fa-pulse fa-1x"></i>');
        $('#reset-password-btn').prop('disabled',true);
        $.post($(this).attr('action'), $(this).serialize(), function (data) {
            $('#reset-password-btn').html('Reset Password');
            $('#reset-password-btn').prop('disabled',false);
            if (data.success) {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.success(data.message, {timeOut: 1500});
            } else {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error(data.message, {timeOut: 1500});
            }
            setTimeout(function () {
                window.location.href = "{{ url('admin/login') }}";
            }, 2000);
        });
    });

</script>