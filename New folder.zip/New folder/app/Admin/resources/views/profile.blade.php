@php $pageTitle = 'Setting | FAF'; @endphp
@php $activePage = ''; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.side-menu')
<div class="main-content adduser_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Edit Profile</h2>
            </div>
        </div>
        <div class="content">
            <div class="add_details mx-auto add_form">
                <div class="card">
                    <div class="card-header">Edit profile <div class="float-right"><p class="mb-0 color-green">Full access</p></div></div>
                    <div class="card-body">
                        <form action="{{ url('admin/profile-update') }}" id="editProfile" method="post" autocomplete="off">	
                            {{ csrf_field() }}
                            <input type="hidden" value="{{$id}}" name="id">
                            <div class="field_content" >
                                <div class="field_box">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input name="full_name" value="{{getUserById($id, 'full_name')}}" type="text" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Email</label>
                                                <input name="email" value="{{getUserById($id, 'email')}}" type="email" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group mobile_no">
                                                <label>Mobile Number</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <select class="selectpicker select-custom form-control" data-size="4" title="&nbsp;">
                                                            <option value="Armenia" selected="">+91</option> 
                                                            <option value="Aruba">+62</option> 
                                                            <option value="Australia">+365</option> 
                                                            <option value="Austria">+3655</option> 
                                                            <option value="Austria">+3655</option> 
                                                        </select>
                                                    </div>
                                                    <input type="text" value="{{getUserById($id, 'phone_number')}}" name="phone_number" class="form-control" aria-label="Text input with dropdown button">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Country</label>
                                                <select name="country_id" id="country" onchange="$(this).valid();" class="selectpicker select-custom form-control" data-size="3" title="Select Country">

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>State</label>
                                                <select name="state_id" id="state" onchange="$(this).valid();" class="selectpicker select-custom form-control" data-size="3" title="Select State">
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input name="city" value="{{getUserById($id, 'city')}}" type="text" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Zip Code</label>
                                                <input type="text" value="{{getUserById($id, 'zip_code')}}" name="zip_code" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <input type="text" value="{{getUserById($id, 'address_line_1')}}" name="address_line_1" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group action text-right mb-0">
                                        <a href="{{ url('admin/dashboard') }}" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                            Cancel
                                        </a>
                                        <button type="button" class="btn btn-dark rounded-0 ripple-effect" id="addUpdateButton" onclick="addUpdateProfile('editProfile')">Save

                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        {!! JsValidator::formRequest('App\Admin\Http\Requests\EditProfileRequest','#editProfile') !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // get all country
    var country_id = "{{ getUserById($id, 'country_id') }}";
    $.post("{{ url('get-all-country') }}", {_token: "{{ csrf_token() }}", type: ""}, function (data) {
        $('#country').html(data);
        $('#country').selectpicker('refresh');
        if (country_id != '' && country_id != undefined)
        {
            $('#country').selectpicker('val', country_id);
            $('#country').selectpicker('render');
        }
    });




    // get state by country id
    var state_id = "{{ getUserById($id, 'state_id') }}";
    $(document).on('change', '#country', function () {
        $.post("{{ url('get-state-by-country-id') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: ""}, function (data) {
            $('#state').html(data);
            $('#state').selectpicker('refresh');
            if (state_id != '' && state_id != undefined)
            {
                $('#state').selectpicker('val', state_id);
                $('#state').selectpicker('render');
            }
        });
    });

    // function for save admins.
    function addUpdateProfile(form_id) {
        if ($("#" + form_id).valid()) {
            showButtonLoader('addUpdateButton', 'Save', 'disable');
            var formData = new FormData($("#" + form_id)[0]);
            $.ajax({
                url: $("#" + form_id).attr('action'),
                data: formData,
                processData: false,
                contentType: false,
                type: 'POST',
                dataType: 'JSON',
                success: function (data) {
                    if (data.success) {
                        message('success', data.message);
                        setTimeout(function () {
                            window.location.href = "{{ url('admin/dashboard') }}"
                        }, 1000);
                    } else {
                        message('error', data.message);
                    }
                },
                error: function (err) {
                    message('error', err);
                },
                complete: function () {

                    showButtonLoader('addUpdateButton', 'Save', 'enable');

                }
            });
        }
    }
</script>

@endsection