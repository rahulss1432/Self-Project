<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Manage Commission</title>
    <?php include 'include/links.php' ?>
</head>
<?php
    $current = 'manage-commission';
    $currentPageName = 'manage Commission';
    ?>

<body class="bg-light-gray" onload="hide_preloader();">
    <div id="preloader">
        <div class="inner">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
    </div>
    <?php include 'include/side-menu.php' ?>
    <?php include 'include/header.php' ?>
    <main class="main-content common-grid-list" id="mainContent">
        <div class="page-content">
            <div class="card custom_card">
                <div class="card-header">
                    <h4 class="page-title float-left">Commission List</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table admin-table">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>value</th>
                                    <th class="w100 text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Commission rate in Percentage %</td>
                                    <td>10</td>
                                    <td>
                                        <ul class="list-inline mb-0 text-center">
                                            <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                                <a href="javascript:void(0);" onclick="editCommission();"><i class="ti-pencil-alt"></i></a>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- add flagged terms modal -->
    <div class="modal fade" id="editCommissionModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Commission</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="ti-close"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form name="" class="f-field">
                        <div class="form-group">
                            <input type="text" class="form-control form-control-lg" value="10" required />
                            <label class="control-label">Commission rate</label>
                        </div>
                        <div class="form-group mb-0 text-right">
                            <button type="button" class="btn btn-sm btn-primary ripple-effect">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php include 'include/footer.php' ?>
    <script type="text/javascript">
        function editCommission(){
       $("#editCommissionModal").modal("show");
        }
    </script>
</body>

</html>