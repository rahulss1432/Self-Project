@php $pageTitle = 'Manage News | Admin'; @endphp
@php $activePage = 'manage-news'; @endphp

@extends('admin::layouts.app')

@section('content')
@include('admin::layouts.include.side-menu')

<div class="main-content manage_user_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2>Manage News</h2>
            </div>
            <!--  -->
            <div class="search_section justify-content-between">
                <div class="row">
                    <div class="col-12 col-sm-8">
                        <ul class="list-inline mb-0">
                            <form autocomplete="off" id="news-search" method="post" action="javascript:void(0);">
                            <li class="list-inline-item">
                                <div class="filter_dropdown">
                                    <select class="selectpicker select-custom" onchange="getListing('')" name="orderBy" id="orderBy" >
                                            <option value="desc">Newest</option>
                                            <option value="asc">Oldest</option>
                                            <option value="date">Recently Updated</option>
                                    </select>
                                </div>
                            </li>
                            <li class="list-inline-item">
                                <div class="input-group">
                                    <input type="text" class="form-control" onkeyup="getListing('')" name="search_input" placeholder="Search By Keyword (User Name / News Id)" aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button type="button" class="input-group-text btn btn-dark rounded-0 ripple-effect" id="basic-addon2" onclick="getListing('')"> <i class="icon-search"></i> <span class="d-none d-md-block">Search</span></button>
                                    </div>
                                </div>
                            </li>
                            </form>
                        </ul>
                        
                    </div>
                    <div class="col-12 col-sm-4">
                        <ul class="filter_right list-inline text-right mb-0">
                            <li class="list-inline-item">
                                <a href="javascript:void(0);" class="btn btn-white rounded-0 ripple-effect" onclick="getFilterOpen()"><i class="icon-filter-filled-tool-symbol"></i> Filter</a>
                            </li>
                            <li class="list-inline-item">
                                <a href="{{url('admin/manage-news/add-news')}}" class="btn btn-dark rounded-0 ripple-effect">Add News</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!--  -->
            <div class="filter_form bg-white">
                <div class="d-flex top_filter">
                    <div class="filter_heading">
                        <h2>Filters</h2>
                    </div>	
                    <div class="ml-auto">
                        <div class="close_btn" onclick="getFilterClose()">
                            <div class="x common rotate30 rotate45"></div>	
                            <div class="z common rotate150 rotate135"></div>
                        </div>
                    </div>
                </div>
                <form id="news-filter" autocomplete="off" method="post" action="javascript:void(0);">
                    <div class="comman_form">
                        <h4 class="form_heading">By News</h4>
                        <div class="form-group">
                            <label>News Status</label>
                            <select class="selectpicker select-custom form-control " title="Status" data-size="2" id="status" name="status">
                                <option value="">Select Status</option> 
                                <option value="active">Active</option> 
                                <option value="inactive">Deactive</option> 
                            </select>
                        </div>
                    </div>
                    <div class="comman_form">
                        <h4 class="form_heading">By Includes</h4>
                        <div class="form-group">
                            <label>Includes</label>
                            <select class="selectpicker select-custom form-control " title="Status" data-size="2" id="includes" name="includes">
                                <option value="all">All</option> 
                                <option value="yes">Media</option> 
                                <option value="no">No Media</option> 
                            </select>
                        </div>
                    </div>
                    <div class="comman_form">
                        <h4 class="form_heading">By Date Range</h4>
                        <div class="form-group">
                            <label class="control-label">From Date</label>
                            <div class="dateIcon">
                                <input type="text" id="startDate" name="startDate" class="form-control rounded-0  datetimepicker-input" data-target="#startDate"  data-toggle="datetimepicker" placeholder="Date" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label">To Date</label>
                            <div class="dateIcon">
                                <input type="text" id="endDate" name="endDate" class="form-control rounded-0  datetimepicker-input" data-target="#endDate"  data-toggle="datetimepicker" placeholder="Date"/>
                            </div>
                        </div>
                    </div>
                    <div class="form-group d-flex submit_btn mb-0">
                        <button type="button" class="btn btn-light rounded-0 ripple-effect" onclick="resetFilter('news-filter','news');">Reset</button>
                        <div class="ml-auto">
                            <button type="button" class="btn btn-dark rounded-0 ripple-effect" onclick="getListing('')"> Apply </button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
        <div id="newsListing"></div>
       
    </div>
</div>
<input type="hidden"  data-url="{{ url('admin/manage-news/update-status') }}" id="update_status">
<script type="text/javascript" src="{{ url('public/administrator/js/common.js') }}"></script>
<script type="text/javascript">
   //aAjax load content
      var currentXhr = null;
    function getListing(url) {
        if (url == '' || url == undefined)
        {
            var url = "{{ url('admin/manage-news/_load_user_list') }}";
        }
         pageLoader('newsListing', 'show');
        var searching = $("#news-search,#news-filter").serializeArray();
        searching.push({name: '_token', value: '{{ csrf_token() }}'});
        currentXhr = $.ajax({
            type: "POST", url: url, data: searching,
            beforeSend: function () {
                if (currentXhr != null) {
                    currentXhr.abort();
                    currentXhr = null;
                }
            },
            success: function (response) {
                $("#newsListing").html("");
                $("#newsListing").html(response.html);
            },
            error: function (err) {
//                getListing(url);
            },
            complete: function () {
                getFilterClose();
            }
        });
    }
    $(document).ready(function () {
        getListing('');
    });

</script>

@endsection