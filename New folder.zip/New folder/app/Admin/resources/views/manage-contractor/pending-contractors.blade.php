@extends('admin::include.app')
@section('title', 'Pending Contractors')
@section('content')
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Pending Contractors List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="filter_section collapse" id="searchFilter">
                    <form method="post" action="javascript:pending_contractor_list()" id="search_form">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control form-control-lg">
                                    <label class="control-label">Name</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="email" class="form-control form-control-lg" />
                                    <label class="control-label">Email Address</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <select name="status" class="selectpicker form-control form-control-lg">
                                        <option value=""> Select Status</option>
                                        <option value="approve">Approve</option>
                                        <option value="disapprove">Disapprove</option>
                                    </select>
                                    <label class="control-label">Status</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group d-inline-block mr-2">
                                    <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                </div>
                                <div class="form-group d-inline-block">
                                    <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="submit">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="getContractorsList">
                </div>
            </div>
        </div>
    </div>
</main>
<!-- prfole modal -->
<div class="modal fade" id="customerProfile" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="customerprofile" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md profile-modal" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Contractors  Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="user_info" id="getCotractorDetailsList">

                </div>
            </div>
        </div>
    </div>
</div>
<!--  modal -->
<div class="modal fade" id="viewAvailibility" tabindex="-1" role="dialog" aria-labelledby="customerprofile" data-backdrop="static" data-keyword="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md availibility-modal" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">View Availibility </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body px-0">
                <div class="mCustomScrollbar list_scr" data-mcs-theme="minimal-dark">
                    <ul class="availibility-list list-unstyled mb-0">
                        <li>
                            <div class="location_row">
                                <i class="fa fa-map-marker"></i>
                                <h3>California <span>Los Angeles</span></h3>
                            </div>
                            <ul class="list-inline date_row mb-0">
                                <li class="list-inline-item">
                                    <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                </li>
                            </ul>
                            <div class="meeting_row">
                                <label><i class="fa fa-home"></i> Meeting Place :</label> <span>Home</span>
                            </div>
                        </li>
                        <!-- xxxxxx -->
                        <li>
                            <div class="location_row">
                                <i class="fa fa-map-marker"></i>
                                <h3>New York <span>Los Angeles</span></h3>
                            </div>
                            <ul class="list-inline date_row mb-0">
                                <li class="list-inline-item">
                                    <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                </li>
                            </ul>
                            <div class="meeting_row">
                                <label><i class="fa fa-home"></i> Meeting Place :</label> <span>User Home</span>
                            </div>
                        </li>
                        <!-- xxxxxx -->
                        <li>
                            <div class="location_row">
                                <i class="fa fa-map-marker"></i>
                                <h3>Denver <span>Los Angeles</span></h3>
                            </div>
                            <ul class="list-inline date_row mb-0">
                                <li class="list-inline-item">
                                    <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                </li>
                            </ul>
                            <div class="meeting_row">
                                <label><i class="fa fa-home"></i> Meeting Place :</label> <span>Public place</span>
                            </div>
                        </li>
                        <li>
                            <div class="location_row">
                                <i class="fa fa-map-marker"></i>
                                <h3>California <span>Los Angeles</span></h3>
                            </div>
                            <ul class="list-inline date_row mb-0">
                                <li class="list-inline-item">
                                    <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                </li>
                            </ul>
                            <div class="meeting_row">
                                <label><i class="fa fa-home"></i> Meeting Place :</label> <span>Home</span>
                            </div>
                        </li>
                        <!-- xxxxxx -->
                        <li>
                            <div class="location_row">
                                <i class="fa fa-map-marker"></i>
                                <h3>New York <span>Los Angeles</span></h3>
                            </div>
                            <ul class="list-inline date_row mb-0">
                                <li class="list-inline-item">
                                    <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                </li>
                            </ul>
                            <div class="meeting_row">
                                <label><i class="fa fa-home"></i> Meeting Place :</label> <span>User Home</span>
                            </div>
                        </li>
                        <!-- xxxxxx -->
                        <li>
                            <div class="location_row">
                                <i class="fa fa-map-marker"></i>
                                <h3>Denver <span>Los Angeles</span></h3>
                            </div>
                            <ul class="list-inline date_row mb-0">
                                <li class="list-inline-item">
                                    <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                </li>
                            </ul>
                            <div class="meeting_row">
                                <label><i class="fa fa-home"></i> Meeting Place :</label> <span>Public Place</span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function viewAvailibility() {
        $("#viewAvailibility").modal('show');
    }

    $(document).ready(function ()
    {
        $('#preloader').hide();
        pending_contractor_list();
    });

    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        pending_contractor_list();
    }

    function pending_contractor_list()
    {
        pageDivLoader('show', 'getContractorsList');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "POST",
            url: "{{ url('admin/load-pending-contractors-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getContractorsList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function changeStatus(el, id) {
        if ($(el).is(':checked')) {
            var status = 'active';
        } else {
            var status = 'inactive';
        }
        bootbox.confirm({
            message: "Are you sure you want to change the status ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                }
            },
            callback: function (result) {
                if (result) {
                    update_status(id, status);
                } else {
                    if (status == 'active') {
                        $(el).prop('checked', false);
                    } else {
                        $(el).prop('checked', true);
                    }
                    return true;
                }
            }
        });
    }

    function update_status(id, status) {
        $.ajax({
            url: "{{ url('admin/update-contractor-status') }}",
            type: 'GET',
            data: {id: id, status: status},
            cache: false,
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    toastrAlertMessage('success', data.message);
                    pending_contractor_list();
                } else {
                    toastrAlertMessage('error', data.message);
                }
            },
            error: function (err) {
                toastrAlertMessage('error', err);
            },
            complete: function () {
            }
        });
    }

    /** @returns load contractor details */
    function loadContractorDetails(id) {
        $('#customerProfile').modal('show');
        pageDivLoader('show', 'getCotractorDetailsList');
        $.ajax({
            type: "GET",
            url: "{{ url('/admin/load-contractor-details') }}/" + id,
            success: function (response)
            {
                if (response.success) {
                    $("#getCotractorDetailsList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            }
        });
    }
</script>
@endsection