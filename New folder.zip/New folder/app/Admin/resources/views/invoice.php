<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Invoice</title>
        <!-- Bootstrap -->
        <?php include 'include/links.php' ?>
    </head>
     <body class="bg-light-gray">
         
        <main class="dashboard-main-wrap invoice-page m-0 p-0" id="content">
        <div class="container-fluid">
            <div class="common-detail-section p-0">
                <div class="content-body rounded">
                    <div class="top-info d-flex align-items-center justify-content-between">
                        <div class="logo">
                            <img src="<?php echo IMAGES_URL ?>/blue-logo.png" title="mentor" alt="logo">
                        </div>
                        <!-- xx -->
                        <h1 class="font-md">Invoice</h1>
                       
                        <!-- xxxxx -->
                    </div>
                    <!-- xxxxx -->
                    <div class="middle-info">
                         <div class="info">
                            <div class="label-text">
                                <label for="">Booking ID : </label>
                                <span>#00124 </span>
                            </div>
                            <div class="label-text">
                                <label for="">Job Date & Time : </label>
                                <span>19 <sup>th</sup> Jan 2018, 10.00 AM</span>
                            </div>
                            <div class="label-text">
                                <label for="">Meeting Place : </label>
                                <span>Home</span>
                            </div>
                             <div class="label-text">
                                <label for="">Service Type : </label>
                                <span>Fitness</span>
                            </div>
                            <div class="label-text">
                                <label for="">Address : </label>
                                <span>36 Edgewater Street Melbourne, 2540, Australia</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="info">
                                    <h4 class="font-md">Mentor</h4>
                                    <p class="mb-1">Steven Shelton</p>
                                    <p class="mb-0">stevens@gmail.com</p>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="info">
                                    <h4 class="font-md">User</h4>
                                    <p class="mb-1">Charlotte Nelligan</p>
                                    <p >charlotten@gmail.com</p>
                                </div>
                            </div>
                        </div>
                        <!-- xxxxxx -->
                        <div class="table-responsive">
                                <table class="table common-table">
                                    <tbody>
                                        <tr>
                                            <td>Service Cost</td>
                                            <td>$ 10</td>
                                        </tr>
                                        <tr>
                                            <td>Commission Cost</td>
                                            <td>$ -0.50</td>
                                        </tr>
                                        <tr>
                                            <th>Total Fare (via credit)</th>
                                            <th>$ 10.00</th>
                                        </tr>
                                    </tbody>
                                    </table>
                                </div>

                    </div>
               
                </div>
            </div>
        </div>
    </main>

    </body>
</html>