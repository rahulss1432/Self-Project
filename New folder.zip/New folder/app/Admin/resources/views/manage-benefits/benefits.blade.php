@php $pageTitle = 'Manage Benefits | FAF'; @endphp
@php $activePage = 'manage-benefits'; @endphp

@extends('admin::layouts.app')

@section('content')

@include('admin::layouts.include.side-menu')

<div class="main-content manage_user_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2>Manage User Benefits</h2>
            </div>
            <!--  -->
            <div class="search_section justify-content-between">
                <div class="row">
                    <div class="col-12 col-sm-7">
                        <form autocomplete="off" id="user-search" method="post" action="javascript:void(0);">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <div class="filter_dropdown">
                                        <select class="selectpicker select-custom" onchange="getListing('')" name="orderBy" id="orderBy" >
                                            <option value="desc">Newest</option>
                                            <option value="asc">Oldest</option>
                                            <option value="date">Recently Updated</option>
                                        </select>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <div class="input-group">
                                        <input type="text" name="columns" onkeyup="getListing('')" id="columns" class="form-control" placeholder="Search By Keyword (Title / User Name)" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button type="button" class="input-group-text btn btn-dark rounded-0 ripple-effect" id="basic-addon2" onclick="getListing('')"> <i class="icon-search"></i> <span class="d-none d-md-block">Search</span></button>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </form>
                    </div>
                </div>
            </div>            
        </div>
        <div  id="usersBenefitList">

        </div>
    </div>
</div>
<input type="hidden"  data-url="{{ url('admin/manage-benefits/status') }}" id="update_status">
<script type="text/javascript" src="{{ url('public/administrator/js/common.js') }}"></script>
<script type="text/javascript">
                                                var currentXhr = null;
                                                function getListing(url) {
                                                    if (url == '' || url == undefined)
                                                    {
                                                        url = "{{ url('admin/manage-benefits/_benefits-list') }} ";
                                                    }
                                                    pageLoader('usersBenefitList', 'show');
                                                    var searching = $("#user-search,#user-filter").serializeArray();
                                                    searching.push({name: '_token', value: '{{ csrf_token() }}'});
                                                    currentXhr = $.ajax({
                                                        type: "POST", url: url, data: searching,
                                                        beforeSend: function () {
                                                            if (currentXhr != null) {
                                                                currentXhr.abort();
                                                                currentXhr = null;
                                                            }
                                                        },
                                                        success: function (response) {
                                                            $("#usersBenefitList").html("");
                                                            $("#usersBenefitList").html(response.html);
                                                        },
                                                        error: function (err) {
                                                        },
                                                        complete: function () {
                                                        }
                                                    });
                                                }

                                                $(document).ready(function () {
                                                    getListing('');
                                                });


                                                /* Active inactive */
                                                function changeStatus(el, id) {
                                                    if (id == 'message') {
                                                        alert('only other users status active and inactive of benefits');
                                                        $(el).prop('checked', true);
                                                    } else {
                                                        if ($(el).is(':checked')) {
                                                            var status = 'active';
                                                        } else {
                                                            var status = 'inactive';
                                                        }
                                                        bootbox.confirm({
                                                            size: "small",
                                                            message: "Are you sure to update status?",
                                                            buttons: {
                                                                confirm: {
                                                                    label: 'Yes',
                                                                    className: 'btn btn-success rounded-0'
                                                                },
                                                                cancel: {
                                                                    label: 'No',
                                                                    className: 'btn btn-light rounded-0'
                                                                }
                                                            },
                                                            callback: function (result) {
                                                                if (result) {
                                                                    update_status(id, status);
                                                                } else {
                                                                    if (status == 'active') {
                                                                        $(el).prop('checked', false);
                                                                    } else {
                                                                        $(el).prop('checked', true);
                                                                    }
                                                                    return true;
                                                                }
                                                            }
                                                        });
                                                    }
                                                }
</script>

@endsection