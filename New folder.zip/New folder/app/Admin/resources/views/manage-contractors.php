<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Manage Contractors</title>
    <?php include 'include/links.php' ?>
</head>
<?php
    $current = 'contractors';
    $currentPageName = 'Manage Contractors';
    ?>

<body class="bg-light-gray" onload="hide_preloader();">
    <div id="preloader">
        <div class="inner">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
    </div>
    <?php include 'include/side-menu.php' ?>
    <?php include 'include/header.php' ?>
    <main class="main-content common-grid-list" id="mainContent">
        <div class="page-content">
            <div class="card custom_card">
                <div class="card-header">
                    <h4 class="page-title float-left">Contractors List</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                            <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="filter_section collapse" id="searchFilter">
                        <form>
                            <div class="row">
                                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-lg" />
                                        <label class="control-label">Name</label>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-lg" />
                                        <label class="control-label">Email Address</label>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <select class="selectpicker form-control form-control-lg">
                                            <option value="approve">Approve</option>
                                            <option value="disapprove">Disapprove</option>
                                        </select>
                                        <label class="control-label">Status</label>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                    <div class="form-group d-inline-block mr-2">
                                        <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                    </div>
                                    <div class="form-group d-inline-block">
                                        <button class="btn btn-dark ripple-effect" type="submit">Reset</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="table-responsive" id="getcontractorslist">
                    </div>
                    <nav aria-label="Page navigation" class="paginationDiv clearfix" id="listPagination" style="display:none;">
                        <div class="nofpages float-left">
                            1 of 6 pages
                        </div>
                        <ul class="pagination float-right mb-0">
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#">4</a></li>
                            <li class="page-item"><a class="page-link" href="#">5</a></li>
                            <li class="page-item"><a class="page-link" href="#">6</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </main>
    <!-- prfole modal -->
    <div class="modal fade" id="customerProfile" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="customerprofile" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md profile-modal" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Contractors  Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="ti-close"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="user_info">
                        <div class="info_row">
                            <div class="img_wrap">
                                <img src="<?php echo IMAGES_URL ?>/user.jpg" alt="profile-img" class="img-fluid">
                            </div>
                                <div class="details">
                                    <ul class="right_side list-unstyled">
                                        <li>
                                            <label>Name</label>
                                            <span>Garrett Bird</span>
                                        </li>
                                        <li>
                                            <label>Email</label>
                                            <span> garrettb@gmail.com</span>
                                        </li>
                                        <li>
                                            <label>Phone Number</label>
                                            <span>0428789958</span>
                                        </li>
                                        <li>
                                            <label>DOB</label>
                                            <span>10/08/2008</span>
                                        </li>
                                        <li>
                                            <label>Experience </label>
                                            <span>2 years 5 month</span>
                                        </li>
                                        <li>
                                            <label>Profile Status</label>
                                            <span class="text-success">Active</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="full-dtl">
                                <ul class="right_side list-unstyled">
                                    <li>
                                        <label>Ratings</label>
                                        <span class="rating d-block">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </span>
                                    </li>
                                    <li>
                                        <label>Registration Date</label>
                                        <span class="d-block">Thursday, Jan 03<sup>rd</sup> 2019</span>
                                    </li>
                                    <li>
                                        <label>Mentor Locator unique URL</label>
                                        <span class="d-block"><a href="javascript:void(0);" class="theme-color">https://www.mentolocator.com/Garrettbird</a></span>
                                    </li>
                                    <li>
                                        <label>Address</label>
                                        <span class="d-block">45 st peter Warner, Queensland, 4500 Australia</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--  modal -->
        <div class="modal fade" id="viewAvailibility" tabindex="-1" role="dialog" aria-labelledby="customerprofile" data-backdrop="static" data-keyword="false" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-md availibility-modal" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">View Availibility </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <i class="ti-close"></i>
                        </button>
                    </div>
                    <div class="modal-body px-0">
                        <div class="mCustomScrollbar list_scr" data-mcs-theme="minimal-dark">
                            <ul class="availibility-list list-unstyled mb-0">
                                <li>
                                    <div class="location_row">
                                        <i class="fa fa-map-marker"></i>
                                        <h3>California <span>Los Angeles</span></h3>
                                    </div>
                                    <ul class="list-inline date_row mb-0">
                                        <li class="list-inline-item">
                                            <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                        </li>
                                        <li class="list-inline-item">
                                            <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                        </li>
                                    </ul>
                                    <div class="meeting_row">
                                        <label><i class="fa fa-home"></i> Meeting Place :</label> <span>Home</span>
                                    </div>
                                </li>
                                <!-- xxxxxx -->
                                <li>
                                    <div class="location_row">
                                        <i class="fa fa-map-marker"></i>
                                        <h3>New York <span>Los Angeles</span></h3>
                                    </div>
                                    <ul class="list-inline date_row mb-0">
                                        <li class="list-inline-item">
                                            <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                        </li>
                                        <li class="list-inline-item">
                                            <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                        </li>
                                    </ul>
                                    <div class="meeting_row">
                                        <label><i class="fa fa-home"></i> Meeting Place :</label> <span>User Home</span>
                                    </div>
                                </li>
                                <!-- xxxxxx -->
                                <li>
                                    <div class="location_row">
                                        <i class="fa fa-map-marker"></i>
                                        <h3>Denver <span>Los Angeles</span></h3>
                                    </div>
                                    <ul class="list-inline date_row mb-0">
                                        <li class="list-inline-item">
                                            <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                        </li>
                                        <li class="list-inline-item">
                                            <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                        </li>
                                    </ul>
                                    <div class="meeting_row">
                                        <label><i class="fa fa-home"></i> Meeting Place :</label> <span>Public place</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="location_row">
                                        <i class="fa fa-map-marker"></i>
                                        <h3>California <span>Los Angeles</span></h3>
                                    </div>
                                    <ul class="list-inline date_row mb-0">
                                        <li class="list-inline-item">
                                            <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                        </li>
                                        <li class="list-inline-item">
                                            <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                        </li>
                                    </ul>
                                    <div class="meeting_row">
                                        <label><i class="fa fa-home"></i> Meeting Place :</label> <span>Home</span>
                                    </div>
                                </li>
                                <!-- xxxxxx -->
                                <li>
                                    <div class="location_row">
                                        <i class="fa fa-map-marker"></i>
                                        <h3>New York <span>Los Angeles</span></h3>
                                    </div>
                                    <ul class="list-inline date_row mb-0">
                                        <li class="list-inline-item">
                                            <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                        </li>
                                        <li class="list-inline-item">
                                            <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                        </li>
                                    </ul>
                                    <div class="meeting_row">
                                        <label><i class="fa fa-home"></i> Meeting Place :</label> <span>User Home</span>
                                    </div>
                                </li>
                                <!-- xxxxxx -->
                                <li>
                                    <div class="location_row">
                                        <i class="fa fa-map-marker"></i>
                                        <h3>Denver <span>Los Angeles</span></h3>
                                    </div>
                                    <ul class="list-inline date_row mb-0">
                                        <li class="list-inline-item">
                                            <i class="fa fa-calendar"></i><span>Dec 25, 2018 - Dec 28, 2018</span>
                                        </li>
                                        <li class="list-inline-item">
                                            <i class="fa fa-clock-o"></i><span>05.00 AM - 08.00 AM</span>
                                        </li>
                                    </ul>
                                    <div class="meeting_row">
                                        <label><i class="fa fa-home"></i> Meeting Place :</label> <span>Public Place</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include 'include/footer.php' ?>
        <script>
        function profileView() {
            $("#customerProfile").modal('show');
        }

        function viewAvailibility() {
            $("#viewAvailibility").modal('show');
        }

        function getCustomerslist() {
            $("#getcontractorslist").html('<div class="listloader text-center pb-4"><i class="fa-2x fa-spin fa fa-spinner"></i></div>');
            var url = '<?php echo BASE_URL ?>/admin/ajax-content/_manage-contractors.php';
            $.ajax({
                type: "POST",
                url: url,
                data: {},
                success: function(response) {
                    setTimeout(function() {
                        $("#getcontractorslist").html("");
                        $("#getcontractorslist").hide().html(response).fadeIn('2000');
                    }, 2000);
                }
            });
        }

        $(document).ready(function() {
            getCustomerslist();
            setTimeout(function() {
                $("#listPagination").fadeIn();
            }, 2000);
        });
        </script>
</body>

</html>