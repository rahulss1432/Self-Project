@php $pageTitle = 'Add Event | Admin'; @endphp
@php $activePage = 'events'; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.side-menu')
<script src="{{ url('public/administrator/js/event-bootstrap-select.min.js') }}"></script>
<div class="main-content adduser_page eventadd_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Event Add </h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/events') }}">Manage Events</a>
                        </li>
                        <li class="breadcrumb-item">Event Add</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <div class="add_form mx-auto">
                <div class="card">
                    <div class="card-header">Add Event Details</div>
                    <div class="card-body">
                        <form id="add-event" method="post" action="{{ url('admin/events/save') }}">
                            {{ csrf_field() }}
                            <div class="field_content">
                                <div class="field_box">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <div class="upload_img img-thumbnail  d-inline-block text-center" style="margin:0">
                                                    <div class="img-holder ">
                                                        <input type="hidden" id="bannerImage" name="banner_image" value="">
                                                        <img id="profile_image" src="{{ checkUserImage('', 'event/thumb','event-banner') }}" alt="default-user" class="img-fluid">
                                                    </div>
                                                    <label class="upload-btn mb-0 pt-2 pb-1" onclick="$('#event_image_input').trigger('click')"> 
                                                        Add Event Picture
                                                    </label>
                                                </div>
                                            </div>
                                        </div>                                        
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Event Name</label>
                                                <input type="text" name="event_name" class="form-control">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Country</label>
                                                <select name="country_id" id="country" class="selectpicker select-custom form-control" data-size="5" title="&nbsp;">

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>State</label>
                                                <select name="state_id" id="state" class="selectpicker select-custom form-control" data-size="5" title="&nbsp;">

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input type="text" name="city" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Zip Code</label>
                                                <input type="text" name="zipcode" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Address</label>
                                        <input type="text" name="address1" class="form-control">
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Team 1</label>
                                                <select name="team1" id="team1" data-live-search="true" onchange="$(this).valid();" class="selectpicker select-custom form-control autocomplete" data-size="5" title="&nbsp;">
                                                </select>                                                
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Team 2</label>
                                                <select name="team2" id="team2"  data-live-search="true" onchange="$(this).valid();" class="selectpicker select-custom form-control" data-size="5" title="&nbsp;">
                                                </select>                                                                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Start Date & Time</label>
                                                <div class="row">
                                                    <div class="col-12 col-sm-6">
                                                        <div class="dateIcon">
                                                            <input type="text" name="start_date" id="startDate" class="form-control  datetimepicker-input" data-target="#startDate" data-toggle="datetimepicker" readonly="true" />
                                                        </div>
                                                    </div>
                                                    <div class="col-12 col-sm-6">
                                                        <div class="timeIcon">
                                                            <input type="text" name="start_time" id="startTime" class="form-control time datetimepicker-input" data-target="#startTime" data-toggle="datetimepicker" readonly="true"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>End Date & Time</label>
                                                <div class="row">
                                                    <div class="col-12 col-sm-6">
                                                        <div class="dateIcon">
                                                            <input type="text" name="end_date" id="endDate" class="form-control date datetimepicker-input" data-target="#endDate" data-toggle="datetimepicker" readonly="true"/>
                                                        </div>
                                                    </div>
                                                    <div class="col-12 col-sm-6">
                                                        <div class="timeIcon">
                                                            <input type="text" name="end_time" id="endTime" class="form-control time datetimepicker-input" data-target="#endTime" data-toggle="datetimepicker" readonly="true"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Ticket url</label>
                                                <input type="text" name="ticket_url" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Keywords</label>             
                                                <input type="text" name="keywords" id="keywords" class="form-control" data-role="tagsinput">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label>Description</label>
                                                <textarea name="description" class="form-control" rows="3"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group action mr-2  text-right mb-0">
                                        <a href="{{ url('admin/events') }}" id="saveCancel" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                            Cancel
                                        </a>
                                        <button type="submit" class="btn btn-dark rounded-0" id="saveEvent">Save <i style="display:none;" class="btn_loader"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                    </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\AddEventRequest','#add-event') !!}
                </div>
            </div>
        </div>
    </div>
</div>
<!-- team add modal-->
<div class="modal fade team_add" id="divTeamAddModal" data-backdrop="static" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document" id="divAddTeamModalBody">
    </div>
</div>

<!-- Image cropper model -->
<div id="imagCropperModal" class="modal fade image_cropper" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel01" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog common-modal crop-modal modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title heading-modal text-center">Event Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="removeCropperFile()"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <div id="cropperDiv">
                    <div style="display:none;" id="processloader" class="imagmodelloader center-block">
                        <i class="fa fa fa-spinner fa-pulse fa-2x"></i>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // open add team modal function   
    function openAddTeamModal() {
        $.get("{{ url('admin/events/add-team-form') }}", function (response) {
            $('#divTeamAddModal').modal('show');
            $('#divAddTeamModalBody').html(response.html);
            $("#eventTeamForm")[0].reset();
        });
    }

    // reset add event team   
    function resetAddTeamForm() {
        $("#eventTeamForm")[0].reset();
    }

    // save event team   
    $(document).on('submit', '#eventTeamForm', function (e) {
        e.preventDefault();
        if ($('#eventTeamForm').valid()) {
            var formData = new FormData($(this)[0]);
            showButtonLoader('saveTeamBtn', 'Save', 'disable');
            $.ajax({
                url: "{{ url('save-event-team') }}",
                data: formData,
                processData: false,
                contentType: false,
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        $('#divTeamAddModal').modal('hide');
                        message('success', response.message);
                        getAllTeam();
                    } else {
                        message('error', response.message);
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        message('error', obj[x]);
                    }
                },complete:function(){
                        showButtonLoader('saveTeamBtn', 'Save', 'enable');
                    
                }
            });
        }
    });

    /* image uload by cropper */
    var profile_picture = $('.upload-btn');
    pPicture = new AjaxUpload(profile_picture, {
        action: "{{ url('upload-event-image') }}",
        name: 'eventImage',
        cache: false,
        method: 'post',
        data: {_token: '{{ csrf_token() }}', folder: 'event', image_type: 'eventImage'},
        responseType: "JSON",
        onChange: function (file, ext) {
            //check the file size
            if (pPicture._input.files[0].size > 2097152) { //2MB
                //show alert message
                message('error', 'Selected file is bigger than 2MB.');
                return false;
            }
        },
        onSubmit: function (file, ext) {
            if (!(ext && /^(jpg|png|jpeg)$/.test(ext))) {
                message('error', 'Only jpg, jpeg, png files are allowed.');
                return false;
            }
        },
        onComplete: function (file, response) {
            if (file != "") {
                if (response.success == 1) {
                    $("input[name='eventImage']").attr('title', '');
                    load_cropp_image(response.filename, 'eventImage');
                } else {
                    $("input[name='eventImage']").attr('title', 'No file chosen');
                    message('error', response.error);
                }
            } else {
                message('error', "Error occured! please try again.");
            }
        }
    });

    function  load_cropp_image(filename, type) {
        $("#imagCropperModal").modal('show');
        var url = "{{ url('load-event-image-cropper') }}";
        $.ajax({
            type: "POST",
            url: url,
            data: {_token: "{{ csrf_token() }}", filename: filename, folder: 'event', thumb_folder: 'event/thumb', image_type: type},
            success: function (response) {
                $("#cropperDiv").html(response);
                setTimeout(function () {
                    $("#cropbutton").attr('disabled', false);
                }, 5000);
            }
        });
    }

    // remove cropper file and set tooltip to no file chosen
    function removeCropperFile() {
        $("input[name='eventImage']").attr('title', 'No file chosen');
    }

    /**start of datetime picker functions*/
//      initialize timeickers
    function initTimePicker() {
        $('#startTime').datetimepicker({
            format: 'LT',
            ignoreReadonly: true
        });
        $('#endTime').datetimepicker({
            format: 'LT',
            ignoreReadonly: true
        });
    }

    $(document).ready(function () {
        $('#team1').selectpicker();
        $('#team2').selectpicker();
        getAllTeam();
        initTimePicker(); // initialize datetimepicker at first

        // date picker functions       
        var currentDate = moment().format('DD/MM/YYYY');
        $('#startDate, #endDate').datetimepicker({// initialize datepicker
            useCurrent: false,
            format: "L",
            minDate: new Date().setHours(0, 0, 0, 0),
            ignoreReadonly: true,
        });

        $("#startDate").on("change.datetimepicker", function (e) {       // on changes start date
            $('#startTime').datetimepicker('clear');                          // reset start time picker            
            $('#endTime').datetimepicker('clear');                          // reset endtime picker
            $('#endDate').datetimepicker('minDate', e.date);             // set minimum end date to startDate 
            var startDate = moment($('#startDate').val(), "L").format('DD/MM/YYYY');     // get start date value
            if (startDate == currentDate) {                                 // if start date and today date is same        
                $('#startTime').datetimepicker('minDate', moment({// start time minimum time set to current time
                    hour: moment().format('H'),
                    minute: moment().format('mm'),
                }));
            } else {
                $('#startTime').datetimepicker('clear');                    // else clear start time and no set any minimum time
                $('#startTime').datetimepicker('minDate', moment({
                    locale: moment.locale(),
                }));
            }
        });

        $("#endDate").on("change.datetimepicker", function (e) {             // on changes of end date
            $('#endTime').datetimepicker('clear');                          // reset endtime picker            
            $('#startDate').datetimepicker('maxDate', e.date);               // start date's mamimux date set to end date
            var endDate = moment($('#endDate').val(), "L").format('DD/MM/YYYY');   // get end date
            if (endDate == currentDate) {                                   // if end date  and current date are same
                $('#endTime').datetimepicker('minDate', moment({// set current time to mimimum end time
                    hour: moment().format('H'),
                    minute: moment().format('mm'),
                }));
            } else {
                $('#endTime').datetimepicker('clear');                      // else reset end time  and don't set any minimum time
                $('#endTime').datetimepicker('minDate', moment({
                    locale: moment.locale(),
                }));
            }
        });

        $("#startTime").on("change.datetimepicker", function (e) {              //on change of start time
            var startDate = moment($('#startDate').val(), "L").format('DD/MM/YYYY');     // get start date
            var endDate = moment($('#endDate').val(), "L").format('DD/MM/YYYY');         // get end date
            if (endDate != 'Invalid date') {
                if (startDate == endDate) {                                     // if start date and end date are same        
                    var startTimeHour = parseInt(moment(e.date._i, "LTH").format("H"));             // get start time hour
                    var startTimeMinute = parseInt(moment(e.date._i, "LTH").format("mm"));          // get start time minute
                    var newStartHour = startTimeHour ? startTimeHour : parseInt(moment().format('H'));
                    var newStartMinutes = startTimeMinute ? startTimeMinute : parseInt(moment().format('mm'));
                    $('#endTime').datetimepicker('minDate', moment({// set to end time's minimum time
                        hour: newStartHour,
                        minute: newStartMinutes,
                    }));
                }
            }
        });
    });

    $("#endTime").on("click", function (e) {              //on change of start time
        $('#endTime').datetimepicker("clear");
        $('#endTime').datetimepicker("destroy");
        initTimePicker();
        var startDate = moment($('#startDate').val(), "L").format('DD/MM/YYYY');     // get start date
        var endDate = moment($('#endDate').val(), "L").format('DD/MM/YYYY');         // get end date                
        if (endDate != 'Invalid date') {
             if (startDate == endDate) {                                     // if start date and end date are same        
                     var startTimeHour = parseInt(moment($('#startTime').val(), "LTH").format("H"));             // get start time hour
                     var startTimeMinute = parseInt(moment($('#startTime').val(), "LTH").format("mm"));          // get start time minute
                     $('#endTime').datetimepicker('minDate', moment({// set to end time's minimum time
                         hour: startTimeHour,
                         minute: startTimeMinute,
                     }));                    
             }
         }
    });
    /**end of datetime picker*/

    // get all country
    $.post("{{ url('get-all-country') }}", {_token: "{{ csrf_token() }}", type: ""}, function (data) {
        $('#country').html(data);
        $('#country').selectpicker('refresh');
    });

    $("#keywords").tagsinput({
        confirmKeys: [32],
    });

    $('.bootstrap-tagsinput input').keydown(function (event) {
        if (event.which == 13) {
            $(this).blur();
            $(this).focus();
            return false;
        }
    });

    $('input[type="file"]').change(function () {
        var file = this.files[ 0 ];
        $("#fileName").html(file.name);
    });

    // get state by country id
    $(document).on('change', '#country', function () {
        $.post("{{ url('get-state-by-country-id') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: ""}, function (data) {
            $('#state').html(data);
            $('#state').selectpicker('refresh');
        });
    });
    // function for save event.
    $(document).on('submit', '#add-event', function (e) {
        e.preventDefault();
        var countryName = $("#country option:selected").text();
        var stateName = $("#state option:selected").text();
        var formData = new FormData($(this)[0]);
        formData.append('country', countryName);
        formData.append('state', stateName);
        showButtonLoader('saveEvent', 'Save', 'disable');
        document.getElementById('saveCancel').style.pointerEvents = 'none';
        $.ajax({
            url: $(this).attr('action'),
            data: formData,
            processData: false,
            contentType: false,
            type: 'POST',
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    message('success', data.message);
                    setTimeout(function () {
                        window.location.href = "{{ url('admin/events') }}";
                    }, 1000);
                } else {
                    message('error', data.message);
                }
            },
            error: function (e) {
            },complete: function(){
                document.getElementById('saveCancel').style.pointerEvents = 'auto';
                showButtonLoader('saveEvent', 'Save', 'enable');
            }
        });
    });
    // get all teams
    function getAllTeam() {
        $.post("{{ url('get-all-team') }}", {_token: "{{ csrf_token() }}"}, function (data) {
            $('#team1').html(data);
            $('#team1').selectpicker('refresh');
            $('#team2').html(data);
            $('#team2').selectpicker('refresh');
        });
    }
</script>

@endsection