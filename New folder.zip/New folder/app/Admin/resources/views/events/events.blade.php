@php $pageTitle = 'Events | Admin'; @endphp
@php $activePage = 'events'; @endphp

@extends('admin::layouts.app')

@section('content')
@include('admin::layouts.include.side-menu')

<div class="main-content manage_user_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2>Manage Events</h2>
            </div>
            <div class="search_section justify-content-between">
                <div class="row">
                    <div class="col-12 col-sm-8">
                        <form autocomplete="off" id="event-search" method="post" action="javascript:void(0);">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <div class="filter_dropdown">
                                        <select class="selectpicker select-custom" onchange="getListing('')" name="orderBy" id="orderBy">
                                            <option value="desc">Newest</option>
                                            <option value="asc">Oldest</option>
                                            <option value="date">Recently Updated</option>
                                        </select>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <div class="input-group">
                                        <input type="text" name="columns" onkeyup="getListing('')" id="columns" class="form-control" placeholder="Search By Keyword (ID/Name/Location/Opponent )" aria-describedby="basic-addon2">

                                        <div class="input-group-append">
                                            <button type="button" onClick="getListing('')" class="input-group-text btn btn-dark rounded-0" id="basic-addon2"> <i class="icon-search"></i> <span class="d-none d-md-block">Search</span></button>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </form>
                    </div>
                    <div class="col-12 col-sm-4">
                        <ul class="filter_right list-inline text-right mb-0">
                            <li class="list-inline-item">
                                <a href="javascript:void(0);" class="btn btn-white rounded-0" onclick="getFilterOpen()"><i class="icon-filter-filled-tool-symbol"></i> Filter</a>
                            </li>
                            <li class="list-inline-item">
                                <a href="{{ url('admin/events/add') }}" class="btn btn-dark rounded-0">Add events</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!--  -->
            <div class="filter_form bg-white" >
                <div class="d-flex top_filter">
                    <div class="filter_heading">
                        <h2>Filters</h2>
                    </div>	
                    <div class="ml-auto">
                        <div class="close_btn" onclick="getFilterClose()">
                            <div class="x common rotate30 rotate45"></div>	
                            <div class="z common rotate150 rotate135"></div>
                        </div>
                    </div>
                </div>
                <form autocomplete="off" method="post" action="javascript:void(0);" id="event-filter">
                    <div class="comman_form">
                        <h4 class="form_heading">By Status</h4>
                        <div class="form-group">
                            <label>Event Status</label>
                            <select class="selectpicker select-custom form-control " id="status" name="status" title="Status" data-size="2">
                                <option value="">Select Status</option> 
                                <option value="active">Active</option> 
                                <option value="inactive">Deactive</option> 
                            </select>
                        </div>
                    </div>
                    <div class="comman_form">
                        <h4 class="form_heading">By Status</h4>
                        <div class="form-group">
                            <label class="control-label">Start Date</label>
                            <div class="dateIcon">
                                <input type="text" id="filterStartDate" name="startDate" class="form-control rounded-0  datetimepicker-input" data-target="#filterStartDate"  data-toggle="datetimepicker" placeholder="Date" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label">End Date</label>
                            <div class="dateIcon">
                                <input type="text" id="filterEndDate" name="endDate" class="form-control rounded-0  datetimepicker-input" data-target="#filterEndDate"  data-toggle="datetimepicker" placeholder="Date"/>
                            </div>
                        </div>
                    </div>
                    <div class="form-group d-flex submit_btn mb-0">
                        <button type="button" class="btn btn-light rounded-0 ripple-effect" onclick="resetFilter('event-filter', 'event');">Reset</button>
                        <div class="ml-auto">
                            <button type="button" class="btn btn-dark rounded-0 ripple-effect" onclick="getListing('')"> Apply <i  style="display:none;" class="btn_loader"></i></button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
        <div id="eventListing">
            <!-- Rnder table with html -->				  				  		
        </div>
    </div>
</div>

<input type="hidden"  data-url="{{ url('admin/events/status') }}" id="update_status">
<script type="text/javascript" src="{{ url('public/administrator/js/common.js') }}"></script>
<script type="text/javascript">
    
    // for filter datepickers start and end date vaidations
    $("#filterStartDate").on("change.datetimepicker", function (e) {
        $('#filterEndDate').datetimepicker('minDate', e.date);
    });
    $("#filterEndDate").on("change.datetimepicker", function (e) {
        $('#filterStartDate').datetimepicker('maxDate', e.date);
    });
    //  dateFormate
    $( function () {
         initDatepicker();
    });
    
    //datetimepicker initialization 
    function initDatepicker(){
        $('#filterStartDate, #filterEndDate').datetimepicker({
            useCurrent: false,
            format: "MM/DD/YYYY",           
        });        
    }
        
//aAjax load content
var currentXhr = null;

function getListing(url) {
    if (url == '' || url == undefined) {
        url = "{{ url('admin/events/_events-list') }} ";
    }
    pageLoader('eventListing', 'show');
    var searching = $("#event-search,#event-filter").serializeArray();
    searching.push({
        name: '_token',
        value: '{{ csrf_token() }}'
    });
    currentXhr = $.ajax({
        type: "POST",
        url: url,
        data: searching,
        beforeSend: function() {
            if (currentXhr != null) {
                currentXhr.abort();
                currentXhr = null;
            }
        },
        success: function(response) {
            $("#eventListing").html("");
            $("#eventListing").html(response.html);
        },
        error: function(err) {
            //message('error', err);
            //getListing(url);
        },
        complete: function() {
            //                showButtonLoader('addButton', 'Save', 'enable');
            getFilterClose();
        }
    });
}
$(document).ready(function() {
    getListing('');

});

</script>
@endsection