@php $pageTitle = 'View Event | Admin'; @endphp
@php $activePage = 'events'; @endphp

@extends('admin::layouts.app')

@section('content')

@include('admin::layouts.include.side-menu')

<div class="main-content view_page viewevent-page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Event View</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/events') }}">Manage Events</a>
                        </li>
                        <li class="breadcrumb-item">Event View</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <div class="view_body detail-wrap">
                <div class="box_wrapper">
                    <div class="detail-top">
                        <div class="event-img">
                            <img src="{{checkUserImage($event->banner_image, 'event/thumb', 'event-banner')}}" class="img-fluid" alt="National football league">
                        </div>
                        <div class="event-detail">
                            <h2 class="heading_22">{{$event->event_name}}</h2>
                            <ul class="list-unstyled">
                                <li class="d-flex align-items-center">                    
                                    <span class="title">Location:</span>
                                    <span>
                                        {{$event->address1 }} {{ !empty($event->country_id) ? ucfirst($event->country->name) : '' }} {{!empty($event->state_id) ? ucfirst($event->state->state_name) : ''}} {{$event->city}} {{$event->zipcode}}
                                    </span>
                                </li>
                                <li class="d-flex align-items-center">
                                    <span class="title">Teams:</span> 
                                    <span>
                                        @if (intval($event->team1))                                        
                                        {{ !empty($event->team1Data->full_name) ? $event->team1Data->full_name : '-' }} 
                                        @else
                                        {{ !empty($event->team1) ? $event->team1 : '-' }}                                         
                                        @endif
                                        <strong>
                                            VS
                                        </strong>
                                        @if (intval($event->team2))                                        
                                        {{ !empty($event->team2Data->full_name) ? $event->team2Data->full_name : '-' }} 
                                        @else
                                        {{ !empty($event->team2) ? $event->team2 : '-' }}                                         
                                        @endif                                                                                
                                    </span>
                                </li>
                                <li class="d-flex align-items-center">
                                    <span class="title">Ticket url:</span> <span>{{$event->ticket_url}}</span>
                                </li>
                                <li class="d-flex align-items-center">
                                    <span class="title">Start date & time:</span> <span>{{dateTimeFormat($event->start_date.' '.$event->start_time)}}</span>
                                </li>
                                <li class="d-flex align-items-center">
                                    <span class="title">End date & time:</span> <span>{{dateTimeFormat($event->end_date.' '.$event->end_time)}}</span>
                                </li>
                                <li class="d-flex align-items-center">
                                    <span class="title">Keywords:</span> <span>{{$event->keywords}}</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="description">
                        <h2 class="heading_22">Description</h2>
                        <p>{{$event->description}}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
