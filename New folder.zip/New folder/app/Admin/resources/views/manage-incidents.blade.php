@php $pageTitle = 'Manage Incidents | Admin'; @endphp
@php $activePage = 'manage-incidents'; @endphp

@extends('admin::layouts.app')

@section('content')

	@include('admin::layouts.include.header')
	@include('admin::layouts.include.side-menu')

	<div class="main-content manage_incidents">
		<div class="content_wrapper">
			<div class="content_header">
				<div class="page_title">
					<h2>Manage Incidents</h2>
				</div>
				<!--  -->
				<div class="search_section justify-content-between">
				    <div class="row">
				    	<div class="col-12 col-sm-8">
			  				<ul class="list-inline mb-0">
			  					<li class="list-inline-item">
			  						<div class="filter_dropdown">
										<select class="selectpicker select-custom" onchange="getListing()">
											<option>Newest</option>
											<option>Oldest</option>
											<option>Recently Updated</option>
										</select>
									</div>
			  					</li>
			  					<li class="list-inline-item">
									<div class="input-group">
									  <input type="text" class="form-control" placeholder="Search by keyword (report entity / entity id / publisher / reported by)" aria-describedby="basic-addon2">
									  <div class="input-group-append">
									    <button type="submit" class="input-group-text btn btn-dark rounded-0 ripple-effect" id="basic-addon2" onclick="getListing()"> <i class="icon-search"></i> <span class="d-none d-md-block">Search</span></button>
									  </div>
									</div>
			  					</li>
			  				</ul>
					    </div>
					    <div class="col-12 col-sm-4">
				     		<ul class="filter_right list-inline text-right mb-0">
				     			<li class="list-inline-item">
				     				<a href="javascript:void(0);" class="btn btn-white rounded-0 ripple-effect" onclick="getFilterOpen()"><i class="icon-filter-filled-tool-symbol"></i> Filter</a>
				     			</li>
				     		</ul>
					    </div>
				    </div>
			 	</div>
				<!--  -->
				<div class="filter_form bg-white">
					<div class="d-flex top_filter">
						  <div class="filter_heading">
						  		<h2>Filters</h2>
						  </div>	
						  <div class="ml-auto">
								<div class="close_btn" onclick="getFilterClose()">
									<div class="x common rotate30 rotate45"></div>	
							        <div class="z common rotate150 rotate135"></div>
								</div>
						  </div>
						</div>
					<form action="">
						<div class="comman_form">
			 				<h4 class="form_heading">By status</h4>
			 				<div class="form-group">
			 					<label>Incidents status</label>
			 					<select class="selectpicker select-custom form-control " title="Status" data-size="2">
			 						<option value="Active">Active</option> 
									<option value="Deactive">Deactive</option> 
			 					</select>
			 				</div>
			 			</div>
			 			<div class="comman_form">
			 				<h4 class="form_heading">By Reported</h4>
			 				<div class="form-group">
			 					<label>Reported entity</label>
			 					<select class="selectpicker select-custom form-control " title="Status" data-size="2">
			 						<option>Micah Chan</option> 
									<option>Kendall Campos</option> 
									<option>Elmo Pratt</option> 
									<option>Kendall Campos</option> 
			 					</select>
			 				</div>
			 			</div>
			 			<div class="comman_form">
			 				<h4 class="form_heading">By date range</h4>
							<div class="form-group">
	                            <label class="control-label">From date</label>
	                            <div class="dateIcon">
	                            	<input type="text" id="satartDate" class="form-control rounded-0  datetimepicker-input" data-target="#satartDate"  data-toggle="datetimepicker" placeholder="Date" />
	                            </div>
	                        </div>
			 				<div class="form-group">
	                            <label class="control-label">To date</label>
	                            <div class="dateIcon">
	                            	 <input type="text" id="endDate" class="form-control rounded-0  datetimepicker-input" data-target="#endDate"  data-toggle="datetimepicker" placeholder="Date"/>
	                            </div>
	                        </div>
			 			</div>
				 		<div class="form-group d-flex submit_btn mb-0">
							<button type="submit" class="btn btn-light rounded-0 ripple-effect">Reset</button>
							<div class="ml-auto">
							  	<button type="submit" class="btn btn-dark rounded-0 ripple-effect" onclick="getFilterApply()"> Apply <i  style="display:none;" class="btn_loader"></i></button>
							 </div>
							
				 		</div>
					</form>
				</div>
			</div>

			<div class="content bg-white box-shadow">
				<!--  -->
				<div class="table-responsive common_table">
					<table class="table mb-0 ">
						<thead>
						    <tr>
						      <th>Incidents No.</th>
						      <th>Reported entity</th>
						      <th>Entity ID</th>
						      <th>Reported on</th>
						      <th>Publisher</th>
						      <th>Reported by</th>
						      <th>Last Updated by</th>
						      <th>Last Updated on</th>
						      <th>Status</th>
						      <th>Action</th>
						    </tr>
						</thead>
						<tbody id="listing"></tbody>
						<!-- Not Record Found -->
						<tr style="display:none;"><td colspan="8"><div class="alert alert-danger text-center">No Record Found</div></td></tr>
						<!--  -->
					</table>
				</div>
			</div>

			<div class="pagination_section box-shadow bg-white mt-3" id="paginationList" style="display: none">
				<div class="d-sm-flex align-items-center">
					<div class="page_counter">
						<p class="mb-0">Page <span class="ml-1 left">1</span><span class="mx-1">of</span><span class="right">20</span></p>
					</div>
					<div class="ml-sm-auto">
						<div class="pagination_right">
							<nav aria-label="Page navigation example">
							  <ul class="pagination mb-0">
							    <li class="page-item"><a class="page-link" href="javascript:void(0);">Previous</a></li>
							    <li class="page-item"><a class="page-link active" href="javascript:void(0);">1</a></li>
							    <li class="page-item"><a class="page-link" href="javascript:void(0);">2</a></li>
							    <li class="page-item"><a class="page-link" href="javascript:void(0);">3</a></li>
							    <li class="page-item"><a class="page-link" href="javascript:void(0);">4</a></li>
							    <li class="page-item"><a class="page-link" href="javascript:void(0);">...</a></li>
							    <li class="page-item"><a class="page-link" href="javascript:void(0);">20</a></li>
							    <li class="page-item"><a class="page-link" href="javascript:void(0);">Next</a></li>
							  </ul>
							</nav>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>

	<script type="text/javascript">
		
	//left menu toggle
	$('#filterbtn').click(function(){
		$(this).toggleClass('active');
		$('#filterform').toggleClass('slide');
	})
	$('#filterclose').click(function(){		
		$('#filterform').removeClass('slide');
		$('#filterbtn').removeClass('active');
	})

	//aAjax load content
    function getListing() {
        $("#listing").html('<tr><td colspan="8" class="listloader text-center pb-4"><span class="ajax_loader btn_ring"></span></td></td>');
        var url = "{{ url('admin/manage-incidents/_incidents-list') }}";
        $.ajax({
            type: "GET", url: url, data: {},
            success: function (response) {
                setTimeout(function () {
                    $("#listing").html("");
                    $("#listing").hide().html(response.html).fadeIn('2000');
                }, 2000);
            }
        });
    }

    $(document).ready(function () {
        getListing();
        setTimeout(function () {
            $("#paginationList").fadeIn('2000');
        }, 2000);
    });
        

	function getFilterApply() {
        $(".btn_loader").css('display', 'inline-block');
        setTimeout(function () {
              $(".btn_loader").hide();
          }, 1000);
    }
</script>

@endsection