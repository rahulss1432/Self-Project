@php $pageTitle = 'Manage Media | Admin'; @endphp
@php $activePage = 'manage-media'; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.side-menu')
<div class="main-content manage_post_view">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Manage Media View</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/manage-media') }}">Manage Media</a></li>
                        <li class="breadcrumb-item">Manage Media View</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content bg-white box-shadow manage_post">
            <div class="post_comment">
                <div class="d-flex">
                    <div class="">
                        <h2>{{ $getMedia->reference_id }}</h2>
                        <h3>{{ getUserFullNameById($getMedia->user_id) }}</h3>
                    </div>
                    <div class="ml-auto">
                        <p class="date_time text-right mb-0">{{ dateTimeFormat($getMedia->created_at) }}</p>
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item"><i class="flaticon-like"></i> {{ mediaLikeCount($getMedia->id,'like')}} </li>
                            <li class="list-inline-item"><i class="flaticon-comment"></i> {{ mediaLikeCount($getMedia->id,'comment') }} </li>
                        </ul>
                    </div>
                </div>
                <p class="description">{{ (!empty($getMedia->post->post)) ? $getMedia->post->post : '-' }}</p>
            </div>
            <div class="video_img d-flex align-items-center justify-content-center">
                @if($getMedia->media_type == 'image')
                <img src="{{ checkMediaImage($getMedia->media,  getUserById($getMedia->user_id, 'role').'/thumb') }}" alt="photo" class="img-fluid">   
                @else 
                <video controls>
                    <source src="{{ checkMediaVideo($getMedia->media, 'post') }}" type="video/mp4">
                </video>
                @endif  
            </div>
            <div class="post_comment_listing">
                <h2 class="heading">Comments</h2>
                <div class="ajax_list_load">
                    <div id="commentlist"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        getCommentList();
    });

    //ajax load content
    function getCommentList() {
        $("#commentlist").html('<span class="ajax_loader btn_ring"></span>');
        var url = "{{ url('admin/manage-media/_comments-list') }}";
        $.ajax({
            type: "GET", url: url, data: {media_id: '{{ $getMedia->id}}'},
            success: function (response) {
                $("#commentlist").html("");
                $("#commentlist").html(response.html);
            }
        });
    }
</script>
@endsection