<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Contractors Payment Admin</title>
    <?php include 'include/links.php' ?>
</head>
<?php
    $current = 'contractors-payment';
    $currentPageName = 'contractors payment';
    ?>

<body class="bg-light-gray" onload="hide_preloader();">
    <div id="preloader">
        <div class="inner">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
    </div>
    <?php include 'include/side-menu.php' ?>
    <?php include 'include/header.php' ?>
    <main class="main-content" id="mainContent">
        <div class="page-content">
            <div class="card custom_card" id="card_height">
                <div class="card-header">
                    <h4 class="page-title float-left">Contractors Payment List</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                            <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="filter_section collapse" id="searchFilter">
                        <form>
                            <div class="row">
                                <div class="col-xl-3 col-lg-4 col-sm-6">
                                    <div class="form-group">
                                        <div class="dateicon">
                                            <input type="text" readonly id="SelectDate" class="form-control form-control-lg datetimepicker-input" data-target="#SelectDate" data-toggle="datetimepicker">
                                            <label class="control-label">From Date</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-4 col-sm-6">
                                    <div class="form-group">
                                        <div class="dateicon">
                                            <input type="text" readonly id="SelectDate03" class="form-control form-control-lg datetimepicker-input" data-target="#SelectDate03" data-toggle="datetimepicker">
                                            <label class="control-label">To Date</label>
                                        </div>
                                    </div>
                                </div>
                                 <div class="col-xl-3 col-lg-4 col-sm-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-lg">
                                        <label class="control-label">Name</label>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-4 col-sm-6">
                                    <div class="form-group">
                                        <select class="form-control form-control-lg selectpicker" data-size="5">
                                            <option value="settled">Settled</option>
                                            <option value="unsettled">Unsettled</option>
                                        </select>
                                        <label class="control-label">Payment Status</label>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-4 col-sm-6">
                                    <div class="form-group d-inline-block mr-2">
                                        <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                    </div>
                                    <div class="form-group d-inline-block">
                                        <button class="btn btn-dark ripple-effect" type="submit">Reset</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="table-responsive" id="getContractorsPaymentList">
                    </div>
                    
                    <nav aria-label="Page navigation" class="paginationDiv clearfix" id="listPagination" style="display:none;">
                        <div class="nofpages float-left">
                            1 of 6 pages
                        </div>
                        <ul class="pagination float-right mb-0">
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#">4</a></li>
                            <li class="page-item"><a class="page-link" href="#">5</a></li>
                            <li class="page-item"><a class="page-link" href="#">6</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </main>
    <?php include 'include/footer.php' ?>
    <script>
    function getPaymentReportlist() {
        $("#getContractorsPaymentList").html('<div class="listloader text-center pb-4"><i class="fa-2x fa-spin fa fa-spinner"></i></div>');
        var url = '<?php echo BASE_URL ?>/admin/ajax-content/_contractors-payment-list.php';
        $.ajax({
            type: "POST",
            url: url,
            data: {},
            success: function(response) {
                setTimeout(function() {
                    $("#getContractorsPaymentList").html("");
                    $("#getContractorsPaymentList").hide().html(response).fadeIn('2000');
                }, 2000);
            }
        });
    }

    $(document).ready(function() {
        getPaymentReportlist();
        setTimeout(function() {
            $("#listPagination").fadeIn();
        }, 2000);
    });
    </script>
</body>

</html>