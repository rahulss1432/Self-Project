@extends('admin::include.app')
@section('title', 'Manage Category')
@section('content')
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Sub Category List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Back">
                        <a href="{{url('admin/manage-category')}}" class="nav-link"><i class="ti-arrow-left"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Add Sub Category">
                        <a href="javascript:void(0);" class="nav-link" onclick="showAddCategoryModel();" ><i class="ti-plus"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter" ></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="filter_section collapse" id="searchFilter">
                    <form method="post" action="javascript:load_subcategory_list()" id="search_form">
                        {{csrf_field()}}
                        <input type="hidden" name="category_id" id="categoryId">
                        <div class="row">
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control form-control-lg">
                                    <label class="control-label">Sub Category Name</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <select name="status" class="form-control form-control-lg selectpicker">
                                        <option value="">Select Status</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                    <label class="control-label">Status</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group d-inline-block mr-2">
                                    <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                </div>
                                <div class="form-group d-inline-block">
                                    <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="reset">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="select_category">
                    <form>
                        <div class="form-group col-sm-6 col-md-4 pl-0">
                            @php
                            $getAllCategories = getAllCategories();
                            @endphp
                            @if(count($getAllCategories) > 0)
                            <select class="form-control form-control-lg selectpicker" onchange="changeSubCategory(this.value)" data-size="5">
                                @foreach($getAllCategories as $data)
                                <option value="{{$data->id}}" {{($data->id == $subCategoryId) ? 'selected' : ''}}>{{$data->category_name}}</option>
                                @endforeach
                            </select>
                            @endif
                            <label class="control-label">Select Category</label>
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="getSubCategoryList">

                </div>
            </div>
        </div>
    </div>
</main>

<!-- add category modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Sub Category</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" id="addSubCategory" class="f-field" action="javascript:void(0);">
                    {{csrf_field()}}
                    <input type="hidden" name="category_id" id="category_id">
                    <div class="form-group">
                        <input type="text" name="subcategory_name" class="form-control form-control-lg" />
                        <label class="control-label">Sub Category Name</label>
                    </div>
                    <div class="form-group mb-0 text-right">
                        <button type="button" onclick="addSubcategory();" id="btnSubCategory" class="btn btn-sm btn-primary ripple-effect">
                            Submit <i id="subCategoryFormLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none"></i>
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Admin\Http\Requests\AddSubCategoryRequest','#addSubCategory') !!}
            </div>
        </div>
    </div>
</div>
<script>

    function changeSubCategory(id) {
        pageDivLoader('show', 'getSubCategoryList');
        $('#category_id').val(id);
        $('#categoryId').val(id);
        var search_filter = $("#search_form").serializeArray();
        search_filter.push({'_token': '{{ csrf_token() }}'});
        $.ajax({
            type: "POST",
            url: "{{ url('admin/load-subcategory-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getSubCategoryList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function showAddCategoryModel() {
        $("#addModal").modal('show');
    }

    function addSubcategory() {
        var formData = $("#addSubCategory").serializeArray();
        formData.push('_token', '{{ csrf_token() }}');
        if ($('#addSubCategory').valid()) {
            $('#btnSubCategory').prop('disabled', true);
            $('#subCategoryFormLoader').show();
            $.ajax({
                type: "POST",
                url: "{{ url('admin/add-subcategory') }}",
                data: formData,
                success: function (response)
                {
                    if (response.success) {
                        $("#addModal").modal('hide');
                        toastrAlertMessage('success', response.message);
                        $('#addSubCategory')[0].reset();
                        load_subcategory_list();
                        $('#subCategoryFormLoader').hide();
                        $('#btnSubCategory').prop('disabled', false);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnSubCategory').prop('disabled', false);
                        $('#subCategoryFormLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#subCategoryFormLoader').hide();
                    $('#btnSubCategory').prop('disabled', false);
                }
            });
        }
    }

    $(document).ready(function ()
    {
        $('#preloader').hide();
        $('#category_id').val('{{$subCategoryId}}');
        $('#categoryId').val('{{$subCategoryId}}');
        load_subcategory_list('');
    });

    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        load_subcategory_list('');
    }
    ;

    function load_subcategory_list()
    {
        pageDivLoader('show', 'getSubCategoryList');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push({'_token': '{{ csrf_token() }}'});
        $.ajax({
            type: "POST",
            url: "{{ url('admin/load-subcategory-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getSubCategoryList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function changeStatus(el, id) {
        if ($(el).is(':checked')) {
            var status = 'active';
        } else {
            var status = 'inactive';
        }
        bootbox.confirm({
            message: "Are you sure you want to change the status ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                }
            },
            callback: function (result) {
                if (result) {
                    update_status(id, status);
                } else {
                    if (status == 'active') {
                        $(el).prop('checked', false);
                    } else {
                        $(el).prop('checked', true);
                    }
                    return true;
                }
            }
        });
    }

    function update_status(id, status) {
        $.ajax({
            url: "{{ url('admin/change-subcategory-status') }}",
            type: 'GET',
            data: {id: id, status: status},
            cache: false,
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    toastrAlertMessage('success', data.message);
                    load_subcategory_list('');
                } else {
                    toastrAlertMessage('error', data.message);
                }
            },
            error: function (err) {
                toastrAlertMessage('error', err);
            },
            complete: function () {
            }
        });
    }
</script>
@endsection