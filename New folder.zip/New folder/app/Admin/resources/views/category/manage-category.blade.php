@extends('admin::include.app')
@section('title', 'Manage Category')
@section('content')
<main class="main-content" id="mainContent">
    <div class="page-content pt-1">
        <ul class="nav nav-tabs admin-tabs border-0" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="category-tab" onclick="showCategoryTab();" data-toggle="tab" href="#Category" role="tab" aria-controls="home" aria-selected="true">Category</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="requested-tab" onclick="showRequestCategoryTab();" data-toggle="tab" href="#Requested" role="tab" aria-controls="profile" aria-selected="false">Requested Category</a>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="Category" role="tabpanel" aria-labelledby="sub-category-tab">
                <div class="card custom_card">
                    <div class="card-header">
                        <h4 class="page-title float-left">Category List</h4>
                        <ul class="list-inline mb-0 text-right">
                            <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Add Category">
                                <a href="javascript:void(0);" class="nav-link" onclick="showAddCategoryModel();" ><i class="ti-plus"></i></a>
                            </li>
                            <li class="list-inline-item"data-toggle="tooltip" data-placement="top" title="Filter">
                                <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="filter_section collapse" id="searchFilter">
                            <form method="post" action="javascript:load_category_list()" id="search_form">
                                {{csrf_field()}}
                                <div class="row">
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <input type="text" name="name" class="form-control form-control-lg">
                                            <label class="control-label">Category Name</label>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <select name="status" class="form-control form-control-lg selectpicker">
                                                <option value="">Select Status</option>
                                                <option value="active">Active</option>
                                                <option value="inactive">Inactive</option>
                                            </select>
                                            <label class="control-label">Status</label>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-4 col-sm-6">
                                        <div class="form-group d-inline-block mr-2">
                                            <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                        </div>
                                        <div class="form-group d-inline-block">
                                            <button class="btn btn-dark ripple-effect" onclick="resetForm();" type="submit">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="table-responsive" id="getCategoryList">

                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="Requested" role="tabpanel" aria-labelledby="requested-tab">
                <div class="card custom_card">
                    <div class="card-header">
                        <h4 class="page-title float-left">Requested Category List</h4>
                        <ul class="list-inline mb-0 text-right">
                            <!--                            <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                                                            <a href="#searchFilter01" data-toggle="collapse" class="nav-link"><i class="ti-filter" ></i></a>
                                                        </li>-->
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="filter_section collapse" id="searchFilter01">
                            <form>
                                <div class="row">
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-lg">
                                            <label class="control-label">Requested Category Name</label>
                                        </div>
                                    </div>

                                    <div class="col-xl-3 col-lg-4 col-sm-6">
                                        <div class="form-group d-inline-block mr-2">
                                            <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                        </div>
                                        <div class="form-group d-inline-block">
                                            <button class="btn btn-dark ripple-effect" type="submit">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="select_category">
                            <form>
                                <div class="form-group col-sm-6 col-md-4 pl-0">
                                    <select class="form-control form-control-lg selectpicker" data-size="5">
                                        <option value="automobile">Automobile</option>
                                        <option value="music">Music & Audio</option>
                                        <option value="languages">Languages</option>
                                        <option value="arts">Arts</option>
                                        <option value="craftsmanship">Craftsmanship</option>
                                        <option value="sports">Sports</option>
                                        <option value="photography">Photography & Video</option>
                                        <option value="ccademics">Academics</option>
                                        <option value="computers">Computers</option>
                                        <option value="cooking">Cooking</option>
                                    </select>
                                    <label class="control-label">Select Category</label>
                                </div>
                            </form>
                        </div>
                        <div class="table-responsive" id="getRequestedList">

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</main>

<!-- add category modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Category</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" id="addCategory" class="f-field" action="javascript:void(0);" enctype="multipart/form-data">
                    <input type="hidden" name="category_id" id="category_id">
                    <div class="form-group">
                        <input type="text" name="category_name" class="form-control form-control-lg" />
                        <label class="control-label">Category Name</label>
                    </div>
                    <div class="form-group">
                        <input type="file" name="category_icon" class="form-control form-control-lg" />
                    </div>
                    <div class="form-group mb-0 text-right">
                        <button type="button" onclick="addCategory();" id="btnCategory" class="btn btn-sm btn-primary ripple-effect">
                            Submit <i id="categoryFormLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none"></i>
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Admin\Http\Requests\AddCategoryRequest','#addCategory') !!}
            </div>
        </div>
    </div>
</div>
<script>

    function showAddCategoryModel() {
        $("#addModal").modal('show');
    }

    function addCategory() {
        var formData = new FormData($('#addCategory')[0]);
        formData.append('_token', '{{ csrf_token() }}');
        if ($('#addCategory').valid()) {
            $('#btncCategory').prop('disabled', true);
            $('#categoryFormLoader').show();
            $.ajax({
                type: "POST",
                url: "{{ url('admin/add-category') }}",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response)
                {
                    if (response.success) {
                        $("#addModal").modal('hide');
                        toastrAlertMessage('success', response.message);
                        $('#addCategory')[0].reset();
                        load_category_list();
                        $('#categoryFormLoader').hide();
                        $('#btnCategory').prop('disabled', false);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnCategory').prop('disabled', false);
                        $('#categoryFormLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#categoryFormLoader').hide();
                    $('#btnCategory').prop('disabled', false);
                }
            });
        }
    }

    $(document).ready(function ()
    {
        $('#preloader').hide();
        load_category_list();
    });

    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        load_category_list();
    }

    function load_category_list()
    {
        pageDivLoader('show', 'getCategoryList');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "POST",
            url: "{{ url('admin/load-category-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getCategoryList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function load_requested_category()
    {
        pageDivLoader('show', 'getRequestedList');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "POST",
            url: "{{ url('admin/load-category-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#getRequestedList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function changeStatus(el, id) {
        if ($(el).is(':checked')) {
            var status = 'active';
        } else {
            var status = 'inactive';
        }
        bootbox.confirm({
            message: "Are you sure you want to change the status ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                }
            },
            callback: function (result) {
                if (result) {
                    update_status(id, status);
                } else {
                    if (status == 'active') {
                        $(el).prop('checked', false);
                    } else {
                        $(el).prop('checked', true);
                    }
                    return true;
                }
            }
        });
    }

    function update_status(id, status) {
        $.ajax({
            url: "{{ url('admin/change-category-status') }}",
            type: 'GET',
            data: {id: id, status: status},
            cache: false,
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    toastrAlertMessage('success', data.message);
                    load_category_list();
                } else {
                    toastrAlertMessage('error', data.message);
                }
            },
            error: function (err) {
                toastrAlertMessage('error', err);
            },
            complete: function () {
            }
        });
    }

    function showCategoryTab() {
        load_category_list();
    }

    function showRequestCategoryTab() {
        load_requested_category();
    }
</script>
@endsection