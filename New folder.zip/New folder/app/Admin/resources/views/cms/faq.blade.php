@extends('admin::include.app')
@section('title', 'Manage Cms')
@section('content')        
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content" id="pageContent">
        <div class="card custom_card" id="card_height">
            <div class="card-header">
                <h4 class="page-title float-left">FAQ List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/add-faqs')}}" class="nav-link"><i class="ti-plus"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="admin-tabs">
                    <div class="tab-content">
                        <div class="tab-pane fade show active">
                            <div class="table-responsive" id="getFaqList">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</main>
<script>
    $(document).ready(function ()
    {
        $('#preloader').hide();
        load_faq_list();
    });

    function resetForm() {
        load_faq_list();
    }
    ;

    function load_faq_list()
    {
        pageDivLoader('show', 'getFaqList');
        $.ajax({
            type: "GET",
            url: "{{ url('admin/load-faq-list') }}",
            success: function (response)
            {
                if (response.success) {
                    $("#getFaqList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function removeFaq(id) {
        bootbox.confirm({
            message: "Are you sure you want to delete this ?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn btn-sm btn-primary ripple-effect success_btn'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn btn-sm btn-dark ripple-effect mr-2 cancle_btn'
                },
            },
            callback: function (result) {
                if (result) {
                    var url = "{{ url('admin/remove-faq') }}/ " + id;
                    $.ajax({type: "GET", url: url,
                        success: function (response) {
                            if (response.success) {
                                toastrAlertMessage('success', response.message);
                                load_faq_list();
                            } else {
                                toastrAlertMessage('error', response.message);
                            }
                        }
                    });
                }
            }
        });
    }
</script>
@endsection