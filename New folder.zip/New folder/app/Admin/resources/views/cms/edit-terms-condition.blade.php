@extends('admin::include.app')
@section('title', 'Manage Cms')
@section('content')
<main class="main-content cms-edit" id="mainContent">
    <div class="page-content" id="pageContent" >
        <div class="card custom_card" id="card_height">
            <div class="card-header">
                <h4 class="page-title float-left">Update Terms Condition</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/cms')}}" class="nav-link" title="Back"><i class="ti-arrow-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-xl-8 offset-xl-2">
                        <form class="f-field">
                            <div class="form-group">
                                <input type="text" class="form-control form-control-lg" placeholder="" required>
                                <label class="control-label">Title</label>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-lg" placeholder="" required>
                                <label class="control-label">Meta Title</label>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control form-control-lg"  required=""></textarea>
                                <label class="control-label">Meta Description</label>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control form-control-lg"  required=""></textarea>
                                <label class="control-label">Description</label>
                            </div>
                            <div class="from-group">
                                <button type="submit" class="btn btn-sm btn-primary ripple-effect">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection