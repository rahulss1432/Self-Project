@extends('admin::include.app')
@section('title', 'Manage Cms')
@section('content')
<main class="main-content cms-page" id="mainContent">
    <div class="page-content" id="pageContent">
        <div class="card custom_card" id="card_height">
            <div class="card-header">
                <h4 class="page-title float-left">CMS Pages List</h4>
            </div>
            <div class="card-body">
                <div class=" table-responsive" id="getCmsList">
                   
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function ()
    {
        $('#preloader').hide();
        load_cms_list();
    });

    function resetForm() {
        load_cms_list();
    }
    ;

    function load_cms_list()
    {
        pageDivLoader('show', 'getCmsList');
        $.ajax({
            type: "GET",
            url: "{{ url('admin/load-cms-list') }}",
            success: function (response)
            {
                if (response.success) {
                    $("#getCmsList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection