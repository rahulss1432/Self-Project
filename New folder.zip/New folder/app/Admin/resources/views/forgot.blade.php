<html lang="en">
    <head>
        <title>Login</title>
        <!-- Bootstrap -->
        @include('admin::layouts.include.head-link')
    </head>
    <body class="login-page ">
        <main >
            <div class="login-wrap mx-auto">
                <div class="login-header d-flex align-items-center justify-content-center">
                    <img src="{{ url('public/administrator/images/white_logo.png') }}" alt="logo">
                </div>
                <h3 class="title">Forgot Password</h3>
                <div class="login-field">
                    <form class="needs-validation" id="admin_forgot" method="post" action="{{ URL('admin/forgot-password') }}" autocomplete="off" novalidate>
                        {{ csrf_field() }}
                        <div class="form-group">
                            <input type="email" name="email" class="form-control form-control-lg" placeholder="Email"/>
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" id="forgot-password-btn" class="btn btn-success btn_radius btn-block ripple-effect">
                                SUBMIT <span class="btn_loader" style="display: none;"></span>
                            </button>
                        </div>
                    </form>
                    {!! JsValidator::formRequest('App\Admin\Http\Requests\ForgotRequest','#admin_forgot') !!}
                </div>
                <div class="login-footer text-right">
                    <a href="{{URL('admin/login')}}">Sign In?<span class="fa fa-long-arrow-right"></span></a>
                </div>
            </div>
        </main>
        @include('admin::layouts.include.footer')
    </body>  
</html>
<script>
    $(document).on('submit', '#admin_forgot', function (e) {
        $('#forgot-password-btn').html('<i class="fa fa-spinner fa-pulse fa-1x"></i>');
        $('#forgot-password-btn').prop('disabled',true);
        e.preventDefault();
        $.post($(this).attr('action'), $(this).serialize(), function (data) {
            $('#forgot-password-btn').html('SUBMIT');
             $('#forgot-password-btn').prop('disabled',false);
            if (data.success) {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.success(data.message, {timeOut: 1500});
                window.location.href = "{{ url('admin/login') }}";
            } else {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error(data.message, {timeOut: 1500});
            }
        });
    });
</script>