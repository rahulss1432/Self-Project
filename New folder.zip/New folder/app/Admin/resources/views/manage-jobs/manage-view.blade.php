
@php $pageTitle = 'Job Detail | Admin'; @endphp
@php $activePage = 'manage-jobs'; @endphp

@extends('admin::layouts.app')

@section('content')

@include('admin::layouts.include.header')
@include('admin::layouts.include.side-menu')
<div class="main-content job_view">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">{{!empty($jobDetail->job_type)? ucfirst($jobDetail->job_type):'-'}} Job View</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{url('admin/manage-jobs')}}">Manage Jobs</a></li>
                        <li class="breadcrumb-item">{{!empty($jobDetail->job_type)? ucfirst($jobDetail->job_type):'-'}} Job View</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <!-- job view  -->
            <div class="ajax_list_load">
                <div class="view_body">
                    <div class="row">
                        <div class="col-xl-6 col-lg-12 col-md-12">
                            <div class="box_wrapper mb-30 height-100">
                                <h2 class="heading_22 mb-3 ">General</h2>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Job Type:</label>	</div>
                                        <div class="col-sm-7 col-12"> <span>{{!empty($jobDetail->job_type) ? ucfirst($jobDetail->job_type) : '-'}}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Institution Name:</label>	</div>
                                        <div class="col-sm-7 col-12"> <span>{{!empty($jobDetail->institution_name) ? ucfirst($jobDetail->institution_name) : '-'}}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Institution Type:</label>	</div>
                                        <div class="col-sm-7 col-12"> <span>{{!empty($jobDetail->institution_type) ? ucfirst($jobDetail->institution_type) : '-' }}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Level Of Team:</label></div>
                                        <div class="col-sm-7 col-12"> <span>{{!empty($jobDetail->level_id) ? getLevelName($jobDetail->level_id) : '-' }}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>League Or Conference:</label>	</div>
                                        <div class="col-sm-7 col-12"> <span>{{!empty($jobDetail->conference) ? ucfirst($jobDetail->conference) : '-' }}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Player Position Title:</label>	</div>
                                        <div class="col-sm-7 col-12"> <span>
                                                @php
                                                $positionName = [];
                                                $positions = explode(',',$jobDetail->position_id);
                                                foreach($positions as $key => $val){
                                                $positionName[$key] = getJobPositionByAdmin($val);
                                                }
                                                if(count($positionName) > 0){
                                                echo implode(',',$positionName);
                                                }else{
                                                echo '-';
                                                }
                                                @endphp
                                            </span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Country:</label>	</div>
                                        <div class="col-sm-7 col-12"> <span>{{ ucfirst($jobDetail->country->name)}}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>State:</label>	</div>
                                        <div class="col-sm-7 col-12"> <span>{{ ucfirst($jobDetail->state->state_name)}}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>City:</label>	</div>
                                        <div class="col-sm-7 col-12"> <span>{{ ucfirst($jobDetail->city)}}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Zip Code:</label></div>
                                        <div class="col-sm-7 col-12"> <span>{{$jobDetail->zip_code}}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Relevant experience:</label></div>
                                        <div class="col-sm-7 col-12"> <span>{{$jobDetail->experience}}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Last date to apply:</label></div>
                                        <div class="col-sm-7 col-12"> <span>{{$jobDetail->apply_date}}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Salary range:</label></div>
                                        <div class="col-sm-7 col-12"> <span>{{$jobDetail->from_salary}} - {{$jobDetail->to_salary}}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row ">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Benifits:</label></div>
                                        <div class="col-sm-7 col-12"> <span>
                                                @php
                                                $benefitsName = [];
                                                $benefits = explode(',',$jobDetail->benefits);
                                                foreach($benefits as $key => $val){
                                                $benefitsName[$key] = getJobBenefitsByAdmin($val);
                                                }
                                                if(count($benefitsName) > 0){
                                                echo implode(',', $benefitsName);
                                                }else{
                                                echo '-';
                                                }
                                                @endphp
                                            </span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row ">
                                    <div class="row">
                                        <div class="col-sm-5 col-12"> <label>Application Acceptable Through:</label></div>
                                        <div class="col-sm-7 col-12"> <span>{{ ucfirst($jobDetail->app_accept) }}</span></div>
                                    </div>
                                </div>
                                <div class="form-group info_row">
                                    <label class="mb-2">Skills Required:</label>
                                    <p class="mb-0">{{ ucfirst($jobDetail->skills)}}</p>
                                </div>
                                <div class="form-group info_row mb-0">
                                    <label class="mb-2">Job Description:</label>
                                    <p class="mb-0">{{ ucfirst($jobDetail->job_description)}}</p>
                                </div>
                            </div>
                        </div>

                        <!-- xxxxxxxx -->

                        <div class="col-xl-6 col-lg-12 col-md-12">
                            <div class="box_wrapper questionnaire mb-30 black-scroll"  id="QuestionnaireList">
                                <h2 class="heading_22 mb-3">Questionnaire</h2>
                                @if(!empty($jobDetail->jobQuestionnaire->jobQuestion) && count($jobDetail->jobQuestionnaire->jobQuestion) > 0)
                                @foreach($jobDetail->jobQuestionnaire->jobQuestion  as $question)
                                <div class="common_question">
                                    <div class="question">
                                        <label>Question:</label>
                                        <span><b>{{ $question->question }} </b></span>
                                    </div>
                                    <div class="answer d-flex">
                                        <label>Answer:</label>
                                        <ul class="list-unstyled d-inline-block mb-0">
                                            @if(!empty($question->jobQuestionsAnswer) && count($question->jobQuestionsAnswer) > 0)
                                            @foreach($question->jobQuestionsAnswer as $ansKey =>  $answer)
                                            <li>{{ $ansKey + 1 }}.{{ $answer->answer }}</li>
                                            @endforeach
                                            @endif
                                        </ul>
                                    </div>
                                    <div class="type">
                                        <label>Type:</label>
                                        <span>{{ $question->type }}</span>
                                    </div>
                                </div>
                                @endforeach
                                @endif
                            </div>
                            <div class="box_wrapper">
                                <h2 class="heading_22 mb-3 ">Contacts</h2>
                                <div class="form-group info_row_flex">
                                    <label>Social Media1:</label>	
                                    <span>{{$jobDetail->media1}}</span>
                                </div>
                                <div class="form-group info_row_flex">
                                    <label>Social media2:</label>	
                                    <span>{{$jobDetail->media2}}</span>
                                </div>
                                <div class="form-group info_row_flex">
                                    <label>Social media3:</label>	
                                    <span>{{$jobDetail->media3}}</span>
                                </div>
                                <div class="form-group info_row_flex">
                                    <label>Contact Person:</label>	
                                    <span>{{ ucfirst($jobDetail->contact_person)}}</span>
                                </div>
                                <div class="form-group info_row_flex">
                                    <label>Email:</label>	
                                    <span>{{$jobDetail->email}}</span>
                                </div>
                                <div class="form-group mb-0 info_row_flex">
                                    <label>Phone Number:</label>	
                                    <span>{{$jobDetail->phone}}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script type="text/javascript">

    //ajax load content
    function getJobDetail() {
        $("#playerjoblist").html('<span class="ajax_loader btn_ring"></span>');
        var url = 'admin/job-detail';
        $.ajax({type: "POST", url: url, data: {},
            success: function (response) {
                setTimeout(function () {
                    $("#playerjoblist").html("");
                    $("#playerjoblist").hide().html(response).fadeIn('3000');
                }, 2000);
            }
        });
    }

    $(document).ready(function () {
        // getJobDetail();
        $("#QuestionnaireList").mCustomScrollbar({
            theme: "dark"
        });
    });


</script>

@endsection