<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Manage User</title>

    <?php include 'include/links.php' ?>
</head>
<?php
    $current = 'manage-user';
    $currentPageName = 'manage users';
    ?>

<body class="bg-light-gray" onload="hide_preloader();">
    <div id="preloader">
        <div class="inner">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
    </div>

    <?php include 'include/side-menu.php' ?>
    <?php include 'include/header.php' ?>
    <main class="main-content common-grid-list" id="mainContent">
        <div class="page-content">
            <div class="card custom_card">
                <div class="card-header">
                    <h4 class="page-title float-left">User List</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                            <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="ti-filter"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="filter_section collapse" id="searchFilter">
                        <form>
                            <div class="row">
                                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-lg">
                                        <label class="control-label">Customer Name</label>
                                    </div>
                                </div>

                                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-lg">
                                        <label class="control-label">Email</label>
                                    </div>
                                </div>

                                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <select class="form-control form-control-lg selectpicker">
                                            <option value="active">Active</option>
                                            <option value="inactive">Inactive</option>
                                        </select>
                                        <label class="control-label">Status</label>
                                    </div>
                                </div>

                                <div class="col-xl-3 col-lg-4 col-sm-6">
                                    <div class="form-group d-inline-block mr-2">
                                        <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                    </div>
                                    <div class="form-group d-inline-block">
                                        <button class="btn btn-dark ripple-effect" type="submit">Reset</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="table-responsive" id="getUserList">

                    </div>
                    <nav aria-label="Page navigation" class="paginationDiv clearfix" id="listPagination" style="display:none;">
                        <div class="nofpages float-left">
                            1 of 6 pages
                        </div>
                        <ul class="pagination float-right mb-0">
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#">4</a></li>
                            <li class="page-item"><a class="page-link" href="#">5</a></li>
                            <li class="page-item"><a class="page-link" href="#">6</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </main>

    <!-- prfole modal -->
    <div class="modal fade" id="customerProfile" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="customerprofile" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md profile-modal" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Customer Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="ti-close"></i>
                    </button>
                </div>
                <div class="modal-body">
                <div class="user_info">
                <div class="info_row">
                    <div class="img_wrap">
                        <img src="<?php echo IMAGES_URL ?>/user.jpg" alt="profile-img" class="img-fluid">
                    </div>
                    <div class="details">
                     <ul class="right_side list-unstyled">
                         <li>
                             <label>Name</label>
                             <span>Garrett Bird</span>
                         </li>
                         <li>
                             <label>Email</label>
                             <span>	garrettb@gmail.com</span>
                         </li>
                         <li>
                             <label>Phone Number</label>
                             <span>0428789958</span>
                         </li>
                         <li>
                             <label>DOB</label>
                             <span>10/08/2008</span>
                         </li>
                         <li>
                             <label>Status</label>
                             <span class="text-success">Active</span>
                         </li>
                         <li>
                             <label>Date Added</label>
                             <span>	10/01/2018</span>
                             </li>
                     </ul>
                    </div>
                </div>
                <div class="full-dtl">
                <ul class="right_side list-unstyled">
                           <li>
                             <label>User  Unique URL </label>
                             <span class="d-block"><a href="javascript:void(0);" class="theme-color">https://www.mentolocator.com/Garrettbird</a></span>
                         </li>
                         <li>
                             <label>Address</label>
                             <span class="d-block">45 st peter Warner, Queensland, 4500 Australia</span>
                         </li>
                       
                         <li>
                             <label>Bio</label>
                             <span class="d-block">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span>
                         </li>
                      </ul>
                </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'include/footer.php' ?>

    <script>
        function profileView(){
            $("#customerProfile").modal('show');
        }
        function getCustomerslist() {
            $("#getUserList").html('<div class="listloader text-center pb-4"><i class="fa-2x fa-spin fa fa-spinner"></i></div>');
            var url = '<?php echo BASE_URL ?>/admin/ajax-content/_manage-user.php';
            $.ajax({
                type: "POST", url: url, data: {},
                success: function (response) {
                    setTimeout(function () {
                        $("#getUserList").html("");
                        $("#getUserList").hide().html(response).fadeIn('2000');
                    }, 2000);
                }
            });
        }

        $(document).ready(function () {
            getCustomerslist();
            setTimeout(function () {
                $("#listPagination").fadeIn();
            }, 2000);
        });
    </script>

</body>

</html>