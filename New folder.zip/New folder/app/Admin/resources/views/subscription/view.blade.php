@php $pageTitle = 'Subscriptions | Admin'; @endphp
@php $activePage = 'subscriptions'; @endphp
@extends('admin::layouts.app')
@section('content')
@include('admin::layouts.include.header')
@include('admin::layouts.include.side-menu')

<div class="main-content adduser_page">
    <div class="content_wrapper">
        <div class="content_header" id="content-header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Subscriptions View</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/subscriptions') }}">Subscriptions</a>
                        </li>
                        <li class="breadcrumb-item">Subscriptions View</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <div class="view_body">
                <div class="box_wrapper " id="content-height">
                    <div class="form-group info_row_flex d-sm-flex">
                        <label>Name:</label>	
                        <span>{{ ($subscription->title) ? $subscription->title : '' }}</span>
                    </div>
                    <div class="form-group info_row_flex d-sm-flex">
                        <label>Renewal Cycle:</label>
                        <span>{{ ($subscription->renewal_cycle) ? $subscription->renewal_cycle : '' }}</span>
                    </div>
                    <div class="form-group info_row_flex d-sm-flex">
                        <label>Amount:</label>
                        <span>{{  ($subscription->amount) ? $subscription->amount : '' }}</span>
                    </div>
                    <div class="form-group info_row_flex d-sm-flex">
                        <label>Description:</label>
                    </div>
                    @if($subscription->subDescription)
                    @foreach($subscription->subDescription as $description)
                    <span>{{ ucfirst($description->description) }}</span><br>
                    @endforeach
                    @endif   
                </div>
            </div>
        </div>
    </div>
</div>
@endsection