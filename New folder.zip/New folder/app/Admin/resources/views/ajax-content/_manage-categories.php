<?php include_once '../include/constant.php'; ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Category Name</th>
            <th>Sub Category</th>
            <th class="w150 text-center">Status</th>
        </tr>
    </thead>

    <tbody>
        <!-- xxx -->
        <tr>
        <td>Automobile</td>
        <td><a href="<?php echo BASE_URL ?>/admin/manage-sub-category.php" class="bg-blue">View <span class="badge badge-light">5</span></a></td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Music & Audio</td>
           <td><a href="<?php echo BASE_URL ?>/admin/manage-sub-category.php" class="bg-blue">View <span class="badge badge-light">2</span></a></td>
            <td>
                <div class="switch text-center ">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Languages</td>
           <td><a href="<?php echo BASE_URL ?>/admin/manage-sub-category.php" class="bg-blue">View <span class="badge badge-light">8</span></a></td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

         <!-- xxx -->
         <tr>
         <td>Arts</td>
         <td><a href="<?php echo BASE_URL ?>/admin/manage-sub-category.php" class="bg-blue">View <span class="badge badge-light">5</span></a></td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Craftsmanship</td>
           <td><a href="<?php echo BASE_URL ?>/admin/manage-sub-category.php" class="bg-blue">View <span class="badge badge-light">5</span></a></td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Sports</td>
           <td><a href="<?php echo BASE_URL ?>/admin/manage-sub-category.php" class="bg-blue">View <span class="badge badge-light">6</span></a></td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

         <!-- xxx -->
         <tr>
         <td>Photography & Video</td>
         <td><a href="<?php echo BASE_URL ?>/admin/manage-sub-category.php" class="bg-blue">View <span class="badge badge-light">5</span></a></td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Academics</td>
           <td><a href="<?php echo BASE_URL ?>/admin/manage-sub-category.php" class="bg-blue">View <span class="badge badge-light">4</span></a></td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Computers</td>
           <td><a href="<?php echo BASE_URL ?>/admin/manage-sub-category.php" class="bg-blue">View <span class="badge badge-light">5</span></a></td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

         <!-- xxx -->
         <tr>
           <td>Cooking</td>
           <td><a href="<?php echo BASE_URL ?>/admin/manage-sub-category.php" class="bg-blue">View <span class="badge badge-light">3</span></a></td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

    </tbody>
</table>