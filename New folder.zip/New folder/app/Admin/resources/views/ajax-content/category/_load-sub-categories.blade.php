@if(count($subCategories) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Sub Category Name</th>
            <th class="w150 text-center">Status</th>
        </tr>
    </thead>
    <tbody>
        @foreach($subCategories as $category)
        <tr>
            <td>{{$category->name}}</td>
            <td>
                <div class="switch text-center">
                    <label>
                        @if($category->status == 'active')
                        <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this,'{{$category->id}}')">
                        @else
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'{{$category->id}}')">
                        @endif
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $subCategories->links() }}
<script>
    $(".pagination li a").on('click', function (e) {
        pageDivLoader('show', 'getSubCategoryList');
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
                $('.pagination:first').remove();
                $('#getSubCategoryList').html(response.html);
            }
        });
    });
</script>     