@if(count($categories) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Category Name</th>
            <th>Category Icon</th>
            <th>Sub Category</th>
            <th class="w150 text-center">Status</th>
        </tr>
    </thead>
    <tbody>
        @foreach($categories as $category)
        <tr>
            <td>{{$category->category_name}}</td>
            <td><img src="{{checkCategoryIcon($category->category_icon, 'category_icons')}}" width="50" height="50"/></td>
            <td><a href="{{url('admin/get-sub-category/'.base64_encode($category->id))}}" class="bg-blue">View <span class="badge badge-light">{{getSubCategoryCount($category->id)}}</span></a></td>
            <td>
                <div class="switch text-center">
                    <label>
                        @if($category->status == 'active')
                        <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this,'{{$category->id}}')">
                        @else
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'{{$category->id}}')">
                        @endif
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $categories->links() }}
<script>
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getCategoryList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getCategoryList').html(response.html);
            }
    });
    });
</script>
