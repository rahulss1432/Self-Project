@if(count($users) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Customer Name</th>
            <th>Email</th>
            <th>Unique url</th>
            <th>Date Added</th>
            <th>Status</th>
            <th class="w150 text-center">Block/Unblock</th>
        </tr>
    </thead>
    <tbody>
        @foreach($users as $user)
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView('{{$user->id}}')">{{getFullName($user->first_name,$user->last_name)}}</a>
            </td>
            <td>{{$user->email}}</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td>{{showDateFormat($user->created_at)}}</td>
            <td>
                <div class="switch">
                    <label>
                        @if($user->status == 'active')
                        <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this,'{{$user->id}}')">
                        @else
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'{{$user->id}}')">
                        @endif
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $users->links() }}
<script>
    $('[data-toggle="tooltip"]').tooltip({trigger: "hover"});
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getUserList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getUserList').html(response.html);
            }
    });
    });
</script>  