@if(!empty($getMedia) && count($getMedia) > 0)
@foreach($getMedia as $key=> $comment)
<div class="comment_list">
    <div class="d-flex align-items-center">
        <div class="d-flex align-items-center">
            <div class="profile_img rounded-circle">
                <img src="{{ checkUserImage(!empty($comment->fromUser->profile_image) ? $comment->fromUser->profile_image : '', !empty($comment->fromUser->role) ? $comment->fromUser->role : '') }}" alt="Profile">
            </div>
            <h3 class="mb-0">{{ !empty($comment->fromUser->full_name) ? ucfirst($comment->fromUser->full_name) : '' }}</h3>
        </div>
        <div class="ml-auto">
            <div class="date_time">
                <span>{{ dateTimeFormat($comment->created_at) }}</span>
            </div>
        </div>
    </div>
    <div class="description">
        <p> {{ ucfirst($comment->comment) }}</p>
    </div>
</div>
@endforeach
@else 
<div class="alert alert-danger text-center">No Comment Found.</div>
@endif
