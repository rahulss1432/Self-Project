<div class="content bg-white box-shadow">
    <div class="table-responsive common_table">
        <table class="table mb-0 ">
            <thead>
                <tr>
                    <th>Media ID</th>
                    <th>Media Type</th>
                    <th>Posted By</th>
                    <th>Post ID</th>
                    <th>Posted Date & Time</th>
                    <th>Size</th>
                    <th>Likes</th>
                    <th>Comments</th>
                    <th>Last Updated By</th>
                    <th>Last Updated On</th>
                    <!--<th>Status</th>-->
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                 @forelse ($mediaList as $media)
                <tr>
                    @php 
                    $post = \App\Models\Post::where(['id' => $media->post_id])->first(['post_type']);
                    @endphp                    
                    <td>{{ ($media->reference_id) ? $media->reference_id : '-' }}</td>
                    <td>{{ ($media->media_type) ? ucfirst($media->media_type) : '-' }}</td>
                    <td>{{ getUserFullNameById($media->user_id) }}</td>
                    <td>{{ $media->post_reference_id }}</td>
                    <td>{{ dateTimeFormat($media->created_at) }}</td>
                    <td>{{ readableBytesToUnit($media->size,'MB') }}</td>
                    <td>{{ mediaLikeCount($media->id,'like') }}</td>
                    <td>{{ mediaLikeCount($media->id,'comment') }}</td>
                    <td>{{ getUserFullNameById($media->user_id) }}</td>
                    <td>{{ ($media->updated_at) ? dateTimeFormat($media->updated_at) : '-' }}</td>
                     <!--<td>
                        <div class="switch">
                            <label>
                                @if($media->status == 'active' )
                                <input type="checkbox" name="activeInactive" checked onchange="getValue(this,'{{$media->id}}')">
                                @else
                                <input type="checkbox" name="activeInactive" onchange="getValue(this,'{{$media->id}}')">
                                @endif
                                <span class="lever"></span>
                            </label>
                        </div>
                    </td>-->
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="{{ url('admin/menage-media/view/'.base64_encode($media->id)) }}">View</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                 @empty
                    <tr style=""><td colspan="11"><div class="alert alert-danger text-center">No Record Found</div></td></tr>
                 @endforelse
            </tbody>
        </table>
    </div>
</div>
{{ $mediaList->links() }} 
<script>
    $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        getListing(pageLink);
    });
</script>



