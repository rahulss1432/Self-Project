<div class="view_body adduser_page">
    <div class="row">
        <div class="col-sm-6">
            <div class="add_details add_form">
                <div class="card">
                    <div class="card-header">Contact Details</div>
                    <div class="card-body">
                        <form action="{{ url('admin/cms/update-contacts') }}" id="contactForm" method="post">
                            {{ csrf_field()}}
                            <div class="field_content">
                                <div class="field_box">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <input type="text" class="form-control" name="address" value="{{ $settingValue->getSettingsValue('address') }}">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group mobile_no">
                                                <label>Mobile Number</label> 
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <select class="selectpicker select-custom form-control"  name="contry_code" data-size="4" title="&nbsp;">
                                                            <option {{ ($settingValue->getSettingsValue('contry_code') == 'Armenia') ? 'selected' : ''}} value="Armenia" selected="">+91</option> 
                                                            <option {{ ($settingValue->getSettingsValue('contry_code') == 'Aruba') ? 'selected' : '' }} value="Aruba">+62</option> 
                                                            <option {{ ($settingValue->getSettingsValue('contry_code') == 'Australia') ? 'selected' : ''  }} value="Australia">+365</option> 
                                                            <option {{ ($settingValue->getSettingsValue('contry_code') == 'Austria') ? 'selected' : ''  }} value="Austria">+3655</option> 
                                                            <option {{ ($settingValue->getSettingsValue('contry_code') == 'Austria') ? 'selected' : ''}} value="Austria">+3655</option> 
                                                        </select>
                                                    </div>
                                                    <input type="text" class="form-control" aria-label="Text input with dropdown button" name="mobile_number"  value="{{$settingValue->getSettingsValue('mobile_number') }}" maxlength="14">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Email</label>
                                                <input type="text" class="form-control" name="email" value="{{ $settingValue->getSettingsValue('email') }}">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Facebook Url</label>
                                                <input type="text" class="form-control" name="facebook_url" value="{{ $settingValue->getSettingsValue('facebook_url') }}">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Twitter Url</label>
                                                <input type="text" class="form-control" name="twitter_url" value="{{ $settingValue->getSettingsValue('twitter_url') }}">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Instagram Url</label>
                                                <input type="text" class="form-control"name="instagram_url" value="{{ $settingValue->getSettingsValue('instagram_url') }}" >
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Copyright</label>
                                                <input type="text" class="form-control" name="copyright" value="{{ $settingValue->getSettingsValue('copyright') }}" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group action mr-2  text-right mb-0">
                                        <a href="{{ url('admin/cms') }}" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                            Cancel
                                        </a>
                                        <button type="button" class="btn btn-dark rounded-0" onclick="submitContactForm()" id="contactFrmBtn" >Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        {!! JsValidator::formRequest('App\Admin\Http\Requests\CmsContactValidation','#contactForm') !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $('.selectpicker').selectpicker();
    function submitContactForm() {
        if ($("#contactForm").valid()) {
            showButtonLoader('contactFrmBtn', 'Save', 'disable');
            var url = "{{ url('admin/cms/update-contacts') }}";
            var formData = $("#contactForm").serializeArray();
            $.ajax({
                url: url,
                data: formData,
                type: 'POST',
                success: function (data) {
                    if (data.success) {
                        message('success', data.message);
                    } else {
                        message('error', data.message);
                    }
                },
                error: function (err) {
                    message('error', err);
                },
                complete: function () {
                    showButtonLoader('contactFrmBtn', 'Save', 'enable');
                }
            });
        }
    }

</script>