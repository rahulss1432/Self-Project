<div class="view_body">
    <div class="row">
        <div class="col-sm-6">
            <div class="add_form">
                <div class="card">
                    <div class="card-header">Update CMS</div>
                    <div class="card-body">
                        <form action="{{ url('admin/cms/add-testimonial') }}" method="POST" id="updateTestimonialFrm" enctype="multipart/form-data">
                            <div class="field_content">
                                <div class="field_box">
                                    <div class="form-group">
                                        <label class="d-block">User Image</label>
                                        <div class="upload-img-wrap">
                                            <label for="userImg" class="upload-img">
                                                <input class="do-not-ignore" type="file" hidden="" id="userImg" name="image" onchange="setImage(this)">
                                                <img id="testimonial-pic"  src="{{ getTestimonialImage($testimonial->image) }}"  alt="user">
                                            </label>
                                        </div>
                                    </div>

                                    <input type="hidden" name="id" class="form-control" value="{{ $testimonial->id}}"> 
                                             
                                    <div class="form-group">
                                        <label class="d-block">User Name</label>
                                        <input type="text" name="name" class="form-control" value="{{ $testimonial->name }}">
                                    </div>

                                    <div class="form-group">
                                        <label class="d-block">Content</label>
                                        <textarea name="content" rows="4" name="content" class="form-control">{{ $testimonial->content }}</textarea>
                                    </div>
                                    <div class="form-group action mr-2  text-right mb-0">
                                        <a href="{{ url('admin/cms') }}" id="cms-cancel" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                            Cancel
                                        </a>
                                        <button type="submit" class="btn btn-dark rounded-0" id="updateTestimonialBtn" onclick="updateTestimonial()">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                          {!! JsValidator::formRequest('App\Admin\Http\Requests\TestimonialValidation','#updateTestimonialFrm') !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $('.selectpicker').selectpicker();
    
    function setImage(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
               $('#testimonial-pic').attr('src',e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    function updateTestimonial() {
        if ($("#updateTestimonialFrm").valid()) {
            showButtonLoader('updateTestimonialBtn', 'Save', 'disable');
            document.getElementById('cms-cancel').style.pointerEvents = 'none';
            var url = "{{ url('admin/cms/update-testimonial') }}";
            var formData = new FormData($('#updateTestimonialFrm')[0]);
                formData.append('_token', '{{ csrf_token() }}');
            $.ajax({
                url: url,
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function (data) {
                    if (data.success) {
                        getUserTestimonials();
                        message('success', data.message);
                    } else {
                        message('error', data.message);
                    }
                },
                error: function (err) {
                    message('error', err);
                },
                complete: function () {
                    showButtonLoader('updateTestimonialBtn', 'Save', 'enable');
                    document.getElementById('cms-cancel').style.pointerEvents = 'auto';
                }
            });
        }
    }
</script>