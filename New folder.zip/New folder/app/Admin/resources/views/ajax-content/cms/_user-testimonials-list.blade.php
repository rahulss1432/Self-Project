<div class="search_section justify-content-between">
    <div class="row">
        <div class="col-12">
            <ul class="filter_right list-inline text-right mb-0">
                <li class="list-inline-item">
                    <a href="javascript:void(0);" onclick="getCmsAdd()" class="btn btn-dark rounded-0">Add Testimonials</a>
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="bg-white box-shadow common_table">
    <div class="table-responsive common_table">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th width="150">Image</th>
                    <th>Name</th>
                    <th>Content</th>
                    <th width="150">Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($testimonialList as $data)
                <tr>
                    <td ><img src="{{ getTestimonialImage($data->image) }}" class="rounded-circle" width="40" height="40" alt="user"></td>
                    <td>{{ ucfirst($data->name) }}</td>
                    <td>{{ ucfirst($data->content) }}</td>
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="javascript:void(0);" onclick="viewTestimonial('{{ $data->id }}')" >View</a>
                                    <a class="dropdown-item" href="javascript:void(0);" onclick="updateTestimonial('{{ $data->id }}')" >Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);" onclick="removeTestimonial('{{$data->id}}')">Delete</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="4">
                        <div class="alert alert-danger text-center">No record found.</div>
                    </td>
                </tr>    
                @endforelse
            </tbody>
            <!-- Not Record Found -->
            <tr style="display:none;"><td colspan="8"><div class="alert alert-danger text-center">No Record Found</div></td></tr>
            <!--  -->
        </table>
    </div>
</div>
{{$testimonialList->links()}} 
<script>
    $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        getUserTestimonials(pageLink);
    });
    
    
   function removeTestimonial(id){
        var url = "{{ url('admin/cms/remove-testimonial/') }}/ " + id;
        $.ajax({type: "GET", url: url, data: {},
            success: function (response) {
              if (response.success) {
                    message('success', response.message);
                    getUserTestimonials();
                }else{
                    message('error', response.message);
                } 
            }
        });
    }

    function updateTestimonial(id) {
          $("#content").html('<span class="ajax_loader btn_ring"></span>');
          var url = "{{ url('admin/cms/_cms-update/') }}/" + id;
          $.ajax({type: "GET", url: url, data: {},
              success: function (response) {
                  $("#content").html("");
                  $("#content").html(response.html);
              }
          });
      }
      
      function viewTestimonial(id) {
          $("#content").html('<span class="ajax_loader btn_ring"></span>');
          var url = "{{ url('admin/cms/view/') }}/" + id;
          $.ajax({type: "GET", url: url, data: {},
              success: function (response) {
                  $("#content").html("");
                  $("#content").html(response.html);
              }
          });
      }

</script>