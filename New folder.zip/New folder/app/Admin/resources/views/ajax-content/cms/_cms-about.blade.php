<div class="view_body">
    <div class="row">
        <div class="col-sm-6">
            <div class="add_form">
                <div class="card">
                    <div class="card-body">
                        <form action="javascript:void(0)" id="aboutAndTermsSubmitFrm">
                            <div class="field_content">
                                <div class="field_box">
                                    <div class="form-group">
                                        <label class="d-block">Content</label>
                                        <textarea rows="6" name="content" id="content" class="form-control aboutUs-contain-editor"> {{$data->content or ""}}{{ $value }} </textarea>
                                        <span id="validation-error-msg" class="error-tooltip"></span>
                                    </div>
                                    <input name="title" value="{{ $title }}" type="hidden">
                                    <div class="form-group action mr-2  text-right mb-0">
                                        <a href="{{ url('admin/cms') }}" class="btn btn-light mr-sm-2 rounded-0 ripple-effect"> Cancel </a>
                                        <button type="button" class="btn btn-dark rounded-0" id="submitAboutUsButton" onclick="submitForm()">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>

    $(document).ready(function () {
        //tinymceInit();
    });
    function tinymceInit(){
        tinymce.init({
            theme: "modern",
            selector: "textarea",
            relative_urls : false,
            remove_script_host : false,
            convert_urls : true,
            plugins: 'preview code searchreplace autolink directionality table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern',
            toolbar: 'undo redo | formatselect | bold italic strikethrough forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat | code',
            height: 300,
            init_instance_callback: function (editor) {
                editor.on('keyup', function (e) {
                    var content = tinymce.get('content').getContent();
                    console.log("content=" + content);
                    if (content === '')
                    {
                        $('#validation-error-msg').css({"color": "#a94442", "display": "inline-block", "margin-top": "5px"}).html("Description field is required.");
                    }
                    else
                    {
                        $('#validation-error-msg').html('');
                    }
                });
            }
        });
    }

    function submitForm() {
        var contentValue = $('.aboutUs-contain-editor').val();
        if (contentValue) {
            $('#validation-error-msg').html('');
            showButtonLoader('submitAboutUsButton', 'Save', 'disable');
            var url = "{{ url('admin/cms/update-about-and-terms') }}";
            var formData = $("#aboutAndTermsSubmitFrm").serializeArray();
            formData.push({name: '_token', value: '{{ csrf_token() }}'});
            formData.push({name: 'content', value: tinymce.get('content').getContent()});
            $.ajax({
                url: url,
                data: formData,
                type: 'POST',
                success: function (data) {
                    if (data.success) {
                        message('success', data.message);
                    } else {
                        message('error', data.message);
                    }
                },
                error: function (err) {
                    message('error', err);
                },
                complete: function () {
                    showButtonLoader('submitAboutUsButton', 'Save', 'enable');
                }
            });
        } else {
            $('#validation-error-msg').css({"color": "#a94442", "display": "inline-block", "margin-top": "5px"}).html("Description field is required.");
        }
    }

</script>