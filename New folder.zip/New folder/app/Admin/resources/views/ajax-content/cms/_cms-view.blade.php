<div class="view_body">
    <div class="row">
        <div class="col-sm-6">
            <div class="add_form">
                <div class="card">
                    <div class="card-header">View CMS</div>
                    <div class="card-body">
                        <div class="field_content">
                            <div class="field_box">
                                <div class="form-group">
                                    <label class="d-block">User Image</label>
                                    <div class="upload-img-wrap">
                                        <label for="userImg" class="upload-img">
                                            <img src="{{ getTestimonialImage($testimonial->image) }}"  alt="user">
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="d-block">User Name</label>
                                    <div>{{ $testimonial->name }}</div>
                                </div>

                                <div class="form-group">
                                    <label class="d-block">Content</label>
                                    <div>{{ $testimonial->content }}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>