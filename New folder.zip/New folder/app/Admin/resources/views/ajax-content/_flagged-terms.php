<table class="table admin-table">
    <thead>
        <tr>
            <th>Flagged Terms Name</th>
            <th class="w100 text-center">Status</th>
        </tr>
    </thead>

    <tbody>
        <!-- xxx -->
        <tr>
            <td>Number</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>
        <!-- xxx -->
       <!-- xxx -->
        <tr>
            <td>Contact</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>Skype</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>Whats App</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>
        <!-- xxx -->
       <!-- xxx -->
        <tr>
            <td>Email</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>Number</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>
        <!-- xxx -->
       <!-- xxx -->
        <tr>
            <td>Contact</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>Skype</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>Whats App</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>
        <!-- xxx -->
       <!-- xxx -->
        <tr>
            <td>Email</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>
    </tbody>
</table>