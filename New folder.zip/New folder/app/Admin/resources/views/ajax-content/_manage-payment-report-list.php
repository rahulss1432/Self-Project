<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th>Transaction ID</th>
            <th>Mentor Name</th>
            <th>User Name</th>
            <th>Job Date and Time</th>
            <th>Total Amount</th>
            <th>Commission</th>
            <th>Job Status </th>
            <th>Payment Method </th>
        </tr>
    </thead>

    <tbody>
        <!-- xxx -->
       <tr>
           <td>#0041512</td>
           <td>#00458692</td>
           <td>Steven Shelton</td>
           <td>Charlotte Nelligan</td>
           <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
           <td>$ 400.00</td>
           <td>$ 20.00</td>
           <td>Completed</td>
           <td>Credit Card</td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#00415564</td>
           <td>#00458685</td>
            <td>Brooke Sears</td>
           <td>Elmo Pratt</td>
           <td>15<sup>th</sup> Feb 2018, 10.00 AM</td>
            <td>$ 200.00</td>
           <td>$ 25.00</td>
           <td>Completed</td>
           <td>Credit Card</td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#0041224</td>
           <td>#00458674</td>
             <td>Jin Stevens</td>
           <td>Garrett Bird</td>
           <td>24<sup>th</sup> Feb 2018, 11.00 AM</td>
          <td>$ 300.00</td>
           <td>$ 35.00</td>
           <td>Completed</td>
           <td>Credit Card</td>
       </tr>

   <!-- xxx -->
       <tr>
           <td>#0041512</td>
           <td>#00458662</td>
           <td>Steven Shelton</td>
           <td>Charlotte Nelligan</td>
           <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
           <td>$ 400.00</td>
           <td>$ 20.00</td>
           <td>Completed</td>
           <td>Credit Card</td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#00415564</td>
           <td>#00458678</td>
            <td>Brooke Sears</td>
           <td>Elmo Pratt</td>
           <td>15<sup>th</sup> Feb 2018, 10.00 AM</td>
            <td>$ 200.00</td>
           <td>$ 25.00</td>
           <td>Completed</td>
           <td>Credit Card</td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#0041224</td>
           <td>#00458692</td>
             <td>Jin Stevens</td>
           <td>Garrett Bird</td>
           <td>24<sup>th</sup> Feb 2018, 11.00 AM</td>
          <td>$ 300.00</td>
           <td>$ 35.00</td>
           <td>Completed</td>
           <td>Credit Card</td>
       </tr>

 <!-- xxx -->
       <tr>
           <td>#0041512</td>
           <td>#00458689</td>
           <td>Steven Shelton</td>
           <td>Charlotte Nelligan</td>
           <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
           <td>$ 400.00</td>
           <td>$ 20.00</td>
           <td>Completed</td>
           <td>Credit Card</td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#00415564</td>
           <td>#00458623</td>
            <td>Brooke Sears</td>
           <td>Elmo Pratt</td>
           <td>15<sup>th</sup> Feb 2018, 10.00 AM</td>
            <td>$ 200.00</td>
           <td>$ 25.00</td>
           <td>Completed</td>
           <td>Credit Card</td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#0041224</td>
           <td>#00458645</td>
             <td>Jin Stevens</td>
           <td>Garrett Bird</td>
           <td>24<sup>th</sup> Feb 2018, 11.00 AM</td>
          <td>$ 300.00</td>
           <td>$ 35.00</td>
           <td>Completed</td>
           <td>Credit Card</td>
       </tr>

 <!-- xxx -->
       <tr>
           <td>#0041512</td>
           <td>#00458692</td>
           <td>Steven Shelton</td>
           <td>Charlotte Nelligan</td>
           <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
           <td>$ 400.00</td>
           <td>$ 20.00</td>
           <td>Completed</td>
           <td>Credit Card</td>
       </tr>

       
    </tbody>
</table>
