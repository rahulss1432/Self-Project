@if(count($notification)>0)
<ul class="list-unstyled child_ul notifi-list green-scroll" data-mcs-theme="my-theme">
    @foreach($notification as $notify)
    <li class="list-group-item border-top-0">
        <a href="{{url('admin/'.$notify->url)}}" class="ripple-effect dropdown-item">
            <h6>{{$notify->message}}</h6>
            <small>{{fullTimeFormat($notify->created_at)}}</small>
        </a>
    </li>
    @endforeach
</ul>
@else
<div class="alert alert-danger text-center">No record found.</div>
@endif