<div class="content bg-white box-shadow manage_post">
    <div class="notification_list">
        @if(count($notification)>0)
        <ul class="list-unstyled mb-0">
            @foreach($notification as $notify)
            <li>
                <a href="{{url('admin/'.$notify->url)}}" class="ripple-effect dropdown-item">
                    <h4>{{$notify->message}}</h4>
                    <div class="cnt">
                        <span><i class="flaticon-clock"></i> {{fullTimeFormat($notify->created_at)}}</span>
                    </div>
                </a>
            </li>
            @endforeach
        </ul>
        @else
        <div class="alert alert-danger text-center">No record found.</div>
        @endif
    </div>
</div>
{{ $notification->links() }}
<script>
    $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        notificationList(pageLink);
    });
</script>