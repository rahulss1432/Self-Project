<?php include_once '../include/constant.php'; ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Unique url</th>
            <th class="w-150 text-center">View Documents</th>
            <th class="w-150 text-center">View Categories </th>
            <th>View Availability </th>
            <th>Status</th>
            <th class="w170 text-center">Approve/Disapprove</th>
            <th class="w100 text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        <!-- xxx -->
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Charlotte Nelligan</a>
            </td>
            <td>charlotten@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/manage-category.php" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>
                </div>
            </td>
             <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" >
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Garrett Bird</a>
            </td>
            <td>garrettb@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/garrettb">https://www.mentolocator.com/garrettb</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/manage-category.php" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>
                </div>
            </td>
             <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Elmo Pratt</a>
            </td>
            <td>elmop@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/elmop">https://www.mentolocator.com/elmop</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/manage-category.php" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>
                </div>
            </td>
             <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Charlotte Nelligan</a>
            </td>
            <td>charlotten@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/manage-category.php" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>
                </div>
            </td>
           <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" >
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Garrett Bird</a>
            </td>
            <td>garrettb@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/garrettb">https://www.mentolocator.com/garrettb</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/manage-category.php" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>
                </div>
            </td>
             <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Elmo Pratt</a>
            </td>
            <td>elmop@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/elmop">https://www.mentolocator.com/elmop</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/manage-category.php" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>
                </div>
            </td>
             <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Charlotte Nelligan</a>
            </td>
            <td>charlotten@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/manage-category.php" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>
                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Garrett Bird</a>
            </td>
            <td>garrettb@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/garrettb">https://www.mentolocator.com/garrettb</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/manage-category.php" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>
                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" >
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Elmo Pratt</a>
            </td>
            <td>elmop@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/elmop">https://www.mentolocator.com/elmop</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/manage-category.php" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>
                </div>
            </td>
             <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Charlotte Nelligan</a>
            </td>
            <td>charlotten@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/manage-category.php" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>
                </div>
            </td>
             <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
    </tbody>
</table>
<script>
$('[data-toggle="tooltip"]').tooltip({ trigger: "hover" });
</script>