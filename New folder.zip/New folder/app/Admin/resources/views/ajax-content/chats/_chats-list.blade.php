<div class="content bg-white box-shadow">
    <!--  -->
    <div class="table-responsive common_table">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Chat. ID</th>
                    <th>User 1</th>
                    <th>User 2</th>
                    <th>Last Updated By</th>
                    <th>Last Updated On</th>
                    <th width="10%">Action</th>
                </tr>
            </thead>
            <tbody>
                @php $user = \App\User::find(\Auth::guard(getAuthGuard())->user()->id); @endphp
                @forelse ($chatMessages as $message)
                <tr>
                    <td>{{ $message->reference_id }}</td>
                    @if (getAuthGuard() == 'subadmin' && !($user->hasMenu('users'))) 
                    <td class="text-capitalize">{{ ($message->from_user_fullName) ? ucfirst($message->from_user_fullName)." (".$message->from_user_reference_id.")" : '-'}}</td>
                    <td class="text-capitalize">{{ ($message->to_user_fullName) ? ucfirst($message->to_user_fullName)." (".$message->to_user_reference_id.")" : '-' }}</td>
                    @else
                    <td class="text-capitalize"><a href="{{ url('admin/users/view/'.base64_encode($message->from_user_id)) }}">{{ ($message->from_user_fullName) ? ucfirst($message->from_user_fullName)." (".$message->from_user_reference_id.")" : '-'}}</a></td>
                    <td class="text-capitalize"><a href="{{ url('admin/users/view/'.base64_encode($message->to_user_id)) }}">{{ ($message->to_user_fullName) ? ucfirst($message->to_user_fullName)." (".$message->to_user_reference_id.")" : '-' }}</a></td>
                    @endif
                    <td class="text-capitalize">{{ getUserFullNameById($message->from_id) }} </td>
                    <td>{{ dateTimeFormat($message->created_at) }}</td>
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="{{ url('admin/chats/view-chat/'.base64_encode($message->chat_id).'/'. base64_encode($message->from_id)) }}">View</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                @empty
              <tr><td colspan="6"><div class="alert alert-danger text-center">No Record Found.</div></td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
{{$chatMessages->links()}} 

<script>
    $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        getListing(pageLink);
    });

    $(function () {
        $('[data-toggle="popover"]').popover()
    })
    $('[data-toggle="popover"]').on('click', function () {
        $(this).toggleClass('btn_active');
    });
</script>
