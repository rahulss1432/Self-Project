<div class="view_body media_view">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-6">
            <div class="box_wrapper pb-0">
                <div class="video_list">
                    <h2 class="heading_22 mb-3">Video</h2>
                    <div class="inner_wrap green-scroll">
                        <div class="row no-gutters">
                            @if(count($getVideo) > 0)
                            @foreach($getVideo as $mediaVideo)
                            <div class="col-6 col-sm-3 col-md-6">
                                <div class="video_box">
                                    <img src="{{ checkMediaImage($mediaVideo->media,  getUserById($mediaVideo->user_id, 'role').'/thumb') }}" class="img-fluid" alt="video thumb">
                                    <div class="overlay">
                                        <a href="javascript:void(0);" onclick="getMediaModal('{{ $mediaVideo->id }}')" class="rounded-circle"> <i class="flaticon-play-button"></i> <span class="active"></span></a>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @else 
                            <div class="col-12">
                                <div class="alert alert-danger text-center mb-4">No video Found</div>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- xxxxxxxx -->

        <div class="col-sm-12 col-md-12 col-lg-6">
            <div class="box_wrapper pb-0 box_wrapper_last">
                <div class="video_list">
                    <h2 class="heading_22 mb-3">Photo</h2>
                    <div class="inner_wrap green-scroll">
                        <div class="row">
                            @if(count($getImage) > 0)
                            @foreach($getImage as  $mediaImage)
                            <div class="col-6 col-sm-3 col-md-6">
                                <div class="video_box">
                                    <img src="{{ checkMediaImage($mediaImage->media,  getUserById($mediaImage->user_id, 'role').'/thumb') }}" class="img-fluid" alt="photo thumb">
                                    <div class="overlay">
                                        <a href="javascript:void(0)" onclick="getMediaModal('{{ $mediaImage->id }}')" class="rounded-circle"> <i class="flaticon-eye"></i> <span class="active"></span></a>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @else 
                           <div class="col-12">
                                <div class="alert alert-danger text-center mb-4">No Image Found</div>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--open post media modal-->
<div class="modal photos modal-effect" id="myPhotosVideos" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="flaticon-cancel-music"></i>
                </button>
            </div>
            <div class="modal-body">
                <div id="get-post-view-modal"></div>
            </div>
        </div>
    </div>
</div>

<script>

    $(".inner_wrap").mCustomScrollbar({
        theme: "dark"
    });

// get media view modal
    function getMediaModal(mediaId){
    $("#get-post-view-modal").html('<span class="ajax_loader btn_ring"></span>');
        var url = '{{ url("admin/users/media-detail-modal") }}';
        $.ajax({
        type: "GET", url: url, data: {media_id: mediaId},
            success: function (response) {
            $("#get-post-view-modal").html("");
            $("#get-post-view-modal").html(response.html);
            $('#myPhotosVideos').modal('show');
            }
        });
    }

    
</script>
