<div class="view_body about_info">
    <div class="row">
        <div class="col-xl-6 col-lg-12 col-md-12">
            <div class="box_wrapper mb-30">
                <h2 class="heading_22 mb-3 ">General</h2>
                @if($user->userGeneral)
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Years Of Playing Experience:</label>	</div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user['userGeneral']['playing_exp']) ? $user['userGeneral']['playing_exp'].' years' : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Currently Under Contract:</label>	</div>
                        <div class="col-sm-8 col-12"> <span>{{ ucfirst($user->userGeneral->under_contract) }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Looking To Sign:</label>	</div>
                        <div class="col-sm-8 col-12"> <span>{{ ucfirst($user->userGeneral->look_to_sign) }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Current Team:</label>	</div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user->userGeneral->current_team) ?  ucfirst($user->userGeneral->current_team) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Current Team Link:</label></div>
                        <div class="col-sm-8 col-12"> <span>{{!empty( $user->userGeneral->current_team_link) ?  $user->userGeneral->current_team_link : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Current League Or Conference:</label>	</div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user->userGeneral->current_league) ? ucfirst($user->userGeneral->current_league) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Current League Or Conference Link:</label>	</div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user->userGeneral->current_league_link) ? ucfirst($user->userGeneral->current_league_link) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Former Team:</label>	</div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user->userGeneral->former_team) ? ucfirst($user->userGeneral->former_team) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Former Team Link:</label>	</div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user->userGeneral->former_team_link) ? $user->userGeneral->former_team_link : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Former League Or Conference:</label>	</div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user->userGeneral->former_league) ? ucfirst($user->userGeneral->former_league) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Former League Or Conference Link:</label>	</div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user->userGeneral->former_league_link) ? $user->userGeneral->former_league_link : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Passport Ready:</label></div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user->userGeneral->passport) ? ucfirst($user->userGeneral->passport) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Country Of Issuance:</label></div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user['userGeneral']['country']['name']) ? ucfirst($user['userGeneral']['country']['name']) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Native Language:</label></div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user['userGeneral']['nativeLanguage']['language']) ? ucfirst($user['userGeneral']['nativeLanguage']['language']) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-12"> <label>Secondary Language:</label></div>
                        <div class="col-sm-8 col-12"> <span>{{ !empty($user['userGeneral']['secondaryLanguage']['language']) ? ucfirst($user['userGeneral']['secondaryLanguage']['language']) : '-' }}</span></div>
                    </div>
                </div>
                @else
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-12">No Record Found.</div>
                    </div>
                </div>
                @endif
            </div>
            <div class="box_wrapper mb-30">
                <h2 class="heading_22 mb-3 ">International experience</h2>
                @forelse($user->userInternationalExperince as $internationalExperince)
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col"> <label>Experience Level:</label>	</div>
                        <div class="col-sm-8 col"> <span>{{ !empty($internationalExperince->experience_type) ? getLevelName($internationalExperince['experience_type']): '' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col"> <label>Duration (year):</label>	</div>
                        <div class="col-sm-8 col"> <span>{{ $internationalExperince->from_year }} - {{ $internationalExperince->to_year }}</span></div>
                    </div>
                </div>
                <hr>
                @empty
                <p>No</p>
                @endforelse
            </div>
            <div class="box_wrapper mb-30 championship_info">
                <h2 class="heading_22 mb-3 ">Accolades/Awards/Captainships/Championship</h2>
                <div class="table-responsive">
                    <table class="table teaminfo_table mb-0">
                        <tbody>
                            @if($user->userAccoladesExperince)
                            @foreach($user->userAccoladesExperince as $accolades)
                            <tr>
                                <td> 
                                    <div class="team_logo rounded-circle">
                                        <img src="{{ checkUserImage($accolades->logo, $user->role, 'logo') }}" alt=" team logo">
                                    </div>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Name Of Accolade:</label>
                                    <span>{{ !empty($accolades->name) ? ucfirst($accolades->name) : '-' }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Presenting Organization:</label>
                                    <span>{{ !empty($accolades->present_organization) ?  ucfirst($accolades->present_organization) : '-' }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Year of Presentation:</label>
                                    <span>{{ !empty($accolades->present_year) ? $accolades->present_year : '-' }}</span>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="box_wrapper mb-30 coaching_experience">
                <h2 class="heading_22 mb-3 ">Coaching Experience</h2>
                <div class="table-responsive">
                    <table class="table coaching_table mb-0">
                        <tbody>
                            @forelse($user->userCoachingExperince as $coaching)
                            <tr>
                                <td rowspan="3">
                                    <div class="team_logo rounded-circle">
                                        <img src="{{ checkUserImage($coaching->logo, $user->role, 'logo') }}" alt=" team logo">
                                    </div>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Team/Program/Organization Name:</label>
                                    <span>{{ !empty($coaching->name) ? ucfirst($coaching->name) : '-' }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Link To Team’s Page/Stats:</label>
                                    <span>{{ !empty($coaching->coaching_link) ? $coaching->coaching_link : '-' }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">League/Conference:</label>
                                    <span>{{ !empty($coaching->coching_league) ? ucfirst($coaching->coching_league) : '-' }}</span>
                                </td>
                            </tr>
                            <tr>
                                <td class="info_row">
                                    <label class="d-block mb-2">Country:</label>
                                    <span>{{ getCountryName($coaching->country_id) }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">State:</label>
                                    <span>{{ getStateName($coaching->state_id) }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Position Held:</label>
                                    <span>{{ !empty($coaching->position_held) ? ucfirst($coaching->position_held) : '-' }}</span>
                                </td>
                            </tr>
                            <tr>
                                <td class="info_row">
                                    <label class="d-block mb-2">Year:</label>
                                    <span>{{ $coaching->from_year }} - {{ $coaching->to_year }}</span>
                                </td>
                                <td class="info_row" colspan="2">
                                    <label class="d-block mb-2">Level:</label>
                                    <span>{{ !empty($coaching['level_id']) ? getLevelName($coaching['level_id']): '-' }}</span>
                                </td>
                            </tr>
                            <tr class="divider">
                                <td colspan="4"><div class="divider_bottom"></div></td>
                            </tr>
                            @empty
                            <tr><td>No</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- xxxxxxxx -->

        <div class="col-xl-6 col-lg-12 col-md-12">
            <div class="box_wrapper mb-30">
                <h2 class="heading_22 mb-3 ">PREP/Collage Experience</h2>
                @forelse($user->userCollegeExperince as $collegeExperince)
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col"> <label>Experience Level:</label>	</div>
                        <div class="col-sm-8 col"> <span>{{ !empty($collegeExperince->experience_type) ? $collegeExperince->experience_type : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col"> <label>Duration (year):</label>	</div>
                        <div class="col-sm-8 col"> <span>{{ $collegeExperince->from_year }} - {{ $collegeExperince->to_year }}</span></div>
                    </div>
                </div>
                <hr>
                @empty
                <p>No</p>
                @endforelse
            </div>
            <div class="box_wrapper mb-30">
                <h2 class="heading_22 mb-3 ">Pro Experience</h2>
                @forelse($user->userProExperince as $proExperince)
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col"> <label>Experience Level:</label>	</div>
                        <div class="col-sm-8 col"> <span>{{ !empty($proExperince->experience_type) ? ucfirst($proExperince->experience_type) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col"> <label>Duration (Year):</label>	</div>
                        <div class="col-sm-8 col"> <span>{{ $proExperince->from_year }} - {{ $proExperince->to_year }}</span></div>
                    </div>
                </div>
                <hr>
                @empty
                <p>No</p>
                @endforelse
            </div>
            <div class="box_wrapper mb-30">
                <h2 class="heading_22 mb-3 ">Indoor experience</h2>
                @forelse($user->userIndooreExperince as $indooreExperince)
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col"> <label>Experience Level:</label>	</div>
                        <div class="col-sm-8 col"> <span>{{ !empty($indooreExperince->experience_type) ? getLevelName($indooreExperince['experience_type']): '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col"> <label>Duration (Year):</label>	</div>
                        <div class="col-sm-8 col"> <span>{{ $indooreExperince->from_year }} - {{ $indooreExperince->to_year }}</span></div>
                    </div>
                </div>
                <hr>
                @empty
                <p>No</p>
                @endforelse
            </div>
            <div class="box_wrapper mb-30">
                <h2 class="heading_22 mb-3 ">Education</h2>
                <div class="table-responsive">
                    <table class="table teaminfo_table mb-0">
                        <tbody>
                            @forelse($user->userEducationExperince as $education)
                            <tr>
                                <td> 
                                    <div class="team_logo rounded-circle">
                                        <img src="{{ checkUserImage($education->logo, $user->role, 'logo') }}" alt=" team logo">
                                    </div>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">School Name::</label>
                                    <span>{{ !empty($education->name) ? ucfirst($education->name) : '-' }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Year:</label>
                                    <span>{{ $education->from_year }} - {{ $education->to_year }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Level Completed:</label>
                                    <span>{{ !empty($education['level_id']) ? getLevelName($education['level_id']) : '-' }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Degree Name:</label>
                                    <span>{{ !empty($education->degree_name) ? ucfirst($education->degree_name) : '-' }}</span>
                                </td>
                            </tr>
                            @empty
                            <tr><td>No</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="box_wrapper mb-0">
                <h2 class="heading_22 mb-3 ">Community service experience</h2>
                <div class="table-responsive">
                    <table class="table teaminfo_table mb-0">
                        <tbody>
                            @forelse($user->userCommunityExperince as $community)
                            <tr>
                                <td> 
                                    <div class="team_logo rounded-circle">
                                        <img src="{{ checkUserImage($community->logo, $user->role, 'logo') }}" alt=" team logo">
                                    </div>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Organization Name::</label>
                                    <span>{{ !empty($community->name) ? ucfirst($community->name) : '-' }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Position Held:</label>
                                    <span>{{ !empty($community->position_held) ? ucfirst($community->position_held) : '-' }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Year:</label>
                                    <span>{{ $community->from_year }} - {{ $community->to_year }}</span>
                                </td>
                            </tr>
                            @empty
                            <tr><td>No</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>