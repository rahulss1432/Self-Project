<div class="view_body contact_info">
    <div class="row align-items-stretch">
        <div class="col-lg-6 col-md-12">
            <div class="box_wrapper h-100">
                <h2 class="heading_22 mb-3 ">Social media</h2>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-lg-3 col-md-2 col-sm-2 col-4"> <label>Skype ID:</label>	</div>
                        <div class="col-lg-9 col-md-10 col-sm-10 col-8"> <span>{{ !empty($user->skype) ? $user->skype : "-" }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-lg-3 col-md-2 col-sm-2 col-4"> <label>Facebook:</label>	</div>
                        <div class="col-lg-9 col-md-10 col-sm-10 col-8"> <span>{{!empty($user->facebook) ?  $user->facebook : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-lg-3 col-md-2 col-sm-2 col-4"> <label>Twitter:</label>	</div>
                        <div class="col-lg-9 col-md-10 col-sm-10 col-8"> <span>{{ !empty($user->twitter) ? $user->twitter : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-lg-3 col-md-2 col-sm-2 col-4"> <label>Instagram:</label>	</div>
                        <div class="col-lg-9 col-md-10 col-sm-10 col-8"> <span>{{ !empty($user->instagram) ? $user->instagram : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row mb-0">
                    <div class="row">
                        <div class="col-lg-3 col-md-2 col-sm-2 col-4"> <label>Linkedin:</label>	</div>
                        <div class="col-lg-9 col-md-10 col-sm-10 col-8"> <span>{{ !empty($user->linkedin) ? $user->linkedin : '-' }}</span></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- xxxxxxxx -->

        <div class="col-lg-6 col-md-12">
            <div class="box_wrapper h-100 box_wrapper_last ">
                <h2 class="heading_22 mb-3 ">Website</h2>
                <div class="form-group info_row mb-0">
                    <div class="row">
                        <div class="col-lg-3 col-md-2 col-sm-2 col-4"> <label>Webpage:</label>	</div>
                        <div class="col-lg-9 col-md-10 col-sm-10 col-8"> <span>{{ !empty($user->website) ? $user->website : '-' }}</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>