@if($getMedia->media_type == 'image')
<div class="leftside float-lg-left d-flex align-items-center justify-content-center" >
    <img src="{{ checkMediaImage($getMedia->media, $getMedia->user->role) }}" class="img-fluid" alt="post img">
    <div class="overlay"></div>
</div>
@else
<div class="leftside float-lg-left d-flex align-items-center justify-content-center">
    <video controls >
        <source src="{{ checkMediaVideo($getMedia->media, $getMedia->user->role) }}" type="video/mp4">
    </video>
</div>
@endif  
<div class="rightside pr-0 float-lg-left">
    <div class="manage_post">
        <div class="post_comment">
            <div class="inner pb-0">
                <h2>{{ ($getMedia->user) ? $getMedia->user->reference_id : '' }}</h2>
                <h3>{{ (!empty(getUserFullNameById($getMedia->user_id))) ? getUserFullNameById($getMedia->user_id) : '-' }}</h3>
                <div class="d-flex align-items-center  mt-2 mt-sm-4">
                    <p class="date_time text-right">{{ dateTimeFormat($getMedia->created_at) }}</p>
                    <ul class="list-inline mb-0 ml-auto">
                        <li class="list-inline-item"><i class="flaticon-like"></i>{{ mediaLikeCount($getMedia->id,'like') }}</li>
                        <li class="list-inline-item" ><i class="flaticon-comment"></i>{{ mediaLikeCount($getMedia->id, 'comment')}}</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="post_comment_listing">
            <h2 class="heading">Comments</h2>
            <div class="ajax_list_load" id="get-media-comment-list"></div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        getMediaCommentList('{{ $getMedia->id }}');
    });

//get comment list on this media
    function getMediaCommentList(mediaId) {
        $("#get-media-comment-list").html('<span class="ajax_loader btn_ring"></span>');
        var url = '{{ url("admin/users/media-comment-list") }}';
        $.ajax({
            type: "GET", url: url, data: {media_id: mediaId},
            success: function (response) {
                $("#get-media-comment-list").html(response.html);
                $(".comment").mCustomScrollbar({
                    theme:"dark",
                    axis:"y",
                }); 
            }
        });
    }
</script>
