<div class="view_body about_info">
    <div class="row">
        <div class="col-md-12 col-xl-6">
            <div class="box_wrapper h-100">
                <h2 class="heading_22 mb-3 ">General</h2>
                @if($user->userGeneral)
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-5"> <label>Years Into Experience:</label>	</div>
                        <div class="col-sm-7"> <span>{{ !empty($user['userGeneral']['playing_exp']) ? $user['userGeneral']['playing_exp'].' years' : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-5"> <label>Currently Recruiting:</label>	</div>
                        <div class="col-sm-7"> <span>{{ !empty($user->userGeneral->recruiting) ? ucfirst($user->userGeneral->recruiting) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-5"> <label>Current League Or Conference:</label>	</div>
                        <div class="col-sm-7"> <span>{{ !empty($user->userGeneral->current_league) ? ucfirst($user->userGeneral->current_league) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-5"> <label>Current League Or Conference Link:</label>	</div>
                        <div class="col-sm-7"> <span>{{ !empty($user->userGeneral->current_league_link) ? $user->userGeneral->current_league_link : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-5"> <label>Former League Or Conference:</label>	</div>
                        <div class="col-sm-7"> <span>{{ !empty($user->userGeneral->former_league) ? ucfirst($user->userGeneral->former_league) : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row mb-0">
                    <div class="row">
                        <div class="col-sm-5"> <label>Former League Or Conference Link:</label>	</div>
                        <div class="col-sm-7"> <span>{{ !empty($user->userGeneral->former_league_link) ? $user->userGeneral->former_league_link : '-' }}</span></div>
                    </div>
                </div>
                @else
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-12">No</div>
                    </div>
                </div>
                @endif
            </div>

        </div>

        <!-- xxxxxxxx -->

        <div class="col-md-12 col-xl-6">
            <div class="box_wrapper h-100 box_wrapper_last">
                <h2 class="heading_22 mb-3 ">Accolades/Awards/Captainships/Championship</h2>
                <div class="table-responsive">
                    <table class="table teaminfo_table">
                        <tbody>
                            @forelse($user->userAccoladesExperince as $accolades)
                            <tr>
                                <td> 
                                    <div class="team_logo rounded-circle">
                                        <img src="{{ checkUserImage($accolades->logo, $user->role, 'logo') }}" alt=" team logo">
                                    </div>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Name Of Accolade:</label>
                                    <span>{{ !empty($accolades->name) ? ucfirst($accolades->name) : '-' }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Presenting Organization:</label>
                                    <span>{{ !empty($accolades->present_organization)  ? ucfirst($accolades->present_organization) : '-' }}</span>
                                </td>
                                <td class="info_row">
                                    <label class="d-block mb-2">Year Of Presentation:</label>
                                    <span>{{ !empty($accolades->present_year) ? $accolades->present_year : '-' }}</span>
                                </td>
                            </tr>
                            @empty
                            <tr><td>No</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>