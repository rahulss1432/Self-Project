<div class="view_body about_info">
    <div class="row">
        <div class="col-md-12 col-lg-6">

            <div class="box_wrapper coaching_experience h-100">
                <h2 class="heading_22 mb-3 ">Players</h2>
                <div class="table-responsive">
                    <table class="table coaching_table table_530 mb-0">
                        <tbody>
                            @if(count($teamPlayer)>0)   
                            @foreach($teamPlayer as $player)
                            <tr>
                                <td class="info_row border-0">
                                    <label class="d-block mb-2">Jersey Number:</label>
                                    <span>{{!empty($player->jersey_no) ? $player->jersey_no : '-'}}</span>
                                </td>
                                <td class="info_row border-0">
                                    <label class="d-block mb-2">Player Name:</label>
                                    <span>{{!empty($player->player_name) ? ucfirst($player->player_name) : '-'}}</span>
                                </td>
                                <td class="info_row border-0">
                                    <label class="d-block mb-2">Position:</label>
                                    <span>{{!empty($player->position_id) ? getLimitText(20,getPositionName($player->position_id))  : '-'}}</span>
                                </td>
                            </tr>
                            <tr>
                                <td class="info_row border-0">
                                    <label class="d-block mb-2">Height:</label>
                                    <span>{{!empty($player->height_ft) ? $player->height_ft."'" : "0'" }} {{!empty($player->height_in) ? $player->height_in."''" : "0''" }}</span>
                                </td>
                                <td class="info_row border-0">
                                    <label class="d-block mb-2">Weight:</label>
                                    <span>{{!empty($player->weight) ? $player->weight.' lbs.' : '-'}} </span>
                                </td>
                                <td class="info_row border-0">
                                    <label class="d-block mb-2">School / Shometown:</label>
                                    <span>{{!empty($player->school) ? ucfirst($player->school) : '-'}}</span>
                                </td>
                            </tr>
                            <tr class="divider">
                                <td  colspan="4"><div class="divider_bottom"></div></td>
                            </tr>
                            @endforeach
                            @else
                            <tr><td colspan="11"><div class="alert alert-danger text-center">No Record Found.</div></td></tr>
                            @endif                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- xxxxxxxx -->

        <div class="col-md-12 col-lg-6">
            <div class="box_wrapper staff_personnel h-100 box_wrapper_last">
                <h2 class="heading_22 mb-3 ">Staff & Personnel</h2>
                @if(count($teamStaff)>0)                                
                @foreach($teamStaff as $staff)                
                <div class="common_box">
                    <div class="profil_details d-flex align-items-center">
                        <div class="profile_img">
                            <img src="{{checkUserImage($staff->profile_picture, 'team/thumb','')}}" class="img-fluid" alt="user img">
                        </div>
                        <ul class="caption list-inline mb-0">
                            <li class="info_row list-inline-item">
                                <label class="d-block">Name</label>
                                <span>{{ !empty($staff->name) ? ucfirst($staff->name) : '-'}}</span>
                            </li>
                            <li class="info_row list-inline-item">
                                <label class="d-block">Title</label>
                                <span>{{!empty($staff->title) ? ucfirst($staff->title) : '-'}}</span>
                            </li>
                        </ul>
                    </div>
                    <div class="bio">
                        <h6>Bio:</h6>
                        <p>{{ !empty($staff->bio) ? ucfirst($staff->bio) : '-'}}</p>
                    </div>
                </div>
                @endforeach
                @else
                <div class="common_box">
                    <div class="alert alert-danger text-center">No Record Found.</div>                   
                </div>
                @endif
            </div>

        </div>
    </div>
</div>