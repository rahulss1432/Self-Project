<div class="view_body desired_benifits">
    <div class="box_wrapper ">
        <div class="info_row">
            <h2 class="heading_22 mb-2">Salary Range</h2>
            <label>(USD){{!empty($user->from_salary) ? $user->from_salary : '0'}} - (USD) {{!empty($user->to_salary) ? $user->to_salary : '0'}}</label>
        </div>

        <ul class="list-inline benifits_list mb-0">
            @forelse($user->userBenefits as $benefit)
            <li class="list-inline-item">
                <div class="box_wrap d-flex align-items-center justify-content-center">
                    <div class="caption text-center">
                        <i class="{{ $benefit->masterBenefits->image }}"></i>
                        <p class="mb-0 d-block">{{ ucfirst($benefit->masterBenefits->title) }}</p>
                    </div>
                </div>
            </li>
            @empty
            <li>
                <div class="box_wrap d-flex align-items-center justify-content-center">
                    <div class="caption text-center">
                        <i class="icon-benefit"></i>
                        <p class="mb-0 d-block">No Benefit Found.</p>
                    </div>
                </div>
            </li>
            @endforelse
        </ul>

    </div>
</div>