<div class="view_body measurables_view">
    <div class="box_wrapper ">
        <div class="row">
            <div class="col-lg-6 col-md-12">
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-4"> <label>Certifier:</label></div>
                        <div class="col-sm-6 col-8"> <span>{{ !empty($user['userMeasurables']['certifier']) ? $user['userMeasurables']['certifier'] : '-'}}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-4"> <label>Certifier Email/Link:</label>	</div>
                        <div class="col-sm-6 col-8"> <span>{{ !empty($user['userMeasurables']['email_link']) ? $user['userMeasurables']['email_link'] : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-4"> <label>Height:</label>	</div>
                        <div class="col-sm-6 col-8"> <span>{{ !empty($user['userMeasurables']['height_ft']) ? ($user['userMeasurables']['height_ft'] ."'") : ("0'")}}
                                {{ !empty($user['userMeasurables']['height_in']) ? ($user['userMeasurables']['height_in'] .'"') : ('0"')}}                                                    
                            </span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-4"> <label>Weight (Lb):</label>	</div>
                        <div class="col-sm-6 col-8"> <span>{{ !empty($user['userMeasurables']['weight']) ? $user['userMeasurables']['weight'] : '-'}}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-4"> <label>Pro Shuttle (Sec):</label>	</div>
                        <div class="col-sm-6 col-8"> <span>{{ !empty($user['userMeasurables']['pro_shuttle']) ? $user['userMeasurables']['pro_shuttle'] : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row info_row_mb0">
                    <div class="row">
                        <div class="col-sm-4 col-4"> <label>Collegiate Shuttle (Sec):</label>	</div>
                        <div class="col-sm-6 col-8"> <span>{{ !empty($user['userMeasurables']['collegiate_shuttle']) ? $user['userMeasurables']['collegiate_shuttle'] : '-'}}</span></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-4"> <label>Bench In Reps:</label></div>
                        <div class="col-sm-8 col-8"> <span>{{ !empty($user['userMeasurables']['bench']) ? $user['userMeasurables']['bench'] : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-4"> <label>Vert (in):</label>	</div>
                        <div class="col-sm-8 col-8"> <span>{{ !empty($user['userMeasurables']['vert']) ? $user['userMeasurables']['vert'] : '-' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-4"> <label>Hand Size (in):</label>	</div>
                        <div class="col-sm-8 col-8"> <span>{{ !empty($user['userMeasurables']['hand_size']) ? $user['userMeasurables']['hand_size'] : '-'}}</span></div>
                    </div>
                </div>
                <div class="form-group info_row">
                    <div class="row">
                        <div class="col-sm-4 col-4"> <label>Broad Jump:</label>	</div>
                        <div class="col-sm-8 col-8"> <span>{{ !empty($user['userMeasurables']['broad_jump_from']) ? $user['userMeasurables']['broad_jump_from'] : '0' }} ' {{ !empty($user['userMeasurables']['broad_jump_to']) ? $user['userMeasurables']['broad_jump_to'] : '0"' }}</span></div>
                    </div>
                </div>
                <div class="form-group info_row mb-0">
                    <div class="row">
                        <div class="col-sm-4 col-4"> <label>40:</label>	</div>
                        <div class="col-sm-8 col-8"> <span>{{ !empty($user['userMeasurables']['fourty']) ? $user['userMeasurables']['fourty'] : '-' }}</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>