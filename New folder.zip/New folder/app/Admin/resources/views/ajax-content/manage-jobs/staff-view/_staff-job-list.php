<div class="view_body">
	<div class="row">
		<div class="col-xl-6 col-lg-12 col-md-12">
			<div class="box_wrapper mb-30 height-100">
				<h2 class="heading_22 mb-3 ">General</h2>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Job type:</label>	</div>
						<div class="col-sm-8 col-12"> <span>Staff & personals</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Institution name:</label>	</div>
						<div class="col-sm-8 col-12"> <span>Indoor</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Institution type:</label>	</div>
						<div class="col-sm-8 col-12"> <span>Offensive tackle</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Level of team:</label></div>
						<div class="col-sm-8 col-12"> <span>Indoor</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>League or conference:</label>	</div>
						<div class="col-sm-8 col-12"> <span>AAL</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Job category:</label>	</div>
						<div class="col-sm-8 col-12"> <span>Full time</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Staff & personal area:</label>	</div>
						<div class="col-sm-8 col-12"> <span>staff</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Position title:</label>	</div>
						<div class="col-sm-8 col-12"> <span>Manager</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Country:</label>	</div>
						<div class="col-sm-8 col-12"> <span>US</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>State:</label>	</div>
						<div class="col-sm-8 col-12"> <span>Boston</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Zip Code:</label></div>
						<div class="col-sm-8 col-12"> <span>02101</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Relevant experience:</label></div>
						<div class="col-sm-8 col-12"> <span>Indoor</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Last date to apply:</label></div>
						<div class="col-sm-8 col-12"> <span>08/31/2018</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Salary range:</label></div>
						<div class="col-sm-8 col-12"> <span>$1500 - $2000</span></div>
					</div>
				</div>
				<div class="form-group info_row ">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Benifits:</label></div>
						<div class="col-sm-8 col-12"> <span>Housing, Health insurance</span></div>
					</div>
				</div>
				<div class="form-group info_row ">
					<div class="row">
						<div class="col-sm-4 col-12"> <label>Application acceptable through:</label></div>
						<div class="col-sm-8 col-12"> <span>FAF account</span></div>
					</div>
				</div>
				<div class="form-group info_row">
					<label class="mb-2">Skills required:</label>
					<p class="mb-0">Dribbling, Shooting, Defending, Passing</p>
				</div>
				<div class="form-group info_row mb-0">
					<label class="mb-2">Job description:</label>
					<p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eu gravida justo, eget iaculis dui. Curabitur nibh nisi, pharetra a vehicula ut, vulputate et dui. Mauris a ligula cursus, sagittis turpis vel, congue lorem. Praesent blandit, risus ut viverra molestie, nulla neque fringilla eros, suscipit pretium velit felis nec arcu. Integer ut lectus justo. Sed accumsan scelerisque neque ac interdum. Nullam erat turpis, scelerisque eget justo at, vestibulum lobortis purus. Ut egestas lacus sapien, vel egestas nibh auctor eget. Etiam vitae tempor nunc. Nullam dolor nunc, malesuada nec dolor ut, blandit sollicitudin lacus.</p>
				</div>
			</div>
		</div>

		<!-- xxxxxxxx -->

		<div class="col-xl-6 col-lg-12 col-md-12">
			<div class="box_wrapper questionnaire mb-30" id="QuestionnaireList">
				<h2 class="heading_22 mb-3">Questionnaire</h2>
				<div class="common_question">
					<div class="question">
						<label>Question:</label>
						<span><b>Which player is best in American football?</b></span>
					</div>
					<div class="answer d-flex">
						<label>Answer:</label>
						<ul class="list-unstyled d-inline-block mb-0">
							<li>A. Tom brady</li>
							<li>B. Antonio brown</li>
							<li>C. Carson centzn</li>
							<li>D. Julio Jones</li>
						</ul>
					</div>
					<div class="type">
						<label>Type:</label>
						<span>Checkbox</span>
					</div>
				</div>
				<div class="common_question">
					<div class="question">
						<label>Question:</label>
						<span><b>Which player is best in American football?</b></span>
					</div>
					<div class="answer d-flex">
						<label>Answer:</label>
						<ul class="list-unstyled d-inline-block mb-0">
							<li>A. Tom brady</li>
							<li>B. Antonio brown</li>
							<li>C. Carson centzn</li>
							<li>D. Julio Jones</li>
						</ul>
					</div>
					<div class="type">
						<label>Type:</label>
						<span>Checkbox</span>
					</div>
				</div>
				<div class="common_question">
					<div class="question">
						<label>Question:</label>
						<span><b>Which player is best in American football?</b></span>
					</div>
					<div class="answer d-flex">
						<label>Answer:</label>
						<ul class="list-unstyled d-inline-block mb-0">
							<li>A. Tom brady</li>
							<li>B. Antonio brown</li>
							<li>C. Carson centzn</li>
							<li>D. Julio Jones</li>
						</ul>
					</div>
					<div class="type">
						<label>Type:</label>
						<span>Checkbox</span>
					</div>
				</div>
				<div class="common_question">
					<div class="question">
						<label>Question:</label>
						<span><b>Which player is best in American football?</b></span>
					</div>
					<div class="answer d-flex">
						<label>Answer:</label>
						<ul class="list-unstyled d-inline-block mb-0">
							<li>A. Tom brady</li>
							<li>B. Antonio brown</li>
							<li>C. Carson centzn</li>
							<li>D. Julio Jones</li>
						</ul>
					</div>
					<div class="type">
						<label>Type:</label>
						<span>Checkbox</span>
					</div>
				</div>
				<div class="common_question">
					<div class="question">
						<label>Question:</label>
						<span><b>Which player is best in American football?</b></span>
					</div>
					<div class="answer d-flex">
						<label>Answer:</label>
						<ul class="list-unstyled d-inline-block mb-0">
							<li>A. Tom brady</li>
							<li>B. Antonio brown</li>
							<li>C. Carson centzn</li>
							<li>D. Julio Jones</li>
						</ul>
					</div>
					<div class="type">
						<label>Type:</label>
						<span>Checkbox</span>
					</div>
				</div>
				<div class="common_question">
					<div class="question">
						<label>Question:</label>
						<span><b>Which player is best in American football?</b></span>
					</div>
					<div class="answer d-flex">
						<label>Answer:</label>
						<ul class="list-unstyled d-inline-block mb-0">
							<li>A. Tom brady</li>
							<li>B. Antonio brown</li>
							<li>C. Carson centzn</li>
							<li>D. Julio Jones</li>
						</ul>
					</div>
					<div class="type">
						<label>Type:</label>
						<span>Checkbox</span>
					</div>
				</div>
			</div>
			<div class="box_wrapper">
				<h2 class="heading_22 mb-3 ">Contacts</h2>
				<div class="form-group info_row_flex">
					<label>Social media1:</label>	
					<span>https://www.socialmedia1.com/social_11</span>
				</div>
				<div class="form-group info_row_flex">
					<label>Social media2:</label>	
					<span>https://www.socialmedia1.com/social_11</span>
				</div>
				<div class="form-group info_row_flex">
					<label>Social media3:</label>	
					<span>https://www.socialmedia1.com/social_11</span>
				</div>
				<div class="form-group info_row_flex">
					<label>Contact person:</label>	
					<span>Dalton hoover</span>
				</div>
				<div class="form-group info_row_flex">
					<label>Email:</label>	
					<span>dalton.hoover0000@email.com</span>
				</div>
				<div class="form-group mb-0 info_row_flex">
					<label>Phone number:</label>	
					<span>+1 987 890 0000</span>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$("#QuestionnaireList").mCustomScrollbar({
        theme: "dark"
    });
</script>