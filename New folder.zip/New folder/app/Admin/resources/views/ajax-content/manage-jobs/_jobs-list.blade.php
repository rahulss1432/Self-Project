
<div class="content bg-white box-shadow">
    <div class="table-responsive common_table">
        <table class="table mb-0 ">
            <thead>
                <tr>
                    <th>Job ID</th>
                    <th>Job Type</th>
                    <th>Position</th>
                    <th>Level</th>
                    <th>Address</th>
                    <th>Posted Date & Time</th>
                    <th>Last Updated By</th>
                    <th>Last Updated On</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @php
                $positionName = [];
                @endphp
                @forelse ($jobList as $job)
                <tr>
                    <td>{{$job->reference_id}}</td>
                    <td>{{ucfirst($job->job_type)}}</td>
                    <td>
                        @php
                        $positions = explode(',',$job->position_id);
                        foreach($positions as $key => $val){
                        $positionName[$key] = getJobPositionByAdmin($val);
                        }
                        if(count($positionName) > 0){
                        echo implode(',',$positionName);
                        }else{
                        echo '-';
                        }
                        @endphp
                    </td>
                    <td>{{getLevelName($job->level_id)}}</td>
                    <td>{{!empty($job->user->address_line_1) ? ucfirst($job->user->address_line_1) : '-'}}</td>
                    <td>{{fullTimeFormat($job->created_at)}}</td>
                    <td>{{!empty($job->user->full_name) ? ucfirst($job->user->full_name) : '-'}} ({{$job->reference_id}})</td>
                    <td>{{fullTimeFormat($job->updated_At)}}</td>
                    <td>
                        <div class="switch">
                            <label>
                                @if( $job->status == 'active' )
                                <input type="checkbox" name="activeInactive" checked onchange="getValue(this,'{{$job->id}}')">
                                @else
                                <input type="checkbox" name="activeInactive" onchange="getValue(this,'{{$job->id}}')">
                                @endif
                                <span class="lever"></span>
                            </label>
                        </div>
                    </td>
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="{{url('admin/manage-jobs/view/'.base64_encode($job->id))}}">View</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="10"><div class="alert alert-danger text-center">No Record Found</div></td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
{{$jobList->links()}}  <!--Pagination render -->
<!-- Pagination on page click-->
<script>
    $(".pagination li a").on('click', function (e) {
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    getListing(pageLink);
    });
</script>
