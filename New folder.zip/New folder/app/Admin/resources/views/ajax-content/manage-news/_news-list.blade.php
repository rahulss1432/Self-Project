<div class="content bg-white box-shadow">
    <div class="table-responsive common_table">
        <table class="table mb-0 ">
            <thead>
                <tr>
                    <th>News ID</th>
                    <th>News Headline</th>
                    <th>Media</th>
                    <th>Posted on</th>
                    <th>Posted By</th>
                    <th>Last Updated by</th>
                    <th>Last Updated on</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($newsData as $news)
                <tr>
                    <td>{{$news->reference_id}}</td>
                    <td>{{$news->title}}</td>
                    <td>{{($news->type)?$news->type:'no'}}</td>
                    <td>{{$news->created_at}}</td>
                    <td>{{ getUserFullNameById($news->created_by) }}</td>
                    <td>{{ getUserFullNameById($news->updated_by) }}</td>
                    <td>{{dateTimeFormat($news->updated_at)}}</td>
             
                    <td>
                        <div class="switch">
                             <label>
                                @if( $news->status == 'active' )
                                <input type="checkbox" name="activeInactive" checked onchange="getValue(this,'{{$news->id}}')">
                                @else
                                <input type="checkbox" name="activeInactive" onchange="getValue(this,'{{$news->id}}')">
                                @endif
                                <span class="lever"></span>
                            </label>
                        </div>
                    </td>
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="{{ url('/admin/manage-news/view/'. base64_encode($news->id) )}}">View</a>
                                    <a class="dropdown-item" href="{{ url('/admin/manage-news/edit-news/'. base64_encode($news->id) )}}">Edit</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                @empty
                    <tr style=""><td colspan="9"><div class="alert alert-danger text-center">No Record Found</div></td></tr>
                @endforelse
            </tbody>
            <!-- Not Record Found -->
            <!--  -->
        </table>
    </div>
</div>

{{$newsData->links()}}  <!--Pagination render -->
<!-- Pagination on page click-->
<script>
    $(".pagination li a").on('click', function(e) {
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    getListing(pageLink);
    });
</script>






