<div class="modal-content" >
    <div class="modal-header">
        <h5 class="modal-title">Add Team</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="resetAddTeamForm()">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <form method="post" autocomplete="off" id="eventTeamForm" enctype="multipart/form-data" action="{{url('save-event-team')}}">
        {{csrf_field()}}
        <div class="modal-body">
            <div class="form-group">
                <label>Team Name</label>
                <input type="text" class="form-control" name="team_name">
            </div>
            <div class="form-group">
                <label>Team Logo</label>
                <label class="d-block" for="uploadLogo">
                    <div class="uploadIcon">
                        <span class="form-control" id="logoName"></span>
                        <input id="uploadLogo" name="team_logo" class="file" type="file">
                    </div>
                </label>
            </div>
        </div>
        <div class="modal-footer">
            <div class="form-group action mr-2  text-right mb-0">
                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-light mr-2 rounded-0 ripple-effect" onclick="resetAddTeamForm()">
                    Cancel
                </a>
                <button type="submit" class="btn btn-dark rounded-0" id="saveTeamBtn">Save <i style="display:none;" class="btn_loader"></i>
                </button>
            </div>
        </div>
    </form>
    {!! JsValidator::formRequest('App\Http\Requests\EventTeamRequest','#eventTeamForm') !!}        
</div>
<script>
    $('input[type="file"]').on('change', function () {
        var filename = $(this).val();
        if (/^\s*$/.test(filename)) {
            $(this).parent().children("#logoName").text("No file chosen...");
        } else {
            $(this).parent().children("#logoName").text(filename.replace(/C:\\fakepath\\/i, ''));
        }
    });
</script>