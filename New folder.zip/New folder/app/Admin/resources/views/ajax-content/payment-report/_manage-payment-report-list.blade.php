@if(count($payments) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th>Transaction ID</th>
            <th>Mentor Name</th>
            <th>User Name</th>
            <th>Job Date and Time</th>
            <th>Total Amount</th>
            <th>Commission</th>
            <th>Job Status </th>
            <th>Payment Method </th>
        </tr>
    </thead>
    <tbody>
        @foreach($payments as $payment)
        <tr>
            <td>#{{$payment->booking_id}}</td>
            <td>#{{$payment->transaction_id}}</td>
            <td>{{$payment->transactionMentor->first_name.' '.$payment->transactionMentor->last_name}}</td>
            <td>{{$payment->transactionUser->first_name.' '.$payment->transactionUser->last_name}}</td>
            <td>{{timeFormat($payment->created_at)}}</td>
            <td>$ {{$payment->total_amount}}</td>
            <td>$ {{$payment->commission}}</td>
            <td>{{ucfirst($payment->status)}}</td>
            <td>{{ucfirst($payment->payment_method)}}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $payments->links() }}
<script>
    $(".pagination li a").on('click', function (e) {
        pageDivLoader('show', 'getPaymentList');
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
                $('.pagination:first').remove();
                $('#getPaymentList').html(response.html);
            }
        });
    });
</script>