<?php include_once '../include/constant.php'; ?>
<table class="table admin-table">
    <thead>
        <tr>
          <th>Name</th>
          <th>Mentor Unique URL</th>
          <th>Account Name</th>
          <th>Account Number</th>
          <th>Bank Name</th>
          <th>Total Earnings Amount</th>
          <th>Total Commission</th>
          <th>Payment Status </th>
          <th class="w100 text-center">Action</th>
        </tr>
    </thead>

    <tbody>
        <!-- xxx -->
       <tr>
          <td>Charlotte Nelligan</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
          <td>Herman Perry</td>
          <td>00590000184002</td>
          <td>Axis Bank</td>
          <td>$ 1000.00</td>
          <td>$ 100.00</td>
          <td>Settled</td>
          <td>
            <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="View Detail">
                        <a href="<?php echo BASE_URL ?>/admin/contractors-payment-detail.php"><i class="ti-eye"></i></a>
                    </li>
                </ul>
          </td>
       </tr>

        <!-- xxx -->
       <tr>
          <td>Garrett Bird</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/garrettb">https://www.mentolocator.com/garrettb</a></td>
          <td>Colby Weeks</td>
          <td>00590000184015</td>
          <td>State Bank of India</td>
          <td>$ 1500.00</td>
          <td>$ 200.00</td>
          <td>
            Settled
          </td>
          <td>
            <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="View Detail">
                        <a href="<?php echo BASE_URL ?>/admin/contractors-payment-detail.php"><i class="ti-eye"></i></a>
                    </li>
                </ul>
          </td>
       </tr>

       <!-- xxx -->
       <tr>
          <td>Elmo Pratt</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/elmop">https://www.mentolocator.com/elmop</a></td>
          <td>Cally Kline</td>
          <td>00590000184050</td>
          <td>Corporation Bank</td>
          <td>$ 2000.00</td>
          <td>$ 250.00</td>
          <td>
            Unsettled
          </td>
          <td>
            <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="View Detail">
                        <a href="<?php echo BASE_URL ?>/admin/contractors-payment-detail.php"><i class="ti-eye"></i></a>
                    </li>
                </ul>
          </td>
       </tr>
       
       <!-- xxx -->
       <tr>
          <td>Charlotte Nelligan</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
          <td>Sage Horton</td>
          <td>00590000184002</td>
          <td>Axis Bank</td>
          <td>$ 1000.00</td>
          <td>$ 100.00</td>
          <td>
           Settled
          </td>
          <td>
            <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="View Detail">
                        <a href="<?php echo BASE_URL ?>/admin/contractors-payment-detail.php"><i class="ti-eye"></i></a>
                    </li>
                </ul>
          </td>
       </tr>

        <!-- xxx -->
       <tr>
          <td>Garrett Bird</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/garrettb">https://www.mentolocator.com/garrettb</a></td>
          <td>Bryar Frank</td>
          <td>00590000184015</td>
          <td>State Bank of India</td>
          <td>$ 1500.00</td>
          <td>$ 200.00</td>
          <td>
            Unsettled
          </td>
          <td>
            <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="View Detail">
                        <a href="<?php echo BASE_URL ?>/admin/contractors-payment-detail.php"><i class="ti-eye"></i></a>
                    </li>
                </ul>
          </td>
       </tr>

       <!-- xxx -->
       <tr>
          <td>Elmo Pratt</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/elmop">https://www.mentolocator.com/elmop</a></td>
          <td>Janna Bean</td>
          <td>00590000184050</td>
          <td>Corporation Bank</td>
          <td>$ 2000.00</td>
          <td>$ 250.00</td>
          <td>
           Unsettled
          </td>
          <td>
            <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="View Detail">
                        <a href="<?php echo BASE_URL ?>/admin/contractors-payment-detail.php"><i class="ti-eye"></i></a>
                    </li>
                </ul>
          </td>
       </tr>

       <!-- xxx -->
       <tr>
          <td>Charlotte Nelligan</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
          <td>Rudyard Kim</td>
          <td>00590000184002</td>
          <td>Axis Bank</td>
          <td>$ 1000.00</td>
          <td>$ 100.00</td>
          <td>
       Settled
          </td>
          <td>
            <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="View Detail">
                        <a href="<?php echo BASE_URL ?>/admin/contractors-payment-detail.php"><i class="ti-eye"></i></a>
                    </li>
                </ul>
          </td>
       </tr>

        <!-- xxx -->
       <tr>
          <td>Garrett Bird</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/garrettb">https://www.mentolocator.com/garrettb</a></td>
          <td>Ahmed Noble</td>
          <td>00590000184015</td>
          <td>State Bank of India</td>
          <td>$ 1500.00</td>
          <td>$ 200.00</td>
          <td>
           Unsettled
          </td>
          <td>
            <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="View Detail">
                        <a href="<?php echo BASE_URL ?>/admin/contractors-payment-detail.php"><i class="ti-eye"></i></a>
                    </li>
                </ul>
          </td>
       </tr>

       <!-- xxx -->
       <tr>
          <td>Elmo Pratt</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/elmop">https://www.mentolocator.com/elmop</a></td>
          <td>Phyllis Hull</td>
          <td>00590000184050</td>
          <td>Corporation Bank</td>
          <td>$ 2000.00</td>
          <td>$ 250.00</td>
          <td>
            Settled
          </td>
          <td>
            <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="View Detail">
                        <a href="<?php echo BASE_URL ?>/admin/contractors-payment-detail.php"><i class="ti-eye"></i></a>
                    </li>
                </ul>
          </td>
       </tr>

       <!-- xxx -->
       <tr>
          <td>Charlotte Nelligan</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
          <td>Wang Cain</td>
          <td>00590000184002</td>
          <td>Axis Bank</td>
          <td>$ 1000.00</td>
          <td>$ 100.00</td>
          <td>
           Unsettled
          </td>
          <td>
            <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="View Detail">
                        <a href="<?php echo BASE_URL ?>/admin/contractors-payment-detail.php"><i class="ti-eye"></i></a>
                    </li>
                </ul>
          </td>
       </tr>

    </tbody>
</table>
<script type="text/javascript">
  $('[data-toggle="tooltip"]').tooltip({ trigger: "hover" });
</script>