<div class="post_comment_listing">
    <h2 class="heading">Comments</h2>
    @if(!empty($getPostComment) && count($getPostComment) > 0)
    @foreach($getPostComment as $key=> $comment)
    <div class="comment_list">
        <div class="d-flex align-items-center">
            <div class="d-flex align-items-center">
                <div class="profile_img rounded-circle">
                    <img src="{{ checkUserImage($comment->user->profile_image, $comment->user->role) }}" alt="Profile">
                </div>
                <h3 class="mb-0">{{ $comment->user->full_name }}</h3>
            </div>
            <div class="ml-auto">
                <div class="date_time">
                    <span>{{ dateTimeFormat($comment->created_at) }}</span>
                </div>
            </div>
        </div>
        <div class="description">
            <p>{{ $comment->comment }}</p>
        </div>
    </div>
    @endforeach
    @else 
    <div class="alert alert-danger text-center">No Comment Found</div>
    @endif
</div>