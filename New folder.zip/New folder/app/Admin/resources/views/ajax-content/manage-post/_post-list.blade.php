<div class="bg-white box-shadow common_table">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Post ID</th>
                    <th>Posted By</th>
                    <th>Posted Date & Time</th>
                    <th>Media</th>
                    <th>Likes</th>
                    <th>Comments</th>
                    <th>Type</th>
                    <th>Last Updated By</th>
                    <th>Last Updated On</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse($getPostList as $post)
                <tr>
                    <td>{{ $post->id }}</td>
                    <td>{{ getUserFullNameById($post->user_id) }}</td>
                    <td>{{ dateTimeFormat($post->created_at) }}</td>
                    <td>{{ ($post->type == 'media') ? 'Yes' : 'No' }}</td>
                    <td>{{ countPostEvent($post->id, 'like') }}</td>
                    <td>{{ countPostEvent($post->id, 'comment') }}</td>
                    <td>{{ $post->post_type }}</td>
                    <td>{{ getUserFullNameById($post->user_id) }}</td>
                    <td>{{ (dateTimeFormat($post->updated_at))? dateTimeFormat($post->updated_at) : '-' }}</td>
                    <td>
                        <div class="switch">
                            <label>
                                @if($post->status == 'active' )
                                <input type="checkbox" name="activeInactive" checked onchange="getValue(this,'{{$post->id}}')">
                                @else
                                <input type="checkbox" name="activeInactive" onchange="getValue(this,'{{$post->id}}')">
                                @endif
                                <span class="lever"></span>
                            </label>
                        </div>
                    </td>
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="{{ url('admin/manage-post/view/'.base64_encode($post->id)) }}">View</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                @empty
                <tr style=""><td colspan="11"><div class="alert alert-danger text-center">No Record Found.</div></td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
{{$getPostList->links()}}  <!--Pagination render -->
<!-- Pagination on page click-->
<script>
   $(".pagination li a").on('click', function(e) {
       e.preventDefault();
       var $this = $(this);
       var pageLink = $this.attr('href');
       getListing(pageLink);
   });
</script>

