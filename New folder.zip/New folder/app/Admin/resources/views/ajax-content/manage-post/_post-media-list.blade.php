<div class="post_img_section mCustomScrollbar" data-mcs-theme="dark" >
    <div class="row">
        @if(count($getPost->media) > 0)
        @foreach($getPost->media as $post)
        <div class="col-sm-3 col-6">
            <div class="post_img">
                <a href="javascript:void(0);" onclick="getMediaModal('{{ $post->id }}')">
                    <img src="{{ checkMediaImage($post->media,  getUserById($post->user_id, 'role').'/thumb') }}" class="img-fluid rounded" alt="post-view">
                </a>
            </div>
        </div>
        @endforeach
        @else 
        <div class="col-12">
            <div class="alert alert-danger text-center">No Media Found.</div>
        </div>
        @endif
    </div>
</div>

<!--open post media modal-->
<div class="modal photos modal-effect" id="myPhotosVideos" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="flaticon-cancel-music"></i>
                </button>
            </div>
            <div class="modal-body">
                <div id="get-post-view-modal"></div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $().mCustomScrollbar({
      theme:"dark"
    });
    
    // get post media view modal
    function getMediaModal(mediaId){
    $("#get-post-view-modal").html('<span class="ajax_loader btn_ring"></span>');
        var url = '{{ url("admin/menage-post/get-media-modal") }}';
        $.ajax({
        type: "GET", url: url, data: {media_id: mediaId},
            success: function (response) {
            $("#get-post-view-modal").html("");
            $("#get-post-view-modal").html(response.html);
            $('#myPhotosVideos').modal('show');
            }
        });
    }
</script>