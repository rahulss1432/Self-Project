<table class="table admin-table">
    <thead>
        <tr>
            <th>Customer Name</th>
            <th>Email</th>
            <th>Unique url</th>
            <th>Date Added</th>
            <th>Status</th>
            <th class="w150 text-center">Block/Unblock</th>
        </tr>
    </thead>

    <tbody>
        <!-- xxx -->
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Charlotte Nelligan</a>
            </td>
            <td>charlotten@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td>10/11/2017</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Garrett Bird</a>
            </td>
            <td>garrettb@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/garrettb">https://www.mentolocator.com/garrettb</a></td>
            <td>10/01/2018</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <div class="switch text-center ">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Elmo Pratt</a>
            </td>
            <td>elmonp@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/elmonp">https://www.mentolocator.com/elmonp</a></td>
            <td>12/11/2017</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>

                </div>
            </td>
        </tr>

         <!-- xxx -->
         <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Charlotte Nelligan</a>
            </td>
            <td>charlotten@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td>10/11/2017</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Garrett Bird</a>
            </td>
            <td>garrettb@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/garrettb">https://www.mentolocator.com/garrettb</a></td>
            <td>10/01/2018</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Elmo Pratt</a>
            </td>
            <td>elmonp@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/elmonp">https://www.mentolocator.com/elmonp</a></td>
            <td>12/11/2017</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>

                </div>
            </td>
        </tr>

         <!-- xxx -->
         <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Charlotte Nelligan</a>
            </td>
            <td>charlotten@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td>10/11/2017</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Garrett Bird</a>
            </td>
            <td>garrettb@gmail.com</td>
           <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/garrettb">https://www.mentolocator.com/garrettb</a></td>
            <td>10/01/2018</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Elmo Pratt</a>
            </td>
            <td>elmonp@gmail.com</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/elmonp">https://www.mentolocator.com/elmonp</a></td>
            <td>12/11/2017</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>

                </div>
            </td>
        </tr>

         <!-- xxx -->
         <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="profileView()">Charlotte Nelligan</a>
            </td>
            <td>charlotten@gmail.com</td>
           <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td>10/11/2017</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>

                </div>
            </td>
        </tr>

    </tbody>
</table>
<script>
$('[data-toggle="tooltip"]').tooltip({ trigger: "hover" });
</script>