<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th>Mentor Name</th>
            <th>User Name</th>
            <th>Rating counts</th>
            <th>Date and time </th>
            <th class="w350">Comment</th>
        </tr>
    </thead>
    <tbody>
        <!-- xxx -->
        <tr>
            <td>#0004125</td>
            <td>Steven Shelton</td>
            <td>Charlotte Nelligan</td>
            <td>
                <div class="rating d-inline-block">
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                </div>
                <span>(5.0)</span>
            </td>
            <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
            <td>Model sentence structures, to generate Lorem Ipsum which looks reasonable</td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>#0004178</td>
            <td>Brooke Sears</td>
            <td>Elmo Pratt</td>
            <td>
                <div class="rating d-inline-block">
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                </div>
                <span>(4.0)</span>
            </td>
            <td>24<sup>th</sup> Jan 2018, 08.00 AM</td>
            <td>Model sentence structures, to generate Lorem Ipsum which looks reasonable</td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>#0004025</td>
            <td>Jin Stevens</td>
            <td>Garrett Bird</td>
            <td>
                <div class="rating d-inline-block">
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star-half-o" aria-hidden="true"></i>
                </div>
                <span>(4.5)</span>
            </td>
            <td>30<sup>th</sup> Jan 2018, 11.00 AM</td>
            <td>Model sentence structures, to generate Lorem Ipsum which looks reasonable</td>
        </tr>
      <!-- xxx -->
        <tr>
            <td>#0004125</td>
            <td>Steven Shelton</td>
            <td>Charlotte Nelligan</td>
            <td>
                <div class="rating d-inline-block">
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                </div>
                <span>(5.0)</span>
            </td>
            <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
            <td>Model sentence structures, to generate Lorem Ipsum which looks reasonable</td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>#0004178</td>
            <td>Brooke Sears</td>
            <td>Elmo Pratt</td>
            <td>
                <div class="rating d-inline-block">
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                </div>
                <span>(4.0)</span>
            </td>
            <td>24<sup>th</sup> Jan 2018, 08.00 AM</td>
            <td>Model sentence structures, to generate Lorem Ipsum which looks reasonable</td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>#0004025</td>
            <td>Jin Stevens</td>
            <td>Garrett Bird</td>
            <td>
                <div class="rating d-inline-block">
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star-half-o" aria-hidden="true"></i>
                </div>
                <span>(4.5)</span>
            </td>
            <td>30<sup>th</sup> Jan 2018, 11.00 AM</td>
            <td>Model sentence structures, to generate Lorem Ipsum which looks reasonable</td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>#0004125</td>
            <td>Steven Shelton</td>
            <td>Charlotte Nelligan</td>
            <td>
                <div class="rating d-inline-block">
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                </div>
                <span>(5.0)</span>
            </td>
            <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
            <td>Model sentence structures, to generate Lorem Ipsum which looks reasonable</td>
        </tr>
        <!-- xxx -->
        <tr>
            <td>#0004178</td>
            <td>Brooke Sears</td>
            <td>Elmo Pratt</td>
            <td>
                <div class="rating d-inline-block">
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star-o" aria-hidden="true"></i>
                </div>
                <span>(4.0)</span>
            </td>
            <td>24<sup>th</sup> Jan 2018, 08.00 AM</td>
            <td>Model sentence structures, to generate Lorem Ipsum which looks reasonable</td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>#0004025</td>
            <td>Jin Stevens</td>
            <td>Garrett Bird</td>
            <td>
                <div class="rating d-inline-block">
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star-half-o" aria-hidden="true"></i>
                </div>
                <span>(4.5)</span>
            </td>
            <td>30<sup>th</sup> Jan 2018, 11.00 AM</td>
            <td>Model sentence structures, to generate Lorem Ipsum which looks reasonable</td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>#0004125</td>
            <td>Steven Shelton</td>
            <td>Charlotte Nelligan</td>
            <td>
                <div class="rating d-inline-block">
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                    <i class="fa fa-star" aria-hidden="true"></i>
                </div>
                <span>(5.0)</span>
            </td>
            <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
            <td>Model sentence structures, to generate Lorem Ipsum which looks reasonable</td>
        </tr>
    </tbody>
</table>