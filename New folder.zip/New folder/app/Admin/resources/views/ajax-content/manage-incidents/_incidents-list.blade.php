<div class="content bg-white box-shadow">
    <div class="table-responsive common_table">
        <table class="table mb-0 ">
            <thead>
                <tr>
                    <th>Incidents No.</th>
                    <th>Reported Entity</th>
                    <th>Entity ID</th>
                    <th>Reported On</th>
                    <th>Publisher</th>
                    <th>Reported By</th>
                    <th>Last Updated By</th>
                    <th>Last Updated On</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($incidents as $incident)
                <tr>
                    <td>{{$incident->reference_id}}</td>
                    <td class="text-capitalize">{{ucfirst($incident->reported_entity)}}</td>
                    <td>{{$incident->entity_id}}</td>
                    <td>{{fullTimeFormat($incident->created_at)}}</td>
                    <td class="text-capitalize">{{getEntityPublisherDetail($incident->entity_id,$incident->reported_entity)['publisher']}}</td>
                    <td class="text-capitalize">{{$incident->reporter->full_name.'('.$incident->reporter->reference_id.')'}}</td>
                    <td>{{!empty($incident->status=='resolved') ? getUserById($incident->updated_by, 'full_name') : '-'}}</td>
                    <td>{{!empty($incident->status=='resolved') ? fullTimeFormat($incident->updated_at) : '-'}}</td>
                    @if($incident->status=='open')
                    <td><span class="text-warning text-capitalize">open</span></td>
                    @else
                    <td><span class="text-success text-capitalize">Resolved</span></td>
                    @endif
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="{{ url('admin/manage-incidents/view/'.base64_encode($incident->id)) }}">View</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="10"><div class="alert alert-danger text-center">No Record Found</div></td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
{{$incidents->links()}}  <!--Pagination render -->
<!-- Pagination on page click-->
<script>
    $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        getListing(pageLink);
    });
</script>


