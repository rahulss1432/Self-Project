
<table class="table admin-table">
    <thead>
        <tr>
          <th>Booking ID</th>
          <th>Name</th>
          <th>Mentor Unique URL</th>
          <th>Job date and time</th>
          <th>Service Type</th>
          <th>Amount</th>
          <th>Commission</th>
          <th>Job Status</th>
          <th>Payment Status </th>
        </tr>
    </thead>

    <tbody>
       <tr>
         <td>#0095841</td>
         <td>Elmo Pratt</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/Elmop">https://www.mentolocator.com/Elmop</a></td>
        <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
         <td>Fitness</td>
         <td>$ 200.00</td>
         <td>$ 20.00</td>
         <td>Completed</td>
         <td>Settled</td>
       </tr>

       <tr>
         <td>#0085874</td>
         <td>Garrett Bird</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/Garrettb">https://www.mentolocator.com/Garrettb</a></td>
        <td>25<sup>th</sup> Jan 2018, 07.00 AM</td>
         <td>Fitness</td>
         <td>$ 3500.00</td>
         <td>$ 15.00</td>
         <td>Completed</td>
         <td>Unsettled</td>
       </tr>

       <tr>
         <td>#0084512</td>
         <td>Charlotte Nelligan</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
        <td>28<sup>th</sup> Jan 2018, 10.00 AM</td>
         <td>Fitness</td>
         <td>$ 300.00</td>
         <td>$ 25.00</td>
         <td>Completed</td>
         <td>Settled</td>
       </tr>

       <tr>
         <td>#0095841</td>
         <td>Elmo Pratt</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/Elmop">https://www.mentolocator.com/Elmop</a></td>
        <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
         <td>Fitness</td>
         <td>$ 200.00</td>
         <td>$ 20.00</td>
         <td>Completed</td>
         <td>Settled</td>
       </tr>

       <tr>
         <td>#0085874</td>
         <td>Garrett Bird</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/Garrettb">https://www.mentolocator.com/Garrettb</a></td>
        <td>25<sup>th</sup> Jan 2018, 07.00 AM</td>
         <td>Fitness</td>
         <td>$ 3500.00</td>
         <td>$ 15.00</td>
         <td>Completed</td>
         <td>Unsettled</td>
       </tr>

       <tr>
         <td>#0084512</td>
         <td>Charlotte Nelligan</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
        <td>28<sup>th</sup> Jan 2018, 10.00 AM</td>
         <td>Fitness</td>
         <td>$ 300.00</td>
         <td>$ 25.00</td>
         <td>Completed</td>
         <td>Settled</td>
       </tr>

       <tr>
         <td>#0095841</td>
         <td>Elmo Pratt</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/Elmop">https://www.mentolocator.com/Elmop</a></td>
        <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
         <td>Fitness</td>
         <td>$ 200.00</td>
         <td>$ 20.00</td>
         <td>Completed</td>
         <td>Settled</td>
       </tr>

       <tr>
         <td>#0085874</td>
         <td>Garrett Bird</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/Garrettb">https://www.mentolocator.com/Garrettb</a></td>
        <td>25<sup>th</sup> Jan 2018, 07.00 AM</td>
         <td>Fitness</td>
         <td>$ 3500.00</td>
         <td>$ 15.00</td>
         <td>Completed</td>
         <td>Unsettled</td>
       </tr>

       <tr>
         <td>#0084512</td>
         <td>Charlotte Nelligan</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
        <td>28<sup>th</sup> Jan 2018, 10.00 AM</td>
         <td>Fitness</td>
         <td>$ 300.00</td>
         <td>$ 25.00</td>
         <td>Completed</td>
         <td>Settled</td>
       </tr>

       <tr>
         <td>#0095841</td>
         <td>Elmo Pratt</td>
         <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/Elmop">https://www.mentolocator.com/Elmop</a></td>
        <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
         <td>Fitness</td>
         <td>$ 200.00</td>
         <td>$ 20.00</td>
         <td>Completed</td>
         <td>Settled</td>
       </tr>

    </tbody>
</table>
<script>
$('[data-toggle="tooltip"]').tooltip({ trigger: "hover" });
</script>