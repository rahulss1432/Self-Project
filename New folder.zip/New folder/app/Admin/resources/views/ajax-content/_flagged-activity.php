<?php include_once '../include/constant.php'; ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>User Name</th>
            <th>Mentor Name</th>
            <th>Date and Time</th>
            <th>Status</th>
            <th class="w100 text-center">Action</th>
        </tr>
    </thead>

    <tbody>
        <!-- xxx -->
        <tr>
            <td>Charlotte Nelligan</td>
            <td>Steven Shelton</td>
           <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Message">
                        <a href="<?php echo BASE_URL ?>/admin/messages.php"><i class="ti-comment-alt"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
       <!-- xxx -->
        <tr>
            <td>Brooke Sears</td>
            <td>Elmo Pratt</td>
           <td>24<sup>th</sup> Jan 2018, 10.00 AM</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Message">
                        <a href="<?php echo BASE_URL ?>/admin/messages.php""><i class="ti-comment-alt"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>Jin Stevens</td>
            <td>Garrett Bird</td>
           <td>24<sup>th</sup> Feb 2018, 07.00 AM</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Message">
                        <a href="<?php echo BASE_URL ?>/admin/messages.php""><i class="ti-comment-alt"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>Charlotte Nelligan</td>
            <td>Steven Shelton</td>
           <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Message">
                        <a href="<?php echo BASE_URL ?>/admin/messages.php""><i class="ti-comment-alt"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
       <!-- xxx -->
        <tr>
            <td>Brooke Sears</td>
            <td>Elmo Pratt</td>
           <td>24<sup>th</sup> Jan 2018, 10.00 AM</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Message">
                        <a href="<?php echo BASE_URL ?>/admin/messages.php""><i class="ti-comment-alt"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>Jin Stevens</td>
            <td>Garrett Bird</td>
           <td>24<sup>th</sup> Feb 2018, 07.00 AM</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Message">
                        <a href="<?php echo BASE_URL ?>/admin/messages.php""><i class="ti-comment-alt"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>Charlotte Nelligan</td>
            <td>Steven Shelton</td>
           <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Message">
                        <a href="<?php echo BASE_URL ?>/admin/messages.php""><i class="ti-comment-alt"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <!-- xxx -->
       <!-- xxx -->
        <tr>
            <td>Brooke Sears</td>
            <td>Elmo Pratt</td>
           <td>24<sup>th</sup> Jan 2018, 10.00 AM</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Message">
                        <a href="<?php echo BASE_URL ?>/admin/messages.php""><i class="ti-comment-alt"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>

        <!-- xxx -->
        <tr>
            <td>Jin Stevens</td>
            <td>Garrett Bird</td>
           <td>24<sup>th</sup> Feb 2018, 07.00 AM</td>
            <td>
                <div class="switch">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Message">
                        <a href="<?php echo BASE_URL ?>/admin/messages.php""><i class="ti-comment-alt"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="deleteModal();"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
    </tbody>
</table>
<script type="text/javascript">
    $('[data-toggle="tooltip"]').tooltip({ trigger: "hover" });
</script>