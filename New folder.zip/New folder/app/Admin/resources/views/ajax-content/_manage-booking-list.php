<?php include_once '../include/constant.php'; ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th class="w250">Address</th>
            <th>Job Date and Time</th>
            <th>Job Type</th>
            <th>Service Type</th>
            <th>Mentor Name</th>
            <th>User Name</th>
            <th>Amount</th>
            <th class="w120 text-center">Invoice</th>
        </tr>
    </thead>

    <tbody>
        <!-- xxx -->
       <tr>
           <td>#0041512</td>
           <td>45 st peter Warner, Queensland, 4500 Australia</td>
           <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
           <td>All</td>
           <td>Fitness</td>
           <td>Steven Shelton</td>
           <td>Charlotte Nelligan</td>
           <td>$ 400.00</td>
           <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/invoice.php" target="_blank" class="btn-blue">View Invoice</a></td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#00415564</td>
           <td>45 st peter Warner, Queensland, 4500 Australia</td>
           <td>15<sup>th</sup> Feb 2018, 10.00 AM</td>
           <td>Pending</td>
           <td>Craftsmanship</td>
           <td>Brooke Sears</td>
           <td>Elmo Pratt</td>
           <td>$ 200.00</td>
           <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/invoice.php" target="_blank" class="btn-blue">View Invoice</a></td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#0041224</td>
           <td>45 st peter Warner, Queensland, 4500 Australia</td>
           <td>24<sup>th</sup> Feb 2018, 11.00 AM</td>
           <td>Completed</td>
           <td>Automobile</td>
           <td>Jin Stevens</td>
           <td>Garrett Bird</td>
           <td>$ 300.00</td>
           <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/invoice.php" target="_blank" class="btn-blue">View Invoice</a></td>
       </tr>

  <!-- xxx -->
       <tr>
           <td>#0041512</td>
           <td>45 st peter Warner, Queensland, 4500 Australia</td>
           <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
           <td>All</td>
           <td>Fitness</td>
           <td>Steven Shelton</td>
           <td>Charlotte Nelligan</td>
           <td>$ 400.00</td>
           <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/invoice.php" target="_blank" class="btn-blue">View Invoice</a></td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#00415564</td>
           <td>45 st peter Warner, Queensland, 4500 Australia</td>
           <td>15<sup>th</sup> Feb 2018, 10.00 AM</td>
           <td>Pending</td>
           <td>Craftsmanship</td>
           <td>Brooke Sears</td>
           <td>Elmo Pratt</td>
           <td>$ 200.00</td>
           <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/invoice.php" target="_blank" class="btn-blue">View Invoice</a></td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#0041224</td>
           <td>45 st peter Warner, Queensland, 4500 Australia</td>
           <td>24<sup>th</sup> Feb 2018, 11.00 AM</td>
           <td>Completed</td>
           <td>Automobile</td>
           <td>Jin Stevens</td>
           <td>Garrett Bird</td>
           <td>$ 300.00</td>
           <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/invoice.php" target="_blank" class="btn-blue">View Invoice</a></td>
       </tr>

        <!-- xxx -->
        <!-- xxx -->
       <tr>
           <td>#0041512</td>
           <td>45 st peter Warner, Queensland, 4500 Australia</td>
           <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
           <td>All</td>
           <td>Fitness</td>
           <td>Steven Shelton</td>
           <td>Charlotte Nelligan</td>
           <td>$ 400.00</td>
           <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/invoice.php" target="_blank" class="btn-blue">View Invoice</a></td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#00415564</td>
           <td>45 st peter Warner, Queensland, 4500 Australia</td>
           <td>15<sup>th</sup> Feb 2018, 10.00 AM</td>
           <td>Pending</td>
           <td>Craftsmanship</td>
           <td>Brooke Sears</td>
           <td>Elmo Pratt</td>
           <td>$ 200.00</td>
           <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/invoice.php" target="_blank" class="btn-blue">View Invoice</a></td>
       </tr>

       <!-- xxx -->
       <tr>
           <td>#0041224</td>
           <td>45 st peter Warner, Queensland, 4500 Australia</td>
           <td>24<sup>th</sup> Feb 2018, 11.00 AM</td>
           <td>Completed</td>
           <td>Automobile</td>
           <td>Jin Stevens</td>
           <td>Garrett Bird</td>
           <td>$ 300.00</td>
           <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/invoice.php" target="_blank" class="btn-blue">View Invoice</a></td>
       </tr>

        <!-- xxx -->
       <tr>
           <td>#0041512</td>
           <td>45 st peter Warner, Queensland, 4500 Australia</td>
           <td>19<sup>th</sup> Jan 2018, 08.00 AM</td>
           <td>All</td>
           <td>Fitness</td>
           <td>Steven Shelton</td>
           <td>Charlotte Nelligan</td>
           <td>$ 400.00</td>
           <td class="text-center"><a href="<?php echo BASE_URL ?>/admin/invoice.php" target="_blank" class="btn-blue">View Invoice</a></td>
       </tr>
    </tbody>
</table>
