@if(!empty($getContractors) && count($getContractors) > 0)
<table class="table admin-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Unique url</th>
            <th class="w-150 text-center">View Documents</th>
            <th class="w-150 text-center">View Categories </th>
            <th>View Availability </th>
            <th>Status</th>
            <th class="w170 text-center">Approve/Disapprove</th>
        </tr>
    </thead>
    <tbody>
        @foreach($getContractors as $contractor)
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="loadContractorDetails('{{ $contractor->id }}')">{{ getFullName($contractor->first_name, $contractor->last_name) }}</a>
            </td>
            <td>{{ $contractor->email }}</td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="{{url('admin/manage-category')}}" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        @if($contractor->status == 'active')
                        <input type="checkbox" name="activeInactive"  checked onchange="changeStatus(this,'{{ $contractor->id}}')">
                        @else
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'{{ $contractor->id}}')">
                        @endif
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else 
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $getContractors->links() }}
<script>
    $('[data-toggle="tooltip"]').tooltip({trigger: "hover"});
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getContractorsList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getContractorsList').html(response.html);
            }
    });
    });
    $('[data-toggle="tooltip"]').tooltip({trigger: "hover"});
</script>