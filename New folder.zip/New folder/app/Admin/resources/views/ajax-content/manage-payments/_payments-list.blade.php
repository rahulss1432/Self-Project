<div class="content bg-white box-shadow">
    <!--  -->
    <div class="table-responsive common_table">
        <table class="table mb-0 ">
            <thead>
                <tr>
                    <th>Trans. ID</th>
                    <th>Payment Mode</th>
                    <th>Plan</th>
                    <th>Purchased On</th>
                    <th>Expires On</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($paymentList as $payment)
                <tr>
                    <td>{{$payment->reference_id}}</td>
                    <td>{{ucfirst($payment->transactionUser->signup_type)}}</td>
                    <td>{{getPlanMonth($payment->userSubscription->renewal_cycle)}}({{$payment->userSubscription->reference_id}})</td>
                    <td>{{sameDate($payment->start_date)}}</td>
                    <td>{{sameDate($payment->end_date)}}</td>
                    <td>$ {{$payment->amount}}</td>
                </tr>
                @empty
                <tr><td colspan="8"><div class="alert alert-danger text-center">No Record Found.</div></td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    {{ $paymentList->links() }}  <!--Pagination render -->
    <!-- Pagination on page click-->
    <script>
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            var $this = $(this);
            var pageLink = $this.attr('href');
            getListing(pageLink);
        });
    </script>