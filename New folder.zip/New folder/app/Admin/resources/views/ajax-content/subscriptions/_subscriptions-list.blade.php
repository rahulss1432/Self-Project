<div class="content bg-white box-shadow">
    <div class="table-responsive common_table">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Sub. ID</th>
                    <th>Sub. Name</th>
                    <th>Renewal Cycle</th>
                    <th>Amount</th>
                    <th>Last Updated By</th>
                    <th>Last Updated On</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($getSubscription as $subscription) 
                <tr>
                    <td>{{ $subscription->reference_id  }}</td>
                    <td>{{ ucfirst($subscription->title) }}</td>
                    <td>{{ $subscription->renewal_cycle }}</td>
                    <td>{{ $subscription->amount }}</td>
                     <td>{{ getUserFullNameById($subscription->updated_by) }}</td>
                   <td>{{ dateTimeFormat($subscription->created_at) }}</td>
                    <td>
                        <div class="switch">
                             <label>
                                @if($subscription->status == 'active' )
                                <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this,'{{$subscription->id}}')">
                                @elseif(checkActiveSubscriptions() >= 4)
                                <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'message')">
                                @else 
                                 <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'{{$subscription->id}}')">
                                @endif
                                <span class="lever"></span>
                            </label>
                        </div>
                    </td>
                    <td>
                        <div class="action_dropdown">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                </button>
                                <div class="dropdown-menu list-menu" aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item" href="{{ url('/admin/subscriptions/view/'. base64_encode($subscription->id) )}}">View</a>
                                    <a class="dropdown-item" href="{{ url('/admin/subscriptions/edit/'. base64_encode($subscription->id) )}}">Edit</a>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                 @empty
              <tr><td colspan="9"><div class="alert alert-danger text-center">No Record Found</div></td></tr>
                @endforelse
            </tbody>
         </table>
    </div>
</div>
{{$getSubscription->links()}} 
<script>
  function changeStatus(el, id){
    if(id == 'message'){
       alert('only 4 status active of subscription');
       $(el).prop('checked',false);
       }else{
       if ($(el).is(':checked')) {
           var status =  'active';
        } else {
           var status =  'inactive';
        }
        bootbox.confirm({
            size: "small",
            message: "Are you sure to update status?",
            buttons: {
                confirm: {
                    label: 'Yes',
                    className: 'btn btn-success rounded-0'
                },
                cancel: {
                    label: 'No',
                    className: 'btn btn-light rounded-0'
                }
            },
            callback: function (result) {
                if (result) {
                  update_status(id, status);
                }else {
                if (status == 'active') {
                    $(el).prop('checked',false);
                } else {
                    $(el).prop('checked', true);
                }
                return true;
              } 
            }
        });
     }
   }

    function update_status(id, status) {
        $.ajax({
            url: "{{ url('admin/subscriptions/status') }}",
            type: 'GET',
            data: {id: id, status: status},
            cache: false,
            dataType: 'JSON',
            success: function (data) {
                if (data.success) {
                    message('success', data.message);
                    var pageNumber = $('a.page-link.active').text();
                    var pageLink = 'http://localhost/faf/admin/subscriptions/_subscriptions-list?page=' + pageNumber;
                    getListing(pageLink);
                } else {
                    message('error', data.message);
                }
            },
            error: function (err) {
                message('error', err);
            },
            complete: function () {
            }
      });
    }
    
     $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        getListing(pageLink);
    });
    
    $(function () {
        $('[data-toggle="popover"]').popover()
    })

    $('[data-toggle="popover"]').on('click', function () {
        $(this).toggleClass('btn_active');
    });



</script>