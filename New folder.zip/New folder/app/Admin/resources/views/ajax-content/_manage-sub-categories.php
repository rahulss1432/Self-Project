<table class="table admin-table">
    <thead>
        <tr>
            <th>Sub Category Name</th>
            <th class="w150 text-center">Status</th>
        </tr>
    </thead>

    <tbody>
        <!-- xxx -->
        <tr>
        <td>Jogging</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Dancing</td>
            <td>
                <div class="switch text-center ">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Swimming laps</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

         <!-- xxx -->
         <tr>
         <td>Jogging</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Dancing</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Swimming laps</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

         <!-- xxx -->
         <tr>
         <td>Jogging</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Dancing</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

           <!-- xxx -->
           <tr>
           <td>Swimming laps</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

         <!-- xxx -->
         <tr>
         <td>Jogging</td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox" checked>
                        <span class="lever" onclick="showStatusModal();"></span>
                    </label>

                </div>
            </td>
        </tr>

    </tbody>
</table>