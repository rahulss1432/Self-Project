@if(count($notification) > 0)
@foreach($notification as $notify)
<div class="notification-box">
    <span class="custom-control-description">
        <p>Editorial Collections</p>
        <span>{{$notify->message}}</span>
    </span>
</div>
@endforeach
@else
<div class="alert alert-danger"><center>No record found</center></div>
@endif
{{ $notification->links() }}