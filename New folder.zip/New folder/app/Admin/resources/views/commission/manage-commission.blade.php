@extends('admin::include.app')
@section('title', 'Manage Payment')
@section('content')
<main class="main-content common-grid-list" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Commission List</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive" id="getCommissionList">

                </div>
            </div>
        </div>
    </div>
</main>
<!-- add flagged terms modal -->
<div class="modal fade" id="editCommissionModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyword="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Commission</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <form name="" class="f-field">
                    <div class="form-group">
                        <input type="text" class="form-control form-control-lg" value="10" required />
                        <label class="control-label">Commission rate</label>
                    </div>
                    <div class="form-group mb-0 text-right">
                        <button type="button" class="btn btn-sm btn-primary ripple-effect">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function ()
    {
        $('#preloader').hide();
        load_commission_list();
    });

    function load_commission_list()
    {
        pageDivLoader('show', 'getCommissionList');
        $.ajax({
            type: "GET",
            url: "{{ url('admin/load-commission-list') }}",
            success: function (response)
            {
                if (response.success) {
                    $("#getCommissionList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    function editCommission() {
        $("#editCommissionModal").modal("show");
    }
</script>
@endsection