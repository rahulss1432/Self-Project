<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Messages</title>

    <?php include 'include/links.php' ?>
</head>
<?php
    $current = 'message';
    $currentPageName = 'message';
    ?>

<body class="bg-light-gray" onload="hide_preloader();">
    <div id="preloader">
        <div class="inner">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
    </div>

    <?php include 'include/side-menu.php' ?>
    <?php include 'include/header.php' ?>
    <main class="main-content messages-page" id="mainContent">
        <div class="page-content">
            <div class="card custom_card">
                <div class="card-header">
                    <h4 class="page-title float-left">Message List</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Back" >
                            <a href="<?php echo BASE_URL ?>/admin/manage-flagged.php" class="nav-link"><i class="ti-arrow-left"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="card-body message-body">
                 <div class="row">
                     <div class="left_section col pr-md-0" id="leftSection">
                        <div class="mCustomScrollbar" data-mcs-theme="minimal-dark">
                            <ul class="list-unstyled">
                             <li>
                                 <a href="javascript:void(0);" class="active">
                                     <img src="<?php echo IMAGES_URL ?>/user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span>Charlotte Nelligan</span>
                                 </a>
                             </li>
                             <li>
                                 <a href="javascript:void(0);">
                                     <img src="<?php echo IMAGES_URL ?>/user-2.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span>Brooke Sears</span>
                                 </a>
                             </li>
                             <li>
                                 <a href="javascript:void(0);">
                                     <img src="<?php echo IMAGES_URL ?>/user-3.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span>Jin Stevens</span>
                                 </a>
                             </li>
                             <li>
                                 <a href="javascript:void(0);">
                                     <img src="<?php echo IMAGES_URL ?>/user-4.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span>Steven Shelton</span>
                                 </a>
                             </li>

                             <li>
                                 <a href="javascript:void(0);">
                                     <img src="<?php echo IMAGES_URL ?>/user-5.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span>Brooke Sears</span>
                                 </a>
                             </li>

                             <li>
                                 <a href="javascript:void(0);">
                                     <img src="<?php echo IMAGES_URL ?>/user-6.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span>Steven Shelton</span>
                                 </a>
                             </li>

                             <li>
                                 <a href="javascript:void(0);">
                                     <img src="<?php echo IMAGES_URL ?>/user-7.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span>Charlotte Nelligan</span>
                                 </a>
                             </li>
                             <li>
                                 <a href="javascript:void(0);">
                                     <img src="<?php echo IMAGES_URL ?>/user-4.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span>Steven Shelton</span>
                                 </a>
                             </li>

                             <li>
                                 <a href="javascript:void(0);">
                                     <img src="<?php echo IMAGES_URL ?>/user-8.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span>Elmo Pratt</span>
                                 </a>
                             </li>

                             <li>
                                 <a href="javascript:void(0);">
                                     <img src="<?php echo IMAGES_URL ?>/user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span>Charlotte Nelligan</span>
                                 </a>
                             </li>
                             <li>
                                 <a href="javascript:void(0);">
                                     <img src="<?php echo IMAGES_URL ?>/user-8.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span>Elmo Pratt</span>
                                 </a>
                             </li>

                             <li>
                                 <a href="javascript:void(0);">
                                     <img src="<?php echo IMAGES_URL ?>/user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span> Garrett Bird</span>
                                 </a>
                             </li>
                         </ul>
                        </div>
                         
                     </div>
                     <!-- right section start -->
                     <div class="right_section col">
                         <div class="chat_head">
                             <img src="<?php echo IMAGES_URL ?>/user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
                                     <span class="align-middle">Charlotte Nelligan</span>
                         </div>
                         <!-- chat section -->
                         <ul class="mCustomScrollbar list-unstyled chat_sec" data-mcs-theme="minimal-dark">
                            <!-- xxxx -->
                             <li class="left">
                                <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                             </li>
                             <!-- xxxx -->
                             <li class="right">
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                                 <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                             </li>
                             <!-- xxxx -->
                             <li class="left">
                                <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                             </li>
                             <!-- xxxx -->
                             <li class="right">
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                                 <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                             </li>
                             <!-- xxxx -->
                             <li class="left">
                                <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                             </li>
                             <!-- xxxx -->
                             <li class="right">
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                                 <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                             </li>
                             <!-- xxxx -->
                             <li class="left">
                                <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                             </li>
                             <!-- xxxx -->
                             <li class="right">
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                                 <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                             </li>
                             <!-- xxxx -->
                             <li class="left">
                                <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                             </li>
                             <!-- xxxx -->
                             <li class="right">
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                                 <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                             </li>
                             <!-- xxxx -->
                             <li class="left">
                                <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                             </li>
                             <!-- xxxx -->
                             <li class="right">
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                                 <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                             </li>
                             <!-- xxxx -->
                             <li class="left">
                                <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue leo eget malesuada aesent sapien massa, convallis a pellentesque nec, egestas orttitor at sem.</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                             </li>
                             <!-- xxxx -->
                             <li class="right">
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                                 <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                             </li>
                             <!-- xxxx -->
                             <li class="left">
                                <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-9.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                             </li>
                             <!-- xxxx -->
                             <li class="right">
                                 <div class="chat_box">
                                     <p>Pnec rutrum congue</p>
                                     <span class="time">05.00 pm</span>
                                 </div>
                                 <div class="img_wrap">
                                    <img src="<?php echo IMAGES_URL ?>/user-10.jpg" class="img-fluid rounded-circle" alt="user-img">
                                </div>
                             </li>
                         </ul>
                     </div>
                 </div>


                </div>
            </div>
        </div>
    </main>

    <?php include 'include/footer.php' ?>
  <script type="text/javascript">
    $(document).ready(function(){
      $("#leftSection ul li a").click(function(){
       $("#leftSection ul li a").removeClass("active");
       $(this).addClass("active");
      });
    });
</script>
</body>

</html>