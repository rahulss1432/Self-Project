<!DOCTYPE html>
<html lang="en">
<head>
    @include('admin::layouts.include.head-link')
    <title>{{ $pageTitle }}</title>
</head>
<body>
    @include('admin::layouts.include.header')
    @yield('content') 
    @include('admin::layouts.include.footer')

    <script>
    function showButtonLoader(id,text,action){
        // console.log(id);
        if(action === 'disable'){
            $('#'+id).html('<span class="d-n" style="opacity:0.1;">'+text+'</span><span class="btn_loader btn_ring" style="display: inline-block;"></span>');
            $('#'+id).prop('disabled',true);
        }else{
            $('#'+id).html('<span class="d-n" style="opacity:1;">'+text+'</span><span class="btn_loader btn_ring" style="display: none;"></span>');
            //$('#'+id).html(text);
            $('#'+id).prop('disabled',false);
        }
    }
    
    function pageLoader(id, action) {
        if (action === 'show') {
            $('#' + id).html('<div class="ajax_list_load bg-white"><span class="ajax_loader btn_ring"></span></div>');
        } else {
//            $('#' + id).html('');
        }
    }

    // toaster common function
    function message(action ,msg){
        if(action == 'success'){
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.success(msg, {timeOut: 1500});
        } else {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.error(msg, {timeOut: 1500});
        }
    }
    </script>
</body>
</html>