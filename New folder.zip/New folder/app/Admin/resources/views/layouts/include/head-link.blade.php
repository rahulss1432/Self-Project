<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<!-- favicon -->
<link rel="apple-touch-icon" sizes="180x180" href="{{ url('public/administrator/images/favicon/apple-touch-icon.png') }}">
<link rel="icon" type="image/png" sizes="32x32" href="{{ url('public/administrator/images/favicon/favicon-32x32.png') }}">
<link rel="icon" type="image/png" sizes="16x16" href="{{ url('public/administrator/images/favicon/favicon-16x16.png') }}">
<link rel="manifest" href="{{ url('public/administrator/images/favicon/site.webmanifest') }}">
<link rel="mask-icon" href="{{ url('public/administrator/images/favicon//safari-pinned-tab.svg') }}" color="#5bbad5">
<meta name="msapplication-TileColor" content="#bee626">
<meta name="theme-color" content="#BEE626">
<meta name="mobile-web-app-capable" content="yes">

<!-- CSS -->
<link rel="stylesheet" href="{{ url('public/administrator/css/bootstrap.min.css') }}" type="text/css">
<link rel="stylesheet" href="{{ url('public/administrator/css/bootstrap-select.min.css') }}" type="text/css">
<link rel="stylesheet" href="{{ url('public/administrator/css/jquery.mCustomScrollbar.min.css') }}"> 
<link rel="stylesheet" href="{{ url('public/administrator/css/tempusdominus-bootstrap-4.min.css') }}" />
<link rel="stylesheet" href="{{ url('public/administrator/css/fontawesome-all.css') }}" type="text/css">
<link rel="stylesheet" href="{{ url('public/administrator/css/flaticon.css') }}" type="text/css">
<link rel="stylesheet" href="{{ url('public/administrator/css/iconmoon.css') }}" type="text/css">
<link rel="stylesheet" href="{{ url('public/administrator/css/toastr.css') }}" type="text/css">
<link rel="stylesheet" href="{{ url('public/administrator/css/bootstrap-tagsinput.css') }}" type="text/css">
<link rel="stylesheet" href="{{ url('public/administrator/css/admin.min.css') }}" type="text/css">
<link rel="stylesheet" href="{{ url('public/administrator/css/cropper.css')}}" type="text/css">

<!-- SCRIPT -->

<script src="{{ url('public/administrator/js/jquery.min.js') }}"></script>
<script src="{{ url('public/administrator/js/popper.min.js') }}"></script>
<script src="{{ url('public/administrator/js/bootstrap.min.js') }}"></script>
<script src="{{ url('public/administrator/js/bootstrap-select.min.js') }}"></script>
<script src="{{ url('public/administrator/js/moment.js') }}"></script>
<script src="{{ url('public/administrator/js/tempusdominus-bootstrap-4.min.js') }}"></script>
<script src="{{ url('public/administrator/js/jquery.mCustomScrollbar.concat.min.js') }}"></script>
<script src="{{ url('public/js/jquery.fileuploadmulti.min.js') }}"></script>
<script src="{{ url('public/administrator/js/jsvalidation.js') }}"></script>
<script src="{{ url('public/administrator/js/toastr.min.js') }}"></script>
<script src="{{ url('public/administrator/js/bootbox.js') }}"></script>
<script src="{{ url('public/administrator/js/bootstrap-tagsinput.js') }}"></script>
<script src="{{ url('public/administrator/js/ajaxupload.3.5.js') }}"></script>
<script src="{{ url('public/administrator/js/cropper.min.js') }}"></script>
<script src="{{ url('public/administrator/js/tinymce/tinymce.min.js') }}"></script>