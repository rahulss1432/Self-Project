<aside class="side_menu mCustomScrollbar green-scroll" data-mcs-theme="my-theme">
    <ul class="list-unstyled">
        <li class="{{ $activePage == 'dashboard' ? 'active' : '' }}"><a class="ripple-effect" href="{{ url('admin/dashboard') }}"> <i class="icon-dashboard"></i>   Dashboard</a></li>
        <?php
        if (\Illuminate\Support\Facades\Auth::guard('admin')->check()) {
        $sidebar_menus = getAllMenus();

        foreach ($sidebar_menus as $s_menu) {
        ?>
        <li class="{{ $activePage == $s_menu['value'] ? 'active' : '' }}"><a class="ripple-effect" href="{{ url('admin/'.$s_menu['value']) }}"> <i class="{{$s_menu['icon']}}"></i> {{$s_menu['name']}}</a></li>
        <?php } ?>

        <li class="{{ $activePage == 'manage-admin' ? 'active' : '' }}"><a class="ripple-effect" href="{{ url('admin/manage-admin') }}"> <i class="icon-user-silhouette1"></i>  Manage Admins</a></li>
        <?php
        } else {
        $userRoles = \App\Models\UserSidebarMenu::getUserSidebarMenu();
        foreach ($userRoles as $s_menu) {
        ?>
        <li class="{{ $activePage == $s_menu['menu']['value'] ? 'active' : '' }}"><a class="ripple-effect" href="{{ url('admin/'.$s_menu['menu']['value']) }}"> <i class="{{$s_menu['menu']['icon']}}"></i> {{$s_menu['menu']['name']}}</a></li>
        <?php } } ?>
    </ul>
</aside> 