<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Notifications</title>

    <?php include 'include/links.php' ?>
</head>
<?php
    $current = 'notifications';
    $currentPageName = 'notifications';
    ?>

<body class="bg-light-gray" onload="hide_preloader();">
    <div id="preloader">
        <div class="inner">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
    </div>

    <?php include 'include/side-menu.php' ?>
    <?php include 'include/header.php' ?>
    <main class="main-content" id="mainContent">
        <div class="page-content">
            <div class="card custom_card">
                <div class="card-header">
                    <h4 class="page-title float-left">Notification List</h4>
                </div>
                <div class="card-body">
                    <div class="notification-box">
                        <span class="custom-control-description">
                            <p>Editorial Collections</p>
                            <span>Contrary to popular belief, lorem ipsum is not simply random text. it has roots in.</span>
                        </span>
                    </div>
                    <div class="notification-box">
                        <span class="custom-control-description">
                            <p>Editorial Collections</p>
                            <span>Contrary to popular belief, lorem ipsum is not simply random text. it has roots in.</span>
                        </span>
                    </div>
                    <div class="notification-box ">
                        <span class="custom-control-description">
                            <p>Editorial Collections</p>
                            <span>Contrary to popular belief, lorem ipsum is not simply random text. it has roots in.</span>
                        </span>
                    </div>
                    <!-- xxxxx -->
                    <div class="notification-box ">
                        <span class="custom-control-description">
                            <p>Editorial Collections</p>
                            <span>Contrary to popular belief, lorem ipsum is not simply random text. it has roots in.</span>
                        </span>
                    </div>
                    <!-- xxxxx -->
                    <div class="notification-box ">
                        <span class="custom-control-description">
                            <p>Editorial Collections</p>
                            <span>Contrary to popular belief, lorem ipsum is not simply random text. it has roots in.</span>
                        </span>
                    </div>
                    <!-- xxxxx -->
                    <div class="notification-box">
                        <span class="custom-control-description">
                            <p>Editorial Collections</p>
                            <span>Contrary to popular belief, lorem ipsum is not simply random text. it has roots in.</span>
                        </span>
                    </div>
                     <!-- xxxxx -->
                    <div class="notification-box">
                        <span class="custom-control-description">
                            <p>Editorial Collections</p>
                            <span>Contrary to popular belief, lorem ipsum is not simply random text. it has roots in.</span>
                        </span>
                    </div>
                     <!-- xxxxx -->
                    <div class="notification-box">
                        <span class="custom-control-description">
                            <p>Editorial Collections</p>
                            <span>Contrary to popular belief, lorem ipsum is not simply random text. it has roots in.</span>
                        </span>
                    </div>
                     <!-- xxxxx -->
                    <div class="notification-box">
                        <span class="custom-control-description">
                            <p>Editorial Collections</p>
                            <span>Contrary to popular belief, lorem ipsum is not simply random text. it has roots in.</span>
                        </span>
                    </div>
                    <!-- xxxxx -->
                </div>
            </div>
        </div>
    </main>
    <?php include 'include/footer.php' ?>

</body>

</html>