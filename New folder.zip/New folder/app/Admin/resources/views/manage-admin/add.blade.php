@php $pageTitle = 'Manage Admin Add | FAF'; @endphp
@php $activePage = 'manage-admin'; @endphp

@extends('admin::layouts.app')

@section('content')

@include('admin::layouts.include.header')
@include('admin::layouts.include.side-menu')

<div class="main-content adduser_page">
    <div class="content_wrapper">
        <div class="content_header">
            <div class="page_title">
                <h2 class="d-inline-block pr-3 mr-3 border-right">Manage Admin</h2>
                <nav aria-label="breadcrumb" class="d-inline-block">
                    <ol class="breadcrumb p-0 mb-0">
                        <li class="breadcrumb-item"><a href="{{ url('admin/manage-admin') }}">Manage Admin</a></li>
                        <li class="breadcrumb-item">Admin Add</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="content">
            <div class="add_details mx-auto add_form">
                <div class="card">
                    <div class="card-header">Add Admin</div>
                    <div class="card-body">
                        <form action="{{ url('admin/manage-admin/save') }}" id="add-admins" method="post" autocomplete="off">	
                            {{ csrf_field() }}
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Admin Name</label>
                                        <input type="text" name="full_name" class="form-control">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Email Id</label>
                                        <input name="email" type="email" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Country</label>
                                        <select name="country_id" id="country" onchange="$(this).valid();" class="selectpicker select-custom form-control" data-size="3" title="Select Country">

                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>State</label>
                                        <select name="state_id" id="state" onchange="$(this).valid();" class="selectpicker select-custom form-control" data-size="3" title="Select State">

                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>City</label>
                                        <input name="city" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Address</label>
                                        <input name="address_line_1" type="text" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Zip Code</label>
                                        <input name="zip_code" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group mobile_no">
                                        <label>Mobile Number</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <select name="country_code" id="country_cod" class="selectpicker select-custom form-control" data-size="3">
                                                    <option value=''>+1</option>
                                                </select>
                                            </div>
                                            <input type="text" name="phone_number" class="form-control" aria-label="Text input with dropdown button">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="row">
                                    <div class="col-sm-12">
                                            <ul class="list-inline users_options">
                                                    <li class="list-inline-item">
                        <div class="radio">
                                                                    <input id="radio-1" name="radio" type="radio" >
                                                                    <label for="radio-1"><span class="radio-label"></span> Full access</label>
                                                            </div>
                                                    </li>
                                                    <li class="list-inline-item">
                                                            <div class="radio">
                                                                    <input id="radio-2" name="radio" type="radio" checked="">
                                                                    <label for="radio-2"><span class="radio-label"></span> Read only</label>
                                                            </div>
                                                    </li>
                                            </ul>
                                    </div>
                            </div> -->
                            <div class="form-group action text-right mb-0">
                                <a href="{{ url('admin/manage-admin') }}" id="add-cancel" class="btn btn-light mr-sm-2 rounded-0 ripple-effect">
                                    Cancel
                                </a>
                                <button type="button" class="btn btn-dark rounded-0 ripple-effect" id="addButton" onclick="addAdminData('add-admins')" onclick="getSavebtn()">Save		
                                </button>
                            </div>
                        </form>
                        {!! JsValidator::formRequest('App\Admin\Http\Requests\AddAdminRequest','#add-admins') !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function getSavebtn() {
        $(".btn_loader").css('display', 'inline-block');
        setTimeout(function () {
            $(".btn_loader").hide();
        }, 1000);
    }


    // get all country
    $(document).ready(function () {
        $.post("{{ url('get-all-country') }}", {_token: "{{ csrf_token() }}", type: ""}, function (data) {
            $('#country').html(data);
            $('#country').selectpicker('refresh');
        });
    });

    // get state by country id
    $(document).on('change', '#country', function () {
        $.post("{{ url('get-state-by-country-id') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: ""}, function (data) {
            $('#state').html(data);
            $('#state').selectpicker('refresh');
        });
    });
    $(document).on('change', '#country', function () {
        $.post("{{ url('get-country-code-byid') }}", {_token: "{{ csrf_token() }}", country_id: $(this).val()}, function (data) {
            $('#country_cod').html(data);
            $('#country_cod').selectpicker('refresh');
        });
    });

    // function for save admins.
    function addAdminData(form_id) {
        if ($("#" + form_id).valid()) {
            showButtonLoader('addButton', 'Save', 'disable');
            document.getElementById('add-cancel').style.pointerEvents = 'none';
            var formData = new FormData($("#" + form_id)[0]);
            $.ajax({
                url: $("#" + form_id).attr('action'),
                data: formData,
                processData: false,
                contentType: false,
                type: 'POST',
                dataType: 'JSON',
                success: function (data) {
                    if (data.success) {
                        message('success', data.message);
                        setTimeout(function () {
                            window.location.href = "{{ url('admin/manage-admin') }}"
                        }, 1000);
                    } else {
                        message('error', data.message);
                    }
                },
                error: function (err) {
                    message('error', err);
                },
                complete: function () {
                    showButtonLoader('addButton', 'Save', 'enable');
                    document.getElementById('add-cancel').style.pointerEvents = 'auto';
                }
            });
        }
    }
</script>

@endsection