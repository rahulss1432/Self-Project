@extends('admin::include.app')
@section('title', 'Manage User')
@section('content')
<main class="main-content" id="mainContent">
    <div class="page-content">
        <div class="card custom_card">
            <div class="card-header">
                <h4 class="page-title float-left">Notification List</h4>
            </div>
            <div class="card-body" id="getNotificationList">

            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function () {
        notificationList();
        readNotification();
    });

    function notificationList()
    {
        pageDivLoader('show', 'getNotificationList');
        $.ajax({
            type: "GET",
            url: "{{url('admin/notification-list')}}",
            success: function (response)
            {
                if (response.success) {
                    $("#getNotificationList").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection