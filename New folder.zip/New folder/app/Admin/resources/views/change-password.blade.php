@extends('admin::include.app')
@section('title', 'Change Password')
@section('content')
<main class="main-content id="mainContent">
      <div class="page-content">
        <div class="card custom_card" id="card_height">
            <div class="card-header">
                <h4 class="page-title float-left">Change Password</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/dashboard')}}" class="nav-link" title="Back"><i class="ti-arrow-left"></i></a> 
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <form action="{{ url('admin/update-password') }}" id="changePassword" method="post" autocomplete="off">	
                    {{ csrf_field() }}
                    <input type="hidden" value="{{$id}}" name="id">
                    <div class="row">
                        <div class="col-sm-6 col-xs-12">
                            <div class="form-group">
                                <input type="password" name="current_password" id="cp" class="form-control form-control-lg"/>
                                <label class="control-label" for="cp">Current Password</label>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                            <div class="form-group">
                                <input type="password" name="new_password" id="new_password" class="form-control form-control-lg"/>
                                <label class="control-label" >New Password</label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-xs-12">
                            <div class="form-group">
                                <input type="password" name="confirm_password" id="confirm_password" class="form-control form-control-lg"/>
                                <label class="control-label" >Confirm password</label>
                            </div>
                        </div>
                    </div>
                    <div class="from-group">
                        <button type="submit" id="updateButton" onclick="updatePassword('changePassword')" class="btn btn-sm btn-primary ripple-effect"> 
                            Update <i id="changePasswordLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none;"></i>
                        </button>
                    </div>
                </form>   
                {!! JsValidator::formRequest('App\Admin\Http\Requests\ChangePasswordRequest','#changePassword') !!}
            </div>
        </div>
    </div>
</main>
<script>
    // function for save admins.
    function updatePassword(form_id) {
        if ($("#" + form_id).valid()) {
            $('#updateButton').prop('disabled', true);
            $('#changePasswordLoader').show();
            var formData = new FormData($("#" + form_id)[0]);
            $.ajax({
                url: $("#" + form_id).attr('action'),
                data: formData,
                processData: false,
                contentType: false,
                type: 'POST',
                dataType: 'JSON',
                success: function (data) {
                    if (data.success) {
                        toastrAlertMessage('success', data.message);
                        setTimeout(function () {
                            window.location.href = "{{ url('admin/dashboard') }}"
                        }, 1000);
                        $('#changePasswordLoader').hide();
                        $('#updateButton').prop('disabled', false);
                    } else {
                        toastrAlertMessage('error', data.message);
                    }
                },
                error: function (err) {
                    toastrAlertMessage('error', err);
                },
                complete: function () {
                    $('#changePasswordLoader').hide();
                    $('#updateButton').prop('disabled', false);
                }
            });
        }
    }
</script>
@endsection