<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Manage Flagged</title>
    <?php include 'include/links.php' ?>
</head>
<?php
    $current = 'manage-flagged';
    $currentPageName = 'Manage Flagged';
    ?>

<body class="bg-light-gray" onload="hide_preloader();">
    <div id="preloader">
        <div class="inner">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
    </div>
    <?php include 'include/side-menu.php' ?>
    <?php include 'include/header.php' ?>
    <main class="main-content" id="mainContent">
        <div class="page-content pt-1">
            <!-- tab -->
            <ul class="nav nav-tabs admin-tabs border-0" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="flagged-activity-tab" onclick="showFlaggedActi();" data-toggle="tab" href="#flagged-activity" role="tab" aria-controls="home" aria-selected="true">Flagged Activity</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="flagged-terms-tab" onclick="showFlaggedTerms();" data-toggle="tab" href="#flagged-terms" role="tab" aria-controls="profile" aria-selected="false">Flagged Terms</a>
                </li>
            </ul>
            <!-- tab content -->
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="flagged-activity" role="tabpanel" aria-labelledby="flagged-activity-tab">
                    <div class="card custom_card" id="card_height">
                        <div class="card-header">
                            <h4 class="page-title float-left">Flagged Activity List</h4>
                            <ul class="list-inline mb-0 text-right">
                                <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                                    <a href="#searchFilter" data-toggle="collapse"  class="nav-link"><i class="ti-filter"></i></a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <div class="filter_section collapse" id="searchFilter">
                                <form>
                                    <div class="row">
                                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <div class="dateicon">
                                                    <input type="text" readonly id="SelectDate01" class="form-control form-control-lg datetimepicker-input" data-target="#SelectDate01" data-toggle="datetimepicker" placeholder="">
                                                    <label class="control-label">From</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <div class="dateicon">
                                                    <input type="text" readonly id="SelectDate" class="form-control form-control-lg datetimepicker-input" data-target="#SelectDate" data-toggle="datetimepicker" placeholder="">
                                                    <label class="control-label">To</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-4 col-sm-6">
                                            <div class="form-group d-inline-block mr-2">
                                                <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                            </div>
                                            <div class="form-group d-inline-block">
                                                <button class="btn btn-dark ripple-effect" type="submit">Reset</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="table-responsive" id="getFlaggedList">
                            </div>
                            <nav aria-label="Page navigation" class="paginationDiv clearfix" id="listPagination" style="display:none;">
                                <div class="nofpages float-left">
                                    1 of 6 pages
                                </div>
                                <ul class="pagination float-right mb-0">
                                    <li class="page-item">
                                        <a class="page-link" href="#" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>                                     
                                    </a>
                                    </li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#">4</a></li>
                                    <li class="page-item"><a class="page-link" href="#">5</a></li>
                                    <li class="page-item"><a class="page-link" href="#">6</a></li>
                                    <li class="page-item">
                                        <a class="page-link" href="#" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <!-- flagged terms tab start -->
                <div class="tab-pane fade" id="flagged-terms" role="tabpanel" aria-labelledby="flagged-terms-tab">
                    <div class="card custom_card" id="card_height">
                        <div class="card-header">
                            <h4 class="page-title float-left">Flagged Terms List</h4>
                            <ul class="list-inline mb-0 text-right">
                                <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Add Flagged Terms">
                                    <a href="javascript:void(0);" onclick="addFlagged();" class="nav-link"><i class="ti-plus"></i></a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive" id="getFlaggedTermsList">
                            </div>
                            <nav aria-label="Page navigation" class="paginationDiv clearfix" id="listPagination01" style="display:none;">
                                <div class="nofpages float-left">
                                    1 of 6 pages
                                </div>
                                <ul class="pagination float-right mb-0">
                                    <li class="page-item">
                                        <a class="page-link" href="#" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>                                     
                                    </a>
                                    </li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#">4</a></li>
                                    <li class="page-item"><a class="page-link" href="#">5</a></li>
                                    <li class="page-item"><a class="page-link" href="#">6</a></li>
                                    <li class="page-item">
                                        <a class="page-link" href="#" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <!-- tab end -->
            </div>
    </main>
    <!-- add flagged terms modal -->
    <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" data-backdrop="static" data-keyword="false" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Flagged Terms</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="ti-close"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form name="" class="f-field">
                        <div class="form-group">
                            <input type="text" class="form-control form-control-lg" required />
                            <label class="control-label">Flagged Terms Name</label>
                        </div>
                        <div class="form-group">
                            <select class="form-control form-control-lg selectpicker">
                             <option value="active">Active</option>
                             <option value="inactive">Inactive</option>
                            </select>
                          <label class="control-label">Status</label>
                        </div>
                        <div class="form-group mb-0 text-right">
                            <button type="button" class="btn btn-sm btn-primary ripple-effect">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php include 'include/footer.php' ?>
    <script>
    function addFlagged() {
        $("#addModal").modal('show');
    }

    function getFlaggedlist() {
        $("#getFlaggedList").html('<div class="listloader text-center pb-4"><i class="fa-2x fa-spin fa fa-spinner"></i></div>');
        var url = '<?php echo BASE_URL ?>/admin/ajax-content/_flagged-activity.php';
        $.ajax({
            type: "POST",
            url: url,
            data: {},
            success: function(response) {
                setTimeout(function() {
                    $("#getFlaggedList").html("");
                    $("#getFlaggedList").hide().html(response).fadeIn('2000');
                }, 2000);
            }
        });
    }

    function getFlaggedTermslist() {
        $("#getFlaggedTermsList").html('<div class="listloader text-center pb-4"><i class="fa-2x fa-spin fa fa-spinner"></i></div>');
        var url = '<?php echo BASE_URL ?>/admin/ajax-content/_flagged-terms.php';
        $.ajax({
            type: "POST",
            url: url,
            data: {},
            success: function(response) {
                setTimeout(function() {
                    $("#getFlaggedTermsList").html("");
                    $("#getFlaggedTermsList").hide().html(response).fadeIn('2000');
                }, 2000);
            }
        });
    }

    $(document).ready(function() {
        getFlaggedlist();
        setTimeout(function() {
            $("#listPagination").fadeIn();
        }, 2000);
    });

    function showFlaggedActi() {
        getFlaggedlist();
        $("#listPagination").hide();
        setTimeout(function() {
            $("#listPagination").fadeIn('2000');
        }, 2000);
    }

    function showFlaggedTerms() {
        getFlaggedTermslist();
        $("#listPagination01").hide();
        setTimeout(function() {
            $("#listPagination01").fadeIn('2000');
        }, 2000);
    }
    </script>
</body>

</html>