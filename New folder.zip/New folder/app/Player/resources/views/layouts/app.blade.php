<!doctype html>
<html lang="en">
    <head>
        @include('player::layouts.include.head-link')
        <title>FAF Player</title>
    </head>
    <body onload="hide_preloader();">
        <div id="fb-root"></div>
        <script>
            setTimeout(function () {
                (function (d, s, id) {
                    var js, fjs = d.getElementsByTagName(s)[0];
                    if (d.getElementById(id))
                        return;
                    js = d.createElement(s);
                    js.id = id;
                    js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.2&appId=1682048595372116&autoLogAppEvents=1';
                    fjs.parentNode.insertBefore(js, fjs);
                }(document, 'script', 'facebook-jssdk'));
            }, 3000);
        </script>
        <div id="wrapper-div" class="wrapper">
            @include('player::layouts.include.header-player')
            @yield('content') 
            @include('player::layouts.include.footer')
        </div>
    </body>
</html>
<script>
    function showButtonLoader(id, text, action) {
        // console.log(id);
        if (action === 'disable') {
            $('#' + id).html('<span class="d-n" style="opacity:0.1;">' + text + '</span><span class="btn_loader btn_ring" style="display: inline-block;"></span>');
            $('#' + id).prop('disabled', true);
        } else {
            $('#' + id).html('<span class="d-n" style="opacity:1;">' + text + '</span><span class="btn_loader btn_ring" style="display: none;"></span>');
            //$('#'+id).html(text);
            $('#' + id).prop('disabled', false);
        }
    }

    function pageLoader(id, action) {
        if (action === 'show') {
            $('#' + id).html('<span class="ajax_loader btn_ring"></span>');
        } else {
            $('#' + id).html('');
        }
    }

    // toaster common function
    function message(action, msg) {
        if (action == 'success') {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.success(msg, {timeOut: 1500});
        } else {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.error(msg, {timeOut: 1500});
        }
    }


</script>