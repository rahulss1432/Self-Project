@extends('player::layouts.app')
@section('content')

<main class="main-content">
    <div class="mainframe_border">
        <div class="borderheight" id="borderheight"></div>
    </div>
    <div class="container-fluid">
        <div class="common_heading">
            <h3 class="black black-lg">
                MY CONNECTIONS
            </h3>
        </div>
    </div>
    <aside class="left_section " id="left-side-html">
        <!--  Left side html render -->
    </aside>
    <section class="middle_section">
        <div class="container-fluid">
            <div class="ajax_list_load">
                <div class="green-scroll" id="membersList" style="height: 2500px;"></div>
            </div>
        </div>
    </section>
    <aside class="right_section" id="right-side-html">
        <!--- Right side html render -->
    </aside>            
</main>
<!-- left & right side url routing-->
<input type="hidden" data-url="{{url('player/left-sidebar')}}" id="player_left_side">
<input type="hidden" data-url="{{url('player/right-sidebar')}}" id="player_right_side">
<script>

    var currentPageUrl = '{{ Request::segment(2) }}';
    var csrfToken = "{{csrf_token()}}";
    var memberConnectDismissUrl = "{{ url('player/connect-dismiss-member') }}";

    /* Get connection list */
    function getConnectionList() {
        console.log('ok');
        pageLoader('membersList', 'show');
        var url = "{{ url('player/get-all-connections') }}";
        var formData = $('#playerMemberForm').serialize();
        $('#applyBtn').prop('disabled', true);
        console.log(formData);
        $.ajax({type: "POST",
            url: url,
            //data:{id:'{{$id}}'}, 
            data: formData,
            success: function (response) {
                if (response.success) {
                    setTimeout(function () {
                        pageLoader('membersList', 'hide');
                        $('#applyBtn').prop('disabled', false);
                        $("#membersList").html("");
                        $("#membersList").html(response.html);
                        $('#left-side-html').removeClass('open');
                        $('body').removeClass("aside-open-left");
                    }, 1000);
                } else {
                    message('error', response.message);
                }
            }, error: function (err) {
                message('error', err);
            }, complete: function () {
                // setHeightMiddleSection();
            }
        });
    }



    $(document).ready(function () {
        getLeftSidebar("connection_list", '{{$id}}');
        getRightSidebar("connection_list", '{{$id}}');
        setTimeout(function () {
            getConnectionList();
        }, 4000);
    });

    /* Clear search form */
    function clearForm() {
        $('#member_type').val('');
        $('#member_type').selectpicker('refresh');
        $('#playerMemberForm').trigger("reset");
        getConnectionList();
    }

</script>
<script src="{{url('public/js/player/player-left-right-sidebar.js')}}"></script>
<script src="{{url('public/js/player/player-connect-dissmiss.js')}}"></script>
@endsection