@extends('player::layouts.app')

@section('content')

<link rel="stylesheet" href="{{ url('public/css/tempusdominus-bootstrap-4.min.css') }}" />

@php
$countryId = Auth::guard('player')->user()->country_id;
$stateId = Auth::guard('player')->user()->state_id;
@endphp

<main class="main-content">
    <div class="container container-1600">
        <h1 class="inner-heading text-uppercase main-head pt-xl-2">Profile Completion</h1>
        <div class="step-form-wrap">
            <div class="d-sm-flex justify-content-sm-start">
                <div class="step step01 active" id="step01">
                    <div class="inner-step text-center">
                        <h2>1</h2>
                        <p>Personal
                            <br> Info</p>
                    </div>
                </div>
                <div class="step step02" id="step02">
                    <div class="inner-step text-center">
                        <h2>2</h2>
                        <p>Contact
                            <br> Info</p>
                    </div>
                </div>
                <div class="step step03" id="step03">
                    <div class="inner-step text-center">
                        <h2>3</h2>
                        <p>About</p>
                    </div>
                </div>
                <div class="step step04" id="step04">
                    <div class="inner-step text-center">
                        <h2>4</h2>
                        <p>Key Stats</p>
                    </div>
                </div>
                <div class="step step05" id="step05">
                    <div class="inner-step text-center">
                        <h2>5</h2>
                        <p>Media</p>
                    </div>
                </div>
                <div class="step step06" id="step06">
                    <div class="inner-step text-center">
                        <h2>6</h2>
                        <p>Measurables</p>
                    </div>
                </div>
                <div class="step step07" id="step07">
                    <div class="inner-step text-center">
                        <h2>7</h2>
                        <p>Desired
                            <br> Benefits</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- xxxxxxx  step 1-->
    <div class="step-form01" id="Form01">
        <div class="container">
            <form autocomplete="off" id="player-step-one" class="custom_form" method="post" action="{{ url('player/player-step-one') }}">
                {{ csrf_field() }}
                <div class="row common-row">
                    <div class="col-12 text-center">
                        <div class="add-profile rounded-circle">
                            <div class="img-holder rounded-circle">
                                @php $img = getUserDataByColumn('profile_image'); @endphp
                                <input type="hidden" id="profile_picture" name="profile_picture" value="{{ $img }}">
                                <img id="profile_image" src="{{ checkUserImage($img, 'player/thumb') }}" alt="default-user" class="img-fluid">
                            </div>
                            <label class="upload-btn rounded-circle mb-0" onclick="$('#profile_image_input').trigger('click')">
                                <i class="fas fa-plus"></i>
                            </label>
                            <label class="control-label mt-3 m-0">Add Profile Picture</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="file" name="profile_image" id="profile_image_input" class="profile_error" style="opacity: 0;position: absolute;padding: 0;width: initial;height: initial;margin: 0;left: 0;display::none;">
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">First Name</label>
                            <div class="input-field">
                                <input type="text" name="first_name" value="{{ getUserDataByColumn('first_name') }}" placeholder="First Name">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Last Name</label>
                            <div class="input-field">
                                <input type="text" name="last_name" value="{{ getUserDataByColumn('last_name') }}" placeholder="Last Name">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Select Age</label>
                            <select name="age" id="age" onchange="$(this).valid()" class="selectpicker form-control select-custom" title="Select " data-size="4">

                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Select Country</label>
                            <select id="country" name="country" onchange="$(this).valid()" class="selectpicker form-control select-custom" title="Select " data-size="4"></select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Select State</label>
                            <select id="state" name="state" onchange="$(this).valid()" class="selectpicker form-control select-custom" title="Select " data-size="4"></select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">City</label>
                            <div class="input-field">
                                <input type="text" name="city" value="{{ getUserDataByColumn('city') }}" placeholder="City">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Zip Code</label>
                            <div class="input-field">
                                <input type="text" name="zip" value="{{ getUserDataByColumn('zip_code') }}" placeholder="Zip Code">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Select Position</label>
                            <select name="position[]" id="position" multiple data-max-options="2" onchange="$(this).valid()" class="selectpicker form-control select-custom" title="Select" data-size="4">
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Signature</label>
                            <div class="input-field">
                                <input type="text" name="signature" value="{{ getUserDataByColumn('signature') }}" placeholder="Signature">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group upload">
                            <label class="control-label">Upload Resume</label>
                            <div class="input-field">
                                <div class="file-upload forupload">
                                    <div class="file-select ">
                                        <!-- <div class="file-select-button" id="fileName">Choose File</div> -->
                                        <div class="file-select-name nofile_name" id="noFile">{{(getUserDataByColumn('resume'))?getUserDataByColumn('resume'):'No file chosen...'}}</div> 
                                        <input type="file" class="upload_file" name="resume" id="uploadVideo">
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label class="control-label">Bio</label>
                            <div class="input-field">
                                <textarea rows="3" name="bio" placeholder="Type more about you">{{ getUserDataByColumn('bio') }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 pl-0">
                        <div class="btn-row w-100 text-right">
                            <button type="button" class="btn btn-success btn-lg border-2 font-22" onclick="firstStepForm('player-step-one', 'next')" id="nextStep01">NEXT</button>
                            <a href="javascript:void(0);" class="btn btn-success btn-lg border-2 font-22" onclick="firstStepForm('player-step-one', 'exit')" id="nextStep011">SAVE & EXIT</a>
                        </div>
                    </div>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Player\Http\Requests\PlayerStepOneRequest','#player-step-one') !!}
        </div>
    </div>
    <!-- xxxxxxx step 2 -->
    <div class="step-form02" id="Form02" style="display: none;">
        <div class="container">
            <form autocomplete="off" id="player-step-two" class="custom_form" method="post" action="{{ url('player/player-step-two') }}">
                {{ csrf_field() }}
                <div class="row common-row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Skype ID</label>
                            <div class="input-field">
                                <input type="text" name="skype" value="{{ getUserDataByColumn('skype') }}" placeholder="Skype ID">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Website</label>
                            <div class="input-field">
                                <input type="text" name="website" value="{{ getUserDataByColumn('website') }}" placeholder="Website">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Facebook</label>
                            <div class="input-field">
                                <input type="text" name="facebook" value="{{ getUserDataByColumn('facebook') }}" placeholder="Facebook">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Twitter</label>
                            <div class="input-field">
                                <input type="text" name="twitter" value="{{ getUserDataByColumn('twitter') }}" placeholder="Twitter">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Instagram</label>
                            <div class="input-field">
                                <input type="text" name="instagram" value="{{ getUserDataByColumn('instagram') }}" placeholder="Instagram">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Linkedin</label>
                            <div class="input-field">
                                <input type="text" name="linkedin" value="{{ getUserDataByColumn('linkedin') }}" placeholder="Linkedin">
                            </div>
                        </div>
                    </div>
                    <div class="col-12 pl-0">
                        <div class="btn-row w-100 text-right">
                            <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2 font-22" id="preStep01">PREVIOUS</a>
                            <button type="button" class="btn btn-success btn-lg border-2 font-22" onclick="secondStepForm('player-step-two', 'next')" id="nextStep02">NEXT</button>
                            <a href="javascript:void(0);" class="btn btn-success btn-lg border-2 font-22" onclick="secondStepForm('player-step-two', 'exit')" id="nextStep02">SAVE & EXIT</a>

                        </div>
                    </div>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Player\Http\Requests\PlayerStepTwoRequest','#player-step-two') !!}
        </div>
    </div>
    <!-- xxxxxxx  step 3-->
    <div class="step-form03" id="Form03" style="display: none;">
        <div class="container">
            <div  class="custom_form">

                <div class="accordion" id="accordionStep3">
                    <div class="card">
                        <div class="card-header" id="headingOne">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" onclick="get_language_country('collapseOne');">
                                    general
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseOne" class="collapse" data-parent="#accordionStep3">
                            <form autocomplete="off" id="player-step-three" method="post" action="{{ url('player/player-step-three-general') }}">
                                {{ csrf_field() }}
                                <div class="card-body panel-body">
                                    <div class="container">
                                        <div class="row common-row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Years of Playing Experience</label>
                                                    <select id="playing_exp" class="selectpicker form-control select-custom" name="playing_exp" data-size="4"  title="Select Experience">
                                                        <option value="0-2" {{ getUserGeneral('playing_exp') == '0-2' ? 'selected':''}} > 0-2 </option>
                                                        <option value="2-5"{{ getUserGeneral('playing_exp') == '2-5' ? 'selected':''}}>2-5</option>
                                                        <option value="6-10" {{ getUserGeneral('playing_exp') == '6-10' ? 'selected':''}}>6-10</option>
                                                        <option value="11-15"{{ getUserGeneral('playing_exp') == '11-15' ? 'selected':''}}>11-15</option>
                                                        <option value="16-20"{{ getUserGeneral('playing_exp') == '16-20' ? 'selected':''}}>16-20</option>
                                                        <option value="21-25"{{ getUserGeneral('playing_exp') == '21-25' ? 'selected':''}}>21-25</option>
                                                        <option value="26-30"{{ getUserGeneral('playing_exp') == '26-30' ? 'selected':''}}>26-30</option>
                                                        <option value="30+"{{ getUserGeneral('playing_exp') == '30+' ? 'selected':''}}>30+</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group ml-2">
                                                    <label class="control-label ml-0">Currently Under Contract</label>
                                                    <ul class="list-inline common_list mb-0">
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="contract01" name="under_contract" value="yes" {{ (getUserGeneral('under_contract') == 'yes') ? 'checked' : '' }}>
                                                                <label for="contract01">
                                                                    <i></i> Yes
                                                                </label>
                                                            </div>
                                                        </li>
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="contract02" name="under_contract" value="no" {{ (getUserGeneral('under_contract') == 'no') ? 'checked' : '' }}>
                                                                <label for="contract02">
                                                                    <i></i> No
                                                                </label>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Current Team</label>
                                                    <div class="input-field">
                                                        <input type="text" name="current_team" placeholder="Current Team" value="{{ getUserGeneral('current_team') }}">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Current Team Link</label>
                                                    <div class="input-field">
                                                        <input type="text" name="current_team_link" placeholder="Team Link" value="{{ getUserGeneral('current_team_link') }}">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Current League or Conference</label>
                                                    <div class="input-field">
                                                        <input type="text" name="current_league" value="{{ getUserGeneral('current_league') }}" placeholder="Current League or Conference">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Current League or Conference Link</label>
                                                    <div class="input-field">
                                                        <input type="text" name="current_league_link" value="{{ getUserGeneral('current_league_link') }}" placeholder="Current League or Conference Link">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Former Team</label>
                                                    <div class="input-field">
                                                        <input type="text" name="former_team" value="{{ getUserGeneral('former_team') }}" placeholder="Former Team">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Former Team Link</label>
                                                    <div class="input-field">
                                                        <input type="text" name="former_team_link" value="{{ getUserGeneral('former_team_link') }}" placeholder="Former Team Link">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Former League or Conference</label>
                                                    <div class="input-field">
                                                        <input type="text" name="former_league" value="{{ getUserGeneral('former_league') }}" placeholder="Former League or Conference">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Former League or Conference Link</label>
                                                    <div class="input-field">
                                                        <input type="text" name="former_league_link" value="{{ getUserGeneral('former_league_link') }}" placeholder="Former League or Conference Link">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group ml-2">
                                                    <label class="control-label ml-0">Passport Ready</label>
                                                    <ul class="list-inline common_list mb-0">
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="passport01" name="passport" value="yes" {{ (getUserGeneral('passport') == 'yes') ? 'checked' : '' }}>
                                                                <label for="passport01">
                                                                    <i></i> Yes
                                                                </label>
                                                            </div>
                                                        </li>
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="passport02" name="passport" value="no" {{ (getUserGeneral('passport') == 'no') ? 'checked' : '' }}>
                                                                <label for="passport02">
                                                                    <i></i> No
                                                                </label>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                             <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Country of Issuance</label>
                                                    <select id="general_country" name="country_id" class="selectpicker form-control select-custom" title="Select Country" data-size="4">
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group ml-2">
                                                    <label class="control-label ml-0">Select Ability to Relocate</label>
                                                    <ul class="list-inline common_list mb-0">
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="relocate01" name="relocate" value="yes" {{ (getUserGeneral('relocate') == 'yes') ? 'checked' : '' }}>
                                                                <label for="relocate01">
                                                                    <i></i> Yes
                                                                </label>
                                                            </div>
                                                        </li>
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="relocate02" name="relocate" value="no" {{ (getUserGeneral('relocate') == 'no') ? 'checked' : '' }}>
                                                                <label for="relocate02">
                                                                    <i></i> No
                                                                </label>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group ml-2">
                                                    <label class="control-label ml-0">Looking to Sign</label>
                                                    <ul class="list-inline common_list mb-0">
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="sign01" name="look_to_sign" value="yes" {{ (getUserGeneral('look_to_sign') == 'yes') ? 'checked' : '' }}>
                                                                <label for="sign01">
                                                                    <i></i> Yes
                                                                </label>
                                                            </div>
                                                        </li>
                                                        <li class="list-inline-item mb-0">
                                                            <div class="border-radio">
                                                                <input type="radio" id="sign02" name="look_to_sign" value="no" {{ (getUserGeneral('look_to_sign') == 'no') ? 'checked' : '' }}>
                                                                <label for="sign02">
                                                                    <i></i> No
                                                                </label>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Native Language</label>
                                                    <select id="native_lang_id" name="native_lang_id" class="selectpicker form-control select-custom" title="Select Language" data-size="4">
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Secondary Language</label>
                                                    <select id="secondary_lang_id" name="secondary_lang_id" class="selectpicker form-control select-custom" title="Select Language" data-size="4">

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            {!! JsValidator::formRequest('App\Player\Http\Requests\PlayerStepThreeRequest','#player-step-three') !!}
                        </div>
                    </div>

                    <!--common route for all below tab -->
                    <!-- for page render -->
                    <input type="hidden" data-addurl="{{ url('player/player-step-three') }}" id="render_html">
                    <!-- for add  -->
                    <input type="hidden" data-url="{{ url('player/player-add-update-experience') }}" id="common_route">
                    <!-- for add  -->
                    <input type="hidden" data-url="{{ url('player/player-edit-delete-experience') }}" id="edit_delete_route">
                    <!--End-->
                    <!-- xxxxxxx college experience -->


                    <div class="card">
                        <div class="card-header" id="headingSix">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" onclick="get_toggle('collapseSix', 'college', '');">
                                    PREP/COLLEGE EXPERIENCE
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseSix" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->



                            <!-- render html end -->

                        </div>
                    </div>


                    <!-- xxxxxxx step 4 -->

                    <div class="card">
                        <div class="card-header" id="headingSeven">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" onclick="get_toggle('collapseSeven', 'pro', '');">
                                    PRO EXPERIENCE
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseSeven" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->


                            <!-- render html  end-->
                        </div>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header" id="headingEight">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" onclick="get_toggle('collapseEight', 'international', '');">
                                    INTERNATIONAL EXPERIENCE
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseEight" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->


                            <!-- render html  end -->
                        </div>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header" id="headingNine">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" onclick="get_toggle('collapseNine', 'indoor', '');">
                                    INDOOR EXPERIENCE
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseNine" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->



                            <!-- render html end -->
                        </div>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header" id="headingTwo">
                            <h5 class="mb-0">
                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false"  onclick="get_toggle('collapseTwo', 'accolades', '');">
                                    ACCOLADES / Awards / Captainships / championship

                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseTwo" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->


                            <!-- render html end -->
                        </div>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header" id="headingThree">
                            <h5 class="mb-0">
                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" onclick="get_toggle('collapseThree', 'education', '');">
                                    Education

                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseThree" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->


                            <!-- render html end -->
                        </div>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" onclick="get_toggle('collapseFour', 'coaching', '');">Coaching experience
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseFour" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->


                            <!-- render html end -->
                        </div>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false"  onclick="get_toggle('collapseFive', 'community', '');">
                                    Community service experience

                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseFive" class="collapse" data-parent="#accordionStep3">
                            <!-- render html -->


                            <!-- render html end -->
                        </div>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="btn-row w-100  text-right">
                        <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2 font-22" id="preStep02">PREVIOUS</a>
                        <button type="button" class="btn btn-success btn-lg border-2 font-22" id="nextStep03" onclick="thirdStepForm('player-step-three', 'next')">NEXT</button>
                        <a href="javascript:void(0);" class="btn btn-success btn-lg border-2 font-22" id="nextStep033" onclick="thirdStepForm('player-step-three', 'exit')" >SAVE & EXIT</a>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- step 4 key stats-->
    <div class="step-form04" id="Form04"  style="display: none;">
        <div class="container">
            <div class="custom_form">

                <div class="accordion" id="accordionStep04">
                    <!-- xxxxxx Current Season Start xxxxxx -->

                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapse01" aria-expanded="false">
                                    Current Season
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapse01" class="collapse" data-parent="#accordionStep04">
                            <form autocomplete="off" id="currentSeasonForm" method="POST" action="{{url('player/save-season')}}">
                                <input type="hidden" name="season_type" value="current">        
                                <input type="hidden" name="season_id" value="{{getUserKeyStatsValueByColumn('id')}}">
                                {{csrf_field()}}
                                <div class="card-body">
                                    <div class="container">
                                        <div class="row common-row">
                                            <div class="col-lg-8 col-xl-6">
                                                <div class="row">
                                                    <div class="col-12 col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">From</label>
                                                            <div class="input-field date_picker z-index">
                                                                <div class="input-group date" id="datetimepicker01" data-target-input="nearest">
                                                                    <input type="text" class="form-control datetimepicker-input currentSeasonStartDate" id="currentFromYear" name="from_year"  data-target="#currentFromYear" data-toggle="datetimepicker" placeholder="Date" readonly="true" />
                                                                    <div class="input-group-append" data-target="#currentFromYear" data-toggle="datetimepicker">
                                                                        <div class="input-group-text">
                                                                            <i class="flaticon-calendar"></i>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12 col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">To</label>
                                                            <div class="input-field date_picker dashed">
                                                                <div class="input-group date" id="datetimepicker02" data-target-input="nearest">
                                                                    <input type="text" class="form-control datetimepicker-input currentSeasonEndDate" id="currentToYear" name="to_year" data-target="#currentToYear" data-toggle="datetimepicker" placeholder="Date"  readonly="true"/>
                                                                    <div class="input-group-append" data-target="#currentToYear" data-toggle="datetimepicker">
                                                                        <div class="input-group-text">
                                                                            <i class="flaticon-calendar"></i>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>                                                                                                                                
                                                </div>
                                            </div>
                                        </div>
                                        <!-- xxxx -->

                                        <div class="row">
                                            <div class="col">
                                                <h2 class="inner-heading text-uppercase">
                                                    Offense
                                                </h2>
                                            </div>
                                        </div>

                                        <!-- xxxx -->

                                        <div class="row common-row">
                                            <div class="w-100"></div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Passing Yards</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="total_passing" value="{{getUserKeyStatsValueByColumn('total_passing')}}" placeholder="Total Passing Yards">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Passing Yards (Game/Season)</label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="passing_game" value="{{getUserKeyStatsValueByColumn('passing_game')}}" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="passing_season" value="{{getUserKeyStatsValueByColumn('passing_season')}}" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">Completions</label>
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="completion" value="{{getUserKeyStatsValueByColumn('completion')}}" placeholder="Completions">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">Completions(<span class="font-arial">%</span>)</label>
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="completion_percent"  value="{{getUserKeyStatsValueByColumn('completion_percent')}}" placeholder="Completions">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">QB Passer Rating</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="passer_rating" value="{{getUserKeyStatsValueByColumn('passer_rating')}}" placeholder="QB Passer Rating">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Rushing Yards</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="total_rushing" value="{{getUserKeyStatsValueByColumn('total_rushing')}}" placeholder="Total Rushing Yards">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Rushing Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="rushing_game" value="{{getUserKeyStatsValueByColumn('rushing_game')}}" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="rushing_season" value="{{getUserKeyStatsValueByColumn('rushing_season')}}" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Receiving Yards</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="total_receiving" value="{{getUserKeyStatsValueByColumn('total_receiving')}}" placeholder="Total Receiving Yards">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Receiving Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput"  name="receiving_game" value="{{getUserKeyStatsValueByColumn('receiving_game')}}" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="receiving_season"  value="{{getUserKeyStatsValueByColumn('receiving_season')}}" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Return Yards</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="total_return" value="{{getUserKeyStatsValueByColumn('total_return')}}" placeholder="Total Receiving Yards">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Return Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="return_game"  value="{{getUserKeyStatsValueByColumn('return_game')}}" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="return_season" value="{{getUserKeyStatsValueByColumn('return_season')}}" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total All Purpose Yards</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="total_all_purpose" value="{{getUserKeyStatsValueByColumn('total_all_purpose')}}"   placeholder="Total Receiving Yards">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Purpose Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="purpose_game" value="{{getUserKeyStatsValueByColumn('purpose_game')}}" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="purpose_season"  value="{{getUserKeyStatsValueByColumn('purpose_season')}}" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Touchdowns</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="tuchdowns"  value="{{getUserKeyStatsValueByColumn('tuchdowns')}}" placeholder="Touchdowns">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Games Played</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="games_played" value="{{getUserKeyStatsValueByColumn('games_played')}}" placeholder="Games Played">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- xxxx -->

                                        <div class="row">
                                            <div class="col">
                                                <h2 class="inner-heading text-uppercase">
                                                    Defense
                                                </h2>
                                            </div>
                                        </div>

                                        <!-- xxxx -->

                                        <div class="row common-row">

                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Tackles</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="tackles"  value="{{getUserKeyStatsValueByColumn('tackles')}}" placeholder="Total Tackles">
                                                    </div>
                                                </div>    
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Tackles Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="tackles_game" value="{{getUserKeyStatsValueByColumn('tackles_game')}}" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="tackles_season" value="{{getUserKeyStatsValueByColumn('tackles_season')}}" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Tackles for Loss</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="total_tackloss" value="{{getUserKeyStatsValueByColumn('total_tackloss')}}" placeholder="Total Tackles for Loss">
                                                    </div>
                                                </div>    

                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Tackles for Loss Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="tackloss_game" value="{{getUserKeyStatsValueByColumn('tackloss_game')}}" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="tackloss_season" value="{{getUserKeyStatsValueByColumn('tackloss_season')}}" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Sacks</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="total_sacks"  value="{{getUserKeyStatsValueByColumn('total_sacks')}}" placeholder="Total Sacks">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Sacks Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="sacks_game" value="{{getUserKeyStatsValueByColumn('sacks_game')}}" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="sacks_season" value="{{getUserKeyStatsValueByColumn('sacks_season')}}" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Pass Breakups</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="total_breaksups" value="{{getUserKeyStatsValueByColumn('total_breaksups')}}" placeholder="Total Pass Breakups">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Pass Breakups Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="breaksups_game" value="{{getUserKeyStatsValueByColumn('breaksups_game')}}" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="breaksups_season"  value="{{getUserKeyStatsValueByColumn('breaksups_season')}}"  placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Interceptions</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="total_interception" value="{{getUserKeyStatsValueByColumn('total_interception')}}"  placeholder="Total Interceptions">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Interceptions Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="interception_game" value="{{getUserKeyStatsValueByColumn('interception_game')}}" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="currentSeasonInput" name="interception_season" value="{{getUserKeyStatsValueByColumn('interception_season')}}" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Blocked Punts</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="blocked_punts" value="{{getUserKeyStatsValueByColumn('blocked_punts')}}" placeholder="Blocked Punts">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- xxxx -->

                                        <div class="row">
                                            <div class="col">
                                                <h2 class="inner-heading text-uppercase">
                                                    Specials
                                                </h2>
                                            </div>
                                        </div>
                                        <!-- xxxx -->

                                        <div class="row common-row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Field Goals</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="total_field_goal" value="{{getUserKeyStatsValueByColumn('total_field_goal')}}" placeholder="Total Field Goals">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Longest Field Goal</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="longest_field_goal"  value="{{getUserKeyStatsValueByColumn('longest_field_goal')}}" placeholder="Longest Field Goal">
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Field Goal Percentage</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="field_goal_percent"  value="{{getUserKeyStatsValueByColumn('field_goal_percent')}}" placeholder="Field Goal Percentage">
                                                    </div>
                                                </div>    
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Longest Punt</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="longest_punt" value="{{getUserKeyStatsValueByColumn('longest_punt')}}" placeholder="Longest Punt">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Average Punt Distance</label>
                                                    <div class="input-field">
                                                        <input type="text" class="currentSeasonInput" name="avg_punt_distance" value="{{getUserKeyStatsValueByColumn('avg_punt_distance')}}" placeholder="Average Punt Distance">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>          
                            {!! JsValidator::formRequest('App\Player\Http\Requests\CurrentSeasonRequest','#currentSeasonForm') !!}                                                                                                       
                        </div>
                    </div>

                    <!-- xxxxxx Past Season Start xxxxxx -->

                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button"  data-toggle="collapse" data-target="#collapse02" aria-expanded="false">
                                    Past Season
                                    <i class="fas fa-plus icon"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapse02" class="collapse" data-parent="#accordionStep04">
                            <form autocomplete="off" id="pastSeasonForm" method="POST" action="{{url('player/save-season')}}">  
                                {{csrf_field()}}
                                <input type="hidden" name="season_type" value="past">
                                <div class="card-body">
                                    <div class="container">
                                        <div class="row common-row">
                                            <div class="col-lg-8 col-xl-6">
                                                <div class="row">
                                                    <div class="col-12 col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">From</label>
                                                            <div class="input-field date_picker z-index">
                                                                <div class="input-group date" id="datetimepicker05" data-target-input="nearest">
                                                                    <input type="text" name="from_year" id="pastFromYear" class="form-control datetimepicker-input" data-target="#datetimepicker05" placeholder="Date" />
                                                                    <div class="input-group-append" data-target="#datetimepicker05" data-toggle="datetimepicker">
                                                                        <div class="input-group-text">
                                                                            <i class="flaticon-calendar"></i>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12 col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">To</label>
                                                            <div class="input-field date_picker dashed">
                                                                <div class="input-group date" id="datetimepicker06" data-target-input="nearest">
                                                                    <input type="text" name="to_year" id="pastToYear" class="form-control datetimepicker-input" data-target="#datetimepicker06" placeholder="Date" />
                                                                    <div class="input-group-append" data-target="#datetimepicker06" data-toggle="datetimepicker">
                                                                        <div class="input-group-text">
                                                                            <i class="flaticon-calendar"></i>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- xxxx -->

                                        <div class="row">
                                            <div class="col">
                                                <h2 class="inner-heading text-uppercase">
                                                    Offense
                                                </h2>
                                            </div>
                                        </div>

                                        <!-- xxxx -->

                                        <div class="row common-row">
                                            <div class="w-100"></div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Passing Yards</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="total_passing" placeholder="Total Passing Yards">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Passing Yards (Game/Session)</label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text"  class="pastSeasonInput" name="passing_game" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text"  class="pastSeasonInput" name="passing_season" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">Completions</label>
                                                            <div class="input-field">
                                                                <input type="text"  class="pastSeasonInput" name="completion" placeholder="Completions">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">Completions(<span class="font-arial">%</span>)</label>
                                                            <div class="input-field">
                                                                <input type="text"  class="pastSeasonInput" name="completion_percent" placeholder="Completions">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">QB Passer Rating</label>
                                                    <div class="input-field">
                                                        <input type="text"  class="pastSeasonInput" name="passer_rating" placeholder="QB Passer Rating">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Rushing Yards</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="total_rushing" placeholder="Total Rushing Yards">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Rushing Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="rushing_game" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="rushing_season" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Receiving Yards</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="total_receiving" placeholder="Total Receiving Yards">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Receiving Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="receiving_game" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="receiving_season" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Return Yards</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="total_return" placeholder="Total Receiving Yards">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Return Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="return_game" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="return_season" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total All Purpose Yards</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="total_all_purpose" placeholder="Total Receiving Yards">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Purpose Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="purpose_game" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="purpose_season" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Touchdowns</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="tuchdowns" placeholder="Touchdowns">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Games Played</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="games_played" placeholder="Games Played">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- xxxx -->

                                        <div class="row">
                                            <div class="col">
                                                <h2 class="inner-heading text-uppercase">
                                                    Defense
                                                </h2>
                                            </div>
                                        </div>

                                        <!-- xxxx -->

                                        <div class="row common-row">

                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Tackles</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="tackles" placeholder="Total Tackles">
                                                    </div>
                                                </div>    
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Tackles Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="tackles_game" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="tackles_season" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Tackles for Loss</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="total_tackloss" placeholder="Total Tackles for Loss">
                                                    </div>
                                                </div>    

                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Tackles for Loss Yards  (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="tackloss_game" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="tackloss_season" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Sacks</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="total_sacks" placeholder="Total Sacks">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Sacks Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="sacks_game" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="sacks_season" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Pass Breakups</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="total_breaksups" placeholder="Total Pass Breakups">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Pass Breakups Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="breaksups_game" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="breaksups_season" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Interceptions</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="total_interception" placeholder="Total Interceptions">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-lg-6">
                                                <label class="control-label">Average Interceptions Yards (Game/Season) </label>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="interception_game" placeholder="For Game">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-field">
                                                                <input type="text" class="pastSeasonInput" name="interception_season" placeholder="For Season">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Blocked Punts</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="blocked_punts" placeholder="Blocked Punts">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <!-- xxxx -->

                                        <div class="row">
                                            <div class="col">
                                                <h2 class="inner-heading text-uppercase">
                                                    Specials
                                                </h2>
                                            </div>
                                        </div>


                                        <!-- xxxx -->


                                        <div class="row common-row">

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Total Field Goals</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="total_field_goal" placeholder="Total Field Goals">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Longest Field Goal</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="longest_field_goal" placeholder="Longest Field Goal">
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Field Goal Percentage</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="field_goal_percent" placeholder="Field Goal Percentage">
                                                    </div>
                                                </div>    
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Longest Punt</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="longest_punt" placeholder="Longest Punt">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Average Punt Distance</label>
                                                    <div class="input-field">
                                                        <input type="text" class="pastSeasonInput" name="avg_punt_distance" placeholder="Average Punt Distance">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="card-footer">
                                    <a href="javascript:void(0);" class="position-relative add-more" onclick="submitSeasonForm('pastSeasonForm', '')" id="pastSeason">ADD MORE</a>
                                </div>
                            </form>     
                            {!! JsValidator::formRequest('App\Player\Http\Requests\PastSeasonRequest','#pastSeasonForm') !!}                                                               
                        </div>
                    </div>
                </div>

                <!-- xxxxxx Added Past Season Start xxxxxx -->
                <!-- Route for get all saved past seasons -->
                <input type="hidden"  data-url="{{url('player/get-saved-past-season')}}" id="saved_past_seasons" >
                <!-- Route for delete past seasons -->
                <input type="hidden"  data-url="{{url('player/delete-season')}}" id="delete_past_seasons" >

                <div class="accordion savedPastSeason" id="accordionAdded">
                </div>

                <div class="btn-row w-100  text-right">
                    <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2 font-22" id="preStep03">PREVIOUS</a>
                    <a href="javascript:void(0);" class="btn btn-success btn-lg border-2 font-22" id="nextStep04" onclick="submitSeasonForm('currentSeasonForm', 'next')">NEXT</a>
                    <a href="javascript:void(0);" class="btn btn-success btn-lg border-2 font-22" id="nextStep044" onclick="submitSeasonForm('currentSeasonForm', 'exit')">SAVE & EXIT</a>
                </div>
            </div>
        </div>
    </div>
    <!-- step 4 end -->
    <!-- xxxxxxx -->
    <div class="step-form05" id="Form05" style="display: none;">
        <div class="container">
            <form autocomplete="off" id="player-step-five" class="custom_form" method="post" action="javascript:void(0)">
                {{ csrf_field() }}
                <div class="row common-row">
                    <div class="col-md-6">
                        <div class="form-group upload">
                            <label class="control-label">Add Files</label>
                            <div class="input-field">
                                <div id="uploadFiles">
                                    <div class="file-upload forupload">
                                        <div class="file-select ">
                                            <div class="file-select-name nofile_name" >No file chosen...</div> 
                                        </div>
                                    </div> 
                                    <!-- file upload success message-->
                                </div>
                                <div class="image-upload-loader"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <ul class="list-inline multipal_images d-flex black-scroll" id="MultipalImages">
                 <!--get media image thumb append-->
                </ul>
                <div id="media-validation-message">
                    <!-- get validation messages -->
                </div>
               <!-- xxxxxxx -->
               <div class="row common-row">
                    <div class="col-12 pl-0">
                        <div class="btn-row w-100  text-right">
                            <button class="btn btn-secondary btn-lg border-2 font-22" id="preStep04">PREVIOUS</button>
                            <button type="button" class="btn btn-success btn-lg border-2 font-22" id="nextStep05" onclick="fifthStepForm('player-step-five', 'next')">NEXT</button>
                            <button href="javascript:void(0);" class="btn btn-success btn-lg border-2 font-22" id="nextStep055" onclick="fifthStepForm('player-step-five', 'exit')">SAVE & EXIT</button>
                        </div>
                    </div>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Player\Http\Requests\PlayerStepFiveRequest','#player-step-five') !!}
        </div>
    </div>
    <!-- xxxxxxx -->
    <div class="step-form06" id="Form06" style="display: none;">
        <div class="container">
            <form autocomplete="off" id="player-step-six" class="custom_form" method="post" action="{{ url('player/player-step-six') }}">
                {{ csrf_field() }}
                <div class="row common-row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Certifier</label>
                            <div class="input-field">
                                <input type="text" name="certifier" value="{{ getUserMeasurables('certifier') }}" placeholder="Certifier">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Certifier Email/Link</label>
                            <div class="input-field">
                                <input type="text" name="email_link" value="{{ getUserMeasurables('email_link') }}" placeholder="Certifier Email/Link">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="control-label">Height</label>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <select name="height_ft" class="selectpicker form-control select-custom" title="Ft " data-size="4">
                                        <option value="4" {{ getUserMeasurables('height_ft') == '4' ? 'selected':'' }}>4</option>
                                        <option value="5" {{ getUserMeasurables('height_ft') == '5' ? 'selected':'' }}>5</option>
                                        <option value="6" {{ getUserMeasurables('height_ft') == '6' ? 'selected':'' }}>6</option>
                                        <option value="7" {{ getUserMeasurables('height_ft') == '7' ? 'selected':'' }}>7</option>
                                        <option value="8" {{ getUserMeasurables('height_ft') == '8' ? 'selected':'' }}>8</option>
                                        <option value="9" {{ getUserMeasurables('height_ft') == '9' ? 'selected':'' }}>9</option>
                                    </select>
                                </div>  
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <select name="height_in" class="selectpicker form-control select-custom" title="In" data-size="4">
                                        <option value="1" {{ getUserMeasurables('height_in') == '0' ? 'selected':'' }}>0</option>
                                        <option value="1" {{ getUserMeasurables('height_in') == '1' ? 'selected':'' }}>1</option>
                                        <option value="2" {{ getUserMeasurables('height_in') == '2' ? 'selected':'' }}>2</option>
                                        <option value="3" {{ getUserMeasurables('height_in') == '3' ? 'selected':'' }}>3</option>
                                        <option value="4" {{ getUserMeasurables('height_in') == '4' ? 'selected':'' }}>4</option>
                                        <option value="5" {{ getUserMeasurables('height_in') == '5' ? 'selected':'' }}>5</option>
                                        <option value="6" {{ getUserMeasurables('height_in') == '6' ? 'selected':'' }}>6</option>
                                        <option value="7" {{ getUserMeasurables('height_in') == '7' ? 'selected':'' }}>7</option>
                                        <option value="8" {{ getUserMeasurables('height_in') == '8' ? 'selected':'' }}>8</option>
                                        <option value="9" {{ getUserMeasurables('height_in') == '9' ? 'selected':'' }}>9</option>
                                        <option value="10" {{ getUserMeasurables('height_in') == '10' ? 'selected':'' }}>10</option>
                                        <option value="10" {{ getUserMeasurables('height_in') == '11' ? 'selected':'' }}>11</option>
                                    </select>
                                </div>  
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Weight (Lb)</label>
                            <div class="input-field">
                                <input name="weight" type="text" value="{{ getUserMeasurables('weight') }}" maxlength="3" placeholder="Weight (Lb)">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Pro Shuttle (sec)</label>
                            <div class="input-field">
                                <input name="pro_shuttle" type="text" value="{{ getUserMeasurables('pro_shuttle') }}" placeholder="Pro Shuttle (sec)">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">College Shuttle (sec)</label>
                            <div class="input-field">
                                <input name="collegiate_shuttle" type="text" value="{{ getUserMeasurables('collegiate_shuttle') }}" placeholder="College Shuttle (sec)">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Bench in Reps</label>
                            <div class="input-field">
                                <input name="bench" type="text" value="{{ getUserMeasurables('bench') }}" placeholder="Bench in Reps">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Vert (in)</label>
                            <div class="input-field">
                                <input name="vert" type="text" value="{{ getUserMeasurables('vert') }}" placeholder="Vert (in)">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Hand Size (in)</label>
                            <div class="form-group">
                                <div class="input-field">
                                    <input name="hand_size" type="text" value="{{ getUserMeasurables('hand_size') }}" placeholder="Hand Size (in)">
                                </div>
                            </div> 
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="control-label">Broad Jump</label>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <select name="broad_jump_from" class="selectpicker form-control select-custom" title="Ft " data-size="4">
                                        <option value="6" {{ getUserMeasurables('broad_jump_from') == '6' ? 'selected':'' }}>6</option>
                                        <option value="7" {{ getUserMeasurables('broad_jump_from') == '7' ? 'selected':'' }}>7</option>
                                        <option value="8" {{ getUserMeasurables('broad_jump_from') == '8' ? 'selected':'' }}>8</option>
                                        <option value="9" {{ getUserMeasurables('broad_jump_from') == '9' ? 'selected':'' }}>9</option>
                                        <option value="10" {{ getUserMeasurables('broad_jump_from') == '10' ? 'selected':'' }}>10</option>
                                        <option value="11" {{ getUserMeasurables('broad_jump_from') == '11' ? 'selected':'' }}>11</option>
                                        <option value="12" {{ getUserMeasurables('broad_jump_from') == '12' ? 'selected':'' }}>12</option>
                                    </select>
                                </div>  
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <select name="broad_jump_to" class="selectpicker form-control select-custom" title="In" data-size="4">
                                        <option value="0" {{ getUserMeasurables('broad_jump_to') == '0' ? 'selected':'' }}>0</option>
                                        <option value="1" {{ getUserMeasurables('broad_jump_to') == '1' ? 'selected':'' }}>1</option>
                                        <option value="2" {{ getUserMeasurables('broad_jump_to') == '2' ? 'selected':'' }}>2</option>
                                        <option value="3" {{ getUserMeasurables('broad_jump_to') == '3' ? 'selected':'' }}>3</option>
                                        <option value="4" {{ getUserMeasurables('broad_jump_to') == '4' ? 'selected':'' }}>4</option>
                                        <option value="5" {{ getUserMeasurables('broad_jump_to') == '5' ? 'selected':'' }}>5</option>
                                        <option value="6" {{ getUserMeasurables('broad_jump_to') == '6' ? 'selected':'' }}>6</option>
                                        <option value="7" {{ getUserMeasurables('broad_jump_to') == '7' ? 'selected':'' }}>7</option>
                                        <option value="8" {{ getUserMeasurables('broad_jump_to') == '8' ? 'selected':'' }}>8</option>
                                        <option value="9" {{ getUserMeasurables('broad_jump_to') == '9' ? 'selected':'' }}>9</option>
                                        <option value="10" {{ getUserMeasurables('broad_jump_to') == '10' ? 'selected':'' }}>10</option>
                                        <option value="11" {{ getUserMeasurables('broad_jump_to') == '11' ? 'selected':'' }}>11</option>
                                    </select>
                                </div>  
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">40 (sec)</label>
                            <div class="form-group">
                                <div class="input-field">
                                    <input name="fourty" type="text" value="{{ getUserMeasurables('fourty') }}" placeholder="0">
                                </div>
                            </div> 
                        </div>
                    </div>
                    <div class="col-12 pl-0">
                        <div class="btn-row w-100  text-right">
                            <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2 font-22" id="preStep05">PREVIOUS</a>
                            <button type="button" class="btn btn-success btn-lg border-2 font-22" id="nextStep06" onclick="sixthStepForm('player-step-six', 'next')">NEXT</button>
                            <a href="javascript:void(0);" class="btn btn-success btn-lg border-2 font-22" id="nextStep066" onclick="sixthStepForm('player-step-six', 'exit')">SAVE & EXIT</a>
                        </div>
                    </div>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Player\Http\Requests\SendMeasurableRequest','#player-step-six') !!}
        </div>
    </div>
    <!-- xxxxxxx -->
    <div class="step-form07 last-form" id="Form07" style="display: none;">
        <div class="container">
            <form autocomplete="off" id="player-step-seven" class="custom_form" method="post" action="{{ url('player/player-step-seven') }}">
                {{ csrf_field() }}
                <label class="control-label">Salary Range (USD) </label>
                <div class="row common-row">
                    <div class="col">
                        <div class="form-group">
                            <div class="input-field">
                                <input type="text" name="salary_from" id="fromSalary" value="{{!empty($userDetail->from_salary) ? $userDetail->from_salary : ''}}" placeholder="From" maxlength="10">
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <div class="input-field dashed">
                                <input type="text" name="salary_to" id="toSalary" value="{{!empty($userDetail->to_salary) ? $userDetail->to_salary : ''}}" placeholder="To" maxlength="10">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- xxxxxxx -->
                <div class="row common-row" id="userBenefitMain">
                    @if(!empty($masterBenefits))
                    @php $userBenefits = getUserBenefits(); @endphp
                    @foreach($masterBenefits as $benefits)
                    <div class="col-md-3 col-sm-6">
                        <label class="d-block for-check">
                            <input type="checkbox" name="benefits[]" value="{{ $benefits->id }}" id="one{{ $benefits->id }}" class="d-none" @php if( in_array($benefits->id, $userBenefits) ){ echo 'checked'; } @endphp>
                                   <span class="box-wrap d-flex align-items-center justify-content-center text-center">
                                <span class="benefit-box text-center mb-0">
                                    <i class="{{$benefits->image}}"></i>
                                    <span class="mb-0 d-block">{{$benefits->title}}</span>
                                </span>
                            </span>
                        </label>
                    </div>
                    @endforeach
                    @endif 
                    <div class="col-md-3 col-sm-6">
                        <a href="javascript:void(0);" class="box-wrap add-box d-flex align-items-center justify-content-center text-center" id="addBenefit">
                            <div class="benefit-box text-center">
                                <p class="mb-0">Add Other Benefits</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="row common-row" id="userBenefitMain">

                    <!-- xxxxxxx -->
                    <div class="col-12 pl-0">
                        <div class="btn-row w-100  text-right">
                            <a href="javascript:void(0);" class="btn btn-secondary btn-lg border-2 font-22" id="preStep06">PREVIOUS</a>
                            <button type="button" class="btn btn-success btn-lg border-2 font-22" id="nextStep07" onclick="sevenStepForm('player-step-seven', 'next')">SAVE</button>
                        </div>
                    </div>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Player\Http\Requests\PlayerStepSevenRequest','#player-step-seven') !!}
        </div>
    </div>


    <!-- Image cropper model -->
    <div id="imagCropperModal" class="modal fade image_cropper" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel01" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog common-modal crop-modal modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header pb-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title heading-modal text-center">Profile Image</h4>
                </div>
                <div class="modal-body">
                    <div id="cropperDiv">
                        <div style="display:none;" id="processloader" class="imagmodelloader center-block">
                            <i class="fa fa fa-spinner fa-pulse fa-2x"></i></div> </div>
                </div>
            </div>
        </div>
    </div>

    <!-- After save step form redirect url -->
    <input type="hidden"  data-url="{{ url('player/player-profile') }}" id="step_form_redirect" >
    <!-- Country/State, Language, Level and position  URL -->    
    <input type="hidden"  data-url="{{ url('get-all-country') }}" id="all_country" >
    <input type="hidden"  data-url="{{ url('get-all-language') }}" id="all_language" >
    <input type="hidden"  data-url="{{ url('get-all-level') }}" id="all_level" >
    <input type="hidden"  data-url="{{ url('get-all-position') }}" id="all_positon" >
    <input type="hidden"  data-url="{{ url('get-state-by-country-id') }}" id="get_state_by_country" >
    <input type="hidden"  data-url="{{ url('player/player-step-five') }}" id="step-five-form-url">
    <!-- end -->     
    <!-- Image upload url -->
    <input type="hidden"  data-url="{{ url('upload-profile-image') }}" id="upload_profile_image" >
    <input type="hidden"  data-url="{{ url('load-profile-image-cropper') }}" id="loading_profile_image" >
    <input type="hidden"  data-url="{{ url('save-profile-image') }}" id="save_profile_image" >
</main>

<script type="text/javascript" src="{{ url('public/js/player/player-step-forms.js') }}"></script>
<script type="text/javascript" src="{{ url('public/js/ajaxupload.3.5.js') }}"></script>
<script type="text/javascript" src="{{ url('public/js/cropper.min.js') }}"></script>

<script>
        $(document).ready(function(){
                var dbFromYear = "{{getUserKeyStatsValueByColumn('from_year')}}";
                var dbToYear = "{{getUserKeyStatsValueByColumn('to_year')}}";
                if(dbFromYear && dbToYear){
                   var seasonFromYear = dbFromYear;
                   var seasonToYear = dbToYear;
                }else{
                    var seasonFromYear = '';
                    var seasonToYear = '';                    
                }                
                setTimeout(function (){
                   // $('#currentFromYear').datetimepicker({defaultDate: seasonFromYear});
                    //$('#currentToYear').datetimepicker({defaultDate: seasonToYear});
                    $("#currentFromYear").val(seasonFromYear);
                    $("#currentToYear").val(seasonToYear);        
                },2000);
        
       /*date picker fucntions for current session with maximum last year*/
        $('#currentFromYear').datetimepicker({// initialize datepicker
            useCurrent: false,
            format: "L",
            maxDate: new Date().setHours(0, 0, 0, 0),
            ignoreReadonly: true,
        });    
        var d = new Date();
        var getYear = d.getFullYear();
        var dd = getYear + "/12/31";
        var currentLastDate = new Date(dd);
        $('#currentToYear').datetimepicker({// initialize datepicker
            useCurrent: false,
            format: "L",
            maxDate: currentLastDate,                            
            ignoreReadonly: true,
        });    
        });

        $("#currentFromYear").on("change.datetimepicker", function (e) {       // on changes start date
            $('#currentToYear').datetimepicker('minDate', e.date);             // set minimum end date to startDate 
        });

        $("#currentToYear").on("change.datetimepicker", function (e) {             // on changes of end date
            $('#currentFromYear').datetimepicker('maxDate', e.date);               // start date's mamimux date set to end date
        });
    
        $('#fromSalary').on('keyup', function () {
            if (($('#toSalary').val()) && ($(this).val() <= $('#toSalary').val())) {
                $('#one1').prop('checked', true);
            } else {
                $('#one1').prop('checked', false);
                $('#toSalary').val('');
            }
        });
        
        $('#toSalary').on('keyup', function () {
            if (($('#fromSalary').val()) && ($(this).val() >= $('#fromSalary').val())) {
                $('#one1').prop('checked', true);
            } else {
                $('#one1').prop('checked', false);
            }
        });


        checkYear = false;
        // get all country
        $(document).ready(function () {
            var type = localStorage.getItem('type');
            if (type == "about") {
                $('#step01,#step02,#step03').addClass('active');
                $('#step01,#step02').addClass('pre-active');
                $('#Form01').hide();
                $('#Form02').hide();
                $('#Form03').show();
                $('html, body').animate({
                    scrollTop: 0
                }, "slow");
            }
            if (type == "measurables") {
                $('#step01,#step02,#step03,#step04,#step05, #step06').addClass('active');
                $('#step01,#step02,#step03,#step04,#step05').addClass('pre-active');
                $('#Form01,#Form02,#Form03,#Form04,#Form05').hide();
                $('#Form06').show();
                $('html, body').animate({
                    scrollTop: 0
                }, "slow");
            }
            if (type == "desired-benefits") {
                $('#step01,#step02,#step03,#step04,#step05,#step06,#step07').addClass('active');
                $('#step01,#step02,#step03,#step04,#step05,#step06').addClass('pre-active');
                $('#Form01,#Form02,#Form03,#Form04,#Form05,#Form06').hide();
                $('#Form07').show();
                $('html, body').animate({
                    scrollTop: 0
                }, "slow");
            }
            
            localStorage.removeItem('type');
            $.post($("#all_country").data('url'), {_token: '{{ csrf_token() }}', type: 'user-profile-step-one'}, function (data) {
                var country1 = '{{ $countryId }}';
                $('#country').html(data);
                $('#country').selectpicker('refresh');
                if (country1 != '')
                {
                    $('#country').selectpicker('val', country1);
                    $('#country').selectpicker('render');
                }
            });

            // get all positions
            $.post($("#all_positon").data('url'), {_token: '{{ csrf_token() }}', type: 'player'}, function (data) {
                var position_id = '{{ getUserDataByColumn("position_id") }}';
                $('#position').html(data);
                $('#position').selectpicker('refresh');
                $('#position').selectpicker('val', [position_id.split(',')[0], position_id.split(',')[1]]);
                $('#position').selectpicker('render');
            });

            // get player state
            setTimeout(function () {
                $.post($("#get_state_by_country").data('url'), {_token: '{{ csrf_token() }}', country_id: "{{ $countryId }}", type: 'user-profile-step-one'}, function (data) {
                    $('#state').html(data);
                    $('#state').selectpicker('refresh');
                    $('#state').selectpicker('val', '{{$stateId}}');
                    $('#state').selectpicker('render');
                });
            }, 2000);
            getAge("{{getUserDataByColumn('age')}}");
        });
        // get state by country id
        $(document).on('change', '#country', function () {
            $.post($("#get_state_by_country").data('url'), {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: 'user-profile-step-one'}, function (data) {
                $('#state').html(data);
                $('#state').selectpicker('refresh');
            });
        });

        $(document).on('change', '#playing_exp', function () {
            $('#playing_exp').selectpicker('refresh');
        });

        /* for step 3 form education */
        // get all country
        function getCountry(type, country_id) {
            $.post($("#all_country").data('url'), {_token: '{{ csrf_token() }}', type: type, country_id: country_id}, function (data) {
                $('#country_id').html(data);
                $('#country_id').selectpicker('refresh');
                $('#country_id').selectpicker('val', country_id);
                $('#country_id').selectpicker('render');
            });
        }
        ;

        // get player state
        function getStateByCountry(type, country_id, state_id) {

            var url = $("#get_state_by_country").data('url');
            $.ajax({
                type: "POST",
                url: url,
                data: {_token: "{{ csrf_token() }}", country_id: country_id, state_id: state_id, type: type},
                success: function (response) {
                    setTimeout(function () {
                        $('#state_id').html(response);
                        $('#state_id').selectpicker('refresh');
                        $('#state_id').selectpicker('val', state_id);
                        $('#state_id').selectpicker('render');
                    }, 1500);
                },
                error: function () {
                    getStateByCountry(type, country_id, state_id);
                },
                complete: function () {
                    //setHeightMiddleSection(); 
                }
            });

        }
        ;
        $(document).on('change', '#country_id', function () {
            $.post($("#get_state_by_country").data('url'), {_token: "{{ csrf_token() }}", country_id: $(this).val(), type: ''}, function (data) {
                $('#state_id').html(data);
                $('#state_id').selectpicker('refresh');
            });
        });
//    /* Genearl staep 3 country and language */
        function get_language_country(type)
        {
            setTimeout(function () {
                $("#playing_exp").selectpicker('refresh');
            }, 2000);

            if ($("#" + type).hasClass('show')) { // if tab already open then return
                return false;
            }
        var url = "{{ url('get-user-general-info') }}"; 
        $.get(url, {id: ''}, function (response) {
            var country_id = response.country_id;
            var native_language = response.native_lang_id;
            var second_language = response.secondary_lang_id;
            /* for general country */
            $.post($("#all_country").data('url'), {_token: '{{ csrf_token() }}', type: 'general', country_id: country_id}, function (data) {
                $('#general_country').html(data);
                $('#general_country').selectpicker('refresh');
                if (country_id != '')
                {
                    $('#general_country').selectpicker('val', country_id);
                    $('#general_country').selectpicker('render');
                }
            });

//       /* for general languages */
            $.post($("#all_language").data('url'), {_token: '{{ csrf_token() }}'}, function (data) {
                $('#native_lang_id').html(data);
                $('#native_lang_id').selectpicker('refresh');
                $('#secondary_lang_id').html(data);
                $('#secondary_lang_id').selectpicker('refresh');
                if (native_language != '') {
                    $('#native_lang_id').selectpicker('val', native_language);
                    $('#native_lang_id').selectpicker('render');
                }
                if (second_language != '') {
                    $('#secondary_lang_id').selectpicker('val', second_language);
                    $('#secondary_lang_id').selectpicker('render');
                }
            });
        });
        }
        /* Genearl step 3 coaching and education */
        function getLevel(id, type)
        {
            /* for coaching step 3  */
            $.post($("#all_level").data('url'), {_token: '{{ csrf_token() }}'}, function (data) {
                $('#colevel_id').html(data);
                $('#colevel_id').selectpicker('refresh');
                $('#elevel_id').html(data);
                $('#elevel_id').selectpicker('refresh');
                $('#interlevel_id').html(data);
                $('#interlevel_id').selectpicker('refresh');
                $('#indolevel_id').html(data);
                $('#indolevel_id').selectpicker('refresh');
                if (id != '' && type == 'coaching')
                {
                    $('#colevel_id').selectpicker('val', id);
                    $('#colevel_id').selectpicker('render');
                }
                if (id != '' && type == 'education')
                {
                    $('#elevel_id').selectpicker('val', id);
                    $('#elevel_id').selectpicker('render');
                }
                if (id != '' && type == 'international')
                {
                    $('#interlevel_id').selectpicker('val', id);
                    $('#interlevel_id').selectpicker('render');
                }
                if (id != '' && type == 'indoor')
                {
                    $('#indolevel_id').selectpicker('val', id);
                    $('#indolevel_id').selectpicker('render');
                }
            });
        }

        /* image uload by cropper */
        var profile_picture = $('.upload-btn');
        pPicture = new AjaxUpload(profile_picture, {
            action: $("#upload_profile_image").data('url'),
            name: 'profileImage',
            cache: false,
            method: 'post',
            data: {_token: '{{ csrf_token() }}', folder: 'player', image_type: 'profileImage'},
            responseType: "JSON",
            onChange: function (file, ext) {
                //check the file size
                if (pPicture._input.files[0].size > 2097152) { //2MB
                    //show alert message
                    message('error', 'Selected file is bigger than 2MB.');
                    return false;
                }
            },
            onSubmit: function (file, ext) {
                if (!(ext && /^(jpg|png|jpeg)$/.test(ext))) {
                    message('error', 'Only jpg, jpeg, png files are allowed.');
                    return false;
                }
            },
            onComplete: function (file, response) {
                console.log(file, response);
                if (file != "") {
                    if (response.success == 1) {
                        load_cropp_image(response.filename, 'profileImage');
                    } else {
                        message('error', response.error);
                    }
                } else {
                    message('error', "Error occured! please try again.");
                }
            }
        });
        function  load_cropp_image(filename, type) {
            $("#imagCropperModal").modal('show');
            var url = $("#loading_profile_image").data('url');
            $.ajax({
                type: "POST",
                url: url,
                data: {_token: "{{ csrf_token() }}", filename: filename, folder: 'player', thumb_folder: 'player/thumb', image_type: type},
                success: function (response) {
                    $("#cropperDiv").html(response);
                    setTimeout(function () {
                        $("#cropbutton").attr('disabled', false);
                    }, 3000);
                }
            });
        }

        $(document).ready(function () {
            $('.selectpicker').selectpicker('refresh');
            uploadMultipleFile();
        });

//    multiple imageupload
        function uploadMultipleFile() {
            var options = {
                url: "{{url('player/upload-multiple-file')}}",
                dragDrop: true,
                method: "POST",
                cache: false,
                allowedTypes: "jpg,png,jpeg,mp4",
                fileName: "myPost",
                async: true,
                multiple: true,
                formData: {_token: '{{ csrf_token() }}'},
                onSelect: function (files, data, xhr)
                { 
                    var ImageCount = $('.imagecount').length;
                    uploadFileCount = files.length;
                    var totaleCount = ImageCount + uploadFileCount;
                    if (totaleCount > 10) {
                        $('#media-validation-message').html('Maximum 10 file upload');
                        return false;
                    }else{
                        $('#media-validation-message').html('');
                    } 

                    $('#nextStep05').attr("disabled", "disabled");
                    $('#nextStep055').attr("disabled", "disabled");

                    $.each(files, function (index, value) {
                        if (value.type == 'image/jpeg' || value.type == 'image/png' || value.type == 'image/jpg' || value.type == 'video/mp4') {
                            $('#preStep04').attr("disabled", "disabled");
                            $('.image-upload-loader').html('<div class="img_loader"><div class="btn_ring"></div></div>');
                            $('.success-message').html('');
                        }
                    });
                },
                onSuccess: function (files, data, xhr)
                {
                    $('.image-upload-loader').html('');
                    if (data.success == true) {
                       $('#MultipalImages').append('<li class="list-inline-item imagecount">\n\
                                       <input type="hidden" name="mediaType[]" value="' + data.type + '">\n\
                                       <input type="hidden" class="imageCount" name="hdnImageName[]" id="hdnImageName" value="' + data.image + '">\n\
                                       <img  src="<?php echo url("public/uploads/temp/thumb") ?>/' + data.image + '" class="img-fluid" alt=""> \n\
                                       <div class="icon"> \n\
                                             <a href="javascript:void(0);" onclick="removeImage(this)"><i class="fas fa-times"></i></a>\n\
                                       </div>\n\
                                      </li>');
                        $("#MultipalImages").mCustomScrollbar("destroy");
                        $("#MultipalImages").mCustomScrollbar({
                            theme: "dark",
                             axis:"x",
                         });
                    } else {
                        message('error', data.message);
                    }
                    $('#preStep04').removeAttr("disabled");
                    $('#nextStep05').removeAttr("disabled");
                    $('#nextStep055').removeAttr("disabled");
                },
            }
            $("#uploadFiles").uploadFile(options);
        }
        
      function removeImage(obj) {
        $('#media-validation-message').html('');
        $(obj).parent().parent().remove();
        $("#MultipalImages").mCustomScrollbar("destroy"); /* Post scrolling */
        $("#MultipalImages").mCustomScrollbar({
          theme: "dark",
           axis:"x",
        });
      }
</script>
@endsection