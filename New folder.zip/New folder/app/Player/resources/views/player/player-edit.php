<!DOCTYPE html>
<html lang="en">
<head>
	<title>Edit | FAF Player</title>
	<?php include "../include/head-link.php" ?>
	<link rel="stylesheet" href="../css/tempusdominus-bootstrap-4.min.css" />
</head>
<body onload="hide_preloader();">
	<div class="wrapper player_edit_page">

		<?php include  "../include/header-player.php" ?>

		<div class="main-content">
			<section class="job_posting">
				<div class="container">
					<div class="heading d-flex justify-content-between align-items-center flex-wrap">
						<div class="common_heading">
			                <h3 class="black black-lg">JOB POSTING</h3>
			            </div>
			            <h5 class="create_date">JOB CREATED ON: <span class="color-black">26/04/2018</span></h5>
					</div>
					<form class="needs-validation custom_form" novalidate>
						<div class="row common-row">
							<div class="col-sm-6">
								<div class="form-group">
									<label class="control-label">Select Job Type<span class="text-danger">*</span></label>
									<!-- <div class="input-field"> -->
										<select class="selectpicker select-custom form-control select01" title="Select Job" data-size="4" required>
											<option>Player</option>
											<option>Coach</option>
											<option>Team</option>
											<option>Player</option>
											<option>Coach</option>
											<option>Team</option>
										</select>
									<!-- </div> -->
								</div>
							</div>
						</div>
						<div class="row common-row">
							<div class="col-sm-6">
								<div class="form-group">
									<label class="control-label">Institution Name</label>
									<div class="input-field">
										<input type="text" placeholder="Enter Name">
									</div>
								</div>
							</div>
							<div class="col-sm-6 ">
								<div class="form-group">
									<label class="control-label">Institution Type</label>
									<select class="selectpicker form-control select-custom" title="Select Type" data-size="4">
										<option>Player</option>
										<option>Coach</option>
										<option>Team</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row common-row">
							<div class="col-sm-6">
								<div class="form-group">
									<label class="control-label">Level of Team</label>
									<select class="selectpicker form-control select-custom" title="Select " data-size="4">
										<option>First Level</option>
										<option>Second Level</option>
										<option>Third Level</option>
									</select>
								</div>
							</div>
							<div class="col-sm-6 ">
								<div class="form-group">
									<label class="control-label">League/Conference</label>
									<div class="input-field">
										<input type="text" placeholder="Type">
									</div>
								</div>
							</div>
						</div>
						<div class="form-group player_position">
							<label class="control-label">Player Position Title<span class="text-danger">*</span></label>
							<ul class="list-inline common_list mb-0">
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position01" checked="">
									  	<label class="custom-control-label" for="position01">C</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position02">
									  	<label class="custom-control-label" for="position02">G</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position033" checked="">
									  	<label class="custom-control-label" for="position033">T</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position03">
									  	<label class="custom-control-label" for="position03">LS</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="customCheck04">
									  	<label class="custom-control-label" for="customCheck04">RB</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position05">
									  	<label class="custom-control-label" for="position05">WR</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position06">
									  	<label class="custom-control-label" for="position06">TE</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position07">
									  	<label class="custom-control-label" for="position07">DE</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position08">
									  	<label class="custom-control-label" for="position08">DT</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position09">
									  	<label class="custom-control-label" for="position09">MLB</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position10">
									  	<label class="custom-control-label" for="position10">OLB</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position11" checked="">
									  	<label class="custom-control-label" for="position11">CB</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position12">
									  	<label class="custom-control-label" for="position12">S</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position13">
									  	<label class="custom-control-label" for="position13">K</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position14">
									  	<label class="custom-control-label" for="position14">P</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position15">
									  	<label class="custom-control-label" for="position15">KR</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="position16">
									  	<label class="custom-control-label" for="position16">PR</label>
									</div>
								</li>
							</ul>
						</div>
						<div class="row common-row">
							<div class="col-sm-6">
								<div class="form-group">
									<label class="control-label">Country<span class="text-danger">*</span></label>
									<div class="input-field">
										<input type="text" class="form-control" placeholder="Country" required>
										<div class="invalid-tooltip">
									        Please provide a valid Country.
								      	</div>
									</div>
								</div>
							</div>
							<div class="col-sm-6 ">
								<div class="form-group">
									<label class="control-label">State/Province<span class="text-danger">*</span></label>
									<div class="input-field">
										<input type="text" class="form-control" placeholder="State/Province" required>
										<div class="invalid-tooltip">
									        Please provide a State/Province.
								      	</div>
									</div>
								</div>
							</div>
						</div>
						<div class="row common-row">
							<div class="col-sm-6">
								<div class="form-group">
									<label class="control-label">City<span class="text-danger">*</span></label>
									<div class="input-field">
										<input type="text" placeholder="City" required>
									 <div class="invalid-tooltip">
								        Please provide a valid City.
							      	</div>
									</div>
								</div>
							</div>
							<div class="col-sm-6 ">
								<div class="form-group">
									<label class="control-label">Zip Code</label>
									<div class="input-field">
										<input type="text" placeholder="Zip Code">
									</div>
								</div>
							</div>
						</div>
						<div class="row common-row">
							<div class="col-sm-6">
								<div class="form-group">
									<label class="control-label">Job Description<span class="text-danger">*</span></label>
									<div class="input-field">
										<textarea  rows="3" class="form-control" placeholder="Job Description" required></textarea>
										<div class="invalid-tooltip">
									        Please provide a valid Job Description.
								      	</div>
									</div>
								</div>
							</div>
							<div class="col-sm-6 ">
								<div class="form-group">
									<label class="control-label">Skills Required<span class="text-danger">*</span></label>
									<div class="input-field">
										<textarea  rows="3" class="form-control" placeholder="Skills" required></textarea>
										<div class="invalid-tooltip">
									        Please provide a valid Skills Required.
								      	</div>
									</div>
								</div>
							</div>
						</div>
						<div class="row common-row">
							<div class="col-sm-6">
								<div class="form-group">
									<label class="control-label">Relevant Experience<span class="text-danger">*</span></label>
									<div class="input-field">
										<input type="text" class="form-control" placeholder="Relevant Experience" required>
										<div class="invalid-tooltip">
									        Please provide a valid Relevant Experience.
								      	</div>
									</div>
								</div>
							</div>
							<div class="col-sm-6 ">
								<div class="form-group">
									<label class="control-label">Last Date to Apply</label>
									<div class="input-field date_picker">
										<div class="input-group date" id="datetimepicker" data-target-input="nearest">
						                    <input type="text" class="form-control datetimepicker-input" data-target="#datetimepicker" placeholder="Last Date to Apply"  />
						                    <div class="input-group-append" data-target="#datetimepicker" data-toggle="datetimepicker">
                                                <div class="input-group-text">
                                                    <i class="flaticon-calendar"></i>
                                                </div>
                                            </div>
						                </div>
									</div>
								</div>
							</div>
						</div>
						<div class="row common-row">
							<div class="col-md-12 col-lg-6">
								<label class="control-label">Salary</label>
								<div class="row">
									<div class="col-12 col-sm-4">
										<div class="form-group">
											<select class="selectpicker form-control select-custom" title="Dol" data-size="4">
												<option>Option</option>
												<option>Option</option>
												<option>Option</option>
											</select>
										</div>
									</div>
									<div class="col-6 col-sm-4">
										<div class="form-group">
											<div class="input-field dashed">
												<input type="text" placeholder="5012">
											</div>
										</div>
									</div>
									<div class="col-6 col-sm-4">
										<div class="form-group">
											<div class="input-field">
												<input type="text" placeholder="10243">
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group benefits ">
							<label class="control-label">Benefits</label>
							<ul class="list-inline common_list mb-0">
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="benefits01" checked="">
									  	<label class="custom-control-label" for="benefits01">Housing</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="benefits02">
									  	<label class="custom-control-label" for="benefits02">Daily Travel</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="benefits03" checked="">
									  	<label class="custom-control-label" for="benefits03">Health Insurance</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="benefits04">
									  	<label class="custom-control-label" for="benefits04">Gym</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="benefits05">
									  	<label class="custom-control-label" for="benefits05">Meals</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="benefits06">
									  	<label class="custom-control-label" for="benefits06">Phone</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="benefits07">
									  	<label class="custom-control-label" for="benefits07">Relocation</label>
									</div>
								</li>
								<li class="list-inline-item">
									<div class="custom-control custom-checkbox border-checkbox">
									  	<input type="checkbox" class="custom-control-input" id="benefits08">
									  	<label class="custom-control-label" for="benefits08">Education/Tuition</label>
									</div>
								</li>
							</ul>
						</div>
						<div class="form-group accept_application">
							<label class="control-label">Accept Application Through</label>
							<ul class="list-inline common_list mb-0">
								<li class="list-inline-item mb-0">
									<div class="border-radio">
										<input type="radio" id="accept01"  name="accept" checked="">
										<label for="accept01" id="fafaccount_btn">
	                                          <i></i>  FAF Account
	                                    </label>
                                    </div>
								</li>
								<li class="list-inline-item mb-0">
									<div class="border-radio">
										<input type="radio" id="accept02"  name="accept" >
										<label for="accept02" id="weburl_btn">
	                                        <i></i>   Website
	                                    </label>
                                    </div>
								</li>
							</ul>
						</div>
						<div class="row common-row collapse" id="website_field">
							<div class="col-sm-6">
								<div class="form-group">
									<div class="input-field">
										<input type="text" placeholder="Website" >
									</div>
								</div>
							</div>
						</div>
						<div class="add_questionnaire">
							<div class="questionnaire_heading text-center">
								<h4>Add New Questionnaire</h4>
							</div>
							<div class="row common-row">
								<div class="col-sm-6">
									<div class="form-group">
										<label class="control-label">Name this Questionnaire</label>
										<div class="input-field">
											<input type="text" placeholder="Give a name to your questionnaire">
										</div>
									</div>
								</div>
								<div class="col-sm-6 ">
									<div class="form-group">
										<label class="control-label">Use Existing Questionnaire</label>
										<select class="selectpicker form-control select-custom" title="Select Questionnaire" data-size="4">
											<option>Player</option>
											<option>Coach</option>
											<option>Team</option>
										</select>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group" id="edit_q">
							<div class="view_question d-flex align-items-center">
								<div class="question mr-auto">
									<ul class="list-inline mb-0 color-white">
										<li class="list-inline-item content"> What is your experience? </li>
										<li class="list-inline-item common_text">  Custom List </li>
										<li class="list-inline-item common_text"> 4 Answers</li>
									</ul>
								</div>
								<div class="action">
									<a href="javascript:void(0);" id="edit_btn"> <i class="far fa-edit"></i></a>
									<a href="javascript:void(0);"> <i class="fas fa-trash-alt"></i></a>
								</div>
							</div>
						</div>
						<div class="edit_question" id="edit_q_d">
							<div class="option collapse" >
								<label class="control-label">EDIT QUESTION</label>
								<div class="form-group mt-2">
									<label class="control-label">Enter Your Question</label>
									<div class="input-field">
										<input type="text" value="What is your experience?">
									</div>
								</div>
								<div class="form-group choose_answer">
									<label class="control-label">Choose Answer Type</label>
									<ul class="list-inline common_list  mb-0 ">
										<li class="list-inline-item ">
											<div class="border-radio">
												<input type="radio" id="edit_answer01"  name="edit_answer" >
												<label for="edit_answer01">
			                                          <i></i> Radio Button
			                                    </label>
		                                    </div>
										</li>
										<li class="list-inline-item ">
											<div class="border-radio">
												<input type="radio" id="edit_answer02"  name="edit_answer" >
												<label for="edit_answer02">
			                                        <i></i> Check Box
			                                    </label>
		                                    </div>
										</li>
										<li class="list-inline-item ">
											<div class="border-radio">
												<input type="radio" id="edit_answer03"  name="edit_answer" checked="">
												<label for="edit_answer03">
			                                        <i></i> Custom List
			                                    </label>
		                                    </div>
										</li>
										<li class="list-inline-item ">
											<div class="border-radio">
												<input type="radio" id="edit_answer04"  name="edit_answer" >
												<label for="edit_answer04">
			                                        <i></i> Text Area
			                                    </label>
		                                    </div>
										</li>
									</ul>
								</div>
								<div class="form-group mb-3">
									<label class="control-label">Enter Your Answer</label>
									<div class="row">
										<div class="col-sm-12">
											<div class="enter_answerlist">
												<ul class="list-inline mb-0">
													<li class="list-inline-item">
														<div class="input-field">
															<input type="text" value="Tom Brady">
															<a href="javascript:void(0);" class=" icon" >
														    	<i class="fas fa-trash-alt"></i>
														    </a>
														</div>
													</li>
													<li class="list-inline-item">
														<div class="input-field">
															<input type="text" value="Tom Brady">
															<a href="javascript:void(0);" class=" icon" >
														    	<i class="fas fa-trash-alt"></i>
														    </a>
														</div>
													</li>
													<li class="list-inline-item">
														<div class="input-field">
															<input type="text" value="Aaron Rodgers">
															<a href="javascript:void(0);" class=" icon" >
														    	<i class="fas fa-trash-alt"></i>
														    </a>
														</div>
													</li>
													<li class="list-inline-item">
														<div class="input-field">
															<input type="text" value="Aaron Rodgers">
															<a href="javascript:void(0);" class=" icon" >
														    	<i class="fas fa-trash-alt"></i>
														    </a>
														</div>
													</li>
													<li class="list-inline-item">
														<div class="input-field">
															<input type="text" value="Aaron Rodgers">
															<a href="javascript:void(0);" class=" icon" >
														    	<i class="fas fa-trash-alt"></i>
														    </a>
														</div>
													</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
								<div class="form-group action_btn text-right">
									<a href="javascript:void(0);" class="btn btn btn-secondary">REMOVE</a>
									<a href="javascript:void(0);" class="btn btn-success">SAVE</a>
								</div>
							</div>	
						</div>
						
						<div class="add_question">
							<div class="option collapse" >
								<label class="control-label">ADD QUESTION</label>
								<div class="form-group mt-2">
									<label class="control-label">Enter Your Question</label>
									<div class="input-field">
										<input type="text" value="Which player is best in american football?">
									</div>
								</div>
								<div class="form-group choose_answer">
									<label class="control-label">Choose Answer Type</label>
									<ul class="list-inline common_list mb-0 ">
										<li class="list-inline-item ">
											<div class="border-radio">
												<input type="radio" id="answer01"  name="answer" checked="">
												<label for="answer01">
			                                          <i></i> Radio Button
			                                    </label>
		                                    </div>
										</li>
										<li class="list-inline-item ">
											<div class="border-radio">
												<input type="radio" id="answer02"  name="answer" >
												<label for="answer02">
			                                        <i></i> Check Box
			                                    </label>
		                                    </div>
										</li>
										<li class="list-inline-item ">
											<div class="border-radio">
												<input type="radio" id="answer03"  name="answer" >
												<label for="answer03">
			                                        <i></i> Custom List
			                                    </label>
		                                    </div>
										</li>
										<li class="list-inline-item ">
											<div class="border-radio">
												<input type="radio" id="answer04"  name="answer" >
												<label for="answer04">
			                                        <i></i> Text Area
			                                    </label>
		                                    </div>
										</li>
									</ul>
								</div>
								<div class="form-group mb-3">
									<label class="control-label">Enter Your Answer</label>
									<div class="row">
										<div class="col-md-8 col-lg-9">
											<div class="enter_answerlist">
												<ul class="list-inline mb-0">
													<li class="list-inline-item">
														<div class="input-field">
															<input type="text" value="Tom Brady">
															<a href="javascript:void(0);" class=" icon" >
														    	<i class="fas fa-trash-alt"></i>
														    </a>
														</div>
													</li>
													<li class="list-inline-item">
														<div class="input-field">
															<input type="text" value="Tom Brady">
															<a href="javascript:void(0);" class=" icon" >
														    	<i class="fas fa-trash-alt"></i>
														    </a>
														</div>
													</li>
													<li class="list-inline-item">
														<div class="input-field">
															<input type="text" value="Aaron Rodgers">
															<a href="javascript:void(0);" class=" icon" >
														    	<i class="fas fa-trash-alt"></i>
														    </a>
														</div>
													</li>
												</ul>
											</div>
										</div>
										<div class="col-md-4 col-lg-3">
											<a class="btn addmore_btn d-block" id="addmore" href="javascript:void(0);"> 
												<span><i class="fas fa-plus"></i> ADD MORE</span>
											</a>
										</div>
									</div>
								</div>
								<div class="form-group action_btn text-right">
									<a href="javascript:void(0);" id="remove" class="btn btn btn-secondary">REMOVE</a>
									<a href="javascript:void(0);" class="btn btn-success">SAVE</a>
								</div>
							</div>	
							<div class="text-center addoption_btn">
								<a href="javascript:void(0);"  id="add_btn" class="btn btn-primary">ADD ANOTHER QUESTION</a>
							</div>
						</div>
						
						<div class="basic_info">
							<div class="row common-row">
								<div class="col-sm-4">
									<div class="form-group">
										<label class="control-label">Social Media1</label>
										<div class="input-field">
											<input type="text" placeholder="Social Media1">
										</div>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label class="control-label">Social Media2</label>
										<div class="input-field">
											<input type="text" placeholder="Social Media2">
										</div>
									</div>
								</div>
								<div class="col-sm-4 ">
									<div class="form-group">
										<label class="control-label">Social Media3</label>
										<div class="input-field">
											<input type="text" placeholder="Social Media3">
										</div>
									</div>
								</div>
							</div>
							<div class="row common-row">
								<div class="col-sm-4">
									<div class="form-group">
										<label class="control-label">Contact Person </label>
										<div class="input-field">
											<input type="text" placeholder="Contact Person ">
										</div>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label class="control-label">Email ID</label>
										<div class="input-field">
											<input type="text" placeholder="Email ID">
										</div>
									</div>
								</div>
								<div class="col-sm-4 ">
									<div class="form-group">
										<label class="control-label">Phone No</label>
										<div class="input-field">
											<input type="text" placeholder="Phone No">
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="job_preview">
							<div class="text-center addoption_btn">
								<a href="javascript:void(0);" class="btn btn-primary" id="jobcard">JOB CARD PREVIEW</a>
							</div>
							<div class="job-block collapse">
                                <div class="jb_logo">
                                    <img src="../images/havoc-lg.png" alt=" job logo">
                                </div>
                                <div class="jb_info d-flex justify-content-between">
                                    <ul class="list-unstyled">
                                        <li>
                                            <label>NAME</label>
                                            <p>Offensive Tackle</p>
                                        </li>
                                        <li>
                                            <label>INSTITUTION TYPE</label>
                                            <p>Team</p>
                                        </li>
                                        <li>
                                            <label>JOB TYPE</label>
                                            <p>Staf and Personnel</p>
                                        </li>
                                        <li>
                                            <label>POSITION AREA</label>
                                            <p>Marketing</p>
                                        </li>
                                        <li>
                                            <label>POSTION TITLE</label>
                                            <p>Director Of Marketing</p>
                                        </li>
                                    </ul>
                                    <ul class="list-unstyled">
                                        <li>
                                            <label>LEVEL</label>
                                            <p>Indoor/Arena</p>
                                        </li>
                                        <li>
                                        	<label>LEAGUE or CONFERENCE</label>
                                            <p>ALL</p>
                                        </li>
                                        <li>
                                            <label>LOCATION</label>
                                            <p>United States</p>
                                        </li>
                                        <li>
                                            <img class="flag" src="../images/american_flag.jpg" alt="flag">
                                        </li>
                                        <li>
                                            <label>DATE</label>
                                            <p>Apr 24, 2018</p>
                                        </li>
                                    </ul>
                                    <ul class="list-unstyled views">
                                        <li>
                                            <label>VIEWS</label>
                                            <p>33</p>
                                        </li>
                                        <li>
                                            <a href="#" class="btn btn-primary text-uppercase">apply</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">
                                            <span class="icon icon-share_icon"></span>
                                        </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
						</div>
						<div class="form-group submit_btn text-right">
							<a href="javascript:void(0);" class="btn btn btn-secondary">CANCEL</a>
							<button  class="btn btn-success" type="submit"> 
								<span class="d-n">SAVE</span>
								<span class="btn_loader btn_ring" style="display: none;"></span>
							</button>
						</div>
					</form>
				</div>
			</section>
		</div>

		<?php include "../include/footer.php" ?>


	</div>
	<style>
		.ld{
			    position: absolute;
    margin: -.5em;
    opacity: 1;
    z-index: -100;
    -webkit-transition: all .3s;
    transition: all .3s;
    transition-timing-function: ease-in;
		}
		.ld-ring{
			width: 1em;  height: 1em;  position: relative;  color: inherit;   display: inline-block;
		}
		.ld-ring:after{    
			border-width: .15em;    border-radius: 50%;  border-style: solid;
    		border-color: currentColor currentColor currentColor transparent;
     		position: absolute;  margin: auto;  top: 0;  left: 0;  right: 0;  bottom: 0;
    		content: " ";  display: inline-block;  background: center center no-repeat;
    		background-size: cover;
    	}
    	@keyframes ld-cycle{
		0%,50%,100%{animation-timing-function:cubic-bezier(0.5,0.5,0.5,0.5)}
		0%{-webkit-transform:rotate(0);transform:rotate(0)}
		50%{-webkit-transform:rotate(180deg);transform:rotate(180deg)}
		100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}
		}
		.ld.ld-cycle {
		    -webkit-animation: ld-cycle 1s infinite linear;
		    animation: ld-cycle 1s infinite linear;
		}
	</style>

	<script>
		
	// // validation
	(function() {
	  'use strict';
	  window.addEventListener('load', function() {
	    // Fetch all the forms we want to apply custom Bootstrap validation styles to
	    var forms = document.getElementsByClassName('needs-validation');
	    // Loop over them and prevent submission
	    var validation = Array.prototype.filter.call(forms, function(form) {
	      form.addEventListener('submit', function(event) {
	        if (form.checkValidity() === false) {
	          event.preventDefault();
	          event.stopPropagation();
	        }
	        form.classList.add('was-validated');
	      }, false);
	    });
	  }, false);
	})();
	setTimeout(function(){
        $('.select01').append('<div class="invalid-tooltip">Please Select Job Title</div>'); 
    }, 1000);


    // validation
    (function() {
      'use strict';
      window.addEventListener('load', function() {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
          form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
              event.preventDefault();
              event.stopPropagation();
            }
            form.classList.add('was-validated');
            $('.btn_loader').css('display', 'inline-block');
            setTimeout(function () {
                $('.btn_loader').css('display', 'none');
            }, 2000);

            $('.d-n').css('opacity', '0.1');
            setTimeout(function () {
                $('.d-n').css('opacity', '1');
            }, 2000);
          }, false);
        });
      }, false);
    })();


   $('#datetimepicker').datetimepicker({ 
   		format: 'L', 
   		widgetPositioning: {
            horizontal: 'right',
            vertical: 'bottom'
        },
   		
   })

	$(document).ready(function(){
	  $('input').focusin(function() {
	    $(this).parent().addClass('focused');
	  });
	  
	  $('input').focusout(function() {
	    $(this).parent().removeClass('focused');
	  });

	   $(".enter_answerlist ").mCustomScrollbar({
        	theme:"dark",
		    axis:"x",
		});
	  
	});


    $('#addmore').click(function() {
        $('.enter_answerlist ul').prepend('<li class="list-inline-item"><div class="input-field"><input type="text" placeholder="Enter Answer"><a href="javascript:void(0);" class=" icon" ><i class="fas fa-trash-alt"></i></a></div></li>');
		 $(".enter_answerlist").mCustomScrollbar("update");
    });

    
    // 
    $("#add_btn").click(function(){
	    $(".add_question .option").show( '2000');
	    $("#edit_q").show( '2000');
	    $(".edit_question .option").hide( '2000');
	});
	$("#remove").click(function(){
	    $(".add_question .option").hide( '2000');
	    $("#edit_q").show( '2000');
	});

	$("#edit_btn").click(function(){
	    $("#edit_q").hide( '2000');
	    $(".add_question .option").hide( '2000');
	    $(".edit_question .option").show( '2000');
	});
	$(".edit_question .action_btn a").click(function(){
	    $(".edit_question .option").hide( '2000');
	    $("#edit_q").show( '2000');
	});
	$("#jobcard").click(function(){
	    $(".job_preview .job-block").toggle( '2000');
	});

	$("#weburl_btn").click(function(){
	    $("#website_field").show( '2000');
	});
	$("#fafaccount_btn").click(function(){
	      $("#website_field").hide( '2000');
	  });
	// 
	
	</script>
</body>
</html>