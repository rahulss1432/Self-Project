<div class="righttoggle_btn">
    <a href="javascript:void(0);"></a>
</div>
<div class="inner_section" >
    @if($page == 'events' )  
    @if(!empty(Auth::guard(getAuthGuard())->check()))
    <div class="btn_top">
        <a href="{{ url('player/event-add') }}" class="search-btn"><i class="fas fa-plus"></i> Add Event</a>
    </div>
    <div class="clearfix"></div>
    @endif
    @endif
    @if($page == 'jobs')
    @if(getAuthGuard() == 'team')
    <div class="btn_top">
        <a href="{{ url('team/job-add') }}" class="search-btn"><i class="fas fa-plus"></i> Create Job</a>
    </div>
    @endif
    @endif  
    @if($page != 'search')
    @if(!empty(Auth::guard(getAuthGuard())->check())) <!-- Checking guest user-->
    <form id="search-player" action="javascript:void(0);" method="GET" >
        {{ csrf_field() }}
        <div class="search">
            <div class="input-group">

                <input type="text" name="txtSearch" id="txtSearch" class="form-control" placeholder="Search" maxlength="20">
                <div class="input-group-append">
                    <button class="search-btn" type="submit" id="common-search"><i class="fas fa-search"></i></button>
                    <a href="{{ url('advance-filter') }}">ADVANCED</a>
                </div>


            </div>
        </div>
    </form>
    @endif
    @endif
    {!! JsValidator::formRequest('App\Player\Http\Requests\SearchRequest','#search-player') !!}
    @if($page == 'dashboard')
    <div class="jobs-dtlwrap">
        <div class="new_job">
            <div class="block-head">
                <div class="heading">
                    <span class="ico icon-old-fashion-briefcase">
                    </span>
                    <span>NEW JOB</span>
                </div>
            </div>
            <div class="ajax_list_load">
                <div id="newjoblist"></div>
            </div>

           
        </div>
        <div class="block-head yourjobs">
            <div class="heading">
                <span class="ico"><img src="{{ url('public/images/check-circle.png') }}" alt="icon"></span>
                <span>YOUR APPLIED JOBS</span>
            </div>
        </div>

        <div class="ajax_list_load">
            <div id="appliedjoblist"></div>
        </div>
    </div>
    @elseif($page != 'member-you-know' && $page != 'connection_list' && $page != 'friend_request_list' && $page != 'events' && $page != 'jobs' && $page != 'search')
    @if(!empty($slug))
    <div class="how-connected">
        <ul class="list-inline heading">
            <li class="list-inline-item">
                <span class="ico"><i class="icon-business-affiliate-network"></i></span>
            </li>
            <li class="list-inline-item">
                <h2>
                    <span>HOW YOU ARE</span> <br>
                    CONNECTED
                </h2>
            </li>
        </ul>
        <div class="connect-timeline" id="divMutualFriendsList">

        </div>

    </div>

    @else
    <div class="prodip">
        <a href="https://prodip.pro/password" target="_blank">
            <img src="{{url('public/images/prodip_img.png')}}" alt="prodip" class="img-fluid">
        </a>
    </div>    

    @endif
    @endif
    @if($page != 'member-you-know' && $page != 'connection_list' && $page != 'friend_request_list' && $page != 'events' && $page != 'jobs' && $page != 'search')
    <div class="connections">
        <div class="block-head">
            <div class="heading text-center">
                <span class="ico icon-connection"><!-- <img src="{{ url('public/images/connection.png') }}" alt="icon"> --></span>
                <span>CONNECTIONS</span>
                <!-- <h2>712</h2> -->
            </div>
        </div>
        <div class='alert alert-danger w-70 mt-md-5 mt-3' id='divNoConnection' style="display: none;">No Connection Found!</div>        
        <div class="conection-list">
            <ul class="list-inline position-relative" id="user-connections-list">

            </ul>
            <div class="text-center view_btn" id="connection_view">
                @if(!empty($slug))
                <a href="{{ url('player/connections/'.$slug) }}">View All</a>
                @else
                <a href="{{ url('player/connections') }}">View All</a>
                @endif
            </div>
        </div>

    </div>
    @endif

    @if(($page == 'dashboard') || ($page == 'player-timeline')) 
    <div class="social-connection">
        <div class="social-block">
            <div class="content">
                <a class="twitter-timeline" data-width="341" data-height="300" href="https://twitter.com/fafproday?ref_src=twsrc%5Etfw">Tweets by fafproday</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
            </div>
            <div class="right_loader">
                <div class="border_loader">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
            <div class="left_loader">
                <div class="border_loader">
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
            <div class="social_caption">
                <div class="social-icon">
                    <a href="javascript:void(0);"><img src="{{ url('public/images/twitter_icon.png') }}" alt="icon"></a>
                </div>
                <div class="social-name text-center">
                    <a href="javascript:void(0);" class="d-block">TWITTER</a>
                </div>
            </div>
        </div>
        <div class="social-block">
            <div class="content">
                <div class="fb-page" data-href="https://www.facebook.com/FreeAgentFootball" data-tabs="timeline" data-width="341" data-height="300" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/FreeAgentFootball" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/FreeAgentFootball">FreeAgentFootball.com</a></blockquote></div>
                <!--<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FFreeAgentFootball&tabs=timeline&width=250&height=300&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=1664434403824350" width="250" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>-->

            </div>
            <div class="right_loader">
                <div class="border_loader">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
            <div class="left_loader">
                <div class="border_loader">
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
            <div class="social_caption">
                <div class="social-icon">
                    <a href="javascript:void(0);"><img src="{{ url('public/images/facebook_icon.png') }}" alt="icon"></a>
                </div>
                <div class="social-name text-center">
                    <a href="javascript:void(0);" class="d-block">FACEBOOK</a>
                </div>
            </div>
        </div>

        <div class="social-block">
            <div class="content">
                <div class="instgram_post mx-auto bg-white">
                    <div id="instgramPost"></div>
                </div>
            </div>
            <div class="right_loader">
                <div class="border_loader">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
            <div class="left_loader">
                <div class="border_loader">
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
            <div class="social_caption">
                <div class="social-icon">
                    <a href="javascript:void(0);"><img src="{{ url('public/images/instagram_icon.png') }}" alt="icon"></a>
                </div>
                <div class="social-name text-center">
                    <a href="javascript:void(0);" class="d-block">INSTAGRAM</a>
                </div>
            </div>
        </div>
    </div>
    @endif

    @if($page == 'member-you-know' || $page == 'connection_list' || $page == 'friend_request_list' || $page == 'events' || $page == 'jobs' || $page == 'search')   <!-- member you may know page only filter and facebook feed show-->
    <div class="facebook_post">
        <div class="fb-page" data-href="https://www.facebook.com/FreeAgentFootball" data-tabs="timeline" data-width="288" data-height="2099" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/FreeAgentFootball" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/FreeAgentFootball">FreeAgentFootball.com</a></blockquote></div>
        <!--<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FFreeAgentFootball&tabs=timeline&width=274&height=2099&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=1664434403824350" width="274" height="2099" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>-->

    </div>
    @endif
</div>
<script>

$(document).on('submit', '#search-player', function (e) {
    e.preventDefault();
    var formData = $('#txtSearch').val();
    var encodedString = btoa(formData);
   
    var url = "{{ url('/search') }}" + '/'+encodedString;
     window.location.href = url;
});
// instagram feed listing
$(document).ready(function () {
    setTimeout(function(){
    getInstagrampostList();
    }, 1000);
});
function getInstagrampostList() {
    pageLoader('instgramPost', 'show')
    var url = "{{ url('get-instagram-feed') }} ";
    $.ajax({type: "GET", url: url,
        success: function (response) {
            $("#instgramPost").html("");
            $("#instgramPost").html(response.html);
        },error:function(){
            getInstagrampostList();
        }
    });
}
</script>

