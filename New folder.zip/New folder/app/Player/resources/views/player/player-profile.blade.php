@extends('player::layouts.app')

@section('content')

<main class="main-content  ">
    <div class="mainframe_border">
        <div class="borderheight" id="borderheight"></div>
    </div>

    <!-- profile information -->
    <section class="profile_information">
        <!--  left side -->
        <aside class="left_section" id="left-side-html">
            <!-- left side html render -->
        </aside>
        <!--  middle section -->
        <div class="middle_section">
            <div class="container-fluid">
                <div class="news_point">
                    <div class="inner">
                        <div class="newsheading">
                            <p><span class="headingtag">NEWS</span></p> <div class="newsline"><span id="newsBulletin"></span></div>
                            <a href="{{ url('/news-details') }}">(READ MORE)</a>
                        </div>                        
                        <div class="news_tag" id="all_player_counts">

                        </div>
                    </div>
                </div>
                <div id="divVideoUserViews">
                </div>
            </div>
        </div>
        <!-- right side -->
        <aside class="right_section" id="right-side-html">
            <!-- right side html render  -->
        </aside> 
    </section>

    <!-- profile status -->
    <section class="profile_status">
        <div class="container-fluid">
            <div class="compare-row d-flex align-items-end">
                <div class="left-sec">
                    <img src="{{ url('public/images/frames-bg/compare-profile-left-corner.png') }}" alt="compare-profile-row-bg" class="img-fluid">
                </div>
                <div class="center-sec">
                    <div class="center d-flex align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item">
                                <a href="{{url('/view/compare')}}">compare profile</a>
                            </li>
                            <li class="list-inline-item">
                                <a href="javascript:void(0);" onclick="KeyStats()">Key stats</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="right-sec">
                    <h2 class="text-center">
                        <span class="text-uppercase">PROFILE LAST UPDATED</span> <br>
                        {{sameDate($user->updated_at)}}
                    </h2>
                </div>
            </div>
        </div>
    </section>

    <!-- compare profile -->
    <section class="compare_profile">
        <div class="left">
            <div class="about_us">
                <div class="heading text-center">
                    <div class="icon">
                        <img src="{{ url('public/images/about_icon.png') }}" alt="icon">
                    </div>
                    <h3 class="heading-24">ABOUT</h3>
                    <div class="edit_icon">
                        <a href="{{ url('player/player-profile-form') }}" oncontextmenu="onRightClickMenu('about')" onclick="sendPlayerStep('about');">
                            <i class="fas fa-edit"></i>
                        </a>
                    </div>
                </div>
                <ul class="list-unstyled">
                    <li>
                        <label>STATE/PROVINCE</label>
                        <h4>{{!empty($user->state)? $user->state->state_name : '-' }}</h4>
                    </li>
                    <li>
                        <label>YEARS OF PLAYING EXPERIENCE</label>
                        <h4>{{!empty($user->userGeneral->playing_exp) ? $user->userGeneral->playing_exp : '-'}}</h4>
                    </li>
                    <li>
                        <label>CURRENTLY UNDER CONTRACT</label>
                        <h4>{{ !empty($user->userGeneral->under_contract) ? ucfirst($user->userGeneral->under_contract) : 'No'}}</h4>
                    </li>
                    <li>
                        <label>LOOKING TO SIGN</label>
                        <h4>{{!empty($user->userGeneral->look_to_sign) ? $user->userGeneral->look_to_sign:'-'}}</h4>
                    </li>
                    <li>
                        <label>CURRENT TEAM</label>
                        <h4>{{ !empty($user->userGeneral->current_team) ?  ucfirst($user->userGeneral->current_team) : '-'}}</h4>
                    </li>
                    <li>
                        <label>CURRENT LEAGUE or CONFERENCE</label>
                        <h4>{{!empty($user->userGeneral->current_league) ? ucfirst($user->userGeneral->current_league) : '-'}} </h4>
                    </li>
                    <li>
                        <label>FORMER TEAM</label>
                        <h4>{{ !empty($user->userGeneral->former_team)? ucfirst($user->userGeneral->former_team) : '-'}}</h4>
                    </li>
                    <li>
                        <label>FORMER LEAGUE or CONFERENCE</label>
                        <h4>{{!empty($user->userGeneral->former_league) ? ucfirst($user->userGeneral->former_league) : '-'}}</h4>
                    </li>
                    <li>
                        <label>PASSPORT READY</label>
                        <h4>{{!empty($user->userGeneral->passport) ? ucfirst($user->userGeneral->passport) : 'No'}}</h4>
                        <h4><h4>{{!empty($user->userGeneral->country) ? $user->userGeneral->country->name : '-'}}</h4></h4>
                    </li>
                    <li>
                        <label>NATIVE LANGUAGE</label>
                        <h4>{{!empty($user->userGeneral->nativeLanguage) ? ucfirst($user->userGeneral->nativeLanguage->language) : '-'}}</h4>
                    </li>
                    <li>
                        <label>SECONDARY LANGAGE</label>
                        <h4>{{!empty($user->userGeneral->secondaryLanguage) ? ucfirst($user->userGeneral->secondaryLanguage->language) : '-'}}</h4>
                    </li>
                    <li>
                        <label>PREP/COLLEGE EXPERIENCE</label>
                        <h4>@if(empty($user->userCollegeExperince[0])){{ 'No'}} @else {{ 'Yes'}} @endif </h4>
                        @if(!empty($user->userCollegeExperince[0]))
                        <h4>{{!empty($user->userCollegeExperince[0]) ? $user->userCollegeExperince[0]['experience_type'] : '-'}}</h4>
                        <h4>{{!empty($user->userCollegeExperince[0]) ? $user->userCollegeExperince[0]['from_year'] .'-'. $user->userCollegeExperince[0]['to_year'] : '-'}} </h4>   
                        @endif
                        @if(!empty($user->userCollegeExperince) && count($user->userCollegeExperince) > 1)
                        <div class="seeall_btn mt-1">
                            <a href="javascript:void(0);" class="btn btn-success btn-sm border-1" onclick="getExperienceList('college_experience')">SEE ALL</a>
                        </div>
                        @endif
                    </li>
                    <li>
                        <label>PRO EXPERIENCE</label>
                        <h4>@if(empty($user->userProExperince[0])){{ 'No'}} @else {{ 'Yes'}} @endif </h4>
                        @if(!empty($user->userProExperince[0]))
                        <h4>{{!empty($user->userProExperince) ? $user->userProExperince[0]['experience_type'] : '-'}}</h4>
                        <h4>{{ !empty($user->userProExperince) ? $user->userProExperince[0]['from_year'] .'-'. $user->userProExperince[0]['to_year'] : '-'}} </h4>   
                        @endif
                        @if(!empty($user->userProExperince) && count($user->userProExperince) > 1)
                        <div class="seeall_btn mt-1">
                            <a href="javascript:void(0);" class="btn btn-success btn-sm border-1" onclick="getExperienceList('user_pro')">SEE ALL</a>
                        </div>
                        @endif
                    </li>
                    <li>
                        <label>INTERNATIONAL EXPERIENCE</label>
                        <h4>@if(empty($user->userInternationalExperince[0])){{ 'No'}} @else {{ 'Yes'}} @endif </h4>
                        @if(!empty($user->userInternationalExperince[0]))
                        <h4>{{!empty($user->userInternationalExperince) ? getLevelName($user->userInternationalExperince[0]['experience_type']) : '-'}}</h4>
                        <h4> {{!empty($user->userInternationalExperince)  ?  $user->userInternationalExperince[0]['from_year'] .'-'. $user->userInternationalExperince[0]['to_year'] : '-'}} </h4>   
                        @endif
                        @if(!empty($user->userInternationalExperince) && count($user->userInternationalExperince) > 1)
                        <div class="seeall_btn mt-1">
                            <a href="javascript:void(0);" class="btn btn-success btn-sm border-1" onclick="getExperienceList('user_international')">SEE ALL</a>
                        </div>
                        @endif
                    </li>
                    <li>
                        <label>INDOOR EXPERIENCE</label>
                        <h4>@if(empty($user->userIndooreExperince[0])){{ 'No'}} @else {{ 'Yes'}} @endif </h4>
                        @if(!empty($user->userIndooreExperince[0]))
                        <h4>{{!empty($user->userIndooreExperince) ? getLevelName($user->userIndooreExperince[0]['experience_type']) : '-'}}</h4>
                        <h4> {{!empty($user->userIndooreExperince) ? $user->userIndooreExperince[0]['from_year'] .'-'.    $user->userIndooreExperince[0]['to_year'] : '-'}} </h4>   
                        @endif
                        @if(!empty($user->userIndooreExperince) && count($user->userIndooreExperince) > 1)
                        <div class="seeall_btn mt-1">
                            <a href="javascript:void(0);" class="btn btn-success btn-sm border-1" onclick="getExperienceList('user_indoor')">SEE ALL</a>
                        </div>
                        @endif
                    </li>
                </ul>
            </div>
        </div>
        <div class="middle_section">
            <div class="container-fluid">
                <div class="biography ml-auto mr-auto">
                    <div class="common_heading">
                        <h3 class="black black-lg">
                            BIOGRAPHY
                        </h3>
                    </div>
                    <p class="text-justify ">
                        {{!empty($user->bio) ? $user->bio : '-'}}
                    </p>
                </div>
                <div class="experience-section">
                    <div class="common_heading">
                        <h3 class="black black-lg">
                            UPCOMING EVENTS
                        </h3>
                    </div>
                    @if(count($upcoming_events)>0)
                    <div class="row">
                        @foreach($upcoming_events as $event)
                        <div class="col-6 col-sm-4">
                            <a href="{{ url('/event/'.base64_encode($event->id)) }}">
                                <div class="event_card">
                                    <p class="status">{{ date('m/d/Y', strtotime($event->start_date)) }}</p>
                                    <h6 class="title">{{getLimitText(10,$event->event_name)}}</h6>
                                    <div class="events_team d-flex justify-content-center text-center">
                                        <div class="team_box">
                                            <div class="img_box d-flex align-items-center">
                                                @if (intval($event->team1))
                                                <img src="{{ checkUserImage(getUserById($event->team1,'profile_image'), 'team') }}" alt="olaf-flag">
                                                @else
                                                <img src="{{ checkUserImage(getTeamLogo($event->team1), 'team') }}" alt="olaf-flag">
                                                @endif
                                            </div>
                                            @if (intval($event->team1))
                                            <p class="mb-0">{{ !empty($event->team1Data->full_name) ? getLimitText(5,$event->team1Data->full_name) : '-' }}</p>
                                            @else
                                            <p class="mb-0">{{ getLimitText(5,$event->team1) }}</p>
                                            @endif
                                        </div>                                        
                                        <div class="vs">VS</div>
                                        <div class="team_box">
                                            <div class="img_box d-flex align-items-center">
                                                @if (intval($event->team2))
                                                <img src="{{ checkUserImage(getUserById($event->team2,'profile_image'), 'team') }}" alt="gac-flag">
                                                @else
                                                <img src="{{ checkUserImage(getTeamLogo($event->team2), 'team') }}" alt="gac-flag">
                                                @endif
                                            </div>
                                            @if (intval($event->team2))
                                            <p class="mb-0">{{ !empty($event->team2Data->full_name) ? getLimitText(5,$event->team2Data->full_name) : '-' }}</p>
                                            @else
                                            <p class="mb-0">{{ getLimitText(5,$event->team2) }}</p>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="info">
                                        <p class="label">Time</p>
                                        <p>{{ getTimeFormat($event->start_time) }} (EST)</p>
                                    </div>
                                    <div class="info">
                                        <p class="label">Location</p>
                                        <p>{{ getLimitText(20,$event->address1) }}</p>
                                    </div> 
                                    <div class="info">
                                        <p class="label">Website</p>
                                        <p class="url">{{ getLimitText(15,$event->ticket_url) }}</p>
                                    </div> 
                                    <div class="bottom_loader">
                                        <div class="border_loader">
                                            <div></div>
                                            <div></div>
                                            <div></div>
                                            <div></div>
                                            <div></div>
                                            <div></div>
                                            <div></div>
                                            <div></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        @endforeach
                    </div>
                     @else
                    <div class="alert alert-danger text-center">No record found.</div>
                    @endif
                </div>
                <div class="validated_attributes">
                    <div class="common_heading">
                        <h3 class="black black-lg">
                            VALIDATED ATTRIBUTES
                        </h3>
                    </div>
                    <!--                     Attribute List-->
                    <div class="attributes_content">
                        <div class="heading d-inline-block text-center">
                            <h6>RELATIVE TO POSITION</h6>
                            <h2>{{getPositionName($user->position_id)}}</h2>
                        </div>
                        <div id="get-attribute-list">

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="right">
            <!--            <div class="key_stats">
                            <div class="heading text-center">
                                <div class="icon">
                                    <img src="{{ url('public/images/key_icon.png') }}" alt="icon">
                                </div>
                                <h3 class="heading-24">KEY STATS</h3>
                            </div>
                            <div class="stats_info">
                                <h4>Current Season</h4>
                                <ul class="list-unstyled">
                                    <li>-{{!empty($user->userCurrentSeason->total_all_purpose) ? $user->userCurrentSeason->total_all_purpose : 0}} All-Purpose Yards</li>
                                    <li>- {{!empty($user->userCurrentSeason->total_receiving) ? $user->userCurrentSeason->total_receiving : 0}} Receiving Yards</li>
                                    <li>- {{!empty($user->userCurrentSeason->tuchdowns) ? $user->userCurrentSeason->tuchdowns : 0}} Touchdowns</li>
                                </ul>
                            </div>
                            <div class="stats_info">
                                <h4>Last Season</h4>
                                <ul class="list-unstyled">
                                    <li>- {{!empty($user->userPastSeason->total_all_purpose) ? $user->userPastSeason->total_all_purpose : 0}} All-Purpose Yards</li>
                                    <li>- {{!empty($user->userPastSeason->total_interception) ? $user->userPastSeason->total_interception : 0}} Interceptions</li>
                                    <li>- {{!empty($user->userPastSeason->tackles) ? $user->userPastSeason->tackles : 0}} Tackles</li>
                                    <li>- {{!empty($user->userPastSeason->tuchdowns) ? $user->userPastSeason->tuchdowns : 0}}  Touchdowns</li>
                                </ul>
                            </div>
                            <div class="stats_info">
                                <h4>Career</h4>
                                @php
                                $collection = collect($user->userKeyStats);
                                @endphp
                                <li>- {{!empty($user->userKeyStats) ? $collection->sum('games_played') : 0 }} Games</li>
                                <li>- {{!empty($user->userKeyStats) ? $collection->sum('tuchdowns') : 0 }} Touchdowns</li>
                                <li>- {{!empty($user->userKeyStats) ? $collection->sum('tackles') : 0 }} Tackles</li>
                                <li>- {{!empty($user->userKeyStats) ? $collection->sum('total_all_purpose') : 0 }}  All Purpose Yards</li>                    
                            </div>
                        </div>-->
            <div class="social-connection">
                <div class="social-block">
                    <div class="content">
                        <a class="twitter-timeline" data-width="341" data-height="300" href="https://twitter.com/fafproday?ref_src=twsrc%5Etfw">Tweets by fafproday</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                    </div>
                    <div class="right_loader">
                        <div class="border_loader">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                    <div class="left_loader">
                        <div class="border_loader">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                    <div class="social_caption">
                        <div class="social-icon">
                            <a href="javascript:void(0);"><img src="{{ url('public/images/twitter_icon.png') }}" alt="icon"></a>
                        </div>
                        <div class="social-name text-center">
                            <a href="javascript:void(0);" class="d-block">TWITTER</a>
                        </div>
                    </div>
                </div>
                <div class="social-block">
                    <div class="content">
                        <div class="fb-page" data-href="https://www.facebook.com/FreeAgentFootball" data-tabs="timeline" data-width="341" data-height="300" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/FreeAgentFootball" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/FreeAgentFootball">FreeAgentFootball.com</a></blockquote></div>
                        <!--<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FFreeAgentFootball&tabs=timeline&width=271&height=300&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=1664434403824350" width="271" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>-->

                    </div>
                    <div class="right_loader">
                        <div class="border_loader">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                    <div class="left_loader">
                        <div class="border_loader">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                    <div class="social_caption">
                        <div class="social-icon">
                            <a href="javascript:void(0);"><img src="{{ url('public/images/facebook_icon.png') }}" alt="icon"></a>
                        </div>
                        <div class="social-name text-center">
                            <a href="javascript:void(0);" class="d-block">FACEBOOK</a>
                        </div>
                    </div>
                </div>
                <div class="social-block">
                    <div class="content">
                        <div id="instgramPost" class="instgram_post mx-auto bg-white"></div>
                    </div>
                    <div class="social_caption">
                        <div class="social-icon">
                            <a href="javascript:void(0);"><img src="{{ url('public/images/instagram_icon.png') }}" alt="icon"></a>
                        </div>
                        <div class="social-name text-center">
                            <a href="javascript:void(0);" class="d-block">INSTAGRAM</a>
                        </div>
                    </div>


                </div>
                <!--                <div class="social-block">
                                    <div class="content">
                                                                              
                                    </div>
                                    <div class="right_loader">
                                        <div class="border_loader">
                                            <div></div>
                                            <div></div>
                                            <div></div>
                                            <div></div>
                                            <div></div>
                                        </div>
                                    </div>
                                    <div class="left_loader">
                                        <div class="border_loader">
                                            <div></div>
                                            <div></div>
                                            <div></div>
                                        </div>
                                    </div>
                                    <div class="social_caption">
                                        <div class="social-icon">
                                            <a href="javascript:void(0);"><img src="{{ url('public/images/linkedin_icon.png') }}" alt="icon"></a>
                                        </div>
                                        <div class="social-name text-center">
                                            <a href="javascript:void(0);" class="d-block">LINKEDIN</a>
                                        </div>
                                    </div>
                                </div>-->
            </div>
        </div> 

    </section>

    <!-- third profile status -->
    <section class="thirdprofile_status secondprofile_status">
        <div class="container-fluid">
            <div class="compare-row d-flex align-items-end">
                <div class="left-sec">
                    <div class="details">
                        <div class="imgdiv"> 
                            <img  class="rounded-circle" src="{{ checkUserImage($user->profile_image, 'player/thumb') }}" alt="player img">
                        </div> 
                        <div class="caption text-center">
                            <h4 class="color-white">{{ucfirst($user->full_name)}}</h4>
                            <h3 class="color-green">{{getPositionName($user->position_id)}}</h3>
                        </div>
                    </div>
                </div>
                <div class="center-sec">
                    <div class="center">
                        <h6 class="color-white "><span>{{ getLimitText(50, $latest_news )}}... </span><a href="{{ url('/news-details') }}">(READ MORE)</a>.</h6>
                    </div>
                </div>
                <div class="right-sec">
                    @if(!empty($playerMeasurable->certifier) && !empty($playerMeasurable->email_link))
                    <div class="verified text-right">
                        <a href="javascript:void(0);" class="btn btn-dark"> 
                            <i class="icon"> <img src="{{ url('public/images/turnoff_icon.svg') }}" alt="icon"></i> VERIFIED
                        </a>
                        <div class="caption">
                            <p>Verifier: {{$playerMeasurable->certifier}}</p>
                            <p>Email: {{$playerMeasurable->email_link}}</p>
                        </div>
                    </div>
                    @else
                    <div class="unverified text-right">
                        <a href="javascript:void(0);" class="btn btn-dark"> 
                            <i class="icon"> <img src="{{ url('public/images/turnoff_icon.svg') }}" alt="icon"></i> UNVERIFIED
                        </a>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </section>
    <!-- eduction -->
    <section class="eduction_section">
        <ul class="list-unstyled bar-animation d-none d-sm-block">
            <li>
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>

            <li>
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>

            <li>
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li class="d-none d-lg-block">
                <ul class="list-unstyled bars-left bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
        </ul>

        <!-- bars right -->
        <ul class="list-unstyled bar-animation bar-animation-right d-none d-sm-block">
            <li>
                <ul class="list-unstyled bars-right bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-right bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>

            <li>
                <ul class="list-unstyled bars-right bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>

            <li>
                <ul class="list-unstyled bars-right bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-right bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-right bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-right bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-right bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-right bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-right bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li>
                <ul class="list-unstyled bars-right bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
            <li class="d-none d-lg-block">
                <ul class="list-unstyled bars-right  bar-wrap">
                    <li class="bar"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                    <li class="bar bar-short"></li>
                </ul>
            </li>
        </ul>

        <div class="container-1800">
            <div class="inner-wrap">
                <div class="common_heading position-relative  mt-0">
                    <h3 class="black black-lg h_black">
                        EDUCATION
                    </h3>
                    <h3 class="black gray-lg color-white h-white">
                        EDUCATION
                    </h3>
                    <div class="edit_icon icon_center">
                        <a href="{{ url('player/player-profile-form') }}" oncontextmenu="onRightClickMenu('about')" onclick="sendPlayerStep('about')">
                            <i class="fas fa-edit"></i>
                        </a>
                    </div>
                </div>
                <?php if (!empty($user->userEducationExperience)) { ?>
                    <ul class="list-inline text-center card-wrap">
                        <?php for ($i = 0; $i < 3; $i++) { ?>
                            <li class="list-inline-item list">
                                <img src="{{(!empty($user->userEducationExperience[$i]->logo)) ? checkUserImage($user->userEducationExperience[$i]->logo, 'player/thumb','logo') : url('public/images/community_icon.svg') }}" alt="icon">
                                <h3>{{(!empty($user->userEducationExperience[$i]->name)) ? getLimitText(20,$user->userEducationExperience[$i]->name) : 'add info'}}</h3>
                                <h6>{{(!empty($user->userEducationExperience[$i]->degree_name)) ? getLimitText(20,$user->userEducationExperience[$i]->degree_name) : '-'}}</h6>
                                <p>{{(!empty($user->userEducationExperience[$i]->from_year)) ? $user->userEducationExperience[$i]->from_year : '-'}} - {{(!empty($user->userEducationExperience[$i]->to_year)) ? $user->userEducationExperience[$i]->to_year : '-'}}</p>
                            </li>
                        <?php } ?>
                    </ul>        
                <?php } if (count($user->userEducationExperience) > 3) { ?>
                    <div class="text-center seeall_btn mt-xl-4 mt-3">
                        <a href="javascript:void(0);" class="btn btn-success btn-sm border-1 p-6-15 font-14" id="ee" onclick="getMoreResults('education_experience', 'ee')">SEE ALL</a>
                    </div>
                <?php } ?>        
            </div>
        </div>
    </section>

    <!-- measurables -->
    <section class="measurables">
        <div class="container-1800">
            <div class="common_heading position-relative  mt-0">
                <h3 class="black gray-lg color-white">
                    MEASURABLES
                </h3>
                <div class="edit_icon icon_center color_white">
                    <a href="{{ url('player/player-profile-form') }}" oncontextmenu="onRightClickMenu('measurables')" onclick="sendPlayerStep('measurables')">
                        <i class="fas fa-edit"></i>
                    </a>
                </div>
            </div>
            <div class="detail-wrap">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="left">
                            <div class="info-circle one"> 
                                <div class="circle-in">
                                    <div class="content">
                                        <p>HEIGHT</p>
                                        <h2>{{!empty($user->userMeasurables->height_ft) ? $user->userMeasurables->height_ft : 0 }}'{{ !empty($user->userMeasurables->height_in) ? $user->userMeasurables->height_in : 0 }}''</h2>
                                        <span>FEET/IN</span>
                                    </div>
                                </div>
                            </div>
                            <div class="info-circle two"> 
                                <div class="circle-in">
                                    <div class="content">
                                        <p>BENCH <br> <span>in Reps</span></p>
                                        <h2>{{!empty($user->userMeasurables->bench) ? $user->userMeasurables->bench : '-' }}</h2>
                                    </div>
                                </div>
                            </div>
                            <div class="info-circle three"> 
                                <div class="circle-in">
                                    <div class="content">
                                        <p>40</p>
                                        <h2>{{!empty($user->userMeasurables->fourty) ? $user->userMeasurables->fourty : '-'}}</h2>
                                        <span>SECONDS</span>
                                    </div>
                                </div>
                            </div>
                            <div class="info-circle four"> 
                                <div class="circle-in">
                                    <div class="content">
                                        <p>PRO <br> SHUTTLE</p>
                                        <h2>{{!empty($user->userMeasurables->pro_shuttle) ? $user->userMeasurables->pro_shuttle : '-' }}</h2>
                                        <span>SECONDS</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 d-none d-sm-block">
                        <div class="center-caracter">
                            <div class="in">
                                <img src="{{ url('public/images/profile-caracter.png') }}" alt="player ">
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="right">
                            <div class="info-circle one"> 
                                <div class="circle-in">
                                    <div class="content">
                                        <p>WEIGHT</p>
                                        <h2>{{!empty($user->userMeasurables->weight) ? $user->userMeasurables->weight : '-'}}</h2>
                                        <span>LBS</span>
                                    </div>
                                </div>
                            </div>
                            <div class="info-circle two"> 
                                <div class="circle-in">
                                    <div class="content">
                                        <p>HAND SIZE</p>
                                        <h2>{{!empty($user->userMeasurables->hand_size) ? $user->userMeasurables->hand_size : '-'}}</h2>
                                        <span>INCHES</span>
                                    </div>  
                                </div>
                            </div>
                            <div class="info-circle three"> 
                                <div class="circle-in">
                                    <div class="content">
                                        <p>VERT</p>
                                        <h2>{{!empty($user->userMeasurables->vert) ? $user->userMeasurables->vert : '-' }}</h2>
                                        <span>INCHES</span>
                                    </div> 
                                </div>
                            </div>
                            <div class="info-circle four"> 
                                <div class="circle-in">
                                    <div class="content">
                                        <p>COLLEGE <br> SHUTTLE</p>
                                        <h2>{{!empty($user->userMeasurables->collegiate_shuttle) ? $user->userMeasurables->collegiate_shuttle : '-' }}</h2>
                                        <span>SECONDS</span>
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="accolades_section">
        <div class="container-1800">
            <div class="frame_bg">
                <div class="left_loader">
                    <div class="border_loader">
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                </div>
                <div class="common_heading position-relative">
                    <h3 class="black gray-lg color-white">
                        ACCOLADES
                    </h3>
                    <div class="edit_icon icon_center color_white">
                        <a href="{{ url('player/player-profile-form') }}" oncontextmenu="onRightClickMenu('about')" onclick="sendPlayerStep('about');">
                            <i class="fas fa-edit"></i>
                        </a>
                    </div>
                </div>
                <?php if (!empty($user->userAccoladesExperince)) { ?>
                    <ul class="list-inline text-center card-wrap">
                        <?php for ($i = 0; $i < 3; $i++) { ?>
                            <li class="list-inline-item list">
                                <img src="{{(!empty($user->userAccoladesExperince[$i]->logo))?checkUserImage($user->userAccoladesExperince[$i]->logo, 'player/thumb','logo'): url('public/images/cairo_icon.svg') }}" alt="icon">
                                <h3 class="color-green">{{(!empty($user->userAccoladesExperince[$i]->name)) ? getLimitText(10,$user->userAccoladesExperince[$i]->name) : 'add info'}}</h3>
                                <h6 class="color-white">{{(!empty($user->userAccoladesExperince[$i]->present_organization)) ? getLimitText(10,$user->userAccoladesExperince[$i]->present_organization) : '-'}}</h6>
                                <p class="color-green">{{(!empty($user->userAccoladesExperince[$i]->present_year)) ? $user->userAccoladesExperince[$i]->present_year:'-'}}</p>
                            </li>
                        <?php } ?>
                    </ul>
                <?php } if (count($user->userAccoladesExperince) > 3) { ?>
                    <div class="text-center seeall_btn mt-xl-4 mt-3">
                        <a  href="javascript:void(0);" class="btn btn-success btn-sm border-1 p-6-15 font-14" id="ac" onclick="getMoreResults('accolades', 'ac')">SEE ALL</a>
                    <?php } ?>
                </div>
            </div>    
    </section>

    <!-- logo present -->
    <section class="logo_present text-center">
        <img class="img-fluid" src="{{ url('public/images/logo_present.png') }}" alt=" logo present">
    </section>

    <!-- desired benefits -->
    <section class="desired_benefits">
        <div class="container-1800">
            <div class="common_heading position-relative  mt-0">
                <h3 class="black gray-lg color-white">
                    DESIRED BENEFITS
                    <div class="edit_icon icon_center color_white">
                        <a href="{{ url('player/player-profile-form') }}" oncontextmenu="onRightClickMenu('desired-benefites')" onclick="sendPlayerStep('desired-benefits')">
                            <i class="fas fa-edit"></i>
                        </a>
                    </div>
                </h3>
                <div id="divDesiredBenifites">

                </div>
            </div>
        </div>
    </section>

    <!-- profile status -->
    <section class="secondprofile_status profile_status ">
        <div class="container-fluid">
            <div class="compare-row d-flex align-items-end">
                <div class="left-sec">
                    <img src="{{ url('public/images/frames-bg/compare-profile-left-corner.png') }}" alt="compare-profile-row-bg" class="img-fluid">
                </div>
                <div class="center-sec">
                    <div class="center ">
                        <h6 class="color-white "><span>...{{getLimitText(55,$latest_news)}}...</span><a href="{{ url('/news-details') }}">(READ MORE)</a>.</h6>
                    </div>
                </div>
                <div class="right-sec text-center">
                    <img class="img-fluid" src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'medium') }}" alt="flag">
                </div>
            </div>
        </div>
    </section>

    <!-- career achivements -->
    <section class="career_achivements"> 
        <div class="container-1800">
            <div class="common_heading position-relative  mt-0">
                <h3 class="black black-lg h_black">COACHING EXPERIENCE</h3>
                <div class="edit_icon icon_center">
                    <a href="{{ url('player/player-profile-form') }}" oncontextmenu="onRightClickMenu('about')" onclick="sendPlayerStep('about')">
                        <i class="fas fa-edit"></i>
                    </a>
                </div>
            </div>
            <?php if (!empty($user->userCoachingExperince)) { ?>
                <ul class="list-inline text-center mb-0">
                    <?php for ($i = 0; $i < 3; $i++) { ?>
                        <li class="list-inline-item list">
                            <span class="year">{{(!empty($user->userCoachingExperince[$i]->from_year))?$user->userCoachingExperince[$i]->from_year:'-'}}-{{(!empty($user->userCoachingExperince[$i]->to_year))?$user->userCoachingExperince[$i]->to_year:'-'}}</span>
                            <div class="team_logo">
                            <img src="{{(!empty($user->userCoachingExperince[$i]->logo))?checkUserImage($user->userCoachingExperince[$i]->logo, 'player/thumb','logo'): url('public/images/coachinglist_logo.png') }}" class="img-fluid" alt="logo">
                            </div>
                            <h5 class="mt-3 mb-3">{{(!empty($user->userCoachingExperince[$i]->name))?$user->userCoachingExperince[$i]->name:'ADD INFO'}}</h5>
                            <div class="form-group">
                                <label>Link to Team’s page/stats</label>
                               @if(!empty($user->userCoachingExperince[$i]->coaching_link)) <a href="{{$user->userCoachingExperince[$i]->coaching_link}}">{{$user->userCoachingExperince[$i]->coaching_link}}</a> @else {{'-'}} @endif
                            </div>
                            <div class="form-group">
                                <label>League/Conference</label>
                                <p>{{(!empty($user->userCoachingExperince[$i]->coching_league)) ? $user->userCoachingExperince[$i]->coching_league : '-'}}</p>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Country</label>
                                        <p>{{(!empty($user->userCoachingExperince[$i]->experienceCountry->name)) ? $user->userCoachingExperince[$i]->experienceCountry->name : '-'}}</p>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>State</label>
                                        <p>{{(!empty($user->userCoachingExperince[$i]->experienceState->state_name)) ? $user->userCoachingExperince[$i]->experienceState->state_name : '-'}}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Level</label>
                                        <p>{{(!empty($user->userCoachingExperince[$i]->experienceLevel->level_name)) ? $user->userCoachingExperince[$i]->experienceLevel->level_name : '-'}}</p>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Position Held</label>
                                        <p>{{(!empty($user->userCoachingExperince[$i]->position_held)) ? getLimitText(10,$user->userCoachingExperince[$i]->position_held) : '-'}}</p>                                        
                                    </div>
                                </div>
                            </div>
                            <div class="bottom_loader">
                                <div class="border_loader">
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                </div>
                            </div>
                            <p class="pra mb-0 text-left mt-3">
                                {{(!empty($user->userCoachingExperince[$i]->bio)) ? getLimitText(60,$user->userCoachingExperince[$i]->bio) : '-'}}                                                                    
                            </p>
                        </li>
                    <?php } ?>
                </ul>
                <?php if (count($user->userCoachingExperince) > 3) { ?>
                    <div class="text-center seeall_btn mt-xl-4 mt-3">
                        <a href="javascript:void(0);" class="btn btn-success btn-sm border-1 p-6-15 font-14" onclick="getMoreResults('coaching_experience', 'co')" id="co">SEE ALL</a>
                    </div>
                    <?php
                }
            }
            ?>
        </div>
    </section>

    <!-- community service -->
    <section class="community_service">
        <div class="container-1800">
            <div class="common_heading position-relative">
                <h3 class="black black-lg">COMMUNITY SERVICE EXPERIENCE</h3>
                <div class="edit_icon icon_center">
                    <a href="{{ url('player/player-profile-form') }}" oncontextmenu="onRightClickMenu('about')" onclick="sendPlayerStep('about');">
                        <i class="fas fa-edit"></i>
                    </a>
                </div>
            </div>
            <?php if (!empty($user->userCommunityExperince)) { ?>
                <ul class="list-inline text-center">
                    <?php for ($i = 0; $i < 3; $i++) { ?>
                        <li class="list-inline-item list">
                            <img src="{{ (!empty($user->userCommunityExperince[$i]->logo)) ? checkUserImage($user->userCommunityExperince[$i]->logo, 'player/thumb','community-experience'): checkUserImage('coachinglist_logo.png', 'coach/thumb','coaching-list')}}" alt="icon">
                            <h3 >{{!empty($user->userCommunityExperince[$i]->name) ? ucfirst(getLimitText(10,$user->userCommunityExperince[$i]->name)) : 'Add'}}</h3>
                            <h6>{{(!empty($user->userCommunityExperince[$i]->position_held)) ? getLimitText(10,$user->userCommunityExperince[$i]->position_held) : '-'}}</h6>                                                        
                            <p>{{(!empty($user->userCommunityExperince[$i]->from_year)) ? $user->userCommunityExperince[$i]->from_year : '-'}} - {{(!empty($user->userCommunityExperince[$i]->to_year)) ? $user->userCommunityExperince[$i]->to_year : '-'}}</p>
                            <div class="bottom_loader">
                                <div class="border_loader">
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                </div>
                            </div>
                        </li>
                    <?php } ?>
                </ul>
                <?php if (count($user->userCommunityExperince) > 3) { ?>
                    <div class="text-center seeall_btn mt-xl-4 mt-3">
                        <a href="javascript:void(0);" class="btn btn-success btn-sm border-1 p-6-15 font-14" onclick="getMoreResults('community', 'cm')" id="cm">SEE ALL</a>
                    </div>
                    <?php
                }
            }
            ?> 
        </div>
    </section>

    <!-- resume -->
    <section class="resume">
        <div class="container-1800">
            <div class="frame_bg">
                <div class="row">
                    <div class="col-sm-4">
                        <h3 class="d-none d-sm-block">{{strtoupper($user->first_name)}} <br> {{strtoupper($user->last_name)}}</h3>
                    </div>
                    <div class="col-sm-4">
                        <div class="player_info text-center">
                            <img class="rounded-circle" src="{{ checkUserImage($user->profile_image, 'player/thumb') }}" alt=" profile">
                            <h3 class="d-block d-sm-none">DESEAN JACKSON</h3>
                            <div class="flag d-block d-sm-none">
                                <img src="{{ url('public/images/american_flag.jpg') }}" alt=" flag">
                            </div>
                            <h4>DOWNLOAD RESUME</h4>  
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    @if(!empty($user->resume))
                                    <a href="{{url('public/uploads/player/'.$user->resume)}}" download class="icon">
                                        <i class="icon-download_icon "></i>
                                    </a>
                                    @else
                                    <a href="javascript:void(0)" class="icon">
                                        <i class="icon-download_icon "></i>
                                    </a>
                                    @endif
                                </li>
                                <li class="list-inline-item">
                                    <a href="{{ url('player/player-profile-form') }}" class="icon">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                </li>
                            </ul>
                        </div> 
                    </div>
                    <div class="col-sm-4">
                        <div class="flag text-right d-none d-sm-block">
                            <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'medium') }}" alt=" flag">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>      
    <div class="procard-player" id="divPlayerProCard">
    </div>
    <!-- experience -->
    <div class="modal fade modal-center collage_experience" id="userExperienceList" data-backdrop="static" data-keyboard="false"  data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md " role="document">
            <div class="modal-content" id="experience_list">

            </div>
        </div> 
    </div>
    <!--  coaching experience model -->
    <div class="modal fade modal-center coaching_experience" id="CoachingExperience" data-backdrop="static" data-keyboard="false"  data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content" id="coaching_experience_list">

            </div>
        </div> 
    </div>
    <!-- desired benefits -->
    <div class="modal fade modal-center desired_benefits" id="DesiredBenefits" data-backdrop="static" data-keyboard="false"  data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content" id="moreDesiredBenefitsList">

            </div>
        </div> 
    </div>

    <!--        </div> -->
    <div class="modal fade modal-center key_stats" id="KeyStats" data-backdrop="static" data-keyboard="false"  data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="post_title">Key Stats</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body p-0" id="key-states">

                </div>
            </div>
        </div> 
    </div>


</main> 
<!-- left side url routing-->
<input type="hidden" data-url="{{url('player/left-sidebar')}}" id="player_left_side">
<input type="hidden" data-url="{{url('player/right-sidebar')}}" id="player_right_side">
<script>
    /* on click on link*/
    function sendPlayerStep(type) {
        localStorage.setItem('type', type);
    }

    /* on click on right button links*/
    function onRightClickMenu(type) {
        localStorage.setItem('type', type);
    }

    var userConnectionList = "{{ url('player/user-connections-list') }}";
    //  profile pages benefits sections animation

    var desired_sec = $('.desired_benefits').offset();
    //var window_h = $(window).height()/2;
    var $window = $(window);
    $window.scroll(function () {
        if ($window.scrollTop() >= desired_sec.top) {
            $('.desired_benefits').addClass("active_sec");
        }
    });

    // show player pro card
    function getPlayerProCard() {
        var url = "{{ url('player/get-player-procard') }}";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                $('#divPlayerProCard').html(response.html);
            },
            error: function () {
                getPlayerProCard();
            },
            complete: function () {
                //setHeightMiddleSection(); 
            }
        });
    }

    function getVideoUserViews() {
        var url = "{{ url('player/get-profile-media-list') }}";
        $.ajax({type: "GET", url: url, data: {},
            success: function (response) {
                $('#divVideoUserViews').html(response.html);
            },
            error: function () {
                getVideoUserViews();
            },
            complete: function () {
                setTimeout(function () {
                    setHeightMiddleSection();
                }, 3000);
            }
        });
    }

    function getAccolades() {
        pageLoader('divAccolades', 'show');
        var url = "{{ url('player/get-accolades') }}";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                if (response.success) {
                    setTimeout(function () {
                        pageLoader('memberlist', 'hide');
                        $('#divAccolades').html(response.html);
                    }, 2000);
                } else {
                    message('error', response.message);
                }
            },
            error: function (err) {
//                message('error', err);
                getAccolades();
            },
            complete: function () {
                //setHeightMiddleSection(); 
            }
        });
    }

    function getDesiredBenifites() {
        var url = "{{ url('player/get-desired-benefites') }}";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                $('#divDesiredBenifites').html(response.html);
            },
            error: function () {
                getDesiredBenifites();
            },
            complete: function () {
                //setHeightMiddleSection(); 
            }
        });
    }


    function getValidateAttributeList() {
        var url = "{{ url('player/get-attribute-list') }}";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                $('#get-attribute-list').html(response.html);
            },
            error: function () {
//               getValidateAttributeList();
            },
        });
    }


    function getCoachinExperience() {
        pageLoader('divCoachinExperience', 'show');
        var url = "{{ url('player/get-coaching-experinces') }}";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                if (response.success) {
                    setTimeout(function () {
                        pageLoader('divCoachinExperience', 'hide');
                        $('#divCoachinExperience').html(response.html);
                    }, 2000);
                } else {
                    message('error', response.message);
                }
            },
            error: function (err) {
//                message('error', err);
                getCoachinExperience();
            },
            complete: function () {
                // setHeightMiddleSection(); 
            }
        });
    }

    function getCommunityServiceExperience() {
        //pageLoader('divCommunityServiceExperiences', 'show');
        var url = "{{ url('player/get-community-service-experince') }}";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                if (response.success) {
                    setTimeout(function () {
                        pageLoader('divCommunityServiceExperiences', 'hide');
                        $('#divCommunityServiceExperiences').html(response.html);
                    }, 2000);
                } else {
                    message('error', response.message);
                }
            },
            error: function (err) {
//                message('error', err);
                getCommunityServiceExperience();
            },
            complete: function () {
                //setHeightMiddleSection(); 
            }
        });
    }

    $(document).ready(function () {
        getPlayerProCard();
        getVideoUserViews();
        getAccolades();
        getDesiredBenifites();
        getCoachinExperience();
        getCommunityServiceExperience();
        getLeftSidebar("player-profile", '');
        getRightSidebar("player-profile", '');
        getValidateAttributeList();
        getPlayerAllCount();
        getInstagrampostList();


    });

// instagram feed listing
    function getInstagrampostList() {
        pageLoader('instgramPost', 'show')
        var url = "{{ url('get-instagram-feed') }} ";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                $("#instgramPost").html("");
                $("#instgramPost").html(response.html);
            },error: function(){
                getInstagrampostList();
            }
        });
    }
    /* Get player  experience */
    function getExperienceList(type) {
        var url = "{{ url('player/get-experience-list') }}";
        var _token = '{{ csrf_token() }}';
        $.ajax({type: "POST",
            url: url,
            data: {_token: _token, experience_type: type},
            success: function (response) {
                $('#userExperienceList').modal('show');
                $('#experience_list').html(response.html);
            },
            error: function () {
                getExperienceList(type)
            },
            complete: function () {
                $(".scroll_body").mCustomScrollbar({
                    theme: "dark",
                    axis: "y",
                });
            }
        });
    }

    // all counts of player
    function getPlayerAllCount() {
        pageLoader('all_player_counts', 'show');
        var url = "{{ url('player/get-player-counts') }}";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                $('#all_player_counts').html('');
                $('#all_player_counts').html(response.html);
                $('#newsBulletin').html(response.newsBulletin);
            },
            error: function () {
                getPlayerAllCount();
            }
        });
    }
    /* Coaching experience */
    function getMoreResults(type, id) {
        showButtonLoader(id, 'SEE ALL', 'disable');
        var url = "{{ url('player/get-different-experience') }}";
        var _token = '{{ csrf_token() }}';
        $.ajax({type: "POST",
            url: url,
            data: {_token: _token, experience_type: type},
            success: function (response) {
                $('#CoachingExperience').modal('show');
                $('#coaching_experience_list').html(response.html);
            }, error: function () {
                //getMoreResults();
            },
            complete: function () {
                showButtonLoader(id, 'SEE ALL', 'enable');
                $(".scroll_body").mCustomScrollbar({
                    theme: "dark",
                    axis: "y",
                });
            }
        });

    }

    function loadMoreBenefits() {
        showButtonLoader('loader_more_benefit', 'SEE ALL', 'disable');
        var url = "{{ url('player/load-more-benefites') }}";
        $.ajax({type: "GET",
            url: url,
            success: function (response) {
                $('#DesiredBenefits').modal('show');
                $('#moreDesiredBenefitsList').html(response.html);
            },
            error: function () {
                // loadMoreBenefits();
            },
            complete: function () {
                showButtonLoader('loader_more_benefit', 'SEE ALL', 'enable');
                $(".scroll_body").mCustomScrollbar({
                    theme: "dark",
                    axis: "y",
                });
            }
        });
    }

    function KeyStats() {
//        showButtonLoader('loader_more_benefit', 'SEE ALL', 'disable');
        var url = "{{ url('player/key-states') }}";
        $.ajax({type: "GET",
            url: url,
            success: function (response) {
                $('#KeyStats').modal('show');
                $('#key-states').html(response.html);
            },
            error: function () {
                // loadMoreBenefits();
            },
            complete: function () {
//           
            }
        });

    }

</script>
<script src="{{url('public/js/player/player-left-right-sidebar.js')}}"></script>
@endsection