@extends('player::layouts.app')
@section('content')

<main class="main-content">
    <div class="mainframe_border">
        <div class="borderheight" id="borderheight"></div>
    </div>
    <div class="container-fluid">
        <div class="common_heading">
            <h3 class="black black-lg">
                MY FRIEND REQUEST
            </h3>
        </div>
    </div>
    <aside class="left_section " id="left-side-html">
        <!--  Left side html render -->
    </aside>
    <section class="middle_section">
        <div class="container-fluid">
            <div class="ajax_list_load">
                <div class="green-scroll" id="membersList" style="height: 2500px;"></div>
            </div>
        </div>
    </section>
    <aside class="right_section" id="right-side-html">
        <!--- Right side html render -->
    </aside>            
</main>
<!-- left & right side url routing-->
<input type="hidden" data-url="{{url('player/left-sidebar')}}" id="player_left_side">
<input type="hidden" data-url="{{url('player/right-sidebar')}}" id="player_right_side">
<script>
    var memberConnectDismissUrl = "{{ url('player/connect-dismiss-member') }}";
    var currentPageUrl = '{{ Request::segment(2) }}';
    var csrfToken = "{{csrf_token()}}";


    /* Get connection list */
    function friendRequestList() {
        pageLoader('membersList', 'show');
        var url = "{{ url('player/get-all-friend-request') }}";
        var formData = $('#playerMemberForm').serialize();
        $('#applyBtn').prop('disabled', true);
        $.ajax({type: "POST",
            url: url,
            data: formData,
            success: function (response) {
                if (response.success) {
                    setTimeout(function () {
                        pageLoader('membersList', 'hide');
                        $('#applyBtn').prop('disabled', false);
                        $("#membersList").html("");
                        $("#membersList").html(response.html);
                        $('#left-side-html').removeClass('open');
                        $('body').removeClass("aside-open-left");
                    }, 1000);
                } else {
                    message('error', response.message);
                }
            }, error: function (err) {
//                message('error', err);
                friendRequestList();
            }, complete: function () {
                setHeightMiddleSection();
            }
        });
    }

    /* Accept connection request */
    function acceptRejectConnection(id, type) {
        if (type == 'accept') {
            var button_name = 'ACCEPT';
            var button_id = 'accept_' + id;
        } else {
            var button_name = 'REJECT';
            var button_id = 'reject_' + id;

        }
        showButtonLoader(button_id, button_name, "disable");
        $.post("{{ url('player/accept-reject-connection') }}", {_token: "{{ csrf_token() }}", id: id, type: type}, function (response) {
            if (response.success) {
                friendRequestList();
                message('success', response.message);
            } else {
                message('error', response.message);
            }
            showButtonLoader(button_id, button_name, "enable");
        }).fail(function () {
//            acceptRejectConnection(id, type);
        });
    }

    $(document).ready(function () {
        getLeftSidebar("friend_request_list", '');
        getRightSidebar("friend_request_list", '');
        setTimeout(function () {
            friendRequestList();
        }, 3000);
    });

    /* Clear search form */
    function clearForm() {
        $('#member_type').val('');
        $('#member_type').selectpicker('refresh');
        $('#playerMemberForm').trigger("reset");
        friendRequestList();
    }

</script>
<script src="{{url('public/js/player/player-left-right-sidebar.js')}}"></script>
<script src="{{url('public/js/player/player-connect-dissmiss.js')}}"></script>
@endsection