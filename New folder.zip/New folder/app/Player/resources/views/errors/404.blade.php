@extends('coach::layouts.app')
@section('content')

<div class="main-content side_padding">
    <h1>Page Not Found!</h1>
</div>    

@endsection