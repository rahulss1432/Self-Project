<ul class="nav nav-pills mb-3 season_tabs d-sm-flex justify-content-sm-between" id="pills-tab" role="tablist">
    <li class="nav-item">
        <a class="nav-link active font_14 rounded-0" id="pills-currect-tab" data-toggle="pill" onclick="getCurrentStates()" href="#currect-season" role="tab" aria-controls="currect-season" aria-selected="true">
            Current season
            <p class="font_10 mb-0">{{!empty($keyCurrent->from_year)?$keyCurrent->from_year:'from'}} - {{!empty($keyCurrent->to_year)?$keyCurrent->to_year:'to'}}</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link font_14 rounded-0" id="pills-past-tab" data-toggle="pill"  onclick="getPastStates()" href="#past-season" role="tab" aria-controls="past-season" aria-selected="false">
            Past season
            <p class="font_10 mb-0">{{!empty($keyPast->from_year)?$keyPast->from_year:'from'}} - {{!empty($keyPast->to_year)?$keyPast->to_year:'to'}}</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link font_14 rounded-0" id="pills-career-tab" data-toggle="pill" onclick="getCareerStates()" href="#career" role="tab" aria-controls="career" aria-selected="false">
            Career
            <p class="font_10 mb-0">{{!empty($keyCurrent->from_year)?$keyCurrent->from_year:'from'}} - {{!empty($keyPast->to_year)?$keyPast->to_year:'to'}}</p>
        </a>
    </li>
</ul>
<div class="tab-content" id="pills-tabContent">
    <div class="tab-pane fade show active" id="currect-season" role="tabpanel" aria-labelledby="pills-currect-tab ">
    </div>
    <div class="tab-pane fade" id="past-season" role="tabpanel" aria-labelledby="pills-past-tab">
    </div>
    <div class="tab-pane fade" id="career" role="tabpanel" aria-labelledby="pills-career-tab">
    </div>
</div>

<script>
    $(document).ready(function () {
        getCurrentStates();
    });

    function getCurrentStates() {
        var url = "{{ url('player/key-states-current') }}";
        $.ajax({type: "GET",
            url: url,
            success: function (response) {
                $('#currect-season').html(response.html);
            },
            error: function () {

            },
            complete: function () {
                $(".key-states-current").mCustomScrollbar({
                    theme: "dark",
                    axis: "y",
                });
            }
        });
    }
    function getPastStates() {
        var url = "{{ url('player/key-states-past') }}";
        $.ajax({type: "GET",
            url: url,
            success: function (response) {
                $('#past-season').html(response.html);
            },
            error: function () {

            },
            complete: function () {
                $(".key-states-past").mCustomScrollbar({
                    theme: "dark",
                    axis: "y",
                });
            }
        });
    }
    function getCareerStates() {
        var url = "{{ url('player/key-states-career') }}";
        $.ajax({type: "GET",
            url: url,
            success: function (response) {
                $('#career').html(response.html);
            },
            error: function () {

            },
            complete: function () {
                $(".key-states-career").mCustomScrollbar({
                    theme: "dark",
                    axis: "y",
                });
            }
        });
    }
</script>