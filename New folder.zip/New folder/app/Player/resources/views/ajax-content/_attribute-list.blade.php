
    <div class="count_addlist">
        <div class="text-md-center">
             @php $loginUser = Auth::guard('player')->user()->id; @endphp 
            @if(count($getAttributes) > 0)
            @foreach($getAttributes as $key => $attribute)
            @if($key == 0) 
            <div class="c_tag top_center wow fadeInLeft {{ (countAttributeById($attribute->id ,$loginUser) != 0) ? 'active' : '' }}" data-wow-delay="0s" data-wow-duration="0.2s">
                <span class="count d-flex align-items-center"> 
                    {{ $attribute->title }}
                    @if(countAttributeById($attribute->id , $loginUser) !=0) <a href="javascript:void(0);" class="review"> {{ countAttributeById($attribute->id , $loginUser) }}</a>@endif
                </span>
            </div>
            @endif
            @endforeach
            @endif

        </div>
        <div class="c_leftlist float-md-left">
            <ul class="list-unstyled text-md-right">
                @if(count($getAttributes) > 0)
                @foreach($getAttributes as $key => $attribute)
                @if($key == 31 || $key != 30 && $key != 0 && $key != 32 && $key % 2 == 0) 
                <li>
                    <div class="c_tag wow fadeInLeft {{ (countAttributeById($attribute->id ,$loginUser) != 0) ? 'active' : '' }}" data-wow-delay="0s" data-wow-duration="0.4s">
                        <span class="count d-flex align-items-center"> 
                            @if(countAttributeById($attribute->id , $loginUser) !=0) <a href="javascript:void(0);" class="d-none d-md-block review"> {{ countAttributeById($attribute->id , $loginUser) }}</a>@endif
                               {{ $attribute->title }}
                        </span>
                    </div>
                </li>
                @endif
                @endforeach
                @endif
            </ul>
        </div>
        <div class="c_rightlist float-md-right">
            <ul class="list-unstyled text-md-left">
                @if(count($getAttributes) > 0)
                @foreach($getAttributes as $key =>  $attribute)
                @if(($key % 2 == 1 && $key != 31) || $key == 30 || $key == 32)
                <li>
                    <div class="c_tag wow fadeInRight {{ (countAttributeById($attribute->id ,$loginUser) != 0) ? 'active' : '' }}" data-wow-delay="0s" data-wow-duration="0.7s">
                        <span class="count d-flex align-items-center"> 
                            {{ $attribute->title }}
                             @if(countAttributeById($attribute->id , $loginUser) !=0) <a href="javascript:void(0);" class="review"> {{ countAttributeById($attribute->id , $loginUser) }}</a>@endif
                        </span>
                    </div>
                </li>
                @endif
                @endforeach
                @endif
            </ul>     
        </div> 
    </div>

