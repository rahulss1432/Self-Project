<div class="inner_section  green-scroll key-states-past" data-mcs-theme="dark">
    <div class="offence">
        <h6 class="font_14 mb-3">Offence</h6>
        <div class="row common_row">
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total passing yards:</label>
                    <span>{{!empty($pastKeyStates->total_passing)?$pastKeyStates->total_passing:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average passing yards (Game):</label>
                    <span>{{!empty($pastKeyStates->passing_game)?$pastKeyStates->passing_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average passing yards (Season):</label>
                    <span>{{!empty($pastKeyStates->passing_season)?$pastKeyStates->passing_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Completions:</label>
                    <span>{{!empty($pastKeyStates->completion)?$pastKeyStates->completion:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Completions<span style="font-family:initial;">(%)</span>:</label>
                    <!--<span>{{!empty($pastKeyStates->completion_percent)?$pastKeyStates->completion_percent:0}}<span style="font-family:initial;">(%)</span></span>-->
                    <span>{{!empty($pastKeyStates->completion_percent)?$pastKeyStates->completion_percent:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">QB passer rating:</label>
                    <span>{{!empty($pastKeyStates->passer_rating)?$pastKeyStates->passer_rating:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total rushing yards:</label>
                    <span>{{!empty($pastKeyStates->total_rushing)?$pastKeyStates->total_rushing:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average rushing yards (Game):</label>
                    <span>{{!empty($pastKeyStates->rushing_game)?$pastKeyStates->rushing_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average rushing yards (Season):</label>
                    <span>{{!empty($pastKeyStates->rushing_season)?$pastKeyStates->rushing_season:0}}</span>
                </div>
            </div>

            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total receiving yards:</label>
                    <span>{{!empty($pastKeyStates->total_receiving)?$pastKeyStates->total_receiving:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average receiving yards (Game):</label>
                    <span>{{!empty($pastKeyStates->receiving_game)?$pastKeyStates->receiving_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average receiving yards (Season):</label>
                    <span>{{!empty($pastKeyStates->receiving_season)?$pastKeyStates->receiving_season:0}}</span>
                </div>
            </div>

            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total return yards:</label>
                    <span>{{!empty($pastKeyStates->total_return)?$pastKeyStates->total_return:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average return yards (Game):</label>
                    <span>{{!empty($pastKeyStates->return_game)?$pastKeyStates->return_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average return yards (Season):</label>
                    <span>{{!empty($pastKeyStates->return_season)?$pastKeyStates->return_season:0}}</span>
                </div>
            </div>

            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total all purpose yards:</label>
                    <span>{{!empty($pastKeyStates->total_all_purpose)?$pastKeyStates->total_all_purpose:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average all purpose yards (Game):</label>
                    <span>{{!empty($pastKeyStates->purpose_game)?$pastKeyStates->purpose_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average all purpose yards (Season):</label>
                    <span>{{!empty($pastKeyStates->purpose_season)?$pastKeyStates->purpose_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Touchdowns:</label>
                    <span>{{!empty($pastKeyStates->tuchdowns)?$pastKeyStates->tuchdowns:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Games played:</label>
                    <span>{{!empty($pastKeyStates->games_played)?$pastKeyStates->games_played:0}}</span>
                </div>
            </div>
        </div>
    </div>
    <div class="defence">
        <h6 class="font_14 mb-3">Defence</h6>
        <div class="row common_row">
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total tackles:</label>  
                    <span>{{!empty($pastKeyStates->tackles)?$pastKeyStates->tackles:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles (Game):</label> 
                    <span>{{!empty($pastKeyStates->tackles_game)?$pastKeyStates->tackles_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles (Season):</label>   
                    <span>{{!empty($pastKeyStates->tackles_season)?$pastKeyStates->tackles_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total tackles for loss:</label> 
                    <span>{{!empty($pastKeyStates->total_tackloss)?$pastKeyStates->total_tackloss:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles for loss (Game):</label>    
                    <span>{{!empty($pastKeyStates->tackloss_game)?$pastKeyStates->tackloss_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles for loss (Season):</label>  
                    <span>{{!empty($pastKeyStates->tackloss_season)?$pastKeyStates->tackloss_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total sacks:</label>    
                    <span>{{!empty($pastKeyStates->total_sacks)?$pastKeyStates->total_sacks:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average sacks (Game):</label>   
                    <span>{{!empty($pastKeyStates->sacks_game)?$pastKeyStates->sacks_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average sacks (Season):</label> 
                    <span>{{!empty($pastKeyStates->sacks_season)?$pastKeyStates->sacks_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total pass breakups:</label>    
                    <span>{{!empty($pastKeyStates->total_breaksups)?$pastKeyStates->total_breaksups:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average pass breakups (Game):</label>   
                    <span>{{!empty($pastKeyStates->breaksups_game)?$pastKeyStates->breaksups_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average pass breakups (Season):</label> 
                    <span>{{!empty($pastKeyStates->breaksups_season)?$pastKeyStates->breaksups_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total Interceptions:</label>    
                    <span>{{!empty($pastKeyStates->total_interception)?$pastKeyStates->total_interception:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Average Interceptions (Game):</label>   
                    <span>{{!empty($pastKeyStates->interception_game)?$pastKeyStates->interception_game:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Average Interceptions (Season):</label> 
                    <span>{{!empty($pastKeyStates->interception_season)?$pastKeyStates->interception_season:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Blocked punts:</label>  
                    <span>{{!empty($pastKeyStates->blocked_punts)?$pastKeyStates->blocked_punts:0}}</span>
                </div>
            </div>
        </div>
    </div>
    <div class="specials">
        <h6 class="font_14 mb-3">Specials</h6>
        <div class="row common_row">
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Total field goals:</label>  
                    <span>{{!empty($pastKeyStates->total_field_goal)?$pastKeyStates->total_field_goal:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Longest field goal:</label> 
                    <span>{{!empty($pastKeyStates->longest_field_goal)?$pastKeyStates->longest_field_goal:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Field goal percentage:</label>  
                    <!--{{!empty($pastKeyStates->field_goal_percent)?$pastKeyStates->field_goal_percent:0}}<span style="font-family:initial;">%</span>-->
                    {{!empty($pastKeyStates->field_goal_percent)?$pastKeyStates->field_goal_percent:0}}
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Longest punt:</label>   
                    <span>{{!empty($pastKeyStates->longest_punt)?$pastKeyStates->longest_punt:0}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Average punt distance:</label>  
                    <span class="text-capitalize">{{!empty($pastKeyStates->avg_punt_distance)?$pastKeyStates->avg_punt_distance:0}}</span>
                </div>
            </div>
        </div>
    </div>
</div>