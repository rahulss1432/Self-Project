@if(!empty($posts) && count($posts) > 0)
@foreach($posts as $post)
<div class="common" id="set{{ $post->id }}">
    <div class="info">
        <div class="p_img">  
            <img src="{{ checkUserImage($post->user->profile_image, $post->user->role.'/thumb') }}" alt="avtar">
        </div>
        <div class="p_content">

            @if( checkLoginUser($post->user_id) )


            <div class="side_option">
                <!-- <a href="javascript:void(0);" onclick="editPost('{{ $post->id }}')"><i class="fas fa-pencil-alt"></i></a>
                <a href="javascript:void(0);" onclick="deletePost('{{ $post->id }}')" ><i class="fas fa-trash"></i></a> -->
                <div class="dropdown common_dropdown ">
                    <button class="btn dropdown-toggle bg-transparent p-0" type="button" id="action" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="flaticon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                    </button>
                    <div class="dropdown-menu rounded-0" aria-labelledby="action" x-placement="bottom-start">
                        <a href="javascript:void(0);" onclick="editPost('{{ $post->id }}')" class="dropdown-item">Edit</a>
                        <a href="javascript:void(0);" onclick="deletePost('{{ $post->id }}')" class="dropdown-item">Delete</a>
                        <a href="{{ url('post-details/'. base64_encode($post->id) )}}"  class="dropdown-item">view</a> 
                    </div>
                </div>

            </div>
            @else
            @php
            $getPost = getIncidentDataByStatus(Auth::guard(getAuthGuard())->user()->id,$post->id, 'post');
            @endphp
            @if($getPost != 'open')
            <div class="side_option">
                <!-- <a href="javascript:void(0);" onclick="addReport('{{Auth::guard(getAuthGuard())->user()->id}}','{{$post->id}}', 'post')">
                    <i class="flaticon-flag"></i>
                </a> -->
                <div class="dropdown common_dropdown ">
                    <button class="btn dropdown-toggle bg-transparent p-0" type="button" id="action" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="flaticon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                    </button>
                    <div class="dropdown-menu rounded-0" aria-labelledby="action" x-placement="bottom-start">
                        <a href="javascript:void(0);" onclick="addReport('{{Auth::guard(getAuthGuard())->user()->id}}','{{$post->id}}', 'post')" class="dropdown-item">Report</a> 
                        <a href="{{ url('post-details/'. base64_encode($post->id) )}}"  class="dropdown-item">view</a> 
                    </div>
                </div>
            </div>
            @endif
            @endif
            <h5>{{$post->user->full_name}}</h5>
            <p>{{ dateDayAgo($post->created_at) }} . <span class="location">{{ !empty($post->user->country->name) ? $post->user->country->name : '-' }}</span></p>
        </div>
        <div class="description"><p>{{ $post->post }}</p></div>
        <div class="photo">
            <div class="row custom_grid">
                @if(!empty($post->media) && count($post->media) > 0)
                @foreach($post->media as $key => $mediaFile)
                @if($key == 0 || $key == 1)
                @if(count($post->media) <= 2 || count($post->media) >= 2 && $key == 0)
                <div class="col first_img play_icon play_icon_big">
                    <a href="javascript:void(0);" onclick="getPostView('{{ $mediaFile->post_id }}')">
                        <img src="{{  checkMediaByType($mediaFile->media, $post->user->role, $mediaFile->media_type, 'thumb')  }}" class="mr-auto ml-auto" alt="post">

                        @if($mediaFile->media_type == 'video')
                        <div class="video_overlay">
                            <div class="action">
                                <i class="icon-play-button"></i>
                            </div>
                        </div>
                        @endif
                    </a>
                </div>
                @endif
                @endif
                @if(count($post->media) > 2 && $key > 0 && $key < 2)
                <div class="w-100"></div>
                @endif
                @if($key == 1 || $key == 2 || $key == 3)
                @if((count($post->media) > 2))
                <div class="col first_img play_icon">
                    <div class="thumb_img">
                        <a href="javascript:void(0);" onclick="getPostView('{{ $mediaFile->post_id }}')">
                            <img src="{{ checkMediaByType($mediaFile->media, $post->user->role, $mediaFile->media_type, 'thumb')  }}" class=" mr-auto ml-auto" alt="post">

                            @if($mediaFile->media_type == 'video')
                            <div class="video_overlay">
                                <div class="action">
                                    <i class="icon-play-button"></i>
                                </div>
                            </div>
                            @endif
                        </a>
                    </div>
                </div>

                @endif
                @endif
                @if($key == 4)
                @if(count($post->media) - 5 > 0 )
                <div class="col">
                    @else
                    <div class="col first_img play_icon">
                        @endif
                        <div class="thumb_img">
                            <a href="javascript:void(0);" onclick="getPostView('{{ $mediaFile->post_id }}')">
                                <img src="{{ checkMediaByType($mediaFile->media, $post->user->role, $mediaFile->media_type, 'thumb') }}" class="mr-auto ml-auto" alt="post">
                                @if(count($post->media) - 5 > 0 )
                                <span class="overlay d-flex align-items-center justify-content-center">
                                    + {{ count($post->media) - 5 }}
                                </span>
                                @else
                                @if($mediaFile->media_type == 'video')
                                <div class="video_overlay">
                                    <div class="action">
                                        <i class="icon-play-button"></i>
                                    </div>
                                </div>
                                @endif
                                @endif
                            </a> 
                        </div>
                    </div>
                    @endif
                    @endforeach
                    @endif
                </div>
            </div>
            <div class="action">
                <div class="row">
                    <div class="col col-sm">
                        @php
                        $check = checkUserLike($post->id,$o_id);
                        if( $check > 0 ){ $likeClass = 'like'; }else{ $likeClass = 'unlike'; }
                        @endphp
                        <a href="javascript:void(0);" onclick="addPostLike('{{ $post->id }}', '{{ $post->user_id }}')" id="like-btn-{{ $post->id }}" class="{{ $likeClass }}">
                            <i class="icon icon-thumb-up-sign icon"></i> Like
                        </a>
                    </div>
                    <div class="col col-sm text-center">
                        <a data-toggle="collapse" href="#comment-{{ $post->id }}" role="button" aria-expanded="false" aria-controls="comment-{{ $post->id }}">
                            <i class="icon icon-chat icon"></i> Comment
                        </a>
                    </div>
                    <div class="col col-sm text-right">
                        <a href="javascript:void(0);" onclick="ShareModal('post-share',{{ $post->id }})">
                            <i class="icon icon-share_icon icon"></i> Share
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="comment">
            <ul class="list-inline view mb-0">
                <li class="list-inline-item">
                    <a href="javascript:void(0);" onclick="getLikeUser('{{ $post->id }}')" id="prevent-{{ $post->id }}">
                        <span id="post-like-{{ $post->id }}"></span> Likes
                    </a>
                </li>
                <li class="list-inline-item">
                    <p class="mb-0"><span id="post-comments-count-{{ $post->id }}"></span> Comments</p>
                </li>
            </ul>
            <div class="user_comment collapse" id="comment-{{ $post->id }}">
                <div class="userimg">
                    <img src="{{ checkUserImage(getUserDataByColumn('profile_image'), getUserDataByColumn('role').'/thumb') }}" class="rounded-circle" alt="user">
                </div>
                <div class="comment_box">
                    <form class="comment-form" method="post" action="{{ url('player/add-post-comment') }}">
                        {{ csrf_field() }}
                        <input type="hidden" name="pid" value="{{ $post->id }}"/>
                        <input type="hidden" name="uid" value="{{ $post->user_id }}"/>
                        <input type="hidden" name="id" value="{{ $o_id }}"/>
                        <input class="form-control" name="comment" type="text" placeholder="Write a Comment..." required="">
                        <div class="uploadicon">
                            <span class="icon-sent-mail" onclick="$(this).parents('form').submit()"></span>
                        </div>
                    </form>
                </div>
            </div>
            <div  id="post-comments-{{ $post->id }}">

                <!--                <div class="view_comment">
                                    <a href="javascript:void(0);" id="load-more-btn-{{ $post->id }}" onclick="loadMoreComment('{{ $post->id }}')">View all comments</a>
                                </div>-->
            </div>
        </div>
    </div>
    <script>
                                                                        // Get post likes
                                                                        getPostLike('{{ $post->id }}'); // get like of post
                                                                        // Get post comments.
                                                                        getPostComments('{{ $post->id }}', 'first'); // get comment of post
    </script>
    @endforeach
    <!-- Pagination -->
    {{$posts->links()}}
    @else
    <div class="alert alert-danger w-70 text-center" role="alert">
        No Post Found!
    </div>
    @endif

    <!--open post media modal-->
    <div class="modal photos modal-effect" id="myPhotosVideos" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="get-post-view-modal"></div>

                </div>
            </div>
        </div>
    </div>

    <!-- Add report modal -->
    <div class="modal fade modal-center share-article" data-backdrop="static" data-keyboard="false" id="add_report" data-easein="flipBounceXIn" tabindex="-1" role="dialog" aria-labelledby="post_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" id="add-report-data">
                <div class="btn_loader btn_ring" id="listLoader"></div>
            </div>
        </div>
    </div>
    <script>
                                                                        /* Post scrolling */
                                                                        $("#postframe").mCustomScrollbar({
                                                                theme:"dark",
                                                                        axis:"y"
                                                                });
                                                                        // Function for delete post
                                                                                function deletePost(id){
                                                                                bootbox.confirm({
                                                                                message: "Are you sure want to delete post?",
                                                                                        buttons: {
                                                                                        confirm: {
                                                                                        label: 'Yes',
                                                                                                className: 'btn-success border-1 font-14'
                                                                                        },
                                                                                                cancel: {
                                                                                                label: 'No',
                                                                                                        className: 'btn btn btn-light rounded-0'
                                                                                                }
                                                                                        },
                                                                                        callback: function (result) {
                                                                                        if (result){
                                                                                        $.post("{{ url('player/delete-post') }}", {_token: "{{ csrf_token() }}", id: id}, function(data){
                                                                                        if (data.success){
                                                                                        message('success', data.message);
                                                                                                $('#set' + id).hide(300);
                                                                                        } else{
                                                                                        message('error', data.message);
                                                                                        }
                                                                                        });
                                                                                        }
                                                                                        }
                                                                                });
                                                                                }
                                                                        /*load more with pagination*/
                                                                        $(document).ready(function() {
                                                                        setTimeout(function() {
                                                                        $("ul.pagination li").first().remove();
                                                                        }, 500);
                                                                                $(".pagination li a").on('click', function(e) {
                                                                        e.preventDefault();
                                                                                //        $(".pagination li a").attr("disabled", true);
                                                                                showButtonLoader('explore-btn-loader', "MORE", "disable");
                                                                                var $this = $(this);
                                                                                var pageLink = $this.attr('href');
                                                                                getpostView('', pageLink, 'pagination');
                                                                        });
                                                                                $(".pagination li a").addClass('btn btn-success btn-lg font-14 p-6-15 border-1 ml-2');
                                                                                $(".pagination li a").attr('id', 'explore-btn-loader');
                                                                                $(".pagination li a").html('MORE');
                                                                        });
                                                                                // get post media view modal
                                                                                        function getPostView(postId){
                                                                                        $("#get-post-view-modal").html('<span class="ajax_loader btn_ring"></span>');
                                                                                                var url = '{{ url("player/get-post-view-modal") }}';
                                                                                                $.ajax({
                                                                                                type: "GET", url: url, data: {postId: postId},
                                                                                                        success: function (response) {
                                                                                                        $("#get-post-view-modal").html("");
                                                                                                                $("#get-post-view-modal").html(response.html);
                                                                                                                $('#myPhotosVideos').modal('show');
                                                                                                        }
                                                                                                });
                                                                                        }

                                                                                // Function for Add report.
                                                                                function addReport(fromId, toId, role) {
                                                                                $.get("{{ url('add-report-form') }}", function (data) {
                                                                                $("#add-report-data").html(data.html);
                                                                                        $('#add_report').modal('show');
                                                                                        $("#fromId").val(fromId);
                                                                                        $("#toId").val(toId);
                                                                                        $("#reportedEntity").val(role);
                                                                                });
                                                                                }


                                                                                function moreLess(initiallyVisibleCharacters) {
                                                                                var visibleCharacters = initiallyVisibleCharacters;
                                                                                        var paragraph = $(".description")
                                                                                        paragraph.each(function() {
                                                                                        var text = $(this).text();
                                                                                                var wholeText = text.slice(0, visibleCharacters) + "<span class='ellipsis'>... </span><a href='#' class='more'>MORE</a>" + "<span style='display:none'>" + text.slice(visibleCharacters, text.length) + "<a href='#' class='less'> LESS</a></span>"
                                                                                                if (text.length < visibleCharacters) {
                                                                                        return
                                                                                        } else {
                                                                                        $(this).html(wholeText)
                                                                                        }
                                                                                        });
                                                                                        $(".more").click(function(e) {
                                                                                e.preventDefault();
                                                                                        $(this).hide().prev().hide();
                                                                                        $(this).next().show();
                                                                                });
                                                                                        $(".less").click(function(e) {
                                                                                e.preventDefault();
                                                                                        $(this).parent().hide().prev().show().prev().show();
                                                                                });
                                                                                };
                                                                                        moreLess(300);

    </script>
