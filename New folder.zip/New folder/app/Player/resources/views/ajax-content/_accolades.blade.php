@if($user->userAccoladesExperince->count() > 0)
@php
$i=0;
@endphp
@foreach($user->userAccoladesExperince as $userAccolades)
@php
if($i == 3){
break;
}
$i++;
@endphp
<li class="list-inline-item list">
    <img src="{{ checkUserImage($userAccolades->logo, 'player/thumb','accolades-experience') }}" alt="icon">
    <h3 class="color-green">{{!empty($userAccolades->name) ? ucfirst($userAccolades->name) : '-'}}</h3>
    <h6 class="color-white">{{getPositionName($user->position_id)}}</h6>
    <p class="color-green">{{!empty($userAccolades->present_year) ? $userAccolades->present_year : '-'}}</p>
</li>
@endforeach
@else
<div class="alert alert-danger" role="alert">
    No Accolades Found!
</div>
@endif