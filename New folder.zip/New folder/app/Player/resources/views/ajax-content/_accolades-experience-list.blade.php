<div class="modal-header">
    <h5 class="modal-title" id="post_title">Accolades</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body p-0">
    <div class="scroll_body black-scroll">
        <div class="table-responsive">
            <table class="table info_table mb-0">
                <thead>
                    <tr>
                        <tr>
                        <th>Logo</th>
                        <th>Name of accolades</th>
                        <th>Presenting Organization</th>
                        <th>Year of Presentation</th>
                         </tr>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($accolades as $accolad) { ?>
                        <tr>
                            <td>
                                <div class="logo border rounded-circle">
                                    <img src="{{ checkUserImage($accolad->logo, 'player/thumb','logo')}}" alt="logo" width="20">
                                </div>
                            </td>
                            <td>{{$accolad->name}}</td>
                            <td>{{$accolad->present_organization}}</td>
                            <td>{{$accolad->present_year}}</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>