@if($user->userCoachingExperince->count() > 0)
@php
$i=0;
@endphp
@foreach($user->userCoachingExperince as $userCoaching)
@php
if($i == 3){
break;
}
$i++;
@endphp
<li class="list-inline-item list">
    <img src="{{ checkUserImage($userCoaching->logo, 'player/thumb','logo') }}" alt="icon">
    <h3 class="color-black">{{!empty($userCoaching->name) ? ucfirst($userCoaching->name) : '-'}}</h3>
    <h6 class="color-black">{{getPositionName($user->position_id)}}</h6>
    <p class="color-black">{{$userCoaching->from_year .' TO '.  $userCoaching->to_year}}</p>
</li>
@endforeach
@else
<div class="alert alert-danger" role="alert">
    No Coaching Experience Found!
</div>
@endif