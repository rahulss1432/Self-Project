@if( $appliedJobs->count() > 0 )
@foreach( $appliedJobs as $appliedJob)
<li class="list-inline-item">
    <div class="job-block"> 
        <div class="jb_logo">
            <a href="{{url('jobs-detail',base64_encode($appliedJob->job_id))}}"><img src="{{ checkUserImage($appliedJob->job->user->profile_image, 'team/thumb','') }}" alt="job logo"></a>
        </div>
        <div class="jb_info d-flex justify-content-between">
            <ul class="list-unstyled">
                <li>
                    <label>NAME</label>
                    <p>{{!empty($appliedJob->job->institution_name) ? $appliedJob->job->institution_name : '-'}}</p>
                </li>
                <li>
                    <label>INSTITUTION TYPE</label>
                    <p>{{!empty($appliedJob->job->institution_type) ? $appliedJob->job->institution_type : '-'}}</p>
                </li>
                <li>
                    <label>JOB TYPE</label>
                    <p>{{!empty($appliedJob->job->job_type) ? $appliedJob->job->job_type : '-'}}</p>
                </li>
                @php
                $positionName = getJobPositionName($appliedJob->job->position_id);
                @endphp            
                @if($appliedJob->job->job_type == 'player')            
                <li>
                    <label>POSITION TITLE</label>
                    @if (!empty($positionName))                
                    <p>{{getLimitText(10,implode(',',$positionName))}}</p>
                    @else
                    <p>-</p>
                    @endif
                </li>
                <li>
                    <label>LEVEL</label>
                    <p>{{!empty($appliedJob->job->level->level_name) ? $appliedJob->job->level->level_name : '-'}}</p>
                </li>
                @else
                <li>
                    <label>POSITION AREA</label>
                    @if (!empty($positionName))                
                    @foreach($positionName as $val)                                                            
                    <p>{{$val}}</p>
                    @endforeach
                    @else
                    <p>-</p>
                    @endif
                </li> 
                <li>
                    <label>POSITION TITLE</label>
                    <p>{{getLimitText(8, !empty($appliedJob->job->position_title) ? $appliedJob->job->position_title : '-')}}</p>
                </li> 
                @endif
            </ul>
            <ul class="list-unstyled">
                <li>
                    <label>LEAGUE or CONFERENCE</label>
                    <p class="text-uppercase">{{!empty($appliedJob->job->conference) ? $appliedJob->job->conference : '-'}}</p>
                </li>
                <li>
                    <label>LOCATION</label>
                    <p>{{!empty($appliedJob->job->country->name) ? $appliedJob->job->country->name : '-'}}</p>
                </li>
                <li>
                    <img class="flag" src="{{ checkFlagImage(!empty($appliedJob->job->country->short_name) ? $appliedJob->job->country->short_name : '', 'small') }}" alt="flag">
                </li>
                <li>
                    <label>DATE</label>
                    <p>{{getMonthDateYearFormat($appliedJob->job->created_at)}}</p>
                </li>
            </ul>
            <ul class="list-unstyled views">
                <li>
                    <label>VIEWS</label>
                    <p>{{getViewCountByJob($appliedJob->job->id)}}</p>
                </li>
                <li>
                    <a href="{{url('jobs-detail',base64_encode($appliedJob->job_id))}}" class="btn btn-primary text-uppercase">VIEW</a>
                </li>
                <li>
                    <a href="javascript:void(0);" onclick="ShareModal('job-share', {{$appliedJob->job_id}})">
                        <span class="icon icon-share_icon"></span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</li>

@endforeach
@else
<div class="alert alert-danger w-70 mt-md-5 mt-3" role="alert">
    No Jobs Available!
</div>
@endif