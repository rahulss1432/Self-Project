@if($getMedia->media_type == 'image')
<div class="leftside float-lg-left d-flex align-items-center justify-content-center" >
    <img src="{{ checkMediaImage($getMedia->media, $getMedia->user->role) }}" class="img-fluid" alt="post img">
    <div class="overlay"></div>
</div>
@else
<div class="leftside float-lg-left d-flex align-items-center justify-content-center">
    <video controls >
        <source src="{{ checkMediaVideo($getMedia->media, $getMedia->user->role) }}" type="video/mp4">
    </video>
</div>
@endif  
<div class="rightside pr-0 float-lg-left">
    <div class="manage_post">
        <div class="post_comment">
            <div class="inner pb-0">
               <h2>{{ ($getMedia->user) ? $getMedia->user->reference_id : '' }}</h2>
               <h3>{{ (!empty(getUserFullNameById($getMedia->user_id))) ? getUserFullNameById($getMedia->user_id) : '-' }}</h3>
                <div class="d-flex align-items-center  mt-2 mt-sm-4">
                    <p class="date_time mb-0">{{ dateTimeFormat($getMedia->created_at) }}</p>
                    <ul class="list-inline mb-0 ml-auto">
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" id="likeCount" onclick="getMediaLikeUserList('{{ $getMedia->id }}')"><i class="icon icon-thumb-up-sign icon"></i>{{ mediaLikeCount($getMedia->id,'like') }}</a></li>
                        <li class="list-inline-item" id="commentCount"><i class="icon icon-chat icon"></i>{{ mediaLikeCount($getMedia->id, 'comment')}}</li>
                    </ul>
                </div>
            </div>
            <div class="post_info mt-3 pr-0 pt-0">
                <h3 class="text-truncate">{{ ($getMedia->post) ? $getMedia->post->post : '' }}</h3>
            </div>
        </div>
        <div class="post_comment_listing">
            <h2 class="heading">Comments</h2>
            <div class="ajax_list_load" id="get-media-comment-list"></div>
        </div>
        <div class="user_comment collapse show pt-0" id="comment01" style="">
          <div class="like_icon">
                @php $loginUser = Auth::guard(getAuthGuard())->user()->id; @endphp
                <a href="javascript:void(0);"  id="like-btn" class="{{ (checkUserMediaLike($getMedia->id, $loginUser, 'like') != 0) ? 'active' : '' }}" onclick="likeMedia('{{ $getMedia->id }}','{{ $getMedia->user_id }}')"><i class="icon icon-thumb-up-sign icon"></i></a>
          </div>
            <div class="comment_box">
                 <form action="javascript:void(0)" id="commentForm">
                    <input type="hidden" name="media_id" value="{{ $getMedia->id }}">
                    <input type="hidden" name="to_id" value="{{ $getMedia->user_id }}">
                    <input class="form-control" name="comment" id="commentdata" type="text" placeholder="Write a Comment...">
                    <div class="uploadicon">
                        <button class="icon-sent-mail" id="saveCommentbtn" onclick="saveMediaComment('{{ $getMedia->id }}','{{ $getMedia->user_id }}')"></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        getMediaCommentList('{{ $getMedia->id }}');
    });

//get comment list on this media
    function getMediaCommentList(mediaId) {
        $("#get-media-comment-list").html('<span class="ajax_loader btn_ring"></span>');
        var url = '{{ url("player/media-comment-list") }}';
        $.ajax({
            type: "GET", url: url, data: {media_id: mediaId},
            success: function (response) {
                $("#get-media-comment-list").html(response.html);
                $(".comment").mCustomScrollbar({
                    theme:"dark",
                    axis:"y",
                }); 
            }
        });
    }
    
//    save comment media on side
    function saveMediaComment(mediaId, toId) {
      var comment = document.getElementById('commentdata').value;
        if(comment == ''){
            return false;
        }
        $('#saveCommentbtn').prop('disabled', true);
        var url = "{{  url('player/save-media-comment') }}";
        var formData = $("#commentForm").serializeArray();
        formData.push({name: '_token', value: '{{ csrf_token() }}'});
        $.ajax({
            url: url,
            data: formData,
            type: 'POST',
            success: function (data) {
                $('#saveCommentbtn').prop('disabled', false);
                if (data.success) {
                     $('#commentCount').html(''); 
                     $('#commentCount').html('<i class="icon icon-chat icon"></i>' + data.count); 
                     $('#commentdata').val('');
                     getMediaCommentList(mediaId);   
                } else {
                    message('error', data.message);
                }
            },
            error: function (err) {
                message('error', err);
            },
        });
    }
    
//  save like media
    function likeMedia(mediaId, toId){ 
        var url = "{{  url('player/save-media-like') }}";
            $.ajax({
            url: url,
            data: {media_id:mediaId, to_id:toId},
            type: 'GET',
            success: function (data) {
                if (data.success) {
                       $('#likeCount').html('');
                       $('#likeCount').html('<i class="icon icon-thumb-up-sign icon"></i>' + data.count);
                       if(data.event == 'unlike'){
                           $('#like-btn').attr('class','inactive');
                       }else{
                           $('#like-btn').attr('class','active');
                       }
                } else {
                    message('error', data.message);
                }
            },
        });     
    }  
    
    
//  get like media user list
  function getMediaLikeUserList(mediaId) {
    var countLike = $('#likeCount').text();
    if(countLike != 0){
    $('#likeCount').attr('data-dismiss','modal');    
    $('#users_like').modal('show');
    $.post("{{ url('player/get-media-like-user') }}", {media_id: mediaId,_token: '{{ csrf_token() }}'}, function (response) {
        if (response.success) {
            $('#LikeUserList').html(response.html);
        } else {
            message('error', response.message);
        }
    });
   }
}

    $(document).ready(function() {
         if($(window).width() >= 1024){
             var divHeight = $('#myPhotosVideos .leftside').height(); 
            $('#myPhotosVideos .rightside').css('height', divHeight+'px');
         }
       
    });
</script>
