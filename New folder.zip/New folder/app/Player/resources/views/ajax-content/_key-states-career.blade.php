<div class="inner_section green-scroll key-states-career" data-mcs-theme="dark">
    <div class="offence">
        <h6 class="font_14 mb-3">Offence</h6>
        <div class="row common_row">
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total passing yards:</label>
                    <span>{{$currentKey->total_passing + $pastKey->total_passing}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average passing yards (Game):</label>
                    <!--<span>{{ $currentKey->passing_game + $pastKey->passing_game }}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average passing yards (Season):</label>
                    <!--<span>{{$currentKey->passing_season + $pastKey->passing_season}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Completions:</label>
                    <span>{{$currentKey->completion + $pastKey->completion}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Completions<span style="font-family:initial;">(%)</span>:</label>
                    <span>-</span>
                    </span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">QB passer rating:</label>
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total rushing yards:</label>
                    <span>{{$currentKey->total_rushing + $pastKey->total_rushing}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average rushing yards (Game):</label>
                    <!--<span>{{$currentKey->rushing_game + $pastKey->rushing_game}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average rushing yards (Season):</label>
                    <!--<span>{{$currentKey->rushing_season + $pastKey->rushing_season}}</span>-->
                    <span>-</span>
                </div>
            </div>

            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total receiving yards:</label>
                    <span>{{$currentKey->total_receiving + $pastKey->total_receiving}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average receiving yards (Game):</label>
                    <!--<span>{{$currentKey->receiving_game + $pastKey->receiving_game}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average receiving yards (Season):</label>
                    <!--<span>{{$currentKey->receiving_season + $pastKey->receiving_season}}</span>-->
                    <span>-</span>
                </div>
            </div>

            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total return yards:</label>
                    <span>{{$currentKey->total_return + $pastKey->total_return}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average return yards (Game):</label>
                    <!--<span>{{$currentKey->return_game + $pastKey->return_game}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average return yards (Season):</label>
                    <!--<span>{{$currentKey->return_season + $pastKey->return_season}}</span>-->
                    <span>-</span>
                </div>
            </div>

            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Total all purpose yards:</label>
                    <span>{{$currentKey->total_all_purpose + $pastKey->total_all_purpose}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average all purpose yards (Game):</label>
                    <!--<span>{{$currentKey->purpose_game + $pastKey->purpose_game}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Average all purpose yards (Season):</label>
                    <!--<span>{{$currentKey->purpose_season + $pastKey->purpose_season}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Touchdowns:</label>
                    <span>{{$currentKey->tuchdowns + $pastKey->tuchdowns}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block">Games played:</label>
                    <span>{{$currentKey->games_played + $pastKey->games_played}}</span>
                </div>
            </div>
        </div>
    </div>
    <div class="defence">
        <h6 class="font_14 mb-3">Defence</h6>
        <div class="row common_row">
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total tackles:</label>  
                    <span>{{$currentKey->tackles + $pastKey->tackles}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles (Game):</label> 
                    <!--<span>{{$currentKey->tackles_game + $pastKey->tackles_game}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles (Season):</label>   
                    <!--<span>{{$currentKey->tackles_season + $pastKey->tackles_season}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total tackles for loss:</label> 
                    <span>{{$currentKey->total_tackloss + $pastKey->total_tackloss}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles for loss (Game):</label>    
                    <!--<span>{{$currentKey->tackloss_game + $pastKey->tackloss_game}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average tackles for loss (Season):</label>  
                    <!--<span>{{$currentKey->tackloss_season + $pastKey->tackloss_season}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total sacks:</label>    
                    <span>{{$currentKey->total_sacks + $pastKey->total_sacks}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average sacks (Game):</label>   
                    <!--<span>{{$currentKey->sacks_game + $pastKey->sacks_game}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average sacks (Season):</label> 
                    <!--<span>{{$currentKey->sacks_season + $pastKey->sacks_season}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total pass breakups:</label>    
                    <span>{{$currentKey->total_breaksups + $pastKey->total_breaksups}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average pass breakups (Game):</label>   
                    <!--<span>{{$currentKey->breaksups_game + $pastKey->breaksups_game}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Average pass breakups (Season):</label> 
                    <!--<span>{{$currentKey->breaksups_season + $pastKey->breaksups_season}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="info_row">
                    <label class="d-block mb-2">Total Interceptions:</label>    
                    <span>{{$currentKey->total_interception + $pastKey->total_interception}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Average Interceptions (Game):</label>   
                    <!--<span>{{$currentKey->interception_game + $pastKey->interception_game}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Average Interceptions (Season):</label> 
                    <!--<span>{{$currentKey->interception_season + $pastKey->interception_season}}</span>-->
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Blocked punts:</label>  
                    <span>{{$currentKey->blocked_punts + $pastKey->blocked_punts}}</span>
                </div>
            </div>
        </div>
    </div>
    <div class="specials">
        <h6 class="font_14 mb-3">Specials</h6>
        <div class="row common_row">
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Total field goals:</label>  
                    <span>{{$currentKey->total_field_goal + $pastKey->total_field_goal}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Longest field goal:</label> 
                    <span>{{$currentKey->longest_field_goal + $pastKey->longest_field_goal}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Field goal percentage:</label>  
                    <span>-</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Longest punt:</label>   
                    <span>{{$currentKey->longest_punt + $pastKey->longest_punt}}</span>
                </div>
            </div>
            <div class="col-sm-4 col-6">
                <div class="form-group info_row">
                    <label class="d-block mb-2">Average punt distance:</label>  
                    <!--<span class="text-capitalize">{{$currentKey->avg_punt_distance + $pastKey->avg_punt_distance}}</span>-->
                    <span class="text-capitalize">-</span>
                </div>
            </div>
        </div>
    </div>
</div>