@php $checkVar = 0; @endphp
@if( count($users) > 0 )
@foreach( $users as $user )
@php $userId = \Auth::guard(getAuthGuard())->user()->id;
if( $userId == $user->to_id ){
$to_id = $user->from_id;
}else{
$to_id = $user->to_id;
}
$lstMsg=lastMessage($user->id);
$checkWorkMode=getUserById($to_id, 'current_status');
@endphp
@if($checkWorkMode == 'available')
<li id="user_{{ $user->id }}">
    <a href="javascript:void(0);" onclick="getUserMessages('{{ $user->id }}', '{{ $to_id }}')">
        <div class="user">
            <div class="user_img">
                @if( checkUnreadCount($user->id) > 0 )
                <span class="badge count">{{ checkUnreadCount($user->id) }}</span>
                @endif
                <span class="{{(getUserById($to_id, 'availability') == 'online'?'online':'')}} rounded-circle" id="user_{{ $to_id }}"></span>
                <img class="rounded-circle" src="{{ checkUserImage(getUserById($to_id, 'profile_image'), getUserById($to_id, 'role').'/thumb') }}" alt="user img">
            </div>	
            <div class="user_info">
                <h4>
                    <span class="title color-black chatUserName" data-user_id="{{ $user->id }}">{{ getUserById($to_id, 'first_name') }}</span>
                    <span class="date">{{ !empty($lstMsg)?dateDayAgo($lstMsg->created_at):'' }}</span>
                </h4>
                <p class="sub_title mb-0" id="user-last-msg-{{ $to_id }}">@if(!empty($lstMsg)) {!! $lstMsg->message !!} @else {{''}} @endif</p>
                <span id="typing-hint-{{ $user->id }}" style="display: none">Typing...</span>
            </div>
        </div>
    </a>
</li>
@php $checkVar++; @endphp
@endif
@endforeach
@else
<div class="alert_msg">
    <div class="alert alert-danger mt-md-5 mt-3">No user found</div>
</div>

@endif
<div class="alert_msg">
    <div class="alert alert-danger mt-md-5 mt-3" id="no_user" style="display: none;">No user found</div>
</div>
@if(empty($checkVar) && $checkVar <= 0)
<div class="alert_msg">
    <div class="alert alert-danger mt-md-5 mt-3">No user found</div>
</div>
@endif
<script>
            $('#get-chat-users').mCustomScrollbar({
    theme:"dark",
            axis:"y"
    });
            socket.on('get-offline', function(data){
            $("#user_" + data.userID).removeClass('online');
            });
            socket.on('set-online', function(data){
            $("#user_" + data.userID).addClass('online');
            });
            /* case of responsive */
            $(".chat_users .users_list li a").click(function () {
            $('.chat_list .chat_content').addClass("open");
            });
            $("#backicon").click(function () {
            $('.chat_list .chat_content').removeClass("open");
            });
</script>
