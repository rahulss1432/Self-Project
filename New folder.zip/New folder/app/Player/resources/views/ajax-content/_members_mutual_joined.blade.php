<!-- member you may know page slider content -->
@if(count($users)>0)
@php
$i=0;
@endphp
@foreach($users as $user)
@php
if($i == 15){
break;
}
$i++;
@endphp
@if($user->role == 'player')
<div class="item" id="divJoinedMember_{{$user->id}}">
    <a href="{{ url('view/player-profile/'.$user->slug )}}">
        <div class="player details ">
            <div class="top-heading d-flex">
                <img src="{{ url('public/images/black_logo.png')}}" alt="logo">
                <h2>{{$user->full_name}}</h2>
            </div>
            <div class="info-sec">
                <div class="left">
                    <ul class="list-unstyled">
                        <li><p>HT</p><span>{{!empty($user->userMeasurables->height_ft) ? $user->userMeasurables->height_ft : 0 }}'{{!empty($user->userMeasurables->height_in) ? $user->userMeasurables->height_in : 0}}''</span></li>
                        <li><p>WT</p><span>{{!empty($user->userMeasurables->weight) ? $user->userMeasurables->weight : '-' }}</span></li>
                        <li><p>40</p><span>{{!empty($user->userMeasurables->fourty) ? $user->userMeasurables->fourty : '-' }}</span></li>
                        <li><p>VERT</p><span>{{!empty($user->userMeasurables->vert) ? $user->userMeasurables->vert : '-' }}</span></li>
                    </ul>
                </div>
                <div class="right d-flex flex-wrap">
                    <div class="profile-box">
                        <div class="user_profile">
                            <img src="{{ checkUserImage($user->profile_image, 'player/thumb','') }}" alt="player">
                        </div>
                        <div class="profile-box-bottom d-flex align-items-center">
                            <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'small') }}" alt="FLAG">
                            <h4>{{getLimitText('8', !empty($user->country->name) ? $user->country->name : '-')}}</h4>
                        </div>
                    </div>
                    <div class="user_details">
                        <div class="player-top d-flex">
                            <h4>{{$user->role}} </h4>
                            <span>{{!empty($user->position_id) ? getLimitText(5,getPositionName($user->position_id)) : '-'}}</span>
                        </div>
                        <ul class="list-unstyled mb-0">
                            <li>
                                <h4>AGE: <span>{{$user->age}}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENTLY UNDER CONTRACT: <span>{{ !empty($user->userGeneral->under_contract) ?  strtoupper($user->userGeneral->under_contract) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENT TEAM: <span>{{ !empty($user->userGeneral->current_team) ?  ucfirst(getLimitText(8,$user->userGeneral->current_team)) : '-' }}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENT LEAGUE: <span>{{!empty($user->userGeneral->current_league) ? ucfirst(getLimitText(8,$user->userGeneral->current_league)) : '-'}}</span></h4>
                            </li>
                            <li>
                                <h4>LOOKING TO SIGN: <span>{{!empty($user->userGeneral->look_to_sign) ? strtoupper($user->userGeneral->look_to_sign) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>PASSPORT READY: <span>{{!empty($user->userGeneral->passport) ?  strtoupper($user->userGeneral->passport) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4> PREP/COLLEGE EXPERIENCE: <span>{{!empty($user->userCollegeExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>PRO EXPERIENCE: <span>{{!empty($user->userProExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>INTERNATIONAL EXPERIENCE: <span>{{!empty($user->userInternationalExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>INDOOR  EXPERIENCE: <span>{{ !empty($user->userIndooreExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                        </ul>
                    </div>
                    <div class="bottom-sec">
                        <h6>freeagentfootball.com</h6>
                    </div>
                </div>
            </div>
            <div class="share-bottom">
                <span class="icon-share_icon"></span>
            </div>
        </div>
    </a>
    @if(empty($o_id))
    <div class="action_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-sm border-1"  onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>
            CONNECT
        </a>
        <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1"  onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>
            DISMISS
        </a>
    </div>
    @else
    <div class="action_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-sm border-1" onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>CONNECT</a>
        <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1" onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>DISMISS</a>
    </div>
    @endif
</div>
@elseif($user->role == 'coach')
<div class="item" id="divJoinedMember_{{$user->id}}">
    <a href="{{ url('view/coach-profile/'. $user->slug )}}">
        <div class="coach details">
            <div class="top-heading d-flex">
                <img src="{{ url('public/images/black_logo.png')}}" alt="logo">
                <h2>{{$user->full_name}}</h2>
            </div>
            <div class="info-sec">
                <div class="right d-flex flex-wrap">
                    <div class="profile-box">
                        <div class="user_profile">
                            <img src="{{ checkUserImage($user->profile_image, 'coach/thumb','') }}" alt="player">
                        </div>
                        <div class="profile-box-bottom d-flex align-items-center">
                            <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '-', 'small') }}" alt="FLAG">
                            <h4>{{getLimitText('8', !empty($user->country->name) ? $user->country->name : '-')}}</h4>
                        </div>
                    </div>
                    <div class="user_details">
                        <div class="player-top d-flex">
                            <h4>{{ucfirst($user->role)}} </h4>
                            <span>{{!empty($user->position_id) ? getLimitText(5,getPositionName($user->position_id)) : '-'}}</span>
                        </div>
                        <ul class="list-unstyled mb-0">
                            <li>
                                <h4>AGE: <span>{{$user->age}}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENTLY UNDER CONTRACT: <span>{{ !empty($user->userGeneral->under_contract) ?  strtoupper($user->userGeneral->under_contract) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENT TEAM: <span>{{ !empty($user->userGeneral->current_team) ?  ucfirst(getLimitText(8,$user->userGeneral->current_team)) : '-' }}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENT LEAGUE: <span>{{!empty($user->userGeneral->current_league) ? ucfirst(getLimitText(8,$user->userGeneral->current_league)) : '-'}}</span></h4>
                            </li>
                            <li>
                                <h4>LOOKING TO SIGN: <span>{{!empty($user->userGeneral->look_to_sign) ? strtoupper($user->userGeneral->look_to_sign) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>PASSPORT READY: <span>{{!empty($user->userGeneral->passport) ?  strtoupper($user->userGeneral->passport) : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4> PREP/COLLEGE EXPERIENCE: <span>{{!empty($user->userCollegeExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>PRO EXPERIENCE: <span>{{!empty($user->userProExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>INTERNATIONAL EXPERIENCE: <span>{{!empty($user->userInternationalExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                            <li>
                                <h4>3-DOWN EXPERIENCE: <span>{{!empty($user->userGeneral->playing_exp) ? 'YES' : 'NO'}}</span></h4>
                            </li> 
                            <li>
                                <h4>INDOOR  EXPERIENCE: <span>{{ !empty($user->userIndooreExperince) ? 'YES' : 'NO'}}</span></h4>
                            </li>
                        </ul>

                    </div>
                    <div class="bottom-sec">
                        <h6>freeagentfootball.com</h6>
                    </div>
                </div>
            </div>

            <div class="share-bottom">
                <span class="icon-share_icon"></span>
            </div>
        </div>
    </a>
    @if(empty($o_id))

    <div class="action_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-sm border-1"  onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>
            CONNECT
        </a>
        <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1"  onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>
            DISMISS
        </a>
    </div>
    @else
    <div class="action_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-sm border-1" onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>CONNECT</a>
        <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1" onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>DISMISS</a>
    </div>
    @endif
</div>
@elseif($user->role == 'team')
<div class="item" id="divJoinedMember_{{$user->id}}">
    <a href="{{ url('view/team-profile/'. $user->slug )}}">
        <div class="coach details team">
            <div class="top-heading d-flex">
                <img src="{{url('public/images/black_logo.png')}}" alt="logo">
                <h2>{{$user->full_name}}</h2>
            </div>
            <div class="info-sec">
                <div class="right d-flex flex-wrap">
                    <div class="profile-box">
                        <div class="user_profile">
                            <img src="{{ checkUserImage($user->profile_image, 'team/thumb','') }}" alt="team">
                        </div>
                        <div class="profile-box-bottom d-flex align-items-center">
                            <img src="{{ checkFlagImage(!empty($user->country->short_name) ? $user->country->short_name : '', 'small') }}" alt="FLAG">
                            <h4>{{getLimitText('8', !empty($user->country->name) ? $user->country->name : '-')}}</h4>
                        </div>
                    </div>
                    <div class="user_details">
                        <div class="player-top d-flex">
                            <h4>{{ucfirst($user->role)}} </h4>
                            <span>{{!empty($user->userLevel->level_name) ? getLimitText(5,$user->userLevel->level_name) : '-'}}</span>
                        </div>
                        <!--                        <ul class="list-unstyled mb-0">
                                                    <li>
                                                        <h4>AGE: <span>24</span></h4>
                                                    </li>
                                                    <li>
                                                        <h4>CURRENTLY UNDER CONTRACT: <span>{{ !empty($user->userGeneral->under_contract) ?  strtoupper($user->userGeneral->under_contract) : 'NO'}}</span></h4>
                                                    </li>
                                                    <li>
                                                        <h4>CURRENT TEAM: <span>Altianta Havoc</span></h4>
                                                    </li>
                                                    <li>
                                                        <h4>CURRENT LEAGUE: <span>{{!empty($user->userGeneral->current_league) ? ucfirst($user->userGeneral->current_league) : '-'}}</span></h4>
                                                    </li>
                                                    <li>
                                                        <h4>LOOKING TO SIGN: <span>NO</span></h4>
                                                    </li>
                                                    <li>
                                                        <h4>PASSPORT READY: <span>NO</span></h4>
                                                    </li>
                                                    <li>
                                                        <h4> PREP/COLLEGE EXPERIENCE: <span>YES</span></h4>
                                                    </li>
                                                    <li>
                                                        <h4>PRO EXPERIENCE: <span>YES</span></h4>
                                                    </li>
                                                    <li>
                                                        <h4>INTERNATIONAL EXPERIENCE: <span>YES</span></h4>
                                                    </li>
                                                    <li>
                                                        <h4>INDOOR  EXPERIENCE: <span>YES</span></h4>
                                                    </li>
                                                </ul>-->
                        <ul class="list-unstyled mb-0">
                            <li>
                                <h4>STATE/PROVINCE: <span>{{!empty($user->state)? $user->state->state_name : '-' }}</span></h4>
                            </li>
                            <li>
                                <h4>YEARS IN EXISTENCE: <span>{{!empty($user->userGeneral->playing_exp) ? $user->userGeneral->playing_exp : '-' }}</span></h4>
                            </li>
                            <li>
                                <h4>CURRENTLY RECRUITING: <span>{{!empty($user->userGeneral->recruiting) ? strtoupper($user->userGeneral->recruiting) : 'NO' }}</span></h4>
                            </li>
                            <li>
                                <h4>LEAGUE: <span>{{!empty($user->userGeneral->current_league) ? getLimitText(8,ucfirst($user->userGeneral->current_league)) : '-'}}</span></h4>                                
                            </li>
                        </ul>
                    </div>
                    <div class="bottom-sec">
                        <h6>freeagentfootball.com</h6>
                    </div>
                </div>
            </div>

            <div class="share-bottom">
                <span class="icon-share_icon"></span>
            </div>
        </div>
    </a>
    @if(empty($o_id))

    <div class="action_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-sm border-1"  onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>
            CONNECT
        </a>
        <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1"  onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>
            DISMISS
        </a>
    </div>
    @else
    <div class="action_btn">
        <a href="javascript:void(0);" class="btn btn-success btn-sm border-1" onclick='connectDismissMember("{{$user->id}}", "connect",$(this))'>CONNECT</a>
        <a href="javascript:void(0);" class="btn btn-secondary btn-sm border-1" onclick='connectDismissMember("{{$user->id}}", "dismiss",$(this))'>DISMISS</a>
    </div>
    @endif
</div>
@endif
@endforeach
<div class="item">
    @if(!empty($o_id))
    <a href="{{ url('player/members-you-may-know/'.getUserById($o_id, 'slug')) }}">
        <img class="img-fluid" src="{{ url('public/images/defaultpro_card.png') }}" alt="procard">
    </a>
    @else
    <a href="{{ url('player/members-you-may-know') }}">
        <img class="img-fluid" src="{{ url('public/images/defaultpro_card.png') }}" alt="procard">
    </a>
    @endif
</div>
@else
<div class="item">
    <img class="img-fluid" src="{{ url('public/images/norecordpro_card.png') }}" alt="procard">        
</div>
<!--<div class="item">
    <a href="javascript:void(0)">
        <img class="img-fluid" src="{{ url('public/images/defaultpro_card.png') }}" alt="procard">
    </a>
</div>-->
<!--<script>$("#sliderDiv").hide();</script>-->
@endif