@if( count($comments) > 0 )
@foreach( $comments as $comment )
<li class="msg d-flex">
    <div class="msg_left">
        <img src="{{ checkUserImage($comment->user->profile_image, $comment->user->role.'/thumb') }}" class="rounded-circle" alt="user">
    </div>
    <div class="msg_body">
        <h6 class="msg_heading">
            {{ $comment->user->first_name . ' ' . $comment->user->last_name }}
            <span class="time">| &nbsp; {{ dateDayAgo($comment->created_at) }}</span>
        </h6>
        <p>{{ $comment->comment }}</p>
    </div>
</li>
@endforeach
<a href="javascript:void(0);" class="load-more-btn-reply-{{ $comment->post_action_id }}" onclick="loadMoreCommentReply('{{ $comment->post_action_id }}')">View all reply</a>
@endif

<script>
    
    // Function for save post comment reply.
    $(document).on('submit', '.comment-reply-form', function (e) {
        e.preventDefault();
        var comment_id = $(this).find('[name="comment_id"]').val();
        var comment = $(this).find('[name="comment"]').val();
        if (comment == '') {
            $(this).find('[name="comment"]').focus();
        } else {
            $.post($(this).attr('action'), $(this).serialize(), function (data) {
                if (data.success) {
                    $('.comment-reply-form').trigger('reset');
                    getPostCommentsReply(comment_id);
                } else {
                    message('error', data.message);
                }
            });
        }
    });

    // Function for get post comment reply.
    function getPostCommentsReply(comment_id) {
        $.post("{{ url('player/get-post-comments-reply') }}", {_token: '{{ csrf_token() }}', comment_id: comment_id}, function (response) {
            if (response.success) {
                $('#post-comments-reply-' + comment_id).html(response.html);
                $('#post-comments-reply-count-' + comment_id).html(response.count);
            } else {
                message('error', response.message);
            }
        });
    }

    // Function for load more comments.
    function loadMoreCommentReply(comment_id) {
        $('.load-more-btn-reply-' + comment_id).hide();
        var pageNumber = localStorage.getItem("commentReply" + comment_id);
        $.post("{{ url('player/get-post-comments-reply') }}", {_token: "{{ csrf_token() }}", comment_id: comment_id, page: pageNumber}, function (data) {
            localStorage.setItem("commentReply" + comment_id, parseInt(pageNumber) + 1);
            if (data.count == 0) {
                $('#post-comments-reply-' + comment_id).append(data.html);
                $('.load-more-btn-reply-' + comment_id).hide();
            } else {
                $('#post-comments-reply-' + comment_id).append(data.html);
            }
        });
    }
    </script>