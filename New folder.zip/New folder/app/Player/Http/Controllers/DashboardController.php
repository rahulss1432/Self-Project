<?php

namespace App\Player\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;

class DashboardController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('player::player.index');
    }

    public function postView(){
       $html = View::make('player::ajax-content._post-view')->render();
       return Response::json(['html' => $html]);
    }

    public function newJobList(){
        $html = View::make('player::ajax-content._new-job-list')->render();
        return Response::json(['html' => $html]);
    }

    public function appliedJobList(){
        $html = View::make('player::ajax-content._applied-job-list')->render();
        return Response::json(['html' => $html]);
    }
    
    public function playerProfile(){
        return view('player::player.player-profile');
    }
    
    public function playerTimeline(){
        return view('player::player.player-timeline');
    }
    
    public function playerMedia(){
        return view('player::player.player-media');
    }

}
