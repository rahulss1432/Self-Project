<?php

namespace App\Player\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use App\Repositories\Player\UserRepository;
use App\Repositories\Player\Attribute;
use Illuminate\Support\Facades\Auth;
use App\Player\Http\Requests\PlayerStepSevenRequest;
use App\Player\Http\Requests\PlayerStepOneRequest;
use App\Repositories\Player\EventRepository;
use App\Player\Http\Requests\PlayerStepThreeRequest;

class PlayerController extends Controller {
    /*
     * Class Construct.
     *
     * @param  array  $data
     * @return App\Player\Repositories\UserRepository;
     */

    public function __construct(UserRepository $user, EventRepository $event, Attribute $attribute, \App\Repositories\UserRepository $commanUser) {
        $this->user = $user;
        $this->event = $event;
        $this->attribute = $attribute;
        $this->commanUser = $commanUser;
    }

    /*
     * Show the application dashboard.
     */

    public function index() {
//        expiredAppliedJobByUser(Auth::guard(getAuthGuard())->user()->id);
        return view('player::player.index');
    }

    /*
     * function for get new jobs.
     */

    public function newJobList() {

        $jobs = $this->user->getPostJob();
        $html = View::make('player::ajax-content._new-job-list', ['jobs' => $jobs])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get applied job list.
     */

    public function appliedJobList() {
        $appliedJobs = $this->user->getPostAppliedJob();
        $html = View::make('player::ajax-content._applied-job-list', ['appliedJobs' => $appliedJobs])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for view profile.
     */

    public function playerProfile($slug = null) {
        $id = '';
        if (!empty($slug)) {
            $id = getUserIdBySlug($slug);
        }
        $user = $this->user->getUseDetails($id);
        $upcoming_events = $this->event->getLatestThreeEvents();
        $user_repository = \App\Models\News::getNewsBulletin('limited');
        $playerMeasurable = $this->user->playerMeasurable();
        return view('player::player.player-profile', ['user' => $user, 'latest_news' => $user_repository, 'playerMeasurable' => $playerMeasurable, 'upcoming_events' => $upcoming_events]);
    }

    /*
     * function using for get attribute list in front section
     */

    public function getValidateAttributeList() {
        $getAttributes = $this->attribute->getAttributes();
        $html = View::make('player::ajax-content._attribute-list', ['getAttributes' => $getAttributes])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function using for get other player profile list
     */

    public function otherPlayerAttrList(Request $request) {
        $getAttributes = $this->attribute->getAttributes();
        $fromUser = $this->user->getUseDetails($id = null);
        $toUser = $request['to_id'];
        $html = View::make('player::ajax-content._other-player-attr-list', ['getAttributes' => $getAttributes, 'fromUser' => $fromUser, 'toUser' => $toUser])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function using for select user attribute 
     */

    public function addSelectAttribute(Request $request) {
        return $this->attribute->addAttribute($request);
    }

    /*
     * function for view player timeline.
     */

    public function playerTimeline($slug = null) {
        $id = '';
        if (!empty($slug)) {
            $id = getUserIdBySlug($slug);
        }
        $user = $this->user->getUseDetails($id);
        return view('player::player.player-timeline', ['user' => $user, 'id' => $id]);
    }

    /*
     * function for view player media.
     */

    public function playerMedia($slug = null) {
        $id = '';
        if (!empty($slug)) {
            $id = getUserIdBySlug($slug);
        }
        $user = $this->user->getUseDetails($id);
        return view('player::player.player-media', ['user' => $user, 'id' => $id]);
    }

    /*
     * function for get select image 
     */

    public function getSelectMedia(Request $request) {
        $id = '';
        if (!empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $getSelectMedia = $this->commanUser->getSelectMedia($user->id);
        $html = View::make('player::ajax-content._get-select-media', ['getSelectMedia' => $getSelectMedia])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for update selected media file order 
     */

    public function updateSelectedMedia(Request $request) {
        $user = $this->user->getUseDetails($id = null);
        return $this->commanUser->updateSelectMedia($user->id, $request->media_id);
    }

    /*
     * function for get listing media videos 
     */

    public function getMediaVideoList(Request $request) {
        $id = '';
        if (!empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $getVideos = $this->commanUser->getMediaListByType('video', $user->id, 6);
        $html = View::make('player::ajax-content._media-video-list', ['getVideos' => $getVideos])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get listing media images 
     */

    public function getMediaImageList(Request $request) {
        $id = '';
        if (!empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $getimages = $this->commanUser->getMediaListByType('image', $user->id, 15);
        $html = View::make('player::ajax-content._media-image-list', ['getimages' => $getimages])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for view player profile edit form.
     */

    public function playerProfileForm() {
        $masterBenefits = $this->user->getAllBenefits();
        $userDetail = $this->user->getUseDetails(\Auth::guard(getAuthGuard())->user()->id);
        return view('player::player.player-step-form', ['masterBenefits' => $masterBenefits, 'userDetail' => $userDetail]);
    }

    /*
     * function for player profile step one.
     */

    public function playerStepOne(PlayerStepOneRequest $request) {
        return $this->user->playerStepOne($request);
    }

    /*
     * function for player profile step two.
     */

    public function playerStepTwo(Request $request) {
        return $this->user->playerStepTwo($request);
    }

    public function playerStepThreegeneral(PlayerStepThreeRequest $request) {

        return $this->user->playerStepThree($request);
    }

    public function playerAddUpdateExp(Request $request) {

        return $this->user->playerExpAddUpdate($request);
    }

    public function playerEditDeleteExp(Request $request) {
        return $this->user->playerExpEditDelete($request);
    }

    public function playerStepThree(Request $request) {
        $type = $request['type'];
        $data = $this->user->playerStepThreeAbout($type);
        $html = View::make('player::player._load-about', ['data' => $data, 'type' => $type])->render();
        return Response::Json(['html' => $html]);
    }

    /* player step 4 form */

    public function saveSeason(Request $request) {
        return $this->user->saveSeason($request->all());
    }

    public function deleteSeason($id) {
        return $this->user->deleteSeason($id);
    }

    public function getSavedPastSeason() {
        try {
            $pastSeasons = $this->user->getPastSeasons();
            $html = View::make('player::player._load-past-season', compact('pastSeasons'))->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /* End step 4 */
    /*
     * function for player profile step five.
     */

    public function playerStepFive(Request $request) {
        return $this->commanUser->saveMyProfileMedia($request);
    }

    /*
     * function for player profile step six.
     */

    public function playerStepSix(Request $request) {
        return $this->user->playerStepSix($request);
    }

    /*
     * function for player profile step six.
     */

    public function playerStepSeven(PlayerStepSevenRequest $request) {
        return $this->user->playerStepSeven($request);
    }

    /*
     * function for get pro card player.
     */

    public function playerProCard(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $html = View::make('player::ajax-content._procard-player', ['user' => $user])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get videos and users views.
     */

    public function getProfileMediaList(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $getUserMedia = $this->commanUser->getMediaListById($user->id);
        $html = View::make('player::ajax-content._videos_user_views', ['mediaList' => $getUserMedia, 'user' => $user])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get Accolades.
     */

    public function getAccolades(Request $request) {
        try {
            $id = '';
            if (!empty($request) && !empty($request->id)) {
                $id = $request->id;
            }
            $user = $this->user->getUseDetails($id);
            $html = View::make('player::ajax-content._accolades', ['user' => $user])->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * function for get Desired Benifites.
     */

    public function getDesiredBenifites(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $masterBenefits = \App\Models\MasterBenefits::where('created_by', 1)->where('title', '<>', 'Scholarship')->get();
        $html = View::make('player::ajax-content._desired_benifites', ['user' => $user, 'masterBenefits' => $masterBenefits])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * function for get coaching experiences.
     */

    public function getCoachingExperiences(Request $request) {
        try {
            $id = '';
            if (!empty($request) && !empty($request->id)) {
                $id = $request->id;
            }
            $user = $this->user->getUseDetails($id);
            $html = View::make('player::ajax-content._coaching_experinces', ['user' => $user])->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * function for get Community Service Experience.
     */

    public function getCommunityServiceExperience(Request $request) {
        try {
            $id = '';
            if (!empty($request) && !empty($request->id)) {
                $id = $request->id;
            }
            $user = $this->user->getUseDetails($id);
            $html = View::make('player::ajax-content._community_service_experience', ['user' => $user])->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * render the recent joined memeber page 
     */

    public function getRecentJoinedMembers(Request $request) {
        try {
            $o_id = '';
            if (!empty($request) && !empty($request->id)) {
                $o_id = $request->id;
            }
            $users = $this->user->getRecentJoinedMembers($request);
            $html = View::make('player::ajax-content._members_recent_joined', ['users' => $users, 'o_id' => $o_id])->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Show the members you may know page.
     */

    public function membersYouMayKnow($slug = null) {
        $id = '';
        if (!empty($slug)) {
            $id = getUserIdBySlug($slug);
        }
        return view('player::player.member-you-may-know', ['id' => $id]);
    }

    /*
     * Show all recent joined member list.
     */

    public function getMemberList(Request $request) {
        try {
            $o_id = '';
            if (!empty($request) && !empty($request->id)) {
                $o_id = $request->id;
            }
            $users = $this->user->getRecentJoinedMembers($request);
            $html = View::make('player::ajax-content._all_recent_member_list', ['users' => $users, 'o_id' => $o_id])->render();
            return Response::Json(['success' => true, 'html' => $html, 'users' => $users]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Connect or dismiss recent joined member.
     */

    public function connectDismissMember(Request $request) {
        return $this->user->connectDismissMember($request);
    }

    /*
     * Render left side bar.
     */

    public function leftSidebar(Request $request) {
        try {
            $id = '';
            $slug = '';
            if (!empty($request) && !empty($request->id)) {
                $id = $request->id;
                $slug = getUserById($id, 'slug');
            }
            if (empty(Auth::guard(getAuthGuard())->check())) {
                $user = '';
            } else {
                $user = $this->user->getUseDetails($id);
            }
            $mediaList = '';
            if (!empty($user)) {
                $mediaList = $this->commanUser->getMediaListById($user->id);
            }
            $html = View::make('player::player._load-left-side-html', ['user' => $user, 'page' => $request->page, 'slug' => $slug, 'mediaList' => $mediaList])->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Render right side bar.
     */

    public function rightSidebar(Request $request) {
        try {
            $id = '';
            $slug = '';
            if (!empty($request) && !empty($request->id)) {
                $id = $request->id;
                $slug = getUserById($id, 'slug');
            }
            $user = $this->user->getUseDetails($id);
            $html = View::make('player::player._load-right-side-html', ['user' => $user, 'page' => $request->page, 'slug' => $slug])->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Get user notification.
     */

    public function getNotification() {
        return $this->user->getNotification();
    }

    /**
     * get notification in front
     */
    public function getAllNotifications() {
        return view('player::player.notifications');
    }

    /**
     * get notification list in front
     */
    function notificationList() {
        $notifications = $this->user->getAllNotifications();
        $html = View::make('player::ajax-content._notifications-list', ['notifications' => $notifications])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /*
     * Delete all notifications.
     */

    public function deleteNotifications($id) {
        try {
            $this->user->deleteNotifications($id);
            return Response::Json(['success' => true, 'message' => 'notification delete successfully.']);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Get Connections List.
     */

    public function userConnectionsList(Request $request) {
        return $this->user->userConnectionsList($request);
    }

    /*
     * Get Connections.
     */

    public function getConnections($slug = null) {
        $id = '';
        if (!empty($slug)) {
            $id = getUserIdBySlug($slug);
        }
        return view('player::player.my-connections', ['slug' => $slug, 'id' => $id]);
    }

    /*
     * Get All Connections.
     */

    public function getAllConnections(Request $request) {

        try {
            $post = $request->all();
            $id = '';
            if (!empty($request) && $post['id'] != '') {
                $id = $post['id'];
            }
            $connections = $this->user->getAllConnections($post);
            $html = View::make('player::ajax-content._members-list', ['connections' => $connections, 'o_id' => $id])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Show the friend request page.
     */

    public function myFriendRequest() {
        $changeConnectionStatus = $this->user->changeConnectionStatus();  // change connection status to read
        return view('player::player.my-friend-request');
    }

    /*
     * my friend request
     */

    public function getAllFriendRequest(Request $request) {

        try {
            $post = $request->all();
            $id = '';
            if (!empty($request) && $post['id'] != '') {
                $id = $post['id'];
            }
            $connections = $this->user->getAllFriendRequests($post);
            $html = View::make('player::ajax-content._friend-request-list', ['connections' => $connections, 'o_id' => $id])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Accept Connection request.
     */

    public function acceptRejectConnection(Request $request) {
        try {
            $this->user->acceptRejectConnection($request);
            return Response::json(['success' => true, 'message' => 'Connection Updated.']);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for getting experience list.
     */

    public function getExperienceList(Request $request) {
        $post = $request->all();
        $id = '';
        if (isset($post['id'])) {
            $id = $post['id'];
        }
        $user = $this->user->getUseDetails($id);
        if ($post['experience_type'] == 'college_experience') {
            $userExperience = $user->userCollegeExperince;
            $experienceType = 'College';
        } elseif ($post['experience_type'] == 'user_pro') {
            $userExperience = $user->userProExperince;
            $experienceType = 'Pro';
        } elseif ($post['experience_type'] == 'user_international') {
            $userExperience = $user->userInternationalExperince;
            $experienceType = 'International';
        } else {
            $userExperience = $user->userIndooreExperince;
            $experienceType = 'Indoor';
        }
        $html = View::make('player::ajax-content._user-experience-list', ['userExperience' => $userExperience, 'experienceType' => $experienceType])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * render the joined member based on country state city and non mutual friends.
     */

    public function getMatchedAndMutualJoinedMembers(Request $request) {
        try {
            $o_id = '';
            if (!empty($request) && !empty($request->id)) {
                $o_id = $request->id;
            }
            $users = $this->user->getMatchedAndMutualJoinedMembers($request);
            $html = View::make('player::ajax-content._members_mutual_joined', ['users' => $users, 'o_id' => $o_id])->render();
            return Response::Json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * Function for getting education,accoldes and choaching experience.
     */

    public function getDifferentExperienceList(Request $request) {
        $post = $request->all();
        $id = '';
        if (isset($post['id'])) {
            $id = $post['id'];
        }
        $userExperience = $this->user->getUseDetails($id);
        if ($post['experience_type'] == 'education_experience') {
            $html = View::make('player::ajax-content._all-education-experience-list', ['educations' => $userExperience->userEducationExperience])->render();
        } elseif ($post['experience_type'] == 'accolades') {
            $html = View::make('player::ajax-content._accolades-experience-list', ['accolades' => $userExperience->userAccoladesExperince])->render();
        } elseif ($post['experience_type'] == 'community') {
            $html = View::make('player::ajax-content._community-experience-list', ['community' => $userExperience->userCommunityExperince])->render();
        } else {
            $html = View::make('player::ajax-content._coaching-experience-list', ['experiences' => $userExperience->userCoachingExperince])->render();
        }
        return Response::json(['html' => $html]);
    }

    /*
     * show all list of joined member based on country state city and non mutual friends.
     */

    public function getMatchedMutualJoinedMembersList(Request $request) {
        try {
            $o_id = '';
            if (!empty($request) && !empty($request->id)) {
                $o_id = $request->id;
            }
            $users = $this->user->getMatchedAndMutualJoinedMembers($request);
            $html = View::make('player::ajax-content._all_matched_mutual_joined_member_list', ['users' => $users, 'o_id' => $o_id])->render();
            return Response::Json(['success' => true, 'html' => $html, 'users' => $users]);
        } catch (\Exception $e) {
            return Response::Json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * function for load all Desired Benifites.
     */

    public function loadMoreBenefites(Request $request) {
        $id = '';
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $user = $this->user->getUseDetails($id);
        $html = View::make('player::ajax-content._load-more-benefites', ['user' => $user])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Function for getting counts.
     */

    public function getAllCount(Request $request) {
        $id = 0;
        if (!empty(Auth::guard(getAuthGuard())->check())) {
            $id = Auth::guard(getAuthGuard())->user()->id;
        }
        if (!empty($request) && !empty($request->id)) {
            $id = $request->id;
        }
        $getViewCount = $this->user->getViewCount($id);
        $getFollowCount = $this->user->getFollowCount($id);
        $getFollowersCount = $this->user->getFollowersCount($id);
        $getLikeCount = $this->user->getLikeCount($id);
        $getConnectionsCount = $this->user->getConnectionsCount($id);
        $newsBulletin = \App\Models\News::getNewsBulletin();
        $html = view('player::ajax-content._all_counts_player', ['getViewCount' => $getViewCount,
            'getFollowCount' => $getFollowCount,
            'getFollowersCount' => $getFollowersCount,
            'getLikeCount' => $getLikeCount,
            'getConnectionsCount' => $getConnectionsCount])->render();
        return Response::json(['html' => $html, 'newsBulletin' => $newsBulletin]);
    }

    /*
     * Function for get unread request count.
     */

    public function getRequestUnreadCount() {
        return $this->user->getRequestUnreadCount();
    }

//  multiple image upload 
    public function uploadMultipleMedia(Request $request) {
        return $this->commanUser->uploadPostFile($request);
    }

    /*
     * Function for get key states.
     */

    public function getKeyStates(Request $request) {
        $currentKeyStates = $this->user->getKeyStatesCurrent($request);
        $pastKeyStates = $this->user->getKeyStatesPast($request);
        $html = view('player::ajax-content._key-states', ['keyCurrent' => $currentKeyStates, 'keyPast' => $pastKeyStates])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Function for get current key states.
     */

    public function getKeyStatesCurrent(Request $request) {
        $currentKeyStates = $this->user->getKeyStatesCurrent($request);
        $html = view('player::ajax-content._key-states-current', ['keyStatesCurrent' => $currentKeyStates])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Function for get past key states.
     */

    public function getKeyStatesPast(Request $request) {
        $pastKeyStates = $this->user->getKeyStatesPast($request);
        $html = view('player::ajax-content._key-states-past', ['pastKeyStates' => $pastKeyStates])->render();
        return Response::json(['html' => $html]);
    }

    /*
     * Function for get career key states.
     */

    public function getKeyStatesCareer(Request $request) {
        $currentKey = $this->user->getKeyStatesCurrent($request);
        $pastKey = $this->user->getKeyStatesPast($request);
        $html = view('player::ajax-content._key-states-career', ['currentKey' => $currentKey, 'pastKey' => $pastKey])->render();
        return Response::json(['html' => $html]);
    }

}
