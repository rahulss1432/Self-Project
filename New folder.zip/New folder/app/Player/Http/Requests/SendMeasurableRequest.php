<?php

namespace App\Player\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SendMeasurableRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'certifier' => "nullable|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/",
            'email_link' => 'nullable|email',
            'weight' => 'nullable|numeric|min:1',
            'pro_shuttle' => 'nullable|numeric',
            'collegiate_shuttle' => 'nullable|numeric',
            'bench' => 'nullable|numeric',
            'vert' => 'nullable|numeric',
            'hand_size' => 'nullable|numeric',
            'fourty' => 'nullable|numeric',
        ];
    }
    
    /*
     * Function for show validation messages.
     */
    public function messages(){
        return [
//            'email.check_email_format' => 'Please provide valid email',
//            'certifier.regex' =>'The only space not allowed.',
//            'weight.regex' =>'The only space not allowed.',
//            'pro_shuttle.regex' =>'The only space not allowed.',
//            'collegiate_shuttle.regex' =>'The only space not allowed.',
//            'bench.regex' =>'The only space not allowed.',
//            'vert.regex' =>'The only space not allowed.',
//            'hand_size.regex' =>'The only space not allowed.',
//            'fourty.regex' =>'The only space not allowed.',
        ];
    }
}
