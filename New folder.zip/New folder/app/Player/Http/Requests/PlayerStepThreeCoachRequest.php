<?php

namespace App\Player\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PlayerStepThreeCoachRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => "required|max:100|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/",
            'image' => 'nullable|mimes:jpeg,jpg,png|max:1048',
            'from_year' => 'required',
            'to_year' => 'required',
            'level_id' => 'required',
            'country_id' => 'required',
            'state_id' => 'required',
            'coaching_link' => 'required|url',
            'coching_league' => "required|max:100|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/",
            'position_held' => "required|max:100|regex:/^[a-zA-Z0-9.@&'][\sa-zA-Z0-9.@&']*$/",
        ];
    }
      public function messages() {
         return [
             'level_id.required' =>'The level field is required.',
             'country_id.required' =>'The country field is required.',
             'state_id.required' =>'The state field is required.',
//             'coching_league.regex' =>'The only space not allowed.',
//             'position_held.regex' =>'The only space not allowed.',
//             'name.regex' =>'The only space not allowed.',
            ];
     }
}
