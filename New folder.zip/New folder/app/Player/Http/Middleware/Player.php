<?php

namespace App\Player\Http\Middleware;

use Illuminate\Support\Facades\Auth;
use Closure;
use Carbon\Carbon;

class Player {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = 'player') {
        
         
        if (Auth::guard($guard)->check()) {
            if(Auth::guard($guard)->user()->status == 'inactive')
            {                
            Auth::guard($guard)->logout();
            $request->session()->invalidate();
            return redirect('/');
            }
            
            $checkFalse=false;
            $popup_open='';
            $id = Auth::guard($guard)->user()->id;
            $customer_id = getUserById($id, 'customer_id');
            $end_date = getUserById($id, 'end_date');
            $signup_type = getUserById($id, 'signup_type');
            $verification = getUserById($id, 'verification');
            $today = Carbon::today()->format('Y-m-d');
            if (empty($customer_id) && $signup_type == 'card') {
               $popup_open= 'card'; 
                 $checkFalse=true;
            } elseif (empty($customer_id) && $signup_type == 'ach') {
               $popup_open='ach'; 
                 $checkFalse=true;
            } elseif ($end_date < $today || $verification == 'no') {
               $popup_open=$signup_type; 
                 $checkFalse=true;
            }
            if($checkFalse){
             return redirect('/payment-process/'.$popup_open);
            }
            $response = $next($request);
            return $response->header('Cache-Control', 'nocache, no-store, max-age=0, must-revalidate')
                            ->header('Pragma', 'no-cache')
                            ->header('Expires', '0');
        }
        return redirect('/');
    }

}
