<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use JWTAuth;

class UserDevice extends Model {

    protected $table = 'user_devices';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'device_id', 'user_id', 'device_type', 'certification_type', '	access_token',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    public static function addUserDevice($post) {
        $token = NULL;
        if ($post['access_token'] == '') {
            $token = JWTAuth::fromUser($post);
        } else {
            $token = $post['access_token'];
        }
        $user = JWTAuth::toUser($token);
        $model = UserDevice::where(['user_id' => $user->id])->first();
        if (isset($post['certification_type'])) {
            $certification_type = $post['certification_type'];
        } else {
            $certification_type = 'development';
        }
        if (!empty($model)) {
            $model->user_id = $user->id;
            $model->device_id = (isset($post['device_id'])) ? $post['device_id'] : '';
            $model->access_token = $token;
            $model->is_loggedin = 1;
            $model->device_type = (isset($post['device_type'])) ? $post['device_type'] : '';
            $model->certification_type = $certification_type;
            $model->update();
        } else {
            $model = new UserDevice();
            $model->user_id = $user->id;
            $model->device_id = (isset($post['device_id'])) ? $post['device_id'] : '';
            $model->access_token = $token;
            $model->is_loggedin = 1;
            $model->device_type = (isset($post['device_type'])) ? $post['device_type'] : '';
            $model->certification_type = $certification_type;
            $model->save();
        }
        return $model;
    }

}
