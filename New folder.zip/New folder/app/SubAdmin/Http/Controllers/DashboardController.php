<?php

namespace App\SubAdmin\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\SubAdmin\DashboardRepository;
use App\Roles;
use App\User;

class DashboardController extends Controller
{
    public function __construct(DashboardRepository $dashboard)
    {
        $this->dashboard = $dashboard;
    }
    /**
     * Display a listing of the resource.
     * @param  null
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return $this->dashboard->index();
    }
    
    public function postAdminPermission(Request $request){
        $user = User::find($request->user_id);
        $user->roles()->detach();
        if( $request['role_player'] ) {
            $user->roles()->attach(Roles::where('name', 'player')->first());
        }
        if( $request['role_team'] ) {
            $user->roles()->attach(Roles::where('name', 'team')->first());
        }
        if( $request['role_coach'] ) {
            $user->roles()->attach(Roles::where('name', 'coach')->first());
        }
        return redirect()->back();
    }
    
    public function playerPage(){
        try {               
            return view('subadmin::dashboard.player');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }
    
    public function teamPage(){
        try {               
            return view('subadmin::dashboard.team');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }
    
    public function coachPage(){
        try {               
            return view('subadmin::dashboard.coach');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => ['message' => $e->getMessage()]]);
        }
    }
    
}
