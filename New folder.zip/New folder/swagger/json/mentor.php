<?php

return [
    'paths' => [
        "/rating" => [
           "post" => [
                "tags" => [
                    "mentor"
                ],
                "summary" => "Login a user",
                "description" => "Login for User",
                "operationId" => "login",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                       [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/rating"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/availability" => [
           "post" => [
                "tags" => [
                    "mentor"
                ],
                "summary" => "add schedule",
                "description" => "add schedule",
                "operationId" => "add schedule",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                       [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/add_schedule"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/edit-availability" => [
           "put" => [
                "tags" => [
                    "mentor"
                ],
                "summary" => "update schedule",
                "description" => "update schedule",
                "operationId" => "update schedule",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                       [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/edit_schedule"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/get-availability" => [
           "get" => [
                "tags" => [
                    "mentor"
                ],
                "summary" => "get schedule",
                "description" => "get schedule",
                "operationId" => "get schedule",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                       [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                       [
                        "name" => "id",
                        "in" => "query",
                        "description" => "",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                   
                ],
                "responses" => [
                ]
            ]
        ],
        "/availability/{id}" => [
           "delete" => [
                "tags" => [
                    "mentor"
                ],
                "summary" => "delete schedule",
                "description" => "delete schedule",
                "operationId" => "delete schedule",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                       [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                       [
                        "name" => "id",
                        "in" => "path",
                        "description" => "",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                   
                ],
                "responses" => [
                ]
            ]
        ],
       
    ],
    'definitions' => [
        'rating' => [
            'type' => "object",
            'properties' => [
                'from_id' => [
                    'type' => 'string'
                ],
                'to_id' => [
                    'type' => 'string'
                ],
                'rating' => [
                    'type' => 'string'
                ],
                'review' => [
                    'type' => 'string'
                ],
                'appoinment_id' => [
                    'type' => 'string'
                ]
               
            ],
            'xml' => [
                'name' => "rating"
            ]
        ],
        'add_schedule' => [
            'type' => "object",
            'properties' => [
                'from_date' => [
                    'type' => 'string'
                ],
                'to_date' => [
                    'type' => 'string'
                ],
                'from_time' => [
                    'type' => 'string'
                ],
                'to_time' => [
                    'type' => 'string'
                ],
                'state' => [
                    'type' => 'string'
                ],
                'city' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "resend_code"
            ]
        ],
        'edit_schedule' => [
            'type' => "object",
            'properties' => [
                'id' => [
                    'type' => 'string'
                ],
                'from_date' => [
                    'type' => 'string'
                ],
                'to_date' => [
                    'type' => 'string'
                ],
                'from_time' => [
                    'type' => 'string'
                ],
                'to_time' => [
                    'type' => 'string'
                ],
                'state' => [
                    'type' => 'string'
                ],
                'city' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "resend_code"
            ]
        ],
        
        'reset_password' => [
            'type' => "object",
            'properties' => [
                'code' => [
                    'type' => 'string'
                ],
                'password' => [
                    'type' => 'string'
                ],
                'confirm_password' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "reset_password"
            ]
        ],
    ]
];
