<?php

return [
    'paths' => [
        "/country-list" => [
            "get" => [
                "tags" => [
                    "common"
                ],
                "summary" => "country list",
                "description" => "country list",
                "operationId" => "country list",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [

                ],
                "responses" => [
                ]
            ]
        ],
        "/state-list" => [
            "get" => [
                "tags" => [
                    "common"
                ],
                "summary" => "state list",
                "description" => "state list",
                "operationId" => "state list",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                        [
                        "in" => "query",
                        "name" => "country_id",
                        "description" => "",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ]
                   
                ],
                "responses" => [
                ]
            ]
        ],
        "/city-list" => [
            "get" => [
                "tags" => [
                    "common"
                ],
                "summary" => "city list",
                "description" => "city list",
                "operationId" => "city list",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                  [
                        "in" => "query",
                        "name" => "state_id",
                        "description" => "",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ]
                   
                ],
                "responses" => [
                ]
            ]
        ],
        
       
    ],
    'definitions' => [
        'login' => [
            'type' => "object",
            'properties' => [
                'email' => [
                    'type' => 'string'
                ],
                'password' => [
                    'type' => 'string'
                ],
                'device_id' => [
                    'type' => 'string'
                ],
                'device_type' => [
                    'type' => 'string'
                ],
                'certification_type' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "Login"
            ]
        ],
        'resend_code' => [
            'type' => "object",
            'properties' => [
                'email' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "resend_code"
            ]
        ],
        'verify_code' => [
            'type' => "object",
            'properties' => [
                'code' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "resend_code"
            ]
        ],
        'forgot_password' => [
            'type' => "object",
            'properties' => [
                'email' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "forgot_password"
            ]
        ],
        'reset_password' => [
            'type' => "object",
            'properties' => [
                'code' => [
                    'type' => 'string'
                ],
                'password' => [
                    'type' => 'string'
                ],
                'confirm_password' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "reset_password"
            ]
        ],
    ]
];
