import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Register } from './register';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

import { UserService } from './user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  title = 'Registration';

  signupForm: FormGroup;
  public loading = false;

  constructor(
    private userapi: UserService,
    private fb: FormBuilder,
    private route: Router,
    private http: HttpClient,
    private location: Location
  ) {
    this.signupForm = fb.group({
      'name': [null, Validators.required],
      'email': [null, [Validators.required, Validators.pattern("[^ @]*@[^ @]*")]],
      'password': [null, [Validators.required, Validators.minLength(6)]],
      'confirm-password': [null, [Validators.required, Validators.minLength(6)]],
    });
  }

  add(userData) {
    this.userapi.addUser(userData).subscribe(res => {
      this.route.navigateByUrl('/register');
      userData.name = '';
      userData.email = '';
      userData.password = '';
      this.reset();
      this.getUsers();
    });
  }

  reset() {
    this.signupForm.reset();
  }

  ngOnInit() {
    this.getUsers();
  }

  register: Register[];
  getUsers(): void {
    this.userapi.getUser()
      .subscribe(register => this.register = register);
  }

  deleteUser(register: Register): void {
    this.register = this.register.filter(h => h !== register);
    this.userapi.deleteUser(register).subscribe();
  }

  selectUser: Register;
  editUser(user: Register | any): void {
    const id = user;
    this.userapi.getEditUser(id)
      .subscribe(user => this.selectUser = user);
  }

  edit(userData) {
    this.userapi.editUserById(userData).subscribe(res => {
      this.route.navigateByUrl('/register');
      userData.name = '';
      userData.email = '';
      this.reset();
      this.getUsers();
    });
  }

}

