<?php if(count($blogs) >0): ?>
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Blog Image  </th>
            <th>Blog Title</th>
            <th>Date and time of Blogpost</th>
            <th>Total Comments</th>
            <th>Total Like</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
        $datetime = App\Common\Utility::converToTz($data->created_at);
         ?>
        <tr id="<?php echo e('blogs'.$data->id); ?>">
            <td><img src="<?php echo e(\App\Common\Utility::checkBlogThumbnailImage($data->image)); ?>" class="img-fluid rounded video_img" alt="video_img"></td>
            <td>
                <span><?php echo e($data->title); ?></span>
            </td>
            <td><?php echo e($datetime->format('d-m-Y h:i A')); ?></td>
            <td><?php echo e(\App\Models\Blog::commentCount($data->id)); ?></td>
            <td><?php echo e(\App\Models\Blog::likeCount($data->id)); ?></td>
            <td>
                <label class="switch">
                    <div class="statusbtn">
                        <label class="switch">
                            <input id="enable_a_<?php echo e($data['id']); ?>" type="radio" onclick="activeInacive(<?php echo e($data->id); ?>,'<?php echo e($data->status); ?>')" value="active" name="radio_<?php echo e($data['id']); ?>" <?php if($data->status=='active'): ?>) checked="checked" <?php endif; ?> >
                                   <span class="slider round" for="enable_<?php echo e($data['id']); ?>"></span>
                        </label>
                    </div>
                </label>
            <td>
                <ul class="list-inline mb-0 "> 
                    <li class="list-inline-item">
                        <a id="view-loader" onclick="viewfunction(<?php echo e($data->id); ?>)" href="<?php echo e(url('admin/blog-view',$data->id)); ?>">
                            <i class="fa fa-eye"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a id="edit-loader" onclick="editfunction(<?php echo e($data->id); ?>)" href="<?php echo e(url('admin/blog-edit',$data->id)); ?>">
                            <i class="fa fa-pencil"></i>
                        </a>
                    </li> 
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onclick="deletefunction(<?php echo e($data->id); ?>)">
                            <i class="fa fa-trash"></i>
                        </a>
                    </li>
                </ul>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center>No blogs available.</center></div>
<?php endif; ?>

