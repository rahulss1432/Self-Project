<?php if($merchantSE->count()>0): ?>
<table class="table admin-table" id="data_table">
    <thead>
    <th>ID</th>
    <th>Name</th>
    <th>Category</th>
    <th>Phone Number</th>
    <th>Company</th>
</thead>
<tbody>
    <?php $__currentLoopData = $merchantSE; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(!empty($user->userProfile->executive_number) ? $user->userProfile->executive_number : ''); ?></td>
        <td><?php echo e($user->userDetail->contact_name); ?></td>
        <td><?php echo e($user->userDetail->bankCategory->name); ?></td>
        <td><?php echo e($user->userDetail->phone_number); ?></td>
        <td><?php echo e($user->userDetail->bank->name); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center><?php echo e(\Config::get('constants.no_record_found')); ?></center></div>
<?php endif; ?>
<?php if($merchantSE->count()>0): ?>
<script>
    $(document).ready(function () {
        $('#merchantSE').show();
    });
</script>
<?php endif; ?>