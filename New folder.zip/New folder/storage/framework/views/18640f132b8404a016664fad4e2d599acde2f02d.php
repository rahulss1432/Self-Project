<?php $__env->startSection('title',ucfirst($user_type). ' List'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-wrapper dashboard-main-wrap payment-history-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Manage User</li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(ucfirst($user_type)); ?></li>
                </ol>
            </nav>
            <div class="content-body">
                <!-- <h1 class="page-title">Payment History</h1> -->
            </div>
            <div class="card common-card mt-0">
                <div class="card-header d-flex align-items-center">
                    <h3 class="font-md"><?php echo e(ucfirst($user_type)); ?> List</h3>
                    <ul class="list-inline mb-0 ml-auto">
                        <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Filter">
                            <a href="#searchFilter" data-toggle="collapse" class="nav-link ripple-effect-dark">
                                <i class="fa fa-filter"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body p-0">
                    <div class="filter_section collapse" id="searchFilter">
                        <form id="frmFilter">
                            <input type="hidden" name="user_type" value="<?php echo e($user_type); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <select name="plan_id" class="selectpicker form-control" title="Subscription Plan"> 
                                            <?php 
                                            $plans = \App\Models\Plan::getPlanDropdown($user_type); 
                                            echo $plans;
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <input type="text" name="name" class="form-control" placeholder="Name">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                    <div class="form-group">
                                        <input type="email" name="email" class="form-control" placeholder="Email Id">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                     <button type="button" class="btn btn-success ripple-effect-dark mr-2" onclick="loadUserList();">Filter</button>
                                     <button type="button" class="btn btn-warning ripple-effect-dark" onclick="resetFilter();">Reset</button>
                                        
                                </div>
                            </div>
                        </form>
                    </div>
                    <div id="userList">

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="edituserModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="addCandidateModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCandidateModal">Update <?php echo e(ucfirst($user_type)); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                </button>

            </div>
                <div id="user-form">
                </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        loadUserList();
    });

    function loadUserList() {
        $("#userList").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('/admin/load-user-list')); ?>",
            data: $('#frmFilter').serialize(),
            success: function (response)
            {
                $("#userList").html(response);
            }
        });
    }
    
    function editUser(id) {
        $('#edituserModal').modal('show');
        $("#user-form").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('/admin/load-user-form')); ?>",
            data: {_token:'<?php echo e(csrf_token()); ?>',id:id},
            success: function (response)
            {
                $("#user-form").html(response);
            }
        });
    }
    
    function resetFilter(){
        $('#frmFilter')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        loadUserList();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>