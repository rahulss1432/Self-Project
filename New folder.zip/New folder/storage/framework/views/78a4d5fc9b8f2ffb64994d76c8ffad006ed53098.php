<?php $__env->startSection('title', 'Edit Merchant'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">edit Merchant</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="<?php echo e(url('manager/manage-merchant')); ?>" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <form id="EditMerchantForm" autocomplete="off" class="f-field" method="POST" action="<?php echo e(url('manager/update-merchant')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                    <div class="row">
                        <div class="col-sm-6">                            
                            <div class="form-group">
                                <?php
                                $executives = \App\Http\Models\User::getExecutivesLinkedById();
                                $linkedExecutives = \App\Http\Models\CustomerExecutiveRelation::getExecutiveByCustomerId($user->id);
                                $data = array();                                                                 
                                foreach($linkedExecutives as $linkedExecutive){
                                $data[] = $linkedExecutive->executive_id;
                                }     
                                ?>                            
                                <select class="form-control selectpicker" id="selectExecutive" name="executive[]" multiple  title="Select Support Executive" data-size="5">
                                    <?php if(count($executives)>0): ?>
                                    <?php $__currentLoopData = $executives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $executive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($executive->id); ?>" <?php echo e(in_array($executive->id,$data) ? 'selected' : ''); ?>><?php echo e(getFullName($executive->first_name ,$executive->last_name )); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>    
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="contact_name"  value="<?php echo e($user->contact_name); ?>" class="form-control">
                                <label class="control-label">Contact Name</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="bussiness_name" value="<?php echo e($user->userDetail->bussiness_name); ?>" class="form-control" >
                                <label class="control-label">Business Name</label>
                            </div>
                        </div>                

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="phone" value="<?php echo e($user->phone_number); ?>" class="form-control">
                                <label class="control-label">Phone Number</label>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control">
                                <label class="control-label">Email Address</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="product" value="<?php echo e($user->userDetail->product); ?>" class="form-control">
                                <label class="control-label">Merchant Processor</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="machine_model" value="<?php echo e($user->userDetail->machine_model); ?>" class="form-control" >
                                <label class="control-label">Credit Card Machine Model</label>
                            </div>
                        </div>                        

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="terminal_model" value="<?php echo e($user->userDetail->terminal_model); ?>"  class="form-control">
                                <label class="control-label">Terminal Model</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="bussiness_address"  value="<?php echo e($user->userDetail->bussiness_address); ?>" class="form-control" >
                                <label class="control-label">Business Address</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="city" value="<?php echo e($user->city); ?>" class="form-control" >
                                <label class="control-label">City</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="state"  value="<?php echo e($user->state); ?>" class="form-control" >
                                <label class="control-label">State</label>
                            </div>
                        </div>                                                
                    </div>
                    <div class="form-group">
                        <button id="btnSubmitForm" type="submit" class="btn btn-primary ripple-effect-dark">Save
                            <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                    
                        </button>                        
                    </div>
                </form>
                <?php echo JsValidator::formRequest('App\Http\Requests\Manager\EditMerchantRequest','#EditMerchantForm'); ?>                
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
//        back button loader
    function backLoader() {
        $("#backLoader").html('<i class="fa fa-spinner fa-spin"></i>');
    }

//       submit add executive form
    $(document).on('submit', '#EditMerchantForm', function (e) {
        e.preventDefault();
        if ($('#EditMerchantForm').valid()) {
            $('#btnSubmitForm').prop('disabled', true);
            $('#btnSubmitLoader').show();
            $.ajax({
                url: "<?php echo e(url('manager/update-merchant')); ?>",
                data: $('#EditMerchantForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "<?php echo e(url('manager/manage-merchant')); ?>";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnSubmitForm').prop('disabled', false);
                    }
                    $('#btnSubmitLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#btnSubmitForm').prop('disabled', false);
                }
            });
        }
    });

//        /* image uploading with cropper*/
//        function uploadFile(thisEl) {
//            if (thisEl.files[0]) {
//                var inputFile = thisEl.files[0].name;
//                var extension = inputFile.substr(inputFile.lastIndexOf('.') + 1); /*get file exension*/
//                /*check file type and exension*/
//                if (extension != 'jpg' && extension != 'jpeg' && extension != 'png') {
//                    toastrAlertMessage('error', 'Image allows only in jpeg, png or jpg format');
//                    $('#imageUpload').val('');
//                    $('#hiddenMediaFileName').val('');
//                    return false;
//                }
//                var formData = new FormData($('#EditMerchantForm')[0]); /*uploading on server via ajax call*/
//                formData.append('_token', '<?php echo e(csrf_token()); ?>');
//                $.ajax({
//                    url: "<?php echo e(url('manager/upload-media-image')); ?>",
//                    type: 'POST',
//                    data: formData,
//                    processData: false,
//                    cache: false,
//                    contentType: false,
//                    success: function (response) {
//                        loadImageCropperModal(response.filename);
//                        $('#cropper-image-modal').modal('show');
//                    }
//                });
//            }
//        }
//
//        function loadImageCropperModal(imageName) {     /*open cropper model*/
//            $.ajax({
//                url: "<?php echo e(url('manager/load-image-cropper')); ?>",
//                type: 'GET',
//                data: {imageName: imageName, type: 'profile_image'},
//                success: function (response) {
//                    $('#image-cropper-form').html(response.html);
//                }
//            });
//        }

    $('.form-group .form-control').focus(function ()
    {
        $(this).parent().addClass('isfocused');
    }).blur(function ()
    {
        $(this).parent().removeClass('isfocused');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('manager.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>