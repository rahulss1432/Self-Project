<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-content dashboard-page" id="mainContent">
    <div class="page-content">
        <div class="container-fluid">
            <section class="admin-fun-fact">
                <div class="filter_section" id="searchF ilter">
                    <form>
                        <div class="row">
                            <div class="col-sm-6 col-md-4 col-xl-3">
                                <div class="form-group">
                                    <select class="form-control selectpicker form-control-lg" data-size="5">
                                        <option value="pacific">Pacific Coast</option>
                                        <option value="mountain">Mountain</option>
                                        <option value="central">Central</option>
                                        <option value="east">East Cost</option>
                                    </select>
                                    <label class="control-label">Region</label>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4 col-xl-3">
                                <div class="form-group">
                                    <select class="form-control selectpicker form-control-lg" data-size="5">
                                        <option value="california">California</option>
                                        <option value="nevada">Nevada</option>
                                        <option value="oregon">Oregon</option>
                                    </select>
                                    <label class="control-label">States</label>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4 col-xl-3">
                                <div class="form-group">
                                    <select class="form-control selectpicker form-control-lg" data-size="5">
                                        <option value="sanfrancisco">San Francisco</option>
                                        <option value="sacramento">Sacramento</option>
                                        <option value="losangelos">Los Angelos</option>
                                    </select>
                                    <label class="control-label">City</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-sm-6">
                                <div class="form-group d-inline-block mr-2">
                                    <button class="btn btn-primary ripple-effect" type="submit">Filter</button>
                                </div>
                                <div class="form-group d-inline-block">
                                    <button class="btn btn-dark ripple-effect" type="submit">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- Candidate -->
                <div class="row box-row">
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="javascript:void(0);" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">2019 Earned Total</h2>
                                <p class="mb-0">100</p>
                            </div>
                            <div class="icon bg-pink">
                                <i class="ti-money"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="/admin/contractors.php" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Contractors</h2>
                                <p class="mb-0">30</p>
                            </div>
                            <div class="icon bg-yello">
                                <i class="ti-user"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="javascript:void(0);" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Notifications</h2>
                                <p class="mb-0">145</p>
                            </div>
                            <div class="icon bg-green">
                                <i class="ti-bell"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="javascript:void(0);" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Impressions</h2>
                                <p class="mb-0">34</p>
                            </div>
                            <div class="icon bg-green-light">
                                <i class="ti-gallery"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="javascript:void(0);" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Categories</h2>
                                <p class="mb-0">50</p>
                            </div>
                            <div class="icon bg-red-light">
                                <i class="ti-view-list-alt"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxxxx -->
                    <div class="col-md-6 col-xl-4">
                        <a href="javascript:void(0);" class="wrap">
                            <div class="text ">
                                <h2 class="text-uppercase">Total Flagged</h2>
                                <p class="mb-0">200</p>
                            </div>
                            <div class="icon bg-blue">
                                <i class="ti-pencil-alt"></i>
                            </div>
                        </a>
                    </div>
                    <!-- xxxxx -->
                    <!-- xxxxxxx -->
                </div>
                <!-- xxxxx -->
            </section>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>