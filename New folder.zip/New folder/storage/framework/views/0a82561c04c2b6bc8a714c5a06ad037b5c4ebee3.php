<!DOCTYPE html>
<html>
    <head>
        <title>error</title>
        <link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('public/css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('public/css/colors/blue.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('public/css/custom-style.css')); ?>">   
    </head>
    <body class="error_page">
        <main class="main_content ">
            <section class="error_section">
                <div class="error_content text-center">
                    <h2>404</h2>
                    <p class="text-center">THE LINK YOU FOLLOWED IS PROBABLY BROKEN OR THE <br class="hidden-xs">PAGE HAS BEEN REMOVED.</p>
                    <?php if(Request::is('admin/*')): ?>
                        <a class="button button-sliding-icon" href="<?php echo e(url('/admin/dashboard')); ?>">GO TO DASHBOARD <i class="icon-material-outline-arrow-right-alt"></i></a>
                    <?php else: ?>
                        <a class="button button-sliding-icon" href="<?php echo e(url('/')); ?>">GO TO HOME <i class="icon-material-outline-arrow-right-alt"></i></a>
                    <?php endif; ?>
                </div>

            </section>
        </main>
    </body>
</html>