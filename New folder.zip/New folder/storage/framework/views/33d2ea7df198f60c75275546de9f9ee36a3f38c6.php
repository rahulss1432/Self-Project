<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <main class="main-content inner-pages blog-detail">
            <div class="container">
                <h1 class="inner-heading">BLOG DETAIL</h1>
                <div class="blog-banner" style="background-image: url('<?php echo e(\App\Helpers\Utility::checkBlogImage($blogData->banner_image,'blog-banner')); ?>');">
                    <div class="banner-title">
                        <h3 class="text-center"><?php echo e($blogData->blog_title); ?></h3>
                        <div class="about-author">
                            <div class="img-wrap">
                                <img src="<?php echo e(\App\Helpers\Utility::checkProfileImage($blogData->getAurhUser->profile_image)); ?>" alt="user" class="img-fluid">
                            </div>
                            <div class="details">
                                <h2><span>by</span> <?php echo e($blogData->getAurhUser->first_name); ?> <?php echo e($blogData->getAurhUser->last_name); ?></h2>
                                <p>on <?php
                                    $createDate = date('F d, Y',strtotime($blogData->created_at));
                                    echo $createDate;
                                ?></p>
                            </div>
                        </div>
                    </div>

                     <div class="share-via">
                        <p class="mb-0">Share Via</p>
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item">
                                <a href="javascript:void(0);"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li class="list-inline-item">
                                <a href="javascript:void(0);"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li class="list-inline-item">
                                <a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="blog-body">
                <p><?php echo e($blogData->meta_description); ?><p>
                     <img src="<?php echo e(\App\Helpers\Utility::checkBlogImage($blogData->blog_image,'blog-image')); ?>" alt="blog-image" class="img-fluid">
                 <p><?php echo e($blogData->content); ?></p>
                </div>

                <div class="comments">
                    <h2>Comment  <span class="badge commentCount">00</span></h2>
                    <div class="post-comment">
                        <div class="img-wrap">
                            <img src="<?php echo e(\App\Helpers\Utility::checkProfileImage(Auth::user()->profile_image)); ?>" alt="user" class="img-fluid">
                        </div>
                        <form id="manage-comments" method="post" action="<?php echo e(url('/save-comment')); ?>">
                          <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="blog_id" value="<?php echo e($blogData->id); ?>">
                            <div class="form-group">
                                <label>Write a comment</label>
                                <textarea name="comments" class="form-control"></textarea>
                            </div>
                            <div class="form-group text-right">
                                <button  class="btn btn-primary ripple-effect text-uppercase" id="submit-btn">post  <i class="fa fa-spin fa-spinner" style="display: none;"></i></button>
                            </div>
                        </form>
                        <?php echo JsValidator::formRequest('App\Http\Requests\BlogCommentRequest','#manage-comments'); ?>

                    </div>
                    <div id="commentBox">

                    </div>
                </div>
            </div>
        </main>
        <script src="<?php echo e(url('public/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
        <script>
           $(document).ready(function () {
            loadComments();
        });

            $("#submit-btn").on('click', (function (e) {
                e.preventDefault();
                var btn = $('#submit-btn');
                var form = $('#manage-comments');
                if (form.valid()) {
                    btn.html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?> Post');
                    btn.prop('disabled', true);
                    $.ajax({
                        url: "<?php echo e((url('/save-comment'))); ?>",
                        type: "POST",
                        data: new FormData($('#manage-comments')[0]),
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data) {
                            btn.prop('disabled', false);
                            $('#manage-comments')[0].reset();
                            successToaster('Your comment posted successfully.','Comment');
                             btn.html('Post');
                            loadComments();
                        },
                        error: function (data) {
                            var obj = jQuery.parseJSON(data.responseText);
                            for (var x in obj) {
                                btn.prop('disabled', false);
                                btn.html('Post');
                                var errors = obj[x].length
                                $('#' + x + '-error').html(obj[x]);
                                $('#' + x + '-error').css("color", '#b30000');
                                $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                            }
                        },
                    });
                }
            }));
            function loadComments(){
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(url('/load-blog-comments')); ?>",
                    data: {_token:'<?php echo e(csrf_token()); ?>',blog_id:"<?php echo e($blogData->id); ?>"},
                    success: function (response)
                    {
                        $('.commentCount').html(response.commentCount);
                        $("#commentBox").html(response.html);
                    }
                });
            }
       </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>