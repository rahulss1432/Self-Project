<?php
$currentRoute = Request::route()->getName();
?>
<aside class="sidemenu">
    <div class="sidebar-wrapper">
        <div class="logo text-center">
            <h2 class="mb-0 text-uppercase">linked assist</h2>
        </div>
        <ul id="sidemenu" class="nav flex-column sidenav mCustomScrollbar" data-mcs-theme="minimal-dark">
            <li class="nav-item <?php echo e(($currentRoute =='admin-dashboard')?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(url('admin/dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            </li>
            <li class="nav-item <?php echo e(($currentRoute =='manage-user')?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(url('admin/manager')); ?>"><i class="fas fa-user-alt"></i> Managers</a>
            </li>
            <li class="nav-item sub_menu  <?php echo e(($currentRoute == 'manage-merchant' || $currentRoute == 'merchant-request' || $currentRoute == 'unassigned-request') ? 'active':''); ?>">
                <a class="nav-link" href="#subMenu" data-toggle="collapse"><i class="fas fa-user-friends" aria-expanded="false"></i>Merchant</a>
                <ul data-parent="#sidemenu" class="list-unstyled collapse <?php echo e(($currentRoute == 'manage-merchant' || $currentRoute == 'merchant-request' || $currentRoute == 'unassigned-request') ? 'show':'hide'); ?>" id="subMenu">
                    <li class="<?php echo e(($currentRoute == 'manage-merchant')?'active':''); ?>">
                        <a href="<?php echo e(url('admin/manage-merchant')); ?>">Manage Merchant</a>
                    </li>
                    <li class=" <?php echo e(($currentRoute == 'merchant-request')?'active':''); ?>">
                        <a href="<?php echo e(url('admin/merchant-request')); ?>">Request History</a>
                    </li>
                    <li class="<?php echo e(($currentRoute == 'unassigned-request')?'active':''); ?>">  
                        <a href="<?php echo e(url('admin/unassigned-request')); ?>">Request Unassigned (SE)</a>
                    </li>
                </ul>
            </li>
            <li class="nav-item sub_menu <?php echo e(($currentRoute == 'manage-executives' || $currentRoute == 'support-executive-request') ? 'active':''); ?>">
                <a class="nav-link" href="#subMenu1" data-toggle="collapse"><i class="fas fa-user-tie"></i>Support Executive</a>
                <ul data-parent="#sidemenu" class="list-unstyled collapse <?php echo e(($currentRoute == 'manage-executives' || $currentRoute == 'support-executive-request') ? 'show':'hide'); ?>" id="subMenu1">
                    <li class=" <?php echo e(($currentRoute == 'manage-executives')?'active':''); ?>">
                        <a href="<?php echo e(url('admin/manage-executives')); ?>">List of (SE)</a>
                    </li>
                    <li class="<?php echo e(($currentRoute == 'support-executive-request')?'active':''); ?>">  
                        <a href="<?php echo e(url('admin/support-executive-request')); ?>">(SE) Request</a>
                    </li>
                </ul>
            </li>
            <li class="nav-item <?php echo e(($currentRoute =='call-request')?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(url('admin/call-request')); ?>"><i class="fas fa-phone call_icon"></i> Call Request</a>
            </li>
            <li class="nav-item <?php echo e(($currentRoute =='documents')?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(url('admin/documents')); ?>"><i class="fas fa-file-alt"></i> Wiki Document</a>
            </li>
            <li class="nav-item <?php echo e(($currentRoute =='banks')?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(url('admin/banks')); ?>"><i class="far fa-list-alt"></i> Banks</a>
            </li>
            <li class="nav-item <?php echo e(($currentRoute =='categories')?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(url('admin/categories')); ?>"><i class="far fa-list-alt"></i> Categories</a>
            </li>
        </ul>
    </div>
</aside>