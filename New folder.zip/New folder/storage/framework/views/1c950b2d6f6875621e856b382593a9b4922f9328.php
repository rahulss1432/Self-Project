<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content dashboard_page">
    <div class="content_wrapper">


        <div class="row static_row mt-0">

            <div class="col-md-3">
                <div class="page_title"><h2>Dashboard</h2></div>


                <div class="static_box align-items-center bg-white box-shadow ">
                    <div class="icon">
                        <img src="<?php echo e(url('public/admin/images/users-ic.png')); ?>" alt="users">
                    </div>
                    <div class="total">
                        <h3 data-count="1423">0</h3>
                        <span>Total Users</span>
                    </div>
                </div>



                <div class="static_box align-items-center bg-white box-shadow">
                    <div class="icon">
                        <img src="<?php echo e(url('public/admin/images/earning-ic.png')); ?>" alt="earning">
                    </div>
                    <div class="total">
                        <h3 data-count="2351" class="currency">0</h3>
                        <span>Total Earnings </span>
                    </div>
                </div>



                <div class="static_box align-items-center bg-white box-shadow">
                    <div class="icon">
                        <img src="<?php echo e(url('public/admin/images/ebook-ic.png')); ?>" alt="ebook">
                    </div>
                    <div class="total">
                        <h3 data-count="1423">0</h3>
                        <span>Total EBook Copies Sold</span>
                    </div>
                </div>

            </div>

            <!-- xxxxxxx -->

            <div class="col-md-9">
                <div class="static_row">
                    <div class="page_title d-flex justify-content-between">
                        <h2>Recent Transaction </h2>
                        <a href="manage-transactions.php" class="view-all">View All</a>
                    </div>
                    <div class="bg-white box-shadow common_table">
                        <div class="table-responsive">
                            <table class="table mb-0">
                                <thead>
                                    <tr>
                                        <th>Transaction Date and Time</th>

                                        <th>Customer name</th>
                                        <th>Email ID</th>
                                        <th>Amount Paid</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>04/21/2019 - 10:40 AM</td>

                                        <td>Chaim</td>
                                        <td>ante@pedemalesuada.org</td>
                                        <td>$9,997</td>
                                    </tr>

                                    <tr>
                                        <td>03/31/2019 - 4:40 AM</td>

                                        <td>Miranda</td>
                                        <td>sem@ideratEtiam.ca</td>
                                        <td>$7,196</td>
                                    </tr>

                                    <tr>
                                        <td>04/08/2018 - 6:40 PM</td>

                                        <td>Xavier</td>
                                        <td>lorem@vulputater.net</td>
                                        <td>$5,742</td>
                                    </tr>

                                    <tr>
                                        <td>09/16/2017 - 2:40 PM</td>

                                        <td>Yuli</td>
                                        <td>lacus.Quisque@risusa.com</td>
                                        <td>$9,642</td>
                                    </tr>

                                    <tr>
                                        <td>02/28/2018 - 8:40 PM</td>

                                        <td>Hyatt</td>
                                        <td>vitae@idantedictum.edu</td>
                                        <td>$8,821</td>
                                    </tr>
                                </tbody>
                                <!-- No Record Found -->
                                <tr>
                                    <td colspan="4" style="display: none"><div class="alert alert-danger text-center">No Record Found</td>
                                </tr>
                                <!--  -->
                            </table>
                        </div>
                    </div>
                </div>


                <!-- xxxxxxxxx -->

                <div class="static_row">
                    <div class="page_title d-flex justify-content-between">
                        <h2>New Users</h2>
                        <a href="manage-users.php" class="view-all">View All</a>
                    </div>
                    <div class="bg-white box-shadow common_table">
                        <div class="table-responsive">
                            <table class="table mb-0">
                                <thead>
                                    <tr>
                                        <th>Customer Name</th>
                                        <th>Email</th>
                                        <th>Phone Number</th>
                                        <th>DOB</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Molly</td>
                                        <td>eleifend@tortordictumeu.co.uk</td>
                                        <td>(568) 279-6303</td>
                                        <td>08/09/2018</td>

                                        <td>
                                            <div class="action_dropdown">
                                                <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="user-view.php">View</a>
                                                        <a class="dropdown-item" href="user-edit.php">Edit</a>
                                                        <a class="dropdown-item" href="javascript:void(0);" onclick="deleteModal()">Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Todd</td>
                                        <td>Donec.at@facilisis.net</td>
                                        <td>(312) 892-1676</td>
                                        <td>08/09/2018</td>
                                        <td>
                                            <div class="action_dropdown">
                                                <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="user-view.php">View</a>
                                                        <a class="dropdown-item" href="user-edit.php">Edit</a>
                                                        <a class="dropdown-item" href="javascript:void(0);" onclick="deleteModal()">Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Keane</td>
                                        <td>semper.egestas.urna@coneget.org</td>
                                        <td>(572) 609-3453</td>
                                        <td>08/09/2018</td>
                                        <td>
                                            <div class="action_dropdown">
                                                <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="user-view.php">View</a>
                                                        <a class="dropdown-item" href="user-edit.php">Edit</a>
                                                        <a class="dropdown-item" href="javascript:void(0);" onclick="deleteModal()">Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Maile</td>
                                        <td>at.arcu@coniscing.com</td>
                                        <td>(234) 460-5687</td>
                                        <td>08/09/2018</td>
                                        <td>
                                            <div class="action_dropdown">
                                                <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="user-view.php">View</a>
                                                        <a class="dropdown-item" href="user-edit.php">Edit</a>
                                                        <a class="dropdown-item" href="javascript:void(0);" onclick="deleteModal()">Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Alfonso</td>
                                        <td>aliquet.sem.ut@nonhd.edu</td>
                                        <td>(248) 202-7572</td>
                                        <td>08/09/2018</td>
                                        <td>
                                            <div class="action_dropdown">
                                                <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-more-button-interface-symbol-of-three-horizontal-aligned-dots"></i>
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="user-view.php">View</a>
                                                        <a class="dropdown-item" href="user-edit.php">Edit</a>
                                                        <a class="dropdown-item" href="javascript:void(0);" onclick="deleteModal()">Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td> 
                                    </tr>
                                </tbody>
                                <!-- No Record Found -->
                                <tr>
                                    <td colspan="4" style="display: none"><div class="alert alert-danger text-center">No Record Found</td>
                                </tr>
                                <!--  -->
                            </table>
                        </div>
                    </div>
                </div>
            </div>




        </div>



    </div>
</div>
<script>
    $('.static_box .total h3').each(function () {
        var $this = $(this),
                countTo = $this.attr('data-count');

        $({countNum: $this.text()}).animate({
            countNum: countTo
        },
        {
            duration: 2300,
            easing: 'linear',
            step: function () {
                $this.text(Math.floor(this.countNum));
            },
            complete: function () {
                $this.text(this.countNum);
            }

        });


    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>