<?php $__env->startSection('title', 'Edit Executive'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray"  onload="hide_preloader();">
    <?php echo $__env->make('admin.layouts.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="main-content cms-edit" id="mainContent">
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="page-content" id="pageContent" >
            <div class="card custom_card" id="card_height">
                <div class="card-header">
                    <h4 class="page-title float-left">Edit Executive</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item">
                            <a id="back-loader" onclick="backloader()" href="<?php echo e(url('admin/executive')); ?>" class="nav-link" title="Back">
                                <i class="fa fa-long-arrow-left"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <form id="editExecutiveForm" autocomplete="off" class="f-field" method="POST" action="<?php echo e(url('admin/executive-update')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="user_id" value="<?php echo e($editExecutive->id); ?>">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">First Name</label>
                                    <input type="text" name="first_name" value="<?php echo e($editExecutive->first_name); ?>" class="form-control form-control-lg">
                                </div>
                            </div> 
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Last Name</label>
                                    <input type="text" name="last_name" value="<?php echo e($editExecutive->last_name); ?>" class="form-control form-control-lg">
                                </div>
                            </div> 
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Email</label>
                                    <input type="text" name="email" value="<?php echo e($editExecutive->email); ?>" class="form-control form-control-lg">
                                </div>
                            </div> 
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Phone</label>
                                    <input type="text" name="phone" value="<?php echo e($editExecutive->phone_number); ?>" class="form-control form-control-lg phoneNumber" maxlength="10">
                                </div>
                            </div>    
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Upload Image</label>
                                    <div class="file-upload">
                                        <div class="file-select">
                                            <div class="file-select-button" id="fileName"  >Choose File</div>
                                            <div class="file-select-name" id="spanFileName"><?php echo e(!empty($editExecutive->profile_image) ? $editExecutive->profile_image : 'No file chosen...'); ?></div> 
                                            <input type="file" name="image_file" id="imageUpload" onchange="uploadFile(this)">
                                            <input type="hidden" value="<?php echo e($editExecutive->profile_image); ?>" name="hiddenFileName" class="do-not-ignore" name="hiddenFileName" id="hiddenMediaFileName">
                                        </div>
                                    </div>  
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <?php
                                $banks = \App\Http\Models\Bank::getBankList();
                                ?>
                                <div class="form-group">
                                    <label class="control-label">Select Company</label>
                                    <select id="selectBank" name="bank" class="form-control selectpicker" onchange="$(this).valid();">
                                        <option value="">Select Bank</option>                                        
                                        <?php if(count($banks)>0): ?>
                                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bank->id); ?>" <?php echo e($editExecutive->bank_id == $bank->id ? 'selected' : ''); ?>><?php echo e($bank->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <?php
                                $categories = \App\Http\Models\BankingCategory::getActiveCategories();
                                ?>
                                <div class="form-group">
                                    <label class="control-label">Select Category</label>
                                    <select id="selectCategory" name="category" class="form-control selectpicker" onchange="$(this).valid();">
                                        <option value="">Select Category</option>                                        
                                        <?php if(count($categories)>0): ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php echo e($editExecutive->category_id == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <?php
                                $managers = \App\Http\Models\User::getManagerLinkedById();
                                $linkedManagers = \App\Http\Models\ExecutiveManagerRelation::getCustomerByExecutiveAdmin($editExecutive->id);
                                ?>
                                <div class="form-group">
                                    <label class="control-label">Select Manager</label>
                                    <select id="selectManager" name="manager_id" class="form-control selectpicker">
                                        <option value="">Select Manager</option>                                        
                                        <?php if(count($managers)>0): ?>
                                        <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($manager->id); ?>" <?php echo e(($manager->id == $linkedManagers) ? 'selected' : ''); ?>><?php echo e(getFullName($manager->first_name ,$manager->last_name )); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <?php
                                $customers = \App\Http\Models\User::getCustomerLinkedById();
                                $linkedCustomers = \App\Http\Models\CustomerExecutiveRelation::getCustomerByExecutiveId($editExecutive->id);
                                $data = array();                                                                 
                                foreach($linkedCustomers as $linkedCustomer){
                                $data[] = $linkedCustomer->customer_id;
                                }
                                ?>
                                <div class="form-group">
                                    <label class="control-label">Select Customer</label>
                                    <select id="selectCustomer" name="customer[]" multiple class="form-control selectpicker">
                                        <option value="">Select Customer</option>                                        
                                        <?php if(count($customers)>0): ?>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($customer->id); ?>" <?php echo e(in_array($customer->id,$data) ? 'selected' : ''); ?>><?php echo e(getFullName($customer->first_name ,$customer->last_name )); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="from-group">
                            <button id="btnEditExecutive" type="submit" class="btn btn-primary btn_radius submitButton">
                                <i id="editExecutiveFormLoader" class="fa fa-spin fa-spinner" style="display: none;"></i> Save
                            </button>
                        </div>
                    </form>
                    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\EditExecutiveRequest','#editExecutiveForm'); ?>

                </div>
            </div>
        </div>
    </main>

    <!-- cropper-Modal -->
    <div class="modal fade" id="cropper-image-modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <!--<h4 class="modal-title"></h4>-->
                </div>
                <div id="image-cropper-form">
                </div>                            
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).on('submit', '#editExecutiveForm', function (e) {
            e.preventDefault();
            if ($('#editExecutiveForm').valid()) {
                $('#btnEditExecutive').prop('disabled', true);
                $('#editExecutiveFormLoader').show();
                var formData = new FormData($('#editExecutiveForm')[0]);
                //                formData.append('_token', '<?php echo e(csrf_token()); ?>');
                $.ajax({
                    url: "<?php echo e(url('admin/executive-update')); ?>",
                    data: formData,
                    type: 'POST',
                    dataType: 'JSON',
                    processData: false,
                    contentType: false,
                    success: function (response) {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            setTimeout(function () {
                                window.location = "<?php echo e(url('/admin/executive')); ?>";
                            }, 1000);
                        } else {
                            toastrAlertMessage('error', response.message);
                            $('#btnEditExecutive').prop('disabled', false);
                        }
                        $('#editExecutiveFormLoader').hide();
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            $('#editExecutiveFormLoader').hide();
                            $('#btnEditExecutive').prop('disabled', false);
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            }
        });

        /* image uploading with cropper*/
        function uploadFile(thisEl) {
            if (thisEl.files[0]) {
                var inputFile = thisEl.files[0].name;
                var extension = inputFile.substr(inputFile.lastIndexOf('.') + 1); /*get file exension*/
                /*check file type and exension*/
                if (extension != 'jpg' && extension != 'jpeg' && extension != 'png') {
                    toastrAlertMessage('error', 'Image allows only in jpeg, png or jpg format');
                    $('#imageUpload').val('');
                    $('#hiddenMediaFileName').val('');
                    return false;
                }
                var formData = new FormData($('#editManagerForm')[0]); /*uploading on server via ajax call*/
                formData.append('_token', '<?php echo e(csrf_token()); ?>');
                $.ajax({
                    url: "<?php echo e(url('admin/upload-media-image')); ?>",
                    type: 'POST',
                    data: formData,
                    processData: false,
                    cache: false,
                    contentType: false,
                    success: function (response) {
                        loadImageCropperModal(response.filename);
                        $('#cropper-image-modal').modal('show');
                    }
                });
            }
        }

        function loadImageCropperModal(imageName) {
            $.ajax({
                url: "<?php echo e(url('admin/load-image-cropper')); ?>",
                type: 'GET',
                data: {imageName: imageName, type: 'profile_image'},
                success: function (response) {
                    $('#image-cropper-form').html(response.html);
                }
            });
        }

        function backloader()
        {
            $("#back-loader").attr("disabled", true);
            $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
        }
        ;
        window.addEventListener('beforeunload', function (event)
        {
            $("#save-loader").attr("disabled", true);
            $("#save-loader").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
        });

    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>