<aside class="side_menu ">
    <ul class="list-unstyled mCustomScrollbar" data-mcs-theme="dark">
        <li class="<?php echo e(( \Request::route()->getName() == 'admin.dashboard') ? 'active' : ''); ?>"><a class="ripple-effect" href="<?php echo e(url('/admin/dashboard')); ?>"> <i class="flaticon-dashboard-interface"></i>   Dashboard</a></li>
        <li class="<?php echo e(( \Request::route()->getName() == 'admin.manage-users') ? 'active' : ''); ?>"><a class="ripple-effect" href="<?php echo e(url('/admin/manage-users')); ?>"> <i class="flaticon-multiple-users-silhouette"></i>  Manage Users</a></li>
        <li class="<?php echo e(( \Request::route()->getName() == 'admin.ebook') ? 'active' : ''); ?>"><a class="ripple-effect" href="<?php echo e(url('admin/manage-ebook')); ?>"> <i class="flaticon-reading"></i>My eBook</a></li>
        <li class="<?php echo e(( \Request::route()->getName() == 'admin.manage-podcast') ? 'active' : ''); ?>"><a class="ripple-effect" href="<?php echo e(url('/admin/manage-podcast')); ?>"> <i class="flaticon-podcast-symbol"></i>Manage Podcasts</a></li>
        <li class="<?php echo e(( \Request::route()->getName() == 'admin.blogs') ? 'active' : ''); ?>"><a class="ripple-effect" href="<?php echo e(url('/admin/manage-blogs')); ?>"> <i class="flaticon-contract"></i>Manage Blogs</a></li>
        <li class="<?php echo e(( \Request::route()->getName() == 'admin.manage-cms') ? 'active' : ''); ?>" class=""><a class="ripple-effect" href="<?php echo e(url('admin/manage-cms/home')); ?>"> <i class="flaticon-content-management"></i>CMS</a></li>
        <li class="<?php echo e(( \Request::route()->getName() == 'admin.transaction') ? 'active' : ''); ?>"><a class="ripple-effect" href="<?php echo e(url('/admin/manage-transactions')); ?>"> <i class="flaticon-transaction"></i>Transactions</a></li>
    </ul>
</aside>
