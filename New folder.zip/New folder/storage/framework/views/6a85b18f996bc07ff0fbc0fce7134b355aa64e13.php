<!-- Modal -->
<div class="modal fade common-modal" id="profile" tabindex="-1" data-backdrop="static" role="dialog" aria-labelledby="profileModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content profile-modal">
            <div class="modal-header align-items-center">
                <div class="col text-left p-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="col p-0 text-center">
                    <h5 class="modal-title" id="profileModalLabel">PROFILE</h5>
                </div>
                <div class="col p-0 text-right">
                </div>
            </div>
            <div class="modal-body" id="divProfileModelBody">
            </div>
        </div>
    </div>
</div>

<!--custome common scripts-->
<script>
// toaster common function
    function toastrAlertMessage(type, msg) {
        if (type == 'success') {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.success(msg, {timeOut: 2000});
        } else {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.error(msg, {timeOut: 2000});
        }
    }

    function pageDivLoader(type, id) {
        if (type === 'show') {
            $('#' + id).html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-2x"></i></div>');
        } else {
            $('#' + id).html('');
        }
    }

    $.validator.setDefaults({
        ignore: ":hidden:not(.do-not-ignore)", // not ignoring validation where .do-not-ignore class is used
    });

//
//    function pageSpinnerLoader(type, id) {
//        if (type === 'show') {
//            $('#' + id).html('<div class="text-center"><i class="fa fa-spin fa-spinner  fa-2x"></i></div>');
//        } else {
//            $('#' + id).html('');
//        }
//    }

</script>

<script>
    // users detail model open
    function showUserProfile() {
        $.ajax({
            url: "<?php echo e(url('/user-profile')); ?>",
            type: 'GET',
            success: function (response) {
                if (response.success) {
                    $("#profile").modal('show');
                    $("#divProfileModelBody").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }

            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>

<script>
    //header scroll effect
    var headerHeight = $('#main_header').height();
    function stickyheader() {
        scrtop = $(window).scrollTop();
        if (scrtop >= headerHeight) {
            $('#main_header').addClass('fixed');
        } else {
            $('#main_header').removeClass('fixed');
        }
    }

    $(window).scroll(function () {
        stickyheader();
    });
    //ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });

    $(function () {
//        $('#SelectDate, #SelectDate01').datetimepicker({
//            format: 'L',
//            debug: true,
//            focusOnShow: false,
//            ignoreReadonly: true,
//            allowInputToggle: true
//        });
        $('#SelectDate, #SelectDate01').datetimepicker({
            focusOnShow: false,
            format: 'L',
            ignoreReadonly: true
        }).on('dp.show', function (e) {
            $(e.target).on('mousedown', function (e) {
                $(e.target).data("DateTimePicker").hide();
                e.preventDefault();
            });
        }).on('dp.hide', function (e) {
            $(e.target).off('mousedown');
        });
    });
    $(function () {
        $('#SelectTime, #SelectTime01').datetimepicker({
            ocusOnShow: false,
            format: 'LT',
            ignoreReadonly: true
        }).on('dp.show', function (e) {
            $(e.target).on('mousedown', function (e) {
                $(e.target).data("DateTimePicker").hide();
                e.preventDefault();
            });
        }).on('dp.hide', function (e) {
            $(e.target).off('mousedown');
        });
    });
    // Interactive Effects
    $(".i-checks").each(function () {
        var intElem = $(this);
        intElem.on('click', function () {
            intElem.addClass('interactive-effect');
            setTimeout(function () {
                intElem.removeClass('interactive-effect');
            }, 400);
        });
    });

    $(document).ready(function () {
        if (screen.width > 1200) {
            $(window).resize(function () {
                var window_height = window.innerHeight;
                var header_height = $('#top-header').outerHeight(true);
                $('#content').css('min-height', window_height - header_height);
            }).resize();
        }
    });

    $(document).ready(function () {
        $(window).resize(function () {
            var header_height = $('#top-header').outerHeight(true);
            $('#content').css('margin-top', header_height);
        }).resize();
    });
</script>