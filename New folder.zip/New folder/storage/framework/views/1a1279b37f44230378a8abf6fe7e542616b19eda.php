<thead>
<th colspan="2">NAME</th>
<th>ID</th>
<th>CATEGORY</th>
<th>TOTAL CALL TIME</th>
<th>DATE OF CALL</th>
<th>STATUS</th>
<th width="140">ACTION</th>
</thead>
<tbody>
    <tr>
        <td width="100" align="right">
            <div class="user_img">
                <img src="user01.jpg" alt="user" class="rounded-circle">
            </div>
        </td>
        <td class="min200">
            <div class="user_detail">
                <h4>Micah Chan</h4>
                <p class="mb-0">American Express Bank</p>
            </div>
        </td>
        <td>ID: 2563542</td>
        <td>Product Upgrade</td>
        <td>
            <div class="user_tym">
                <i class="icon-clock"></i> 15 mins
            </div>
        </td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 23 Aug 2018
            </div>
        </td>
        <td>
            <div class="user_status pending">
                <span>Pending</span>
            </div>
        </td>
        <td>
            <ul class="list_btns list-inline mb-0">
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary btn-icon ripple-effect-dark" onClick="viewHestory()"><i class="icon-eye"></i></a></li>
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary ripple-effect-dark btn-icon" onclick="editNote();"><i class="icon-pencil"></i></a></li>
            </ul>
        </td>
    </tr>
    <tr>
        <td width="100" align="right">
            <div class="user_img">
                <img src="user02.jpg" alt="user" class="rounded-circle">
            </div>
        </td>
        <td class="min200">
            <div class="user_detail">
                <h4>Kendall Campos</h4>
                <p class="mb-0">American Express Bank</p>
            </div>
        </td>
        <td>ID: 2563542</td>
        <td>Account Changes</td>
        <td>
            <div class="user_tym">
                <i class="icon-clock"></i> 15 mins
            </div>
        </td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 23 Aug 2018
            </div>
        </td>
        <td>
            <div class="user_status resolved">
                <span>Resolved</span>
            </div>
        </td>
        <td>
            <ul class="list_btns list-inline mb-0">
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary btn-icon ripple-effect-dark" onClick="viewHestory()"><i class="icon-eye"></i></a></li>
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary ripple-effect-dark btn-icon" onclick="editNote();"><i class="icon-pencil"></i></a></li>
            </ul>
        </td>
    </tr>
    <tr>
        <td width="100" align="right">
            <div class="user_img">
                <img src="user03.jpg" alt="user" class="rounded-circle">
            </div>
        </td>
        <td class="min200">
            <div class="user_detail">
                <h4>Clementine Fischer</h4>
                <p class="mb-0">American Express Bank</p>
            </div>
        </td>
        <td>ID: 2563542</td>
        <td>Request Supplies</td>
        <td>
            <div class="user_tym">
                <i class="icon-clock"></i> 15 mins
            </div>
        </td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 23 Aug 2018
            </div>
        </td>
        <td>
            <div class="user_status pending">
                <span>PENDING</span>
            </div>
        </td>
        <td>
            <ul class="list_btns list-inline mb-0">
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary btn-icon ripple-effect-dark" onClick="viewHestory()"><i class="icon-eye"></i></a></li>
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary ripple-effect-dark btn-icon" onclick="editNote();"><i class="icon-pencil"></i></a></li>
            </ul>
        </td>
    </tr>
    <tr>
        <td width="100" align="right">
            <div class="user_img">
                <img src="user04.jpg" alt="user" class="rounded-circle">
            </div>
        </td>
        <td class="min200">
            <div class="user_detail">
                <h4>Elmo Pratt</h4>
                <p class="mb-0">American Express Bank</p>
            </div>
        </td>
        <td>ID: 2563542</td>
        <td>Technical Support</td>
        <td>
            <div class="user_tym">
                <i class="icon-clock"></i> 15 mins
            </div>
        </td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 23 Aug 2018
            </div>
        </td>
        <td>
            <div class="user_status pending">
                <span>PENDING</span>
            </div>
        </td>
        <td>
            <ul class="list_btns list-inline mb-0">
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary btn-icon ripple-effect-dark" onClick="viewHestory()"><i class="icon-eye"></i></a></li>
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary ripple-effect-dark btn-icon" onclick="editNote();"><i class="icon-pencil"></i></a></li>
            </ul>
        </td>
    </tr>
    <tr>
        <td width="100" align="right">
            <div class="user_img">
                <img src="user05.jpg" alt="user" class="rounded-circle">
            </div>
        </td>
        <td class="min200">
            <div class="user_detail">
                <h4>Marny Sampson</h4>
                <p class="mb-0">American Express Bank</p>
            </div>
        </td>
        <td>ID: 2563542</td>
        <td>Request Supplies</td>
        <td>
            <div class="user_tym">
                <i class="icon-clock"></i> 15 mins
            </div>
        </td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 23 Aug 2018
            </div>
        </td>
        <td>
            <div class="user_status resolved">
                <span>Resolved</span>
            </div>
        </td>
        <td>
            <ul class="list_btns list-inline mb-0">
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary btn-icon ripple-effect-dark" onClick="viewHestory()"><i class="icon-eye"></i></a></li>
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary ripple-effect-dark btn-icon" onclick="editNote();"><i class="icon-pencil"></i></a></li>
            </ul>
        </td>
    </tr>
    <tr>
        <td width="100" align="right">
            <div class="user_img">
                <img src="user06.jpg" alt="user" class="rounded-circle">
            </div>
        </td>
        <td class="min200">
            <div class="user_detail">
                <h4>Dalton Hoover</h4>
                <p class="mb-0">American Express Bank</p>
            </div>
        </td>
        <td>ID: 2563542</td>
        <td>Account Changes</td>
        <td>
            <div class="user_tym">
                <i class="icon-clock"></i> 15 mins
            </div>
        </td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 23 Aug 2018
            </div>
        </td>
        <td>
            <div class="user_status resolved">
                <span>Resolved</span>
            </div>
        </td>
        <td>
            <ul class="list_btns list-inline mb-0">
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary btn-icon ripple-effect-dark" onClick="viewHestory()"><i class="icon-eye"></i></a></li>
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary ripple-effect-dark btn-icon" onclick="editNote();"><i class="icon-pencil"></i></a></li>
            </ul>
        </td>
    </tr>
    <tr>
        <td width="100" align="right">
            <div class="user_img">
                <img src="user07.jpg" alt="user" class="rounded-circle">
            </div>
        </td>
        <td class="min200">
            <div class="user_detail">
                <h4>Steven Bray</h4>
                <p class="mb-0">American Express Bank</p>
            </div>
        </td>
        <td>ID: 2563542</td>
        <td>Technical Support</td>
        <td>
            <div class="user_tym">
                <i class="icon-clock"></i> 15 mins
            </div>
        </td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 23 Aug 2018
            </div>
        </td>
        <td>
            <div class="user_status resolved">
                <span>Resolved</span>
            </div>
        </td>
        <td>
            <ul class="list_btns list-inline mb-0">
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary btn-icon ripple-effect-dark" onClick="viewHestory()"><i class="icon-eye"></i></a></li>
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary ripple-effect-dark btn-icon"><i class="icon-pencil" onclick="editNote();"></i></a></li>
            </ul>
        </td>
    </tr>
    <tr>
        <td width="100" align="right">
            <div class="user_img">
                <img src="user08.jpg" alt="user" class="rounded-circle">
            </div>
        </td>
        <td class="min200">
            <div class="user_detail">
                <h4>Genevieve Stark</h4>
                <p class="mb-0">American Express Bank</p>
            </div>
        </td>
        <td>ID: 2563542</td>
        <td>Technical Support</td>
        <td>
            <div class="user_tym">
                <i class="icon-clock"></i> 15 mins
            </div>
        </td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 23 Aug 2018
            </div>
        </td>
        <td>
            <div class="user_status resolved">
                <span>Resolved</span>
            </div>
        </td>
        <td>
            <ul class="list_btns list-inline mb-0">
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary btn-icon ripple-effect-dark" onClick="viewHestory()"><i class="icon-eye"></i></a></li>
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary ripple-effect-ark btn-icon" onclick="editNote();"><i class="icon-pencil"></i></a></li>
            </ul>
        </td>
    </tr>
</tbody>
<script>
    //ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });
</script>