<?php $__env->startSection('title', 'Add Bank Category'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray"  onload="hide_preloader();">
    <?php echo $__env->make('admin.layouts.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="main-content cms-edit" id="mainContent">
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="page-content" id="pageContent" >
            <div class="card custom_card" id="card_height">
                <div class="card-header">
                    <h4 class="page-title float-left">Add Bank Category</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item">
                            <a id="back-loader" onclick="backloader()" href="<?php echo e(url('admin/categories')); ?>" class="nav-link" title="Back">
                                <i class="fa fa-long-arrow-left"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <form id="addCategoryForm" autocomplete="off" class="f-field" method="POST" action="<?php echo e(url('admin/add-category')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Name</label>
                                    <input type="text" name="name" class="form-control form-control-lg">
                                </div>
                            </div>
                        </div>
                        <div class="from-group">
                            <button id="btnAddCategory" type="submit" class="btn btn-primary btn_radius submitButton">
                                <i id="addCategoryFormLoader" class="fa fa-spin fa-spinner" style="display: none;"></i> Save
                            </button>
                        </div>
                    </form>
                    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\AddBankCategoryRequest','#addCategoryForm'); ?>

                </div>
            </div>
        </div>
    </main>
    <script type="text/javascript">
        $(document).on('submit', '#addCategoryForm', function (e) {
            e.preventDefault();
            if ($('#addCategoryForm').valid()) {
                $('#btnAddCategory').prop('disabled', true);
                $('#addCategoryFormLoader').show();
                $.ajax({
                    url: "<?php echo e(url('admin/add-category')); ?>",
                    data: $('#addCategoryForm').serialize(),
                    type: 'POST',
                    dataType: 'JSON',
                    success: function (response) {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            setTimeout(function () {
                                window.location = "<?php echo e(url('/admin/categories')); ?>";
                            }, 1000);
                        } else {
                            toastrAlertMessage('error', response.message);
                            $('#btnAddCategory').prop('disabled', false);
                        }
                        $('#addCategoryFormLoader').hide();
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            $('#addCategoryFormLoader').hide();
                            $('#btnAddCategory').prop('disabled', false);
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            }
        });

        function backloader()
        {
            $("#back-loader").attr("disabled", true);
            $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
        }
        ;
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>