<?php $__env->startSection('title', 'Bank Category'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray" onload="hide_preloader();">
    <?php echo $__env->make('admin.layouts.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="main-content common-grid-list" id="mainContent">
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="page-content" id="pageContent">
            <div class="card custom_card" id="card_height">
                <div class="card-header">
                    <h4 class="page-title float-left">Bank Categories</h4>
                    <ul class="list-inline mb-0 text-right">
<!--                        <li class="list-inline-item">
                            <a href="<?php echo e(url('admin/add-category')); ?>" id="add-loader" onclick="addloader()" class="nav-link"><i class="fa fa-plus"></i></a>
                        </li>-->
                        <li class="list-inline-item">
                            <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="fa fa-search"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="filter_section collapse" id="searchFilter">
                        <form id="search_form" action="javascript:load_category_list()" method="post" autocomplete="off">
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                                    <div class="form-group">
                                        <label class="control-label">Search by Name</label>
                                        <input type="text" id="name" name="name" class="form-control form-control-lg"/>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                                    <div class="form-group d-inline-block mr-2">
                                        <label class="btn-block d-none d-md-block">&nbsp;</label>
                                        <button class="btn btn-primary" type="submit">Filter</button>
                                    </div>
                                    <div class="form-group d-inline-block mr-2">
                                        <label class="btn-block d-none d-md-block">&nbsp;</label>
                                        <input type="reset" id="reset-btn" class="btn btn-primary" value="reset">
                                    </div>
                                </div> 
                            </div>
                        </form>
                    </div>
                    <div class="table-responsive" id="category_list">

                    </div>
                </div>
            </div>
        </div>
    </main>

    <script type="text/javascript">
        $(document).ready(function ()
        {
            load_category_list();
        });

        $("#reset-btn").click(function ()
        {
            $('#name').val('').change();
            load_category_list();
        });

        function load_category_list()
        {
            pageDivLoader('show', 'category_list');
            var search_filter = $("#search_form").serializeArray();
            $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/category-list')); ?>",
                data: search_filter,
                success: function (response)
                {
                    if (response.success) {
                        $("#category_list").html(response.html);
                    } else {
                        toastrAlertMessage('error', response.message);
                    }

                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }

        function viewfunction(id)
        {
            $("#view-loader" + id).attr("disabled", true);
            $("#view-loader" + id).html('<i class="fa fa-spinner fa-spin"></i>');
        }

        function addloader()
        {
            $("#add-loader").attr("disabled", true);
            $("#add-loader").html('<i class="fa fa-spinner fa-spin"></i>');
        }

        function editfunction(id)
        {
            $("#edit-loader" + id).attr("disabled", true);
            $("#edit-loader" + id).html('<i class="fa fa-spinner fa-spin"></i>');
        }

        function activeInacive(id, status)
        {
            if (status == 'active')
            {
                var msg = "Are you sure you want to deactivate this bank category?";
            }
            else if (status == 'inactive')
            {
                var msg = "Are you sure you want to activate this bank category?";
            }
            bootbox.confirm(msg, function (result)
            {
                if (result)
                {
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(url('admin/active-inactive-category')); ?>/" + id,
                        data: {'_token': '<?php echo e(csrf_token()); ?>'},
                        success: function (response)
                        {
                            if (response.success) {
                                toastrAlertMessage('success', response.message);
                                load_category_list();
                            } else {
                                toastrAlertMessage('error', response.message);
                            }
                        },
                        error: function (err) {
                            var obj = jQuery.parseJSON(err.responseText);
                            for (var x in obj) {
                                toastrAlertMessage('error', obj[x]);
                            }
                        }
                    });
                }
                else
                {
                    if (status == 'active')
                    {
                        $('#enable_a_' + id).attr('checked', true);
                    }
                    else
                    {
                        $('#enable_a_' + id).attr('checked', false);
                    }
                }
            });
        }

        function deletefunction(id)
        {
            bootbox.confirm('Are you sure do you want to delete this bank category?', function (result)
            {
                if (result)
                {
                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(url('admin/delete-category')); ?>/" + id,
                        success: function (response)
                        {
                            if (response.success) {
                                toastrAlertMessage('success', response.message);
                                document.getElementById('category' + id).style.display = 'none';
                            } else {
                                toastrAlertMessage('error', response.message);
                            }
                        },
                        error: function (err) {
                            var obj = jQuery.parseJSON(err.responseText);
                            for (var x in obj) {
                                toastrAlertMessage('error', obj[x]);
                            }
                        }
                    });
                }
            });
        }
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>