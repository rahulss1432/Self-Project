<?php $__env->startSection('title', 'Admin Login'); ?>
<?php $__env->startSection('content'); ?>
  <main class="login-page">
    <div class="login-wrap mx-auto">
      <div class="login-header d-flex align-items-center justify-content-center">
        <img src="public/assets/images/logo.png" alt="logo">
      </div>
      <div class="login-field">
        <form id="adminLoginForm" method="POST" action="<?php echo e(url('/admin/login')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <div class="input- group">
              <label class="control-label">Email</label>
              <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control form-control-lg" id="inlineFormInputGroup">
            </div>
          </div>
          <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <div class="input- group">
              <label class="control-label">Password</label>
              <input type="password" name="password" value="<?php echo e(old('password')); ?>" class="form-control form-control-lg">
              <?php if($errors->has('email')): ?>
                <span class="help-block error-help-block"><b><?php echo e($errors->first('email')); ?></b></span>
              <?php endif; ?>
            </div>
          </div>
          <div class="form-group text-center">
            <button type="submit" class="btn btn-primary btn_radius" id="login-form-loader">LOGIN</button>
          </div>
        </form>
        <?php echo JsValidator::formRequest('App\Http\Requests\AdminLoginRequest','#adminLoginForm'); ?>

      </div>
      <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
          <?php echo e(session()->get('message')); ?>

        </div>
      <?php endif; ?>
      <div class="login-footer">
        <a id="forward-loader" href="<?php echo e(url('/admin/forgot-password')); ?>" onclick="forwardloader()">FORGOT PASSWORD <i class="fa fa-long-arrow-right"></i></a>
      </div>
    </div>
  </main>
  <?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <script type="text/javascript">

    window.addEventListener('beforeunload', function(event)
    {
      $("#login-form-loader").attr("disabled", true);
      $("#login-form-loader").html('LOGIN <i class="fa fa-spinner fa-spin"></i>');
    });

    function forwardloader()
    {
      $("#forward-loader").attr("disabled", true);
      $("#forward-loader").html('FORGOT PASSWORD <i class="fa fa-spinner fa-spin"></i>');
    };
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>