<div class="table-responsive">
    <table class="table common-table">
        <thead>
            <tr>
                <th>Sr.</th>
                <th>Transaction id</th>
                <th>Purchase Date</th>
                <th>Plan Type</th>
                <th>Amount</th>
                <th>Expiry Date</th>
            </tr>
        </thead>
        <tbody>
            <?php if($paymentList->count()>0): ?>
            <?php $i=1; ?>
            <?php $__currentLoopData = $paymentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $srNo = ($paymentList->currentPage() - 1) * $paymentList->perPage() + $i++; ?>
            <tr>
                <td><?php echo e($srNo); ?></td>
                <td><?php echo e($payment['transaction_id']); ?></td>
                <td><?php echo e(\App\Helpers\Utility::getDateFormat($payment['created_at'])); ?></td>
                <td><?php echo e($payment->getPlan->plan_name); ?></td>
                <td><?php echo e(\App\Helpers\Utility::getPriceFormat($payment['amount'])); ?></td>
                <td><?php echo e(\App\Helpers\Utility::getDateFormat($payment['expiry_date'])); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="6">
                    <?php \App\Helpers\Utility::emptyListMessage('payment history'); ?>
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php if($paymentList->count()>0): ?>
<?php \App\Helpers\Utility::getAdminPaginationDiv($paymentList); ?>
<?php endif; ?>
<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            $("#paymentList").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
            var pageLink = $(this).attr('href');
            $.ajax({
                type: 'POST',
                url: pageLink,
                async: false,
                data: {_token: '<?php echo e(csrf_token()); ?>'},
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#paymentList").html(response);
                }
            });
        });
    });
</script>
