<form id="addManagerForm" autocomplete="off" class="f-field" method="POST" action="<?php echo e(url('admin/add-contact-manager')); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <label class="control-label">First Name</label>
                <input type="text" name="first_name" value="<?php echo e($viewManager->first_name); ?>" class="form-control form-control-lg">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label class="control-label">Last Name</label>
                <input type="text" name="last_name" value="<?php echo e($viewManager->last_name); ?>" class="form-control form-control-lg">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label class="control-label">Email</label>
                <input type="email" name="email" value="<?php echo e($viewManager->email); ?>" class="form-control form-control-lg">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label class="control-label">Mobile Number</label>
                <input type="text" name="phone" value="<?php echo e($viewManager->phone); ?>" class="form-control form-control-lg">
            </div>
        </div>

        <div class="col-sm-6">
            <div class="form-group">
                <label class="control-label">Company</label>
                <input type="text" name="company" value="<?php echo e($viewManager->company); ?>" class="form-control form-control-lg">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label class="control-label">Manager Type</label>
                <select name="manager_type" class="form-control form-control-lg">
                    <option value="">Select Manager Type</option>
                    <option value="technical" <?php if($viewManager->type == "technical"): ?> selected="selected" <?php endif; ?>>Technical SM</option>
                    <option value="merchant" <?php if($viewManager->type == "merchant"): ?> selected="selected" <?php endif; ?>>Merchant SM</option>
                    <option value="relationship" <?php if($viewManager->type == "relationship"): ?> selected="selected" <?php endif; ?>>Relationship SM</option>
                </select>
            </div>
        </div>
    </div>
    <div class="from-group">
        <button id="btnAddManager" type="submit" class="btn btn-primary btn_radius submitButton">
            <i id="addManagerFormLoader" class="fa fa-spin fa-spinner" style="display: none;"></i> Save
        </button>
    </div>
</form>
<?php echo JsValidator::formRequest('App\Http\Requests\Admin\AddContactManagerRequest','#addManagerForm'); ?>