<?php if(count($managers) >0): ?>
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Company Name</th>
            <th>Phone number</th>
            <th>Type</th>
            <th>Created Date</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>       
        <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e('managers'.$data->id); ?>">
            <td><?php echo e($data->first_name.' '.$data->last_name); ?></td>
            <td><?php echo e($data->email); ?></td>
            <td><?php echo e($data->company); ?></td>
            <td><?php echo e($data->phone); ?></td>
            <td><?php echo e($data->type); ?></td>
            <td><?php echo e($data->created_at); ?></td>
            <td>
                <ul class="list-inline mb-0 "> 
                    <li class="list-inline-item">
                        <a id="view-loader" href="javascripe:void(0)" onclick="viewfunction(<?php echo e($data->id); ?>)">
                            <i class="fa fa-eye"></i>
                        </a>
                    </li>
                </ul>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center><?php echo e(\Config::get('constants.no_record_found')); ?></center></div>
<?php endif; ?>
