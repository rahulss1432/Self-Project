<?php $__env->startSection('title', 'Notification'); ?>
<?php $__env->startSection('content'); ?>
<?php
$currentRoute = Request::route()->getName();
?>
<main class="main-content requests-page" id="content">
    <section class="tabs_section">
        <ul class="list-unstyled tabs_links d-flex justify-content-start">
            <li class="text-uppercase <?php echo e(($currentRoute == 'executive-notification' )?'active':''); ?>"><a href="<?php echo e(url('notification')); ?>">NOTIFICATIONS <span>(05)</span></a></li>
            <li class="text-uppercase <?php echo e(($currentRoute == 'executive-request' )?'active':''); ?>"><a href="<?php echo e(url('customer-request')); ?>">CUSTOMER REQUESTS</a></li>
            <li class="text-uppercase <?php echo e(($currentRoute == 'executive-history' )?'active':''); ?>"><a href="<?php echo e(url('linked-history')); ?>">LINKED HISTORY</a></li>
        </ul>
        <div class="tabs_content">
            <div class="table-responsive">
                <table class="table no-border">
                    <tbody id="getnotifications"></tbody>
                </table>
            </div>
        </div>
    </section>
</main>
<script>
    $(document).ready(function () {
        getNotificationslist();
    });
    function getNotificationslist() {
        $("#getnotifications").html('<div class="listloader text-center pb-4"><i class="fa-2x fa-spin fas fa-spinner"></i></div>');
        var url = '<?php echo e(url("notification-list")); ?>';
        $.ajax({type: "GET", url: url,
            success: function (response) {
                setTimeout(function () {
                    $("#getnotifications").html("");
                    $("#getnotifications").hide().html(response.html).fadeIn('2000');
                }, 1000);
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('executive.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>