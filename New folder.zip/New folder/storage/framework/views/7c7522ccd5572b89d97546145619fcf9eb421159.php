<?php if($seMerchant->count()>0): ?>
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Merchant Name</th>
            <th>Merchant Processor</th>
            <th>Credit Card Machine Model</th>
            <th>Phone Number</th>
            <th>Business name</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $seMerchant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->userCustomerDetail->contact_name); ?></td>
            <td><?php echo e(!empty($user->userCustomerProfile->product) ? $user->userCustomerProfile->product : ''); ?></td>
            <td><?php echo e(!empty($user->userCustomerProfile->machine_model) ? $user->userCustomerProfile->machine_model : ''); ?></td>
            <td><?php echo e($user->userCustomerDetail->phone_number); ?></td>
            <td><?php echo e(!empty($user->userCustomerProfile->bussiness_name) ? $user->userCustomerProfile->bussiness_name : ''); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center><?php echo e(\Config::get('constants.no_record_found')); ?></center></div>
<?php endif; ?>