<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-wrapper dashboard-main-wrap  dasboard" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <!-- breadcrumb start-->
            <nav aria-label="breadcrumb" class="text-right order-md-last">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" id="dashboardInactive">Dashboard</li>
                    <li class="breadcrumb-item" style="display:none"><a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a></li>                            
                    <li class="breadcrumb-item active" id="selectedTab" style="display:none"></li>
                    
                    
                </ol>
            </nav>
            <!-- breadcrumb end-->
            <!-- <div class="content-body">
                <h1 class="page-title">Dashboard</h1>
            </div> -->
            <section class="fun-fact">
                <div class="row box-row">
                    <div class="col-sm-6 col-lg-3"><!--applied-job.php-->
                        <a href="javascript:void(0);" id="appliedjobBox" onclick="showjobApplied();" class="wrap view-profile d-flex justify-content-between align-items-center">
                            <div class="text ">
                                <h2><?php echo e($jobsAppliedCount); ?></h2>
                                <p>JOBS APPLIED</p>
                            </div>
                            <div class="icon bg-green d-flex align-items-center justify-content-center">
                                <img src="<?php echo e(url('public/images/job-applied-icon.svg')); ?>" alt="icon">
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <a href="javascript:void(0);" id="invitationBox" onclick="showInvitation();" class="wrap yellow d-flex justify-content-between align-items-center">
                            <div class="text">
                                <h2><?php echo e($invitationCount); ?></h2>
                                <p>INVITATION</p>
                            </div>
                            <div class="icon bg-pink d-flex align-items-center justify-content-center">
                                <img src="<?php echo e(url('public/images/group-user-icon.svg')); ?>" alt="icon">
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <a href="javascript:void(0);" id="videobtnBox" onclick="getvideoList();" class="wrap view-video d-flex justify-content-between align-items-center">
                            <div class="text ">
                                <h2><?php echo e($videoViewsCount); ?></h2>
                                <p>VIDEO VIEWES </p>
                            </div>
                            <div class="icon bg-yello d-flex align-items-center justify-content-center">
                                <img src="<?php echo e(url('public/images/play-button-icon.svg')); ?>" alt="icon">
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <a href="javascript:void(0);" id="profilebtnBox" onclick="getprofileList();" class="wrap view-profile d-flex justify-content-between align-items-center">
                            <div class="text ">
                                <h2><?php echo e($profileViewsCount); ?></h2>
                                <p>PROFILE VIEWES</p>
                            </div>
                            <div class="icon bg-blue d-flex align-items-center justify-content-center">
                                <img src="<?php echo e(url('public/images/view-profile-icon.svg')); ?>" alt="icon">
                            </div>
                        </a>
                    </div>
                </div>

                <!-- view jobs applied content start -->
                <div class="card common-card" id="showjobApplied" style="display:none;">
                    <div class="card-body">
                        <h3 class="font-md top-heading">Jobs Applied</h3>
                        <div id="viewappliedList"></div>
                        <div class="text-center">
                            <div class="load_more" id="loadMoreJob" style="display: none;"> 
                                <a href="applied-job.php">
                                    View All
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- view jobs invitation start -->
                <div class="card common-card" id="showInvitation" style="display:none;">
                    <div class="card-body">
                        <h3 class="font-md top-heading">Invitation</h3>
                        <div id="invitationList"></div>
                        <div class="text-center">
                            <div class="load_more" id="loadMoreInvita" style="display: none;"> 
                                <a href="request-received.php">
                                    View All
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- view profile content start -->
                <div class="card common-card" id="showviewProfile" style="display:none;">
                    <div class="card-body">
                        <h3 class="font-md top-heading">Who Viewed Your Profile</h3>
                        <div id="viewedProfile"></div>
                        <div class="text-center">
                            <div class="load_more" id="profileVideoViews" style="display: none">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- view profile content end -->

                <!-- view video content start -->
                <div class="card common-card" id="showviewVideo" style="display:none;">
                    <div class="card-body">
                        <h3 class="font-md top-heading">Who Viewed Your Video</h3>
                        <div id="viewedVideo"></div>
                        <div class="text-center">
                            <div class="load_more" id="loadMoreVdo" style="display: none">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- view video content end -->
                <div id="graphSection">
                    <div class="row box-row">
                        <div class="col-lg-6">
                            <div class="card common-card mt-0 mt-lg-4">
                                <div class="card-header">
                                    <h3 class="font-md mb-0">Profile View</h3>
                                </div>
                                <div class="card-body">
                                    <canvas id="myChart1" width="100%" max-height="500"></canvas>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="card common-card mt-md-0 mt-lg-4">
                                <div class="card-header">
                                    <h3 class="font-md mb-0">Video View</h3>
                                </div>
                                <div class="card-body">
                                    <canvas id="myChart2" width="100%" max-height="500"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card common-card">
                        <div class="card-header d-flex">
                            <h3 class="font-md mb-0 mr-auto"> Payment History</h3>
                            <a href="<?php echo e(url('/user/payment-history')); ?>" class="see_all">See All</a>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table common-table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Transaction id </th>
                                            <th scope="col">Purchase Date</th>
                                            <th scope="col">Plan Type</th>
                                            <th scope="col">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($paymentHistoryData) > 0): ?>
                                            <?php $__currentLoopData = $paymentHistoryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(($data->getPlan->plan_name =='Free' ? '-' : $data->transaction_id)); ?></td>
                                                    <td><?php echo e(\App\Helpers\Utility::getDateFormat($data->created_at)); ?></td>
                                                    <td><?php echo e($data->getPlan->plan_name); ?></td>
                                                    <td><?php echo e(\App\Helpers\Utility::getPriceFormat($data->amount)); ?></td>
                                                </tr>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="4">
                                                <?php echo e(\App\Helpers\Utility::emptyListMessage('payment history')); ?>

                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</main>

<script>
    function getvideoList() {
        $("#videobtnBox").addClass("active");
        $("#dashboardInactive").hide();
        $("#selectedTab").prev().show();                               
        $("#selectedTab").show();                               
        document.getElementById("selectedTab").innerText = 'Video Views';
        $("#profilebtnBox, #appliedjobBox, #invitationBox").removeClass("active");
        $("#showviewProfile, #graphSection, #showjobApplied, #showInvitation").hide();
        $("#showviewVideo").show();
        loadVideoViewsList();
        $("#loadMoreVdo").fadeIn('1000');

    }
    
    function getprofileList() {
        $("#profilebtnBox").addClass("active");
        $("#dashboardInactive").hide();
        $("#selectedTab").prev().show();                               
        $("#selectedTab").show();                               
        document.getElementById("selectedTab").innerText = 'Profile Views';
        $("#videobtnBox, #appliedjobBox, #invitationBox").removeClass("active");
        $("#showviewProfile").show();
        $("#showviewVideo, #graphSection, #showjobApplied, #showInvitation").hide();
        loadProfileViewsList();
        $("#profileVideoViews").fadeIn('1000');
    }
    
    function loadVideoViewsList(){
        $("#loadMoreVdo").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        var token = '<?php echo e(csrf_token()); ?>';
        $.ajax({
            type: "POST",            
            url: "<?php echo e(url('/user/load-profile-video-view-list')); ?>",
            data: {_token: token, activity_type: 'view_video', page:'dashboard'},
            success: function (response) {
                $('#loadMoreVdo').html(response);
            }
        });
    }
    
    function loadProfileViewsList(){
        $("#profileVideoViews").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        var token = '<?php echo e(csrf_token()); ?>';
        $.ajax({
            type: "POST",            
            url: "<?php echo e(url('/user/load-profile-video-view-list')); ?>",
            data: {_token: token, activity_type: 'view_profile', page:'dashboard'},
            success: function (response) {
                $('#profileVideoViews').html(response);
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>