<section class="step-form-header">
    <ul class="list-unstyled mb-0 d-flex justify-content-center">
        <li class="<?php echo e((\Request::route()->getName() == 'user.edit-profile') ? 'active' : ''); ?>"><a href="<?php echo e(url('/user/edit-profile')); ?>">Personal Details</a></li>
        <li class="<?php echo e((\Request::route()->getName() == 'user.experience') ? 'active' : ''); ?>"><a href="<?php echo e(url('/user/experience')); ?>">Experience</a></li>
        <?php if(Auth::user()->user_type=='freelancer'): ?>
        <li class="<?php echo e((\Request::route()->getName() == 'user.portfolio') ? 'active' : ''); ?>"><a href="<?php echo e(url('/user/portfolio')); ?>">Portfolio</a></li>
        <?php endif; ?>
        <li class="<?php echo e((\Request::route()->getName() == 'user.skills') ? 'active' : ''); ?>"><a href="<?php echo e(url('/user/skills')); ?>">Skills</a></li>
        <li class="<?php echo e((\Request::route()->getName() == 'user.education') ? 'active' : ''); ?>"><a href="<?php echo e(url('/user/education')); ?>">Education</a></li>
        <li class="<?php echo e((\Request::route()->getName() == 'user.promo-video') ? 'active' : ''); ?>"><a href="<?php echo e(url('/user/promo-video')); ?>">Promo Video</a></li>
    </ul>
</section>