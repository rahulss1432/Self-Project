<?php $__env->startSection('title', 'Executive Detail'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray"  onload="hide_preloader();">
    <?php echo $__env->make('admin.layouts.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="main-content manage_post_view common-grid-list" id="mainContent">
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="page-content" id="pageContent">
            <div class="card custom_card" id="card_height">
                <div class="card-header">
                    <h4 class="page-title float-left">Executive Detail</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item">
                            <a id="back-loader" href="<?php echo e(url('admin/executive')); ?>" class="nav-link" onclick="backloader()" title="Back"><i class="fa fa-long-arrow-left"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="bg-white box-shadow manage_post">
                    <div class="post_comment">
                        <div class="d-sm-flex">
                            <div class="col-sm-6">
                                <h4>Profile :- <img src="<?php echo e(checkProfileImage($viewExecutive->profile_image)); ?>"></h4>
                            </div>
                            <div class="col-sm-6">
                                <h4>Name :- <?php echo e(getFullName($viewExecutive->first_name ,$viewExecutive->last_name )); ?></h4>
                            </div>
                        </div>
                        <div class="d-sm-flex">
                            <div class="col-sm-6">
                                <h4>Phone Number :- <?php echo e($viewExecutive->phone_number); ?></h4>
                            </div>
                            <div class="col-sm-6">
                                <h4>Email :- <?php echo e($viewExecutive->email); ?></h4>
                            </div>
                        </div>
                        <div class="d-sm-flex">
                            <div class="col-sm-6">
                                <h4>Company Name :- <?php echo e($viewExecutive->bank->name); ?></h4>
                            </div>
                            <div class="col-sm-6">
                                <h4>Category Name :- <?php echo e($viewExecutive->bankCategory->name); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script>
        function backloader()
        {
            $("#back-loader").attr("disabled", true);
            $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
        }
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>