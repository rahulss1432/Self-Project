<?php if($commentData->count()>0): ?>
<?php $__currentLoopData = $commentData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="comment-box">
    <div class="img-wrap">
        <img src="<?php echo e(\App\Helpers\Utility::checkProfileImage($list->getUser->profile_image)); ?>" alt="user" class="img-fluid">
    </div>
    <div class="right-side">
        <h3><?php echo e($list->getUser->first_name); ?> <?php echo e($list->getUser->last_name); ?></h3>
        <p class="user-comment"><?php echo e($list->comments); ?></p>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
