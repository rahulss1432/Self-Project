<header  id="topHeader">
    <div class="container-fluid">
        <nav class="navbar navbar-light justify-content-between bg-transparent">
            <h3 class="page-title">
                <a href="javascript:void(0);" onclick="sideMenu();" class="toggle-icon">
                    <i class="fa fa-outdent"></i>
                </a>
                <?php
                $currentUrl = Request::route()->getName();
                ?>
                <span><?php if($currentUrl =='manager-view-profile'): ?>
                    view profile
                    <?php elseif($currentUrl =='manager-dashboard'): ?>
                    dashboard
                    <?php elseif($currentUrl =='manage-merchant' || $currentUrl =='add-merchant' || $currentUrl == 'merchant-request-view' || $currentUrl =='edit-merchant' || $currentUrl == 'merchant-request' || $currentUrl == 'merchant-linked-executive' ): ?>
                    MERCHANT
                    <?php elseif($currentUrl =='manage-executives' || $currentUrl =='add-executive' || $currentUrl =='edit-executive' || $currentUrl == 'view-executive' || $currentUrl == 'support-executive-request' || $currentUrl == 'support-executive-request-view' || $currentUrl == 'support-executive-request-view-note'): ?>
                    SUPPORT EXECUTIVE
                    <?php elseif($currentUrl =='manage-document' || $currentUrl =='add-document' || $currentUrl =='edit-document' || $currentUrl == 'view-document'): ?>
                    DOCUMENTS                   
                    <?php elseif($currentUrl =='manager-change-password'): ?>
                    SETTING
                    <?php elseif($currentUrl =='call-request'||$currentUrl == 'call-request-view'): ?>
                    CALL REQUEST
                    <?php elseif($currentUrl =='notifications'): ?>
                    NOTIFICATIONS
                    <?php else: ?>
                    <?php endif; ?>
                </span>
            </h3> 
            <ul class="nav align-items-center ml-auto">
                <li class="dropdown notification">
                    <a href="javascript:void(0);" class="dropdown-toggle" id="dropdownMenuButton01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="count">20</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton01">
                        <div class="head">
                            <h3 class="font-hy mb-0">Notifications</h3>
                        </div>
                        <div class="noti_body">
                            <ul class="list-unstyled mCustomScrollbar" data-mcs-theme="minimal-dark">
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>

                            </ul>
                        </div>
                        <div class="noti_footer text-center">
                            <a href="notifications.php" class="d-block">View All</a>
                        </div>
                    </div>
                </li>
                <?php
                $authUser = \Auth::guard('manager')->user();
                ?>
                <li class="dropdown user_avtar">
                    <a href="javascript:void(0);"  class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="<?php echo e(getImage($authUser->profile_image,'users','users')); ?>" alt="user_img" class="user-img rounded-circle">
                        <span class="name"><?php echo e(getFullName($authUser->first_name ,$authUser->last_name)); ?></span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="<?php echo e(url('manager/view-profile')); ?>">View Profile</a>
                        <a class="dropdown-item" href="<?php echo e(url('manager/change-password')); ?>" >Change Password</a>
                        <!--<a class="dropdown-item" href="/index.php" >Logout</a>-->
                        <a class="dropdown-item" href="<?php echo e(url('manager/logout')); ?>" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                            Logout</span>
                        </a>
                        <form id="logout-form" action="<?php echo e(url('manager/logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </div>
                </li>

            </ul>
        </nav>
    </div>
</header>