<!-- delete modal -->
    <div class="modal delete-modal fade" data-backdrop="static" data-keyboard="false"  tabindex="-1" role="dialog" id="deleteModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xs">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="flaticon-cancel-music"></i>
                    </button>
                </div>
                <!-- xxxxx -->
                <div class="modal-body text-center">
                    
                    <!-- <p>Are you sure you want to delete ?</p> -->
                    <div class="modal-heading">
                        <h2>Are you sure you want to delete ?</h2>
                    </div>

                    <ul class="list-inline mb-0 mt-3 mt-md-4">
                        <li class="list-inline-item">
                             <a href="javascript:void(0);" class="btn btn-success rounded-0 ripple-effect" data-dismiss="modal">Yes</a>
                        </li>

                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="btn btn-dark rounded-0 ripple-effect ml-2" data-dismiss="modal">No</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

<script src="<?php echo e(url('public/admin/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(url('public/admin/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
<script src="<?php echo e(url('public/admin/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>

<script>
    function deleteModal(){
       $('#deleteModal').modal('show');
    }
    

    //nave toggle
	$(".navbar_toggle").click(function(){
	    $("body").toggleClass("toggle_menu");
	});
    // switch Effect 
    setTimeout(function(){  
        $(".switch , .custom-radio , .custom-checkbox , .checkbx_shadow").each(function () {
            var intElem = $(this);
            intElem.on('click', function () {
                intElem.addClass('interactive-effect');
                setTimeout(function () {
                    intElem.removeClass('interactive-effect');
                }, 400);
            });
        });
    }, 3000);
    //  dateFormate
    $( function () {
        $( '#satartDate, #endDate, #datepicker01' ).datetimepicker( {
            format: 'L',
            // debug:true
        } );
    } );
    //ripple effect button
  	$('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });


  // filter open / close
    function filterOpen(){
        $('#filterform').addClass('slide');
    }

    function filterClose(){
        $('#filterform').removeClass('slide');
    }
</script>
