<form id="EditSEquestForm" autocomplete="off" class="f-field" method="POST" action="<?php echo e(url('update-se-request')); ?>">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="request_id" value="<?php echo e($seRequest->id); ?>"> 
    <div class="form-group input_wrap">
        <label class="theme-color02 d-block">Request Status</label>
        <label class="i-checks">
            <input type="radio" name="status" value="pending" <?php echo e($seRequest->status == 'pending' ? 'checked' : ''); ?> onchange="status_radio('Pending');"><i></i> Pending 
        </label>
        <label class="i-checks ml-2 ml-sm-3">
            <input type="radio" name="status" value="resolved" <?php echo e($seRequest->status == 'resolved' ? 'checked' : ''); ?> onchange="status_radio('Resolved');"><i></i> Resolved 
        </label>
    </div>
    <div class="field_box Pending">
        <div class="form-group">
            <label class="theme-color02 d-block">Notify me</label>
            <div class="form-check form-check-inline">
                <label class="i-checks">
                    <input type="radio" name="notify_type" value="when_online" <?php echo e($seRequest->notify_type == 'when_online' ? 'checked' : ''); ?> onchange="notify_radio('UserOnline');"><i></i> When user back online 
                </label>
            </div>
            <div class="form-check form-check-inline">
                <label class="i-checks">
                    <input type="radio" name="notify_type" value="today" <?php echo e($seRequest->notify_type == 'today' ? 'checked' : ''); ?> onchange="notify_radio('Today');"><i></i> Today 
                </label>
            </div>
            <div class="form-check form-check-inline">
                <label class="i-checks">
                    <input type="radio" name="notify_type" value="selected_date" <?php echo e($seRequest->notify_type == 'selected_date' ? 'checked' : ''); ?> onchange="notify_radio('DateTime');"><i></i> Select date & time 
                </label>
            </div>
        </div>
        <div class="notify_box collapse Today">
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group input_wrap">
                        <label class="control-label">Notify in</label>
                        <select class="selectpicker select-custom" name="today_in_time" id="selectNotify" data-size="4">
                            <option value="30" <?php echo e($seRequest->today_in_time == '30' ? 'selected' : ''); ?>>30 minutes</option>
                            <option value="1" <?php echo e($seRequest->today_in_time == '1' ? 'selected' : ''); ?>>01 hour </option>
                            <option value="2" <?php echo e($seRequest->today_in_time == '2' ? 'selected' : ''); ?>>02 hour </option>
                            <option value="3" <?php echo e($seRequest->today_in_time == '3' ? 'selected' : ''); ?>>03 hour </option>
                            <option value="4" <?php echo e($seRequest->today_in_time == '4' ? 'selected' : ''); ?>>04 hour </option>
                            <option value="5" <?php echo e($seRequest->today_in_time == '5' ? 'selected' : ''); ?>>05 hour </option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="notify_box collapse DateTime">
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group input_wrap">
                        <label class="control-label">Select date</label>
                        <div class="dateicon">
                            <input type="text" name="notify_date" id="SelectDate01" readonly="true" class="form-control datetimepicker-input" data-target="#SelectDate01" data-toggle="datetimepicker" placeholder="DD/MM/YYYY"/>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group input_wrap">
                        <label class="control-label">Select time</label>
                        <div class="timeicon">
                            <input type="text" name="notify_date_time" value="<?php echo e(date('h:i A',strtotime($seRequest->notify_date_time))); ?>" id="SelectTime01" readonly="true" class="form-control datetimepicker-input" data-target="#SelectTime01" data-toggle="datetimepicker" placeholder="HH/MM"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group input_wrap">
                    <label class="control-label">Select category</label>
                    <?php
                    $categories = \App\Http\Models\BankingCategory::getActiveCategories();
                    ?>
                    <select class="selectpicker select-custom" name="category_id" id="selectCategory" data-size="4">
                        <?php if(count($categories)>0): ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(($category->id == $seRequest->category_id) ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group input_wrap">
                    <label class="control-label">Select executive</label>
                    <?php
                    $executives = \App\Http\Models\User::getExecutivesLinkedById();
                    ?>
                    <select class="selectpicker select-custom" name="executive_id" id="selectExecutive" data-size="4">
                        <?php if(count($executives)>0): ?>
                        <?php $__currentLoopData = $executives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $executive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($executive->id); ?>" <?php echo e(($executive->id == Auth::guard()->user()->id) ? 'selected' : ''); ?>><?php echo e(ucfirst($executive->contact_name)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <div class="note border p-3 rounded">
        <label class="theme-color02">Note</label>
        <textarea class="form-control" name="notes" rows="10"><?php echo e($seRequest->notes); ?></textarea>
    </div>
    <!--    <div class="field_box collapse Resolved">
            <div class="note border p-3 rounded">
                <label class="theme-color02">Note</label>
                <textarea class="form-control" rows="10"><?php echo e($seRequest->notes); ?></textarea>
                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut venenatis mauris augue. Phasellus sed convallis nisi, vitae consectetur nibh. Aliquam facilisis ipsum et erat sollicitudin, non rhoncus ex luctus. Aenean pellentesque consectetur semper. Nulla vehicula eros eget convallis maximus. Nulla dapibus vulputate nisi, quis placerat elit. Proin tincidunt sem at eleifend hendrerit. Mauris a rutrum dolor. Duis mauris risus, vestibulum at lacinia sed, dictum nec dui.</p>
            </div>
        </div>-->
    <div class="text-center">
        <button id="btnSubmitForm" type="submit" class="btn btn-primary text-uppercase ripple-effect-dark font-bk">FINISH CALL
            <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                    
        </button> 
        <!--<button type="submit" class="btn btn-primary text-uppercase ripple-effect-dark font-bk" data-dismiss="modal">FINISH CALL</button>-->
    </div>
</form>
<script>
//       submit edit executive request form
    $(document).on('submit', '#EditSEquestForm', function (e) {
        e.preventDefault();
        if ($('#EditSEquestForm').valid()) {
            $('#btnSubmitForm').prop('disabled', true);
            $('#btnSubmitLoader').show();
            $.ajax({
                url: "<?php echo e(url('update-se-request')); ?>",
                data: $('#EditSEquestForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            location.reload();
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnSubmitForm').prop('disabled', false);
                    }
                    $('#btnSubmitLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#btnSubmitForm').prop('disabled', false);
                }
            });
        }
    });
</script>
<script>
    $(document).ready(function () {
        var checkValue = $("input[name='status']:checked").val();
        if (checkValue == 'resolved') {
            $('.field_box').hide();
        }
        var checkValue1 = $("input[name='notify_type']:checked").val();
        if (checkValue1 == 'today') {
            $('.Today').show();
        } else if (checkValue1 == 'selected_date') {
            $('.DateTime').show();
        }
    });

    function status_radio(value) {
        $(".field_box").hide();
        $("." + value).show();
    }
    function notify_radio(value) {
        $(".notify_box").hide();
        $("." + value).show();
    }

    $(function () {
        $('.select-custom').selectpicker();
        $('#SelectDate01').datetimepicker({
            focusOnShow: false,
            format: 'L',
            ignoreReadonly: true,
            defaultDate: "<?php echo e(showFullDateFormat($seRequest->notify_date)); ?>"
        }).on('dp.show', function (e) {
            $(e.target).on('mousedown', function (e) {
                $(e.target).data("DateTimePicker").hide();
                e.preventDefault();
            });
        }).on('dp.hide', function (e) {
            $(e.target).off('mousedown');
        });
    });
    $(function () {
        $('#SelectTime01').datetimepicker({
            ocusOnShow: false,
            format: 'LT',
            ignoreReadonly: true,
        }).on('dp.show', function (e) {
            $(e.target).on('mousedown', function (e) {
                $(e.target).data("DateTimePicker").hide();
                e.preventDefault();
            });
        }).on('dp.hide', function (e) {
            $(e.target).off('mousedown');
        });
    });
</script>