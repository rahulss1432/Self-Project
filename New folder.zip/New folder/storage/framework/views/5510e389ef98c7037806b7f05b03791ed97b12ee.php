<table class="table mb-0">
    <thead>
        <tr>
            <th>S.No.</th>
            <th>Date and Time</th>
            <th>Customer Name</th>
            <th>Email ID</th>
            <th>Amount Paid</th>
        </tr>
    </thead>
    <tbody>
        <?php if(!empty($paymentList->count()>0)): ?>
        <?php $i=1; ?>
        <?php $__currentLoopData = $paymentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        if(!empty($paymentList->pagination)){
        if ($paymentList->currentPage() == 1) {
        $srNo = $i++;
        } else {
        $srNo = ($paymentList->currentPage() - 1) * $paymentList->perPage() + $i++;
        }
        }else{
        $srNo = $i++;
        }
        ?>
        <tr>
            <td><?php echo e($srNo); ?></td>
            <td><?php echo e(\App\Helpers\Utility::getDateTimeFormat($payment->created_at)); ?></td>
            <td><?php echo e($payment->getUser->first_name); ?> <?php echo e($payment->getUser->last_name); ?></td>
            <td><?php echo e($payment->getUser->email); ?></td>
            <td><?php echo e(\App\Helpers\Utility::getPriceFormat($payment->amount)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td colspan="6"><?php \App\Helpers\Utility::emptyListMessage('transaction'); ?></td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>