<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url('public/images/favicon/apple-touch-icon.png')); ?>">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('public/images/favicon/favicon-32x32.png')); ?>">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('public/images/favicon/favicon-16x16.png')); ?>">
        <link rel="manifest" href="<?php echo e(url('public/images/favicon/site.webmanifest')); ?>">
        <link rel="mask-icon" href="<?php echo e(url('public/images/favicon/safari-pinned-tab.svg')); ?>" color="#5bbad5">
        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="theme-color" content="#ffffff">
        <!-- Bootstrap -->
        <?php echo $__env->make('admin::include.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body class="bg-light-gray" onload="hide_preloader();">
        <div id="preloader">
            <div class="inner">
                <div class="spinner">
                    <div class="rect1"></div>
                    <div class="rect2"></div>
                    <div class="rect3"></div>
                    <div class="rect4"></div>
                    <div class="rect5"></div>
                </div>
            </div>
        </div>
        <?php if(Auth::guard('admin')->check()): ?>
        <?php echo $__env->make('admin::include.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('admin::include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('admin::include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>