<?php if(count($notification) > 0): ?>
<?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="notification-box">
    <span class="custom-control-description">
        <p>Editorial Collections</p>
        <span><?php echo e($notify->message); ?></span>
    </span>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($notification->links()); ?>