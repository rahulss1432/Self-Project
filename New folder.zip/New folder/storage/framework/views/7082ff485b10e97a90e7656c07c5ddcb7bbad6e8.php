<?php if(!empty($blogInfo->id)): ?>
<?php $__env->startSection('title','Edit Blog'); ?>
<?php else: ?>
<?php $__env->startSection('title','Add Blog'); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
<div class="main-content adduser_page">
    <div class="content_wrapper">
        <div class="page_title">
            <h2 class="d-inline-block pr-3 mr-3 border-right"><?php echo e($blogInfo->id ? 'Edit Blog' : 'Add Blog'); ?></h2>
            <nav aria-label="breadcrumb" class="d-inline-block">
                <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="dashboard.php">Home</a>
                    </li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/manage-blogs')); ?>">Manage Blog</a>
                    </li>
                    <li class="breadcrumb-item"><?php echo e($blogInfo->id ? 'Edit Blog' : 'Add Blog'); ?></li>
                </ol>
            </nav>
        </div>
        <div class="add_details">
            <div class="card">
                <div class="card-header"><?php echo e($blogInfo->id ? 'Edit' : 'Add'); ?> Blog Details</div>
                <div class="card-body">
                    <form id="manage-blog" method="post" action="<?php echo e(url('/admin/save-blog')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="blog_id" value="<?php echo e($blogInfo->id); ?>">
                        <div class="field_content">
                            <div class="field_box">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label>Blog Title</label>
                                            <input type="text" name="blog_title" value="<?php echo e($blogInfo->blog_title); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <input type="hidden" name="oldImageName" id="oldImageName" value="<?php echo e($blogInfo->blog_image); ?>">
                                            <label class="d-block">Upload blog image</label>
                                            <label class="uploadIcon d-block w-100 h-100" for="uploadFile">
                                                <span class="form-control" id="imageName"><?php echo e($blogInfo->blog_image); ?></span>
                                                <input class="do-not-ignore" id="uploadFile" name="blog_image" type="file"  hidden>

                                            </label>
                                        </div>

                                        <ul class="list-inline preview-images" id="div-image">
                                            <li class="list-inline-item">
                                                <div class="preview-img">
                                                    <a href="javascript:void(0);" class="remove-it" onclick="removeImage();"><i class="flaticon-cancel-music"></i></a>
                                                    <img src="<?php echo e(\App\Helpers\Utility::checkBlogImage($blogInfo->blog_image,'blog-image')); ?>" alt="book" class="img-fluid" id="preview_image">
                                                </div>
                                            </li>
                                        </ul>
                                    </div>


                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <input type="hidden" name="oldBannerName" id="oldBannerName" value="<?php echo e($blogInfo->banner_image); ?>">
                                            <label class="d-block">Upload banner image</label>
                                            <label class="uploadIcon d-block w-100 h-100" for="uploadBanner">
                                                <span class="form-control" id="bannerName"><?php echo e($blogInfo->banner_image); ?></span>
                                                <input class="do-not-ignore" id="uploadBanner" name="banner_image" type="file"  hidden>
                                            </label>
                                        </div>

                                        <ul class="list-inline preview-images" id="div-banner">
                                            <li class="list-inline-item">
                                                <div class="preview-img">
                                                    <a href="javascript:void(0);" class="remove-it" onclick="removeBanner();"><i class="flaticon-cancel-music"></i></a>
                                                    <img src="<?php echo e(\App\Helpers\Utility::checkBlogImage($blogInfo->banner_image,'blog-banner')); ?>" alt="book" class="img-fluid" id="preview_banner">
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Add Meta Description</label>
                                    <textarea  class="form-control" name="meta_description" rows="4"><?php echo e($blogInfo->meta_description); ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label>Content</label>
                                    <textarea  class="form-control" name="content" rows="4"><?php echo e($blogInfo->content); ?></textarea>
                                </div>  

                                <div class="form-group  text-right mb-0">
                                    <button type="submit" id="submit-btn" class="btn btn-success rounded-0 ripple-effect">Save
                                        <i style="display:none;" class="btn_loader"></i>
                                    </button>

                                    <a href="<?php echo e(url('/admin/manage-blogs')); ?>" class="btn btn-dark rounded-0 ripple-effect ml-2">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                    <?php echo JsValidator::formRequest('App\Http\Requests\ManageBlogRequest','#manage-blog'); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $("#submit-btn").on('click', (function (e) {
        e.preventDefault();
        var btn = $('#submit-btn');
        var form = $('#manage-blog');
        if (form.valid()) {
            btn.html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?> Save');
            btn.prop('disabled', true);
            $.ajax({
                url: "<?php echo e((url('/admin/save-blog'))); ?>",
                type: "POST",
                data: new FormData($('#manage-blog')[0]),
                contentType: false,
                cache: false,
                processData: false,
                success: function (data) {
                    btn.prop('disabled', false);
                    window.location.href = "<?php echo e(url('/admin/manage-blogs')); ?>";
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        var errors = obj[x].length
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').css("color", '#b30000');
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));


    $('#uploadFile').change(function () {
        $('#div-image').show();
        var file = this.files[ 0 ];
        $("#imageName").html(file.name);
    });

    function readURL(input) {
        var fileTypes = ['jpg', 'jpeg', 'png'];  //acceptable file types
        if (input.files && input.files[0]) {
            var extension = input.files[0].name.split('.').pop().toLowerCase(), //file extension from input file
                    isSuccess = fileTypes.indexOf(extension) > -1;  //is extension in acceptable types
            if (isSuccess) { //yes
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#div-image').html('<li class="list-inline-item">\
                    <div class="preview-img">\
                        <a href="javascript:void(0);" class="remove-it" onclick="removeImage();"><i class="flaticon-cancel-music"></i></a>\
                        <img src="" alt="book" class="img-fluid" id="preview_image">\
                    </div>\
                </li>')
                    $('#preview_image').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    }
    $("#uploadFile").change(function () {
        readURL(this);
    });

    function removeImage() {
        $('#div-image li').remove();
        $('#imageName').html('');
        $('#uploadFile').val();
        $('#oldImageName').val('');
    }



    $('#uploadBanner').change(function () {
        $('#div-banner').show();
        var file = this.files[ 0 ];
        $("#bannerName").html(file.name);
    });

    function readBannerURL(input) {
        var fileTypes = ['jpg', 'jpeg', 'png'];  //acceptable file types
        if (input.files && input.files[0]) {
            var extension = input.files[0].name.split('.').pop().toLowerCase(), //file extension from input file
                    isSuccess = fileTypes.indexOf(extension) > -1;  //is extension in acceptable types
            if (isSuccess) { //yes
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#div-banner').html('<li class="list-inline-item">\
                    <div class="preview-img">\
                        <a href="javascript:void(0);" class="remove-it" onclick="removeBanner();"><i class="flaticon-cancel-music"></i></a>\
                        <img src="" alt="book" class="img-fluid" id="preview_banner">\
                    </div>\
                </li>')
                    $('#preview_banner').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    }
    $("#uploadBanner").change(function () {
        readBannerURL(this);
    });

    function removeBanner() {
        $('#div-banner li').remove();
        $('#bannerName').html('');
        $('#uploadBanner').val();
        $('#oldBannerName').val('');
    }

</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>