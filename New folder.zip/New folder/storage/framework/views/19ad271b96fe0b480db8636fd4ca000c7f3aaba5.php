<?php $__env->startSection('title', 'Manager Login'); ?>
<?php $__env->startSection('content'); ?>
<main class="login-page d-flex align-items-center justify-content-center">
    <div class="login-wrap mx-auto">
        <div class="login-header d-flex align-items-center justify-content-center">
            <h2 class="mb-0 text-uppercase text-center">linked assist<br><span>support manager</span></h2>
        </div>
        <div class="login-field">
            <form id="managerLoginForm" method="POST" action="<?php echo e(url('manager/login')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <i class="fas fa-user"></i>
                    <input type="text" name="username" value="<?php echo e(old('username')); ?>" class="form-control form-control-lg"/>
                    <label class="control-label">Username</label>
                </div>
                <div class="form-group">
                    <i class="fa fa-lock"></i>
                    <input type="password" name="password" value="<?php echo e(old('password')); ?>" class="form-control form-control-lg"/>
                    <label class="control-label">Password</label>
                    <?php if($errors->has('username')): ?>
                    <span class="help-block error-help-block"><b><?php echo e($errors->first('username')); ?></b></span>
                    <?php endif; ?>                    
                </div>                
                <div id="spanLoginError"></div>                
                <div class="form-group text-center pl-0 mb-0">
                    <button type="submit" id="btnLogin" class="btn btn-primary ripple-effect-dark">SUBMIT
                        <i id="loginFormLoader" class="fas fa-spin fa-spinner" style="display: none"></i>
                    </button>                
                </div>
            </form>
            <?php echo JsValidator::formRequest('App\Http\Requests\Manager\ManagerLoginRequest','#managerLoginForm'); ?>

        </div>
        <div class="login-footer">
            <a href="<?php echo e(url('/manager/forgot-password')); ?>" class="ripple-effect-dark">FORGOT PASSWORD <i class="fas fa-long-arrow-alt-right"></i></a>
        </div>
    </div>
</main>

<?php echo $__env->make('manager.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(document).on('submit', '#managerLoginForm', function (e) {
        $('#spanLoginError').text('');
        e.preventDefault();
        if ($('#managerLoginForm').valid()) {
            $('#btnLogin').prop('disabled', true);
            $('#loginFormLoader').show();
            $.ajax({
                url: "<?php echo e(url('manager/login')); ?>",
                data: $('#managerLoginForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = response.redirectUrl;
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnLogin').prop('disabled', false);
                        $('#loginFormLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#loginFormLoader').hide();
                        $('#btnLogin').prop('disabled', false);
                        $('#spanLoginError').html('<span class="help-block error-help-block">' + obj[x] + '</span>');
                    }
                }
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('manager.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>