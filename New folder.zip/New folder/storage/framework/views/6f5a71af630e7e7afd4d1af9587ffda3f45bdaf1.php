<?php $__env->startSection('title', 'Edit Merchant'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray"  onload="hide_preloader();">
    <?php echo $__env->make('admin.layouts.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="main-content cms-edit" id="mainContent">
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="page-content" id="pageContent" >
            <div class="card custom_card" id="card_height">
                <div class="card-header">
                    <h4 class="page-title float-left">Edit Merchant</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item">
                            <a id="back-loader" onclick="backloader()" href="<?php echo e(url('admin/merchant')); ?>" class="nav-link" title="Back">
                                <i class="fa fa-long-arrow-left"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <form id="EditMerchantForm" autocomplete="off" class="f-field" method="POST" action="<?php echo e(url('admin/merchant-update')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="user_id" value="<?php echo e($editMerchant->id); ?>">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">First Name</label>
                                    <input type="text" name="first_name" value="<?php echo e($editMerchant->first_name); ?>" class="form-control form-control-lg">
                                </div>
                            </div> 
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Last Name</label>
                                    <input type="text" name="last_name" value="<?php echo e($editMerchant->last_name); ?>" class="form-control form-control-lg">
                                </div>
                            </div> 
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Email</label>
                                    <input type="text" name="email" value="<?php echo e($editMerchant->email); ?>" class="form-control form-control-lg">
                                </div>
                            </div> 
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Phone</label>
                                    <input type="text" name="mobile" value="<?php echo e($editMerchant->phone_number); ?>" class="form-control form-control-lg phoneNumber" maxlength="10">
                                </div>
                            </div> 
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Upload Image</label>
                                    <div class="file-upload">
                                        <div class="file-select">
                                            <div class="file-select-button" id="fileName">Choose File</div>
                                            <div class="file-select-name" id="spanFileName"><?php echo e(!empty($editMerchant->profile_image) ? $editMerchant->profile_image : 'No file chosen...'); ?></div> 
                                            <input type="file" name="image_file" id="imageUpload" onchange="uploadFile(this)">
                                            <input type="hidden" name="hiddenFileName" value="<?php echo e($editMerchant->profile_image); ?>" class="do-not-ignore" name="hiddenFileName" id="hiddenMediaFileName">                                                                                        
                                        </div>
                                    </div>  
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Merchant Number</label>
                                    <input type="text" name="merchant_number" value="<?php echo e($editMerchant->userDetail->merchant_number); ?>" class="form-control form-control-lg">
                                </div>
                            </div> 
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Product</label>
                                    <input type="text" name="product" value="<?php echo e($editMerchant->userDetail->product); ?>" class="form-control form-control-lg">
                                </div>
                            </div>                             
                            <div class="col-sm-6">
                                <?php
                                $banks = \App\Http\Models\Bank::getBankList();
                                ?>
                                <div class="form-group">
                                    <label class="control-label">Select Company</label>
                                    <select id="tags" name="bank" class="form-control selectpicker" onchange="$(this).valid();">
                                        <option value="">Select Bank</option>                                        
                                        <?php if(count($banks)>0): ?>
                                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bank->id); ?>" <?php echo e($editMerchant->bank_id == $bank->id ? 'selected' : ''); ?>><?php echo e($bank->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Bussiness Name</label>
                                    <input type="text" name="bussiness_name" value="<?php echo e($editMerchant->userDetail->bussiness_name); ?>" class="form-control form-control-lg">
                                </div>
                            </div>                                                         
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Bussiness Address</label>
                                    <input type="text" name="bussiness_address" value="<?php echo e($editMerchant->userDetail->bussiness_address); ?>" class="form-control form-control-lg">
                                </div>
                            </div> 

                            <div class="col-sm-6">
                                <?php
                                $executives = \App\Http\Models\User::getAllExecutivesByAdmin();
                                $linkedExecutives = \App\Http\Models\CustomerExecutiveRelation::getExecutiveByCustomerId($editMerchant->id);
                                $data = array();                                                                 
                                foreach($linkedExecutives as $linkedExecutive){
                                $data[] = $linkedExecutive->executive_id;
                                }
                                ?>
                                <div class="form-group">
                                    <label class="control-label">Select Executive</label>
                                    <select id="selectExecutive" name="executive[]" multiple class="form-control selectpicker">
                                        <!--<option value="">Select Executive</option>-->                                        
                                        <?php if(count($executives)>0): ?>
                                        <?php $__currentLoopData = $executives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $executive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($executive->id); ?>" <?php echo e(in_array($executive->id,$data) ? 'selected' : ''); ?>><?php echo e(getFullName($executive->first_name ,$executive->last_name )); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>                                                                                

                        </div>
                        <div class="from-group">
                            <button id="btnSubmitForm" type="submit" class="btn btn-primary btn_radius">Save
                                <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                    
                            </button>
                        </div>
                    </form>
                    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\EditMerchantRequest','#EditMerchantForm'); ?>

                </div>
            </div>
        </div>
    </main>

    <!-- cropper-Modal -->
    <div class="modal fade" id="cropper-image-modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <!--<h4 class="modal-title"></h4>-->
                </div>
                <div id="image-cropper-form">
                </div>                            
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).on('submit', '#EditMerchantForm', function (e) {
            e.preventDefault();
            if ($('#EditMerchantForm').valid()) {
                $('#btnSubmitForm').prop('disabled', true);
                $('#btnSubmitLoader').show();
                var formData = new FormData($('#EditMerchantForm')[0]);
                $.ajax({
                    url: "<?php echo e(url('admin/merchant-update')); ?>",
                    data: formData,
                    type: 'POST',
                    dataType: 'JSON',
                    processData: false,
                    contentType: false,
                    success: function (response) {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            setTimeout(function () {
                                window.location = "<?php echo e(url('admin/merchant')); ?>";
                            }, 1500);
                        } else {
                            toastrAlertMessage('error', response.message);
                            $('#btnSubmitForm').prop('disabled', false);
                        }
                        $('#btnSubmitLoader').hide();
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                        $('#btnSubmitForm').prop('disabled', false);
                    }
                });
            }
        });

        /* image uploading with cropper*/
        function uploadFile(thisEl) {
            if (thisEl.files[0]) {
                var inputFile = thisEl.files[0].name;
                var extension = inputFile.substr(inputFile.lastIndexOf('.') + 1);
                if (extension != 'jpg' && extension != 'jpeg' && extension != 'png') {
                    toastrAlertMessage('error', 'Image allows only in jpeg, png or jpg format');
                    $('#imageUpload').val('');
                    $('#hiddenMediaFileName').val('');
                    return false;
                }
                var formData = new FormData($('#EditMerchantForm')[0]);
                formData.append('_token', '<?php echo e(csrf_token()); ?>');
                $.ajax({
                    url: "<?php echo e(url('admin/upload-media-image')); ?>",
                    type: 'POST',
                    data: formData,
                    processData: false,
                    cache: false,
                    contentType: false,
                    success: function (response) {
                        loadImageCropperModal(response.filename);
                        $('#cropper-image-modal').modal('show');
                    }
                });
            }
        }

        function loadImageCropperModal(imageName) {
            $.ajax({
                url: "<?php echo e(url('admin/load-image-cropper')); ?>",
                type: 'GET',
                data: {imageName: imageName, type: 'profile_image'},
                success: function (response) {
                    $('#image-cropper-form').html(response.html);
                }
            });
        }

        function backloader()
        {
            $("#back-loader").attr("disabled", true);
            $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
        }
        ;
        window.addEventListener('beforeunload', function (event)
        {
            $("#save-loader").attr("disabled", true);
            $("#save-loader").html('SAVE <i class="fa fa-spinner fa-spin"></i>');
        });

    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>