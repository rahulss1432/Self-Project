<?php $__env->startSection('title','Personal Detail'); ?>
<?php $__env->startSection('content'); ?>
<main class="dashboard-main-wrap step-form jobseeker-steps" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <!-- breadcrumb start-->
            <nav aria-label="breadcrumb" class="text-right">
                <ol class="breadcrumb d-inline-flex">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Personal Detail</li>
                </ol>
            </nav>
            <!-- breadcrumb end-->
            <div class="content-body">
                <!-- <h2 class="page-title mt-0">Update Profile</h2> -->
                <div class="form-wrap">
                    <?php echo $__env->make('user.profile.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!-- xxxxxxxxxxx -->
                    <section class="step-form-body">
                        <div class="form01 common-form" id="form01">
                            <div class="inner-body">
                                <form  id="editProfileForm" method="POST" action="javascript:void(0);">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="profile-wrap text-center">
                                        <div class="add-profile rounded-circle">
                                            <div class="img-holder rounded-circle">
                                                <img src="<?php echo e(\App\Helpers\Utility::checkProfileImage(Auth::user()->profile_image)); ?>" alt="default-user" class="img-fluid profileImage">
                                            </div>
                                            <label class="upload-btn rounded-circle mb-0">
                                                <input type="file"  onchange="setImage(this)" id="cropImageInput" class="d-none">
                                                <i class="fa fa-camera" aria-hidden="true"></i>
                                            </label>
                                        </div>
                                        <div class="details">
                                            <p class="color-gray font-md mb-2">Upload profile picture</p>
                                            <p class="color-green"><?php echo e($userDetails->email); ?></p>
                                        </div>
                                    </div>

                                    <!-- xxxxxxxxx -->

                                    <div class="row">
                                        <!-- field-heading -->
                                        <div class="col-12">
                                            <label class="field-heading font-md d-block w-100">Personal Info<span class="text-danger">*</span></label>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="first_name" placeholder="First Name" value="<?php echo e($userDetails->first_name); ?>">
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="last_name" placeholder="Last Name" value="<?php echo e($userDetails->last_name); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="mobile_number" maxlength="13" placeholder="Mobile Number" value="<?php echo e($userDetails->mobile_number); ?>">
                                            </div>
                                        </div>

                                        <!-- field-heading -->
                                        <div class="col-12">
                                            <label class="field-heading font-md d-block w-100">Date of Birth</label>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" readonly="true" class="form-control date" data-toggle="datetimepicker"  data-target="#date_of_birth" id="date_of_birth" placeholder="Date of Birth" name="dob" value="<?php echo e((strtotime($userDetails->dob)>0)?date("d-m-Y",strtotime($userDetails->dob)):''); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <textarea  rows="4" class="form-control" name="profile_summary" placeholder="Write profile summary"><?php echo e($userDetails->profile_summary); ?></textarea>
                                            </div>
                                        </div>
                                        <?php if(Auth::user()->user_type=='employer'): ?>
                                        <div class="col-12">
                                            <label class="field-heading font-md d-block w-100">Set Your Hourly Rate</label>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <input type="text" name="hourly_rate" maxlength="3" placeholder="Enter Amount in USD" class="form-control">
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <div class="col-12">
                                            <label class="field-heading font-md d-block w-100">Address<span class="text-danger">*</span></label>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input id="address" type="text" class="form-control" name="address" placeholder="Address" value="<?php echo e($userDetails->address); ?>" autocomplete="off">
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <select id="user-country" name="country" class="form-control selectpicker select02" title="Country" data-live-search="true"> 
                                                    <?php 
                                                    $country = \App\Models\Country::getCountriesDropdown($userDetails->country); 
                                                    echo $country;
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="user-administrative_area_level_1" name="state" placeholder="State" value="<?php echo e($userDetails->state); ?>">
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="user-locality" name="city" placeholder="City" value="<?php echo e($userDetails->city); ?>">
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="user-postal_code"  maxlength="7" name="zipcode" placeholder="Zip" value="<?php echo e(($userDetails->zipcode!=0)?$userDetails->zipcode:''); ?>">
                                            </div>
                                        </div>

                                        <!-- field-heading -->
                                        <div class="col-12">
                                            <label class="field-heading font-md d-block w-100">Conferencing Platform</label>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="skype_id" placeholder="Skype Id" value="<?php echo e($userDetails->skype_id); ?>">
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="join_me" placeholder="Join Me" value="<?php echo e($userDetails->join_me); ?>">
                                            </div>
                                        </div>

                                        <!-- field-heading -->
                                        <div class="col-12">
                                            <label class="field-heading font-md d-block w-100">Social Media Account Links </label>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="facebook_url" placeholder="Facebook" value="<?php echo e($userDetails->facebook_url); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="linkedin_url" placeholder="Linkedin" value="<?php echo e($userDetails->linkedin_url); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="twitter_url" placeholder="Twitter" value="<?php echo e($userDetails->twitter_url); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="youtube_url" placeholder="Youtube" value="<?php echo e($userDetails->youtube_url); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-12 mt-2 btn-row">
                                            <button type="submit" class="text-uppercase btn btn-success" id="updateProfileBtn"> 
                                                <i id="addLoader" class="fa fa-spinner fa-spin" style="display: none;"></i> save <span class="and-font">&</span> continue
                                            </button>
                                        </div>
                                    </div><!-- row end -->
                                </form>
                                <?php echo JsValidator::formRequest('App\Http\Requests\EditProfileRequest','#editProfileForm'); ?>

                            </div>
                        </div>
                        <!-- xxxxxxxxxxx -->
                    </section>
                </div>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="imageCropperModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="imageCropperModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addindustyModal">Profile Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="image_container">
                    <img alt="image" src="" id="crop_image" class="img-responsive" height="auto" width="100%"/>
                </div>
                <input type="hidden" id="imageBaseCode">
                <input type="hidden" id="imageType" value="profile_image">
                <div class="clearfix"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn ripple-effect-dark btn-success btn-sm text-uppercase" id="cropbutton">Save</button>
                <button type="button" class="btn ripple-effect-dark btn-warning btn-sm text-uppercase" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>
<!-- category model end -->
<link href="<?php echo e(url('public/css/cropper.min.css')); ?>" rel="stylesheet">
<script src="<?php echo e(url('public/js/cropper.min.js')); ?>"></script>
<script>
    $(function () {
        $('#date_of_birth').datetimepicker({
            format: '<?php echo e(\App\Helpers\Utility::getDatePickerForamt()); ?>',
            maxDate: moment(),
            ignoreReadonly: true,
            useCurrent: false
        });
    });
    
    function setImage(input) {
        $('#crop_image').attr('src', '');
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $("#imageCropperModal").modal("show");
                $('#crop_image').attr('src', e.target.result);
                $('#imageBaseCode').val(e.target.result);
                setTimeout(function () {
                    loadCropper();
                }, 150);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    $('#imageCropperModal').on('hidden.bs.modal', function (e) {
        var $image = $("#crop_image");
        var input = $("#cropImageInput");
        input.replaceWith(input.val('').clone(true));
        $image.cropper("destroy");
    })
//cropper
    function loadCropper() {
        var $image = $("#crop_image");
        $image.cropper({
            viewMode: 1,
            dragMode: 'move',
            aspectRatio: 1,
            movable: false,
            zoomable: true,
            rotatable: true,
            center: true,
            responsive: true,
            cropBoxResizable: true,
        });
    }
    $("#cropbutton").click(function () {
        var $image = $("#crop_image");
        $("#cropbutton").html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?> Submit');
        $("#cropbutton").attr('disabled', true);
        var imageBaseCode = $('#imageBaseCode').val();
        var imageType = $("#imageType").val();
        var imageCropedData = $image.cropper('getData');
        var croppedWidth = imageCropedData.width;
        var croppedHeight = imageCropedData.height;
        var croppedX = imageCropedData.x;
        var croppedY = imageCropedData.y;
        var rotate = imageCropedData.rotate;
        var url = "<?php echo e(url('/user/save-profile-image')); ?>";
        $.ajax({
            type: "POST",
            url: url,
            dataType: 'JSON',
            data: {
                imageBaseCode: imageBaseCode,
                imageType: imageType,
                croppedWidth: croppedWidth,
                croppedHeight: croppedHeight,
                croppedX: croppedX,
                croppedY: croppedY,
                rotate: rotate,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function (response) {
                if (response.success) {
                    $("#imageCropperModal").modal("hide");
                    $image.cropper('destroy');
                    $("#cropbutton").attr('disabled', false);
                    $("#cropbutton").html('Save');
                    $('.profileImage').attr('src', response.filename);
                }
            }
        });
    });
    
    $('#imageCropperModal').on('hidden.bs.modal', function (e) {
        $('#crop_image').attr('src', '');
        var $image = $("#crop_image");
        var input = $("#cropImageInput");
        input.replaceWith(input.val('').clone(true));
        $image.cropper("destroy");
    });
    
    $("#updateProfileBtn").on('click', (function(e) {
        e.preventDefault();
        var btn = $('#updateProfileBtn');
        var form = $('#editProfileForm');
        if (form.valid()) {
            btn.html('<?php echo e(\App\Helpers\Utility::buttonLoader()); ?> Submit');
            btn.prop('disabled', true);
            $.ajax({
                url: "<?php echo e(url('/user/update-profile')); ?>",
                type: "POST",
                data: new FormData($('#editProfileForm')[0]),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data)
                {
                    btn.prop('disabled', false);
                    location.reload();
                },
                error: function (data) {
                    var obj = jQuery.parseJSON(data.responseText);
                    obj = obj['errors'];
                    for (var x in obj) {
                        btn.prop('disabled', false);
                        btn.html('Submit');
                        $('#' + x + '-error').html(obj[x]);
                        $('#' + x + '-error').parent('.form-group').removeClass('has-success').addClass('has-error');
                    }
                },
            });
        }
    }));
</script>
<?php echo $__env->make('layouts.address-autocomplete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>