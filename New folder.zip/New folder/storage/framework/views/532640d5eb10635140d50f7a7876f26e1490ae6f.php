<?php $__env->startSection('title','Support Executive'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Support Executive Request View</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="<?php echo e(url('admin/support-executive-request')); ?>" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="table-responsive" id="getrequestlist">
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function () {
        getrequestlist();
    });
    function getrequestlist() {
        pageDivLoader('show', 'getrequestlist');
        var url = '<?php echo e(url("admin/support-executive-view-list")); ?>';
        $.ajax({type: "GET", url: url, data: {id: '<?php echo e($id); ?>'},
            success: function (response) {
                $("#getrequestlist").html(response.html);
                $("#data_table").DataTable({
                    searching: false,
                    "columnDefs": [{
                            "targets": 'no-sort',
                            "orderable": false,
                        }]
                });
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>