<?php if(count($payment) >0): ?>
  <table class="table admin-table" id="data_table">
    <thead>
      <tr>
        <th>Name</th>
        <th>user type</th>
        <th>Email</th>
        <th>Subscription plan</th>
        <th>Billing Date</th>
        <th>amount paid</th>
        <th>Payment Status</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e('payment'.$data->id); ?>">
          <td class="text-capitalize">
            <span style="display:none"><?php echo e($data->trans_id); ?></span><?php echo e(ucfirst($data->first_name)); ?> <?php echo e(ucfirst($data->last_name)); ?>

          </td>
          <td class="text-capitalize"><?php echo e($data->user_type); ?></td>
          <td><?php echo e($data->email); ?></td>
          <td class="text-capitalize"><?php echo e($data->name); ?></td>
          <td><?php echo e($data->date); ?></td>
          <td>$ <?php echo e($data->price); ?></td>
          <td class="text-capitalize"><span class="color-green">Success</span></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php else: ?>
    <div class="alert alert-danger"><center>No payment available.</center></div>
<?php endif; ?>