<?php $__env->startSection('title', 'Edit Category'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Edit Category</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="<?php echo e(url('admin/categories')); ?>" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <form id="editCategoryForm" onsubmit="return !!(checkDesc());" autocomplete="off" class="f-field" method="POST" action="<?php echo e(url('admin/category-update')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="categoryId" value="<?php echo e($editCategory->id); ?>">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name" class="form-control form-control-lg" value="<?php echo e($editCategory->name); ?>">
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <textarea class="form-control" name="description" id="description" rows="2"><?php echo $editCategory->description; ?></textarea>
                                <span id="description-error" style="font-size: 12px;" class="help-block"></span>
                            </div>
                        </div>
                    </div>
                    <div class="from-group">
                        <button id="btnEditCategory" type="submit" class="btn btn-primary btn_radius submitButton">
                            <i id="editCategoryFormLoader" class="fa fa-spin fa-spinner" style="display: none;"></i> Update
                        </button>
                    </div>
                </form>
                <?php echo JsValidator::formRequest('App\Http\Requests\Admin\AddCategoryRequest','#editCategoryForm'); ?>

            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    $(document).on('submit', '#editCategoryForm', function (e) {
        if ($('#description').val() == '') {
            $('#description-error').show();
            $('#description-error').html('The description field is required');
            $("#description-error").css('color', 'red');
            return false;
        } else {
            $('#description-error').hide();
        }
//            e.preventDefault();
        if ($('#editCategoryForm').valid()) {
            $('#btnEditCategory').prop('disabled', true);
            $('#editCategoryFormLoader').show();
            $.ajax({
                url: "<?php echo e(url('admin/category-update')); ?>",
                data: $('#editCategoryForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "<?php echo e(url('/admin/categories')); ?>";
                        }, 1000);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnEditCategory').prop('disabled', false);
                    }
                    $('#editCategoryFormLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#editCategoryFormLoader').hide();
                        $('#btnEditDocument').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });

    $(document).ready(function ()
    {
        tinymce.init({
            theme: "modern",
            selector: "textarea",
            relative_urls: false,
            remove_script_host: false,
            convert_urls: true,
//                plugins: 'image code',
            height: 300,
//                toolbar: 'undo redo | image code',
//                images_upload_url: '<?php echo e(url("admin/admin-image-upload")); ?>',
            images_upload_handler: function (blobInfo, success, failure) {
                var xhr, formData;
                xhr = new XMLHttpRequest();
                xhr.withCredentials = false;
//                    xhr.open('POST', '<?php echo e(url("admin/admin-image-upload")); ?>');
                xhr.setRequestHeader('X-CSRF-TOKEN', '<?php echo e(csrf_token()); ?>');
                xhr.onload = function () {
                    var json;
                    if (xhr.status != 200)
                    {
                        failure('HTTP Error: ' + xhr.status);
                        return;
                    }
                    json = JSON.parse(xhr.responseText);
                    if (!json || typeof json.location != 'string')
                    {
                        failure('Invalid JSON: ' + xhr.responseText);
                        return;
                    }
                    success(json.location);
                };
                formData = new FormData();
                formData.append('file', blobInfo.blob(), blobInfo.filename());
                xhr.send(formData);
            },
            init_instance_callback: function (editor)
            {
                editor.on('keyup', function (e)
                {
                    var message = tinymce.get('description').getContent();
                    if (message === '')
                    {
                        $("#description-error").html('The description field is required');
                        $("#description-error").css('color', 'red');
                    }
                    else
                    {
                        $("#description-error").html('');
                    }
                });
            }
        });
    });

    function checkDesc()
    {
        if ($('#description').val() == '') {
            $('#description-error').show();
            $('#description-error').html('The description field is required');
            $("#description-error").css('color', 'red');
            return false;
        } else {
            $('#description-error').hide();
        }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>