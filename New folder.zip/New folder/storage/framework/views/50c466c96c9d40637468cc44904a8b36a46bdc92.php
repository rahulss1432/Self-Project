<?php $__env->startSection('title', 'Edit Profile'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray">
    <?php echo $__env->make('admin.layouts.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="main-content common-grid-list" id="mainContent">
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="page-content" id="pageContent">
            <div class="card custom_card" id="card_height">
                <div class="card-header">
                    <h4 class="page-title float-left">Edit Profile</h4>
                </div>
                <div class="card-body">
                    <form class="f-field" id="editProfileForm" action="<?php echo e(url('admin/update-profile')); ?>" method="post" autocomplete="off">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e(Auth()->guard('admin')->user()->id); ?>">
                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label class="control-label">Enter Email</label>
                                        <input type="email" name="email" value="<?php echo e(Auth()->guard('admin')->user()->email); ?>" class="form-control form-control-lg ">
                                    </div>    
                                </div>
                                <div class="col-sm-12">
                                    <button type="submit" id="btnEditProfile" class="btn btn-primary btn_radius m-t-10">Save Changes
                                        <i id="btnEditProfileLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                    
                                    </button>
                                </div>
                            </div>
                        </div> 
                    </form>
                    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\EditProfileRequest','#editProfileForm'); ?>

                </div>
            </div>
        </div>
    </main>

    <script>
        $(document).on('submit', '#editProfileForm', function (e) {
            e.preventDefault();
            if ($('#editProfileForm').valid()) {
                $('#btnEditProfile').prop('disabled', true);
                $('#btnEditProfileLoader').show();
                $.ajax({
                    url: "<?php echo e(url('admin/update-profile')); ?>",
                    data: $('#editProfileForm').serialize(),
                    type: 'POST',
                    dataType: 'JSON',
                    success: function (response) {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            setTimeout(function () {
                                window.location = "<?php echo e(url('/admin')); ?>";
                            }, 1500);
                        } else {
                            toastrAlertMessage('error', response.message);
                            $('#btnEditProfile').prop('disabled', false);
                        }
                        $('#btnEditProfileLoader').hide();
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            $('#btnEditProfileLoader').hide();
                            $('#btnEditProfile').prop('disabled', false);
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            }
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>