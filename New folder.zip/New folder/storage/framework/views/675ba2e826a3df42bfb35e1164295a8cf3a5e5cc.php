<tr>
    <td width="100" align="right">
        <div class="user_img">
            <img src="user01.jpg" alt="user" class="rounded-circle">
            <span class="status online"></span>
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Micah Chan</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>1 hour ago
        </div>
    </td>
    <td width="230">Online</td>
    <td width="150"><a href="linked-note.php" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
</tr>
<tr>
    <td width="100" align="right">
        <div class="user_img">
            <img src="user02.jpg" alt="user" class="rounded-circle">
            <span class="status online"></span>
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Kendall Campos</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>1 hour ago
        </div>
    </td>
    <td width="230">Online</td>
    <td width="150"><a href="linked-note.php" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
</tr>
<tr>
    <td width="100" align="right">
        <div class="user_img">
            <img src="user03.jpg" alt="user" class="rounded-circle">
            <span class="status offline"></span>
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Clementine Fischer</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>1 hour ago
        </div>
    </td>
    <td width="230">Last seen: 30 minutes ago</td>
    <td width="150"><a href="linked-note.php" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
</tr>
<tr>
    <td width="100" align="right">
        <div class="user_img">
            <img src="user04.jpg" alt="user" class="rounded-circle">
            <span class="status offline"></span>
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Elmo Pratt</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>1 hour ago
        </div>
    </td>
    <td width="230">Last seen: 5 hours ago</td>
    <td width="150"><a href="linked-note.php" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
</tr>
<tr>
    <td width="100" align="right">
        <div class="user_img">
            <img src="user05.jpg" alt="user" class="rounded-circle">
            <span class="status offline"></span>
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Marny Sampson</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>1 hour ago
        </div>
    </td>
    <td width="230">Last seen: 5 hours ago</td>
    <td width="150"><a href="linked-note.php" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
</tr>
<tr>
    <td width="100" align="right">
        <div class="user_img">
            <img src="user06.jpg" alt="user" class="rounded-circle">
            <span class="status offline"></span>
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Dalton Hoover</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>1 hour ago
        </div>
    </td>
    <td width="230">Last seen: 5 hours ago</td>
    <td width="150"><a href="linked-note.php" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
</tr>
<tr>
    <td width="100" align="right">
        <div class="user_img">
            <img src="user07.jpg" alt="user" class="rounded-circle">
            <span class="status offline"></span>
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Steven Bray</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>1 hour ago
        </div>
    </td>
    <td width="230">Last seen: 8 hours ago</td>
    <td width="150"><a href="linked-note.php" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
</tr>
<tr>
    <td width="100" align="right">
        <div class="user_img">
            <img src="user08.jpg" alt="user" class="rounded-circle">
            <span class="status offline"></span>
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Genevieve Stark</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>1 hour ago
        </div>
    </td>
    <td width="230">Last seen: 12 Oct 2018</td>
    <td width="150"><a href="linked-note.php" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
</tr>

<script>
    //ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });
</script>