<?php if(count($payments) > 0): ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Booking ID</th>
            <th>Transaction ID</th>
            <th>Mentor Name</th>
            <th>User Name</th>
            <th>Job Date and Time</th>
            <th>Total Amount</th>
            <th>Commission</th>
            <th>Job Status </th>
            <th>Payment Method </th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>#<?php echo e($payment->booking_id); ?></td>
            <td>#<?php echo e($payment->transaction_id); ?></td>
            <td><?php echo e($payment->transactionMentor->first_name.' '.$payment->transactionMentor->last_name); ?></td>
            <td><?php echo e($payment->transactionUser->first_name.' '.$payment->transactionUser->last_name); ?></td>
            <td><?php echo e(timeFormat($payment->created_at)); ?></td>
            <td>$ <?php echo e($payment->total_amount); ?></td>
            <td>$ <?php echo e($payment->commission); ?></td>
            <td><?php echo e(ucfirst($payment->status)); ?></td>
            <td><?php echo e(ucfirst($payment->payment_method)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($payments->links()); ?>

<script>
    $(".pagination li a").on('click', function (e) {
        pageDivLoader('show', 'getPaymentList');
        e.preventDefault();
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '<?php echo e(csrf_token()); ?>'},
            success: function (response) {
                $('.pagination:first').remove();
                $('#getPaymentList').html(response.html);
            }
        });
    });
</script>