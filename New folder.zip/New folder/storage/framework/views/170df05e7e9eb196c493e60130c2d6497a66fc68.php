<?php if(count($ratings) >0): ?>
  <table class="table admin-table" id="data_table">
    <thead>
      <tr>
        <th>Citizen Name</th>
        <th>Date/Time of incident</th>
        <th>Officer Name</th>
        <th>Officer’s Badge Number</th>
        <th>Ticket number</th>
        <th>Star Rating</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td class="text-capitalize">
            <span style="display:none"><?php echo e($data->id); ?></span><?php echo e(ucfirst($data->first_name)); ?> <?php echo e(ucfirst($data->last_name)); ?>

          </td>
          <td><?php echo e(date('d-m-Y h:i A',strtotime($data->created_at))); ?></td>
          <td><?php echo e(ucfirst($data->name)); ?></td>
          <td><?php echo e($data->badge_number); ?></td> 
          <td><?php echo e($data->warning_number); ?></td>   
          <td><span id="ratting_<?php echo e($data->id); ?>"></span></td>
          <script>
            $.fn.raty.defaults.path = '<?php echo url('public/images/raty') ?>';
            $("#ratting_<?php echo e($data->id); ?>").raty({
                                                half: false,
                                                halfShow:false,
                                                targetType: 'score',
                                                readOnly: true,
                                                score: '<?php echo e($data->rating); ?>'
                                              });  
          </script>
          <td>
            <ul class="list-inline mb-0 ">
              <li class="list-inline-item">
                <a id="view-loader<?php echo e($data->id); ?>" onclick="viewfunction(<?php echo e($data->id); ?>)" href="<?php echo e(url('admin/ratings-and-reviews-view',$data->id)); ?>"><i class="fa fa-eye"></i></a>
              </li> 
            </ul>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php else: ?>
    <div class="alert alert-danger"><center>No rating and review available.</center></div>
<?php endif; ?>