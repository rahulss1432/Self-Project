<?php $__env->startSection('title','Merchant Request View'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">merchant request view</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onClick="Editmodal();" class="nav-link">
                            <i class="fas fa-pencil-alt"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="<?php echo e(url('manager/merchant-request')); ?>" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="profile-img">
                            <img src="micah.jpg" alt="user-img" class="rounded-circle img-fluid">
                        </div>
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                <label>Name </label>
                                <span>Micah Chan</span>
                            </li>
                            <li>
                                <label>Merchant Processor</label>
                                <span>Callisto</span>
                            </li>
                            <li>
                                <label>Request generate date</label>
                                <span>23 Aug 2018</span>
                            </li>
                            <li>
                                <label>Request Status</label>
                                <span class="status pending">Pending</span>
                            </li>
                            <li>
                                <label>SE Assigned </label>
                                <span>Kendall Campos</span>
                            </li>
                            <li>
                                <label>Recorded Video</label>
                                <span><a href="javascript:void(0);" onClick="playVideo();">Play Video</a></span>
                            </li>
                            <li>
                                <label>Rating</label>
                                <span class="rating">
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                </span>
                            </li>
                            <li>
                                <label>Request Category</label>
                                <span>Technical Support</span>
                            </li>
                            <li>
                                <label>Total time of Call</label>
                                <span><i class="far fa-clock"></i> 15 mins</span>
                            </li>
                            <li>
                                <label class="notes_label">Notes</label>
                                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar sic tempor. Sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus pronin sapien nunc accuan eget.</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<div class="modal fade common-modal edit-modal" id="EditNote" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="EditmodalModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content history-modal">
            <div class="modal-header align-items-center">
                <div class="col text-left p-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="col p-0 text-center">
                    <h5 class="modal-title" id="EditmodalModalLabel">Edit</h5>
                </div>
                <div class="col p-0 text-right">

                </div>
            </div>
            <div class="modal-body">
                <div class="edit-form">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <select class="selectpicker form-control" title="Request Status">
                                    <option>Resolved</option>
                                    <option>Pending</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <select class="selectpicker form-control" title="Request Status">
                                    <option value="">Technical Support</option>
                                    <option value="">Product Upgrade</option>
                                    <option value="">Account Changes</option>
                                    <option value="">Request Supplies</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <textarea rows="3" class="form-control"></textarea>
                                <label class="control-label">Notes</label>
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="button" class="btn btn-primary mb-3 text-uppercase ripple-effect-dark font-bk" data-dismiss="modal">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade common-modal vdo-modal" id="playVideo" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="playVideoModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content history-modal">
            <div class="modal-header align-items-center">
                <div class="col text-left p-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="col p-0 text-center">
                    <h5 class="modal-title" id="playVideoModalLabel">Recorded Video</h5>
                </div>
                <div class="col p-0 text-right">

                </div>
            </div>
            <div class="modal-body">
                <video width="100%" controls>
                    <source src="videos/SampleVideo.mp4" type="video/mp4">
                    Your browser does not support HTML5 video.
                </video>
            </div>
        </div>
    </div>
</div>
<script>
    function Editmodal() {
        $("#EditNote").modal('show');
    }

    function playVideo() {
        $("#playVideo").modal('show');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('manager.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>