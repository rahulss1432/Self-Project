<?php if(count($notification)>0): ?>
<ul class="list-unstyled mCustomScrollbar notifi-list" data-mcs-theme="minimal-dark">
    <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="javascript:void(0);">
            <?php echo e($notify->message); ?>

        </a>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php else: ?>
<div class="alert alert-danger text-center">No record found.</div>
<?php endif; ?>