<?php $__env->startSection('title', 'Reports'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray" onload="hide_preloader();">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content common-grid-list" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent">
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Reports</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <select class="selectpicker" id="mySelect" > 
                <option value="payment">Payment From Subscription Plans</option>
                <option value="video">Video Download</option>
                <option value="live">Live broadcasts</option>
                <option value="Citizens">Citizens</option>
                <option value="Lawyers">Lawyers</option>
              </select> 
            </li>
          </ul>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <div class="">
              <div class="payment select-box">
                <h4 class="page-title float-left">Payment From Subscription Plans</h4>
                <ul class="list-inline mb-0 text-right">
                  <li class="list-inline-item">
                    <a href="#searchFilterone" data-toggle="collapse" class="nav-link">
                      <i class="fa fa-search"></i>
                    </a>
                  </li>
                </ul>
                <div class="filter_section collapse show" id="searchFilterone">
                  <form id="subscription_form" method="post" autocomplete="off" action="javascript:subscription_list();">
                    <?php echo e(csrf_field()); ?>

                    <div class="row m-0">
                      <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-">
                        <div class="form-group">  
                        <label class="control-label">Select User</label>
                        <select id="user_type_change" class="form-control form-control-lg selectpicker" name="users">
                          <option value="">Select User</option>
                          <option value="citizen">Citizen</option>
                          <option value="lawyer">Lawyer</option>
                          <option value="bail bondsman">Bail Bondsman</option>
                        </select>
                      </div>
                      </div> 
                      <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-">
                        <div class="form-group">  
                          <label class="control-label">Start Date - End Date</label>
                          <input type="text" id="daterange" class="form-control form-control-lg" name="datefilter">
                        </div>
                      </div> 
                      <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-">
                        <div class="form-group d-inline-block mr-2">
                          <label class="btn-block">&nbsp;</label>
                          <button class="btn btn-primary" type="submit">Filter</button>
                        </div>
                        <div class="form-group d-inline-block mr-2">
                          <label class="btn-block">&nbsp;</label>
                          <input id="subscription-reset-btn" type="reset" class="btn btn-primary" value="reset">
                        </div>
                      </div> 
                    </div>
                  </form>
                </div>
                <div class="table-responsive" id="subscription_list">
                  
                </div>
              </div>

              <!-- ...............Video Download............... -->
              <div class="video select-box">
                <h4 class="page-title float-left">Video Download</h4>
                <ul class="list-inline mb-0 text-right">
                  <li class="list-inline-item">
                    <a href="#searchFiltertwo" data-toggle="collapse" class="nav-link">
                      <i class="fa fa-search"></i>
                    </a>
                  </li>
                </ul>
                <div class="filter_section collapse show" id="searchFiltertwo">
                  <form id="video_form" method="post" autocomplete="off" action="javascript:video_download_list();">
                    <?php echo e(csrf_field()); ?>

                    <div class="row m-0">
                      <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-">
                        <div class="form-group">  
                          <label class="control-label">Start Date - End Date</label>
                          <input type="text" id="daterange" class="form-control form-control-lg" name="datefilter">
                        </div>
                      </div> 
                      <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-">
                        <div class="form-group">
                          <label class="control-label">location</label>
                          <input id="video_location" type="text" class="form-control form-control-lg" name="location">
                        </div>
                      </div> 
                      <div class="col-xl-2 col-lg-3 col-md-2 col-sm-6 col-">
                        <div class="form-group d-inline-block mr-2">
                          <label class="btn-block">&nbsp;</label>
                          <button class="btn btn-primary" type="submit">Filter</button>
                          <input id="video-reset-btn" type="reset" class="btn btn-primary" value="reset">
                        </div>
                      </div> 
                    </div>
                  </form>
                </div>
                <div class="table-responsive" id="video_list">
                  
                </div>
              </div>

              <!-- ...............Live Broadcasts............... -->
              <div class="live select-box">
                <h4 class="page-title float-left">Live broadcasts</h4>
                <ul class="list-inline mb-0 text-right">
                  <li class="list-inline-item">
                    <a href="#searchFilterthree" data-toggle="collapse" class="nav-link">
                      <i class="fa fa-search"></i>
                    </a>
                  </li>
                </ul>
                <div class="filter_section collapse show" id="searchFilterthree">
                  <form id="broadcast_form" method="post" autocomplete="off" action="javascript:live_broadcast_list();">
                    <?php echo e(csrf_field()); ?>

                    <div class="row m-0">
                      <div class="col-xl-5 col-lg-6 col-md-6 col-sm-12 col-">
                        <div class="form-group">  
                          <label class="control-label">Start Date - End Date</label>
                          <input type="text" id="daterange" class="form-control form-control-lg" name="datefilter">
                        </div>
                      </div> 
                      <div class="col-xl-5 col-lg-4 col-md-4 col-sm-6 col-">
                        <div class="form-group">
                          <label class="control-label">Location</label>
                          <input id="broadcast_location" type="text" class="form-control form-control-lg" name="location">
                        </div>
                      </div>  
                      <div class="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-">
                        <div class="form-group d-inline-block mr-2">
                          <label class="btn-block">&nbsp;</label>
                          <button class="btn btn-primary" type="submit">Filter</button>
                          <input id="broadcast-reset-btn" type="reset" class="btn btn-primary" value="reset">
                        </div>
                      </div> 
                    </div>
                  </form>
                </div>
                <div class="table-responsive" id="live_list"></div>
                                
                </div>
              </div>

              <!-- ...............Citizens............... -->
              <div class="Citizens select-box">
                <h4 class="page-title float-left">Citizens</h4>
                <ul class="list-inline mb-0 text-right">
                  <li class="list-inline-item">
                    <a href="#searchFilterfour" data-toggle="collapse" class="nav-link">
                      <i class="fa fa-search"></i>
                    </a>
                  </li>
                </ul>
                <div class="filter_section collapse show" id="searchFilterfour">
                  <form id="citizen_form" method="post" autocomplete="off" action="javascript:citizen_list();">
                    <?php echo e(csrf_field()); ?>

                    <div class="row m-0">
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 col-">
                        <div class="form-group">
                          <label class="control-label">Name</label>
                          <input id="citizen_name" type="text" class="form-control form-control-lg" name="name">
                        </div>
                      </div>  
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 col-">
                        <div class="form-group"> 
                          <label class="control-label">Email</label>
                          <input id="citizen_email" type="text" class="form-control form-control-lg" name="email">
                        </div>
                      </div> 
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 col-">
                        <div class="form-group">
                          <label class="control-label">Mobile</label>
                          <input id="citizen_phone" type="text" class="form-control form-control-lg" name="phone">
                        </div>
                      </div> 
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                        <div class="form-group">
                          <label class="control-label">Subscription Status</label>
                          <select id="citizen_subscription" class="form-control form-control-lg selectpicker" name="s_status">
                            <option value="">Select Status</option>
                            <option value="active">Active</option>
                            <option value="cancel">Cancelled</option>
                          </select>
                        </div>
                      </div> 
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 col-">
                        <div class="form-group">
                           <label class="control-label">User Type</label>
                          <select id="citizen_type_change" class="form-control form-control-lg selectpicker" name="u_status">
                            <option value="">Select Type</option>
                            <option value="active">Active</option>
                            <option value="inactive">De-active</option>
                          </select>
                        </div>
                      </div> 
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 col-">
                        <div class="form-group d-inline-block mr-2">
                          <label class="btn-block">&nbsp;</label>
                          <button class="btn btn-primary" type="submit">Filter</button>
                          <input id="citizen-reset-btn" type="reset" class="btn btn-primary" value="reset">
                        </div>
                      </div> 
                    </div>
                  </form>
                </div>
                <div class="table-responsive" id="citizens_list"></div>
                              
                </div>
              </div>

              <!-- ...............Lawyers............... -->
              <div class="Lawyers select-box">
                <h4 class="page-title float-left">Lawyers</h4>
                <ul class="list-inline mb-0 text-right">
                  <li class="list-inline-item">
                    <a href="#searchFilterfive" data-toggle="collapse" class="nav-link">
                      <i class="fa fa-search"></i>
                    </a>
                  </li>
                </ul>
                <div class="filter_section collapse show" id="searchFilterfive">
                  <form id="lawyer_form" method="post" autocomplete="off" action="javascript:lawyer_list();">
                    <?php echo e(csrf_field()); ?>

                    <div class="row m-0">
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                        <div class="form-group">
                          <label class="control-label">Name</label>
                          <input id="lawyer_name" type="text" class="form-control form-control-lg" name="name">
                        </div>
                      </div>  
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                        <div class="form-group">
                          <label class="control-label">Email</label>
                          <input id="lawyer_email" type="text" class="form-control form-control-lg" name="email">
                        </div>
                      </div> 
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                        <div class="form-group">
                          <label class="control-label">Mobile</label>
                          <input id="lawyer_phone" type="text" class="form-control form-control-lg" name="phone">
                        </div>
                      </div> 
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                        <div class="form-group">
                          <label class="control-label">Subscription Status</label>
                          <select id="lawyer_subscription" class="form-control form-control-lg selectpicker" name="s_status">
                            <option value="">Select Status</option>
                            <option value="active">Active</option>
                            <option value="cancel">Cancelled</option>
                          </select>
                        </div>
                      </div> 
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                        <div class="form-group">
                          <label class="control-label">User Type</label>
                          <select id="lawyer_type_change" class="form-control form-control-lg selectpicker" name="u_status">
                            <option value="">Select Type</option>
                            <option value="active">Active</option>
                            <option value="inactive">De-active</option>
                          </select>
                        </div>
                      </div> 
                      <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                        <div class="form-group d-inline-block mr-2">
                          <label class="btn-block">&nbsp;</label>
                          <button class="btn btn-primary" type="submit">Filter</button>
                          <input id="lawyer-reset-btn" type="reset" class="btn btn-primary" value="reset">
                        </div>
                      </div> 
                    </div>
                  </form>
                </div>
                <div class="table-responsive" id="lawyer_list"></div>
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
        
              
  <script type="text/javascript">
     // 
    $('#chooseFile').bind('change', function () {
        var filename = $("#chooseFile").val();
        if (/^\s*$/.test(filename)) {
          $(".file-upload").removeClass('active');
          $("#noFile").text("No file chosen..."); 
        } 
        else {
          $(".file-upload").addClass('active');
          $("#noFile").text(filename.replace("C:\\fakepath\\", "")); 
        }
      });
 
    $("#subscription-reset-btn").click(function() 
    {
      $('#user_type_change').val('').change();
      $('#daterange').val('').change();
      subscription_list();
    });


    $("#video-reset-btn").click(function() 
    {
      $('#video_location').val('').change();
      $('#daterange').val('').change();
      video_download_list();
    });


    $("#broadcast-reset-btn").click(function() 
    {
      $('#broadcast_location').val('').change();
      $('#daterange').val('').change();
      video_download_list();
    });


    $("#citizen-reset-btn").click(function() 
    {
      $('#citizen_name').val('').change();
      $('#citizen_email').val('').change();
      $('#citizen_phone').val('').change();
      $('#citizen_type_change').val('').change();
      $('#citizen_subscription').val('').change();
      citizen_list();
    });


    $("#lawyer-reset-btn").click(function() 
    {
      $('#lawyer_name').val('').change();
      $('#lawyer_email').val('').change();
      $('#lawyer_phone').val('').change();
      $('#lawyer_type_change').val('').change();
      $('#lawyer_subscription').val('').change();
      lawyer_list();
    });


    function subscription_list()
    {
      $("#subscription_list").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter=$("#subscription_form").serializeArray();
      search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
      $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/report-subscription-list')); ?>",
                data: search_filter,
                success: function (response)
                {
                  $(".select-box").not(".payment").hide();
                  $(".payment").show();
                  $("#subscription_list").html(response.html);
                  $('#payment_list').DataTable({
                                                  searching: false,
                                                  "order": [],
                                              });
                }
            });
    }


    function video_download_list()
    {
      $("#video_list").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter=$("#video_form").serializeArray();
      search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
      $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/report-video-list')); ?>",
                data: search_filter,
                success: function (response)
                {
                  $(".select-box").not(".video").hide();
                  $(".video").show();
                  $("#video_list").html(response.html);
                  $('#video_table').DataTable({
                                                searching: false,
                                                "order": [],
                                              });
                }
            });
    }
    
      
    function live_broadcast_list()
    {
      $("#live_list").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter=$("#broadcast_form").serializeArray();
      search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
      $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/report-broadcast-list')); ?>",
                data: search_filter,
                success: function (response)
                {
                  $(".select-box").not(".live").hide();
                  $(".live").show();
                  $("#live_list").html(response.html);
                  $('#live_broadcast').DataTable({
                                                    searching: false,
                                                    "order": [],
                                                });
                }
            });
    }
    

    function citizen_list()
    {
      $("#citizens_list").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter=$("#citizen_form").serializeArray();
      search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
      $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/report-citizens-list')); ?>",
                data: search_filter,
                success: function (response)
                {
                  $(".select-box").not(".Citizens").hide();
                  $(".Citizens").show();
                  $("#citizens_list").html(response.html);
                  $('#list_citizens').DataTable({
                                                  searching: false,
                                                  "order": [],
                                                });
                }
            });
    }
        

    function lawyer_list()
    {
      $("#lawyer_list").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter=$("#lawyer_form").serializeArray();
      search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
      $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/report-lawyer-list')); ?>",
                data: search_filter,
                success: function (response)
                {
                  $(".select-box").not(".Lawyers").hide();
                  $(".Lawyers").show();
                  $("#lawyer_list").html(response.html);
                  $('#list_lawyers').DataTable({
                    searching: false,
                    "order": [],
                  });
                }
            });
    }


  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>