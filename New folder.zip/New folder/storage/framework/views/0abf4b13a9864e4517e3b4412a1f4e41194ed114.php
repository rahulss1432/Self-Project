<?php $__env->startSection('title', 'Forget Password'); ?>
<?php $__env->startSection('content'); ?>
<main class="login-page">
    <div class="login-wrap mx-auto">
        <div class="login-header d-flex align-items-center justify-content-center">
            <img src="<?php echo e(asset('public/images/logo.png')); ?>" alt="logo" class="img-fluid">
        </div>
        <div class="login-field">
            <form id="forgotPasswordForm" method="POST" action="<?php echo e(url('admin/send-forgot-email')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <div class="input-group align-items-end">
                        <div class="input-group-addon"><i class="ti-email"></i></div>
                        <input type="text" name="email" class="form-control form-control-lg"/>
                        <label class="control-label">Email</label>
                    </div>
                </div>
                <div class="form-group text-center">
                    <button type="submit" id="btnForgotPassword" class="btn btn-primary ripple-effect">SUBMIT 
                        <i id="forgotFormLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none;"></i></button>
                </div>
            </form>
            <?php echo JsValidator::formRequest('App\Admin\Http\Requests\ForgotPasswordRequest','#forgotPasswordForm'); ?>

        </div>
        <div class="login-footer">
            <a href="<?php echo e(url('/admin')); ?>"> <span class="ti-arrow-left"></span> &nbsp; LOGIN</a>
        </div>
    </div>
</main>
<script type="text/javascript">
    $(document).on('submit', '#forgotPasswordForm', function (e) {
        e.preventDefault();
        if ($('#forgotPasswordForm').valid()) {
            $('#btnForgotPassword').prop('disabled', true);
            $('#forgotFormLoader').show();
            $.ajax({
                url: "<?php echo e(url('admin/send-forgot-email')); ?>",
                data: $('#forgotPasswordForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "<?php echo e(url('/admin')); ?>";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnForgotPassword').prop('disabled', false);
                    }
                    $('#forgotFormLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#forgotFormLoader').hide();
                        $('#btnForgotPassword').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>