<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
<div class="home-header">
    <?php echo $__env->make('layouts.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<main class="main-content home-page">
    <section class="banner-section">
        <div class="container">
            <div class="banner-content">
                <?php echo $home->content; ?>

                <a href="<?php echo e(url('/buy-now')); ?>" class="btn btn-primary ripple-effect text-uppercase">BUY NOW</a>
            </div>
        </div>
    </section>

    <!-- xxxxxxx -->

    <section class="book-section common-pad" id="purchaseBook">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <img src="<?php echo e(\App\Helpers\Utility::checkEBookImage($book->book_image)); ?>" alt="book" class="img-fluid"/>
                </div>

                <div class="col-md-8">

                    <div class="row">
                        <?php echo $book->pages_content; ?>

                    </div>

                    <div class="row">
                        <div class="col-12">
                            <a href="<?php echo e(url('/buy-now')); ?>" class="btn btn-primary text-uppercase ripple-effect">buy now</a>
                        </div>
                    </div>

                </div>


            </div>
        </div>
    </section>

    <!-- xxxxxxx -->
    <?php if(count($podcastList)>0): ?>
    <section class="podcast-section common-pad" id="podcast">
        <h2 class="common-heading text-uppercase text-center">
            LISTEN TO THE PODCASTS
        </h2>
        <div class="container">
            <div class="row custom-gutters">
                <?php $__currentLoopData = $podcastList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                <div class="col-lg-3 col-sm-6">
                    <div class="podcast-box" style="background-image: url('<?php echo e(\App\Helpers\Utility::checkPodcastImage($list->podcast_image)); ?>')">
                        <div class="position-div">
                            <h2><?php echo e($list->title); ?> </h2>
                            <div class="hidden-item">
                                <p><?php echo e($list->description); ?></p>
                                <a href="javascript:void(0);" onclick="playMedia($(this),'<?php echo e($list->title); ?>','<?php echo e($list->audio_url); ?>')">
                                    <span class="playBtn"><img src="<?php echo e(url('public/images/play-icon.png')); ?>" alt="Play"/> Play</span>
                                    <span class="voicBar"><img src="<?php echo e(url('public/images/bars-loader.gif')); ?>" width="50" alt="Play"/></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>               
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="view-more-wrap">
                <a href="<?php echo e(url('/podcast')); ?>" class="section-view-more">View More</a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- xxxxxxx -->

    <?php if(count($blogList)>0): ?>
    <section class="blog-section common-pad" id="blog">
        <h2 class="common-heading text-uppercase text-center">
            blogs
        </h2>

        <div class="container">
            <div class="row">
                <?php if(!empty($blogList[0])): ?>
                <div class="col-md-12 col-lg-4">
                    <a href="<?php echo e(url('/blog-detail/'.$blogList[0]['id'])); ?>" class="blog-wrap first-blog">
                        <div class="blog-img" style="background-image: url('<?php echo e(\App\Helpers\Utility::checkBlogImage('500-600'.$blogList[0]['blog_image'],'blog-image')); ?>');"></div>
                        <div class="blog-info">
                            <h2><?php echo e($blogList[0]['blog_title']); ?> </h2>
                            <p class="mb-0"><?php echo e(\App\Helpers\Utility::getDateFormat($blogList[0]['created_at'])); ?></p>
                        </div>
                    </a>
                </div>
                <?php endif; ?>

                <!-- xxxxxxxxx -->

                <div class="col-md-12 col-lg-4">
                    <div class="row">
                        <?php if(!empty($blogList[1])): ?>
                        <div class="col-md-6 col-lg-12 col-12">
                            <a href="<?php echo e(url('/blog-detail/'.$blogList[1]['id'])); ?>" class="blog-wrap">
                                <div class="blog-img" style="background-image: url('<?php echo e(\App\Helpers\Utility::checkBlogImage('500-285'.$blogList[0]['blog_image'],'blog-image')); ?>');"></div>
                                <div class="blog-info">
                                    <h2><?php echo e($blogList[1]['blog_title']); ?> </h2>
                                    <p class="mb-0"><?php echo e(\App\Helpers\Utility::getDateFormat($blogList[1]['created_at'])); ?></p>
                                </div>
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if(!empty($blogList[2])): ?>
                        <div class="col-md-6 col-lg-12 col-12">
                            <a href="<?php echo e(url('/blog-detail/'.$blogList[2]['id'])); ?>" class="blog-wrap">
                                <div class="blog-img" style="background-image: url('<?php echo e(\App\Helpers\Utility::checkBlogImage('500-285'.$blogList[0]['blog_image'],'blog-image')); ?>');"></div>
                                <div class="blog-info">
                                    <h2><?php echo e($blogList[2]['blog_title']); ?> </h2>
                                    <p class="mb-0"><?php echo e(\App\Helpers\Utility::getDateFormat($blogList[2]['created_at'])); ?></p>
                                </div>
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>


                <!-- xxxxxxxxx -->

                <div class="col-md-12 col-lg-4">
                    <div class="blog-list">
                        <ul class="list-unstyled">
                            <?php if(!empty($blogList[3])): ?>
                            <li>
                                <div class="img-wrap">
                                    <img src="<?php echo e(\App\Helpers\Utility::checkBlogImage('160-135'.$blogList[0]['blog_image'],'blog-image')); ?>" alt="blog" class="img-fluid" />
                                </div>


                                <div class="right-side">
                                    <a href="<?php echo e(url('/blog-detail/'.$blogList[3]['id'])); ?>"><?php echo e($blogList[3]['blog_title']); ?> </a>
                                    <p><?php echo e(\App\Helpers\Utility::getDateFormat($blogList[3]['created_at'])); ?></p>
                                </div>
                            </li>
                            <?php endif; ?>

                            <?php if(!empty($blogList[4])): ?>
                            <li>
                                <div class="img-wrap">
                                    <img src="<?php echo e(\App\Helpers\Utility::checkBlogImage('160-135'.$blogList[0]['blog_image'],'blog-image')); ?>" alt="blog" class="img-fluid" />
                                </div>


                                <div class="right-side">
                                    <a href="<?php echo e(url('/blog-detail/'.$blogList[4]['id'])); ?>"><?php echo e($blogList[4]['blog_title']); ?> </a>
                                    <p><?php echo e(\App\Helpers\Utility::getDateFormat($blogList[4]['created_at'])); ?></p>
                                </div>
                            </li>
                            <?php endif; ?>

                            <?php if(!empty($blogList[5])): ?>
                            <li>
                                <div class="img-wrap">
                                    <img src="<?php echo e(\App\Helpers\Utility::checkBlogImage('160-135'.$blogList[0]['blog_image'],'blog-image')); ?>" alt="blog" class="img-fluid" />
                                </div>


                                <div class="right-side">
                                    <a href="<?php echo e(url('/blog-detail/'.$blogList[5]['id'])); ?>"><?php echo e($blogList[5]['blog_title']); ?> </a>
                                    <p><?php echo e(\App\Helpers\Utility::getDateFormat($blogList[5]['created_at'])); ?></p>
                                </div>
                            </li>
                            <?php endif; ?>

                            <?php if(!empty($blogList[6])): ?>
                            <li>
                                <div class="img-wrap">
                                    <img src="<?php echo e(\App\Helpers\Utility::checkBlogImage('160-135'.$blogList[0]['blog_image'],'blog-image')); ?>" alt="blog" class="img-fluid" />
                                </div>


                                <div class="right-side">
                                    <a href="<?php echo e(url('/blog-detail/'.$blogList[6]['id'])); ?>"><?php echo e($blogList[6]['blog_title']); ?> </a>
                                    <p><?php echo e(\App\Helpers\Utility::getDateFormat($blogList[6]['created_at'])); ?></p>
                                </div>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

            </div>

            <div class="view-more-wrap">
                <a href="<?php echo e(url('/blogs')); ?>" class="section-view-more">View More</a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- xxxxxxx -->


    <section class="deniel-section common-pad" id="danielZeman">
        <div class="container">
            <div class="deniel-wrapper">
                <div class="row">
                    <div class="col-md-5">
                        <img src="<?php echo e(url('public/images/daniel-zeman.jpg')); ?>" alt="daniel-zeman" class="img-fluid" />
                    </div>

                    <!-- xxxxxxxx -->

                    <div class="col-md-7">
                        <div class="details">
                            <?php echo $aboutUs->content; ?>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <!-- xxxxxxx -->

    <section class="testimonial-section common-pad">
        <h2 class="common-heading text-center">
            What People Say...
        </h2>
        <p class="sub-heading text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <div class="container">
            <div class="testimonial-wrap">
                <div id="userTestimonial">
                    <div class="slide">
                        <div class="testimonial-box">
                            <div class="img-wrap">
                                <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" alt="user" class="rounded-circle img-fluid" />
                            </div>

                            <p>
                                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                            </p>

                            <h5 class="text-center">Hunter Hemls</h5>
                        </div>
                    </div>

                    <!-- xxxxxxxxx -->

                    <div class="slide">
                        <div class="testimonial-box">
                            <div class="img-wrap">
                                <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" alt="user" class="rounded-circle img-fluid" />
                            </div>

                            <p>
                                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                            </p>

                            <h5 class="text-center">Hunter Hemls</h5>
                        </div>
                    </div>

                    <!-- xxxxxxxxx -->

                    <div class="slide">
                        <div class="testimonial-box">
                            <div class="img-wrap">
                                <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" alt="user" class="rounded-circle img-fluid" />
                            </div>

                            <p>
                                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                            </p>

                            <h5 class="text-center">Hunter Hemls</h5>
                        </div>
                    </div>

                    <!-- xxxxxxxxx -->

                    <div class="slide">
                        <div class="testimonial-box">
                            <div class="img-wrap">
                                <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" alt="user" class="rounded-circle img-fluid" />
                            </div>

                            <p>
                                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                            </p>

                            <h5 class="text-center">Hunter Hemls</h5>
                        </div>
                    </div>

                    <!-- xxxxxxxxx -->

                    <div class="slide">
                        <div class="testimonial-box">
                            <div class="img-wrap">
                                <img src="<?php echo e(url('public/images/user-01.jpg')); ?>" alt="user" class="rounded-circle img-fluid" />
                            </div>
                            <p>
                                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
                            </p>
                            <h5 class="text-center">Hunter Hemls</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- xxxxxxx -->
              <!--   <section class="signup-section common-pad" >
                    <div class="container">
                        <div class="signup-wrap">
                            <img src="assets/images/inbox-book01.png" alt="inbox-book0" class="signup-img01" />
                            <img src="assets/images/inbox-book02.png" alt="inbox-book0" class="signup-img02" />

                            <h2 class="font-bold">
                                Get the latest news and stories delivered to your inbox.
                            </h2>

                            <a href="javascript:void(0);" class="btn btn-secondary text-uppercase ripple-effect-dark">sign up</a>
                        </div>
                    </div>
                </section> -->
</main>


<script src="<?php echo e(url('public/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(url('public/js/slick.min.js')); ?>"></script>
<script>
$('#userTestimonial').slick({
    dots: true,
    arrows: false,
    autoplay: true,
    autoplaySpeed: 3000,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
});


// menu scroll header
var lastId,
        topMenu = $(".topheader"),
        topMenuHeight = topMenu.outerHeight() - 40,
        // All list items
        menuItems = topMenu.find(".front-links"),
        // Anchors corresponding to menu items
        scrollItems = menuItems.map(function () {
            var item = $($(this).attr("href"));
            if (item.length) {
                return item;
            }
        });

// Bind click handler to menu items
// so we can get a fancy scroll animation
menuItems.click(function (e) {
    var href = $(this).attr("href"), offsetTop = href === "#" ? 0 : $(href).offset().top - topMenuHeight + 1;
    $('html, body').stop().animate({
        scrollTop: offsetTop
    }, 1000);
    e.preventDefault();
});

// Bind to scroll
$(window).scroll(function () {
    // Get container scroll position
    var fromTop = $(this).scrollTop() + topMenuHeight;

    // Get id of current scroll item
    var cur = scrollItems.map(function () {
        if ($(this).offset().top < fromTop)
            return this;
    });
    // Get the id of the current element
    cur = cur[cur.length - 1];
    var id = cur && cur.length ? cur[0].id : "";

//
});

// if redirect from other page to home page then
//console.log(window.location.hash);

if (window.location.hash == '#purchaseBook') {
    var href = '#purchaseBook';
    var offsetTop = $(href).offset().top - topMenuHeight + 1;
    $('html, body').stop().animate({
        scrollTop: offsetTop
    }, 1000);

}

if (window.location.hash == '#podcast') {
    var href = '#podcast';
    var offsetTop = $(href).offset().top - topMenuHeight + 1;
    $('html, body').stop().animate({
        scrollTop: offsetTop
    }, 1000);

}

if (window.location.hash == '#blog') {
    var href = '#blog';
    var offsetTop = $(href).offset().top - topMenuHeight + 1;
    $('html, body').stop().animate({
        scrollTop: offsetTop
    }, 1000);

}

if (window.location.hash == '#danielZeman') {
    var href = '#danielZeman';
    var offsetTop = $(href).offset().top - topMenuHeight + 1;
    $('html, body').stop().animate({
        scrollTop: offsetTop
    }, 1000);

}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>