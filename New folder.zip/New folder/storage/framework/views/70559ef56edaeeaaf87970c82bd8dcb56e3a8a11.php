<?php if(count($callRequest) >0): ?>
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Business Name</th>
            <th>Merchant Number</th>
            <th>Date of Call</th>
            <th>Status of Call</th>
            <th>SE Assigned</th>
            <th>Category</th>
            <th class="th_action no-sort">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $callRequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>Clinitial</td>
            <td>MN6548</td>
            <td>28-10-2018</td>
            <td>
                <div class="user_status pending">
                    <span>Pending</span>
                </div>
            </td>
            <td>Elmo Pratt</td>
            <td>Product Upgrade</td>

            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="<?php echo e(url('manager/call-request-view')); ?>">View</a>
                    </div>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center><?php echo e(\Config::get('constants.no_record_found')); ?></center></div>
<?php endif; ?>