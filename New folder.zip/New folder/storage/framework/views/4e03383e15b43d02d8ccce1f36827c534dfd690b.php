<div class="info_row">
    <div class="img_wrap">
        <img src="<?php echo e(checkUserImage($getContractors->profile_image, 'user')); ?>" alt="profile-img" class="img-fluid">
    </div>
    <div class="details">
        <ul class="right_side list-unstyled">
            <li>
                <label>Name</label>
                <span><?php echo e(getFullName($getContractors->first_name, $getContractors->last_name)); ?></span>
            </li>
            <li>
                <label>Email</label>
                <span><?php echo e($getContractors->email); ?></span>
            </li>
            <li>
                <label>Phone Number</label>
                <span><?php echo e((!empty($getContractors->phone_number)) ? $getContractors->phone_number : '-'); ?></span>
            </li>
            <li>
                <label>DOB</label>
                <span><?php echo e((!empty($getContractors->date_of_birth)) ? showDateFormat($getContractors->date_of_birth) : '-'); ?></span>
            </li>
            <li>
                <label>Experience </label>
                <span><?php echo e((!empty($getContractors->experience)) ? $getContractors->experience : '-'); ?></span>
            </li>
            <li>
                <label>Profile Status</label>
                <span class="text-success"><?php echo e((!empty($getContractors->status)) ? ucfirst($getContractors->status) : '-'); ?></span>
            </li>
        </ul>
    </div>
</div>
<div class="full-dtl">
    <ul class="right_side list-unstyled">
        <li>
            <label>Ratings</label>
            <span class="rating d-block">
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
                <i class="fa fa-star" aria-hidden="true"></i>
            </span>
        </li>
        <li>
            <label>Registration Date</label>
            <span class="d-block">
                <?php 
                echo showDateTimeFormat($getContractors->created_at);
                 ?>
            </span>
        </li>
        <li>
            <label>Mentor Locator unique URL</label>
            <span class="d-block"><a href="javascript:void(0);" class="theme-color">https://www.mentolocator.com/Garrettbird</a></span>
        </li>
        <li>
            <label>Address</label>
            <span class="d-block">45 st peter Warner, Queensland, 4500 Australia</span>
        </li>
    </ul>
</div>