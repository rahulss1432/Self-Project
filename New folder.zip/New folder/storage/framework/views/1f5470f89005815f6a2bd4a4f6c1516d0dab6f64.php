<?php if(!empty($video)): ?>
  <table class="table admin-table" id="data_table">
    <thead>
      <tr>
        <th>Video ID</th>
        <th>Video Image</th>
        <th>Video Title</th>
        <th>Posted By</th>
        <th>Duration</th>
        <th>Size</th>
        <th>Date & Time</th>
        <th>Location</th>
        <th>Total View</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php  $serial = 1;  ?>
      <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="video<?php echo e($data->id); ?>">
          <td><?php echo e($serial); ?></td>
          <td class="text-capitalize">
            <?php if($data->video_thumb): ?>
<!--              <?php if($data->video_type == "youtube"): ?>
                <img src="<?php echo e($data->video_thumb); ?>" class="video_img">
                <?php elseif($data->video_type == ""): ?>-->
                  <img src="<?php echo e(url('public/uploads/videos/thumb/'.$data->video_thumb)); ?>" class="video_img">
<!--              <?php endif; ?>-->
              <?php else: ?>
                <img src="<?php echo e(url('public/assets/images/timeline_img02.jpg')); ?>" class="video_img">
            <?php endif; ?>
          </td>
          <td class="text-capitalize"><?php echo e(ucfirst($data->title)); ?></td>
          <td class="text-capitalize"><?php echo e(ucfirst($data->first_name)); ?> <?php echo e(ucfirst($data->last_name)); ?></td>
          <td><?php echo e($data->video_length); ?> Min</td>
          <td><?php echo e(substr($data->video_size,0,4)); ?> MB</td>
          <td><?php echo e(date('d-m-Y h:i A', strtotime($data->created_at))); ?></td>
          <?php if($data->location): ?>
            <td><?php echo e(substr($data->location,0,39)); ?>...</td>
            <?php else: ?>
              <td></td>
          <?php endif; ?>
          <td><?php echo e($data->video_views); ?></td>
          <td>
            <ul class="list-inline mb-0 ">
              <li class="list-inline-item">
                <a id="view-loader<?php echo e($data->id); ?>" onclick="viewfunction(<?php echo e($data->id); ?>)" href="<?php echo e(url('admin/broadcasted-videos-view',$data->id)); ?>">
                  <i class="fa fa-eye"></i>
                </a>
            </li>
            <li class="list-inline-item">
                <a id="edit-loader<?php echo e($data->id); ?>" onclick="editfunction(<?php echo e($data->id); ?>)" href="<?php echo e(url('admin/broadcasted-videos-edit',$data->id)); ?>">
                  <i class="fa fa-pencil"></i>
                </a>
            </li> 
            <li class="list-inline-item">
                <a id="delete-loader<?php echo e($data->id); ?>" href="javascript:void(0);" onclick="deletefunction(<?php echo e($data->id); ?>)">
                  <i class="fa fa-trash"></i>
                </a>
            </li>
            </ul>
          </td>
        </tr>
        <?php  $serial++;  ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php else: ?>
    <div class="alert alert-danger"><center>No video available.</center></div>
<?php endif; ?>