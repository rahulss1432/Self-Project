<?php if(count($categories) > 0): ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Category Name</th>
            <th>Category Icon</th>
            <th>Sub Category</th>
            <th class="w150 text-center">Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($category->category_name); ?></td>
            <td><img src="<?php echo e(checkCategoryIcon($category->category_icon, 'category_icons')); ?>" width="50" height="50"/></td>
            <td><a href="<?php echo e(url('admin/get-sub-category/'.base64_encode($category->id))); ?>" class="bg-blue">View <span class="badge badge-light"><?php echo e(getSubCategoryCount($category->id)); ?></span></a></td>
            <td>
                <div class="switch text-center">
                    <label>
                        <?php if($category->status == 'active'): ?>
                        <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this,'<?php echo e($category->id); ?>')">
                        <?php else: ?>
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'<?php echo e($category->id); ?>')">
                        <?php endif; ?>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($categories->links()); ?>

<script>
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getCategoryList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '<?php echo e(csrf_token()); ?>'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getCategoryList').html(response.html);
            }
    });
    });
</script>
