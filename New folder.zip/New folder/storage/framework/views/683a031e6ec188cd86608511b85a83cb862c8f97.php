<?php if(count($citizens) > 0): ?>
  <table class="table admin-table" id="data_table">
    <thead>
      <tr>
        <th>Full Name</th>
        <th>Email</th>
        <th>Mobile Number</th>
        <th>state</th>
        <th>city</th>
        <th>status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $citizens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr id="<?php echo e('citizen'.$data->id); ?>">
            <td class="text-capitalize">
              <span style="display:none"><?php echo e($data->id); ?></span><?php echo e(ucfirst($data->first_name)); ?> <?php echo e(ucfirst($data->last_name)); ?>

            </td>
            <td><?php echo e($data->email); ?></td>
            <td><?php echo e($data->phone); ?></td>
            <td class="text-capitalize"><?php echo e($data->states_name); ?></td>
            <td class="text-capitalize"><?php echo e($data->city_name); ?></td>
            <td>
              <label class="switch">
                <div class="statusbtn">
                  <div class="status-chk enable">
                    <input id="enable_a_<?php echo e($data->id); ?>" type="radio" onclick="activeInacive(<?php echo e($data->id); ?>,'<?php echo e($data->status); ?>')" value="active" name="radio_<?php echo e($data->id); ?>" <?php if($data->status=='active'): ?>) checked="checked" <?php endif; ?> >
                    <span class="slider round" for="enable_<?php echo e($data->id); ?>"></span>
                  </div>
                </div>
              </label>
            </td>
            <td>
              <ul class="list-inline mb-0 ">
                <li class="list-inline-item">
                  <a id="view-loader<?php echo e($data->id); ?>" onclick="viewfunction(<?php echo e($data->id); ?>)" href="<?php echo e(url('admin/citizens-view',$data->id)); ?>">
                    <i class="fa fa-eye"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a id="edit-loader<?php echo e($data->id); ?>" onclick="editfunction(<?php echo e($data->id); ?>)" href="<?php echo e(url('admin/citizens-edit',$data->id)); ?>">
                    <i class="fa fa-pencil"></i>
                  </a>
                </li> 
                <li class="list-inline-item">
                  <a id="delete-loader<?php echo e($data->id); ?>" href="javascript:void(0);" onclick="deletefunction(<?php echo e($data->id); ?>)">
                    <i class="fa fa-trash"></i>
                  </a>
                </li>
              </ul>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php else: ?>
    <div class="alert alert-danger"><center>No citizen available.</center></div>
<?php endif; ?>