<div class="user_info">
    <div class="info_row">
        <div class="img_wrap">
            <img src="<?php echo e(checkUserImage($user->profile_image, '')); ?>" alt="profile-img" class="img-fluid">
        </div>
        <div class="details">
            <ul class="right_side list-unstyled">
                <li>
                    <label>Name</label>
                    <span><?php echo e(getFullName($user->first_name,$user->last_name)); ?></span>
                </li>
                <li>
                    <label>Email</label>
                    <span><?php echo e($user->email); ?></span>
                </li>
                <li>
                    <label>Phone Number</label>
                    <span><?php echo e((!empty($user->phone_number)) ? $user->phone_number : '-'); ?></span>
                </li>
                <li>
                    <label>DOB</label>
                    <span><?php echo e(showDateFormat($user->date_of_birth)); ?></span>
                </li>
                <li>
                    <label>Status</label>
                    <span class="text-success">
                        <?php echo e(($user->status == "active") ? 'Active' : 'Inactive'); ?>

                    </span>
                </li>
                <li>
                    <label>Date Added</label>
                    <span><?php echo e(showDateFormat($user->created_at)); ?></span>
                </li>
            </ul>
        </div>
    </div>
    <div class="full-dtl">
        <ul class="right_side list-unstyled">
            <li>
                <label>User  Unique URL </label>
                <span class="d-block"><a href="javascript:void(0);" class="theme-color">https://www.mentolocator.com/Garrettbird</a></span>
            </li>
            <li>
                <label>Address</label>
                <span class="d-block"><?php echo e((!empty($user->address)) ? $user->address : '-'); ?></span>
            </li>

            <li>
                <label>Bio</label>
                <span class="d-block"><?php echo e((!empty($user->address)) ? $user->address : '-'); ?></span>
            </li>
        </ul>
    </div>
</div>