<?php if(count($messages) > 0): ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>User Name</th>
            <th>Mentor Name</th>
            <th>Date and Time</th>
            <th>Status</th>
            <th class="w100 text-center">View / Delete Message</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($message->messageUser->first_name.' '.$message->messageUser->last_name); ?></td>
            <td><?php echo e($message->messageMentor->first_name.' '.$message->messageMentor->last_name); ?></td>
            <td><?php echo e(timeFormat($message->created_at)); ?></td>
            <td>
                <div class="switch">
                    <label>
                        <?php if($message->status == 'active'): ?>
                        <input type="checkbox" name="activeInactive" checked onchange="changeStatus(this,'<?php echo e($message->id); ?>')">
                        <?php else: ?>
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'<?php echo e($message->id); ?>')">
                        <?php endif; ?>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <ul class="list-inline mb-0 text-center">
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Message">
                        <a href="/admin/messages.php"><i class="ti-comment-alt"></i></a>
                    </li>
                    <li class="list-inline-item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="javascript:void(0);" onclick="removeMessage('<?php echo e($message->id); ?>');"><i class="ti-trash"></i></a>
                    </li>
                </ul>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($messages->links()); ?>

<script type="text/javascript">
    $('[data-toggle="tooltip"]').tooltip({trigger: "hover"});
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getChatList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '<?php echo e(csrf_token()); ?>'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getChatList').html(response.html);
            }
    });
    });
</script>