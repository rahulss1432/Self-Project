<!-- Modal -->
<div class="modal fade common-modal" id="viewHestory" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="viewHestoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content history-modal">
            <div class="modal-header align-items-center">
                <div class="col text-left p-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="col p-0 text-center">
                    <h5 class="modal-title" id="viewHestoryModalLabel">HISTORY</h5>
                </div>
                <div class="col p-0 text-right">
                    <a href="javascript:void(0)" onclick="editModalNote();" class="btn btn-secondary btn-icon"><i class="fas fa-pen"></i></a>
                </div>
            </div>
            <div class="modal-body">
                <div class="user-dtl-top d-sm-flex justify-content-between">
                    <div class="left-dtl d-flex align-items-center">
                        <div class="user-avtar">
                            <img src="<?php echo e(url('public/assets/images/user01.jpg')); ?>" alt="User" class="rounded-circle">
                        </div>
                        <div class="user-name">
                            <h3>Micah Chan</h3>
                            <p>American Express Bank</p>
                        </div>
                    </div>
                    <div class="right-dtl text-sm-right">
                        <div class="user_status pending">
                            <span>Pending</span>
                        </div>
                        <ul class="list-inline">
                            <li class="list-inline-item">
                                <i class="icon-calendar"></i> <span>23 Aug 2018</span>
                            </li>
                            <li class="list-inline-item">
                                <i class="icon-clock"></i> <span>15 mins</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="user-dtl-in">
                    <p class="note">Note</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- add note Modal -->
<div class="modal fade common-modal add_note" id="AddNote" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="viewHestoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header ">
                <div class="col p-0 text-center">
                    <h5 class="modal-title" id="viewHestoryModalLabel">ADD NOTE</h5>
                </div>
            </div>
            <div class="modal-body">
                <form action="">
                    <div class="form-group input_wrap">
                        <label class="theme-color02 d-block">Request Status</label>
                        <label class="i-checks">
                            <input type="radio" name="status" checked onchange="status_radio('Pending');"><i></i> Pending 
                        </label>
                        <label class="i-checks ml-2 ml-sm-3">
                            <input type="radio" name="status"  onchange="status_radio('Resolved');"><i></i> Resolved 
                        </label>
                    </div>
                    <div class="field_box Pending">
                        <div class="form-group">
                            <label class="theme-color02 d-block">Notify me</label>
                            <div class="form-check form-check-inline">
                                <label class="i-checks">
                                    <input type="radio" name="notify" checked onchange="notify_radio('UserOnline');"><i></i> When user back online 
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="i-checks">
                                    <input type="radio" name="notify" onchange="notify_radio('Today');"><i></i> Today 
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="i-checks">
                                    <input type="radio" name="notify" onchange="notify_radio('DateTime');"><i></i> Select date & time 
                                </label>
                            </div>
                        </div>
                        <div class="notify_box UserOnline">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select category</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Account Changes</option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select executive</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                            <option value="">John Cart </option>
                                            <option value="">Kendra Lust </option>
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="note border rounded">
                                <label class="theme-color02">Note</label>
                                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut venenatis mauris augue. Phasellus sed convallis nisi, vitae consectetur nibh. Aliquam facilisis ipsum et erat sollicitudin, non rhoncus ex luctus. Aenean pellentesque consectetur semper. Nulla vehicula eros eget convallis maximus. Nulla dapibus vulputate nisi, quis placerat elit. Proin tincidunt sem at eleifend hendrerit. Mauris a rutrum dolor. Duis mauris risus, vestibulum at lacinia sed, dictum nec dui.</p>
                            </div>
                        </div>
                        <div class="notify_box collapse Today">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Notify in</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">10 minutes</option>
                                            <option value="">20 minutes </option>
                                            <option value="">30 minutes </option>
                                            <option value="">40 minutes </option>
                                            <option value="">50 minutes </option>
                                            <option value="">60 minutes </option>
                                            <option value="">70 minutes</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select category</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Account Changes</option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select executive</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                            <option value="">John Cart </option>
                                            <option value="">Kendra Lust </option>
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="note border rounded">
                                <label class="theme-color02">Note</label>
                                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut venenatis mauris augue. Phasellus sed convallis nisi, vitae consectetur nibh. Aliquam facilisis ipsum et erat sollicitudin, non rhoncus ex luctus. Aenean pellentesque consectetur semper. Nulla vehicula eros eget convallis maximus. Nulla dapibus vulputate nisi, quis placerat elit. Proin tincidunt sem at eleifend hendrerit. Mauris a rutrum dolor. Duis mauris risus, vestibulum at lacinia sed, dictum nec dui.</p>
                            </div>
                        </div>
                        <div class="notify_box collapse DateTime">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select date</label>
                                        <div class="dateicon">
                                            <input type="text" id="SelectDate" readonly="true" class="form-control datetimepicker-input" data-target="#SelectDate" data-toggle="datetimepicker" placeholder="DD/MM/YYYY" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select time</label>
                                        <div class="timeicon">
                                            <input type="text" id="SelectTime" readonly="true" class="form-control datetimepicker-input" data-target="#SelectTime" data-toggle="datetimepicker" placeholder="HH/MM"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select category</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Account Changes</option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select executive</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                            <option value="">John Cart </option>
                                            <option value="">Kendra Lust </option>
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="note border p-3 rounded">
                                <label class="theme-color02">Note</label>
                                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut venenatis mauris augue. Phasellus sed convallis nisi, vitae consectetur nibh. Aliquam facilisis ipsum et erat sollicitudin, non rhoncus ex luctus. Aenean pellentesque consectetur semper. Nulla vehicula eros eget convallis maximus. Nulla dapibus vulputate nisi, quis placerat elit. Proin tincidunt sem at eleifend hendrerit. Mauris a rutrum dolor. Duis mauris risus, vestibulum at lacinia sed, dictum nec dui.</p>
                            </div>
                        </div>

                    </div>
                    <div class="field_box collapse Resolved">
                        <div class="note border p-3 rounded">
                            <label class="theme-color02">Note</label>
                            <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut venenatis mauris augue. Phasellus sed convallis nisi, vitae consectetur nibh. Aliquam facilisis ipsum et erat sollicitudin, non rhoncus ex luctus. Aenean pellentesque consectetur semper. Nulla vehicula eros eget convallis maximus. Nulla dapibus vulputate nisi, quis placerat elit. Proin tincidunt sem at eleifend hendrerit. Mauris a rutrum dolor. Duis mauris risus, vestibulum at lacinia sed, dictum nec dui.</p>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="button" class="btn btn-primary text-uppercase ripple-effect-dark font-bk" data-dismiss="modal">FINISH CALL</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- edit history Modal -->
<div class="modal fade common-modal add_note" id="EditHistory" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="viewHestoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header ">
                <div class="col text-left p-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="col p-0 text-center">
                    <h5 class="modal-title" id="viewHestoryModalLabel">Edit</h5>
                </div>
                <div class="col p-0 text-center">

                </div>
            </div>
            <div class="modal-body">
                <form action="">
                    <div class="form-group input_wrap">
                        <label class="theme-color02 d-block">Request Status</label>
                        <label class="i-checks">
                            <input type="radio" name="status" checked onchange="status_radio('Pending');"><i></i> Pending 
                        </label>
                        <label class="i-checks ml-2 ml-sm-3">
                            <input type="radio" name="status"  onchange="status_radio('Resolved');"><i></i> Resolved 
                        </label>
                    </div>
                    <div class="field_box Pending">
                        <div class="form-group">
                            <label class="theme-color02 d-block">Notify me</label>
                            <div class="form-check form-check-inline">
                                <label class="i-checks">
                                    <input type="radio" name="notify" checked onchange="notify_radio('UserOnline');"><i></i> When user back online 
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="i-checks">
                                    <input type="radio" name="notify" onchange="notify_radio('Today');"><i></i> Today 
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="i-checks">
                                    <input type="radio" name="notify" onchange="notify_radio('DateTime');"><i></i> Select date & time 
                                </label>
                            </div>
                        </div>
                        <div class="notify_box UserOnline">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select category</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Account Changes</option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select executive</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                            <option value="">John Cart </option>
                                            <option value="">Kendra Lust </option>
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="note border p-3 rounded">
                                <label class="theme-color02">Note</label>
                                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut venenatis mauris augue. Phasellus sed convallis nisi, vitae consectetur nibh. Aliquam facilisis ipsum et erat sollicitudin, non rhoncus ex luctus. Aenean pellentesque consectetur semper. Nulla vehicula eros eget convallis maximus. Nulla dapibus vulputate nisi, quis placerat elit. Proin tincidunt sem at eleifend hendrerit. Mauris a rutrum dolor. Duis mauris risus, vestibulum at lacinia sed, dictum nec dui.</p>
                            </div>
                        </div>
                        <div class="notify_box collapse Today">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Notify in</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">10 minutes</option>
                                            <option value="">20 minutes </option>
                                            <option value="">30 minutes </option>
                                            <option value="">40 minutes </option>
                                            <option value="">50 minutes </option>
                                            <option value="">60 minutes </option>
                                            <option value="">70 minutes</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select category</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Account Changes</option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select executive</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                            <option value="">John Cart </option>
                                            <option value="">Kendra Lust </option>
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="note border p-3 rounded">
                                <label class="theme-color02">Note</label>
                                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut venenatis mauris augue. Phasellus sed convallis nisi, vitae consectetur nibh. Aliquam facilisis ipsum et erat sollicitudin, non rhoncus ex luctus. Aenean pellentesque consectetur semper. Nulla vehicula eros eget convallis maximus. Nulla dapibus vulputate nisi, quis placerat elit. Proin tincidunt sem at eleifend hendrerit. Mauris a rutrum dolor. Duis mauris risus, vestibulum at lacinia sed, dictum nec dui.</p>
                            </div>
                        </div>
                        <div class="notify_box collapse DateTime">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select date</label>
                                        <div class="dateicon">
                                            <input type="text" id="SelectDate01" readonly="true" class="form-control datetimepicker-input" data-target="#SelectDate01" data-toggle="datetimepicker" placeholder="DD/MM/YYYY"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select time</label>
                                        <div class="timeicon">
                                            <input type="text" id="SelectTime01" readonly="true" class="form-control datetimepicker-input" data-target="#SelectTime01" data-toggle="datetimepicker" placeholder="HH/MM"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select category</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Account Changes</option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                            <option value="">Tech Support </option>
                                            <option value="">Technical Support </option>
                                            <option value="">Product Upgrade </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group input_wrap">
                                        <label class="control-label">Select executive</label>
                                        <select class="selectpicker select-custom " data-size="4">
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                            <option value="">John Cart </option>
                                            <option value="">Kendra Lust </option>
                                            <option value="">Michal Corn</option>
                                            <option value="">Jenifer Mart </option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="note border p-3 rounded">
                                <label class="theme-color02">Note</label>
                                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut venenatis mauris augue. Phasellus sed convallis nisi, vitae consectetur nibh. Aliquam facilisis ipsum et erat sollicitudin, non rhoncus ex luctus. Aenean pellentesque consectetur semper. Nulla vehicula eros eget convallis maximus. Nulla dapibus vulputate nisi, quis placerat elit. Proin tincidunt sem at eleifend hendrerit. Mauris a rutrum dolor. Duis mauris risus, vestibulum at lacinia sed, dictum nec dui.</p>
                            </div>
                        </div>

                    </div>
                    <div class="field_box collapse Resolved">
                        <div class="note border p-3 rounded">
                            <label class="theme-color02">Note</label>
                            <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut venenatis mauris augue. Phasellus sed convallis nisi, vitae consectetur nibh. Aliquam facilisis ipsum et erat sollicitudin, non rhoncus ex luctus. Aenean pellentesque consectetur semper. Nulla vehicula eros eget convallis maximus. Nulla dapibus vulputate nisi, quis placerat elit. Proin tincidunt sem at eleifend hendrerit. Mauris a rutrum dolor. Duis mauris risus, vestibulum at lacinia sed, dictum nec dui.</p>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="button" class="btn btn-primary text-uppercase ripple-effect-dark font-bk" data-dismiss="modal">FINISH CALL</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
    function status_radio(value) {
        $(".field_box").hide();
        $("." + value).show();
    }
    function notify_radio(value) {
        $(".notify_box").hide();
        $("." + value).show();
    }
    // function edit_history() {
    //     $("#EditHistory").modal("show");
    // }
</script>