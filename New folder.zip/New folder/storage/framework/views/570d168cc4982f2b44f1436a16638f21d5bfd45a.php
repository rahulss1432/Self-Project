<?php if(count($executives) >0): ?>
<table class="table admin-table" id="data_table">
    <thead>
    <th>Merchant Name</th>
    <th>SE Assigned</th>
    <th>Support Department</th>
    <th>Request generate date</th>
    <th>Request Status</th>
    <!--<th>Request Category</th>-->
    <th>Total time of Call</th>
    <th class="th_action no-sort">Action</th>
</thead>
<tbody>
    <?php $__currentLoopData = $executives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <?php echo e($data->customerDetail->contact_name); ?>

        </td>
        <td>
           <?php echo e($data->executiveDetail->contact_name); ?>

        </td>
        <td>
           <?php echo e($data->BankCategory->name); ?> 
        </td>
        <td>
            <?php
            $generateDate = date('d M Y', strtotime($data->created_at));
            echo $generateDate;
            ?>
        </td>
        <td>
            <?php if($data->status == "resolved"): ?>
            <div class="user_status resolved">
                <span>Resolved</span>
            </div>
            <?php else: ?>
            <div class="user_status pending">
                <span>Pending</span>
            </div>
            <?php endif; ?>            
        </td>
        <!--<td>Technical Support</td>-->
        <td>
            <div class="user_tym">
                <i class="far fa-clock"></i> <?php echo e($data->call_time); ?> mins
            </div>
        </td>
        <td class="action">
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-h"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="<?php echo e(url('admin/support-executive-request-note-view/'.$data->id)); ?>">View</a>
                </div>
            </div>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center><?php echo e(\Config::get('constants.no_record_found')); ?></center></div>
<?php endif; ?>