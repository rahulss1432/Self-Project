<?php $__env->startSection('title', 'Notifications'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-content innerpages notifications-page" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Notifications List</h4>
            </div>
            <div class="card-body">
                <ul class="notification_list list-unstyled" id="notificationlist">
                </ul>
            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function () {
        getnotificationlist();
        setTimeout(function () {
            $("#loadPagination").fadeIn('500');
        }, 2000)
    });
    function getnotificationlist() {
        $("#notificationlist").html('<div class="listloader text-center pb-4"><i class="fa-2x fa-spin fas fa-spinner"></i></div>');
        var url = "<?php echo e(url('manager/notification-list')); ?>";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                setTimeout(function () {
                    $("#notificationlist").html("");
                    $("#notificationlist").hide().html(response.html).fadeIn('2000');
                }, 2000);
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('manager.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>