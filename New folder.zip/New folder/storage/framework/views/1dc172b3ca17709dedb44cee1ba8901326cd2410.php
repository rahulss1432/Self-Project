<?php $__env->startSection('title', 'Bail Bondsmans'); ?>
<?php $__env->startSection('content'); ?>
<body class="bg-light-gray" onload="hide_preloader();" id="searchForm">
  <?php echo $__env->make('admin.layouts.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main class="main-content common-grid-list" id="mainContent">
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page-content" id="pageContent">
      <div class="card custom_card" id="card_height">
        <div class="card-header">
          <h4 class="page-title float-left">Bail Bondsmans</h4>
          <ul class="list-inline mb-0 text-right">
            <li class="list-inline-item">
              <a id="add-loader" onclick="addfunction()" href="<?php echo e(url('admin/add-bailbondsman')); ?>" class="nav-link"><i class="fa fa-plus"></i></a>
            </li>
            <li class="list-inline-item">
              <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="fa fa-search"></i></a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <div class="filter_section collapse show" id="searchFilter">
              <form id="search_form" action="javascript:load_bailbondsman_list();" method="post" autocomplete="off">
                 <?php echo e(csrf_field()); ?>

                <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                    <div class="form-group">
                      <label class="control-label">User Type</label>
                      <select id="user_type_change" class="form-control form-control-lg selectpicker" name="user_type">
                        <option value="">Select Type</option>
                        <option value="premium">Premium Bail Bondsman</option>
                        <option value="basic">Basic Bail Bondsman</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                    <div class="form-group">
                      <label>State</label>
                      <select id="state_change" name="state" onchange="selectCity(this.value,''),$(this).valid()" class="form-control form-control-lg selectpicker">
                        <option value="">Select State</option>
                        <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div> 
                  <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                    <div class="form-group">
                      <label>City</label>
                      <select name="city" id="city" onchange="$(this).valid()" class="form-control form-control-lg selectpicker">
                        <option value="">Select City</option>
                      </select>
                    </div>
                  </div> 
                  <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                    <div class="form-group">
                      <label>Status</label>
                      <select id="status_change" name="status" class="form-control form-control-lg selectpicker">
                        <option value="">Select Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">De-active</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                    <div class="form-group">
                      <label class="control-label">Name</label>
                      <input id="user_name" name="name" type="text" class="form-control form-control-lg"/>
                    </div>
                  </div> 
                  <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                    <div class="form-group">
                      <label class="control-label">Email</label>
                      <input id="user_email" name="email" type="text" class="form-control form-control-lg"/>
                    </div>
                  </div> 
                  <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                    <div class="form-group">
                      <label class="control-label">Mobile</label>
                      <input id="user_phone" name="phone" type="text" class="form-control form-control-lg"/>
                    </div>
                  </div> 
                  <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                    <div class="form-group d-inline-block mr-2">
                      <label class="btn-block d-none d-sm-block">&nbsp;</label>
                      <button class="btn btn-primary" type="submit">Filter</button>
                    </div>
                    <div class="form-group d-inline-block mr-2">
                      <label class="btn-block d-none d-sm-block">&nbsp;</label>
                      <input id="reset-btn" type="reset" class="btn btn-primary" value="reset">
                    </div>
                  </div> 
                </div>
              </form>
            </div>
          <div class="table-responsive" id="bailbondsman_list"></div>
        </div>
      </div>
    </div>
  </main>

  <script type="text/javascript">

    $( "#reset-btn" ).click(function() 
    {
      $('#user_type_change').val('').change();
      $('#state_change').val('').change();
      $('#city').val('').change();
      $('#status_change').val('').change();
      $('#user_name').val('').change();
      $('#user_email').val('').change();
      $('#user_phone').val('').change();
      load_bailbondsman_list();
    });


    $(document).ready(function () 
    {
      load_bailbondsman_list();
    });

    function addfunction()
    {
      $("#add-loader").attr("disabled", true);
      $("#add-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    };

    function load_bailbondsman_list()
    {
      $("#bailbondsman_list").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
      var search_filter=$("#search_form").serializeArray();
      search_filter.push('_token', '<?php echo e(csrf_token()); ?>');

      $.ajax({
              type: "POST",
              url: "<?php echo e(url('admin/load-bailbondsman-list')); ?>",
              data: search_filter,
              success: function (response)
              {
                $("#bailbondsman_list").html(response.html);
                $('#data_table').DataTable({
                        searching: false,
                        "order": [],
                        "columnDefs": [{"targets"  : [6,7],"orderable": false,}],
                });
              }
            });
    }

    
    function viewfunction(id)
    {
      $("#view-loader"+id).attr("disabled", true);
      $("#view-loader"+id).html('<i class="fa fa-spinner fa-spin"></i>');
    };


    function editfunction(id)
    {
      $("#edit-loader"+id).attr("disabled", true);
      $("#edit-loader"+id).html('<i class="fa fa-spinner fa-spin"></i>');
    };


    function activeInacive(id , status)
    {
      if(status == 'active')
      {
        var msg = "Are you sure you want to deactivate this bail bondsman?";
      }
      else  if(status == 'inactive')
      {
        var msg = "Are you sure you want to activate this bail bondsman?";
      }
      bootbox.confirm(msg, function (result)
      {
        if (result)
        {
          $.ajax({
                    type: "POST",
                    url: "<?php echo e(url('admin/active-inactive')); ?>/" + id,
                    data: {'_token':'<?php echo e(csrf_token()); ?>'},
                    success: function (response)
                    {
                      if (response)
                      {
                        toastr.remove();
                        toastr.options.closeButton = true;
                        load_bailbondsman_list();
                        toastr.success('Status updated successfully', 'Success', {timeOut: 2000});
                      }
                      else
                      {
                        toastr.remove();
                        toastr.options.closeButton = true;
                        toastr.error('Something went wrong', 'Error', {timeOut: 2000});
                      }
                    }
                  });
        }
        else
        {
          if(status == 'active')
          {
            $('#enable_a_'+id).attr('checked',true);
          }
          else
          {
            $('#enable_a_'+id).attr('checked',false);
          }
        }
      });
    }


    function selectCity(id,city_id) 
    {
      if(id !='')
      {
        var token = '<?php echo e(csrf_token()); ?>';
        $.ajax({
                url: "<?php echo e(url('admin/select-cities')); ?>",
                data: {_token: token,id:id,city_id:city_id},
                type: 'POST',
                success: function (city)
                {
                  $('#city').html(city.html);
                  $('#city').selectpicker('refresh');
                },
                error: function (city)
                {
                  console.log('an error occurred');
                }
              });
      }
      else
      {
        
        $('#city').html('<option value="">Select City</option>');
        $('#city').selectpicker('refresh');
      }
    }
  

    function deletefunction(id)
    {
      bootbox.confirm('Are you sure do you want to delete this Bail Bondsman?', function (result)
      { 
        if (result)
        {
          $.ajax({
                  type: "GET",
                  url: "<?php echo e(url('admin/delete-user')); ?>/" + id,
                  success: function(response)
                  {
                    if (response)
                    {

                       toastr.remove();
                        toastr.options.closeButton = true;
                        toastr.success('Bail bondsman deleted successfully', 'Success', {timeOut: 1000});
                        document.getElementById('bailbondsman'+id).style.display = 'none';

                    }
                    else
                    {

                      toastr.remove();
                      toastr.options.closeButton = true;
                      toastr.error('Something went wrong', 'Error', {timeOut: 1000});

                    }
                  }
                });
        }
      });
    }
    $(document).ready(function(){
       
       $('.form-control').on('keyup',function(){
          if($(this).val()!=''){
            $(this).addClass('i-focused');
          }else {
            $(this).removeClass('i-focused');
          }
         
        
       });
    })
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>