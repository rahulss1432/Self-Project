<?php if(count($managers) >0): ?>
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Company Name</th>
            <th>Phone number</th>
            <th>Type</th>
            <th>Created Date</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>        
        <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $bankName = \App\Http\Models\Bank::getBankByDucument($data->bank_id);
        ?>
        <tr id="<?php echo e('managers'.$data->id); ?>">
            <td><?php echo e($data->first_name.' '.$data->last_name); ?></td>
            <td><?php echo e($data->email); ?></td>
            <td><?php echo e(!empty($bankName->name) ? $bankName->name : '-'); ?></td>
            <td><?php echo e($data->phone_number); ?></td>
            <td><?php echo e($data->manager_type); ?></td>
            <td><?php echo e($data->created_at); ?></td>
            <td>
                <div class="switch">
                    <label>
                        <input id="userStatus_<?php echo e($data->id); ?>" type="checkbox" onclick='changeStatus("<?php echo e($data->id); ?>" , "<?php echo e($data->status); ?>")' <?php echo e($data->status == 'active' ? 'checked':''); ?> >
                        <span class="lever" for="userStatus_<?php echo e($data->id); ?>"></span>
                    </label>
                </div>
            </td>
            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="<?php echo e(url('admin/manager-view',$data->id)); ?>">View</a>
                        <a class="dropdown-item" href="<?php echo e(url('admin/manager-edit',$data->id)); ?>">Edit</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick='changeStatus("<?php echo e($data->id); ?>" , "deleted")'>Delete</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="changePassword('<?php echo e($data->id); ?>')">Change Password</a>
                    </div>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center><?php echo e(\Config::get('constants.no_record_found')); ?></center></div>
<?php endif; ?>