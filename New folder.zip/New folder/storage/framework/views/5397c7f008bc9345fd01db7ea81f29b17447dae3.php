<!--footer-->
<div class="overlay-screen"></div>
<footer class="dashboard-footer" id="footer">
    <div class="footer-in d-flex justify-content-between align-items-center">
        <div class="copyright-text">
            <span class="and-font">&copy;</span> 2018 <strong>Rezieo</strong>. All Rights Reserved.
        </div>
        <ul class="list-inline footer-social-link mb-0">
           <li class="list-inline-item">
                <a href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Facebook"><i class="fa fa-facebook-f"></i></a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a>
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Google+"><i class="fa fa-google-plus"></i></a>
            </li>
            
        </ul>
    </div>
</footer>
<script src="<?php echo e(url('public/js/tempusdominus-bootstrap-4.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('public/js/jquery.mCustomScrollbar.concat.min.js')); ?>" type="text/javascript"></script>

    <script>
         $(document).ready(function () {
            if ($(window).width() >= 1025) {
                $('.toggle-icon').click(function () {
                    $("body").toggleClass("menu-toggle")
                });
            }
            if ($(window).width() <= 1024) {
                $('.toggle-icon').click(function () {
                    $("body").toggleClass("menu-toggle")
                });
                $('.overlay-screen').click(function () {
                    $("body").removeClass("menu-toggle")
                });

            }
        });

        (function ($) {
            $(window).on("load", function () {
                $(".side_menu").mCustomScrollbar();
            });
            $(window).on("load", function () {
                $(".scroll_notification").mCustomScrollbar();
            });
        })(jQuery);
        
        $(window).resize(function() {
            var chk_account_height = $('#top-header').outerHeight(true);
            var window_height = $(window).height();
            $("#content").css('min-height', window_height - chk_account_height + 28 );
			
			if ($(window).width() <= 1199){	
				var chk_account_height = $('#top-header').outerHeight(true);
				var window_height = $(window).height();
				$("#content").css('min-height', window_height - chk_account_height + 18 );
				}
			
        }).resize();

        $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
            var rippleDiv = $('<span class="ripple-overlay">'),
                    rippleOffset = $(this).offset(),
                    rippleY = e.pageY - rippleOffset.top,
                    rippleX = e.pageX - rippleOffset.left;

            rippleDiv.css({
                top: rippleY - (rippleDiv.height() / 2),
                left: rippleX - (rippleDiv.width() / 2),
                // background: $(this).data("ripple-color");
            }).appendTo($(this));

            window.setTimeout(function () {
                rippleDiv.remove();
            }, 800);
        });
        
         $(function () {
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>