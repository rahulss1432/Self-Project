<script src="<?php echo e(url('public/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('public/js/jsvalidation.js')); ?>"></script>
<script src="<?php echo e(url('public/js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(url('public/js/bootbox.min.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(url('public/css/toastr.min.css')); ?>"/>
<script>
function successToaster(message, title) {
    toastr.remove();
    toastr.options.closeButton = true;
    toastr.success(message, title, {timeOut: 2000});
}
function errorToaster(message, title) {
    toastr.remove();
    toastr.options.closeButton = true;
    toastr.error(message, title, {timeOut: 2000});
}
</script>
<?php if(session()->has('success')): ?>
<script>
    $(document).ready(function () {
        successToaster("<?php echo session('message'); ?>", "<?php echo session('success'); ?>");
    });
</script>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<script>
    $(document).ready(function () {
        errorToaster("<?php echo session('message'); ?>", "<?php echo session('error'); ?>");
    });
</script>
<?php endif; ?>