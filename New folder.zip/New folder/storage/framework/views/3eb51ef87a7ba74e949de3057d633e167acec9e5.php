<?php $__env->startSection('title', 'Linked Notes'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-content requests-page" id="content">
	<section class="tabs_section">
		<div class="row">
            <div class="col-lg-5 col-xl-6 left">
                <ul class="list-unstyled tabs_links d-flex justify-content-start nav nav-tabs" id="myTab" role="tablist">
                    <li class="text-uppercase nav-item"><a id="note-tab" onclick="noteTab();" data-toggle="tab" href="#note" role="tab" aria-controls="note" aria-selected="true" class="nav-link active">NOTE</a></li>
                    <li class="text-uppercase nav-item"><a id="documents-tab" onclick="documentTab();" data-toggle="tab" href="#documents" role="tab" aria-controls="documents" aria-selected="false" class="nav-link">DOCUMENTS</a></li>
                    <li class="text-uppercase nav-item"><a id="history-tab" onclick="historyTab();" data-toggle="tab" href="#history" role="tab" aria-controls="history" aria-selected="false" class="nav-link">NOTES HISTORY</a></li>

                    <div class="search_box ml-auto" id="searchBox">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Document name" aria-label="Document name" aria-describedby="document_button">
                            <div class="input-group-append">
                                <button class="btn bg-transparent border-0" type="button" id="document_button"><i class="icon-search"></i></button>
                            </div>
                        </div>
                    </div>
                </ul>
                <div class="tab-content tabs_content" id="myTabContent">
                    <div class="tab-pane fade show active" id="note" role="tabpanel" aria-labelledby="note-tab">
                        <div class="note_box">
                            <h5>Note</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="documents" role="tabpanel" aria-labelledby="documents-tab">
                        <ul class="document_list list-unstyled" id="documentList">
                            <li><a href="javascript:void(0);" onclick="documentView();">Internal function.doc</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Key use.pdf</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Model E550.txt</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Operate functions.exls</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Card swipe document.pdf</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Internal function.doc</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Model E550.txt</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Key use.pdf</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Operate functions.exls</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Card swipe document.pdf</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Internal function.doc</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Key use.pdf</a></li>
                            <li><a href="javascript:void(0);" onclick="documentView();">Internal function.doc</a></li>
                        </ul>

                        <div class="document_view" id="viewContent" style="display:none;">
                            <div class="d-flex justify-content-between">
                                <h4>Operation function</h4>
                                <a href="javascript:void(0);" onclick="documentClose();">Close</a>
                            </div>
                            <div class="content_text">
                                <h6>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia.</h6>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="history" role="tabpanel" aria-labelledby="history-tab">
                        <div class="document_info">
                            <div class="accordion" id="accordionExample">
                                <div class="card">
                                    <div class="card-header" id="historyheadingOne">
                                        <a href="javascript:void(0);" class="bg-transparent p-0 border-0 collapsed" data-toggle="collapse" data-target="#historyOne" aria-expanded="false" aria-controls="historyOne">
                                            <i class="icon-calendar"></i> 23 Aug 2018 <i class="more-less"></i>
                                        </a>
                                    </div>

                                    <div id="historyOne" class="collapse" aria-labelledby="historyheadingOne" data-parent="#accordionExample">
                                        <div class="card-body">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="historyheadingTwo">
                                        <a href="javascript:void(0);" class="bg-transparent p-0 border-0" data-toggle="collapse" data-target="#historyTwo" aria-expanded="true" aria-controls="historyTwo">
                                            <i class="icon-calendar"></i> 23 Aug 2018 <i class="more-less"></i>
                                        </a>
                                    </div>
                                    <div id="historyTwo" class="collapse show" aria-labelledby="historyheadingTwo" data-parent="#accordionExample">
                                        <div class="card-body">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="historyheadingThree">
                                        <h5 class="mb-0">
                                            <a href="javascript:void(0);" class="bg-transparent p-0 border-0 collapsed" data-toggle="collapse" data-target="#historyThree" aria-expanded="false" aria-controls="historyThree">
                                                <i class="icon-calendar"></i> 23 Aug 2018 <i class="more-less"></i>
                                            </a>
                                        </h5>
                                    </div>
                                    <div id="historyThree" class="collapse" aria-labelledby="historyheadingThree" data-parent="#accordionExample">
                                        <div class="card-body">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="historyheadingFour">
                                        <h5 class="mb-0">
                                            <a href="javascript:void(0);" class="bg-transparent p-0 border-0 collapsed" data-toggle="collapse" data-target="#historyFour" aria-expanded="false" aria-controls="historyFour">
                                                <i class="icon-calendar"></i> 23 Aug 2018 <i class="more-less"></i>
                                            </a>
                                        </h5>
                                    </div>
                                    <div id="historyFour" class="collapse" aria-labelledby="historyheadingFour" data-parent="#accordionExample">
                                        <div class="card-body">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="historyheadingFive">
                                        <h5 class="mb-0">
                                            <a href="javascript:void(0);" class="bg-transparent p-0 border-0 collapsed" data-toggle="collapse" data-target="#historyFive" aria-expanded="false" aria-controls="historyFive">
                                                <i class="icon-calendar"></i> 23 Aug 2018 <i class="more-less"></i>
                                            </a>
                                        </h5>
                                    </div>
                                    <div id="historyFive" class="collapse" aria-labelledby="historyheadingFive" data-parent="#accordionExample">
                                        <div class="card-body">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="historyheadingSix">
                                        <h5 class="mb-0">
                                            <a href="javascript:void(0);" class="bg-transparent p-0 border-0 collapsed" data-toggle="collapse" data-target="#historySix" aria-expanded="false" aria-controls="historySix">
                                                <i class="icon-calendar"></i> 23 Aug 2018 <i class="more-less"></i>
                                            </a>
                                        </h5>
                                    </div>
                                    <div id="historySix" class="collapse" aria-labelledby="historyheadingSix" data-parent="#accordionExample">
                                        <div class="card-body">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="historyheadingSeven">
                                        <h5 class="mb-0">
                                            <a href="javascript:void(0);" class="bg-transparent p-0 border-0 collapsed" data-toggle="collapse" data-target="#historySeven" aria-expanded="false" aria-controls="historySeven">
                                                <i class="icon-calendar"></i> 23 Aug 2018 <i class="more-less"></i>
                                            </a>
                                        </h5>
                                    </div>
                                    <div id="historySeven" class="collapse" aria-labelledby="historyheadingSeven" data-parent="#accordionExample">
                                        <div class="card-body">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in uienply voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat norin proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-4 col-lg-4">
                <div class="machine_sec">
                    <div class="machine_inner">
                        <img src="<?php echo e(url('public/assets/images/machine.jpg')); ?>" alt="img" class="img-fluid">
                    </div>
                    <ul class="btn_list list-inline">
                        <li class="list-inline-item">
                            <div id="myEditDropdown" class="dropdown-content">
                                <a href="javascript:void(0);" class="ripple-effect-dark"><i class="icon-close"></i><span>Clear</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark"><i class="icon-text"></i><span>Text</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark draw"><i class="icon-highlighter"></i><span>Draw</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark"><i class="size_text">2 pt</i><span>Size</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark"><i class="icon-fill"></i><span>Color</span></a>
                            </div>
                            <a href="javascript:void(0);" onclick="myEditToggle()" class="icons edit_btn ripple-effect-dark"><i class="icon-edit"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="addmodal();" class="icons callend_btn ripple-effect-dark"><i class="icon-call-cut"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="icons camera_btn ripple-effect-dark"><i class="icon-photo-camera"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="custom-col-2 col-lg-3 right">
                <div class="profile_detail">
                    <img src="<?php echo e(url('public/assets/images/micah.jpg')); ?>" alt="user" class="img-fluid rounded-circle">
                    <h3>Micah Chan</h3>
                    <span class="bank_name">American Express Bank</span>
                    <div class="info_list">
                        <div class="list d-flex justify-content-between">
                            <p>Merchant no.</p>
                            <span>3218410256</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Product</p>
                            <span>American Express</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Company</p>
                            <span>Codware</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Business name</p>
                            <span>Star Traders</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Business address</p>
                            <span>San Francisco, CA</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Mobile</p>
                            <span>+123 456 7890</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Email</p>
                            <span>john.doe@gmail.com</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</section>
</main>
<?php echo $__env->make('executive.linked-notes.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
    function myEditToggle(){
        $("#myEditDropdown").toggleClass("active");
    }
    $(document).ready(function(){
        $('#searchBox').hide();
    });
    function addmodal(){
       $("#AddNote").modal('show');
    }
    function noteTab(){
        $('#searchBox').hide();
    }
    function documentTab(){
        $('#searchBox').show();
    }
    function historyTab(){
        $('#searchBox').hide();
    }
    function documentView(){
        $('#viewContent').show();
        $('#documentList').hide();
    }
    function documentClose(){
        $('#viewContent').hide();
        $('#documentList').show();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('executive.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>