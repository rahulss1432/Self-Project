<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<?php
if (!defined('BASE_URL')) {
    define('BASE_URL', 'http://localhost/linkedassist-html');
    // define('BASE_URL','http://caption.neuroninc.com/neuron/linkedassist/www/');	
}
if (!defined('IMAGES_URL')) {
    define('IMAGES_URL', 'http://localhost/linkedassist-html/images');
    // define('IMAGES_URL','http://caption.neuroninc.com/neuron/linkedassist/www/assets/images');		
}
?>
<link rel="stylesheet" href="<?php echo e(url('public/css/iocnmoon.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(url('public/css/fontawesome.min.all.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap-select.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(url('public/css/tempusdominus-bootstrap-4.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(url('public/css/custom.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(url('public/css/toastr.min.css')); ?>" type="text/css">

<!-- js script -->
<script src="<?php echo e(url('public/js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('public/js/popper.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('public/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('public/js/bootstrap-select.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('public/js/moment.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('public/js/tempusdominus-bootstrap-4.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('public/js/jsvalidation.min.js')); ?>"></script>
<script src="<?php echo e(url('public/js/toastr.js')); ?>"></script>