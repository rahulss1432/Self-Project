<?php if(count($download) > 0): ?>  
  <table class="table admin-table dataTable no-footer" id="data_table">
    <thead>
      <tr>
        <th>PURCHASE TYPE </th>
        <th>DATE PURCHASED</th>
        <th>AMOUNT PAID</th>
        <th>PAYMENT MODE</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $download; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e('transaction'.$data->id); ?>">
          <td class="text-capitalize"><?php echo e($data->name); ?></td>
          <td><?php echo e($data->start_date); ?></td>
          <td>$ <?php echo e($data->price); ?></td>
          <td class="text-capitalize"><?php echo e($data->payment_mode); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php else: ?>
    <div class="alert alert-danger"><center>No download available of this citizen.</center></div>
<?php endif; ?>