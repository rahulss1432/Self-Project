<?php $__env->startSection('title', 'Manage Cms'); ?>
<?php $__env->startSection('content'); ?>  
<main class="main-content cms-edit" id="mainContent">
    <div class="page-content" id="pageContent">
        <div class="card custom_card" id="card_height">
            <div class="card-header">
                <h4 class="page-title float-left">Edit FAQ</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="<?php echo e(url('admin/faq')); ?>" class="nav-link" title="Back"><i class="ti-arrow-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-xl-8 offset-xl-2">
                        <form method="post" id="editFaqs" class="f-field" action="javascript:void(0);">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="faq_id" value="<?php echo e($editFaqs->id); ?>">
                            <div class="form-group">
                                <input type="text" name="question" class="form-control form-control-lg" placeholder="" value="<?php echo e($editFaqs->question); ?>">
                                <label class="control-label">Question</label>
                            </div>
                            <div class="form-group">
                                <textarea name="answer" class="form-control form-control-lg" rows="5"><?php echo e($editFaqs->answer); ?></textarea>
                                <label class="control-label">Answer</label>
                            </div>
                            <div class="from-group">
                                <button type="submit" id="btnFaqs" onclick="editFaqs();" class="btn btn-sm btn-primary ripple-effect"> 
                                    Update <i id="faqFormLoader" class="fa fa-spinner ml-1 fa-spin" style="display: none;"></i>
                                </button>
                            </div>
                        </form>
                        <?php echo JsValidator::formRequest('App\Admin\Http\Requests\AddFaqRequest','#editFaqs'); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    function editFaqs() {
        var formData = $("#editFaqs").serializeArray();
        formData.push('_token', '<?php echo e(csrf_token()); ?>');
        if ($('#editFaqs').valid()) {
            $('#btnFaqs').prop('disabled', true);
            $('#faqFormLoader').show();
            $.ajax({
                type: "POST",
                url: "<?php echo e(url('admin/edit-faqs')); ?>",
                data: formData,
                success: function (response)
                {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        $('#faqFormLoader').hide();
                        $('#btnFaqs').prop('disabled', false);
                        window.location.href = "<?php echo e(url('admin/faq')); ?>"
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnFaqs').prop('disabled', false);
                        $('#faqFormLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#faqFormLoader').hide();
                    $('#btnFaqs').prop('disabled', false);
                }
            });
        }
    }

    $("textarea").keydown(function () {
        var el = this;
        el.style.cssText = 'height:auto; padding:0';
        el.style.cssText = 'height:' + el.scrollHeight + 'px';
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::include.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>