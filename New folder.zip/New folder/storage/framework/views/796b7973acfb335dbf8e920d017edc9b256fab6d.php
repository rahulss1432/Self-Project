<?php $__env->startSection('title','My Profile'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main class="main-content inner-pages profile-page">
    <div class="container">
        <h1 class="text-uppercase font-bold theme-color inner-heading">
            <a href="javascript:void(0);" class="d-lg-none profile-menu" onclick="openMenu()">
                <img src="<?php echo e(url('public/images/menu-blk.png')); ?>" alt="menu-icon">
            </a>
            my profile
        </h1>
        <div class="profile-wrapper d-lg-flex">
            <?php echo $__env->make('layouts.front.profile-sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- right side start-->
            <div class="right-side-wrap">
                <div class="content-holder">
                    <div class="d-flex justify-content-between">
                        <div class="img-holder">
                            <img src="<?php echo e(\App\Helpers\Utility::checkProfileImage(Auth::user()->profile_image)); ?>" alt="user">
                        </div>

                        <a href="<?php echo e(url('/user/edit-profile')); ?>" class="edit-btn ripple-effect">
                            <img src="<?php echo e(url('public/images/edit-ic.png')); ?>" alt="edit-icon">
                        </a>
                    </div>

                    <div class="view-content">
                        <div class="row">
                            
                            <div class="col-sm-6">
                                <div class="info-set">
                                    <label>First Name</label>
                                    <p class="mb-0"><?php echo e(Auth::user()->first_name); ?></p>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="info-set">
                                    <label>Lase Name</label>
                                    <p class="mb-0"><?php echo e(Auth::user()->last_name); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-set">
                                    <label>Email</label>
                                    <p class="mb-0"><?php echo e(Auth::user()->email); ?></p>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="info-set">
                                    <label>Mobile Number</label>
                                    <p class="mb-0"><?php echo e(Auth::user()->phone); ?></p>
                                </div>
                            </div>

                           <div class="col-sm-6">
                                <div class="info-set">
                                    <label>DOB</label>
                                    <p class="mb-0"><?php echo e(\App\Helpers\Utility::getDateFormat(Auth::user()->date_of_birth)); ?></p>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="info-set">
                                    <label>Address</label>
                                    <p class="mb-0"><?php echo e((!empty(Auth::user()->address))?Auth::user()->address:'-'); ?></p>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="info-set">
                                    <label>Zip</label>
                                    <p class="mb-0"><?php echo e((!empty(Auth::user()->zipcode))?Auth::user()->zipcode:'-'); ?></p>
                                </div>

                            </div>

                            

                            <div class="col-sm-6">
                                <div class="info-set">
                                    <label>State</label>
                                    <p class="mb-0"><?php echo e((!empty(Auth::user()->state))?Auth::user()->state:'-'); ?></p>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="info-set">
                                    <label>City</label>
                                    <p class="mb-0"><?php echo e((!empty(Auth::user()->city))?Auth::user()->city:'-'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>