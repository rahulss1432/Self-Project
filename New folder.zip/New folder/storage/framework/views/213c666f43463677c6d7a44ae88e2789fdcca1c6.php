<?php if(count($category) >0): ?>
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Created Date</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>     
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e('category'.$data->id); ?>">
            <td><?php echo e($data->name); ?></td>
            <td><?php echo e($data->created_at); ?></td>
<!--            <td>
                <label class="switch">
                    <div class="statusbtn">
                        <label class="switch">
                            <input id="enable_a_<?php echo e($data['id']); ?>" type="radio" onclick="activeInacive(<?php echo e($data->id); ?>,'<?php echo e($data->status); ?>')" value="active" name="radio_<?php echo e($data['id']); ?>" <?php if($data->status=='active'): ?>) checked="checked" <?php endif; ?> >
                                   <span class="slider round" for="enable_<?php echo e($data['id']); ?>"></span>
                        </label>
                    </div>
                </label>
            </td>-->
            <td>
                <div class="switch">
                    <label>
                        <input id="userStatus_<?php echo e($data->id); ?>" type="checkbox" onclick='activeInacive("<?php echo e($data->id); ?>" , "<?php echo e($data->status); ?>")' <?php echo e($data->status == 'active' ? 'checked':''); ?> >
                        <span class="lever" for="userStatus_<?php echo e($data->id); ?>"></span>
                    </label>
                </div>
            </td>
            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="<?php echo e(url('admin/category-edit',$data->id)); ?>">Edit</a>
                    </div>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center><?php echo e(\Config::get('constants.no_record_found')); ?></center></div>
<?php endif; ?>