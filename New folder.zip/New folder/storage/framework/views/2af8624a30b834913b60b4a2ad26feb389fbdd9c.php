<aside class="side_menu ">
    <ul class="list-unstyled mCustomScrollbar" data-mcs-theme="dark">
        <li class="<?php echo e(( \Request::route()->getName() == 'admin.dashboard') ? 'active' : ''); ?>"><a class="ripple-effect" href="<?php echo e(url('/admin/dashboard')); ?>"> <i class="flaticon-dashboard-interface"></i>   Dashboard</a></li>
        <li class=""><a class="ripple-effect" href="manage-users.php"> <i class="flaticon-multiple-users-silhouette"></i>  Manage Users</a></li>
        <li class=""><a class="ripple-effect" href="manage-ebook.php"> <i class="flaticon-reading"></i>Manage eBook</a></li>
        <li class=""><a class="ripple-effect" href="manage-podcast.php"> <i class="flaticon-podcast-symbol"></i>Manage Podcasts</a></li>
        <li class=""><a class="ripple-effect" href="manage-blog.php"> <i class="flaticon-contract"></i> Manage Blogs</a></li>
        <li class=""><a class="ripple-effect" href="manage-cms.php"> <i class="flaticon-content-management"></i>Manage CMS</a></li>
        <li class=""><a class="ripple-effect" href="manage-transactions.php"> <i class="flaticon-transaction"></i>Manage Transactions</a></li>
    </ul>
</aside> 