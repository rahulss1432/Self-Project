<?php if(!empty($getContractors) && count($getContractors) > 0): ?>
<table class="table admin-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Unique url</th>
            <th class="w-150 text-center">View Documents</th>
            <th class="w-150 text-center">View Categories </th>
            <th>View Availability </th>
            <th>Status</th>
            <th class="w170 text-center">Approve/Disapprove</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $getContractors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contractor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <a href="javascript:void(0);" class="theme-color" onclick="loadContractorDetails('<?php echo e($contractor->id); ?>')"><?php echo e(getFullName($contractor->first_name, $contractor->last_name)); ?></a>
            </td>
            <td><?php echo e($contractor->email); ?></td>
            <td><a href="javascript:void(0);" class="theme-color unique_url" data-toggle="tooltip" data-placement="top" title="https://www.mentolocator.com/charlotten">https://www.mentolocator.com/charlotten</a></td>
            <td class="text-center"><a href="javascript:void(0);" class="icon"><i class="fa fa-file-text-o"></i></a></td>
            <td class="text-center"><a href="<?php echo e(url('admin/manage-category')); ?>" class="icon"><i class="ti-layout-grid3"></i></a></td>
            <td><a href="javascript:void(0);" class="theme-color" onclick="viewAvailibility();">Check Availability</a></td>
            <td>
                <div class="switch">
                    <label>
                        <?php if($contractor->status == 'active'): ?>
                        <input type="checkbox" name="activeInactive"  checked onchange="changeStatus(this,'<?php echo e($contractor->id); ?>')">
                        <?php else: ?>
                        <input type="checkbox" name="activeInactive" onchange="changeStatus(this,'<?php echo e($contractor->id); ?>')">
                        <?php endif; ?>
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
            <td>
                <div class="switch text-center">
                    <label>
                        <input type="checkbox">
                        <span class="lever"></span>
                    </label>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?> 
<div class="alert alert-danger"><center>No record found</center></div>
<?php endif; ?>
<?php echo e($getContractors->links()); ?>

<script>
    $('[data-toggle="tooltip"]').tooltip({trigger: "hover"});
    $(".pagination li a").on('click', function (e) {
    pageDivLoader('show', 'getContractorsList');
    e.preventDefault();
    var $this = $(this);
    var pageLink = $this.attr('href');
    $.ajax({
    type: 'POST',
            url: pageLink,
            async: false,
            data: {_token: '<?php echo e(csrf_token()); ?>'},
            success: function (response) {
            $('.pagination:first').remove();
            $('#getContractorsList').html(response.html);
            }
    });
    });
    $('[data-toggle="tooltip"]').tooltip({trigger: "hover"});
</script>