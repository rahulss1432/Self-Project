<?php $__env->startSection('title', 'Homepage'); ?>
<?php $__env->startSection('content'); ?>
<main class="main_content" id="maincontent" >
            <!-- about us -->
            <section class="aboutus_section common_section text-center" id="aboutus" data-anchor="aboutus">
                <div class="container">
                    <div class="heading">
                        <h2><?php echo e($about->title); ?></h2>
                        <hr>
                    </div>
                    <div class="content">	
                        <?php 
                            echo($about->key_value);
                         ?>
                    </div>
                </div>
            </section>

            <!-- amazing features -->
			<section class="amazingfeatures_section common_section" id="features" data-anchor="features">
                <div class="container">
                    <div class="heading text-center">
                        <h2>Amazing Features</h2>
                        <hr>
                    </div>

                    <ul class="nav tab_list mb-3 " id="pills-tab" role="tablist">
                        <li class="nav-item tab1" >
                            <a class="nav-link active" id="pills-citizen-tab" data-toggle="pill" href="#pills-citizen" role="tab" aria-controls="pills-citizen" aria-selected="true">Citizen</a>
                        </li>
                        <li class="nav-item tab2">
                            <a class="nav-link right" id="pills-lawyer-tab" data-toggle="pill" href="#pills-lawyer" role="tab" aria-controls="pills-lawyer" aria-selected="false">Lawyer</a>
                        </li>
                        <li class="nav-item tab3">
                            <a class="nav-link right" id="pills-bailbondsman-tab" data-toggle="pill" href="#pills-bailbondsman" role="tab" aria-controls="pills-bailbondsman" aria-selected="false">Bail Bondsman</a>
                        </li>
                        <div class="slider"><div class="indicator"></div></div>
                    </ul>


                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-citizen" role="tabpanel" aria-labelledby="pills-citizen-tab">
                            <div class="citizen_tab">
                                <ul class="list-unstyled ">
                                    <li class="first_row clearfix">
                                        <div class="content_box text-center float-md-left" data-aos="fade-left">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/citizen_icon01.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Go Live</h3>
                                            <p>This feature allows the user to start recording their <br class="d-none d-xl-block"> interactions with their fellow officer while streaming <br class="d-none d-xl-block"> the encounter live.</p>
                                        </div>
                                        <div class="content_box text-center float-md-right" data-aos="fade-right">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/citizen_icon02.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Subscribe to View Broadcasts</h3>
                                            <p>This feature allows users to watch live streaming <br class="d-none d-xl-block"> encounters of broadcasted videos.</p>
                                        </div>
                                    </li>
                                    <li class="second_row clearfix">
                                        <div class="content_box text-center float-md-left" data-aos="fade-left">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/citizen_icon03.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Rate an Officer</h3>
                                            <p>This feature allows the user to enter the information<br class="d-none d-xl-block"> of the incident, the officer information and rate their<br class="d-none d-xl-block"> experience.</p>
                                        </div>
                                        <div class="content_box text-center float-md-right" data-aos="fade-right">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/citizen_icon04.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Contact Lawyer</h3>
                                            <p>This feature allows users to contact any lawyer <br class="d-none d-xl-block"> registered within the Cop Merit application.</p>
                                        </div>
                                    </li>
                                    <li class="third_row clearfix">
                                        <div class="content_box text-center float-md-left" data-aos="fade-left">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/citizen_icon05.png')); ?>" alt="icon">
                                            </div>
                                            <h3>View Broadcasted Videos</h3>
                                            <p>This feature allows users to view or download their <br class="d-none d-xl-block">recorded footage.</p>
                                        </div>
                                        <div class="content_box text-center float-md-right mb-0" data-aos="fade-right">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/citizen_icon06.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Upload Ticket</h3>
                                            <p>This feature allows users to take a screenshot of any<br class="d-none d-xl-block"> documentation received from an officer.</p>
                                        </div>
                                    </li>

                                </ul>
                                <div class="circle_animation " >
                                    <div class="spinner">  
                                        <div class="ball ball-1"></div>
                                        <div class="ball ball-2"></div>  
                                        <div class="ball ball-3"></div>  
                                        <div class="ball ball-4"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade"  id="pills-lawyer" role="tabpanel" aria-labelledby="pills-lawyer-tab">
                            <div class="citizen_tab lawyer_tab">
                                <ul class="list-unstyled ">
                                    <li class="first_row clearfix">
                                        <div class="content_box text-center float-md-left" data-aos="fade-left">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/lawyer_icon01.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Advertise Your Company</h3>
                                            <p>This feature allows lawyers to setup a profile and<br class="d-none d-xl-block"> advertise.</p>
                                        </div>
                                        <div class="content_box text-center float-md-right" data-aos="fade-right">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/lawyer_icon02.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Receive Email Communication</h3>
                                            <p>This feature grants access of users to advertised <br class="d-none d-xl-block">lawyers.</p>
                                        </div>
                                    </li>
                                    <li class="second_row clearfix">
                                        <div class="content_box text-center float-md-left" data-aos="fade-left">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/lawyer_icon03.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Receive in application Notifications</h3>
                                            <p>This feature will organize and notify lawyers when <br class="d-none d-xl-block">contact is initiated.</p>
                                        </div>
                                        <div class="content_box text-center float-md-right" data-aos="fade-right">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/lawyer_icon04.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Contact Citizen</h3>
                                            <p>This feature allows users to contact citizen who tried <br class="d-none d-xl-block"> to contact that lawyer within the Cop Merit <br class="d-none d-xl-block">application.</p>
                                        </div>
                                    </li>
                                    <li class="third_row clearfix m-auto">
                                        <div class="content_box text-center m-auto "  data-aos="fade-up" >
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/citizen_icon05.png')); ?>" alt="icon">
                                            </div>
                                            <h3>View Broadcasted Videos</h3>
                                            <p>This feature allows users to view or download their <br class="d-none d-xl-block">recorded footage.</p>
                                        </div>
                                    </li>
                                </ul>
                                <div class="circle_animation " >
                                    <div class="spinner">  
                                        <div class="ball ball-1"></div>
                                        <div class="ball ball-2"></div>  
                                        <div class="ball ball-3"></div>  
                                        <div class="ball ball-4"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade"  id="pills-bailbondsman" role="tabpanel" aria-labelledby="pills-bailbondsman-tab">
                            <div class="citizen_tab lawyer_tab bailbondsman_tab">
                                <ul class="list-unstyled ">
                                    <li class="first_row clearfix">
                                        <div class="content_box text-center float-md-left" data-aos="fade-left">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/lawyer_icon01.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Advertise Your Company</h3>
                                            <p>This feature allows bail bondsman to setup a <br class="d-none d-xl-block">profile and advertise.</p>
                                        </div>
                                        <div class="content_box text-center float-md-right" data-aos="fade-right">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/lawyer_icon02.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Receive Email Communication</h3>
                                            <p>This feature grants access of users to<br class="d-none d-xl-block"> advertised bail bondsman.</p>
                                        </div>
                                    </li>
                                    <li class="second_row clearfix">
                                        <div class="content_box text-center float-md-left" data-aos="fade-left">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/lawyer_icon03.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Receive in application Notifications</h3>
                                            <p>This feature will organize and notify bail<br class="d-none d-xl-block"> bondsman when contact is initiated.</p>
                                        </div>
                                        <div class="content_box text-center float-md-right" data-aos="fade-right">
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/lawyer_icon04.png')); ?>" alt="icon">
                                            </div>
                                            <h3>Contact Citizen</h3>
                                            <p>This feature allows users to contact citizen who tried <br class="d-none d-xl-block"> to contact that bail bondsman within the Cop Merit <br class="d-none d-xl-block">application.</p>
                                        </div>
                                    </li>
                                    <li class="third_row clearfix m-auto">
                                        <div class="content_box text-center m-auto "  data-aos="fade-up" >
                                            <div class="icon m-auto">
                                                <img src="<?php echo e(url('public/assets/images/citizen_icon05.png')); ?>" alt="icon">
                                            </div>
                                            <h3>View Broadcasted Videos</h3>
                                            <p>This feature allows users to view or download their <br class="d-none d-xl-block">recorded footage.</p>
                                        </div>
                                    </li>
                                </ul>
                                <div class="circle_animation " >
                                    <div class="spinner">  
                                        <div class="ball ball-1"></div>
                                        <div class="ball ball-2"></div>  
                                        <div class="ball ball-3"></div>  
                                        <div class="ball ball-4"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </section>
			
            <!-- how it works -->
            <section class="howitworks_section common_section clearfix" id="howitworks">
                <div class="container">
                    <div class="heading text-center">
                        <h2>How it works</h2>
                        <hr>
                    </div>
                    <div class="timeline clearfix">
                        <div class="commoncontainer_timeline timeline_right top" data-aos="fade-up" data-aos-duration="500">
                            <span class="timline_count">01</span>
                            <div class="timeline_img">
                                <img src="<?php echo e(url('public/assets/images/timeline_img02.jpg')); ?>" alt="image'">
                            </div>
                            <div class="timeline_caption">
                                <h3>Register</h3>
                                <p>This feature allows users to register within the Cop Merit application.</p>
                            </div>

                        </div>
                        <div class="commoncontainer_timeline timeline_left " data-aos="fade-up" data-aos-duration="500">
                            <span class="timline_count">02</span>
                            <div class="timeline_img">
                                <img src="<?php echo e(url('public/assets/images/timeline_img01.jpg')); ?>" alt="image'">
                            </div>
                            <div class="timeline_caption">
                                <h3>Go live</h3>
                                <p>This feature allows the user to start recording their <br class="d-none d-xl-block"> interactions with their fellow officer while streaming <br class="d-none d-xl-block"> the encounter live.</p>
                            </div>
                        </div>
                        <div class="commoncontainer_timeline timeline_right" data-aos="fade-up" data-aos-duration="500">
                            <span class="timline_count">03</span>
                            <div class="timeline_img">
                                <img src="<?php echo e(url('public/assets/images/timeline_img03.jpg')); ?>" alt="image">
                            </div>
                            <div class="timeline_caption">
                                <h3>Rate an officer</h3>
                                <p>This feature allows the user to enter the information<br class="d-none d-xl-block">of the incident, the officer information and rate their<br class="d-none d-xl-block"> experience.</p>
                            </div>
                        </div>
                        <div class="commoncontainer_timeline timeline_left " data-aos="fade-up" data-aos-duration="500">
                            <span class="timline_count">04</span>
                            <div class="timeline_img">
                                <img src="<?php echo e(url('public/assets/images/timeline_img04.jpg')); ?>" alt="image">
                            </div>
                            <div class="timeline_caption">
                                <h3>Contact lawyer</h3>
                                <p>This feature allows users to contact any lawyer<br class="d-none d-xl-block"> registered within the Cop Merit application.</p>
                            </div>
                        </div>
                        <div class="commoncontainer_timeline timeline_right" data-aos="fade-up" data-aos-duration="500">
                            <span class="timline_count">05</span>
                            <div class="timeline_img">
                                <img src="<?php echo e(url('public/assets/images/timeline_img05.jpg')); ?>" alt="image">
                            </div>
                            <div class="timeline_caption">
                                <h3>Contact Bail Bondsman</h3>
                                <p>This feature allows users to contact any Bail Bondsman<br class="d-none d-xl-block">registered within the Cop Merit application.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- faq -->
            <section class="faq_section common_section" id="faq">
                <div class="container">
                    <div class="heading text-center">
                        <h2 class="d-inline-block"><?php echo e($faqtitle->title); ?><small>s</small>
                            <hr>
                        </h2>

                    </div>
                    <div class="row">
                        <div class="col-lg-5">
                            <div class="faq_img">
                                <img src="<?php echo e(url('public/assets/images/faq_img.jpg')); ?>" class="img-fluid" alt="img">
                            </div>
                        </div>
                        
                        <div class="col-lg-7">
                            <h3>
                                <?php echo e($faqtitle->key_value); ?>

                            </h3>
                            <div id="accordion" class="faq_details">
                                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key == 0): ?>
                                        <div class="card">
                                            <div class="card-header" id="headingOne<?php echo e($data->id); ?>">
                                                <h5 class="mb-0">
                                                    <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne<?php echo e($data->id); ?>" aria-expanded="true" aria-controls="collapseOne<?php echo e($data->id); ?>">
                                                    <?php echo e($data->question); ?><i class="icon"></i> 
                                                    </button>
                                                </h5>
                                            </div>
                                            <div id="collapseOne<?php echo e($data->id); ?>" class="collapse show" aria-labelledby="headingOne<?php echo e($data->id); ?>" data-parent="#accordion">
                                                <div class="card-body">
                                                    <p><?php echo e($data->answer); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <?php else: ?>
                                            <div class="card">
                                                <div class="card-header" id="headingOne<?php echo e($data->id); ?>">
                                                    <h5 class="mb-0">
                                                        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne<?php echo e($data->id); ?>" aria-expanded="true" aria-controls="collapseOne<?php echo e($data->id); ?>">
                                                            <?php echo e($data->question); ?>

                                                            <i class="icon"></i> 
                                                        </button>
                                                    </h5>
                                                </div>
                                                <div id="collapseOne<?php echo e($data->id); ?>" class="collapse" aria-labelledby="headingOne<?php echo e($data->id); ?>" data-parent="#accordion">
                                                    <div class="card-body">
                                                        <p><?php echo e($data->answer); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="faq_section common_section" id="blog">
                <div class="container">
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div>
            </section>
        </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>