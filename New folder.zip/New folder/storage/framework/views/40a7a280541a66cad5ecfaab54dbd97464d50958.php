<?php if($paginator->hasPages()): ?>
<ul class="pagination">
    
    <?php if($paginator->hasMorePages()): ?>
    <li style="width: 100%">
        <div class="text-center">
            <div id="loadMore" class="load_more">
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">
                    <span id="spinner"><i class="fa fa-spinner fa-spin"></i></span> Load More
                </a>
            </div>
        </div>
    </li>
    <?php endif; ?>
</ul>
<?php endif; ?>
