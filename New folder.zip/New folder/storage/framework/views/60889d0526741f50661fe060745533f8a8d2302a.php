<?php if($seRequest->count()>0): ?>
<thead>
<th colspan="2">NAME</th>
<th>ID</th>
<th>CATEGORY</th>
<th>TOTAL CALL TIME</th>
<th>DATE OF CALL</th>
<th>STATUS</th>
<th width="140">ACTION</th>
</thead>
<tbody>
    <?php $__currentLoopData = $seRequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td width="100" align="right">
            <div class="user_img">
                <img src="<?php echo e(checkProfileImage($data->customerDetail->profile_image)); ?>" alt="user" class="rounded-circle">
            </div>
        </td>
        <td class="min200">
            <div class="user_detail">
                <h4><?php echo e(ucfirst($data->customerDetail->contact_name)); ?></h4>
                <p class="mb-0"><?php echo e(!empty($data->executiveDetail->bank->name) ? $data->executiveDetail->bank->name : ''); ?></p>
            </div>
        </td>
        <td>ID: <?php echo e(!empty($data->UserProfile->merchant_number) ? $data->UserProfile->merchant_number : ''); ?></td>
        <td><?php echo e($data->BankCategory->name); ?></td>
        <td>
            <div class="user_tym">
                <i class="icon-clock"></i> <?php echo e($data->call_time); ?> mins
            </div>
        </td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 
                <?php echo e(showFullMonthDateFormat($data->created_at)); ?>

            </div>
        </td>
        <td>
            <div class="user_status <?php echo e($data->status == 'resolved' ? 'resolved' : 'pending'); ?>">
                <span><?php echo e($data->status); ?></span>
            </div>
        </td>
        <td>
            <ul class="list_btns list-inline mb-0">
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary btn-icon ripple-effect-dark" onClick="viewHestory('<?php echo e($data->id); ?>')"><i class="icon-eye"></i></a></li>
                <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary ripple-effect-dark btn-icon" onclick="editNote('<?php echo e($data->id); ?>');"><i class="icon-pencil"></i></a></li>
            </ul>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<?php else: ?>
<div class="alert alert-danger"><center><?php echo e(\Config::get('constants.no_record_found')); ?></center></div>
<?php endif; ?>
<script>
                    //ripple-effect for button
                    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
            var rippleDiv = $('<span class="ripple-overlay">'),
                    rippleOffset = $(this).offset(),
                    rippleY = e.pageY - rippleOffset.top,
                    rippleX = e.pageX - rippleOffset.left;
                    rippleDiv.css({
                    top: rippleY - (rippleDiv.height() / 2),
                            left: rippleX - (rippleDiv.width() / 2),
                            // background: $(this).data("ripple-color");
                    }).appendTo($(this));
                    window.setTimeout(function () {
                    rippleDiv.remove();
                    }, 800);
            });
</script>