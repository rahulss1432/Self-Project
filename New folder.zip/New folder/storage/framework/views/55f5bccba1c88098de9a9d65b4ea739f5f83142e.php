<?php $__env->startSection('title','Payment History'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-wrapper dashboard-main-wrap payment-history-page" id="content">
    <div class="container-fluid">
        <div class="common-detail-section">
            <div class="top_section align-items-start">
                <!--<a href="invoice.php" target="_blank" class="btn btn-success ripple-effect-dark text-uppercase invoice_btn">View invoice</a>-->
                <nav aria-label="breadcrumb" class="text-right nav-breadcrumb">
                    <ol class="breadcrumb d-inline-flex">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Payment History</li>
                    </ol>
                </nav>
            </div>
            <!--  <div class="content-body">
                <h1 class="page-title">Payment History</h1>
            </div> -->
            <div class="card common-card mt-0">
                <div class="card-body p-0" id="paymentList">

                </div>
            </div>

        </div>
    </div>
</div>
</main>
<script>
    $(document).ready(function () {
        loadPaymentList();
    });

    function loadPaymentList() {
        $("#paymentList").html('<?php echo e(\App\Helpers\Utility::ajaxLoader()); ?>');
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('/user/get-payment-history')); ?>",
            data: {_token: '<?php echo e(csrf_token()); ?>'},
            success: function (response)
            {
                $("#paymentList").html(response);
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>