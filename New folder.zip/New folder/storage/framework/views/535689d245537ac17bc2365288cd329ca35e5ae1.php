<header class="topheader">
    <nav class="navbar navbar-expand-md">
       
            <a class="navbar-brand" href="index.php">
                <img src="<?php echo e(url('public/images/black-logo.png')); ?>" alt="logo" class="blk-logo" />
                <img src="<?php echo e(url('public/images/logo.png')); ?>" alt="logo" class="white-logo"/>
            </a>

            <button class="navbar-toggler ml-auto " type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation" onclick="closeMenu()">
                <span class="ti-menu">
                    <img src="<?php echo e(url('public/images/menu.png')); ?>" alt="menu">
                </span>
            </button>



            <div class="right navbar-collapse collapse " id="navbarCollapse"> 
                <ul class="navbar-nav ml-auto align-items-md-center">
                    <li><a href="#purchaseBook">Purchase book</a></li>
                    <li><a href="#podcast">Podcast</a></li>
                    <li><a href="#blog">Blog</a></li>
                    <li><a href="#danielZeman">Daniel Zeman</a></li>
                    <li class="signup-li"><a href="signup.php">Sign up</a></li>
                    <li class="login-li"><a href="login.php">Login</a></li>

                    <li class="user-pic">
                        <a href="my-profile.php">
                            <img src="<?php echo e(url('public/images/user-02.png')); ?>" alt="user">
                        </a>
                    </li>
                </ul>
            </div>
        
    </nav>   
</header>
