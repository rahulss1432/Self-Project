<?php $__env->startSection('title', 'Manage Executive'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Executive List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="<?php echo e(url('admin/executive-csv-download')); ?>" class="nav-link"><i class="fa fa-cloud-download-alt"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="<?php echo e(url('admin/add-executive')); ?>" class="nav-link"><i class="fa fa-plus"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="fa fa-search"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <div class="filter_section collapse show" id="searchFilter">
                    <form id="search_form" action="javascript:load_executive_list()" method="post" autocomplete="off">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Search</label>
                                    <input type="text" id="name" name="name" class="form-control form-control-lg"/>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                                <div class="form-group">
                                    <?php
                                    $banks = \App\Http\Models\Bank::getBankList();
                                    ?>
                                    <select id="selectBankFilter" name="bank_id" class="form-control selectpicker" select="Search by Bank">
                                        <option value="">Select Bank</option>                                        
                                        <?php if(count($banks)>0): ?>
                                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                                <div class="form-group">
                                    <?php
                                    $categories = \App\Http\Models\BankingCategory::getActiveCategories();
                                    ?>
                                    <select id="selectCategoryFilter" name="category_id" class="form-control selectpicker" select="Search by Category">
                                        <option value="">Select Category</option>                                        
                                        <?php if(count($categories)>0): ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                                <div class="form-group">
                                    <select id="selectStatusFilter" name="status" class="form-control selectpicker" select="Search by Status">
                                        <option value="">Select Status</option>                                        
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <button type="button" class="btn btn-primary ripple-effect-dark mr-2">Search</button>
                                    <button type="button" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="executive_list">
                </div>
            </div>
        </div>
    </div>
</main>

<script type="text/javascript">

    $(document).ready(function ()
    {
        load_executive_list();
    });

    $("#reset-btn").click(function ()
    {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        load_executive_list();
    });

    function load_executive_list()
    {
        $("#executive_list").html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-3x"></i></div>');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '<?php echo e(csrf_token()); ?>');
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('admin/executive-list')); ?>",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    setTimeout(function () {
                        $("#executive_list").html("");
                        $("#executive_list").hide().html(response.html).fadeIn('2000');
                        $("#data_table").DataTable({
                            searching: false,
                            "columnDefs": [{
                                    "targets": 'no-sort',
                                    "orderable": false,
                                }]
                        });
                    }, 2000);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function changeStatus(id, status) {
        var token = '<?php echo e(csrf_token()); ?>';
        if (status == 'deleted') {
            var newStatus = status;
            var confirmMsg = "Are you sure want to delete this executive ?";
        } else {
            var newStatus = status == 'active' ? 'inactive' : 'active';
            var confirmMsg = "Are you sure want to change executive status ?";
        }
        bootbox.confirm(confirmMsg, function (result) {
            if (result == true) {
                $.ajax({
                    url: "<?php echo e(url('/admin/change-user-status')); ?>",
                    type: 'POST',
                    data: {_token: token, id: id, status: newStatus},
                    success: function (response) {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            setTimeout(function () {
                                location.reload();
                            }, 1500);
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            } else {
                if (status == 'active') {
                    $('#userStatus_' + id).prop("checked", true);
                }
                if (status == 'inactive') {
                    $('#userStatus_' + id).prop("checked", false);
                }
            }
        });
    }

    function userChangePassword(id) {
        $.ajax({
            url: "<?php echo e(url('admin/user-change-password')); ?>" + '/' + id,
            type: 'GET',
            success: function (response) {
                if (response.success) {
                    toastrAlertMessage('success', response.message);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>