<?php if(count($users) >0): ?>
<table class="table admin-table" id="data_table">
    <thead>
        <tr>           
            <th>Merchant Number</th>
            <th>Business Name</th>
            <th>Contact Name</th>
            <th>Phone Number</th>
            <th>Machine Model</th>
            <th>City/State</th>
            <th class="th_action no-sort">Action</th>
        </tr>
    </thead>
    <tbody>                 
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                  
        <tr id="<?php echo e('merchant_'.$user->id); ?>">
            <td><?php echo e($user->merchant_number); ?></td>
            <td><?php echo e($user->bussiness_name); ?></td>
            <td><?php echo e(ucfirst($user->contact_name)); ?></td>
            <td><?php echo e($user->phone_number); ?></td>
            <td><?php echo e($user->machine_model); ?></td>
            <td><?php echo e($user->city.','.$user->state); ?></td>
            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="<?php echo e(url('admin/linked-support/'.$user->user_id)); ?>">View</a>
                        <a class="dropdown-item" href="<?php echo e(url('admin/merchant-linked-executive/'.$user->user_id)); ?>">Linked Support</a>
                        <a class="dropdown-item" href="<?php echo e(url('admin/edit-merchant',$user->user_id)); ?>">Edit</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick='changeStatus("<?php echo e($user->user_id); ?>" , "deleted")'>Delete</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="changePassword('<?php echo e($user->user_id); ?>');">Change Password</a>
                    </div>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<div class="alert alert-danger"><center><?php echo e(\Config::get('constants.no_record_found')); ?></center></div>
<?php endif; ?>
<?php if(count($users) >0): ?>
<script>
                    $(document).ready(function(){
            $('#merhantCsv').show();
            });
</script>
<?php endif; ?>
