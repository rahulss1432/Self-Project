<?php

Route::get('/notification', 'NotificationController@index')->name('executive-notification');
Route::get('/notification-list', 'NotificationController@notificationList');
Route::get('/customer-request', 'CustomerRequestController@index')->name('executive-request');
Route::get('/customer-request-list', 'CustomerRequestController@customerRequestList');
Route::get('/linked-history', 'LinkedHistoryController@index')->name('executive-history');
Route::get('/linked-history-list', 'LinkedHistoryController@linkedHistoryList');
Route::get('/linked-history-view', 'LinkedHistoryController@linkedHistoryView');
Route::get('/linked-history-edit', 'LinkedHistoryController@linkedHistoryEdit');
Route::post('/update-se-request', 'LinkedHistoryController@updateExecutiveRequest');
Route::get('/user-profile', 'DashboardController@viewUserProfile');
Route::get('/linked-notes/{id}', 'LinkedNotesController@index');
Route::post('/executive-document-list', 'LinkedNotesController@executiveDocumentsList');
Route::get('/linked-merchant-notes-history-list/{id}', 'LinkedNotesController@linkedMerchantNotesHistoryList');
Route::get('/load-add-note-modal/{id}', 'LinkedNotesController@loadAddNoteModal');
