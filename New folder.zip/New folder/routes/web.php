<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

/* admin routes */
Route::get('admin', 'Admin\AdminController@index');
Route::get('admin/login', 'Admin\AdminController@index');
Route::get('admin/forgot-password', 'Admin\AdminController@forgotPassword');
Route::post('admin/send-forgot-email', 'Admin\AdminController@sendForgotEmail');
Route::get('admin/reset-password/{token}', 'Admin\AdminController@resetPassword');
Route::post('admin/reset-password', 'Admin\AdminController@reset');

Route::post('admin/login', 'Admin\LoginController@login');
Route::get('admin/logout', function() {
    return redirect('admin');
});

Route::group(['namespace' => 'Admin', 'prefix' => 'admin', 'middleware' => 'admin'], function() {
    Route::post('logout', 'LoginController@logout');
    include 'admin-routes.php';
});

/* manager routes */
Route::get('manager', 'Manager\ManagerController@index');
Route::get('manager/login', 'Manager\ManagerController@index');
Route::post('manager/login', 'Manager\LoginController@login');
Route::get('manager/forgot-password', 'Manager\ManagerController@forgotPassword');
Route::post('manager/send-forgot-email', 'Manager\ManagerController@sendForgotEmail');
Route::get('manager/reset-password/{token}', 'Manager\ManagerController@resetPassword');
Route::post('manager/reset-password', 'Manager\ManagerController@reset');
Route::get('manager/logout', function() {
    return redirect('manager');
});
Route::group(['namespace' => 'Manager', 'prefix' => 'manager', 'middleware' => 'manager'], function() {
    Route::post('logout', 'LoginController@logout');
    include 'manager-routes.php';
});

/* executive routes */
Route::get('/', 'Executive\LoginController@showLoginForm');

//Auth::routes();
Route::get('login', function() {
    abort(404);
});
Route::post('login', 'Executive\LoginController@login');
//Route::get('/home', 'HomeController@index')->name('home');
Route::group(['namespace' => 'Executive', 'middleware' => 'executive'], function() {
    Route::post('logout', 'LoginController@logout');
    include 'executive-routes.php';
});



