<?php

Route::get('dashboard', 'DashboardController@index')->name('manager-dashboard');
Route::get('change-password', 'DashboardController@changePassword')->name('manager-change-password');
Route::post('update-password', 'DashboardController@updatePassword');
Route::get('user-change-password/{id}', 'DashboardController@changePasswordById');
Route::get('view-profile', 'DashboardController@viewManagerProfile')->name('manager-view-profile');
Route::post('/content-image-upload', 'DashboardController@contentImageUpload');
/* image cropper routes for profile image */
Route::post('/upload-media-image', 'DashboardController@uploadMedia');
Route::get('/load-image-cropper', 'DashboardController@loadImageCropper');
Route::post('/upload-cropped-image', 'DashboardController@uploadCroppedPicture');

Route::post('change-user-status', 'DashboardController@changeUserStatus');
Route::get('load-change-password/{id}', 'DashboardController@loadChangePasswordModel');
Route::post('update-user-password', 'DashboardController@updateUserPassword');

/* excecutives routes */
Route::get('manage-executives', 'ExecutivesController@index')->name('manage-executives');
Route::post('executives-list', 'ExecutivesController@allExecutives');
Route::get('add-executive', 'ExecutivesController@addExecutive')->name('add-executive');
Route::post('save-executive', 'ExecutivesController@saveExecutive');
Route::post('update-executive', 'ExecutivesController@updateExecutive');
Route::get('edit-executive/{id}', 'ExecutivesController@editExecutive')->name('edit-executive');
Route::get('view-executive/{id}', 'ExecutivesController@viewExecutive')->name('view-executive');
Route::get('merchant-assigned-list/{id}', 'ExecutivesController@assignedMerchantList');

Route::get('support-executive-request', 'ExecutivesController@seRequest')->name('support-executive-request');
Route::post('se-request-list', 'ExecutivesController@SeRequestList');
Route::get('support-executive-view/{id}', 'ExecutivesController@seRequestView')->name('support-executive-request-view');
Route::get('support-executive-view-list', 'ExecutivesController@seRequestViewList');
Route::get('support-executive-request-view-note/{id}', 'ExecutivesController@seRequestNoteView')->name('support-executive-request-view-note');
Route::get('executives-list-csv-download', 'ExecutivesController@executivesListCsvDownload');
Route::get('/executive-request-csv-download', 'ExecutivesController@downloadExecutiveRequestCsv');

/* merchants routes */
Route::get('manage-merchant', 'MerchantController@index')->name('manage-merchant');
Route::post('merchant-list', 'MerchantController@allMerchant');
Route::get('add-merchant', 'MerchantController@addMerchant')->name('add-merchant');
Route::post('save-merchant', 'MerchantController@saveMerchant');
Route::get('edit-merchant/{id}', 'MerchantController@editMerchant')->name('edit-merchant');
Route::post('update-merchant', 'MerchantController@updateMerchant');
Route::get('view-merchant/{id}', 'MerchantController@viewMerchant')->name('view-merchant');
Route::get('linked-support/{id}', 'MerchantController@linkedSupport')->name('manage-merchant');
Route::post('linked-support-list', 'MerchantController@linkedSupportList')->name('manage-merchant');
Route::get('merchant-request', 'MerchantController@merchantRequest')->name('merchant-request');
Route::post('merchant-request-list', 'MerchantController@merchantRequestList');
Route::get('merchant-request-view/{id}', 'MerchantController@merchantRequestView')->name('merchant-request-view');
Route::get('edit-merchant-request-modal/{id}', 'MerchantController@editMerchantRequestModal');
Route::post('update-merchant-request', 'MerchantController@updateMerchantRequest');
Route::get('unassigned-request', 'MerchantController@merchantUnassignedRequest')->name('unassigned-request');
Route::get('unassigned-request-list', 'MerchantController@listUnassignedRequest');
Route::get('unassigned-request-view', 'MerchantController@unassignedRequestView')->name('unassigned-request-view');
Route::get('/merchant-csv-download', 'MerchantController@downloadMerchantCsv');
Route::get('/merchant-request-history-csv-download', 'MerchantController@downloadMerchantRequestHistoryCsv');
Route::get('merchant-linked-executive/{id}', 'MerchantController@merchantLinkedExcutives')->name('merchant-linked-executive');
Route::get('merchant-linked-executive-list', 'MerchantController@merchantLinkedExcutiveList');
Route::get('/merchant-linked-executive-csv-download/{id}', 'MerchantController@downloadMerchantLinkedExecutiveCsv');

/* wiki document routes */
Route::get('manage-document', 'DocumentController@index')->name('manage-document');
Route::post('document-list', 'DocumentController@allDocument');
Route::get('add-document', 'DocumentController@addDocument')->name('add-document');
Route::post('save-document', 'DocumentController@saveDocument');
Route::get('edit-document/{id}', 'DocumentController@editDocument')->name('edit-document');
Route::post('update-document', 'DocumentController@updateDocument');
Route::get('delete-document/{id}', 'DocumentController@deleteDocument');
Route::get('view-document/{id}', 'DocumentController@viewDocument')->name('view-document');

/* call request routes */
Route::get('/call-request', 'CallRequestController@callRequestList')->name('call-request');
Route::post('/call-request-list', 'CallRequestController@AllCallRequestlist');
Route::get('call-request-view/{id}', 'CallRequestController@callRequestView')->name('call-request-view');
Route::get('/call-request-csv-download', 'CallRequestController@downloadCallRequestCsv');
/* End */

/* notification routes */
Route::get('notifications', 'NotificationController@notifications')->name('notifications');
Route::get('notification-list', 'NotificationController@listNotificationList');
/* End */