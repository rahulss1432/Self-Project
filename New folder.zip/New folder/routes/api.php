<?php

use Illuminate\Http\Request;

/*
  |--------------------------------------------------------------------------
  | API Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register API routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | is assigned the "api" middleware group. Enjoy building your API!
  |
 */

Route::group(['namespace' => 'Api'], function() {

    Route::get('country-list', 'CommonController@getCountry');
    Route::get('state-list', 'CommonController@getState');
    Route::get('city-list', 'CommonController@getCity');
    
    Route::post('signup', 'UserController@signup');
    Route::post('login', 'AccountController@login');
    Route::post('resend-code', 'UserController@sendOTP');
    Route::post('verify-code', 'UserController@OTPVerify');
    Route::post('forgot-password', 'UserController@forgotPassword');
    Route::post('reset-password', 'UserController@resetPassword');
    
    Route::group(['middleware' => 'jwt.auth'], function () {

        Route::post('/logout', 'AccountController@logout');
        Route::post('/update-profile', 'UserController@updateProfile');
        Route::get('/user-detail', 'UserController@getUser');
        Route::post('/add-availability', 'MentorController@addAvailability');
        Route::post('/edit-availability', 'MentorController@editAvailability');
        Route::get('/get-availability', 'MentorController@getAvailability');
        Route::delete('/delete-availability', 'MentorController@deleteAvailability');
    });
});
