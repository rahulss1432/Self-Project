<?php
if (!defined('BASE_URL')) {
   	define('BASE_URL', 'http://localhost/mentoradmin-html');
        // define('BASE_URL','http://caption.neuroninc.com/neuron/mentor_locator/www');	
}
if (!defined('IMAGES_URL')) {
   define('IMAGES_URL', 'http://localhost/mentoradmin-html/images');
    // define('IMAGES_URL','http://caption.neuroninc.com/neuron/mentor_locator/www/images');		
}
?>