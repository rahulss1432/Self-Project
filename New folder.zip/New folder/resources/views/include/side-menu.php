<aside class="sidemenu" >
    <div class="sidebar-wrapper">
        <div class="logo">
            <img src="../images/logo.png" alt="logo" class="img-fluid">      
        </div>
        <ul  id="nav-aside" class="nav flex-column mCustomScrollbar sidenav" data-mcs-theme="minimal-dark">
            <li class="nav-item <?php if($current == 'dashboard') {echo 'active';} ?>">
                <a class="nav-link" href="<?php echo BASE_URL ?>/admin/dashboard.php"><i class="ti-home"></i>Dashboard</a>
            </li>
            <li class="nav-item <?php if($current == 'contractors') {echo 'active';} ?>">
                <a class="nav-link" href="<?php echo BASE_URL ?>/admin/manage-contractors.php"><i class="ti-user"></i>Manage Contractors</a>
            </li>
            <li class="nav-item <?php if($current == 'manage-user') {echo 'active';} ?>">
                <a class="nav-link" href="<?php echo BASE_URL ?>/admin/manage-user.php"><i class="ti-user"></i>Manage User</a>
            </li>
            <li class="nav-item <?php if($current == 'manage-categories') {echo 'active';} ?>">
                <a class="nav-link" href="<?php echo BASE_URL ?>/admin/manage-category.php"><i class="ti-layout-grid3"></i>Manage Category</a>
            </li>
            <li class="nav-item <?php if($current == 'manage-booking') {echo 'active';} ?>">
                <a class="nav-link" href="<?php echo BASE_URL ?>/admin/manage-booking.php"><i class="ti-bookmark-alt"></i>Manage Bookings</a>
            </li>
            <li class="nav-item <?php if($current == 'payment-report') {echo 'active';} ?>">
                <a class="nav-link" href="<?php echo BASE_URL ?>/admin/manage-payment-report.php"><i class="fa fa-credit-card"></i>Payment Report</a>
            </li>
            <li class="nav-item <?php if($current == 'contractors-payment') {echo 'active';} ?>">
                <a class="nav-link" href="<?php echo BASE_URL ?>/admin/contractors-payment.php"><i class="fa fa-money"></i>Contractors Payment</a>
            </li>
            <li class="nav-item <?php if($current == 'manage-commission') {echo 'active';} ?>">
                <a class="nav-link" href="<?php echo BASE_URL ?>/admin/manage-commission.php"><i class="ti-money"></i>Manage Commission</a>
            </li>
            <li class="nav-item <?php if($current == 'manage-flagged') {echo 'active';} ?>">
                <a class="nav-link" href="<?php echo BASE_URL ?>/admin/manage-flagged.php"><i class="ti-flag-alt"></i>Manage Flagged</a>
            </li>
            <li class="nav-item <?php if($current == 'reviews-posts') {echo 'active';} ?>">
                <a class="nav-link" href="<?php echo BASE_URL ?>/admin/reviews-and-posts.php"><i class="ti-share-alt"></i>Reviews and Posts</a>
            </li>
             <li class="nav-item <?php if($current == 'notificatios') {echo 'active';} ?>">
                <a class="nav-link" href="<?php echo BASE_URL ?>/admin/notification.php"><i class="ti-bell"></i>Notifications</a>
            </li>
        </ul>
    </div>
</aside>
