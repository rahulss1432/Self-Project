<?php include_once 'constant.php'; ?>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<!-- links -->
    <link href="<?php echo BASE_URL ?>/css/bootstrap-select.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo BASE_URL ?>/css/themify-icons.css" rel="stylesheet" type="text/css">
    <link href="<?php echo BASE_URL ?>/css/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css">
    <link href="<?php echo BASE_URL ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo BASE_URL ?>/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo BASE_URL ?>/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo BASE_URL ?>/css/admin.min.css" rel="stylesheet" type="text/css">