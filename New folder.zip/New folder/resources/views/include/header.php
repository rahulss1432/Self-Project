<header id="header">
    <nav class="navbar navbar-light justify-content-between bg-transparent">

        <h3 class="page-title">
            <a href="javascript:void(0);" onclick="openSideMenu();" class="toggle-icon">
                <i class="ti-menu-alt"></i>
            </a>
            <?php echo $currentPageName ?></h3>
        <ul class="nav">
             <li class="dropdown notification ">
		<a href="javascript:void(0);" class="dropdown-toggle" id="dropdownMenuButton01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			<i class="ti-bell"></i>
			<span class="count">20</span>
		</a>
		  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton01">
			<div class="head">
				<h3 class="font-hy mb-0">Notifications</h3>
			</div>
			<div class="noti_body">
				<ul class="list-unstyled mCustomScrollbar" data-mcs-theme="minimal-dark">
					<li>
						<a href="javascript:void(0);">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
						</a>
					</li>
					<li>
						<a href="javascript:void(0);">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
						</a>
					</li>
					<li>
						<a href="javascript:void(0);">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
						</a>
					</li>
					<li>
						<a href="javascript:void(0);">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
						</a>
					</li>
					<li>
						<a href="javascript:void(0);">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
						</a>
					</li>
					<li>
						<a href="javascript:void(0);">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
						</a>
					</li>

				</ul>
			</div>
			<div class="noti_footer text-center">
				<a href="<?php echo BASE_URL ?>/admin/notification.php" class="d-block">View All</a>
			</div>
		  </div>
  </li> 
            <li class="dropdown nav-item mr-0 user-dropdwon">
                <a class="bg-transparent dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="ti-user"></i>
                </a>
                <div class="dropdown-menu border-0" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="change-password.php"><i class="ti-key"></i> Change Password</a>
                    <a class="dropdown-item" href="index.php"><i class="ti-power-off"></i>Log Out</a>
                </div>
            </li>

        </ul>
    </nav>
</header>