<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="theme-color" content="#005281">
        <link rel="apple-touch-icon" sizes="144x144" href="{{ asset('public/images/apple-touch-icon.png')}}">
        <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('public/images/favicon-32x32.png')}}">
        <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('public/images/favicon-16x16.png')}}">

        <!-- Material Design for Bootstrap fonts and icons -->
        <script src="{{ asset('public/js/jquery-3.2.1.min.js') }}"></script>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href='https://fonts.googleapis.com/css?family=Roboto:300,400,500' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href=" {{ asset('public/css/bootstrap-glyphicons.css')}}" crossorigin="anonymous">
        <!-- Material Design for Bootstrap CSS -->
        <link rel="stylesheet" href="{{ asset('public/css/bootstrap-material-design.min.css')}}" crossorigin="anonymous">
      
        <link rel="stylesheet" href="{{ asset('public/css/jquery.datetimepicker.min.css')}}">
        <link rel="stylesheet" href="{{ asset('public/css/morris.css')}}">
        <link rel="stylesheet" href="{{ asset('public/css/font-awesome.min.css')}}">
        <link rel="stylesheet" href="{{ asset('public/css/toastr.min.css')}}">
        <link rel="stylesheet" href="{{ asset('public/css/bootstrap-select.min.css')}}">
        <link rel="stylesheet" href="{{ asset('public/css/custom.min.css')}}" crossorigin="anonymous">
        <title>OPTT</title>
    </head>
    <body class="bg_lightgray">
        <main >
            @include('admin::layouts.header')
            @include('admin::layouts.sidebar')
            <div class="content-wrapper">
                @yield('content')
            </div>
        </main>
        <script src="{{ asset('public/js/popper.js') }}" crossorigin="anonymous"></script>
        <script src="{{ asset('public/js/bootstrap-material-design.js') }}" crossorigin="anonymous"></script>
        <script src="{{ asset('public/js/morris.min.js') }}" crossorigin="anonymous"></script>  
        <script src="{{ asset('public/js/raphael-min.js') }}" crossorigin="anonymous"></script>
        <script>
            $(document).ready(function () {
                $('body').bootstrapMaterialDesign();
            });
        </script>
        <script src="{{ asset('/public/js/jsvalidation.min.js') }}"></script>
        <script src="{{ asset('/public/js/bootbox.min.js') }}"></script>
        <script src="{{ asset('/public/js/bootstrap-select.min.js') }}"></script>
        
        <script src="{{ asset('/public/js/jquery.dataTables.min.js') }}"></script>
        <script src="{{ asset('/public/js/dataTables.buttons.min.js') }}"></script>
        <script src="{{ asset('/public/js/buttons.html5.min.js') }}"></script>
        <script src="{{ asset('/public/js/jszip.min.js') }}"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
        <script src="{{ asset('/public/js/toastr.min.js') }}"></script>
        <script>
        $(document).ready(function(){
            $('.selectpicker').selectpicker();
        });
        function fullwidth() {
            $("#nav-aside").toggleClass('slide');
            $("body").toggleClass('add-wrapper');
            $(document).on('touchmove', function (e) {
                if (!$(e.target)('body.add-wrapper')[0]) {
                    e.preventDefault();
                }
            });
        };
        function showButtonLoader(id,text,action){
                if(action === 'disable'){
                    $('#'+id).html('Processing...<i class="fa fa-spinner fa-pulse"></i>');
                    $('#'+id).prop('disabled',true);
                }else{
                    $('#'+id).html(text);
                    $('#'+id).prop('disabled',false);
                }
            }
    
        </script>

        <script type="text/javascript">
            (function (window, document, undefined) {

                var factory = function ($, DataTable) {
                    "use strict";

                    $('.search-toggle').click(function () {
                        if ($('.hiddensearch').css('display') == 'none')
                            $('.hiddensearch').slideDown();
                        else
                            $('.hiddensearch').slideUp();
                    });

                    /* Bootstrap paging button renderer */
                    DataTable.ext.renderer.pageButton.material = function (settings, host, idx, buttons, page, pages) {
                        var api = new DataTable.Api(settings);
                        var classes = settings.oClasses;
                        var lang = settings.oLanguage.oPaginate;
                        var btnDisplay, btnClass, counter = 0;

                        var attach = function (container, buttons) {
                            var i, ien, node, button;
                            var clickHandler = function (e) {
                                e.preventDefault();
                                if (!$(e.currentTarget).hasClass('disabled')) {
                                    api.page(e.data.action).draw(false);
                                }
                            };

                            for (i = 0, ien = buttons.length; i < ien; i++) {
                                button = buttons[i];

                                if ($.isArray(button)) {
                                    attach(container, button);
                                } else {
                                    btnDisplay = '';
                                    btnClass = '';

                                    switch (button) {

                                        case 'first':
                                            btnDisplay = lang.sFirst;
                                            btnClass = button + (page > 0 ?
                                                    '' : ' disabled');
                                            break;

                                        case 'previous':
                                            btnDisplay = '<i class="material-icons">chevron_left</i>';
                                            btnClass = button + (page > 0 ?
                                                    '' : ' disabled');
                                            break;

                                        case 'next':
                                            btnDisplay = '<i class="material-icons">chevron_right</i>';
                                            btnClass = button + (page < pages - 1 ?
                                                    '' : ' disabled');
                                            break;

                                        case 'last':
                                            btnDisplay = lang.sLast;
                                            btnClass = button + (page < pages - 1 ?
                                                    '' : ' disabled');
                                            break;

                                    }

                                    if (btnDisplay) {
                                        node = $('<li>', {
                                            'class': classes.sPageButton + ' ' + btnClass,
                                            'id': idx === 0 && typeof button === 'string' ?
                                                    settings.sTableId + '_' + button : null
                                        })
                                                .append($('<a>', {
                                                    'href': '#',
                                                    'aria-controls': settings.sTableId,
                                                    'data-dt-idx': counter,
                                                    'tabindex': settings.iTabIndex
                                                })
                                                        .html(btnDisplay)
                                                        )
                                                .appendTo(container);

                                        settings.oApi._fnBindAction(
                                                node, {
                                                    action: button
                                                }, clickHandler
                                                );

                                        counter++;
                                    }
                                }
                            }
                        };

                        var activeEl;

                        try {
                           
                            activeEl = $(document.activeElement).data('dt-idx');
                        } catch (e) {
                        }

                        attach(
                                $(host).empty().html('<ul class="material-pagination list-unstyled"/>').children('ul'),
                                buttons
                                );

                        if (activeEl) {
                            $(host).find('[data-dt-idx=' + activeEl + ']').focus();
                        }
                    };



                    /* Set the defaults for DataTables initialisation */
                    $.extend(true, DataTable.defaults, {
                        dom: "<'my-buttons'B'>" + "<'hiddensearch'f'>" +
                                "tr" +
                                "<'table-footer'lip'>",
                        renderer: 'material'
                    });

                }; // /factory

                // Define as an AMD module if possible
                if (typeof define === 'function' && define.amd) {
                    define(['jquery', 'datatables'], factory);
                } else if (typeof exports === 'object') {
                    // Node/CommonJS


                    factory(require('jquery'), require('datatables'));
                } else if (jQuery) {
                    // Otherwise simply initialise as normal, stopping multiple evaluation
                    factory(jQuery, jQuery.fn.dataTable);
                }

            })(window, document);

            function ExportData(type){
                if(type == 'excel'){
                    $('.buttons-excel').click();
                };
                if(type == 'pdf'){
                    $('.buttons-pdf').click();
                };
                if(type == 'csv'){
                    $('.buttons-csv').click();
                };
            };

        </script>

        <script>
            (function () {
                'use strict';
                window.addEventListener('load', function () {
                    // Fetch all the forms we want to apply custom Bootstrap validation styles to
                    var forms = document.getElementsByClassName('needs-validation');
                    // Loop over them and prevent submission
                    var validation = Array.prototype.filter.call(forms, function (form) {
                        form.addEventListener('submit', function (event) {
                            if (form.checkValidity() === false) {
                                event.preventDefault();
                                event.stopPropagation();
                            }
                            form.classList.add('was-validated');
                        }, false);
                    });
                }, false);
            })();
            $(document).ready(function () {
                $.validator.setDefaults({
                    ignore: []
                });


            });

                $(".notification").on('click',function(e){
           e.stopPropagation();
       });
        </script>
    </body>
</html>





