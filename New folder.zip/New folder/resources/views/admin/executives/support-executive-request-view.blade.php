@extends('admin.layouts.app')
@section('title','Support Executive')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Support Executive Request View</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/support-executive-request')}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="table-responsive" id="getrequestlist">
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function () {
        getrequestlist();
    });
    function getrequestlist() {
        pageDivLoader('show', 'getrequestlist');
        var url = '{{url("admin/support-executive-view-list")}}';
        $.ajax({type: "GET", url: url, data: {id: '{{$id}}'},
            success: function (response) {
                $("#getrequestlist").html(response.html);
                $("#data_table").DataTable({
                    searching: false,
                    "columnDefs": [{
                            "targets": 'no-sort',
                            "orderable": false,
                        }]
                });
            }
        });
    }
</script>
@endsection