@extends('admin.layouts.app')
@section('title', 'Call Request')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Call Request List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" id="callRequestCsv" style="display:none;">
                        <a href="{{url('admin/call-request-csv-download')}}" class="nav-link">
                            <i class="fas fa-cloud-download-alt"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link">
                            <i class="fa fa-search"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <div class="filter_section collapse" id="searchFilter">
                    <form id="search_form" action="javascript:load_callRequest_list()" method="post" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label>Merchant Number</label>
                                    <input type="text" name="merchant_number" id="merchant_number" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label>Business Name</label>
                                    <input type="text" name="business_name" id="business_name" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                @php
                                $executives = \App\Http\Models\User::getExecutivesLinkedById();
                                @endphp                                                            
                                <div class="form-group">
                                    <select class="form-control selectpicker" id="filterAssignedSE" name="se_assigned" data-actions-box="true" title="select Assigned SE" data-size="5">
                                        @if(count($executives)>0)
                                        @foreach($executives as $executive)
                                        <option value="{{$executive->id}}">{{ucfirst($executive->contact_name)}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label>Date of Call </label>
                                    <div class="dateicon">
                                        <input type="text" name="date_of_call" readonly id="SelectDate01" class="form-control datetimepicker-input" data-target="#SelectDate01" data-toggle="datetimepicker" placeholder="">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary ripple-effect-dark mr-2">Search</button>
                                    <button type="reset" onclick="resetForm();" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="call_request_list">
                </div>
            </div>
        </div>
    </div>
</main>

<script type="text/javascript">
    $(document).ready(function ()
    {
        load_callRequest_list();
    });

    function resetForm() {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        load_callRequest_list();
    }

    function load_callRequest_list()
    {
        pageDivLoader('show', 'call_request_list');
        var search_filter = $("#search_form").serializeArray();
        $.ajax({
            type: "POST",
            url: "{{ url('admin/call-request-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#call_request_list").html(response.html);
                    $("#data_table").DataTable({
                        searching: false,
                        "columnDefs": [{
                                "targets": 'no-sort',
                                "orderable": false,
                            }]
                    });
                } else {
                    toastrAlertMessage('error', response.message);
                }

            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection