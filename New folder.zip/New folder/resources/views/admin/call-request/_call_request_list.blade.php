@if(count($callRequest) >0)
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Business Name</th>
            <th>Merchant Number</th>
            <th>Date of Call</th>
            <th>Status of Call</th>
            <th>SE Assigned</th>
            <th>Category</th>
            <th class="th_action no-sort">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($callRequest as $data)
        <tr>
            <td>{{$data->UserProfile->bussiness_name}}</td>
            <td>{{$data->UserProfile->merchant_number}}</td>
            <td>{{showDateFormat($data->created_at)}}</td>
            <td>
                <div class="user_status {{$data->status == 'resolved' ? 'resolved' : 'pending'}}">
                    <span>{{ucfirst($data->status)}}</span>
                </div>
            </td>
            <td>{{ucfirst($data->executiveDetail->contact_name)}}</td>
            <td>{{$data->BankCategory->name}}</td>

            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="{{url('admin/call-request-view/'.$data->id)}}">View</a>
                    </div>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
@if(count($callRequest) >0)
<script>
    $(document).ready(function () {
        $('#callRequestCsv').show();
    });
</script>
@endif