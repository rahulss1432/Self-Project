@extends('admin.layouts.app')
@section('title', 'Category')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">View Profile</h4>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="profile-img">
                            <img src="{{checkProfileImage($adminData->profile_image)}}" alt="user-img" class="rounded-circle img-fluid">
                        </div>
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                <label>Name </label>
                                <span>{{$adminData->first_name.' '.$adminData->last_name}}</span>
                            </li>
                            <li>
                                <label>Email Address</label>
                                <span>{{$adminData->email}}</span>
                            </li>
                            <li>
                                <label>Phone Number </label>
                                <span>{{$adminData->phone_number}}</span>
                            </li>
                            <li>
                                <label>No. of Linked Support Executives</label>
                                <span>15</span>
                            </li>
                            <li>
                                <label>No. of Linked Merchants</label>
                                <span>22</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection