@extends('admin.layouts.app')
@section('title', 'Edit Merchant')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">edit Merchant</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/manage-merchant')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <form id="EditMerchantForm" autocomplete="off" class="f-field" method="POST" action="{{url('admin/update-merchant')}}">
                    {{csrf_field()}}
                    <input type="hidden" name="user_id" value="{{$user->id}}">
                    <div class="row">
                        <div class="col-sm-6">                            
                            <div class="form-group">
                                @php
                                $executives = \App\Http\Models\User::getExecutivesLinkedById();
                                $linkedExecutives = \App\Http\Models\CustomerExecutiveRelation::getExecutiveByCustomerId($user->id);
                                $data = array();                                                                 
                                foreach($linkedExecutives as $linkedExecutive){
                                $data[] = $linkedExecutive->executive_id;
                                }     
                                @endphp                            
                                <select class="form-control selectpicker" id="selectExecutive" name="executive[]" multiple  data-actions-box="true" title="Select Support Executive" data-size="5">
                                    @if(count($executives)>0)
                                    @foreach($executives as $executive)
                                    <option value="{{$executive->id}}" {{in_array($executive->id,$data) ? 'selected' : ''}}>{{$executive->contact_name}}</option>
                                    @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>    
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="contact_name"  value="{{$user->contact_name}}" class="form-control">
                                <label class="control-label">Contact Name</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="bussiness_name" value="{{$user->userDetail->bussiness_name}}" class="form-control" >
                                <label class="control-label">Business Name</label>
                            </div>
                        </div>                

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="phone" value="{{$user->phone_number}}" class="form-control">
                                <label class="control-label">Phone Number</label>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="email" name="email" value="{{$user->email}}" class="form-control">
                                <label class="control-label">Email Address</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="product" value="{{$user->userDetail->product}}" class="form-control">
                                <label class="control-label">Merchant Processor</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="machine_model" value="{{$user->userDetail->machine_model}}" class="form-control" >
                                <label class="control-label">Credit Card Machine Model</label>
                            </div>
                        </div>                        

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="terminal_model" value="{{$user->userDetail->terminal_model}}"  class="form-control">
                                <label class="control-label">Terminal Model</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="bussiness_address"  value="{{$user->userDetail->bussiness_address}}" class="form-control" >
                                <label class="control-label">Business Address</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="city" value="{{$user->city}}" class="form-control" >
                                <label class="control-label">City</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="state" value="{{$user->state}}" class="form-control" >
                                <label class="control-label">State</label>
                            </div>
                        </div>                                                
                    </div>
                    <div class="form-group">
                        <button id="btnSubmitForm" type="submit" class="btn btn-primary ripple-effect-dark">Save
                            <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                    
                        </button>                        
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Admin\EditMerchantRequest','#EditMerchantForm') !!}                
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    $(document).on('submit', '#EditMerchantForm', function (e) {
        e.preventDefault();
        if ($('#EditMerchantForm').valid()) {
            $('#btnSubmitForm').prop('disabled', true);
            $('#btnSubmitLoader').show();
            $.ajax({
                url: "{{ url('admin/update-merchant') }}",
                data: $('#EditMerchantForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('admin/manage-merchant')}}";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnSubmitForm').prop('disabled', false);
                    }
                    $('#btnSubmitLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#btnSubmitForm').prop('disabled', false);
                }
            });
        }
    });
</script>
@endsection