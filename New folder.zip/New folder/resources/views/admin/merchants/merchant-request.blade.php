@extends('admin.layouts.app')
@section('title','Merchant Request')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Request History</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" id="merhantRequestCsv" style="display: none;">
                        <a href="{{url('admin/merchant-history-csv-download')}}" class="nav-link">
                            <i class="fas fa-cloud-download-alt"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link">
                            <i class="fa fa-search"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="filter_section collapse" id="searchFilter">
                    <form id="searchFilterForm" action="javascript:void(0)" onsubmit="getMerchantRequestList()" method="post" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <input type="text" id="filterBusinessName" name="bussiness_name" class="form-control">
                                    <label class="control-label">Business Name</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <input type="text" id="filterPhoneNumber" name="phone" class="form-control">
                                    <label class="control-label">Phone Number</label>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                @php
                                $executives = \App\Http\Models\User::getExecutivesLinkedById();
                                @endphp                                                            
                                <div class="form-group">
                                    <select class="form-control selectpicker" id="filterAssignedSE" name="executive_id" data-actions-box="true" title="select Assigned SE" data-size="5">
                                        @if(count($executives)>0)
                                        @foreach($executives as $executive)
                                        <option value="{{$executive->id}}">{{ucfirst($executive->contact_name)}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <label>Request Date</label>
                                    <div class="dateicon">
                                        <input type="text" name="request_date" readonly id="SelectDate03" class="form-control datetimepicker-input" data-target="#SelectDate03" data-toggle="datetimepicker">
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                @php
                                $categories = \App\Http\Models\BankingCategory::getActiveCategories();
                                @endphp                                                                       
                                <div class="form-group">
                                    <select class="form-control selectpicker" id="selectCategoryFilter" name="category_id" title="Support Department">
                                        <option value="">Select Category</option>                                        
                                        @if(count($categories)>0)
                                        @foreach($categories as $category)
                                        <option value="{{$category->id}}">{{$category->name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>


                            <div class="col-12">
                                <div class="form-group">
                                    <button type="submit" id="btnSubmitForm" class="btn btn-primary ripple-effect-dark mr-2">Search
                                        <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>  
                                    </button>
                                    <button type="button" id="btnResetForm" onclick="resetForm()"class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>                            
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="divMerchantRequestList">
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function () {
        getMerchantRequestList();
    });

    function resetForm() {
        $('#searchFilterForm')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        getMerchantRequestList();
    }

    function getMerchantRequestList() {
        pageDivLoader('show', 'divMerchantRequestList');
        var searchString = $("#searchFilterForm").serializeArray();
        $.ajax({
            type: "POST",
            url: "{{url('admin/merchant-request-list')}}",
            data: searchString,
            success: function (response) {
                if (response.success) {
                    $('#divMerchantRequestList').html(response.html);
                    $("#data_table").DataTable({
                        searching: false,
                        "columnDefs": [{
                                "targets": 'no-sort',
                                "orderable": false,
                            }]
                    });
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection