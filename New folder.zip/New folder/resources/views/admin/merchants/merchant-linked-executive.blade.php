@extends('admin.layouts.app')
@section('title','Support Executive List')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Support Executive List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item" id="merchantSE" style="display: none;">
                        <a href="{{url('admin/merchant-linked-executive-csv-download/'.$id)}}" class="nav-link">
                            <i class="fas fa-cloud-download-alt"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="{{url('admin/manage-merchant')}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="table-responsive" id="getSelist">
                    <table class="table admin-table">

                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function () {
        getSelist();
    });
    function getSelist() {
        pageDivLoader('show', 'getSelist');
        var url = '{{url("admin/merchant-linked-executive-list")}}';
        $.ajax({type: "GET", url: url, data: {id: '{{$id}}'},
            success: function (response) {
                $("#getSelist").html(response.html);
                $("#data_table").DataTable({
                    searching: false,
                    "columnDefs": [{
                            "targets": 'no-sort',
                            "orderable": false,
                        }]
                });
            }
        });
    }
</script>
@endsection