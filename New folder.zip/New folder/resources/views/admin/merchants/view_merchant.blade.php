@extends('admin.layouts.app')
@section('title', 'Merchant Detail')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card custom_card" id="card_height">
                <div class="card-header">
                    <h4 class="page-title float-left">Merchant Detail</h4>
                    <ul class="list-inline mb-0 text-right">
                        <li class="list-inline-item">
                            <a href="{{url('admin/manage-merchant')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="bg-white box-shadow manage_post">
                    <div class="post_comment">
                        <div class="d-sm-flex">
                            <div class="">
                                <h2>Name {{getFullName($user->first_name ,$user->last_name )}}</h2>
                            </div>
                        </div>
                        <div class="d-sm-flex">
                            <div class="">
                                <h2>Email {{$user->email}}</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </div>
</main>
@endsection