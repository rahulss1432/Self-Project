@if($merchantSE->count()>0)
<table class="table admin-table" id="data_table">
    <thead>
    <th>ID</th>
    <th>Name</th>
    <th>Category</th>
    <th>Phone Number</th>
    <th>Company</th>
</thead>
<tbody>
    @foreach($merchantSE as $user)
    <tr>
        <td>{{!empty($user->userProfile->executive_number) ? $user->userProfile->executive_number : ''}}</td>
        <td>{{$user->userDetail->contact_name}}</td>
        <td>{{$user->userDetail->bankCategory->name}}</td>
        <td>{{$user->userDetail->phone_number}}</td>
        <td>{{$user->userDetail->bank->name}}</td>
    </tr>
    @endforeach
</tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
@if($merchantSE->count()>0)
<script>
    $(document).ready(function () {
        $('#merchantSE').show();
    });
</script>
@endif