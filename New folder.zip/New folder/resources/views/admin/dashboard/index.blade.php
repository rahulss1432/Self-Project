@extends('admin.layouts.app')
@section('title', 'Dashboard')
@section('content')
<main class="main-content dashboard-page" id="mainContent">
    <div class="container-fluid">
        <div class="top-boxes">
            <div class="row">
                <div class="col-md-4 col-sm-6 col-400">
                    <a href="{{url('admin/manage-executives')}}" class="box clearfix bg-orange">
                        <i class="icon fas fa-user-tie orange-color"></i>
                        <div class="content">
                            <h3>{{$excutiveCount}}</h3>
                            <p class="text-uppercase">Total Support Executive</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 col-sm-6 col-400">
                    <a href="{{url('admin/call-request')}}" class="box clearfix bg-blue">
                        <i class="icon fas fa-user-friends blue-color"></i>
                        <div class="content">
                            <h3>{{$callrequestCount}}</h3>
                            <p class="text-uppercase">Total  Number of Request Raised</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 col-sm-6 col-400">
                    <a href="{{url('admin/manage-merchant')}}" class="box clearfix bg-red">
                        <i class="icon fas fa-clock red-color"></i>
                        <div class="content">
                            <h3>{{$merchantCount}}</h3>
                            <p class="text-uppercase">Total Number of Merchant</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <section class="perfomance-section">
        <div class="container-fluid">
            <h2 class="text-uppercase font-hy">Preformance report of SE</h2>	
            <div class="row">
                <div class="col-lg-6">
                    <div class="common_box boxshadow">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="inner_heading">Preformance Graph</h4>
                            <ul class="list-inline mb-0 text-right">
                                <li class="list-inline-item">
                                    <a href="#searchFilter" data-toggle="collapse" class="nav-link  p-0" aria-expanded="true">
                                        <i class="fa fa-filter"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="filter_section collapse" id="searchFilter">
                            <form>
                                <div class="row">
                                    <div class="col-md-4 col-sm-6 col-">
                                        <div class="form-group">
                                            <select class="form-control selectpicker" title=" Select SE" data-live-search="true">
                                                <option>Micah Chan</option>
                                                <option>Kendall Campos</option>
                                                <option>Clementine Fischer</option>
                                                <option>Elmo Pratt</option>
                                                <option>Dalton Hoover</option>
                                                <option>Micah Chan</option>
                                                <option>Kendall Campos</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-">
                                        <div class="form-group">
<!--														<input type="text" class="form-control" placeholder="From">-->
                                            <label>From</label>
                                            <div class="dateicon">
                                                <input type="text" readonly id="SelectDate" class="form-control datetimepicker-input" data-target="#SelectDate" data-toggle="datetimepicker" placeholder="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-">
                                        <div class="form-group">
<!--														<input type="text" class="form-control" placeholder="">-->
                                            <label>To</label>
                                            <div class="dateicon">
                                                <input type="text" readonly id="SelectDate01" class="form-control datetimepicker-input" data-target="#SelectDate01" data-toggle="datetimepicker" placeholder="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <button type="button" class="btn btn-primary ripple-effect-dark mr-2">Search</button>
                                            <button type="button" class="btn btn-warning ripple-effect-dark">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div class="perfomance-graph">
                            <canvas id="subscriptionsChart" width="100%"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="common_box boxshadow se-rating">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="inner_heading">Rating of Support Executive</h4>
                            <ul class="list-inline mb-0 text-right">
                                <li class="list-inline-item">
                                    <a href="{{url('admin/ratings')}}">
                                        VIEW ALL
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="table-responsive">
                            <table class="table list_table admin-table mb-0">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Ratting</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Colin Clark</td>
                                        <td class="rating">
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Colin Clark</td>
                                        <td class="rating">
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Colin Clark</td>
                                        <td class="rating">
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Colin Clark</td>
                                        <td class="rating">
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Colin Clark</td>
                                        <td class="rating">
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<script>
// for chart
var ctx = document.getElementById("subscriptionsChart");
// Chart.defaults.global.animation.duration = 3000;
// ctx.height= 500;
Chart.defaults.global.defaultFontSize = 12;
var myChart1 = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        datasets: [
            {
                label: 'Resolved',
                data: [10, 15, 30, 35, 20, 25, 40, 50, 55, 60, 65, 90],
                backgroundColor: [
                    'transparent',
                ],
                pointBackgroundColor: 'rgba(255, 255, 255, 1)',
                pointHoverBorderColor: '#81D8D0',
                borderColor: [
                    '#81D8D0',
                ],
                borderWidth: 2
            },
            {
                label: 'Pending',
                data: [5, 10, 12, 8, 5, 7, 9, 7, 10, 13, 15, 10],
                backgroundColor: [
                    'transparent',
                ],
                pointBackgroundColor: 'rgba(255, 255, 255, 1)',
                pointHoverBorderColor: '#FF5E3A',
                borderColor: [
                    '#FF5E3A',
                ],
                borderWidth: 2
            },
        ]
    },
    options: {
        scaleShowVerticalLines: false,
        legend: {
            display: true,
            position: 'top',
        },
        responsive: true,
        scales: {
            xAxes: [{
                    gridLines: {
                        display: false
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'Months',
                        fontSize: 14,
                        fontColor: '#c3c3c3',
                    },
                }],
            yAxes: [{
                    gridLines: {
                        color: "rgba(122,122,122,0.1)",
                        zeroLineColor: "rgba(74,69,69,0.01)",
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'Number Of Request',
                        fontSize: 14,
                        fontColor: '#c3c3c3',
                    },
                    ticks: {
                        beginAtZero: true,
                        stepSize: 10,
                        tickMarkLength: 100,
                    }
                }]
        }
    }
});
</script>
@endsection