@extends('admin.layouts.app')
@section('title', 'Dashboard')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Rating of Support Executive</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link">
                            <i class="fa fa-search"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="{{url('admin/dashboard')}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <div class="filter_section collapse show" id="searchFilter">
                    <form>
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="text" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-">
                                <div class="form-group">
                                    <select class="form-control selectpicker" title="Select Rating">
                                        <option>5 Star</option>
                                        <option>4 Star</option>
                                        <option>3 Star</option>
                                        <option>2 Star</option>
                                        <option>1 Star</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-">
                                <div class="form-group">
                                    <button type="button" class="btn btn-primary ripple-effect-dark mr-2">Search</button>
                                    <button type="button" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive">
                    <table class="table admin-table" id="getRating">
                    </table>
                </div>
                <!-- pagination start -->
                <div class="pagination_list text-right" id="loadPagination" style="display:none">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end mb-0">
                            <li class="page-item">
                                <a class="page-link" href="#">Previous</a>
                            </li>
                            <li class="page-item active">
                                <a class="page-link" href="#">1</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">2</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">3</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <!-- pagination end -->
            </div>
        </div>
    </div>
</main>
@endsection