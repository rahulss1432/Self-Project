@extends('admin.layouts.app')
@section('title', 'Forgot Password')
@section('content')
<main class="login-page d-flex align-items-center justify-content-center">
    <div class="login-wrap mx-auto">
        <div class="login-header d-flex align-items-center justify-content-center">
            <h2 class="mb-0 text-uppercase text-center">linked assist <br> <span>admin</span></h2>
        </div>
        <div class="login-field">
            <form id="forgotPasswordForm" method="POST" action="{{url('admin/send-forgot-email')}}">
                {{ csrf_field() }}
                <div class="form-group">
                    <i class="fa fa-envelope"></i>
                    <input type="email" name="email" class="form-control"/>
                    <label class="control-label">Email</label>
                </div>
                <div class="form-group text-center mb-0 pl-0">
                    <button id="btnForgotPassword" type="submit" class="btn btn-primary ripple-effect-dark">SUBMIT
                        <i id="forgotFormLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                    
                    </button>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Http\Requests\Admin\ForgotPasswordRequest','#forgotPasswordForm') !!}
        </div>
        @if ($errors->has('email'))
        <span class="help-block">
            <div class="alert alert-danger">
                <strong>{{ $errors->first('email') }}</strong>
            </div>
        </span>
        @endif
        @if(session()->has('message'))
        <div class="alert alert-success">
            {{ session()->get('message') }}
        </div>
        @endif
        <div class="login-footer forgot">
            <a href="{{url('admin')}}" class="ripple-effect-dark"><i class="fas fa-long-arrow-alt-left ml-0"></i> LOGIN</a>
        </div>
    </div>
</main>

<script>
    $(document).on('submit', '#forgotPasswordForm', function (e) {
        e.preventDefault();
        if ($('#forgotPasswordForm').valid()) {
            $('#btnForgotPassword').prop('disabled', true);
            $('#forgotFormLoader').show();
            $.ajax({
                url: "{{url('admin/send-forgot-email')}}",
                data: $('#forgotPasswordForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('/admin')}}";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnForgotPassword').prop('disabled', false);
                    }
                    $('#forgotFormLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#forgotFormLoader').hide();
                        $('#btnForgotPassword').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });
</script>
@endsection