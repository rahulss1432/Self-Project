@extends('admin.layouts.app')
@section('title', 'Reset Password')
@section('content')
<main class="login-page d-flex align-items-center justify-content-center">
    <div class="login-wrap mx-auto">
        <div class="login-header d-flex align-items-center justify-content-center">
            <h2 class="mb-0 text-uppercase text-center">linked assist <br> <span>admin</span></h2>
        </div>
        <div class="login-field">
            <form id="resetPasswordForm" method="POST" action="{{url('admin/reset-password')}}">
                {{ csrf_field() }}
                <input type="hidden" name="reset_token" value="{{$token}}">
                <div class="form-group">
                    <i class="fa fa-lock"></i>
                    <input type="password" name="password" class="form-control">                    
                    <label class="control-label">New Password</label>
                </div>                
                <div class="form-group">
                    <i class="fa fa-lock"></i>
                    <input type="password" name="password_confirmation" class="form-control">                    
                    <label class="control-label">Confirm Password</label>
                </div>                                
                <div class="form-group text-center mb-0 pl-0">
                    <button id="btnResetPassword" type="submit" class="btn btn-primary ripple-effect-dark">RESET
                        <i id="btnResetLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                    
                    </button>
                </div>                
            </form>
            {!! JsValidator::formRequest('App\Http\Requests\ResetPasswordRequest','#resetPasswordForm') !!}
        </div>
    </div>
</main>
<script>
    $(document).on('submit', '#resetPasswordForm', function (e) {
        e.preventDefault();
        if ($('#resetPasswordForm').valid()) {
            $('#btnResetPassword').prop('disabled', true);
            $('#btnResetLoader').show();
            $.ajax({
                url: "{{url('admin/reset-password')}}",
                data: $('#resetPasswordForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('/admin')}}";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnResetPassword').prop('disabled', false);
                    }
                    $('#btnResetLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#btnResetLoader').hide();
                        $('#btnResetPassword').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });
</script>
@endsection