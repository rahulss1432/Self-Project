@extends('admin.layouts.app')
@section('title', 'Document')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Documents List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/add-document')}}" class="nav-link">
                            <i class="fa fa-plus"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link">
                            <i class="fa fa-search"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <div class="filter_section collapse" id="searchFilter">
                    <form id="search_form" action="javascript:load_document_list()" method="post" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    @php
                                    $bankList = \App\Http\Models\Bank::getBankList();
                                    @endphp
                                    <select name="bank_id" id="bank_id" title="Select Bank" data-size="5" class="form-control selectpicker">
                                        <option value=''>Select Bank</option>
                                        @if(count($bankList)>0)
                                        @foreach($bankList as $bank)
                                        <option value="{{$bank->id}}">{{$bank->name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label>Title</label>
                                    <input type="text" id="title" name="title"  class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary ripple-effect-dark mr-2">Search</button>
                                    <button type="reset" id="reset-btn" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="document_list">
                </div>
            </div>
        </div>
    </div>
</main>

<script type="text/javascript">
    $(document).ready(function ()
    {
        load_document_list();
    });

    $("#reset-btn").click(function ()
    {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        load_document_list();
    });

    function load_document_list()
    {
        pageDivLoader('show', 'document_list');
        var search_filter = $("#search_form").serializeArray();
        $.ajax({
            type: "POST",
            url: "{{ url('admin/document-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#document_list").html(response.html);
                    $("#data_table").DataTable({
                        searching: false,
                        "columnDefs": [{
                                "targets": 'no-sort',
                                "orderable": false,
                            }]
                    });
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    function deletefunction(id)
    {
        bootbox.confirm('Are you sure do you want to delete this document?', function (result)
        {
            if (result)
            {
                $.ajax({
                    type: "GET",
                    url: "{{url('admin/delete-document')}}/" + id,
                    success: function (response)
                    {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            document.getElementById('documents' + id).style.display = 'none';
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            }
        });
    }
</script>
@endsection