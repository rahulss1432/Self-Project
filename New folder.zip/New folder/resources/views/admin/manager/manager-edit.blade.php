@extends('admin.layouts.app')
@section('title', 'Edit Manager')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Edit Manager</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/manager')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <form id="editManagerForm" autocomplete="off" method="POST" action="{{url('admin/manager-update')}}" enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <input type="hidden" name="managerId" value="{{$editManager->id}}">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" name="first_name" value="{{$editManager->first_name}}" class="form-control form-control-lg">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" name="last_name" value="{{$editManager->last_name}}" class="form-control form-control-lg">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" value="{{$editManager->email}}" class="form-control form-control-lg">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Phone</label>
                                <input type="text" name="phone" value="{{$editManager->phone_number}}" class="form-control form-control-lg">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Company</label>
                                @php
                                $bankName = \App\Http\Models\Bank::getBankByDucument($editManager->bank_id);
                                @endphp
                                <input type="text" name="company" value="{{$bankName->name}}" class="form-control form-control-lg">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <select name="manager_type" class="form-control selectpicker" select="Manager Type">
                                    <option value="">Select Manager Type</option>
                                    <option value="technical" @if($editManager->manager_type == "technical") selected="selected" @endif>Technical SM</option>
                                    <option value="merchant" @if($editManager->manager_type == "merchant") selected="selected" @endif>Merchant SM</option>
                                    <option value="relationship" @if($editManager->manager_type == "relationship") selected="selected" @endif>Relationship SM</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Upload Image</label>
                                <div class="file-upload">
                                    <div class="file-select">
                                        <div class="file-select-button" id="fileName"  >Choose File</div>
                                        <div class="file-select-name" id="spanFileName">{{!empty($editManager->profile_image) ? $editManager->profile_image : 'No file chosen...'}}</div> 
                                        <input type="file" name="image_file" id="imageUpload" onchange="uploadFile(this)">
                                        <input type="hidden" value="{{$editManager->profile_image}}" name="hiddenFileName" class="do-not-ignore" name="hiddenFileName" id="hiddenMediaFileName">
                                    </div>
                                </div>  
                            </div>
                        </div>
                    </div>
                    <div class="from-group">
                        <button id="btnEditManager" type="submit" class="btn btn-primary btn_radius submitButton">
                            <i id="editManagerFormLoader" class="fa fa-spin fa-spinner" style="display: none;"></i> Save
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Admin\EditManagerRequest','#editManagerForm') !!}
            </div>
        </div>
    </div>
</main>

<!-- cropper-Modal -->
<div class="modal fade" id="cropper-image-modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <!--<h4 class="modal-title"></h4>-->
            </div>
            <div id="image-cropper-form">
            </div>                            
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).on('submit', '#editManagerForm', function (e) {
        e.preventDefault();
        if ($('#editManagerForm').valid()) {
            $('#btnEditManager').prop('disabled', true);
            $('#editManagerFormLoader').show();
            var formData = new FormData($('#editManagerForm')[0]);
//                formData.append('_token', '{{ csrf_token() }}');
            $.ajax({
                url: "{{url('admin/manager-update')}}",
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('/admin/manager')}}";
                        }, 1000);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnEditManager').prop('disabled', false);
                    }
                    $('#editManagerFormLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#editManagerFormLoader').hide();
                        $('#btnEditManager').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });

    /* image uploading with cropper*/
    function uploadFile(thisEl) {
        if (thisEl.files[0]) {
            var inputFile = thisEl.files[0].name;
            var extension = inputFile.substr(inputFile.lastIndexOf('.') + 1); /*get file exension*/
            /*check file type and exension*/
            if (extension != 'jpg' && extension != 'jpeg' && extension != 'png') {
                toastrAlertMessage('error', 'Image allows only in jpeg, png or jpg format');
                $('#imageUpload').val('');
                $('#hiddenMediaFileName').val('');
                return false;
            }
            var formData = new FormData($('#editManagerForm')[0]); /*uploading on server via ajax call*/
            formData.append('_token', '{{ csrf_token() }}');
            $.ajax({
                url: "{{url('admin/upload-media-image')}}",
                type: 'POST',
                data: formData,
                processData: false,
                cache: false,
                contentType: false,
                success: function (response) {
                    loadImageCropperModal(response.filename);
                    $('#cropper-image-modal').modal('show');
                }
            });
        }
    }

    function loadImageCropperModal(imageName) {
        $.ajax({
            url: "{{url('admin/load-image-cropper')}}",
            type: 'GET',
            data: {imageName: imageName, type: 'profile_image'},
            success: function (response) {
                $('#image-cropper-form').html(response.html);
            }
        });
    }
</script>
@endsection