<script type="text/javascript">
    $(function () {
        var $images = $('#cropbox');
        $images.cropper({
            viewMode: 1,
            dragMode: 'move',
            autoCropArea: 0.65,
            restore: false,
            guides: false,
            highlight: true,
            movable: false,
            zoomable: false,
            rotatable: true,
            center: false,
            scalable: false,
            responsive: true,
            strict: true,
            cropBoxResizable: false,
            aspectRatio: 1
        });

        $("#cropbutton").click(function () {
            $("#cropbutton").attr('disabled', true);
            $('#btnCropperLoader').show();
            var imageCropedData = $images.cropper('getData');
            var croppedWidth = imageCropedData.width;
            var croppedHeight = imageCropedData.height;
            var croppedX = imageCropedData.x;
            var croppedY = imageCropedData.y;
            var rotate = imageCropedData.rotate;
            saveCroppedImage(croppedWidth, croppedHeight, croppedX, croppedY, rotate);
        });
    });

    function saveCroppedImage(croppedWidth, croppedHeight, croppedX, croppedY, rotate) {
        var imageName = '{{$imageName}}';
        var type = '{{$type}}';
        $.ajax({
            type: "POST",
            url: "{{url('/admin/upload-cropped-image')}}",
            data: {croppedWidth: croppedWidth,
                croppedHeight: croppedHeight,
                croppedX: croppedX,
                croppedY: croppedY,
                rotate: rotate,
                _token: '{{ csrf_token() }}',
                imageName: imageName,
                type: type
            },
            success: function (response) {
//                console.log(response);
                $('#hiddenMediaFileName').val(response); // set input file name
                $('#cropper-image-modal').modal('hide');
                $('#spanFileName').html(response);
                $("#cropbutton").attr('disabled', false);
                $('#btnCropperLoader').hide();

                /* show preview div and image*/
//                if (type == 'profile_image') {
//                    var imagePath = '{{url("public/uploads/users/")}}/';
//                }
                $('#divImagePreview').show();
//                $("#imagePreview").attr("src", imagePath + response);
            }
        });
    }

    function rotate_plus(rotate_angle) {
        $('#cropbox').cropper("rotate", rotate_angle);
    }

    function zoom_image(zoomRatio) {
        $('#cropbox').cropper("zoom", zoomRatio);
    }
</script>
<div class="modal-body">
    <div class="cropdiv">
        <img alt="image" src="{{ url('/public/uploads/temp-image/'.$imageName)}}"  value="{{$imageName}}" id="cropbox" class="img-responsive" />
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-primary waves-effect waves-button waves-light" data-dismiss="modal" id="cropbutton">SAVE
        <i class="fa fa-spin fa-spinner" id="btnCropperLoader" style="display: none;"></i>    
    </button>
    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
</div>


