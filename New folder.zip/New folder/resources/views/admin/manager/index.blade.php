@extends('admin.layouts.app')
@section('title', 'Manage Manager')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Manager List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{ url('admin/manager-csv-download') }}" class="nav-link"><i class="fas fa-cloud-download-alt"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="{{url('admin/add-manager')}}" class="nav-link"><i class="fa fa-plus"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link"><i class="fa fa-search"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <div class="filter_section collapse" id="searchFilter">
                    <form id="search_form" action="javascript:load_manager_list()" method="post" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label>Search</label>
                                    <input type="text" id="name" name="name" class="form-control form-control-lg"/>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    @php
                                    $banks = \App\Http\Models\Bank::getBankList();
                                    @endphp
                                    <select id="selectBankFilter" name="bank_id" class="form-control selectpicker" select="Select Bank">
                                        <option value="">Select Bank</option>                                        
                                        @if(count($banks)>0)
                                        @foreach($banks as $bank)
                                        <option value="{{$bank->id}}">{{$bank->name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary ripple-effect-dark mr-2">Search</button>
                                    <button type="reset" id="reset-btn" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="manager_list">
                </div>
            </div>
        </div>
    </div>
</main>

<script type="text/javascript">

    $(document).ready(function ()
    {
        load_manager_list();
    });

    $("#reset-btn").click(function ()
    {
        $('#search_form')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        load_manager_list();
    });

    function load_manager_list()
    {
        pageDivLoader('show', 'manager_list');
        var search_filter = $("#search_form").serializeArray();
        search_filter.push('_token', '{{ csrf_token() }}');
        $.ajax({
            type: "POST",
            url: "{{ url('admin/manager-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#manager_list").html(response.html);
                    $("#data_table").DataTable({
                        searching: false,
                        "columnDefs": [{
                                "targets": 'no-sort',
                                "orderable": false,
                            }]
                    });
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function changeStatus(id, status) {
        var token = '{{ csrf_token() }}';
        if (status == 'deleted') {
            var newStatus = status;
            var confirmMsg = "Are you sure want to delete this manager ?";
        } else {
            var newStatus = status == 'active' ? 'inactive' : 'active';
            var confirmMsg = "Are you sure want to change manager status ?";
        }
        bootbox.confirm(confirmMsg, function (result) {
            if (result == true) {
                $.ajax({
                    url: "{{url('/admin/change-user-status')}}",
                    type: 'POST',
                    data: {_token: token, id: id, status: newStatus},
                    success: function (response) {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            setTimeout(function () {
                                location.reload();
                            }, 1500);
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            } else {
                if (status == 'active') {
                    $('#userStatus_' + id).prop("checked", true);
                }
                if (status == 'inactive') {
                    $('#userStatus_' + id).prop("checked", false);
                }
            }
        });
    }
</script>
@endsection