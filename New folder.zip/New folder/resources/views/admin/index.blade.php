@extends('admin.layouts.app')
@section('title', 'Admin Login')
@section('content')
<main class="login-page d-flex align-items-center justify-content-center">
    <div class="login-wrap mx-auto">
        <div class="login-header d-flex align-items-center justify-content-center">
            <h2 class="mb-0 text-uppercase text-center">linked assist<br><span>Admin</span></h2>
        </div>
        <div class="login-field">
            <form id="adminLoginForm" method="POST" action="{{url('admin/login')}}" autocomplete="off">
                {{ csrf_field() }}
                <div class="form-group {{ $errors->has('email') ? ' has-error' : '' }}">
                    <i class="fas fa-user"></i>
                    <input type="text" name="email" value="{{old('email')}}" class="form-control form-control-lg" id="inlineFormInputGroup">
                    <label class="control-label">Email</label>
                </div>
                <div class="form-group  {{ $errors->has('password') ? ' has-error' : '' }}">
                    <i class="fa fa-lock"></i>
                    <input type="password" name="password" value="{{old('password')}}" class="form-control form-control-lg">
                    @if ($errors->has('email'))
                    <span class="help-block error-help-block"><b>{{ $errors->first('email') }}</b></span>
                    @endif
                    <label class="control-label">Password</label>
                    <div id="spanLoginError"></div>
                </div>
                <div class="form-group text-center pl-0 mb-0">
                    <button type="submit" id="btnLogin" class="btn btn-primary ripple-effect-dark">SUBMIT
                        <i id="loginFormLoader" class="fas fa-spin fa-spinner" style="display: none"></i>
                    </button>
                </div>
            </form>
            {!! JsValidator::formRequest('App\Http\Requests\Admin\AdminLoginRequest','#adminLoginForm') !!}
        </div>
        <div class="login-footer">
            <a href="{{url('/admin/forgot-password')}}" class="ripple-effect-dark">FORGOT PASSWORD <i class="fas fa-long-arrow-alt-right"></i></a>
        </div>
    </div>
</main>
@include('admin.layouts.footer')
<script>
    $(document).on('submit', '#adminLoginForm', function (e) {
        $('#spanLoginError').text('');
        e.preventDefault();
        if ($('#adminLoginForm').valid()) {
            $('#btnLogin').prop('disabled', true);
            $('#loginFormLoader').show();
            $.ajax({
                url: "{{ url('admin/login') }}",
                data: $('#adminLoginForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = response.redirectUrl;
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnLogin').prop('disabled', false);
                        $('#loginFormLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#loginFormLoader').hide();
                        $('#btnLogin').prop('disabled', false);
                        $('#spanLoginError').html('<span class="help-block error-help-block">' + obj[x] + '</span>');
                    }
                }
            });
        }
    });
</script>
@endsection
