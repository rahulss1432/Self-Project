<header  id="topHeader">
    <div class="container-fluid">
        <nav class="navbar navbar-light justify-content-between bg-transparent">
            <h3 class="page-title">
                <a href="javascript:void(0);" onclick="sideMenu();" class="toggle-icon">
                    <i class="fa fa-outdent"></i>
                </a>
                @php
                $currentRoute = Request::route()->getName();
                @endphp
                <span>
                    @if($currentRoute == 'manage-user')
                    {{"Manager"}}
                    @elseif($currentRoute == 'manage-executives' || $currentRoute == 'support-executive-request')
                    {{"Support Executive"}}
                    @elseif($currentRoute == 'manage-merchant' || $currentRoute == 'merchant-request' || $currentRoute == 'unassigned-request')
                    {{"Merchant"}}
                    @elseif($currentRoute == 'call-request')
                    {{"Call Request"}}
                    @elseif($currentRoute == 'documents')
                    {{"Wiki Document"}}
                    @elseif($currentRoute == 'banks')
                    {{"Bank"}}
                    @elseif($currentRoute == 'categories')
                    {{"Category"}}
                    @elseif($currentRoute == 'view-profile')
                    {{"View Profile"}}
                    @elseif($currentRoute == 'change-password')
                    {{"Setting"}}
                    @elseif($currentRoute == 'ratings')
                    {{"Rating"}}
                    @else
                    {{"Dashboard"}}
                    @endif
                </span>
            </h3> 
            <ul class="nav align-items-center ml-auto">
                <li class="dropdown user_avtar">
                    <a href="javascript:void(0);"  class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="{{checkProfileImage(Auth()->guard('admin')->user()->profile_image)}}" alt="user_img" class="user-img rounded-circle">
                        <span class="name">{{Auth()->guard('admin')->user()->first_name.' '.Auth()->guard('admin')->user()->last_name}}</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="{{url('admin/view-profile')}}">View Profile</a>
                        <a class="dropdown-item" href="{{url('admin/change-password')}}">Change Password</a>
                        <a class="dropdown-item" href="{{url('admin/logout')}}" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                            Logout
                        </a>
                        <form id="logout-form" action="{{url('admin/logout')}}" method="POST" style="display: none;">
                            {{ csrf_field() }}
                        </form>
                    </div>
                </li>

            </ul>
        </nav>
    </div>
</header>