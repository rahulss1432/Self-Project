<div class="page-overlay" onclick="closeMenu();">
</div>

<!--change password model-->
<div class="modal fade" id="divChangePassword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog common-modal modal-dialog-centered" id="divChangePasswordModelBody" role="document">
    </div>
</div>

<script>

    function changePassword(id) {
        $.ajax({
            type: "GET",
            url: "{{ url('admin/load-change-password') }}" + '/' + id,
            success: function (response) {
                if (response.success) {
                    $('#divChangePasswordModelBody').html(response.html);
                    $("#divChangePassword").modal('show');
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    $(document).on('submit', '#changeUserPasswordForm', function (e) {
        e.preventDefault();
        if ($('#changeUserPasswordForm').valid()) {
            $('#btnChangeUserPassword').prop('disabled', true);
            $('#btnChangeUserPasswordLoader').show();
            $.ajax({
                url: "{{url('admin/update-user-password')}}",
                data: $('#changeUserPasswordForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            location.reload();
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnChangeUserPassword').prop('disabled', false);
                    }
                    $('#btnChangeUserPasswordLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#btnChangeUserPasswordLoader').hide();
                        $('#btnChangeUserPassword').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });

// toaster common function
    function toastrAlertMessage(type, msg) {
        if (type == 'success') {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.success(msg, {timeOut: 2000});
        } else {
            toastr.remove();
            toastr.options.closeButton = true;
            toastr.error(msg, {timeOut: 2000});
        }
    }
    function pageDivLoader(type, id) {
        if (type === 'show') {
            $('#' + id).html('<div class="text-center"><i class="fa fa-spin fa-spinner fa-2x"></i></div>');
        } else {
            $('#' + id).html('');
        }
    }
    $.validator.setDefaults({
        ignore: ":hidden:not(.do-not-ignore)", // not ignoring validation where .do-not-ignore class is used
    });
</script>
<script>
    $('#SelectDate, #SelectDate01, #SelectDate03').datetimepicker({
        focusOnShow: false,
        format: 'L',
        ignoreReadonly: true
    });
    $('.form-control').on('focus blur', function (e) {
        $(this).parents('.form-group').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
    }).trigger('blur');

    function getHeight() {
        $(window).resize(function () {
            var headerHeight = $("#topHeader").outerHeight(true);
            var window_height = $(window).height();
            var check_height = window_height - headerHeight;
            $("#cardBox").css('min-height', check_height - 50);
        }).resize();
    }
    getHeight();

    //ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });

    $(".selectpicker").selectpicker();

    $(".i-checks").each(function () {
        var intElem = $(this);
        intElem.on('click', function () {
            intElem.addClass('interactive-effect');
            setTimeout(function () {
                intElem.removeClass('interactive-effect');
            }, 400);
        });
    });

    function sideMenu() {
        $("body").toggleClass("sidemenu-open");
    }
    function closeMenu() {
        $("body").removeClass("sidemenu-open");
    }

    // for menu
    $(".sub_menu.active a ").attr('aria-expanded', 'true');

    if ($(window).width() <= 991) {
        $(".filter_section").removeClass("show");
    }
    ;

    if ($(window).width() <= 1199) {
        $(document).ready(function () {
            $("body").removeClass("sidemenu-open");
        });
    }
</script>