@extends('admin.layouts.app')
@section('title', 'Error')
@section('content')
<body class="error_page">
  <main class="main_content ">
    <section class="error_section">
      <div class="error_content " align="center">
        <h2>404</h2>
        <p class="text-center">THE LINK YOU FOLLOWED IS PROBABLY BROKEN OR THE 
        	<br clear="hidden-xs">PAGE HAS BEEN REMOVED.
        </p>
        <a class="btn btn-primary" href="{{url('admin/dashboard')}}">RETURN TO THE HOME PAGE</a>
      </div>
    </section>
  </main>
@endsection