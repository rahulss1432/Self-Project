<aside class="sidemenu">
    <div class="sidebar-wrapper">
        <div class="logo text-center">
            <h2 class="mb-0 text-uppercase">linked assist</h2>
        </div>
        @php
        $currentRoute = Request::route()->getName();
        @endphp
        <ul id="sidemenu" class="nav flex-column sidenav mCustomScrollbar" data-mcs-theme="minimal-dark">
            <li class="nav-item {{($currentRoute == 'manager-dashboard' )?'active':''}}">
                <a class="nav-link" href="{{url('manager/dashboard')}}"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            </li>
            <li class="nav-item sub_menu  {{($currentRoute == 'manage-merchant' || $currentRoute == 'add-merchant' || $currentRoute == 'edit-merchant' || $currentRoute == 'view-merchant' || $currentRoute == 'merchant-request' || $currentRoute == 'merchant-linked-executive' ||$currentRoute == 'merchant-request-view') ? 'active':''}}">
                <a class="nav-link" href="#subMenu" data-toggle="collapse"><i class="fas fa-user-friends" aria-expanded="false"></i>Merchant</a>

                <ul data-parent="#sidemenu" class="list-unstyled collapse {{($currentRoute == 'manage-merchant' || $currentRoute == 'add-merchant' || $currentRoute == 'edit-merchant' || $currentRoute == 'view-merchant' || $currentRoute == 'merchant-request' || $currentRoute == 'merchant-linked-executive' || $currentRoute == 'merchant-request-view') ? 'show':'hide'}}" id="subMenu">
                    <li class="{{($currentRoute == 'manage-merchant' || $currentRoute == 'merchant-linked-executive')?'active':''}}">
                        <a href="{{url('manager/manage-merchant')}}">Manage Merchant</a>
                    </li>
                    <li class=" {{($currentRoute == 'merchant-request' || $currentRoute == 'merchant-request-view')?'active':''}}">
                        <a href="{{url('manager/merchant-request')}}">Request History</a>
                    </li>
                    <li class="{{($currentRoute == 'unassigned-request')?'active':''}}">  
                        <a href="{{url('manager/unassigned-request')}}">Request Unassigned (SE)</a>
                    </li>
                </ul>
            </li>
            <li class="nav-item sub_menu {{($currentRoute == 'manage-executives' || $currentRoute ==  'add-executive' ||  $currentRoute ==  'edit-executive' || $currentRoute ==  'view-executive' || $currentRoute == 'support-executive-request' || $currentRoute == 'support-executive-request-view' || $currentRoute == 'support-executive-request-view-note' ) ? 'active':''}}">
                <a class="nav-link" href="#subMenu1" data-toggle="collapse"><i class="fas fa-user-tie"></i>Support Executive</a>
                <ul data-parent="#sidemenu" class="list-unstyled collapse {{($currentRoute == 'manage-executives' || $currentRoute ==  'add-executive' ||  $currentRoute ==  'edit-executive' || $currentRoute == 'support-executive-request' || $currentRoute == 'support-executive-request-view' || $currentRoute == 'support-executive-request-view-note' || $currentRoute ==  'view-executive') ? 'show':'hide'}}" id="subMenu1">
                    <li class=" {{($currentRoute == 'manage-executives')?'active':''}}">
                        <a href="{{url('manager/manage-executives')}}">List of (SE)</a>
                    </li>
                    <li class="{{($currentRoute == 'support-executive-request' || $currentRoute == 'support-executive-request-view' )?'active':''}}">  
                        <a href="{{url('manager/support-executive-request')}}">(SE) Request</a>
                    </li>
                </ul>
            </li>
            <li class="nav-item {{($currentRoute == 'call-request' || $currentRoute == 'call-request-view')?'active':''}}">
                <a class="nav-link" href="{{url('manager/call-request')}}"><i class="fas fa-phone call_icon"></i> Call Request</a>
            </li>
            <li class="nav-item {{($currentRoute == 'manage-document' || $currentRoute == 'add-document' || $currentRoute == 'edit-document' || $currentRoute == 'view-document') ? 'active' : ''}}">
                <a class="nav-link" href="{{url('manager/manage-document')}}"><i class="fas fa-file-alt"></i> Wiki Document</a>
            </li>
            <li class="nav-item {{($currentRoute == 'notifications')?'active':''}}">
                <a class="nav-link" href="{{url('manager/notifications')}}"><i class="far fa-bell"></i> Notifications</a>
            </li>
            <!-- <li class="nav-item {{($currentRoute == 'manager-view-profile')?'active':''}}">
                <a class="nav-link" href="support-manager.php"><i class="far fa-user"></i> Support Manager</a>
            </li> -->
        </ul>
    </div>
</aside>
