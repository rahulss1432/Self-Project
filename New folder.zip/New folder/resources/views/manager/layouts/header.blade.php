<header  id="topHeader">
    <div class="container-fluid">
        <nav class="navbar navbar-light justify-content-between bg-transparent">
            <h3 class="page-title">
                <a href="javascript:void(0);" onclick="sideMenu();" class="toggle-icon">
                    <i class="fa fa-outdent"></i>
                </a>
                @php
                $currentUrl = Request::route()->getName();
                @endphp
                <span>@if($currentUrl =='manager-view-profile')
                    view profile
                    @elseif($currentUrl =='manager-dashboard')
                    dashboard
                    @elseif($currentUrl =='manage-merchant' || $currentUrl =='add-merchant' || $currentUrl == 'merchant-request-view' || $currentUrl =='edit-merchant' || $currentUrl == 'merchant-request' || $currentUrl == 'merchant-linked-executive' )
                    MERCHANT
                    @elseif($currentUrl =='manage-executives' || $currentUrl =='add-executive' || $currentUrl =='edit-executive' || $currentUrl == 'view-executive' || $currentUrl == 'support-executive-request' || $currentUrl == 'support-executive-request-view' || $currentUrl == 'support-executive-request-view-note')
                    SUPPORT EXECUTIVE
                    @elseif($currentUrl =='manage-document' || $currentUrl =='add-document' || $currentUrl =='edit-document' || $currentUrl == 'view-document')
                    DOCUMENTS                   
                    @elseif($currentUrl =='manager-change-password')
                    SETTING
                    @elseif($currentUrl =='call-request'||$currentUrl == 'call-request-view')
                    CALL REQUEST
                    @elseif($currentUrl =='notifications')
                    NOTIFICATIONS
                    @else
                    @endif
                </span>
            </h3> 
            <ul class="nav align-items-center ml-auto">
                <li class="dropdown notification">
                    <a href="javascript:void(0);" class="dropdown-toggle" id="dropdownMenuButton01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="count">20</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton01">
                        <div class="head">
                            <h3 class="font-hy mb-0">Notifications</h3>
                        </div>
                        <div class="noti_body">
                            <ul class="list-unstyled mCustomScrollbar" data-mcs-theme="minimal-dark">
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do 
                                    </a>
                                </li>

                            </ul>
                        </div>
                        <div class="noti_footer text-center">
                            <a href="notifications.php" class="d-block">View All</a>
                        </div>
                    </div>
                </li>
                @php
                $authUser = \Auth::guard('manager')->user();
                @endphp
                <li class="dropdown user_avtar">
                    <a href="javascript:void(0);"  class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="{{getImage($authUser->profile_image,'users','users')}}" alt="user_img" class="user-img rounded-circle">
                        <span class="name">{{getFullName($authUser->first_name ,$authUser->last_name)}}</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="{{url('manager/view-profile')}}">View Profile</a>
                        <a class="dropdown-item" href="{{url('manager/change-password')}}" >Change Password</a>
                        <!--<a class="dropdown-item" href="/index.php" >Logout</a>-->
                        <a class="dropdown-item" href="{{url('manager/logout')}}" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                            Logout</span>
                        </a>
                        <form id="logout-form" action="{{url('manager/logout')}}" method="POST" style="display: none;">
                            {{ csrf_field() }}
                        </form>
                    </div>
                </li>

            </ul>
        </nav>
    </div>
</header>