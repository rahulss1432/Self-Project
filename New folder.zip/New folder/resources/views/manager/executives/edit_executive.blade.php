@extends('manager.layouts.app')
@section('title', 'Edit Executive')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Edit Support Executive</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/manage-executives')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <form id="addExecutiveForm" autocomplete="off" class="f-field" method="POST" action="{{url('manager/update-executive')}}">
                    {{csrf_field()}}
                    <input type="hidden" name="manager_id" value="{{Auth::guard(getAuthGuard())->user()->id}}">
                    <input type="hidden" name="user_id" value="{{$user->id}}">
                    <div class="row">
                        <div class="col-sm-6">
                            @php
                            $customers = \App\Http\Models\User::getCustomerLinkedByManagerId(Auth::guard(getAuthGuard())->user()->id);
                            $linkedCustomers = \App\Http\Models\CustomerExecutiveRelation::getCustomerByExecutiveId($user->id);
                            $data = array();                                                                 
                            foreach($linkedCustomers as $linkedCustomer){
                            $data[] = $linkedCustomer->customer_id;
                            }
                            @endphp                            
                            <div class="form-group">
                                <select class="form-control selectpicker" name="customer[]" multiple data-actions-box="true" title="Select Merchant" data-size="5">
                                    @if(count($customers)>0)
                                    @foreach($customers as $customer)
                                    <option value="{{$customer->id}}" {{in_array($customer->id,$data) ? 'selected' : ''}}>{{ucfirst($customer->contact_name)}}</option>
                                    @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Contact Name</label>
                                <input type="text" name="contact_name" value="{{$user->contact_name}}" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Company</label>
                                <input type="text" name="company" value="{{$user->bank->name}}" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            @php
                            $categories = \App\Http\Models\BankingCategory::getActiveCategories();
                            @endphp                            
                            <div class="form-group">
                                <select class="form-control selectpicker" id="selectCategory" name="category" title="Select Support Department">
                                    @if(count($categories)>0)
                                    @foreach($categories as $category)
                                    <option value="{{$category->id}}" {{$category->id == $user->category_id ? 'selected' : ''}} >{{$category->name}}</option>
                                    @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="text" name="phone" value="{{$user->phone_number}}" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" name="email" value="{{$user->email}}" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>City</label>
                                <input type="text" name="city" value="{{$user->city}}" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>State</label>
                                <input type="text" name="state" value="{{$user->state}}" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Business Address</label>
                                <textarea rows="3" name="bussiness_address" class="form-control" placeholder="">{{!empty($user->userDetail->bussiness_address) ? $user->userDetail->bussiness_address : ''}}</textarea>
                            </div>
                        </div>
                    </div>

                    <h5 class="mb-3">Supervisor </h5>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="supervisor_name" value="{{!empty($user->executiveSupervisor->name) ? $user->executiveSupervisor->name : ''}}" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" name="supervisor_email" value="{{!empty($user->executiveSupervisor->email) ? $user->executiveSupervisor->email : ''}}" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="text" name="supervisor_phone" value="{{!empty($user->executiveSupervisor->phone_number) ? $user->executiveSupervisor->phone_number : ''}}" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            @php
                            $customers = \App\Http\Models\User::getCustomerLinkedByManagerId(Auth::guard(getAuthGuard())->user()->id);                             
                            $customerIds = [];                            
                            if(!empty($user->executiveSupervisor->customer_id)){
                            $customerIds = explode(',',$user->executiveSupervisor->customer_id);                            
                            }
                            @endphp                            
                            <div class="form-group">
                                <select class="form-control selectpicker" id="selectSupervisorCustomer" name="supervisor_customer[]" data-actions-box="true" multiple title="Select Merchant" data-size="5">
                                    @if(count($customers)>0)
                                    @foreach($customers as $customer)
                                    <option value="{{$customer->id}}" {{in_array($customer->id,$customerIds) ? 'selected' : '' }}>{{$customer->contact_name}}</option>
                                    @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>
                    </div>                    
                    <div class="form-group">
                        <button id="btnSubmitForm" type="submit" class="btn btn-primary ripple-effect-dark">Save
                            <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                    
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Manager\EditExecutiveRequest','#addExecutiveForm') !!}                
            </div>
        </div>
    </div>
</main>

<script type="text/javascript">
//        back button loader
    function backLoader() {
        $("#backLoader").html('<i class="fa fa-spinner fa-spin"></i>');
    }

//       submit add executive form

    $(document).on('submit', '#addExecutiveForm', function (e) {
        e.preventDefault();
        if ($('#addExecutiveForm').valid()) {
            $('#btnSubmitForm').prop('disabled', true);
            $('#btnSubmitLoader').show();
            $.ajax({
                url: "{{ url('manager/update-executive') }}",
                data: $('#addExecutiveForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('manager/manage-executives')}}";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnSubmitForm').prop('disabled', false);
                    }
                    $('#btnSubmitLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#btnSubmitForm').prop('disabled', false);
                }
            });
        }
    });

    /* image uploading with cropper*/
    function uploadFile(thisEl) {
        if (thisEl.files[0]) {
            var inputFile = thisEl.files[0].name;
            var extension = inputFile.substr(inputFile.lastIndexOf('.') + 1); /*get file exension*/
            /*check file type and exension*/
            if (extension != 'jpg' && extension != 'jpeg' && extension != 'png') {
                toastrAlertMessage('error', 'Image allows only in jpeg, png or jpg format');
                $('#imageUpload').val('');
                $('#hiddenMediaFileName').val('');
                return false;
            }
            var formData = new FormData($('#addExecutiveForm')[0]); /*uploading on server via ajax call*/
            formData.append('_token', '{{ csrf_token() }}');
            $.ajax({
                url: "{{url('manager/upload-media-image')}}",
                type: 'POST',
                data: formData,
                processData: false,
                cache: false,
                contentType: false,
                success: function (response) {
                    loadImageCropperModal(response.filename);
                    $('#cropper-image-modal').modal('show');
                }
            });
        }
    }

    function loadImageCropperModal(imageName) {     /*open cropper model*/
        $.ajax({
            url: "{{url('manager/load-image-cropper')}}",
            type: 'GET',
            data: {imageName: imageName, type: 'profile_image'},
            success: function (response) {
                $('#image-cropper-form').html(response.html);
            }
        });
    }

//        $('#imageUpload').bind('change', function () {
//            var filename = $("#imageUpload").val();
//            if (/^\s*$/.test(filename)) {
//                $(".file-upload").removeClass('active');
//                $("#noFile").text("No file chosen...");
//            }
//            else {
//                $(".file-upload").addClass('active');
//                $("#noFile").text(filename.replace(/C:\\fakepath\\/i, ''));
//            }
//        });

    $('.form-group .form-control').focus(function ()
    {
        $(this).parent().addClass('isfocused');
    }).blur(function ()
    {
        $(this).parent().removeClass('isfocused');
    });
</script>
@endsection