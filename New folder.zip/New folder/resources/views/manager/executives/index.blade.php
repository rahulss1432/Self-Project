@extends('manager.layouts.app')
@section('title', 'Manage Executives')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Support Executive List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/executives-list-csv-download')}}" class="nav-link">
                            <i class="fas fa-cloud-download-alt"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a  href="{{url('manager/add-executive')}}" id="addExecutive" class="nav-link">
                            <i class="fa fa-plus"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link">
                            <i class="fa fa-search"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <div class="filter_section collapse" id="searchFilter">
                    <form id="searchFilterForm" action="javascript:void(0)" onsubmit="getExecutivesList()" method="post" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" id="nameFilter" name="name" class="form-control" placeholder="">
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <label>ID Number </label>
                                    <input type="text" name="executive_id" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <label>City, State </label>
                                    <input type="text" name="city_state" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <label>Phone Number</label>
                                    <input type="text" id="phoneFilter" name="phone" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                @php
                                $categories = \App\Http\Models\BankingCategory::getActiveCategories();
                                @endphp                                                                       
                                <div class="form-group">
                                    <select class="form-control selectpicker" id="selectCategoryFilter" name="category_id" title="Support Department">
                                        <option value="">Select Category</option>                                        
                                        @if(count($categories)>0)
                                        @foreach($categories as $category)
                                        <option value="{{$category->id}}">{{$category->name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <button type="submit" id="btnSubmitForm" class="btn btn-primary ripple-effect-dark mr-2">Search
                                        <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                                                                
                                    </button>
                                    <button id="btnResetForm" onclick="resetForm()" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="divExecutivesList">

                </div>
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    $(document).ready(function () {
        getExecutivesList();
    });

    function resetForm() {
        $('#searchFilterForm')[0].reset();
        $('.selectpicker').selectpicker('refresh');
        getExecutivesList();
    }

    function getExecutivesList() {
        pageDivLoader('show', 'divExecutivesList');
        var searchString = $("#searchFilterForm").serializeArray();
        $.ajax({
            type: "POST",
            url: "{{ url('manager/executives-list') }}",
            data: searchString,
            success: function (response) {
                if (response.success) {
                    $('#divExecutivesList').html(response.html);
                    $("#data_table").DataTable({
                        searching: false,
                        "columnDefs": [{
                                "targets": 'no-sort',
                                "orderable": false,
                            }]
                    });
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    // change user status
    function changeStatus(id, status) {
        var token = '{{ csrf_token() }}';
        if (status == 'deleted') {
            var newStatus = status;
            var confirmMsg = "Are you sure want to delete this user?";
        } else {
            var newStatus = status == 'active' ? 'inactive' : 'active';
            var confirmMsg = "Are you sure want to change user's status?";
        }
        bootbox.confirm(confirmMsg, function (result) {
            if (result == true) {
                $.ajax({
                    url: "{{url('/manager/change-user-status')}}",
                    type: 'POST',
                    data: {_token: token, id: id, status: newStatus},
                    success: function (response) {
                        if (response.success) {
                            toastrAlertMessage('success', response.message);
                            setTimeout(function () {
                                location.reload();
                            }, 1500);
                        } else {
                            toastrAlertMessage('error', response.message);
                        }
                    },
                    error: function (err) {
                        var obj = jQuery.parseJSON(err.responseText);
                        for (var x in obj) {
                            toastrAlertMessage('error', obj[x]);
                        }
                    }
                });
            } else {
                if (status == 'active') {
                    $('#userStatus_' + id).prop("checked", true);
                }
                if (status == 'inactive') {
                    $('#userStatus_' + id).prop("checked", false);
                }
            }
        });
    }

</script>

@endsection