@if(count($executives) >0)
<table class="table admin-table" id="data_table">
    <thead>
    <th>Name</th>
    <th>Average Waiting time</th>
    <th>Pending request</th>
    <th>Completed Request</th>
    <th class="th_action no-sort">Action</th>
</thead>
<tbody>
    @foreach($executives as $data)
    <tr>
        <td>{{ucfirst($data->contact_name)}}</td>
        <td>
            <div class="user_tym">
                <i class="far fa-clock"></i>
                {{!empty($data->bank->waiting_time) ? $data->bank->waiting_time : '0'}} min
            </div>
        </td>
        <td>{{\App\Http\Models\CallRequest::getPendingCallRequestByExecutive($data->id,'count')}}</td>
        <td>{{\App\Http\Models\CallRequest::getResolveCallRequestByExecutive($data->id,'count')}}</td>
        <td class="action">
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-h"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="{{url('manager/support-executive-view/'.$data->id)}}">View</a>
                </div>
            </div>
        </td>
    </tr>
    @endforeach
</tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif