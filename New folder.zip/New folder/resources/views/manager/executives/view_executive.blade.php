@extends('manager.layouts.app')
@section('title', 'Executive Detail')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Support Executive View</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/manage-executives')}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="profile-img">
                            <img src="{{getImage($user->profile_image,'users','users')}}" alt="user-img" class="rounded-circle img-fluid">
                        </div>
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                <label>Name</label>
                                <span>{{getFullName($user->first_name ,$user->last_name )}}</span>
                            </li>
                            <li>
                                <label>Support Department (Category)</label>
                                <span>{{$user->bankCategory->name}}</span>
                            </li>
                            <li>
                                <label>Phone Number</label>
                                <span>{{$user->phone_number}}</span>
                            </li>
                            <li>
                                <label>Company</label>
                                <span>{{$user->bank->name}}</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <h5 class="theme-color01 mt-4 mb-3">Merchant Assigned</h5>
                <div class="table-responsive" id="divMerchantAssignedlist">
                </div>
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    $(document).ready(function () {
        getMerchantAssignedlist();
    });
    function getMerchantAssignedlist() {
        pageDivLoader('show', 'divMerchantAssignedlist');
        var searchString = $("#searchFilterForm").serializeArray();
        $.ajax({
            type: "GET",
            url: "{{ url('manager/merchant-assigned-list') }}" + '/' + '{{$user->id}}',
            success: function (response) {
                if (response.success) {
                    $('#divMerchantAssignedlist').html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection