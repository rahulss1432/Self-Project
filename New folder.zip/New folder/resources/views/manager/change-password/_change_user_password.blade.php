<div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title font-hy" id="exampleModalLabel">Change Password</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <form class="f-field" id="changeUserPasswordForm" action="{{url('manager/update-user-password')}}" method="post" autocomplete="off">
        {{ csrf_field() }}
        <input type="hidden" name="user_id" value="{{$user->id}}">
        <div class="modal-body">
            <div class="form-group">
                <input type="password" name="current_password" class="form-control">
                <label class="control-label">Enter Current Password</label>
            </div>

            <div class="form-group">
                <input type="password" name="password" class="form-control">
                <label class="control-label">New Password</label>
            </div>

            <div class="form-group">
                <input type="password" name="password_confirmation" class="form-control">
                <label class="control-label">Confirm New Password</label>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" id="btnChangeUserPassword" class="btn btn-primary ripple-effect-dark">Save
                <i id="btnChangeUserPasswordLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                    
            </button>
            <button type="button" class="btn btn-warning ripple-effect-dark" data-dismiss="modal">Close</button>
        </div>
    </form>
    {!! JsValidator::formRequest('App\Http\Requests\ChangeUserPasswordRequest','#changeUserPasswordForm') !!}    
</div>