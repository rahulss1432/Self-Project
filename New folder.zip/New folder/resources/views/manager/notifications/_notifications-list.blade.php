<li>
    <span class="notification-text">
       Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
    </span>
    <span class="ml-auto date_tym">07/12/2018</span>
</li>
<li>
    <span class="notification-text">
       Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
    </span>
    <span class="ml-auto date_tym">07/12/2018</span>
</li>
<li>
    <span class="notification-text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
    </span>
    <span class="ml-auto date_tym">07/12/2018</span>
</li>
<li>
    <span class="notification-text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
    </span>
    <span class="ml-auto date_tym">07/12/2018</span>
</li>
<li>
    <span class="notification-text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
    </span>
    <span class="ml-auto date_tym">07/12/2018</span>
</li>