@extends('manager.layouts.app')
@section('title','Merchant Request View')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">merchant request view</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" onClick="openEditRequestModal();" class="nav-link">
                            <i class="fas fa-pencil-alt"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="{{url()->previous()}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="profile-img">
                            <img src="{{getImage($callRequest->customerDetail->profile_image,'users','users')}}" alt="user-img" class="rounded-circle img-fluid">
                        </div>
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                <label>Name </label>
                                <span>{{$callRequest->customerDetail->contact_name}}</span>
                            </li>
                            <li>
                                <label>Merchant Processor</label>
                                <span>{{$callRequest->UserProfile->product}}</span>
                            </li>
                            <li>
                                <label>Request generate date</label>
                                <span> {{showFullMonthDateFormat($callRequest->created_at)}}</span>
                            </li>
                            <li>
                                <label>Request Status</label>
                                <span class="status {{$callRequest->status == 'pending' ? 'pending' :  'resolved'}}">{{ucfirst($callRequest->status)}}</span>
                            </li>
                            <li>
                                <label>SE Assigned </label>
                                <span>{{$callRequest->executiveDetail->contact_name}}</span>
                            </li>
                            <li>
                                <label>Recorded Video</label>
                                <span><a href="javascript:void(0);" onClick="playVideo({{$callRequest->video_link}});">Play Video</a></span>
                            </li>
                            <li>
                                <label>Rating</label>
                                <span class="rating">
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                </span>
                            </li>
                            <li>
                                <label>Request Category</label>
                                <span>{{$callRequest->BankCategory->name}}</span>
                            </li>
                            <li>
                                <label>Total time of Call</label>
                                <span><i class="far fa-clock"></i> {{$callRequest->call_time}} mins</span>
                            </li>
                            <li>
                                <label class="notes_label">Notes</label>
                                <p class="mb-0">{{$callRequest->notes}}</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!--edit merchant request model -->
<div class="modal fade common-modal edit-modal" id="divEditRequestModal" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="EditmodalModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content history-modal">
            <div class="modal-header align-items-center">
                <div class="col text-left p-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="col p-0 text-center">
                    <h5 class="modal-title" id="divEditRequestModalBody">Edit</h5>
                </div>
                <div class="col p-0 text-right">
                </div>
            </div>
            <div class="modal-body" id="editMerchantReqestModalBody">
            </div>
        </div>
    </div>
</div>

<div class="modal fade common-modal vdo-modal" id="playVideo" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="playVideoModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content history-modal">
            <div class="modal-header align-items-center">
                <div class="col text-left p-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="col p-0 text-center">
                    <h5 class="modal-title" id="playVideoModalLabel">Recorded Video</h5>
                </div>
                <div class="col p-0 text-right">

                </div>
            </div>
            <div class="modal-body">
                <video width="100%" controls>
                    <source src="videos/SampleVideo.mp4" type="video/mp4">
                    Your browser does not support HTML5 video.
                </video>
            </div>
        </div>
    </div>
</div>

<script>
function openEditRequestModal() {
    $.ajax({
        type: "GET",
        url: "{{ url('manager/edit-merchant-request-modal')}}"+'/'+"{{$callRequest->id}}",
        success: function(response) {
            if (response.success) {
                $('#editMerchantReqestModalBody').html(response.html);
                $('#divEditRequestModal').modal("show");
                $('.selectpicker').selectpicker('refresh');
            } else {
                toastrAlertMessage('error', response.message);
            }
        },
        error: function(err) {
            var obj = jQuery.parseJSON(err.responseText);
            for (var x in obj) {
                toastrAlertMessage('error', obj[x]);
            }
        }
    });
}

function playVideo() {
    $("#playVideo").modal('show');
}

</script>

@endsection