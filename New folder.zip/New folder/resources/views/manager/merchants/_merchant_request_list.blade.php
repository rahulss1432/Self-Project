@if(count($callRequests) >0)
<table class="table admin-table" id="data_table">
    <thead>
    <th>Name</th>
    <th>Processor</th>
    <th>Generate Date</th>
    <th>Status</th>
    <th>SE Assigned</th>
    <th>Category</th>
    <th>Time of Call</th>
    <th class="th_action no-sort">Action</th>
</thead>
<tbody>
    @foreach($callRequests as $request)  
    <tr id="{{'callRequest_'.$request->id}}">
        <td class="min200">
            <div class="user_detail">
                <h4>{{$request->customerDetail->contact_name}}</h4>
                <p class="mb-0">{{!empty($request->customerDetail->bank->name) ? $request->customerDetail->bank->name : ''}}</p>
            </div>
        </td>
        <td>{{$request->UserProfile->product}}</td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> {{showFullMonthDateFormat($request->created_at)}}
            </div>
        </td>
        <td>
            <div class="user_status {{$request->status == 'pending' ? 'pending' :  'resolved'}}">
                <span>{{ucfirst($request->status)}}</span>
            </div>
        </td>
        <td>{{$request->executiveDetail->contact_name}}</td>
        <td>{{!empty($request->BankCategory->name) ? $request->BankCategory->name : ''}}</td>
        <td>
            <div class="user_tym">
                <i class="far fa-clock"></i> {{$request->call_time}} mins
            </div>
        </td>
        <td class="action">
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-h"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="{{url('manager/merchant-request-view',$request->id)}}">View</a>
                </div>
            </div>
        </td>
    </tr>
    @endforeach    
</tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
