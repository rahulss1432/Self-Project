@if(count($merchantCall) >0)
<table class="table admin-table" id="data_table">
    <thead>
    <th>Name</th>
    <th>Processor</th>
    <th>Generate Date</th>
    <th>Status</th>
    <th>SE Assigned</th>
    <th>Category</th>
    <th>Call of Time</th>
    <th class="th_action no-sort">Action</th>
</thead>
<tbody>
    @foreach($merchantCall as $call)
    <tr>
        <td class="min200">
            <div class="user_detail">
                <h4>{{$call->customerDetail->contact_name}}</h4>
                <p class="mb-0">{{!empty($call->executiveDetail->bank->name) ? $call->executiveDetail->bank->name : ''}}</p>
            </div>
        </td>
        <td>{{!empty($call->UserProfile->product) ? $call->UserProfile->product : ''}}</td>
        <td>
            <div class="user_date">
                <i class="icon-calendar"></i> 
                @php
                echo $generateDate = date('d M Y',strtotime($call->created_at));
                @endphp
            </div>
        </td>
        <td>
            <div class="user_status {{$call->status == 'resolved' ? 'resolved' : 'pending'}}">
                <span>{{ucfirst($call->status)}}</span>
            </div>
        </td>
        <td>{{$call->executiveDetail->contact_name}}</td>
        <td>{{$call->BankCategory->name}}</td>
        <td>
            <div class="user_tym">
                <i class="far fa-clock"></i> {{$call->call_time}} mins
            </div>
        </td>
        <td class="action">
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-h"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="{{url('manager/merchant-request-view/'.$call->id)}}">View</a>
                </div>
            </div>
        </td>
    </tr>
    @endforeach
</tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif