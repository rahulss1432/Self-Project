@extends('manager.layouts.app')
@section('title', 'Add Merchant')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">add merchant</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/manage-merchant')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <form id="addMerchantForm" autocomplete="off" class="f-field" method="POST" action="{{url('manager/save-merchant')}}">
                    {{csrf_field()}}
                    <div class="row">
                        <div class="col-sm-6">
                            @php
                            $executives = \App\Http\Models\User::getExecutivesLinkedById();
                            @endphp                            
                            <div class="form-group">
                                <select class="form-control selectpicker" id="selectExecutive" name="executive[]"  multiple data-actions-box="true" title="Select Support Executive" data-size="5">
                                    @if(count($executives)>0)
                                    @foreach($executives as $executive)
                                    <option value="{{$executive->id}}">{{ucfirst($executive->contact_name)}}</option>
                                    @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="username" class="form-control">
                                <label class="control-label">Username</label>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="password" name="password" class="form-control">
                                <label class="control-label">Password</label>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="merchant_number" class="form-control">
                                <label class="control-label">Merchant Number</label>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="terminal_model" class="form-control">
                                <label class="control-label">Terminal Model</label>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="contact_name" class="form-control">
                                <label class="control-label">Contact Name</label>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="bussiness_name" class="form-control" >
                                <label class="control-label">Business Name</label>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">                                
                                <input type="text" name="bussiness_address" class="form-control" >
                                <label class="control-label">Business Address</label>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="product" class="form-control" >
                                <label class="control-label">Merchant Processor</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="phone" class="form-control" >
                                <label class="control-label">Phone Number</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="email" class="form-control" >
                                <label class="control-label">Email Address</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="city" class="form-control" >
                                <label class="control-label">City</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" name="state" class="form-control" >
                                <label class="control-label">State</label>
                            </div>
                        </div>                        
                    </div>
                    <div class="form-group">
                        <button id="btnSubmitForm" type="submit" class="btn btn-primary ripple-effect-dark">Send
                            <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                    
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Manager\AddMerchantRequest','#addMerchantForm') !!}                
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
//        back button loader
    function backLoader() {
        $("#backLoader").html('<i class="fa fa-spinner fa-spin"></i>');
    }

//       submit add executive form
    $(document).on('submit', '#addMerchantForm', function (e) {
        e.preventDefault();
        if ($('#addMerchantForm').valid()) {
            $('#btnSubmitForm').prop('disabled', true);
            $('#btnSubmitLoader').show();
            $.ajax({
                url: "{{ url('manager/save-merchant') }}",
                data: $('#addMerchantForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('manager/manage-merchant')}}";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnSubmitForm').prop('disabled', false);
                    }
                    $('#btnSubmitLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#btnSubmitForm').prop('disabled', false);
                }
            });
        }
    });

    /* image uploading with cropper*/
//    function uploadFile(thisEl) {
//        if (thisEl.files[0]) {
//            var inputFile = thisEl.files[0].name;
//            var extension = inputFile.substr(inputFile.lastIndexOf('.') + 1); /*get file exension*/
//            /*check file type and exension*/
//            if (extension != 'jpg' && extension != 'jpeg' && extension != 'png') {
//                toastrAlertMessage('error', 'Image allows only in jpeg, png or jpg format');
//                $('#imageUpload').val('');
//                $('#hiddenMediaFileName').val('');
//                return false;
//            }
//            var formData = new FormData($('#addMerchantForm')[0]); /*uploading on server via ajax call*/
//            formData.append('_token', '{{ csrf_token() }}');
//            $.ajax({
//                url: "{{url('manager/upload-media-image')}}",
//                type: 'POST',
//                data: formData,
//                processData: false,
//                cache: false,
//                contentType: false,
//                success: function (response) {
//                    loadImageCropperModal(response.filename);
//                    $('#cropper-image-modal').modal('show');
//                }
//            });
//        }
//    }
//
//    function loadImageCropperModal(imageName) {     /*open cropper model*/
//        $.ajax({
//            url: "{{url('manager/load-image-cropper')}}",
//            type: 'GET',
//            data: {imageName: imageName, type: 'profile_image'},
//            success: function (response) {
//                $('#image-cropper-form').html(response.html);
//            }
//        });
//    }

//        $('#imageUpload').bind('change', function () {
//            var filename = $("#imageUpload").val();
//            if (/^\s*$/.test(filename)) {
//                $(".file-upload").removeClass('active');
//                $("#noFile").text("No file chosen...");
//            }
//            else {
//                $(".file-upload").addClass('active');
//                $("#noFile").text(filename.replace(/C:\\fakepath\\/i, ''));
//            }
//        });

    $('.form-group .form-control').focus(function ()
    {
        $(this).parent().addClass('isfocused');
    }).blur(function ()
    {
        $(this).parent().removeClass('isfocused');
    });
</script>
@endsection