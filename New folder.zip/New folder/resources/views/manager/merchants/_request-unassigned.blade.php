<table class="table admin-table" id="data_table">
    <thead>
    <th colspan="2">Name</th>
    <th> Processor</th>
    <th>Generate Date</th>
    <th>Status</th>
    <th>SE Assigned</th>
    <th>Category</th>
    <th>time of Call</th>
    <th class="th_action no-sort">Action</th>
</thead>
<tbody>
    <tr>
        <td class="w-65">
            <img src="user01.jpg" alt="user" class="rounded-circle user_img">
        </td>
        <td class="min200">
            <div class="user_detail">
                <h4>Micah Chan</h4>
                <p class="mb-0">American Express Bank</p>
            </div>
        </td>
        <td>Callisto</td>
        <td>23 Aug 2018</td>
        <td>
            <div class="user_status pending">
                <span>Pending</span>
            </div>
        </td>
        <td>Elmo Pratt</td>
        <td>Product Upgrade</td>
        <td>
            <div class="user_tym">
                <i class="far fa-clock"></i> 15 mins
            </div>
        </td>

        <td class="action">
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-h"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="{{url('manager/merchant-request-view')}}">View</a>
                </div>
            </div>
        </td>
    </tr>
</tbody>
</table>