@extends('manager.layouts.app')
@section('title', 'View Documents')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">View Documents</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/manage-document')}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-6">
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                <label>Bank Name</label>
                                <span>{{$document->bank->name}}</span>
                            </li>
                            <li>
                                <label>Title</label>
                                <span>{{$document->title}}</span>
                            </li>
                            <li>
                                <label>Created Date</label>
                                <span>{{$document->created_at}}</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection