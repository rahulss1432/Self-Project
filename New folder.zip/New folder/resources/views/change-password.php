<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Change Password</title>
        <!-- Bootstrap -->
        <?php include 'include/links.php' ?>
    </head>
    <?php $currentPageName = 'Setting'; ?>
     <body class="bg-light-gray"  onload="hide_preloader();">

        <div id="preloader">
            <div class="inner">
                <div class="spinner">
                    <div class="rect1"></div>
                    <div class="rect2"></div>
                    <div class="rect3"></div>
                    <div class="rect4"></div>
                    <div class="rect5"></div>
                </div>
            </div>
        </div>
         
        <?php include 'include/side-menu.php' ?>
        <?php include 'include/header.php' ?>
        <main class="main-content id="mainContent">
            <div class="page-content">
                <div class="card custom_card" id="card_height">
                    <div class="card-header">
                        <h4 class="page-title float-left">Change Password</h4>
                        <ul class="list-inline mb-0 text-right">
                            <li class="list-inline-item">
                                <a href="dashboard.php" class="nav-link" title="Back"><i class="ti-arrow-left"></i></a> 
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <form class="f-field">
                            <div class="row">
                                <div class="col-sm-6 col-xs-12">
                                    <div class="form-group">
                                        <input type="password" id="cp" class="form-control form-control-lg" required />
                                        <label class="control-label" for="cp">Current Password</label>


                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-12">
                                    <div class="form-group">
                                        <input type="password" class="form-control form-control-lg"  required/>
                                        <label class="control-label" >New Password</label>

                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-6 col-xs-12">
                                    <div class="form-group">
                                        <input type="password" class="form-control form-control-lg"  required/>
                                        <label class="control-label" >Confirm password</label>

                                    </div>
                                </div>
                            </div>

                            <div class="from-group">
                                <button type="submit" class="btn btn-sm btn-primary ripple-effect"> Update <i class="fa fa-spinner ml-1 fa-spin d-none"></i></button>
                            </div>
                            
                        </form>               
                    </div>
                </div>
            </div>
        </main>
        <?php include 'include/footer.php' ?>

    </body>
</html>